# Examen de grado · administracin-enero-2020

Fuente: examen anterior

[pág. 1]
PONTIFICIA UNIVERSIDAD CATÓLICA DE CHILE
 ESCUELA DE ADMINISTRACIÓN
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
 alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
 hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
 hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
 que los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
 realidad de las empresas que allí se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
 dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
 misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente a la Profesora Marta Del Sante, Presidente de la Comisión
 de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
 cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
 condiciones, la Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala ni relojes inteligentes, los que
 deberán estar apagados y guardados en las mochilas adelante.
12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
 examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
 identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
 como “borrador”, esas hojas no se deben entregar con las respuestas.
Fecha : 24 de enero de 2020
Duración : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá la Profesora
 Marta Del Sante, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 y
 11:00 hrs. (aprox.).

[pág. 2]
2
PREGUNTA Nº1
Jorge Salmon, gerente general de Redington, pequeña empresa que fabrica cañas para la pesca con mosca, se
preguntaba cuál sería la mejor estrategia de crecimiento para este año 2020. Las ventas del año 2019 de
Redington habían logrado el presupuesto establecido para el año. Para este año, Jorge había presupuestado un
crecimiento en ventas del 20% con respecto al año anterior y no estaba seguro de cuál era la mejor forma de
lograrlo.
La Pesca con Mosca
La pesca con mosca es una actividad que tiene por objeto la captura de peces, tanto en agua salada como dulce,
con una finalidad comercial, alimenticia, deportiva, turística o de pasatiempo. Este tipo de pesca no admite el
uso de redes, trampas, espineles, arpones, etc. Como en todo deporte, en la pesca con mosca el equipo resulta
fundamental a la hora de llevar a cabo esta actividad. Los elementos básicos para llevar a cabo este deporte
son una caña, carrete, varilla y línea. La caña es la extensión del brazo del pescador, permitiéndole lanzar, dar
dirección a la línea y pelear al pez. Las primeras cañas fueron de bambú, siendo reemplazadas por las de fibra
de vidrio, y éstas por las de grafito, tratando siempre de lograr menor peso con la mayor resistencia y
flexibilidad posible. Las cañas son sin duda, el elemento más preciado del pescador con mosca, y se diferencian
por su numeración, el alcance y su longitud.
El Mercado de la Pesca con Mosca y Redington
La pesca con mosca es un mercado que se encuentra en crecimiento en nuestro país y abarca tanto a los hombres
como a las mujeres. La industria clasifica a los consumidores en cuatro segmentos: principiantes, ocasionales,
serios y profesionales. Los pescadores serios y profesionales representan el 80% del gasto en equipos de pesca,
sin embargo, representan el 5% y el 40% de los pescadores respectivamente.
Redington ofrece una amplia línea de cañas para la pesca con mosca para distintos tipos de pescadores. En
general, sus cañas se caracterizan por tener un buen desempeño a un precio medio. Los precios de las cañas de
pescar de Redington varían entre $150.000 y $450.000, con un precio promedio de $250.000. Su precio es
consistente con muchos de los de sus competidores directos para una caña de calidad dirigida principalmente
a los pescadores serios, sin embargo las marcas más prestigiosas, como: St.Croix, Shimano, Penn, Okuma y
Wilson por nombrar algunas, tenían precios superiores a los $700.000.
En el mercado de la pesca con mosca se pueden encontrar cañas que van desde los $100.000 para el segmento
principiante, hasta aproximadamente entre $700.000 y $800.000 para el segmento profesional.
Redington ha desarrollado una relación cercana con muchos de sus distribuidores minoristas de equipos de
pesca, que contaban con tiendas especializadas, las cuales representan aproximadamente el 70% de sus ventas
en valor y 50% en volumen. El 50% restante del volumen de ventas, se comercializa a través del canal
mayorista y la página web de Redington. A fines del 2019 la empresa contaba con 50 distribuidores minoristas
en Santiago y regiones, especializados en pesca con mosca como: Fly Shop, Flyfishing store, Pesca Total, Rod
and Gun, etc. Además, la marca se encuentra en casi todos los lodges1 de pesca del sur de nuestro país. En
general, los distribuidores minoristas como lodges, ofrecen distintas marcas de caña para pesca con mosca para
los segmentos serios y profesionales. Redington le ofrece distintos servicios a sus distribuidores minoristas:
los modelos de cañas de su línea de productos de acuerdo a las necesidades de cada uno de ellos, capacitación
a los vendedores, ya que la compra de una caña para los segmentos serios y profesional requiere de la ayuda y
recomendación del vendedor del local, y al mismo tiempo ofrece excursiones programadas de pesca a distintos
lugares para los potenciales interesados que los distribuidores se encargan de promocionar.
1 Los lodges son alojamientos ubicados en destinos no masivos, apartados de las grandes ciudades, rodeados de naturaleza y construidos
en madera y materiales amigables con el medio ambiente.

[pág. 3]
3
Estrategias de Crecimiento para Redington
Oscar “Jurel” Herrera, gerente de ventas de Redington, planteaba que la mejor estrategia para lograr la meta
de crecimiento en ventas de la empresa, era a través de la incorporación de la cadena de tiendas de deporte
Decathlon como nuevo canal de venta de las cañas de pescar de Redington. Según Herrera, este canal ya estaba
ofreciendo cañas para pesca con mosca principalmente para los pescadores principiantes y ocasionales. Por lo
tanto, según él, las marcas que ya estaban en esta cadena no representaban una competencia directa para
Redington. Además, otro beneficio para Redington era que la orden de compra inicial de Decathlon sería más
grande comparada a lo que piden el resto de los distribuidores de la empresa.
Decathlon es una cadena de deportes multinacional francesa que nació en 1976 con la idea de hacer accesible
el deporte a un mayor número de personas, desde que se inician en un deporte, hasta que se convierten en
expertos. Sus tiendas se caracterizan por tener entre 1.000 y 12.000 metros cuadrados en las cuales se ofrecen
productos y marcas para más de 70 deportes bajo el mismo techo y donde los clientes eligen sus productos a
través de un sistema de autoservicio. Decathlon tiene un posicionamiento de precios bajos y un gran surtido
de productos y marcas. En nuestro país, Decathlon ya cuenta con dos locales: uno en la comuna de La Reina
y el otro en el mall recientemente inaugurado Open Kennedy. Se espera que en los próximos dos años abran
20 nuevos locales en nuestro país.
Por su parte, Renato “Tiburón” Ramos, gerente de Marketing de Redington, planteaba que la mejor estrategia
era incorporar una caña de pescar de más alta calidad en relación a su actual línea de productos lo que les
permitiría diferenciarse de su competencia directa. Específicamente, planteaba incorporar la nueva marca
Crux, la cual contaría con el aval de la marca Redington. Esta nueva marca se caracterizaría por ser la mejor
caña que haya sido fabricado por Redington, ya que incorporaría una tecnología innovadora denominada Line
Speed Taper y nuevos puños Angled Key Grip. La nueva marca se caracterizaría por su menor peso, su alcance,
longitud y el ser producida por materiales nobles y de manera artesanal. Ésta estaría orientada
fundamentalmente al mercado profesional y su precio de venta a público se espera que alcance los $550.000.
De acuerdo a Ramos, llevar a cabo esta opción implicaba un alta inversión que tendría que llevar a cabo
Redington. En efecto, la orden mínima de producción era de 7.000 nuevas cañas de pescar Crux lo que
representaba aproximadamente un 25% del volumen de cañas de pescar de la empresa. Según él, este riesgo
se justificaría ya que la empresa necesitaba lograr las metas de crecimiento para este año. Además, con esta
nueva marca podrían ampliar la base del segmento de pescadores serios y alcanzar al segmento profesional.
PREGUNTAS
a) Desde el punto de vista de marketing, y de acuerdo a los conceptos de estrategia de producto y distribución,
 señale y explique claramente las tres principales desventajas de las estrategias planteadas en su conjunto
 por ambos gerentes para lograr los objetivos de crecimiento de Redington. (no necesita señalar 3
 desventajas por cada una de las estrategias, sólo 3 en su conjunto). Justifique claramente su respuesta.
b) Desde el punto de vista de marketing, y de acuerdo a los conceptos de estrategia de marca, ¿qué le parece
 la estrategia de marca sugerida por Renato “Tiburón” Ramos, gerente de marketing de Redington, para
 lograr los objetivos de crecimiento? ¿Buena? ¿Mala? Señale y explique claramente las dos principales
 razones que justifican su respuesta.

[pág. 4]
4
PREGUNTA Nº2
La Empresa Eléctrica Río Claro suministra servicios de construcción de infraestructura e instalaciones
eléctricas en un mercado de varios miles de pequeñas y medianas empresas. La empresa compite con otras en
el mercado y se ha posicionado como un proveedor de servicios de calidad y rapidez.
Jorge Valdivia es el sub-gerente a cargo de todos los equipos humanos encargados de las instalaciones y
reparaciones de los sistemas eléctricos. Cada equipo está formado aproximadamente por siete empleados que
trabajan juntos para responder a las llamadas relativas a interrupciones en el suministro, incendios provocados
por el mal funcionamiento del sistema eléctrico y a la instalación de nuevos equipos o líneas eléctricas.
Dependiendo de la complejidad de los proyectos en que estos equipos trabajan estos están conformados por
diferentes combinaciones de ingenieros eléctricos, técnicos electricistas, expertos en seguridad industrial y en
certificación de normas nacionales sobre instalaciones eléctricas. Cada uno de estos miembros contribuye al
logro de los objetivos de su equipo desde sus especialidades técnicas en tareas de alta interdependencia. Los
equipos suelen trabajar juntos desde un mínimo de 3 a 4 meses hasta muchos años seguidos. La empresa se
sentía orgullosa de que sus equipos de instalaciones y reparaciones eléctricas estaban conformados en un 35%
por mujeres, cifra que era muy superior al 15% observado en el resto de la industria.
Hace catorce meses Valdivia decidió poner en marcha un sistema de incentivos mediante el cual se daría a
cada equipo un premio anual en dinero si lograban ciertos resultados. Valdivia apuntaba a mejorar la gestión
de sus equipos fomentando el emprendimiento de estos grupos y, de este modo, conseguir llevarlos a un alto
nivel de auto-gestión. Las medidas de rendimiento incluían indicadores como el tiempo medio necesitado para
efectuar una faena (ejemplo: restablecer el suministro), los resultados de evaluaciones de satisfacción de
clientes y el número de horas usadas para realizar de forma correcta un proyecto asignado.
Al final del primer año, cinco equipos recibieron el incentivo anual, reflejo de las mejoras en productividad y
satisfacción de los clientes, con un promedio de siete millones de pesos cada equipo. Según las bases del
sistema (comunicadas inicialmente), el monto del incentivo se distribuyó proporcionalmente, en función de
los sueldos base de cada miembro del equipo.
Poco después de que anunciara los grupos que recibirían los premios, Valdivia empezó a recibir una gran
cantidad de quejas. Algunos de los equipos que no habían obtenido el incentivo expresaron su insatisfacción
directamente a Valdivia, otros a través de una encuesta anónima que Valdivia distribuyó entre los miembros
de todos los equipos para evaluar el funcionamiento del nuevo sistema de incentivos. Algunas de las quejas
más comunes insistían en que los equipos que habían tenido que trabajar en los proyectos más complicados
eran penalizados (debido a que les resultaba más difícil obtener una buena puntuación en la evaluación).
También se quejaron de que los equipos que no dedicaban tiempo a colaborar con otros equipos (perjudicando
al resto), eran precisamente los equipos recompensados. Por último, algunos de los participantes en estos
equipos se quejaron de sospechar que, como las horas dedicadas a cada proyecto eran informadas
subjetivamente por cada equipo, los equipos ganadores podían estar alterando el número de horas dedicadas a
los proyectos, para ganarse los incentivos.
Para sorpresa de Valdivia, los miembros de los equipos que recibieron los premios también expresaron su
insatisfacción. Los trabajadores de los equipos recompensados opinaban en las encuestas que el sistema era
injusto, debido a que los montos individuales del incentivo no reflejaban las contribuciones propias de cada
integrante del equipo. Algunas opiniones nombraban a “…sacadores de vuelta…” que habían recibido “…más
de lo que correspondía a su participación”, ya que llegaban tarde con frecuencia a trabajar, alargaban
demasiado el tiempo de sus almuerzos, paraban muchas veces para descansar y fumar, y carecían de iniciativa.
Además, las integrantes mujeres de estos equipos ganadores, se quejaron de que sus incentivos eran
proporcionalmente menores a las de sus pares hombres, ya que ellas eran perjudicadas al ser el incentivo
calculado en proporción a los sueldos base, debido a que la empresa reflejaba la misma disparidad de

[pág. 5]
5
remuneraciones base entre hombres y mujeres observable a nivel nacional, lo que ellas consideraban injusto.
Valdivia sabía que todos los equipos contaban con las competencias y condiciones para ser más productivos y
ganarse los premios, sin embargo, no sabía qué hacer.
El gerente general le recomendó un consultor de RRHH, quién después de escuchar la situación descrita por
Jorge, le respondió: “Esta empresa debe ponerse a tono con los tiempos. Debe subir los sueldos y eliminar el
sistema de incentivos. Sugiero un sistema 10X”. Al ver que Jorge no conocía lo que era un sistema 10X el
consultor prosiguió: “10X es una iniciativa que se ha planteado en redes sociales en medio de la crisis social,
como un llamado a empresarios para sumarse a una iniciativa que podría aumentar los salarios: Las empresas
se comprometen a que la brecha máxima entre quién gana más y quién gana menos en la empresa es de 10
veces el sueldo de quién tiene la menor remuneración", aseguró. “Lo que propongo es eliminar el sistema de
incentivos e implementar el sistema 10X”, terminó de comentar el consultor.
PREGUNTAS
a) Identifique dos problemas centrales relacionados con el diseño y aplicación de planes de retribución por
 rendimiento (incentivos) que ilustra este caso. Razone su respuesta.
b) Proponga dos intervenciones a incorporar en esta empresa, para mantener la motivación y productividad
 de los equipos al momento de implementar el sistema 10X y lograr los objetivos de negocio de la compañía.
 Indique de qué manera esas intervenciones lograrían estos propósitos.
c) Identifique dos potenciales problemas que se podrían presentar en la empresa al intentar implementar el
 sistema 10X.

[pág. 6]
6
PREGUNTA Nº3
“San Roque” es una empresa dedicada al transporte de rocas para la construcción de “roqueríos”, que opera
con un camión de manera permanente, el que cada cierto tiempo debe ser reemplazado por uno nuevo.
Camión Petrolero:
Hoy, 31 de diciembre de 2019, la empresa dispone de un camión petrolero (en adelante “el petrolero”), que
fue comprado nuevo por “San Roque” el 31 de diciembre de 2014. El costo de adquisición del “petrolero”,
fue de MM$ 64 (millones de $), precio pagado al contado. Al momento de su adquisición, el “petrolero” tenía
una vida útil (VU) de 8 años, un valor residual (VR) o de desecho para fines contables y tributarios de MM$
0 y se deprecia linealmente. La empresa “San Roque”, sabe que, si el camión “petrolero” se vende antes del
término de su vida útil o al término de ella, su precio de venta en el mercado (PV) sería de MM$ 0. La operación
anual del “petrolero”, le significa a “San Roque”, un total de egresos de caja, tanto cuando el camión está
nuevo, como en la actualidad, de MM$ 20, antes de impuestos.
Se sabe que este modelo de camión “petrolero”, se encuentra siempre disponible en el mercado, manteniendo
sus características operacionales y financieras: costo de adquisición = MM$ 64 (contado); total egresos de
caja anuales (antes de impuestos) = MM$ 20; V.U. = 8 años; VR = MM$ 0; PV (antes o a fines del año 8 de
uso) = MM$ 0.
En este momento se ha comenzado a ofrecer en el mercado un nuevo modelo de camión, que para su operación
usaría energía eléctrica (en adelante “el eléctrico”), y que se sabe cumpliría perfectamente con los
requerimientos técnicos que “San Roque” exige a sus camiones.
Camión Eléctrico:
El costo de adquisición del eléctrico es de MM$ 100 (precio contado), tiene una vida útil (VU) de 10 años, un
valor residual (VR) o de desecho para fines contables y tributarios de MM$ 10 y se deprecia linealmente. Se
estima que al término de su vida útil (fines del año 10 de uso), este camión, “eléctrico” podría ser vendido
(PV) en MM$ 14 (al contado). La operación anual del “eléctrico”, le significaría a “San Roque”, un total de
egresos de caja de MM$ 15 antes de impuestos. En caso de comprar este camión, la empresa no lo vendería
antes del término de su vida útil.
Se sabe que este modelo de camión “eléctrico”, se encontraría siempre disponible en el mercado, manteniendo
sus características operacionales y financieras: costo de adquisición = MM$ 100 (contado); total egresos de
caja anuales (antes de impuestos) = MM$ 15; V.U. = 10 años; VR = MM$ 10; PV (fines del año 10 de uso) =
MM$ 14.
En este momento, la empresa “San Roque”, se encuentra evaluando las siguientes tres opciones, mutuamente
excluyentes:
Opción 1: Cambiar hoy el camión petrolero por un camión eléctrico y en el futuro seguir operando
siempre con camiones eléctricos.
Opción 2: No cambiar hoy el camión petrolero, pero sí cambiarlo por un camión eléctrico al término de
su vida útil, esto es, dentro de tres años. Luego de dicho cambio, seguir operando siempre con camiones
eléctricos.
Opción 3: No cambiar hoy el camión petrolero y seguir operando con él durante los tres años que le
restan de vida útil y al término de esos tres años, volver a invertir en la compra de un nuevo camión petrolero,
y al término de su vida útil, renovarlo por el mismo tipo de camión de manera indefinida, de modo de seguir
operando de manera permanente con camiones petroleros.

[pág. 7]
7
Suponga que:
  Todos los flujos de caja relacionados con los distintos proyectos anteriores, se producen el último día
 de cada año y comienzan a producirse exactamente un año después de realizada la inversión inicial.
  El “Costo de Capital Promedio Ponderado” (después de impuestos), relevante para la evaluación
 financiera de ambos camiones, es de 8% anual.
  La Tasa de Impuestos es de 25%; Inflación = 0%
  La empresa minera “San Roque” requiere seguir contando con un camión para el transporte de rocas,
 de manera permanente y en forma indefinida.
  La disponibilidad de cualquier camión nuevo, es “instantánea”, es decir, comienza a operar de
 inmediato y a generar sus flujos justo un año después de su inversión inicial.
  Los ingresos por ventas anuales que se pueden generar con cada uno de los dos tipos de camiones son
 los mismos.
  Para efectos tributarios “San Roque” utiliza depreciación lineal y tiene suficientes ingresos como para
 absorber cualquier costo y gasto derivado de la operación de los camiones.
  Trabaje las cifras en millones de $ (MM$) y con dos decimales.
A usted se le pide, evaluar desde un punto de vista financiero, las tres opciones o alternativas, mutuamente
excluyentes, de reemplazo de los camiones de la minera “San Roque”, indicando claramente cuál de las tres
alternativas, es la más conveniente para la empresa. Explique claramente su respuesta y para sus cálculos, si
lo requiere, utilice las tablas de matemáticas financieras que se adjuntan al final del enunciado. De cualquier
modo, todo cálculo numérico debe estar suficientemente respaldado por la expresión matemática que lo ha
originado.

[pág. 8]
8
PREGUNTA Nº4
 Delta y Latam una alianza con Impacto
Delta Airlines Inc. está expandiendo fuertemente su presencia en América Latina, gracias a un acuerdo de US$
2.250 millones con LATAM, la aerolínea más grande de la región. El acuerdo contempla que Delta pagará
US$ 1.900 millones por una participación de 20% en LATAM, a través de una oferta pública de adquisición a
US$ 16 por acción (que ya fue declarada exitosa), más US$ 350 millones que Delta invertirá para deshacer los
lazos que hoy unen a LATAM con American Airlines, su archirrival, a través de la alianza Oneworld. Para
Delta, el acuerdo le permite continuar con la estrategia de expansión internacional que viene siguiendo desde
hace algún tiempo mediante la compra de participaciones en aerolíneas extranjeras. Así, LATAM se agrega a
una lista de socios que incluye al Grupo Aeroméxico SAB, Air France-KLM y Korean Airlines Co.
LATAM y su historial de Alianzas y Asociaciones
Para LATAM esto de las asociaciones no es nuevo. Ya en 2012 LAN y TAM sorprendieron al mercado
anunciando la unión de ambas compañías. También, el 2019 y ya como LATAM, se intentó un acuerdo
comercial con American Airlines, el cual fue frustrado por el dictamen de la Corte Suprema chilena que
impidió que esta asociación se llevara a cabo.
 “Tenemos experiencia valiosa en alianzas” declaraba Enrique Cueto, Gerente General de LATAM en una
entrevista publicada con ocasión del ingreso de Delta a la compañía. En efecto, ya en 2012 LAN anunció la
fusión con TAM dando origen a LATAM. Una fusión que, a juicio de algunos analistas, fue estratégica para
LAN, pero cara. Estratégica, porque accedía al mercado brasilero, el mayor en Latinoamérica. Cara, porque
los resultados distaron mucho de lo proyectado, ya que la integración de ambas compañías resultó ser más
compleja de lo que se pensaba. Como consecuencia de lo anterior, las utilidades de la compañía unida se
desplomaron, las sinergias no fueron las previstas, el negocio en Brasil fue un verdadero dolor de cabeza y a
eso se suma la pérdida del "investment grade"(Ver Nota #1) que obligó a LATAM a realizar un aumento de
capital de 1.000 millones de dólares. Como consecuencia de lo anterior, la valorización de mercado de LATAM
pasó de US$ 14.000 millones a US$ 6.500 millones. Pese a todo, LATAM sigue siendo hoy en día una empresa
con un desempeño superior que sus competidores en Latinoamérica.
Por otra parte, en 2019 LATAM buscó concretar un acuerdo con American Airlines para compartir rutas. Era
un acuerdo sólo comercial dentro de la alianza Oneworld a la que pertenecían ambas aerolíneas, el cual
permitiría ofrecer códigos compartidos entre ellas, aumentando la oferta de viajes para cada aerolínea. No
obstante, y pese a que tanto LATAM como American coincidían en un número importante de rutas (en especial
Santiago-Miami), lo que bajaba el nivel de integración efectivo que pudiera lograrse, la Corte Suprema en
Chile consideró el acuerdo como contrario a la libre competencia por la alta concentración que generaría en
las rutas de Norteamérica y Europa.
El mercado aéreo: competitivo y cada vez más sofisticado
Volar hoy en día genera desafíos importantes para cualquier compañía aérea. En efecto, las exigencias de los
clientes, el alto nivel de competencia existente en la industria, la tendencia descendente de los precios, y la
cada vez mayor concentración existente en el sector, explican este fenómeno. Por tanto, hoy en día competir
con éxito en la industria aérea exige de cualquier compañía relevante conjugar muy buenas tarifas con buenos
niveles de servicios, destacándose dentro de esto último, las rutas disponibles, flexibilidad de horarios, y
conexiones eficientes especialmente en mercados altamente desarrollados, como es el caso del mercado
norteamericano.

[pág. 9]
9
Los Beneficios de la Alianza LATAM - Delta
La alianza lograda es mucho más que un acuerdo comercial. Ella permitirá contar con una flota mayor, ya que
como parte del acuerdo, Delta adquirirá cuatro aviones A350 de Airbus SE para la flota de larga distancia de
LATAM, más otros diez aviones cuyas entregas estaban programadas a partir del 2020 y hasta el 2025.
Adicionalmente LATAM mantendrá la compra de ocho aviones A350.
Con la alianza, Delta Airlines obtiene acceso privilegiado a algunos de los mercados más importantes y de más
rápido crecimiento de América Latina, como es el caso de Brasil que representa el 30% del negocio general
de LATAM. Esto generará nuevas oportunidades de crecimiento, y le permitirá a Delta ofrecer una extensa
red de destinos alrededor del mundo con una experiencia de viaje más fluida y una mejor conexión a nivel
mundial. A lo anterior hay que sumar una presencia más activa de Delta en tres países con los que Estados
Unidos tiene acuerdos de cielos abiertos (Ver Nota #2): Chile, Colombia y Perú. En total, la alianza le
significará sumar 435 nuevos destinos alrededor del mundo a la oferta actual de Delta. Con todo lo anterior,
Delta quedará pisando los talones al líder del sector, American Airlines, su rival de siempre.
Por su parte, LATAM con esta alianza gana un socio estadounidense poderoso y estable, y asegura la
oportunidad de continuar reduciendo su pasivo, con mejoras esperadas en la generación de flujo de efectivo
libre, reducción de la abultada deuda que mantiene, y mejorar su estructura de capital, todo lo cual aumentará
la capacidad de ejecutar su estrategia a largo plazo. Por otro lado, LATAM tendrá una presencia más activa en
el mercado de Estados Unidos, uno de los principales destinos en el mercado de Latinoamérica, con una mejor
oferta para sus clientes. Así mismo, el acuerdo es definitivamente una integración entre las empresas vía
participación directa de Delta en la propiedad de LATAM. Con ello, Delta ocupará un sillón en el Directorio
de LATAM, enriqueciendo la gestión y el gobierno corporativo de esta última empresa.
Al parecer no es casualidad que el Gerente General de LATAM terminara la entrevista citada anteriormente
diciendo: “La alianza con Delta nos fortalece como compañía y mejora significativamente nuestra posición
competitiva en América Latina. Nuestros clientes y nuestros inversionistas lo valorarán”.
Notas:
 (1) Investment Grade o Grado de Inversión, es una clasificación de la calidad de una empresa desde el punto de vista del
 accionista que espera invertir en ella. Mayor grado de inversión, implica mejor calidad.
 (2) Cielos Abiertos es una especie de acuerdo de libre comercio, pero aplicado al espacio aéreo. Cuando existe este tipo de
 acuerdos las aerolíneas de los países involucrados vuelan libremente en todo el espacio aéreo de los países en cuestión.
Considerando sólo la información entregada en el caso, responda las siguientes preguntas.
 a) Al considerar la Alianza entre LATAM-Delta, ¿Existen elementos que permiten potenciar o mejorar
 la Ventaja Competitiva de LATAM? ¿Sí o No? ¿Cuáles? En caso de haberlos señale tres. En caso de
 no haberlos, explique por qué. Adicionalmente, explique conceptualmente cómo se puede potenciar o
 mejorar una Ventaja Competitiva.
 b) Al final del caso se cita al Gerente General de LATAM señalando: “La alianza con Delta nos fortalece
 como compañía y mejora significativamente nuestra posición competitiva en América Latina.
 Nuestros clientes y nuestros inversionistas lo valorarán”. Según sus conocimientos de Estrategia, ¿Por
 qué el Gerente General de LATAM afirma que la alianza con Delta mejora significativamente la
 posición competitiva de LATAM en la industria aérea en América Latina? Fundamente su respuesta
 basándose en algún modelo que la sustente.

[pág. 10]
10
PREGUNTA Nº5
La Central de Abastecimiento del Sistema Nacional de Servicios de Salud (Cenabast), es una institución
pública dependiente del Ministerio de Salud, cuya misión es abastecer de medicamentos e insumos médicos a
la Red de Salud Pública. Cenabast es quien compra los remedios más baratos en Chile y un decreto de ley
publicado hace pocos días en el Diario Oficial permitirá que las farmacias accedan a los precios Cenabast.
Aunque no todas las farmacias podrán acceder de manera inmediata. A partir del 6 de abril de 2020, los
chilenos podrán comprar medicamentos, a precio Cenabast, en aquellas farmacias independientes que
intermedien con la institución pública. En 12 meses, esta medida se ampliará a las cadenas regionales y en un
plazo de 24 meses, a las grandes cadenas farmacéuticas.
Las tres grandes cadenas de farmacias que operan en Chile están preocupadas porque durante dos años no
podrán acceder a los menores precios de los medicamentos. Los consumidores probablemente, preferirán las
farmacias independientes y cadenas regionales que accedan a los menores precios, generando condiciones
menos favorables para las grandes cadenas. Según un estudio de Geo-Research (www.geo-research.com), en
el año 2019 la participación de mercado de las grandes cadenas fue 17% para Cruz Verde, 11% para Salcobrand
y 9% para Farmacias Ahumada. Las farmacias independientes alcanzaron una participación del 49%; algunas
cadenas de menor tamaño tenían la participación restante.
Una de las cadenas grandes de farmacia, ha realizado en los últimos días un estudio de mercado con el
propósito de medir el impacto que podrían tener los eventuales cambios de precio en la participación de
mercado. El estudio seleccionó una muestra de 300 personas mayores de 18 años a quienes se les presentaron
distintos escenarios de farmacias, con distintos escenarios de precio, y con distintos escenarios de cercanía
geográfica al hogar o lugar de trabajo. Los encuestados debían elegir la opción preferida.
Suponga que los resultados del estudio son los que se muestran en la tabla siguiente. La tabla muestra las
estimaciones de dos modelos de elección, estimados mediante regresiones logísticas. El primero sólo incluye
las constantes de marca en las cuales las tres cadenas grandes se han asociado a las letras A, B y C, a través de
variables 0/1 según si la marca está presente en la alternativa. El segundo modelo incluye además las variables
cuantitativas Precio y Distancia. En ambos modelos, la alternativa de referencia corresponde a la Cadena A.
La tabla muestra, para cada modelo, el coeficiente estimado y el estadístico z (ó t) correspondiente a cada
variable.
 Modelo 1 Modelo 2
 Variable Coeficiente Estadístico z Coeficiente Estadístico z
 Precio (Miles de $) -0.20 -7.4
 Distancia (Kms.) -1.00 -6.5
 Cadena B* 1.20 4.2 0.50 2.1
 Cadena C* -0.80 -3.1 -0.50 -2.2
 Farmacia Independiente* 1.80 4.7 1.50 3.1
 n 300 300
 Estadístico R2 0.22 0.36
 (*) Constantes de marca tomando como referencia la Cadena A

[pág. 11]
11
PREGUNTAS
 a) ¿De qué forma se hace cargo el modelo logístico de la heterogeneidad de los consumidores? Explique
 su respuesta.
 b) A partir de los resultados de la estimación detallados en la tabla anterior, ¿Cuál es la variable más
 importante en la preferencia de los consumidores? Explique su respuesta.
 c) Suponga que un consumidor enfrenta un medicamento con precio M$ 10 en las todas las cadenas de
 farmacia y precio M$5 en una farmacia independiente. ¿Bajo qué condiciones, alguna de las cadenas
 de farmacia presentaría una oferta competitiva a la farmacia independiente en este caso particular?
 Justifique numéricamente.

[pág. 12]
12
PREGUNTA Nº6
Está ampliamente documentado que en países afectados por crisis, como el estallido social ocurrido en Chile
en octubre de 2019, se producen fuertes caídas en la bolsa local y una depreciación del tipo de cambio
(típicamente medido como la moneda local versus el dólar estadounidense).
La tabla que se presenta más abajo ilustra lo antes señalado mostrando el comportamiento mensual de los
siguientes indicadores financieros para el período septiembre – diciembre del año 2019:
  Retorno del índice accionario IPSA en pesos chilenos (CLP), que agrupa a las principales acciones
 que se transan en la bolsa chilena.
  Retorno del índice accionario S&P500 en pesos chilenos (CLP). Este índice incluye a las principales
 acciones que se transan en la bolsa de EE.UU. Normalmente los retornos del índice S&P500 se miden
 en dólares estadounidenses (USD). Sin embargo, las rentabilidades en USD del S&P500 fueron
 transformadas a CLP para facilitar la comparación directa con el IPSA.
  Variación del tipo de cambio (pesos chilenos por dólar estadounidense).
 Retorno IPSA Retorno S&P500 Variación Tipo
 Mes (en CLP) (en CLP) Cambio (CLP/USD)
 Sep-19 5,30% 2,38% 0,66%
 Oct-19 -6,22% 2,40% 0,36%
 Nov-19 -4,33% 11,10% 7,70%
 Dic -19 2,89% 2,07% -1,90%
Suponga que las volatilidades históricas de los retornos del IPSA (en CLP) y del S&P500 (tanto en USD como
en CLP) son similares en magnitud. Suponga que la volatilidad es medida como la desviación estándar de los
retornos. La tabla anterior se le entrega sólo para ilustrar la dirección de los movimientos de las distintas
variables en un periodo de crisis.
A usted se le pide contestar las preguntas que se le formulan a continuación entregando los fundamentos
conceptuales sobre los cuales basa su respuesta. No es necesario hacer cálculos para responder.
a) ¿Cree usted que un portafolio en el cual se invierte el 50% de los recursos en el IPSA y el 50% restante en
el S&P500 tendría mayor o menor volatilidad, medida en pesos chilenos (CLP), que una cartera en la cual se
invierte el 100% de los recursos en el IPSA? ¿Por qué?
b) Suponga que usted es un inversionista chileno que tiene una cartera en la cual el 50% de los recursos están
invertidos en el IPSA y el 50% restante en el S&P500. Como la inversión en el S&P500 está expuesta a la
variación del tipo de cambio, usted está evaluando la posibilidad de cubrir el riesgo cambiario utilizando
derivados (forwards o futuros de dólar). Pensando únicamente en términos de volatilidad, medida en CLP, ¿es
conveniente contratar derivados cambiarios para el portafolio 50% IPSA y 50% S&P 500 o sería mejor no
hacerlo? ¿Por qué?
c) Suponga que usted tiene un portafolio con el 100% de los recursos invertidos en el IPSA y está considerando
adicionalmente la posibilidad de contratar futuros o forwards de dólares estadounidenses. ¿Cómo se vería
afectada la volatilidad de su cartera si usted mantuviera permanentemente una posición “corta” en futuros, es
decir, si estuviera vendiendo dólares a futuro? ¿Cambiaría su respuesta anterior si usted mantuviera
permanentemente una posición “larga” en futuros, es decir, si estuviera comprando dólares a futuro?
Fundamente sus respuestas.

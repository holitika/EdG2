# Examen de grado · Examen-de-Administracion-Agosto-2021-Parte-I-y-II-618a9a6c56319

Fuente: examen anterior

[pág. 1]
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. El examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
 alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas. Esta parte del examen
 contiene las preguntas número 1, 2 y 3 del examen.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
 hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
 hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
 que los datos que ha recibido están correctamente calculados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
 realidad de las empresas que allí se mencionan.
5. Si, como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
 dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
 misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente a la Profesora Marta Del Sante, Presidente de la Comisión
 de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
 cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
 condiciones, la Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala ni relojes inteligentes, los que
 deberán estar apagados y guardados en las mochilas adelante.
12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
 examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
 identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
 como “borrador”, esas hojas no se deben entregar con las respuestas.
Fecha : 20 de agosto de 2021
Duración : 90 minutos (9:00 horas a 10:30 horas).
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá la
 Profesora Marta Del Sante, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.).

[pág. 2]
1
PREGUNTA Nº1
El gigante francés del lujo LVMH (en adelante LV), dueño de la marca Louis Vuitton entre muchas otras,
confirmó su interés en comprar la emblemática joyería estadounidense Tiffany & Co. para muchos la
joyería más famosa e importante del mundo. La oferta de LV se hizo a comienzos de 2020 y fue de US$
14.500 millones por quedarse con la afamada joyería, operación que de concretarse sería una de las mayores
adquisiciones del grupo francés, líder mundial en el mercado de artículos de lujo. LV está presente en moda,
vinos, perfumes, cosméticos y en una serie de otros productos. Tiene además una acotada línea de joyería
destacando relojes. Al día siguiente de conocerse el interés en la joyería estadounidense, el precio de las
acciones de Tiffany aumentó un 30% lo que al menos en parte puede deberse a este evento. La pandemia
en 2020 y 2021 ha retrasado la operación, y el Directorio del LV continúa debatiendo si la llevará o no
adelante.
Los Actores
En su conjunto, LV y sus 70 marcas -incluidas Christian Dior, Fendi, Hennessy y Dom Pérignon, Bulgari-
obtuvieron en 2019 resultados récord de ventas y de beneficios. Por su parte, Tiffany registró en el mismo
año, un aumento de 6,5% en sus ingresos y su facturación bordeó el 10% de la de LV. La disminución en
los turistas por el Covid-19 frenó el crecimiento de Tiffany desde el inicio de 2020.
Tiffany & Co., es la primera joyería a nivel mundial, tiene un buen potencial de crecimiento y actualmente
se encuentra en fase de relanzamiento, después de vivir un difícil 2020. Al cierre de ese año contaba con
321 tiendas propias en 20 países bajo la marca Tiffany, lo que constituía el principal canal de
comercialización de la afamada marca. Del total de tiendas de Tiffany, 124 estaban en Estados Unidos y
90 en Asia. La tienda online representa el 15% de la venta total de Tiffany en el mundo, mientras que las
tiendas físicas en Estados Unidos explican el 25% de la venta total de la empresa. Desde 1982 la compañía
controla el suministro y la procedencia de todos sus diamantes en bruto, habiendo claridad en la ruta del
diamante, desde su origen (la mina desde donde se extrae) hasta la confección de la joya misma, controlando
así todo el proceso de abastecimiento. El Gerente de Finanzas de LV declaraba: "Queremos aprender e
integrar nuestra estructura de producción a la de Tiffany y así crear varias sinergias a nivel de LV”.
Por su parte LV, distribuye sus productos a través de tiendas propias especializadas en cada una de las
marcas que administra (hay tiendas para Bulgari, otras para Dior y así sucesivamente). Una eventual
adquisición de Tiffany fortalecería su negocio de joyería, en especial la venta de relojes de lujo, y extendería
su oferta a joyas más sofisticadas, en donde Tiffany es fuerte. Además, aumentaría su participación en el
comercio electrónico de Estados Unidos, ya que en tiendas físicas LV muestra una robusta posición en el
mercado de Estado Unidos. Además, ayudaría a la expansión de LV en Asia, mercado en donde Tiffany
tiene una buena posición. Según analistas de la industria del lujo, “Tiffany sería un complemento perfecto
para LV: potenciaría su cartera de productos y regiones combinando tradición y modernidad. Además, le
permitiría acceder a procesos productivos y a tecnologías aún no desarrolladas adecuadamente en el
grupo francés”.
El 2020, un año difícil para la industria del lujo
A pesar de los signos de recuperación en China en el segundo semestre de 2020 - uno de los máximos
compradores de artículos de lujo en el mundo con el 35% de la demanda mundial - las ventas de la industria
del lujo a nivel global sufrieron una contracción del 40% anual durante ese año. Como respuesta a las
restricciones de movilidad, las firmas que operan en el mercado del lujo han puesto el foco en el comercio
electrónico ya que suponen que el miedo al contagio en las tiendas físicas persistirá.
Por otro lado, para el 2021 se espera un incremento en el costo de las materias primas a causa de la
persistencia de la pandemia, y un aumento de precios entre un 5% y un 17% para piezas icónicas (por
ejemplo, relojes en la marca Cartier) durante el resto del 2021, pese a la baja proyectada para la industria
del turismo.

[pág. 3]
2
Lo difícil que está resultando el 2021 para LV
En la primera mitad de 2021 las ventas de LV descendieron de manera importante, y más significativo aún
fue el descenso en sus resultados. Lo anterior muestra uno de los desafíos más importantes que enfrenta el
grupo y la industria del lujo en general, mientras se combate la pandemia: la reducción significativa de sus
costos.
Pero no es la única dificultad que está enfrentando LV. Diversos movimientos ambientalistas y de derechos
humanos, están obligando a LV a declarar el origen de sus diamantes, de manera de asegurar que los
productos que se comercializan especialmente en su línea de relojes de lujo y en una serie de artículos que
incluyen diamantes, no contribuyen a abusos en contra de personas y en especial de niños en los países de
África en donde se encuentran varias de las principales minas de diamantes. La demanda social concreta,
busca que LV declare detalles del origen de los diamantes que utiliza, trazando la ruta entre los depósitos
de diamantes (las minas) hasta las joyas que se exhiben en catálogos y en tiendas.
La decisión
El Consejo Directivo de LV se reunió a comienzos de junio de 2021, con el objeto de analizar el impacto
que la pandemia está teniendo en el negocio, y resolver si mantendrá o no la oferta realizada por Tiffany.
La operación se presenta como la mayor compra en la historia de LV y su salto definitivo a Asia, un mercado
que parece atractivo para el gigante del lujo francés.
El cierre de la compra por parte de LV, en caso de concretarse, debería producirse hacia el mes de
noviembre de este año, siempre que se cumplan una serie de condiciones, entre ellas la aprobación de los
organismos regulatorios, el visto bueno de los accionistas de Tiffany y el convencimiento del Directorio de
LV, el cual enfrentaba opiniones divididas en relación a la decisión.
Responda las siguientes preguntas basándose sólo en la información presentada en el caso
a) ¿Fortalece o no el modelo de negocios corporativo de LV la eventual compra de Tiffany & Co.? ¿Por
 qué si o por qué no? En caso de ser afirmativa su respuesta señale tres aspectos específicos que
 fortalezcan el modelo de negocio corporativo. En caso de ser negativa su respuesta, señale tres aspectos
 que deberían tenerse en consideración para fortalecerlo.
b) Considerando la información del caso, ¿Qué decisión recomienda al Directorio de LV: comprar Tiffany
 o desistirse de la compra? Entregue los dos principales argumentos que sustentan su recomendación.
 Considerando su decisión, ¿cuáles son los riesgos que involucra la decisión tomada y sobre los cuales
 debiera la compañía evaluar planes alternativos? Sea preciso e indique dos riesgos principales.

[pág. 4]
3
PREGUNTA Nº2
La industria de los videojuegos es uno de los pocos sectores de la economía que ha crecido en medio de la
pandemia. Diversos estudios muestran que, a nivel global, los gamers aumentaron en más de 260 millones en
lo que va de pandemia. Por su parte, sitios como Linio y Mercado Libre registraron un alza de 200% en la
compra de consolas y accesorios “gaming”, demostrando ser una de las pocas industrias que va al alza en
medio de la crisis económica más importante del último tiempo.
El estudio “ABC del Gaming” realizado por la agencia WILD FI identifica cuatro tipos de “gamers”. Uno de
estos segmentos es el Ultimate Gamer, que corresponde en un 60% a hombres con promedio de edad de 28
años. Es aquel que vive y respira videojuegos en todos los espectros del mercado, ya sea jugando, comprando
o consumiendo streaming. Este segmento es muy importante para la industria de los videojuegos, por lo que
los fabricantes orientan sus desarrollos tecnológicos de manera de dar respuesta a los constantes cambios y
requerimientos de estos gamers.
Para entender mejor al segmento de ultimate gamers, se le encargó un estudio a una empresa de investigación
de mercado, con el objetivo de obtener sus preferencias respecto a las características más importantes de las
consolas más populares de videojuegos. En particular, se desarrolló un estudio de análisis conjunto, evaluando
distintas características de estos productos, incluso con características que no están disponibles actualmente en
el mercado pero que podrían desarrollarse si los clientes muestran preferencias importantes.
Los resultados del análisis conjunto para un consumidor promedio de este segmento pueden verse en la
siguiente tabla.
 Atributo Nivel Part-worth o utilidad
 parcial*
 Microsoft 0
 Marca Nintendo -50
 Sony 100
 8GB 0
 Memoria 16GB 100
 32GB 120
 500GB 0
 Almacenamiento 1TB 80
 2TB 100
 400 0
 Precio(USD) 500 -60
 600 -120
 4K 0
 Resolución HD -40
 8K 10
 Nota: Considere que todos los valores estimados (part-worths) son estadísticamente distintos de cero
 (excepto los niveles base no estimados que se fijaron = 0).
Sobre la base de la información que se le ha presentado, responda las siguientes preguntas fundamentando su
respuesta.
a) Considerando el segmento de los ultimate gamers, nombre los dos principales beneficios de realizar un
 estudio de análisis conjunto versus un estudio que analice datos de compras históricas.
b) ¿Cuánto estaría dispuesto a pagar un consumidor promedio por aumentar la memoria RAM de su consola
 de 16 GB a 32 GB? ¿Qué decisiones puede tomar un fabricante a partir de un análisis como éste?

[pág. 5]
4
c) ¿Cuál de las dos siguientes consolas es más preferida por un cliente promedio? Indique sus supuestos y
 desarrolle su respuesta.
 Consola A Consola B
 Marca Sony Nintendo
 Memoria 8 GB 16 GB
 Almacenamiento 500 GB 1 TB
 Precio USD 500 USD 400
 Resolución 8K 4K

[pág. 6]
5
PREGUNTA Nº3
Santa Juana es una viña que se encuentra en la zona central de nuestro país y sus propietarios son chilenos que
viven en Chile. La viña se ha dedicado durante los últimos años a la producción y exportación de vinos de
primera calidad y si bien, en promedio, sus rentabilidades operacionales han sido relativamente buenas,
siempre ha debido enfrentar fuertes cambios en sus ingresos por ventas, tanto por las permanentes y abruptas
variaciones del tipo de cambio, como por la cantidad de vino exportada, producto de las variaciones en el clima
al momento de la cosecha de uva apta para vinos de exportación. Además, la empresa enfrenta fluctuaciones
significativas en sus costos, principalmente debido a los cambios en los precios de algunos insumos como
fletes y los sueldos y arriendos que se debe pagar a las personas y por las maquinarias que debe contratar
durante la etapa de recolección de la uva, todo lo cual genera desembolsos que dependen de la cantidad
cosechada.
La siguiente es la última información financiera disponible del año 2020 de la Viña Santa Juana:
 BALANCE "VIÑA SANTA JUANA" S.A.
 31 DE DICIEMBRE DE 2020
 $ $
 Activos Corrientes Pasivos Corrientes
 Caja y Activos Equivalentes a Caja 5.000 Cuentas por Pagar a Proveedores 24.000
 Cuentas por Cobrar a Clientes (Neto) 50.000 Sueldos por Pagar 30.000
 Existencias 240.000 Gastos Acumulados por Pagar 73.400
 Arriendo Pagado por Adelantado 25.000 IVA por Pagar 21.000
 Porción de C.P. de Bonos por Pagar 10.000
 Intereses por Pagar 1.600
 Total Activos Corrientes 320.000 Total Pasivos Corrientes 160.000
 Activos No Corrientes Pasivos de Largo Plazo
 Terrenos 40.000 Bonos por Pagar 40.000
 Máquinas 70.000
 Menos: Depreciación Acumulada -30.000 Patrimonio
 Capital 50.000
 Utilidades Retenidas 120.000
 Resultado del Ejercicio 30.000
 TOTAL ACTIVOS $400.000 TOTAL PASIVOS + PATRIMONIO $400.000
 ESTADO DE RESULTADOS 2020
 "VIÑA SANTA JUANA"
 Ingreso por Ventas 300.000
 Costo de Ventas -192.000
 = Margen Bruto 108.000
 Gastos de Distribución y Ventas (GDV) -13.500
 Gasto por Depreciación -10.000
 Gasto en Sueldos de Administración -60.000
 Gasto en Arriendo -16.000
 Gasto por Provisión por Deudores Incobrables -4.500
 = Resultado Operacional 4.000
 Gasto por Intereses -4.000
 Utilidad en Venta de Activo Fijo 40.000
 = Resultado Afecto a Impuestos 40.000
 Gastos por Impuestos -10.000
 Resultado del Ejercicio 30.000
Otra información disponible de la Viña Santa Juana:
● Tanto la producción, como las ventas de vino son uniformes a través del año.
● Todas las ventas de existencias de la empresa son hechas con crédito que otorga a sus clientes.
● Todas las compras de existencias de la empresa son hechas con crédito de sus proveedores.

[pág. 7]
6
● La empresa ha presentado una rotación de existencias promedio en los últimos años de 0,8 veces.
● La viña ha presentado una rotación de cuentas por pagar promedio en los últimos años de 18 veces.
● La suma de los costos y gastos operacionales fijos anuales de Santa Juana representa el 80% del total de
 sus gastos y costos operacionales anuales.
● El IVA que se adeuda al 31/12/2020, se debe pagar no después del 12/01/2021
Supuestos para su análisis:
● Para las razones financieras en las que intervenga una variable de stock y una de flujo, para la variable de
 stock suponga su valor al término del año 2020.
● El año tiene 360 días
En la reunión de directorio del 1 de enero de 2021, en la que se analizó la única información financiera
disponible de la empresa y que es también la única de la que usted dispone, distintos(as) directores(as) hicieron
ver sus opiniones respecto de diversos aspectos financieros de la empresa y que ellos(as) estimaban se podían
desprender de la información financiera disponible.
Respecto de la liquidez de la empresa, el director 1 dijo lo siguiente:
“Dado que al 31/12/20 la razón corriente o circulante de la viña es tranquilizadora, de hecho es de 2,0 veces,
y teniendo presente el ciclo de efectivo que tiene la empresa, esto es, el plazo que en promedio la empresa
demora en cobrar sus cuentas por cobrar menos el plazo que en promedio se paga a los proveedores, es de solo
40 días, opino que como empresa no debiéramos enfrentar problemas de liquidez, es decir, no debiéramos
tener inconvenientes para pagar oportunamente nuestras obligaciones de corto plazo”.
Respecto del riesgo operacional o variabilidad de los retornos de los activos de la empresa, la directora
2 ha dicho lo siguiente:
“Conociendo los elementos que determinan el riesgo operacional de una empresa, yo diría que a la luz de la
información de la que disponemos, Santa Juana es una empresa de bajo riesgo operacional”.
Además, esta directora agregó: “Otro argumento que me permite reforzar mi opinión en términos de que el
riesgo operacional que enfrentamos es bajo, es constatar que en nuestra viña estamos operando con un nivel
de endeudamiento [(Deuda Total/Patrimonio) = 1,0], cifra bastante inferior respecto del nivel de
endeudamiento promedio que exhiben otras empresas comparables”.
Finalmente, respecto de lo que conocemos como el principio de “igualdad” o “calce” en el tema del
financiamiento general de la empresa, la directora 3 dice:
“Yo agregaría que otro de los aspectos que me da tranquilidad, es que el principio que conocemos como
principio de "igualdad" o "calce" se cumple holgadamente en la empresa. En efecto, la información que se
nos ha entregado muestra que nuestros activos de largo plazo o "No Corrientes" son de $80.000 y la suma de
nuestras fuentes de financiamiento de largo plazo (Deuda de Largo Plazo + Patrimonio) es de $240.000, es
decir es tres veces el valor total de nuestros activos de largo plazo, que en el fondo es el valor que representa
nuestras necesidades de financiamiento permanentes”.
PREGUNTA
A partir únicamente de la información de la que se dispone y que es la entregada previamente a usted se le
pide analizar y comentar de manera independiente, los conceptos financieros, afirmaciones y conclusiones que
pudieran contener las opiniones emitidas por cada uno de los(as) tres directores(as) de la empresa Santa Juana.
Su análisis de los aspectos tanto cuantitativos como cualitativos o conceptuales de las opiniones de cada uno
de los(as) tres directores(as), debe ser el resultado de la aplicación de sus conocimientos financieros a la
información que se entrega de la viña.
Nota:
En el desarrollo de su respuesta, separe e indique claramente el análisis de las intervenciones de cada uno de
los(as) tres directores(as), identificándolos(as) por su número (1, 2 o 3), de este modo: Director(a) 1: desarrollo
de la respuesta; etc.

[pág. 8]
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. El examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
 alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas. Esta parte del examen
 contiene las preguntas número 4, 5 y 6 del examen.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
 hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
 hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
 que los datos que ha recibido están correctamente calculados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
 realidad de las empresas que allí se mencionan.
5. Si, como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
 dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
 misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente a la Profesora Marta Del Sante, Presidente de la Comisión
 de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
 cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
 condiciones, la Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala ni relojes inteligentes, los que
 deberán estar apagados y guardados en las mochilas adelante.
12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
 examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
 identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
 como “borrador”, esas hojas no se deben entregar con las respuestas.
Fecha : 20 de agosto de 2021
Duración : 90 minutos (11:00 horas a 12:30 horas).
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá la
 Profesora Marta Del Sante, en forma individual, entre las 11:30 y 11:45 hrs. (aprox.).

[pág. 9]
1
PREGUNTA Nº4
Desde inicios del 2020, diversas empresas han tenido que adaptarse rápidamente a la nueva realidad de
negocios impuesta por las consecuencias del Covid19. La Pandemia provocó cambios importantes por
restricciones de circulación y aforo y, por otro lado, el uso más intensivo de medios digitales. Previo a estos
cambios, la gran mayoría de las empresas tradicionales dependía exclusivamente de canales de venta físicos
(distribuidores) o su propia cadena de tiendas. En pocos meses, las empresas más ágiles optaron por
complementar su canal de distribución físico tradicional, incorporándose a un “marketplace” (plataforma
virtual de comercio de otras empresas; ej. Mercado Libre), delegando su comercio online a una plataforma de
compras (ej. Cornershop) o desarrollando su propio canal virtual D2C (Directo al consumidor) el que les
permite conocer más profundamente a sus clientes.
Si una empresa decide crear su propia unidad de ecommerce, tiene que tener el talento profesional adecuado y
realizar entre otras tareas, el crear su página web, una app para el móvil, desarrollar campañas de generación
de tráfico y conversión, así como organizar el proceso logístico de gestión de inventarios en un centro de
distribución o sus propias tiendas (“Black Stores”, sin atención de público y “Grey Stores”, en caso que sí),
del despacho a los clientes y, muchas veces, el retorno de los productos por parte del cliente final (logística
reversa). Estas últimas dos actividades se delegan por lo general, a un operador logístico (ej. Chilexpress, DHL,
Boosmap).
Suponga que a mediados de 2021, usted es consultor de la empresa HomeTips, reconocida marca diseñadora
e importadora de productos con su marca propia de menaje y cocina, ropa de cama, muebles, adornos para el
hogar y juguetes, ya establecida en el mercado nacional con una cadena de 50 tiendas físicas, distinguidas por
su buen servicio. En las tiendas de grandes dimensiones, ofrece una gran gama de productos con diseño
exclusivo, vendedores capacitados para asesorar en decoración o en qué regalar y diversos servicios tales como
despacho a domicilio, instalación, empaque de regalos y otros. El ticket promedio de compra en sus tiendas se
ha incrementado a $18.000 durante la pandemia, desde aproximadamente $14.000 en el período previo. Si bien
las personas llegan a la tienda con una idea, los productos son muy atractivos y generan ventas impulsivas. El
margen promedio de HomeTips en sus tiendas es aproximadamente un 40% de la venta.
La pandemia está reduciéndose y gran parte de sus tiendas están en comunas que avanzan en las “Fases” del
Plan Paso a Paso y el tráfico a las tiendas empieza a aumentar. Un reciente estudio de mercado cuantitativo
entre clientes de HomeTips, indicaba que más de un 65% quería volver a las tiendas a comprar
presencialmente, mientras que un 10% quería seguir exclusivamente comprando online las categorías de
productos de la tienda. El resto, valoraba el poder usar herramientas digitales, pero también extrañaba las
tiendas y tener la experiencia sensorial total.
HomeTips no tiene actualmente una operación propia de comercio electrónico. Desde el inicio de la pandemia
ha logrado aminorar en parte el impacto negativo en las ventas, por la vía de operar con CornerTop, una
plataforma de compra online y despacho de “última milla”. El comprador final entra a la plataforma/app de
CornerTop y ahí selecciona la alternativa HomeTips y los productos que desea de ésta, y paga con su tarjeta
de crédito. Luego, el “comprador” (Shopper) de CornerTop va a la tienda HomeTips, compra lo pedido con
tarjeta de crédito provista por CornerTop y luego lleva el producto a la casa del comprador final. CornerTop
le cobra a HomeTips un monto fijo de $5.000 por compra, lo que ha reducido significativamente los márgenes
de esta última. Los datos de clientes quedan en las bases de CornerTop.
La empresa ha estado considerando entrar a Mercado Libre, el principal marketplace de América Latina con
cobertura en varios países, dónde HomeTips tiene también tiendas físicas. Los marketplaces o plataformas de
comercio se han desarrollado rápidamente en Chile y el mundo (Ej. Mercado Libre, Linio.cl, Barrio Meiggs.cl,
etc.). Estas plataformas captan por un lado oferentes, incluso competidores entre sí, de diversos productos y
servicios, exigiéndoles compromiso de inventarios y servicios de postventa. A cambio de un pago por servicios
y una comisión porcentual sobre la venta, la plataforma ofrece un espacio virtual estándar en su web, apoya
en el uso de fotos de productos, gestiona el carro de compra y medios de pago, así como los servicios logísticos
de despacho. A los compradores finales, un marketplace le ofrece en un solo lugar una gran variedad de
productos, marcas y servicios, confianza en el medio de pago y el despacho a su casa o empresa.

[pág. 10]
2
Uno de los Directores de HomeTips, el Sr. A, cree que la pandemia durará pocos meses más y que los recursos
deben invertirse en fortalecer la cadena de tiendas, refrescar su interior e invertir en publicidad para promover
el retorno a las tiendas. “Nuestros clientes valoran la experiencia de la tienda y para nosotros es más rentable”,
planteaba el Sr.A, que además pedía se terminara el contrato con CornerTop.
En cambio, otra Directora, Sra. Z, planteaba que era el momento para invertir en la propia unidad de
ecommerce y logística de despacho, terminar el contrato con CornerTop, organizar el retiro en tiendas y
potenciar la omnicanalidad. “Opino que nuestros clientes han cambiado para siempre. Más que nunca debemos
conocer profundamente sus preferencias y conductas”, enfatizaba.
Se pide:
 a) Ante las alternativas posibles planteadas y excluyentes por presupuesto, se le pide a usted identificar
 y desarrollar los dos argumentos principales, que sustentan lo propuesto por cada uno de los
 Directores.
 b) Suponga que HomeTips, fortalece su red de tiendas, desarrolla su operación propia de ecommerce,
 mantiene el vínculo comercial con CornerTop y además, incorpora a Mercado Libre como
 marketplace. ¿Cuáles son los tres principales factores para el éxito de esta estrategia de distribución?

[pág. 11]
3
PREGUNTA Nº5
Move+ es una consultora fundada en 2018, dirigida a diseñar, implementar y evaluar programas de mejora de
salud de trabajadores en empresas de diferentes rubros. Su fundador y gerente general, Germán Carrasco
entendió que los trabajadores de muchas empresas, con la intención de romper la monotonía de su trabajo,
incurrían en conductas peligrosas al realizar sus labores. Para ello, la mayoría de los servicios de Move+ se
han concentrado en crear planes de deporte, salud, meditación y alimentación saludable para estas compañías
que buscan fomentar el bienestar y la productividad de su personal.
Move+ apunta a diferenciarse de la competencia por sus soluciones creativas que se adaptan a una gran gama
de necesidades, considerando las especificidades en las funciones y preferencias de los trabajadores, además
de las restricciones en las instalaciones disponibles de las empresas que contratan sus servicios, sobre todo
debido a la pandemia. La relación con los gerentes de recursos humanos, que contrataban los servicios y con
los trabajadores de las empresas cliente, eran clave para entender sus necesidades y adaptar permanentemente
las soluciones ofrecidas. La empresa no estaba sola en el mercado. Recientemente, en el mercado en donde
estaba posicionado Move+, habían aparecido, y capturado una participación de mercado relevante, una serie
de nuevos competidores. Estos nuevos actores, se diferenciaban mediante la utilización intensiva de las nuevas
tecnologías digitales y la inteligencia artificial, ofreciendo al mercado aplicaciones móviles y servicios online
con planes de salud, deporte y bienestar a la medida para los trabajadores de sus clientes.
Por su parte, con la crisis sanitaria, Move+ creció rápidamente, diversificando aún más el número de programas
para el personal de las empresas que estaban teletrabajando. En sus inicios la compañía contaba con 5
ingenieros comerciales a cargo del diseño y la evaluación de los programas para empresas y 20 técnicos
deportivos y de la salud que implementaban el plan y recogían la información necesaria para hacer las
evaluaciones de los programas implementados. En 2021, en cambio, la empresa contaba con 15 ingenieros
comerciales y 50 técnicos.
Este aumento en el volumen y diversificación de los planes para sus clientes fue posible gracias a la transición
que hizo el equipo de ingenieros comerciales de Move+, hacia la modalidad de teletrabajo en un 100%, a
comienzos de 2020. A su vez, los técnicos que implementaban y supervisaban los planes deportivos y de salud
para las empresas, fueron reasignados de manera transitoria a tareas de apoyo en diseño y la evaluación. De
todas formas, Germán Carrasco, junto al Directorio de la empresa, decidió que, luego de la pandemia, todo el
personal de la compañía evolucionaría de manera permanente a una modalidad de trabajo híbrido integrando
lo presencial con teletrabajo. Las labores remotas hacían aún más crítica la comunicación y colaboración entre
todos los empleados de Move+. Debían intensificar su integración en los equipos para dar respuesta a los
constantes cambios que solicitaban los clientes, evaluarlos, rediseñar soluciones y buscar una mayor
diferenciación de la competencia. Necesitaban profundizar su propuesta de valor asociada al servicio
personalizado y cercano a las empresas, tanto para quiénes contrataban el servicio como para los usuarios, de
modo de competir frente a una oferta de la competencia con menor relacionamiento con los clientes, pero
intensiva en tecnología. Cada equipo de Move+ atendía a varios clientes y una misma persona era parte de
varios equipos al mismo tiempo.
Germán Carrasco contaba con 2 jefes comerciales, cada uno a cargo de dirigir y coordinar a los equipos de
trabajo. En la nueva modalidad de teletrabajo, a él y los coordinadores les costaba más poder interactuar con
cada persona dentro de la empresa. Si bien recibían informes periódicos de venta, abandono del servicio por
parte de clientes, encuestas de satisfacción de clientes, o informes con el avance en la implementación de los
proyectos en sus clientes, el teletrabajo dificultaba los vínculos con cada uno de quienes conformaban los
equipos. Esta situación se agudizaba por el hecho que durante 2020 habían recibido un número importante de
nuevos ingenieros comerciales a cargo de diseño y evaluación de programas. Las reuniones de trabajo
presenciales se hacían menos habitualmente por la dificultad de coordinar horarios debido a las múltiples
obligaciones que ahora debían absorber los empleados de la compañía. Antes, los directivos le daban mayor
atención a los trabajadores que sentían que tenían mayores brechas de desempeño, ahora, ello era menos
frecuente. Por otra parte, el gerente general estaba inquieto porque hasta ahora las remuneraciones (fijas y
variables) no estaban vinculadas con el desempeño de los empleados de la empresa.

[pág. 12]
4
En el mes de diciembre de cada año, Germán Carrasco y sus 2 coordinadores de equipo realizaban la evaluación
formal de desempeño de cada una de las personas de Move+. Contaban con una pauta y una escala de
evaluación definida que aplicaban al personal, cada uno de manera individual. Luego, se reunían entre los tres
y consensuaban la evaluación final de cada empleado. Posteriormente sostenían una entrevista de
retroalimentación para dar a conocer los resultados y generar un plan de trabajo para el año siguiente con
acciones que apuntaban al desarrollo de competencias y conductas asociadas a las necesidades del negocio.
En enero de 2021, sin embargo, los trabajadores le manifestaron al gerente general que durante ese año no era
conveniente realizar la evaluación de desempeño. Según ellos, la evaluación constituía una instancia estresante
que nadie estaba dispuesto a enfrentar de buena forma. Los empleados argumentaron que habían tenido un
aumento de la carga de trabajo y les faltaba tiempo para hacer la evaluación de manera profesional. También
mencionaron las evidentes presiones que experimentaban los trabajadores de Move+ por las mayores
exigencias que significaba para ellos el tener que teletrabajar, junto a los deberes asociados al cuidado de niños
y adultos mayores y otras labores domésticas que consumían importantes horas de su día, con límites de tiempo
poco claros en la jornada laboral. Por último, el personal indicaba que la evaluación de desempeño estaba
basada principalmente en variables subjetivas, como la percepción de los clientes, la observación de las
competencias técnicas de los empleados y las conductas asociadas al servicio al cliente, proactividad y
colaboración al interior de los equipos, entre otras.
Suponga que estamos a comienzos de 2021. A usted se le pide, que en relación a la información planteada
en el caso y tomando en cuenta los objetivos de Move+ junto a los conceptos de gestión estratégica de
personas, entregue su opinión respecto al esquema de evaluación de desempeño y al sistema de incentivos
variables. En concreto:
 a) El Directorio de la empresa ha decidido llevar adelante la evaluación de desempeño, pese a la solicitud
 contraria de los trabajadores. Desarrolle dos argumentos que permitan respaldar la decisión del
 Directorio.
 b) Alineado con el mandato del Directorio, Germán Carrasco decidió realizar la evaluación de desempeño
 durante 2021, pero adecuándola a la situación actual y futura de la empresa. Por ello, explique dos
 componentes o características esenciales que debiera considerar el nuevo modelo de evaluación de
 desempeño.
 c) Germán Carrasco, le solicita además que explique dos componentes o características esenciales que
 debiera considerar un esquema de incentivos variables que esté asociado a la evaluación de desempeño
 del personal de Move+.

[pág. 13]
5
PREGUNTA Nº6
La empresa Diver S.A. es un holding financiero cuyo único activo son acciones de tres compañías que
pertenecen a diversos rubros (industrias). Las acciones de estas compañías se transan activamente en bolsa y
presentan las siguientes características financieras:
 Valor de Mercado del
 Deuda / Patrimonio Beta Beta
 Compañía Industria Patrimonio (cifras en (*)
 Deuda Acciones
 millones de $)
 BCD Pin Retail MM$ 2.000 1,0 0,6 1,8
 Los Troncos Forestal MM$ 4.000 0,5 0,25 1,0
 Chispita Energía MM$ 6.000 2/3 0,1 0,6
(*): Las compañías se financian únicamente con bonos. El índice de endeudamiento está calculado sobre el
 patrimonio medido a valor de mercado.
El 20% de los activos de Diver S.A. corresponden a acciones de la compañía BCD Pin, y el 80% restante está
repartido en partes iguales (40% cada una) en acciones de la empresa Los Troncos y de la compañía Chispita.
El holding no tiene otros activos y no utiliza deuda (100% de financiamiento patrimonial). El premio por riesgo
de mercado [E(RM) – RF)] es un 6% y la tasa libre de riesgo igual a 4%.
Suponiendo que el mercado de capitales es perfecto y que se cumple el modelo CAPM, responda las preguntas
que se le formulan a continuación, mostrando todos los cálculos que correspondan. Para sus cálculos y
respuestas utilice un mínimo de dos decimales, (ejemplo 12,23%).
a) ¿Cuál es el costo de capital promedio ponderado de Diver S.A.?
b) La señora Edison, es una inversionista que en este momento dispone de $10 millones de recursos propios y
que ha decidido comprar en el mercado $15 millones en acciones de Chispita. Dado que la señora Edison
contaba solamente con $10 millones para la compra de las acciones, ella decidió tomar una deuda por $5
millones en un Banco, que consiguió pactarla a la tasa libre de riesgo (4% anual) y así reunir el monto requerido
para llevar a cabo su inversión.
¿Cuál será el retorno anual esperado del patrimonio de la señora Edison, como resultado de su estrategia? ¿Es
este retorno distinto del rendimiento esperado de las acciones de Chispita? Si los retornos esperados son iguales
explique brevemente porqué son iguales y si, por el contrario, son distintos, explique porqué son distintos.
c) Diver S.A. está analizando la posibilidad de adquirir el 100% de la propiedad de la cadena de tiendas
“Londres”, que es el principal competidor de BCD Pin. Ambas empresas son totalmente representativas de la
industria del retail y la idea del holding, con esta adquisición, es fortalecer su posición en el rubro del retail.
“Londres” es una empresa que no tiene deuda y sus activos tienen el mismo riesgo que los activos de BCD
Pin.
Para financiar la adquisición de “Londres”, la administración de Diver S.A. venderá una parte de las acciones
que el holding actualmente posee en la empresa “Los Troncos”, con la idea de reducir la exposición al sector
forestal por razones estratégicas.
El Gerente General de Diver S.A. estaba un poco confundido respecto de la tasa de descuento que debía
utilizarse para descontar los flujos de caja de la potencial adquisición de la cadena de tiendas “Londres” y le
pide a Ud. que lo asesore en dicha tarea. En concreto, a usted se le solicita determinar la tasa de descuento
apropiada para descontar los flujos de caja de la eventual compra de la citada cadena de tiendas.

# Examen de grado · EG-Administracion-Enero-2022

Fuente: examen anterior

[pág. 1]
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
 alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
 hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
 hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
 que los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
 realidad de las empresas que allí se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
 dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
 misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente a la Profesora Marta Del Sante, Presidente de la Comisión
 de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
 cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
 condiciones, la Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala ni relojes inteligentes, los que
 deberán estar apagados y guardados en las mochilas adelante.
12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
 examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
 identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
 como “borrador”, esas hojas no se deben entregar con las respuestas.
Fecha : 24 de enero de 2022
Duración : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá la Profesora
 Marta Del Sante, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 y
 11:00 hrs. (aprox.).

[pág. 2]
2
PREGUNTA Nº1
“Notco”, un nombre muy singular que enfatiza la contradicción. La empresa se fundó en Chile hace unos años
basándose en una gran cantidad de investigación y ciencia, que han logrado patentar. Lo que querían hacer era
replicar la composición molecular de productos alimenticios con ingredientes de origen animal como la leche,
la mayonesa, los helados y las carnes mismas, con combinaciones de productos de origen vegetal. Su gran
innovación fue crear a Giuseppe, un algoritmo capaz de generar fórmulas de alimentos conocidos basándose
sólo en ingredientes vegetales, imitando la funcionalidad (múltiples usos), el sabor y la textura de los alimentos
a reemplazar. Giuseppe fue desarrollado a partir de un algoritmo de inteligencia artificial que busca patrones
que ocurren en el comportamiento de plantas y alimentos tradicionales.
Actualmente, tienen en su base de datos más de 300 plantas y frutas con su estructura molecular. El algoritmo
encuentra una combinación de plantas o "receta" que replica el sabor, la sensación y textura de los productos
de origen animal, para que puedan reemplazarlos de una manera sostenible y tener un excelente sabor. Sus
ejecutivos plantean que sus productos son para “todos”, incluyendo a veganos, alérgicos, pero lo más relevante,
es que va dirigido a todos a los que quieren seguir comiendo las categorías que tienen ingredientes de origen
animal, pero sin el impacto negativo que producen los animales sobre el medio ambiente o por el maltrato a
los animales.
“Hoy día, la producción animal pasa a ser el principal factor del cambio climático. Deforestación, uso de agua,
uso de tierra, contaminación de los océanos, pérdidas de especies, deforestación del Amazonas, emisiones de
CO2. ¿Adivina quién es el número uno? Es la industria de alimentos”, explica Matías Muchnik, cofundador
de la empresa, en entrevista a un medio.
El propósito estratégico de esta empresa y la motivación de su innovación, es ser amigables con el medio
ambiente por la vía de eliminar a los animales en la cadena alimenticia humana, pero a la vez, ofrecer productos
con un sabor similar o mejor, a quienes quieren seguir sintiendo los sabores y texturas de los productos cárnicos
o lácteos, sin impacto ambiental y a menor precio relativo. "Estamos tratando de revolucionar la industria de
la alimentación y que cada vez más personas se cambien a una dieta sin elementos animales", explica Javiera
Bravo, jefa de Innovación de la compañía, en entrevista a 3Claves. Si bien el uso de plantas como insumo hace
que los productos tengan algunas características positivas para la salud, algunos de sus productos siguen
teniendo altas calorías, alto contenido de azúcar, alto sodio y altas grasas saturadas, lo que se refleja en los
sellos que tienen la mayoría de los productos de Notco.
NotCo lanzó NotMilk en los EE.UU. con dos variedades (Leche Entera y 2% Grasa), en Whole Foods, una
cadena de 468 supermercados Premium, hoy propiedad de Amazon (Jeff Bezos, dueño de Amazon es socio
inversionista en NotCo), y en Starbucks. Los primeros productos en Chile y luego en otros países de América
Latina, fueron NotMayo y NotMilk, y luego siguieron con NotIceCream, NotBurger y NotChicken, con las
mismas proteínas e imitando el sabor de sus símiles de origen animal. En la foto siguiente, pueden observar
algunos de sus productos.

[pág. 3]
3
Las variedades (SKUs) en cada categoría son limitadas en comparación a su competencia. Por ejemplo, en
helados, hay sólo cuatro sabores, en leches tres (Original, chocolate y low fat) y en Mayonesa, cinco sabores
(Original, Low Fat, Spicy, Olive y Garlic).
 Las ventas minoristas de alimentos de origen vegetal en los EE.UU.
 han aumentado en dos dígitos en los últimos años. En 2020, crecieron
 un 27 por ciento, llevando el valor de mercado total de productos
 vegetales a $ 7 mil millones de dólares. Un estudio de Mintel
 Consulting, reveló que en Chile la oferta de productos de origen
 vegetal, ha crecido en los últimos 4 años, 8 puntos porcentuales en la
 cuota de mercado de estos productos, que hoy alcanzan el 12% de la
 torta del rubro alimentario.
 De los tres países analizados en el estudio (Chile, Argentina y Brasil),
 Chile lleva la delantera en términos de aumento de la oferta de
 productos.
 Suponga que el equipo comercial de NOTCO está evaluando
alternativas de crecimiento, dado que crecer aceleradamente, tanto en Chile como a nivel global, es una
iniciativa estratégica para este año y el próximo.
Una de sus ejecutivas, Rúcula Berry, planteaba que el camino más atractivo era seguir extendiendo su marca
“NOT”, la cual ya tenía reconocimiento y recordación tanto en Chile como en otros países, a distintas
categorías de alimentos, incluyendo aquellas que no tienen origen animal, tales como pastas, azúcar, cereales
de desayuno, bebidas no alcohólicas, etc., enfatizando sus ingredientes orgánicos y sanos. La idea es sacar una
línea de productos bajo los atributos de “sano” (sin o con nivel reducido de gluten, azúcar, sodio, grasas
saturadas, calorías, etc.), con la marca “NOT”, evitando los sellos del Minsal, que por ley deben ir en los
empaques y que alertan a la población del potencial daño a la salud.
Por otro lado, el Gerente de Marketing, Rábano Celery, planteaba que el mejor camino de crecimiento era
potenciar la marca NOT en las categorías que ya manejaban (lácteos, aderezos, carnes) y que reemplazan
ingredientes de origen animal, creciendo en ellas vía la proliferación de sabores (en helados, leches
saborizadas), presentaciones de empaque (tamaños, tipos de empaque), funcionalidades y variedades de
sustitutos cárnicos (ej. Not Pork (cerdo), Not Fish (Salmón, Atún), NotCream (crema), NotCheese (Queso),
etc.). También proponía ampliarse al segmento de servicios de alimentación (restoranes, cadenas de comida
rápida, hoteles y casinos de empresas) como proveedor de las categorías mencionadas.
Preguntas:
 a) De acuerdo a la información del enunciado y desde el punto de vista de marketing, señale y explique
 claramente, tres argumentos en contra de cada una de las propuestas de los ejecutivos, dado el objetivo
 de crecimiento de la empresa y el contexto de NotCo.
 b) ¿Cuál debiera ser la estrategia de marcas de NotCo para su portfolio de productos, si se adoptan las
 propuestas de cada uno de los ejecutivos? Justifique claramente su respuesta para cada propuesta.

[pág. 4]
4
PREGUNTA Nº2
El Hospital Francés entrega servicios. Este centro asistencial se ha posicionado como un proveedor de atención
de salud con una alta calidad de servicio de todo su personal en los distintos momentos de interacción con el
paciente (toma de horas, consultas, hospitalizaciones, alimentación, procedimientos médicos y facturación,
entre otros). A través del tiempo, la organización también instaló la innovación en todas las 25 unidades o
áreas del Hospital, así como en sus diversos procesos y funciones. Para ello incorporó cambios tecnológicos
de punta en diagnósticos, tratamientos, cirugías, atención al paciente y administración hospitalaria, como ejes
sobre los cuáles se debía mantener la diferenciación respecto a otras instituciones de salud.
A pesar del prestigio logrado, el Hospital no estaba exento de un mayor nivel de rotación de personal que la
industria. Un grupo de trabajadores que presentaba una rotación no deseada particularmente alta eran los
Técnicos en Enfermería de Nivel Superior (TENS). Estas personas realizan labores de apoyo a los médicos y
enfermeras del hospital en funciones como:
 Recibir y preparar pacientes para el control de los diferentes profesionales
 Realizar controles de signos vitales y medidas antropométricas (peso y altura)
 Efectuar tratamientos y cuidados básicos
 Apoyar la realización de electrocardiogramas
 Realizar visitas domiciliarias acompañando a los médicos
La institución presentaba una rotación no deseada superior a la de la industria, tal como lo indica la tabla
siguiente:
 Hospital Francés Industria
 Rotación no deseada general 13% 7%
 Rotación no deseada TENS 18% 11%
Además de los TENS, un número relevante de empleados con buenas capacidades técnicas y conocimientos
se retiraba del Hospital ya que eran atraídas por otras organizaciones de salud que ofrecían remuneraciones
más elevadas. Incluso a niveles gerenciales existía fuga de talentos. Sin ir más lejos, hace una semana el
Gerente de Personas del Hospital, Francisco Morales, recibió una mejor oferta laboral de una empresa
farmacéutica, y la aceptó. En las entrevistas de salida que realizaba el área de Gestión de Personas a quiénes
abandonaban la organización, los aspectos económicos, en la gran mayoría de los casos, no eran el factor
decisivo para presentar su renuncia. Por el contrario, quiénes renunciaban se sentían frustrados sentir que no
aportaban en forma decisiva al logro de los objetivos del Hospital.
Por este motivo el Hospital decidió cubrir este puesto con María Sandoval, empleada de la organización hace
más de 10 años, quien se desempeñaba como Jefa de Remuneraciones y que había cursado hace pocos años
un diploma en Gestión de Recursos Humanos, el que le permitió incorporar una visión amplia de la gestión de
personas. Ya en su nuevo cargo de Gerente de Personas, María decidió concentrar sus primeros esfuerzos en
mejorar la selección de los TENS.
El foco en la selección de TENS era clave, ya que en las próximas semanas se realizaría una contratación
masiva de estos técnicos en el Hospital, debido al crecimiento y diversificación de los servicios ofrecidos. El
Hospital buscaba personas que contaran con el perfil técnico requerido para el cargo, de manera que pudieran
cubrir adecuadamente las funciones para las que se requerían sus servicios. Asimismo, se necesitaba contratar
a personas con una buena disposición a integrar los equipos interdisciplinarios que entregaban estos servicios,
los que incluían a médicos, enfermeras, paramédicos y administrativos, además de los propios TENS. La
cultura del Hospital Francés, desde sus inicios había sido que el cuidado al paciente requiere de la interacción
permanente de todas las áreas y especialidades de la organización. De hecho, dentro de la definición de cultura
organizacional se mencionaba que: “Entregar salud requiere una buena labor de nuestros médicos, enfermeras,
así como del personal técnico, de apoyo, de hotelería y alimentación, higiene y administración. Tenemos que
brindar al paciente una experiencia en salud única e integral, que nos distinga de otros centros asistenciales.”

[pág. 5]
5
Al revisar el proceso de selección del personal TENS, usado actualmente en el hospital, la nueva Gerente de
Personas observó que los antecedentes de las/los postulantes eran evaluados en varias instancias, las que con
frecuencia se desarrollaban en distintos momentos en el tiempo, dentro del proceso de selección, pero sin un
orden prestablecido. Entre las actividades más comúnmente desarrolladas en este proceso se incluían las
siguientes:
 Pruebas de conocimientos técnicos tales como procedimientos de cuidados básicos de pacientes,
 conocimientos de normas de bioseguridad y normas del manejo de material clínico
 Eliminación de candidatos sin requisitos mínimos para el cargo
 Ranking de postulantes en función de sus antecedentes curriculares
 Administración de una prueba de inteligencia general
 Entrevistas online de los Jefes de Unidad a los candidatos/as. Para ello, la Gerencia de Personas entregaba
 pautas para realizar dichas entrevistas en donde se sugerían algunas preguntas que indagaban en las
 competencias técnicas, ciertos valores como la honestidad y transparencia profesional y su interés real
 por el trabajo a desarrollar.
 Recepción de currículos
 Decisión y selección final del candidato a ocupar la posición por parte de la Gerencia de Personas
Para llevar adelante el proceso de selección, el Hospital confiaba de manera importante en el buen criterio de
sus Jefaturas de Unidad de las distintas especialidades médicas (pediatría, cirugía, urgencia, imágenes, etc.).
Concretamente, para la selección de los TENS, a estas Jefaturas, junto con facilitarles las pautas antes
mencionadas, se les entregaba libertad para conducir dichas entrevistas. Además, María descubrió que para el
cargo de TENS, que requiere un grado de especialización importante, se recibía un número extremadamente
grande de currículos, con una variedad de antecedes de personas con una amplia diversidad de historiales
personales y profesionales. Un 40% de postulantes decían tener habilidades y conocimientos que, una vez
contratadas, en realidad se demostraba que no poseían.
Desde que asumió su nuevo cargo como Gerente de Personas del Hospital, María Sandoval, había recibido
muchos comentarios respecto del “buen ojo clínico” que los Jefes de Unidad tenían para entrevistar y evaluar
a los candidatos para los cargos de TENS. María, sin embargo, tiene ciertas dudas respecto al proceso de
selección y solicita su opinión experta.
Preguntas:
 a) María le solicita que le indique 3 aspectos clave que deben modificarse en el perfil del cargo (aspectos
 a investigar en los candidatos/as) para acertar en un mayor número de casos a los TENS que se
 seleccionan, de modo de alcanzar los objetivos estratégicos del Hospital y reducir significativamente
 la fuga voluntaria del Hospital Francés.
 b) En segundo lugar, la nueva Gerente de Personas le solicita que, con sus conocimientos de Gestión
 Estratégica de Personas, le desarrolle un proceso estructurado de selección de los TENS, con
 actividades ordenadas secuencialmente en el tiempo, también con el objetivo de contribuir a los
 objetivos estratégicos de la organización y lograr una mayor fidelización de este personal.
 c) Por último y en términos específicos, María le solicita dos proposiciones concretas sobre cómo mejorar
 la efectividad de las entrevistas de selección del Hospital que realizan los Jefes de Unidad para predecir
 de mejor manera el desempeño futuro de los candidatos/as a TENS.

[pág. 6]
6
PREGUNTA Nº3
La empresa Queulat es una compañía que tiene la concesión exclusiva de generación de energía eléctrica en una
amplia zona del norte de su país. Por contrato con el Estado de Chile, Queulat es la única empresa autorizada para
generar energía en la zona de concesión. Para cumplir con los compromisos de la concesión, la empresa genera
energía a través de paneles solares por ser ésta una solución no sólo de mayor eficiencia y menor riesgo que otras
fuentes de energía tradicionales, sino además una fuente muchísimo más amigable con el medio ambiente.
Queulat adquiere paneles de energía solar y los instala en el lugar que se ha estimado es el más adecuado para
cumplir con los requerimientos de la demanda de energía de cada sector que corresponde a su zona de concesión.
Como resultado de su experiencia y de una relación de varios años con su proveedor de paneles solares, en este
momento se ha llegado a un nivel de eficiencia que ha hecho que, en la práctica, la demora entre el momento en que
Queulat compra los paneles solares y el momento en que ellos quedan instalados y listos para ser usados es mínima
(despreciable).
Por otra parte, se sabe que por distintas razones el proveedor acepta únicamente órdenes de compra de nueve paneles
solares por pedido. El pedido de nueve paneles tiene un costo total de UF 900, las que deben ser pagadas en el
mismo momento de la compra. Se estima que este precio se mantendrá sin cambios en el futuro.
Se espera que cada panel pueda ser usado sin límite en el tiempo, en otras palabras, su vida útil es “infinita”. Se
sabe también que cada tres años la compañía debe instalar, y ella se ha comprometido a hacerlo, tres nuevos
paneles solares de modo de lograr satisfacer la creciente demanda por energía solar que se espera en su zona de
concesión. Dado que justamente ayer, 31/12/2021, Queulat hizo el último pedido de nueve paneles, y hoy 1/1/2022
instaló y comenzaron a operar tres de ellos, en este momento la compañía tiene en sus bodegas seis paneles sin uso.
Suponga que para las empresas el costo del bodegaje propiamente tal (bodega y seguro) de los paneles solares es
de $0.
La Sra. Yanara, Gerente de Gestión de la empresa minera “El Alambre Pelado”, empresa que se encuentra fuera de
la zona de concesión de energía de Queulat, se ha acercado a usted, Gerente Comercial de Queulat y le ha solicitado
que Queulat le arriende, a partir de hoy 1/1/2022, cuatro paneles solares durante un período de exactamente cinco
años. Si bien la empresa minera “El Alambre Pelado” podría acceder a la compra de los paneles por cuenta propia,
ella no está en condiciones financieras que le permitan financiar dicha inversión en este momento, razón por la cual
estaría optando por el arriendo. Aun cuando el arriendo de paneles solares no es parte del negocio de Queulat, y
sabiendo que este eventual arriendo en nada cambiaría las ventas de energía de Queulat en su zona de concesión y
con el solo propósito de colaborar con la empresa minera, Queulat ha accedido a arrendarle los cuatro paneles
solares a un plazo de exactamente cinco años a partir del día de hoy. Por su parte, la empresa “El Alambre Pelado”,
se ha comprometido a que, al término del quinto año, los paneles serían devueltos a Queulat en perfectas
condiciones, listos para ser usados por Queulat cuando lo estime conveniente.
La política de “Queulat” es la de ayudar a todos quienes pueda, con la condición de que, en este caso, este eventual
arriendo no signifique una disminución de valor de la riqueza de sus propios accionistas. “Queulat” tampoco busca
aumentar la riqueza de los accionistas producto de este eventual contrato de arriendo.
Se sabe que el costo de oportunidad relevante para las inversiones en paneles solares es de 10% real anual y que el
Estado ha otorgado una ventaja tributaria permanente a las empresas generadoras de energía solar, a la que está
sujeta “Queulat”, que consiste en el no pago de impuestos durante toda la vida de la empresa.
Sobre la base de la información que se le ha entregado a usted se le pide responder la pregunta que se le formula a
continuación, presentando un análisis ordenado con todos los cálculos que corresponda:
Si el acuerdo del arriendo considerase que la empresa “El Alambre Pelado” pagaría el arriendo anual en UF al
término de cada uno de los cinco años de duración del contrato (teniendo presente que el primer pago de arriendo
sería el 31/12/2022), a usted se le solicita que obtenga el monto anual que Queulat debiera cobrar por el arriendo de
los paneles a la empresa “El Alambre Pelado”, de modo de cumplir satisfactoriamente con el objetivo que ella se
ha propuesto. Recuerde que este objetivo es el de colaborar con la empresa minera, con la condición de que el
contrato de arriendo no altere el valor de la empresa “Queulat” para sus dueños, respecto de la alternativa de no
arrendar los paneles. Explicite sus supuestos si los hubiera.

[pág. 7]
7
PREGUNTA Nº4
 La reinvención del Cirque Du Soleil
 En junio de 2020, la empresa de espectáculos más conocida del mundo, Cirque du Soleil, se
 declaró en quiebra, al mismo tiempo que los principales inversionistas de la compañía, presentaban
 un plan de reestructuración para enfrentar las dificultades financieras agudizadas por la aparición de la
 pandemia de Covid-19. A partir de Marzo de 2022, el circo regresa en gloria y majestad con más de 10
 espectáculos y muchos desafíos.
Cirque du Soleil es un espectáculo circense sin animales que incluye artistas, payasos, acróbatas y gimnastas,
creando una mezcla de actos de danza, teatro y música. No ofrece simples espectáculos circenses, ofrece
experiencias teatrales que capturan la imaginación, deseos y recuerdos de sus espectadores. Su objetivo es
entregar entretenimiento, innovación e invocar la imaginación. Es una experiencia inolvidable por donde
quiera que se mire.
El centro del espectáculo no es único, es múltiple y diverso, y recae en los propios artistas. Números
simultáneos que sorprenden y mantienen al espectador durante las dos horas que dura el espectáculo
completamente sintonizado con la escena.
Su Estrategia
En palabras simples se trata de gestionar de una forma no tradicional un negocio de espectáculo, combinando
expresión artística y libertad para los artistas situándolos a ellos como centro del entretenimiento. Todo con
un esquema muy estudiado y disciplinado que hace que cualquier espectáculo donde quiera que se exhiba e
independiente de los artistas que actúen, será siempre el mismo ante los ojos del espectador.
El circo busca diferenciarse en los detalles de sus montajes y en la constante innovación que ofrece a través de
espectáculos de vanguardia, con tecnología de punta y una permanente capacidad de reinvención que lo sitúa
como “El Mejor Circo del Mundo”.
Entre sus principales prácticas de gestión está el reclutamiento de artistas a nivel mundial, los cuales pueden
ser desde personas que ofrecen espectáculos callejeros, hasta medallistas olímpicos. Hay una constante
búsqueda de gente creativa a todo nivel. Se estimula un buen clima laboral en el cual el personal se siente muy
orgulloso de trabajar en la empresa, donde se promueven sus habilidades, personalidad y creatividad,
haciéndoles sentir que son parte de todo el espectáculo. Se privilegia la diversidad cultural, de idiosincrasias y
costumbres. Se tienen condiciones de trabajo ejemplares para todos los empleados (transporte, vivienda,
comida, etc.), con una importante inversión en capacitación para tener a los mejores “maestros” en cada
especialidad. Se protege el conocimiento mediante la transmisión de competencias entre los propios integrantes
de la organización. La compañía se preocupa del cuidado y manejo de las lesiones de los artistas; de la rotación
de ellos entre los diferentes espectáculos, e incluso cambiar los espectáculos.
Desde su creación hace 36 años, Cirque du Soleil se orientó a un público selecto compuesto por familias de
alto poder adquisitivo capaces de pagar un nivel de precios superior por un espectáculo de la sofisticación que
ofrecía Cirque du Soleil. Sin embargo, la pandemia lo cambio todo, y de la noche a la mañana, el público
desapareció de sus teatros y carpas, con lo que su principal fuente de ingresos, el público en vivo en el
espectáculo, se redujo a cero.
La Crisis de Cirque du Soleil
El presidente y consejero delegado de Cirque du Soleil, Daniel Lamarre, declaró que “durante los pasados 36
años, Cirque du Soleil ha sido una organización muy exitosa y rentable. Sin embargo, sin ingresos desde la
pandemia nos hemos visto forzados a cerrar”.

[pág. 8]
8
Hasta la aparición de Covid-19 la compañía operaba 44 espectáculos en todo el mundo. El cierre de sus
espectáculos implicó el despido de unas 4.680 personas, 95% de ellos directamente relacionados con el
espectáculo (artistas la mayoría, músicos, cantantes e iluminadores), debido a la cancelación de sus espectáculos.
En 2019, el Circo generó ganancias por 155 millones de dólares. En 2020, sin ganancias ni caja, y con una deuda
de unos 900 millones de dólares, por primera vez en su historia el circo enfrentó la quiebra de la mano de un
profundo plan de reestructuración financiera.
El renacer del Cirque de Soleil.
El último trimestre de 2021 y el inicio del 2022 presentaron un nuevo panorama para la compañía. En efecto,
recientemente Cirque du Soleil ha iniciado una campaña de promoción para anunciar su regreso en todo el
mundo. Ya ha retomado siete espectáculos fijos en Las Vegas, otro en Riviera Maya y la gira del espectáculo
“Alegría”. Además, ha estrenado un montaje nuevo en Orlando y en enero del 2022 presentará el espectáculo
“Luzia” en la sala Royal Albert Hall de Londres. Pero no será hasta marzo del año 2022 cuando vuelva a
levantar su emblemática carpa itinerante en Europa, y lo hará por primera vez en Barcelona con Luzia, que se
trasladará en julio a Alicante y en noviembre a Madrid. La balanza parece haberse invertido de nuevo: desde
éxito a la quiebra en tres meses y de la quiebra otra vez al éxito en menos de un año.
Son muchas las preguntas que deja el caso vivido por Cirque du Soleil. Aunque quizás la más importante de
todas tiene que ver con cómo evitar volver a vivir lo que la pandemia le enrostró: pese a ser tan único y
espectacular, no era infalible.
Preguntas:
 a) ¿Cuáles son las fuentes que generan la Ventaja Competitiva de Cirque Du Soleil? Argumente con
 precisión. En su respuesta se solicita que muestre los diferentes elementos que participan en la creación
 de la Ventaja Competitiva y por qué la hacen sostenible.
 b) Dado el impacto que la pandemia le ha mostrado a Cirque du Soleil, ¿Qué ajustes debiera la compañía
 incorporar en su modelo de negocio de manera de robustecer su posición competitiva, y así evitar a
 futuro el impacto generado en el negocio por eventos como la pandemia vivida? Argumente con
 precisión.

[pág. 9]
9
PREGUNTA Nº5
En los últimos años ha habido una explosión en la cantidad de datos disponibles para la toma de decisiones en
las áreas de marketing de empresas y organizaciones: redes sociales, datos de navegación y transacciones a
través de Internet, información de bases de datos de clientes y registros de datos en plataformas. Este escenario
contrasta marcadamente con el escenario de 20 años atrás en el cual la principal fuente de información en
marketing eran las encuestas.
La plataforma Statista (www.statista.com) es una de las plataformas de datos para negocios más importantes
en Internet que registra datos de 170 industrias en 150 países. En la categoría de automóviles de lujo tipo sedán
en EE.UU., Statista registra (entre otros datos) el precio de los automóviles en miles de dólares, la participación
de mercado en esta categoría de automóviles y un rating o puntaje, en la escala 1 a 10, elaborado
automáticamente por la plataforma a partir de características físicas u observables de las distintas marcas:
consumo de combustible, características del sistema de seguridad, características del sistema de frenos, espacio
interior y potencia del motor. Los datos de Statista se actualizan constantemente cada vez que se produce un
cambio en las condiciones de mercado.
La figura que se presenta a continuación muestra la posición relativa de 10 marcas de la categoría de
automóviles de lujo tipo sedán en EE.UU. en base a los registros de Statista. Los modelos de cada marca no
se han considerado para una mejor visualización. En el eje horizontal de la figura se representa el precio en
miles de dólares y en el eje vertical se muestra el rating o puntaje elaborado por Statista. El tamaño de los
textos en la figura es proporcional a la participación de mercado de las marcas en esta categoría. Las líneas
punteadas vertical y horizontal corresponden a los promedios de precio y puntaje de las marcas
respectivamente.
 Figura: Mapa de Marcas de Automóviles
Preguntas:
 a) Describa ventajas y desventajas de la metodología utilizada para representar la posición relativa de las
 distintas marcas, según la figura y los registros de Statista, con respecto a la metodología usual o
 clásica de Mapas de Posicionamiento.
 b) ¿Cómo se puede explicar que, según el mapa de la figura, marcas como Mercedes-Benz, y en cierta
 medida BMW, tengan alta participación de mercado en circunstancias que hay otras marcas con mejor
 rating y un precio más conveniente?

[pág. 10]
10
PREGUNTA Nº6
Chile tiene mercados de deuda tanto nominal como indexada al alza del costo de vida representada por la UF
(unidad de fomento). Suponga que la tasa de interés que se exige en el mercado a un bono nominal, o que
ofrece pagos en pesos, es 𝑦 , en tanto que el rendimiento exigido en el mercado a un bono indexado a la UF
es 𝑦 . Es común en el mercado referirse a la diferencia (o spread) 𝑦 − 𝑦 como el break-even de inflación.
En simple, una tasa de inflación para el periodo igual a 𝑦 − 𝑦 implica que el retorno total medido en pesos
 1
de ambos bonos es exactamente el mismo . Una inflación efectiva mayor a 𝑦 − 𝑦 implica que el retorno
en pesos del bono indexado a UF fue mayor al del retorno del bono nominal.
Preguntas:
Responda las tres preguntas que se le formulan a continuación. Fundamente cuidadosamente sus respuestas.
 a) Economistas argumentan que tanto la expansión fiscal fruto de la pandemia, como los problemas de
 oferta, han llevado a alzas sistemáticas de precios y a una mayor inflación en 2021 (7,2%, la más alta
 en Chile desde hace una década). Frente a esta inflación en alza, su jefa le pide su opinión respecto de
 nominalizar (invertir en instrumentos de deuda denominados en pesos) o indexar (invertir en
 instrumentos de deuda que tengan reajustabilidad en UF) totalmente su cartera de renta fija. Desarrolle
 una regla de decisión que relacione su expectativa subjetiva de inflación (por ejemplo, basada en sus
 propios modelos económicos o análisis estadístico) con el break-even de inflación observado en el
 mercado para los bonos en pesos y en UF. Suponga que su jefa es neutral al riesgo y que, por lo tanto,
 solo le importa el pago esperado de cada estrategia (no su riesgo).
 b) No solo ha subido la inflación en el último año, sino que también la incertidumbre respecto de la
 inflación futura. Suponga ahora que su jefa es aversa al riesgo, y que prefiere medir los retornos de las
 inversiones en términos de su poder adquisitivo real, es decir, en UF. Si su jefa sigue pensando en
 nominalizar o indexar el 100% de la cartera de renta fija. ¿cómo se modifica, si es que es necesario
 hacerlo, la regla de decisión del inciso a) anterior? No se espera que usted entregue una respuesta
 cuantitativa, sino que explique cualitativamente qué nuevos elementos es necesario incorporar a la
 regla de decisión, de ser el caso.
 c) Una analista del Banco Central que es su amiga está interesada en predecir la inflación futura usando
 datos macroeconómicos y de mercado. Suponga que corre una regresión predictiva de este tipo:
 𝜋 = 𝛼 + 𝛽(𝑦 − 𝑦 ) +𝜀
 Donde 𝜋 es la inflación observada en h periodos después del periodo t, (𝑦 − 𝑦 ) es el break-
 even medido en el periodo t, y 𝜀 es el residuo (error) de la regresión. Esta analista encuentra que el
 poder predictivo del break-even para inflaciones futuras es muy bajo (por ejemplo, baja magnitud y
 significancia del coeficiente 𝛽, bajo 𝑅 de la regresión, etc.). Dado que usted trabaja en el sistema
 financiero, la analista llama para pedirle su ayuda en entender este resultado. En algún punto de la
 conversación su amiga analista hace la siguiente aseveración: “La regresión indica que el mercado de
 la renta fija chilena es totalmente ineficiente: los partícipes del mercado hacen pésimas proyecciones
 de inflación (…)”. Elabore una explicación para su amiga basándose en lo que ya analizó en los incisos
 a) y b) de esta pregunta. ¿Puede el mercado nacional de renta fija ser eficiente a pesar de lo encontrado
 por su amiga en la regresión predictiva? Fundamente su respuesta.
1 En estricto rigor, esta afirmación es solo aproximadamente correcta, o funciona bien cuando la tasa de inflación es baja.
Si usamos tasas logarítmicas la afirmación es exacta. Para efectos de esta pregunta puede suponer que no hay error de
aproximación o que estamos hablando de tasas logarítmicas.

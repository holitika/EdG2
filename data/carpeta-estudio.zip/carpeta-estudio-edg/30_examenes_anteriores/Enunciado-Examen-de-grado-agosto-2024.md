# Examen de grado · Enunciado-Examen-de-grado-agosto-2024

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


AE z
Alle ESCUELA DE ADMINISTRACIÓN
E $4) FACULTAD DE ECONOMÍA Y ADMINISTRACIÓN
qe
EXAMEN DE GRADO
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el alumno
deberá obtener una calificación de "Pase” en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos hojas
que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar hojas
adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga que
los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. Nonecesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la realidad
de las empresas que allí se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados dichos
supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la misma.
ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente a la Profesora Marta Del Sante, presidente de la Comisión de
Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos” (calculadoras alfanuméricas, etc.). El
cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas condiciones,
la presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala ni relojes inteligentes, los que deberán
estar apagados y guardados en las mochilas adelante.
12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el examen.
13. Alterminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han identificado
con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar como “borrador”,
esas hojas no se deben entregar con las respuestas.
(—_—-- y A
Fecha : 9 de agosto de 2024
Duración : 9:00 horas a 12:00 horas
Consultas: Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá la Profesora Marta
Del Sante, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 y 11:00 hrs.
AProX.).
-----
: 2
PREGUNTA NI
El índice S£P500 es el índice bursátil más representativo del mercado accionario de EE.UU. En julio de 2024, la razón
precio-utilidad (cíclicamente ajustada tomando las utilidades promedio de los últimos 10 años corregidas por inflación)
para el S£P500 alcanzó uno de los niveles más altos del último tiempo. En concreto, la razón precio-utilidad en julio de
2024 llegó a niveles de aproximadamente 35 siendo que el promedio histórico de esta razón es de alrededor de 20. La
figura de abajo muestra la dinámica de esta razón desde finales del siglo XIX:
Evolución de la Razón Precio-Utilidad del S£P500
? RD PERO AL A O]
Varios de los peaks anteriores en la razón precio-utilidad, como los de 1929 y 1999, precedieron fuertes caídas en la
bolsa americana. Hay que notar que son solo algunos episodios en más de 100 años. Otros peaks (como el de 2020
relacionado al Covid) se debieron a fuertes caídas en las utilidades y solo anticiparon fuertes alzas en las utilidades en
los años siguientes. Por uno u otro motivo, esta razón captura el interés de muchos analistas que argumentan en base a
ésta, que las acciones americanas están “sobrevaloradas/caras” o “subvaloradas/baratas”.
En los últimos años, también han subido las tasas de interés largas (por ejemplo, la tasa del bono del tesoro americano a
10 añios en la figura de abajo) y las tasas de interés cortas como la tasa de política monetaria americana (Fed Funds Rate).
Estas tasas han subido desde niveles de prácticamente 0% durante pandemia hasta 5% aproximadamente hoy en día.
Evolución de la Tasa del Bono del Tesoro Americano a 10 años
FRED. 2 — tarcervieic or: 3.5. Trezsuny Securrdes al 10.Year Constant htotariay, Oveted on ax fovesunent Basis
: A A
: du20 ra e ut zaza dana: 621 da JE + ua de 207
Bhadad arsas indicas U.S. rertanens Saura: Boer el Covers of me Federal Rosen Destem (18) ter siste
-----
? 3
Evolución de la Tasa de Política Monetaria Americana (FED Funds Rate)
ERED 4: — tecern runas estocuve Raro
. ne
¿ e A
: l
' : AAA
Zea nes zm are pr pa pa mear pm pa
Shaced arezs inticate U.S. recsssions: Áaurcz. Esara 11 Gorarnors of me Fegera Resena Bye (US) trec suduistod org
Responda las preguntas que se le formulan a continuación, entregando los argumentos en los cuales fundamenta sus
respuestas.
1. Explique a través de un modelo de valor presente los elementos necesarios para justificar los actuales niveles
de la razón precio-utilidad. En su respuesta distinga conceptos como tasa libre de riesgo, premio por riesgo, y
crecimiento esperado de flujos. ¿Qué implica su análisis respecto de las predicciones de crecimiento de flujos y
de retornos futuros? Considere un horizonte de 10 años aproximadamente. Se pide un análisis cualitativo, de
dirección y magnitudes relativas de los efectos, pero no se piden cifras precisas.
2. Algunos analistas de mercado han expresado preocupación frente a los niveles de valoración que se observan
actualmente, Más de alguno menciona la palabra “burbuja”, es decir, la posibilidad de que las valoraciones estén
desancladas de variables fundamentales y que sean solo ficticias. ¿Implica la razón precio-utilidad a julio de
2024 necesariamente la existencia de una burbuja?
3. Siusted quisiera proteger su inversión actual en el Sé¿P500 frente a caídas en los precios, o frente a un “pinchazo
de la burbuja”: ¿qué instrumento financiero derivado podría utilizar? Sea explícito en las características de ese
instrumento.
-----
: 4
PREGUNTA N*2
La “anti-estrategia” de Hermés
Hermés International, es un fabricante francés de artículos de lujo especializado en accesorios de cuero, seda, textiles y
otros artículos. Ha sido calificada como la marca de lujo más valiosa del mundo en diferentes estudios de valoración de
marcas. La categoría de artículos de cuero es la que más contribuye a los ingresos de la empresa (41%). En el último
año, las acciones de Hermés han subido más de un 30% con un rendimiento superior al de grandes marcas de lujo, como
Louis Vuitton o Gueci.
Hermés goza de un estatus icónico en el mundo del lujo, gracias a una combinación de historia heredada, artesanía única
y exclusiva, atención y máximo cuidado en los detalles y altos niveles de calidad y profesionalismo en la confección de
“los productos. Su secreto, dicen los expertos, es que no ha intentado masificar sus productos, sino que ha optado por
mantener la calidad y exclusividad de los mismos, estimulando el sentido de escasez ante el cliente, quien no
necesariamente encuentra el producto cuando lo desea. Nunca se ha dirigido a un segmento muy masivo, sino que
siempre exclusivo. El masivo per se, no le interesa. Su foco está en quienes valoran genuinamente un artículo de lujo.
Hermés mantiene un estricto control de su crecimiento, lo que va en sintonía con la sensación de escasez. Hoy en día, la
compañía es dirigida por los primos Axel y Pierre-Alexis Dumas, ambos directores propietarios de la empresa y
tataranietos del fundador, quienes han sido fieles a los valores de la marca: calidad, herencia y refinamiento. Son estos
principios los que la han llevado a hacer casi lo contrario de lo que hacen otras marcas de lujo. En efecto, en Hermés
siempre se ha evitado la producción masiva, las líneas de fabricación automatizadas y la subcontratación de partes del
proceso de fabricación; nunca se ha sustituido al mejor material posible para algún producto por razones de ahorro de
costos, ya que todo ello deteriora el resultado final y por tanto el valor percibido por el cliente.
La innovación continua y el refinado diseño es lo que ha caracterizado el desarrollo de la empresa, proceso que está a
cargo de sus directores propietarios. Ello ha ido de la mano con abrir talleres y no fábricas, reflejando la dedicación única
a cada producto. La selección de artesanos es otra de las tareas relevantes, llegando hoy en día a contar con un equipo
de más de 7.000 artesanos, todos empresarios independientes a Hermés, pero que trabajan prácticamente de forma
exclusiva para la fabricación de productos de Hermés. Son de diferentes edades y nacionalidades, y el oficio de artesano
de Hermés se va heredando de generación en generación enseñando padres a hijos a trabajar conforme a los principios
de la compañía.
Los artesanos están separados en diferentes especialidades (cueros, maderas, materiales reciclables, etc.) los cuales dan
vida a cada producto, siempre cuidando los más mínimos detalles. Son más de 15 especialidades distintas
cuidadosamente coordinadas por los directores propietarios desde la casa matriz para así lograr el producto final buscado
con los estándares anhelados. Unido a lo anterior es necesario destacar el estricto proceso de control de calidad en la
fabricación, que además va estableciendo el cuánto fabricar. Esto último es ejercido directamente por los directores
propietarios de la compañía, quienes ponen especial énfasis en entender las necesidades de los clientes y en realizar el
control de calidad para asegurar que lo producido satisfaga lo que el cliente anhela. Así mismo, el crecimiento no está
entregado a los ejecutivos comerciales, ya que son los propios directores propietarios quienes deciden cuánto producir y
dan el visto bueno para saber si un producto sale o no al mercado, dependiendo del alineamiento que tenga con los gustos
y necesidades de los clientes. Con todo, Hermés solo incrementa su capacidad de producción en un máximo de 10%
cada año, lo que supone una garantía de crecimiento sin abandonar ni los atributos esenciales de la marca, ni la
motivación que moviliza a la compañía: seguir siendo un objeto de deseo para los consumidores que aman el real lujo.
Los productos de Hermes se fabrican en su totalidad en sus “Ateliers Hermes” (talleres de trabajo Hermés), todos en
Francia. Cada producto es fabricado íntegramente a mano por un solo artesano, lo que incrementa la percepción de
calidad, de artesanía y de singularidad. El aura de exclusividad de la marca es esencial ya que no tiene la intención de
presentarse como al alcance de todos. Nuevamente aquí aparecen los directores propietarios. Son ellos quienes
seleccionan a los artesanos que pasarán a integrar la red de “artistas” que más tarde producirán las piezas que darán vida
a las exclusivas colecciones. Literalmente, un trabajo hecho de detalles en el más propio sentido de la palabra.
Como parte de su estrategia de marketing Hermés no colabora con celebridades para construir marca. Tampoco lanza
ofertas ni promociones de productos. Las mismas colecciones de productos se venden en todo el mundo, y siempre con
edición limitada y distribución acotada sólo a sus propias tiendas. La compañía introduce la “paciencia” como un
principio muy fuerte de su marca. En lugar de hacer frente a la alta demanda subiendo el precio, como dictan las leyes
del mercado, Hermés suple esa solución clásica por la lista de espera. En otras palabras, el exceso de demanda es parte
-----
: 5
de lo buscado lo que contribuye a hacer al producto aún más anhelado. Un ejemplo de esto último es el exclusivo bolso
Birkin, el modelo más icónico de la empresa, cuyo precio oscila entre los 100 mil y los 300 mil dólares. Su producción
es obra de solo un artesano (de entre los 7.000), demora dos meses en la confección de una unidad, y hay lista de espera
de 18 meses para adquirir uno de ellos. Los interesados deben ser clientes de la marca desde hace años, de lo contrario
no pueden comprarlo. Lo interesante además es que esta espera desvía la atención hacia otros productos del catálogo que
sirven de “consuelo a la espera”, como carteras y cinturones mientras llega el anhelado bolso. Finalmente señalar que la
publicidad es muy selectiva, con una inversión en televisión, medios impresos y videos en línea, cuidadosamente
analizados y seleccionados utilizando el humor traducido en ingeniosas situaciones, para mostrar los productos.
Los desafíos futuros para Hermés
Hermés sabe del poder de su marca. Hoy en día, la compañía se encuentra en la encrucijada de cómo mantener los valores
que le han dado el éxito, y al mismo tiempo lograr un mayor crecimiento sin entrar a ser masivo en el mercado del lujo
y rentabilizando el activo que la marca le proporciona. La empresa es consciente que se ha desarrollado con éxito a lo
largo del tiempo, siempre apegada a principios empresariales sólidos. Sin embargo, en los últimos años, se ha instalado
un sentimiento de duda con respecto a las bondades de su estrategia para competir en un creciente y cada vez más
competitivo mercado del lujo. Incluso se ha llegado a hablar de la “anti-estrategia” de Hermés, en alusión a que un
planteamiento tan descabellado como el que tiene la compañía, desafía los parámetros tradicionales de la forma de
competir en el mercado del lujo. Un conocido analista del sector del lujo lo verbalizó muy bien la semana pasada en
Nueva York en una nota alusiva a la empresa aparecida en el prestigioso diario The New York Times: “No parece
sostenible que Hermés pueda continuar aplicando una estrategia tan contradictoria con lo que el mercado hace,
negándose a crecer como lo hacen la mayoría de las empresas en una industria. Su afán por hacerlo siempre en contra
de lo que hacen otros grandes de la industria le está pasando la cuenta y cada vez la separa más de los sólidos principios
de una buena estrategia competitiva”.
Preguntas:
1. Conrespecto a la estrategia de Hermés, ¿Diría Ud. que crea valor? ¿Diría que captura valor? Para cada pregunta
explique por qué Sí o por qué No.
2. No cabe duda que Hermés tiene ventaja competitiva. ¿Cuál es la core competence o complementariedades
estratégicas que hacen realidad la materialización de dicha ventaja competitiva? Señale de la forma más clara
posible, los elementos que la conforman y la manera en cómo ellos se interrelacionan entre sí.
3. ¿Es sostenible la estrategia de Hermes? ¿Qué riesgos existen a la sostenibilidad de dicha estrategia?
-----
: 6
PREGUNTA N*3
En consumo masivo, algunas de las categorías más relevantes de productos son las relacionadas con cuidado personal
(piel, cabello, cosmética, fragancias, etc), medicamentos OTC (venta sin receta) y bebidas “isotónicas”. A nivel mundial,
los productos de cuidado personal han crecido en los últimos 5 años a una tasa inferior al 3% anual, mientras que los
OTC a menos del 2% anual, alineado con el bajo crecimiento demográfico. La pandemia ha cambiado hábitos y las
ventas tienden a estabilizarse en estas dos categorías.
Genomma Lab Internacional, S.A.B. de C.V es una de las empresas líderes en la industria de productos farmacéuticos
OTC, cuidado personal y bebidas isotónicas en México, con una creciente presencia internacional. Genomma Lab se
dedica al desarrollo, venta y promoción de una gran variedad de productos de marca, muchos de los cuales son líderes
en términos de ventas en la categoría en la cual compiten.
Genomma Lab, viene desarrollando desde el 2009, una estrategia para crecer sus ventas, que contempla entre otras
acciones, generar eficiencias en su portafolio de productos. Así el 2009 tenía 62 marcas y 430 UPC!. Hoy posee cerca
de 30 marcas y 211 UPC. Sus ventas totales han crecido sobre el 15% anual.
La empresa pretende desinvertir o vender las marcas que no son parte de su foco principal de crecimiento, aun cuando
sean rentables. Así, busca enfocarse en sólo algunas categorías. “Vemos una gran posibilidad de desinvertir en ciertas
categorías. En las categorías en las que estamos ahora o en otras de OTC [medicamentos de venta libre o sin receta]
podemos crear mucho valor”, dijo Rodrigo Herrera, fundador y presidente de Genomma Lab, durante el evento de la
compañía, “Día de los inversionistas 2023”.
ISOTONIC BEVERAGES SUEROX — +2850mM
GASTRO CES TED geo mM La tabla de la izquierda muestra el ranking de ventas 2023 de
o o . - marcas de Genomma Lab. La empresa produce y comercializa
SIINCARE/DERMA | CerminrsAsené moco productos para el cuidado del cabello basados en jalea real de
HAIR CARE NIÑO TES +9somM abejas bajo la marca Tío” Nacho, la bebida isotónica
A BÚkhk  electrolítica Suerox, el medicamento para osteoartritis X-RA Y
ANALGESICS ia a la o y analgésicos como Alliviax, así como las máquinas de afeitar
cae TukolD EL MS 080m desechables Groomen y productos de cuidado de la piel como
. — Asepxia y Cicatricure, entre otros.
INFANT NUTRITION Novamil +500 MM
RAZORS € BLADES GRCOMEN +150 MM
qe A a
O Dia od o A |
Una de las categorías de mayor crecimiento para Genomma Lab es la de bebidas a S San al
. Los var > > E Ur NSMATA A
isotónicas (electrolíticas e hidratantes) con su marca Suerox. El año 2023 su LE la
volumen creció 42%, alcanzando un 4,2% de participación del mercado E A
mundial y un 44% de crecimiento compuesto anual (CAGR) desde el 2018. A ES A E
nivel mundial, la categoría de bebidas isotónicas crece significativamente en Hy=y E] En
ventas y las predicciones apuntan a un continuo crecimiento, tal como se puede 4 0 (EL
observar en la Gráfica siguiente. a O
1 código universal de producto (UPC, por sus siglas en inglés), combinación de marca, formato, versión, con un código de producto único,
independiente de dónde se venda.
-----
: : 7
Ventas Mundiales de Bebidas Isotónicas (US$B).
sn
2563
250 e
2236
2169
200
za 151<
z 2720
z , 1643
E 150 E
se
e
2018 2019 2020 2021 2022 2023 2024 2025 2026 2027 2028
Cambio en Ventas de Suerox (%)
KEY HIGHLIGHTS:
Ñ ETE
SETS :
SS SS A
a
AN II 7 A
A A ll
y a A Ñ +14%
MANE EU
Suponga que uno de los ejecutivos de Genomma Lab, planteaba que se debían tomar decisiones comerciales claves
respecto de Suerox, en particular, reducir la inversión publicitaria de Suerox en los distintos mercados donde se
comercializa exitosamente, aumentar el número de formatos y sabores, desde 6 UPC a 15 UPC, e incrementar las
promociones de precios vía descuentos a los canales de distribución.
Preguntas:
1. Considerando la estrategia de reducción del portfolio de UPCs y marcas de Gennoma Lab., identifique los cuatro
factores principales que debiera considerar la empresa, al eliminar una categoría o marcas de su portfolio.
Argumente conceptualmente cada factor.
2. Analice críticamente cada una de las propuestas del ejecutivo, respecto de la mezcla comercial para Suerox.
Argumente su respuesta.
A
-----
: 8
PREGUNTA N'4
El estado chileno es dueño de un terreno en una zona del desierto de Atacama y ha decidido licitar y entregar dicho
terreno en concesión a alguna empresa que ofrezca desarrollar en él un proyecto de generación de energía solar. El
proyecto consistiría en la construcción y operación de una planta solar generadora de energía eléctrica. Las bases de la
Icitación estipulan que el estado chileno ofrece el terreno para que sea usado indefinidamente, es decir, durante infinitos
años y del mismo modo la empresa que gane la licitación se debe comprometer a operar (generar y vender la energía
generada por la planta solar) para siempre.
Las bases de la licitación estipulan también que la empresa que gane la licitación tendrá que construir e iniciar la
operación de la planta el 1% de enero del año 2025 (hoy). Luego de estas fechas no hay posibilidades de desarrollar el
proyecto. Suponga que la construcción de la planta es instantánea, lo que hace que el momento en el que se construye la
planta y aquel en el que la empresa ganadora de la licitación puede comenzar a operarla es el mismo, y corresponde al
1" de enero del año 2025.
Para entregar el terreno a la empresa que se gane la licitación, el estado chileno pide un pago anual constante en US$
que deberá ser pagado por la empresa ganadora el último día de cada año, es decir a partir de fines del año 2025 y durante
los infinitos años que duraría la concesión del terreno.
Las empresas interesadas en presentarse a la licitación deben tener en cuenta la siguiente información:
+ Inversión: Se estima que el monto que se deberá invertir es de US$ 50.000, monto total que debe ser pagado el
1 de enero del año 2025.
+  Mantenciones y reinversiones: Se estima que en la medida que a la planta de energía solar se le haga todos los
años las mantenciones necesarias y además se realicen las reinversiones que permitan que cada año ella quede
como nueva, la planta estaría en condiciones de generar energía solar durante infinitos años.
+ Ingresos de caja estimados para la empresa que gane la licitación: Se ha estimado que producto de la venta
de energía, la empresa que gane la licitación pueda obtener a fines del año 2025 y anualmente de manera
perpetua, un flujo de ingresos de caja total anual esperado de US$60.000
+ Egresos de caja estimados para la empresa que gane la licitación: Se ha estimado que producto de la
generación de energía, la empresa que gane la licitación pueda obtener a fines del año 2025 y anualmente de
manera perpetua, un flujo de egresos de caja total anual esperado (incluidos egresos de caja por mantenciones
y reinversiones) de US$50.000.
+ Tasa de descuento anual: La tasa anual relevante para la evaluación del proyecto dado su riesgo es de 10%
anual y es constante a través del tiempo.
En todas las preguntas que se le formulan más adelante suponga que:
e Las empresas que se presenten a la licitación no tienen ni tendrán deudas y buscan maximizar su valor
económico o de mercado.
+ Por “monto máximo” se entenderá aquel monto que a quien lo ofrece le dejaría indiferente entre ofrecer o no
dicho monto, es decir aquel que no haría cambiar la riqueza de quien lo ofrece.
* No hay impuestos
+ Todos los flujos de caja, con la sola excepción de lo relativo a la inversión inicial, se producen al término de
cada año.
Responda las preguntas que se le formulan a continuación mostrando los cáleulos necesarios:
1. Suponga que la empresa “Rayo de Luz” está interesada en presentarse a la licitación. Obtenga el monto máximo
anual constante en US$ de hoy (1'" de enero de 2025) que “Rayo de Luz” debiera estar dispuesta a pagar al estado
chileno, al término de cada año, por tener la concesión que le permitiría operar durante infinitos años la planta de
energía.
2. Suponga ahora que se produce un cambio en las condiciones de la licitación. Ahora el estado chileno está dispuesto
a que la planta de energía se pueda construir y comenzar a Operar ya no solo el 1" de enero del año 2025, sino
alternativamente el 1% de enero de los años 2026 o 2027 o 2028. Luego de este último año no hay posibilidades de
construir la planta. Respecto de los próximos años se sabe que la cantidad de energía que la empresa podría generar
y vender anualmente podría variar cada año, en un porcentaje respecto del flujo de caja de ingresos del año anterior,
según lo indicado en la tabla que se muestra más adelante. Por otra parte, razones regulatorias han llevado a las
-----
: 9
empresas interesadas en presentarse a la licitación a estimar un aumento en el flujo de egreso de caja total anual, en
un porcentaje respecto del flujo de egresos de caja del año anterior según lo indicado en la tabla que se muestra más
adelante.
Tasa de aumento anual respecto del año anterior
o Aumento % del Flujo de ingresos de Caja | Aumento % del Flujo de Egresos de Caja
(respecto del año anterior) (respecto del año anterior]
[2025  |Datode Flujo de Ingreso de Caja: US$60.000]
[po aa | am 7]
lar [| as]
as [a]
En todo caso las empresas interesadas en presentarse a la licitación han estimado que lo relevante para determinar el
monto (US$) de la oferta que cada una de ellas haría en este caso, sería suponer que tanto el flujo de ingresos de caja
total anual esperado como de egresos de caja total anual esperado que se generaría a perpetuidad sería el que
corresponde al año en que decidan construir y comenzar a operar la planta. De este modo, de la lectura del cuadro de
ingresos y egresos de caja anuales presentado anteriormente se debe desprender que, si la empresa comienza a operar
el año 2025, los ingresos de caja de todos los años en que ella opere serían de US$60.000 a perpetuidad. Si comienza
a operar el año 2026 los ingresos de caja de todos los años en que ella opere serían de US$61.800 a perpetuidad y así
sucesivamente. Lo mismo se aplica a los egresos de caja.
Sin embargo, para tener la opción de poder construir y comenzar a operar la central en alguno de los años futuros
posibles (2026 o 2027 o 2028) la empresa que se presente a la licitación deberá ofrecer pagar al estado hoy (1% de
enero de 2025) y por una sola vez, un monto (US$) adicional a lo que ella estaba dispuesta a pagar anualmente en la
pregunta anterior. En este caso entonces y bajo las nuevas condiciones de la licitación, la empresa ganadora tendría
que pagar al término de cada año, a partir del 31 de diciembre de 2025, el monto en US$ ofrecido en la pregunta
anterior y además pagar hoy, por una sola vez, el monto adicional que haya ofrecido pagar y que le permitiría tener
la opción de construir la planta en el año que más le convenga.
Suponiendo que cualquiera que sea el año en el que se decida construir la planta el monto de la inversión inicial se
mantendrá en US$50.000 y que dicha suma se debe pagar el primer día del año de su construcción, a usted se le pide
determinar el máximo monto adicional en US$ de hoy (1"? de enero de 2025) que la empresa “Rayo de Luz” debiera
estar dispuesta a ofrecer pagar hoy al estado con las nuevas condiciones de la licitación.
3. Finalmente suponga que las condiciones de la licitación son las que permiten que la planta se construya al comienzo
de alguno de los cuatro años que se han descrito previamente, pero que ahora el estado ha flexibilizado la forma de
pago del monto (US$) adicional que de acuerdo a la pregunta anterior la empresa estaría dispuesta a pagar hoy (1%
de enero de 2025), por una sola vez, por tener la opción de poder construir y comenzar a operar la central en alguno
de los años futuros posibles (2026 o 2027 o 2028). El estado ahora permitiría que dicho pago adicional se agregue al
monto anual que la empresa tendría que pagarle por la concesión a partir del 31 de diciembre de 2025 y que usted
obtuvo en la primera pregunta. Obtenga el máximo monto total anual constante en US$ de hoy (1'* de enero de 2025)
que “Rayo de Luz” debiera estar dispuesta a pagar al estado chileno, al término de cada año, bajo las condiciones
aquí señaladas.
-----
" 10
PREGUNTA N'%5
La empresa Lipigas lanzó hace un año una aplicación (App) para realizar pedidos de gas residencial directamente desde
un teléfono celular. A pesar del corto tiempo, un porcentaje importante de los pedidos ya se realizan utilizando este
canal. Para fortalecer este nuevo canal de comunicación y ventas, la empresa ha realizado fuertes inversiones
publicitarias en TV y redes sociales por el impacto que creen que tienen en la descarga de la App y luego en las ventas.
La empresa realizó un estudio para evaluar el impacto de la inversión en distintos medios de contacto (televisión abierta
y redes sociales) sobre las ventas semanales. Luego de recolectar los datos, se generaron dos modelos de regresión lineal
múltiple. El primer modelo determina cuántas personas descargaron la App (y crearon una cuenta) como función del
precio e inversión publicitaria, mientras que el segundo modelo determina las ventas (en unidades de 15kg vendidas)
como función del precio e inversión publicitaria.
En particular los modelos son:
Modelo 1:
Descargas; = ay + ayPrecio; + azInversión en TV, + azInversión en Redes Sociales; + ej
Modelo 2:
Ventas; = fp + f,Precio; + fB2Inversión en TV, + BgInversión en Redes Sociales, + e?
Donde Descargas;corresponde a las cuentas creadas en la App en la semana £, Ventas; corresponde a las unidades de
15kg vendidas en la semana £, considerando todos los canales de venta (en miles de unidades), Precio, es el precio
promedio de los cilindros de 15kg en la semana £ (en miles de pesos) que puede considerarse exógeno en ambas
ecuaciones, y, las variables Inversión en TV, e Inversión en Redes Sociales;, corresponden a los montos en millones
de pesos en dichas inversiones en la semana f.
Para estimar los modelos se utilizaron los datos de las últimas 52 semanas en la Región Metropolitana. Los resultados
se muestran a continuación
: : Modelo 1: Modelo 2:
Variable Independiente Coeficiente
Intercepto 2.000
Inversión en TV Abierta
Inversión en Redes Sociales
R? Ajustado
Todos los coeficientes son estadísticamente significativos al 95%. Considere que el precio está en pesos mientras que
la inversión publicitaria está en millones de pesos.
Preguntas:
1. Tomando los modelos econométricos desarrollados para Lipigas y sus resultados, indique si las inversiones en
publicidad en TV y en publicidad en redes sociales, pueden o no ser consideradas como complementarias o
sustitutas. Fundamente su respuesta.
2. El gerente general quiere saber cuál de los dos tipos de inversiones en publicidad le genera mayor retorno
financiero a la empresa, y si estos modelos (1 y 2), permiten responder su inquietud. Respóndale al Gerente,
argumentando su respuesta.
3. Considerando el Modelo 2, ¿Cuál sería la reducción en el precio, equivalente al impacto de la publicidad tanto
en TV abierta como en redes sociales de $10 millones y $5 millones (simultáneamente), en una semana en
particular? Considere un precio actual promedio de $30.000.
-----
. a
PREGUNTA N'%
Costco y Sam's Club son dos de las cadenas de supermercados de gran tamaño más exitosas financieramente de las
últimas décadas. Ellas compiten mano a mano en el mercado de Estados Unidos ofreciendo bajos precios a sus
consumidores. Sam's Club cuenta con 551 tiendas, emplea a 110.200 personas y tiene un 40% del mercado en valor de
ventas de tiendas de gran tamaño, mientras que Costco cuenta con 67.600 empleados, 338 salas de venta y un 50% de
participación de mercado en valor de ventas en Estados Unidos.
Al igual que en todo el mundo, los supermercados ya desde hace unos seis a siete años enfrentan crecientemente múltiples
desafíos políticos, sociales, ambientales y laborales para su negocio. Las empresas supermercadistas deben hacerse cargo
de reducir dramáticamente las emisiones de carbono que genera toda su cadena de actividades. Por otra parte, los
consumidores están cada vez más activos en castigar a las marcas poco transparentes en la comercialización y marketing
de sus productos y que no basan su negocio en valores positivos. En lo laboral, los gobiernos han estado impulsando la
implementación de nuevas leyes y normativas laborales, a partir de mayores demandas por bienestar de los trabajadores.
Entre estas nuevas medidas se encuentran la intensificación del teletrabajo y trabajo flexible, la no discriminación en la
selección, promoción y despido de personal, la equidad de género, una mayor supervisión en materia de condiciones de
trabajo seguras y saludables, la obligación de incrementar los niveles de información, capacitación y desarrollo en
diversas materias a los empleados y sanciones más duras en contra del acoso laboral y sexual en el trabajo.
Para poder comprar en Costco los clientes deben pagar una membresía anual de 100 dólares y así acceder a sus bajos
precios. Esta tarifa, unida a la venta de sus productos genera ingresos significativos y un margen bruto de alrededor del
30%. Costco vende una selección limitada de 3.800 productos, lo que le permite negociar mejores precios con un menor
número de proveedores, usar el espacio de manera más eficiente y rotar su mercadería rápidamente, lo que significa
menos capital inmovilizado en inventario y con ello puede trasladar esos ahorros a sus clientes miembros. Costco también
ha expandido su marca propia, Kirkland Signature, que representa más de un 25% de sus ventas y cuyos márgenes brutos
son más altos que en productos de marca comercial, ya que es considerada una de las marcas privadas de mayor prestigio
del mercado.
Por su parte, Sam”s Club compite con “precios bajos todos los días” de manera constante, sin depender de promociones
temporales, atrayendo a una amplia base de clientes sensibles a precios. También exige una membresía por un valor de
75 dólares al año para poder acceder a comprar en sus tiendas. Sam's Club ofrece una amplia gama de categorías y
aproximadamente 7.000 artículos en sus tiendas. La empresa mantiene costos operativos bajos mediante una cadena de
suministro altamente eficiente, la compra en grandes volúmenes, la búsqueda constante de eficiencia en todas las áreas
de la empresa y la inversión de montos significativos en tecnología y procesos logísticos avanzados para optimizar sus
operaciones. Como resultado de su modelo de gestión, Sam's Club tiene márgenes brutos de alrededor del 24%. Sam's
Club también cuenta con marca propia, Member's Mark, que representa cerca de un 17% de sus ventas cuyos productos
son percibidos como de una calidad levemente superior a la de sus marcas comerciales.
Costco ofrece un sueldo promedio a sus trabajadores de 17 dólares por hora el que es muy superior al de la industria, El
82% de sus empleados cuenta con un seguro médico y el 91% recibe un plan de jubilación con una contribución anual
por parte de la empresa de 1.331 dólares por empleado. Cuenta con un esquema de incentivos variables por desempeño
que aumenta en función de los años de servicio y desarrollo de carrera y pueden alcanzar los 5.550 dólares anuales.
También otorga un pago de 0,15 dólares por cada dólar que sus trabajadores invierten en acciones de la compañía. La
empresa entrega amplia autonomía a los empleados para la toma de decisiones sobre el manejo diario de las tiendas
(siempre alineadas con las políticas y objetivos de la empresa). También otorga un bono a la innovación y sugerencias
para lograr mejoras operativas y de servicio al cliente. Costco cuenta con una política de promoción interna que ha
significado que la mayoría de los líderes en Costco hayan sido promovidos desde dentro. También ofrece una variedad
de programas de capacitación que ayuda a los nuevos empleados a fortalecer las herramientas para desarrollar su actual
trabajo, a desarrollar habilidades de liderazgo a los empleados promovidos a roles de supervisión y a potenciar sus
capacidades basadas en los objetivos de la empresa de corto y largo plazo, la amabilidad y proactividad del servicio a
los clientes y los valores de la compañía.
En cuanto a su gestión de personas Sam's Club paga un sueldo promedio por hora de casi 12 dólares, muy cercano al
salario mínimo. Los empleados de Sam's Club pueden recibir bonos variables por desempeño anuales que varían en
función del desempeño individual y del rendimiento de la tienda. Estas bonificaciones pueden alcanzar hasta 1.000
dólares dependiendo de las ventas y otros indicadores de rendimiento. Por su parte, Sam's Club también le otorga un
pago de 0,15 dólares por cada dólar que sus trabajadores invierten en acciones de la compañía. La empresa cuenta
también con beneficios limitados para sus trabajadores, como un seguro médico que cubre al 45% de sus trabajadores y
A
-----
? 12
un plan de jubilación de costo de la empresa que les aporta 747 dólares por empleado. La empresa utiliza una mezcla de
promociones internas y un alto porcentaje de contrataciones externas para los diferentes cargos de la organización. La
toma de decisiones tiende a estar más bien centralizada. Los empleados de las tiendas tienen ciertos espacios específicos
para la definición de una porción de la oferta de productos de cada tienda que no requieren la aprobación de los niveles
superiores. La capacitación de su personal se basa en un plan de inducción inicial breve en donde se enseñan las políticas
y procedimientos básicos de la empresa. También cuentan con capacitación por períodos acotados de tiempo en el puesto
de trabajo y programas de liderazgo en la Sam's Club Academy para un número reducido de personas de la compañía.
Preguntas:
1. Enunreciente seminario sobre gestión de personas en retail, un analista planteaba lo siguiente: “No comprendo cómo
dos empresas que compiten en el mismo sector enfocadas en precios bajos como Sam”s Club y Costco pueden tener
estrategias de gestión de personas tan diferentes”. ¿Cómo responde usted a la duda que tiene el analista? Indique los
tres principales argumentos para explicar dichas diferencias.
2. Existe un porcentaje mayoritario de empresas que, en distintas industrias, aplican un esquema de gestión de personas
similar al adoptado por Sam's Club. Por su parte, una minoría ha adoptado un modelo de gestión de personas similar
al de Costco. Si ambas empresas han sido exitosas. Indique tres factores fundamentales que explican la mayor
adopción del modelo de gestión de personas implementado por Sam?s Club con respecto a una minoría de compañías
que optan por aplicar el esquema de gestión de personal de Costco.
3. A continuación, se observa un gráfico con la evolución del precio de la acción de las dos empresas. El mercado valora
más la gestión de personas implementada por Costco que la de Sam's Club. Asumiendo todo lo demás constante para
ambas empresas y considerando las variables asociadas a la gestión de personas, se pide que indique qué puede
explicar esta diferencia en la valorización de la acción entre empresas.
f 600%
AA dr . 400%
2 ni 2
AR Cy
o 0 pros
IRA AAA AA 0%
2015 2016 2017 2018 2019 2020 2021 2022 2023 2024
«- Sarm's Club — Costco
-----


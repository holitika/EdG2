# Examen de grado · semestre-1-2014

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


>
:
PONTIFICIA UNIVERSIDAD CATÓLICA DE CHILE
ESCUELA DE ADMINISTRACIÓN
FER,
2)
Ea
NIVI LAY
E E
EXAMEN DE GRADO
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen,
el alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para responder cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni
utilizar hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta.
Suponga que los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
realidad de las empresas que allí se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente al Profesor Ignacio Rodríguez, Presidente de la
Comisión de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.).
El cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9, Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
condiciones, el Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala, los que deberán estar apagados y
no deberán mantenerse sobre el escritorio durante el examen.
12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
como “borrador”, esas hojas no se deben entregar con las respuestas.
(  _A —>=+= ==
Fecha : 24 de Enero de 2014
Duración : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el Profesor
Ignacio Rodríguez, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45
y 11:00 hrs. (aprox.).
xAE4> A —  ___—_ __
-----
2
PREGUNTA N* 1
En 1982 la empresa Coca-Cola introdujo en Estados Unidos la bebida gaseosa Diet Coke (que fue vendida como
Coca-Cola Light en el resto del mundo), eliminando las calorías de la tradicional Coca-Cola al usar aspartame, un
endulzante artificial. En 2005, la empresa lanzó exitosamente Coca-Cola Zero, originalmente dirigida a los hombres
y promocionada como libre de calorías pero con similar sabor al de la Coca-Cola tradicional, usando también
endulzantes artificiales. Ambas bebidas (Light y Zero) representan hoy aproximadamente el 20% del total de bebidas
cola que vende Coca-Cola en el mundo, y en varios países, Zero supera actualmente en ventas a Light. Hacia fines del
2013, la bebida “Coca-Cola Life” fue introducida exclusivamente en Argentina y Chile, como mercados de prueba.
“Coca-Cola Life” es endulzada con extracto de Stevia, hierba originaria de Brasil y Paraguay, y en menor medida con
azúcar, logrando tener un 60% menos calorías que la Coca-Cola regular.
El nuevo producto, Coca-Cola Life, tiene 36 calorías por cada 200 cc. Es la primera Coca-Cola endulzada
naturalmente con Stevia y azúcar. Esto es una mezcla que permite que la bebida sea baja en calorías, y hace que se
encuentre en el intermedio entre las Coca-Cola Light y Zero -que no tienen calorías- y la Coca-Cola regular. Stevia es
percibido como el endulzante más natural respecto de otros endulzantes como la sucralosa, sacarina, aspartame y el
azúcar misino.
La marca Coca-Cola, con 127 años de antigiiedad, es una de las más reconocidas y valiosas del mundo (Interbrand,
2013). En los últimos 20 años, la empresa ha expandido su alcance en el mundo de las bebidas en categorías tales
como: aguas filtradas, saborizadas, vitaminizadas y minerales; jugos de fruta; isotónicas; energizantes; entre otras
bebidas. Del total de bebidas vendidas por la empresa Coca-Cola, un 75% son gaseosas y un 48% son vendidas bajo
la marca Coca-Cola,
La venta de bebidas gaseosas en EE.UU., el principal mercado, han estado cayendo entre un 1% y 2% por año,
llegando el 2013 al nivel que tenían en 1996. Algo similar ocurre en todo el mundo, respondiendo a una tendencia que
busca productos de bajas calorías, como resultado de una mayor conciencia sobre los problemas de la obesidad y una
preferencia creciente por productos naturales. A lo anterior se agrega el efecto demográfico de envejecimiento de la
población, lo que la hace que las personas se preocupen relativamente más de su salud y bienestar.
Un reciente estudio a nivel mundial, en una muestra representativa de consumidores de bebidas gaseosas, cuyos
beneficios buscados en una bebida gaseosa y su importancia relativa son homogéneos, arrojó los resultados que se
muestran en la siguiente Tabla:
(Ver Observación 2) | Regular Light Zero Competencia 1 | Competencia 2 | Competencia 3
aaa TA
Essabross > AA
Eset] A RA]
Es dulce > YT A
[ueritva Y Y o fa | 2 | e. | 3 | 1 |]
[Me despierta Y” vw > __| 6 [| e [se | 3 |. 5 [| 7 |]
[o engorda | ws | o | _7_| 6 | 6 | o [3 |
Meltena Y Ye [ls | e | 2 [| 3 | 2 |
[Su enduizante ss nataral | 3 | IA A
Esaegre TT] AAA
Buena para comparar | 9] AA
fe da energia Y Pa]
Observación 1: Las percepciones de cada beneficio percibido en las distintas marcas de la Tabla, son evaluadas con una
nota que va desde 0 a 7, siendo 7 la mejor evaluada. :
Observación 2: La importancia relativa es porcentual. A mayor %, mayor importancia tiene ese beneficio en la decisión de
compra.
-----
3
Un analista de la industria, planteaba que el lanzamiento de “Coca-Cola Life” era un gran error y que sólo confundiría al
consumidor y afectaría negativamente las ventas de la familia completa de las bebidas que se vendían bajo la marca
Coca-Cola. En cambio, ejecutivos de Coca-Cola respondían que “Coca-Cola Life” era una correcta aplicación de los
conceptos de marketing en beneficio de la categoría de bebidas gaseosas.
PREGUNTAS:
a) Si el objetivo de la empresa Coca-Cola fuera aumentar las ventas en la categoría de bebidas gaseosas con marca Coca-
Cola, ¿qué debe lograr Coca-Cola Life en la mente de los segmentos meta? Argumente su respuesta precisando la (s)
fuente (s) de origen más probable (s) del volumen incremental esperado.
b) Más allá de aumentar las ventas, ¿qué otros argumentos podría haber tenido en mente la empresa Coca-Cola para
lanzar al mercado “Coca-Cola Life”? Responda en forma breve y precisa. :
€) ¿Qué factores podrían hacer fracasar a “Coca-Cola Life”, considerando que su estrategia comunicacional ha sido
evaluada como bien hecha y que sus precios son competitivos? Argumente en forma concisa.
A
-----
4
PREGUNTA N' 2
Eran las 14:00 horas y Richard Tormen, el gerente de recursos humanos de CletaPlus, empresa dedicada a la
fabricación y comercialización de bicicletas, reflexionaba acerca de la elevada rotación del personal
comercial de la compañía y cómo ella afectaba la satisfacción de los clientes e impedía el crecimiento de los
ingresos y la rentabilidad.
Por ello, Tormen ideó Pedalea, un plan de incentivos que reemplazaba al anterior esquema de bonificaciones
para el personal comercial de las 30 tiendas de venta a público con la que ya contaba la empresa en las
principales ciudades del país. Este nuevo esquema consistía en el reparto de utilidades concebido para que la
compensación de los jefes de tienda fuese más competitiva y los motivara a maximizar las utilidades de su
local. Luego de 6 meses, a fines de 2013, el programa Pedalea había concluido su fase piloto en dos tiendas
cuidadosamente seleccionadas y equivalentes en todas las variables relevantes del negocio. Tormen tenía en
sus manos el informe final de este programa y necesitaba decidir qué recomendar a los dueños y directores
de CletaPlus: aplicar el programa en todas las tiendas, modificarlo o simplemente desecharlo por completo.
Sergio Aliste y Fernando “Lobo” Vera, grandes glorias del ciclismo nacional, fundaron CletaPlus al retirarse
del profesionalismo. Ellos fabricaban y vendían productos elaborados con materiales de primera calidad,
diseños de vanguardia, aerodinámica y a precios algo superiores a la competencia. CletaPlus buscaba además
entregar una atención personalizada. “Nos gusta transmitir nuestro cariño por el ciclismo y que el cliente
sienta que vendemos una forma de vida y no solo una bicicleta, junto a una asesoría técnica experta”,
declaraban los socios. Como consecuencia, en los primeros años del negocio las ventas crecieron
aceleradamente en un público amplio de ingresos medios y altos.
Este éxito acelerado, sin embargo, trajo aparejados varios efectos negativos. En particular, la rotación del
personal de CletaPlus comenzó a incrementarse a partir de 2011. Aliste decía que ellos hacían lo mejor
posible para que CletaPlus fuese un buen lugar para trabajar, especialmente para quienes comparten su
pasión, así que no podían entender porqué seguían perdiendo buenos jefes de tienda. “El año pasado nuestros
costos de selección duplicaron lo presupuestado debido a la enorme cantidad de contrataciones realizadas —la
mitad de personal externo- para llenar las vacantes que se produjeron.” La falta de personal especializado en
el mercado, junto a la intensa demanda derivada del crecimiento y la necesidad de dar un excelente servicio
para diferenciarse de la competencia, implicaba que ningún puesto podía permanecer vacante por mucho
tiempo. Por ello, las contrataciones las hacía cada jefe de tienda de acuerdo a los requerimientos de su local.
A veces, algún empleado ascendía al puesto de jefe; en otras ocasiones, se contrataba a alguien externo. Se
optaba por lo que fuera más rápido.
La baja remuneración era el principal motivo que esgrimían los jefes de tienda para renunciar, según las
entrevistas de salida que realizaba el área de recursos humanos. La compensación a estos ejecutivos consistía
en un sueldo base mensual más un bono trimestral variable asociado al promedio de ventas de la tienda a su
cargo en cada período. Estos niveles de ventas se agrupaban en cinco rangos y las jefaturas de las tiendas
recibían el mismo bono, tanto si apenas habían calificado para el rango como si se encontraban en su límite
superior. “Comulgo con la estrategia de CletaPlus, pero la compensación no me alcanza; me voy”, afirmó
uno de los jefes de tienda. Otro colega decía: “manejo la tienda más rentable, pero mi compensación no lo
refleja porque es la más pequeña y no logra ventas suficientes para calificar en un rango más alto”.
A diferencia del anterior plan de incentivos de la empresa, el nuevo sistema de incentivos (Pedalea), hacía
que los bonos variables del jefe de tienda estuvieran directamente relacionados con las utilidades de su local
y no con las ventas. Los jefes recibirían un 35% del incremento de las ganancias de la tienda y los asistentes
del jefe obtendrían el 15% del aumento de dichas utilidades. El 50% restante de los incrementos sería para la
empresa, Con el fin de fomentar la retención, los bonos se pagarían un mes después del trimestre en el que se
(AAA
-----
5
generaron. Cualquier empleado que renunciara antes de la fecha de pago perdería el derecho al bono de ese
periodo. A cambio de ese mayor riesgo que estaban asumiendo, los jefes tendrían, dentro de ciertos límites,
una mayor libertad para gestionar su tienda.
Como el plan representaba un cambio importante, se decidió probarlo primero en fase piloto antes de
lanzarlo en toda la empresa. Las siguientes tablas muestran los resultados financieros y de satisfacción de
clientes, antes y después de la implementación del piloto de Pedalea, durante el 2" semestre de 2013. El local
de Barrio Italia, a cargo de Miguel “Topo Gigio” Droguett, estaba ubicado en un barrio atractivo por sus
múltiples ciclovías, Por su parte, la tienda Mall Santiago Centro, se encontraba localizada en un centro
comercial, a cargo de Roberto “Pata de Lana” Muñoz, otro ex ciclista, imbatible en la ascensión a los
“caracoles” de Portillo.
Resultados Operacionales de las Tiendas (en $ millones)
a Antes de Después de Antes de Después de
Tienda Barrio Ital .
¡enda Barrlo Italia Pedalea Pedalea Tienda Mall Stgo. Centro Pedalea Pedalea
Ingresos: 100 11: Ingresos 100. 99|
Gastos ¡Gastos
Sueldos Jefe 9 10 Sueldos Jefe 10 11
Incentivo Variable Jefe 0 5 Incentivo Variable Jefe 0 5
Sueldo Personal 14 14] Sueldo Personal 14 7
Incentivo Variable Personal 0 2] Incentivo Variable Personal o 1
imposiciones 2 2 Imposiciones 2 2
Materiales y Publicidad 3. 32] Materiales y Publicidad 31 26]
Arriendo y Otros Gastos Fijos 13 13] Arriendo y Otros Gastos Fijos 15 13
Resultado Operacional Tienda 31 37|  |Resultado Operacional Tienda 28 34]
Resultados Encuesta Satisfacción de Clientes (1 = Malo; 5 = Excelente)
Tienda Barrio Italia Antes de — Después de Tienda Mall Stgo. Centro Antes de — Después de
Pedalea Pedalea Pedalea Pedalea
Rapidez al saludar 4,3 41 Rapidez al saludar . 4,2 3,8
Calidad exposición de las bicicletas 4,6 4,7 Calidad exposición de las bicicletas 4,8 4,5
¡Sentirse valorado como cliente 3,4 4,7 ¡Sentirse valorado como cliente 3,5 3,1
Tiempo de espera 4,2 3,5 Tiempo de espera 4,1 3,8
Conocimiento técnico vendedor 4,5 4,5 Conocimiento técnico vendedor 4,4 4,5
Probabilidad de volver 4,4 4,7 Probabilidad de volver 4,33 3,9
Probabilidad de recomendar 4,3 4,6 Probabilidad de recomendar 4,2 3,9
A la luz de estos resultados, Tormen pensaba que el nuevo sistema de incentivos había dado los resultados
esperados y que apoyaban la implementación de la estrategia de negocios de CletaPlus. Aliste y “Lobo”
Vera, en cambio, pensaban que el sistema de incentivos que se había probado en las dos tiendas, no era el
más adecuado para lograr los objetivos estratégicos de la empresa.
PREGUNTAS
a) ¿Con cuál de las opiniones está usted de acuerdo: con Tormen o con Aliste y Vera? Justifique su respuesta
en forma breve y precisa.
b) ¿Haría cambios en el esquema de incentivos “Pedalea”? ¿Cuáles y por qué?
€) ¿Qué modificaciones haría en las prácticas de selección de personal de las tiendas, para disminuir la
rotación y lograr los objetivos estratégicos de FullCleta? Argumente en forma precisa y concisa.
A
-----
6
PREGUNTA N* 3
En enero de 2014, Malaquías Matamala, un alumno en práctica en el banco de inversiones “Banco del Sur”,
fue llamado a la oficina del Jefe del Departamento de Análisis Financiero de dicho Banco.
Los siguientes son los comentarios hechos en esa oportunidad por el Jefe de Análisis Financiero del Banco a
nuestro estimado Malaquías (se reproducen a continuación en letra itálica o cursiva):
Malaquías, aquí están los Estados Financieros de la “Viña Los Huasos” del año 2013,
correspondiente a la información del último ejercicio contable disponible de la Viña, y del año 2008
(Ver Figuras N1 y N2 en la página siguiente). Nuestro departamento de inversiones ha mantenido
acciones de la “Viña Los Huasos” desde comienzos del año 2008. Como usted sabe, al seleccionar las
inversiones que hace nuestro Banco, se pone mucho énfasis en el análisis de la “calidad” de las
rentabilidades contables de las empresas en las que se invierte, esto es, se pone especial cuidado en
tratar de entender las causas o variables que explican la obtención de dichas rentabilidades y, en
particular, de las rentabilidades del patrimonio de las empresas en que se invierte,
La Memoria Anual del año 2013 de la “Viña Los Huasos”, muestra una preocupante disminución en
la rentabilidad patrimonial de sus dueños. Pues bien, nuestra gente de inversiones quiere que
nosotros le comentemos respecto de la forma como la “Viña Los Huasos” ha obtenido sus
rentabilidades sobre el patrimonio en el último tiempo, comparando su rentabilidad patrimonial del
año 2013, con la rentabilidad del patrimonio obtenida por la empresa durante el año 2008.
A usted se le pide que entregue un análisis o informe en el que indique, acompañando ordenadamente los
cómputos que avalan sus cifras, cuáles son a su juicio las causas o factores de mayor importancia que
explican la disminución que ha experimentado la rentabilidad patrimonial (rentabilidad de los dueños) de la
“Viña Los Huasos”, cuando se comparan los años 2008 y 2013. Su informe debe tomar en cuenta los
distintos elementos o variables que, desde una perspectiva financiera, determinan la rentabilidad del
patrimonio de una empresa.
Sea profundo en su análisis y específico en su respuesta y además tome en consideración las notas y
supuestos que se detallan a continuación:
Notas y supuestos:
+ En los cálculos aritméticos que usted haga (particularmente razones financieras), use dos decimales.
Cuando deba obtener un porcentaje (%), expréselo con dos decimales. Ejemplo: 10,45%
+ Cuando usted deba calcular una razón financiera en la que en el numerador tiene un “flujo” y en el
denominador un “stock”, para la variable de “stock” use el valor que ella tiene al final del período,
Este supuesto se hace únicamente por razones de orden práctico que se aplican a este Caso.
+ No hay inflación en el período 2008 — 2013.
+ Suponga que la empresa “Viña Los Huasos” no ha tenido cambios significativos en sus criterios y
prácticas contables durante los últimos 5 años.
AÁAA
-----
7
Figura NL
"Viña Los Huasos"
Balances
(A131 de diciembre de cada año; cifras en Millones de $
HA 877]
¡ACTIVOS
¡Activos Corrientes o Circulantes:
Caja 315 580
¡Cuentas por Cobrar Existencias
¡Existencias 2.257 2.274;
¡Total de Activos Corrientes o Circulantes 5.166 4.978
¡Activos de Largo Plazo Operacionales: ad
Plantas y Equipos (Neta) 2.616 2.074]
¡Terrenos 159 592]
Total Activos de Largo Plazo Operacionales: 2.775 2.666
¡Activos de Largo Plazo No Operacionales: |
Inversiones Financieras de Largo Plazo 2.131 2.196
¡Total de Activos (Operac. + No Operac.) 10.072 9.840|
¡PASIVOS + PATRIMONIO
Pasivos Corrientes o Circulantes:
¡Cuentas por Pagar a Proveedores 696 752]
Ingresos Percibidos por Adelantado 1.000 600]
¡Dividendos por Pagar 73 118
Impuestos por Pagar 337 636|
Otros Gastos Devengados por Pagar 1.128 786
Préstamos Bancarios de Corto Plazo 645 242
¡Total Pasivos Corrientes o Circulantes 3.234 2.892]
Pasivos de Largo Plazo:
Préstamos Bancarios de Largo Plazo
¡Bonos de Largo Plazo 519 522,
Total Pasivos de Largo Plazo (Deuda Financiera) | 1.714] 1.250]
¡Total de Pasivos 4.948 4,142
Patrimonio:
Lied Ro
Utilidades Retenidas 2.410 3.448
¡Total de Patrimonio 3410] 4,448]
[Total Pasivos + Patrimonio
Figura N*2
"Viña Los Huasos”
(2008 versus 2013)
(Montos son en Millones de $)
EA
Ingresos por Venta de Bienes y Servicios 13.500 13,000
- Costo de Ventas -10.125 -9.750
- Gastos de Administración y Ventas [GAV] -2.295| - -1.950
|- Depreciación del Ejercicio [1] -314 -249
= Resultado Operacional 766 1,051
+ Otros Ingresos 170 176
- Gastos Financieros -137 -175
= Utilidad Antes de Impuesto
- Impuesto a las Utilidades -280 -526
|= Resultado del Ejercicio (Utilidad Neta) ns 56
[1]: El total de la depreciación del ejercicio del año de la empresa, está reflejado
en esta cuenta, Las cuentas "Costo de Ventas” y "GAV", no incluyen gastos
por depreciación.
HA A
-----
8
PREGUNTA N' 4
Tres empresas navieras que transportan contenedores a nivel mundial, y que compiten con la
chilena Compañía Sudamericana de Vapores CSAV, anunciaron recientemente que iban a
establecer una alianza estratégica: la “Red P3”. Esta alianza tendría un 38% de participación de
mercado del transporte de containers (o contenedores) a nivel mundial. Las navieras que conforman
esta alianza son: Maersk Line que contribuiría con un 42% de la capacidad instalada de transporte
de la alianza, MSC que aportaría un 34%, y CMA CGM que contribuiría con el 24% restante. Red
P3 sería la alianza más grande a nivel mundial y se espera que comience a operar en el segundo
trimestre de 2014.
El mercado del transporte de contenedores presenta indicios claros de estar en etapa de madurez. La
manera como funciona es muy estándar: el transporte de containers se realiza en “loops”, esto es,
una vuelta completa origen — destino — origen, como podría ser, por ejemplo, la ruta Hong Kong —
Valparaíso — Hong Kong. El servicio de transporte debe estar disponible en forma continua en la
ruta elegida. Esto significa que cada firma configura sus barcos de modo que, por ejemplo, siempre
haya uno que está siendo despachado cada semana rumbo al destino (Valparaíso en el ejemplo
anterior). Si la ruta ida y vuelta toma 10 semanas, la disponibilidad en forma continua significa que
la naviera tendrá 10 barcos (uno para cada semana) haciendo el “loop” (la vuelta completa). De esta
forma, distintas navieras compiten en el mismo loop, por lo que los niveles de ocupación de los
barcos pasan a determinar la rentabilidad de las empresas navieras. Por supuesto, los costos de un
loop para una naviera son casi todos fijos, ya que una vez que se decide echar a andar un loop no se
puede suspender el servicio por falta de carga. El costo más importante de una naviera es el costo
del petróleo.
Los miembros de la Red P3 han anunciado que operaran 225 barcos en 29 loops, comparado con los
32 loops que ofrecen actualmente las tres empresas por separado. Analistas de la industria estiman
que la participación de mercado de la Red P3 alcanzará a un 44% en las rutas Asia-Europa, lo cual
supera el umbral del 30% establecido por los reguladores de la Unión Europea. Aunque superar el
30% de participación de mercado no es ilegal, será interesante ver cómo responden los reguladores
a la noticia, toda vez queel índice de concentración de Herfindahl en estas rutas crecerá
considerablemente.
Es crucial tener en mente que las alianzas estratégicas entre navieras no constituyen una fusión de
las empresas, sino que solo son la optimización de una red de transporte a través del agrupamiento
de la flota. Las navieras que entran en la alianza solo pueden compartir los espacios de carga en los
barcos y administrar en forma conjunta sus operaciones, pero no pueden cooperar en términos de
fijaciones de precios, ventas, marketing y servicio al cliente.
En la última reunión del sector celebrada en noviembre recién pasado, James Davis, uno de los
principales analistas de la industria, comentaba en su exposición: “No hay duda que la Red P3 se
convertirá en un jugador importante en la industria del transporte de contenedores, generando
múltiples beneficios para sus integrantes, y en especial el desarrollo de mejores ventajas
competitivas para cada uno de ellos, en una industria donde las empresas necesitan
imperiosamente buscar formas de diferenciarse ante sus clientes para ser más competitivas. Lo
anterior no debería contar con la oposición del regulador, por cuanto las alianzas estratégicas no
son algo nuevo en esta industria”.
Hs
-----
9
PREGUNTAS
a) El destacado analista James Davis, planteó en el párrafo que está al final del Caso, que uno de los
beneficios de la Red P3 será “... el desarrollo de mejores ventajas competitivas ...” para cada uno de los
integrantes de la alianza.
Desde el punto de vista de la teoría de la ventaja competitiva, ¿Bajo qué condiciones el analista tendrá razón?
¿Bajo qué condiciones no tendrá razón? Sea preciso en cada caso.
b) ¿Qué efectos se pueden prever que tendrá la alianza Red P3 sobre la estructura de la industria? Se le pide
señalar con precisión los 3 principales efectos que se pueden razonablemente prever.
-----
10
PREGUNTA N*5
Faris es una importante cadena de tiendas por departamento del país, que debe definir su inversión en publicidad
online (ej. banners en páginas web de empresas o buscadores) para los próximos 18 meses. Antes de tomar esta
decisión, el gerente de marketing de Faris, Richard Thumb, quiere saber cuál es el impacto que la publicidad
online tiene sobre las ventas online de productos de Faris. Para resolver esta duda, Thumb se reunió con dos
empresas de investigación de mercados, les explicó el problema que quieren estudiar, y les solicitó una propuesta
de metodología de investigación para responder a esta pregunta, teniendo como grupo objetivo personas con
acceso a Internet, que hayan realizado compras en el sitio web de Faris en los últimos 6 meses. A continuación se
presentan las propuestas de ambas empresas:
Empresa 1: ComRate
Ofrece monitorear las conductas de navegación de un panel de consumidores, conformado por personas que han
aceptado que se instale un software en sus computadores personales, que “observa” y monitorea la actividad
online que cada miembro del panel realiza. Como recompensa por participar, los panelistas reciben servicios
informáticos gratis, tales como memoria virtual para respaldar archivos, o softwares anti-virus. Así, ComRate
registrará durante 1 mes, para todos los miembros del panel, lo siguiente: (a) si vieron avisos de Faris en sitios
web de otras empresas (por ejemplo, en páginas de medios de prensa online, tales como El Mercurio o La
Tercera); (b) si vieron avisos de Faris en motores de búsqueda (por ejemplo, la página de Google); y (e) si vieron
avisos de Faris en los dos medios online mencionados anteriormente!l. Durante el mismo mes, ComRate registró
para cada miembro del panel, las compras online que realizaron en la página web de Faris. Para medir el impacto
de la publicidad online en las ventas online de Faris, simplemente se compara el nivel de compras online de Faris
(en dinero) entre quienes vieron publicidad online de Faris (en las 3 modalidades antes descritas), y quienes no lo
hicieron. Si las compras promedio de quienes sí vieron publicidad, son mayores (con significancia estadística) que
las compras de quienes no lo hicieron, entonces se concluye que la publicidad online de Faris se traduce en
mayores ventas online para esta empresa.
Empresa 2: E-Test
Propone obtener una muestra estadísticamente representativa de personas que navegan en Internet, e invitarlos a
participar en una tarea que consiste en que durante 15 minutos deben evaluar la calidad de distintas páginas web
según ciertos criterios que les fueron entregados con anterioridad. Para medir el impacto de la publicidad online
de Faris en sus ventas online, a los participantes se les asigna aleatoriamente y en igual número, a los siguientes 5
grupos experimentales:
Grupo 1: ve el aviso de Faris en el sitio web de otra empresa (ej. El Mercurio).
Grupo 2: ve el aviso de Faris en un buscador (ej. Google).
Grupo 3: ve el aviso de Faris en los dos medios anteriores,
Grupo 4: No ve avisos de Faris en los medios anteriores.
Grupo 5; No participa de la tarea encomendada (tarea de evaluar páginas web).
A continuación de la tarea asignada, se les pide a los participantes que completen una breve encuesta, en que una
de las preguntas es la siguiente: “En una escala de 1 a 7, ¿Qué tan probable es que usted compre por Internet
productos de la empresa Faris, durante los próximos 30 días?” Usando los resultados de esta pregunta como
variable dependiente, se mide el efecto de la publicidad online de Faris (en las tres modalidades descritas), en la
intención de compra de los participantes.
PREGUNTAS
a) Compare ambas propuestas, explicando brevemente las principales ventajas de cada una en relación a la otra y
a la luz del objetivo de “saber cuál es el impacto que la publicidad online tiene sobre las ventas online de
productos de Faris.”
b) Indique cuál de las dos propuestas recomendaría y por qué. Para responder esta pregunta suponga que el costo
para Faris de ambas propuestas es equivalente y que los resultados de ambos estudios estarían disponibles en el
mismo momento.
1 Se supone que quienes entraron al buscador o página web que contiene un aviso, vieron el aviso.
-----
11
PREGUNTA N' 6
BLIR es una empresa manufacturera nacional que últimamente ha tenido algunos problemas financieros. La
compañía tiene actualmente (en t = 0) activos que generan un único flujo de caja en un período más (t = 1) que es
incierto, por cuanto depende de la situación económica que se dé en el país. Según las estimaciones de la empresa,
dicho flujo puede tomar sólo dos valores: $100 millones en un escenario de alto crecimiento del PIB o $40
millones si el crecimiento del PIB es bajo. Cada uno de estos escenarios tiene una probabilidad de ocurrencia del
50%. Los activos de BLIR están parcialmente financiados con deuda bancaria, cuyo valor libro (valor de carátula)
es de $50 millones.
Los acreedores de la empresa (bancos) están evaluando la posibilidad de pedir la quiebra de BLIR, lo cual exige
una serie de formalidades de tipo legal que culminan finalmente en el nombramiento, por parte de los tribunales
de justicia, de un síndico que se encarga de liquidar (vender) en forma ordenada los activos de la empresa y de
pagar a los acreedores lo que se recaude en dicha liquidación. El proceso de quiebra tiene un costo esperado de $5
millones que deben ser pagados hoy (t = 0) por quien solicita la quiebra (acreedores de BLIR).
Suponiendo que:
+ No hay inflación ni impuestos.
+ La deuda de BLIR está pactada con una tasa de interés igual a cero y se debe pagar ent= 1.
+ Latasa de descuento relevante para evaluar cualquier proyecto es igual a cero.
+ Los activos y pasivos de la empresa no generan flujos de caja después del próximo período (no hay flujos
de caja ent=2,t=3, etc.).
A usted se le pide responder las preguntas que se le formulan a continuación:
Pregunta A
Si el valor de liquidación de los activos de BLIR fuera hoy (t = 0) igual a $52 millones, ¿le convendría a los
acreedores pedir la quiebra de la empresa? Justifique su respuesta mostrando los cálculos necesarios.
Suponga ahora, y esto es válido solamente para los efectos de responder las preguntas n? 2 y 3 que se formulan
más abajo, que los acreedores de BLIR acuerdan no solicitar la quiebra de la compañía ya que los ingenieros de la
empresa acaban de desarrollar una tecnología que le permitirá a BLIR, cualquiera sea el escenario económico que
finalmente prevalezca, aumentar el próximo período los flujos de caja netos generados por los activos en $10
millones, Para llevar a cabo este proyecto de implementación de la nueva tecnología, la empresa tendría que
invertir hoy (t = 0) la suma de $3 millones, que sería financiada integramente con aportes de capital de los
actuales accionistas de BLIR.
Pregunta B .
Desde un punto de vista financiero, ¿conviene a los actuales dueños de BLIR llevar a cabo el proyecto de
introducción de la nueva tecnología? Explique por qué exhibiendo todos los cálculos pertinentes.
Pregunta €
Suponga que la empresa fuera informada hoy (en t = 0) que las probabilidades de que ocurran los escenarios de
alto y bajo crecimiento del PIB cambian a 25% y 75% respectivamente y que los flujos de caja de los activos de
BLIR el próximo periodo (t = 1) para cada escenario fueran los mismos ($100 millones y $ 40 millones). El
Gerente de Finanzas de la empresa sostiene que: “dado que el proyecto que introduce la nueva tecnología genera
(en t = 1) flujos de caja de $10 millones en cualquier escenario de crecimiento del PIB, este cambio en las
probabilidades no tiene ningún impacto en la conclusión a la que Ud. llegó en la Pregunta B anterior.” ¿Está Ud.
de acuerdo con esta aseveración? Fundamente su respuesta.
-----


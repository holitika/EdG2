# Examen de grado · Examen-de-Grado-Administracion-Agosto-2026

Fuente: examen anterior

[pág. 1]
EXAMEN DE GRADO
 Ingeniería Comercial
 Mención: Administración de Empresas
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el alumno
 deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos hojas que sólo
 se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar hojas adicionales. No
 se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder no está permitido usar el reverso de las hojas ni una tercera hoja (sólo las 2 hojas recibidas).
4. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga que los
 datos que ha recibido están correctamente calculados y que no han sido tergiversados.
5. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la realidad de
 las empresas que allí se mencionan.
6. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados dichos
 supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
7. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la misma
 ponderación al momento de ser evaluadas.
8. Las preguntas de enunciado se podrán hacer solamente al Profesor José Rivera, Presidente de la Comisión de Examen de
 Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
9. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
 cumplimiento de esta norma es de absoluta responsabilidad del alumno.
10. Usted NO debe escribir su nombre en las hojas de respuesta.
11. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas condiciones, el
 Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
12. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala ni relojes inteligentes, los que deberán estar
 apagados y guardados en las mochilas adelante.
13. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el examen.
14. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han identificado
 con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar como “borrador”, esas
 hojas no se deben entregar con las respuestas.
Fecha : 7 de Agosto de 2026
Duración : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el Profesor José Rivera,
 en forma individual, entre las 9:30 y 9:50 hrs. (aprox.), y luego entre las 10:45 y 11:15 hrs. (aprox.).

[pág. 2]
PREGUNTA N°1
 Tres semanas después de finalizada la Copa Mundial de Fútbol 2026, el directorio
 de GlobalFan volvió a reunirse en su oficina regional de Santiago.
 Durante los últimos años, la empresa se había consolidado como uno de los
 principales distribuidores de merchandising deportivo oficial en América Latina.
 Su negocio combinaba una plataforma de e-commerce, presencia en
 marketplaces, tiendas físicas y acuerdos con cadenas de retail deportivo.
Comercializaba camisetas oficiales, ropa deportiva, balones, accesorios, artículos de colección y experiencias
asociadas a distintas selecciones nacionales.
El Mundial había sido el mejor período de su historia. Las ventas crecieron un 74% respecto del año anterior, el
tráfico al sitio web se cuadruplicó y la aplicación móvil registró más de 850.000 nuevas descargas. Las redes
sociales alcanzaron cifras récord de visualizaciones, seguidores e interacciones.
Sin embargo, al analizar los resultados con mayor detalle comenzaron a aparecer señales preocupantes. Mientras
los productos de las selecciones semifinalistas se agotaron antes del término del campeonato, la empresa mantenía
un importante exceso de inventario de equipos eliminados tempranamente. Asimismo, aunque el tráfico web
aumentó considerablemente, la tasa de conversión apenas mejoró y el abandono del carrito de compra alcanzó un
71%. Los analistas descubrieron que muchos usuarios utilizaban la plataforma para comparar precios y luego
compraban en marketplaces o tiendas físicas de especialistas en deportes.
El área de Business Intelligence de GlobalFan identificó cuatro grandes tipos de compradores: fanáticos históricos,
que compraban regularmente durante el año; consumidores emocionales, que solo adquirían productos de distintos
deportes durante grandes torneos internacionales (mundiales, copas regionales, amistosos, etc.); compradores
ocasionales, que buscaban regalos; y un nuevo segmento de consumidores jóvenes atraídos principalmente por
contenidos virales relacionados con el Mundial.
Las diferencias entre ellos eran importantes. Los fanáticos históricos presentaban la mayor tasa de recompra y el
mayor gasto promedio. Los consumidores emocionales compraban impulsados por el torneo, pero rara vez volvían.
Los jóvenes interactuaban intensamente con la marca en redes sociales, aunque compraban poco, mientras que los
compradores de regalos registraban tickets promedio elevados, pero prácticamente ninguna interacción digital.
Durante el mundial, GlobalFan implementó una estrategia comercial prácticamente uniforme para todos los
consumidores. La mayor parte de la inversión se concentró en campañas masivas en redes sociales, promociones
asociadas a los partidos más importantes y publicidad digital orientada principalmente a maximizar el tráfico a su
página web y las ventas. Una vez realizada la compra, todos los clientes recibían las mismas comunicaciones
promocionales, independientemente del producto adquirido, del canal utilizado o de su comportamiento previo.
Aunque la empresa disponía de información sobre navegación, historial de compra e interacción digital, esta se
utilizaba principalmente para medir el desempeño de las campañas y no para personalizar la experiencia del cliente.
Asimismo, las acciones comerciales prácticamente finalizaban con la compra, existiendo escasas iniciativas
orientadas a fomentar la recompra o fortalecer la relación con la marca.
La encuesta realizada a más de doce mil clientes tampoco entregó un diagnóstico concluyente. El 82% recordaba
espontáneamente la marca GlobalFan y más del 75% evaluaba positivamente la experiencia de compra. Sin
embargo, solo un 31% afirmaba que probablemente volvería a comprar durante los siguientes doce meses. Al
mismo tiempo, un 58% manifestó interés en recibir contenidos personalizados relacionados con su selección
favorita y un 46% valoraría pertenecer a una comunidad digital con beneficios exclusivos.
La reunión del directorio reflejó distintas interpretaciones de la información obtenida tras el Mundial. Después de
varias semanas de discusión, el gerente comercial presentó una propuesta estratégica para los próximos doce
meses.
 2

[pág. 3]
La propuesta contemplaba cuatro iniciativas principales. En primer lugar, liquidar mediante promociones
selectivas el inventario de productos asociados a selecciones eliminadas tempranamente, con el objetivo de reducir
el capital inmovilizado y generar recursos para financiar la estrategia comercial del año siguiente. En segundo
lugar, concentrar la mayor parte del presupuesto de marketing en campañas digitales dirigidas a los segmentos con
mayor probabilidad de compra inmediata y con resultados fácilmente medibles. En tercer lugar, desarrollar un
programa de fidelización para clientes registrados, pero focalizado exclusivamente en aquellos con mayor historial
de compra. Finalmente, reducir las campañas masivas de comunicación y privilegiar acciones comerciales
orientadas a incrementar la conversión y las ventas durante los meses posteriores al Mundial.
El gerente comercial argumentó que, una vez finalizado el torneo, la prioridad debía ser capturar la demanda
remanente, maximizar la rentabilidad de las inversiones en marketing y evitar destinar recursos a iniciativas cuyos
resultados fueran inciertos o difíciles de medir en el corto plazo.
Si bien los directores valoraron el esfuerzo por integrar distintas miradas, varios manifestaron dudas respecto de
la propuesta. Le piden a usted asesoría.
Se pide responder:
1. Desde el punto de vista de marketing, identifique y explique los cuatro criterios más importantes, que en este
 caso, debiera utilizar el directorio para evaluar la propuesta presentada por el gerente comercial. Explique por
 qué cada criterio es relevante en el contexto del caso y utilícelo para analizar críticamente la propuesta
 estratégica del gerente comercial.
2. El directorio decidió priorizar durante los próximos doce meses el segmento de consumidores jóvenes.
 Identifique y justifique los tres cambios más importantes que recomendaría introducir en la estrategia
 comercial que GlobalFan implementó para este segmento durante el Mundial. Fundamente su respuesta
 utilizando el concepto de Customer Journey (viaje del cliente).
 3

[pág. 4]
PREGUNTA N°2
Hoy es 31 de diciembre de 2025 y usted, que es un operador de centros de esquí en la zona central de Chile, acaba de ser
informado que se le ha adjudicado la concesión de uno de aquellos centros de la región metropolitana en una licitación
efectuada y asignada por la Dirección de Turismo, y que puede ser operada por usted a partir de mañana 01/01/2026. Los
costos de participar en la licitación fueron de US$500.000 (MUS$500). El centro de esquí cuya operación se le ha adjudicado,
funciona durante la temporada de invierno (1 de julio al 30 de septiembre de cada año), y permanece cerrado el resto del año.
La concesión le entregaría a usted la exclusividad de la operación del centro de esquí por los próximos tres años: 2026, 2027
y 2028, con la condición de mantener funcionando, de manera ininterrumpida, sus andariveles durante los tres meses de la
temporada de invierno. De cualquier modo, Ud. debe responder hoy mismo si aceptará la concesión que se le ha adjudicado.
El principal desembolso que usted tendría que enfrentar como nuevo operador del centro de esquí es el costo del petróleo
necesario para entregar energía a los andariveles que deben operar de manera ininterrumpida durante los tres meses de la
temporada de invierno. Para asegurarse del cumplimiento de esta condición, el contrato incorpora una cláusula que obliga al
operador a comprar con anticipación todo el petróleo necesario para gestionar los andariveles. La cláusula establece que 6
meses antes de comenzar la temporada de invierno del primer año de operación del centro de esquí, es decir, el 01/01/2026,
el operador debe firmar con ENAP un contrato de abastecimiento de petróleo que asegure su disponibilidad para cada uno de
los 3 años que dura la concesión. En este momento (01/01/2026) el precio “spot” o “contado vigente para el día” del petróleo
se encuentra en un valor de US$118 por barril. Sin embargo, es posible firmar hoy, 01/01/26 un contrato con ENAP para el
petróleo que espera consumir en los andariveles durante los próximos 3 años, a los siguientes precios:
• Precio por barril a pagar el 31/12/2026 si usted opera durante el año 2026: US$120
• Precio por barril a pagar el 31/12/2027 si usted opera durante el año 2027: US$125
• Precio por barril a pagar el 31/12/2028 si usted opera durante el año 2028: US$130
La siguiente es la información que corresponde a todos los ingresos y costos anuales esperados de operación del centro de
esquí (todos en US$) para cada uno de los tres años futuros:
 Ingresos por Ventas US$ 12.000.000
 Costo de Ventas US$ [100.000 barriles x 𝑃𝑟𝑒𝑐𝑖𝑜𝑛 𝑐𝑜𝑛𝑡𝑟𝑎𝑡𝑎𝑑𝑜 𝑐𝑜𝑛 𝐸𝑁𝐴𝑃]
 Gastos de Operación (excluyendo depreciación) US$ 500.000
 Depreciación (anual) US$ 3.500.000
 Nota 1: 𝑃𝑟𝑒𝑐𝑖𝑜𝑛 = Precio a pagar por el barril de petróleo a fines del año n (n =1, 2, 3)
Como se desprende de la información entregada previamente, el costo de venta está directamente relacionado (indexado) al
precio del petróleo fijado en el contrato con ENAP siendo el único componente que cambia año a año.
Información complementaria (supuestos):
• Suponga que todos los componentes del estado de resultados anual del centro de esquí, con la sola excepción de su gasto
 por depreciación, son flujos de caja que se producen el último día de cada uno de los años de operación del centro de esquí.
• Suponga que la tasa de Costo de Capital Promedio Ponderado (CCPP o WACC) relevante para la operación de este centro
 de esquí es de un 8% anual (en US$) y constante para los 3 años de la concesión.
• No hay valor residual alguno como resultado de la operación una vez que ella termina a fines del año 3.
• No hay impuestos ni inflación y en el desarrollo de sus respuestas use dos decimales y responda en US$.
Se pide responder (en su respuesta a cada pregunta, presente de manera clara y detallada su desarrollo):
 a) Dada la información anterior, determine el valor que hoy (01/01/2026) tendría este proyecto para Ud. como operador
 del centro de esquí e indique si aceptaría o rechazaría la concesión.
 4

[pág. 5]
b) Releyendo el contrato de la concesión, usted encuentra que éste incluye una cláusula que le permitiría retrasar el
comienzo de la operación por un año. Bajo esta cláusula, usted podría no operar el centro de esquí el año 1 (año 2026)
y hacerlo sólo los años 2027 y 2028 firmando, el 01/01/2027, un contrato de abastecimiento de petróleo con ENAP, para
estos años de operación. En el caso de que usted decidiera hacer uso de esta opción de “retraso”, dicha decisión debiera
ser avisada 6 meses antes del inicio de la temporada de invierno del primer año de operaciones, es decir el 01/01/2026.
Si usted como operador del centro de esquí decidiera hacer uso de la opción de retraso, el mismo día 01/01/2026 tendría
que pagar una multa de US$ 1,5 millones, y la empresa que tenía la concesión anteriormente continuaría operando el
centro de esquí por un año más. En este momento (01/01/2026), su expectativa como operador del centro es que al inicio
del año 2027 (01/01/27), fecha en la que en el caso de retraso se tendría que firmar el contrato con ENAP y por lo tanto
fijar el precio de compra del petróleo de los 2 años restantes de operación, es que el precio del petróleo haya bajado a
US$80 el barril y que los precios de un barril de petróleo a pagar el 31 de diciembre de los años 2027 y 2028 sean de
US$82 y US$ 85 respectivamente:
Dada su expectativa del precio futuro del petróleo de US$80 el barril para el 01/01/2027. ¿Cuál es el valor que para Ud.
tendría la opción de “retraso” pagando hoy, 01/01/2026, la multa y así comenzar a operar el centro de esquí a partir del
01/01/2027?
c) Un reporte del mercado del petróleo conocido el día de hoy (01/01/2026), ha estimado que hay solo un 50% de
probabilidad de que el 01/01/2027 (fecha en la que se debería firmar el contrato con ENAP por el petróleo de los 2 años
restantes de operación), el precio “spot” del barril de petróleo ese día sea de US$80. El otro escenario (también con 50%
de probabilidad) es que el precio “spot” del barril de petróleo ese día (01/01/2027) no baje y siga siendo de US$118.
Dado lo anterior, los precios esperados por barril de petróleo al 31 de diciembre de cada uno de los próximos dos años
(2027 y 2028) son los siguientes:
 Si al 01/01/27 el precio "spot" Si al 01/01/27 el precio "spot"
 del barril fuese de US$80 del barril fuese de US$118
 Precio a pagar por el barril el
 82 125
 31/12/2027 (US$)
 Precio a pagar por el barril el
 85 130
 31/12/2028 (US$)
Hoy 01/01/2026, momento en que se iniciaría el período de la concesión y ya conocida la información anterior, a su jefe
se le ha ocurrido proponer y evaluar un nuevo contrato en el que además de considerar la opción de “retrasar” en un
año el inicio de la concesión (opción planteada en la pregunta anterior), se incluya la opción de “abandonar” la
concesión al inicio del día 01/01/2027, una vez sabido si el precio de ese día es de US80 o US$118 el barril, y por lo
tanto en caso de que Ud. así lo decida, no operar el centro de esquí durante los 2 años restantes (2027 y 2028)
Esta opción de abandonar la concesión no está en las cláusulas actuales del contrato que se le ha ofrecido, pero su jefe
quiere negociar con la Dirección de Turismo, dueña de los centros de esquí, para que la opción de abandono sea incluida.
El costo que pudiera tener esta opción sería adicional a la multa ya establecida por retrasar en un año el comienzo de la
concesión. Por supuesto, su jefe sabe que, en este momento, la única posibilidad que él tendría respecto de los años
2027 y 2028 sería operar el centro de esquí, y por ello quisiera negociar con la Dirección de Turismo, esa opción de
abandonar el proyecto el día 01/01/27.
¿Cuál es el monto máximo que el operador del centro de esquí debiera estar dispuesto a pagar hoy 01/01/26 por incluir
la cláusula de abandono futura? (por “monto máximo” entienda ese monto en US$ que en caso de pagarlo su riqueza es
la misma que si no lo paga) En su respuesta suponga que abandonar la concesión al término del año 1 sin tener un
acuerdo explícito con la Dirección de Turismo sería prohibitivamente caro (por ejemplo, costos legales ante demandas,
acceso denegado a futuras licitaciones, etc.) y que la decisión de postergar el inicio de la concesión no afectaría el valor
de la opción de abandonar.
 5

[pág. 6]
PREGUNTA N°3
Fundada por Marcos Galperin en 1999, Mercado Libre no es solo un Marketplace, sino una plataforma donde el
comercio, los pagos, el crédito y la logística se refuerzan mutuamente en un círculo que se ha vuelto cada vez más
difícil de romper desde afuera. “Poner la transacción del cliente y su experiencia en el centro del negocio explica
el éxito en el desarrollo de la empresa” declaraba su CEO en una de sus últimas entrevistas. Por ejemplo, Mercado
Pago, el brazo financiero de la compañía, nació como solución a un problema concreto: los compradores no
confiaban en pagar a vendedores desconocidos, y los vendedores no confiaban en recibir el pago. La solución fue
crear un intermediario que garantizara ambos lados. Con el tiempo, ese intermediario se convirtió en un ecosistema
financiero completo.
En la actualidad, la compañía cuenta con más de 100 millones de compradores anuales, con ingresos netos de
21.000 millones de dólares, creciendo un 38% interanual. El valor de mercado de sus acciones ha crecido de
manera sostenida con retornos atractivos para los inversionistas.
La construcción del ecosistema digital
Uno de los mayores logros de la gestión del CEO que acaba de partir de la compañía, fue el desarrollo de las
principales unidades de negocio de Mercado Libre en el mercado chileno. En 2015 se lanza Mercado Pago, la
plataforma de servicios financieros digitales que posteriormente se transformó en uno de los pilares del ecosistema
de la compañía. Un año después se implementó Mercado Envíos, fortaleciendo la capacidad logística para reducir
los tiempos de entrega y mejorar la experiencia de compra de los usuarios. Estos dos negocios lograron diferenciar
a Mercado Libre de un Marketplace tradicional.
La estrategia consistió en integrar con inteligencia y tecnología, soluciones de pago, logística y financiamiento
dentro de una misma plataforma, simplificando el proceso de compra y venta. Lo anterior, fue acompañado de
inversiones en Chile para fortalecer la infraestructura logística y tecnológica, más la contratación de personal con
altas competencias. Todo lo anterior, separó y diferenció a Mercado Libre de sus competidores, quienes no han
logrado todavía replicar su estrategia en toda la dimensión que ella tiene.
Uno de los aspectos más destacados de Mercado Libre ha sido su enfoque en la innovación promoviendo una
cultura orientada a experimentar, aprender rápidamente de los errores y mantener al cliente como eje central de las
decisiones. Se desarrollaron equipos multidisciplinarios capaces de responder al crecimiento acelerado que
experimentó la empresa durante los últimos años. Además, la incorporación de nuevas tecnologías unido a
eficiencias logísticas, contribuyeron a ampliar la base de clientes al permitir al segmento de pequeñas y medianas
empresas acceder al comercio electrónico como un nuevo canal de comercialización para ellas. Así mismo, la
incorporación de tecnologías permitió a Mercado Libre mejorar la calidad en el servicio de entregas. En efecto,
mas del 95% de los envíos se realizan dentro de la red gestionada por la propia empresa, y el 49% se entregaron
en el mismo día o al día siguiente.
Para Mercado Libre, la inteligencia artificial no opera como una capa decorativa sobre el producto, sino que está
integrada en las decisiones que determinan el funcionamiento de la empresa, la integración entre negocios y el
logro de eficiencias en sus procesos. En otras palabras, no se trata de usar la IA para recabar solo información,
sino de aplicarla para el desarrollo del negocio de manera de hacerlo más sólido y con capacidad de generar un
mejor servicio a los clientes, tanto compradores como empresas que venden sus productos. Por ejemplo, los
modelos de calificación crediticia con que cuenta Mercado Libre permiten prestar dinero a personas y pequeñas
empresas a las que la banca tradicional no llega, con tasas de morosidad manejables a pesar de operar en mercados
volátiles, lo que significa que la IA no solo aumenta el volumen de operación (en este caso, los créditos otorgados
por Mercado Libre, los cuales crecieron en un 74% en 2025 en relación al año anterior), sino también, hace que el
 6

[pág. 7]
riesgo sea más calculable y por lo tanto más controlable. Otro ejemplo, es la operación directa de la plataforma.
El Asistente de IA de Mercado Pago, lanzado en octubre de 2025, gestionó más de 9 millones de conversaciones
en el cuarto trimestre de ese año, con más del 87% de ellas resueltas sin intervención humana. Así mismo, en
comercio, herramientas de IA facilitan devoluciones y recomiendan tallas a los consumidores, generando una
mejor experiencia para el cliente.
El modelo de Mercado Libre es poderoso, pero no está exento de presiones. La primera es la exposición que tiene
en países con alta volatilidad cambiaría, inflación y ciclos políticos convulsionados como es el caso de Brasil,
México, Argentina y Chile. La segunda es la competencia, Amazon lleva años intentando consolidar su posición
en la región, y plataformas chinas como Shein y Temu han ingresado con agresividad. Ninguno de estos
competidores ha logrado replicar el ecosistema integrado de comercio, pagos, logística y crédito, que Mercado
Libre ha construido durante dos décadas y la posición de la empresa sigue estando a distancia de sus competidores.
La tercera presión es regulatoria, a medida que Mercado Pago se convierte en el banco digital más grande de
América Latina, la atención de los reguladores financieros de Brasil, México, Chile y Argentina se intensifica.
Próximos desafíos para Mercado Libre
La empresa cerró 2025 con muy buenos resultados, y sigue invirtiendo para expandir su red logística, profundizar
los servicios financieros, incluyendo el lanzamiento de la tarjeta de crédito en Argentina en 2025, y en usar la IA
como palanca para potenciar y escalar sus negocios sin aumentar proporcionalmente los costos operativos. En el
caso de Chile, el desarrollo de servicios financieros digitales seguirá siendo un componente clave dentro de la
estrategia de la empresa, especialmente en una región donde todavía existe un amplio margen para avanzar en
inclusión financiera.
Aunque sin lugar a duda el principal desafío de la empresa será mantener la efectividad mostrada en la gestión de
los últimos años, en donde se desarrolló el negocio, se eficientaron e integraron procesos y los negocios mismos,
se construyó el ecosistema integrado comercial, y se redujeron los riesgos competitivos globales de la estrategia.
La compañía construyó una estructura consolidada sobre la cual se podrá continuar creciendo. Más allá de los
resultados financieros, el principal legado del recientemente renunciado CEO, como ya dijimos, radica en haber
construido un ecosistema integrado de negocio, visión que le permitió a la empresa fortalecer su liderazgo en Chile
y consolidarse como uno de los principales protagonistas de la transformación digital del comercio
latinoamericano.
Se pide responder:
a) ¿Constituye la IA y su aplicación una fuente de Ventaja Competitiva Sostenible? ¿Por qué Sí o por qué No?
b) ¿Qué tipo de estrategia de crecimiento explica la evolución y el desarrollo de Mercado Libre en América
 Latina? Justifique su respuesta.
 7

[pág. 8]
PREGUNTA N°4
Era una fría mañana de mediados de 2026, el comité de dirección del Banco de la Plaza—el mayor banco del país— llevaba ya
un buen rato reunido. Sentada a la mesa, Daniela Vergara, gerente de Personas y Cultura, seguía la discusión con una mezcla de
entusiasmo y vértigo. El directorio lo quería todo a la vez: más eficiencia, crecimiento y, sobre todo, aumentar la disposición a
pagar de los clientes clave y el valor que les genera la empresa. La ambición era tan clara como ambigua —convertir a la
organización en un banco “AI-first” de manera que la implementación de la inteligencia artificial le permitiera ser una
organización más eficiente y, especialmente, aumentar el valor de los negocios realizados. A Daniela, por su parte, le
correspondería desarrollar un plan de gestión de personas para lograr la completa implementación y generación de valor de la IA
en el banco.
“Quiero que cada colaborador trabaje con IA y que el cliente lo note. Nuestro norte es aumentar nuestra participación de
mercado, atendiendo a los diferentes segmentos de nuestra cartera de clientes. Los necesitamos a todos. Necesitamos seguir
buscando eficiencias y buscar con mucha intensidad ser un banco más cercano, más inteligente, que preste una asesoría de alto
valor a nuestros clientes más valiosos.” — Gerente general
En sus Business·Center —sucursales pensadas para orientar más que para transar— una ejecutiva del banco podía pasar una hora
ayudando a una familia o a un empresario a ordenar sus finanzas, porque su foco era asesorar de manera personalizada antes que
de cerrar una venta. Ese estilo cercano y paciente era lo que principalmente caracterizaba al Banco de la Plaza.
El banco terminó 2024 como líder en la industria, con una participación de mercado en colocaciones y depósitos cercana al 17%,
y un ROE en torno al 26%. Además, durante ese año realizó una fuerte inversión en su personal: jornada reducida a 40 horas,
remuneraciones por sobre la media del mercado y una formación intensiva para sus equipos.
En paralelo, fintechs como Tenpo, Nubank o Mercado Pago presionaban por entrar a competir en la industria con una promesa
distinta: costo mínimo, sin red física y experiencia 100% digital. Como toda institución de su tamaño, el Banco de la Plaza atendía
a clientes muy distintos, desde quienes solo operaban por la app hasta grandes patrimonios y empresas. El área comercial los
agrupaba en tres segmentos, como lo muestran los datos al cierre de 2025:
 Costo de Servir al Rotación # de
 % de clientes (en % del resultado
 Segmento (canal predominante) segmento (considere anual de Productos
 número) final del Banco
 el promedio en 100) clientes por cliente
 Transaccional masivo (app / 100% digital) 58% 14% 40 24% 1,6
 Rentas medias y Pyme (mixto) 31% 33% 125 11% 3,4
 Patrimonial y Empresas (asesoría / Business Center) 11% 53% 350 4% 6,1
 Cifras ilustrativas de la estructura de clientes al cierre de 2025. El segmento transaccional masivo es el de mayor crecimiento en N° de clientes.
En el segmento transaccional masivo, la IA permitía hacer más eficientes muchos procesos rutinarios —verificaciones, consultas
frecuentes, tareas de back-office—, los que representaban una parte importante de la operación diaria del banco. En las labores
de asesoría orientada al segmento patrimonial y empresas, en cambio, la IA funcionaba como apoyo: sugería alertas de riesgo y
productos a la medida, pero era el ejecutivo quien debía interpretar esas señales y ajustarlas a cada cliente, pues dos familias o
empresas con perfiles casi idénticos podían necesitar consejos distintos. Para lo anterior, el Banco de la Plaza se había propuesto
una transformación “data y AI-first” —acceso a la IA para todo su personal, miles de “agentes” de IA automatizando tareas, y
formación obligatoria en IA—, y utilización en todas las actividades clave, sobre todo comerciales, del banco. Se pretendía,
además, aplicar estas herramientas con especial énfasis a los clientes clave del banco de modo de optimizar la generación de valor
para los próximos años.
Sobre esa base, el gerente de finanzas, Andrés Lecaros, expuso a la mesa un plan que había preparado con una consultora
internacional: lanzar una Academia Digital corporativa con programas obligatorios de reskilling (preparar a las personas para
nuevas funciones) y upskilling (mejorar el desempeño en la función actual) en datos e IA para toda la dotación; ajustar la dotación
donde la automatización volviera redundantes ciertos roles; y comprar en el mercado el talento escaso que el banco no tenía.
 “La matemática es simple: la IA permite hacer lo mismo con menos. Nos permite altos grados de eficiencia. Formemos
 a quien se pueda reconvertir, contratemos a los mejores para lo que no tenemos y ajustemos donde sobra. No podemos
 formar a todos en todo.” — Andrés Lecaros, gerente de finanzas.
 8

[pág. 9]
Varios en la mesa asentían. “El que no se suba ahora competirá en desventaja; esto no es un lujo, es supervivencia”, había
advertido un director, y la consultora respaldaba el plan con benchmarks de “mejores prácticas” del sector.
Daniela escuchaba, y anticipándose al giro digital que se pretendía para la empresa, ya en 2025 había corrido —a pequeña escala—
un piloto del mismo tipo de formación que Lecaros quería ahora masificar. En ese momento, Daniela interrumpió y señaló los
resultados que había obtenido: “Al comienzo fue un pequeño orgullo interno: se inscribió más gente de la esperada y las salas se
llenaron. Seis meses después, los resultados contaban una historia más matizada”, lo que se muestra en la siguiente tabla:
 Piloto de formación digital 2025 (red de sucursales) Resultado
 Finalización de los programas de formación 94% de participantes
 Satisfacción de los participantes (índice, −100 a +100) +91
 Conocimientos en la prueba posterior (vs. medición inicial) 83% (desde 46%)
 Uso efectivo de las nuevas herramientas con clientes (a 6 meses) 22%
 Indicadores de asesoría (productos por cliente, retención): sucursales piloto vs. resto sin diferencia
Había, además, algo que Daniela no perdía de vista: la manera en que el banco gestionaba a su gente seguía patrones muy
asentados en la organización. A los ejecutivos se los evaluaba y reconocía, sobre todo, por la colocación de productos del trimestre.
Por su parte, la agenda de las jefaturas estaba dominada por esas mismas metas comerciales. Además, en los segmentos de cargos
más expuestos a la automatización, una reciente ola de ajustes de dotación había dejado inquietud sobre el futuro de ciertos cargos.
Una reciente encuesta interna que media compromiso del personal con la empresa lo reflejaba:
 Encuesta interna — resultados de los segmentos más expuestos a la automatización % de acuerdo
 Me siento seguro respecto a la estabilidad futura del empleo en este banco 38%
 Tengo alta autonomía para decidir en mi puesto de trabajo 27%
 Recibo apoyo de la empresa y mi jefatura para innovar en nuevas formas de hacer las tareas mediante uso de IA 36%
 El compromiso promedio del banco se mantenía alto; las cifras del cuadro corresponden a los segmentos más expuestos a la automatización.
La propuesta de Lecaros era rápida, medible y fácil de defender, pero el comité estaba dividido y Daniela tenía pocas semanas
para volver con una respuesta: respaldar el plan de Lecaros, ajustarlo o proponer un camino distinto, en un entorno que cambiaba
cada trimestre.
Se pide responder:
1. El banco se ha propuesto ser “AI-first” para potenciar el valor en su negocio. (a) A partir de la información del caso, determine
en dónde se concentra el valor generado por el banco y, en función de ello, identifique dos capacidades clave que su personal
necesita para agregar valor allí donde resulte más beneficioso para el banco, y explique cómo cada capacidad se traduce en valor
para el banco. (b) Explique si el plan de Andrés Lecaros es adecuado para que las personas lleguen a aprender y a utilizar esas
capacidades.
2. Desde el punto de vista del impacto estratégico que la capacitación debe tener para alcanzar los objetivos del banco, ¿fue
exitoso el plan piloto de Daniela? Fundamente su respuesta.
3. Al momento del lanzamiento del proyecto AI-first, salvo el piloto de capacitación impulsado por la gerente de personas, el
banco no había modificado ninguna de sus prácticas de gestión de personas. Identifique tres prácticas clave de gestión de personas
del banco, distintas a los esfuerzos de capacitación ya implementados, que debiera revisar en relación con su ambición “AI-first”
y con el logro de los objetivos de negocio más importantes del banco. Para cada una de las prácticas proponga cómo debería
modificarse y explique cómo, estas prácticas en conjunto se refuerzan entre sí.
 9

[pág. 10]
PREGUNTA N°5
Los modelos de suscripción se han expandido con fuerza, desde el streaming hacia las aplicaciones de movilidad
y delivery. Uber, que en Chile cuenta con más de 3 millones de usuarios activos, evalúa lanzar un plan de
suscripción mensual para viajes urbanos: a cambio de un monto fijo mensual, el suscriptor accede a beneficios en
la tarifa de los viajes que realiza durante el mes —descuentos porcentuales o una tarifa fija por viaje dentro de la
ciudad— además de otros beneficios incluidos. Este servicio no existe actualmente en el mercado chileno.
Para diseñar el plan y fijar su valor mensual, dos gerentes plantean posiciones distintas:
 Gerente de Datos: «No necesitamos hacer estudios con encuestados. Uber registra millones de viajes reales:
 sabemos cuánto viaja cada usuario, cuánto paga, a qué hora y por qué zonas. Con esa información de
 comportamiento real podemos estimar directamente cómo respondería cada usuario al nuevo servicio
 propuesto».
 Gerente de Marketing: «Si vamos a preguntar, hagámoslo simple y directamente: focus groups y luego una
 encuesta a una muestra representativa de nuestros usuarios activos, donde cada persona indique cuánto valora
 cada atributo del servicio y cuánto estaría dispuesta a pagar por el plan».
Finalmente, y pese a las propuestas de sus gerentes, el Gerente General optó por encargar un estudio de análisis
conjunto (conjoint) basado en la evaluación de perfiles completos (planes completos del servicio) con una muestra
representativa de 600 usuarios actuales de Uber en Santiago. La Tabla N°1 presenta los atributos y niveles por
cada atributo.
Tabla N°1. Atributos y niveles
 Atributo Niveles
 Precio suscripción mensual $5.000 / $8.000 / $12.000
 Beneficio en la tarifa por viaje 10% de descuento / 20% de descuento / Tarifa fija por viaje en la ciudad
 N° de viajes al mes con beneficio 20 viajes al mes con beneficio / N° Ilimitado de viajes al mes con beneficio
 Envíos de Uber Eats sin costo No incluye envíos sin costo / Sí incluye envíos sin costo
Con la información de uso en la aplicación, Uber clasificó previamente a los encuestados en dos segmentos:
Segmento 1 de «usuarios intensivos» (30% de los usuarios, promedio de 15 viajes/mes) y Segmento 2, de
«usuarios ocasionales» (70% de los usuarios, promedio de 3 viajes/mes). La Tabla N°2 presenta, para cada
segmento, las utilidades parciales estimadas y la utilidad base.
 10

[pág. 11]
Tabla N°2. Utilidades parciales por segmento
 Variable Intensivos (30%) Ocasionales (70%)
 Utilidad base 3,0 2,5
 Precio Suscripción mensual de $8.000 (vs. base $5.000) −0,6 −1,5
 Precio Suscripción mensual de $12.000 (vs. base $5.000) −1,4 −3,5
 Beneficio 20% descuento (vs. base 10% descuento) 0,6 0,8
 Beneficio tarifa fija por viaje (vs. base 10% descuento) 1,6 1,0
 Número de viajes al mes con beneficio: Ilimitado (vs. base 20) 1,0 0,1
 Uber Eats: Incluye envíos sin costo (vs. base no incluye) 0,2 0,6
Nota: todos los coeficientes son estadísticamente significativos al 5%, salvo el coeficiente de «Ilimitado» en
el segmento ocasional. Los datos presentados en esta tabla son ficticios. Uso académico.
Se pide responder:
a) Justifique metodológicamente por qué el Gerente General optó por un análisis conjunto de perfiles completos
 en lugar de las propuestas del Gerente de Datos y del Gerente de Marketing. Desarrolle los argumentos más
 significativos frente a cada propuesta.
b) Suponga que Uber evalúa dos planes alternativos:
 Plan A: Precio suscripción $8.000; precio fijo por viaje; número de viajes ilimitados; sin envíos de
 Uber Eats.
 Plan B: Precio suscripción $5.000; 20% de descuento por viaje; tope de 20 viajes; con envíos de Uber
 Eats incluidos.
 Suponga además que la opción “no suscribirse” tiene una utilidad igual a 3.0 para el segmento «usuarios
 intensivos» y de 3.8 para el segmento «usuarios ocasionales». Estas utilidades representan el atractivo de no
 adoptar ninguno de los planes.
 Si el objetivo de Uber fuese maximizar ingresos por la suscripción, ¿usted le recomendaría ofrecer sólo el
 Plan A, sólo el Plan B ó ambos planes? Explique y fundamente su decisión.
c) Independientemente de los planes mencionados en la pregunta anterior, ¿cuánto más estaría dispuesto a pagar
 un usuario promedio de cada segmento (entiéndase, el usuario representativo de cada segmento) por tener
 tarifa fija por viaje, en lugar del beneficio de 20% de descuento? Explique.
 11

[pág. 12]
PREGUNTA N°6
El fondo de inversión ELE5, administrado por los hermanos Escarriaga, está especializado en plantas fotovoltaicas
que generan electricidad a través de paneles solares y sólo tiene inversiones en dos sociedades dedicadas al rubro:
Catalina S.A. ubicada en La Ligua, y Santa Águeda S.A., localizada en el desierto de Atacama, cerca de la ciudad
de María Elena. El fondo ELE5 posee el 100% de las acciones de cada una de estas sociedades.
A continuación, se presentan algunos antecedentes financieros de las dos empresas antes mencionadas al 31 de
diciembre de 2025 (t = 0):
Catalina S.A.
Su único activo son paneles solares que generan energía eléctrica e inyectan toda su producción al Sistema
Eléctrico Nacional en un nodo (punto de inyección) en el que no hay congestión y vende toda su energía en el
mercado (spot)1 durante las horas de sol. Se espera que este activo genere flujos de caja netos perpetuos, producto
de la venta de energía, de USD 500.000 anuales. El problema actual de Catalina es su nivel de deuda. Al cabo de
un año deberá pagar el total de una única deuda con el Banco UITA por USD 2.120.000. La empresa ha tratado de
renegociar esta deuda consiguiendo más plazo, y viendo otras alternativas de financiamiento, pero no lo ha logrado.
El activo de Catalina fue entregado como garantía al banco y no se puede vender sin el consentimiento del banco,
de manera que si Catalina no puede pagar su deuda dentro de un año deberá declararse en quiebra y el fondo ELE5
tendrá que entregar la empresa a sus acreedores, sin recuperar nada.
Santa Águeda S.A.
Su único activo son paneles solares que generan energía que es almacenada en baterías (sistema BESS). La
empresa tiene un contrato para vender la energía almacenada a un precio fijo (llamado PPA) con un riesgo
virtualmente nulo en sus flujos, es decir, suponga que los flujos son perfectamente predecibles. El contrato le
permite a Santa Águeda obtener un flujo de caja neto perpetuo de USD 1.000.000 por año. La empresa no tiene
deudas de ningún tipo.
Información adicional
La tasa de descuento para los flujos de caja de los activos del sector eléctrico, dado su riesgo asociado al ciclo
económico, es de 10% anual en dólares. La tasa de descuento de la deuda en dólares es de 6% anual en el caso de
empresas sin problemas de solvencia. La tasa libre de riesgo perpetua en dólares es un 5% anual. Para simplificar,
suponga que los flujos de caja recibidos o pagados por las empresas del fondo se producen al término de cada año,
y que no hay inflación ni impuestos.
a) Determine el valor económico que tendrían hoy (t = 0) los activos y el patrimonio del fondo de inversión ELE5.
Fundamente su respuesta de manera conceptual y numérica.
b) Dada la alta variabilidad intra-diaria en el precio de la energía que Catalina vende actualmente en el mercado
spot, la empresa comenzó a estudiar un proyecto de baterías, que le permitiría almacenar una parte de la energía
generada, en vez de venderla en momentos del día en que el precio de venta es bajo. Con las baterías, la empresa
inyectaría la energía al sistema eléctrico nacional durante las primeras horas de la tarde-noche, cuando el precio
de la energía eléctrica es significativamente mayor. Este proyecto requiere que la empresa haga hoy (t = 0) una
inversión de USD 5.000.000 que le permitiría a Catalina generar flujos de caja netos perpetuos incrementales de
1
 El mercado spot de energía consiste en vender la energía que se genere en el instante t al precio de mercado que esté
vigente en el mismo instante t. Este mercado también se denomina mercado al contado.
 12

[pág. 13]
USD 600.000 mil al año, recibiendo el primero de ellos en un año más (t = 1). Sin embargo, como Catalina tenía
problemas financieros, no había logrado conseguir financiamiento para este nuevo proyecto.
Los hermanos Escarriaga, administradores del fondo ELE5, están viendo qué hacer para no perder la inversión
que el fondo tiene en Catalina. Una de las alternativas que ellos estudian sería endeudar a Santa Águeda en montos
exactamente suficientes como para que ésta le haga un aporte de capital a Catalina, con tal de que pueda prepagar
su deuda (que vence al cabo de un año) y, además, financiar el proyecto de baterías de Catalina, si es que resulta
rentable. Los Escarriaga están conscientes de que, si llevan a cabo el aporte de capital a Catalina, los flujos de caja
de Santa Águeda dejarán de ser libres de riesgo, ya que dentro de sus activos estarán las acciones de Catalina. Sin
embargo, el aporte de capital a Catalina, le permitiría a esta última prepagar su deuda desembolsando hoy (t = 0)
la suma de USD 1.950.000 en vez de los USD 2.120.000 que tendría que pagar un año después.
Los Escarriaga han conversado con diversos acreedores potenciales que están dispuestos a prestarle a Santa
Águeda lo necesario, con una deuda en USD que sería perpetua, a una tasa de interés de 6% anual.
¿Le conviene a los dueños del fondo de inversión ELE5 llevar a cabo la operación de hacer un aporte de capital
de USD 6.950.000 a Catalina para prepagar la deuda y permitir que la empresa lleve a cabo el proyecto de baterías?
Justifique su respuesta desde un punto de vista financiero mostrando los cálculos necesarios.
c) Suponga que los dueños del fondo de inversión aprueban llevar a cabo la operación señalada en la letra b
anterior. En concreto, Santa Águeda se endeuda en USD 6.950.000 y hace un aporte de capital por este mismo
monto a Catalina. Esta última empresa, prepaga la deuda bancaria e invierte los USD 5.000.000 necesarios para
llevar a cabo la inversión requerida para el proyecto de baterías. Suponiendo que todas estas operaciones se llevan
a cabo hoy (t = 0), construya el balance económico del fondo de inversión mostrando los activos, deuda y
patrimonio que tendrán las sociedades Catalina y Santa Águeda, inmediatamente después de las operaciones aquí
mencionadas. Fundamente su respuesta mostrando los cálculos necesarios.
 1.
 13

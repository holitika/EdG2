# Examen de grado · agosto-2016

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


s PONTIFICIA UNIVERSIDAD CATÓLICA DE CHILE
ESCUELA DE ADMINISTRACIÓN
(SENASA
us
RAS
EXAMEN DE GRADO
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
que los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
realidad de las empresas que allí se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
, 6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente al Profesor Ignacio Rodríguez, Presidente de la Comisión
de Examen de Grado, quien recorrerá Jas salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
- cumplimiento de esta norma es de absoluta responsabilidad del alumno.
. 9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
condiciones, el Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un (a) alumno (a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala, los que deberán estar apagados y no
deberán mantenerse sobre el escritorio durante el examen.
12. Cada alumno (a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han :
identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
como “borrados”, 'esas hojas no se deben entregar con las respuestas, .
Fecha : 5 de agosto de 2016
Duración : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el Profesor
Ignacio Rodríguez, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 y
11:00 hrs. (aprox.).
-----
-----
2
: PREGUNTA N' 1
Goodyear, empresa líder en la producción y comercialización de neumáticos a nivel mundial, atiende a una
amplia variedad de clientes que requieren de distintos tipos de neumáticos. Entre ellos podemos destacar la
industria automotriz, de transporte (pasajeros y carga), de maquinarias (construcción, minería, forestal, eto.) y
la industria aérea. En el caso de la industria automotriz, Goodyear cuenta con dos tipos de clientes: las empresas
productoras de automóviles y los consumidores finales que requieren de repuestos para cambiar los neumáticos
originales producto del desgaste por el uso.
En nuestro país, Goodyear sólo atiende el mercado automotriz en lo que se refiere a repuestos de neumáticos.
Durante todos estos años, Goodyear ha mantenido una posición de liderazgo indiscutido en el mercado chileno,
proceso en el cual ha sido clave su potente red de comercialización y distribución exclusiva, con más de 100
distribuidores independientes en todo el país, donde los usuarios acceden a los mejores neumáticos y reciben
el servicio profesional y especializado que requieren para distintas necesidades relacionadas con el auto. :
Los distribuidores Goodyear ofrecen sólo las marcas de neumáticos Goodyear y no cuentan con territorios
exclusivos para la comercialización de los neumáticos. Lo anterior hace que esta red de distribuidores
independientes de Goodyear no sólo tenga que competir con distribuidores de otras marcas (Pirelli, Michelin
y Bridgestone entre las más importantes), sino que también entre ellos mismos.
Todos los distribuidores, además de ofrecer las distintas marcas de neumáticos de Goodyear, ofrecen una serie
de servicios de valor agregado a los consumidores de manera de satisfacer las múltiples necesidades de éstos.
Entre los servicios ofrecidos se encuentran: balanceo, alineación de neumáticos, cambio de las pastillas de
frenos y amortiguación, por nombrar algunos. Cada distribuidor de Goodyear fija en forma independiente sus
precios a público en lo referente a los servicios de valor agregado. Los costos de los servicios de valor agregado
ofrecidos por los distintos distribuidores son similares y se han mantenido constantes en el tiempo.
Goodyear segmenta a sus clientes en tres grupos en base a su comportamiento de compra:
: a) Compradores orientados a la variable precio: se caracterizan por adquirir la mejor marca que su
presupuesto les permite siendo muy sensibles al precio. Son poco leales a una determinada marca o
punto de venta, ya que no valoran los servicios de valor agregado ofrecidos por los distribuidores, y
tienden a visitar muchos locales antes de realizar la compra, Representan el 10% de las ventas de los
distribuidores Goodyear.
b) Compradores fieles a la marca: se caracterizan por ser fieles tanto a la marca y a los distribuidores
autorizados de ésta. Demandan por sobretodo calidad de los neumáticos. Representan el 50% de las
ventas de los distribuidores Goodyear.
c) Compradores orientados a la calidad del servicio entregado por el local de venta: se caracterizan por
buscar la mejor experiencia de compra en el punto de venta. Valoran la marca pero por sobretodo los
servicios de valor agregado entregados en el punto de venta. Representan el 40% de las ventas de los
distribuidores Goodyear.
Hasta ahora la relación de Goodyear con sus distribuidores independientes ha sido buena. Goodyear entrega a
los distribuidores productos y marcas de acuerdo con las necesidades que cada uno de ellos tenga, además de
publicidad en distintos medios de forma de atraer consumidores a su marca, publicidad y promociones én el
punto de venta, y desarrollo de nuevos productos, todo lo cual permite dar una mejor atención a los
consumidores. Adicionalmente, Goodyear entrega a sus distribuidores el precio final a público para cada marca
de neumáticos Goodyear, el cual es el mismo para todos los distribuidores de la red. Dentro de los neumáticos '
ofrecidos por Goodyear a sus distribuidores se encuentran marcas premium (alta calidad) y marcas de precio
bajo. Las marcas premium les entregan a los distribuidores de Goodyear un margen mayor que las marcas de
precio bajo. >
En la siguiente tabla se muestran los ingresos y márgenes sobre el precio de venta de las categorías neumáticos
y servicios de valor agregado para los distintos distribuidores de la red de Goodyear en los últimos 4 años.
|
|
|
-----
-----
3
Neumáticos | 70%_ 50% | 75% __ 50%
Servicios de Valor Agregado 30% 15%-25% 25% 5%-15%
Producto de la fuerte competencia, Goodyear perdió un 3% de participación de mercado durante el año anterior
(2015). Como una forma de revertir los resultados y recuperar la participación de mercado, Goodyear se
encuentra evaluando la posibilidad de ampliar sus canales de distribución de manera de aumentar sus ventas.
Específicamente, la empresa se encuentra en conversaciones con Walmart, cadena de supermercados líder de
nuestro país, para que se convierta en la primera cadena en comercializar las marcas de neumáticos Goodyear
en los 47 locales Hiper Líder que tiene Walmart a lo largo de Chile, Hiper Líder se caracteriza por tener un
posicionamiento de precios bajos, un gran surtido de productos, salas de venta de gran amplitud y por tener
locales ubicados en lugares estratégicos, buscando atender la mayor cantidad de clientes.
En caso de llegar a acuerdo, Hiper Líder ofrecería sólo neumáticos de marca Goodyear al interior de sus
locales, No ofrecería servicios de valor agregado a sus consumidores como los ofrecidos por los distribuidores
Goodyear. Hiper Líder fijaría el precio final de los neumáticos a los consumidores de acuerdo a la ubicación
de sus locales y la competencia existente. Se espera que Hiper Líder pueda acceder a más de dos millones de
potenciales consumidores de neumáticos Goodyear.
Ante la posible incorporación de Hiper Líder como un nuevo canal de distribución de Goodyear, los
distribuidores de la marca se han mostrado molestos e incluso decepcionados con esta posibilidad. Muchos
sienten que perderían los derechos de exclusividad sobre las famosas marcas de Goodyear. Otros temen que
se desencadene una disminución más acentuada en sus márgenes. Incluso uno de los distribuidores más
importantes manifestó que esta era una seria amenaza y que de ocurrir evaluaría seriamente si seguir
comercializando las marcas Goodyear o bien convertirse en distribuidor de alguna marca de la competencia.
PREGUNTAS
1. Según lo señalado en el caso y utilizando conceptos de marketing, ¿Cómo explica Ud. que el margen
logrado por los distribuidores de la red de Goodyear, en la categoría neumáticos, se haya mantenido
constante en los últimos cuatro años, mientras que el margen logrado por los servicios de valor agregado
haya caído durante los dos últimos años en comparación al período 2012-2013? Justifique claramente su
respuesta.
2. De acuerdo con la información entregada en el caso y utilizando conceptos de marketing, ¿Está Ud. de .
acuerdo con la afirmación de uno de los distribuidores más importantes de Goodyear, que señalaba que en
caso de que la empresa cerrara el acuerdo con Walmart, éste sería una seria amenaza para los distribuidores
de la marca Goodyear? ¿Por qué sí o por qué no? Fundamente su respuesta,
-----
»
-----
4
PREGUNTA N* 2
Google acaba de realizar una colocación de acciones en el mercado, captando particularmente la atención de
inversionistas institucionales que, viendo las enormes oportunidades de la empresa, decidieron invertir en ella.
Todos quienes habían invertido en la empresa tenían claro que Google operaba en la industria con mayor
rivalidad competitiva del planeta y con la tasa de cambio y obsolescencia de sus productos y soluciones más
alta de la llamada “nueva economía.” Días después de la exitosa emisión de títulos de la compañía Lazlo Bock,
Vicepresidente (VP) de Recursos Humanos de la empresa, paseaba por los jardines del 1.600 de Amphiteatre
Parkway, en donde Google tenía su cuartel general y se divisaba en el horizonte el maravilloso puente Golden
Gate de San Francisco, California. El alto ejecutivo reflexionaba acerca del sistema de incentivos que la
compañía debía implementar para su personal. Bock sabía que Google tenía que responder a la confianza
recién depositada por los inversionistas en la empresa. Era evidente para Bock que Google debía seguir
creciendo, para lo cual era imprescindible no perder a su mejor gente. Facebook y Twitter andaban tras ellos
y había que motivarlos para se quedaran en la empresa. El problema, sin embargo, es que no había consenso
entre los VPs respecto de qué forma debía tomar dicho esquema de compensación variable. Por ello es que el
Comité Directivo, la instancia en donde se decidían las cuestiones estratégicas como eran los sistemas de
: compensación variables de los ejecutivos y el personal en general de Google, le había encomendado a Bock
que presentara una propuesta para la siguiente reunión del Comité, ya que el asunto se había dilatado por
demasiado tiempo y el crecimiento e innovación permanente de la compañía requerían de un sistema de
incentivos que permitiera el logro de dichos objetivos. Esa era la principal preocupación de Lazlo Bock
mientras no dejaba de observar las maravillosas gardenias que florecían en los cuidados jardines de las oficinas
de Google.
En la última reunión del Comité Directivo Luc Vicent, VP de Ingeniería tomó la palabra para plantear un
esquema de incentivos variables para los ejecutivos y el personal en general de la empresa. Vicent señaló que
“gracias a nuestros exigentes procesos de selección, aquí contratamos a los mejores para cada cargo; solo
aquellas personas que tanto en la empresa como afuera muestran un alto nivel de desempeño. Por ello, es que
para los cuatros niveles organizacionales que tiene actualmente la compañía, debe existir una banda de
incentivos variables relativamente estrecha, que pague entre uno y cuatro sueldos adicionales a los 12 que cada
persona obtiene como remuneración fija. El sueldo adicional debiera corresponder a aquellos que logran la
metas que tienen cada año, mientras que los 4 sueldos debieran ser para quienes tengan una performance sobre
lo esperado. La alta calidad del personal que tiene Google no debiera generar mayores diferencias en bonos
variables y la dispersión relativamente estrecha que propongo es consistente con el desempeño esperado de
nuestro personal. Por lo tanto, si dos personas realizan las mismas funciones o se encuentran en niveles
jerárquicos similares dentro de la compañía, deberían tener bonos variables por desempeño similares. Es lo
justo.”
Bock, sin embargo no estaba muy seguro que la propuesta de Luc Vicent fuera la más apropiada para el logro
de los objetivos de crecimiento en ingresos y márgenes basados en una innovación permanente de Google. El
VP de Recursos Humanos pensaba que los supuestos detrás del planteamiento de Vicent estaban equivocados '
y que el sistema de incentivos que había que plantear al Comité de Dirección debía ser radicalmente diferente. .
Lazlo Bock pensaba que a la gente en Google había que pagarle de manera “injusta.” En una reunión pasada
del Comité Directivo, Bock había sugerido de hecho que: “podemos pagarle a alguien un bono 10 veces
superior al de otra persona que cumple la misma función. Es más, deberíamos estar dispuestos a recompensar
a alguien con poca experiencia o “junior” con un incentivo variable anual que incluso sea superior al del
: gerente general si acaso su contribución es muy relevante para los resultados de la empresa.”
Varios metros atrás habían quedado ya las gardenias y ahora Lazlo Bock contemplaba los cerezos en flor en
-----
-----
5
los jardines del 1.600 de Amphiteatre Parkway, mientras meditaba su decisión y decidía consultar a algunos!
expertos en la materia, antes de llevar su propuesta definitiva de incentivos al Comité Ejecutivo de Google.
Más aún, varios expertos consultados por Bock coincidían en que ambas propuestas de incentivos eran viables
para los propósitos que perseguía Google, aunque, indicaban, ambas también tenían características y
potenciales efectos negativos.
PREGUNTAS
1. A sujuicio, ¿Cuáles son los supuestos del desempeño de las personas en una organización, que están detrás
de las propuestas de Bock y Vicent, respectivamente? Señale además cuáles son los potenciales efectos
negativos fundamentales que cada una de dichas propuestas podría generar.
2. Para cada una de las dos propuestas planteadas por Bock y Vicent, señale cuál es la principal práctica de
gestión de personas, distinta al esquema de incentivos, que debe incorporase para atenuar los efectos
negativos que cada propuesta pueda generar, en cuanto a la capacidad del sistema de incentivos para apoyar
el logro de los objetivos de Google. Sea breve y preciso.
-----
-----
6
PREGUNTA N* 3
La empresa “Los Bicampeones” (LB) se dedica a la compra y venta a mayoristas de un único producto: la
camiseta oficial de la selección chilena. !
La siguiente es la información financiera de la empresa LB, al 31 de diciembre de 2016:
e Ce 21 31/12/2016 EEE,
Caja 100.000|Cuentas x Pagar Proveedores 90.000|
Cuentas x Cobrar 125.000;
[Existencias 225.000 [
¡Terrenos 550.000| Patrimonio _ 910,000]
Activos Totales _ $1.000.000|Pasivos + Patrimonio . sc. 5 1.900.000]
Se sabe que la rentabilidad operacional de la empresa el año 2016 alcanzó a un 5%, lo que ha llevado a su
Gerente a plantear al Directorio la conveniencia de aumentar el plazo que se otorga a los clientes para el pago
de sus compras, con la finalidad de acceder a nuevos mercados y así aumentar las ventas de LB.
A continuación se presentan los valores, de algunas variables de la política de crédito que sigue actualmente
la empresa con sus clientes, y los cambios que propone el Gerente para el año 2017:
Política Actual (2016) | Nueva Política (2017)
Ventas Anuales ($) 51.000.000 $1.100.000 _ _
Rotación de Cuentas por Cobrar (veces al año) 8 5
¡Rotación de Existencias (veces al año) 4 4
Período Promedio de Pago a Proveedores (días) 36 36
Incobrables (% sobre ventas) 0% 0%
Margen operacional (% de Utilidad Operacional/Ventas) 5% 5%
Descuento por Pronto Pago 0% 0%
En opinión del Gerente, el cambio de política que él propone, no sólo generará un aumento en la liquidez y en
la rentabilidad operacional de la empresa, sino que también permitirá aumentar la riqueza de los dueños.
Algunas de las características más relevantes de la empresa son las siguientes:
+  Laempresa compra todo a crédito a sus proveedores y vende todo a crédito a sus clientes.
e Todas las compras y ventas se producen de manera uniforme durante el año.
+ La empresa comercializa un único producto, con el mismo costo y el mismo precio de venta unitario.
+ El costo de adquisición de cada camiseta, corresponde a un 90% de su precio de venta y se mantendrá sin
cambios con la nueva política de crédito.
+ La empresa tiene Únicamente los cuatro tipos de activos que aparecen en el balance que se ha presentado,
y todos ellos son operacionales: Caja, Cuentas por Cobrar, Existencias y Terrenos. De manera similar, la
empresa tiene únicamente un tipo de pasivo: Cuentas por Pagar a Proveedores, las que no generan intereses
de manera explícita. Todo el financiamiento complementario corresponde a Patrimonio.
+  Eltotal de los activos de la empresa durante los dos últimos años, situación que se espera se repita en los
próximos dos años, se ha mantenido constante en $1.000.000, |
+ No hay impuestos ni inflación. |
e La empresa no tiene transacciones que den origen a resultados contables (utilidades o pérdidas) no |
operacionales. Los únicos gastos operacionales de la empresa son 100% variables y corresponden al Costo |
|
-----
-----
7
de Ventas y a los Gastos de Administración y Ventas. De este modo, el Resultado del Ejercicio anual de la'
empresa (Utilidad o Pérdida) es idéntico a su Resultado Operacional anual.
e  Latasa de costo de oportunidad o de descuento, según el riesgo relevante tanto de cada uno como de los
activos de la empresa considerados individualmente, como del total de sus activos en conjunto, es de 15,5%
anual, compuesta diariamente. .
+  Unaño tiene 360 días (meses de 30 días).
» Es política de la empresa, disponer el 31 de diciembre de cada año, de Caja o Efectivo equivalente al 10%
del total de las ventas del año que está terminando.
+ Los pedidos de existencias se reciben en la bodega de la empresa el mismo día en que ellos se realizan.
PREGUNTAS :
Sobre la base de la información presentada, a Ud. se le pide:
Evaluar financieramente la propuesta del Gerente de LB. Específicamente, refiérase y fundamente de manera
numérica, su opinión sobre cada uno de los siguientes tres aspectos señalados por el Gerente y que se
producirían durante el año 2017, como resultado de la implementación de la nueva política de crédito:
+ Habrá un aumento en la riqueza de los dueños de la empresa.
e Habrá un aumento en la rentabilidad operacional de la empresa.
+ Habrá un aumento en la liquidez de la empresa (para su medición, use los dos indicadores contables
tradicionalmente utilizados para ello).
NOTA: En la página siguiente encontrará una tabla de interés diaria correspondiente a una tasa de interés del
15,5% anual, compuesta diariamente.
-----
-----
8
Tabla Exponencial para una Tasa de Interés = 15,5% Anual (Compuesta Diariamente) :
A
Valor =| (14-0,155)360 |, en que “t”=N? de días
lens | vato] vacios | valor | mraenias | vetar] nraemas | valor | .
Por | rw [o "fro |" is] iso [aa] ass Y
po | towwew Y" 9 | Tor Y 32  j tossw | "ee | try
Ss 9 8 or js] ms]
A es 1 pies] ms
lo [ir sf ie po ss iras ms [mes |
|" Piso $ ss [19m j 186 | ios | "ae — | amen A
lr [is [| 9% "TI is | "e | iemms | am | Tiumse fl
ps [| isa fos | ros | ve | veis | 28 | ts |
Es [lime [ "o [tom [ss [ross | mi uses |]
pe Pra [m0 7 esosso 98] ooo | 280 Pistas |
pa Piar for posó JJ toas Jae poor]
: loa [toos | 12" | iomém | we Y tomes $382] 1996 Y
PP or a oa Ys > fosos Pass fo Al
e Pie [osas A 4 Tm | [tamos]
as [oo $ ses > | 1owsas $ ws [toser | es | vos
is fis $ 1 [| nowws | ws] rra | 26 | tos |
es pm Tio pp wr] 107 o] > | em» |]
> [toos | ños [tome | 198 > Pf voszasi | 288 [isos]
ps [te [> mw | roms] ws | tomo | aw Y tr ]
la oo fo tor Ja | vosaar > 90 Po ttasos7 |
la or > ess Jo | omar Y] a Tasa |
pe Pos Y) m2 "IO tossesi aa Y osas Jo 292 | 1.196]
la [is] ms | reeopo sf tome Jas | iio |
Pa ss PY "ma tonos] 209 fosos | a] toss6
ps fio Y ms] normes | aos Troessts Jo 2s [15337]
as fro $ 16 | voz Jj 20 | 1osos [ww | 112587]
par toos | 07 | io pr fi | 2 > | ipems |]
pa ar > es [oie pa [tomes | 28 | tam]
lla TT tos | mw [rows |] ws | vosms? | 2» | ens]
o [tomos [> to Ptos |] "aro | "tosros >) 30m > | 1oa 1
[a "fi > 1 pios Y 24] tosems Ja] 1ize0s |
Pa [ios e > | ess Pare po tes po 30] tema |
TT Tos] osos Ja] tomo | am | rias]
[la [io Y ms | rososesz Y zm f—1esws | 305 [1108 |]
as | om .s | vosos Y ws | tossm [_ 30s | 1125850]
ls Po vom | ya [ross | 26 | tous | _3w [tios |
ps fm Per is Jo cr or ar Y or]
loss [| ios || _m_ | rss of as  [ romer [sms (tios |
LA ma | im os Pas | voor PY aras]
A CC CI TO E CI CT
lo [imss | ía [ss | aa fia Y aa] aser |
le  [_ 10 _ | sw "joss | zz Jj 1i00 J 32 (| tisww |
| [| imss | _ mu | tos | "23 [16] ms Jj inn ]
ls tomes | "rss" Ptos | es | tows ) "—3s | rise y
|] os] ws [rosso] es  f 1068 ] 36 | 1.1086 1]
| eo Ys Pose [ws | tos5s58 | sis _ | Limas |
po [rows | 1 [ross | ws  f 1086 ] 39 [16 |
lg Y tor Y mo | tos79 [0 $ 16 | "30 | "Tissss |]
si Pr Pa rss poa a po am] ro]
fa Ti Pe roses Po ae fm |] imss]
pos [ios P 16 [ vos Jas [| towss | ss | re]
ls Pts Po ie [rosas fo a $ tome [am [ 11806]
ps [| im»s [us | roms fo ws | www |]  39s | ts]
os | to | vw  [  tosoez [  23s | room | _ ws [ 11988]
los [ies [mb [reso |” as | rosos2= | 32m | tro |
la | mw | 19 | vosmwss | 29 | v10098 [> 3»  f vts |
pe [ tos | is [| toser | aw  [ itooss [30 _f rms |
Pa [row | ws [tom [_ za _[_ tem "ss "Y Lime |
E do Y 1 [toa Yo e || ima] s2 | moy |
pS [os fs | 15 [| as | rms Po 3s3 [| 1uses |]
és [ios Y ws [| toós58e ] 204 [ts |  3s | 1Jw0%3 7]
ls Pass | 1o6w008 J 25 | 110308 [xs _ | rrss00 |]
pes > | immer | 15 [| roms $ 26 [tos [| "36 [197 ]
led iens | as [| tos [20m | 192 | 337 | 19u1 ]
[a [ts [2 ws [| [| 2 [iv [| ss | tii
le [| ios [| _ 159 [| vo6m3 [| 29 | isso | 3 | is |
pi tn | teamo | o | aaa [o isos
a [ios] ve j ioses67 | asi | riosó0 | 34 | tiem |
| mr | mess | 162 | wow [|  2s [| vts Y 39 (| 1168 |
ls | res] ios | ass > | two6s78 || 3s > | rn |
O > | 136 | 161 (tos | se | tom | 34 | us |]
load sf rs | rosas | 3ss | iso _] ss | 1.r80ss |
O vs > | 1osws | 166 | toser | 2 | twmos | 316 | Les |
Ps $ som | 168 [| toóss f 288 | tum [ 386 | ros |]
o a e ica Y co | poe A
ps aa Y a | is]  2w jr | ss | ts]
CS O IC EI A E
[le ss $ 2 | tea] 26% | imosw |  3s | tas |
fa ies Y ws | ive | os [mos | as [siste |
le | ise Y im | iomsr Je $ imss [| ss | ti» |
Pas [| ise j vs | ise js ] ue |] "ss" [rie |
loss [ms po ae [ 1omso Js [109 |  3ss | tesis |
ps [imss [Pm [| _iommwo|__ 2%] mms |_ 3” | "rim |
ls fo ies [| mm | imss [| e [uso |  3ss | 11siws |]
ps [tee | ws | _1i0ww [| 29 | vis | 359 | tits |
A A A a is |
-----
mn
-----
9
PREGUNTA N* 4
Como ha ocurrido en gran parte de los países del mundo, el desarrollo de los Malls y Centros Comerciales ha
sido la tónica en los últimos años. En Latinoamérica cada vez se aprecia una mayor profundidad en el desarrollo
de este tipo de comercio. El mercado ecuatoriano no ha sido la excepción a esta tendencia.
Grupo Real
Desde hace más de 15 años el protagonista principal en el sector de los Malls y Centros Comerciales en Ecuador
ha sido Grupo Real, una compañía internacional, fundada hace 70 años, y que opera centros comerciales en
Ecuador, Perú, Colombia y Venezuela. Su principal giro es el desarrollo, comercialización y operación de
centros comerciales. Ello se materializa a través de ofrecer locales comerciales principalmente en arriendo, y
unos pocos que se ofrecen en venta.
En Ecuador, Grupo Real tiene 8 centros comerciales, los cuales representan un millón de metros cuadrados
construidos. Es uno de los cinco principales actores en la industria latinoamericana y el número uno en Ecuador.
Grupo Real opera bajo estrictas normas de seguridad y está ubicado en las principales ciudades del país.
La Industria de Centros Comerciales en Ecuador y su Modelo de Negocio
Es una industria que ha venido creciendo sistemáticamente durante los últimos 5 años. A los centros comerciales
ya establecidos, se han ido agregando nuevos malls de distintos tipos, tamaños y público objetivo, los cuales
buscan llenar las expectativas de los diferentes segmentos de consumidores que hay en el país. A este
crecimiento han contribuido factores como la seguridad que brindan los centros comerciales, lo que permite que
sean lugares de esparcimiento, diversión y compras.
Un centro comercial recibe ingresos por múltiples actividades que realiza. Su principal fuente de ingresos es el
arriendo de locales comerciales, valor que se compone de una tarifa fija de arriendo (un valor cobrado por metro
cuadrado de superficie arrendada en el local comercial), más una tarifa variable calculada como un porcentaje
de las ventas del local. Para la tarifa variable, en cualquier mall, a los locales pequeños, que son los de menor
venta, se les cobra una tasa porcentual que fluctúa entre el 10% y el 12% de las ventas mensuales del local; a
los medianos, entre el 5% y el 8% de las ventas mensuales; y a los de mayor tamaño, entre el 1% y el 3%. Las
grandes casas comerciales pagan por lo general el 0,5% de las ventas mensuales como renta porcentual,
En términos relativos, la parte fija del ingreso por arriendo representa por lo general un 60% del total de estos
ingresos por arriendo, mientras que la variable representa el 40% restante. De esta forma, la gestión comercial
del mall se orienta a no tener vacancia de locales arrendables, a preocuparse por generar el mayor tráfico posible
al interior del mall, lo que incide directamente en la vacancia, y a obtener la mayor compra promedio en cada
local del mall de manera que se genere mucha venta para el local y así el mall tenga un atractivo ingreso
porcentual en la parte variable del cobro por arriendo.
También un mall recibe ingresos por una serie de otras actividades o negocios, como es el caso de la venta de
publicidad, del estilo paletas publicitarias, en los pasillos interiores del mall, el cobro por el estacionamiento, y
una serie de otras actividades menores,
Cabe destacar que al interior del Grupo Real, los ingresos por publicidad interna en los propios malls que posee
en Ecuador alcanzaron durante el año 2015 la cantidad de US$285.000, una cifra muy discreta sobretodo si se
considera que representa menos del 2% de los ingresos obtenidos por el arriendo de locales en los mismos malls,
La Publicidad en los Malls del Grupo Real
Cuando hablamos de publicidad en los malls, nos estamos refiriendo a la venta de publicidad en paletas |
publicitarias ubicadas en los pasillos interiores del mall y en algunos grandes letreros que se ubican en los
exteriores del centro comercial. Este tipo de publicidad se utiliza exclusivamente por las propias empresas que
operan y venden al interior del mall, para atraer a su tienda o casa comercial a aquellos clientes que se encuentran
dentro del mall. Dada esta característica, en la publicidad interna del mall suelen avisarse ofertas, liquidaciones
-----
-----
10
o ganchos comerciales de tiendas específicas del mall para conducir al visitante que está en el centro comercial
hacia un determinado local comercial.
La publicidad al interior de los malls del Grupo Real en Ecuador, se realiza a través de la empresa ABC
Publicidad, compañía externa independiente del Grupo Real. Con esta empresa, se tiene suscrito desde hace 3
años un contrato para regular la relación comercial entre Grupo Real y ABC Publicidad. Las condiciones del
contrato suscrito entre ambas partes son las siguientes:
- Grupo Real recibe el 45% del valor de la venta de la publicidad, con un ingreso mínimo garantizado de US$
250.000 anuales.
- ABC Publicidad cobra al avisador una tarifa fija por letrero cuyo valor varía dependiendo del tamaño y de la
ubicación del letrero en el mall.
- Los espacios publicitarios privilegian las marcas anclas y los locales internos del centro comercial.
- ABC Publicidad asume los costos de instalación, medidores y los costos operativos de energía eléctrica.
El contrato con ABC Publicidad está bajo la responsabilidad de la Gerente de Marketing del Grupo Real, quien
maneja un portafolio de contratos en donde el suscrito con ABC Publicidad representa sólo un 10% del total de
negocios que están bajo su responsabilidad.
Voces de Alerta en el Directorio
Después de tres años de vigencia del contrato con ABC Publicidad, la dirección de Grupo Real no está contenta
con los resultados del mismo, y se han generado opiniones muy diversas que están complicando al Directorio,
“En estos tres años hemos bordeado los US$ 285.000 en ingresos por publicidad, lo que nos acerca el nivel
mínimo de ingresos garantizados (US$ 250.000) que contempla el contrato, y pienso que hay elementos que
muestran que debiéramos haber sido mucho más exitosos desde el punto de vista financiero con la publicidad
vendida”, señalaba el Gerente de Administración y Finanzas del Grupo Real en el último Directorio. Otro de
los gerentes apuntaba directamente al contrato de arriendo: “El contrato está mal diseñado a nuestros intereses
ya que nos llevamos una parte del negocio muy poco significativa en relación con nuestro real aporte”.
Pareciera ser que el Directorio debía tomar cartas en el asunto.
PREGUNTAS
Considerando sólo la información contenida en este caso, responda las preguntas que se le formulan a
continuación:
1. En el último comentario que se señala en el caso, uno de los gerentes del Grupo Real sostiene: “El contrato
está mal diseñado a nuestros intereses ya que nos llevamos una parte del negocio muy poco significativa
en relación con nuestro real aporte”. Desde un punto de vista estratégico, ¿cómo explicaría Ud. el bajo
resultado para el Grupo Real que hoy muestra el negocio de publicidad al interior de sus malls? Señale dos
posibles causas de este bajo resultado. Sea breve y preciso en su respuesta.
2. Desde un punto de vista estratégico del Grupo Real, ¿debiera la publicidad en los malls gestionarse con una
empresa externa del tipo ABC Publicidad, o debiera manejarse internamente en el Grupo Real? Defina con
claridad su posición y arguméntela adecuadamente.
-----
-----
11
PREGUNTA N*5 :
Algramo es una empresa Bi, creada en 2013 por José Manuel Moller, egresado de Ingeniería Comercial
UC, que comercializa productos de primera necesidad en almacenes de sectores residenciales de bajos
ingresos en la ciudad de Santiago. La idea básica de Algramo es utilizar una máquina dispensadora de
productos a granel (sin envasar o empaquetar) que se instala en el almacén, y que permite al consumidor
comprar la cantidad que desee a un precio similar al precio que compra el mayorista por los productos de
una canasta básica, en lugar de pagar el mayor precio que significa la compra en formatos fijos y pequeños.
El ahorro en precio para el consumidor final llega a 20% - 30%, [PRA == ea sei
dependiendo del producto, aunque este no es el único beneficio que 44% 0 E A
busca Algramo; también aspira a tener un impacto medioambiental y dl O
social. Algramo instala la máquina dispensadora en los locales e
adheridos y vende los productos a los almaceneros quienes, a su Vez, gas | a oe
venden sus productos al consumidor final. El O pS ; pa
Algramo negocia con los almaceneros la instalación de la máquina +3... AS
en su local (ver figura a la derecha). En la primera compra, el A Esso de
consumidor paga el producto a granel y adicionalmente paga un ao y e a
envase retornable. En las siguientes compras, el cliente sólo paga el 5 ¡oa 0 o he
producto a granel si utiliza el mismo envase. El mayor ahorro para el ¿dE A par
consumidor final se produce en las compras sucesivas en las cuales EA
no se paga el envase. a a ; a Le A A Na
o o
Los ejecutivos de Algramo buscan hacer crecer las ventas de la Cl a
empresa, ya sea en penetración (mayor cobertura) como en frecuencia *. AAA AN A ss
e intensidad de compra a través de consumidores más leales con la . AA
marca. Así, se busca poder conocer mejor al consumidor y al “TAO a
comprador de Algramo, la viabilidad de una estrategia de crecimiento, los atributos que los consumidores
valoran, los formatos de productos requeridos, las líneas de productos de consumo básico que debiera
ofrecer la empresa, el modo de compra de los consumidores, el uso del envase desechable, la disposición
a pagar y la valoración de productos social y ambientalmente responsables.
ra , Tc Hasta ahora, los dueños y ejecutivos de
O E Pao Algramo no han hecho ningún estudio de
e a E mercado y todas sus decisiones se han basado
E A >. SS en información no estructurada respecto de los
O , . eN / almaceneros y de los clientes finales. Para
PRA CAR hacer frente al nuevo desafío que enfrenta la
cal E A de empresa, los ejecutivos de Algramo han
cd o E EAS cotizado en tres empresas de investigación de
: OA PEE 9 bas mercado un estudio que permita responder a
a a , LOS Ué o las interrogantes planteadas. El Cuadro 1 que
e de A pe SL $ pa h E y eo está en la página siguiente presenta, en forma
o oo O SS resumida, características metodológicas de los
tres estudios propuestos.
1 Las empresas B tienen como objetivo no sólo las utilidades para sus dueños sino también el impacto social y
medioambiental.
-----
-----
ee
12
= Cuadro 1: Características Metodológicas Estudios de Mercado :
Consumidores Finales Compradores Algramo
Población (de productos Algramo| Almaceneros (quienes toman decisiones
Obietivo y no Algramo que no (Algramo y no de compra en el hogar y
y toman decisiones de Algramo) compran productos
compra en el hogar) Algramo
40 entrevistas en
2 Focus Group para profundidad de Investigación etnográfica
Metodología cada uno de los aproximadamente | de 40 casos en el almacén,
Cualitativa segmentos: Hombres 20 minutos c/u selección mediante cuotas
y Mujeres con selección por por comuna
conveniencia.
En paralelo a la fase
cualitativa, muestra
de 400 casos con
Metodología selección de la . ,
e - r d
Cuantitativa | muestra estratificada No considerado No considerado
por comuna y en tres
etapas (manzana,
hogar, persona)
PREGUNTAS
a) ¿Cuál es el problema de marketing de Algramo según se describe en el caso? Sea específico.
b) ¿Cuál es el problema de investigación de Algramo según se describe en el caso? Sea preciso.
e) El Cuadro 1 presenta, en forma resumida, tres propuestas metodológicas que ha recibido Algramo, El
gerente de marketing de Algramo ha descartado la alternativa A y considera que las alternativas B y
C son igualmente válidas. ¿Está usted de acuerdo con el ejecutivo de Algramo? Explique por qué.
-----
-----
13
PREGUNTA N' 6
El 24 de junio de este año, los habitantes del Reino Unido (o británicos para todos los efectos prácticos)
concurrieron a las urnas para votar en un plebiscito si permanecían o no dentro de la Unión Europea (UE). El
referendo fue mundialmente conocido como el Brexit, que corresponde a la abreviatura de dos palabras en
inglés: Britain (Gran Bretaña o Reino Unido) y exit, que significa salida (de la UE). Un año antes ya se sabía
que ocurriría esta consulta ciudadana, pero los políticos, las personas y los mercados le asignaban una baja
probabilidad a la ocurrencia del Brexit y había baja incertidumbre al respecto.
Al acercarse la fecha del referendo la incertidumbre aumentó exponencialmente. Ya nadie se sentía seguro de
lo que ocurriría. Se puede pensar que el tipo de cambio spot (tipo de cambio vigente en el mercado cambiario),
que justo antes del referendo tenía un valor de 1,5 USD / Libra (1,5 dólares estadounidenses por libra esterlina),
reflejaba el valor esperado post-consulta: habría una depreciación de la Libra si se aprobaba el Brexit (la salida
de la UE) y una apreciación si ocurría lo contrario. Pero la volatilidad del tipo de cambio era muy alta, para
los estándares históricos,
Suponga que hoy es el 23 de junio de 2016, día inmediatamente anterior a la fecha del referendo, y que los
resultados del mismo se conocerán al día siguiente (24 de junio). En base a la información que se le ha
proporcionado, responda las preguntas que se le formulan a continuación. Justifique sus respuestas en forma
breve y precisa,
1) En este ambiente de altísima incertidumbre previo al plebiscito:
i) Si Ud. hubiera querido proteger, frente a un potencial Brexit, el valor de un depósito a plazo en libras
esterlinas que vence el 24 de junio, y que Ud. tiene la intención de convertir a dólares estadounidenses (USD)
a su vencimiento, ¿Qué tipo opciones debería haber comprado y por qué?
ii) Suponiendo igual plazo, precio de ejercicio, tasa de interés y precio spot ¿Cree Ud. que hoy (un día antes
del referendo) las opciones sobre la libra esterlina tenían precios mayores o menores a los que tenían un año
atrás? ¿Por qué?
2) Suponga que Ud. no tuviera certeza alguna de cuál será el resultado del referendo. Proponga, mostrando sus
resultados gráficamente, una estrategia de inversión, con una opción Put y una opción y Call, ambas con
vencimiento al día 24 de junio y precio de ejercicio de 1,5 USD / Libra, que Je dé a Ud. la posibilidad de
obtener resultados positivos, independientemente del resultado de la consulta, si se producen cambios
significativos (apreciación o depreciación) en el valor de la libra esterlina, Fundamente con claridad su
respuesta.
3) El 23 de junio (un día antes que se conociera el resultado de la consulta) se transaban opciones del tipo
europeas Calls y Puts que vencían el 24 de junio, ambas con precio de ejercicio de 1,5 USD/Libra (igual al
valor spot de la divisa del día 23). Suponga que se cumple la paridad Put — Call, esto es: :
P=C-So+VP(X)
(el precio de una opción Put es igual al precio de una opción Call, menos el precio spot del tipo de cambio más
el valor presente del precio de ejercicio de la opción Call y de la opción Put (X = 1,5 USD/Libra)).
Suponiendo que la tasa de interés relevante a un día es igual a cero ¿Qué relación debiera cumplirse entre los
precios de las opciones Call y Put? ¿Significa este resultado que el mercado le asignaba lá misma probabilidad
. de ocurrencia a que el Reino Unido permaneciera o saliera de la Unión Europea? Fundamente sus respuestas,
-----
-----
-----
-----


# Examen de grado · agosto-2017-administracin

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


, PONTIFICIA UNIVERSIDAD CATÓLICA DE CHILE
ESCUELA DE ADMINISTRACIÓN
SI
>
DIVAS
a ES
EXAMEN DE GRADO |
" INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El ahumno puede responder las seis preguntas. Para aprobar el examen, el
alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2, Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3, Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
que los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
realidad de las empresas que allí se mencionan.
5, — Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente al Profesor Ignacio Rodríguez, Presidente de la Comisión
de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
cumplimiento de esta norma es de absoluta responsabilidad del alumno.
_ 9. Usted NO debe escribir su nombre en las hojas de respuesta.
10, No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
condiciones, el Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un (a) alumno (a).
11, No está permitido el uso, para fin alguno, de teléfonos celulares en la sala, los que deberán estar apagados y no
deberán mantenerse sobre el escritorio durante el examen.
12. Cada alumno (a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
examen.
13. Al terminar el examen, Ud. debe entregar ímicamente las hojas que ba recibido para responder y que se han
identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar :
como “borrador”, esas hojas no se deben entregar con las respuestas.
Fecha : 4 deagosto de 2017 : |
Duración : 9:00 horas a 12:00 horas |
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el Profesor
Ignacio Rodríguez, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 y |
11:00 hrs. (aprox.). |
|
|
|
-----
2
. PREGUNTA N' 1
La cadena de tiendas “xyzpin” es la empresa más importante de retail en nuestro país en la venta de electro hogar
(TV, proyectores, equipos de blue-ray, máquinas fotográficas, etc.), tecnología (computadores, impresoras, |
telefonía, etc.), y línea blanca (refrigeradores, lavadoras, secadoras, etc.). La cadena posee actualmente 90 locales |
a nivel nacional, los cuales se caracterizan por tener amplias salas de venta para exhibir y comercializar las
distintas marcas de estas categorías. Además, cuenta con personal de ventas altamente capacitado para resolver
las distintas dudas que tengan los clientes en relación con las diferentes marcas y modelos de estas categorías.
Esta cadena de retail tiene una estrategia multicanal: realiza ventas tanto en sus tiendas físicas como en su página
de internet, donde los clientes pueden hacer compras con despacho a domicilio,
Desde la fusión del 2008 entre las empresas de retail XYZ y PIN, la cadena “xyzpin” había mostrado un
crecimiento tanto en sus ventas como en utilidades, pero en el último año ambas habían caído. El Gerente General
de la cadena se encuentra preocupado por la situación actual de la compañía. Observa, por un lado, cómo caen las
ventas de las tiendas físicas de la empresa y por otro, cómo la estrategia de precios seguida por el departamento a
cargo de la tienda virtual, ha llevado a una disminución de los márgenes en las ventas de e-commerce.
Según el Gerente General de “xyzpin”, una de las principales razones de por qué habían caído las ventas y los
márgenes de los locales de la cadena, era al efecto “showrooming” (efecto “vitrineo”). Este efecto consiste en la
práctica de los consumidores de visitar un local, examinar, probar y preguntar todo lo referente a un determinado
producto, para luego hacer la compra online en otra tienda digital a un precio más bajo. En general, las tiendas
online suelen ofrecer precios más bajos ya que tienen estructuras de menores costos, producto de que no cuentan
con locales y personal de tiendas, Actualmente, más del 70% de los consumidores está utilizando el
“showrooming” sobre todo en categorías como electro hogar, tecnología y línea blanca, las cuáles requieren de
un proceso de decisión de compra más complejo. Estas categorías se caracterizan por requerir, de parte de los
clientes, de información más específica de los distintos modelos de productos, asesoría en el proceso de compra
y en algunos casos demostraciones de productos.
La conocida cadena Walmart ha sido una de las empresas pioneras en facilitar el efecto showrooming en nuestro
país. En efecto, hoy en día es posible bajar una aplicación en los smartphones de las personas, que les permite a
ellas comparar el precio de un determinado producto, que podrían adquirir en la tienda online de Walmart,
mientras se encuentran visitando locales de la competencia. Así, por ejemplo, un consumidor podría estar
analizando la compra de un refrigerador Mademsa en un local de “XyZpin” y comparar en su teléfono el precio al
cual podría adquirirlo en la tienda online de Walmart.
A pesar de contar con distintos formatos y un gran número de locales, Walmart es capaz de ofrecer precios más
bajos que los competidores, debido a las fuertes economías de escala que logra en la operación de sus distintos
tipos de formatos y en los grandes volúmenes de compra a los proveedores, lo que le permite tener menores costos
de operación de sus locales y tienda on-line.
Después de un año de caída en las ventas y utilidades de la empresa, el Gerente General de “xyzpin” estaba
pensando aplicar una “Política de igualación de Precios Permanente”, a partir del segundo semestre de este año,
como una forma de defenderse de la agresiva política de precios de los retailers online, especialmente de Walmart.
Esta política consistía en igualar el precio que encontraba un cliente al hacer “showrooming” en los locales de
“xyzpin”. Por ejemplo, si un consumidor estaba analizando la compra de un computador en un local de la cadena
y encontraba el mismo producto en una tienda online como Walmart.com u otra, “xyzpin” le igualaba el precio
inmediatamente en el local. De esta manera, “xyzpin” se aseguraba que el cliente materializara la compra del
computador en la tienda y no a través de un competidor online.
-----
3
El Gerente de Marketing de “xyzpin” no estaba tan convencido de aplicar la “Política de Igualación de Precios
Permanente” que estaba sugiriendo el Gerente General de la cadena. El sugería dos estrategias alternativas para
enfrentar la agresiva estrategia de precios de Walmart. La primera estrategia consistía en reducir el tamaño de las
tiendas de “xyzpin”, en términos de metros cuadrados, de manera de bajar costos fijos producto del pago del
arriendo de los locales y del menor número de empleados que se necesitarían en cada uno de ellos. Además, el
tener tiendas más pequeñas le permitía a “xzypin” disminuir los costos de inventario y los costos asociados al
espacio destinado a la bodega utilizada para mantener dicho inventario. Así, la cadena podría disminuir los precios
de los productos en los cuales eran amenazados por Walmart. La segunda, consistía en mejorar el servicio que
ofrecían las tiendas a sus clientes. Por ejemplo, “xyzpin” le ofrecería a los clientes que compraran los productos
en sus locales, la instalación de estos en forma gratuita en sus casas u oficinas, o bien que ellos pudieran traer los
productos a las tiendas donde existiría un área donde podrían ser revisados y reparados en caso de tener algún
problema. El mayor costo que implicaba este servicio para “xyzpin” sería financiado por los proveedores, a
quienes la cadena les cobraría un pago por el concepto de exhibición de los productos en el punto de venta y
asesoría en la venta de los productos a los clientes. De acuerdo al Gerente de Marketing, este cobro a los
proveedores se estaba convirtiendo en una práctica común en la industria del retail a nivel global.
PREGUNTAS
1.  Deacuerdo ala información entregada, señale y explique claramente dos razones por las cuales la cadena
de tiendas "xyzpin" no debiera mantener una "Política de Igualación de Precios Permanente". Justifique :
claramente su respuesta. :
2. ¿Cuál de las dos estrategias planteadas por el Gerente de Marketing implementaría Ud. para enfrentar las
consecuencias del efecto showrooming en la cadena “xyzpin”? Justifique su respuesta señalando las
principales ventajas y desventajas de cada una de ellas.
-----
4
- PREGUNTA N*2
Es 2008. Cae una intensa nevazón sobre Paris, la “ciudad luz”, capital de Francia. Los emprendedores
estadounidenses Trayis Kalanick y Garrett Camp se encuentran en viaje de negocios en esa ciudad y tienen
problemas para conseguir un taxi, Piensan en una simple idea: “qué tal sería simplemente presionar un botón
para conseguir un viaje.”
Así nació Uber, aplicación que cambió la forma en que las personas se movilizan en el planeta. A los pocos
meses, ya de regreso a su país, Kalanick y Camp lanzaron Uber, que comenzó a operar en San Francisco, Estados
Unidos. Hoy la compañía está presente en 500 ciudades en todo el mundo y Kalanick —actual gerente general
(CEO) de la empresa-, de 40 años, ya posee una fortuna de US$6.700 millones y la empresa tiene un valor de
US$69.000 millones, según Bloomberg.
Una de las principales razones para el explosivo crecimiento de la compañía, es la cultura de la empresa de alta |
intensidad, la que está instalada sobre una estructura descentralizada con un énfasis importante en la autonomía |
de cada oficina en cada país y ciudad, sin una supervisión cercana de la oficina central de San Francisco. A cada
persona se le pide un alto nivel de exigencia con resultados financieros concretos y rápidos.
Pero, al parecer, los números no lo son todo. Hace unos días Kalanick fue obligado a dejar su cargo de CEO,
tras la fuerte presión de los inversionistas. Aunque seguirá en la empresa, las razones para que saliera de la
dirección obedecen a una serie de polémicas al interior de la firma, como denuncias y juicios laborales por acoso
sexual y laboral, declaraciones machistas de varios ejecutivos de nivel alto y mandos medios de la empresa y  -
conductas refiidas con la ética de varios empleados de Uber en diferentes niveles jerárquicos y áreas funcionales
de la organización. De hecho, la compañía despidió hace pocos días a 20 empleados, después de 215 quejas en |
el interior de la empresa por estas malas prácticas. A lo anterior se suman problemas de liderazgo que él mismo
CEO reconoció, luego que Bloomberg publicara un vídeo, en febrero, en que se mostraba a Kalanick discutiendo
con un conductor de Uber, La empresa también enfrenta varias investigaciones judiciales por cuestionamientos
acerca del uso encubierto de softwares para que sus conductores eviten ser detectados por las autoridades en las
áreas donde sus autos no pueden trabajar y por tácticas aparentemente encaminadas a perturbar a rivales en el
negocio del transporte compartido.
Cuando los nuevos empleados son seleccionados y llegan a trabajar a Uber, les piden un par de requisitos: que
tengas ganas de darlo todo en su cargo y que se apeguen a los valores centrales de la empresa Estos valores se
pueden resumir en que “cada trabajador de Uber debe hacer apuestas audaces, estar “obsesionado” con el cliente,
trabajar muy arduamente y apuntar a la meritocracia como mecanismo de ascenso en la compañía: la idea de
que los mejores y más brillantes ascenderán con base en su propio esfuerzo.” Lo anterior también se
complementa con un agresivo esquema de incentivos que enfatiza el esfuerzo y resultados individuales, con la
promesa adicional de que “los que más contribuyan al crecimiento de la empresa tendrán un progreso más rápido
en ella”, en palabras de un alto ejecutivo de Uber. Varios empleados también señalaron que, en ocasiones, se
observa incluso que ejecutivos de alto desempeño pero con problemas con sus equipos no salían de la empresa,
sino que eran reasignados a otras regiones. “El despido no es una alternativa para la gente con buenos resultados
en Uber. A veces, los gerentes problemáticos, objeto de numerosas quejas, eran asignados a distintas regiones;
los despidos eran menos comunes”, indicó Gerard Stevenson, un trabajador con muy buen desempeño, que ha
estado desde el inicio de la compañía. Al parecer, un grupo en particular era inmune al escrutinio interno, dijeron
empleados y ex empleados. Incluso los miembros de ese grupo, llamado A-Team y compuesto por ejecutivos
de diversos niveles y áreas de la organización, cercanos a Kalanick, no tenían por qué rendir cuentas de sus
actos.
-----
5
: Durante las investigaciones en curso varios trabajadores como Susan Fowler, indicaron que en múltiples
oportunidades había presentado reclamos a la gerencia de recursos humanos sobre sus problemas. Señalaron que
a menudo los ignoraban, con lo que quedaban completamente desamparados frente a los abusos. Ella y otros
empleados dijeron que Recursos Humanos a menudo justificaba estos actos. En una oportunidad, comentó
Fowler, me señalaron claramente: “sería bueno recordarte que los indicadores de crecimiento en ventas y
eficiencia operacional para todos los empleados eran los dos indicadores de gestión que contaban. La compañía
te lo deja claro desde un principio. Esto es Uber.”
Con la salida de Kalanick como CEO, el directorio se ve ahora en la necesidad de tomar medidas respecto a lo
sucedido y disminuir las posibilidades de que estos acontecimientos se repitan en el futuro. El directorio se daba
cuenta que los resultados financieros no lo eran todo y ahora estaba preocupado por la sustentabilidad de los
números que mostraba Uber, Para ello, como asesor del directorio a Ud. se le pide que responda las siguientes
preguntas:
PREGUNTAS
1. Indique y describa cuáles son las tres principales prácticas de gestión de personas que llevaron a la creación
de la cultura de trabajo que se ha desarrollado transversalmente en la empresa Uber.
2. Explique ¿cómo transformaría la cultura de Uber para hacer de esta una empresa más sostenible? Describa
las tres principales prácticas de gestión de personas que usted implementaría para lograr el objetivo de
sustentabilidad señalado. |
-----
, " 6
. PREGUNTA N* 3
Usted es una joven egresada de nuestra Facultad y como resultado de un emprendimiento, ha logrado construir .
la empresa “Vaya Seguro” S.A., dedicada al negocio de los estacionamientos en el sector del desierto florido,
cerca de Copiapó, empresa que felizmente ha alcanzado muy buenos resultados financieros desde el momento
de su creación. En este momento, usted es la dueña del 100% de las acciones de la empresa.
Se sabe que el único activo que en este momento mantiene la empresa “Vaya Seguro” S.A., valorado a costo
histórico en su contabilidad, es un terreno por $100.000, El siguiente es el balance de la contabilidad financiera
de la empresa, “Vaya Seguro” S.A, en el día de hoy 31 de diciembre de 2017.
Activos $ Pasivos y Patrimonio $
Terreno 100.000 Deuda Bancaria 40.000
Patrimonio
Capital (100 acciones) 60.000 .
Total de Activos $ 100.000 Total Pasivos + Patrimonio $ 100,000
La única deuda vigente de la empresa al 31/12/17, es la Deuda Bancaria de $40.000, la que está pactada en
condiciones de mercado a una tasa de interés anual de un 5%. Se sabe además que, si al final de cada año la
empresa paga al banco los intereses que dicha deuda genera, su plazo se puede extender indefinidamente sin
necesidad de amortizaciones.
: Adicionalmente, se sabe que el valor esperado del Flujo de Caja Operacional Neto Anual (Ingresos de Caja
Operacionales anuales menos Egresos de Caja Operacionales anuales) de Vaya Seguro S.A., es de $10.500.
Todos los flujos de caja se generan y se pagan el último día de cada año y se espera que ellos se produzcan
indefinidamente, a partir del año 2018, sin necesidad de reinversiones. Así entonces, lo que se espera es que
el flujo de caja de $10.500, se produzca de manera perpetua.
Si bien, como se ha dicho, la empresa ha logrado muy buenos resultados en su gestión a partir del momento
de su creación, usted como dueña de “Vaya Seguro” S.A., ha decidido vender el 100% de sus acciones, de
modo de poder contar con los recursos que le permitan el desarrollo de nuevas ideas.
Conteste las preguntas que se le formulan a continuación, mostrando todos los cálculos necesarios en los
cuales se fundamentan sus respuestas. En todos los casos suponga que no hay inflación ni impuestos.
PREGUNTAS
1. En esta primera pregunta, suponga que “Vaya Seguro” S.A. opera en un Mercado de Capitales Perfecto
(MCP), y que bajo estas condiciones la tasa de retorno anual exigida por los accionistas de la empresa fuera
de 10,625% (Nota: en sus cómputos, este porcentaje trabájelo con sus tres decimales). ¿Cuál es la tasa de
costo de capital que “Vaya Seguro” S.A. debiera utilizar en la evaluación financiera de un nuevo proyecto
-----
? 7
, de inversión, que consistiría en una expansión de su negocio actual, es decir en una expansión del negocio
de estacionamientos en la zona en la que ella actualmente opera?
2. En esta segunda pregunta, dejaremos de lado el supuesto de mercado de capitales perfecto. Suponga ahora,
que dado que la empresa “Vaya Seguro” S.A., se encuentra en una zona que el gobierno quiere desarrollar
con nuevas inversiones, el Estado le ofrece a la compañía un subsidio a la tasa de interés de la deuda, que
consiste en que, a partir de este momento (31/12/17), la deuda de $40.000 que la empresa tiene con el
Banco, dejaría de devengar una tasa de interés anual del 5% y pasaría a devengar una tasa de interés anual
del 3% anual, manteniendo las condiciones originales de dicha deuda (plazo, forma de pago, etc.). Suponga |
]
también que, en este nuevo contexto de un mercado de capitales con imperfecciones, el costo de capital |
promedio ponderado de “Vaya Seguro” S.A., fuese de un 7,5% anual.
¿Cuál sería ahora, el máximo precio que un inversionista, que cuenta con la información anterior, debiera :
estar dispuesto a pagar por una acción de “Vaya Seguro” S.A, ese día 31/12/17?
|
3. En esta tercera pregunta, seguimos trabajando en un escenario en que el mercado de capitales no es perfecto |
y en el cual se mantienen las condiciones de la pregunta 2 anterior. ¿Cuál sería ahora (dada la.tasa de interés |
con subsidio de la deuda y suponiendo que el nuevo costo de capital de la empresa es de un 7,5% anual),
la tasa de retorno o rentabilidad anual que exigiría un potencial accionista a su inversión en “Vaya Seguro”
S.A?
Notas para todas las preguntas:
e Trabaje los porcentajes con dos decimales XX, Y Y% :
e Si bien se espera que, salvo que expresamente se indique otra cosa, los porcentajes se trabajen con 2
decimales (XX, Y Y%), para entregar los valores de sus respuestas, hágalo usando números enteros.
e Suponga que el mercado espera que las tasas que se han indicado, se mantengan constantes en el largo
plazo.
-----
8
. PREGUNTA N” 4
Unilever en la mira de 3G Capital '
Si la fusión hubiera resultado, habría sido la segunda empresa de alimentos más grande del mundo, solo superada
por Nestlé. Por un lado estaba Unilever y por el otro los brasileños de la firma de inversión privada 3G Capital
en alianza con el millonario Warren Buffett.
Unilever es una compañía anglo - holandesa dueña de marcas líderes en diferentes industrias. Sólo por nombrar
algunas: Omo y Drive en el mercado de los detergentes; Dove en higiene y cuidado personal; Bresler en el
mercado de los helados, que además es el mayor fabricante de helados del mundo; Hellmann”s en mayonesas,
y Knorr en sopas y condimentos. A éstas, hay que sumar wna gran variedad de otras marcas que lideran sus
respectivas industrias en Estados Unidos y en otros países del mundo.
La compañía 3G Capital es un fondo de inversión privado con sede en Brasil, que a través de audaces
adquisiciones hoy controla empresas muy importantes en diferentes industrias como Lojas Americanas, Kraft
Heinz, Burger King y el imperio cervecero AB Inbev con marcas como Miller.
Fue a mediados de febrero de este año, cuando 3G Capital en alianza con Warren Buffett hicieron llegar una
oferta al directorio de Unilever de US$50 por acción (un premio de 18% sobre el precio de mercado), para
fusionar ambas compañías. La oferta, que totalizaba US$143 billones de dólares, fue rechazada — en palabras de
Paul Polman, el Gerente General de Unilever — “por no tener justificación financiera ni estratégica”. Los
potenciales compradores decidieron “retirar amigablemente” su oferta, dada la hostilidad del directorio de
Unilever y las críticas desde el ámbito político.
Dos visiones en disputa
“Lo que estaba en juego no era meramente una operación bursátil, sino que dos visiones empresariales muy
diferentes” señalaba Paul Polman.
Paul Polman es conocido por haber priorizado la responsabilidad social empresarial (RSE) y la sustentabilidad
de los resultados en los negocios de la firma anglo-holandesa realizando importantes inversiones para el cuidado
del medio ambiente y las relaciones comunitarias con clientes y con sus stakeholders en general. De hecho, en
un elogioso artículo en la revista Harvard Business Review, hace un par de años lo bautizaron como el “Capitán
Planeta” del sector empresarial por su estrategia de crecimiento sostenible, orientada entre otras medidas de
responsabilidad social empresarial, a reducir la huella de carbono y mejorar el impacto social en las comunidades
a través del “Plan de Sustentabilidad de Unilever”. Todas estas medidas han posibilitado a Unilever cobrar
precios levemente superiores a los de su competencia. .
La visión de Buffett y sus socios de 3G Capital, por su parte, era muy distinta. Ellos eran conocidos por la
aplicación de eficiencia operacional y la búsqueda de productividades no logradas por las empresas. Luego de
un análisis detallado de los principales procesos de la cadena de valor, estimaban costos según benchmarks (o
estándares de referencia) reconocidos. Sin cambiar necesariamente de estrategia (diferenciación o costos), e
independientemente de la estrategia con que compitiera la compañía, se establecían brechas de costos y se
formulaban planes de reducción y de eficiencia de manera de llevar a la compañía a niveles comparables con
los principales competidores de referencia, incluso muchas veces superándolos y estableciendo nuevos
estándares en la industria. A modo de ejemplo, hace algún tiempo, Buffett y 3G generaron la fusión por US$ 55
billones de dólares entre Heinz y Kraft, prometiendo rebajas de US$1.500 millones en los costos anuales antes
de 2017. Previo a esta fusión, el flujo de caja operacional de la compafiía bordeaba el 20% de los ingresos. Al
poco tiempo de efectuada la fusión, el nuevo flujo de caja operacional combinado superaba el 35% de los
ingresos combinados, logrando rebajas efectivas de costos mayores a los US$ 1.800 millones, un 20% más de
lo que inicialmente se había estimado, :
-----
: 9
: Reacciones
Sobre lo que se esperaba, el precio de la acción de Unilever subió 28% - a un nivel record - cuando se conoció
la oferta de 3G y Buffett, y cayó posteriormente en un 10% cuando ésta fue rechazada.! Pero las cosas no
terminaron ahí.
Ante la presión de los accionistas, Polman anunció que la frustrada fusión y las motivaciones que le dieron
origen en febrero recién pasado, “subrayaban la necesidad de capturar el valor que vemos en Unilever, razón
por la cual se efectuaria una profunda revisión estratégica de los negocios y de los procesos de la compañía,
de manera de capturar eficiencias que hoy en día están al alcance de la empresa”. De esta forma, Polman
estructuró un ambicioso plan de recortes de gastos prescindibles, unido al rediseño de procesos y a importantes
mejoras en la productividad, de manera de elevar sustancialmente los niveles de caja operacional generada. Y
aparentemente los números le daban la razón a Polman, ya que en un indicador crucial, como es el costo de
ventas, un competidor directo de Unilever, como Kraft, mostraba un nivel que era la mitad del costo de ventas
que exhibía el negocio comparable en Unilever.
Los cálculos de 3G y Buffett eran auspiciosos. Ellos estimaban que reduciendo los costos de ventas de Unileyer
en un tercio, Kraft pagaba el precio de adquisición ofrecido por Unilever. Con estos números, medios británicos
especulaban que 3G y Buffett podrían volver a la carga en seis meses más, dada la legislación sobre Fusiones y
Adquisiciones, y los altos diferenciales de márgenes existentes entre las compañías.
PREGUNTAS
1. Tal como se expone en el caso, Paul Polman, Gerente General de Unilever, señalaba que el fracaso de la
oferta de 3G y Buffett se explicaba "por no tener justificación financiera ni estratégica". ¿Le parece
correcto este comentario toda vez que el precio de la acción aumenta en un 28% conocida la posible fusión,
y luego baja sólo un 10% cuando se anuncia su fracaso? Sea especifico señalando dos posible razones
concretas que pueden ayudar a fundamentar su respuesta.
2. Un destacado analista de los sectores en donde compite Unilever escribió en una columna de opinión: "el
nuevo plan que Paul Polman pretende implementar (contenido en el penúltimo párrafo del Caso), viene a
complementar lo que hasta ahora ha venido realizando Unilever, y bajo ninguna circunstancia puede verse
como algo contradictorio o como una visión diferente en relación con lo que ha hecho la empresa hasta
ahora". Sin embargo, Polman opina que son "dos visiones de negocio muy diferentes”. ¿Quién tiene la
razón: Polman o el analista? ¿Por qué? (Ayuda: en su respuesta no olvide cuál es el verdadero propósito de
una estrategia competitiva para una empresa).
1 Por ejemplo, si el precio de la acción de Unilever era de $100 antes del anuncio de Ja potencial fusión, éste subió a
$128 con el anuncio y posteriormente cayó a $ 115,2 (un 10% menos de $128) cuando la fusión fue rechazada.
-----
10
. PREGUNTA N* 5
: Aunque apenas representan el 1% del total de refrescos que se comercializan en Chile, las bebidas isotónicas
mantienen un fuerte crecimiento en el país según datos de AB Chile, entidad gremial que reúrie a los productores
e importadores de alimentos y bebidas analcohólicas. Entre enero y septiembre de 2016 se vendieron 19,9
millones de litros de este tipo de bebidas, mostrando un crecimiento de 33,1% con respecto al año anterior. En
los últimos 10 años, la penetración de estas bebidas rehidratantes ha subido de 2% a 19,9%. En Chile existen 5
competidores en la categoría de bebidas isotónicas: Gatorade, Powerade, Vitamin 02, Sprim Sport y Zuko Go.
La marca Gatorade, elaborada y embotellada por CCU S.A., es líder de la categoría con un 80% de participación
de mercado,
Los ejecutivos de Gatorade encargan a vna empresa de investigación de mercado un estudio de Análisis
Conjunto (conjoint analysis) con el objeto de conocer los cambios que podrían estar teniendo los consumidores
en relación a las preferencias por bebidas isotónicas.
El estudio realizado por la empresa de investigación consideró los atributos y niveles que se presentan en el
Cuadro 1 de la página siguiente: Light / Regular, Precio, Tapa, Marca y Sabor. El estudio se realizó en base a la
metodología de perfil completo (o método indirecto) en la cual un determinado número de perfiles es evaluado
por cada encuestado en una muestra representativa, en este caso de tamaño n = 543, del segmento objetivo.
Algunos resultados del estudio se exhiben, en la página siguiente, en el Cuadro 2 y el Cuadro 3. El Cuadro 2
presenta la importancia de cada atributo calculada en base a la diferencia máxima de utilidades en cada atributo
y escalada para que sume 100, por lo cual se puede leer como porcentaje de importancia. En la primera columna
de este Cuadro se presenta la importancia para el total de la muestra mientras que en las columnas siguientes se
exhiben los resultados desagregados por género, edad, grupo socio económico y si es consumidor de la categoría.
En la última fila del Cuadro 2 se presenta el tamaño de la muestra correspondiente a cada segmento. Finalmente,
en el Cuadro 3 se presentan las utilidades (o preferencias) de un consumidor particular.
PREGUNTAS
a) Suponga que al momento de la presentación de los resultados del estudio, uno de los ejecutivos de Gatorade
se da cuenta y hace notar que en el estudio no está presente el atributo Formato o Contenido (500 cc, 600
cc, 750 cc, 1.000 cc, etc...). Si el atributo Formato o Contenido fuese efectivamente relevante en las
preferencias de los consumidores, ¿podría esto sesgar o influir de manera significativa en los análisis de los
resultados del estudio? Fundamente su respuesta.
b) De los resultados que se presentan en el Cuadro 2, se desprende que los consumidores son homogéneos en
sus preferencias respecto de este tipo de bebidas, con lo cual no se podrían obtener Jas ganancias que produce
una segmentación de los consumidores ¿Está usted de acuerdo con esta afirmación? Justifique su respuesta.
€) ¿Cuánto vale, en valor monetario (pesos), la marca Gatorade para el consumidor cuyas utilidades se
presentan en el Cuadro 3? Explique, mostrando los cálculos correspondientes.
-----
: 11
. Cuadro 1 : Atributos y Niveles
A as le Nivel ai
Lighi/Regular | Lihn | Regular |
[Precio [$800 $900 $1.00
[Tapa [Deportiva [Pla | |
| Marca | Gatorade | Powerade [| ____|
Cuadro 2: Importancia de Atributos Según Distinto Tipo de Variables (en porcentaje)
E II CTO TN
, tributos E “Total | Hombre Muler Años Años 200. 2 SD Consumidores - Consumidores
Light/Regular | 7% 7% 6% 7% 1% 6% 6% 7% 7% 6%
Precio 10% 10% 10% 10% 10% 10% 10% 10% 10% 14%
Tapa 17% 16% 18% 16% 19% 18% 19% 17% 17% 11%
Marca 27% 21% 28% 27% 27% 26% 28% 27% 27% 31%
Sabor 39% 40% 38% 40% 37% 40% 37% 39% 39% 38%
Total 100% 100% 100% | 100% 100% | 100% 100% 100% 100% 100%
n (Muestra 303 240 | 277 266 181 182 180 533 10
Cuadro 3: Utilidades de un Consumidor (*) :
Apto o Niveles y Utilidadés
Lisht/Regular Light 20 Regalar =0 | |
$800 = 10 $900 =0 $1.000 =-5
Praga] Depomiva= E | Prma=o
[vasca | Gorade=o | Powerade==10 |]
(*) El estadígrafo R? en la estimación es 0,96 y la utilidad del producto (perfil) base es 25.
-----
| : : 2 |
PREGUNTA N” 6
El pasado mes de junio (2017) el Banco Santander adquirió por un simbólico euro (1 EUR) la propiedad del
Banco Popular en España, El Banco Popular había experimentado fuertes pérdidas por préstamos inmobiliarios
a partir de la crisis europea desatada el 2008. El Banco Popular era el sexto banco más importante de España,
en términos de colocaciones (préstamos), y había sido una buena inversión para sus accionistas hasta antes de
la venta al Banco Santander, la cual fue, en todo menos en nombre, una quiebra,
El objetivo de esta pregunta es entender las decisiones de financiamiento de una institución con una
: probabilidad de quiebra no despreciable en el corto plazo como puede haber sido el Banco Popular a comienzos
del año 2017. A continuación se presenta un ejemplo numérico muy sencillo, pero que tiene como objetivo
capturar los principales elementos presentes en un caso como el del Banco Popular. Suponga que no hay
impuestos corporativos y que el mercado de capitales es eficiente en el sentido de que los precios entregan una
compensación adecuada por el riesgo contenido en los flujos futuros.
Sitúese al día 31 de diciembre de 2016 evaluando la situación financiera del banco. Suponga que la cartera de
préstamos del Banco Popular puede entregar flujos (todos en millones de euros) de $120 o de $60 en 6 meses
más (30 de junio de 2017), dependiendo de cómo evolucione la situación económica general de España. Usted
estima que la probabilidad de ocurrencia de cada escenario es de 50%. La tasa de retorno esperada (o tasa de
descuento exigida) para igual periodo (6 meses) de esta cartera de préstamos es de Ra = 10%. En términos de
sus pasivos, el banco está financiado con una cartera de deuda (una combinación de depósitos, bonos y otros
instrumentos de deuda) con valor de carátula (o pago total prometido a futuro) de $80 y una tasa de retorno
esperado (o tasa de descuento exigida) de Rd = 2%, todo a un plazo de 6 meses. El resto del financiamiento
del Banco Popular corresponde a capital accionario.
Para las preguntas que se le formulan a continuación, suponga que las tasas de retorno exigidas a los activos y
a la deuda del banco no cambian y que la información sobre los pagos futuros es sabida por todo el mercado,
incluyendo acreedores y accionistas. En cada pregunta, fundamente sus respuestas mostrando todos los
cálculos que sean necesarios.
PREGUNTAS
1) Con la información que se le ha proporcionado, ¿cuánto vale el capital accionario del Banco Popular al
31-12-2016? ¿Qué tasa de retorno esperada a 6 meses tiene dicho capital accionario?
2) Un director del Banco Popular sugiere en la junta de cierre de año que, para aprovechar mejor las bajas
tasas de interés que se observan en Europa, sería más conveniente aumentar el financiamiento con deuda,
En concreto, el director propone aumentar la deuda del banco hasta un valor (de carátula) de $90 y
recomprar acciones con lo obtenido sin afectar la cartera de préstamos. Según el director, esto permitiría
aumentar el valor económico total del banco (deuda + capital accionario). ¿Qué opina usted al respecto?
¿Cambia la riqueza de los accionistas con la operación propuesta por el director? ¿Cambia el retorno
esperado del capital accionario del banco?
3) Suponga ahora que, el 1? de enero 2017, las perspectivas sobre la cartera de préstamos del banco se
deterioran sorpresivamente de tal manera que el flujo en el escenario positivo 6 meses después pasa a ser
-----
€ 13
a solo $91. En el escenario negativo el flujo sigue siendo $60. Respecto de la situación vigente al 31-12-
2016 ¿qué ocurre con el valor del capital accionario del banco si la deuda tiene un valor carátula de $80? |
4) Un analista de mercado dice que el valor del capital accionario del Banco Popular, después de conocerse
el deterioro de la cartera de préstamos el 1* de enero 2017, está excesivamente castigado porque no
considera el valor de la opción de los préstamos en carpeta (préstamos que el banco podría hacer pero que
todavía no se han materializado). Argumenta que el banco podría fácilmente, con un aporte (aumento) de
capital de $6, aumentar su cartera de colocaciones haciendo préstamos de igual riesgo que los actuales y
que darían flujos, 6 meses después, de $11 en el escenario positivo y $10 en el escenario negativo. El
mismo analista opina que, frente a estos buenos proyectos en carpeta, un aumento de capital es solo
frenado por la inoperancia de los actuales accionistas controladores, ¿Está Ud. de acuerdo con la
afirmación del analista? Fundamente su respuesta.
-----


# Examen de grado · Examen-Grado-Administracion-Enero-2024

Fuente: examen anterior

[pág. 1]
EXAMEN DE GRADO
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
 alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
 hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
 hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
 que los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
 realidad de las empresas que allí se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
 dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
 misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente a la Profesora Marta Del Sante, Presidente de la Comisión
 de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
 cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
 condiciones, la Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala ni relojes inteligentes, los que
 deberán estar apagados y guardados en las mochilas adelante.
12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
 examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
 identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
 como “borrador”, esas hojas no se deben entregar con las respuestas.
Fecha : 26 de enero de 2024
Duración : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá la Profesora
 Marta Del Sante, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 y
 11:00 hrs. (aprox.).

[pág. 2]
2
PREGUNTA Nº1
Sin duda, la electromovilidad llegó para quedarse en nuestro país. A nivel gubernamental se están acordando
diversas acciones y estrategias para sustituir los autos a combustión por alternativas más limpias. Pero no sólo a
nivel de políticas públicas están impulsándose estas mejoras, las personas también están tomando mayor conciencia
de la relevancia de hacer un cambio en pro de una mejor calidad de vida. Lo anterior se refleja en el alza que ha
tenido el uso de bicicletas eléctricas, que en 2023 alcanzaron ventas de más de cinco mil unidades, lo que implicó
un crecimiento de aproximadamente un 25% con respecto al 2022.
Este crecimiento del mercado de bicicletas eléctricas ha llevado a una mejora en la infraestructura para ciclistas en
algunas ciudades de nuestro país. Además, se están implementando más ciclovías para bicicletas y estaciones de
carga, lo que favorece el uso de este medio de transporte. Asimismo, se ha visto una mayor diversidad de marcas y
modelos de bicicletas eléctricas tanto locales como internacionales en el mercado que ofrecen opciones para
diferentes necesidades y preferencias. Así también, los precios de las bicicletas se encuentran en un rango que va
desde los $500,000 las más básicas hasta los casi $7,500,000 las más sofisticadas.
Los principales canales de distribución de bicicletas eléctricas pueden variar según la ubicación y el mercado
específico, pero en general, los más comunes incluyen: a) Tiendas especializadas en bicicletas, las cuales se
focalizan en la venta de bicicletas y productos relacionados, como accesorios y ropa para ciclistas; b) Cadenas de
tiendas de deportes, las cuales venden una variedad de productos deportivos, incluyendo bicicletas y productos
relacionados; c) Tiendas online y marketplaces, las cuales incluyen distintos tipos de plataformas de comercio
electrónico que permiten a los consumidores comprar bicicletas y accesorios en línea y recibirlos en sus hogares
(ej: Falabella.com, Mercado Libre, Ripley.com, etc.); d) Tiendas de departamentos y grandes cadenas de
supermercados, las cuales tienen áreas dedicadas a artículos deportivos, donde también se pueden encontrar
bicicletas; y e) Venta directa del fabricante o D2C, los cuales se caracterizan por ser el fabricante y/o marca de la
bicicleta quien le vende directamente a los consumidores a través de sus propios canales online o tiendas físicas.
Cannondale es una marca muy reconocida en el mercado y fabrica una variedad de bicicletas, incluyendo bicicletas
eléctricas. Estas son conocidas por su alta calidad y rendimiento. Hasta ahora, la empresa se ha focalizado en las
bicicletas eléctricas de alta gama y al mercado que valora el tiempo de duración de la batería y la capacidad del
motor por sobre el precio. Actualmente, la marca comercializa los modelos de bicicletas eléctricas Moterra Neo
Carbón 1 y Moterra Neo Carbón 2 a un precio de $6,499,990 y $5,499,990 respectivamente. Los canales de
distribución de Cannondale para sus bicicletas eléctricas y bicicletas incluyen sólo su página web, locales propios
y algunos distribuidores exclusivos de la marca en nuestro país. La página web y los locales propios de la marca
representaban el 60% de las ventas y el resto se lograba a través de los distribuidores exclusivos que sólo venden
bicicletas Cannondale.
El Gerente General de Cannondale acaba de recibir una invitación de parte de la cadena Falabella para que la marca
comience a comercializar estos dos modelos de bicicletas eléctricas a través de su marketplace.
Falabella es una cadena de tiendas de retail con presencia en varios países de América Latina. Originalmente
comenzó como una tienda de confección, pero con el tiempo se expandió para incluir una amplia gama de productos,
desde ropa y accesorios hasta electrodomésticos, muebles, artículos para el hogar y artículos deportivos. Esta cadena
tiene como principal segmento objetivo los sectores de clase media y media alta de nuestro país y se caracteriza por
ofrecer una gran cantidad de marcas de reconocidos proveedores en múltiples categorías, así como así también una
importante y creciente oferta de marcas propias en prácticamente todas las categorías que ofrece. Además, Falabella
ofrece un servicio de financiamiento a través de su propio banco y de su tarjeta CMR, la cual ofrece la posibilidad
a los clientes de comprar productos a crédito.
Por su parte el marketplace de Falabella es una plataforma digital que reúne a varios vendedores y una gran gama
de categorías y productos. El marketplace actúa como intermediario en el proceso de compraventa, con distintas
tarifas o comisiones para los vendedores que deciden comercializar sus productos a través de este. Los compradores
online pueden acceder al marketplace de Falabella para consultar el catálogo de varias marcas, realizar búsquedas
por tipo de producto, precio y multitud de palabras claves. En este marketplace los vendedores pueden publicar
pagando una comisión sobre el valor del producto vendido, que incluye el costo de utilizar el procesador de pago,
y una mejor ubicación en los listados de búsqueda. Por su parte, el marketplace de Falabella establece la ubicación
de los productos de los vendedores en las distintas secciones de su plataforma y les pide una foto estándar a cada
uno de ellos de los distintos modelos ofrecidos. El precio público del producto es establecido por los vendedores y
no por el marketplace.

[pág. 3]
3
El Gerente General de Cannondale le pidió al Gerente de Marketing y al Gerente de Ventas de la empresa su
recomendación en cuanto a si debían aceptar la invitación de Falabella para comercializar sus dos modelos de
bicicletas eléctricas en el marketplace de la cadena.
El Gerente de Marketing de Cannondale pensaba que no deberían comercializar las bicicletas eléctricas a través este
canal. Sus principales preocupaciones eran la posibilidad de no cumplir con los requerimientos de entrega y plazo
de los productos que los clientes ordenaban a través de esta plataforma. Asimismo, le preocupaban los costos que
implicaría vender a través de este marketplace, desde la publicidad que debían pagar, hasta el mayor costo financiero
que implicaba vender a través de este portal, ya que Falabella se demoraba en promedio 45-60 días en hacer las
liquidaciones de las compras de sus clientes a los proveedores. De acuerdo a sus cálculos el margen operacional por
comercializar en este canal era un 15% menor comparado al logrado en sus actuales canales. El Gerente de
Marketing señalaba que estos modelos de bicicletas debían seguir siendo comercializado a través de los actuales
canales de la marca.
Por su parte, el Gerente de Ventas pensaba que entrar al marketplace de Falabella era una gran oportunidad para la
marca. Dentro de las fortalezas que destacaba de este marketplace era el potencial número de clientes que podía
atraer a la marca que hoy era inalcanzable con los canales con que contaba. El marketplace de Falabella era el líder
en cuanto a venta de comercio electrónico en el país alcanzando un 34% de las ventas online (Mercado Libre
alcanzaba sólo el 24%). Además, señalaba que al estar en el marketplace líder del mercado le daba un mayor
reconocimiento de marca y la posibilidad de acceder a un nuevo segmento de mercado para la marca. Asimismo,
mostraba que más del 50% de los clientes que compran online iniciaban su proceso de compra a través de un
marketplace. También señalaba que existía una gran cantidad de marcas con diferentes modelos de bicicletas
eléctricas y con un amplio rango de precios. De hecho, señalaba que existían más de cuatro marcas que ya
comercializaban sus modelos de bicicletas eléctricas en el marketplace de Falabella a precios similares a la de los
modelos de Cannodale. Finalmente, señalaba que no existían riesgos en cuanto a la fijación de precios de las
bicicletas en al marketplace, ya que estos eran fijados por Cannondale lo que permitía alinearlo con los del resto de
sus canales de distribución.
Preguntas
a) De acuerdo a la información señalada en el caso, señale y explique claramente cuatro factores que debiera
 considerar el Gerente General de Cannondale para tomar la decisión de entrar a comercializar sus modelos de
 bicicletas eléctricas en el marketplace de Falabella.
b) De acuerdo a la información entregada en el caso, señale y explique claramente los tres principales riesgos para
 Cannodale, desde el punto de vista de su estrategia de marca, de comercializar sus modelos de bicicletas
 eléctricas a través del marketplace de Falabella.

[pág. 4]
4
PREGUNTA Nº2
Desde su fundación en 2017, InnovarTech Chile se ha destacado como un polo de desarrollo de la innovación en
el país. La compañía comenzó como una pequeña startup con una estrategia de negocios especializada y a la
vanguardia en soluciones de inteligencia artificial (IA) que facilitan la capacidad predictiva de sus clientes mineros
en aspectos como la detección de las áreas óptimas para el desarrollo de su explotación, la prevención de riesgos
de accidentabilidad o la reducción de costos operacionales. Su estrategia competitiva está orientada al escalamiento
de sus operaciones de manera de proveer en todo el mundo, a partir de su desarrollo de plataformas tecnológicas
con una base de productos comunes, soluciones únicas y customizadas a los diferentes clientes y sus necesidades
de la industria minera.
El modelo de innovación de InnovarTech se centra en 3 pilares, los que son clave para el logro de sus objetivos de
negocio en cuanto a liderar el mercado de soluciones avanzadas de IA para la industria minera. Ellos son:
• Desarrollamos soluciones de IA que atiendan las necesidades actuales y futuras del mercado. Debemos ser líderes
 de innovación en nuestras soluciones para la industria a escala mundial.
• La Innovación no es un acto individual sino un proceso colectivo y colaborativo que se enriquece con las
 distintas perspectivas de todas nuestras gerencias. Por ello, debemos promover una amplia diversidad de perfiles
 en nuestra organización.
• Somos una sola marca y una única empresa y debemos proyectarnos al mercado como una única empresa siempre
 coherente con la calidad de nuestras soluciones, la confiabilidad de nuestros productos, así como igualdad de
 oportunidades, desarrollo y trato respetuoso para todos.
Si bien la empresa había crecido durante la pandemia, alcanzando ingresos de US$80 millones en 2021 que incluye
sus ventas no solo en Chile, sino que también en mercados internacionales como Perú y Brasil, en los últimos 2
años los números mostraban una preocupante caída en las ventas y márgenes, así como en su capacidad para innovar
y de captar y mantener clientes. InnovarTech contaba a fines de 2023 con una dotación de 350 empleados con un
31% de mujeres y 69% de hombres de 11 nacionalidades y culturas diferentes. Sus edades varían entre 23 y 62
años al igual que su formación, ya que su personal posee desde títulos técnicos hasta doctorados, existiendo además
una amplia gama de experiencias profesionales en una multiplicidad de industrias. El personal se selecciona de
acuerdo a criterios técnicos, apuntando también a su diversidad. Al ser una empresa de soluciones de software el
énfasis de la capacitación está puesto en los conocimientos y habilidades técnicas, al igual que el desarrollo de
quienes se destacan en la compañía, cuya promoción depende de su desempeño individual y el mejoramiento
sostenido de sus habilidades técnicas. Por su parte, los incentivos variables por desempeño para el personal están
asociados al logro de objetivos definidos para la gerencia en la que cada cual se desempeña.
La estructura organizacional de InnovarTech sigue una lógica funcional. Así, el Directorio y la Gerencia General
se encargan de establecer la visión y estrategia de la empresa, supervisar todas las operaciones y asegurar el
cumplimiento de los objetivos corporativos. Suelen tener opiniones muy homogéneas. Su composición es
completamente masculina, con personas experimentadas en diversas industrias y países
Por su parte, la Gerencia de Marketing y Ventas está a cargo de desarrollar estrategias comerciales, gestionar
campañas publicitarias y supervisar el equipo de ventas para maximizar los ingresos. Es un equipo joven,
culturalmente muy diverso, que ha logrado éxitos notables en ciertas campañas. Sin embargo, también ha tenido
resultados pobres al promover soluciones en empresas más tradicionales poco orientadas al uso de nuevas
tecnologías. Un ejemplo de ello era la gestión de María. Ella es una especialista en marketing, una influencer en
redes sociales, particularmente en la promoción de nuevas soluciones que Innovar Tech lanzaba al mercado. Si
bien María tenía gran tracción comercial en el segmento de sus clientes mineros más jóvenes, no siempre lograba
buenos resultados con empresas más tradicionales en cuanto a su dominio de la tecnología.
A su vez, la Gerencia de Investigación y Desarrollo genera las primeras ideas y pruebas piloto de las nuevas
soluciones, apuntando a mantener a la empresa a la vanguardia tecnológica. En las posiciones clave de esta área
trabajan ingenieros, hombres, reclutados de las dos mejores escuelas de ingeniería de Chile. Pedro, un ingeniero de
software de Brasil con un historial de excelencia técnica, era la excepción a esta regla ya que fue contratado en esta
Gerencia. Pedro, de hecho, comentaba las dificultades que había encontrado para adaptarse a su nuevo entorno
laboral.
Por último, la Gerencia de Personas estaba compuesta en un 95% por mujeres de diversas edades, currículums
profesionales y nacionalidades, casi todas provenientes de América Latina. Esta área tiene la responsabilidad sobre

[pág. 5]
5
la gestión del talento; su atracción y selección, capacitación, desarrollo y retribución de quienes conforman
InnovarTech. En sus procesos, esta Gerencia pone énfasis en promover un alto grado de diversidad cultural de los
trabajadores de la empresa, de manera de hacer creíble la promesa de igualdad de oportunidades y desarrollo y con
ello potenciar la innovación en la compañía. No siempre, sin embargo, se lograba este objetivo. De hecho, Li, una
ejecutiva de selección de personal, de origen chino, contratada hace un año, comentaba en diversas reuniones que
se sentía aislada debido a barreras idiomáticas y su poca costumbre a las largas reuniones de trabajo que sostenía
su equipo versus instancias breves y eficientes a las que ella estaba acostumbrada. Esto afectaba su participación
en el equipo. Así, en esta Gerencia y en otras, el clima laboral era irregular. Algunas gerencias mostraban muy
buenos índices y otras, en cambio, mucho conflicto.
Preguntas:
1. Frente a los malos resultados del último tiempo, Ricardo Barrios uno de los gerentes de la empresa, en la reunión
 de cierre de resultados de 2023 comentaba: “tenemos demasiada diversidad en nuestro personal y eso dificulta
 la toma de decisiones para la innovación y el logro de nuestros objetivos estratégicos. Como experto en gestión
 de personas y cultura organizacional y considerando el rol de la diversidad en la adecuada ejecución de la
 estrategia de InnovarTech, se le pide que explique: ¿Cuál es el problema con la diversidad en InnovarTech? ¿El
 problema es el que señala el ejecutivo? ¿O es otro el problema? Justifique de manera precisa su respuesta.
2. Otra ejecutiva de InnovarTech, Sandra Cabrera, señalaba en la misma reunión de cierre de 2023: “la diversidad
 nos favorece, pero está mal gestionada.” A usted como analista se le pide que indique tres iniciativas de gestión
 de personas y cultura organizacional que permitan lograr que la diversidad del personal fortalezca el
 alineamiento de los equipos con los pilares estratégicos y los objetivos de negocio de la empresa. En su respuesta
 señale cómo las prácticas propuestas impactarán positivamente en el alineamiento del personal de la empresa
 con los pilares del modelo de innovación y los objetivos de negocio de la empresa.

[pág. 6]
6
PREGUNTA Nº3
A continuación, se desarrollan de manera breve tres temas o comentarios completamente independientes entre sí.
Usted debe responder lo que se pide en cada uno de ellos en forma independiente, identificando con claridad el tema
o comentario que usted responderá (Comentario N°1, etc.). La ponderación de cada uno de los tres temas o
comentarios que se plantean en esta pregunta del examen no necesariamente es la misma para cada uno de ellos. La
evaluación final de esta pregunta corresponde al resultado de una evaluación global del conjunto de los tres temas
o comentarios que se habrán planteado.
Comentario N°1:
Para el análisis de este primer comentario, en el que se hará referencia a dos empresas que operan en distintos rubros
(industrias), suponga lo siguiente:
 • Ambas empresas venden un solo producto.
 • Las ventas de ambas empresas (P x Q) se comportan de acuerdo a una distribución normal y tienen la
 misma desviación estándar.
 • Debido al alto nivel de competencia en los mercados en que ellas operan, las compañías enfrentan un precio
 que, para todos los efectos prácticos, está “dado”.
 • El nivel de activos (monto en $) que ellas mantienen a través del tiempo se mantiene constante.
Comentario: “Dos empresas para las cuáles se cumplen los supuestos anteriores, son empresas que tienen el mismo
nivel de riesgo operacional, medido como la variabilidad (o desviación estándar) de su resultado operacional, toda
vez que las características de las variables que determinan dicho riesgo son las mismas para ambas”.
Se pide: Entregar en primer lugar su opinión en términos de si usted está “de acuerdo” o “en desacuerdo” con el
comentario y luego fundamentar su opinión.
Comentario N°2:
En la última reunión del directorio de una empresa, el Gerente General comentaba lo siguiente: “hemos evaluado
un nuevo proyecto de inversión, que tiene varios años de duración, calculando su valor actual (presente) neto o
VAN con un resultado ampliamente positivo, con lo cual se estaría creando valor para los dueños de la compañía”.
Al conocer este resultado un director de la empresa preguntó, cuál sería la rentabilidad anual esperada del proyecto,
en el escenario que se dieran exactamente los flujos de caja que se proyectaron al momento de su evaluación. Frente
a esta consulta, el Gerente de Finanzas le comenta al director que dicha rentabilidad anual era la Tasa Interna de
Retorno (TIR) del proyecto.
Se pide: Entregar en primer lugar su opinión en términos de si usted está “de acuerdo” o “en desacuerdo” con el
comentario del Gerente de Finanzas y luego fundamentar su opinión.
Comentario N°3:
Es sabido que, para la valoración de una empresa desde la perspectiva financiera, hay básicamente dos métodos o
metodologías que se usan habitualmente: el primero es el método de los “Flujos de Caja Descontados” y el segundo
el método de los “Múltiplos” o de los “Comparables”.
Estando en una negociación, en la que se tenía como objetivo estimar el precio al que se iba a ofrecer a la venta un
porcentaje del patrimonio de la “Viña Santa Juana” (VSJ), habiendo optado por el camino o metodología de los
“Múltiplos” y respecto de la que se contaba con la siguiente información, se siguió el procedimiento o metodología
que se describe más adelante.

[pág. 7]
7
Información disponible: Se contaba con la siguiente información de dos empresas (viñas) comparables, la “Viña
Santa Francisca” (VSF) y “Viña Santo Tomás” (VST):
 Empresa "Objetivo" "Comparables"
Datos: Viña Santa Juana (VSJ) Viña Santa Francisca (VSF) Viña Santo Tomás (VST)
Precio de M° por Acción ($ por Acción): No se transa en bolsa $14 $18
N° de Acciones: 5.000 21.000 14.000
Caja disponible: $0 $0 $0
Deuda Financiera: $24.000 $32.000 $28.000
EBITDA (estimado próximos 12 meses): $14.500 $32.600 $20.000
Nota: EBITDA = Earnings Before Interests Taxes Depreciation and Amortization
Cuya traducción es: Utilidad Antes de Intereses, Impuestos, Depreciación y Amortización
Las tres empresas sólo tienen activos operacionales y toda su deuda es “Deuda Financiera” (deuda con bancos que
genera intereses de manera explícita).
Resultado y Metodología: Dado lo anterior, el analista cuyo objetivo es el de valorar el patrimonio de la “Viña
Santa Juana”, obtuvo como resultado de dicho valor un monto de $174.000. Preguntado por el procedimiento o
metodología seguido, él lo resumió de la siguiente manera:
 • Sabemos que uno de los múltiplos más usados en el proceso de valoración por “Múltiplos” es el múltiplo
 [Valor de la Empresa/EBITDA]
 • Obtenido este múltiplo para cada una de las dos empresas y tomando luego el promedio simple de ellos, es
 posible calcular que el múltiplo [Valor de la Empresa/EBITDA] promedio para las dos empresas
 comparables de las que disponemos información es de 12 veces
 • Al aplicar este promedio de 12 veces al EBITDA estimado para los próximos 12 meses de la Viña Santa
 Juana, obtenemos que, de acuerdo con este método, la estimación del valor de su patrimonio total es de
 $174.000 (= 12 veces x $14.500)
Se pide: Entregue en primer lugar su opinión en términos de si usted está “de acuerdo” o “en desacuerdo” con el
procedimiento seguido por el analista y luego fundamente su opinión.
Nota: No se pide un análisis del método de valoración usando múltiplos, ni tampoco comentar la poca información
de la que se dispone o las características o sesgos que pueda tener dicha información. Lo que se pide es analizar la
aplicación del método de los múltiplos que en este caso específico está haciendo el analista para estimar el valor
que tiene como objetivo estimar.

[pág. 8]
8
 PREGUNTA Nº4
 Inteligencia artificial y el Sector Bancario en Chile
La Inteligencia Artificial (IA) está desempeñando un papel fundamental en la transformación de la banca chilena. Este
 cambio no sólo ha mejorado la eficiencia y la productividad, sino también ha fortalecido la seguridad de las
 operaciones financieras, además de ofrecer la oportunidad a bancos, fintechs (empresas financieras online) e
 instituciones financieras, de mejorar las experiencias de los clientes y su percepción de valor.
La inteligencia artificial se refiere al desarrollo de sistemas capaces de aprender, planear o resolver problemas de una
forma similar a como lo hacen los humanos. Para que un dispositivo electrónico o software tenga inteligencia artificial
necesita de datos y de algoritmos capaces de tomar decisiones. Los primeros los puede recibir a través de internet,
aplicaciones de Big data o conectándose directamente con otros dispositivos para intercambiar información. Los
segundos, en cambio, son una serie de instrucciones con las que han sido programados para que creen conductas o
patrones según los diferentes datos que reciben. Lo que diferencia a la IA de la digitalización es que no solo automatiza,
sino también, puede mejorar sus propios procesos de forma autónoma, descubrir nuevos segmentos, detectar nuevos
gustos de los clientes, y por tanto generar nuevos productos. Es decir, aprende de las tareas realizadas en el pasado sin la
necesidad de la intervención humana. Esto último se le conoce también como machine learning.
El Sector Bancario y la IA
Es un sector competitivo, de grandes actores, en donde la segmentación y las estrategias comerciales juegan un rol
importante en la forma en como competir. No cabe duda de que la tecnología y la IA han transformado al sector bancario,
han impactado a competidores tradicionales, y han permitido el acceso a la industria a una banca distinta, basada en
internet, que no requiere el que un cliente vaya a una sucursal, ya que posibilita recibir al banco, cotizar productos, recibir
sugerencias, en cualquier lugar en donde estén las personas. Esto ha permitido bancarizar fuertemente a segmentos como
los jóvenes, que muestran menos rasgos de lealtad con una institución en particular, y buscan más la conveniencia, la
facilidad, la agilidad, en comparación con los segmentos tradicionales los cuales tardan más en la adopción de tecnologías
en sus operaciones financieras, ya que privilegian confianza, cobertura y solidez de la institución que está detrás. Quizás
por este motivo es que los bancos tradicionales han intentado incorporar tecnología e IA en el desarrollo de productos,
compitiendo en ciertos segmentos con las Fintech, que es como se les conoce a las empresas financieras basadas
completamente en internet.
Por lo anteriormente expuesto, es que probablemente la IA ha intervenido fuertemente en la industria bancaria chilena.
Los usos y aplicaciones más frecuentes hasta ahora son mejorar la atención al cliente, optimizar los procesos de
aprobación de créditos para prevenir la morosidad, automatizar procesos internos que reduzcan costos, entre otras
aplicaciones. Sin embargo, el verdadero potencial de la IA en la banca chilena se encuentra en la tecnología predictiva,
es decir, la correcta predicción de eventos, respaldada por datos sólidos y accesibles, siendo una herramienta crucial para
la toma de decisiones informadas. Así mismo, importantes aportes tendrá la IA en el conocimiento de clientes y de sus
hábitos, en los modelos de segmentación que se utilicen y en la generación de valor a los clientes. Todo lo anterior puede
verse mejorado con la potencial colaboración entre bancos y fintechs, permitiendo la creación de ecosistemas
interconectados que beneficien a los clientes.
Además de lo anterior, existen otras variadas aplicaciones de la IA en diferentes partes del negocio bancario: en cuanto
al front office (procesos con interacción con clientes), la IA ha permitido mejorar la experiencia del cliente, ofreciendo
servicios más rápidos y personalizados, como asistentes virtuales que recomiendan productos y solucionan dudas como
consultas de saldos. Uno de los aspectos más destacados es poder llegar a segmentos masivos con soluciones
personalizadas. En el middle Office (procesos con impacto en clientes, pero sin interacción), la IA se utiliza en la gestión
de fraudes en transacciones financieras y en la automatización de las tareas que ahorran costos. Finalmente, en el back
office (procesos rutinarios que impactan el costo), la IA aporta eficiencia y precisión en tareas contables, facturación,
gestión de documentos y otras tareas rutinarias, todo lo cual reduce los costos y aumenta la productividad.
Analistas de la industria bancaria proyectan una mayor intensidad en el uso de la IA por las claras ventajas y atributos
que generan en las empresas del sector, en especial en la forma de desarrollar y gestionar clientes. Así mismo es
presumible que con el desarrollo tecnológico se fortalezca la IA en la industria y con ello las ventajas que genera sobre
el sector. Desde luego que en este caso, como otros, los efectos sobre los competidores establecidos serán variables. Por
ejemplo, y como habitualmente ocurre, quienes se muevan primero, más rápido y lo hagan bien, obtendrán la mayor
parte del valor potencial que la IA será capaz de aportar en la industria bancaria.

[pág. 9]
9
BancoEstado y la Inteligencia Artificial
BancoEstado es sinónimo de banca tradicional, una banca basada en la relación con el banco por medio de ejecutivo de
cuenta, en sucursal física y con uso de internet para operaciones puntuales. Es un banco que genera alta confianza en la
población (Banco Estado es una de las instituciones bancarias más confiables de Chile), que llega a todos los habitantes
de nuestro país, que no distingue clase social, ni tipo de trabajo, y que cuenta con clientes muy tradicionales de todas las
edades, quienes se sienten atraídos por la confianza que les genera la institución. En la actualidad Banco Estado tiene
casi 15 millones de clientes en todos los rincones de Chile, quienes confían en la institución, y la adoptan como su banco.
Lo anterior hace que el banco cuente con una gran base de datos de información de clientes, la cual es el resultado de
entregar confianza y cobertura geográfica, a través de contar con sucursales en todo el país y el acceso al sitio web del
banco para realizar ciertas operaciones. El despliegue de BancoEstado a lo largo de todo el país y el gran número de
clientes que posee (gran parte de los habitantes del país), es algo que ningún otro banco puede igualar. Sin perjuicio de
lo anterior cabe destacar que su tamaño a veces le impide moverse con la agilidad que se requiere, y en un mercado
competitivo la velocidad en la respuesta estratégica se aprecia y genera valor.
La misión de BancoEstado es crear soluciones financieras innovadoras, sostenibles e inclusivas para el progreso de los
habitantes en Chile, y su propósito es impulsar un ecosistema financiero innovador, social y sostenible que haga de
Chile un mejor país. En la cuenta pública del 11 de mayo 2023, su presidente dio a conocer las principales cifras e hitos
de la institución durante el 2022 y anunció importantes desafíos para 2023 y los próximos años. En la instancia, el
ejecutivo destacó que el banco está desarrollando un plan de transformación digital, con el que busca adaptarse a los
nuevos desafíos del sector. Se espera que este plan impacte a más de 10 millones de clientes con el objetivo de reducir
el uso de efectivo (dinero) y disminuir la presencialidad en sucursales.
El plan digital y de IA de BancoEstado permitirá digitalizar y automatizar procesos para lograr mantener sus costos,
mientras siguen creciendo las transacciones por los canales digitales y ofreciendo una experiencia personalizada. Para
lograr lo anterior, se han incorporado nuevas herramientas tecnológicas basada en Inteligencia Artificial que permiten
identificar clientes y detectar fraudes. En ese marco, algunas de las innovaciones que se trabajan son el Bolsillo Familiar
Electrónico; el pago a través del celular, la Billetera Digital (BEPay) que permite pagar sin la necesidad de tener un
plástico asociado; la cuenta corriente digital de BancoEstado; la autenticación por biometría facial para el enrolamiento,
recuperación de clave o desbloqueo de tarjetas mediante IA, entre otros. Así mismo, el banco ha comenzado a incursionar
en campañas digitales personalizadas a millones de clientes, dándoles a conocer los productos y servicios del banco.
Preguntas:
1. ¿Qué impacto tiene la IA en la estructura competitiva del Sector Bancario en Chile? Señale tres impactos directos y
 sus consecuencias sobre la rentabilidad y riesgos de esta industria. Sea preciso.
2. Pensando ahora en Banco Estado, ¿Qué elementos determinarán el nivel de impacto que la IA tendrá sobre la
 sostenibilidad de la estrategia competitiva de Banco Estado? Se solicita que señale tres de estos elementos.

[pág. 10]
10
PREGUNTA Nº5
EcoVida, un destacado fabricante nacional de productos de consumo envasados, ha lanzado recientemente una
nueva línea de galletas sin gluten y sin lactosa, dentro de la categoría “Galletas”. La acogida de estos productos por
parte de los consumidores ha sido variada. Con el objetivo de comprender mejor las preferencias de los
consumidores hacia estos productos, se realizó una segmentación de mercado utilizando el método k-medias, basada
en variables demográficas y patrones de compra de productos sin gluten y sin lactosa, en otras categorías (por
ejemplo: leche, pan, pastas).
Esto resultó en la identificación de dos segmentos distintos: el Segmento 1, que constituye el 75% de los clientes,
compuesto principalmente por consumidores de mayor edad que previamente no habían comprado productos sin
gluten o sin lactosa en otras categorías; y el Segmento 2, que representa el 25% restante, incluyendo a clientes más
jóvenes que ya tenían un historial de compra regular de este tipo de productos.
Para profundizar en el análisis, se decidió examinar las ventas de las galletas, tanto de productos tradicionales como
de los nuevos productos sin gluten y sin lactosa. Se aplicó un modelo por segmento para cuantificar cómo las
variaciones en los precios y las promociones afectan las ventas en toda la categoría de galletas. Las promociones
analizadas son del tipo 2x1 y se llevaron a cabo durante el último semestre.
El modelo utilizado es el siguiente, donde la variable dependiente es el logaritmo natural de las ventas totales de
galletas (unidades vendidas), y las variables independientes incluyen el logaritmo natural del precio regular
promedio de toda la categoría de galletas (incluye los productos recientemente introducidos), además de una
variable dummy para las promociones actuales y el efecto retardado de las promociones que hubo la semana anterior.
Es decir, se indica con 1, si hubo promociones en esta categoría esa semana y 0 en caso contrario.
 𝐿𝑜𝑔(𝑣𝑒𝑛𝑡𝑎𝑠𝑡 ) = 𝛼𝑜 + 𝛼1 log(𝑝𝑟𝑒𝑐𝑖𝑜𝑡 ) + 𝛼2 𝑃𝑟𝑜𝑚𝑜𝑐𝑖ó𝑛𝑡 + 𝛼3 𝑃𝑟𝑜𝑚𝑜𝑐𝑖ó𝑛𝑡−1 + 𝜀𝑡
Donde:
- 𝛼1 representa el coeficiente para el logaritmo del precio regular.
- 𝛼2 es el coeficiente para las promociones actuales.
- 𝛼3 es el coeficiente para el efecto de las promociones realizadas la semana anterior.
Los coeficientes obtenidos para cada segmento son los siguientes:
 Variable Coef. Segmento 1 Coef. Segmento 2
 Intercepto (𝛼𝑜 ) 10.000 4.500
 log(Precio regular) (𝛼1 ) -0.8 -0.3
 Promoción (𝛼2 ) 0.4 0.3
 Promoción Lag (𝛼3 ) -0.2 -0.05
 Nota: Todos los coeficientes son estadísticamente significativos
Preguntas:
1. Considerando la información proporcionada y comparando ambos segmentos, ¿cuál segmento elegiría para
 dirigir una estrategia promocional y por qué? Argumente.
2. ¿Cuáles son las principales ventajas y desventajas de usar en este caso, una segmentación con k-medias basada
 en variables demográficas y compras en otras categorías? En particular, ¿Qué otras variables de segmentación
 habría usado usted en la segmentación de k-medias de manera de detectar segmentos con distintos patrones de
 compra de productos sin gluten y sin lactosa en otras categorías?
3. Basándose en los coeficientes del modelo, ¿cuál es el impacto observado de una promoción en las ventas de la
 categoría de galletas? Si se aumentara la frecuencia de las promociones en el futuro y, con nuevos datos, se
 volviera a estimar una regresión como la planteada, ¿cómo esperaría que esto se viera reflejado en los
 coeficientes del modelo (𝛼1, 𝛼2 , 𝑦 𝛼3 )?

[pág. 11]
11
PREGUNTA Nº6
La tasa de política monetaria (TPM) es la tasa de interés nominal fijada por el Banco Central de Chile (BCCh) para
sus operaciones con los bancos comerciales. Esta tasa afecta las demás tasas del sistema financiero chileno, tanto
de corto plazo (por ejemplo, depósitos a 30 días) como de largo plazo (por ejemplo, bonos de tesorería a 10 años),
aunque no es su único determinante. Las tasas de corto plazo siguen la TPM bastante cerca. Las tasas más largas
incorporan otros factores como el futuro comportamiento de la política monetaria (las futuras TPM), las tasas
internacionales de papeles de largo plazo y otros. El comportamiento de la TPM en los años 2017-2023 ha sido el
siguiente:
El BCCh subió fuertemente la TPM en 2022 y 2023 con el objetivo de frenar la inflación sufrida en el periodo post-
pandemia por Chile y el mundo. La inflación ha dado señales de ya estar en una trayectoria descendiente en los
últimos meses, y tanto analistas como otros operadores del mercado financiero esperan que la TPM comience a
bajar durante el año 2024 hacia niveles de “neutralidad” lo cual sería una tasa de alrededor del 5%. Estos nuevos
niveles de tasas, si bien inferiores al máximo de 11,25% visto durante el 2022, son sustancialmente superiores a las
tasas observadas pre-pandemia de alrededor de 3%. Este es un fenómeno mundial: se espera que las tasas de interés
extremadamente bajas de la década 2010-2020 no se repitan en el futuro cercano.
Sobre la base de la información que se le ha presentado, responda las preguntas que se le formulan a continuación
entregando los fundamentos correspondientes. Si necesita hacer algún supuesto adicional debe explicitarlo en su
respuesta. Adopte un horizonte de inversión de corto plazo.
Preguntas
a) Suponga que usted mantiene un portafolio diversificado que, para simplificar, puede ser descompuesto en dos
 grandes clases de activos: depósitos bancarios de corto plazo en pesos, que prácticamente no tienen riesgo, y
 activos riesgosos, compuestos por acciones chilenas e internacionales. Si su opinión es que el retorno esperado
 y el riesgo de estos activos riesgosos se mantendrán relativamente constantes comparados con la década del
 2010-2020, ¿qué debería implicar para su portafolio, en términos de aumentar o reducir la ponderación de cada
 clase de activos, el mayor nivel de la TPM de neutralidad? Su respuesta puede fundamentarla de manera
 conceptual o, si lo estima conveniente, utilizando un análisis gráfico del tipo media-varianza.

[pág. 12]
12
b) Suponga ahora, sólo para efectos de esta pregunta, que Ud. está analizando la posibilidad de agregar al
 portafolio diversificado de la letra (a) una tercera clase de activo compuesta por bonos de largo plazo en pesos.
 En los últimos meses las tasas de los bonos de largo plazo en pesos han sido comparables o incluso han estado
 por debajo de las tasas de los depósitos bancarios de corto plazo. En jerga de mercado, “la estructura de tasas
 ha estado invertida”. Algunos inversionistas opinan que en este contexto los bonos de largo plazo dejan de
 cumplir una función en un portafolio diversificado y deben ser reemplazados por depósitos bancarios de corto
 plazo, ya que estos últimos tienen un menor riesgo y un retorno similar o incluso mayor que los bonos en pesos
 de largo plazo. ¿Es adecuada esta recomendación? Suponga que efectivamente el retorno esperado de invertir
 en bonos de largo plazo es igual (o menor) al de los depósitos de corto plazo. Al igual que en la letra (a) su
 respuesta puede fundamentarla de manera conceptual o, si lo estima conveniente, utilizando un análisis gráfico
 del tipo media-varianza.
c) Algunos inversionistas opinan que la trayectoria a la baja de la TPM en los próximos años está perfectamente
 incorporada en los bonos de largo plazo en pesos y que el BCCh tiene completa credibilidad en el mercado
 chileno. Dado esto, algunos analistas opinan que es más recomendable invertir en bonos largos que en
 depósitos bancarios de corto plazo en pesos, porque la disminución en las tasas de interés debería producir una
 ganancia de capital que entregaría un retorno superior en estos papeles de alta duración. Cada vez que el BCCh
 baje la TPM, de acuerdo a lo esperado, se produciría ese día una ganancia de capital que no obtendría si solo
 invierto en depósitos de corto plazo. ¿Qué opina usted respecto de los fundamentos de esta recomendación de
 invertir en bonos de largo plazo en pesos? Haga los supuestos que considere necesario para responder esta
 pregunta.

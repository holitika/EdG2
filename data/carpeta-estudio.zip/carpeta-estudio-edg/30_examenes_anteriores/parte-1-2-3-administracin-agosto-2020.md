# Examen de grado · parte-1-2-3-administracin-agosto-2020

Fuente: examen anterior

[pág. 1]
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Esta parte del examen contiene las preguntas número 1 y 2 en cuatro páginas que están numeradas
 correlativamente, después de esta carátula, con los números 1 al 4 (ambos inclusive).
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
 hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
 hojas adicionales.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
 que los datos que ha recibido están correctamente calculados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
 realidad de las empresas que allí se mencionan.
5. Si, como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
 dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
 misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente al Profesor Ignacio Rodríguez Ll. Presidente de la
 Comisión de Examen de Grado, quien responderá sólo a través del correo examen.admuc@gmail.com en el
 horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
 cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. Manténgase permanentemente conectado a su sesión de Zoom con la cámara encendida y el micrófono en
 silencio. Cualquier inconveniente que se le presente con la cámara o el micrófono, siga el protocolo señalado en
 el punto 7 del instructivo que Ud. recibió.
11. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
 examen.
12. Al terminar el examen, Ud. debe remitir al correo señalado en el instructivo que Ud. recibió, solamente el
 cuadernillo con las hojas de respuesta (4 en total) en formato pdf.
Fecha : 13 de agosto de 2020
Duración : 15:00 horas a 16:20 horas
Envío de respuestas : 16:20 horas a 16:30 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el
 Profesor Ignacio Rodríguez, por correo, entre las 15:15 y 15:25 hrs. (aprox.), y luego entre
 las 15:50 y 16:00 hrs. (aprox.).

[pág. 2]
1
PREGUNTA N° 1
“Mientras otros piden salvataje, Carozzi sale de compras durante la pandemia”. Así titulaba el diario la
Segunda, el pasado 25 de junio, luego de que la empresa anunciara la adquisición de los activos, las marcas
Bresler y Melevi, y la licencia de las marcas globales de helados de Unilever presentes en el mercado local,
comercializadas por Unilever Chile, en US$20,8 millones. De esta manera, la firma controlada por la familia
Bofill entrará a competir de lleno con Savory de Nestlé y otros competidores en este segmento del rubro
alimentos1.
Bresler pertenece a Heartbrand, filial de Unilever dedicada a la fabricación de helados que está presente en
más de 40 países y es el primer productor mundial de este tipo de alimentos. De forma global se conoce como
Heartbrand por el característico logotipo del corazón de la firma que caracteriza también a Bresler. Su helado
insignia es Magnum, un producto con palo de madera que tiene una gruesa cubierta de chocolate, y que fue
lanzado al mercado en 1989. Hoy, junto a Cornetto y Carte D’Or, Magnum figura entre los seis helados más
consumidos en el mundo. Según analistas de la industria, sería este robusto portfolio de marcas, que lleva años
en Chile, el que Carozzi buscaría potenciar para hacer crecer este negocio en el país.
Chile lidera el ranking de consumo de helados en Latinoamérica con ocho litros per cápita al año, según cifras
de Euromonitor Internacional de 2019, muy por sobre el segundo y tercer lugar que ocupan Costa Rica y
Uruguay, con 2,8 y 2,7 litros, respectivamente, sin embargo, muy lejos de los líderes mundiales que son Nueva
Zelanda y Estados Unidos con 26,4 litros y 24,5 litros per cápita respectivamente.
La industria de los helados en nuestro país se ha desarrollado fuertemente durante los últimos años,
experimentando un crecimiento constante superior al 7% anual. En efecto, durante el 2015 el mercado de
helados se valorizó en US$700 millones, cifra que para este año 2020 se espera que alcance los US$1.000
millones, logrando un crecimiento de casi 43% en los últimos cinco años.
Bresler produce tanto helados de consumo individual o impulsivo, como productos de consumo hogareño
(postres y cassatas). Dentro de los helados de consumo impulsivo existen varios productos como Magnum,
Cornetto, Viennetta, Futtare, Cate D’or, entre otros, los cuales presentan atributos similares a los helados de
la misma categoría que comercializa la empresa Trendy, como también el líder del mercado, Nestlé, con su
marca Savory. Estos competidores también producen helados de consumo hogareño.
En la siguiente tabla se puede ver la participación de mercado, tanto del mercado de helados impulsivos como
del mercado de postres, de las cuatro principales marcas (medido en miles de litros):
 Mercado Helados Consumo Mercado Helados
 Individual o Impulsivos Hogareños o Postres
 Nestlé 38,5% 44,40%
 Trendy 37,4% 18,80%
 Fruna 16,8% 17,80%
 Bresler 4,6% 13,10%
 Otros 2,7% 5,90%
Los helados son comercializados a los consumidores finales, principalmente a través de dos canales de
distribución: los supermercados y el canal tradicional. Este último incluye almacenes, tiendas de conveniencia,
kioscos y otros similares. El canal tradicional se focaliza en los helados de consumo individual o impulsivo,
mientras que en el canal supermercados el foco está puesto en aquellos productos de consumo doméstico u
hogareño (cassatas y postres). De hecho, del total de ventas de helado de consumo impulsivo, el porcentaje
que se realiza en el canal supermercados no supera el 10%.
1
 El Grupo Carozzi participa en 19 categorías de productos diferentes como: pastas, chocolates, dulces y comida para
mascotas entre otros.

[pág. 3]
2
Durante el semestre primavera-verano (octubre-marzo) las ventas se triplican en relación al semestre otoño-
invierno (abril-septiembre). Las ocasiones de consumo de helado son gatilladas en un 54% por antojos, en un
16% en oportunidades que involucren reuniones con amigas o amigos, alrededor de un 9% de las personas
consumen helado cuando salen de compras, un 8% durante paseos de fin de semana, casi un 6% lo consume
para capear el calor o como postre, y solo un 1% de los consumidores lo hace para saciar el hambre después
de una noche de fiesta u ocasión afín. En general, los distintos análisis de mercado muestran que la decisión
de marca del helado se toma en el momento y lugar de la compra.
El plan estratégico del Grupo Carozzi consiste en que Bresler y su portfolio de marcas aumenten su
participación de mercado y el volumen de ventas en el mercado de los helados durante el semestre octubre-
marzo (2020-2021). De acuerdo al plan estratégico, el principal mercado objetivo serán los actuales
consumidores, sin embargo, también se destinarán esfuerzos y recursos para atraer nuevos consumidores de
las marcas de la competencia. Para lograr lo anterior, Bresler ha decido llevar a cabo una inversión de $500
millones en programas de marketing, los cuales serán dirigidos a los consumidores finales y canales de
distribución a través de distintas promociones.
Iván “Loly” Fernandez, nuevo Gerente de Marketing de Bresler, proponía destinar los $500 millones en una
campaña comunicacional usando medios tradicionales, dirigida a los consumidores finales, de manera de
lograr preferencia de marca. Esta campaña comunicacional sería tanto en medios tradicionales (diarios,
revistas, TV abierta, letreros en las calles, etc.) como en las principales redes sociales como Facebook e
Instagram (ej: descuentos en una app de la marca, puntos por compras de helados de la marca Bresler
canjeables por premios, concursos en las cuales la plata ganada por los participantes iría a organizaciones sin
fines de lucro, etc.). El objetivo de esta campaña según “Loly” Fernández, era lograr preferencia por la marca
Bresler y su portfolio de marcas en el consumidor final.
Por su parte, Jaime “Chocolito” Ramírez, nuevo Gerente de Ventas de Bresler, tenía un plan diferente. Su
propuesta se focalizaba fundamentalmente en hacer promociones al comercio, esto es, a los distintos canales
de distribución de Bresler. Específicamente, su plan consistía en hacer descuentos de precio por volumen
(cantidad de cajas compradas por los distribuidores), cajas de helados de regalo por órdenes mínimas de
compra, congeladores para exhibir los helados y material publicitario en los puntos de venta de los diferentes
distribuidores. Su objetivo era mantener la lealtad de los actuales distribuidores y atraer nuevos canales de
distribución a la marca.
En la siguiente tabla se muestran los resultados proyectados para las estrategias propuestas por los Gerentes
de Marketing y de Ventas de Bresler para el período octubre-marzo (2020-2021) con respecto al año anterior:
 Aumento Ingresos Aumento
 por Ventas Utilidad Operacional
 Promociones al Consumidor Final 4,3% 3,1%
 Promociones al Comercio 8,5% 1,2%
PREGUNTAS
a) Usando los conceptos fundamentales de marketing y de acuerdo con la información entregada en el caso,
 ¿cuál de las dos estrategias que proponen los Gerentes de Bresler elegiría usted? ¿Por qué? Señale tres
 razones que sustenten su decisión justificando claramente cada una de ellas.
b) ¿Cuáles serían los dos principales riesgos de la estrategia elegida? ¿Qué medidas propondría para mitigar
 los riesgos señalados? Justifique claramente su respuesta.

[pág. 4]
3
PREGUNTA N° 2
San Lorenzo S.A. es una empresa dedicada a la venta y distribución de implementos para la minería. Algunas de las
políticas financieras de esta compañía son las siguientes:
 Caja: La política actual de la empresa, es la de terminar, al final de cada año, luego de pagados los dividendos que
 le corresponda pagar el último día del año, con un monto en Caja equivalente a 15 días, de las ventas en pesos
 esperadas para el año siguiente.
 Crédito a sus Clientes (Cuentas por Cobrar): San Lorenzo ofrece a sus clientes un plazo de 30 días para el pago
 de sus compras.
 Inventarios de Productos (Existencias): La política de existencias de la compañía, es la de operar con un Período
 Promedio de Permanencia de sus Existencias (P.P.P.E.) en bodega, de 45 días, es decir, ella debiera mantener en
 Existencias, como promedio, el equivalente a las ventas de 45 días de actividad, valoradas a su costo de adquisición.
A continuación, se muestran el Balance de la empresa al día de hoy, 31 de diciembre de 2019, y el Estado de
Resultados Proyectado para el año 2020 (todas las cifras en $):
 Balance de San Lorenzo S.A. al 31 de diciembre de 2019
 Activos Pasivos y Patrimonio
 Caja (1) $ 26.250 Bonos por Pagar (5) 250.000
 Cuentas por Cobrar (2) 87.500
 Existencias (3) 70.000 Capital 50.000
 Utilidades Retenidas (6) 100.000
 Instalaciones y Terrenos (4) 216.250
 Totales $ 400.000 Totales $ 400.000
 Estado de Resultados Proyectado de San Lorenzo S.A. para el año 2020
 Ingresos por Ventas $ 630.000
 ‐ Costo de Ventas -336.000
 = Margen Bruto 294.000
 ‐ Gastos de Adm. y Ventas -278.000
 = Resultado Operacional 16.000
 Gastos Financieros -5.000
 = Resultado Afecto a Impuestos 11.000
 ‐ Impuestos (20%) -2.200
 = Utilidad Neta o Res. del Ejercicio $ 8.800
Notas al Balance (en sus cómputos suponga 1 año = 360 días)
(1): El requerimiento de caja mínimo para la operación de la empresa, se ha estimado en el equivalente a 15 días de las
 ventas esperadas para el año siguiente (2020).
(2): Si bien la política de la empresa es la de operar con un Período Promedio de Cobranza (PPC) de 30 días, en este
 momento (31-12-19) el PPC es de 50 días.
(3): Aun cuando la política de la empresa es la de operar con un P.P.P.E. en bodega, de 45 días, los números muestran
 que al 31-12-19 el P.P.P.E. es de 75 días.
(4): Los activos fijos depreciables, se deprecian a un ritmo de $5.000 anuales y dicha depreciación ya está incluida en
 los Gastos de Administración y Ventas del Estado de Resultados de San Lorenzo S.A. Además, se sabe que la
 empresa reinvierte todos los años una cifra igual a la depreciación contable ($5.000), para así poder mantener su
 capacidad operativa indefinidamente.
(5): Cada 31 de diciembre, la empresa debe amortizar $50.000 de sus Bonos por Pagar. El saldo de esta cuenta al
 31/12/19, es posterior a dicha amortización. Estos bonos ofrecen pagar una tasa de interés del 2,0% anual (tasa de
 carátula) y la tasa de interés anual que el mercado exige a estos bonos es también del 2,0% anual.
(6): El último día de cada año, la empresa reparte, como mínimo, dividendos en efectivo por un monto equivalente al
 total de las utilidades del ejercicio del año que está terminando. Dado lo anterior, el monto de Utilidades Retenidas
 que se presenta en el balance al terminar el año 2019, es posterior al reparto de las utilidades de dicho año.

[pág. 5]
4
En reunión de Directorio de hoy, 31/12/19, el Gerente de San Lorenzo, comentó lo siguiente: “Los resultados
proyectados para el año 2020, nos permiten ver que la rentabilidad esperada sobre los activos será de un 10,7% tal
como se aprecia en el siguiente indicador:
 (Rentabilidad de los Activos)2020 = [Resultado Operacional)2020 / Patrimonio(31/12/2019)] = [16.000/150.000] = 10,7%
Esto demuestra que estamos creando valor para los dueños de la empresa, porque el 10,7% anterior es mayor que el
Costo de Capital Promedio Ponderado (CCPP) relevante para San Lorenzo que asciende a un 4,5% anual.
Suponiendo que:
 Todos los activos de la empresa son operacionales.
 Todas las ventas de San Lorenzo S.A. se efectúan a crédito, son parejas durante el año y de montos similares en $.
 Todas las compras de Existencias se efectúan al contado, son parejas durante el año y de montos similares en $.
 La tasa de impuesto a las utilidades de las empresas es de 20%.
 Las proyecciones de resultados operacionales de San Lorenzo para el año 2020, no se verán afectadas por los
 cambios que más adelante se propondrán para mejorar la gestión de sus activos.
 1 año = 360 días; Inflación = 0%;
 Para las razones financieras en las que intervenga una variable de flujo y una de stock, para la variable de stock use
 el valor al 31-12-19.
A Ud. se le pide responder las preguntas que se le formulan a continuación, mostrando claramente todos los cálculos
necesarios en los cuales se sustentan sus respuestas. Use dos decimales en sus cálculos, y suponga que la información
contable que se entrega es la única disponible y relevante para su análisis.
1. ¿Está Ud. de acuerdo con el análisis de la rentabilidad hecho por el Gerente de San Lorenzo y su conclusión en
 términos de una “creación de valor” por parte de la empresa en el año 2020?
2. A diferencia de su Gerente, el Presidente de San Lorenzo, preocupado por lo que podría ser una señal de mala
 gestión de los activos de la empresa, le ha contratado a usted para analizar el impacto que tendría sobre la
 compañía, las medidas destinadas a mejorar su gestión y que se describen a continuación:
  Cambios tecnológicos aplicados a la gestión de la caja de la empresa, permitirían que el nivel de caja mínimo
 con el que actualmente ella opera, que equivale a 15 días de ventas, disminuya a 10 días de ventas, es decir,
 una disminución de 5 días.
  Disminuir el Período Promedio de Cobranza, desde los actuales 50 días a un período promedio de 30 días, es
 decir, lo disminuirá en 20 días.
  Disminuir el Período Promedio de Permanencia de su Existencias en bodega, desde los actuales 75 días a un
 período promedio de 45 días, es decir, una disminución de 30 días.
  Venta al contado, el mismo 31 de diciembre de 2019, de un terreno colindante con los terrenos de la empresa,
 que estaba destinado al estacionamiento de visitas y que se consideró como innecesario para el negocio. El
 terreno se vendería a su precio de mercado, el que casualmente correspondía a su costo histórico, y que
 alcanzaba a la suma de $8.250.
 Se sabe que si, el último día del año, la empresa presenta un exceso de caja en relación al nuevo monto de caja
 óptimo que ha determinado la compañía (10 días de ventas), dicho exceso que se produciría como resultado de la
 implementación de las medidas ya señaladas de mejora en la gestión de la empresa, lo repartiría completamente
 como dividendo en efectivo a sus dueños, el mismo 31 de diciembre de 2019, es decir, el reparto de dicho
 dividendo en efectivo, sería lo último que la compañía haría ese 31/12/19.
 Para su análisis, suponga que San Lorenzo se beneficiaría de manera completa e inmediata, es decir, en el
 mismo momento de su implementación, esto es, al término del año 2019, del total de los beneficios que se puedan
 producir como resultado de las medidas que se han propuesto.
 En base a lo anterior, responda las siguientes preguntas:
 a) Obtenga el monto ($) de la creación de valor que podría generarse en la empresa el 31/12/2019, como
 resultados del conjunto de medidas que se ha descrito y que han sido propuestas por su Presidente.
 b) Obtenga el monto ($) de la creación de valor esperada para el año 2020, luego de las medidas descritas.

[pág. 6]
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Esta parte del examen contiene las preguntas número 3 y 4 en cuatro páginas que están numeradas
 correlativamente, después de esta carátula, con los números 5 al 8 (ambos inclusive).
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
 hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
 hojas adicionales.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
 que los datos que ha recibido están correctamente calculados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
 realidad de las empresas que allí se mencionan.
5. Si, como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
 dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
 misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente al Profesor Ignacio Rodríguez Ll. Presidente de la
 Comisión de Examen de Grado, quien responderá sólo a través del correo examen.admuc@gmail.com en el
 horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
 cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. Manténgase permanentemente conectado a su sesión de Zoom con la cámara encendida y el micrófono en
 silencio. Cualquier inconveniente que se le presente con la cámara o el micrófono, siga el protocolo señalado en
 el punto 7 del instructivo que Ud. recibió.
11. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
 examen.
12. Al terminar el examen, Ud. debe remitir al correo señalado en el instructivo que Ud. recibió, solamente el
 cuadernillo con las hojas de respuesta (4 en total) en formato pdf.
Fecha : 14 de agosto de 2020
Duración : 10:00 horas a 11:20 horas
Envío de respuestas : 11:20 horas a 11:30 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el
 Profesor Ignacio Rodríguez, por correo, entre las 10:15 y 10:25 hrs. (aprox.), y luego entre
 las 10:50 y 11:00 hrs. (aprox.).

[pág. 7]
5
PREGUNTA N° 3
“La crisis social, sanitaria y económica que enfrenta Chile requiere de una cantidad enorme de recursos, como nunca
antes en nuestra historia, para ir en ayuda de los sectores más vulnerables y de las clases medias del país. Esta crisis nos
acompañará por varios años. Por ello, debemos desplegar todas nuestras capacidades técnicas y buscar ahorros en todos
los ámbitos. Ello nos permitirá reorientar el gasto fiscal hacia los objetivos más urgentes y los grupos más vulnerables”,
declaraba recientemente una autoridad de gobierno al referirse a la aprobación de la ley Nº 21.233 que rebaja las
remuneraciones de Diputados y Senadores. Hasta ahora, los sueldos de estos funcionarios del Estado estaban entre los
más altos del mundo antes de la modificación legal. Una vez que la ley entre en vigencia, ella establece que las
remuneraciones de estos funcionarios públicos se reducirán en un 25%. Por ello, agregaba el representante del gobierno,
“esta reforma nos permite, reducir gastos en el Estado y, al mismo tiempo, ponernos a tono con los estándares
internacionales en materia de remuneraciones de quienes ejercen funciones públicas.”
Los Diputados y Senadores conforman el Congreso, uno de los tres poderes autónomos del Estado, y encargado
fundamental de la aprobación de las leyes de la nación. Para ser parlamentario se requiere, además de ser elegido por
votación popular, tener 21 años de edad cumplidos en el caso de los Diputados y 35 años si se trata de los Senadores.
Adicionalmente, es requisito para poder desempeñar funciones parlamentarias, el haber cursado la enseñanza media. Tal
como lo confirma la reciente aprobación de la ley que impide la reelección a los cargos de Diputados y Senadores, los
parlamentarios tienden a permanecer por muchos años en sus cargos mediante sucesivas reelecciones. En caso de no ser
electos, y a pesar de los bajos niveles de credibilidad del parlamento y los partidos políticos (3% de confianza ciudadana
según encuesta CEP 2019, cuya principal causa es la percepción de corrupción, de acuerdo con informe PNUD, 2016),
los parlamentarios habitualmente continúan trabajando en labores políticas dentro de sus partidos.
El siguiente gráfico muestra las remuneraciones de los diferentes cargos públicos, antes de la reforma a la ley Nº 21.233:
 Remuneraciones mensuales 2020 (en $, ajustadas por PPA) *
 14.000.000
 12.000.000
 10.000.000
 8.000.000
 6.000.000
 4.000.000
 2.000.000
 0
 Chile Estados Unidos Alemania Holanda Promedio Total Uruguay
 Países
 Diputados Senadores Directivos Profesionales Jefaturas Profesi onales
 *PPA = paridad de poder adquisitivo
La modificación legal solo consideró a los parlamentarios. Las remuneraciones de los cargos de Dirección y Jefaturas
profesionales que se desempeñan en los diversos ministerios y servicios públicos que conforman el Poder Ejecutivo, otro
de los tres poderes del Estado, no se verán afectadas por este cambio normativo.
Los Directivos y Jefaturas profesionales se desempeñan en funciones técnicas asociadas al diseño e implementación de
las políticas públicas, junto a labores de fiscalización en materias especializadas como el monitoreo y persecución de
faltas a la libre competencia, el desarrollo y supervisión del mercado de valores, el mejoramiento de la salud pública, la
calidad de la educación y la focalización de recursos para una urgente reducción de la pobreza, entre otros asuntos. En un
buen número de casos, estas funciones son ocupadas por profesionales que provienen del ámbito privado y que también,
en otras tantas ocasiones, regresan después de varios años de servicio público, a trabajar a la empresa privada. Una
comparación válida de las remuneraciones del sector público y privado para los cargos de dirección y jefatura se muestra
a continuación en el siguiente gráfico:

[pág. 8]
6
 Remuneraciones mensuales 2020 (en $)
El perfil que establece el Consejo de Alta Dirección Pública (CADP), organismo a cargo del proceso de selección de
estos funcionarios, para este tipo de posiciones se detalla en la tabla a continuación:
 Requerimientos del perfil de un candidato para ocupar un cargo Directivo o de Jefatura Profesional en la
 Administración Pública chilena
 Título profesional universitario o técnico.
 Master e incluso doctorado cuando la especialidad técnica del cargo a ocupar lo requiere.
 Experiencia profesional no inferior a 5 años en cargos similares.
 Dominio de idioma inglés.
 Competencias estratégicas: visión estratégica, gestión y logro, liderazgo externo y articulación de redes con personas
 clave, manejo de crisis y contingencias, liderazgo interno, gestión de personas, innovación y flexibilidad.
 Competencias para la gestión pública: dirección de servicios públicos, probidad y ética en la gestión pública, vocación
 de servicio público y conciencia de impacto público.
Este organismo fue creado con el propósito “de fortalecer la función pública y contribuir a la modernización del Estado,
a través de la implementación de políticas de gestión y desarrollo profesionales en cargos de Jefatura y Dirección, para
promover un mejor empleo público y un Estado al servicio de los ciudadanos. “En esta coyuntura -indicaba un alto
funcionario del CADP-, se requiere redoblar los esfuerzos en materia de eficiencia del gasto público. Por ello debemos
desplegar todo el talento de todos aquellos que tienen un rol directivo y de jefatura, para movilizar a sus equipos en la
entrega de un servicio y apoyo a los ciudadanos, con excelencia, efectividad, oportunidad y eficiencia. En estas críticas
circunstancias no hay margen de error para la acción del Estado.”
PREGUNTAS
1. La propuesta de rebaja de 25% de las remuneraciones de Diputados y Senadores, fue preparada por el Consejo de
 Alta Dirección Pública (CDAP). El Consejo está compuesto por 5 miembros independientes. Sin embargo, su
 propuesta no fue aprobada por unanimidad. Hubo 3 votos de mayoría y dos de oposición. Uno de los consejeros en
 minoría, consideró que la disminución del 25% era insuficiente, mientras que el otro consejero que también se opuso,
 paradojalmente, consideró que, por el contrario, las remuneraciones de Diputados y Senadores debieran
 incrementarse respecto de los niveles actuales. Los dos votos de minoría, si bien rechazan la reducción de
 remuneraciones de los parlamentarios, lo hacen por razones diametralmente distintas. ¿Desde el punto de vista del rol
 de los sistemas de remuneraciones efectivos, qué razones pueden sustentar estos dos votos de minoría tan dispares?
 Fundamente su respuesta en forma precisa.
2. Un honorable parlamentario señalaba a un medio de comunicación, minutos después de promulgada la ley Nº 21.233:
 “Me parece contradictoria esta propuesta. Nosotros los parlamentarios, que tenemos un alto nivel jerárquico dentro
 del Estado, terminaremos obteniendo remuneraciones menores a los Directivos y Profesionales de rango inferior.”
 Desde el punto de vista de la efectividad del sistema de remuneraciones, ¿le parece correcta la posición que expresa
 el parlamentario? Justifique su respuesta.

[pág. 9]
7
PREGUNTA N° 4
Los fondos de pensiones chilenos (que son administrados por las Administradoras de Fondos de Pensiones o
AFPs), y otros vehículos de inversión similares, combinan múltiples activos al formar portafolios. El objetivo
principal es entregar buenas rentabilidades de largo plazo (es decir, pensando en la etapa de jubilación) sujeto a
un cierto perfil de riesgo deseado por el afiliado o inversionista. En esta pregunta se pide que usted desarrolle
criterios para evaluar el desempeño de los fondos de pensiones en el corto y largo plazo, bajo el supuesto de
que los fondos de pensiones hacen un análisis media-varianza simple.
Para simplificar el análisis considere que existen 3 grandes clases de activos en los que las AFPs invierten:
depósitos, bonos y acciones. Suponga que la correlación entre los retornos de bonos y acciones es de 0 y que
sus rentabilidades históricas y esperadas, en términos mensuales y nominales, son las siguientes:
  Depósitos: básicamente el activo libre de riesgo en la economía con un retorno mensual promedio de
 0,2% sin volatilidad (desviación estándar de los retornos igual a 0).
  Bonos: retorno mensual promedio de 0,4% con desviación estándar de 0,6%.
  Acciones: retorno mensual promedio de 1% con desviación estándar de 2%.
Nos enfocaremos en 2 Fondos ofrecidos por las AFPs a sus afiliados: un Fondo más riesgoso (“Fondo A”) y
otro menos riesgoso (“Fondo C”). Suponga que los portafolios de estos Fondos tienen la siguiente composición:
 Fondo A Fondo C
 Depósitos 0% 50%
 Bonos 20% 10%
 Acciones 80% 40%
Para efectos de responder las preguntas que se le formulan a continuación, suponga que los retornos de todos
los activos siguen la distribución normal y que los retornos de un mes son independientes de todos los meses
anteriores.
 a) ¿Cuál es la rentabilidad esperada y la volatilidad (medida como desviación estándar) de los Fondos A
 y C? Muestre los cálculos correspondientes.
 b) ¿Qué tan probable es que, en un mes cualquiera, el Fondo A rente menos que el Fondo C? No se pide
 una estimación precisa de esa probabilidad, ni un cálculo matemático muy complicado, sino que se pide
 una respuesta en términos intuitivos en la siguiente escala: muy probable (> 95% de los meses), probable
 (entre 95% y 5%), muy improbable (< 5% de los meses). Justifique su respuesta utilizando la
 información obtenida en la letra anterior. Recuerde que en una distribución normal con media y
 desviación estándar aproximadamente:
  El 95% de los casos posibles están contenidos en el intervalo ± .
  El 68% de los casos posibles están contenidos en el intervalo ± .
  El 38% de los casos posibles están contenidos en el intervalo ± (
 c) Suponga que un afiliado a una AFP decide tratar de maximizar la rentabilidad de sus inversiones
 cambiándose “estratégicamente” entre el Fondo A y el C según un modelo que acaba de idear. Suponga
 que el inversionista tiene hoy 25 años y que seguirá esta política por los próximos 30 años. Considere
 las tres siguientes políticas de inversión:
  Política 1: Invertir siempre en el Fondo C
  Política 2: Invertir siempre en el Fondo A

[pág. 10]
8
  Política 3: Invertir según la estrategia pensada por el inversionista que consiste en invertir en el
 Fondo A, pero cambiarse al Fondo C, por un mes, cada vez que el Fondo A tiene una
 rentabilidad negativa y después volver al Fondo A.
 ¿Cuál sería el ranking de rentabilidades esperadas al comparar las 3 políticas de inversión? No es
 necesario entregar un valor para cada rentabilidad, sólo ordenarlas de mayor a menor. Justifique su
 respuesta suponiendo que los cambios entre los Fondos A y C son instantáneos, es decir, no hay tiempo
 de espera cuando un inversionista decide cambiarse de un Fondo a otro.
d) Suponga ahora que usted toma una muestra de 20 años y calcula la razón de Sharpe para los Fondos A
 y C, es decir, el retorno promedio del Fondo (en exceso de la tasa de depósitos) dividido por la
 desviación estándar de esos retornos. Suponga que 20 años es suficiente para ser considerado como
 largo plazo. Si el análisis media-varianza que hicieron inicialmente las AFPs fue adecuado, es decir,
 efectivamente maximizaron la razón de Sharpe ofrecida a sus afiliados, y no tenían restricciones de
 inversión en sus portafolios, ¿Cómo debería ser la razón de Sharpe del Fondo A con relación a la razón
 de Sharpe del Fondo C: mayor, menor, igual? Fundamente su respuesta ya sea de manera conceptual o
 numérica.

[pág. 11]
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Esta parte del examen contiene las preguntas número 5 y 6 en tres páginas que están numeradas correlativamente,
 después de esta carátula, con los números 9 al 11 (ambos inclusive).
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
 hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
 hojas adicionales.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
 que los datos que ha recibido están correctamente calculados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
 realidad de las empresas que allí se mencionan.
5. Si, como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
 dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
 misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente al Profesor Ignacio Rodríguez Ll. Presidente de la
 Comisión de Examen de Grado, quien responderá sólo a través del correo examen.admuc@gmail.com en el
 horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
 cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. Manténgase permanentemente conectado a su sesión de Zoom con la cámara encendida y el micrófono en
 silencio. Cualquier inconveniente que se le presente con la cámara o el micrófono, siga el protocolo señalado en
 el punto 7 del instructivo que Ud. recibió.
11. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
 examen.
12. Al terminar el examen, Ud. debe remitir al correo señalado en el instructivo que Ud. recibió, solamente el
 cuadernillo con las hojas de respuesta (4 en total) en formato pdf.
Fecha : 14 de agosto de 2020
Duración : 15:00 horas a 16:20 horas
Envío de respuestas : 16:20 horas a 16:30 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el
 Profesor Ignacio Rodríguez, por correo, entre las 15:15 y 15:25 hrs. (aprox.), y luego entre
 las 15:50 y 16:00 hrs. (aprox.).

[pág. 12]
9
PREGUNTA N° 5
 GRUPO PATIO Y LA OTRA UTILIDAD
“En momentos de pandemia la vida nos ha puesto a todos en una posición difícilmente imaginable. Una
 de las grandes preguntas a hacerse desde las empresas es qué rol queremos jugar en estos tiempos.
 Porque si de algo estoy seguro es que por lo que hagamos hoy seremos medidos en el futuro”.
Así comenzaba una entrevista en un diario de circulación nacional hace pocas semanas atrás, uno de los
máximos directivos de Grupo Patio, cuando explicaba las bases de la estrategia de la empresa en tiempos de
Covid, anclada en el concepto de “la otra utilidad”.
Grupo Patio es un grupo empresarial chileno, que ofrece opciones y soluciones en diferentes mercados
destinados al arriendo de inmuebles. Sus proyectos, ubicados en zonas estratégicas a lo largo del país y también
en Perú, se caracterizan por la flexibilidad y conectividad de los edificios y por la preocupación por los detalles
orientados a mejorar la calidad de vida de quienes los utilizan.
En la actualidad, Grupo Patio cuenta con más de 200 empleados, posee más de 1.000 clientes (arrendatarios),
y es propietario de 115 propiedades para arriendo (edificios e inmuebles) lo que totaliza casi 900.000 metros
cuadrados de superficie arrendable. Opera 77 centros comerciales, 6 de los cuales están en Perú, y el resto en
Chile.
Los Negocios
En Grupo Patio los negocios están organizados dependiendo del uso de los inmuebles en arriendo:
 - Patio Comercial: son 76 propiedades (locales comerciales de diferentes tamaños) en diferentes
 formatos en Chile y Perú. Son construcciones integradas a cada entorno, con soluciones para sus
 vecinos y apropiadas para grandes marcas y retailers. Cuentan con opciones de menor tamaño como
 strip centers.
 - Patio Residencial: edificios con diseños y servicios orientados a clientes arrendatarios. Se busca
 resolver de manera integral las necesidades de vivienda, ubicación y estilo de vida de personas y
 familias.
 - Patio Industrial: se orienta a la solución de problemas de espacio para distintas necesidades. Dirigido
 a empresas grandes o pymes, con desarrollos que se amoldan a distintas necesidades. Bodegas, mini
 bodegas, galpones, son parte de los activos de este negocio.
 - Patio Oficinas: orientado al mercado de empresas, ofrece opciones de oficinas en diferentes
 ubicaciones a lo largo de Chile.
 - Patio Financiero: busca obtener una buena rentabilidad para inversionistas interesados en el mercado
 inmobiliario. Ofrece proyectos inmobiliarios de la propia compañía a inversionistas. Se ofrece además
 asesoría para participar en fondos de inversión.
La Otra Utilidad
Hace algunas semanas Grupo Patio informó acerca de los elementos centrales de su nueva estrategia, la cual
responde a la situación que actualmente enfrenta la economía, el país y sus clientes (empresas grandes,
medianas y pequeñas, y personas). En efecto, Grupo Patio ha anunciado que implementará con sus clientes un
paquete de beneficios con el objeto de avanzar en lo que denominan “la otra utilidad”, pensando en el beneficio

[pág. 13]
10
de diferentes grupos de interés que se interrelacionan con Patio. El paquete de beneficios informado por Grupo
Patio es el siguiente:
 - Suspensión temporal de rentas de arrendamiento en activos comerciales: desde el 18 de marzo de este
 año (inicio de la pandemia) se decidió suspender el cobro de rentas a 413 clientes Pyme (pequeñas y
 medianas empresas) de locales comerciales que no están pudiendo funcionar por disposición de la
 autoridad.
 - Apoyo en la obtención de créditos a tasa real de 0%: se consiguió que los clientes Pyme puedan
 postular a la obtención de créditos otorgados por una empresa especializada por un monto de hasta 10
 millones de pesos con tasa de interés real de 0%, sin comisión y con 3 meses de gracia.
 - Asesoría legal, financiera, emocional y mentoría: se está entregando asesoría legal y financiera para
 que los clientes que lo requieran puedan acceder a los beneficios y programas del Estado. Se
 implementó un equipo asesor compuesto por profesionales especializados en distintas disciplinas sin
 costo para los clientes. Esto incluye mentoría para entregar orientación en el manejo de sus negocios
 en este complejo momento, así como coaching emocional para contener y apoyar a los clientes.
 - Cero despidos y no uso de la ley de protección de empleo: se asumió el compromiso de no desvincular
 a ningún colaborador para ahorrar costos, ni tampoco ocupar la ley de protección de empleo impulsada
 por el gobierno.
 - Compromisos salariales: se tomó la decisión de mantener todos los compromisos salariales adoptados
 con los colaboradores. Esto incluye no rebajar el sueldo a nadie y conservar todo lo acordado con cada
 uno de ellos.
Las Reacciones
No se hicieron esperar y fueron variadas. La que destacó fue la reacción de un connotado periodista económico
y asiduo comentarista en temas de negocios: “Es curioso esto de “la otra utilidad” de Grupo Patio,… suena
más a campaña de marketing para hacerse publicidad que otra cosa. Si no fuera sólo marketing, sería razón
más que suficiente para no invertir (como accionista) en esta empresa, ya que la destrucción de valor sería
significativa para una empresa arrendadora de espacios e inmuebles, cuya razón de ser fundamental debe ser
cuidar la generación de valor”.
PREGUNTAS
1. Suponga que “La Otra Utilidad”, constituye efectivamente el pilar fundamental sobre el cual Grupo Patio
 desea anclar su estrategia. En este contexto, y considerando la esencia de una estrategia competitiva, ¿es
 correcta la conclusión del periodista en el sentido de calificar el planteamiento estratégico de la empresa
 como destructor de valor? ¿Por qué sí o por qué no? Entregue tres razones que avalen su respuesta.
2. Desde el punto de vista de la posición competitiva de Grupo Patio en su industria, la estrategia competitiva
 anclada en “La Otra Utilidad”, ¿mejora, es neutra o empeora la posición competitiva que la empresa
 mantenía en su industria antes de comenzar la implementación de la misma? En su respuesta señale tres
 posibles razones que sustenten la opción seleccionada. (No es necesario que describa la posición
 competitiva actual, sino que piense en términos de variación en ella, independientemente desde dónde se
 parta).

[pág. 14]
11
PREGUNTA N° 6
Las restricciones que ha implicado la pandemia del coronavirus han profundizado el uso del canal online, tanto
en Chile como en muchos otros países del mundo. De acuerdo con un estudio de la empresa consultora Bain
& Company1, realizado en junio recién pasado, un 33% de los consumidores chilenos declaran haber utilizado
por primera vez el canal online para hacer sus compras de supermercado y alimentos. Los clientes nuevos que
más crecieron fueron del estrato socio económico alto (44% de crecimiento) aunque los consumidores nuevos
de estratos medios y bajos también crecieron (26% y 39% respectivamente). Estos aumentos incluyen tanto
los canales online propios de los supermercados, como las apps de “última milla” como Uber Eats, Pedidos
Ya y Cornershop. Según el estudio de Bain & Company, un 24% de los consumidores usaron una app de
“última milla” por primera vez durante la pandemia del coronavirus. También han crecido en este mercado la
frecuencia de uso y el monto de la compra promedio.
Definitivamente no hay actor del mercado de delivery de alimentos que no esté desarrollando nuevas y mejores
formas de llegar al consumidor en el canal online. Los supermercados se potencian para hacer frente a la
demanda de mejor forma, las tiendas especialistas debutan en este mundo y las aplicaciones tradicionales
generan mecanismos para adaptarse a un entorno que se expande. Los expertos pronostican que las compras
online de supermercado probablemente se van a mantener en el futuro porque los consumidores ya han bajado
las aplicaciones, han realizado compras y han podido apreciar sus conveniencias. Probablemente van a
participar en esta industria muchos actores. El problema no es tanto la competencia sino el ofrecer una
propuesta de valor atractiva porque el mercado está creciendo de manera significativa.
En el mundo de las apps de “última milla”, Cornershop ha sido el líder hasta antes de la pandemia del
coronavirus. Según uno de sus máximos ejecutivos, los desafíos que enfrentan hoy en día son captar nuevos
clientes, generar hábitos en los clientes para mantener la demanda después de terminadas las restricciones
sanitarias, aumentar la penetración en regiones donde no están llegando y ajustar la propuesta de valor a las
necesidades de los nuevos clientes. Estos cambios en la propuesta de valor podrían considerar la estructura de
precios, las características de la membresía Pop (cliente premium), los comercios con convenio u otras
características
PREGUNTAS:
a) Describa, a partir de los antecedentes en la pregunta, dos problemas de marketing que enfrenta
 actualmente Cornershop. Sea preciso (a) en su respuesta.
b) Considerando uno (y sólo uno) de los desafíos que enfrenta Cornershop:
 (i) Mencione un modelo o metodología analítica que ayude a los ejecutivos a tomar las decisiones que
 deben enfrentar con respecto al desafío considerado por usted. Justifique su respuesta.
 (ii) Indique los datos que requiere para aplicar el modelo o metodología mencionado.
 (iii) Indique los resultados que se obtendrían del modelo en directa relación con las decisiones relevantes
 al problema.
1
 El Mercurio, viernes 17 de Julio 2020

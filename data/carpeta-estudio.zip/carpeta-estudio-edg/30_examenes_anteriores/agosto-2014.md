# Examen de grado · agosto-2014

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


a z a Se . ii Z e - - A : 2 |
PONTIFICIA UNIVERSIDAD CATÓLICA DE CHILE . |
. ESCUELA DE ADMINISTRACIÓN :
l
l a : |
aa |
ES ña
| AD |
ETS
2 EXAMEN DE GRADO
|
- !
INFORMACIÓN GENERAL E INSTRUCCIONES: |
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen,
el alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para responder cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos |
hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni
utilizar hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta. i
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta.
Suponga que los datos que ha recibido están correctamente calculados y que no han sido tergiversados,
4. No necesariamente toda la información que. se entrega en las distintas preguntas corresponde exactamente a la |
realidad de las empresas que allí se mencionan. |
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta. |
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
misma ponderación al momento de ser evaluadas.
. . . .
7. Las preguntas de enunciado se podrán hacer solamente al Profesor Ignacio Rodríguez, Presidente de la |
Comisión de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.),
El cumplimiento de esta norma es de absoluta responsabilidad del alumno. :
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
condiciones, el Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala, los que deberán estar apagados y
no deberán mantenerse sobre el escritorio durante el examen.
12, Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
examen,
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han |
identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
como “borrador”, esas hojas no se deben entregar con las respuestas.
¡(Oo >
Fecha : 1 de Agosto de 2014
Duración : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el Profesor
Ignacio Rodríguez, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45
y 11:00 hrs. (aprox.). "
-----
:
[
2 |
PREGUNTA N'1 |
É
A fines de abril de este año, el Tribunal de Defensa de la Libre Competencia (TDLC) aprobó un acuerdo
conciliatorio entre la Fiscalía Nacional Económica (FNE) y la empresa Unilever Chile (UL), tras una denuncia de i
presunto abuso de posición de dominio, por parte de UL, mediante prácticas exclusorias en el mercado de
detergentes para lavado de ropa, con sus marcas Omo, Drive y Rinso. De acuerdo a la FNE, UL entregaba en fotma
sistemática incentivos a los distribuidores por exclusividad en la venta de detergentes, además de descuentos o
premios condicionales a desempeño y para privilegiar el uso de espacios para la venta, tanto en el canal tradicional
como en el supermercadista, |
Entre los términos del acuerdo, está que respecto de las categorías donde UL tenga más de un 60% de participación
de mercado total en ventas a nivel nacional, UL no podrá pactar con los distribuidores ni pagos, ni descuentos ni |
premios asociados a: exclusividad en la venta en el local; metas de crecimiento en ventas; asignación de espacios en |
góndolas 1 mayores a su participación de mercado nacional, para la exhibición de sus productos en supermercados y
otros comercios que tengan góndolas de autoservicio (almacenes, supermercados - mayoristas, etc.). En el caso de |
UL, la participación promedio actual que la empresa tiene en el espacio en góndolas de supermercados, es un poco |
inferior a la participación de mercado total en ventas que UL tiene en Chile.
La estructura de la industria de detergentes en Chile Tabla N2 1 |
corresponde a una de alta competencia, caracterizada por la N? de Skus por Empresa
presencia de una gran cantidad de empresas multinacionales (categoría detergentes ropa)
y chilenas, que comercializan (fabrican y/o importan) en ee
conjunto más de 200 Skus 2 (ver Tabla N* 1) y más de 70 [FABRICANTE FROBaFagE
marcas de detergentes para la ropa (incluyendo las marcas |
propias de los distribuidores). feunsoL AA |
Varias de las empresas nacionales compiten en el mercado [KLAREN Y 22 |
tanto con sus propias marcas como también a través de la [ree [| 2 2 |
fabricación de las marcas propias de los supermercados, las [CLEANER CHILE | 2] 3] |
cuales no son fabricadas por UL o PéG (Procter and Gamble). IBERIA. Y 23]
Unilever, principal actor de la categoría detergentes para el - JHENKEL. |. 6-5 |
lavado de ropa, es una empresa multinacional que compité :
además en otras categorías tales como cosmética 'y cuidado JLABACH | 5] al]
personal (Dove, Ponds, Pepsodent, LeSancy, Axé, Rexona,
etc.), alimentación (Hellmanns, Knorr, Malloa, Bresler, Lipton, [Marcas Propias | 26| 26] .
etc.), cuidado del pelo (Sedal, St.Ives, Tresemme, Clear, etc.), :
cuidado del hogar (Vim, Cif, etc.), y así sucesivamente. Tanto
UL como PéG tienen centros de investigación en distintas 1 í
partes del mundo.
Fuente: AC Nielsen
Además de las empresas multinacionales como UL y Pé<G, en la categoría de detergentes para el lavado de la ropa
compiten una serie de empresas locales como Maritano, Cleaner, Brillex y Ballerina, entre otras. UL y P£G son las
únicas empresas que compiten en el rubro con tres o más marcas y gran cantidad de Skus, La venta se realiza a
través de múltiples canales de distribución incluyendo: cadenas de supermercados (los cuales representan el 80%
del volumen de ventas totales), cadenas de tiendas por conveniencia, almacenes (a través de mayoristas) y ferias.
Estudios de mercado recientes muestran que la mayoría de los consumidores chilenos compra detergentes
mayoritariamente en base a preferencia de marca, luego funcionalidad, precio, y en menor medida, por conveniencia
en la compra, La Tabla N* 2, describe la evolución de la participación de mercado en ventas a nivel nacional,
considerando todos los canales de distribución de las principales empresas que componen el mercado de los
detergentes.
1 La participación porcentual en góndola se mide tomando los metros lineales que tiene la marca sobre el total de metros
lineales de la categoría.
2 Sku: “Stock Keeping Unit”, corresponde a una combinación de marca, tamaño, empaque y variedad o modelo. Es la
unidad de referencia que se utiliza para el control de inventarios y ventas,
-----
3 :
Tabla N? 2: Participación de Mercado Detergentes |
[2005 [| 2008 | 2007 | 2008 | 2008 [| 200 | 20 |] 202 e
UNILEVER 76,4% 73,9% 74,1% 72,0% 73,5% 73,2% 69,7% 67,5%
PSG 17,3% 17,8% 17,0% 17,7% 17,4% 20,7% 22,0% 21,9%
MARITANO 3,2% : 3,2% 3,0% 3,1% 2,7% 1,5% 1,9% 2,2%
LABACH 0,2% ' 0,3% 0,2% 0,2% 0,2% 0,1% 0,2% 1,1%
CLEANER CHILE 0,0% 1,0% 0,4% 15% 1,8% 0,8% 1,3% 1,6%
MARCAS PROPIAS 1,1% | 2,6% 4,2% 4,9% 3,4% 2,8% 4,0% 4,8% |
OTROS 1,8% : 1,2% 11% 0,6% 1,0% 0,9% 0,9% 0,9%
100,0%
Fuente: AC Nielsen |
Entre los años 2005-2012, el mercado de detergentes muestra un comportamiento competitivo, con frecuentes
promociones de valor agregado (regalos a los consumidores) por parte de UL y PézG, así como de promociones de |
- precios por parte de todos los actores, logrando que los precios promedio hayan sido más bien estables. Las marcas
de UL y P82G tienen precios superiores al resto del mercado. La inversión publicitaria en la categoría durante el año
2012 sobrepasó los 5 mil millones de pesos, representando UL y P£G juntos, más del 85% de ese total.
Actualmente, en nuestro país existen cuatro cadenas de supermercados (Walmart, Cencosud, SMU, Tottus) que
representan cerca del 90% de las ventas de productos en supermercados. Por otra parte, existen más de 500 empresas
o locales mayoristas que atienden a más de 100.000 almacenes que comercializan detergentes para el lavado de ropa,
Como era de esperar, las marcas con menor participación en el mercado de detergentes estaban felices con el |
acuerdo entre la FNE y UL. Un analista del sector planteaba que “ahora que UL no podrá pagar por exhibir sus |
marcas en más del 67% del espacio en góndolas de supermercados, destinado a la categoría de detergentes, lo más
probable es que el conjunto de empresas nacionales que representan a las marcas más pequeñas (sin incluir las
marcas propias de los supermercados) llegará en el corto plazo a tener una participación de mercado minima de un |
15% de las ventas totales”. |
PREGUNTAS . :
En base a la información provista en el enunciado y respecto de la categoría de detergentes de ropa, responda las
siguientes preguntas:
1) Desde un punto de vista comercial, ¿le parece correcta la afirmación del analista? Argumente en forma breve y
precisa.
2) ¿Qué impactos de corto y largo plazo, sobre la estrategia comercial de detergentes de UL, pueden tener las
restricciones acordadas con la FNE? Fundamente su respuesta.
-----
4 ¿
PREGUNTA N? 2
Hace más de 20 años, Augusto Parra creó la cadena de panadería y pastelería Vienna debido a su
insatisfacción con el modelo que imperaba en aquellos años para este tipo de establecimientos: una panadería
de barrio, local, que solo ofrecía pan fresco y de mediana calidad. Augusto Parra comentaba: “En aquella
época, era imposible pensar en una panadería que tuviera algo más que pan. Si querías además un kuchen o  * |
un pastel, tenías que ir a dos lugares distintos. Para qué decir si estabas buscando algún producto más
variado, como pan de aceitunas o con finas hierbas. Yo que disfruto de la cocina resolvía esta falta de |
variedad cocinando yo mismo, pero muchas veces esta solución era costosa en términos de tiempo.” Hoy en
día Vienna contaba con 50 locales en diferentes ciudades del país y su estrategia tenía, como uno de sus
objetivos, la diversificación de productos de la panadería tradicional.
Junto con proveer de una amplia línea de productos, el fundador de la empresa también enfrentaba el desafío
de mantener la alta calidad de,sus productos que lo caracterizaba. La diversificación de la oferta no era :
sustentable si los productos no mantenían su excelencia, ya que como decía Augusto Parra, “nadie quiere un
pan novedoso si es malo. Por el contrario, debemos fabricar con las mejores recetas e ingredientes, ya que
además la disposición a pagar de los clientes lo permite.”
Ofrecer una gran variedad de productos de excelente calidad suponía, sin embargo, una gran exigencia en las
competencias del personal. En sus inicios, Augusto Parra comenzó su cadena con tres panaderos a quienes
entrenó personalmente en el estilo que él deseaba darle a las creaciones. Sin embargo, cuando el negocio
creció, se vio en la obligación de delegar el entrenamiento de sus panaderos. Para ello contrató a un
consultor, Carlos Matta, quien estaba a cargo de ayudarlo a diseñar un conjunto de políticas de capacitación
y de remuneraciones, para enfrentar óptimamente el crecimiento de personal que Vienna necesitaba y lograr |
sus objetivos estratégicos. . |
Matta creó e implementó un sistema de capacitación interna: los panaderos más antiguos, basados en su |
experiencia, entrenarían a los nuevos panaderos. La justificación del consultor para esta iniciativa era que
nadie mejor que los panaderos antiguos, partiendo por aquellos que fueron entrenados por Augusto mismo y
que por lo tanto conocen el sello que él desea darle a los productos, para seguir con la tarea de crear la mejor
y más amplia gama de productos. Para ello dividió a los panaderos en.grupos de trabajo bajo la supervisión |
de uno de los panaderos antiguos a los cuales, informalmente y de manera verbal,-sé les denominó “Panadero
Jefe.” Aquellos panaderos a los que se designaba en esta última función de Panadero Jefé, pasaban entonces
de tareas productivas a ser instructores. Su trabajo consistía primero en mostrar cómo se cocinaban los
productos de Vienna y luego, una vez que los panaderos ya conocían las recetas, debían supervisar la
ejecución de las mismas. Se les agregó también responsabilidad de crear nuevos productos. -
Al respecto, uno de los Panaderos Jefe comentaba sobre el desempeño de su nueva función: “los panaderos
son tan porfiados Don Augusto ... no me hacen caso. Yo les digo cómo se hacen las cosas y no me entienden
... y Se van temprano y llegan tarde ... Yo los reto, pero no me escuchan. Es más, estoy incómodo con mis
nuevas responsabilidades. A mí nadie me preguntó si quería asumir estas nuevas tareas. Preferiría volver a
mi puesto de panadero. Lo que a mí me gusta es cocinar. La verdad es que yo acepté ser Panadero Jefe
porque el sueldo era el doble de lo que ganaba antes y me dijeron que el trabajo era el mismo.”
Dado que la decisión adoptada por la empresa involucraba la creación de un nuevo puesto, la política de
capacitación de panaderos debía necesariamente ir aparejada con un nuevo esquema de incentivos. Carlos
Matta consideró entonces que los Panaderos Jefes debían ganar sustancialmente más que el resto de los
panaderos ya que el salario debía reflejar la mayor responsabilidad del nuevo cargo. Para ello les aumentó el
salario fijo hasta casi el doble y les advirtió que éste podría ser ajustado en el futuro (al alza o a la baja)
según como estuvieran los números de la empresa. No se agregó ninguna instancia formal de evaluación ni
feedback. Matta creía que duplicar el sueldo fijo era suficiente para que los nuevos Panaderos Jefes se
esforzaran para mantener su puesto.
Nueve meses después de que se implementó el nuevo puesto de Panadero Jefe, Augusto Parra citó a Carlos .
Matta para evaluar el programa de capacitación y remuneraciones diseñado e implementado por este último.
El fundador de la empresa le comunicó a Matta su preocupación porque, desde el trimestre anterior, las
ventas habían bajado y las encuestas de satisfacción mostraban clientes que ya no creían que los productos de
-----
5
Vienna fueran ni los más diversos, ni los de mejor calidad. A luz de la encuesta de satisfacción que habían |
implementado en todos los locales, los clientes señalaban que Vienna se había transformado en un empresa ,
con una línea de productos limitada y, peor aún, de calidad mediocre. Carlos Matta, sin embargo, argumentó
que no creía que la disminución de las ventas y la peor percepción de los clientes se debía a un problema de :
la gestión de recursos humanos. Según él, “como los Panaderos Jefe conocen perfectamente la línea de
productos que se desea en Vienna, entonces lo más probable es que el problema se deba a que la demanda se
encuentra deprimida y tal vez a que se ha puesto más exigente”. Para remediar esta situación, Carlos Matta |
le recomendó a Augusto Parra que entregara un bono variable extra a los Panaderos Jefes por cada producto |
nuevo que crearan para poner a la venta. á
Parra, sin embargo, no estaba convencido con la explicación que le daba Matta respecto a la caída de las |
ventas y la satisfacción de los clientes. También tenía dudas respecto de la entrega del incentivo variable |
propuesto.
PREGUNTAS
1) Suponga que con el objetivo de mejorar la situación de la empresa Augusto Parra lo contrata a usted |
como nuevo asesor de recursos humanos. Para ello se le pide evaluar el plan de capacitación y
compensaciones implementado por Carlos Matta, así como su nueva sugerencia de incorporar un bono
variable, describiendo los tres principales problemas que enfrenta dicho esquema. Sea breve y preciso
en su respuesta.
2) Formule tres recomendaciones para mejorar el sistema de capacitación y compensaciones de los !
: Panaderos Jefes. Justifique su respuesta de manera concisa. |
-----
o - o a o Ls 1
6 |
PREGUNTA N' 3 :
Durante muchos años una empresa chilena ha mantenido la política de repartir a sus accionistas, como
dividendo en efectivo al término de cada año, un 60% de sus utilidades después de impuestos. Los
dividendos de esta compañía han crecido y se espera que continúen haciéndolo en forma indefinida al 4%
anual. La empresa no utiliza deuda para el financiamiento de sus proyectos, sino únicamente sus utilidades i
retenidas (40% de las utilidades) que son íntegramente reinvertidas, todos los años, en proyectos que tienen |
un rendimiento de 10% anual después de impuestos y que generan flujos de caja perpetuos. La tasa de
descuento pertinente, después de impuestos, es un 8% anual y la tasa de impuestos corporativos asciende
actualmente a un 20%.
Para las preguntas que se le formulan a continuación, trabaje bajo los supuestos del modelo de crecimiento
perpetuo de Gordon.' Ignore la'existencia de impuestos personales y suponga que hoy es el 1 de enero de
2015. Justifique sus repuestas mostrando los cálculos necesarios.
PREGUNTAS
1) Si la empresa espera obtener utilidades después de impuestos de $2.500 millones durante 2015 y
planea mantener la política de dividendos histórica. ¿Cuál será su valor económico?
2) Enla reforma tributaria que se discute en el Congreso se plantea subir el impuesto a las utilidades de |
las empresas a 27%. Si la compañía mantiene la política de repartir el 60% de sus utilidades después |
de impuestos y suponiendo que la tasa de descuento pertinente sigue siendo un 8% anual, ¿Qué |
impacto tendrá la reforma sobre el valor de la empresa? Haga explícitos los supuestos adicionales
que estime necesarios. |
3) Suponga ahora que se aprueba la reforma tributaria y que la tasa de impuestos corporativos aumenta
a 27% a partir del año 2015. A raíz de esto, la.empresa toma la' decisión de. ajustar la tasa de reparto
de dividendos de forma tal de mantener la tasa de crecimiento de las utilidades en 4%. Si la tasa de
descuento pertinente se mantiene en un 8% anual ¿Cuánto cambia el valor económico de la empresa
en este escenario, con respecto a la situación inicial?
1 El modelo de Gordon establece que el precio de una acción (P,) cuyos flujos de caja (dividendos) crecen en forma
d,
indefinida a una tasa anual g se puede calcular con la fórmula: P, = —L— donde d, es el dividendo en efectivo que se
r=8
espera recibir en un período más y r es la tasa de descuento de los flujos de caja esperados.
-----
7 Z Z - |
PREGUNTA N' 4 (
En el año 2013, este juego perdió más de un millón de jugadores en el país del Norte.
Recuperar los niveles que tenía hace diez años, parece difícil, pero aparecen luces de esperanza.
Hace no mucho tiempo, el golf se consideraba una actividad elegida para establecer vínculos corporativos y el i
vehículo directo para verse exitoso. Sin embargo, hoy las compañías dependen menos de las “relaciones 0
sociales”, y mucha gente joven no se ve atraída por una actividad que se percibe como altamente consumidora
de tiempo y muy elitista. El resultado de lo anterior se ha dejado ver en los últimos años: el golf ha sufrido, y
está sufriendo aunque con alguna esperanza de mejoría, un éxodo de jugadores acompafíado por el cierre de
muchas canchas. En efecto, el número de golfistas hoy en día en Estados Unidos se estima en 23 millones de
personas, un 24% menos del nivel que existía diez años atrás, de acuerdo con proyecciones de Pellucid, una
compañía consultora especializada en el negocio del golf.
¿Qué puede explicar lo que ocurre en la industria? Son varios los factores: el juego es dificil cuando se desea
jugar bien; requiere mucho tiempo para jugarse; y es un juego caro. A lo anterior se agrega los escándalos |
protagonizados por el principal jugador del mundo, lo que a juicio de algunos también pudo haber afectado el |
desarrollo de este deporte. Asimismo, la abultada tasa de construcción de canchas de golf en los años 90 llevó a
un exceso de capacidad en la industria, lo que dejó a varios de los actores en una posición muy vulnerable,
Sin embargo, no todas son malas noticias, y hay hechos que están generando alguna luz de optimismo en esta
alicaída industria. En efecto, las inversiones en tecnología hechas por las principales empresas de la industria,
están haciendo más sencillo jugar bien al golf, por la calidad muy superior que tienen en la actualidad los |
implementos claves de este deporte, como es el caso de los palos y las pelotas de golf. Por otro lado, varios |
jugadores jóvenes han logrado muy buenos" resultados en el circuito, lo que ha ayudado a reencantar por lo
menos a una parte de los jóvenes, con este deporte. El canal ESPN golf ha difundido ampliamente los |
principales torneos, atrayendo el interés por el golf a público que hasta ahora no ha mostrado mayor conexión |
con el deporte. Varios de los clubes de golf surgidos con el boom del deporte han desarrollado agresivas |
campañas de captura de socios, estableciendo así mismo acuerdos y convenios entre ellos, para facilitar y
abaratar el costo del juego. Todo lo anterior, hace pensar a algunos que estaría comenzando un posible cambio
de tendencia en el sector, razón por la cual valdría la pena estar en esta industria y apostar por ella.
Las preocupaciones de fondo
Sin lugar a dudas la mayor preocupación de los analistas del sector y que los inquieta más que cualquier otro |
factor, es el cambio generacional que ha experimentado el mercado, y cómo las nuevas generaciones están '
respondiendo, fríamente y con cierto desinterés, ante el golf en Estados Unidos. El propio Jim Koopen,
Presidente de Pellucid, comentaba en una entrevista aparecida el mes pasado: "Tenemos que encontrar una
manera de contener la disminución de golfistas, partiendo por solucionar la tendencia en cuanto a que las
nuevas generaciones no se están interesando en el golf, y no se ve que alguien esté haciendo algo para detener
lo anterior”, terminaba diciendo.
Reacciones de algunos actores
Han sido varias y profundas las formas en cómo, diversas empresas, todas partícipes de esta industria, aunque
no necesariamente competidoras entre sí, han reaccionado ante la difícil situación que se está experimentando en
el mercado. A continuación, se exponen las reacciones de tres actores diferentes del sector.
- Golf Technology: es una empresa especializada en implementos para el golf, líder en el mercado
norteamericano, que cuenta con el 70% de participación en el mercado de implementos técnicos para el
juego. Palos y pelotas de gran tecnología conforman el grueso de sus mix de oferta. Es reconocida como
una empresa especializada, líder en innovación tecnológica aplicada a implementos para el golf. Su
gerente general comentaba la semana pasada en una revista especializada: “Veinte meses atrás, vendia
los palos de golf a un precio promedio de 850 dólares cada uno, mientras que hoy los mismos productos
los vendemos a un precio promedio de 8350, menos de la mitad del precio de hace dos años”. El primer
semestre de 2014 fue el quinto semestre consecutivo de descenso en las utilidades de la empresa, lo que
-----
8 |
acumula una caída de más del 40% en los últimos 3 años. El Directorio está cuestionando la permanencia
de la empresa en el mercado y evaluando su cierre.
- Adidas: es una gran empresa diversificada en deportes, que participa activamente en el diseño,
producción y comercialización de artículos de ropa y zapatos deportivos. Hace 5 años, Adidas compró
una división de vestuario deportivo y zapatos de golf. Posee una oferta muy acotada y menor de
implementos. La línea golf de Adidas representa en Estados Unidos el 5% de su EBITDA. En la última
reunión de Directorio de Adidas, el Directorio quedó en un virtual acuerdo de reducir significativamente |
la inversión en la Unidad de Negocio de Golf.
- Clubes de Golf: en Estados Unidos existen principalmente de dos tipos: los clubes de golf privados, que E
son propiedad preferentemente de familias empresarias que están en el negocio inmobiliario, y que se
abrieron como respuesta al explosivo crecimiento que experimentó el golf. Por otro lado están los Clubes
de Golf Públicos, que son provistos por el Estado, quien ha dedicado terrenos exclusivos para fomentar la
vida al aire libre que provee el golf. Los Clubes Públicos construidos han sido declarados zona protegida
por el Estado, y no pueden destinarse a ningún otro fin distinto al del golf por los próximos 50 años.
PREGUNTAS
1) En los últimos meses se ha observado una tendencia a la colaboración o cooperación entre los diferentes
actores (no necesariamente competidores) que participan en la industria del golf, con el objeto de reflotar
este deporte, ¿Qué razones específicas pueden explicar esta conducta colaborativa? Señale dos razones
debidamente argumentadas. |
2) En el caso se presentan cuatro actores diferentes en esta industria: Golf Technology, Adidas, Clubes de
Golf Privados y Clubes de Golf Públicos. Haga un ranking, ordenando a estos actores, desde mayor a |
menor nivel de disposición, que cada uno ellos tendría para colaborar o cooperar con otros actores de la |
industria. Fundamente su respuesta
3) ¿En qué aspectos específicos debiera haber colaboración entre los distintos actores para reflotar la |
industria del golf? Señale dos aspectos concretos argumentando en forma breve y precisa...”
-----
9 :
PREGUNTA N* 5
Balmaceda es una compañía chilena de danza moderna que crea montajes para hacer presentaciones en salas
de teatro y espectáculos en las principales ciudades del país. Según Enrique Balmaceda, su fundador y
director ejecutivo, “...nuestra misión es llevar la danza moderna a muchos espectadores, a través de |
espectáculos novedosos que logren una conexión emocional con la audiencia”. La compañía Balmaceda ha i
sido exitosa en Chile, por lo que ahora se plantean un nuevo desafío: crecer a través de una expansión al
resto de los países de Latinoamérica, es decir, llevar espectáculos de danza moderna nuevos y de alta calidad
a audiencias de otros países de la región.
Con el fin de llevar a cabo este desafio, la compañía ha contratado recientemente como Gerente de
Marketing a Natalia, una ex bailarina de la compañía, que hasta hace poco se desempeñaba de manera
exitosa como gerente de negocios de una tienda de ropa deportiva. Enrique Balmaceda le ha encargado a
Natalia que diseñe e implemente la estrategia de expansión internacional de la empresa.
;
El primer desafío de Natalia es desarrollar los nuevos “productos” que se ofrecerán, es decir, crear los
espectáculos específicos de danza moderna que se presentarán en el resto de Latinoamérica. Con este
objetivo en mente, y aprovechando la experiencia adquirida en su trabajo anterior, Natalia le plantea a
Enrique Balmaceda la necesidad de realizar estudios de mercado de consumidores (audiencia potencial) en .
esos otros países. Sin embargo, y para su sorpresa, Natalia se encontró con la siguiente respuesta de Enrique:
“No necesitamos hacer estudios de mercado de consumidores. ¿Por qué tenemos que preguntarle a la
audiencia lo que quiere? Cuando las personas vienen a nuestro show, esperan una experiencia única y
fantástica, una que nunca podrán olvidar. ¿Cómo pueden las personas decir lo que quieren si nunca lo han
visto? Si les preguntáramos, terminaríamos haciendo el tradicional ballet 'El Lago de los Cisnes' todos los
años.” 0 |
En favor de la posición de Enrique Balmaceda, no son pocas las empresas que operan de acuerdo a esta
filosofía de no involucrar a los consumidores en estudios de mercados conducentes a desarrollar nuevos |
productos. Por ejemplo: (i) la joyería Tiffany no le pregunta a las mujeres por el tipo de joyas que necesitan;
(ii) Steve Jobs, de Apple, señaló en una oportunidad: “... muchas veces las personas no saben lo que quieren
hasta que lo ven” y (iii) Mario D'Amico, Vicepresidente de Marketing de Cirque du Soleil, declaró hace
algún tiempo “... cualquier empresa innovadora se cuestiona cuánto se debe preguntar a los.consumidores;
la misión central de nuestra compañía es hacer lo que ningún consumidor espera que hagamos”.
PREGUNTAS .
1) ¿Está Ud, de acuerdo con la posición de Enrique Balmaceda, en cuanto a que la compañía no debería
hacer estudios de mercado con los potenciales consumidores (audiencia) de los espectáculos de danza
moderna, y con los argumentos que él plantea? Justifique su respuesta.
2) Suponga que Enrique Balmaceda, para no frustrar a Natalia y darle la oportunidad de demostrar el valor
de su propuesta, acepta que se realice un solo estudio de mercado con la audiencia potencial, definida
como personas de grupos socioeconómicos medios y altos, que asisten al menos 4 veces al año a
espectáculos artísticos en los ámbitos de teatro, danza, o música. Natalia debe decidir cuál de las
siguientes metodologías de investigación (recolección de datos) utilizar: (a) encuestas presenciales en
hogares, utilizando un cuestionario estructurado (preguntas cerradas) de unos 20 minutos de duración;
(b) entrevistas en profundidad de 45 a 60 minutos de duración, en un lugar especialmente habilitado para
ello; o (c) etnografía, en que durante e inmediatamente después de la realización de espectáculos de
teatro, danza o música, se observa a la audiencia y se interactúa con ella a través de breves entrevistas (3
a 5 minutos). ¿Cuál de estas tres opciones elegiría y por qué? Fundamente su respuesta.
-----
10 |
PREGUNTA N'* 6 |
l
Catalina es una joven empresaria, egresada de Ingeniería Comercial de la PUC, que ha estado operando un !
negocio que consiste en vender trajes de novia a través de su local Novias. Lo que ella hace, es vender vestidos |
en Chile, mandados a hacer a pedido por las novias. Actualmente, Catalina envía el modelo y las medidas a una |
pequeña fábrica en Vietnam, lugar donde los vestidos son pre-confeccionados y posteriormente enviados a Chile.
Luego, en Chile, el vestido es probado por la novia y se procede a terminar su confección, afinando únicamente |
sus detalles finales. : |
Lamentablemente, en los últimos meses Catalina ha venido enfrentando algunos atrasos en el cumplimiento de los a
pedidos que deben llegar desde Vietnam, lo que acarrea muy serios problemas con sus clientas. Como resultado a
de lo anterior, Catalina está evaluando la posibilidad de fabricar los vestidos en Chile. da
A usted se le pide evaluar el proyecto que ella tiene en mente, esto es, evaluar la conveniencia financiera de
dejar de importar los vestidos y pasar a fabricarlos íntegramente en Chile.
Algunos datos que Catalina estima deberá tener en Cuenta en el análisis de su decisión, son los siguientes: |
e Se supondrá que hoy es el 31/12/2014 (t = 0) y que Catalina debe tomar hoy la decisión de seguir importando |
o comenzar a fabricar los vestidos en Chile.
e En primer lugar, Catalina sabe que en el caso de fabricar, ella tendría que firmar hoy (t = 0) un contrato de
arriendo de un pequeño local adicional al que arrienda actualmente, en el que podría fabricar los vestidos, cuyo
costo anual sería de M$400. Los pagos de arriendo anuales serían hechos por adelantado, por lo que al :
finalizar cada año, excepto el año en que termina el contrato, ella debe pagar el arriendo completo del año que |
comienza el día siguiente, Adicionalmente a los pagos anuales de arriendo, la empresa tendría que pagar en
efectivo y al momento de firmar el contrató, una garantía correspondiente a un año de arriendo (M$400). El
contrato de arriendo sería por tres años, y en él se estipula que al término del segundo año de vigencia del
contrato, esto es, el 31/12/2016, a Catalina se le devolverá, en efectivo, el monto total de la garantía (M$400). |
o La remodelación y adaptación del local, para dejarlo en condiciones de comenzar a operar como fábrica,
tendrían un costo de M$200, los que tendrían que ser pagados completamente y en efectivo al momento de
firmar el contrato de arriendo (t= 0). Para efectos tributarios, la empresa puede llevar a gasto, al término del i
primer año de operación (no antes), el costo total de la remodelación. * e o
e Finalmente, se sabe que en caso de optar por la producción propia de los vestidos, la empresa Novia”s tendrá
que comprar hoy, pagando al contado, una máquina adicional que tendría un costo de M$1.500, una vida útil
de 3 años y para efectos tributarios se podría depreciar de mánera lineal y sin valor residual. :
e El Cuadro N'1 de la página siguiente presenta la siguiente información:
- Estado de Resultados proyectado para los próximos 3 años, en el evento en que la empresa Novia”s optase
por continuar importando todo desde Vietnam (columna IM).
- El Estado de Resultados proyectado para los próximos 3 años, en el evento en que la empresa Novia”s
decidiera dejar de importar y pasara a un esquema de producción propia (columna PP).
o En llo que se refiere a inversión en Capital de Trabajo (CT?), se sabe que en el caso de optar por la producción
propia (PP), la operación de la empresa de Catalina requeriría, al iniciar sus operaciones y luego al término de |
cada año, de una inversión en CT” algo mayor que la que se necesitaría en el caso de seguir con el modelo de |
importar los vestidos (IM). El Cuadro N2 de la página siguiente muestra la inversión en Capital de Trabajo |
requerida al término de cada año (para iniciar el año siguiente de operaciones), para ambas alternativas (IM o
PP). Se sabe, en todo caso, que al 31/12/2014 y antes de evaluar la opción de fabricar los vestidos en Chile, la
empresa ya cuenta con una inversión en CT” de M$2.000,
e Se sabe también, que para operar de manera eficiente, sea que la empresa decide seguir importando o que
comience a fabricar los vestidos, ella deberá realizar al término de cada año reinversiones por el equivalente a
1,2 veces el gasto por depreciación anual. Estas reinversiones no afectan el monto del gasto anual por
depreciación que aparece en el Cuadro NO 1 para las alternativas IM y PP.
-----
á
: |
11 |
o Para estar más tranquila con las estimaciones de venta, la empresa ha encargado un estudio de mercado cuyo
costo es de M$1.000 y que debe ser pagado en efectivo integramente el primer día del proyecto (t= 0). :
e La política de dividendos de la empresa, es repartir al término de cada año, el monto total de efectivo residual :
disponible para los dueños. |
e Se ha determinado que la tasa de actualización relevante para los flujos de caja que recibiría Catalina, única |
dueña de la empresa, es de 10% anual. Se espera que esta tasa se mantenga constante en el futuro.
+ Los flujos de caja, con la sola excepción de la inversión inicial, toda la cual se produce el 31/12/2014 (t = 0),
se producen al término de cada año. Suponga también que la empresa mantiene únicamente activos |
operacionales, que no hay impuestos personales, inflación, ni IVA.
e Suponga que, en caso de continuar el negocio importando los vestidos, al término del tercer año la dueña de
Novia's podría vender el negocio “en marcha” (funcionando) y recibir M$45,000 en efectivo, luego de haber
considerado tanto la deuda del negocio vigente en ese momento, como los impuestos que pudiera corresponder
pagar. Por otra parte, si se opta por cambiar hoy a producción propia, dicho valor a recibir por parte de la
dueña sería de M$60.000.
Cuadro N*1
Definiciones: Estados de Resultados Proyectados
TM = Con Importación de Vestidos Noyia's :
PP = Con Producción Propia (Montos son en Miles de $)
A 2017
A ———————— MARA APA AMA]
Ingresos por Venta 8.000 12.000 10.000 14.000 12.000| 18.000]
- Costo de Ventas -1,600 -3.000 -2.000| -3.500 -2.4001  -4.500 |
- Gastos de Administración y Ventas [GAV] |
GAV Fijos -800 -1.440| -1,000 -1.680| -1.200) -2.160
GAV Variables -400 -1,200| -S00 -1,400| -600 -1.800
- Depreciación del Ejercicio [1] [2] -500 -1.000| -5$00 -1.000| -500 -1.000
= Resultado Operacional 4.700 5,360| 6.000 6,420 7.300 8.540
- Gastos Financieros -1.000 -1,000| -1.000| -1.000 -1,000 -1.000|
|- Gasto No Operacional (Remodelación) -200
= Utilidad Antes de Impuesto 3.700 : 4,160 5:000| 5,420 6:300| 7.540|
- Impuesto a las Utilidades (25%) -925 -1.040]. '1.250| 1,355 «1,575 -1.885
- Resultado del Ejercicio (Utilidad Neta) Y 20775 | 310 3750] 406s] — 4.725[ 5.655]
.
[1]: El total de la depreciación del ejercicio del año de la empresa, 12] La opción de PP incluye M$500 de depreciación
está reflejado en esta cuenta. Las cuentas "Costo de Venta" anual por la nueva máquina que habría :
y "GAV”, no incluyen gastos por depreciación. que comprar.
Inversión en Capital de Trabajo Operacional Requerida
Novia's
(Montos son en Miles de $)
31/12/2014 31/12/2015 31/12/2016 31/12/2017
Inversión en Capital de Trabajo Importaciones (IM) 250 113000 1350]
Inversión en Capital de Trabajo Producción Propia (PP) | 4200 [| 490 [| 6300 [8.4001
[5]: 31/12/2014 (IM): Corresponde a la Inversión en CT? que ya tiene la empresa al 31/12/2014. e
|
PREGUNTA |
Evalúe financieramente la conveniencia de dejar de importar los vestidos y pasar a fabricarlos íntegramente en |
Chile. : |
: |
-----


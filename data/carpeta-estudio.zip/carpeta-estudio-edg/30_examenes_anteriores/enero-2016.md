# Examen de grado · enero-2016

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


PONTIFICIA UNIVERSIDAD CATÓLICA DE CHILE
ESCUELA DE ADMINISTRACIÓN
a
ESO
El a
ECH
EXAMEN DE GRADO
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
que los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4, No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
realidad de las empresas que allí se mencionan. :
5. Si como parte de alguna de sus respuestas Ud, hace uso de uno o más supuestos, deje expresamente indicados
dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente al Profesor Ignacio Rodríguez, Presidente de la Comisión
de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
condiciones, el Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alummo(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala, los que deberán estar apagados y no
deberán mantenerse sobre el escritorio durante el examen.
12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
como “borrador”, esas hojas no se deben entregar con las respuestas.
Fecha : 22 de enero de 2016
Duración  : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el Profesor
Ignacio Rodríguez, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 y
11:00 hrs. (aprox.).
-----
2
h PREGUNTA N* 1
Un reciente estudio concluyó que los chilenos somos los que tomamos más té en latinoamérica, llegando a la
cifra de 77 litros anuales. Se trata de 387 tazas anuales per cápita (versus 86,7 en Argentina). El té en Chile tiene
una penetración de mercado del 99,4% y mientras nuestros vecinos siguen deleitándose con el mate, la hoja de
coca y el café, nosotros seguimos disfrutando este legado británico. Las estadísticas nos indican que cada chileno
consume por lo menos una taza de té al día, lo que nos ubica dentro de los 20 consumidores, per cápita, más
grandes del mundo. A nivel mundial el consumo del té va en aumento, debido a clientes que buscan estilos de
vida más saludables y que han reorientado su consumo hacia el té de variedades como el té verde y los
saborizados, dejando de lado otras bebidas con mayor cafeína o azúcar, así como también clientes que buscan
sofisticar su consumo con productos de mayor valor agregado. Al igual que con el café, se observa un segmento
creciente de consumidores que valoran y conocen los distintos orígenes geográficos y variedades de té.
La categoría en Chile ha crecido un 10% en valor en los últimos 5 años, llegando a US$ 205 millones en ventas,
aunque a nivel de volumen creció menos del 5% en dicho período. El mercado nacional está liderado por dos
empresas: Cambiaso Hermanos, con un 46% de participación de mercado en volumen (Té Supremo y Pure
Ceylon Tea) y Unilever con un 43% de participación (Lipton y Té Club). Aproximadamente un 85% de las
ventas de Cambiaso Hnos. y Unilever en la categoría Té, provienen de las líneas tradicionales más económicas
(precio menor a $800 por caja de 30 unidades).
Durante el año 2015, Cambiaso Hnos. lanzó al mercado, bajo su marca Té Supremo, la línea “Pirámides”, con
mezclas de té premium de la India y bajo un empaque en forma de pirámide que aprovecha de manera más
eficaz el té y se acerca a los envases similares de marcas premium como Twinnings y otras importadas, que las
tienen en sus líneas de productos.
cn di
pe ol E
A: E
A a de PRUEBA LAS NUEVAS PIRAMIDES
A E AS E
E La E E E E El
e. e eo oo RA + O st co de E
PES A OR A
FE A FR
y ha AE
HSA
La mezcla comercial de “Piramides” incluye publicidad en medios masivos como TV abierta , diarios y redes
sociales, con un personaje indio y un mensaje que privilegia el humor y el origen indio del té, y distribución
intensiva a nivel nacional a través del canal “supermercados” orientados al segmento socio económico medio-
alto. Los precios a público de “Pirámides” son de aproximadamente $2.800 (por caja de 15 unidades)
comparados con la línea Té Supremo Ceylán (precio de $880 por caja de 30 unidades) y Té Supremo Rendidora
(precio de $360 por caja de 30 unidades). Otros competidores que traen té importados tales como Twimings,
tienen precios que oscilan en el rango $3.000 - $3.960. Unilever, el mayor competidor de Cambiaso Hnos.
tiene líneas de té con precios similares en los rangos menores a $1.300.
El cuadro que se muestra a la derecha, resume los rangos de precios yA
a MA q d Lai premo.
promedio a público a los cuales se venden las distintas líneas de té bajo eo
la marca Té Supremo de Cambiaso Hermanos. Los precios corresponden sa 28
a cajas que contienen 20 unidades (bolsitas) con excepción de “Pirámides Blrámides | 22.820
que trae 15 unidades (bolsitas) por caja. |
|
Saborizados | [$ 1.080 -$ 1.200]
Ceylan | [$750 - $ 879]
Rendidora | [$320 -$ 400]
Nota:
Cajas de 20 unidades excepto Pirámides
que trae 15 unidades por caja.
-----
3
PREGUNTAS
1) Considerando la posición competitiva de Cambiaso Hermanos y el contexto del mercado descrito,
explique las tres principales razones comerciales que justificarían el lanzamiento de “Pirámides” para
dicha compañía. Sea breve y preciso en su respuesta.
2) Usted recibe un estudio de seguimiento de las compras (“tracking de marca”) de los 3 primeros meses del
lanzamiento de “Pirámides”, el cual muestra que la tasa de prueba del nuevo producto por parte del
segmento objetivo, es la mitad de lo presupuestado, pero la tasa de recompra de estos consumidores es
mucho más alta de lo esperado, así como también la cantidad comprada y la frecuencia de compra.
¿Cuáles son los factores comerciales más relevantes para explicar los resultados a la fecha del estudio?
Argumente usando conceptos de marketing y la información provista en el enunciado.
-----
4
. PREGUNTA N* 2
En aquella tarde otoñal todo parecía bajo control en la oficina de Emilio Ruíz, Gerente General de Pura Luz, la
principal empresa de distribución eléctrica del país. Sin embargo, cuando ya se disponía a regresar a casa, el
ejecutivo recibió una llamada del Gerente de RR.HH. de la empresa comunicándole la muerte de un trabajador de
la empresa contratista Instalaciones Altiro, que realizaba trabajos para Pura Luz. El trabajador había caído desde .
una altura de 4 metros al estar reparando líneas eléctricas.
Un año antes de esta fatalidad, en su proceso de planificación estratégica, Pura Luz había definido 4 pilares
estratégicos para los próximos años: (1) aumentar sus utilidades posicionándose por sobre la media de las
empresas de su industria; (2) mejorar la satisfacción percibida por sus clientes en el servicio; (3) incrementar el
uso de tecnología en sus procesos, particularmente en aquellos vinculados con el servicio a los clientes y (4)
mejorar sustantivamente la seguridad laboral del personal propio y de las empresas contratistas de Pura Luz.
La empresa distribuidora contaba con 600 trabajadores propios y 2.000 personas pertenecientes a un conjunto de
40 empresas contratistas, que realizaban variadas funciones de construcción, instalación y mantención de equipos
y redes eléctricas. Mediante un contrato, Pura Luz encargaba dichos trabajos a algunas de sus empresas
contratistas, quienes con su propio personal realizaban dichas labores y luego informaban a un supervisor de Pura
Luz respecto de lo realizado, junto con el envío de la factura correspondiente. Desde luego la gestión de todos los
aspectos comerciales, financieros, laborales y de seguridad era de responsabilidad de la empresa contratista. Por
su parte Pura Luz, de acuerdo a la ley, tiene una responsabilidad subsidiaria con la empresa contratista, debiendo
responder si esta última no cumplía con sus obligaciones laborales y previsionales respecto de sus trabajadores.
El accidente laboral constituyó un aviso para la Gerencia General, de que los pilares estratégicos definidos por la
empresa meses antes, no se estaban cumpliendo. Si bien las utilidades eran mejores que las de la industria, las
quejas que escuchaba de los clientes por la baja calidad de servicio eran continuas e iban en aumento, muchas
áreas de Pura Luz no lograban los resultados esperados y la empresa aún no estaba a la altura de la tecnología que
ya utilizaban otras empresas de distribución eléctrica. Por ello decidió modificar sus políticas y prácticas de
gestión de personas de modo que ellas contribuyeran efectivamente a la consecución de los pilares estratégicos.
Lo primero que hizo Emilio Ruíz fue modificar el sistema de evaluación de metas y los incentivos que existían en
Pura Luz. Hasta ahora, todo el personal era evaluado exclusivamente por la utilidad obtenida por la empresa cuyo
cumplimiento estaba asociado a un bono variable si se lograba la meta de utilidad definida por la empresa. El
Gerente General presentó al Directorio un sistema de evaluación de metas asociado al pago de bonos variables
por su cumplimiento. Con este esquema, Ruíz pretendía minimizar los accidentes y, al mismo tiempo, medir y
recompensar los resultados asociados a los diferentes pilares estratégicos definidos meses antes. El tablero de
indicadores propuesto era el siguiente:
Teorias | ito] 0 Tre
para el Bono
las áreas) - media de la industria
20
ue generan ingresos y gastos) áreas de negocio ejercicio anterior
Índice de satisfacción de
servicio (encuesta externa
-
clientes pregunta por el nivel (escala 1 a 100)
general de satisfacción
con el servicio)
% de clientes cuyo
asa : settidor sa ls d 50% de clientes
4 Incorporación de tecnología en el satelitalmente (sin cubiertos por 10%
servicio a clientes necesidad de que ix :
concurra un visitador al mito ale
domicilio)
-----
5
ci | e [et
¡jetivo a Evaluar Indicador Meta
ara el Bono
a) N” de accidentes de a) Menos de 4
personal propio y accidentes por
contratistas cada 100
b) Gravedad (n? de días trabajadores
sin trabajar) del propios o
personal accidentado contratistas
propio y contratistas b) Menos de 60 días 15% (5%
5 | Seguridad laboral del 1 Cc) N” de muertes por sin trabajar por d d
guridad laboral del persona : a cada una de
accidentes del trabajo cada 100
de personal propio y trabajadores las metas)
contratistas propios o
contratistas
c) Cero muertes en
el trabajo de
personal propio y
contratista
De acuerdo al nivel de logro alcanzado en los indicadores antes mencionados, cada persona en la empresa,
podría recibir un pago variable por cumplimiento de entre 0 y 5 sueldos adicionales al año (además de sus 12
sueldos base). !
Adicionalmente, y para evitar que ocurrieran nuevos accidentes, y así cumplir con lo establecido en el cuarto
pilar estratégico definido por la empresa (preocupación por la seguridad laboral del personal propio y de
empresas contratistas), el Gerente General decidió implementar las siguientes medidas:
e Entregar a todo el personal un instructivo de seguridad estableciendo los “procedimientos seguros” que
cada persona en la empresa debía seguir estrictamente para evitar accidentes y fatalidades en el futuro.
e Proveer a cada persona de Pura Luz, particularmente a aquellos en labores más peligrosas, toda la ropa y
elementos de seguridad necesarios para realizar sus tareas de manera segura. Ello incluía cascos, guantes,
arneses y otros elementos que de acuerdo a los expertos eran clave para evitar accidentes.
De manera análoga, se obligaría a todas las empresas contratistas como Instalaciones Altiro a seguir los
mismos procedimientos y entregar idéntica ropa y elementos de seguridad a sus propios trabajadores, para
evitar así que el personal contratista sufriera accidentes.
PREGUNTAS
1) El Gerente General de la compañía estaba convencido de que el nuevo esquema de evaluación de metas e
incentivos propuesto sería un factor clave para mejorar considerablemente e nivel de cumplimiento de los
4 pilares estratégicos de la empresa. Sin embargo, el Gerente de RR.HH de Pura Luz no comparte la opinión
del Gerente General. ¿Qué razones podría tener el Gerente de RR.HH. para estar en desacuerdo con el
Gerente General? Sea breve y preciso.
2) Frente al accidente ocurrido el Gerente General de Pura Luz señaló: “ ninguna empresa tiene el derecho a
que sus trabajadores no vuelvan sanos y salvos a sus casas después de la jornada de trabajo. Por ello, estoy
convencido de que las iniciativas propuestas de: (a) modificar el esquema de evaluación e incentivos en la
empresa, (b) proveer a todo el personal con la ropa de seguridad adecuada y (c) exigir una serie de
condiciones de seguridad a sus empresas contratistas; lograrán el objetivo de mejorar significativamente el
cumplimiento del cuarto pilar estratégico de la compañía que consiste en generar mejoras sustantivas en la
seguridad laboral del personal propio y de empresas contratistas que trabajaban para Pura Luz.”
Nuevamente el Gerente de RR.HH. discrepa del Gerente General de la empresa. ¿Qué razones podrían
explicar que el Gerente de RR.HH. piense que dichas medidas no lograrán el objetivo que se proponen?
Argumente en forma breve y concisa.
-----
6
: PREGUNTA N” 3
La compañía PPTT tiene el siguiente balance al 31/12/2015:
Activos Pasivos y Patrimonio
Activos Corrientes o Circulantes Pasivos Corrientes o Circulantes
Caja $ 5.000 Cuentas por Pagar a Proveedores $ 150.000
Cuentas. por Cobrar a Clientes 100.000 Deudas con Bancos (Corto Plazo) 0
Existencias 100.000 Pasivos No Corrientes (Largo Plazo)
Activos No Corrientes Deudas con Bancos (Largo Plazo) 100.000
Terrenos 295.000 (Ver Nota N*1)
Patrimonio
Capital 50.000
Utilidades Retenidas (UR) 200.000
(Ver Nota N*2)
Total Activos $ 500.000 Total $ 500,000
Nota N* 1: La primera amortización o pago de la deuda de largo plazo con los bancos, se debe hacer el año 2021.
Durante los próximos 5 años, anualmente se deben pagar únicamente los intereses devengados
Nota N? 2: Las UR son posteriores al pago de dividendos correspondientes al resultado del ejercicio 2015.
Información financiera relevante de la empresa:
e Las ventas del año 2015 de la empresa fueron de $1.000.000.
+  Seespera que las ventas del año 2016 sean de $1.200.000
+  Laproyección de margen neto anual sobre ventas (Utilidad Neta / Ventas) de los próximos 4 años es de un 15%
anual.
e El único movimiento de activos no corrientes que hará la empresa durante el año 2016, será la compra y pago al
contado un nuevo terreno para sus bodegas por valor de $172.000.
+ Dado su ciclo de efectivo, se sabe que las siguientes relaciones se dan de manera permanente en la empresa:
Ttemes Corrientes o Circulantes que Varían Espontáneamente con las Ventas (%):
o Itemes Circulantes como Función de las Ventas Anuales (%
Cuentas por Cobrar a Clientes 10%[Cuentas por Pagar a Proveedores 15%
Existencias 10%
% Activos Circulantes Espontáneos % Pasivos Circulantes Espontáneos
e Se sabe que al 31/12/2015, la empresa está financiada cumpliendo con el principio de “igualdad” o “calce”
(también llamado enfoque de equiparación de vencimientos para financiar el capital de trabajo).
e El Directorio ha definido las siguientes políticas financieras para la empresa:
«e Al término de cada año, el saldo en la cuenta “Caja” de la Compañía, debe ser de $5.000.
«+ Al término de cada año, la razón de endeudamiento (Deuda o Pasivos Totales/Patrimonio), medida en términos
contables, debe ser igual a 1,0.
«e Al término de cada año, se debe pagar como dividendos y en efectivo, el 63% del resultado del ejercicio de
dicho año.
«+ Al término de cada año, el financiamiento de la empresa debe cumplir con el principio de “igualdad” o “calce.”
Suponiendo que:
+ Todos los activos de la empresa son operacionales.
e Todas las ventas de la empresa son hechas otorgando crédito de corto plazo a sus clientes.
-----
P
: e Todas las compras de existencias que hace la empresa, son hechas usando crédito de sus proveedores.
e Todas las compras y ventas de la empresa son uniformes durante el año.
+  Laempresa sólo tiene tres tipos de pasivos: Cuentas por Pagar a Proveedores (que no genera intereses explícitos),
Deuda de Corto Plazo con Bancos y Deuda de Largo Plazo con Bancos.
e  Todoslos fondos que la empresa requiera para su financiamiento, cualquiera sea su origen, se solicitan y se dispone
de ellos al inicio (el primer día) del año en que se solicitan o emiten en el caso de acciones.
e  Todoslos costos o gastos financieros (intereses) relacionados con el financiamiento con deuda tanto pasada (deuda
al 31/12/2015) como futura (nueva deuda) de la empresa ya han sido considerados en el margen neto de ventas de
15%, Este margen neto no cambia frente a las distintas formas de financiamiento que adopte la empresa.
e  Unaño tiene 360 días y un mes 30 días.
e No hay inflación y se espera que no haya cambios en los valores de mercado de activos o pasivos.
e El balance de la empresa está constituido únicamente por las cuentas que se desprenden del enunciado.
Responda las preguntas que se le formulan a continuación, mostrando los cálculos que sean necesarios:
1) Obtenga el monto ($) de "Financiamiento Externo Requerido" (F.E.R.) por la empresa “PPTT” para el año
2016 (recuerde que para el año 2016 se estima que las ventas aumentarán a $1.200.000). Fundamente su
respuesta,
2) Suponga ahora que, luego de conocido el F.ER. para el año 2016 (obtenido por Ud. en la pregunta anterior),
la empresa ha proyectado todos los movimientos de caja esperados para cada uno de los años 2017, 2018 y
2019, y ellos son los siguientes:
Superávit/(Déficit) de Caja del Año ($80.000) + $95.400 (superávit) ($120.000)
A usted se le pide que obtenga el “Financiamiento Permanente” requerido por la empresa, considerando el
período 2016 a 2019 (ambos años incluidos). Muestre el procedimiento.
3) Suponga ahora que la empresa está elaborando su plan de financiamiento para el período 2016 a 2019 (ambos
años incluidos), de modo de cumplir con las cuatro políticas financieras señaladas anteriormente en el
enunciado.
La empresa ha estimado que para el período que se está planificando (2016 a 2019), ella usará como fuentes
de financiamiento, complementarias a las que se encuentra actualmente utilizando al 31/12/2015, las siguientes
tres fuentes de financiamiento, que pueden ser usadas en las proporciones que la compañía estime conveniente:
«< Deuda Bancaria de Corto Plazo
«+ Nueva Deuda de Largo Plazo la que se puede emitir con 6 años de gracia (la primera amortización del
principal de la deuda se debe hacer en 6 años más). Los intereses siempre se deben pagar al término del
año.
«+ Nuevo Patrimonio o Aportes de Capital en efectivo por parte de los dueños.
A usted se le solicita determinar el monto de recursos ($) de cada una de las tres fuentes de financiamiento que
se le han indicado, que debiera proyectar la empresa PPTT, para el financiamiento de sus actividades en el año
2016 (solamente el 2016), de modo de cumplir con las cuatro políticas financieras señaladas en el enunciado.
Para responder esta pregunta, Ud. debe presentar el balance proyectado de “PPTT” al 31/12/2016, incluido el
nuevo financiamiento que sea necesario.
-----
8
: PREGUNTA N' 4
El Nuevo Escenario en la Industria del Retail de Ropa
Como muchos sectores de consumo masivo, el sector del retail de ropa 1 ha presentado en el último tiempo
dificultades. Los altos costos de la infraestructura y las cada vez más agresivas liquidaciones de los stocks al
final de las temporadas, explican una parte importante de lo anterior. Sin embargo, es un sector que sigue en
movimiento.
Al interior del sector de venta de ropa al detalle, se pueden distinguir tres tipos de competidores. Un grupo de
ellos, el mayoritario, ha seguido un modelo de negocio que podríamos denominar Tradicional, representado
por grandes tiendas de departamento cuyo ámbito de operación es de alcance local (operan principalmente en
un país o un grupo muy acotado de países). Por otro parte, encontramos a empresas muy innovadoras, con una
buena propuesta de valor asociada a productos considerados premium, que han desarrollado un modelo de
negocio que podríamos definir como No Tradicional. Son empresas cuya escala de operación es global, con
alta adaptación al consumidor local de cada uno de los países en donde operen. Finalmente, y aunque en menor
número, en este mercado también se encuentra a un tipo de competidores que son verdaderas “boutiques
locales”, las cuales poseen cadenas de tiendas propias en un determinado país, aunque una parte importante de
su negocio es distribuida a través de grandes tiendas locales tradicionales.
El Modelo Tradicional
Ampliamente difundido y adoptado por las grandes tiendas y casas comerciales en el mercado de la ropa, es
un modelo que hasta ahora ha sido exitoso. No obstante hoy en día enfrenta importantes amenazas. Es un
modelo ampliamente conocido. Primero, se analizan tendencias de la moda y lo que se llevará en la próxima
temporada; luego se diseñan las colecciones a encargar; a continuación se ponen las órdenes de pedido para la
fabricación generalmente en países como China. Son grandes lotes de pedido que se encargan a proveedores
globales, lo que hace aprovechar al máximo las economías de escala en el proceso de compra. Con el pedido
ya en el país donde se efectuará la venta, se llenan las estanterías de todos los locales de la respectiva cadena.
Luego comienza el proceso de ventas, y finalmente, hacia el término de la temporada, se realizan diferentes
tipos de liquidaciones de stocks sobrantes para salir de los remanentes no vendidos y reducir al mínimo las
pérdidas por inventarios. Como se puede apreciar, es un modelo centrado fundamentalmente en una buena
decisión de qué comprar y en una buena negociación de precios al realizar la compra del stock, para lo cual se
aprovechan al máximo las economías de escala que genera el gran volumen comprado. Complementa a lo
anterior, la continua gestión que se va haciendo del precio a medida que transcurre la temporada, de manera
de agotar los stocks al final del período. Es un modelo que en general va reduciendo el margen a lo largo de la
temporada y requiere de entre 6 y 9 meses desde la orden de pedido y hasta el llenado de estanterías para la
venta. Empresas como Macy's en USA y Falabella en Chile, Perú y Colombia, son exponentes de este tipo de
modelo de negocio.
El Modelo No Tradicional
Desde hace un tiempo, algunos competidores han estado cambiando la forma de hacer el negocio. En efecto,
el modelo de negocio en este caso es diferente. Primero, los competidores toman rápidamente una decisión de
fabricación de algún modelo de ropa que se quiere introducir o de alguna tendencia que se espera tenga éxito;
luego se manda a fabricar con mucha rapidez, a proveedores geográficamente cercanos al lugar en donde se
generará la demanda, un lote “acotado” de prendas de vestir, de no más del 5% de lo que se esperaría vender
en la temporada. En poco tiempo el pedido está confeccionado y se seleccionan los puntos de venta en donde
ofrecer el producto. Se pone el pedido a la venta en esas ubicaciones; luego se analiza la velocidad de venta
de los diferentes tipos de prendas introducidas. Si el resultado se evalúa como satisfactorio, se manda a fabricar
en grandes cantidades para distribución en todas las tiendas de la cadena en el mundo o en la región,
1 Para los efectos de este caso, por industria de retail de ropa vamos a entender a aquella compuesta por tiendas de
departamento y otras tiendas menores de distribución al detalle de todo tipo de ropa, más las marcas cuyos productos se
distribuyen por medio de los canales anteriores. No considera negocios complementarios o adicionales como crédito,
seguro, etc. sino que solo la venta de prendas de vestir al detalle.
-----
9
introduciendo las particularidades de los distintos consumidores en las diferentes localidades en donde opera
la empresa. Es un modelo que permite realizar variantes de diseño lo que permite introducir modelos diferentes
en una misma temporada. Si por el contrario, el resultado del lote original encargado en producción no es
exitoso, se desecha el ítem fabricado y no se pone a la venta en la temporada. Rápidamente se manda a producir
otro tipo de ropa con otro diseño y el ciclo comercial comienza nuevamente, donde se requiere aún más rapidez
que con el pedido original. Así, una logística eficiente para actuar, mezclando con eficiencia lo global de las
decisiones comerciales con la ejecución de estas decisiones en los mercados locales, marcarán la diferencia
entre competidores y se traducirá en ofertas atractivas, variadas y dinámicas para los clientes. En este modelo,
sólo transcurren 3 semanas entre la puesta del pedido y el llenado de las estanterías para ver si el producto
tiene o no éxito. Empresas como HéM, Forever 21 y Zara, son exponentes de este tipo de modelo de negocios.
Las Boutiques Locales
Aunque en un número significativamente menor que los actores en los dos modelos anteriores, las boutiques
locales son competidores locales (en un solo país), de menor tamaño, los cuales han construido algún grado de
diferenciación en relación a su marca, y dada la alta dependencia de su venta de las grandes cadenas de tiendas
por departamento, han seguido un modelo del tipo tradicional. Estos competidores distribuyen un porcentaje
muy importante de su venta a través de grandes tiendas de departamento que siguen el modelo tradicional. Se
estima que sobre el 70% de su venta sale por el canal de grandes tiendas, canal que representa del orden del
15% de su margen. Empresas como Saville Raw y Trial en Chile, son claros exponentes de este tipo de
competidor.
No está claro qué modelo de negocio primará o si podrán coexistir todos ellos. Por otra parte, las boutiques
locales están enfrentando una complicada situación y gran incertidumbre, al no conocer si las grandes tiendas
locales se mantendrán en el modelo que hasta ahora les ha dado el éxito, o si definitivamente migrarán hacia
el esquema no tradicional.
PREGUNTAS
1) ¿Qué elementos crean valor en el modelo de negocio tradicional y en el no tradicional? Responda esta
pregunta utilizando como referencia, los distintos componentes que conforman el indicador financiero
conocido como Valor Actual Neto (VAN). Para cada uno de los modelos señale tres elementos concretos
que permiten crear valor. No olvide utilizar en su respuesta al VAN como medida de creación de valor.
2) Considerando ahora la situación de una “Boutique Local”, ¿Qué elementos determinarán si este competidor
decidirá mantenerse en el Modelo Tradicional o cambiarse al Modelo No Tradicional? Señale y explique
tres elementos. Sea breve y preciso en su respuesta. o
-----
10
: PREGUNTA N' 5
En Junio de 2016 entrará en vigencia la nueva Ley de Etiquetado Nutricional de Alimentos en Chile que afecta
a alimentos con altas cantidades de calorías, grasa total, azúcares o sodio. El objetivo de la Ley es informar a
la población de aquellos alimentos que pueden resultar perjudiciales para la salud cuando se consumen en
exceso. La nueva Ley establece que, los alimentos que no cumplan los estándares fijados por el Ministerio de
Salud, deberán colocar en sus envases advertencias en sellos de color negro con frases de la forma ”alto en”
calorías, grasas saturadas, azúcares o sodio, según corresponda. Para la industria alimentaria, esta norma
representa un desafío en términos de desarrollar tecnologías que permitan modificar la composición de los
alimentos a fin de mejorar su calidad nutricional.
Se estima que, en algunas categorías de productos, la mayoría de las marcas deberán colocar el sello negro
(como se muestra en la figura de más abajo) y sólo unas pocas marcas estarán liberadas del sello mencionado
al cumplir los estándares que ha determinado la autoridad. La pregunta que muchas empresas que fabrican y
comercializan productos alimenticios se están haciendo en Chile es cómo va a reaccionar el consumidor ante
este nuevo escenario en el mercado.
MA NN
A | ATT |
Una de las categorías que se podría ver afectada de manera muy significativa con la nueva normativa es la de
“mantequillas”. En ésta categoría existen tres líneas de producto: las de buen sabor (como atributo distintivo),
las supuestamente saludables ( que tienen un atributo funcional como “light”, “bajo en sodio”, etc, y que no
necesariamente cumplen la nueva norma) y las económicas (de bajo precio relativo). El Cuadro 1 muestra
estadísticas de ventas del año 2015 para toda la categoría de “mantequillas” ! y para el fabricante H Foods que
tiene una extensión de marca diferente en cada una de las líneas mencionadas. En los últimos años, las
preferencias del consumidor por las distintas líneas en esta categoría no han variado de manera importante.
Cuadro 1: Ventas Categoría Mantequillas
Ventas Volumen 2015 Ventas Valor 2015
(miles de kilos) (millones de $)
Total Categoría 18.522 42.281 :
Sabor 11.570 26.775
Saludable 3.228 9.679
Económico 3.724 5.827
Total H Foods 7.147 14.808
Sabor 4.647 10,271
Saludable 803 2.184
Económico 1.697 2.353
H Foods ha estado trabajando en los últimos meses en el desarrollo de una mantequilla que cumple las nuevas
normas y por tanto no requeriría del sello negro “alto en ...” Los ejecutivos de H. Foods creen que esta nueva
mantequilla podría ser la única en el mercado en cumplir la norma. Si bien este producto está listo para salir al
mercado, el principal inconveniente que se ha detectado, en estudios de sabor, es que tiene un desempeño en
este atributo significativamente más bajo que las otras mantequillas que se comercializan actualmente.
1 La información contenida en este caso es real, aunque algunos datos han sido modificados para resguardar la
confidencialidad.
-----
11
! PREGUNTAS
1) En base a la información entregada, ¿Cómo cree Ud. que afectará a H. Foods la nueva ley de etiquetado si
esta empresa es la única en lanzar al mercado un nuevo producto que cumple la norma? Justifique su
respuesta y suponga que todas las marcas existentes en el mercado se mantienen aunque, desde Junio de
2016, con el sello negro.
2) Proponga un estudio de mercado específico 2 que le permita a H. Foods apoyar, de la forma más integral
posible, la decisión de lanzar o no al mercado su marca saludable y con qué precio. Concretamente, a Ud.
se le pide que explique de qué manera usaría los resultados de dicho estudio para apoyar la decisión que
enfrentan los ejecutivos de H Foods.
2 Ensu propuesta de estudio no se refiera a aspectos de diseño metodológico tales como: muestra, cuestionario,
método de entrevista, etc... que estarán a cargo de la empresa de investigación que desarrolle el estudio.
-----
nn
É PREGUNTA N' 6
Usted seguramente sabe que en Chile (y en muchos otros países) existen bonos estatales denominados en
pesos nominales (CLP) y también en Unidades de Fomento (UF). Suponga para efectos de análisis que la
UF del mes t se reajusta según la inflación del mes t-1. En el mercado chileno, existen y se transan
activamente bonos estatales a múltiples plazos denominados en cada una de esas monedas.
Responda las preguntas que se le formulan a continuación entregando los argumentos y cálculos que sean
necesarios. Suponga que un año tiene 360 días (meses de 30 días).
a) Suponga que Ud. administra un fondo mutuo de corto plazo. Entre las alternativas elegibles, Ud.
invertirá una mayor proporción de los recursos en la opción de mayor rentabilidad esperada. La fecha
actual es el 30 de enero de 2016 y su horizonte de inversión es de 3 meses (hasta el 30 de abril de .
2016). Existen bonos estatales a 2 años plazo del tipo bullet (pagan intereses semestralmente y
amortizan el 100% del principal al final del período de maduración del bono). Estos bonos pagarán
intereses por primera vez el 30 de junio de 2016.
El Cuadro N* 1 que se muestra a continuación, resume las condiciones de mercado actuales (al
31/01/2016) y los valores que Ud. espera al 30/04/2016. Para cada una de estas fechas, se entrega la
tasa interna de retorno (o TIR) para bonos bullef estatales, que maduran en 2 años, denominados en
pesos (bonos BCP) y bonos bullet estatales, con vencimiento a 2 años, denominados en UF (bonos
BCU) y el valor de la unidad de fomento (UF). Suponga que el precio de mercado inicial (al
31/01/2016) de ambos bonos es UF 1 (o $25.629,09) y que los dos instrumentos se transan actualmente
a su valor par. Dadas sus expectativas y su horizonte de inversión (3 meses), ¿Cuál de los dos bonos
favorecería en su portafolio? Fundamente su respuesta mostrando todos los cálculos necesarios.
Cuadro N* 1
Condiciones de Mercado Bonos BCP y BCU a 2 años
TIR BCP 2 años TIR BCU 2 años Valor de 1 UF
(nominal en CLP (en UF)
31/01/2016 4,01% 1,26% $25.629,09
30/04/2016 4,01% 1,26% $25.830,58
b) Entre los ejecutivos de inversiones es frecuente encontrar la opinión de que siempre conviene estar
invertido en UF a principios del año. Esto se daría por la estacionalidad de la inflación, que suele ser
mayor durante los primeros meses del año, en particular en marzo, por el efecto del alza de las
matrículas escolares y otros ítems del IPC.
El Cuadro N?2 que se muestra en la página siguiente, compara la estrategia de invertir en bonos bullet
con pagos semestrales y vencimiento a 2 años del tipo BCP (en pesos o CLP) y del tipo BCU (en UF),
para el trimestre Febrero - Abril entre los años 2009 - 2015. Los retornos son ex post y están expresados
en términos reales (corregidos por inflación) para el trimestre señalado. A modo de ejemplo, en el
trimestre Febrero — Abril del año 2015, la inversión en bonos BCU que maduran en 2 años tuvo un
rendimiento real de 1,27% mientras que la inversión en bonos BCP con vencimiento a 2 años tuvo un :
retorno real de -0,13% (menos 0,13%).
-----
13
, Cuadro N* 2
Retorno (%) Real Trimestre Febrero — Abril para Bonos BCP y BCU a 2 Años
Año BCU BCP
2015 1,27%  -0,13%
2014 2,79% 1,77%
2013 141% 2,00%
2012 0,61%  -0,07%
2011 1,36% 1,2%
2010 2,84% 0,10%
2009 3,66% 4,92%
Usando argumentos de la teoría financiera y en base a la evidencia presentada en el Cuadro N? 2
¿Qué opinión le merece la creencia de los ejecutivos de inversiones en cuánto a que siempre conviene
estar invertido en UF a principios del año? Fundamente su respuesta.
e) Suponga ahora que el mercado de bonos está dominado por ahorrantes con horizonte de inversión de
largo plazo. ¿Cuál de los dos tipos de bonos (BCP o BCU) debería tener una mayor rentabilidad
esperada a largo plazo y por qué? Mencione en su respuesta el concepto de premio por riesgo.
-----


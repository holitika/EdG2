# Examen de grado · Examen-de-Grado-Administracion-Agosto-2023

Fuente: examen anterior

[pág. 1]
PONTIFICIA UNIVERSIDAD CATÓLICA DE CHILE
 ESCUELA DE ADMINISTRACIÓN
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
 alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos hojas
 que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar hojas
 adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga que
 los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
 realidad de las empresas que allí se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados dichos
 supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la misma
 ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente al Profesor Ignacio Rodríguez, Presidente de la Comisión de
 Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
 cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas condiciones,
 el Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un (a) alumno (a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares ni relojes inteligentes en la sala, los que deberán
 estar apagados y guardarse en las mochilas en la parte de adelante de la sala donde Ud. rinde este examen.
12. Cada alumno (a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
 examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
 identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar como
 “borrador”, esas hojas no se deben entregar con las respuestas.
Fecha : 11 de agosto de 2023
Duración : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el Profesor Ignacio
 Rodríguez, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 y 11:00 hrs.
 (aprox.).

[pág. 2]
2
PREGUNTA Nº 1
Ha estallado una intensa guerra de precios en el mercado de automóviles eléctricos (EVs1) más grande del mundo:
China. En marzo de 2023, la empresa conjunta en China de Volkswagen y Xpeng, recortó los precios de sus
autos eléctricos ID.3 en un 18 %. Varios otros productores chinos, así como extranjeros, han hecho rebajas de
hasta un 40% en los EV, así como en los tradicionales autos a combustión.
La Gráfica N°1 muestra que el mercado mundial de EVs
ha estado creciendo exponencialmente en los últimos años,
liderado por Tesla y seguido cada vez más de cerca por
fabricantes chinos como BYD. El año pasado se vendieron
en el mundo más de 10 millones de unidades, con un
crecimiento del 55% respecto de 2021, lo que representa
un 13% de participación de las ventas totales de vehículos
en el mundo. Alrededor de uno de cada siete automóviles
de pasajeros comprados en 2022 en todo el mundo, fue un
EV. Esto se compara con uno de cada 70, solo cinco años
antes.
 En China, existen hoy cerca de 100 productores de EVs con más
 de 300 modelos de autos, liderados por BYD, e incluye a algunas
 empresas extranjeras (Volkswagen y Tesla con participaciones de
 mercado de 3% y 7% respectivamente), tal como muestra la
 Gráfica N°2. Las ventas de vehículos eléctricos nuevos en China
 aumentaron un 82 % en 2022 en comparación con el año anterior.
 Este país representó el 59% de las ventas mundiales de vehículos
 eléctricos el año pasado, consolidando su posición como el
 mercado de vehículos eléctricos más grande del mundo. China
 también es el mayor productor de vehículos eléctricos del mundo,
 con el 64 % del volumen mundial. Según analistas, la gran cantidad
 de productores chinos se explica por los subsidios estatales de su
 Gobierno.
La Gráfica N°3 muestra las ventas en unidades (100%
eléctricos con batería e híbridos) de EVs en China y las
estimaciones para los próximos años. Las marcas chinas
tienen una participación superior al 80% en su país. La
capacidad anual china de producción de EVs ascendió a
5,7 millones de vehículos a fines de 2022, lo que
significa la utilización del 58% de la capacidad instalada
de las fábricas operativas de EVs en China. Las fábricas
de EVs en construcción desde 2022, tendrán una
capacidad total de producción de 10,5 millones de
vehículos eléctricos, y se cree que la mayoría serán EVs.
Una vez que todas estas fábricas estén operando, se
espera que China alcance una capacidad de producción
de 16 millones de EVs por año. La alta tecnología de las
plantas determina que la estructura de costos de las empresas es principalmente fija. Este año 2023, se espera
que las exportaciones totales de EV desde China al resto del mundo, lleguen a 1,3 millones de unidades.
1 EVs: Autos eléctricos, incluyendo los híbridos (eléctricos + combustión) y los 100% eléctricos con batería.

[pág. 3]
3
Por muchos años, Tesla fue el productor de EVs más grande del mundo con mega fábricas en USA, Alemania y
China. En este último país, Tesla fabrica más del 50% del total mundial de su producción de EVs. Su producción
total mundial en 2022, fue de 1,6 millones de EVs. Hoy, su liderazgo (50% de participación en USA y 15% en
Europa) está amenazado por empresas chinas como BYD, que en China tiene una participación de mercado del
30% y que, a diferencia de Tesla, es una empresa altamente integrada en su cadena de valor y produce gran parte
de sus insumos y partes. BYD exporta a diversos países y espera tener plantas de fabricación en Europa para
2025. En Europa y Estados Unidos existen hoy barreras arancelarias para los autos fabricados en China y estos
no acceden a los subsidios estatales a la compra, que los gobiernos occidentales ofrecen.
Desde los comienzos de la fabricación de EVs en 2008, Tesla ha tenido una ventaja de costos respecto de los
autos a combustible y también del resto de productores de EVs, gracias a su simple tecnología de montaje, al
reducido número de modelos (2 modelos representan más del 80% de su producción), y a que sus fábricas fueron
diseñadas para EVs y no reconvertidas de plantas de autos a combustible. También ha influido que su inversión
en publicidad es mínima y se basa en el boca-a-boca, y que además usa un canal de venta directa, evitando los
concesionarios. Esta ventaja de costos, sumada a su imagen premium y de calidad, le ha permitido tener márgenes
operacionales porcentuales cercanos al 20%.
 Sin embargo, el haber recientemente reaccionado a la guerra de precios en
 China, ha llevado a Tesla a reducir sus márgenes operacionales a cerca de
 la mitad en dicho país (ver Gráfica N°4). Bajo la presión de una
 competencia cada vez mayor y la incertidumbre económica en China,
 Tesla ha bajado en este país sus precios en más de un 25% durante 2023
 para disminuir sus inventarios. El presidente ejecutivo de Tesla, Elon
 Musk, redobló dicha guerra de precios, señalando que la compañía
 priorizaría el crecimiento de las ventas más que las ganancias en una
 economía china débil y en un entorno de creciente competencia.
 Zhu Jiangming, CEO de Leapmotor, comentó que es muy posible que un
 vehículo eléctrico promedio o de gama alta en China, se venda por
 alrededor de US$7.000 en pocos años. Elon Musk, estima que el precio
 promedio de un automóvil eléctrico en China ya es significativamente más
 bajo que en el resto del mundo, alrededor de US$ 35.000, en comparación
con US$ 60.000 en Europa y US$ 70.000 en los Estados Unidos. En parte, esta diferencia se debe a significativos
subsidios estatales chinos a la compra de EVs producidos en China, que debieran terminarse este año.
William Li, director ejecutivo de Nio, una de las empresas chinas emergentes de vehículos eléctricos de alta gama,
dijo que planeaba mantener a Nio fuera de la guerra de precios, a la que calificó de "poco saludable e insostenible".
PREGUNTAS
1.- Considerando el mercado chino de EVs, ¿debiera Tesla seguir en la guerra de precios y mantener sus rebajas
 y promociones de precios en dicho país? ¿Sí o no? Desarrolle los 3 principales argumentos que justifican su
 decisión. En su respuesta utilice conceptos de marketing.
2.- Desde el punto de vista de marketing señale, entregando los fundamentos correspondientes, las 3 ventajas
 más importantes para Tesla de iniciar una guerra de precios a nivel de los mercados occidentales más
 importantes, como Estados Unidos y Europa.

[pág. 4]
4
PREGUNTA Nº 2
Frut-Ex es una empresa dedicada a la venta de maquinaria agrícola (como por ejemplo tractores y máquinas
cosechadoras) para la producción frutícola. Fue creada en el año 1998 por Ricardo Paredes (RP), quien fundó la
empresa antes que Chile se convirtiera en un referente de la producción y exportación de frutas como cerezas,
uvas, arándanos y frutos secos.
En esos años, RP aprovechó una amplia red de contactos que había construido en la universidad y sus postgrados
en el extranjero, para lograr importar maquinarias del rubro agrícola con un alto nivel de especialización que no
estaban usualmente disponibles en el mercado chileno. Frut-Ex operaba en un mercado en crecimiento, pero
caracterizado por una cada vez más intensa rivalidad competitiva y el ingreso persistente de nuevas empresas
comercializadoras de maquinaria con ofertas atractivas para el mundo agrícola.
Por su parte, la propuesta de valor de Frut-Ex incluía equipamiento de gran calidad y su ventaja se basaba en la
alta durabilidad de sus productos. A pesar de establecer precios un poco más altos que sus competidores, su
maquinaria era una buena solución para los agricultores que buscaban rentabilidad en el largo plazo y tenían la
necesidad de operar con equipamiento de alto nivel de especialización debido a la complejidad de sus tareas
agrícolas. La vida útil de la maquinaría de Frut-Ex era de 10 años aproximadamente. RP además había conseguido
que Tuerquita, una empresa independiente, especializada en el servicio de reparación de maquinaria, se hiciera
cargo del servicio técnico, reparación y mantenimiento a los clientes de Frut-Ex.
Los clientes de Frut-Ex eran en su gran mayoría medianos y grandes agricultores que tenían cultivos distribuidos
en varias zonas del país y plantaban diversas variedades de fruta. Los encargados de comprar en dichas empresas
agrícolas eran en su gran mayoría ingenieros agrónomos con alto conocimiento técnico de los equipos y productos
que adquirían.
En sus inicios Frut-Ex comenzó con un equipo de ventas de 10 personas los que eran íntegramente pagados por
una comisión por articulo vendido. Ese esquema de comisión aún se mantenía. No existía ningún otro tipo de
pago (el sueldo era 100% variable, sin ningún componente fijo). Ricardo tenía una relación cercana con todos sus
vendedores (él mismo los seleccionaba y contrataba). A pesar de no contar tampoco con un sistema de evaluación
de desempeño formal que midiera el desarrollo de las competencias y las conductas deseadas en el personal, la
tasa de rotación era cercana a cero. Por ello, RP consideraba que el pago íntegramente por comisión hacía todo el
trabajo necesario para motivar a sus trabajadores. Efectivamente, no solo la rotación era prácticamente nula, sino
que también las ventas y el negocio crecían satisfactoriamente.
En los últimos años, RP pensó que el crecimiento del sector frutícola y los logros que había alcanzado su empresa
eran lo suficientemente robustos como para dar un nuevo salto e innovar. En particular RP pensaba ampliar su
línea de productos para incluir fertilizantes, mercado altamente competitivo, en donde las innovaciones
tecnológicas de los fabricantes habían permitido tener productos cada vez de mayor calidad y a mejores precios.
Una vez analizado este nuevo mercado, RP decidió que sus vendedores ya no sólo venderían maquinaria agrícola,
es decir, un producto con baja rotación de compra, sino que se ampliaría a fertilizantes, producto que los clientes
debían comprar de manera repetida varias veces al año para aplicarlos en las distintas variedades y zonas en que
operaban. A su vez, los fertilizantes eran un producto complejo que requería conocimientos altamente
especializado del tipo de suelo, la especie de fruta, la humedad, temperatura y otras variables de los predios en
donde se iban a utilizar, por lo que Frut-Ex tenía considerado que su venta requería entregar una asesoría técnica
personalizada a sus clientes.
Luego de conseguir un fertilizante que lo satisfacía desde el punto de vista de la calidad, lo cual era importante
para ser congruente con su ventaja competitiva, RP y su socio, Carlos Rivero (CR), discutían si es que debían
modificar la forma en que se motivaba al equipo de ventas. Esto era muy relevante, especialmente porque el
número de vendedores había crecido de forma sostenida en los últimos años, alcanzando un total de 32 personas
dedicadas exclusivamente a la venta directa.

[pág. 5]
5
En la última reunión de directorio de Frut-Ex, RP y CR discutían cómo abordar el tema de la motivación a su
equipo de vendedores a partir de la incorporación de fertilizantes en su oferta a los clientes:
CR: Ricardo, creo que como nuestro negocio ha crecido, vamos a incorporar ahora la venta de fertilizantes y
nuestro equipo de vendedores también pasó de 10 a 32 vendedores, es necesario que nos replanteemos como
motivar a nuestra fuerza de venta.
RP: Si te refieres a crear un sistema más estructurado para evaluar su desempeño, me parece bien, pero no
indispensable. Hasta ahora no lo hemos necesitado y además nos ha permitido omitir toda la burocracia que
significa tener un proceso estructurado y formal de evaluación de desempeño. Por su parte, el sistema de comisión
por venta, sin un sueldo fijo, nos ha funcionado muy bien durante años. Este esquema ha sido hasta ahora el
adecuado y consistente con nuestra estrategia de negocio y nuestros atributos de diferenciación. Nos interesa que
se venda y es por eso se les paga a los vendedores. No veo por qué deberíamos cambiarlo. ¿No te parece Carlos?
A usted como asesor de la empresa en gestión estratégica de personas y con la información planteada en la
reunión en la que participa, se le pide que intervenga y responda las siguientes preguntas:
PREGUNTAS
a) Considere lo planteado por RP en la reunión respecto a que “el sistema de comisión por venta, sin un sueldo
 fijo, nos ha funcionado muy bien durante años. Este esquema ha sido hasta ahora el adecuado y consistente
 con nuestra estrategia de negocio y nuestros atributos de diferenciación. Nos interesa que se venda y es por
 eso se les paga a los vendedores. No veo por qué deberíamos cambiarlo.” ¿Mantendría usted el esquema de
 incentivos actual? ¿Sí o no? Sea preciso y justifique adecuadamente su respuesta.
b) Suponga que Frut-Ex ha decidido mantener el esquema de incentivos para la venta de maquinaria, pero al
 mismo tiempo ha optado por desarrollar un nuevo sistema de incentivos para las ventas de fertilizantes.
 ¿Cuáles son los tres principales elementos que la empresa debiera considerar en el diseño de este nuevo sistema
 para la venta de fertilizantes? Fundamente en forma breve su respuesta.

[pág. 6]
6
PREGUNTA Nº 3
Una empresa analiza la conveniencia financiera de cambiar de una máquina antigua por una nueva. El cambio le
permitiría a la empresa disminuir desde $500 millones a $350 millones sus costos de producción anuales a
perpetuidad, manteniendo constante tanto su capacidad de producción, como sus ventas. La empresa reinvertirá
anualmente en la máquina nueva el monto necesario para que su vida útil sea infinita. Los montos tanto de
depreciación anual como de las reinversiones anuales necesarias para el funcionamiento de la nueva máquina son
iguales a los de la máquina que se está reemplazando. La máquina antigua se puede vender al contado a su valor
neto de libros (costo histórico menos depreciación acumulada), que es de $200 millones. La tasa de impuestos a
las utilidades de las empresas es de 30%.
Para el financiamiento y pago al contado del costo total de la nueva máquina, se podría disponer de un crédito
por el cual la empresa tendría que pagar como intereses anuales a perpetuidad y al término de cada año, la suma
de $60 millones, correspondientes a una tasa de interés anual de 5%. Cumpliendo con el pago anual de los
intereses, la empresa no requeriría de amortizaciones o pagos del crédito solicitado.
El Costo de Capital Promedio Ponderado (C.C.P.P. o W.A.C.C.) de la empresa, relevante para este tipo de
inversiones, dado su nivel de endeudamiento objetivo (óptimo) de largo plazo, es de 12% anual después de
impuestos. El proyecto que se evalúa no cambiará dicho nivel de endeudamiento objetivo de largo plazo.
Suponga que no hay inflación y que todos los flujos a que se refiere el tema se producen al término del año.
El siguiente es un resumen de las opiniones emitidas por tres Gerentes de la compañía respecto del proyecto de
inversión:
Gerente de Proyectos: En primer lugar, quiero exhibir una evaluación financiera, que muestra tanto lo que a mi
juicio sería la inversión inicial que la empresa tendría que hacer, como los flujos de caja que la nueva máquina
podría generar y por lo tanto el impacto que tendría el cambio de máquina sobre el valor de la empresa:
 Inversión Flujos de Caja Anuales
 Inicial (Desde Fines del Año 1
 (Al comenzar el Año 1) hasta el Infinito)
Ahorro de costos - MM$ 150
- Pago de intereses por la nueva deuda - (60)
+ Ahorro de impuestos por uso de la deuda - 18
Flujo de Caja Neto de la Nueva Máquina MM$ 0 MM$ 108
En mi opinión, dado que según la evaluación financiera que he presentado, la empresa tendría a perpetuidad un
mayor flujo de caja anual de $108 millones con la nueva máquina, y teniendo en cuenta que la tasa de descuento
relevante para este tipo de inversiones, es decir, la que corresponde dado el riesgo de sus flujos de caja, es de
12% anual, el proyecto tiene un VAN o VPN de $900 millones (= [MMS108/0,12]), me parece obvio que la
empresa debe comprar la nueva máquina. ¡¿qué mejor argumento que un VAN positivo?!
Gerente de Finanzas: En mi opinión, debemos tener en cuenta que para la realización de este proyecto la única
inversión que como empresa tendríamos que hacer serían los $200 millones que se recaudarían por la venta de la
máquina antigua, puesto que el resto del financiamiento necesario se puede solicitar al banco a una tasa de interés
del 5% anual, lo cual generaría un desembolso de $50 millones en intereses anuales a perpetuidad y al término
de cada año. Esto haría aumentar los flujos de caja anuales del proyecto (desde fines del año 1 al infinito) que se
muestran en el cuadro anterior desde MM$ 108 a MM$ 115 (intereses de la nueva deuda serían de MM$50 y el
ahorro de impuestos por el uso de deuda ascendería a MM$15). Podemos decir entonces, que la interna de retorno

[pág. 7]
7
(TIR) del proyecto es de un 57,5% anual (= 115/200) a perpetuidad. Por lo tanto, estamos frente a un proyecto
cuya TIR es mayor que su CCPP (12% anual), lo que significa que hay creación de valor.
Gerente General: He escuchado con mucha atención sus opiniones, pero quiero darles a conocer una información
que recién me ha sido entregada. El Resultado del Ejercicio de la empresa del último período es una pérdida de
$600 millones. De este modo, nuestra empresa tiene una “Pérdida Acumulada” de $600 millones que puede ser
usada para disminuir los pagos futuros de impuestos hasta que se agote dicho monto1. De hecho, la empresa
espera obtener grandes utilidades en los próximos períodos, lo que sin duda le permitiría aprovechar la “Pérdida
Acumulada” en cuestión. Según mis cómputos, el valor presente de los menores pagos de impuestos que
tendríamos con la Pérdida Acumulada sería de $136,7 millones (Nota: suponga que este valor es correcto. No se
pide demostrarlo).
Con la nueva información he procedido a evaluar el proyecto de compra de la nueva máquina de la forma que yo
considero correcta y en realidad, aunque no estoy de acuerdo con los resultados que ustedes me han entregado
(VAN = $900 millones y TIR anual = 57,5%), mi conclusión es la siguiente: lo mejor que puede hacer la
empresa en este momento, dado el monto de Pérdida Acumulada con la que ella cuenta, es comprar la nueva
máquina. Mi principal argumento para fundamentar esta conclusión es que estamos frente a un proyecto que por
sí mismo crea valor y tiene méritos propios suficientes como para ser emprendido. Sin embargo, termina diciendo
el Gerente General, de acuerdo con mis cálculos, de no contar con la ventaja tributaria que genera la “Pérdida
Acumulada” que les he comentado, nosotros no debiéramos comprar la nueva máquina.
A usted se le pide contestar las preguntas que se le formulan a continuación mostrando los cálculos y argumentos
necesarios para fundamentar sus respuestas. Trabaje las cifras en millones de $ (MM$).
PREGUNTAS
1. Analice y evalúe los comentarios y la evaluación financiera del Gerente de Proyectos de la empresa
 (teniendo en cuenta únicamente la información con que él contaba al momento de hacer su evaluación),
 indicando expresamente, si los hubiera, los errores o críticas que usted le haría ya sea a los comentarios o a
 la evaluación que él ha presentado. Si no está de acuerdo con el VAN o VPN que él presenta, entregue lo
 que a su juicio sería el verdadero VAN (Indique: inversión inicial, flujos relevantes, tasa de descuento y
 VAN).
2. Responda lo solicitado en la pregunta anterior, ahora respecto de los planteamientos del Gerente de
 Finanzas. Si no está de acuerdo con la TIR que él presenta, entregue lo que a su juicio sería la verdadera
 TIR (Indique: inversión inicial, flujos relevantes y TIR).
3. Respecto del planteamiento hecho por el Gerente General, analice críticamente la conclusión y el argumento
 que él entrega para fundamentar su opinión favorable respecto de la compra de la nueva máquina.
1 : Esto significa que, si el resultado antes de impuestos generado en su primer año de actividad por el activo que se está evaluando, fuese
por ejemplo de $200 millones, en ese año no se pagarían impuestos ya que se podrían ocupar $200 millones de los $600 millones de
“Pérdida Acumulada” disponible, y así sucesivamente en los años siguientes, hasta que ésta se agote.

[pág. 8]
8
PREGUNTA Nº 4
 Farmacias Fracción
Fracción es la primera farmacia digital lanzada en Chile. Fundada en 2018, vende medicamentos fraccionados,
para que las personas puedan comprar las dosis exactas recetadas por su médico evitando así el gasto en cajas
completas. Su objetivo es acercar medicamentos a bajo costo a todo el país, sobre todo en localidades aisladas
que no cuentan con farmacias. En la actualidad, Fracción ofrece más de 1.400 medicamentos, que se pueden
buscar por marca o por principio activo. Tiene despacho a domicilio en todo Chile con plazos de entrega entre 24
y 72 horas. En 2022, sus ventas aumentaron 10 veces en relación a 2021, y los pedidos 8 veces. Hoy cuenta con
más de 10 mil clientes activos en todo el país.
El sitio web de Fracción permite enviar medicamentos a nivel nacional, lo que se espera reforzar con la apertura
de un local en cada región, medida que acortará tiempos de entrega y abaratará el servicio. Así mismo, Fracción
está implementando farmacias móviles a través de convenios con municipalidades y centros comunitarios, además
de contar con vehículos que llevan el local físicamente hasta comunas donde no hay ninguna farmacia. Otra
medida que está próxima a lanzarse es el plan de suscripción, pensado para pacientes crónicos que toman
medicamentos todos los meses. Para ellos se contempla un plan de entrega mensual en la casa del paciente, sin
costos adicionales a los del fármaco. Todo lo anterior ayudará a Fracción a expandir su negocio.
Los laboratorios de los que se abastece Fracción son los mismos que proveen a las grandes cadenas de farmacias,
pero Fracción ofrece una menor variedad de medicamentos que las grandes cadenas y a un precio más bajo. Los
menores precios obedecen a tres factores: la venta fraccionada de medicamentos permitida y regulada por la Ley
de Fármacos 1; la ley de Cenabast que permite abastecerse de productos de manera conjunta con el Estado de
Chile que actúa como intermediario aprovechando así el poder de compra que se genera, aunque viendo limitado
el precio máximo que Fracción puede cobrar al público por un medicamento; y, por los menores costos de
operación y comercialización que tiene el modelo de Fracción.
Las potencialidades del modelo de Fracción
La pandemia permitió a la compañía validar su modelo de negocio el que se visualiza como de gran potencial. En
efecto, Fracción es vista como una parte de una cadena que puede llegar a ser mucho más robusta. Como ejemplo
considérese una eventual integración con la telemedicina que creció fuertemente con la pandemia.
Teniendo en vista lo anterior, la empresa ha realizado importantes convenios con Microsoft por sus servidores
Cloud en la plataforma Azure, lo que le ha permitido contar con esta tecnología desde sus inicios, lo cual fue
fundamental para afrontar los desafíos de la pandemia y responder a la alta demanda de los clientes que
comenzaron a comprar sus medicamentos en línea.
La distribución de medicamentos en Chile
El mercado de distribución de medicamentos en Chile bordea los 2.000 millones de dólares en ventas al cierre de
2022. Es un mercado altamente concentrado; las tres principales cadenas de distribución de medicamentos
(Ahumada, Cruz Verde y Salcobrand) representan el 60% de las farmacias existentes en el país. Al mismo tiempo,
Chile es reconocido como el país en donde los consumidores invierten más en fármacos de marca y es uno de los
países con los mayores precios de medicamentos.
El año 2022, el 52% del valor de las compras de medicamentos en Chile se hizo en cadenas de farmacias, el 12%
en farmacias que no son de cadenas, y el resto, en compras públicas que se destinan a hospitales y centros de
atención, incluyendo además las compras realizadas por instituciones privadas como clínicas. Las cadenas de
farmacias Cruz Verde, Salcobrand y Ahumada pagan en promedio un 70% de mayor precio por sus compras de
medicamentos a los laboratorios, en relación a lo que paga el sector público, y un 60% más que los precios
pagados por compradores privados institucionales (por ejemplo, clínicas).
La pandemia Covid-19 ayudó al desarrollo del sector. En efecto, si bien detuvo en parte el desarrollo de locales
de las grandes cadenas de farmacias, permitió potenciar y modernizar los canales online. Otros factores que han
ayudado al crecimiento de este sector son el aumento de las enfermedades crónicas (hipertensión, diabetes,

[pág. 9]
9
enfermedades cardiovasculares y cáncer) a nivel mundial, la aparición de nuevas enfermedades, mejoras y
sofisticaciones en las estrategias de marketing, el uso de nuevos modelos comerciales y el aumento de los puntos
de venta. Todos estos factores se consideran además como potenciales motores para el crecimiento futuro de la
industria.
Las cadenas de farmacias tradicionales
Son tres las cadenas de farmacias que han dominado hasta ahora el mercado de distribución de medicamentos en
Chile: Ahumada, Cruz Verde y Salcobrand. Ninguna de ellas ha mostrado interés por replicar lo que hace
Fracción, pese a que han transcurrido 4 años desde que se promulgaron las leyes antes citadas. Por el contrario,
todas estas cadenas han intensificado sus estrategias comerciales y de negocios, basadas en la apertura de locales
que amplíen los puntos de contacto con el cliente (en una misma cuadra se puede encontrar una farmacia de cada
una de estas tres cadenas), el fortalecimiento de sus líneas de productos por medio de aumentar tanto la amplitud
como la profundidad de fármacos ofrecidos para diferentes dolencias, y el desarrollo de productos
complementarios que han convertido a las farmacias de cadenas en verdaderas tiendas de conveniencia.
Los altos costos comerciales y operacionales asociados a la estrategia anterior se han enfrentado con políticas de
precios que han posicionado a Chile como uno de los países con mayores precios de medicamentos, aunque
matizados con permanentes ofertas, clubes de clientes frecuentes y convenios con diferentes instituciones que
reducen el precio final al cliente.
Cabe señalar que la estrategia anterior le ha reportado hasta ahora a las grandes cadenas, éxito financiero y
también algunos cuestionamientos reputacionales. Pese a lo anterior, no ha sido ésta la estrategia seguida por
compradores institucionales (clínicas, hospitales, etc.), quienes privilegian el tener un buen precio al cliente final,
aunque ello signifique sacrificar variedad de productos.
El futuro de la Industria
Expertos señalan que existen tendencias claras que determinarán la industria en el futuro: la consolidación del
comercio digital; el fortalecimiento de la relación con los clientes; el monitoreo de información médica de los
clientes en la nube; y la sofisticación de los niveles de servicio y de postventa demandados por los clientes. Las
tendencias anteriores han hecho surgir actores internacionales que están desarrollando activamente este negocio.
Cabe destacar el caso de Amazon con su servicio “Pill Pack by Amazon Pharmacy”, con el cual aspira convertirse
en la mayor farmacia del mundo: medicamentos fraccionados, en las dosis justas por día, y entregados en la
frecuencia que el tratamiento del paciente (cliente) requiere. Como se aprecia, un nivel de servicio y de
integración llevado al extremo.
Basado únicamente en la información provista en el caso, responda las preguntas que se le formulan a
continuación:
PREGUNTAS
1) Analistas de la industria coinciden en señalar lo poco sostenible que es el modelo de negocio de Fracción.
 ¿De qué forma podría Fracción robustecer su modelo de negocio de manera de hacerlo más sostenible? Se
 pide que Ud. entregue las tres principales medidas concretas que fortalecerían el modelo de negocio de
 Fracción desde el punto de vista de la sostenibilidad del mismo, indicando el por qué cada una de las medidas
 señaladas hace que el modelo sea más sostenible.
2) ¿Por qué las cadenas de farmacia tradicionales no siguieron la estrategia de negocios implementada por
 Fracción? Indique, entregando los fundamentos correspondientes, los tres principales argumentos estratégicos
 que pueden explicar lo anterior.

[pág. 10]
10
PREGUNTA Nº 5
MasterClass es un servicio de streaming online que ofrece clases de diversos temas impartidas por personas
expertas en sus respectivas áreas. Los y las instructoras van desde escritores ganadores del Premio Nobel hasta
chefs con estrellas Michelin, directores de cine premiados con el Oscar y más. Las clases cubren una amplia gama
de temas como escritura, cine, cocina, música, deportes, entre otros. En cada clase, los instructores comparten sus
experiencias, habilidades y consejos a través de videos de alta calidad y materiales complementarios.
Actualmente, Masterclass ofrece tres planes: individual, dúo y familiar; y está pensando modificar el plan de
suscripción individual para lo cual diseñó e implementó un análisis conjunto basado en elecciones (choice-based
conjoint, CBC). A partir de un estudio preliminar, se determinó que los cinco atributos clave de la suscripción
individual son:
1. Precio mensual (US$9, US$11, US$13)
2. Acceso a todas las clases (Sí, No)
3. Posibilidad de interactuar con los instructores (Sí, No)
4. Incluye material extra de aprendizaje (Sí, No)
5. Posibilidad de descargar las clases para ver offline (Sí, No)
Un total de 1.000 encuestados evaluaron distintos perfiles utilizando una escala tipo elección múltiple. Una vez
obtenidas las respuestas, se estimó un modelo logit con dos clases latentes (suponiendo una función lineal para
las utilidades) obteniéndose los siguientes resultados:
Tabla 1: Resultados de la estimación de un modelo logit con dos clases latentes
 Segmento 1 Segmento 2
 Atributo Nivel (40%) (60%)
 Precio Mensual $9 0 0
 Precio Mensual $11 -0,3 -0,7
 Precio Mensual $13 -0,5 -0,9
 Acceso a todas las clases No 0 0
 Acceso a todas las clases Si 0,3 0,1
 Interacción con instructores No 0 0
 Interacción con instructores Si 0,6 0,2
 Material extra de aprendizaje No 0 0
 Material extra de aprendizaje Si 0,4 0,2
 Descargas offline No 0 0
 Descargas offline Si 0,4 0,2
 Observaciones:
 a. Los valores en la tercera y cuarta columna de la Tabla N° 1 son los coeficientes del modelo logit para
 cada segmento. Estos representan las utilidades parciales (part-worths).
 b. Los niveles con coeficientes igual a cero corresponden al nivel base (y por lo tanto no fueron estimados).
 c. Todos los coeficientes estimados son estadísticamente significativos al 5% (p < 0,05).
 d. Notar que la probabilidad de pertenecer al segmento 1 es 0,4.
Basado en los resultados anteriores, responda las preguntas que se le formulan a continuación entregando los
fundamentos correspondientes:

[pág. 11]
11
PREGUNTAS
 1. ¿Existen diferencias entre los dos segmentos en términos de preferencias e importancia de los atributos?
 2. El plan básico actual de la empresa (que cuesta US$9) no ofrece hoy la posibilidad de interactuar con los
 instructores. La gerenta comercial de la empresa evalúa ofrecer este servicio y subir el precio del plan
 básico a US$10. ¿Recomendaría usted mantener el servicio original, ofrecer el nuevo servicio u ofrecer
 ambos? Determine la disposición a pagar por este atributo y utilícelo en su argumentación.
 3. ¿Por qué los ejecutivos utilizan la metodología CBC, que es una de las metodologías indirectas y no se
 pregunta directamente, a los potenciales consumidores, por las utilidades que les reporta cada nivel de
 cada atributo? Explique.

[pág. 12]
12
PREGUNTA Nº 6
Un credit default swap (CDS) es un instrumento financiero que funciona como un seguro de crédito, en el sentido
que paga al tenedor de este seguro cuando alguien que debe dinero (normalmente llamado el deudor), deja de
pagar sus deudas. La diferencia con un seguro de crédito estándar es que no es necesario ser acreedor (es decir,
que a uno le deban dinero) para comprarlo. Un CDS puede ser comprado por cualquier inversionista, sea o no
acreedor de ese deudor. Se transforma así en un instrumento derivado donde los pagos son contingentes al
comportamiento de un deudor (básicamente, si paga sus deudas o no). Por lo tanto, como muchos instrumentos
derivados, puede ser comprado para fines de cobertura o por especulación.
Puede decirse que el comprador del CDS es el asegurado y el emisor del CDS es el asegurador. El asegurado debe
pagar periódicamente una prima por este seguro. En caso de que el deudor suspenda sus pagos, el asegurado
recibe del asegurador el monto impago de la deuda. La prima del CDS se mide en centavos de dólar a pagar (en
base anual) por cada $100 dólares asegurados. Por ejemplo, el CDS del bono soberano1 chileno en el gráfico
adjunto alcanzó una prima de poco más de 300 durante la crisis financiera de 2008-2009, es decir, para asegurar
$100 dólares de deuda chilena se tenían que pagar 300 centavos o 3 dólares como prima.
 CDS Bonos Soberanos Chile
 350,00
 300,00
 250,00
 200,00
 150,00
 100,00
 50,00
 0,00
En el caso de los bonos soberanos, el CDS es muchas veces usado como un termómetro del riesgo de crédito de
un país. Un aumento del CDS es interpretado como una mala señal, usualmente como un aumento en la
probabilidad de no pago de la deuda soberana. Asuma que las suspensiones de pago (o defaults) de bonos
soberanos tienden a ocurrir en periodos recesivos o de bajo crecimiento a nivel mundial, y de manera coordinada,
es decir, es frecuente que varios países simultáneamente suspendan pagos de su deuda.
Sobre la base de la información que se le ha presentado, responda las preguntas que se le formulan a continuación
entregando los fundamentos correspondientes:
PREGUNTAS
a) Suponga que usted compra un portafolio de CDS de bonos de varios países emergentes. ¿Como debería ser
 el beta del CAPM (o beta de mercado) de los flujos asociados a este portafolio de CDS? Si combina este
 portafolio de CDS’s con un portafolio de bonos soberanos de países emergentes, ¿qué debería ocurrir con el
 beta de su portafolio combinado? Justifique sus respuestas.
1 Un bono soberano es un título de deuda emitido por el gobierno de un país.

[pág. 13]
13
b) Dado que el CDS funciona como un seguro, la compra de este instrumento permite “quitar” el riesgo de
 crédito a un bono soberano. Seguirá existiendo riesgo de mercado o riesgo de tasa, pero, en principio,
 comprar un CDS hace al bono soberano de cualquier país igual de seguro que el bono emitido por EE.UU.
 (asumiendo que EE.UU. es un emisor libre de riesgo de crédito). En consecuencia, debería existir una
 relación de arbitraje entre la tasa de un bono soberano chileno (𝑦 ), la prima del CDS (𝑟 ), y la tasa del
 bono del Tesoro de EE.UU. (𝑦 , considerando un bono de EE.UU. al mismo plazo, moneda y otras
 condiciones contractuales que el bono chileno. ¿Cuál debiera ser la relación de arbitraje que debiera
 cumplirse? Explique la intuición de esta relación y los supuestos utilizados.
c) ¿Qué fricciones podrían explicar que no se cumpliera la relación de arbitraje sugerida por Ud. en (b) en la
 práctica? ¿En qué condiciones de mercado esperaría Ud. que fuera más probable que no se cumpliera la
 relación encontrada en (b)? Sea breve y preciso.

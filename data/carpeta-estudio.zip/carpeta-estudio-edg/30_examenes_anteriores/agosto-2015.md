# Examen de grado · agosto-2015

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


PONTIFICIA UNIVERSIDAD CATÓLICA DE CHILE
ESCUELA DE ADMINISTRACIÓN : ¡
a
SS j
a |
ES |
e AS
SE CH ;
EXAMEN DE GRADO i
INFORMACIÓN GENERAL E INSTRUCCIONES: 4
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, :
el alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan. ;
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud, cuenta con dos :
hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni i
utilizar hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta. :
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. á
Suponga que los datos que ha recibido están correctamente calculados y que no han sido tergiversados. ;
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la :
realidad de las empresas que allí se mencionan. :
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados :
dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta. ¡
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la :
misma ponderación al momento de ser evaluadas, i
7. Las preguntas de enunciado se podrán hacer solamente al Profesor lgnacio Rodríguez, Presidente de la |
Comisión de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo. 1
1
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, eto.). i
El cumplimiento de esta norma es de absoluta responsabilidad del alumno. — * ¿
9. Usted NO debe escribir su nombre en las hojas de respuesta. :
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
condiciones, el Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a). ]
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala, los que deberán estar apagados y :
no deberán mantenerse sobre el escritorio durante el examen. ¿
12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el :
examen. E
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
identificado con un número, Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar :
como “borrador”, esas hojas no se deben entregar con las respuestas. :
Fecha : 7 de agosto de 2015 :
Duración : 9:00 horas a 12:00 horas ]
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el Profesor 1
Ignacio Rodríguez, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 ]
11:00 hrs. (aprox.). ]
-----
2 :
PREGUNTA N* 1 :
El mercado de los taxis en el mundo no había cambiado mucho en los últimos 50 años hasta la llegada de
una nueva generación de empresas de taxi tales como Uber, SaferTaxi, EasyTaxi y varias más. El tradicional
taxi en Londres o en Santiago, se contrata en la calle con un precio base (bajada de bandera) y luego un
cargo que está asociado a la distancia recorrida y un recargo cuando el auto está detenido. Estos precios por
bajada de bandera y distancia recorrida están regulados y no pueden ser cambiados por el chofer. Por ello,
existe un taxímetro que va en el auto. También están las empresas de “radio taxi” a las cuales uno llama para l
que lo vayan a buscar a una determinada dirección y finalmente, están los colectivos, con precios fijos
basados en recorridos preestablecidos. ;
La empresa Uber fue creada el año 2009 en Estados Unidos y hoy existe en alrededor de 50 países y en 200 :
ciudades, incluida Santiago. Uber es una plataforma que permite unir a los usuarios en necesidad de :
transporte con choferes independientes, dispuestos a llevarlos por un precio, de los cuales Uber obtiene :
aproximadamente el 20%. El servicio que ofrece Uber al usuario es el uso de una aplicación móvil sobre un :
teléfono inteligente y con capacidad de uso de GPS, para solicitar un auto y chofer previamente calificados ¡
por Uber y con altos estándares de servicio. La aplicación entrega el tiempo exacto para ser recogido e
informa de la llegada del auto vía el celular, El cobro por el servicio es una combinación de tarifa base (ej.
$800) más un cargo por distancia (ej. $300/km) y por minutos recorridos (ej. $120/min.). Al terminar el ,
viaje, Uber informa al usuario el costo total del viaje vía el celular y lo carga a la tarjeta de crédito :
(previamente registrada en web) del pasajero, con la aprobación de éste. El pasajero puede luego evaluar al :
chofer y el trayecto vía su aplicación. :
A Na AS A A Ai :
A IES AS niga i
|
u aa: a a: CES :
PA. $8.25 PP |
SS +. MM. MM. - |
 do-- Plos=. | lema l |
El chofer, que se une junto con su auto a la red de Uber como independiente, recibe como depósito directo :
en Su cuenta aproximadamente el 80% de la tarifa cobrada por Uber en cada trayecto. El chofer aporta el :
auto (con estándares mínimos exigidos de calidad del vehículo, tales como marca, antigiedad y tamaño, :
entre otros), y asume todos los costos de mantención, combustible y seguros. :
Uber, por su parte, asume los costos del pago con tarjeta de crédito, y se preocupa del servicio de atención :
a clientes (call center y web) y del desarrollo de la aplicación. Los choferes son independientes y ellos i
deciden libremente, en cada solicitud de trayecto, si la aceptan o no, así como las horas y días en que salen i
a trabajar. Ellos no tienen vínculo contractual de trabajo con Uber. Uber selecciona estrictamente a los :
choferes/autos que postulan a pertenecer a la red y mantiene limitado el número de choferes de la red para ]
garantizar la calidad. El auto debe cumplir con las exigencias de Uber, pero no requiere pintarse de color j
negro-amarillo ni tener taxímetro. Los choferes no necesitan permiso oficial especial alguno para operar ]
sus autos con Uber. :
En los días en que ocurren extremos climáticos (lluvias, nevazones, etc.) o eventos masivos (ej. eventos :
deportivos, manifestaciones, conciertos, etc.), Uber aplica una tarifa especial mayor en el área del evento, :
que duplica o triplica el valor regular mientras dure el evento (se conoce como “Surge Price”: 2X 6 3X), la :
cual es informada al potencial pasajero cuando pide el taxi vía su aplicación. :
-----
3 :
0 ss Xan
y - De Ls E ¿
EA a ES ne 6
e NZ sd ml ron :
PREGUNTAS
1) Considerando el modelo de negocios de Uber, ¿qué tipos de clientes ha descubierto Uber que le han
permitido diferenciarse y ser exitoso? ¿Cuál es la propuesta de valor de Uber para cada tipo de cliente?
2) El uso del incremento en precios (“Surge Price”) en días de eventos especiales ha generado muchas |
críticas de algunos pasajeros y de la opinión pública, que han visto que el costo del trayecto, mientras ]
dure el evento, se multiplica por dos o tres veces respecto del precio normal. Aplicando conceptos de :
marketing, argumente por qué es fundamental esta política de precios para el modelo de negocios de a
Uber, 1
i
4
i
d
1
-----
4 :
PREGUNTA N* 2
Mientras las frías ráfagas de viento azotaban la ciudad, en la sala de reuniones del piso 10 de la torre de
oficinas “Los Campeones”, la temperatura iba en aumento. El equipo ejecutivo de los supermercados
Suceso, se encontraba analizando los resultados de la empresa. Suceso estaba entre las cuatro cadenas de
supermercados más grandes del país. La empresa había invertido muchos recursos en tecnología para hacer :
más eficientes sus procesos operacionales y de ventas en sus salas, en línea con las mejores cadenas del :
mundo. La productividad de sus empleados, sin embargo, era baja, lo que contrastaba con el deseo de la :
empresa de ser líder en productividad de su industria. :
Ricardo Parada, miembro del equipo ejecutivo que estaba reunido, señalaba: “Si queremos ser los mejores en :
. la industria, debemos compararnos con los estándares que tienen las cadenas de supermercados en Estados ;
Unidos.” Parada, sabía que si no se lograba incrementar la productividad (margen de operación de cada :
tienda/n” de trabajadores), difícilmente la empresa podría convertirse en líder en su propio país y menos :
y » p pi pais y
expandirse a América Latina. Dentro del país todas las cadenas de supermercados mostraban, en promedio, :
niveles similares de productividad. Por lo tanto, afirmaba Parada: “la única manera de ser competitivos en el !
tiempo, es lograr una administración de nuestro negocio, particularmente en lo referido a la gestión de
personal, que se constituya como nuestra fuente de ventaja competitiva. Por ahora estamos lejos de ser !
competidores de clase mundial.”
Y en una clara señal de molestia agregó Parada: “miren este análisis de nuestro Departamento de Estudios :
(ver gráfico a continuación)”:
|
Brecha de Productividad (Margen operacional de cada sala de supermercado/ i
N? de trabajadores) en las cadenas de supermercados 2010-2014 i
i
AU ¿
A > 2 O ;
E o o. :
O o |
A |
Productividad Informatidad Bajo uso de las apacidad para Menor Canasta. Productividad :
en un en la gestión tecnologías lograr que las capacidad de promedio que  enuna sala de
supermercado — de diversos para , nuevas salas Suceso para compra el supermercado |
promedio de procesos operaciones y operen aplena adaptar al consumidor de  líderen , |
Suseso (compras ventas capacidad personal menor valor Estados Unidos :
operaciones, disponiblesen (madurez) en frente a que en Estados ¿
ici ? las salas en un menor diferencias en Unidos ¿
servicio al _ ” > j
cliente, RR.HH. tiempo la afluencia de (precios y :
y público productos) i
administración !
general) i
“Los datos muestran que tenemos una productividad equivalente al 35% de la productividad de los :
supermercados líderes en Estados Unidos; o dicho de otra manera, somos un 65% menos eficientes que los :
líderes de la industria. El estudio cuantifica el aumento potencial en productividad que podría producirse en !
cinco áreas si se introdujeran prácticas modernas de gestión, particularmente en cuanto a la dirección de :
personal, que hoy no tenemos. Por ejemplo, si Suceso lograra formalizar la gestión de diversos procesos :
(compras, operaciones, servicio al cliente, etc.) lograría aumentar su productividad en 4% y así acercarse a la :
productividad que consiguen las cadenas de supermercados norteamericanas. ¿Cómo pretendemos escalar ¡
nuestras operaciones a otros países si nos falta tanto aún por mejorar nuestra gestión del personal?”, :
concluyó Parada. ;
-----
5 :
A continuación fue el turno del gerente de operaciones, Mario Bermúdez, quién manifestó: “yo creo que el |
problema es que en esta empresa se trabaja poco. Sin infringir la ley, es claro que podemos aumentar el
número de horas que se trabaja en nuestros supermercados. La gerencia de recursos humanos (RR.HH.)
recientemente me entregó los datos comparativos del promedio de horas trabajadas en los supermercados e
chilenos (Suceso está en el promedio), comparadas con los supermercados en otros países de la OECD :
(economías más desarrolladas). El gráfico siguiente nos muestra que aún hay espacio para aumentar la :
productividad de nuestros supermercados, incrementando el número de horas trabajadas, lo que aumentaría a
su vez las ventas de cada sala y con ello la productividad.”
Horas de trabajo por empleado al año en supermercados en diferentes países de la
Organización para la Cooperación y el Desarrollo Económicos (OCDE) (*)
México 2.228 |
Costa Rica PEPE EEES 2.216
Grecia hi a 7 A id al 2.042
Estados Unidos a o ol 1709
o o El
a E |
Nueva Zelandia PET 1.762
l
Alemania hi a 1,371 :
(*) Promedio de los años 2010-2014
i
|
PREGUNTAS
Como asesor del equipo ejecutivo, usted se encuentra esta mañana en la reunión y se le pide su opinión i
respecto a dos asuntos que pueden aportar en la solución al problema de Suceso:
j
1. ¿Está usted de acuerdo con los argumentos entregados tanto por Parada (instalar prácticas de gestión de |
personas que incrementen la productividad) como de Bermúdez (aumentar las horas trabajadas en los :
.. , . j
supermercados) para elevar la productividad de Suceso? Justifique en forma precisa su respuesta.
d
2. Considerando la información entregada, describa las dos prácticas o decisiones propias de la gestión :
estratégica de RR.HH. que permitirían incrementar de manera más significativa la productividad de :
Suceso (Margen operacional en cada sala de supermercado / N” de trabajadores). En su respuesta explique ¡
cómo dichas prácticas impactarían de manera relevante en el incremento en productividad de Suceso. :
-----
o
PREGUNTA N" 3 i
La compañía OKLEDOK S.A. cuenta actualmente con un capital de 5.000 de acciones en circulación
(emitidas, suscritas y pagadas) y su propiedad está dividida entre un grupo que controla el 51% de las
acciones y varios accionistas minoritarios que son dueños del 49% restante. En este momento la !
capitalización de mercado de OKLEDOK S.A. o el valor de mercado de su patrimonio es de US$50.000 y la :
empresa tiene un monto de deuda total cuyo valor de mercado alcanza los US$30.000. Las acciones de :
. OKLEDOK $.A. se transan tanto en Chile como en el extranjero. :
La empresa ha estimado necesario realizar nuevas inversiones que le permitan mantener el liderazgo que ella :
tiene en la región y para ello necesita llevar a cabo un aumento de capital por la suma de US$10.000. :
En este momento, el grupo controlador de la compañía está analizando una propuesta con relación al precio
de emisión de las nuevas acciones que se requerirían para recaudar los US$10.000 de fondos necesarios para
las futuras inversiones. En la discusión respecto del precio al cuál emitir las nuevas acciones, han surgido
dos posturas: la de quienes plantean que se debieran emitir acciones a US$8 cada una y la de quienes ]
consideran que se debieran emitir a US$16 cada una. El precio de emisión aún no ha sido decidido.
Suponga que, antes de la emisión de las nuevas acciones, Don Pepe es dueño de 1.000 acciones de ;
OKLEDOK S.A,, y que toda su riqueza consiste en esas 1.000 acciones, más US$2.000 que él tiene en :
efectivo, :
Por otra parte, se sabe que de acuerdo a la legislación actualmente vigente en el país, existe lo que se conoce
como el derecho preferente de suscripción, que consiste en que, cuando una empresa emite nuevas acciones, :
dichas acciones deben ser ofrecidas en primer lugar, al precio de emisión acordado, a sus actuales i
accionistas, en la proporción de la propiedad que cada uno de ellos tenía de la empresa al momento de la :
emisión, De este modo, el derecho preferente de suscripción otorga, a todos los accionistas, la posibilidad de
mantener, luego de la emisión de nuevas acciones, el porcentaje de la propiedad que cada uno de ellos tenía
antes del aumento de capital. :
PREGUNTAS i
|
1. Suponga que todos los accionistas de OKLEDOK S.A.(mayoritarios y minoritarios), han decidido :
suscribir el aumento de capital y por lo tanto comprar las acciones en los porcentajes que les permitirán
mantener la participación en la propiedad que cada uno de ellos tenía antes de la emisión de las nuevas i
acciones. ]
a. Si las nuevas acciones hubiesen sido emitidas a US$8 cada una; obtenga el valor de la riqueza de
Don Pepe luego de la emisión de las nuevas acciones. Para ello, indique expresamente tanto el ¿
número total de acciones que Don Pepe tendría luego de la nueva emisión, como el valor de
mercado por acción de OKLEDOK S.A. luego de la nueva emisión. Para números no enteros, use ]
cuatro decimales. Fundamente su respuesta mostrando los cálculos necesarios. ]
: b. Responda la pregunta “a” anterior, suponiendo ahora que las nuevas acciones hubiesen sido
emitidas a US$16 cada una. Justifique su respuesta mostrando los cálculos pertinentes.
2. Suponga ahora, y sólo para efectos de responder esta pregunta, que las normas legales indicaran que |
si en la primera oportunidad en que se ofrece a los actuales dueños comprar las nuevas acciones del
aumento de capital (primera vuelta), un accionista no hace uso de su derecho preferente de suscripción, :
las nuevas acciones emitidas y no compradas por los actuales accionistas, en dicha primera vuelta, serán ]
ofrecidas en una segunda vuelta, a los accionistas que compraron en la primera oportunidad, al mismo :
precio de suscripción original, pudiendo entonces estos últimos aumentar su porcentaje de participación
en la propiedad de la empresa. El accionista que en primera vuelta no compró acciones de la nueva
emisión, no puede vender en el mercado esos derechos de compra o suscripción de nuevas acciones.
Suponga ahora que Don Pepe no tuviera los recursos que le permitirían comprar las nuevas acciones del ]
aumento de capital, pero él sabe que en este caso, los accionistas mayoritarios, quienes en primera |
-----
7
vuelta ya suscribieron el porcentaje que les correspondía, estarán dispuestos a comprar el mayor número
de acciones posibles de aquellas que se ofrezcan en segunda vuelta, cualquiera que sea el valor de :
suscripción que ellas tengan. :
El día en que se deba decidir el precio de suscripción de las acciones de la nueva emisión (US$8 o
US$16), ¿por cuál precio de suscripción debería votar Don Pepe y por qué?
3. Suponga ahora que en la primera vuelta en que se ofrecen las nuevas acciones, un accionista decide no
hacer uso de su derecho de suscripción preferente. Suponga también que estos derechos preferentes :
pueden ser vendidos en el mercado y que el accionista controlador ha decidido utilizar el precio menor :
(US$8) para realizar el aumento de capital de OKLEDOK S.A. Finalmente, suponga que todos los /
accionistas antiguos (controladores y minoritarios) tienen el derecho preferente a suscribir su fracción :
(prorrata) del aumento de capital y que, como se ha indicado en esta pregunta, dicho derecho preferente ,
puede ejercerse (pagando la fracción correspondiente del aumento de capital) o venderse a un tercero. :
a. ¿A qué instrumento financiero conocido se asemeja el derecho preferente de suscripción? Explique
su respuesta.
b, Algunos accionistas minoritarios, han efectuado sendas declaraciones a los medios de
comunicación, denunciando un desmedido afán de lucro y la “expropiación” que pretende llevar a ]
cabo el accionista controlador al emitir las nuevas acciones “a precios tan bajos”. ¿Está usted de ]
acuerdo con este planteamiento de los minoritarios? Fundamente numéricamente su respuesta. |
e
|
]
|
|
z
-----
8 :
PREGUNTA N' 4 :
El Grupo Innovation and Development Group (IDG) es considerado un ejemplo en desarrollo empresarial, y
su único Gerente General Corporativo latino, el mexicano Juan Antonio Mejías, un ejemplo de buenas :
prácticas de gestión de alta dirección. :
IDG fue fundada para explotar patentes de invención y gestionar procesos de innovación y desarrollo :
tecnológico. En poco tiempo se convertiría en un grupo empresarial con participación en diversos campos de
actividad comercial, con operaciones relacionadas con la generación, distribución y uso de energía eléctrica,
De esta forma, el portafolio de negocios del Grupo IDG fue aumentando con el tiempo, y en la actualidad :
posee negocios en los sectores de la aviación, el plástico, la energía nuclear y la informática, entre varios :
otros, El Grupo IDG opera además otras divisiones como generadores, transformadores, cables, iluminación i
y electrodomésticos. La envergadura de este Grupo es de tal complejidad, que desde hace muchos años su ;
gestión representa un verdadero reto para quienes la dirigen. :
Entre los principales ejecutivos que el Grupo IDG ha tenido a lo largo de su historia, sin lugar a dudas
merece una mención especial Juan Antonio Mejías, quien ejerció la posición de Gerente General entre 1990 :
y el 2010. Mejías es considerado por muchos como la persona que trasformó verdaderamente a este Grupo, y :
que lo llevó al sitial que hoy día tiene en el mundo. En las dos décadas que estuvo al mando de la gestión del
grupo empresarial, Mejías realizó diversas transformaciones, siendo una de las principales la que hizo en el :
desarrollo y formulación de la Visión/Misión Estratégica del Grupo IDG. Los resultados lo acompañaron :
durante su gestión, con sostenidas alzas en la cotización bursátil de la acción del Grupo a lo largo de los 20 :
años que lo dirigió. |
j
El primer período de la administración de Mejías (1990 — 2000) |
!
La situación de los diversos sectores donde participaba el Grupo IDG se fue tornando cada vez más :
competitiva como consecuencia de la permanente entrada de nuevos actores, la cual era estimulada por el
desarrollo y crecimiento en cada sector donde se competía. Para ganar posición en los diferentes mercados, - j
Mejías se orientó a construir un posicionamiento estratégico en cada negocio en que participaba. Su gran :
desafío por negocio fue impulsar el desarrollo comercial y de los productos, construyendo marcas y ventajas |
competitivas en cada uno de ellos, de manera de capturar resultados atractivos y salir del período de |
monotonía que hasta 1990 mostraban los resultados del Grupo. En palabras del propio Mejías, la :
Visión/Misión Estratégica del Grupo IDG como un todo, a comienzos de 1990 fue la siguiente: |
“Buscaremos que cada negocio del Grupo IDG, sea percibido como único, altamente ¡
inspirador, admirado y muy rentable. Buscaremos además que como grupo empresarial se nos :
aprecie como muy diversificado y líder en calidad en todos y cada uno de nuestros productos, ”
El segundo período de Mejías (2000 — 2010) i
Fue un período complejo para el Grupo IDG. Todo el posicionamiento estratégico construido en la década
anterior había logrado forjar una sólida posición en cada negocio, la cual requería consolidarse y fortalecerse, i
sobre todo considerando el nuevo entorno que se vivía. En efecto, en los diferentes mercados aparecían i
señales de desaceleración, con una demanda que no crecía, habiendo desaparecido muchas empresas :
competidoras de los diferentes negocios de IDG. Parecía claro que los distintos sectores donde se competía, i
habían entrado en una fase de madurez. Lo anterior, en opinión del propio Mejías, generaba importantes :
desafios para el equipo de profesionales, directivos y trabajadores de la empresa. A ellos “les correspondía :
hacer su parte”, señalaba Mejías ante el difícil momento que se presentaba en todos los mercados al inicio
del 2000. Fue precisamente en esa época, cuando Mejías hace un nuevo ajuste en la Visión/Misión ]
Estratégica del Grupo IDG, quedando ésta a contar del año 2000 de la siguiente manera: E
“En los últimos años hemos construido el posicionamiento estratégico deseado para IDG, cual |
es el de un grupo empresarial admirado, creciente, con productos de muy buena calidad y muy :
rentable. Necesitamos seguir en esta línea estratégica y no desviarnos de ella, fortaleciendo el |
posicionamiento alcanzado en cada mercado.
-----
9 z
En los próximos 10 años, queremos que, además de lo anterior, las revistas describan al Grupo
IDG como un lugar donde la gente tiene la libertad para crear, un lugar que saca a la luz lo
mejor de cada persona, de cada colaborador. Un lugar donde se alcanzan destacados niveles de
productividad y eficiencia, que sean un ejemplo para el mercado y ampliamente reconocidos en
la industria. Un lugar abierto y agradable, donde la gente tenga la sensación de que su trabajo
cuenta, y donde esa percepción sea retribuida tanto en lo económico como en el espíritu.”
PREGUNTAS :
1. ¿Qué objetivo persigue Juan Antonio Mejías con la primera definición de Visión/Misión que realiza
para su primer período (1990 — 2000) como gerente general de IDG ? ¿Qué objetivo persigue con la |
segunda definición de Visión/Misión, que realiza en su segundo período (2000 — 2010) como gerente :
general de IDG? Sea preciso en su respuestas. .
2. Desde un punto de vista estratégico, y en base a la información que se le ha proporcionado en el :
enunciado, ¿qué razones (señale dos) explican el ajuste de la primera a la segunda definición de la :
Visión/Misión realizado por Juan Antonio Mejías? Sea preciso para contestar.
:
|
;
¿
|
|
|
-----
10
PREGUNTA N' 5
El mercado de automóviles de lujo en EE.UU. en los últimos años ha estado dominado por las marcas BMW, :
Mercedes-Benz, Lexus, Audi, Accura e Infinity. Las marcas del grupo económico TaTa de India, Jaguar y
Land Rover, apenas llegan al 3% de participación de mercado en este país. Los ejecutivos del grupo Tata
esperan que esto cambie en los próximos años porque pretenden re-posicionar al modelo Jaguar en el
mercado de lujo de EE.UU. como un modelo deportivo, de buen diseño y de buena calidad en relación a su
precio,
Para evaluar la nueva propuesta de valor de la marca Jaguar, los ejecutivos de Tata India realizan un estudio :
de posicionamiento del mercado de automóviles de lujo en EE.UU. Las Figuras 1 y 2 que se exhiben más :
adelante, muestran un mapa de percepciones del mercado de automóviles actual, en el cual Jaguar es
prácticamente inexistente. El mapa se construye a partir de un estudio basado en las percepciones de ,
atributos relevantes de las marcas más significativas. La Figura 1 presenta las dimensiones o factores 1 y 2
mientras que la Figura 2 presenta las dimensiones o factores 1 y 3. En el título de los ejes se indica el % de la
varianza explicado de acuerdo a la solución de análisis de factores. El Cuadro A, que aparece en la siguiente
página, entrega información adicional de las percepciones de los consumidores al presentar las correlaciones
entre las dimensiones obtenidas del análisis de factores y algunos de los atributos considerados en el estudio.
Por último, para incorporar las preferencias de los consumidores en el análisis, el Cuadro B, que se presenta
en la página siguiente, muestra los coeficientes de regresión que relacionan las preferencias declaradas por |
los consumidores (variable dependiente) con las dimensiones obtenidas del análisis de factores (variables
independientes). Los coeficientes no significativos estadísticamente en este Cuadro son reemplazados por el
valor 0. También se reportan en la última fila del Cuadro B los estadígrafos R? correspondientes.
1
Figura 1 : Mapa de Posicionamiento de Marcas en Dimensiones 1 y 2
2,0 -L,0 0,0 1,0 2.
A 2,0 E
a O Audi dl
o A
a O Mercedes 10.
o Í : :
8 | mM a E
Sl | inmi a
a | o |
LL: 0 Ford e Accura E ¡
a ! 0.
pa 4 0 Lexus o 1
a e ! € 20
o... Factor l43%)
-----
11
Figura 2 : Mapa de Posicionamiento de Marcas en Dimensiones 1 y 3
A
z z z A ias iii Sn ARE 20
: : Accura + :
ad ¿ 10:
a Mercedes Y : Ñ :
a o
A + O BMW ;
5. + + ; ; Er] + : . , ju ¿ 0,0 : j
5 : . o |
O Ford audi 8 Infinity Eo ;
Da . a 9 Lexus 10 ]
a a ) coo 20
o ca Factor 1 (43%) a o i
Cuadro A: Correlaciones entre Atributos Seleccionados y Factores y Comunalidades :
Atributos Factorl Factor2 Factor3 Comunalidad :
Atractivo 0.934 0.104 0.267 0.954
Mal Construido -0.989 0.111 0.026 0.992 |
Deportivo -0.032 0.923 -0.030 0,853 :
Buen Diseño -0,102 0.899 0.113 0.832 E
Prestigioso 0.903 -0.416 -0.047 0,992 :
Valor* 0,426 0.054 0.866 0.934 :
- Varianza 43% 28% 18% :
(*) Desempeño en relación a precio |
Cuadro B: Coeficientes de Regresión entre Preferencias Declaradas y Factores :
Segmento 1 Segmento 2 Segmento 3 a
Tamaño % 40% 12% 48% é
Constante 6.00 5.63 6.60 :
Factor 1 1.53 0.00 1.10 :
Factor 2 0.68 0.95 0.00 :
Factor 3 0.68 0.00 2.08 :
R? 0.92 0.60 0.85 i
PREGUNTAS :
a) Describa las preferencias de los segmentos 2 y 3. ¿A cuál de estos dos segmentos debiera dirigirse :
Jaguar? Fundamente su respuesta. :
b) Suponga que Jaguar es exitosa en su reposicionamiento en este mercado y es percibido como un auto |
deportivo, de buen diseño, con alto valor. Suponga además que Jaguar logra ubicarse en la mente de los ]
consumidores como un automóvil tan deportivo y de buen diseño como el mejor del mercado actual (en :
las Figuras 1 y 2) y de tanto valor (desempeño en relación a precio) como el mejor del mercado actual i
(en las Figuras 1 y 2). ¿Qué posición ocuparía Jaguar en el mapa de posicionamiento? Grafique en los :
mapas de posicionamiento que se presentan en la Hoja de Respuesta y explique su respuesta. ]
-----
1
12 :
PREGUNTAN 6
Usted acaba de ingresar al Family Office de la familia LéR, en particular al equipo que maneja el |
portafolio de inversiones financieras de dicha familia. Su primera tarea es seleccionar un Fondo de :
acciones chilenas donde se invertirá aproximadamente el 10% de los recursos disponibles. Su
predecesor redujo las múltiples opciones a tres Fondos de Inversión con las siguientes características: :
Retorno neto :
rondo de acumulado entre Beta con respecto al e
ersió j
mvero9n | 101-13/30-06-15 Y IPSA
| Fondo2 | 58% ___| 08 7] |
[— Fondo3_]_ 54% ___| 09 |] |
(1): Corresponde al exceso de retorno, por sobre la tasa libre de riesgo, que exhibe el Fondo en cuestión en el
período señalado, neto de comisiones e impuestos. :
(2): El IPSA es el Índice de Precios Selectivo de Acciones, y se considera representativo de la cartera de i
mercado chilena. Durante el período analizado (1-01-13 al 30-06-15), este índice accionario acumuló un |
exceso de retorno (rendimiento por sobre la tasa libre de riesgo) de 5,7%. :
Suponga que el modelo CAPM fuera válido, que no hay inflación, y que el Family Office pretende
mantener la inversión en el Fondo que Ud. le recomiende por un período no inferior a un año. 1
Utilizando solamente la información que se le ha proporcionado, responda las preguntas que se le |
formulan a continuación. En todos los casos justifique sus repuestas. |
a) ¿Cuál de los tres Fondos elegiría usted si el objetivo de su inversión fuera entregar el mejor retorno |
ajustado por riesgo en acciones chilenas? !
Í
b) ¿Cuál de los tres Fondos elegiría usted si el objetivo de su inversión fuera superar el índice e
accionario IPSA? |
e) Suponga ahora que su propio análisis del mercado chileno y la opinión de expertos es que el mercado |
chileno vivirá un boom en el próximo año. Si Ud. tiene plena confianza en esta información y la cree
verdadera, ¿cambiaría el Fondo de Inversión elegido en las letras (a) y (b) anteriores? :
d) Suponga ahora que su propio análisis del mercado chileno y la opinión de expertos es que el mercado
chileno vivirá una fuerte crisis en el próximo año. Si Ud. tiene absoluta confianza en esta E
información y la cree verdadera, ¿cambiaría el Fondo de Inversión elegido en las letras (a) y (b)
anteriores?
-----


# Examen de grado · enero-2015

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


. PONTIFICIA UNIVERSIDAD CATÓLICA DE CHILE
Ga ESCUELA DE ADMINISTRACIÓN
SE .
E e)
az
7) NETAS
EXAMEN DE GRADO
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen,
el alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni |
utilizar hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta. |
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. |
. — Suponga que los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
realidad de las empresas que alli se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la :
misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente al Profesor Ignacio Rodríguez, Presidente de la||* |
Comisión de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo, |
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.).
El cumplimiento de esta norma es de absoluta responsabilidad del alumno. |
|
9. Usted NO debe escribir su nombre en las hojas de respuesta. . i
|
10, No está permitido salir de Ja sala durante el examen. En casos muy excepcionales, y bajo determinadas i
condiciones, el Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a). |
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala, los que deberán estar apagados y
no deberán mantenerse sobre el escritorio durante el examen.
: 12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
examen.
13. A) terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
| identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar |
| como “borrador”, esas hojas no se deben entregar con las respuestas.
Fecha : 23 de enero de 2015
| Duración  : 9:00 horas a 12:00 horas
| Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el Profesor
| Ignacio Rodríguez, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45
| 11:00 hrs. (aprox.). :
-----
0 IA a ti e A A A se |
. , |
PREGUNTA N” 1
La empresa McDonald”s tuvo un mal año 2014 en Estados Unidos. Las ventas cayeron cerca de 5% y los |
índices de lealtad también. Aquella época en que los adolescentes iban a McDonald”s debido a los bajos |
precios y utilizaban sus locales como centro de reunión ha ido quedando atrás. De acuerdo a un artículo en |
Brandchannel escrito por el periodista Dale Buss, “el principal problema de McDonald's, es que muchos |
jóvenes americanos pertenecientes a la generación Millennials, no perciben razones claras para seguir |
prefiriéndolo respecto de otras alternativas emergentes, tales como Chipotle (líder en comida mexicana |
casual tipo gourmet), Panera Bread (sándwiches gourmets, ensaladas y sopas) y Panda Express (comida |
china gourmet)”. La generación Millennials, compuesta por jóvenes nacidos entre las décadas de los 80's |
hasta principios de la primera década del 2000, se caracteriza por su uso masivo de las redes sociales y su |
familiarización innata con la comunicación, los medios y la tecnología digital. Los Millennials no sólo son
consumidores, sino también infhuenciadores y provocan cambios en los mercados. |
Panera y Chipotle corresponden a una nueva categoría de restaurantes llamada “Casual-Rápida” (Fast—-
Casual), que ofrecen comida mejor y más elaborada que las tradicionales cadenas de “Comida Rápida” |
(Fast-Food), con un servicio rápido pero a precios mayores en un 20% a 30% que un McDonald's. Una
comida promedio en un Fast-Food no supera los US$6 mientras que en los Fast-Casual cuesta
aproximadamente US$8. Las cadenas Fast-Casual tienden a enfatizar sus insumos frescos y sanos y el
cliente puede elegir sus ingredientes. Del total de ventas de restaurantes en EE.UU., los Fast-Food |
representan el 44% y los Fast-Casual el 8%. :
McDonald's, la principal cadena de Fast-Food a nivel mundial, tiene hoy cerca de 35.000 locales en más de
100 países y sirve a alrededor de 70 millones-de personas diariamente. Sus dos competidores más directos,
Burger King y Wendy”s, cuentan a nivel mundial con 12.200 locales y 6.550 respectivamente, El |
crecimiento en los últimos años de los locales que venden hamburguesas, principal categoría de alimentos de |
los restaurantes Fast-Food, ha sido estable y en torno al 2% anual, mientras que los locales de las cadenas de |
comida Fast-Casual han crecido a tasas superiores al 10% anual. Las estimaciones de crecimiento para los * |
| restaurantes de comida Fast-Casual en Estados Unidos son de un 9% anual para el período comprendido |
entre los años 2015-2017, Este mayor crecimiento es explicado fundamentalmente por los nuevos hábitos de |
| consumo en Estados Unidos, en especial de los Millennials, que favorecen una comida rápida más sana, de |
| mejor calidad y en ambientes más atractivos. |
McDonald's es una de las marcas más reconocidas en el mundo entero y ha llegado a constituirse en una |
marca símbolo de EE.UU, La propuesta de valor tradicional de la empresa ha sido “comida con una calidad |
estandarizada que es servida en forma rápida y consistente en todo el mundo a un precio bajo.” Los |
| Millennials, como segmento, representan para McDonald's un 20% de sus ingresos. |
| Los competidores tradicionales de McDonald”s son las cadenas de hamburguesas Wendy's y Burger King.
McDonald's es el líder de la industria y controla aproximadamente el 50% del mercado de los restaurantes
del tipo Fast-Food de hamburguesas en Estados Unidos. Sin embargo, y a diferencia de McDonald”s, sus
| competidores tradicionales han mostrado resultados positivos en sus ventas e indicadores de lealtad. La
| estrategia de estos competidores ha sido incorporar productos de mayor calidad a su menú tradicional y
modernizar sus locales. Algunas de las alternativas que han agregado estas cadenas a su menú tradicional son
las hamburguesas de soya, de carne wagyu, las hamburguesas de menor contenido calórico, etc. También han
introducido papas fritas light que contienen un 50% de menos calorías que las tradicionales.
| Como una forma de ir adecuándose a las nuevas tendencias de mercado del segmento joven, McDonald”s ha
| ido cambiando en los últimos años su propuesta de valor original ampliando constantemente su menú, de
l manera de cubrir las necesidades de todo su mercado objetivo. Las nueve alternativas que contenía su menú
-----
3
en 1948, en las cuales las hamburguesas representaban el 85% de su oferta, se han ampliado hasta 121,
: incluyendo nuevas categorías tales como postres y batidos, wraps, ensaladas, sándwiches de pollo y de |
pescado, entre otras. Incluso, en su declaración de misión actual, la empresa ni siquiera menciona las
hamburguesas. A pesar de lo anterior, sus resultados de ventas e indicadores de lealtad durante el año 2014 |
no han mejorado. |
El recientemente nombrado Presidente y CEO de McDonald's, Don Thompson, dijo en una entrevista: |
“Estos desafíos significativos requieren de cambios igualmente significativos en la forma que hacemos los
negocios. Los consumidores de hoy crecientemente prefieren flexibilidad y opciones al comer, ambientes |
atractivos y conveniencia al ordenar. En McDonald's estamos trabajando para entregar una mejor |
experiencia.” |
|
En la última reunión de Directorio de la empresa, un director presentó una nueva propuesta de innovación. |
Esta consistía en el lanzamiento de una nueva hamburguesa al mercado, la cual sería puesta recién en la 0
parrilla cuando el consumidor hiciera su orden. Además, al cliente se Je ofrecerían más de 20 alternativas |
(desde tomate hasta champiñones a la parrilla) para que él construyera la hamburguesa que deseara. Todo |
esto se haría en el mismo sector donde hoy se producen las hamburguesas tradicionales. Además, el precio
promedio de la hamburguesa pasaría de U$5,79 a U$7,79 convirtiéndose en el producto de mayor precio del
menú, lo que permitiría a la empresa mejorar sus resultados financieros. Asimismo, el director proponía |
sustituir en un 30% la variedad de productos actualmente ofrecidos. Su idea era incorporar,
fundamentalmente, productos bajos en calorías como por ejemplo ensaladas y frutas, sopas, jugos, yogures
- naturales, y otros productos saludables, en detrimento de las hamburguesas, papas fritas y bebidas.
Otro director de la empresa opinaba que está propuesta era un error. De acuerdo a su razonamiento, si |
McDonald's quería mantenerse creciendo y siendo rentable debía reforzar lo que históricamente hizo, |
hamburguesas estandarizadas de bajo precio, reducir las categorías de productos para acelerar el proceso de |
: compra e invertir en renovar los locales y agregarles tecnología de punta (wi-fi, cargadores de celulares, |
pago a través de teléfonos, etc.). ! : |
|
| PREGUNTAS : o
1) Desde el punto de vista de la propuesta de valor tradicional de McDonald”s, ¿qué aspectos se verían |
| negativamente afectados con las proposiciones hechas por cada uno de los directores? Refiérase a cada : |
| una de ellas por separado.
2) Utilizando los conceptos de marketing, ¿cuál de las dos propuestas presentadas por los directores |
contribuye de mejor manera a que McDonalds mejore su posición competitiva en los próximos tres |
años? Justifique claramente su respuesta de manera breve y precisa. .
|
-----
4
PREGUNTA N* 2
Ernesto Piña, analista del sector fruticola exportador, preparaba el informe que debía despachar esa misma
. tarde a dos empresas frutícolas que le habían consultado sobre el impacto que tendrían en el negocio los
cambios en la legislación laboral anunciados para el 2015.
En Chile, la industria exportadora de frutas está estructurada alrededor de tres actividades: producción,
procesamiento y exportación de sus productos. Existen alrededor de 7.800 productores, 60 empresas
procesadoras y 520 exportadoras. Las empresas multinacionales del sector y también grandes y medianas
empresas nacionales están integradas a través de toda la cadena de valor en las tres actividades mencionadas.
Las compañías de menor tamaño, en cambio, se dedican a alguna de las actividades específicas de la cadena
de valor. El sector frutícola exportador es cíclico. La mayor actividad se produce entre octubre y abril, que
coincide con el período de cosecha, procesamiento y envío al exterior de la mayoría de variedades de fruta
producida (e.g., arándanos). Algunas empresas se han diversificado a otras variedades de fruta “de invierno”
(e.g., naranjas) extendiendo su temporada a todo el año.
Durazno S.A, es una empresa integrada verticalmente con un posicionamiento de bajos costos en la industria. |
Su organización del trabajo entrega metas específicas y gran autonomía a cada una de las tres áreas del |
proceso de la fruta. Cada área intenta reducir costos y con un mínimo nivel de coordinación, le traspasa el |
producto en proceso a la siguiente área de la cadena, hasta llegar al cliente final. Para reducir costos, ¡
Durazno ha subcontratado la mayor parte de la cosecha en sus huertos y el procesamiento de la fruta a |
empresas con personal altamente especializado y que hacen uso intensivo de tecnología en sus procesos. Las
exportaciones las realiza en un 100% el equipo de ejecutivos comerciales de Durazno S.A. Esta es una
compañía que ha tenido una historia de conflictos con su personal debido a un estilo de liderazgo autoritario
-impuesto por el dueño-, con bajo nivel de comunicación con sus trabajadores y escasa participación de estos |
en la generación de ideas y soluciones que aporten a la reducción de costos. Hasta ahora la empresa ha |
evitado la formación de sindicatos. Cuando dichos intentos han existido, la administración ha respondido con |
incrementos salariales al personal, ante los cuales los trabajadores, hasta ahora, se han desistido de -
sindicalizarse. Durazno opera a capacidad completa durante toda la temporada de fruta fresca y luego, |
durante tres meses, entre julio y septiembre, despide a gran parte del personal, para volver a contratar en la |
siguiente temporada que comienza en octubre. La compañía retiene a un grupo reducido de personas con
contrato indefinido quienes hacen tareas de mantención en los campos (limpieza y poda). La planta cierra
para mantención de equipos, realizada por mecánicos especializados de una empresa externa, :
Frambuesa S.A. es una compañía reconocida en los mercados por la calidad de su fruta. Su esquema de |
trabajo está basado en equipos de trabajadores polifuncionales que realizan diversas actividades en |
simultáneo: tareas técnicas específicas propias de cada cargo, análisis estadísticos de sus procesos, |
colaboración en mejoras en seguridad laboral y participación en el mejoramiento de la calidad de todos los |
procesos y productos de la compañía. Frambuesa tiene un estilo de liderazgo participativo con diversos |
canales de comunicación con los trabajadores. También mantiene una relación de colaboración con su |
sindicato que representa al 70% de los trabajadores, mayoritariamente los de mayor antigiedad en la |
empresa. Últimamente, sin embargo, debido a la escasez de personal calificado en el mercado, la empresa ha |
contratado personal joven, no sindicalizado, que ha mostrado un mayor nivel de rotación en la empresa. Por
otra parte, Frambuesa realiza labores de cosecha y procesamiento durante toda la temporada de fruta fresca.
El resto del año (mayo-septiembre) Frambuesa hace mantención en sus campos y presta servicios de
procesamiento a otras compañías fruteras que producen variedades “de invierno” durante esos meses, las que
no cuentan con su propia planta y valoran los altos estándares de calidad de esta empresa.
Recientemente se anunciaron cambios en la legislación laboral que entrarían en vigencia durante el año
2015. Primero, se prohíbe expresamente que los trabajadores realicen funciones de distinta naturaleza
-----
5
diferentes a las que establece su función específica. Segundo, para los contratos por temporada o faena, se
establece que el plazo del contrato será indefinido cuando un trabajador preste servicios en diversas obras o
faenas para un mismo empleador durante $ meses o más en un lapso de 12 meses. Tercero, queda prohibida
la subcontratación de trabajadores para las labores propias del giro principal de la empresa. Cuarto, en caso
de encontrarse la empresa en huelga, se prohíbe el reemplazo de los trabajadores que están en paro por otros
(personal interno de la empresa o de empresas contratistas externas) para realizar dichas funciones que
quedaron sin personal. Finalmente, las reformas legales contemplan la libertad de empresarios y trabajadores
para llegar a acuerdos en diversas materias propias de la organización del trabajo -incluidas las antes
mencionadas y más allá de la negociación de remuneraciones-, como pueden ser diversidad de funciones a
desempeñar, horarios y jornadas especiales y tareas a realizar que sean diferentes a las habituales, siempre
que exista un sindicato en la empresa y que éste represente a más del 65% del personal de la compañía.
Ernesto Piña, ya estaba por concluir su informe. Antes de despacharlo a sus dos empresas cliente, le pide a
usted, en su calidad de colega consultor experto, que le dé su opinión sobre lo siguiente:
PREGUNTAS
1) ¿Cómo afectarán las reformas laborales anunciadas el logro de sus objetivos estratégicos y, en definitiva, |
el éxito del negocio de cada una de estas dos compañías? ¿Serán similares los efectos para Durazno y
para Frambuesa? Explique de manera breve y precisa. .
2) En relación a los cambios normativos planteados y considerando los sistemas de gestión de personas que
actualmente tienen implementados Durazno y Frambuesa, respectivamente, indique tres acciones
concretas que cada una de ellas debiera adoptar para hacer frente a dichos cambios legales y lograr la
implementación exitosa de su estrategia de negocio.
i
: . |
|
|
|
-----
: 6
PREGUNTA N* 3 .
Suponga que hoy es 31/12/14 y el balance, a valores de mercado, de la empresa Minera Nacional S.A, (MINASA), de
giro Explotación Minera, es el siguiente:
ACTIVOS PASIVOS Y PATRIMONIO
Caja $ 500 Deuda de Largo Plazo $ 3.600 (*)
Yacimiento $ 5.500 Patrimonio $ 2,400 (5)
Total $ 6.000 Total $ 6.000
(*): Valores de mercado antes de que se haga pública la posibilidad que tiene la empresa de invertir en un nuevo proyecto,
que se describe más adelante, y que en este momento está siendo analizado en el Directorio.
El mismo día 31/12/14, el Directorio de la empresa debe decidir si emprender un nuevo proyecto y la forma de
financiarlo, en caso que se opte por llevarlo a cabo. Este nuevo y único proyecto que la empresa tiene como
alternativa de inversión, es una expansión operacional de la compañía y tiene el mismo riesgo relevante que sus
actuales inversiones. Las principales características del proyecto que está evaluando son las siguientes:
o La inversión inicial sería de $3.000 (el total de ella se debe realizar al inicio de la vida del proyecto) y se destinará i
integramente a la adquisición de activos operacionales que se depreciarán contablemente a razón de $500 por año.
e El 60% del total de recursos necesarios para el financiamiento de la inversión inicial, es decir $1.800, sería
financiado usando un préstamo de un Banco que cobra un interés de 10% anual, equivalente a la tasa de mercado
para este tipo de deuda. El interés debe ser pagado al término de cada año. Sin embargo, se sabe que si al término
de cada año la empresa paga al Banco los intereses de la deuda, el préstamo de $1.800 se puede renovar de manera
indefinida. Los restantes $1.200 de la inversión inicial del proyecto, serían financiados con el aporte de un nuevo
socio, al que los actuales dueños, a cambio de dicho aporte, le han ofrecido una participación del 30% en la
propiedad de la empresa. o
o La decisión que la compañía ha tomado para el financiamiento de esta inversión (60% nueva deuda y 40% nuevo
capital), le permite operar con Jo que ella estima es su nivel de endeudamiento económico óptimo de largo plazo y !
la política es mantener dicho nivel a perpetuidad.
e. Los resultados esperados del nuevo proyecto, en términos anuales, son los que se presentan a continuación (la |
depreciación del ejercicio, única partida del estado de resultados que no es flujo de caja al final de cada período, i
se incluye dentro de los “Gastos de Administración y Ventas”). Para todos los efectos prácticos, estos resultados |
anuales se mantendrán constantes en forma indefinida: |
Estado de Resultados Anual Esperado del Nuevo Proyecto : |
Ventas $ 5.000 |
Costos de Explotación 3.000
Margen Bruto 2.000
Gastos de Administración y Ventas (1.360) |
Resultado Operacional 640 |
Intereses (10%) (180) |
Resultado antes de Impuestos 460
Impuestos (30%) (138)
Utilidad Neta Ss 322 |
Información Adicional y Supuestos: |
e Se estima que los flujos de caja anuales esperados del proyecto son perpetuos y constantes. La perpetuidad de
estos flujos se logra gracias a que al término de cada año la empresa reinvertiría la suma de $438, No obstante
estas reinversiones anuales, se sabe que en el futuro y de manera permanente, el gasto contable anual por
depreciación del nuevo proyecto, se mantendría en $500 lo que permitiría mantener, de manera perpetua, el
Resultado Operacional anual esperado.
e La tasa de impuestos corporativos es de 30%. No hay impuestos personales.
-----
|
: 7
+ La tasa de Costo de Capital Promedio Ponderado (C.C.P.P.) relevante para la evaluación financiera del nuevo
proyecto es de 15,0% (C.C.P.P. anual, después de impuestos corporativos).
» El total de la inversión inicial se paga al inicio del proyecto y todos los ingresos y gastos del Estado de
Resultados Anual Esperado de la empresa, con la sola excepción de la depreciación del ejercicio, son flujos
de caja que se producen al término de cada año. Suponga además que no hay inflación y que el primer flujo de
: caja del proyecto se produce exactamente un año después de realizada la inversión inicial.
e Altérmino de cada año, la empresa reparte a sus accionistas el flujo de caja residual disponible.
e Se espera que todas las tasas (%) vigentes en este momento en el mercado (tasa de interés de la deuda, tasa
exigida por los accionistas, tasa de C.C.P.P., tasa de impuestos, etc.) permanecerán invariable en el largo plazo.
e Si usted tiene que calcular alguna tasa de rentabilidad en % o en decimales, hágalo usando cuatro decimales,
Ejemplo: si r = 15,4632%, al transformar esa tasa en decimales use 0,1 54632 y viceversa,
Suponiendo que las proyecciones de resultados del proyecto estuvieran correctas, que no existen impuestos
personales ni inflación y que la estructura de financiamiento utilizada para el proyecto fuese la óptima de largo plazo
para la empresa, a usted se le pide responder las siguientes preguntas:
1) Obtenga el Valor Actual Neto (VAN) del nuevo proyecto de inversión, desde la perspectiva de la empresa o del |
activo (Enfoque de “Costo de Capital Promedio Ponderado”). En su respuesta refiérase y sea preciso en la |
determinación de: el monto de la inversión inicial a considerar, los flujos de caja relevantes y la tasa de descuento
que a su juicio se debiera utilizar en el cómputo del Valor Actual Neto (VAN). -
2) Uno de los Directores de la empresa, el Sr. Concerned, preocupado por los cambios que ha observado en la
legislación tributaria, ha planteado que él no descarta la posibilidad de que el Parlamento apruebe una ley que
establezca que, a partir de este mismo momento (31/12/14), los intereses de las deudas de las empresas no puedan
ser considerados como gasto para efectos de disminuir la base imponible. El Directorio quiere evaluar el mismo
proyecto pero ahora considerando la posibilidad que ha planteado el Sr, Concerned. Suponiendo que la tasa de |
C.C.P.P. relevante para la evaluación financiera del nuevo proyecto es de 15,0% y que los impuestos a las |
empresas fuesen la única imperfección presente en el mercado de capitales, ¿recomendaría usted emprender el |
nuevo proyecto bajo tales condiciones? Fundamente numéricamente. . |
|
3) Suponga ahora que el eventual nuevo socio, que aportaría los $1.200 de capital para financiar el nuevo proyecto, |
le ha hecho saber a los actuales dueños de la empresa que él no está dispuesto a realizar el apórte si a cambio |
recibe sólo un 30% de la propiedad. Dado lo anterior, los actuales dueños han recurrido al Banco del Sur para ver |
la posibilidad de conseguir un préstamo por el total de los $3.000 de recursos que se necesitan para financiar el
nuevo proyecto. El Banco ha informado a los dueños su disposición a prestarles los $3.000 que requiere el .
proyecto, pero con una tasa de interés mayor que la ofrecida inicialmente a la empresa. Se sabe que como |
resultado de la nueva tasa de interés que el Banco cobraría por el nuevo préstamo, y por distintas imperfecciones
que se observan en el mercado de capitales, el VAN del nuevo proyecto sería de $200.
Conocida esta nueva información, los actuales dueños saben que tendrían dos formas alternativas para financiar
los $3.000 que requiere el proyecto. La primera opción es financiarlo con $1.800 de nueva deuda más el aporte de
un nuevo socio que entregaría los $1.200 restantes, a cambio de un porcentaje de la propiedad de la empresa que
| tendría que ser mayor al 30%. La segunda alternativa sería pedir los $3.000 al Banco, en cuyo caso el VAN del
| nuevo proyecto sería de $200, :
| Sobre la base de la información disponible, y suponiendo que usted como representante de los actuales
| accionistas, hoy en la tarde (31/12/14) tiene que reunirse con el eventual nuevo socio para informarle si los dueños
| están dispuestos a ofrecerle un % mayor al 30% de la propiedad de la empresa, a usted se le pide determinar, de
manera fundamentada, el máximo % de propiedad de la empresa MINASA que los actuales (o antiguos)
| dueños de la compañía, podrían estar dispuestos a ofrecerle al potencial nuevo socio de la empresa, si ellos saben
que, en caso que el nuevo socio no acepte el nuevo porcentaje ofrecido, entonces el proyecto se tendría que hacer
| pidiéndole al Banco los $3.000 de inversión inicial que se requieren. Fundamente numéricamente su respuesta,
-----
8
PREGUNTA N* 4 .
Cloud Computing: el nuevo escenario para la guerra tecnológica |
Gigantes de la tecnología desarrollan una guerra de precios para ganar |
el negocio computacional de otras firmas |
|
En 2004, la empresa Amazon comenzaba a armar su infraestructura tecnológica para ofrecer servicios |
computacionales a otras compañías. Diez años después, Amazon había constituido “Amazon Web Services”, |
empresa a través de la cual estaba realizando cuantiosas inversiones tecnológicas, las cuales constituían el foco |
central para el éxito y consolidación de su negocio de Cloud Computing (CC). El servicio de CC, también
conocido como la “Nube”, permite a diferentes empresas arrendar espacio de almacenaje y capacidad de
procesamiento en servidores de terceros (por ejemplo, en servidores de Amazon), en lugar de comprar y |
mantener sus propios servidores y bases de datos. La “Nube” prometía ser revolucionaria: sería más barata, |
ofrecería una gran capacidad de almacenamiento de datos, mantendría los software al día, con mayores niveles
de seguridad, permitiendo además una mayor colaboración entre los usuarios. |
Pero las grandes compañías han incorporado el concepto de la Nube de manera más lenta que lo esperado. Hay |
quienes no han entrado al CC porque sus propios equipos de Tecnologías de Información pueden dar los |
servicios de manera más económica. Otros, no ingresan por las dudas que les genera el manejar información |
importante en servidores de otras firmas. En todo caso y pese a lo anterior, el negocio del CC ha ido creciendo |
de manera sistemática, aunque más lento que lo esperado.
Desde el punto de vista de la estructura del negocio de CC, el 70% de los costos corresponde a amortización de |
inversiones, sueldos y gastos fijos, dejando a sólo un 30% como costos que podrían ser administrados a partir de i
una eficiente gestión de recursos e insumos variables, |
Los resultados del negocio del CC están comenzando a mostrar niveles atractivos aunque todavía en la parte |
baja de la curva, como Jo muestran las proyecciones que hace la empresa IDC, firma de investigación en el |
| negocio de CC, que estima, para este año 2015, que el comercio mundial gastará unos 100.000 millones de |
dólares en servicios de CC, lo que se considera aceptable para un sector que aún está lejos de haber alcanzado su |
| potencial de crecimiento. |
|
| Es posible que el volumen anterior de negocios pronto comience a superarse, ya que las bajas de precios hacen
| al CC cada vez más barato. A fines de Marzo de 2014, Google redujo sus precios para el servicio CC, entre un |
| 30% y un 85%. Esta acción estratégica de Google, orientada a impulsar su negocio de CC, provocó una rápida |
| respuesta por parte de Amazon, quien también redujo precios en hasta un 65%. Por su parte Microsoft, quien
también es considerado un grande en el negocio de la Nube, los acompañó reduciendo sus propios precios,
Y la situación no termina aquí, por cuanto se proyecta que los precios continúen bajando. "Aún no hemos
| llegado a la base de la curva. Cada proveedor en la Nube hará lo imposible para igualar los precios de la
| competencia", señalaba en una revista especializada el Presidente de SR Group, empresa que monitorea a
| diversas compañías que utilizan CC.
| Algunos clientes ya están tomando ventaja de esta situación, como es el caso de la Edmund.com que ofrece vía
web información sobre autos. Esta compañía recibe 18.000 visitantes mensuales, y según ha anunciado su CEO,
| la empresa pondrá todo su sistema en la Nube de Google, con lo que espera ahorrar millones de dólares anuales.
| Amazon y otros competidores trabajan duramente para asegurar a las personas y empresas que sus datos estarán
| seguros en la Nube, un trabajo que ha sido complejo por rumores que han circulado en la industria en cuanto a
-----
9
que empresas como Google y Microsoft, son parte de redes de vigilancia online. En respuesta, las grandes
firmas americanas de la Nube han avanzado en sus niveles de encriptación de información para proteger los
datos que manejan y continúan trabajando en la obtención de mayores niveles de seguridad.
A pesar de los precios decrecientes en el sector, de la mayor seguridad, y del mayor nivel de ofertas disponibles,
una gran cantidad de empresas se mantienen cautelosas de entregar todas sus necesidades computacionales a
otra compañía. Por ello es que ha surgido el concepto de "Nube Híbrida", que mezcla el uso del servicio de
almacenamiento entregado por la Nube de empresas como Google, con la mantención de otros servicios y
aplicaciones en servidores propios de la compañía. Empresas como IBM y Rackspace, están promoviendo
ofertas híbridas para competir con otras del estilo de Amazon y Google.
Para los próximos años, esquemas híbridos en la Nube posiblemente serán los que dominen en el sector,
especialmente por la posibilidad que ofrecen a empresas que manejan información reservada (de clientes, del
negocio, etc.), de poder combinar almacenamiento externo en la Nube, con otro mantenido en la propia
empresa, para información considerada como más reservada o estratégica.
El Potencial del Cloud Computing
Ya son varios los interesados en el desarrollo del servicio del CC, y se proyecta que a medida que los precios |
caigan y la seguridad aumente, habrán más actores en esta industria, Diversos analistas del sector atribuyen este
alto interés en el negocio del CC al hecho de ser considerado como la puerta de entrada a otros servicios de *
_ mayor valor agregado, ¿Qué nos depara el futuro en la industria del CC. En poco tiempo más se irá dilucidando
esta interrogante.
PREGUNTAS
1) A la luz de la dinámica competitiva que se presenta en el sector descrito en el Caso, ¿es esperable una guerra |
de precios en el sector del Cloud Computing? ¿Por qué sí o por qué no? Señale tres fundamentos que |
sustenten su respuesta. Sea breve y preciso. . |
. > |
2) Considere a los principales actores de la industria. En el caso de darse una guerra de precios, ¿quién(es) |
- — gana(n) en el corto plazo y en el mediano y largo plazo? ¿Quién(es) pierde(en) en el corto plazo y en el |
| mediano y largo plazo? Argumente cada respuesta, en forma concisa, desde el punto de vista estratégico, . |
|
|
| - |
|
|
|
|
|
| .
-----
10
PREGUNTA N' 5 :
El concepto de farmers* markets (en español, “mercados de los granjeros”) se ha desarrollado mucho en los
últimos años, y la cantidad de este tipo de minoristas ha crecido una enormidad en Estados Unidos y Canadá,
pasando de 1.755 tiendas en 1994 a 8.144 en 2013. En ellas se venden muchos productos frescos, tales como
frutas y verduras, carnes, comida preparada, yogurts, dulces artesanales, etc., además de alimentos envasados |
que típicamente se consumen en un hogar. El surtido de productos favorece los alimentos frescos, orgánicos, |
integrales y, en general, saludables. |
Junto con ofrecer una gama diferenciada de productos en relación a la que ofrecen los supermercados |
tradicionales, los farmers' markets intentan posicionarse como una tienda de alimentación en que el cliente |
vive una experiencia de compra distinta, en base a atractivas exhibiciones de producto, variadas |
degustaciones de alimentos, hugares especialmente habilitados para consumir productos en la misma tienda, |
y la entrega de información y asesoría nutricional a los compradores.
Novofresh es una tienda farmers” market en Seattle (Washington, Estados Unidos), que nació en 1907 y que
se ubica en un sector residencial caracterizado por tener una población bastante diversa en cuanto a edad y
ciclo de vida familiar. Es muy común en este sector ver personas solteras, parejas sin hijos, familias con
hijos de distintas edades, y parejas mayores en que los hijos ya no viven con ellos. En los últimos años, la. |
tienda Novofresh se ha transformado en una de las mayores atracciones turísticas de la ciudad. Tiene un alto |
flujo de público, y las encuestas a clientes indican que estos están bastante satisfechos con la tienda y el
servicio prestado. Sin embargo, la rotación de ciertos productos, la compra promedio, y la rentabilidad de la
tienda no han sido lo suficientemente buenas, en relación a cifras de desempeño de otros farmers * markets de
Estados Unidos. Por lo tanto, los dueños de. Novofresh deciden contratar a Todd Offresco como asesor
comercial, para que les ayude a entender mejor el problema y proponer vías de solución. |
J
El diagnóstico de Todd indica que gran parte del alto flujo de personas en la tienda proviene de turistas, |
quienes no compran surtidos de productos muy rentables para la empresa: “el desafío es ampliar y potenciar |
la base de clientes locales!, y asegurarse que la propuesta de valor de Novofresh responda a sus necesidades, |
y los invite a volver a la tienda con frecuencia y a recomendarla a sus familiares y amigos.” Ante este |
desafío, Offresco explica a los dueños de Novofresh-que es fundamental medir y gestionar la experiencia del |
cliente durante su visita a la tienda. “Es necesario capturar las reacciones, sentimientos, motivaciones y |
comportamientos de los consumidores antes de que estos elementos sean racionalizados y filtrados por la .
memoria. Esto es particularmente relevante en tiendas de este tipo, en que el cliente no sólo viene a comprar
productos de “su canasta típica”, sino que a buscar soluciones alimenticias, y disfrutar el proceso de compra,”
argumentaba Offresco. |
|
Los dueños de Novofresh, convencidos con el planteamiento de Offresco, deciden contratar a la empresa |
RevNext, que ofrece un servicio de medición y gestión de- experiencia de clientes en tienda, a través de los
propios teléfonos inteligentes (smartphones) de los clientes. ¿Cómo funciona? Primero, usando la base de
datos de clientes locales de la tienda, se invita a unos 20 clientes a que participen de un estudio de mercado
durante 2 semanas, y como agradecimiento se les entrega una canasta de productos seleccionados al término
del estudio. Para que este grupo represente a la clientela de Novofresh, se reclutan personas de distintas
edades y ciclos de vida familiar. Luego se instala la aplicación RevNext en los teléfonos inteligentes de Jos
participantes y se acuerda con cada uno un plan de visitas a la tienda, en días y horarios específicos.
Una vez en la tienda, la aplicación RevNext conecta en línea al cliente (a través de su teléfono) con un
investigador, quien desde su oficina monitorea el recorrido del cliente en la tienda, recibe sus comentarios y
T Clientes “locales” son aquellos que viven en Seattie, y por lo tanto no incluye a los turistas que visitan la tienda.
-----
- cn - 2 A A A A a A > -
11 o
le hace preguntas. A continuación se indican algunos ejemplos de los principales usos de la aplicación |
RevNext: |
- El cliente informa, al ingresar a la tienda, si viene solo o acompañado (y con quién). |
- El investigador le pregunta al cliente, mediante un mensaje de texto “¿qué andas buscando en este |
momento? Opciones: algo de aperitivo, algo para el almuerzo, algo de postre, algo para regalo, otra
cosa,” (El cliente debe marcar sus opciones en el teléfono).
- El cliente saca una foto de una exhibición de productos que le parece confusa y se la manda al
investigador con algún comentario al respecto.
- El cliente filma su propia cara haciendo un comentario al investigador, ya sea espontáneamente o a partir |
de alguna pregunta del investigador. |
- El investigador pregunta al cliente si vio o no una determinada promoción y qué tan atractiva le parece.
El cliente le responde a través de su teléfono.
- — Si hay una cola muy larga en las cajas, el cliente puede manifestar su incomodidad con tal situación |
simplemente haciendo un click en un ícono que indica “colas muy largas”.
- — El cliente registra lo que compra y el investigador le pregunta en ese momento por qué está llevando un |
determinado producto. .
.- — El cliente manifiesta sus emociones, en diversas etapas de la compra, a través de una serie de emoticons
(caras con distintas expresiones, por ejemplo cansado, enojado, contento, entretenido, etc.).
- — Inmediatamente terminada la compra, el investigador le pregunta al cliente qué tan satisfecho quedó con
la experiencia en Novofresh, si encontró todo lo que buscaba, si espera volver dentro de una semana, si
recomendaría la tienda a un amigo, etc. |
|
|
PREGUNTAS |
|
1) ¿Cuáles son los principales beneficios y las principales limitaciones del enfoque de investigación |
utilizado, en relación al problema que enfrenta Novofresh, y al objetivo de medir y gestionar la
experiencia de los clientes? Refiérase tanto a aspectos relacionados con la implementación de la . |
metodología (aplicación RevNext), como a su pertinencia en cuanto a los resultados y conclusiones que |
se podrían obtener. Sea preciso y conciso en su respuesta, |
2) En la última reunión de Directorio de Novofresh, el Gerente General presentó con mucho orgullo el
estudio que realizarían con RevNext. A pesar del entusiasmo con que varios directores acogieron la idea,
hubo uno que se mostró escéptico, planteando lo siguiente: “sinceramente no creo que tengamos que
reinventar la rueda; yo sugiero hacer un estudio de cliente incógnito, de la siguiente forma:
investigadores preparados se hacen pasar por clientes y reportan una serie de aspectos objetivos del
servicio entregado en la tienda, tales como la disponibilidad de productos, los precios de ciertos
productos, la cantidad de minutos que dura la cola, si estaba o no visible el material publicitario, si la
cajera sonrió o no al interactuar con el cliente, etc. Si logramos completar 300 informes de este tipo,
tendremos resultados muy contundentes sobre la experiencia de los clientes, que nos permitirían mejorar
la rotación de productos, compra promedio y rentabilidad de la tienda.” ¿Está usted de acuerdo con el
comentario de este director? ¿Por qué sí o por qué no? Justifique su respuesta. Suponga que el costo de la
propuesta planteada por este director es equivalente al costo del estudio RevNext.
-----
: 12
. PREGUNTA N' 6
En Chile las personas con contrato de trabajo formal deben cotizar (o imponer) mensualmente una fracción
de sus ingresos en una Administradora de Fondos de Pensiones (AFP), que son las entidades encargadas de
invertir los ahorros previsionales de la manera más eficiente posible, para que los cotizantes (o afiliados)
obtengan buenas pensiones cuando llegue el momento de jubilar.
Desde el año 2002, las AFP ofrecen cinco Fondos de Pensiones que los afiliados (o cotizantes) pueden elegir
para invertir sus ahorros previsionales, Estos Fondos difieren entre sí en el porcentaje de inversión que ellos
pueden destinar a instrumentos de renta variable e instrumentos de renta fija. Es así como el Fondo A (más
riesgoso) puede invertir, como máximo, hasta un 80% de los recursos captados en renta variable y el saldo
restante en renta fija, mientras que el Fondo E (más seguro) sólo puede invertir, como máximo, hasta un 5%
en renta variable, En la práctica, los Fondos de Pensiones se invierten en porcentajes cercanos al. tope
máximo en renta variable. :
"El Cuadro N* ] que se exhibe a continuación, muestra las principales características de los tipos de Fondos |
de Pensiones antes señalados:
Cuadro N? 1
|
“Tipo de Fondo % Máximo en | % Mínimo en | Retorno Volatilidad
p Renta Variable | — Renta Fija Anual % | Anual”
[a [ em [200 [om | mm
as |
|
(a): Rentabilidad real promedio anual desde septiembre de 2002 — mayo de 2013 — |
(b): Desviación estándar de los retornos reales entre septiembre-2002 ymayo 2013...
: En los últimos años se ha observado un creciente número de personas que cambian sus ahorros previsionales
desde un Fondo a otro con la expectativa de conseguir mayores rendimientos. Parte importante de éstos . |
cambios están motivados por recomendaciones que hacen asesores no regulados que entregan “alertas” de |
cambio de Fondos, esto es, una sugerencia de trasladar los ahorros desde un determinado Fondo de |
Pensiones a otro, con la promesa de mayores rendimientos. |
Una de las empresas asesoras más conocidas en el rubro es CSN, la cual opera a través de un sitio web y
cuenta con un volumen significativo de suscriptores, a quienes les ha prometido rendimientos muy atractivos
y una fórmula que evitaría pérdidas en tiempos de erisis económicas. Los suscriptores de CSN deben pagar
todos los meses un honorario por tener acceso a las recomendaciones de la empresa.
El Cuadro N* 2 que se exhibe a continuación, es un ejemplo de recomendaciones efectuadas por CSN en
distintas fechas, para que los cotizantes trasladen sus ahorros previsionales desde el Fondo A al Fondo E y
viceversa. Por ejemplo, en la recomendación n? 1, hecha con fecha 27-07-2011, CSN sugiere a sus clientes
cambiar su ahorro previsional desde el Fondo A al E; en la recomendación n? 2, de fecha 12-10-2011, la
sugerencia de CSN a sus clientes suscriptores es que muevan sus fondos previsionales desde el Fondo E al A
y así sucesivamente. La cuarta columna del Cuadro (Retorno CSN) muestra los rendimientos (retornos)
acumulados que hubiera obtenido un afiliado, entre la fecha de larecomendación y el 31 de mayo de 2013, si
hubiera seguido las sugerencias de cambio de Fondos hechas por CSN desde esa fecha en adelante. Estos
rendimientos acumulados se comparan con los obtenidos por el promedio de las AFP para el Fondo A y el
Fondo E en el mismo periodo (columnas $ y 6 respectivamente):
-----
, - 13
ps Cuadro N? 2
Rendimientos Acumulados desde la Fecha de Recomendación de Cambio de Fondos al 31/05/13
Es N' de a Fecha de la Recomendación de | Retorno | Retorno | Retorno
Recomendación | Recomendación Cambio de Fondos CSN - | Fondo A | Fondo E
: 27.972011 18,0% 129%
10-01-2012 122% | 13,0%
28-06-2012 10,1%
19-07-2012 1,7% |
02-01-2013 |
| 03-04-2013 |
De la lectura del Cuadro N* 2, se desprende que un cotizante que cambia sus ahorros previsionales desde el
Fondo A al E el 27-07-11 (fecha de la recomendación n* 1 de CSN en la que se sugiere dicho cambio),
acumularía un rendimiento del 18% entre esa fecha y el 31-05-13 si sigue las 10 recomendaciones restantes :
que CSN hace de allí en adelante. En ese mismo período, el rendimiento acumulado que tuvieron los Fondos
de Pensiones A y E que manejan las AFP fue de 7,2% y 12,9% respectivamente. Por otra parte, un afiliado |
que cambia sus ahorros previsionales desde el Fondo E al A el 12-10-11 (fecha de la recomendación n* 2 de
CSN en la que se sugiere dicho cambio), obtiene un rendimiento acumulado del 14,1% entre esa fecha y el |
31-05-13 si sigue las 9 recomendaciones restantes que CSN hace de allí en adelante. Para ese mismo
período, el rendimiento acumulado de los Fondos A y E fue de 17,3% y 9,2% respectivamente. Y así * |
sucesivamente. . |
.
Sobre la base de la información que aquí se le ha entregado, responda las siguientes preguntas: |
PREGUNTAS |
1) ¿Son coherentes los resultados que obtendría un afiliado, que siguiera las recomendaciones de CSN, con |
la hipótesis de mercados eficiente en su forma semi - fuerte? Fundamente su respuesta,
2) Los directivos de CSN han argumentado que la estrategia de inversión que ellos recomiendan no
necesariamente busca aumentar la rentabilidad para el cotizante sino que también acotar el nivel de riesgo de |
su inversión. Aunque el modelo que fundamenta las recomendaciones de CSN no es-público, hay evidencia |
de que se basa en el desempeño reciente que han tenido lós Fondos de Pensiones que administran las AFP. |
Dicho modelo permitiría a CSN recomendar a sus suscriptores estrategias de inversión para que trasladen sus |
ahorros previsionales, por ejemplo, desde el Fondo A (más riesgoso) al E (menos riesgoso), en períodos |
donde se anticipa que la economía no andará bien y viceversa. |
|
|
| 2a) Desde la perspectiva de un afiliado conservador, que normalmente pondría sus ahorros previsionales en |
el Fondo E, ¿será exitoso seguir una estrategia de inversión como la que sugiere CSN (ir cambiando los |
| ahorros desde el Fondo A al E o viceversa, según las circunstancias), para aumentar la rentabilidad esperada
| y disminuir el riesgo? Explique por qué fundamentando su respuesta.
| . . co
| 2b) Desde la perspectiva de un cotizante agresivo, que usualmente pondría sus ahorros previsionales en el
| Fondo A, ¿será exitoso seguir una estrategia de inversión como la que sugiere CSN (ir cambiando los
| ahorros desde el Fondo A al E o viceversa, según las circunstancias), para aumentar la rentabilidad esperada
] y disminuir el riesgo? Explique por qué entregando los argumentos necesarios.
.
-----


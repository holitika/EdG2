# Examen de grado · administracin-enero-2018-5

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


: l PONTIFICIA UNIVERSIDAD CATÓLICA DE CHILE
: ESCUELA DE ADMINISTRACIÓN
a
E RIOS
AD
¿iZ
Sa cuño
EXAMEN DE GRÁDO
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan. :
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
bojas adicionales, No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3.  Pararesponder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
f que los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
realidad de las empresas que allí se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente al Profesor Ignacio Rodríguez, Presidente de la Comisión
de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
$. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). Elf
cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
condiciones, el Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un (a) alumno (a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala, los que deberán estar apagados y no
| deberán mantenerse sobre el escritorio durante el examen,
12. Cada alumno (a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
como “borrador”, esas hojas no se deben entregar con las respuestas.
AAA
Fecha : 24 de enero de 2018
Duración : 9:00 horas a 12:00 horas h
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el Profesor
Ignacio Rodríguez, en forma individual, entre las 9:30 y 9:45 hrs, (aprox), y luego enire las 10:45 y
11:00 hrs. (aprox.).
-----
2
PREGUNTA N* 1
Homero Cisternas, gerente general de Envases del Atlántico (EDELTA), se encontraba preocupado por la entrada
de Envasin, un nuevo competidor en la industria de los envases. Envasin había lanzado al mercado una nueva línea
de envases que se caracterizaban por tener una menor calidad, pero a precios más bajos que los de EDELTA.
- Envasin, con sólo un equipo de tres vendedores, había logrado ventas por Í millón de USD (dólares
estadounidenses) durante el último trimestre del año anterior. Homero Cisternas pensaba que la empresa que él
dirigía debía tomar una decisión de crecimiento: mantenerse en la misma línea de siempre con la tecnología
avanzada y productos de alta calidad, o entrar en la categoría de productos más económicos.
EDELTA desarrolla envases flexibles combinando materiales, estructuras y diseños que permiten extender la
duración de los productos, proteger su calidad y presentarlos de manera atractiva al consumidor final. En la industria
de los envases, EDELTA es reconocida como líder en calidad e innovación tecnológica. Sus líneas de productos
incluyen envases para la industria de los alimentos (lácteos, mayonesas, ketchup, etc.) y otros de especialidad para
la industria de la limpieza (detergentes, lavavajillas, etc.). La participación de mercado de EDELTA alcanza el 80%
del mercado total de los envases. Hasta ahora EDELTA no tenía competidores en la industria de los alimentos. En
la industria de la limpieza EDELTA tiene dos competidores con una propuesta de valor similar a la suya.
En la siguiente tabla se indican las ventas y los márgenes brutos del portfolio de productos de EDELTA durante el
año 2017:
A Ventas (en MM de USD)| Margen Bruto
Industria Limpieza 25 20%
Homero Cistemas tenía dudas de si entrar o no en la categoría de envases económicos para la industria de los
alimentos y así competir directamente con Envasin, y recordó el discurso del Presidente del Directorio de la
empresa, justo el mes pasado: .
“Las ventas de EDELTA han crecido a un ritmo de 30% anual durante los últimos cinco años. Un resultado
sin precedentes. En los últimos diez años hemos innovado constantemente en el sector de los envases en la
industria de los alimentos. Estos éxitos son consecuencia de nuestro liderazgo tecnológico y nuestra
continua inversión en Investigación y Desarrollo. Nuestro futuro depende de continuar en esta línea y seguir
proporcionando a nuestros clientes envases más sólidos, seguros y eficaces. La misión de EDELTA se
focaliza en ofrecer a nuestros clientes la más alta calidad y los productos más innovadores del mercado.”
Para algunos clientes de EDELTA el proceso de compra de envases era muy relevante y de alto involucramiento,
por lo que analizaban las propiedades de cada uno de ellos con respecto a sus necesidades. Según sus datos, Cisternas
señalaba que alrededor del 30% de las ventas de envases de sus clientes, en la industria de los alimentos, las decidían
los ingenieros de empaque, los cuales eran bien conscientes de los beneficios que les aportaban los productos de
mayor calidad que suponía utilizar los envases de EDELTA. Cisternas sabía que para el resto de sus clientes era el
jefe de compra quien tomaba la decisión, el cual privilegiaba el precio dado ciertos estándares mínimos.
La fuerza de ventas de EDELTA era la más formada y especializada de la industria. Si bien esta fuerza de ventas
no vendía directamente, su rol era estimular la demanda que luego era satisfecha por los distribuidores de la empresa.
El equipo de ventas pasaba la mayoría de su tiempo con los clientes finales, intentando encontrar soluciones a
problemas complejos, analizando aplicaciones in sifu y preparando estudios para demostrar lo efectivo que eran los
productos de la empresa en materia técnica. De acuerdo a Cisternas, si la fuerza de ventas entendía bien los
problemas de sus clientes y lograba demostrarles las ventajas de los envases de mayor calidad que la empresa
producía, entonces serían capaces de hacerles una propuesta de valor más convincente.
-----
| 3
EDELTA vende todas sus líneas de envases a través de una red de distribuidores industriales no exclusiva. El año
: pasado, su red incluía a 60 distribuidores de los cuales 15 representaban más del 80% de las ventas de la compañía.
Los distribuidores solían tener en stock una amplia gama de productos y muchos de ellos hacían de punto de venta
único para todas las necesidades de envasado, Algunos distribuidores de EDELTA comercializaban también los
productos de Envasin ya que tenían una buena aceptación en el mercado, mientras otros que no lo hacían le habían
pedido a EDELTA que desarrollara una línea de productos más económica para poder competir.
En la siguiente tabla se muestran los actuales precios unitarios en USD tanto a los distribuidores como el sugerido
de reventa, a los clientes finales de ambas empresas, para la industria de alimentos:
| PRECIO UNITARIO POR ENVASE |
E
Precio aldistibuidor 2222220002152 2 8
Precio sugerido de reventa al cliente final 2,0 17
Con la llegada de Envasin y considerando que la industria de los envases para alimentos no presentaba barreras a la
entrada, Homero Cisternas se preguntaba cómo hacerlo en caso de ingresar al mercado con una línea de envases
más económica. Dado que la nueva línea de envases económicos tenía el mismo costo de producción unitario que
Envasin, su propuesta general de precios era mantener el precio a los distribuidores de sus envases premium y para
ei caso de la línea de envases económicos fijar un precio de venta al distribuidor que le permitiera a EDELTA
mantener el margen de contribución unitario. Además, le sugeriría a los distribuidores un precio de reventa del
envase económico al cliente final que les permitiera a ellos mantener el actual margen de contribución que tenían
con la línea premium de EDELTA.
PREGUNTAS
a) De acuerdo con la información entregada, ¿debiera EDELTA responder a la entrada de Envasin con una línea
de envases más económica y similar a la de esta? Justifique claramente su respuesta desde el punto de vista
comercial.
b) De acuerdo con la información proporcionada, ¿cómo puede impactar la decisión de precios propuesta por
Homero Cisternas a la generación de valor de EDELTA? Fundamente claramente su respuesta desde el punto
de vista comercial.
-----
4
PREGUNTA N” 2
Los tiempos navideños no traían la esperada calma a la empresa Casi Fuimos. Se reunía el Comité Ejecutivo de la
compañía, compuesto por todos sus gerentes, en la última reunión del año, a analizar la Tabla de Mando de la
Gestión de Personas de la empresa. Enrique Pozo, gerente de recursos humanos de la empresa señaló: "Como
recordarán, esta Tabla, cuyas métricas se presentan a continuación, señala la situación de los principales indicadores
de la gestión de recursos humanos y relaciones laborales del año 2017 que termina, y su comparación con el
promedio de las empresas del sector en donde compite Casi Fuimos.”
TABLA DE MANDO INTEGRAL 2017 DE CASI FUIMOS
Promedio
Variable Casi Fuimos] Empresas del
Sector
: Tasa de accidentabilidad: Número de
% de trabajadores de la empresa que
Claridad de funciones tienen claridad sobre cómo su trabajo 26,14 42,30%
impacta los resultados de su área y de la
empresa en su conjunto
% de trabajadores de la empresa que
Coordinación transversal participaron habitualmente en equipos de 9,7%] 65,0%]
trabajo transversales de innovación y
mejora continua
Número de sugerencias promedio al año
Empoderamiento por trabajador registradas e implementadas 0,4 7,0|
en el sistema de innovación de la empresa
% de gerentes y jefes de la empresa que
tienen un estilo de liderazgo exigente y que,
Calidad del liderazgo paralelamente, dan espacios de 31,6% 13,9%
participación a sus equipos y desarrollan el
personal que tienen a cargo
Fortaleza de las Número de sueldos adicionales (a los 12
compensaciones sueldos base) por concepto de 1,9 4,0]
variables productividad promedio por trabajador
a Diferencia entre el sueldo bruto promedio
Equidad interna de las o.
promedio de trabajadores sin gente a cargo
compensaciones trabajador
Una vez presentada la Tabla de Mando, tomó la palabra Alejandra Secco, gerente de relaciones laborales de Casi
Fuimos, a cargo del vínculo de la administración de la empresa con su sindicato, organización que agrupaba al 85%
de los trabajadores. Secco pidió a los asistentes que se concentraran en el Mapa de Relaciones Laborales que se
presenta en la siguiente página:
-----
5
. " MAPA DE LA RELACIÓN ENTRE EL SINDICATO Y LA ADMINISTRACIÓN DE CASI FUIMOS COMPARADA CON LAS
RELACIONES ENTRE SINDICATO Y ADMINISTRACIÓN DE OTRAS EMPRESAS DEL SECTOR 2017
Oaboración 8 .
0...'...2. |
| —e— Aa —
... 7 e“ —
esa... 10 L5 8 10 y o 40 45 50
—— wd e >
Onilidto A e
Conan tigéric) AFERRA ny AAA e tanencicas,
y de corto plazo sindicatos es...
Como se puede apreciar en el mapa, “las relaciones con nuestra organización sindical no son buenas” señaló Secco.
“Estamos en el cuadrante inferior izquierdo. Nuestra agenda de conversación y resolución de temas entre la
administración de la empresa y el sindicato se centra solo en materias de corto plazo como incremento de
remuneraciones, los aguinaldos de fiestas patrias y navidad, las becas de escolaridad para los hijos de los
trabajadores y el bono de término de negociación que se entregaba a los trabajadores sindicalizados de Casi Fuimos
al término de cada negociación colectiva cada 4 años. Con el sindicato no hablamos de temas como la necesidad de
mejorar la productividad de la empresa, nuestra calidad de servicio o los cambios tecnológicos que enfrentará tanto
: nuestra compañía como sus trabajadores en el mediano plazo. Por otra parte, nuestra relación es de conflicto, con
escasas instancias de diálogo con el sindicato, en busca de convergencia entre los intereses de los trabajadores y los
de la empresa.” Y remató diciendo: “Me esperaba algo así. Lo que tenemos que hacer, sin embargo, está claro.
Debemos tener una mayor cercanía con el sindicato, manteniendo con ellos reuniones periódicas que nos permitan
establecer una relación de confianza. De este modo nos moveremos al cuadrante superior derecho del mapa, que es
dónde queremos estar.”
A continuación, tomó la palabra Dédalo Jara, gerente general de Casi Fuimos. Comentó: “sabemos que el
compromiso de nuestro personal y por tanto nuestros resultados como empresa dependen fuertemente de cómo
motivamos a nuestros trabajadores, es decir la calidad del contrato sicológico o la llamada propuesta de valor hacia
nuestros trabajadores. Tenemos que ser capaces de dar respuesta a las motivaciones extrínsecas vinculadas
principalmente a las compensaciones de nuestra gente. También debemos ser capaces de satisfacer sus motivaciones
intrínsecas, asociadas a la calidad y potencial del trabajo que realizan. Por último, debemos generar una respuesta
que esté a la altura de las necesidades afectivas de nuestro personal, las que dicen relación con la calidad de vida al
interior de nuestra empresa y las relaciones entre nuestros jefes y sus equipos de trabajo. Y no lo estamos logrando.
Nuestro contrato sicológico con los trabajadores de Casi Fuimos está fallando. Tenemos que rediseñar
completamente la propuesta de valor que como empresa le entregamos a nuestros empleados.”
-----
6
, Finalmente, y ya al filo del término de la reunión del Comité Ejecutivo, habló Arturo Verbal, gerente comercial de
la empresa, quién planteó: “Yo estoy en el día a día con casi todo nuestro personal, especialmente nuestros
vendedores, y también con sus dirigentes sindicales. Creo que no estamos abordando los resultados de nuestra Tabla
de Mando de la Gestión de Personas de la empresa de manera sistémica, integrando todos sus elementos.
Concretamente, creo que el problema de relaciones laborales se resuelve haciendo una mejor gestión en las métricas
de dicha Tabla de Mando.”
En su calidad de asesor de la empresa, a Ud. se le solicita que responda a las siguientes preguntas en forma breve
y precisa:
PREGUNTAS
a. ¿Está de acuerdo con el diagnóstico y la solución planteada por Alejandra Secco, gerente de relaciones laborales
de Casi Fuimos? Justifique su respuesta.
bh. ¿Concuerda con el análisis y conclusiones de Dédalo Jara, gerente general Casi Fuimos, respecto a que debe
reestructurarse completamente el contrato sicológico que Casi Fuimos mantiene con los trabajadores de la
compañía? Fundamente de manera concisa.
e. ¿Está de acuerdo con las afirmaciones de Arturo Verbal, gerente comercial de Casi Fuimos, en cuanto a que el
mejoramiento de las relaciones laborales —desplazamiento hacia el cuadrante superior derecho del mapa-, está
fuertemente vinculado a la gestión de las variables de la Tabla de Mando de Gestión de Personas? Jl ustifique su
respuesta.
-----
7
PREGUNTA N” 3
Suponga que hoy, 1 de enero de 2018, los siguientes son los valores esperados para el año 2018 de parte de la
información financiera de dos empresas (“E-1” y “E-2”), que pertenecen a distintas industrias y que operan en
Chile:
Utilidad Resultado) Operacional
Rentabilidad delos Activos
Rotación de Activos = Ventas/Activos
Utilidad Neta
Margen Neto = Utilidad Neta Ventas
Razón de Endeudamiento = Deuda Total/Patrimonio
[Bera Daga o]
Supuestos e Información Complementaria:
+ Las empresas sólo tienen activos operacionales.
e Todas las partidas del Estado de Resultados de las dos empresas, son flujos de caja que se producen al término
del año.
» Toda la deuda de las empresas es deuda financiera, libre de riesgo, que genera intereses de manera explícita.
+ Latasa libre de riesgo en la economía es de un 3% anual y el premio por riesgo de mercado [E(Rm) — Re] es igual
a 5% anual.
» EL único resultado no operacional presente en el Estado de Resultados de las empresas, es el gasto financiero
(intereses de la deuda).
«e No hay inflación ni impuestos.
+ Todos los valores de activos, pasivos y patrimonio que se han usado para la obtención de los indicadores O
razones financieras de las empresas, en la tabla anterior, o que se puedan obtener a partir de la información
disponible, corresponden a valores económicos.
+ Se sabe que durante el año 2018, ambas empresas (“B-1” y “E-2”) realizarán transacciones que les permitirán
mantener, durante todo el año, y por lo tanto al 31/12/2018, tanto el monto total de sus activos, como la relación
(Deuda Total/Patrimonio), que ellas tenían al finalizar el año 2017 (o lo que es mismo, al comenzar el año 2018).
» En aquellas razones financieras en las que intervengan variables de flujo y variables de stock, use el valor de la
variable de stock al comienzo del año 2018, es decir, al 1/1/18.
* Suponga que ambas empresas (“B-1” y “E-2”), tenen la política de distribuir al término de cada año, un
dividendo equivalente al 100% de sus utilidades.
+ Se sabe que el mercado accionario es eficiente, esto es, toda la información relevante y conocida el 1 de enero
de 2018, respecto del futuro de la empresa, es información que está incorporada en el precio de mercado de la
acción a esta fecha.
+ En sus cómputos, use dos decimales
Sobre la base de la información que se le ha proporcionado, a Ud. se le pide responder las preguntas que se
le formulan a continuación:
-----
8
PREGUNTAS
Suponga que un inversionista sólo cuenta con la información de las empresas “E-1” y “E-2” que se entregó en
el enunciado anterior y que hoy (1 de enero de 2018) él debe tomar una decisión de si comprar o no una acción
de alguna de estas dos empresas, para venderlas exactamente dentro de un año (el 31/12/18). ¿Le recomendaría
Ud. al inversionista en cuestión la compra de una acción de alguna de estas dos empresas? En caso de responder
positivamente, ¿cuál de ellas le recomendaría adquirir? Usted debe fundamentar su respuesta tanto a través de
un argumento conceptual que respalde su recomendación, corno también a través de cálculos numéricos
orientados a mostrar si la compra el 1 de enero de 2018, crearía o no riqueza para el inversionista.
-----
9
PREGUNTA N” 4
Philips y su Estrategia en los Mercados Emergentes
Este es el título de una entrevista aparecida hace algunas semanas en el diario Wall Street Journal a Gerard
Kleisterlee, Presidente Ejecutivo de la compañía holandesa Philips. Al momento de jubilarse, lo que ocurrirá
el próximo año, Kleisterlee habrá dejado una empresa con un creciente enfoque en los mercados emergentes.
Por lo menos los números así lo demuestran.
Philips es una de las empresas más importantes del mundo que compite a escala global en tres líneas de
negocios: cuidado de la salud, con equipamiento de alto nivel para clínicas y centros médicos como ecógrafos
y scanners; iluminación, con ampolletas de diversos tipos, diseños y materiales; y consumo, con
electrodomésticos de la más amplia gama. Todos estos negocios de Philips, literalmente se han disparado en
los mercados emergentes, especialmente en China, India y América Latina, subiendo en más de un 29% las
ventas en el segundo trimestre del 2017 en comparación con el mismo período del año 2016.
Los mercados emergentes representan el 34% del total de las ventas de la compañía, y Philips se ha planteado
como objetivo elevar dicha participación a un 50% para el año 2020, La mayor concentración de la compañía
en China se explica por el atractivo plan de inversiones que tiene el gobierno central en ese país, por más de
US$125.000 millones, para construir miles de hospitales y clínicas durante los próximos tres años. Para
responder a lo anterior, Philips, al igual que sus principales competidores, está también ampliando sus equipos
de trabajo y sus divisiones de investigación en dicho país, además de fortalecer sus redes de distribución. Lo
anterior contrasta con la actitud que el propio Kleisterlee ha impulsado en otros países donde compite la
compañía, en los cuales ha reducido el número de empleados, ha disminuido el número de negocios y las
carteras de productos, disminuyendo de esta forma el volumen de operación.
Philips en los Mercados Emergentes
La carrera hacia los mercados emergentes empezó hace 10 años. La crisis y la desaceleración, en especial en
los mercados occidentales, enfatizaron aún más esta tendencia. Lo que se ha empezado a ver en muchos de los
mercados emergentes es que competidores locales se convierten en rivales regionales o incluso en aspirantes
a ser compañías globales, dado los volúmenes de negocio en los países emergentes.
En países como India y China, no basta con servir sólo en las zonas metropolitanas, por el alto nivel de
fragmentación demográfica 1 existente en esos mercados. Es indispensable tener una buena estructura de
distribución rural, por la gran cantidad de consumidores que habitan en lugares apartados de las grandes
ciudades. Ante ello, tanto Philips como otros competidores, han respondido a esta tendencia del mercado
desarrollando productos en los propios mercados emergentes y para los mercados emergentes, con una
distribución muy al detalle en almacenes y tiendas de barrio para ir a tono con la manera en cómo se distribuye
la población. Así, “no son productos europeos 0 estadounidenses los que se venden en China o India, sino
artículos diseñados y fabricados de manera local para el mercado local”, declaraba Kleisterlee en la entrevista
al diario norteamericano.
Haciendo Negocios en los Mercados Emergentes
En la misma entrevista antes citada, el Presidente Ejecutivo de Philips señalaba que en el caso de los mercados
emergentes la compañía fomenta más la toma de decisiones local, tendencia común en industrias emergentes,
la cual es asumida por varios de los actuales competidores, En general, decía el Presidente de Philips, “tratamos
de delegar responsabilidades hasta los puestos más bajos y descentralizar todo lo que sea posible. Pero en el
caso de los mercados emergentes, lo hemos hecho más que en los mercados desarrollados. Con nuestra fuerte
1 Mercado fragmentado geográficamente significa que los consumidores se encuentran altamente dispersos en el territorio
y ningún punto concentra a una cantidad significativa de potenciales consumidores.
-----
10
. presencia en mercados emergentes, es lógico que tengamos una gran presencia en la fuerza laboral asiática,
ya que también necesitamos tener más líderes locales”
El Mercado de Iluminación
Como se señaló anteriormente, Philips compite en tres ámbitos de negocio en los mercados en donde participa:
el cuidado de la salud, la iluminación, y un mercado de productos de consumo. El negocio de iluminación es
de gran importancia para la compañía por cuanto representa sobre el 55% de la venta consolidada de Philips
en el mundo, y explica más del 60% de la rentabilidad a nivel mundial.
En los mercados emergentes se le reconoce al mercado de iluminación, como un mercado de altísima
fragmentación demográfica, con canales muy de nivel retail, como almacenes y tiendas de barrio, y por tanto
pequeñas unidades comerciales muy dispersas a lo largo del país. Es un mercado que en los países del mundo
emergente ha mostrado importantes tasas de crecimiento, razón por la cual Philips lo mira con mucha atención
y altas expectativas para construir Una posición atractiva en él. :
PREGUNTAS:
a) Considerando solamente la información del caso basada en la entrevista dada por el Presidente Ejecutivo
de Philips al diario WSJ, ¿Qué le parece la estrategia seguida por Philips en los mercados emergentes?
Argumente su respuesta con precisión.
b) En relación al negocio de iluminación, y sólo considerando la información del caso, ¿En qué
circunstancias el negocio de iluminación de Philips en los mercados emergentes sería un negocio atractivo
para la compañía? Señale dos aspectos esenciales que permitan responder lo anterior entregando los
fundamentos correspondientes.
-----
1
PREGUNTA N*5
El retail ha sido, sin lugar a dudas, el sector de mayor dinamismo de la economía chilena en las últimas tres décadas.
No sólo se ha incrementado su volumen de ventas de manera muy importante, sino también ha mostrado evidencia
de una evolución rápida, que ha sabido adaptarse a los cambios del país y de los consumidores. En el sector retail
participan hipermercados de gran tamaño, supermercados, supermercados mayoristas que venden tanto a almacenes
como a consumidores finales, almacenes, ferias y otros canales tales como tiendas de conveniencia, farmacias y
comercio electrónico. Los supermercados son el canal de distribución más grande, con casi un 60% de las ventas de
productos de consumo masivo, Hoy en día el mercado nacional de supermercados es controlado principalmente por
dos operadores: Walmart y Cencosud, que concentran el 65% de la facturación total; le siguen el grupo SMU y
Falabella (Tottus).
De acuerdo a un reporte elaborado el 2017 por Kantar Worldpanel, en los últimos meses se ha observado una
disminución en la participación del canal hipermercados y un crecimiento de las ventas de supermercados de menor
tamaño. También, ha crecido la preferencia por ferias y supermercados mayoristas. Según el reporte mencionado, los
chilenos han mostrado un cambio en sus preferencias hacia la compra rápida, lo que está llevando a las principales
firmas del sector a potenciar los formatos de menor tamaño, los cuales facilitan justamente este tipo de compras. La
Tabla N%1 siguiente muestra, según Kantar Worldpanel, la participación en volumen de ventas del sector retail para
los distintos canales en los años 2013 y 2017. Estos datos revelan el crecimiento de formatos de supermercado de
menor tamaño, los supermercados mayoristas y las ferias. La contrapartida es la caída de los hipermercados:
Tabla N? 1: Evolución del Volumen de Ventas por Canal en el Sector Retail de Chile
La Figura N? 1 de la página siguiente muestra un mapa de posicionamiento de los distintos canales o tiendas de retail
donde los consumidores compran productos de consumo masivo. Esta figura se obtiene mediante un análisis de
factores aplicado a los datos de un estudio de mercado donde se preguntó a una muestra de consumidores por sus
percepciones respecto de cada uno de los canales en cada uno de 23 ítems o atributos. Los dos factores principales
capturan de manera conjunta el 75% de la varianza en los ítems originales. Los vectores con flechas en la figura
representan dimensiones o atributos, y los vectores sin flechas y con línea punteada representan las preferencias de
distintos segmentos de consumidores, en el modelo de vector ideal. No todos los segmentos son de igual tamaño.
PREGUNTAS
1. Uno de los ítems o atributos originales del estudio de mercado que se incluyó en el análisis de factores es el
atributo “Servicio al Cliente”. En los resultados del análisis de factores este atributo no aparece como significativo
porque no está correlacionado con ninguno de los dos factores seleccionados. ¿Significa esto que a los
consumidores no les importa el Servicio al Cliente? Explique su respuesta.
2. Los supermercados mayoristas no son el canal preferido por ningún segmento según el Mapa de Posicionamiento
en la Figura N* 1 y por lo tanto debieran tener participación de mercado igual a O. En la realidad, sin embargo,
esto no es así, y este canal ha aumentado su participación llegando actualmente a tener un 5% ¿Cómo se entiende
esta aparente contradicción? Fundamenie su respuesta.
3. La pérdida de participación de mercado de los hipermercados ha generado en estos la necesidad de defenderse
de los otros canales que han ganado participación en los últimos años. Suponga que la siguiente ecuación
representa el beneficio que los hipermercados quieren maximizar:
-----
12
B = (Precio — Costo) x Mercado Total x (PM) — Gasto Marketing (1)
Donde B representa el beneficio, Mercado Total corresponde a la venta total y PM es la participación de mercado en
volumen. Suponga que los hipermercados reaccionan a la pérdida de participación mediante una campaña
comunicacional que muestra: (i) el valor que tiene para el consumidor la variedad de productos para poder comprar
todo en un solo lugar y (ii) la importancia de la confianza en la tienda donde se compra.
Explique el cambio que más probablemente se producirá con la reacción de los hipermercados a la pérdida de
participación:
a) en el mapa de posicionamiento y
b) en la ecuación de beneficio (1).
Fundamente claramente sus respuestas.
Figura N* 1: Mapa de Posicionamiento Canales Productos Consumo Masivo
10-
Entreieniia Variedad Productos
Hipermercado
0.5- Fería h +
e E ?
Buena Relsción Precio/Calad A K, 7 q
= . ¿EZ Coofidlle
X A a ¿EL eS e
a La : e Je .?
a ON
Z 0.0 7 — — Buena Sañiatración
2 o 6 Almacen
8 Precios Bajos > Lita
LL
Supermercado Mayorista
.
D05- Supermercado
: 0.5 :
A0-
AD 08 0.0 05 10
Factor 1 (45%)
-----
13
PREGUNTA N* 6
En muchas transacciones privadas, donde se invierte en activos que son muy poco líquidos, como por ejemplo,
en acciones de empresas cerradas 1 (que suelen llamarse “private equity” en inglés), hay un inversionista
controlador que invita a accionistas minoritarios a participar en el negocio. Puede tratarse de negocios de
cualquier tipo y en distintos rubros, tales como la minería, supermercados, concesiones de carreteras, empresas
pesqueras, etc. En estos negocios, el objetivo normalmente es que, Juego de reorganizar las compañías y forjar
nuevas alianzas, las empresas cerradas sean abiertas a la bolsa, con la correspondiente expectativa de generar
ganancias para sus accionistas (controlador y minoritarios). Estos procesos suelen ser largos, con una duración
de entre 7 y 10 años, por lo que las inversiones en estas compañías cerradas típicamente sólo podrán liquidarse
en plazos largos.
El accionista controlador y los accionistas minoritarios que invierten en las acciones de estas empresas, que
son cerradas, establecen contratos o pactos que suelen ser bastante complejos. Típicamente, estos pactos
incluyen una o más de las siguientes cuatro cláusulas:
1) la posibilidad de que después de un tiempo, los minoritarios puedan vender al controlador su paquete
accionario minoritario a un precio pre - establecido;
1i) la cláusula “Tag Along”, que consiste en que si el inversionista (accionista) controlador logra vender
sus acciones a un tercero luego de un tiempo, el inversionista minoritario también pueda concurrir O
acoplarse a la venta en cuestión bajo las mismas condiciones que el controlador;
iii) la cláusula “Drag Along”, mediante la cual el controlador, en caso de recibir una oferta de un tercero
para adquirir la empresa, puede obligar a los minoritarios a participar en esta transacción haciendo que
ambas partes (controlador y minoritarios) vendan sus paquetes accionarios al tercero en las mismas
condiciones.
iv) la cláusula “Right of First Refasal”, que da al controlador la posibilidad prioritaria, de comprar al
minoritario, su participación accionaria, al mismo precio que le ofrecería un tercero (al minoritario)
por dicha participación;
Sobre la base de la información que se le ha proporcionado, a Ud. se le pide responder las preguntas que se le
formulan a continuación. En todos los casos, justifique claramente sus respuestas.
PREGUNTAS
a) Dado un nivel de riesgo (que podríamos medir según el Beta), ¿esperaría Ud. que las acciones de empresas
cerradas tuvieran un rendimiento mayor, menor o igual que las acciones de una empresa de similares
características pero que fuera abierta a la bolsa? Fundamente su respuesta.
b) Utilizando conceptos de finanzas, identifique las “opciones financieras” (put, call, etc.) que están implícitas
en cada una de las cuatro cláusulas que se mencionan en el enunciado, y que típicamente forman parte de
los pactos que se establecen entre el inversionista controlador y los minoritarios en los negocios descritos.
Para cada “opción financiera”, señale expresamente a cuál de las dos partes involucradas (controlador o
minoritario) beneficiaría dicha opción.
c) ¿Por qué cree Ud. que, en los negocios descritos en el enunciado (“private equity”), se incluyen las cláusulas
mencionadas en los contratos o pactos entre el inversionista controlador y los accionistas minoritarios? En
concreto, desde un punto de vista económico - financiero ¿qué se pretendería lograr con cada una de estas
cuatro cláusulas? Responda, argumentando separadamente para cada cláusula, en forma muy breve y
precisa.
1 Se trata de sociedades anónimas cuyas acciones no se transan en bolsa.
-----


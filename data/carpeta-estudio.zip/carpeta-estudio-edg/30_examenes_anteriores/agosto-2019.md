# Examen de grado · agosto-2019

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


+ PONTIFICIA UNIVERSIDAD CATÓLICA DE CHILE :
ESCUELA DE ADMINISTRACIÓN
JS 40 >
y O:
ES
ONES
LE COS
EXAMEN DE GRADO
INFORMACIÓN GENERAL E INSTRUCCIONES:
I, Este examen contiene seis preguntas. El alumno puede responder las seis preguntas, Para aprobar el examen, el
alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe tsar el reverso de las hojas, ni utilizar
hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta, Suponga
. . que los datos que ha recibido están correctamente calculados y que no han sido tergiversados,
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
realidad de las empresas que allí se mencionan.
5, Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
dichos supuestos, Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
--:6.... Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
misma ponderación al momento de ser evaluadas.
7. — Las preguntas de enunciado se podrán hacer solamente a la Profesora Marta Del Sante, Presidente de la Comisión
> de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, eto). El
cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9, Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
condiciones, la Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala ni relojes inteligentes, los que
deberán estar apagados y guardados en las mochilas adelante.
. 12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
examen. .
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
identificado con un-número. Si a Ud, se le han entregado hojas en blanco y sin numerar para que las pueda usar
como “borrador”, esas hojas no se deben entregar con las respuestas.
Fecha  : 2deagostode2019 .
. Duración : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá la Profesora
Marta Del Sante, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 y
11:00 hys. (aprox.).
-----
2
: PREGUNTA N*1
: ce La industria de la minería de cobre en Chile es de alto nivel
dai E ARE de inversión en bienes de capital, los cuales se usan en los
IAEA o SÉ distintos procesos extractivos. Aspectos claves de su
pS A E a modelo de negocios son el control de costos, la continuidad
CEE A de los procesos productivos, la seguridad y el eficiente uso
E e MK de activos. Una de las inversiones relevantes son los
tE camiones tolva (que transportan hasta 400 toneladas de
Ñ E mineral y roca desde la mina hasta las plantas de proceso),
PE AN ON los cuales tienen un costo de adquisición superior a los
! O USD$4 millones. Una mina de gran tamaño en Chile, ocupa
ES y Pa MN entre 60 y 100 camiones tolva en su operación diaria, La
EA CIR vida útil de un camión es de 15 afios en promedio.
En el contexto de la continuidad de procesos, una variable clave en la gestión de la flota de camiones tolva, es
garantizar su máxima disponibilidad operativa las 24 horas del día, los 365 días del año, de tal forma de no
interrumpir los traslados de mineral a la planta. Un ejemplo de reducción en la disponibilidad en los camiones
tolva, se refiere a los tiempos dedicados a mantención, en los que el camión debe parar. Dado que el tamaño
del motor del camión minero es de más de 16 cilindros, su consumo de aceite es significativo y requiere un
. proceso de cambio de aceite, en el que éste debe decantarse, luego aspirarse y finalmente rellenar con aceite
nuevo, para permitir el funcionamiento del camión. Cuando el aceite debe ser cambiado, el camión debe
llevarse al taller de la mina y hacer el “cambio de aceite”, faena que debe hacerse cada 500 horas de
funcionamiento y que, dado el alto consumo, demora aproximadamente 4 horas. Un proceso de duración
similar ocurre cuando deben cambiarse los neumáticos (de más de 3,5 metros de diámetro), cuyo valor de
compra es de USD$100.000 cada uno y su duración promedio de uso es de 15 meses,
En los últimos 20 años, el líder en ventas de camiones para la Minería ha sido Caterpillar, representado en
Chile por Finning, con un 52% de participación de mercado. Otros competidores son la japonesa Komatsu
(44%) y otras empresas (4%). Estas empresas venden sus camiones a las Mineras y luego prestan servicios de
mantención y reparación en la Mina bajo un contrato de pago fijo mensual. La tasa de disponibilidad técnica!
promedio de los camiones de estos proveedores, fue de 85% en el último año.
Suponga que un nuevo competidor, la alemana Liebherr, empresa relevante en el mercado mundial, quiere
entrar al mercado chileno. Hasta ahora no ha podido obtener contratos de venta de camiones a empresas
mineras, debido a que el precio de venta de sus camiones es superior al de la competencia. Según uno de sus
gerentes, el precio de mercado en Chile no es suficiente para sus expectativas de rentabilidad ni para cubrir
sus costos, los que se justifican debido a la mejor tecnología en los equipos. Por ejemplo, en el caso del
consumo de aceite, sus camiones usan un sistema de relleno permanente lo que evita tener que parar el camión
por varias horas, ya que simplemente rellena el depósito de aceite, con aceite nuevo, tal como se hace con el
combustible. Así, el tiempo de parada se reduce a media hora y coincide con el de llenado de combustible.
En una reunión de ejecutivos de Liebherr, se discutía la mejor forma de entrar el mercado chileno. Sigmund,
gerente comercial, planteaba que no quedaba más alternativa que bajar precios por debajo de la competencia,
junto con ofrecer una serie de servicios de mantención de los camiones en la mina, a costo cero en mano de
obra para los clientes. “Lo importante es entrar como proveedor de camiones y luego ir subiendo los precios
cuando los clientes, solos, se den cuenta de lo bueno que es Liebherr y de sus grandes beneficios”, enfatizaba
Sigmund,
Por otra parte, el gerente de Marketing, Wolfgang, planteaba que “había que pensar fuera de la caja, y que era
mejor que solamente arrendáramos nuestros camiones, incluyendo un innovador contrato que garantizada una
disponibilidad técnica del 95%, Liebherr se haría cargo de todos los costos de mantención y reparación,
incluyendo aquellos de los neumáticos, y de todos los repuestos e insumos. El cobro mensual sería por tonelada
1 Se entiende por disponibilidad técnica el número de horas sobre un total potencial, en que el camión está operativo para
el transporte de mineral.
-----
3
: métrica transportada. “Esto significa que el cliente siempre conoce su costo por tonelada mientras dure el
contrato. El no tiene que preocuparse por reclamos de garantía, disponibilidad de repuestos, ni aspectos
mecánicos; nosotros nos encargamos de todo. El cliente puede concentrarse en hacer minería,” dijo Wolfgang.
De acuerdo a la información entregada en el caso y asus conocimientos comerciales, se le pide responder lo
siguiente:
a) Señale y explique los tres argumentos principales en contra de la opción planteada por Sigmund, el
Gerente Comercial.
b) Señale y explique los tres argumentos principales a favor de la opción de Wolfgang, Gerente de
Marketing. :
-----
4
: PREGUNTA N2
En la reunión con su equipo ejecutivo, el gerente general de la agencia de publicidad Eclipse afirmaba:
"Acordamos la implementación de la nueva estrategia de negocios de nuestra compañía. Sin embargo, creo
que, para alcanzar nuestros nuevos objetivos, no estamos considerando posibles adaptaciones de nuestra
cultura y de nuestras prácticas de gestión de personal, Tenemos que implementar ciertos cambios.”
Por estos días, todas las agencias enfrentan un nuevo escenario de negocios. Los consumidores -principalmente
las nuevas generaciones-, se desplazan hacia el uso intensivo de las redes sociales, el consumo de información
en medios digitales por sobre los tradicionales (TV, prensa en papel y radio) y compras vía e-commerce, En
este contexto, las empresas quieren que las agencias de publicidad les ayuden a desarrollar sus estrategias de
crecimiento en redes sociales, medios de comunicación digitales y comercio electrónico, logrando lo que
finalmente les interesa: incrementar sus ventas.
Un experto comentaba: “Hoy, los mejores resultados no los obtienen las agencias de mayor tamaño, sino las
más capaces de abordar los cambios que experimenta la industria y transformarlos en oportunidades para
generar ingresos tangibles para sus clientes. La creatividad es clave, pero ahora las compañías quieren
monetizar rápidamente sus inversiones en los canales digitales. Y, por cierto, los clientes quieren que estas
: estrategias digitales estén integradas y sean coherentes con sus campañas en medios tradicionales”.
Eclipse es la principal agencia de publicidad medida en ventas. Cuenta con personal, que como mínimo tiene
15 años en la empresa, experto en campañas publicitarias en TV, prensa escrita y radio. Sus clientes les
solicitan apoyo creativo y asesoría en la planificación, diseño de campañas e inversión en la compra de
espacios, en los medios tradicionales. La fidelización de clientes pasa ahora por ser capaz de brindar soluciones
digitales con enfoques innovadores que permitan incrementar sus ingresos con estrategias basadas en las
nuevas plataformas de negocio virtuales (redes sociales y e-commerce) e integradas con los canales
tradicionales,
Eclipse tenía tres gerencias, cuyos equipos desarrollaban sus tareas con mucha autonomía, debido a la
experiencia y especialización alcanzada. Un gerente afirmaba: “Cada uno hace muy bien lo suyo: la Gerencia
Comercial busca a los clientes, la Gerencia Creativa diseña las estrategias de marca y campañas publicitarias,
mientras que la Gerencia de Tecnología diseña sitios webs muy interactivos para sus clientes”, Otro ejecutivo .
señalaba: “Coincido con mi colega. Nadie hace campañas publicitarias más atractivas que Eclipse. El escenario ,
de negocios ha cambiado, pero las competencias requeridas y la forma de prestar nuestros servicios siguen
siendo las mismas. No nos van a enseñar ahora cómo se hace publicidad y cómo se responde a nuestros clientes,
Basta solo observar los premios que históricamente hemos obtenido en el Festival de Cine Publicitario de
Cannes por la creatividad y calidad visual de nuestras campañas en TV, Ahí radica nuestra ventaja competitiva
y nuestro prestigio. Los sitios webs que diseñamos logran incrementar las visitas de los usuarios de las
compañías a las que prestamos nuestros servicios”.
Otro gerente indicaba: “Estos logros son consecuencia de la coordinación de las tres gerencias, coordinación
que realiza nuestro Gerente General, y de los incentivos diseñados para lograr nuestros resultados. La Gerencia
Comercial obtiene sus bonos de acuerdo a las cuentas (clientes) que logra capturar y mantener. La Gerencia
: de Tecnología recibe sus incentivos variables de acuerdo al grado de aceptación de los clientes en relación al
atractivo de los sitios web que les diseña. Por su parte, la Gerencia Creativa obtiene sus compensaciones
variables en base a los premios obtenidos y la satisfacción de los clientes.”
En la misma reunión, los ejecutivos de Eclipse concordaron que lo fundamental para lograr convertir sus
servicios a los clientes en ingresos tangibles, era el mejoramiento de los aspectos tecnológicos y digitales de
sus productos y procesos. Los nuevos competidores «tecnológicos desde su origen-, son disruptivos y generan
soluciones para sus clientes a gran velocidad y con alta capacidad de transformar sus campañas y servicios
digitales en mayores ingresos para sus clierites. Estos nuevos competidores cuentan mayoritariamente con
personal joven -nativos digitales-, quienes desarrollan una intensa interacción con sus clientes. Sus áreas
comerciales capturan las necesidades digitales de las compañías en materia de e-commerce. Las áreas de
tecnología, dedicadas al desarrollo de aplicaciones (apps) y otras soluciones para el comercio digital, se
coordinan con las áreas comerciales para traducir las necesidades de los clientes a soluciones digitales
-----
5
: apropiadas. Estas áreas tecnológicas también buscan la cooperación con las áreas creativas encargadas de
generar las estrategias y soluciones digitales que deben realizar sus clientes en redes sociales y e-commerce.
Finalmente, tanto las áreas de tecnología como las creativas vuelven a conectarse con las áreas comerciales
para que estas últimas hagan una buena entrega de las soluciones digitales diseñadas a sus clientes.
El Gerente General, quiere lograr pronto los nuevos objetivos de Eclipse: convertirse en una agencia líder en
desarrollo de estrategias y campañas en plataformas digitales y redes sociales para sus clientes -integradas con
sus canales tradicionales- logrando a su vez, un incremento en los ingresos de dichos clientes, Sin embargo,
salió preocupado de la reunión con su equipo ejecutivo, por lo que requiere de su opinión en varios puntos.
Por ello, y de acuerdo a la información entregada, el gerente general le pide a usted, que desarrolle de
manera concreta, las tres principales iniciativas en materia de gestión de personas que le permita a la
compañía alcanzar los nuevos objetivos estratégicos planteados. Indique de qué manera los cambios que
usted propone, permiten modificar determinados aspectos de la cultura de la empresa y con ello lograr
sus objetivos estratégicos.
Ñ
a - A
-----
6
: PREGUNTA N%3
Hoy 1 de enero del año 2020, usted dispone únicamente de la siguiente información financiera al 31 de
' diciembre de cada uno de los últimos dos años de la empresa importadora y comercializadora de juegos
novedosos para niños “La Novedad del Año S.A.”
BALANCES 31/12/2018 | 31/12/2019
ACTIVOS
Disponible (Caja, Depósitos Corto Plazo, ete.) 2.675 1.500
Cuentas por Cobrar a Clientes 2.200 4.000
1500] 2.000
Total Activo Circulante 6.375 7.500
Activos Fijos (Netos de Depreciación 15.661 15.250
TOTAL ACTIVOS 22.036 22,750
PASIVOS Y PATRIMONIO +]
Cuentas por Pagar a Proveedores (Corto Plazo)
Cuentas por Pagar a los Bancos (Corto Plazo 1.500 3.000
Cuentas por Pagar al Fisco (Corto Plazo) 1.028 2.287
Total Pasivo Circulante | —— 3.250] 6.250
Pasivo de Largo Plazo 3.036
Patrimonio Total 15.750 16.250
TOTAL PASIVOS + PATRIMONIO . 22.036 22.750
no | | |
ESTADO DE RESULTADOS (US$): Año 2018 Año 2019
10,000| 15.000
Menos: Costo de Ventas de Existencias Vendidas -4.000 -6.000'
Menos: Gastos de Administración y Ventas -2.000 -2,300
lo incluye Depreciación del Ejercicio PJ |
Menos: Depreciación del Ejercicio l -1.000 -1.200
Resultado Operacional [3.0001  s.s00|
Menos: Gastos Financieros (Intereses)
Igual: Resultado Afecto a Impuestos 2.800 5.165
Menos: Impuestos (10%)
Igual: Resultado del Ejercicio (Utilidad Neta 2.520 4.648|
Las preguntas se deben responder sobre la base de los siguientes supuestos:
+ No hay inflación y la tasa de impuestos a las utilidades de las empresas es de 10%
+ Todas las ventas se realizan otorgando crédito de corto plazo a los clientes y todas las compras de
existencias a los proveedores son con crédito de corto plazo que ellos le otorgan a la empresa.
e Todas las compras y las ventas de los productos que comercializa la empresa, se producen de manera
uniforme a través del tiempo y son de montos ($) similares, .
+ La empresa sólo tiene Activos Operacionales,
+ Si en el cálculo de una “razón financiera” (ratio o cuociente financiero), intervienen variables de
“fiujo” (estado de resultados) y de “stock” (variables del balance), para la variable de “stock” considere
el valor que dicha variable tenga al inicio del período (o valor final del período anterior). En sus
cálculos use dos decimales.
+ Suponga: 1 mes= 30 días; 1 año = 360 días
-----
: 7
El cuadro siguiente, presenta información de los saldos de algunas cuentas al 31/12/2017 (cifras en US$):
[Saldo de Activo Fijo (Neto de Depreciación); | 90%l
Suponga que los siguientes son los datos relevantes para cada uno de los indicadores o razones de rotación
de la empresa:
IO MIN TETONA TECA
[Rotación de Cuentas por Cobrar (veces)______]_ so | 68 |]
[Rotación de Cuentas por Pagar a Proveedores (veces) | _9 [9]
A usted se le pide que, desde una perspectiva financiera, analice la información financiera que se le ha
entregado de la empresa “La Novedad del Año” y usando únicamente dicha información, responda las
siguientes preguntas: : :
a) Indique cuáles son las “debilidades” financieras más importantes que ha tenido la empresa en el
último año (2019), en relación al año anterior (2018) y que se desprenden de la información entregada;
sea preciso en su respuesta. Como parte de su respuesta, usted debe presentar el cálculo de las razones
(ratios) financieros o-indicadores, que le permitan fundamentar dicha respuesta.
b) En el último tiempo, se ha notado un aumento en el interés de los inversionistas por comprar acciones
de la empresa. A usted se le pide que indique cuál es la “fortaleza” o “atractivo” financiero más
importante que desde el punto de vista de los inversionistas potenciales, ha tenido la empresa en el
último año (2019) en relación al año anterior (2018) y que se desprenden de la información entregada;
sea preciso en su respuesta. Como parte de su respuesta, usted debe presentar el cálculo de dos razones
(ratios) financieros o indicadores, que le permitan fundamentar dicha respuesta.
e) Si usted, como Ingeniero Comercial, fuese contratado como asesor de esta empresa, indique cuál sería
la recomendación, relacionada con un mejoramiento de la gestión financiera de la empresa, más
importante que usted le haría a esta empresa. Usted deber ser muy claro y específico al momento de
indicar cuál sería su recomendación. A modo de ejemplo: no es suficiente decir que se debe mejorar
una determinada razón o ratio financiero, además de ello, se debe plantear la forma en que a su juicio
se podría mejorar dicha razón o ratio financiero.
-----
. 8
: PREGUNTA N'4
“Falabella vende Viajes Falabella a Despegar”
El pasado lunes 15 de abril de 2019, Falabella anunció la venta de su negocio Viajes Falabella a Despegar.
Operación que incluye una alianza comercial por 10 años”.
Falabella realizó un cambio radical en su negocio de viajes al cerrar un acuerdo con Despegar, el mayor actor
online en este rubro en Latinoamérica. El acuerdo contempla la venta del 100% del negocio “Viajes Falabella”
en las operaciones de Chile, Colombia, Perú y Argentina, más la licencia por el uso de la marca “Viajes
Falabella”, todo en US$ 27 millones. La operación implicará la salida de Falabella de la operación turística
directa, pasando a ser parte de una alianza comercial por diez años con Despegar, por medio de la cual Falabella
profundizará su oferta de productos financieros asociados al negocio turístico, El acuerdo también contempla
la posibilidad de ampliar la asociación entre ambas empresas hacia otros mercados en donde operan ambas
firmas. :
Despegar (antiguamente Despegar.com), es una agencia de viajes que opera exclusivamente online con sede
en Argentina. Cuenta con presencia en 21 países y es la agencia de viajes. más grande de América Latina en
volumen de transacciones,
Falabella, por su parte, es uno de los más importantes holding empresariales latinoamericanos. Opera y
gestiona un portafolio de negocios amplio, compuesto por varias unidades de negocio, entre ellas Viajes
Falabella y Falabella Financiero, entre varios otros negocios (multitienda, centros comerciales, seguros,
supermercados, ctc). A Falabella Financiero pertenece CMR, la tarjeta de crédito y débito que constituye un
producto esencial de su negocio financiero, En el negocio de multitienda (tiendas por departamentos), Falabella
mantiene operaciones en Chile, Argentina, Perú, Colombia, entre otros países, llegando con sus negocios a
millones de personas, las cuales presentan altos niveles de lealtad con marca. La empresa posee un sólido
posicionamiento en los diferentes mercados en donde compite, lo que es producto de un amplio y activo
despliegue comercial en los diferentes mercados en donde participa. Así mismo, Falabella gestiona diversos
canales, entre ellos un creciente canal online para la venta de sus productos, el cual ha ido creciendo
sistemáticamente en los últimos años, siendo hoy en día un canal muy relevante dentro de la estrategia
comercial de la empresa.
Desde sus inicios, Viajes Falabella desarrolló el negocio de viajes operando principalmente desde las propias
tiendas de Falabella con una oferta orientada esencialmente a los clientes de la multitienda. En 2018, Viajes
Falabella registró ingresos por US$ 50 millones, de los cuales un 65% se debió a la venta de paquetes turísticos.
En el mismo período, Viajes Falabella obtuvo un EBITDA (utilidad antes de intereses, impuestos,
depreciaciones y amortizaciones) por aproximadamente US$ 3,5 millones.
Dado que la transacción tiene por delante las aprobaciones de las autoridades de libre competencia de los
países involucrados, las partes esperan contar con luz verde durante el segundo semestre de este año.
El Acuerdo
Las compañías acordaron mantener la marca “Viajes Falabella” que será comercializada a través de Despegar,
al igual que las plataformas digitales y redes de tiendas físicas, base desde la cual Despegar potenciará sus
productos y servicios en viajes y turismo. Por su parte, Falabella Financiero aportará con sus capacidades de
procesamiento de pagos, financiamiento y el programa de lealtad más reconocido de la región, mejorando la
oferta y la experiencia digital con su programa CMR puntos.
Como primera acción, se espera que se enfatice el uso de CMR como medio de pago. Por ejemplo, todas las
ventas que se realicen con CMR en Despegar tendrán acceso a doble acumulación de puntos. Además, los
puntos CMR se podrán canjear en el sitio de Viajes Falabella, en el sitio de Despegar, en los Call Centers y/o
en las sucursales de Viajes Falabella, todos canales que serán operados por el equipo de Despegar,
-----
. 9
" manteniéndose los puntos de venta dentro de las tiendas de la casa comercial. Adicionalmente, los clientes de
Falabella podrán acceder a promociones exclusivas desarrolladas por Despegar.
Un alto ejecutivo de Despegar señalaba en una reciente entrevista: “Estamos adquiriendo una empresa con un
trayectoria exitosa y atractivas oportunidades de crecimiento, completamente alineada con nuestra estrategia
de enfocarnos en paquetes, hoteles y otros productos de viajes. La alianza comercial nos permitirá fortalecer "
nuestra oferta de financiamiento para nuestros productos. Nos permite adquirir capacidades y es una
oportunidad para potenciar los equipos de ambas compañías en las actividades que mejor desarrollan; Viajes
Falabella es experto en la venta de paquetes turísticos, que es justamente donde Despegar busca seguir
creciendo y enriqueciendo la propuesta de valor a los clientes de toda la región”.
A su vez, por el lado de Falabella, otro alto ejecutivo de esta compañía explicó: “La alianza permitirá integrar
una mejor propuesta de valor a nuestro ecosistema digital, mejorando ampliamente la oferta de viajes y la
experiencia del programa CMR puntos, dando acceso a nuestros clientes al mejor contenido de productos
turísticos del mercado”. La compañía busca un modelo de atención omnicanal, esto es, incorpora los procesos
de atención digital a sus canales físicos y viceversa,
La Reacción del Mercado
Conocida la noticia de esta operación, las reacciones no sé hicieron esperar. Algunos analistas de la industria
celebraban efusivamente la transacción, mientras que otros se mostraban cautos y expectantes, La reacción
que no demoró fue la del mercado financiero, Las bolsas donde transan Falabella y Despegar mostraron al día
siguiente, comportamientos disímiles, pese a ser la misma operación. En efecto, las acciones de Falabella
subieron un tímido 0,2%, mientras que las de Despegar, la empresa compradora, lo hicieron con fuerza,
empinándose un 8% más que al cierre de la jornada anterior, cuando aún no se conocía la transacción.
Responda las siguientes preguntas en base al caso “Venta de Viajes Falabella a Despegar” y sólo utilizando la
información que se desprende del caso
a) ¿Cómo cambia el modelo de negocios de Viajes Falabella comparando la situación inicial antes de la
venta a Despegar, versus la situación post venta a Despegar? Señale y explique al menos tres cambios
a nivel del modelo de negocio de Viajes Falabella.
b) Utilizando sus conocimientos de estrategia, ¿cómo se pueden interpretar las disímiles reacciones del
mercado en relación a uno y otro caso, para una misma transacción? Se pide que su interpretación no
sea sólo conceptual, sino también específica y concreta aplicada a la situación del caso.
-----
10
: PREGUNTA N'5 .
En las últimas décadas, Chile ha experimentado una caída drástica en la tasa de fertilidad total (número
promedio de hijos de una mujer durante su vida fértil). Si en 1960, esta tasa fue de 5,5, para 1980 ya había
caído a 2,6 y el último Censo, arrojó 1,3 hijos por mujer. La cifra más baja de la historia. En este contexto, el
mercado de pañales para niños se ha visto fuertemente afectado, experimentando contracción tanto en volumen
(unidades) como en ventas valoradas ($), a tasas de 7% anual aproximadamente, en los últimos 5 años.
El mercado de pañales para niños en Chile está liderado por tres marcas, que en conjunto capturan hoy, cerca
del 85% de la participación en ventas. Sin embargo, la participación de mercado de hace un año de las 3 marcas
mencionadas, superaba el 95%. La caída de más de diez puntos de estas marcas tradicionales se debe
fundamentalmente a la proliferación de nuevas marcas propias del retail, que han ganado participación
rápidamente y contribuyen a la contracción del mercado tradicional debido a la emigración de consumidores
desde marcas de-mayor precio hacia las de menor precio.
Los fabricantes de las marcas principales han intentado defenderse de la declinación del tamaño del mercado,
profundizando promociones de precios y bajas permanentes de precios. Adicionalmente, una de las acciones
que redujo en parte la declinación de la categoría, fue el lanzamiento hace un par de años de nuevos productos -
de mayor valor agregado, como los pañales formato Pants (tipo calzón), que tienen beneficios de practicidad
ala hora de poner y sacar, además de mejor ajuste al cuerpo del bebé, El segmento Pants en Chile es incipiente.
La gráfica N*1 muestra la penetración del producto Pants en Chile desde su lanzamiento a mediados de 2017.
La gráfica N*, por su parte, muestra el precio promedio de Pants relativo al precio efectivo de los pañales
clásicos, en el mismo período de tiempo.
Gráfica N'1 Gráfica N?2
Penetración % de Producto Pants Precio Relativo Producto Pants Relativo!
Según Meses Desde Lanzamiento a Precio Pañal Clásico
A A
AN SN AA Bra A NA
SAA O ii, A e
FP O A ecos a E
25707 : amor 200.07 : ¿01801 : 20104 arar 201001 or amo a.
Mes
A usted se le pide responder:
a) ¿De qué manera afecta a la velocidad de crecimiento de las ventas del producto Pants, la caída en la
tasa de fertilidad? Argumente usando un modelo analítico.
b) ¿De qué manera afecta a la velocidad de crecimiento de las ventas, los cambios de precios
implementados en el producto Pants por los líderes del mercado? Argumente usando un modelo
analítico,
Continúa en la página siguiente
1 El precio relativo corresponde al precio de Pants dividido por el precio del pañal clásico
-----
11
c) Suponga que existen sólo dos marcas para el producto Pants. Una marca clásica de proveedor y una
marca propia del retail, Se dispone de datos de elección de marca a partir de los cuales se estima un
modelo de regresión logística, que entrega la siguiente función de utilidad para un consumidor
promedio.
: U=0,556 x (Marca) — 1,5 (Precio) + Residuo
Donde (Marca) es una variable dummy que toma el valor 1 si es marca proveedor y valor 0 si es marca
propia del retail. El (Precio) se expresa en pesos. :
¿Cuáles debieran ser las participaciones de mercado de la marca del Proveedor y de la marca Propia
. si los precios de ambas marcas son iguales? Explique,
-----
12
: PREGUNTA N'6
El grupo empresarial representado por la sociedad de inversiones CHINVEST S.A. está considerando comprar
la compañía de seguros de vida de rentas vitalicias For Ever Young S.A. (FEYSA). Las rentas vitalicias son
equivalentes a un bono emitido y garantizado por una compañía de seguros (FEYSA, en este caso), que es
comprado por una persona a que se va a pensionar, con los ahorros acumulados en una AFP (Administradora
de Fondos de Pensiones) durante su vida laboral, Las rentas vitalicias entregan al pensionado pagos mensuales
iguales de por vida.
FEYSA tiene en la actualidad activos financieros cuyo valor de mercado es de $1.000. Dichos activos tienen
menor liquidez que otros activos financieros, pero son poco riesgosos y tienen una rentabilidad esperada anual
y perpetua de 2,8%, El valor de mercado de los pasivos por rentas vitalicias de FEYSA (que es el único pasivo
de la empresa) es de $900 y estos devengan un interés anual del 2,5% anual. Para simplificar, suponga que los
pagos de las rentas vitalicias cesan al fallecer el pensionado, pero el pensionado fallecido es reemplazado por
uno más joven, en las mismas condiciones financieras, manteniéndose los flujos de pasivos de FEYSA
constantes en el tiempo de manera indefinida.
Suponga que el mercado de capitales es perfecto, esto es, que no hay impuestos ni costos de transacción y que
la información es gratis y está ampliamente disponible para todos los inversionistas. Suponga también que el
único costo de operación de FEYSA es el pago de los pasivos por rentas vitalicias. Responda las preguntas
que se le formulan a continuación:
a) A partir de los flujos de caja residuales disponibles para los accionistas, determine el máximo valor
que CHINVEST estaría dispuesto a pagar por el 100% del patrimonio de FEYSA. Fundamente su
respuesta mostrando todos los cálculos necesarios.
b) La consultora externa KERCER cree que FEYSA no está aprovechando todo su potencial
endeudamiento, ya que las compañías de seguros dedicadas al rubro de las rentas vitalicias pueden
tener, sin problemas, un leverage (razón deuda / patrimonio medida con valores de mercado) de hasta
20 veces. KERCER estima que con la situación actual, el costo de capital del patrimonio de FEYSA
es de 5,5% anual y que, dado ese costo de capital, el valor económico del patrimonio (hoy) de la
compañía puede aumentar dependiendo del nivel de endeudamiento (no aprovechado) que se utilice,
Por ejemplo, si la compañía aumentara el leverage desde 9 a 15 veces, sólo requeriría un patrimonio
. de $60 en vez de $100, lo que liberaría $40 para los accionistas, dejando los pasivos en $900 y los
activos en $960. Este flujo anticipado de $40 que recibirían hoy (ent= 0) los accionistas, más el valor
presente de los flujos residuales que ellos recibirían desde t = 1 en adelante, de manera perpetua,
permitiría incrementar el valor económico del patrimonio a $119,6. La Tabla N* 1 que se muestra a
continuación, ilustra los resultados que se obtendrían al incrementar la razón (deuda / patrimonio):
Tabla N* 1: Valor Económico del Patrimonio de FEYSA (cifras en pesos), para una rentabilidad :
esperada de los activos de 2,8% anual.
Leverage Valor Económico del
(Deuda / Patrimonio) Patrimonio
9 100.0
15 119.6
20 127.0
¿Está Ud. de acuerdo en que el valor económico del patrimonio de FEYSA aumenta con el nivel de
leverage? Fundamente su respuesta conceptual y numéricamente. -
. Continúa en la página siguiente
-----
. 13
e) Un conocido analista de inversiones sostiene que el valor económico del patrimonio de FEYSA
también podría incrementarse, sin cambiar el actual nivel de leverage (9 veces) que tiene la compañía,
si ésta invirtiera en activos que tuvieran una mayor rentabilidad esperada, tal como se muestra a
continuación en la Tabla N? 2:
- Tabla N* 2: Valor Económico del Patrimonio de FEYSA (cifras en pesos)
Rentabilidad Anual Valor Económico del
Esperada de los Activos Patrimonio
. 2.80% 100.0
3.00% 136.4
. 3.20% 172.7
Suponiendo que se cumple la hipótesis de mercados eficientes ¿está Ud. de acuerdo en que al invertir
en activos (instrumentos financieros) con mayor rentabilidad esperada, aurnentará el valor económico
del patrimonio de FEYSA? Fundamente su respuesta.
-----


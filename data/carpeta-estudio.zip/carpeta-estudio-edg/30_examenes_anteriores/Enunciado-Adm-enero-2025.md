# Examen de grado · Enunciado-Adm-enero-2025

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


ee o
CARO ESCUELA DE ADMINISTRACIÓN
SR FACULTAD DE ECONOMÍA Y ADMINISTRACIÓN
AS
EXAMEN DE GRADO
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. — Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
que los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
realidad de las empresas que allí se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
misma ponderación al momento de ser evaluadas. Z
7. Las preguntas de enunciado se podrán hacer solamente a la Profesora Marta Del Sante, Presidente de la Comisión
de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta,
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
condiciones, la Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala ni relojes inteligentes, los que
deberán estar apagados y guardados en las mochilas adelante.
12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han .
identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
como “borrador”, esas hojas no se deben entregar con las respuestas.
—ooooOoOE sz
Fecha : 27 de enero de 2025 :
Duración : 9:30 horasa 12:30 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá la Profesora
Marta Del Sante, en forma individual, entre las 10:00 y 10:15 hrs. (aprox.), y luego entre las 11:00
11:15 hrs. (aprox.).
-----
2
. PREGUNTA N'1
La empresa de arriendo de vehículos “El Auto Prestado” (“EAP”) es una empresa que durante los últimos 50
años se ha dedicado al arriendo de autos. Hoy, que es 1 de enero de 2025 (1/ 1/25) “EAP” ha observado que el
negocio de arriendo de autos en los últimos años ha experimentado una fuerte caída, pero al mismo tiempo ha
constatado el sistemático y casi exponencial aumento en la demanda por las compras “on line”, a través de las
innumerables plataformas hoy disponibles para adquirir bienes, principalmente en el rubro de alimentos y
bebidas, incluyendo el despacho al domicilio de los clientes. Esta realidad, ha llevado a la empresa a evaluar
la posibilidad de destinar los autos que no se estén arrendando, para ofrecer el servicio de envío o traslado de
pedidos a domicilio. La empresa sabe que se trata de un negocio completamente distinto al que ha gestionado
por años, pero la disminución de la demanda en su negocio actual la ha llevado a evaluarlo.
El nuevo negocio de envíos a domicilio de distintos tipos de pedidos le significaría a “EAP” tener que realizar
hoy 1/1/25 (t= 0) una inversión inicial total de M$90.000 (M$ = Miles de $) en nuevos activos. Por otra parte,
“EAP” ha estimado que esta inversión estaría en condiciones de generar un flujo de caja anual (total de entradas
menos total de salidas de caja anuales generadas por el proyecto) a perpetuidad de M$38.000 anuales. Se :
espera que el primer flujo anual que genere el proyecto se reciba dentro de exactamente un año, es decir el
31/12/25 (t= 1).
En este momento, 1/1/25, el total del Patrimonio de “EAP” se encuentra distribuido entre muchos accionistas
que son dueños(as) de los 20 millones de acciones comunes de la empresa, cada una de las cuales se está
transando hoy en el mercado a $20. El beta de este Patrimonio se ha estimado en 1,0. Adicionalmente, una
parte de los activos de “EAP” se financia con deuda financiera, la que en este momento tiene un valor de
mercado de M$100.000; el beta de esta deuda financiera se ha estimado en 0,25. “EAP” no tiene ningún otro
tipo de deudas. Se sabe que del total de activos que “EAP” mantiene en este momento, M$90.000 son
inversiones en activos libres de riesgo, de fácil liquidación (depósitos a plazo, valores negociables, etc.), para
uso en su gestión operacional y para destinar a eventuales proyectos de inversión.
Para evaluar el nuevo proyecto, un analista financiero ha estimado adecuado usar el modelo C.A.P.M. (Capital
Asset Pricing Model) o M.V.A.C. (Modelo de Valoración de Activos de Capital) para estimar la tasa de
descuento que debe usar para dicha evaluación y ha recurrido a la información disponible a partir de la cual
espera obtener una estimación de dicha tasa de descuento. Lo que el analista sabe es que hay una empresa, la
empresa “SERVIMOS” cuyo negocio principal es precisamente el de ofrecer el servicio de envío de pedidos
a domicilio. La información que el analista conoce de la empresa “SERVIMOS” es que hoy ella tiene un
Patrimonio a valor de mercado de M$400.000 y que no tiene deudas. También sabe que la mejor estimación
del beta del Patrimonio de “SERVIMOS” es de 1,2. Por último, el analista ha averiguado que “SERVIMOS”
mantiene entre sus activos una inversión en activos no operacionales, esto es una inversión no necesaria para
el desarrollo de su actual negocio de ofrecer el servicio de envío de pedidos a domicilio. Esta inversión en
activos no operacionales corresponde a un depósito a plazo por un valor total de M$100.000 y que se considera
como una inversión libre de riesgo.
Suponga que:
+ El mercado de capitales es perfecto
+ No hay inflación
+ La tasa libre de riesgo (Ry) es igual a 8%
+ El premio por riesgo de mercado (Ry - Rg) es de un 7,5%
+ Todos los flujos, con la sola excepción de la inversión inicial, se producen al término de cada año.
-----
3
: Se Pide:
Responda cada una de las siguientes preguntas, presentando el desarrollo de sus respuestas de manera ordenada
y fundamentando la respuesta de manera precisa. Cada respuesta, cuando lo requiera, debe estar acompañada
de todos y cada uno de los cómputos que la sustentan. Trabaje los valores monetarios en M$ (Miles de $).
1. Obtenga el VAN o VPN del proyecto que está pensando desarrollar la empresa “EAP” (ofrecer el servicio
de envío de pedidos a domicilio), suponiendo que en caso de llegar a ejecutarse el proyecto se financiaría
enteramente con nuevo capital.
Para las preguntas 2 y 3 que se plantean a continuación, suponga ahora que la empresa ha decidido hacer
pública su intención de llevar a cabo el nuevo proyecto de inversión, entregando al mercado todos los
antecedentes necesarios y relevantes para su evaluación.
2. Suponga, en primer lugar, que para financiar el nuevo proyecto la empresa “EAP” utilizaría M$45.000 de
sus actuales inversiones en activos libres de riesgo y de fácil liquidación, y que los M$45.000 restantes los
obtendría a través de un aumento de capital a través de la emisión de nuevas acciones comunes. Los actuales
accionistas de la empresa “EAP” han informado su decisión de no participar del aumento de capital
¿Cuántas acciones debiera emitir “EAP” para obtener el saldo de M$45.000 que ella requiere para
completar el financiamiento del nuevo proyecto, adicionales a los M$45.000 con los que la empresa ya
cuenta? Fundamente su respuesta mostrando los cálculos necesarios.
3. Suponga ahora que, para el financiamiento del nuevo proyecto de inversión la empresa “EAP” decidiera
utilizar M$45.000 de sus inversiones en activos libres de riesgo y de fácil liquidación y que los M$45.000
restantes los obtuviese a través de la emisión de nueva deuda financiera. La nueva deuda sería emitida en
condiciones de mercado, a un plazo perpetuo (es decir, “EAP” sólo tendría que pagar los intereses de la
nueva deuda al final de cada año, pero el principal o monto original de la deuda, “nunca” se paga o si Ud.
lo prefiere se renueva anualmente todos los años, durante los próximos “infinitos” años). Suponga, además
que la nueva deuda tiene el mismo riesgo que la deuda actual de “EAP” (beta igual a 0,25). “EAP” ha
estimado que la emisión de esta nueva deuda no haría cambiar el riesgo de su deuda actual u original de
M$100.000 (su deuda al 1/1/25 antes del nuevo proyecto) lo que significaría que el beta de dicha deuda
actual se mantendría en 0,25.
¿Cuál sería el VAN o VPN que tendría el nuevo proyecto de inversión de la empresa “EAP” (servicio de
envío de pedidos a domicilio) y el Costo de Capital Promedio Ponderado (C.C.P.P.) o tasa de descuento
que se debiera usar para la evaluación de dicho nuevo proyecto de inversión, bajo esta nueva forma de
financiamiento? Fundamente su respuesta.
-----
4
: PREGUNTA N2
Desde hace 6 años, Lucrecia Guita lidera la Gerencia de Planificación y Control de Gestión (GPyCG), en
Banco Morlacci, uno de los actores más grandes en el sector bancario del país, el cual otorga servicios
financieros a personas, enfocándose en la entrega de préstamos, instrumentos de inversión y ahorro, cuentas
corrientes y tarjetas de crédito y débito. Morlacci aspira a ser el principal banco de personas en Chile y desde
hace un año busca crecer rápidamente en sus colocaciones intentando diferenciarse por su capacidad de
respuesta al cliente, el más ágil en sus transacciones, el mejor percibido en cuanto al desarrollo de tecnología
y por un trabajo en equipo transversal para atender las necesidades integrales de sus clientes. Banco Morlacci
lanzó un plan de transformación organizacional con el objetivo que todas las áreas de la institución operaran
bajo estos principios y los hicieran parte de su cultura de trabajo y de sus actividades diarias.
En palabras del gerente general del banco, Gustavo Dolareke, “la diferenciación en estos atributos nos
permitirá lograr una rentabilidad superior a las de nuestros competidores. Además, señalaba el gerente,
“lograremos distinguirnos frente a nuestra competencia no solo si entregamos un buen servicio a nuestros
clientes finales, ágil y tecnológicamente amigable. Necesitamos además aplicar estos mismos a las relaciones
y servicio interno entre las áreas del banco que conforman nuestra cadena de valor. La percepción de nuestros
clientes respecto a nuestro banco solo será el reflejo de nuestra gestión al interior de banco Morlacci.”
La GPyCdG que lidera Guita atiende a 12 gerencias funcionales del banco a las que denomina stakeholders o
clientes internos (comercial, finanzas, operaciones, productos bancarios, marketing, medios de pago,
experiencia de clientes, mesa de dinero, business intelligence, gestión de personas, tecnología y fiscalía). A
partir de la información que cada gerencia del banco les proporciona, PyCDdG elabora y luego envía los
presupuestos finales aprobados por la Gerencia General, así como los informes mensuales y anuales de
cumplimiento de dichos presupuestos. También PyCdG se encarga de entregar los análisis de las desviaciones
de más de 10 indicadores de gestión por cada gerencia en diversos ámbitos (productividad, ahorro de costos,
calidad de servicio interna, gestión de procesos de cada área, clima laboral en cada uno de los equipos y nivel
de capacidades del personal que cada uno de sus stakeholders debe cumplir). Finalmente, PyCdG elabora
propuestas de mejora para cada una de las brechas detectadas tanto en el cumplimiento del presupuesto como
en los indicadores de gestión del negocio que cada una de las gerencias funcionales de Banco Morlacci tienen
asignados. Como señalaba Guita en una reunión con el equipo de su Gerencia, “en Banco Morlacci cada
gerencia cree que es la más importante y por ello exigen que les demos prioridad en la atención. Esta enorme
carga y complejidad de trabajo, superior a la que se observaba en áreas similares en bancos de la competencia,
solo era posible de alcanzar con equipos enfocados en objetivos comunes y compartidos, alta motivación,
coordinación y trabajo colaborativo.”
Debido al gran número y diversidad de “stakeholders” con los que se relaciona y a los cerca de 120 indicadores
que debe auditar, revisar y generar las correspondientes recomendaciones de mejora mensualmente, PyCdG
cuenta desde hace años con un sistema FIFO (First In — First Out) para priorizar los requerimientos que llegan
desde los stakeholders a la Gerencia, de modo que la gerencia presta el servicio “por orden de llegada.”
Desde su entrada al Banco, Raúl y todo su equipo en la GPyCdG reciben una compensación que consta de una
parte fija y otra variable. Ambos componentes de la compensación se pagan, en promedio, en la media de
mercado. La compensación variable conocida como Bono por Resultados está sujeta a una evaluación anual y
considera tres elementos: (1) un ítem asociado al logro del Ebitda del banco (10% del bono), (2) la tasa de
crecimiento de las colocaciones del banco (10% del bono) y (3) un conjunto de KPIs individuales asociados a
la calidad de servicio de cada empleado de la GPyC4G en relación con la gerencia que les correspondía atender
(80% del bono).
-----
- 5
: Los KPls y la evaluación anual de metas individual (80% del bono) estaban estructurados según el siguiente
esquema:
ARA a
enviados a las gerencias errores errores errores errores errores
de brechas tanto en el cumplimiento del presupuesto 36% menos de 5 entre 6 y 10 entre 11 vis entre 16 25 más de 26
como en los indicadores de gestión del negocio recomendaciones | recomendaciones | recomendaciones | recomendaciones | recomendaciones
7
La definición de estos indicadores las realiza la jefatura directa de cada persona dentro de la GPyCdG. A su
vez, la evaluación del cumplimiento de estos KPls está a cargo del empleado que hace de contraparte en la
gerencia a la que el personal de la GPyCdG presta el servicio. En otras palabras, su cliente directo es su
evaluador. Guita estaba muy conforme con su sistema de evaluación del desempeño y con el Bono por
Resultados. .
Preguntas:
1. Por tratarse de un área estratégica, el directorio del banco está revisando el sistema de evaluación del
desempeño de la Gerencia de PyCdG. Para ello citó al gerente general Enrique Dolareque y al Gerente
del área en cuestión, Lucrecia Guita. Ésta última comentó: “nuestro esquema de KPIs cuenta con los
más altos estándares SMART!. Si bien no todos los años todos obtienen el mínimo aceptable en la
porción individual de su bono, cada uno tiene muy claro qué indicador no cumplió y cómo corregir su
desempeño en el siguiente período.” Inmediatamente el gerente general respondió: “Puede ser que tu
personal de la Gerencia de PyCdG esté cómoda con el esquema de evaluación de desempeño, pero yo
pienso que no agrega suficiente valor a nuestro negocio.” Desde el punto de vista de la gestión
estratégica de personas ¿Son correctos los argumentos entregados por cada uno de los ejecutivos?
Justifique su respuesta.
2. La discusión no terminó ahí y Dolareque volvió a la carga. Con convicción afirmó: “También veo
problemas en el Bono por Desempeño de la GPyCdG. No genera la motivación en las personas del
área. De hecho, los datos muestran un aumento en la rotación del personal de dicha gerencia, y no veo
cómo contribuye al éxito del banco.” Ofúscada, la gerente de la GPyCdAG retrucó: “puede que estemos
perdiendo algunas personas, incluso algunas personas clave, pero eso no significa que el sistema de
compensación variable no funcione. La gran mayoría de mi equipo está satisfecho con su Bono de
Resultados.”
Nuevamente el directorio le pide que desde la perspectiva de la gestión estratégica de personas indique
si son correctos los argumentos entregados por cada uno de los ejecutivos. Justifique su respuesta.
1 SMART es un acrónimo para medir ciertas características de los KPls: específicos/ specific, mesurable/ medibles, alcanzables/
achievable, realistas/ realistic y de duración limitada/ time-bound.
-----
6
: PREGUNTA N%3
Macy's y su nueva Estrategia para reposicionarse en el sector de Multitiendas
No corren buenos tiempos para Macy's. La tradicional mutitienda de Estados Unidos, acaba de informar el
cierre de 150 tiendas adicionales a las cerradas hasta ahora en el país del norte, y el despido de cerca de 2.350
empleados (3,5% de su plantilla). Pese a los esfuerzos hechos por la compañía, los resultados de la estrategia
implementada por su nuevo CEO no han dado los resultados esperados. Macy's cerró el primer semestre de
2024 con resultados económicos inferiores al mismo período del año anterior en cuanto a facturación y un
ebitda en similar nivel. En los últimos 9 años el valor de su acción ha caído un 75%. Hoy cuenta con 722
tiendas en todo Estados Unidos, habiendo cerrado casi 300 en los últimos seis años.
Maoy's, al igual que otras multitiendas, señaló que estos resultados se deben principalmente a que su mercado
objetivo, el consumidor estadounidense de clase media, privilegió el gasto en alimentación, productos básicos
y servicios frente a la incertidumbre económica en Estados Unidos, lo que se ha venido prolongando desde
después de la pandemia. Con el objeto de avanzar en diferenciación, la compañía ha ido incorporando
productos de marca propia, líneas de productos de lujo y promociones agresivas. Lo cierto es que ello sólo
ha ayudado a intensificar el nivel de competencia en la industria.
El sector de multitiendas en Estados Unidos
Una multitienda es una gran tienda minorista que incluye varias tiendas en su interior, cada una orientada a
diferentes productos, mercados, y/o clientes (vestuario, electrónica, jóvenes, hogar, etc.). Vende al cliente
final, y su gestión se realiza de forma centralizada. Son tiendas que suelen tener un tamaño superior a los
1.500 metros cuadrados, de manera de entregar comodidad al cliente y al mismo tiempo mostrar diferentes
experiencias que complementen a los conceptos de tiendas que incorporan en su interior. Las multitiendas
Operan, ya sea en el interior de centros comerciales (malls) o están directamente ubicadas hacia la calle en
avenidas de alto tráfico.
En los últimos años, el sector de tiendas minoristas en Estados Unidos se ha destacado por el auge de tiendas
como Amazon, la creciente fuerza de cadenas de descuentos como TJ Maxx y las marcas online.
Históricamente, la competencia ha sido intensa entre las diversas cadenas tradicionales, especialmente
Macy's, Nordstrom y JCPenney. Estas últimas tres son cadenas orientadas a consumidores entre 45 y 60
años, de clase media, y de hábitos más bien tradicionales. Son consumidores que buscan la presencialidad
para realizar sus compras y el vivir la experiencia al adquirir los productos que requieren. Si bien no son un
segmento que se sienta atraído por el comercio online, algunos de estos consumidores han comenzado a
emigrar hacia el comercio electrónico reconociendo las bondades y comodidad que ello significa.
Según datos de Credit Suisse, actualmente hay unos 1.100 centro comerciales (malls) en EE.UU., y el 25%
de ellos estaría en riesgo de cerrar en los próximos cinco años. En el sector de multitiendas, ya se han cerrado
alrededor de 5.300 tiendas, incluyendo el cierre de varios puntos de venta de gigantes minoristas como Sears,
Macy”s, JCPenney, RadioShack y Kmart.
Las multitiendas requieren una inversión importante de recursos para alcanzar volúmenes que permitan
viabilizar económicamente su negocio. Las altas inversiones se explican por infraestructura, recursos
tecnológicos, y redes logísticas robustas. Además, requieren de inversiones en marketing y posicionamiento
de la marca. Debido a sus altos costos operativos, requieren lograr economías de escala y establecer una red
de proveedores. Por ello resulta fundamental lograr tamaño y volumen para ser competitivos en esta industria.
De esta forma, si las ventas no crecen, se deteriora la posición competitiva de estas cadenas al no alcanzar
volúmenes mínimos eficientes de operación.
Cambios en las preferencias de los consumidores
Son varios los cambios que se están dando en el sector de multiendas en Estados Unidos. Quizás uno de los
factores más relevantes que explica la evolución de esta industria se encuentra en el desarrollo del comercio
electrónico, que ha traído la incorporación al sector de nuevos consumidores que valoran un fácil acceso a
una gran variedad de opciones, una compra más fácil y cómoda, disponer de información de precios y
comparaciones en línea, todos atributos que les brinda el comercio online, y que les da mayor poder en la
-----
7
toma de decisiones. Estos nuevos consumidores son distintos a los tradicionales que históricamente han
comprado en multitiendas, ya que poseen hábitos de compra distintos, son más exigentes y sensibles al precio,
buscan ofertas y descuentos manteniendo el nivel de servicio, lo que obliga a las empresas a ser competitivas
en términos de facilidad, flexibilidad, precios y promociones. Así mismo, existe un flujo de consumidores
tradicionales que están emigrando hacia la compra online por las comodidades que provee. Diversos analistas
de la industria concuerdan de que son transformaciones que llegaron para quedarse. Hay tres tendencias en
el sector que son claras:
- Aumento de las compras online: generado principalmente por la irrupción de Amazon, lo que
provocó que todas las empresas mejorarán sus procesos de logística y personalización. Comprar
online se há convertido en una experiencia social y es cada vez más masivo. Ha atraído a segmentos
de clientes que hasta ahora no participaban de las compras en multitiendas, como es el caso de los
jóvenes.
- Búsqueda de mejor experiencia en tienda y al interior de centros comerciales: los centros
comerciales y sus tiendas, en especial los competidores más tradicionales, han reaccionado buscando
mejorar la experiencia de los clientes en la misma tienda y en el centro comercial, incluyendo
espacios de entretenimiento como cines, cafeterías, espectáculos y juegos para niños. Cada vez son
malls más pequeños orientados a segmentos específicos, y están pasando de ser lugares de compra a
ser un mix de esparcimiento, entretención y compras.
- La tienda sigue siendo la opción más conveniente para tipos de productos específicos como
productos del hogar y de alto involucramiento: la tienda se utiliza muchas veces como showroom
para posteriormente comprar presencial u online. Una situación similar viven otras categorías cuya
compra requiere alto involucramiento por parte del cliente.
La estrategia de Macy?s para impulsar su futuro
El nuevo CEO de Macy”s, Tony Spring, siendo fiel a lo que ha sido hasta ahora la empresa y el tipo de cliente
al cual se orienta, anunció un nuevo plan estratégico, el cual se enfoca en lo que ha sido esencial hasta ahora
de la empresa: presencialidad, foco en clientes tradicionales, manteniendo su negocio online sin desarrollos
adicionales, considerando a los clientes tradicionales a los cuales se orienta. Las principales directrices de la
nueva estrategia son las siguientes:
- Expansión hacia afuera de los centros comerciales, apartándose del formato de grandes tiendas, y
emigrando a formatos más pequeños.
- Una mayor orientación al desarrollo de outlet.
- Incrementar la apuesta por el lujo incorporando nuevas marcas dentro de esta categoría en tiendas
seleccionadas de la cadena dado el nivel aspiraciones del segmento tradicional que frecuenta la
tienda.
- Mejorar la imagen de la tienda, y robustecer la logística con importantes inversiones.
- Modernización de la infraestructura de sus tiendas, mejorando la experiencia al interior de ella.
En complemento a lo anterior, Macy”s planea abrir 10 nuevas tiendas de su marca outlet, Macy”s Backstage,
para beneficiar a los productos fuera de temporada, en centros comerciales más pequeños y cercanos, en
condiciones de precios muy favorables.
Preguntas:
1. Considere como industria al sector de multitiendas de Estados Unidos. ¿Cómo afectan a los
competidores tradicionalmente establecidos tipo Macy's, desde la perspectiva de la generación y
captura de valor, y desde la óptica del riesgo del negocio, los cambios que están ocurriendo en la
estructura competitiva de este sector?
2. ¿Qué aspectos positivos y negativos tiene la nueva estrategia de Macy's impulsada por su nuevo CEO?
Al considerar el conjunto de su análisis, ¿diría Ud. que la nueva estrategia de Macys's es buena o no?
¿Por qué?
-----
8
PREGUNTA N'4
TRICORP presenta su nueva imagen corporativa
Tricorp es una empresa dedicada a la prestación de servicios financieros y seguros, orientada a brindar
soluciones de protección financiera a individuos y empresas. Su objetivo principal es gestionar riesgos y
ofrecer coberturas que incluyan seguros de vida, salud, vehículos, propiedades y otros bienes. Reconocido
por su enfoque en la innovación y la adaptabilidad, esta empresa busca garantizar la tranquilidad y estabilidad
económica de sus clientes, promoviendo confianza y sostenibilidad a través de productos y servicios
personalizados. Tricorp se ha caracterizado por ser la empresa más eficiente en el mercado, gracias a una
preocupación constante por mantener los costos operacionales bajos.
En 2022, la entidad que construye el Índice Nacional de Satisfacción del Consumidor reportó un aumento
del 11% en los reclamos presentados por los consumidores contra empresas relacionadas con el mercado
financiero respecto al primer semestre del año anterior, alcanzando un total de 48.103 quejas. Las principales
causas fueron cobros indebidos, incumplimiento de las condiciones contractuales y cobranzas extrajudiciales
abusivas. Con el objetivo de evaluar a las empresas bajo los mismos parámetros, la entidad elaboró un ranking
que mide el comportamiento de las empresas en términos de respuesta a reclamos. En este análisis, Tricorp
obtuvo la peor evaluación del sector.
Para abordar estas deficiencias, Tricorp realizó cerca de 20 estudios de investigación de mercado con el
objetivo de analizar y mejorar su propuesta de valor. Estos estudios incluyeron una evaluación detallada de
los principales “viajes del cliente” (customer journeys), identificando problemáticas y puntos sensibles en la
experiencia del usuario. Además, la empresa implementó un sistema de revisión semanal y mensual de los
reclamos ingresados en todas sus líneas de negocio. Un hallazgo destacable fue que el 62% de las quejas+
provenían de interacciones realizadas a través de canales digitales.
En 2023, Tricorp lanzó una nueva imagen corporativa como parte de una nueva visión estratégica. Con logo
remozado y bajo el lema “Resolvemos todas las necesidades financieras de nuestros clientes, entregándoles
la mejor experiencia personal”, se abarca a todas sus líneas de negocio: Seguros, Banco, Inversiones,
Previsión y Salud. La estrategia comercial de Tricorp combina equipos de venta, una red de 27 sucursales a
nivel nacional, un Contact Center, una Sucursal Virtual y una App Corporativa.
El Gerente Corporativo de Marketing y Clientes destacó: “La nueva imagen de marca de Tricorp representa
una evolución significativa que rescata todos los elementos de confianza y solidez que ha tenido la marca
durante sus más de 100 años de trayectoria. Este cambio de logo refuerza la relevancia de la marca y le da
una mirada más contemporánea, cercana para abordar el desafío de acompañar a nuestros clientes en cada
etapa de sus vidas”.
La nueva identidad corporativa ya se encuentra implementada en los principales puntos de contacto con los
clientes, como el frontis del edificio corporativo, las sucursales, las comunicaciones corporativas, folletos, el
sitio web y la aplicación móvil.
Según datos internos, el índice de Experiencia del Cliente en sucursales mostró una mejora significativa,
pasando de 14,9% en 2023 a 30,9% en 2024. Este avance fue atribuido a una mejora en el servicio a los
clientes, la cual se focalizó en la empatía y el conocimiento de los clientes, respaldada por herramientas
tecnológicas avanzadas como sistemas de inteligencia artificial para la gestión de correos electrónicos,
control de tiempos de respuesta y resolución de requerimientos y enriquecimiento de la base de clientes.
Estas iniciativas contribuyeron a resultados positivos en productos clave como Vida Individual, Seguro
Automotriz, Seguro de Hogar, Créditos de Consumo, y Fondos Mutuos, fortaleciendo el posicionamiento de
Tricorp en diversas líneas de negocio con respecto a su competencia.
A través de sus 27 sucursales a nivel nacional, Tricorp atiende a sus clientes bancarios y de las Compañías
de Seguros, con 181 ejecutivos comerciales y 38 de servicio de posventa para Banco y Seguros. En 2024 esta
red presentó un incremento de visitas de 25% en comparación con 2023.
-----
9
Para el 2025, el 75% del total del presupuesto de marketing anual será destinado a campañas publicitarias
tradicionales, como televisión y radio, y a la mejora de las sucursales físicas, un 10% será asignado al
desarrollo y optimización de los canales digitales, incluyendo la app y el sitio web, y el resto, para invertir
en un chatbot automatizado de atención a clientes, lo que permitirá sustituir a más de la mitad ejecutivos de
postventa y lograr mayor eficiencia.
Preguntas:
1. Uno de los Directores de Tricorp, planteaba que el cambio de imagen corporativa debía hacerse en el
contexto de una estrategia de centralidad en el cliente, de lo contrario, sería un desperdicio de recursos.
El Gerente General le replicaba que eso era precisamente lo que había iniciado Tricorp el 2023 y que
hasta hoy se ejecutaba. Considerando la información entregada, ¿quién tiene la razón, El Director o el
Gerente General? Argumente su respuesta.
2. En una reunión interna, el Gerente de Ventas y Sucursales expondrá posibles riesgos asociados con la
implementación de la nueva imagen corporativa. Anticipe y evalúe al menos dos riesgos específicos
que podrían surgir en 2025 y proponga una acción de mitigación para cada uno de ellos.
-----
10
PREGUNTA N'5
ABC es un Fondo Mutuo que invierte de manera diversificada en acciones de empresas chilenas. En el último
Comité de Inversiones de ABC se estudió la posibilidad de incorporar, al portafolio del Fondo, algunos
activos financieros donde el Fondo no había invertido.
Lo que se muestra a continuación, es el análisis efectuado por el Comité de Inversiones del Fondo Mutuo
respecto de las potenciales inversiones. Ud. debe contestar las preguntas que se le formulan a continuación,
entregando los fundamentos en los cuales sustenta sus respuestas.
1. Uno de los sectores en los cuales el Fondo Mutuo de ABC no había invertido era el sector pesquero
industrial, que consiste en la extracción, mediante el uso de barcos con tecnología avanzada, de
recursos pelágicos como la anchoveta y la sardina, que posteriormente son transformados en harina de
pescado. El Gerente Comercial de ABC opinaba que, a pesar de lo atractivo que resultaban los retornos
esperados de las acciones de empresas pesqueras industriales no era conveniente invertir en ellas,
porque sus resultados están expuestos a demasiados riesgos que son incontrolables, por ejemplo,
cambios climáticos (corriente del niño, de la niña, marejadas), vedas (por virus, marea roja o peligro
de extinción de la especie), alzas en el precio del combustible (insumo para los barcos), huelgas, etc.
¿Está Ud. de acuerdo con los fundamentos entregados por el Gerente Comercial de ABC para no
invertir en acciones de las empresas pesqueras industriales? Explique por qué.
2. ABC está analizando la posibilidad de que el Fondo Mutuo invierta en acciones de alguna de las
siguientes dos compañías vinculadas al sector transporte: Rodantes S.A. y Barcarola S.A. Las acciones
de Rodantes S.A. tienen un retorno anual esperado de 10% y una volatilidad (medida como desviación
estándar de los retornos) de 30%. Por su parte, las acciones de Barcarola S.A. tienen una rentabilidad
anual esperada y riesgo (desviación estándar) de 15% y 40% respectivamente. Suponga que se
cumpliera el modelo CAPM. La tasa libre de riesgo es de un 4% y la prima por riesgo de mercado
(Rm — Rf) es igual a 6%. La acción de Rodantes S.A. tiene un beta igual a 0,9 y la acción de Barcarola
S.A. tiene un beta igual 2,0. Sobre la base únicamente de la información que se le ha proporcionado,
¿le recomendaría Ud. al Fondo Mutuo ABC invertir en alguna de estas dos acciones del sector
transporte? Fundamente su respuesta.
3. Como una manera de enriquecer los retornos del Fondo Mutuo, la administración de ABC decidió
invertir en opciones sobre acciones de algunas empresas chilenas que formaban parte de la cartera del
Fondo Mutuo. Desgraciadamente, los precios de los activos subyacentes de estas opciones subieron
de manera considerable, y el Fondo Mutuo no pudo ejercer dichas opciones. ¿Cuál era la apuesta tras
la estrategia con opciones que estaba haciendo ABC? ¿Qué posición (corta o larga) y qué tipo de
opción (put o call) mantenía el Fondo Mutuo ABC?
-----
11
PREGUNTA N'6
Lanzamiento de nuevo producto enriquecido con proteínas
Una empresa chilena de alimentos, que compite en la categoría Helados, desea evaluar la introducción de un
nuevo helado enriquecido con proteínas en la categoría de helados vendidos en supermercados. Actualmente,
í A 0] UT en Chile no existe ningún producto con dicho atributo en
: . Ro -— O MU esta categoría de helados. Los alimentos con proteínas
A... agregadas son una tendencia mundial, y Chile no es la
mu. MI A excepción. Lácteos en general (leche, yogurt), granola e
D a : dl E incluso pan, son los productos que destacan en el mercado
A a E. E a nacional: “Se le puede agregar proteína a cualquier
=— Pi o o o] Lo producto”, señalan los especialistas. El helado
a dl ig] Convencional contiene entre 2 y 4 gr de proteína por
MM la e da laa EN porción. Los helados enriquecidos con proteínas pueden
OM h= O] tener hasta 6-12 gr/porción.
+= hd
Actualmente, la empresa cuenta con datos transaccionales históricos de la categoría de helados en Chile, que
incluyen información, para los últimos dos años, sobre precios semanales, volúmenes vendidos de sus marcas,
si hubo o no promociones de precio en cada semana y, sabores de helados vendidos en distintos canales de
venta. El equipo gerencial tenía que presentar al Directorio las predicciones de venta para el nuevo producto y
tenía dudas de cómo justificar el lanzamiento de la nueva línea de helados enriquecidos con proteínas.
A continuación, se muestran dos propuestas que usted debe analizar:
Propuesta 1: Una de las analistas del área comercial proponía construir un modelo predictivo de ventas para la
nueva línea. Dados los datos transaccionales, disponibles en la base de datos de la empresa, proponía usarlos
en un modelo predictivo para estimar las ventas de la nueva línea de helados.
1. Haga un análisis crítico de dicha propuesta metodológica para tener una buena estimación de ventas
del nuevo producto.
Propuesta 2: Ante la insistencia del gerente de investigación de mercado, la empresa realizó un análisis
conjunto para identificar cómo los consumidores valoran diferentes atributos de un producto. Para este estudio,
se evaluaron cuatro atributos clave para la introducción del nuevo helado:-
+ Sabor: Manjar, Vainilla de Madagascar y Pistacho de Turquía.
» Proteína: proteína Regular y Enriquecido con proteína.
+ Precio: $12.000, $10.000 y $8.000.
+ Marca: Marca A (la que introduce el producto nuevo), Marca Competidor B, Marca Competidor C.
Se recolectaron datos de preferencias de dos segmentos de consumidores: El Segmento 1 (70%) corresponde
al público general de la categoría de helados, mientras que el Segmento 2 (30%) corresponde a clientes de la
marca A, la que está introduciendo el producto.
-----
: 2
Los part-worths (o utilidades parciales) obtenido(a)s fueron lo(a)s siguientes:
s , Part Worth | Part Worth
A o 1) (Segmento 2;
E
pe]
[re ar | ax |
5 A
iria os | 2
E
fa
IA
| pre a
fre] js]
3
El nivel base de cada atributo (Manjar, Proteína regular, $12.000, Marca A) tiene un part-worth de 0. El resto
de coeficientes (part-worths) son todos estadísticamente significativos al 5% (p-value<0.05).
Recibidos los resultados del estudio, el equipo comercial seguía teniendo dudas sobre el mejor plan comercial
para la nueva línea. El gerente de investigación de mercado proponía lanzar el nuevo helado bajo la marca A,
con foco en el segmento 1 y con un precio premium respecto del resto de la categoría.
2. Haga un análisis crítico de dicha propuesta de plan comercial para la nueva línea de helados,
considerando los resultados obtenidos en el análisis conjunto y las métricas de disposición a pagar e
importancia relativa de los atributos evaluados, para cada uno de los segmentos. Justifique
cuantitativamente sus argumentos.
-----


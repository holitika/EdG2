# Examen de grado · administracin-agosto-2018

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


2.
“ PONTIFICIA UNIVERSIDAD CATÓLICA DE CHILE
ESCUELA DE ADMINISTRACIÓN
l [SEDA
o
. ÉL 8
. AS
EXAMEN DE GRADO
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
alumno deberá obtener una calificación de "Pase" en al menos ires de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos hojas
que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar hojas
adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3.  Pararesponder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga que!
los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
realidad de las empresas que allí se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados dichos
supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la misma]
ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente al Profesor Ignacio Rodríguez, Presidente de la Comisión de
- — Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
$8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
cumplimiento de esta norma es de absoluta responsabilidad del alumno.
” 9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas condiciones,
el Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un (a) alumno (a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala, los que deberán estar apagados y no
: deberán mantenerse sobre el escritorio durante el examen,
12. Cada alumno (a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
examen, .
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
identificado con un número. Sí a Ud, se le han entregado hojas en blanco y sin numerar para que las pueda usar como
“borrador”, esas hojas no se deben entregar con las respuestas.
Fecha : 3 de agosto de 2018
Duración : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el Profesor Ignacio
Rodríguez, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 y 11:00 hrs.
gprox.).
-----
2
Ñ PREGUNTA N' 1
El sistema Autocar representa un nuevo modelo de negocio en la industria automotriz y un cambio notable del
proceso de distribución automotriz tradicional. Áutocar.com se ubica entre el concesionario (distribuidor) de la
marca tradicional de automóviles y el consumidor final del vehículo, proveyendo una serie de servicios. Cuando
un cliente visitaba el sitio web Autocar.com, accedía a una gran cantidad de información objetiva en un solo lugar
y podía pre-comprar vehículos, teniendo pre-acordado el precio vía Autocar.com. Es decir, no necesitaba
“negociar” el precio con el vendedor del concesionario.
- Los compradores que iniciaban el proceso de búsqueda de un auto en Autocar.comn, lo podían hacer por marca y
modelo mediante distintos filtros. También accedían a información acerca de las especificaciones del modelo
base y su precio acordado con el concesionario. Una vez que los compradores comenzaban a reducir sus
alternativas, podían acceder a una variedad de información automotriz (artículos, testimonios, videos, etc.) acerca
de sus autos preferidos. Cuando los clientes finalmente se habían decidido por una marca y un modelo, Autocar
les permitía “construir” su auto desde lo más básico a lo más elaborado. Autocar automáticamente incluía las
características estándar del vehículo y los clientes podían agregar paquetes de opcionales y observar cómo
cambiaban los precios ya “negociados” del concesionario, Una vez que el vehículo estaba “construido”, los
consumidores podían enviar una pre-solicitud de compra, gratis y libre de obligaciones (no tenían ninguna
obligación de comprar) para el vehículo de su elección. Los prospectos de compra (potenciales clientes) eran
derivados a un concesionario de la marca elegida y asociado a Autocar (el cual había recibido derechos exclusivos
de una marca para un territorio geográfico determinado), y el concesionario contactaba al potencial cliente para
que fuera a probar el auto. El concesionario que operaba con Autocar estaba obligado a respetar el precio acordado
con Autocar para el consumidor, el cual era entre un 4-5 % menor que el precio de lista. Esto se comparaba con
el 6% de descuento que un comprador buen negociador, podía lograr en una negociación presencial,
En la industria automotriz los autos nuevos se venden tradicionalmente a través de transacciones negociadas en
forma personal entre el comprador y el vendedor del concesionario de la marca. Para muchos consumidores, este
proceso les produce angustia e inseguridad. La compra de un auto es considerada la segunda compra más grande
que la mayoría de los consumidores hace en su vida (después de la compra de una casa). Por este motivo, la
compra de un auto tiende a ser un proceso tanto racional como emocional. .
Por lo general, cuando los consumidores entran en un concesionario para comprar un auto nuevo, tienen
relativamente poca información con respecto a las variables de calidad de los distintos modelos y marcas, precios,
opcionales, y otro tipo de información relevante. Sin embargo, como saben que el precio del auto es negociable,
se ven enfrentados a la ardua tarea de regatear con el vendedor para obtener un precio percibido como favorable,
Después de Jlegar a un acuerdo en el precio, el cliente por lo general tiene que encontrarse con varios otros
ejecutivos antes de poder retirar el auto del concesionario. Si el cliente tiene un vehículo usado para dar en parte
de pago por el vehículo nuevo, se llama a un encargado de autos usados para que inspeccione ese vehículo usado
y negocie su precio. Si el cliente busca financiamiento (cerca del 75% de las transacciones automotrices
involucraban algún tipo de financiamiento y seguro), un ejecutivo distinto maneja esta parte de la transacción. Y
si el cliente busca repuestos y accesorios adicionales, es dirigido a un vendedor de servicio post venta,
En general, los concesionarios automotrices derivan sus ingresos de tres fuentes principales: la venta de vehículos
nuevos y usados, servicios técnicos, repuestos y financiamiento. El siguiente cuadro muestra las ventas y las
utilidades de un concesionario típico y su evolución en 10 años,
AAA
l HC
Participación en las ventas (%)
: Autos nuevos 62% 50%
Autos usados 20% 20%
Servicio és repuestos, financiamiento 18% 30%
Margen Bruto (%)
Autos nuevos 10% 6%
Autos usados 27% 30%
Servicio £: repuestos, financiamiento 40% 60% .
-----
3
El vicepresidente de marketing de Autocar.com, estaba revisando los resultados del primer semestre de la
empresa. Al revisar las cifras se dio cuenta que los ingresos de la empresa no sólo habían aumentado un 70% en
comparación con el mismo semestre del año anterior, sino que la empresa además estaba promediando 67
prospectos de compra (potenciales clientes) al mes para cada uno de los 300 concesionarios de su red a lo largo
del país. La mala noticia era que la empresa aún estaba con problemas de caja. Las ventas durante el primer
semestre fueron de U$10 millones, sin embargo, las pérdidas alcanzaron los US$150,000 durante el mismo
período. El vicepresidente de marketing estaba consciente que el crecimiento era esencial para mantener la
confianza de los inversionistas. Por ende, el principal objetivo de la empresa era acelerar el crecimiento de los
ingresos,
El 100% de los ingresos de Autocar provienen de pagos hechos por los concesionarios pertenecientes a la red,
. Autocar recibía un pago inicial de inscripción, por una sola vez, de US$ 2,000 por concesionario además de una
cuota mensual de U$$ 1.000 por cada uno de los concesionarios participantes, por enviar casi-clientes a la puerta
del concesionario. Autocar asignaba a cada concesionario un territorio geográfico exclusivo en base a marcas
específicas de vehículos y ya estaba alcanzando el nivel de 90% de cobertura en el territorio nacional. Autocar
estimaba que el 20% de los prospectos de compra que recibía la empresa terminaban en ventas, cifra que la
mayoría de los analistas de la industria consideraba que era significativarmente mayor que la de sus competidores
y la de los propios concesionarios. Además, los concesionarios que participaban en Autocar tenían un ahorro
importante en costos de personal y marketing.
Autocar enfrentaba una dura competencia por parte de una serie de fuentes, incluyendo los servicios de compra
online, los sitios web de los fabricantes y los sitios web de los concesionarios locales. Los principales
competidores de Autocar eran: Autoweb.com y AutoDirecto.com. Estos trabajaban con muchos concesionarios
en un área determinada, no dando territorios exclusivos, de manera de ofrecer un precio más competitivo. La
cuota que le cobraban estas empresas a los concesionarios era de U$30 por solicitud más un cobro de una sola
vez por ser miembro del sistema de U$2.000.
PREGUNTAS
a) Como una forma de mejorar sus resultados, el vicepresidente de marketing de Autocar está pensando lanzar
un nuevo servicio: Autocarservicios.com, el cual consistiría en ofrecerle a los consumidores la oportunidad
de obtener servicios de mantenimiento, repuestos, y financiamiento y seguros para sus vehículos, utilizando
un sistema de precios pre-negociados (similar al que ya tiene). De esta manera, los consumidores tendrían,
además de los concesionarios de la red, más opciones donde comparar y llevar a cabo la compra (por ejemplo:
bancos, compañías de seguros, talleres de autos, mecánicos independientes, etc,). Desde el punto de vista de
marketing, ¿le parece acertada la estrategia del vicepresidente de marketing? ¿Por qué sí o por qué no?
Justifique claramente su respuesta.
b) Algunos analistas pensaban que una forma rápida para mejorar los resultados de Autocar era subiendo los
precios que cobraba a los concesionarios por su servicio. Desde el punto de vista de marketing, ¿está Ud. de
acuerdo con los analistas? Justifique claramente su respuesta,
-----
4
cs PREGUNTA N' 2
Esteban Canales, gerente de estudios del banco de inversiones RSH, una empresa financiera de gran tamaño
ubicada en Santiago de Chile, enfrentaba un gran problema, Su analista senior estrella, Pedro Terrazas, había
anunciado abruptamente su renuncia, ya que había recibido una oferta de la competencia, Con ello, varios clientes
quedaron sin un ejecutivo a cargo. En un mercado tan competitivo como el que enfrentaba RSH en que los
márgenes habían caído enormemente, captar y mantener clientes era clave. RSH prestaba servicios a compañías
de diversas industrias en Latinoamérica, que requerían financiamiento para sus proyectos de expansión. El rol de
los analistas era clave para la compañía ya que estos ejecutivos eran Jos que estudiaban las empresas que
solicitaban el servicio, para luego ir a buscar potenciales inversionistas que quisieran financiar los proyectos de
crecimiento de sus clientes.
RSH es una compañía reconocida por la capacidad de análisis de sus ejecutivos a la vez que se destacaba por la
precisión y claridad de los informes con los resultados de la evaluación que realizaba y que luego entregaba tanto
a sus clientes como a los potenciales inversionistas, Muchas veces las alternativas de financiamiento debían salir
de lo tradicional y RSH impulsaba la capacidad de innovación de su personal y que pensaran “fuera de la caja”.
Junto a su conocimiento técnico y experiencia en análisis de empresas, los analistas requerían capacidad
emprendedora y comercial ya que, con las evaluaciones e informes de sus clientes, salían al mercado a captar
_ potenciales inversionistas, siendo convincentes y haciendo presentaciones atractivas para mostrar los beneficios
de financiar a sus clientes.
El trabajo en equipo permitía a RSH, siendo una empresa mediana, cubrir una mayor cantidad de clientes. Los
bonos para los analistas no solo estaban asociados el éxito individual sino también al resultado grupal, La
compañía desarrollaba talleres en habilidades analíticas y de redacción de informes a la vez que implementaba
ejercicios destinados a fomentar la comunicación, la confianza y compromiso con la empresa, RSH exigía que
los analistas senior formaran a los analistas junior. No era extraño que los analistas rechazaran las ofertas de
aumentos salariales del 15-20% en otras empresas porque les gustaba la camaradería y el trabajo en equipo
fomentado en RSH. Era común que las personas permanecieran durante la mayor parte de sus carreras en la
compañía.
La empresa de selección le había entregado a Canales, en orden alfabético, los cuatro candidatos. El primero,
David Hernández (54 años), era un analista de inversiones muy bien catalogado en el mercado y tenía una cartera
de clientes importante que lo seguían. Comenzó su carrera hace 30 años y llevaba 15 años trabajando para su
actual empleador. Poseía una gran inteligencia analítica. Los informes de David, si bien requerían de mayor
claridad, presentaban un buen análisis de las compañias. Había formado a muchos analistas jóvenes y trabajaba
con el mismo equipo que él había desarrollado, Planteaba que de ser contratado por RSH quería moverse con sus
tres analistas más jóvenes. En la entrevista de selección dijo que necesitaba una empresa que le planteara un nuevo
desafío y le diera flexibilidad de tiempo, evitando una frecuencia alta de viajes, ya que había sido abuelo
recientemente y quería pasar más tiempo con sus nietos.
Gerardo Hernández (36 años), el segundo candidato, tenía un historial oscilante como analista, Había estado entre
los mejores, luego su reputación había decaído y ahora se decía que “estaba de vuelta”. Puede que los cambios
constantes de empleo le hayan perjudicado en la apreciación que las empresas tenían de él, pero sin duda “era un
tipo inteligente.” Él mismo señalaba: “finalmente mi esfuerzo y capacidad están dando frutos, más allá de los
equipos con los que he trabajado.” Le interesaba el financiamiento de compañías en un amplio espectro de
industrias, aunque históricamente había estado solo concentrado en pocos sectores. Viajaba constantemente para
estar cerca de sus clientes, los cuales lo seguían a las distintas empresas en donde había trabajado. No estaba
contento en su actual empleo en Inversiones GéL, sobre todo porque su sueldo se había estancado, Aprendía
rápido los aspectos técnicos del negocio y era innovador al analizar las compañías.
Por su parte, Sergio Martínez (42 años), el tercer candidato, no era tan conocido como analista en el sector, ya
que solo había trabajado en empresas pequeñas, con menor exposición de marca, En su actual compañía, Investia,
llevaba 15 años. Recientemente había hecho un muy buen negocio y en la industria se empezaba a hablar ahora
-----
5
- de Martínez y de Investia. Tenía buenos contactos en el sector de empresas informáticas, en donde se había
especializado. Allí había mostrado habilidades comerciales y sus clientes daban muy buenas referencias sobre él,
aunque declaraban que sus informes eran algo confusos. Las cora pañías donde había trabajado dejaban que cada
analista trabajara por su cuenta de acuerdo a sus propios métodos. En la entrevista había mostrado deseos de
cambiarse a RSH. Estaba recién divorciado y su ex mujer e hijos vivían en Osorno.
Finalmente, Sonia Orrego (35 años), tenía buenas credenciales como analista, Si bien aún no estaba
completamente consolidada, se hablaba de ella como “ana promesa en crecimiento”, considerando que había
trabajado en bancos de inversiones más pequeños tipo boutique con clientes a los que se les daba un servicio muy
personalizado, pero con un equipo reducido, que ella había formado en el tiempo. Manifestó que le gustaría,
trabajar más en equipo para ampliarse a más clientes, y así mejorar los buenos resultados que había obtenido.
Mostraba buenas capacidades para realizar informes y presentaciones. Su motivación principal no era el dinero
sino la posibilidad de aportar en una compañía más grande y tener un buen equilibrio trabajo - familia, según dijo
en una entrevista. Está casada y tiene niños chicos. Es muy buena manejando la tecnología, especialmente para
armar video conferencias para evitar el exceso de viajes.
A] pasarle la lista de candidatos a Canales, la empresa de selección le había advertido que los sueldos de los
analistas estaban experimentando una fuerte alza en el mercado. Las expectativas de compensaciones de los 5
candidatos eran las siguientes; :
Sueldo actual (millones de $) | Sueldo planteado para incorporarse a RSH
Pao ROA
En su calidad de experto en gestión estratégica de personas a usted se le pide responder las siguientes preguntas:
PREGUNTAS
a) Indique, en orden de importancia, los tres (3) principales factores que Canales debería considerar para su
decisión de contratación. En su respuesta, explique los factores y el orden que usted ha planteado.
b) Indique cuál es el candidato que Canales debiera elegir. Argurnente su respuesta con precisión.
-----
: 6
- PREGUNTA N” 3
Alexandra Vanguard es una joven profesional reción graduada de un programa de MBA de una prestigiosa
universidad extranjera, que acaba de ser contratada como asesora financiera para colaborar en la gestión de la
cartera de inversiones de una adinerada familia que administra sus inversiones a través de una empresa holding.
Actualmente, la cartera en cuestión está íntegramente invertida en el fondo mutuo indexado FSP500, que tiene
como objetivo replicar el conocido índice bursátil Standard $: Poor's (S$zP) 500. 1 :
La Gerente General del holding familiar está convencida de que la mejor estrategia que debe seguir una persona
que invierte en acciones es comprar y mantener algo similar a lo que podría ser la cartera de mercado, porque
ningún otro portafolio diversificado puede ofrecer el mismo retorno esperado a un menor riesgo. Dado que en
EE.VÚ. la cartera de mercado típicamente se asocia al índice bursátil S£P 500, existen muchos fondos mutuos
que replican este Índice y que reciben el nombre de “fondos indexados”, De esa forma, quienes invierten en dichos
fondos, es como si estuvieran invirtiendo en una especie de portafolio de mercado, y esa es la razón por la cual
los recursos financieros del fondo están invertidos en el fondo mutuo FSP500,
Alexandra, cree que ha llegado el momento de introducir algunos cambios en la administración de la cartera de
inversiones del holding. En particular, ella ha estudiado las siguientes tres alternativas de inversión, mutuamente
excluyentes, que a su juicio permitirían mejorar la relación riesgo — retorno que obtiene el holding en sus
inversiones financieras, tomando en cuenta que los miembros de la familia propietaria del holding son aversos al
riesgo: -
Alternativa 1
Agregar a la cartera del holding, acciones de una nueva empresa del rubro de la pesca que se acaba de abrir a la
Bolsa. Á juicio de los especialistas, esta nueva empresa, que fabrica y comercializa hariva de pescado, tiene muy
buenas perspectivas económicas porque utiliza una tecnología de punta en su proceso productivo.
Alternativa 2
Mantener un 99% de los recursos invertidos en el fondo mutuo FSP500 (que replica el SécP 500) e invertir el 1%
restante en una de las siguientes acciones que no forman parte del S£PS00: la Compañía A o la Compañía B.
Alexandra ha recolectado la siguiente información respecto de estas inversiones:
po || rsso0 |compAÑÍAA | compAÑlaB
Retorno anual esperado 10% 13% 14%
Desviación estándar 20% 25% 40%
El coeficiente de correlación entre los retornos esperados del fondo FSP500 y los rendimientos esperados de las
acciones de las Compafias A y B se estima en 0,6 y 0,25 respectivamente.
Alternativa 3
Invertir el 100% de los recursos del holding en otro tipo de fondos mutuos que también son bastante diversificados
pero que no tienen como objetivo replicar el índice bursátil Sé(P500. Para ello se rescataría el 100% de los
recursos invertidos por el holding en el fondo mutuo ESP500 y estos dineros serían invertidos integramente en
uno de los siguientes fondos mutuos:
po || Fspsoo | FoNDOCc | FONDOD
Retorno anual esperado 10% 15% 18%
Desviación estándar 20% 22% 35%
1 Este índice comprende las 500 acciones de las compafifas más importantes que se transan en bolsa en EE.UU. ponderadas
de acuerdo a su capitalización de mercado.
-----
7
o Responda las preguntas que se le formulan a continuación en base a la información específica que a Ud. se le
está proporcionando en cada una de las Alternativas (por ejemplo, la información de la Alternativa 3 solamente
es válida para dicha Alternativa y no para las Alternativas 1 y 2). :
PREGUNTAS .
a) Al conocer la Alternativa 1, la Gerente General del holding le dice a Alexandra que no cree que sea bueno
invertir en acciones de la nueya empresa pesquera, porque sus resultados están expuestos a demasiados riesgos
que son incontrolables, como por ejemplo, cambios climáticos (corriente del niño, tormentas), vedas (marea roja
o extinción de la especie), alzas en el precio del combustible (insumo para los barcos pesqueros), etc.
Adicionalmente, la harina de pescado (principal fuente de ingresos de la pesquera) es un commodity que se transa
a nivel mundial con un precio altamente volátil. ¿Está Ud. de acuerdo con este análisis? Explique por qué.
b) Si Ud. tuviera que invertir el 1% de la cartera del holding familiar en una de las dos compañías mencionadas
en la Alternativa 2 (manteniendo el 99% restante en el fondo mutuo FSP500) ¿Cuál de ellas elegiría? Fundamente
su respuesta en forma conceptual y numérica. Use un mínimo de dos decimales en sus cálculos (XX, Y Y %).
e) Suponga, sólo para efectos de esta pregunta, que la tasa libre de riesgo fuera del 4% anual y que Ud, tuviera
que tomar la decisión de invertir, en el corto plazo, el 100% de los recursos del holding en el fondo mutuo C o el
fondo mutuo D mencionados en la Alternativa 3, ¿Cuál de ellos elegiría? Fundamente su respuesta en forma
conceptual y numérica. Use un mínimo de dos decimales en sus cálculos.
-----
8
es PREGUNTA N' 4
Uber: cambiando la forma en que se mueye el mundo
Uber es una de las compañías más icónicas de nuestro tiempo y hoy atiende casi 2 millones de viajes por día en
453 ciudades de 65 países del mundo.
El servicio es muy fácil de utilizar. Los usuarios solo tienen que bajar la aplicación a sus Smartphones, crear una
cuenta y entregar información sobre una tarjeta de crédito, Cuando se requiere pedir un auto, se presiona un botón
en la aplicación. Entonces la aplicación muestra autos cercanos disponibles y en cuestión de segundos un
conductor indica que está en camino a recoger al usuario. El usuario puede ver el nombre del conductor y su
ranking de calidad (1 a 5), incluso rechazarlo si así quisiera. Ambas partes pueden comunicarse telefónicamente.
Una vez a bordo, el conductor lleva al pasajero a su destino usando un dispositivo GPS incorporado en la misma
aplicación Uber. Usuarios frecuentes también son incorporados en el sistema Uber de tal forma que los
conductores pueden desechar llamadas asociadas a usuarios problemáticos. Adicionalmente, Uber entrega a los
conductores información de las áreas donde es más probable encontrar más demanda.
Uber cobra tarifas de acuerdo al tiempo y la distancia del viaje que típicamente son menores (eu promedio 10%)
que las que cobra un taxi. Sin embargo, de acuerdo al sistema “Surge Price”, algoritmo de precios dinámicos
incluido en la aplicación del servicio, cada vez que la demanda supera a la oferta de autos, Uber cobra tarifas más
altas que oscilan entre 1,5 y 1,7 veces las tarifas normales. Para ser transparentes con los usuarios, Uber avisa a
sus clientes cada vez que el sistema Surge Price ha sido activado. La firma suple sus altos requerimientos de
procesamiento de datos con la contratación de Ph.D.s de los más variados campos.
Los conductores son contratistas independientes pagados por las carreras realizadas y no son empleados
permanentes de Uber. De la tarifa que se cobra a un pasajero, un 20% es para Uber y el 80% para el conductor.
Los conductores del servicio más común (UberX) debían poseer licencia de manejo y seguro de automóvil. En el
caso de los servicios más exclusivos (como UberBlack), la licencia de manejo debía ser profesional.
Adicionalmente, ningún conductor podía tener antecedentes por mal manejo y se requería que cada conductor
tuviese un smartphone. Uber no es dueña de los autos pero aquellos utilizados deben satisfacer ciertos requisitos,
como por ejemplo tener menos de 10 años de antigiledad. Actualmente existen servicios asociados a tipos
particulares de autos como UberX (autos más grandes) y UberSUV (autos tipo SUV).
Cuando Uber planea entrar a nuevas ciudades, envía a dos equipos de avanzada con seis semanas de anticipación.
Uno de los equipos tiene a su cargo crear “conciencia” en el mercado sobre la próxima entrada de Uber. El otro
tiene a cargo contratar conductores para el servicio. En esa tarea, este segundo grupo enfatiza los beneficios de
trabajar en las horas que a ellos les convenga, ganar buen dinero, recibir un pago inmediato, y también ser capaces
de excluir del servicio a los usuarios mal comportados. Adicionalmente, Uber ofrece a los nuevos conductores
financiamiento para comprar el vehículo o un smartphone en caso que no tuvieran.
Competencia
Uber compite con la industria de los taxistas que opera en diversos países. En contra de los taxistas, abundan las
quejas de los usuarios (autos en mal estado, sucios, música a todo volumen y algunos hablan por teléfono mientras
conducen). Adicionalmente, encontrar un taxi no es siempre fácil, en particular en ciertas partes de las ciudades
y durante la noche, Además, en muchos países las restricciones y requerimientos regulatorios para ser taxista son
elevados (sus precios están regulados y el número de taxistas está fijado). En otros segmentos del mercado, Uber
también enfrenta competencia en servicios de limousines, transportes livianos y otros servicios de transporte
como Lyft, Cabify y Sidecar, Ninguno de estos servicios, sin embargo, tiene la popularidad de Uber.
-----
9
a Regulación y la batalla de dos mundos
Pocos meses después de la creación de Uber, los reguladores, políticos y la industria de los taxistas ya estaban
peleando en su contra y para el 2015 la lucha había alcanzado gran intensidad. En países como Holanda y Corea,
Uber ha sido tratado como un servicio de taxis ilegal. En otros países, los taxistas so han manifestado con protestas
contra sus gobiernos por no haber regulado.
En realidad, la legalidad del negocio de Uber no estaba clara. Aunque existían leyes que regulaban los servicios
de taxis y limousines, no era para nada evidente que Uber en verdad ofrecía ese tipo de servicios. Lo cierto es que
la tecnología usada por Uber significaba un cambio radical para esos mercados y tanto leyes como reguladores
no estaban preparados para lidiar con ella.
Una de las críticas contra la firma era que usaba conductores no-profesionales, lo cual era verdad en UberX. Sin
embargo, ¿se estaban poniendo vidas en riesgo por ello? Uber respondía que los tests y exámenes a los que se
sometían sus conductores muchas veces eran más estrictos que los propios de la industria de taxis. Otra crítica se
refería a que Uber utilizaba esquemas de cobro de precios que estaban pensados para eliminar la competencia
(taxis). Su CEO respondía que Uber se enfrentaba a una industria protegida y que por definición prefería no
competir. Aún más, Kalancik (CBO de Uber) llegaría a escribir: “Nuestro oponente—el gran cartel de los taxistas-
ha usado décadas de contribuciones políticas e influencias para restringir la competencia, reducir las opciones a
los consumidores y restringir las oportunidades en el mercado de los conductores”. No hay necesidad de decir
que los consumidores que defienden a Uber son muchos. :
- Al cerrar el año 2015, Uber tenía muchas razones para celebrar. Una de ellas, recientemente había ganado una
batalla no menor en Nueva York. Su alcalde, Bill de Blasio había amenazado con limitar el número de autos
operando con Uber. Como respuesta, Uber no solo lanzó una campaña publicitaria enrostrándole al alcalde su
excesiva dependencia económica de la industria de taxis, sino que también introdujo simulaciones en su
aplicación para que las personas pudieran estimar los largos tiempos de espera para conseguir un taxi que se
producirían si la medida de Blasio se aprobase. El apoyo popular a Uber y de numerosas celebridades, incluyendo
autoridades como el Gobernador del mismo estado de Nueva York no se hicieron esperar. Otras señales del  *
momentum de Uber eran sugerencias del positivo impacto del desarrollo inmobiliario en ciertas ubicaciones de
las ciudades, una reducción en los casos de conducir bajo la influencia de alcohol, y tal vez si lo más importante,
una reducción de hasta 40% en el valor de las licencias para operar un taxi en ciertas ciudades. Sin embargo, al
mismo tiempo, la compañía continuaba con sus colisiones con los reguladores y con las cortes en múltiples países
alrededor del mundo. Las protestas contra Uber, algunas veces violentas, continuaban encendiendo ciudades
desde Paris hasta Madrid.
Basado únicamente en la información provista en el caso, responda las preguntas que se le formulan a
continuación:
PREGUNTAS
1) Actualmente se está discutiendo la idea de incrementar la regulación hacia los proveedores independientes
de servicios de transporte urbano como Uber. Estos incrementos regulatorios como mínimo implicarán que
Uber tendrá que pagar más impuestos que los que paga hoy. Expertos en estrategias de negocios han
aseverado que este cambio regulatorio significará el fín de la capacidad de Uber de obtener rentabilidades
sobre normales en el largo plazo ¿Está Ud. de acuerdo con la opinión de estos expertos? Utilice conceptos de
Estrategias de Negocios para justificar su respuesta. .
2) Dados los efectos generados por la irrupción de Uber en el mercado del transporte urbano, una de las más
grandes asociaciones de taxistas ha decidido desarrollar su propia aplicación para competir con Uber. ¿Cree
Ud. que esta estrategia le permitirá a la mencionada asociación de taxistas competir exitosamente contra Uber?
Utilice conceptos de Estrategias de Negocios para justificar su respuesta.
-----
10
0 PREGUNTA N? 5 :
Siguiendo los pasos del mercado de productos para el cuidado de la piel, la industria de productos para el cuidado
del cabello está enfrentando, en la mayoría de los mercados del mundo, importantes cambios. Motivado por la
creciente atención que los consumidores prestan al cabello, en muchos países se observa una tendencia hacia el
consumo de productos que se ajusten mejor a las necesidades individuales y a los deseos de lograr una
determinada apariencia. Las personas ya no sólo se lavan el cabello, también lo hidratan, protegen, fortalecen,
eto.
De acuerdo a la empresa de investigación de mercado IRI, en el mercado en EE.UU., las categorías de productos
relacionadas con el cuidado del cabello han tenido un crecimiento leve en los últimos años, muy en línea con el
crecimiento de la población. La composición de este ligero crecimiento, sin embargo, ha sido muy heterogénea,
Los productos orgánicos y naturales son los que más han crecido. Los consumidores se han vuelto más conscientes
de los ingredientes de los productos, Productos con sulfatos, aceites minerales y alcohol, que alguna vez fueron
ampliamente usados, se han transformado en tabú en las nuevas formulaciones.
3 y En Chile, según el panel de consumidores Kantar
A AA WorldPanel que mide las conductas de compra de un panel
y ES de 2.000 hogares en las principales ciudades de Chile, los
A A a a productos de belleza y cuidado de la piel tuvieron un
: ! E AE E 0 ODA] crecimiento importante el 2017. En particular, las
ARO dioss da a Y gl O , .
E a, io o categorías de cuidado del cabello, que incluye
A sE oe: q E aa eN fundamentalmente los shampoo y los acondicionadores,
28 de. E E la Un Do A. tuvieron un erecimiento cercano al 2,5%.
AR
A La Tabla siguiente muestra indicadores de desempeño de
categoría y de marca para las categorías Shampoo y
Acondicionador en Chile, según el panel de Kantar WorldPanel. Para los años 2016 y 2017, la tabla muestra la
penetración de mercado (Y de hogares que compran el producto), la frecuencia de compra o número de visitas
en las cuales se compra la categoría (o marca) y el ticket (o valor) promedio por visita, Todos los indicadores
corresponden a un período de un año. Las dos últimas filas de la tabla muestran los indicadores correspondientes
a la empresa líder en ambas categorías.
Tabla: Indicadores de Desempeño de Shampoo y Acondicionador de Pelo
Categoría y Marca Lider de las Categorías (datos anuales)*
: Frecuencia Gasto por
. Penetración (7) Compras Compre ($)
Categoría 2016 2017 2016 2017 2016 2017
Shampoo 99,6 99,2 9,8 10,0 2.354 — 2314
Acondicionador 94,4 94,0 6,7 67 2.025 2.030
Shampoo Líder Categoría 56,3 55,9 2,9 3,3 3.473 3,169
Acondicionador Marca Líder 355 345 22 23 2991 3.044
(*) Los datos corresponden a hogares. Suponga formatos iguales entre la marca líder de la categoría y las otras marcas.
Suponga que en un año el consumo y la compra coinciden. Los datos de penetración de marca se refieren al total del
mercado y no a los que compran la categoría.
PREGUNTAS
a) Describa las ventajas que tiene para el análisis de los datos de desempeño de categoría y marca un panel de :
consumidores, en relación a muestras independientes en cada período. Sea preciso en su respuesta,
-----
1
0. b) Suponga que los ejecutivos de la marca líder de las categorías analizan la tabla con los indicadores de
desempeño y discuten si en productos para el cuidado del cabello debieran enfatizar una estrategia de
crecimiento basada en (1) la penetración o en (ii) la frecuencia. Suponga costos de inversión semejantes para
estas dos estrategias. Proponga una (y sólo una) de estas estrategias, a la fuz de los datos presentados en la
Tabla y considerando los patrones usuales de indicadores de desempeño en productos de consumo masivo.
Justifique su respuesta.
e) Suponga que el líder del mercado desarrolla un nuevo acondicionador en base a ingredientes orgánicos
y naturales y que después de 3 meses dispone de los datos de penetración y frecuencia para ese trimestre.
Proponga un modelo para estimar la penetración que podría alcanzar el nuevo producto después de 12
meses. Explique sin usar fórmulas.
(
-----
1
PREGUNTA N' 6
Hoy, 1 de enero de 2019, usted está evaluando un negocio, que consiste en la compra de un motor capaz de
generar energía de manera instantánea (se prende el motor y de inmediato comienza el proceso de generación de
energía). La energía generada se vendería, a través de un contrato, al proveedor oficial y responsable final de
satisfacer la demanda de energía de los habitantes de la zona en que usted operaría su negocio. Por ley, este
proveedor está obligado a disponer en todo momento, del total de la energía que sus propios clientes le demanden,
y le preocupa que los días 31 de diciembre, a las 24:00 hrs., momento de máxima demanda por energía que él
enfrenia, pudiera no contar con la energía requerida para satisfacer la demanda de ese momento, Se sabe que la
multa que tendría que pagar el proveedor oficial de energía de la zona, en caso de no poder satisfacer
oportunamente la demanda por energía de sus clientes, es muy elevada.
: Así entonces, este tipo de contrato es una especie de respaldo o seguro con el que el proveedor oficial encargado
de abastecer energía en la zona, espera contar en caso de necesidad. En particular, el contrato entre Ud. y el
proveedor oficial, que sería su único y exclusivo cliente, estipularía que usted se compromete a venderle a £l, en
caso que lo requiera, toda la energía que su motor sea capaz de generar, fnicamente el último día de cada año (31
de diciembre), entre las 23:00 y las 24:00 hrs., que es cuando se produce el peak de demanda,
La inversión inicial total requerida hoy 1 de enero de 2019 (t= 0), en este nuevo negocio, para dejar el generador
en condiciones de operar los días 31 de diciembre de cada año, alcanzaría los US$400.000 al contado. La máxima
capacidad de generación de energía del motor es de 7.000 unidades de energía por hora, en cada uno de los dos
años de vida útil que tiene el motor, es decir, en los años 2019 y 2010. Al término del segundo año (2020), el
motor dejaría de tener la capacidad de volver a generar energía (termina su vida útil), y el valor comercial de las
inversiones hechas en el nuevo negocio sería de US$ 0 (cero). Al término del segundo año se acaba el negocio y
se estima que habría que pagar, en ese mismo momento y en efectivo, indemnizaciones laborales y otros
desembolsos, por un total de US$35.000.
El precio al cual ayer, 31 de diciembre de 2018 en la noche, se transó una unidad de energía fue de US$ 500
(precio contado) y, para los días de finales de cada uno de los próximos dos años (2019 y 2010), se estima que
hay un 60% de probabilidad de que el precio por unidad de energía pueda subir en US$ 60 y un 40% de
probabilidad de que pueda bajar en US$ 60 con respecto, en ambos casos, al precio vigente en el periodo
inmediatamente anterior, tal como se muestra en el siguiente cuadro:
_ EVOLUCIÓN DE PRECIOS POR UNIDAD DE ENERGÍA (US$) |
O O
AE A
1 T
PS —
7] RG
El costo total de generación de una unidad de energía, que se estima permanecerá constante a través del tiempo,
es de US$ 490 por unidad. La tasa de descuento de este nuevo negocio es de 10% anual. Tanto el costo de
generación de la energía, como el ingreso por su venta, ocurren simultáneamente a fines de cada año.
El proveedor oficial le ha ofrecido a usted un contrato, en el cual se estipula que si usted decide hoy emprender
el nuevo proyecto (negocio), es decir, comprar y dejar en condiciones de operar el nuevo generador, entonces
-----
_ 13
c+ usted está obligado a generar y entregarle a él, al término de cada uno de los años 2019 y 2010, el total de la
energía que su generador es capaz de producir, es decir, él le demandaría y usted le tendría que vender, las 7.000
unidades de energía que su generador es capaz de producir, al precio que esté vigente en cada uno de esos dos
momentos futuros, 31 de diciembre de 2019 y de 2020,
Como usted no tiene certeza respecto de los precios que se le pagarían por cada unidad de energía que le venda
al proveedor (su único cliente), usted ha decidido proponerle un contrato distinto, en el cual usted tenga la opción
de no venderle energía si el precio vigente en el momento de la venta no le resulta conveniente. El contrato en
cuestión estipularia que el día 31 de diciembre de los años 2019 y 2010, usted tendría el derecho a decidir si hacer
funcionar o no su generador, es decir, si venderle o no energía al proveedor, dependiendo del precio de compra
que en ese momento le ofrezca su único cliente, De este modo, usted haría funcionar el generador y le vendería
energía al proveedor, sólo en la medida en que el precio vigente en el momento sea conveniente para usted. Esta
opción, sin embargo no sería gratis, ya que si usted decide no generar energía en un período, deberá compensar a
su cliente, en ese mismo momento, con un pago en efectivo de US$40.000.
Usted tendría la opción de “abandonar” el proyecto (terminar con el contrato con el proveedor) tanto a fines del
primer año, como a fines del segundo año. Sin embargo, si Ud. ejerce esta opción a fines del primer año, el
contrato se termina y no existen posibilidades de vender energía, a nadie, el segundo y último año de vida útil del
generador. Adicionalmente, cualquiera que sea el momento en que usted deje de generar energía, y por lo tanto
- termine la empresa, habrá que pagar, en efectivo y en ese mismo momento, la suma de US$35.000, por concepto
de indemnizaciones laborales y otros desembolsos asociados al cierre del negocio. Este pago es adicional a la
compensación de US$40.000 que debe pagársele al proveedor como compensación en caso de no generar energía.
En resumen, el contrato con el proveedor seguiría vigente durante el segundo año (2020), siempre que usted le
haya vendido a él, en el caso que lo hubiese requerido, las 7.000 unidades de energía que es capaz de generar su
motor, cualquiera que haya sido el precio vigente el 31 de diciembre de 2019. Bn caso contrario, el contrato se
entiende terminado a fines del año 2019 y además habrá que pagar la compensación de US$ 40.000 antes
mencionada.
El cliente escuchó detenidamente su ofrecimiento y quedó de estudiarlo.
Suponiendo que:
e No hay inflación ni impuestos.
* Que todos los valores en US$, son flujos de caja que se producen al inicio del proyecto (1 de enero de
: 2019) en el caso de la inversión inicial, y al final del año (31 de diciembre de 2019 y 2020) en el caso de
los flujos de caja que el proyecto podría generar.
+  Queno existe la opción de postergar el inicio de la operación, es decir, si se decide emprender el proyecto,
éste debe partir ent= 0. Tampoco existe la posibilidad de modificar las 7.000 unidades de energía que el
motor es capaz de generar entre las 23:00 y las 24:00 de cada 31 de diciembre.
Responda las preguntas que se le formulan a continuación:
PREGUNTAS
Estime al valor que tendría para usted, en su calidad de inversionista en este emprendimiento, la opción de poder
decidir si vender o no energía a su cliente al término de cada wno de los años 2019 y 2020 de operaciones del
generador. Fundamente su respuesta mostrando los cálculos correspondientes.
Ayuda; Para responder la pregunta, lo primero que usted debs hacer, es determinar el valor del proyecto bajo las
condiciones del contrato inicial propuesto por su cliente, es decir, cuando usted está obligado a venderle al
proveedor aun cuando el precio no le resulte conveniente.
-----


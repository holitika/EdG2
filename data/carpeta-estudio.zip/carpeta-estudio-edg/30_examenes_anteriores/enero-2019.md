# Examen de grado · enero-2019

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


" PONTIFICIA UNIVERSIDAD CATÓLICA DE CHILE
ESCUELA DE ADMINISTRACIÓN
ISSO
SE ¡EL s
XIV] LAY
E ES
EXAMEN DE GRADO
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
que los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
realidad de las empresas que allí se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente a la Profesora Marta Del Sante, Presidente de la Comisión
de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
condiciones, la Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala, los que deberán estar apagados y no
deberán mantenerse sobre el escritorio durante el examen.
12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
como “borrador”, esas hojas no se deben entregar con las respuestas.
Fecha : 25 de enero de 2019
Duración : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá la Profesora
Marta Del Sante, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 y
11:00 hrs. (aprox.).
-----
2
: PREGUNTA N'1
El mercado de celulares, y en particular de smartphones, ha sido muy dinámico y se expandió hasta el año 2015
a tasas de dos dígitos. Sin embargo, tal como se observa en la Gráfica N*1, la tasa de crecimiento (línea en el
eráfico) de las ventas anuales de aparatos smartphones es hoy casi nula y trae una fuerte tendencia negativa en
los últimos 2 años.
En muchos países, incluido Chile, la
penetración de los smartphones en la
138 = mm población total es superior al 65% y la de
e ld 1 Bi € celulares totales, sobre el 110%. En Chile,
y Y Y Y Y ñ el 85% de los accesos a internet son
ci ANO a Y Y 7 l Y DA - realizados desde un smartphone. Algunos
: S Y Y m analistas escu que algunos segmentos
O A % 4. G- Y Y 5% y como niños y adultos mayores no
s 2 7 Y 4 7 Y 7 n necesitan/valoran las características de un
IV UY t Smartphone.
E AS 10 A Al parecer, también los consumidores
Zanória Eos 0%" —E están cada vez más sensibles a los precios
y están demorando el cambio de equipos,
pese a la incorporación de mejores cámaras fotográficas, mayor duración de la batería y una serie de nuevos
atributos en aplicaciones. En los últimos tres años, la posesión promedio de un mismo modelo de Smartphone
ha subido de 16 meses a 27 meses. Una parte significativa de las ventas se hacen a través de las empresas de
telecomunicaciones tales como Entel, Movistar, WOM y Claro, y como condición para no comprar el equipo al
contado, el cliente se compromete contratar el plan por un mínimo de 18 meses. De esta forma, paga un monto
menor por el equipo. La relativamente alta penetración de smartphones ha desarrollado también un mercado
secundario muy activo de modelos más antiguos.
La empresa Apple, posee un portafolio de productos (Smartphones, tablets, relojes, accesorios) y servicios
(¡Tunes[música], iPhoto, ¡Cloud [memoria en la nube], Apple Play [Música y videos] y Apple Pay [servicio de
pago]), así como una serie de proyectos en curso en distintas categorías.
Para Apple, las ventas de sus aparatos iPhone con sistema operativo propio IOS, están reflejando la tendencia
negativa del mercado. Las expectativas de sus iPhone X en distintas versiones no se han cumplido y para este
año 2019, varios de sus proveedores de componentes! están rebajando sus estimaciones de ventas, ya que Apple
está recortando sus estimaciones de producción.
Por otro lado, el mercado se ha hecho aún más competitivo, tal como se muestra en el Cuadro N”1, con el ingreso
de las marcas chinas tales como Huawei, Xiaomi, Oppo y el relanzamiento de Motorola bajo la mano de Lenovo.
1 Apple no fabrica sus aparatos, sino que diseña e integra componentes de otros fabricantes, incluso de competidores
(Samsung, Sony, LG, Toshiba). Ej. Las pantallas OLED son provistas por Samsung, los chips por Intel, etc. El ensamblaje
lo hace FoxConn, una empresa Taiwanesa con fábricas en China.
-----
3
O
¡Participación Mercado Mundial 5 principales marcas (unid) , a
l 2orog] 2os7oa]  2otsqu] 201802] 201803 En particular, Huawei, con lanzamientos de
LL] 241705] 2170H 2otB0s|  2osÓnai 201003 productos Premium (que al igual que Apple y
23,0% 19,0% 24,0% 20,0% Samsung, han superado la barrera de los USD
Apple 12,5% 19,5% 15,5% 1.000), y una amplia gama de modelos, tanto
: 10,2% 10,7% 10% 160%] 14,5% regulares como smartphones, ha logrado
quae piipción a Ape y n pate a
Samsung.
Tal como se muestra en la Gráfica N“2, las marcas chinas, todas bajo el sistema Android, tienen precios
promedio de sus líneas de productos, significativamente por debajo de Apple y más cercanas al líder del
mercado, e además de costos Gráfica Ne2
Las mars chinas ct anando modelos de
Las marcas chinas están lanzando modelos de SS MESES (2018) MES)
equipos con tecnología, si bien inferior a la de A e enrmnimcsrs SFODO
Samsung o Apple, relativamente buenos y
con atributos valorados por una gran parte del
mercado. Apple comercializa 6 modelos de  - e 500)
smartphones y no tiene celulares fuera de esa e
categoría. Sus competidores tienen, cada uno, a Cl A ps
más de 15 modelos distintos en smartphones E A
y varios más en celulares simples. Apple Samsung OPPO Huawei vo Ximomi Transsion
Source-1DC
Los ejecutivos de Apple Chile están ao
preocupados con los desafíos para el 2019,
que son crecer en ventas y en margen de contribución. Uno de sus Gerentes planteaba que debían pedir a la
matriz que lanzara productos con la marca iPhone en el nivel medio de precios, más simples y accesibles, para
poder competir con Samsung y las marcas chinas. Un Director se oponía y proponía concentrar los recursos en
quitarle participación a Samsung y Huawei en la categoría Premium (Equipos sobre USD$1,000) mediante
campañas publicitarias y promociones de precios.
PREGUNTAS
a) Desde el punto de vista comercial, analice la principal ventaja y la principal desventaja de las
propuestas de ambos ejecutivos.
b) Identifique y argumente una forma alternativa a lo propuesto por los ejecutivos, y factible dada la
información del enunciado, para cumplir los objetivos de crecer en ventas y márgenes para el año 2019.
-----
4
A PREGUNTA N“2
Superzon, una importante empresa del comercio online con presencia mundial, hoy no tiene operaciones físicas
en nuestro país. Si hoy un consumidor chileno quiere comprar un producto por Superzon, debe encargarlo a
Estados Unidos. Sin embargo, esta empresa ha dado señales inequívocas de que quiere contar con oficinas,
bodegas y toda la logística que se requiere para ser un operador local. Actualmente es una de las compañías con
mayor valorización bursátil en el mundo, lo que ha conseguido mediante permanentes inversiones en tecnología,
la que le permite tener una muy buena interacción con sus clientes. Ello se traduce en recomendaciones de
productos escogidos a la medida del perfil de los usuarios, buscadores rápidos y efectivos de productos, sistema
de pago online muy seguro, despachos con precisión en donde el comprador en cada momento tiene información
del estado de sus pedidos y un sistema muy efectivo de devoluciones.
Por su parte, la multitienda nacional Chilezon, así como muchas otras compañías de retail locales, también han
desarrollado sus negocios de venta online, los que complementan su cadena de tiendas en todo el país. Ante la
amenaza inminente de la instalación de Superzon como competidor local, Chilezon está haciendo grandes
esfuerzos por ser un actor competitivo en el comercio online. Ha invertido en tecnología, centros de distribución,
sistemas de pago seguro, aplicaciones para compra mediante teléfonos móviles, logística y también ha adquirido
empresas que pueden acelerar la construcción de sus ventajas competitivas en el negocio del retail online.
Hasta ahora la experiencia de los clientes con respecto a Superzon y Chilezon ha sido dispar. Un reciente estudio
mostraba las opiniones de clientes de ambas empresas. En uno de sus capítulos aparecía este testimonio:
“Compré un smartphone a través de la página web de Chilezon. Como tenía dudas respecto de la compra, llamé
al call center. A la persona que me respondió muy amablemente y con gran motivación, le costó dar respuesta
a mis consultas y sus respuestas no fueron técnicamente muy convincentes. Sentí que improvisó una respuesta.
Luego de terminar mi conversación, y como necesitaba el smartphone pronto (había perdido el mío), hice clic
en la opción de retirarlo en tienda en 24 horas. Así que al día siguiente concurrí a Chilezon. Me atendió un señor
muy amable y proactivo. El problema fue que por más que insistí, solo me pudo informar que mi pedido del día
anterior estaba ingresado en el sistema, que había smartphones en la tienda, pero que no me lo podían entregar
porque no se había emitido aún la guía de despacho. Frustrado, insistí en que me lo entregara, pero quién me
atendía me repitió una y otra vez que de verdad lo sentía mucho, pero que para poder entregarme en ese momento
el celular que había comprado debía consultar a su jefa, quién no se encontraba disponible en ese momento. Ese
era el procedimiento y sin la autorización de su supervisor no podía entregarme el producto, me señaló la persona
de la tienda.
Por otra parte, una semana después, compré un parlante en el sitio web de la tienda online Superzon. Como
tenía poca experiencia como usuario y también dudas sobre el producto me contacté con su centro de atención
al cliente. Un señor me contestó muy amablemente en español. Me indicó que el producto que buscaba no era
el más adecuado para mis propósitos. Me sugirió en cambio, una alternativa, incluso más barata. Después, en
un par de minutos me explicó “en fácil”, las ventajas técnicas de su sugerencia. De paso, me dijo que para que
fuera cliente frecuente de Superzon, me daría gratis el costo del envío. Me convencí de que su producto
alternativo era mi mejor opción. ¡Y al mismo precio que comprarlo en Chile; flete incluído! Ante mi sorpresa,
le pregunté si estaba seguro de esta oferta y si acaso no tendría que preguntar a su jefa para lograr tamaño
descuento. Me contestó: “a nuestra jefa no la molestamos con estos detalles. Sé lo que estoy haciendo.” Por mi
natural estado de nerviosismo con estas cosas llamé al call center de Superzon varias veces para conocer el
estado del envío y en todo momento me contestaron con amabilidad e indicándome con mucha seguridad en
qué estatus se encontraba el envío. Finalmente, el artículo llegó a mi casa en Santiago, sin problemas.”
El cliente, luego de esta doble experiencia, terminaba su relato con la siguiente conclusión: “El desafío para
Chilezon no pasa solo por incorporar nuevas tecnologías. Lo que debe cambiar esta empresa es mucho más
profundo.”
-----
5
] En su calidad de asesor experto y desde la perspectiva del rol de la gestión de personas, se le pide que conteste
las siguientes preguntas:
a) ¿A qué se refiere el cliente citado en el estudio con que el desafío para Chilezon es mucho más profundo
que solo incorporar las más avanzadas tecnologías en el comercio online? Explique de manera precisa.
b) Suponiendo que el testimonio planteado por el cliente expuesto en este caso es representativo de una
realidad para un conjunto amplio de clientes de Chilezon, señale las tres prácticas de gestión de
personas más importantes que esta empresa debe modificar o implementar si quiere lograr competir en
igualdad de condiciones con Superzon, de cara a los clientes de nuestro país. Indique en su respuesta
qué efectos provocará en la forma de hacer negocios de Chilezon, las prácticas que usted propone.
-----
6
s PREGUNTA N%3
Usted debe evaluar la conveniencia de iniciar una nueva empresa (proyecto) llamada CMV S.A. en el rubro de
transporte marítimo. Su gran duda es qué tasa de descuento usar para evaluar este proyecto. Investigando, usted
encontró tres empresas cuyo giro sería similar al del proyecto que usted desea evaluar. Los datos encontrados
son los siguientes:
Beta 'Valor de mercado del! Valor de mercado de
Er patrimonio Beta Deuda la deuda
Patrimonio ; :
(millones de US$) (millones de US$)
avegación Oceánica S.A. 1.050 3.150
Se ha determinado además que el CAPM (Modelo de Valoración de Activos de Capital) es un buen modelo a
ser utilizado para los efectos de estimar tasas de descuento. La tasa libre de riesgo es 3% anual y el premio por
riesgo de mercado es 5% anual. La empresa que usted evalúa será similar, en términos de activos y estructura
de financiamiento, al promedio ponderado de las empresas del cuadro anterior. Suponga inicialmente que el
mercado de capitales es perfecto.
Responda las preguntas que se le formulan a continuación mostrando todos los cálculos que sean necesarios:
a) Si CMV S.A. será similar al promedio ponderado de las empresas en el cuadro anterior, determine el Beta y
la tasa de descuento que debería utilizar esta empresa para descontar los flujos de caja de sus activos.
b) Mantenga el supuesto de mercado de capitales perfecto. Usted también desea calcular la tasa de costo de
capital del patrimonio, para explicarle a sus accionistas cuál sería la rentabilidad esperada “justa” de largo plazo
de este negocio. Para calcular el Beta del patrimonio y así poder obtener el costo de capital del patrimonio, un
analista le recomienda utilizar la siguiente fórmula:
= Da
Bi = Ba(l + 577)
donde:
P = beta del patrimonio
Ba = beta de los activos
E = razón (deuda / patrimonio) utilizando valores de mercado
La relación (deuda / patrimonio), usando valores de mercado, que planea usar la empresa CMV S.A. es de
1,1268, que corresponde al promedio ponderado de las empresas del cuadro anterior. ¿Está usted de acuerdo
con utilizar la fórmula propuesta para calcular el Beta del patrimonio? ¿Qué Beta y qué tasa de descuento para
el patrimonio debería usarse para evaluar el proyecto de CMV S.A.?
e) Suponga ahora que existen impuestos con una tasa corporativa de 25% y que la deuda tiene ventajas
tributarias. Suponiendo que la única imperfección del mercado de capitales fuera la existencia de impuestos
corporativos, ¿Cuál sería ahora el costo de capital de los activos y del patrimonio de CMV S.A.? Fundamente
su respuesta.
-----
7
: PREGUNTA N'4
En un intento por incorporarse de lleno al mundo del comercio electrónico, la cadena de supermercados
Walmart, compró recientemente el 100% de la compañía chilena de compra asistida con despacho a domicilio
Cornershop por US$225 millones. La firma recién adquirida, se convierte entonces en una subsidiaria de
Walmart.
A través de la aplicación de Cornershop para smartphones y tablets, o desde su sitio web, los usuarios ingresan
a supermercados como Jumbo, Líder o Unimarc, a farmacias, al Mundo del Vino, Dulcería Montolin,
Chocolates Varsovienne, Alimentos Felipe Didier y otros comercios. El usuario o cliente, indica el comercio en
donde desea realizar su compra y luego marca los productos que quiere comprar, lo cual genera una orden de
compra para un “shopper” (comprador). Después de hacer su pedido y pagar online, el shopper irá al comercio
señalado por el usuario y efectuará la compra por cuenta de éste.
Si el shopper no encuentra algún producto, él llamará e indicará al cliente qué alternativas hay y si quiere que
haga el cambio del producto que no se encuentra, por uno que esté disponible. Por ejemplo, es muy común el
tipo de llamadas del shopper al cliente diciendo: “no hay mostaza Marca A, pero está la Marca B que vale $20
más”. Entonces, a diferencia de empresas como Jumbo online, Telemercados u otros competidores o sustitutos,
al cliente no le llegan productos cambiados sin avisarle. En este sentido, un experto de la industria afirma sobre
Cornershop: “Eso es lo que lo hace tan atractivo. Es como que tú mismo fueses al supermercado, pero sin salir
de tu casa. Habrá alguien eligiendo la fruta, una persona que dirá “esta manzana está fea” y simplemente tomará
otra.”
El mismo experto señalaba que: “Otra cosa que destaca a Cornershop es que el pedido llega en horas, no días.
O lo puedes agendar para recibirlo en un horario específico, por ejemplo, mañana entre las 9 y las 10 AM. El
objetivo es fortalecer la entrega de los pedidos en la “última milla', nombre que recibe el paso final en la cadena
de distribución de un pedido online, proporcionando una nueva y más conveniente forma de comprar para el
consumidor.”
Por su parte, uno de los socios de Cornershop señalaba sobre su compañía que: “la principal diferencia de
nuestra empresa con otras, es que nosotros estamos totalmente orientados por la tecnología. Estamos llenos de
ingenieros de software y toda nuestra logística y operaciones son algoritmos. Esto a su vez, nos permite medir
nuestras operaciones para ir cambiando y mejorando constantemente.”
En relación a la reciente adquisición de Cornershop, el gerente general de Walmart, destacó que: “Estoy
convencido de que la recién adquirida Cornershop debe ser administrada de manera integrada por Walmart. Es
decir, como si ambas fueran una sola empresa. Creo que tanto el Directorio de Walmart, como su gerente general
y el equipo ejecutivo deben tener la administración y control directo sobre Cornershop e integrar esta compañía
al negocio de Walmart, compartiendo gerencias, activos, bases de datos y actividades de soporte. La
administración de Cornershop por parte de Walmart en una sola gerencia potenciará las sinergias entre ambas
empresas. Cornershop necesita nuestras tiendas para poder dar una última milla de excelencia a nuestros clientes
y nosotros necesitamos a Cornershop para complementar nuestra propuesta no solamente de venta, sino para
entregar un servicio completo al cliente.”
Saliendo al paso de las opiniones del ejecutivo de Walmart, una importante analista del sector de retail online
señalaba que: “Walmart y Cornershop deberían administrarse de manera separada, como dos compañías
independientes. Walmart no debiera administrar de manera integrada su negocio de supermercados con el
negocio de Cornershop recién adquirido. Ello destruirá valor económico para Walmart. La administración
integrada ignora que una serie de condiciones externas del entorno competitivo y también las características de
cada una de las dos compañías involucradas en esta transacción, podrían llevar a que esta adquisición finalmente
termine destruyendo valor económico.”
-----
8
PREGUNTAS
a) Frente a estas dos opiniones encontradas (administración integrada o independiente), el Directorio tiene
dudas de cuál esquema de administración adoptar. En su calidad de experto, el Directorio le solicita a
usted que mencione y describa la principal ventaja y la principal desventaja de la administración
integrada de Cornershop por parte de Walmart, si lo que se pretende es crear valor económico con la
adquisición recientemente realizada.
b) Por otra parte, el mismo Directorio le pide que, considerando como supuesto un eventual escenario de
administración integrada de Cornershop por parte de Walmart, responda lo siguiente: ¿qué condiciones
del entorno competitivo y/o factores internos de las propias compañías involucradas en esta operación
(Walmart y Cornershop), podrían destruir el potencial valor económico de esta adquisición? Mencione
y describa las dos condiciones y/o factores más importantes.
-----
9
. PREGUNTA N%5
La plataforma Uber, que contacta pasajeros y conductores cumple 5 años en Chile, está presente en 26 ciudades
con más de 60 mil conductores y tiene más de 2 millones de usuarios. La competencia más directa es Cabify
que cuenta con 50 mil conductores. Una diferencia importante entre las empresas Uber y Cabify es que la
primera tiene un procedimiento de selección de sus conductores más simple y que sólo requiere una solicitud a
través de Internet; mientras que Cabify requiere además una entrevista presencial en el proceso de selección.
Adicionalmente, Cabify tiene, en promedio, conductores con automóviles más modernos y precios levemente
superiores. A modo de comparación, los taxis de techo amarillo no llegan a 35 mil en todo el país.
Las razones por las cuales estas plataformas de transporte han crecido de manera tan dinámica en los últimos
años son varias. En primer lugar, la alta tasa de bancarización de los chilenos permite pagar los viajes con tarjeta.
En segundo lugar, la alta penetración de teléfonos inteligentes, hace posible que los usuarios gestionen su viaje
y se comuniquen con el conductor. Finalmente, la aplicación otorga certeza en el trayecto y la tarifa.
Adicionalmente, la propuesta de valor para los conductores ha sido exitosa.
La empresa Uber hizo un estudio de Análisis Conjunto!. Para esto seleccionó una muestra de usuarios de su
plataforma a quienes se les aplicó una encuesta para medir las utilidades parciales de atributos en base al método
indirecto (evaluación de perfiles). Los atributos considerados más importantes por estudios previos en clientes
y las utilidades parciales correspondientes al promedio de la muestra se presentan en el Cuadro N*1. Estos
atributos son: (i) el tiempo que demora el automóvil en llegar desde el momento en que el usuario lo solicita,
(ii) la antigiiedad del automóvil, (iii) el desempeño histórico del conductor en base a las encuestas de satisfacción
que completan los usuarios, (iv) si el sistema de postulación de los conductores se realiza íntegramente por
Internet o si la selección requiere además una entrevista presencial y (v) la experiencia del conductor en la
compañía.
Cuadro N*1: Utilidades Parciales de Atributos (Promedio de la Muestra)
Atributo Niveles
Tiempo Demora Llegada (min.) i 5 min. | 7 min, | 10 min,
Utilidad : 0 -2 4
Antigúedad Vehículo (años) Í 061 | 263 | 46 más
Utilidad i 0 “1 ! -2
Desempeño Conductor (Escala 1 a 5) i 5.0 | 4.5 l 4.0
Utilidad o 4 loa
Sistema Postulación Conductor | Internet | Presencial |
Utilidad : oo 3
Experiencia Conductor (meses) i 1mes | 6meses | 12 meses
Utilidad o | 2 | 4
PREGUNTAS
a) ¿Cuál es el principal problema de marketing que enfrenta Uber y que los lleva a hacer este estudio?
¿Cómo podría utilizar Uber los resultados presentados?
b) ¿Por qué Uber hace un estudio de mercado basado en encuestas si dispone de una enorme cantidad de
información detallada de los millones de viajes que realizan los usuarios? Explique.
e) ¿Cuántos perfiles completos, en el modelo de medición indirecta, habría usado usted para estimar las
utilidades en el Cuadro 1? Justifique su respuesta
1 Del inglés “Conjoint Analysis”.
-----
10
3 PREGUNTA N%6
Hoy 31 de diciembre de 2019, la Panquequería “Panqueques de Mora”, presenta el siguiente balance (todas las cifras están
en valor “económico” y expresadas en miles de $ o MS):
Balance en Valor Económico
(31/12/2019)
Pasivos y Patrimonio
Caja 1.500 [Deuda Financiera 4.000
CTNO (distinto de Caja) (Nota 1) 2.500
Edificios y equipos (Nota 2) 4.000 [Patrimonio (Nota 3) 4.000
Total activos 8.000  |Total Pas. + Pat. 8.000
(1): CTNO= Capital de Trabajo Neto Operacional
CTNO = [Activos Corrientes Operacionales (distintos de “Caja”) menos Pasivos Corrientes Operacionales]
(2): Neto de Depreciación Acumulada
(3): Compuesto por 1.000 acciones comunes, a valor de mercado de $4.000 cada una
Justo en la medianoche de hoy, los dueños de “Panqueques de Mora”, han decidido evaluar la posibilidad de abrir una
nueva sucursal, a través de la compra de un nuevo local, también dedicada a la producción de panqueques, la que sería
financiada con recursos propios de la empresa, más un nuevo aporte de capital por parte de los actuales dueños. La siguiente
es la información disponible respecto de las proyecciones de la empresa, con y sin el nuevo local:
Definiciones:
SNL = Proyecciones “Sin Nuevo Local; CNL = Proyecciones “Con Nuevo Local”
Estados de Resultados Proyectados
Panquequería "Panqueques de Mora"
(Montos son en Miles de $)
OOOO | amo200alimfimito | Año2020 al infinito
Ingresos por Venta 10.000 12.000
- Costo de Ventas -6.000| -7.000|
- Gastos de Administración y Ventas [GA V]
GA V Fijos -1.000 -1.000|
GA V Variables -1.300| -1.400|
- Depreciación del Ejercicio [1] [2] -500] -600
= Resultado Operacional 1.200 2.000
- Gastos Financieros -320 -320
= Utilidad Antes de Impuesto 880 1.680
- Impuesto a las Utilidades (25%) -220| -420
= Resultado del Ejercicio (Utilidad Neta A 60| 1.260
(1): El total del “Gasto por Depreciación del Ejercicio” de cada año de la empresa, está reflejado en esta cuenta. Las cuentas “Costo
de Ventas” y Gastos de Administración y Ventas” (GAV), no incluyen gastos por depreciación.
(2): La alternativa o escenario “CNL”, incluye M$100 de gasto por depreciación anual por el nuevo local.
A continuación, se presentan los requerimientos de inversión inicial en caso de comprar el nuevo local o sucursal. Los
requerimientos de inversión inicial se deben desembolsar al momento de la inversión, que en caso de resultar conveniente
el proyecto, se debiera concretar al inicio del 1 de enero de 2020 o T=0:
Inversión Inicial (MS): 1 de enero de 2020 (TI =0)
Se sabe además, que los siguientes son los requerimientos de reinversiones anuales, al término de cada año, tanto para el
caso en que no se abra un nuevo local, como aquel en que se abra un nuevo local:
Reinversión Anual (MS): Fin Año 2020 al Infinito
Sin Nuevo Local (SND)]______60 |
Con Nuevo Local (CNL)
-----
1
Por otra parte, se sabe que los requerimientos de Capital de Trabajo Neto Operacional (CTNO), se deben cumplir o contar
con ellos, al inicio del primer día del año en que se espera se produzcan las ventas que requieren de dicho CTNO. Se ha
estimado que los requerimientos de CTNO, sin el nuevo local (condición “Actual”) y con el nuevo local (CNL), serían los
siguientes:
Monto (stock) de Capital de Trabajo Neto Operacional (CTNO) Requerido
Panquequería "Panqueques de Mora"
(Montos son en Miles de $)
11]: 3/12/2019 (Actual): Corresponde al monto de la Inversión en CTNO que ya tiene la empresa al 31/12/2019.
2]: 31/12/2019 (CNL): Corresponde al monto de la Inversión en CTNO que tendría que tener el 31/12/19,
en caso de adquirir el nuevo local.
BJ: 31/12/20 al infinito (Actual): Corresponde al monto de la Inversión en CTNO que tendría que tener la empresa
al término de cada año, a partir del 31/12/20 y hasta el infinito, SIN un nuevo local.
[4]: 31/12/20 al infinito (CNL): Corresponde al monto de la Inversión en CTNO que tendría que tener la empresa
al término de cada año, a partir del 31/12/20 y hasta el infinito, CON un nuevo local.
El financiamiento del nuevo local, sería del modo siguiente:
[Financiamiento Original (MS 22222222]
Finalmente, se sabe que la empresa ha contratado un asesor, quien evaluará la conveniencia de emprender o no el proyecto,
al cual se le pagará la suma de M$500, en T = 0, es decir, el 1 de enero de 2020.
PREGUNTAS
1. Suponga en primer lugar, que los actuales accionistas o dueños de la empresa, están dispuestos y en condiciones de aportar
los M$1.500 necesarios para invertir en el nuevo local, si dicha inversión resultase conveniente. Se sabe además, que en
dichas condiciones, el Costo de Capital Promedio Ponderado (CCPP) relevante de largo plazo de la empresa, aplicable
también a los activos del nuevo proyecto, es de un 10% anual, después de impuestos. ¿Conviene la adquisición del nuevo
local? Presente ordenadamente, todos los cómputos necesarios para fundamentar su respuesta.
2. Suponga ahora, que por distintas razones, los actuales dueños o accionistas no podrán aportar los M$1.500 de nuevo capital
requerido para la compra del nuevo local y que una alternativa que tendría la empresa para el financiamiento de los
M$1.500 faltantes para la compra del nuevo local, sería obtener un préstamo especial de un banco, atado al proyecto, el
que entre otras características, exigiría el pago anual y de manera indefinida, únicamente de sus intereses. Con esta
información, los dueños han determinado que en caso de usar dicho préstamo para completar el financiamiento, una buena
estimación del CCPP anual, relevante para ser usada en la evaluación del nuevo local, ya no sería del 10%, sino, y debido
a una serie de imperfecciones del mercado de capitales, de un 12,5% marginal, anual, después de impuesto. Con la
información anterior, los actuales dueños, han decidido abrirse a la posibilidad de invitar a una nueva inversionista, para
que aporte como capital los M$1.500 faltantes, en cuyo caso el CCPP relevante para la evaluación de la nueva inversión,
sería el 10% inicialmente estimado. Teniendo presente estas dos alternativas de financiamiento de los M$1.500 (con el
crédito del banco o a través de un aporte de capital de un nuevo accionista), ¿Cuál sería el máximo porcentaje (%) de
la propiedad o patrimonio de la nueva empresa (empresa actual más nuevo local), que los actuales dueños de la
panquequería debieran estar dispuestos a ofrecer a la nueva accionista, a cambio de los nuevos M$1.500 de capital
que ella aportaría?
Suponga que el cambio en el CCPP marginal relevante para la evaluación del nuevo local en caso de usar los M$1.500 del
crédito bancario, no afectaría el valor económico que tenía la empresa, antes de evaluar la posibilidad de invertir en este
nuevo proyecto.
-----


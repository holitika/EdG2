# Examen de grado · Examen-de-Grado-Administracion-Agosto-2022

Fuente: examen anterior

[pág. 1]
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
 alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
 hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
 hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
 que los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
 realidad de las empresas que allí se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
 dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
 misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente a la Profesora Marta Del Sante, Presidente de la Comisión
 de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
 cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
 condiciones, la Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala ni relojes inteligentes, los que
 deberán estar apagados y guardados en las mochilas.
12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
 examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
 identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
 como “borrador”, esas hojas no se deben entregar con las respuestas.
Fecha : 12 de agosto de 2022
Duración : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá la Profesora
 Marta Del Sante, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 y
 11:00 hrs. (aprox.).

[pág. 2]
2
PREGUNTA Nº1
SMU, holding de distintos formatos supermercadistas, presentó hace un año, Super10, un nuevo formato de
supermercados que surge con el concepto de “soft discount”. ¿Qué significa ser un supermercado soft discount?
El formato soft discount se caracteriza por ser un supermercado entre 1.200 a 1.500 metros cuadrados, que
ofrece precios más bajos en relación a un supermercado tradicional y dónde el 40 a 50% de los productos son
de marca propia, a diferencia de un supermercado tradicional dónde representan un 15% aproximadamente. Con
esta inauguración, Super10 se incorpora al portfolio de SMU, supermercadista con cobertura geográfica
presente en las 16 regiones de Chile, y que cuenta con Unimarc, Unimarc.cl, Alvi y Mayorista10. Este nuevo
formato soft discount de supermercados ofrece un surtido más limitado de productos para las familias, a bajos
precios relativos a la cadena Unimarc.
 Si bien no todas las marcas de cada categoría están presentes en Super10, están las
 más populares y de alta rotación, junto con las marcas propias de la cadena. En ese
 sentido, Marcelo Gálvez, Gerente General de SMU, reveló los beneficios que ofrece
 este modelo a los consumidores. “Permite una operación más rápida y más simple.
 Toda esa eficiencia se traspasa a precios, así que finalmente el cliente encuentra de
 todo, con buena calidad y a precios súper económicos”, sostuvo.
 De acuerdo al Gerente General, este nuevo formato, a diferencia de Alvi y
 Mayorista10, busca que los clientes sean los consumidores finales y reforzar la
 presencia de marcas propias. En el caso de Alvi, éste se caracteriza por ser es un
supermercado de autoservicio mayorista para comerciantes, que también atiende a consumidores finales que
compran grandes volúmenes. Este formato se caracteriza por no vender productos en forma unitaria, por ejemplo
un empaque de shampoo, sino que cajas de 6 ó 12. Lo mismo ocurre con todo el resto de las categorías de
productos. Por su parte, Mayorista10 se focaliza 100% en comerciantes que luego revenden esos productos en
sus propios locales (por ejemplo una pequeña tienda de abarrotes de barrio se abastece de productos en locales
como Mayorista10). En Super10 el mercado objetivo es el cliente final y no los comerciantes.
De acuerdo a Nicolás Delsol, gerente de Super10, “se busca entregar una nueva propuesta de valor centrada en
el cliente, brindando una buena experiencia de compra con un surtido optimizado que permite la adquisición
completa de productos como panadería, abarrotes, perecibles, perfumería, frutas y verduras, ya sea para
abastecimiento o reposición para el hogar. Es una tienda centrada totalmente en garantizar al cliente una compra
rápida”. El tamaño de las tiendas es de alrededor de 1.300 metros cuadrados, lo que se compara con los
supermercados Unimarc que tienen un tamaño medio de 3.000 metros cuadrados, siendo el de mayor tamaño
de cerca de 6.000 m2. Agregaba el gerente, “las cajas de checkout (de pago) están diseñadas para un pago ágil
y práctico, las góndolas no superan una altura de 1,65 metros, para estar al alcance de todos los clientes e
incorpora una etiqueta de precio de fácil lectura. Además, se exhibe el 100% del stock disponible a la venta, por
lo que no existen bodegas. Los camiones de reposición llegan con carga y ésta es dispuesta inmediatamente en
tienda”.
Los principales competidores de SMU, Walmart y Cencosud cuentan también con distintos formatos de
supermercados. En el caso de Walmart, tiene: los supermercados Líder, los cuáles compiten con Unimarc. Este
formato se caracteriza por ofrecer una amplia gama de categorías, abarcando desde productos comestibles hasta
otros como hogar, electrónica, juguetería y vestuario con marcas de diferentes proveedores y contando además
con productos de marca propia, nacionales e importados; Super Bodega aCuenta, el cual se caracteriza por
ofrecer sólo productos comestibles, foco en marcas propias y locales de menor tamaño y bajo costo de operación,
lo que le permite ofrecer precios bajos relativos a sus otros formatos; y finalmente, con Central Mayorista, el
cual se focaliza en comerciantes y HORECA (Hoteles, Restaurantes y Casinos), de manera de ofrecerle a estos
segmentos lo que necesitan en un solo lugar, y a precios bajos relativos a la venta al detalle, generando una
experiencia de compra rápida, simple y conveniente en sus locales. Cencosud por su parte, cuenta con:
Hipermercados Jumbo, el cual compite con Líder y Unimarc; con el supermercado de tamaño medio, Santa
Isabel, un formato económico que atiende a clientes finales; y, el formato Spid35, el cual está enfocado en
compras express, para ocasiones de consumo no planificadas y de conveniencia. Su propuesta de valor está

[pág. 3]
3
pensada en ofrecer despachos rápidos en menos de 35 minutos en compras por web, tiendas de menor tamaño
y surtido de alta rotación. Sus principales competidores son las tiendas de conveniencia de Oxxo y OK Market.
Super10 tiene una mayor presencia de marcas propias de SMU en las góndolas que en los otros formatos de
SMU. En cada categoría ofrece una marca de un proveedor líder más su marca propia. En ese sentido, el grupo
supermercadista está potenciando nuevas marcas propias con precio inferior a la marca del proveedor líder.
“Nosotros partimos este año cambiando la estrategia. Ahora desarrollamos marcas por agrupación de productos.
En abarrotes tenemos la marca “Nuestra Cocina”, para artículos de limpieza está “SmartClean”, “Fundo Río
Alegre” en carnicería, y en panadería-pastelería, contamos con “Amada Masa”. Estas son marcas transversales
que vendemos en todos nuestros formatos”, explicó Marcelo Gálvez, gerente general de SMU.
El tema de las marcas propias de los distribuidores ha sido recurrente desde hace mucho tiempo en nuestro país
al igual que en el resto del mundo, mostrando un crecimiento sostenido en los últimos años. Estas categorías de
productos con marcas propias son, por lo general, producidas por pequeños proveedores que operan en nuestro
país. Desde el punto de vista de los consumidores, el atributo más valorado, entre quienes consumen marcas
propias, es su precio más bajo, relativo a las marcas reconocidas de proveedores.
Preguntas:
1. Desde el punto de vista comercial, señale y explique claramente los tres argumentos principales que
 justifiquen la decisión de SMU de incorporar esta nueva marca Super10 y formato soft discount a su
 portfolio.
2. Señale y explique tres desventajas de potenciar las marcas propias de SMU en su formato Super10 por
 sobre las marcas de proveedores.

[pág. 4]
4
PREGUNTA Nº2
LizTaylor es una empresa chilena de tamaño mediano que diseña, importa y distribuye muebles listos para
 1
armar . La empresa tiene acuerdos con fabricantes extranjeros para la producción de las distintas partes y piezas
que luego el consumidor final ensambla en su hogar. LizTaylor fue fundada en 2009 por Igor Robles, dueño y
gerente general de la empresa, quién recientemente declaraba:
 “Nuestros productos apuntan a acompañar a través de sus diferentes etapas del ciclo de vida al
 segmento de profesionales: primer hogar, vida en pareja, llegada y crecimiento de los hijos, nido
 vacío (los hijos ya adultos se van de la casa) y adultos mayores autovalentes que viven solos de
 manera permanente.”
Durante toda esta trayectoria vital, LizTaylor se orienta a clientes de ingresos medio-altos, que aprecian los
diseños atractivos, la buena relación precio-calidad, un excelente servicio de postventa en caso de devoluciones
y reparaciones y una asesoría personalizada para ayudar a sus clientes en el armado de sus muebles, luego de
constatar en Chile una cultura aun poco desarrollada en cuanto a las manualidades y reparaciones en el hogar.
Los clientes de LizTaylor aprecian también la utilización de materiales reciclables asociados a su preocupación
por el cuidado del medio ambiente.
Cuando se fundó la empresa, los muebles listos para armar eran una novedad en el mercado chileno y tuvieron
un éxito mucho mayor a lo que Igor esperaba. La aceptación de la propuesta de valor al cliente que ofrecía la
compañía le permitieron un fuerte crecimiento en ventas y utilidades entre 2010 y 2019. Durante esa década la
empresa aumentó su dotación de 50 a 800 trabajadores. Ellos son, prácticamente en su totalidad, profesionales
calificados con un título técnico avanzado o universitario, de entre 24 y 42 años, que como parte de su
generación aspiran a “dejar huella” en la sociedad a través de su trabajo, pretenden disfrutar de una buena calidad
de vida material y emocional, valoran alcanzar mayores logros académicos y profesionales y que dichos
esfuerzos sean reconocidos.
A partir de 2020, con el inicio de la pandemia y una necesaria mayor permanencia y trabajo en el hogar, se
generó un incremento importante en la demanda por los muebles listos para armar. Desafortunadamente,
LizTaylor no ha aprovechado este incremento de las preferencias de los consumidores de este tipo de muebles.
De hecho, las ventas de la compañía chilena han caído en los últimos dos años. Sumado a lo anterior, la situación
competitiva ya no es la misma que en años previos. Recientemente han entrado al mercado varias marcas
competidoras y en julio de 2022 inició sus operaciones Akilisto, la compañía finlandesa líder mundial en
muebles listos para armar. Esta empresa ha salido a contratar alrededor de 600 trabajadores para sus primeras
tiendas según lo anunció su gerente general para Chile hace solo unos días, declarando que:
 “En Akilisto ofrecemos oportunidades de aprendizaje y desarrollo. Creemos en la enorme
 experiencia previa en el sector, capacidad y el gran potencial que pueden seguir desarrollando
 nuestros colaboradores, por lo que los animamos a probar diferentes roles y a cambiar de funciones
 para que adquieran e incrementen su experiencia.”
La compañía finlandesa se caracteriza por su “diseño escandinavo” mundialmente reconocido de líneas simples
y cálidas, precios muy convenientes y un servicio de postventa más bien estándar ya que confía en que sus
clientes pueden seguir fácilmente las instrucciones que acompañan sus productos y “sentirse orgullosos de armar
sus muebles con sus propias manos”, como declaraba hace unas semanas un ejecutivo de marketing de la
empresa. Para sostener su propuesta de valor la empresa Akilisto ha mostrado prácticas de gestión de personas
que son muy atractivas para los trabajadores en todos los ámbitos: un alto nivel de remuneración fija en relación
a los incentivos variables por desempeño, flexibilidad laboral, buenas condiciones para el trabajo remoto,
desarrollo profesional del personal y preocupación por el bienestar integral de las familias de sus trabajadores.
En el ámbito laboral, la rotación voluntaria de LizTaylor, al igual que en la gran mayoría las empresas del retail
a nivel nacional y global de la industria, han ido en aumento, tal como lo indica el siguiente gráfico.
1 El cliente compra en la tienda una caja con todos los componentes junto a las herramientas e instrucciones para su armado. Este es un proceso fácil y
amigable y no requiere de mayores conocimientos ni fuerza física para su ensamblaje.

[pág. 5]
5
 Rotación voluntaria (no despidos)
 25%
 20%
 15%
 10%
 5%
 0%
 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019 2020 2021
 Rotación voluntaria de LizTaylor Rotación voluntaria de del sector retail
Preocupado por los resultados económicos y también por los niveles de rotación de 1los últimos dos años de
LizTaylor, Igor encargó un estudio de satisfacción con el trabajo mediante encuestas tanto a ex-trabajadores
que renunciaron en los últimos dos años y también al personal que actualmente se desempeña en la empresa.
Los resultados
 2
 se presentan en las siguientes tablas, en donde aparecen los promedios de las respuestas
obtenidas . Él pensaba que, tal vez, las prácticas de gestión de personas y la relación que estas habían
conformado entre la compañía y sus empleados habían perdido vigencia. Por otro lado, no estaba seguro ya que,
reflexionaba: “aquí pagamos bien, más bajo que la competencia en el componente fijo, pero un muy alto
incentivo variable por productividad que premia el esfuerzo de cada trabajador”
Dada su preocupación por la caída en resultados e incremento en la rotación, Igor Robles le consulta a usted en
su calidad de experto en gestión de personas, lo siguiente:
1. ¿Qué tipo de relación, vínculo o contrato psicológico ha desarrollado LizTaylor con sus trabajadores en el
 tiempo? ¿Es el más apropiado de acuerdo al modelo de negocio que apunta a desarrollar LizTaylor?
 Justifique su respuesta con antecedentes concretos del caso.
2. Considerando el diagnóstico realizado, proponga los tres cambios más importantes que LizTaylor debe
 realizar en sus prácticas de gestión de personas para mejorar su situación y alcanzar sus objetivos
 estratégicos. Explique, específicamente, cómo los cambios propuestos pueden mejorar la situación
 competitiva de la empresa y la satisfacción/disminución de la rotación de sus trabajadores.
1 El estudio realizado cuenta con todas las características metodológicas que aseguran su representatividad, validez y confiabilidad.
2 Las desviaciones estándar en todos los casos son bajas.

[pág. 6]
6
PREGUNTA Nº3
Suponga que la empresa minera “Último Año” tiene al día de hoy, 1 de enero de 2023, sólo dos activos: el
primero de ellos, es un activo actualmente en operaciones al que le queda un solo año de vida (se termina el
31/12/2023) y cuyo flujo de caja de éste, su último año de operación, es completamente incierto; el segundo
activo es una inversión en caja.
Primer activo: el negocio actualmente en operaciones:
Respecto del primero de los activos, el negocio actualmente en operaciones, las estimaciones de generación de
flujo de caja neto operacional para el año 2023, muestran que se podría dar uno de sólo dos posibles resultados.
Si el escenario del año que comienza hoy (año 2023) resulta ser un “buen año” para la economía, se espera que
dicho activo genere un flujo de caja (al término del año) de $80. Si por el contrario, el año que comienza hoy
resulta ser un “mal año” para la economía, se espera que dicho activo genere un flujo de caja (al término del
año) de $0. No hay más flujos de caja después del año 2023 y cada uno de los dos posibles escenarios (“buen”
o “mal” año para la economía) tiene una probabilidad de ocurrencia de 50%
Segundo activo: caja
Este segundo activo, corresponde a $10 que actualmente (1/1/2023) la empresa mantiene en caja.
Financiamiento actual de la empresa:
En este momento, 1/1/2023, la empresa está financiada con una combinación de deuda y patrimonio. La única
deuda que mantiene la empresa es una deuda financiera cuyo saldo por amortizar en el día de hoy (1/1/2023) es
de $30, que no devenga intereses, y que vence el 31/12/2023, una vez conocidos los flujos de caja que pudieran
generar los activos de la compañía.
Posibilidad de desarrollo de un nuevo proyecto de inversión:
Adicionalmente se sabe que hoy 1 de enero de 2023, la empresa podría invertir en un nuevo proyecto el que
requeriría de una inversión inicial de $10 y tendría una duración de un año, es decir, se invertiría hoy 1 de enero
y generaría un único flujo de caja el 31/12/23. Si el año que comienza hoy (año 2023) resulta ser un “buen año”
para la economía, se espera que este nuevo proyecto genere un flujo de caja neto operacional (al término del
año) de $15. Si por el contrario, el año que comienza hoy resulta ser un “mal año” para la economía, se espera
que este nuevo proyecto genere un flujo de caja (al término del año) de $0. Las probabilidades de “buen año” y
de “mal año” de la economía para el año 2023, siguen siendo de 50% para cada escenario.
Algunos supuestos:
 • Suponga que todos los agentes son neutrales al riesgo y que la tasa de descuento relevante para todos y
 cada uno de los flujos de caja presentes en el ejercicio (flujos generados por activos, deuda o patrimonio)
 es de 0% anual.
 • Suponga que la tasa de interés que las instituciones financieras pagan por depósitos a plazo es de un 0%
 anual (es decir, no hay una pérdida para la empresa si ella mantiene la caja guardada).
 • No hay inflación, impuestos ni costos de transacción.
 • Suponga que todo lo relacionado con esta empresa termina el 31/12/2023, es decir, suponga que todo
 dura un solo período.
 • Si al término del año la empresa dispusiera de caja para repartir a sus dueños, ella sería repartida a sus
 dueños en la forma de un dividendo en efectivo.
 • Respecto de los $10 que la empresa mantiene en caja en este momento (1/1/2023), suponga que:
 - Ellos pueden ser usados únicamente para el financiamiento del nuevo proyecto en el caso en que
 ella se decida a emprenderlo o para el pago de sus deudas financieras en el momento en que la
 empresa lo estime conveniente.
 - La empresa no puede usar esos $10 para ningún otro fin que no sea alguno de los dos indicados
 anteriormente. Si la empresa no emprende el nuevo proyecto, esos $10 deben quedar en caja hasta
 el término del año.
 • Suponga que durante el año 2023 la empresa no emitirá nueva deuda ni habrá nuevos aportes de capital.

[pág. 7]
7
Se Pide:
1. Usando la información entregada en la pregunta, determine el valor económico del patrimonio o valor
 presente del patrimonio de los dueños de la empresa al 1/1/2023 sin considerar el nuevo proyecto de
 inversión.
2. El Directorio de la empresa debe decidir si usar o no los $10 de caja de que dispone para financiar el nuevo
 posible proyecto de inversión. Desde una perspectiva únicamente financiera y por lo tanto en el contexto
 de accionistas o dueños que buscan maximizar el valor económico de su patrimonio, ¿Debiera la empresa
 emprender el nuevo proyecto de inversión? Fundamente numéricamente su respuesta.
3. Suponga que el Banco está pensando en hacer una oferta a la empresa, consistente en un descuento por la
 deuda que ésta tiene con el Banco. Esta oferta consistiría en que si la empresa le prepaga hoy (1/1/2023) al
 Banco $10 de la deuda que vence el 31/12/2023 (esto es, si la empresa le prepaga antes de saber si el
 escenario del año 2023 ha de ser de un “buen” o un “mal” año para la economía y por lo tanto para las
 inversiones de la empresa y antes de que ella haya decidido si hacer o no el nuevo proyecto de inversión)
 el Banco le reduciría el valor a pagar por la deuda el 31/12/2023. Se sabe entonces que si la empresa hace
 el prepago al Banco usando los $10 de que dispone el 1/1/2023, ella no podría emprender el nuevo proyecto
 de inversión.
 ¿Cuánto es el monto máximo (en pesos) que el Banco debiera estar dispuesto a ofrecer a la empresa como
 descuento en el monto de $20, que la empresa le quedaría debiendo al Banco con vencimiento a fines del
 año 2023 para saldar completamente su deuda, si hoy (1/1/2023) ella le prepaga al Banco los $10?
 Fundamente numéricamente su respuesta.

[pág. 8]
8
PREGUNTA Nº4
Google es mucho más que un buscador. Es una empresa que compite en diferentes ámbitos y que enfrenta
diversos competidores de la talla de Microsoft, Apple, Yahoo y Amazon, dependiendo del servicio o producto
del que estemos hablando. Sus resultados netos al cierre del 2021 superaron los 40 mil millones de dólares, un
18% superior al 2020. Lo anterior se explica por la alta demanda por sus servicios en un escenario aun de
pandemia, y la mejora de ingresos en varios de los segmentos de negocio en donde compite.
El negocio de Google
La compañía se hizo mundialmente conocida por su famoso buscador de internet (o Google Search), siendo hoy
en día el principal buscador del mundo (participación de mercado de 92%). La compañía además cuenta con
una sorprendente lista de servicios, y en algunos casos negocios, con diferentes características y funcionalidades,
algunos de los cuales van dirigidos a personas y otros a empresas. Además del buscador, Google cuenta con
Youtube, Google Drive, Google Cloud, Gmail y Google maps entre otros.
Las fuentes de ingresos de Google
Los principales ingresos de la compañía provienen de la venta de publicidad digital a empresas, que facturó 149
mil millones de dólares en 2021. La publicidad se realiza directamente en el buscador o en los videos de
Youtube. Otra fuente importante de ingresos es Google Cloud que entrega servicios a personas y a empresas.
El servicio dirigido a personas entrega almacenamiento gratuito en la nube hasta cierta cantidad de GB, debiendo
pagar para almacenamientos superiores. Para empresas, el servicio es más sofisticado ya que ofrece servidores
remotos, seguridad informática y servicios de tecnología en la nube como el “Análisis de Datos de Personas y
Consumidores”, que entrega información procesada de clientes y conductas de compra de consumidores
digitales. Desde luego, mientras más usuarios existan en el sistema Google, mayor valor tendrá la información
que se entrega. También se generan ingresos con Soluciones creadas para smartphones, tabletas, laptops, y con
Google Playstore, que provee de juegos y entretenciones, gratis en niveles básicos y con un cobro en niveles
más sofisticados. Finalmente, están los contenidos premium en Youtube, que permite disfrutar de videos sin
interrupción de publicidad a cambio de un pago de US$11 por mes.
El Modelo de Negocio de Google
Se basa en dos aspectos fundamentales: por un lado el buscador, que organiza la información con su algoritmo,
de forma rápida y precisa, generando información útil para quien la solicita y accediendo a un número de páginas
web muy superiores en relación a otros buscadores. Este conjunto de atributos lo transforma en el mejor
buscador del mundo. El segundo aspecto fundamental de su modelo de negocio, es la plataforma de publicidad
que ofrece para una importante cartera de anunciantes, lo que le permite a Google financiar inversiones y
mejoras al buscador y su plataforma de productos, solventar la gratuidad que se entrega a los usuarios y generar
ingresos para el negocio.
Los dos aspectos anteriores requieren de un complemento que resulta fundamental para la generación de valor
en el negocio de Google: el desarrollo comercial, de productos y de servicios. En efecto, la generación continua
y creativa de productos y servicios incentivan al mayor uso del buscador, y al mismo tiempo hace que más
personas lo quieran utilizar. Por tal motivo, la compañía invierte en desarrollar aplicaciones, soluciones e
infraestructura tecnológica, gratuitamente hasta cierto nivel de servicio, mejorando la experiencia del usuario
con Google y facilitando que quienes utilicen Google se multipliquen día a día.
La Innovación en Google
No cabe duda que la innovación es importante en Google, aunque los realmente importante son quienes la
realizan: los propios empleados de Google o en el lenguaje interno de la compañía, los “Googlers”. Según el
presidente de Google, la compañía contrata a los “mejores del mundo, gente inteligente, original y creativa”.
En los procesos de selección están presentes los futuros compañeros y jefes, y así se ven otros puntos de vista.

[pág. 9]
9
Google cuida mucho a sus trabajadores razón por la cual sus prácticas de gestión de personas son admiradas y
destacadas en el mundo entero. Entre ellas cabe destacar las diversas entretenciones y juegos con que cuenta en
las zonas de trabajo, gimnasio, comida gratis, entre otras. Una especial mención requiere el programa “20%
Time Program”, que permite a los “Googlers” utilizar una parte de su tiempo de trabajo (un día por semana) en
proyectos propios enfocados en algo que a la persona le apasione, pudiendo utilizar la estructura y los recursos
de la empresa para avanzar. Esto estimula la creatividad, la motivación y el buen ambiente desde donde puedan
surgir buenas ideas incluso para la propia compañía. También se destaca el programa de objetivos, el sistema
de incentivos, y muchas otras iniciativas focalizadas en hacer de Google un logar atractivo para los googlers.
No cabe duda que Google es una empresa admirada, y siempre se destaca en cualquier espacio donde se discuta
el sector y el futuro. Un ejemplo de lo anterior se dio en la última convención mundial de empresas de tecnología,
donde el prestigioso analista George Derek, señaló en parte de su exposición lo siguiente:
 “Google es una compañía cuidadosa y creativamente diseñada. Los dos aspectos centrales de su modelo de
 negocio (el buscador y la plataforma de publicidad) generan la energía necesaria para construir su base de
 negocio. Estos dos elementos se encuentran entrelazados en un perfecto círculo virtuoso que genera las
 condiciones necesarias para la creación de valor de la empresa. El éxito final dependerá de la creatividad e
 innovación con que finalmente Google desarrolle su negocio”.
Preguntas:
 1. ¿Podría explicar el comentario del analista George Derek? En concreto se pide que desde el punto de
 vista de sus conocimientos de estrategia, explique los siguientes dos aspectos:
 a. ¿Por qué el analista señala que “los dos aspectos centrales de su modelo de negocio (el
 buscador y la plataforma de publicidad) generan la energía necesaria para construir su base
 de negocio”? Sea preciso.
 b. ¿Por qué el analista dice “el éxito final dependerá de la creatividad e innovación con que
 finalmente Google desarrolle su negocio”? Sea preciso.
 2. Analice la Ventaja Competitiva Corporativa de Google. Señale cuál es, por qué tiene sentido hablar
 de Ventaja Competitiva Corporativa y no por Unidad de Negocio, y si le parece que es o no sostenible.

[pág. 10]
10
PREGUNTA Nº5
De acuerdo con datos de Euromonitor1 (www.euromonitor.cl), Chile es el líder en el consumo de helados en
Latinoamérica, con 7,7 litros por persona al año. Las ventas en la región han crecido en los últimos cinco años
un 52%.
En este mercado se aprecia una tendencia importante hacia un consumo más premium, sofisticado y artesanal.
Los consumidores se fijan cada vez más en la calidad, y por lo tanto muchos están dispuestos a pagar más por
productos con mejores ingredientes, como leche líquida en vez de en polvo, trozos de frutas y frutos secos
naturales y sin grasas saturadas y trans agregadas.
El formato cassata o familiar (envase de aproximadamente 1 litro) ocupa el primer lugar en el consumo de
helado de los chilenos, con un 56%. Tras este formato, los helados premium (20,4%) y los postres y tortas
(18,9%) son los que presentan la mayor demanda en el mercado local. El mercado actual de helados está liderado
por Savory, que ocupa el 42% de participación de mercado, seguido por Bresler, con el 24%, y San Francisco
de Loncomilla con el 15%.
El fabricante de los helados San Francisco de Loncomilla, quiere estudiar las conductas de compra de los
consumidores de helados en formato cassata o familiar para implementar acciones orientadas a aumentar su
participación de mercado. Para esto utiliza un panel de 400 consumidores en el cual se registran mediante un
scanner las compras de helados tipo cassata en el canal supermercado durante un año. Para cada compra de un
helado cassata se registra la marca, el precio pagado en miles de pesos, si el producto está en display2 en un
espacio destacado del supermercado y si se han distribuido en la sala de ventas flyers o folletos promocionando
el producto. Estas dos últimas variables tienen la forma si/no correspondiente a los valores 1 y 0
respectivamente. Además, se consideran en el modelo las constantes de marca.
La tabla siguiente muestra la estimación de un modelo de regresión logístico (logit) para explicar la elección de
marca en esta categoría, en función de las variables independientes mencionadas. La marca considerada como
base es San Francisco. El Modelo 1 en la tabla considera sólo las constantes de marca y el Modelo 2 agrega las
otras variables definidas.
 Estimaciones Modelo Logístico Elección de Marca
 Modelo 1 Modelo 2*
 Error Error
 Variable Coeficiente t** Coeficiente t**
 Estándar Estándar
 Precio (miles $) -1.25 0.18 -6.9
 Display (0/1) 0.88 0.46 1.9
 Flyer/Folleto (0/1) 0.19 0.05 3.8
 Constante Savory 0.84 0.25 3.4 0.83 0.39 2.1
 Constante Bresler 0.73 0.23 3.2 0.44 0.25 1.8
 (*) Pseudo R2 = 68%
 (**) Estadístico t igual a coeficiente dividido por error estándar
Suponga que en el formato cassata o familiar sólo existen las tres marcas consideradas en el estudio. Responda
las siguientes preguntas.
a) ¿Qué información relevante para la toma de decisiones de marketing puede ser obtenida de los modelos
 presentados en la tabla? Sea específico en su respuesta.
1 Los datos que se presentan en esta pregunta no necesariamente son reales.
2 Display es un espacio en el local que paga el proveedor para exhibir en forma destacada y temporal un producto adicional
a su espacio normal en la góndola.

[pág. 11]
11
b) ¿Qué le recomendaría usted a San Francisco de Loncomilla, si esta marca quiere aumentar su participación
 de mercado: disminuir el precio en $1 mil pesos o poner los helados San Francisco en display? Explique
 su recomendación.
c) ¿Qué crítica(s) se le podría hacer a los datos utilizados y a la metodología implementada en el estudio
 considerando la categoría helados analizada? Explique su respuesta.

[pág. 12]
12
PREGUNTA Nº6
A continuación, se presenta un gráfico que muestra la evolución, durante la crisis del COVID - 19 en el año
2020, del conocido índice accionario S&P 500 (Standard and Poor’s 500) y el indicador de volatilidad esperada
conocido como VIX:
 S&P 500 y VIX
 5.000 70
 4.500 60
 50
 4.000
 S&P500
 VIX (%)
 40
 3.500
 30
 3.000
 20
 2.500 10
 2.000 0
 dic-19 feb-20 abr-20 may-20 jul-20 sept-20 oct-20 dic-20
 S&P500 VIX
El eje vertical izquierdo del gráfico muestra el valor del índice accionario S&P 500, medido en dólares, cuya
evolución, entre diciembre del año 2019 y diciembre del 2020, se exhibe a través de la línea continua en el
gráfico. Este índice es proporcional al valor de mercado de las 500 empresas más importantes (grandes) de
EE.UU. Estas empresas representan, aproximadamente, la mitad de la capitalización bursátil mundial. El S&P
500 es un índice ampliamente diversificado y tiene una correlación de 0,99 con el índice accionario del
portafolio mundial. De hecho, durante la crisis del COVID – 19 en el año 2020, el portafolio mundial se
comportó de manera prácticamente idéntica al S&P 500.
El eje vertical derecho del gráfico muestra la evolución, entre diciembre del año 2019 y diciembre del 2020, del
índice VIX, a través de la línea discontinua que se exhibe en dicho gráfico. El VIX es un indicador de volatilidad
esperada (desviación estándar anualizada), que se deriva de los precios de las opciones sobre el S&P 500.
Concretamente, el VIX mide la volatilidad anualizada implícita que el mercado espera en el futuro, para los
retornos del S&P 500.
La epidemia del Coronavirus se inició en China a fines del año 2019. El primer caso de COVID - 19 que se
confirmó fuera de China, fue el 21 de enero de 2020. De allí en adelante, el virus comenzó a esparcirse por el
mundo.
Para efectos de responder las preguntas que se formulan a continuación, suponga que las personas optimizan en
base a media-varianza, que poseen horizontes de inversión relativamente cortos, es decir, de alrededor de un
año y que sólo invierten en activos financieros transables.
a) Al analizar el gráfico del enunciado, el Analista Uno comentaba: “esta relación aparentemente inversa que
 se observa entre el nivel del índice S&P 500 y la volatilidad (VIX) tiene poco sentido y es difícilmente
 coherente con la idea de los mercados eficientes. Todo el mundo sabe que lo pertinente no es la volatilidad
 total, que incluye un componente idiosincrático (riesgo propio o único), sino el riesgo sistemático, no
 diversificable (riesgo de mercado). Por lo tanto, uno no debería esperar encontrarse con esta relación
 inversa.” ¿Está Ud. de acuerdo con los comentarios del Analista Uno? Fundamente su respuesta en forma
 breve y precisa.

[pág. 13]
13
b) Por su parte, el Analista Dos comentaba: “la evidencia demuestra que el mercado accionario claramente
 sobrereaccionó. De hecho, entre diciembre de 2019 y marzo de 2020 el S&P 500 cayó un 30%
 aproximadamente. Esto fue obviamente una sobrerreacción a un evento que se sabía que tendría que
 superarse, tal como ha ocurrido en tantas otras crisis que han afectado a la humanidad. De hecho, tan solo
 2 meses después de marzo de 2020, el índice S&P 500 ya había retomado su valor inicial, para seguir
 subiendo hasta fines de año. Más aún, desde su punto mínimo hasta el final del año 2020, el mercado subió
 un 63%. ¡Nadie puede creer en la hipótesis de mercados eficientes!” ¿Está Ud. de acuerdo con las
 aseveraciones del Analista Dos? Argumente su respuesta, en forma breve y precisa.
c) El Analista Tres a su vez comentaba: “creo que el Analista Dos tiene razón en cuanto a que hubo una
 sobrerreacción en el mercado accionario el año 2020. Para ahondar en ese punto, fíjense que el valor del
 índice S&P 500 debería ser proporcional al valor presente de los flujos de caja que se espera, generen en el
 futuro, las 500 empresas incluidas en dicho índice. Nadie puede realmente creer que el valor esperado de
 los flujos de caja futuros cayera un 30% a perpetuidad en un mes o en un mes y medio. Esto es absurdo. Es
 equivalente a una destrucción permanente de la riqueza de 30%. Ni una guerra mundial causa esto.” ¿Está
 Ud. de acuerdo con las afirmaciones del Analista Tres? Fundamente su respuesta, en forma breve y precisa.

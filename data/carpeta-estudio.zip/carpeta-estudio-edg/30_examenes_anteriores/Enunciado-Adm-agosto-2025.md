# Examen de grado · Enunciado-Adm-agosto-2025

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


2
TER
MA a
ei ESCUELA DE ADMINISTRACIÓN
ESAS) FACULTAD DE ECONOMÍA Y ADMINISTRACIÓN
ES
EXAMEN DE GRADO
Ingeniería Comercial
Mención: Administración de Empresas
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el alumno
deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos hojas que
sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar hojas adicionales.
No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder no está permitido usar el reverso de las hojas ni una tercera hoja (sólo las 2 hojas recibidas).
4. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga que los
datos que ha recibido están correctamente calculados y que no han sido tergiversados.
5. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la realidad
de las empresas que allí se mencionan.
6. — Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados dichos
: supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
7. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la misma
ponderación al momento de ser evaluadas.
8. Las preguntas de enunciado se podrán hacer solamente al Profesor Julio Gálvez, Presidente de la Comisión de Examen
de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
9. NO está autorizado el uso de calculadoras que permitan almacenar "textos” (calculadoras alfanuméricas, etc.). El
cumplimiento de esta norma es de absoluta responsabilidad del alumno.
10. Usted NO debe escribir su nombre en las hojas de respuesta.
11. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas condiciones, el
Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
12, No está permitido el uso, para fin alguno, de teléfonos celulares en la sala ni relojes inteligentes, los que deberán estar
apagados y guardados en las mochilas adelante.
13. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el examen.
14. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han identificado
con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar como “borrador”, esas
hojas no se deben entregar con las respuestas.
——___ _— —_—_ — _——
Fecha : 8 de agosto de 2025
Duración : 9:00 horasa 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el Profesor Julio Gálvez,
en forma individual, entre las 9:30 y 9:50 hrs. (aprox. , y luego entre las 11:00 y 11:20 hrs. (aprox.).
02 OOQOQÓOAOÓA — 0 —  _—___  __ —_ —_—_—22 _  ——
-----
PREGUNTA N*1
En el competitivo mercado global de zapatillas deportivas, dominado históricamente por gigantes como Nike y
Adidas, pocas marcas emergentes han logrado abrirse camino. La suiza On, fundada en 2010, es una de esas
excepciones. En menos de 15 años, On pasó de ser una “startup” con un producto experimental a una marca
global valorada en más de 11.000 millones de dólares, con presencia en más de 80 países.
. La historia de la marca suiza On comenzó en 2010, cuando tres
AS amigos -—Olivier Bernhard, Caspar Coppetti y David
o , Allemann— decidieron reinventar la experiencia de correr. La
1d Jl 8 motivación surgió de una búsqueda personal por mejorar la
e a sensación del running, protegiendo las articulaciones y ofreciendo
o io un mayor confort. Su primer prototipo, bautizado informalmente
a e > como “Frankenstein”, incorporaba trozos de manguera en la
suela, buscando crear aterrizajes suaves y despegues potentes. Aunque visualmente poco atractivo, el concepto
fue revolucionario y rápidamente ganó el premio ISPO BrandNew ese mismo año, marcando el inicio del
posicionamiento diferencial de la marca.
Desde el inicio, On eligió un camino diferente a los de Nike Y MUS
Adidas. Mientras estas marcas se construían alrededor del alto (a lr
rendimiento competitivo y del estilo urbano, respectivamente, Y a
On apostó por la comodidad, la innovación tecnológica y la PMA" Ab A e yd )
sustentabilidad. Su tecnología patentada, CloudTecB*, permite [AN NX a. O
una experiencia de carrera que se describe como “correr sobre O me ¿MA
nubes”, enfocada en reducir el impacto en las articulaciones. a A e -— A TN
Así, On se posicionó como una marca premium orientada a Pl có dis
corredores serios y conscientes del medioambiente, dispuestos a AA ñ O naadk:
pagar por una experiencia distinta que combina ciencia, confort y responsabilidad social.
Durante sus primeros años, On creció consistentemente, ganando adeptos entre atletas amateurs avanzados y
profesionales que valoraban su propuesta. La marca reforzó su imagen con evidencia científica sobre beneficios
fisiológicos (como menores niveles de lactato? y frecuencia cardiaca durante el ejercicio), el patrocinio de atletas
. . amo” “omo Nicola Spirigó, y la apertura de oficinas en
o AA 3 a mw Portland, EE.UU., cerca del corazón de la industria del
AS la sel : dl deporte. La incorporación del tenista Roger Federer como
o y sil a a inversor y embajador, en 2019, consolidó su estatus
; ( o O a a aspiracional y premium.
a 3 AR A
a. ERA EN : Y z de Sin embargo, el crecimiento de On ha estado centrado en
a SE ON MN ba un segmento relativamente pequeño del mercado global
dE li 1 o. oa E] de running. Según estimaciones, el mercado total
O A asciende a 54.000 millones de dólares anuales, donde los
e corredores ocasionales representan el 60% (=32.400
millones de USD), los regulares un 30%, y los profesionales/élite apenas un 10%. Hasta hoy, On se ha enfocado
principalmente en este 10%, dejando sin atender un segmento ocasional masivo, con hábitos menos exigentes
pero con alto volumen.
lí A
1 CloudTec es una tecnología de amortiguación y propulsión basada en una serie de cavidades huecas ('clouds") que se comprimen y
expanden durante el movimiento, ubicadas en la suela del calzado. Estas "nubes" permiten que el impacto al aterrizar se absorba
vertical y horizontalmente, ofreciendo amortiguación cuando el pie toca el suelo y una respuesta firme al despegar.
2 El lactato es un compuesto químico que se produce de forma natural en el Cuerpo cuando se descomponen los carbohidratos para obtener
energía en condiciones de bajo oxígeno. Esto puede ocurrir durante el ejercicio intenso, o cuando hay una infección o enfermedad que
reduce el suministro de oxígeno a los tejidos. Los niveles de lactato son una medida de la concentración de lactato en la sangre, que se
utiliza para evaluar la salud del paciente y su función metabólica.
3 Nicola Spirig es una abogada suiza y ex triatleta profesional. Es campeona olímpica de 2012 y seis veces campeona europea.
2
A
-----
Actualmente, On tiene una participación global inferior al 1% y aproximadamente un 8% en Estados Unidos, lo
que muestra un amplio margen de crecimiento. Esto ha llevado al Directorio a plantearse una nueva estrategia:
la expansión hacia el segmento de corredores ocasionales, que representan el grueso del mercado. Este segmento
está representado por personas que corren de forma recreativa o simplemente usan zapatillas deportivas como
parte de su estilo de vida diario. El desafío que ha puesto el Directorio se condiciona a que la marca no pierda
su esencia premium, su compromiso ambiental y su diferenciación basada en la comodidad y el bienestar.
La competencia en este mercado es muy fuerte. Nike mantiene un posicionamiento claro como la marca del
rendimiento extremo, asociándose con atletas élite y rompiendo límites físicos a través de la innovación
científica. Adidas, por su parte, combina rendimiento con un estilo urbano aspiracional, integrando tecnologías
como Boost' y colaboraciones con marcas de moda. Ambas marcas tienen presencia consolidada en todos los
segmentos, desde profesionales hasta ocasionales.
On, en cambio, ha cultivado un nicho claro: corredores serios que valoran su salud física y buscan productos
sostenibles, diferenciándose por priorizar la comodidad, el diseño innovador y la tecnología ecológica. El desafío
es cómo trasladar esta propuesta a un público más ocasional, menos especializado, sin diluir su esencia.
Preguntas:
1. A partir de la información del caso, identifique y explique claramente qué variables de segmentación
psicográficas y conductuales debería considerar On para definir con precisión el perfil de estos corredores
ocasionales. Además, caracterice a estos corredores ocasionales de acuerdo a estas variables. Justifique
claramente su respuesta.
2. A partir de la información del caso y del nuevo segmento objetivo y condiciones planteadas por el
Directorio, redacte la declaración de posicionamiento de On dirigida a dicho segmento de corredores
ocasionales, considerando sus características y motivaciones. Además, explique claramente en qué aspectos
claves esta declaración se diferencia del posicionamiento actual de On y del posicionamiento de Nike y
Adidas.
4 Boost es una tecnología de amortiguación desarrollada por Adidas en colaboración con la empresa química BASF. Se basa en un material
llamado TPU expandido (poliuretano termoplástico expandido), que se presenta como pequeñas cápsulas que, al fusionarse, crean una
suela con alta capacidad de retorno de energía y amortiguación duradera
3
A A
-----
PREGUNTA N*2
Nubank: la gigante Fintech de Servicios Bancarios
Nubank, es una plataforma de servicios financieros 100% digital, sin sucursales físicas, fundada en 2013 en Sáo
Paulo, Brasil, y es reconocida como uno de los bancos digitales más grandes del mundo. Conocida como Nu, ha
revolucionado la industria financiera en América Latina en base a tecnología e innovación, ofreciendo todos sus
servicios a través de una aplicación móvil intuitiva y fácil de usar lo que le permite operar con costos mucho
más bajos que los bancos tradicionales y ofrecer productos sin comisiones o con tarifas muy reducidas,
generando gran lealtad entre sus clientes. Sus objetivos son ambiciosos: luchar contra la burocracia, las altas
comisiones y el mal servicio de la banca tradicional.
Nubank cuenta con más de 118 millones de clientes en Brasil, México y Colombia, poco más de 98 millones son
usuarios activos cada mes. Conocedores de la industria señalan que más allá de la tecnología, el principal activo
estratégico de Nubank, son los millones de clientes que posee.
La compañía ha tenido un crecimiento vertiginoso con un total enfoque en el cliente, ejecutando un modelo de
negocio que a juicio de entendidos es fácilmente escalable a volúmenes mayores. Sus decisiones se basan en
analizar grandes cantidades de datos provenientes del feedback de los clientes. Lo anterior ha permitido que
Nubank se posicione como una de las empresas más valiosas e innovadoras de América Latina. Con el tiempo,
la compañía ha ido ampliando su oferta de productos y servicios más allá de su tarjeta de crédito inicial,
convirtiéndose en una plataforma financiera integral. En el primer trimestre de 2025, su beneficio neto creció un
74% (respecto del primer trimestre del año anterior), alcanzando los 557 millones de dólares.
La compañía se ha enfocado y seguirá haciéndolo, en jóvenes no bancarizados, un segmento de cliente
desatendido por los bancos tradicionales por considerarlos poco rentables. Nubank vio en ellos una oportunidad,
construyendo un completo portafolio de productos financieros para su mercado objetivo. Los principales
productos / negocios con que hoy en día cuenta Nubank son: Tarjeta de Crédito Nu, Cuenta Digital Nu (Cuenta
de Débito), Cajitas Nubank (para separar dinero para objetivos de ahorro específicos), Préstamos Personales, e
Inversiones. Todos son productos de bajo costo, creados, construidos e inspirados pensando en el segmento
objetivo.
El sector de Telecomunicaciones en Brasil capturó la mirada de Nubank
Es un sector muy competitivo, con alto nivel de concentración y con una segmentación más bien clásica:
empresas versus personas, y dentro de estas últimas, de prepago y post pago. El mercado de prepago, donde
normalmente habitan los jóvenes, es mirado como un segmento más bien marginal por su baja rentabilidad.
Las redes de comunicación están concentradas en pocos actores de la industria, y son propiedad de los
competidores más grandes, quienes ocupan una parte de la capacidad de dichas redes. Esto permite que en el
mercado operen empresas más pequeñas, sin infraestructura tecnológica (sin antenas), pero que arriendan
espacio disponible en el mercado.
El ingreso de Nubank al negocio de telefonía móvil
Nubank señala que está ampliando su presencia más allá del sector financiero con la entrada en servicios móviles
(NuCel), con foco en su mismo segmento objetivo, y una oferta adaptada a sus necesidades. Lo anterior permite
también lograr mejoras en la gestión de pagos del cliente al contar con la aplicación móvil para pagar, lo cual
refuerza su posición como líder Fintech en América Latina. Con esta estrategia espera convertirse en un
proveedor de servicios esenciales, no solo financieros, sino también de conectividad, entre otros, lo que refuerza
la fidelización del cliente.
En el negocio de telefonía móvil, NuCel ofrece diferentes tipos de productos, todos a precios muy competitivos
y con diseños pensados en su segmento objetivo. El pago se carga a la tarjeta de crédito de Nubank y todos los
planes incluyen un paquete de voz ilimitado para llamadas locales y de larga distancia, y WhatsApp ilimitado,
incluyendo llamadas de voz y vídeo.
Con lo anterior, Nubank entra a competir directamente con los operadores tradicionales de telefonía móvil en
Brasil, amenazando con captar una parte del negocio por medio de ofrecer una alternativa digital, ágil, de bajo
4
-----
costo, y con beneficios exclusivos pensados y adaptados a los segmentos objetivos de clientes. De hecho, Nubank
planea expandir NuCel a nivel regional en varios países de sudamérica.
NuCel actúa como operador de móviles de forma virtual, lo que le permite ofrecer servicios sin necesidad de
grandes inversiones en redes de telecomunicaciones, arrendando capacidad a competidores establecidos. De
hecho, Nubank no poseería redes de comunicación propia, sino que utilizaría, vía contrato de arriendos, la
capacidad excedentaria en las redes existentes que son propiedad de los grandes actores de la industria.
Evidentemente que este modelo no está exento de riesgos, ya que se debe garantizar la estabilidad y calidad del
servicio para competir con los operadores tradicionales, además de enfrentar las regulaciones del sector de
telecomunicaciones, que suelen ser más estrictas que las del sector financiero. También existe la incertidumbre
sobre la rentabilidad a largo plazo de estos servicios, especialmente en mercados con alta competencia.
Con el negocio de telefonía celular, Nubank espera además mejorar su capacidad de recolección de datos lo que
se vería enriquecido con el servicio móvil activo. Medidas así permitirán a Nubank potenciar algoritmos para la
evaluación de créditos, ofertas personalizadas y desarrollo de productos más precisos.
Las dudas que genera la estrategia corporativa de Nubank
Diversos analistas han planteado dudas acerca de la estrategia corporativa que está implementando Nubank. No
está claro si con el modelo que desea implementar podrá llegar a ser un actor relevante en la industria de las
telecomunicaciones. Tampoco se sabe cuál será la reacción que tendrán los competidores existentes en la
industria de las telecomunicaciones. En lo que si hay acuerdo es que el éxito de Nubank en su estrategia
corporativa dependerá de la innovación que le imprima a su negocio.
Preguntas:
1. ¿Por qué razón podría decirse que existe un Modelo de Negocio Corporativo de Nubank? ¿Cuáles serían
los principales elementos de este modelo de negocio corporativo?
2. ¿Qué elementos específicos del caso podrían permitir afirmar que la estrategia corporativa que está
implementando Nubank podría ser exitosa? Señale dos. ¿Qué elementos específicos del caso podrían
permitir afirmar que la estrategia corporativa que está implementando Nubank podría No ser exitosa? Señale
dos.
5
-----
PREGUNTA N*3
Andrés Tagle, gerente general del Grupo El Mercurio, hojeaba los informes de gestión más recientes con
creciente inquietud. Aunque el Grupo seguía siendo uno de los conglomerados de medios más influyentes de
Chile, los dos negocios que lo sostenían —el diario impreso y el portal digital Emol.com— parecían vivir en
mundos paralelos.
Por una parte, El Mercurio, con una historia centenaria como diario impreso en papel, conservaba su rentabilidad
gracias a contar con una base de suscriptores fieles, publicidad institucional y productos editoriales y
suplementos especializados. Pero su circulación bajaba año a año: 74.000 ejemplares diarios, menos de la mitad
que una década atrás. Su audiencia era madura, exigente, influyente.
Así mismo, Emol.com, fundado en 2001 era el portal informativo online propiedad del mismo Grupo El Mercurio
y lideraba el consumo digital de noticias en el país, con más de 6 millones de usuarios únicos mensuales, y un
crecimiento sostenido en redes sociales, contenido audiovisual y posicionamiento SEO”. Sin embargo, su
rentabilidad era volátil y su fidelización, baja. Su audiencia era joven, fragmentada y móvil.
Andrés Tagle sabía que ambos negocios tenían futuro, pero intuía que la forma en que estaban organizados y
gestionados no era sostenible. “Son dos empresas dentro de una empresa. ¿Pero tienen que funcionar así?”, se
: preguntaba.
Dos formas de entender el periodismo (Y de gestionar personas)
En el diario impreso, Pedro Hurtado, editor general desde 2011, dirigía una operación editorial tradicional,
jerárquica y especializada en el periodismo escrito. El foco estaba en la calidad del contenido, la profundidad, la
responsabilidad pública y el criterio editorial. Por su parte los incentivos variables existentes premiaban esos
mismos atributos aunque eran muy bajos en cuanto a los montos que se otorgaban. El equipo estaba compuesto
por periodistas con larga trayectoria, muchos con más de 20 años en la empresa. Las evaluaciones eran
cualitativas, las decisiones centralizadas.
—“Aquí no se improvisa. Esto no es hacer noticias ni videos virales. Hacemos periodismo serio, que exige
tiempo, criterio y rigor”, solía decir Pedro Hurtado.
Mientras tanto, Catalina Ríos, directora de Emol, lideraba un equipo joven, mixto, con perfiles que iban desde
periodistas hasta data analysts, diseñadores UX y community managers. Trabajaban en equipos ágiles, con alta
autonomía, con tableros de control que contenían indicadores de tráfico y lectoría en tiempo real, pruebas A/B”
para determinar que contenidos obtenían mejor rendimiento entre los lectores, y decisiones tomadas en minutos.
Sus incentivos estaban ligados a incremento del tráfico al sitio web, aumento d ellos tiempos de permanencia en
el sitio de los lectores digitales y fidelización de esos mismos lectores. Los liderazgos eran horizontales y
colaborativos.
—“Si una nota no funciona en los primeros 30 minutos, la matamos. Esa es nuestra realidad. La velocidad es
parte del rigor”, decía Catalina.
Tensión organizacional: “No somos enemigos, pero no somos socios”
Los dos equipos compartían edificio, pero no compartían rutinas, ni herramientas, ni estructuras de gestión. Los
intentos de colaboración editorial conjunta habían sido esporádicos y, muchas veces, incómodos. Las áreas
comerciales también trabajaban por separado.
(IA
$ El posicionamiento SEO (por sus siglas en inglés: Search Engine Optimization, u Optimización para Motores de Búsqueda) es el
conjunto de estrategias y técnicas que se aplican a un sitio web o contenido digital para mejorar su visibilidad en los resultados orgánicos
(no pagados) de Google.
$ Un diseñador UX (experiencia de usuario) se enfoca en crear productos y servicios digitales que sean fáciles de usar, eficientes y
agradables para el usuario. Su objetivo principal es comprender las necesidades y deseos del usuario para diseñar experiencias que sean
intuitivas y satisfactorias. Por su parte, un community manager es un profesional encargado de construir, gestionar y administrar la
comunidad online de una marca o empresa, fomentando interacciones positivas y relaciones duraderas con clientes y seguidores
7 Las pruebas A/B en medios digitales son una técnica para comparar dos versiones de un elemento, como una página web o un correo
electrónico, para determinar cuál funciona mejor en función de los objetivos de marketing
6
-----
El área de Personas había detectado barreras culturales y de lenguaje. Los perfiles que contrataba Emo? rara vez
eran considerados para movilidad interna dentro del Grupo. Las evaluaciones de desempeño no eran
comparables. Y las estructuras de compensación tampoco eran similares.
En uno de los reportes preparados por el área de Desarrollo Organizacional se incluía una observación que había
pasado desapercibida en reuniones anteriores:
— “En el actual entorno de desinformación y fragmentación, los medios—independientemente de su soporte—
enfrentan el reto de sostener su legitimidad. pública. Aspectos como la claridad editorial, la confianza del lector,
el conocimiento del contexto nacional e internacional y la calidad narrativa se han vuelto claves para marcar
diferencia en la credibilidad de una marca periodística. ”
Tanto en El Mercurio como en Emol, estos principios aparecían recogidos en sus respectivas declaraciones de
propósito y se mencionaban con frecuencia en discursos internos, aunque no estaba claro cómo influían en las
prácticas cotidianas ni si eran gestionados de forma coordinada entre ambas unidades.
Debate en el directorio
Durante una reunión extraordinaria del directorio, surgieron dos posturas marcadas:
Carlos Rivas, ejecutivo de Emol con amplia experiencia en medios digitales, fue directo:
—“Tenemos que separar los negocios. Son modelos distintos. Requieren estructuras distintas, personas distintas,
culturas distintas. La integración solo los frena. Cada negocio requiere de espacio propio para crecer y ser
rentable.”
Patricia Moya, periodista histórica del diario, respondió con igual convicción:
-—“Separarlos es destruir la marca. La experiencia del papel es el corazón de este medio. Emol tiene que
integrarse más a esa herencia. Las políticas y prácticas de gestión de personas de nuestro diario en papel son
perfectamente aplicables al negocio online. Solo así tendrá consistencia y solidez como marca.”
El debate se estancó. Ninguna de las dos propuestas convencía del todo.
Preguntas:
1. Como consultor externo usted ha sido convocado por Grupo El Mercurio y sus empresas para ayudar a
entregar mayor claridad frente a la diferencia de opinión entre Carlos Rivas y Patricia Moya, dos personas
con amplia experiencia en la industria de medios de comunicación. En concreto se le pide que, desde el
punto de vista de la gestión estratégica de personas apuntando a lograr los objetivos de Grupo El Mercurio
y sus negocios, entregue su opinión respecto a las afirmaciones de ambos ejecutivos. Fundamente su
respuesta de manera precisa.
2. Luego de esta acalorada discusión sostenida en la reunión extraordinaria de directorio intervino entonces
Teresa Larenas, directora con experiencia en estrategia y talento, señalando: “Entiendo las diferencias de
opinión entre Carlos Rivas y Patricia Moya, pero tenemos que tomar decisiones para lograr el desarrollo y
rentabilidad del Grupo El Mercurio y sus dos negocios. A usted se le pide que describa y detalle con
precisión dos políticas de gestión de personas que sean clave para el logro de los objetivos del Grupo El
Mercurio y sus dos negocios.
7
A As
-----
PREGUNTA N*%4
Doña Javiera es una de las dueñas de la recién creada empresa “Los Huasos” y se encuentra evaluando lo que
podría ser su primer proyecto de inversión. Este nuevo proyecto requeriría de un monto de inversión inicial de
US$ 14.000.
La siguiente es la información que se conoce del primer y nuevo proyecto:
» Los resultados esperados del proyecto en términos anuales son los que se presentan a continuación. Para
todos los efectos prácticos, estos resultados esperados se mantendrán constantes a perpetuidad:
= Resultado Operacional US$ 2.500
- Intereses (6%) (336)
= Resultado antes de Impuestos 2.164
- Impuestos (20%) (432,8)
= Utilidad Neta US$ 1.731,2
+ Gasto por Depreciación Anual = US$ 625
+ Requerimientos de Reinversión Anual (al término de cada año) = US$ 725
Este monto de reinversión anual (US$ 725) le permitiría a la Empresa mantener a perpetuidad su capacidad
para generar el Resultado Operacional anual de US$ 2.500 del nuevo proyecto. No obstante dicho monto de
reinversión anual (US$ 725), el gasto anual por depreciación se mantendría constante en US $ 625.
+ Financiamiento de los US$ 14.000 requeridos para la Inversión Inicial:
Nueva Deuda de Largo Plazo con un Banco (ver detalle en Tasa de Interés de la Deuda) = US$ 5.600
Nuevo Aporte de Capital por parte de las dueñas de la Empresa = US$ 8.400
» Tasa de Interés Anual de la Denda (US$) = 6%
La deuda estaría pactada en condiciones de mercado, dado su riesgo. Los intereses deben ser pagados al
término de cada año. Mientras la empresa pague anualmente los intereses de la deuda, ella puede y espera
mantener su nivel de deuda a perpetuidad.
+ Tasa de Costo de Capital Promedio Ponderado (CCPP); (usar este CCPP con tres decimales)= 15,079%
Un análisis hecho por las dueñas de la empresa ha indicado que dadas las características de este proyecto de
inversión (activos), este 15,079% es el CCPP anual, después de impuestos, relevante para los activos del
proyecto que se está evaluando. Este es el CCPP óptimo de largo plazo y que se espera se mantenga a
perpetuidad.
+ Tasa de Impuesto a las Utilidades de las Empresas = 20%
SUPUESTOS:
+ El total de la inversión inicial se paga al inicio del proyecto y todos los ingresos y gastos del estado de
resultados de la empresa, con la sola excepción de la depreciación del ejercicio, son flujos de caja que
se producen al término de cada año. Suponga además que no hay inflación y que la empresa sólo tiene
activos operacionales.
+ El mercado espera que las tasas que se han indicado se mantengan constantes en el largo plazo (perpetuidad).
+ Al término de cada año, la empresa reparte a sus dueños el flujo de caja residual disponible de la empresa.
Preguntas:
1. Obtenga el V.A.N del nuevo proyecto de inversión para las dueñas o socias de la empresa. Para responder,
usted debe evaluar el nuevo proyecto desde la perspectiva de las dueñas de la empresa (o Enfoque de
“Dividendos” o “Flujo de Caja Residual”), indicando si bajo estas condiciones convendría o no
emprender el nuevo proyecto. En su respuesta refiérase y sea preciso en la determinación de: el monto de
la inversión inicial a considerar, los flujos de caja relevantes y la tasa de descuento que a su juicio se debiera
utilizar en el cómputo del Valor Actual Neto (VAN), desde la perspectiva de las dueñas.
8
A
-----
2. Enuna discusión entre dos ejecutivos de la empresa se produjo el siguiente diálogo:
Ejecutivo 1: “Les comento que para llegar a ese CCPP de 15,079% que estamos usando, hemos tomado
como base una empresa que es en todo idéntica a la nuestra (considerando también el nuevo proyecto),
salvo en la relación entre los costos operacionales fijos y los costos operacionales totales (fijos más
variables) presentes en cada flujo. En el caso de la empresa que usamos como base, dicha relación era de
un 50%, mientras que en el caso de nuestra empresa y en el proyecto que estamos evaluando dicha relación
es de un 80%. Esa es la razón por la cual, en mi opinión y dado que como se nos ha informado ambas
empresas tienen y seguirán teniendo el mismo nivel de riesgo financiero, a los activos de nuestro proyecto
debemos exigirle un mayor rendimiento, esto es a estos activos debemos exigirle un CCPP mayor que el
de la empresa usada como base, debemos exigirle ese 15,079%”
Ejecutivo 2: “Entiendo aquello de que en este proyecto la relación a la que tú te refieres es más alta que
aquella de la empresa usada como base y que por esa razón, y de acuerdo a tu opinión, se deba usar ese
CCPP de 15,079% algo mayor que el de la empresa usada como base, sin embargo yo no estoy de acuerdo
con esto último. Yo entiendo que precisamente por tratarse de costos “fijos”, es decir porque son costos
que no cambian frente a cambios en el nivel de operaciones de la empresa (al menos dentro de cierto rango
de actividad) y siendo todo lo demás idéntico entre nuestra empresa y la que hemos tomado como base,
desde un punto de vista operacional ambas empresas enfrenarían el mismo nivel de riesgo operacional.
Como además se sabe que ambas tienen también el mismo riesgo financiero relevante para la determinación
de su CCPP, en mi opinión no habría motivo para que la relación entre los costos operacionales fijos y los
costos operacionales totales deba afectar al CCPP de nuestra empresa o proyecto”
Se Pide: Indique en primer lugar con cuál de las dos opiniones O planteamiento anteriores (Ejecutivo 1 o
Ejecutivo 2) está usted de acuerdo y fundamente de manera conceptual su respuesta
3. Finalmente, ahora suponga que para el financiamiento de los recursos que la empresa obtendría a través de
deuda con el Banco (US$ 5.600), ella pudiera acceder a un préstamo especial (deuda subsidiada) que puede
ser usado únicamente para este proyecto, préstamo que tendría una tasa de interés preferencial de 3% amual
a perpetuidad (antes de impuestos).
Se pide responder: Dadas las características de la nueva deuda ¿Qué efecto tendría sobre el VAN del
proyecto el que la empresa decidiese cambiar-el total de la actual deuda a “tasa de mercado” que tendría
con el Banco para el financiamiento del nuevo proyecto por la nueva deuda a una “tasa subsidiada”?
(cambio en el VAN del proyecto respecto del VAN que tenía cuando los US$5.600 de deuda usada para su
financiamiento era a la tasa de mercado del 6% anual a perpetuidad).
Nota: Solo para efectos de simplificar su análisis y por lo tanto su respuesta, suponga que como resultado
del endeudamiento a la nueva tasa “subsidiada” del 3%, tanto el CCPP de la empresa “Los Huasos”
(15,079%), como la Tasa de Rendimiento o de Rentabilidad originalmente exigida por las dueñas a su
inversión NO cambian.
9
-----
PREGUNTA N*%5
Un reciente estudio publicado en la prestigiosa revista académica “Marketing Science”, explora el potencial uso
de la plataforma GP74.0% de inteligencia artificial para construir mapas de posicionamiento, que representen las
percepciones de los consumidores respecto de las marcas de una categoría de productos, y que permitan tomar
decisiones comerciales.
El estudio publicado considera 21 marcas de automóviles que fueron evaluadas en distintos atributos usando GPT
4.0 y un prompt? que pide que actúe como un Joven, de altos ingresos y educación universitaria, que llena una
encuesta de percepciones de marca. Luego, los resultados fueron contrastados con la metodología tradicional, es
decir, un estudio con encuestas a una muestra de consumidores, con el perfil mencionado, para así generar mapas
perceptuales de las marcas.
En particular, los 12 atributos considerados en el estudio fueron: popular, potente, deportivo, con estilo, con
tecnología avanzada, eco-friendly, eficiente en el consumo de combustible, confiable, seguro, cómodo, durable y
espacioso. En GPT4.0 se utilizó el prompt: “Evalúe en una escala de puntajes de O (muy bajo) a 10 (muy alto) el
atributo ...(atributo)... de la marca de automóvil -..(marca).... “. En el caso de la encuesta a consumidores se
realizaron exactamente las mismas preguntas a 402 personas representativas del segmento objetivo de los autos
considerados, según la metodología tradicional.
Con los datos obtenidos por cada metodología se obtuvo una matriz de puntajes para cada atributo en cada marca.
A continuación, se aplicó un análisis de factores que entregó las siguientes varianzas explicadas, en porcentaje,
para los primeros seis factores, las cuales se presentan a continuación en el siguiente cuadro:
Metodología YFactor__| 1 | 2 |] 3 |] 4 | _s [| 6]
GPT4.0
Las tablas que se presentan a continuación muestran las correlaciones (o loadings) más significativas entre los
atributos originales y los factores obtenidos en cada metodología.
Tabla de Correlaciones en Tabla de Correlaciones en
Metodología GPT4.0 Metodología Encuesta :
[_Eficiente*_ | 060 [| -012 |
[_ Deportivo | -0.90 [001 | [Deportivo | 034 | -009 ]
Ecofriendly | 0.64 | 019 |
Confiable [ 0.42 | 0.10 | Confiable
(+) Eficiente en consumo de combustible
La Figura 1, que se presenta a continuación, muestra el mapa de posicionamiento construido con análisis de factores
a partir de las respuestas de GPT4.0. Asimismo, la Figura 2 presenta el mapa de posicionamiento construido
mediante análisis de factores a partir de las encuestas a la muestra de 402 consumidores representativos. En los
ejes de ambas figuras se presenta el porcentaje de la varianza capturado/explicado por los factores correspondientes.
IáIAIA
$ GPT4.0 es un sistema de inteligencia artificial entrenado con enormes cantidades de contenidos disponibles en Intemet, para entender
y generar lenguaje humano.
? Un prompt es una instrucción, pregunta o texto que se proporciona a un modelo de lenguaje para generar una respuesta o contenido
específico
10
AAA A __- —__ __ E _=A-q- _ AAA A e
-----
Figura 1: Mapa de Posicionamiento Basado en Inteligencia Artificial (GPT4.0)
:
:
Jeep :
0.4- :
: 1 Subaru
;
: :
Y 02- ;
So Ford !
E : -
zo. ;
N Dodge : Y Nissan, Volvo
3 Chevrolet Mazda "Toyota
O E
Le Porshe Lexus :
:
Ferrari BMW,
Mercedes Benz : Volkswagen
:0.2= Lamborghini Ayai
: Hyundai
'
Tesla Renault
, : :
-0.75 -0.50 0.25 0.00 0.25
Factor 1 (41%)
Figura 2: Mapa de Posicionamiento Basado en Encuestas a Consumidores
'
0.08 - Jeep
Subaru
:
1 Dodge
.04- !
= o ¡ Chevrolet Honda
X ,
a :
z Ferrari Lexus; Toyota
N ! :
5 000==m=mm=====----Mergedes Benz
3 ,
E Porshe Lamborghini BMW : Nissan Ford
Audi; Mazda
1
-0.04- Volkswagen
;
: Hyundai
1
: Renault
Tesla í
0.2 0.1 2.0 0.1
Factor 1 (70%)
Preguntas:
1. Independientemente de los resultados que este caso presenta, describa dos ventajas significativas y dos
desventajas significativas, que podría tener el uso de plataformas de inteligencia artificial para construir mapas
de posicionamiento, en relación a la metodología tradicional basada en encuestas a consumidores.
2. ¿Diría usted que las dos metodologías presentadas en este caso describen de manera similar las percepciones
que tienen los consumidores sobre las marcas de automóviles? Explique su respuesta.
3. La marca Toyota se declara como la marca líder en la fabricación de automóviles eficientes y eco-friendly. ¿Es
esta declaración creíble para los consumidores de acuerdo al mapa presentado en la Figura 2? ¿Qué tres acciones
de marketing debiera realizar Toyota para comunicar bien su posicionamiento deseado?, Explique su respuesta.
1
qx A
-----
PREGUNTA N%6
Lavanda S.A. es una empresa especializada en la limpieza de ropa de cama (sábanas, plumones, frazadas) que
presenta una gran estabilidad tanto en sus resultados de operación como en sus flujos de caja operacionales. Los
accionistas controladores de esta empresa son muy conservadores y manejan la compañía sin deuda.
Los cambios en la demografía y los hábitos de los consumidores hacen que el rubro de la limpieza de ropa de
cama sea un negocio maduro con nulas posibilidades de crecimiento. Por esta razón, los analistas financieros
proyectan que la compañía generará, para todos los efectos prácticos, un resultado operacional de $6.000
millones anuales a perpetuidad. Este resultado operacional coincide con el flujo de caja operacional que se espera
genere la empresa a perpetuidad. La tasa de impuestos corporativos es de un 25% y la política de dividendos de
la empresa es repartir a los accionistas el 100% de sus utilidades después de impuestos. El rendimiento que se
exige en el mercado a empresas sin deuda y de similar riesgo operacional a Lavanda S.A. es de 12% anual
después de impuestos.
Suponiendo que la única imperfección presente en el mercado de capitales es la existencia de impuestos
corporativos y que los flujos de caja de la empresa se producen al término de cada año, siendo el primer flujo en
un año más, y en base a los antecedentes que se le han presentado, a Ud. se le pide responder las preguntas que
se le formulan a continuación, fundamentando cada respuesta con los cálculos pertinentes, en el caso que
corresponda. Cuando deba usar tasas de interés en porcentaje ocupe dos decimales (por ejemplo 13,75%).
Preguntas:
1. Calcule el valor económico del patrimonio de Lavanda S.A.
2. Los accionistas minoritarios han solicitado al directorio de Lavanda S.A. que la empresa emita bonos de
carácter perpetuo, por un total de $10.000 millones y que simultáneamente este dinero sea repartido
íntegramente a los accionistas como un dividendo extraordinario. Los bonos perpetuos permitirían que la
compañía sólo pagara intereses anuales por $600 millones de manera indefinida (6% anual de interés a
perpetuidad) sin necesidad de devolver el capital ($10.000 millones). De esta manera, la empresa quedaría
con una deuda permanente de $10.000 millones, que dejaría a Lavanda S.A. con un endeudamiento .
absolutamente razonable para los estándares de la industria donde opera la compañía.
El presidente del directorio de Lavanda S.A., coincide con los accionistas minoritarios en que un
endeudamiento permanente de $10.000 millones es prudente, ya que llevaría a una razón (Deuda /
Patrimonio) muy inferior a la que exhiben actualmente la mayoría de sus competidores más cercanos. Sin
embargo, le preocupa el efecto que podría tener la Operación anterior, ya que él ha escuchado que el
endeudamiento hace más volátiles los flujos de caja de los accionistas, lo cual podría afectar negativamente
el valor económico del patrimonio y la riqueza de los accionistas.
Para poder tomar una decisión, el presidente del directorio de Lavanda S.A. lo contrata a Ud. para que lo
asesore respecto de los potenciales efectos que podría tener, para los actuales accionistas de la empresa, la
Operación antes descrita, (emisión de bonos perpetuos por $10.000 millones y el reparto simultáneo de un
dividendo extraordinario por idéntico monto a los accionistas). En concreto, el presidente le solicita a Ud.
que calcule el valor económico que tendrá la compañía inmediatamente después de la operación anterior y
que señale el impacto que dicha operación tendrá en la riqueza de los actuales accionistas Fundamente su
respuesta mostrando los cálculos correspondientes.
3. Otro director de la compañía expresó su preocupación por el efecto que podría tener la operación descrita
en el número (2) anterior en el costo de capital de la empresa. Según sus palabras, “una mayor volatilidad
de los flujos de caja de los accionistas unido a un eventual deterioro patrimonial, podrían causar un
aumento en el costo de capital de Lavanda S.A., con el consiguiente impacto en la riqueza de los dueños”.
Por su parte, el gerente general de la compañía respondió a este director señalándole que, a su juicio, “la
operación de emisión de deuda y reparto simuliáneo de dividendos no debiera tener ningún impacto en el
costo de capital de la compañía, ya que se trata de un cambio en el lado derecho del balance que no afecta
12
A A As
-----
en absoluto a los activos de la empresa. En consecuencia, desde el punto de vista operacional, la compañía
sigue operando en el mismo negocio y por lo tanto se debiera mantener sin cambios el costo de capital.
¿Está Ud. de acuerdo con lo expresado por el director de la empresa o más bien con lo que sostiene el
gerente general de la compañía? Justifique su respuesta ya sea de manera conceptual o numérica. Si Ud. no
está de acuerdo con ninguno de ellos (director o gerente general), explique su punto de vista entregando los
fundamentos correspondientes ya sea de manera conceptual o numérica.
El
A AA
-----


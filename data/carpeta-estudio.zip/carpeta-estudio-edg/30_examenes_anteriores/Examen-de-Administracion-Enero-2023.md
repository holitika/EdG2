# Examen de grado · Examen-de-Administracion-Enero-2023

Fuente: examen anterior

[pág. 1]
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el
 alumno deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
 hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
 hojas adicionales. No se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
 que los datos que ha recibido están correctamente calculados y que no han sido tergiversados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
 realidad de las empresas que allí se mencionan.
5. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
 dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
 misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente a la Profesora Marta Del Sante, Presidente de la Comisión
 de Examen de Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
 cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas
 condiciones, la Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
11. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala ni relojes inteligentes, los que
 deberán estar apagados y guardados en las mochilas adelante.
12. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
 examen.
13. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han
 identificado con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar
 como “borrador”, esas hojas no se deben entregar con las respuestas.
Fecha : 26 de enero de 2023
Duración : 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá la Profesora
 Marta Del Sante, en forma individual, entre las 9:30 y 9:45 hrs. (aprox.), y luego entre las 10:45 y
 11:00 hrs. (aprox.).

[pág. 2]
2
PREGUNTA Nº1
Contact Vision (CV) es una empresa fabricante de lentes de contacto que vende a través de un sistema de suscripción
mensual y un modelo de distribución virtual D2C o Directo al Consumidor. Es una marca que, utilizando
principalmente el marketing digital, su página web y las redes sociales, y evitando los canales tradicionales (ej.
Cadenas de ópticas), vende lentes de contactos directamente a los consumidores a un precio más bajo que los
competidores. A través de esta estrategia, se podía, por ejemplo, comprar su producto directamente vía los anuncios
de Facebook, que le daban acceso a la página web de CV. De esta manera, a los prospectos que se les hubiera
prescrito lentes de contacto por parte del oftalmólogo (médico oculista) de su preferencia y que terminaran
suscribiéndose, recibirían en su casa cada mes las lentes de uso diario y desechables, a un precio de USD 1 (50
centavos por cada lente). El precio de suscripción mensual era de US30.
A diferencia de otras marcas de consumo D2C que ofrecían a los consumidores productos de cuidado personal no
regulados (ej: Dollar Shave Club que vendía hojas de afeitar), CV vende lentes de contacto que están clasificados
como productos sanitarios por la Food Drug Administration (FDA) estadounidense y, por lo tanto, se rigen por
estrictas normas de fabricación y prácticas de venta. Toda persona que requiriera anteojos ópticos o lentes de
contacto para corregir un problema de visión necesitaba una orden médica para poder adquirir estos productos. La
ruta de compra del consumidor promedio se iniciaba al darse cuenta de que ya no veía bien, lo que gatillaba una
visita al oftalmólogo, el cuál sugería usar anteojos ópticos o lentes de contacto desechables y emitía una receta.
Luego, la persona buscaba información, tanto en medios como en sus conocidos, sobre qué opción era la más
adecuada, así como la marca de óptica más confiable. Eventualmente, visitaba locales y páginas web de ópticas.
Finalmente elegía dónde registrar la receta y mandaba a fabricar los lentes ópticos o lentes de contacto. En este
último caso, debía volver a comprar cada 30 días o elegir una suscripción como la que ofrecía CV, dado que era una
deficiencia visual permanente. La empresa CV contaba con la ventaja de ser la primera que entraba al mercado
óptico con el modelo D2C, y de haber creado una relación estrecha con clientes finales y oftalmólogos, lo que
generaba una buena reputación y tráfico a su sitio web.
CV había sido capaz de construir una marca moderna, diferenciadora y atractiva para distintos segmentos, con una
alta tasa de fidelización y satisfacción entre sus clientes, gracias a la satisfacción con el producto y el servicio de
entrega oportuno.
La publicidad de CV debía llegar a los clientes potenciales de forma efectiva y eficiente, y lograr destacarse en la
gran cantidad de avisos de ópticas, que utilizaban redes sociales, buscadores y sitios web, además de publicidad
tradicional, para atraer prospectos. El plan de “medios ganados”1 de CV le significaba una gran cobertura en varias
redes sociales, blogs y páginas web de medios de comunicación. Por ejemplo, algunos clientes subían sus fotos,
usando las lentes CV a Facebook, Instagram y Pinterest. CV publicaba anuncios digitales en otras redes sociales
además de las ya mencionadas, como Snapchat, e invertía en medios offline tradicionales como radio y TV. Además,
compraba anuncios en Google Adwords y Google Display.
Cada medio comunicacional ofrecía opciones de cómo comprar y luego monitorear la inversión para la toma de
decisiones. La métrica más tradicional utilizada en la mayoría de los medios era el costo por mil (CPM), referida al
costo que el anunciante paga por hacer llegar su anuncio a 1.000 personas del segmento objetivo, y se empleaba
para medir el alcance o el número de impresiones de un anuncio. El porcentaje de clics (CTR), medía cuantas
personas hacían clic en un anuncio para visitar el sitio web de la empresa respecto del total de visualizaciones, lo
que ofrecía una referencia sobre el nivel de atracción generado por el anuncio. Por su parte, el costo de adquisición
(CPA) medía el costo promedio asociado a la captación de un cliente a través de un medio específico.
1 Medio Ganado: se refiere a todo medio en que la marca aparezca y se exponga al segmento objetivo, sin que se pague
por ello. Es una exposición “orgánica” en base a la calidad de sus contenidos asociados a la marca.

[pág. 3]
3
Preguntas:
1. El Gerente de Marketing de CV se encontraba evaluando cómo seguir con las campañas que estaba realizando
 en la plataforma Facebook para lograr aumentar las ventas de suscripciones durante el 2023. Tenía dos opciones:
 (1) destinar $100.000 mensuales a conversión de prospectos1, ó (2) invertir $100.000 mensuales en realizar
 acciones de retargeting2.
 Para tomar la decisión, el gerente de marketing cuenta con la siguiente información sobre campañas recientes:
 Campaña de Prospección en Buscadores vs Campaña de Retargeting
 Campaña de Prospección Campaña de Retargeting
 Inversión $100.000 $100.000
 Impresiones 6.425.703 417.084
 Clics 98.313 21.986
 Consumidores que inician el proceso de suscripción 5.141 3.153
 Consumidores que completan la suscripción 1.285 2.628
 CPM - costo por mil $15,56 $239,76
 CPC - costo por clic $1,02 $4,55
 CPA - costo por adquisición $77,8 $38,05
 CTR - Tasa de clics 1,53% 5,27%
 Tasa de conversión a compra 0,02% 0,63%
 Desde el punto de vista de marketing, y de acuerdo a la información entregada en el enunciado, recomiende qué
 campaña, la de prospección de clientes, la de retargeting o una combinación de ambas, debiera seguir el gerente
 de marketing, si este contara con $100.000 mensuales y su objetivo fuera el de aumentar el número de
 suscripciones en el tiempo.
2. Por otro lado, uno de los gerentes de CV, proponía asignar más recursos a comprar listas de personas con alta
 probabilidad de necesitar una corrección visual dada su edad, y generar campañas de emails con promociones
 de precios para la suscripción. El Gerente General, en cambio, proponía una campaña masiva de marca en medios
 tradicionales y redes sociales, para así empujar las ventas mensuales de nuevas suscripciones. Desde el punto de
 vista de marketing, evalúe cada una de las propuestas presentadas, de manera de tomar la decisión correcta de
 asignación presupuestaria.
1 Campaña de Prospección: técnica de marketing cuyo objetivo es impactar a potenciales usuarios que pertenecen a los
segmentos objetivo y que no han tenido contacto previo con la marca.
2 Retargeting: es una técnica de marketing digital cuyo objetivo es impactar a los usuarios que previamente han
interactuado (visitado la web, visto videos, bajado info, etc.) con la marca. La finalidad del retargeting es recordar a los
usuarios interesados en nuestros productos y marca, que estamos ahí y que tenemos una oferta interesante que ofrecerles.

[pág. 4]
4
PREGUNTA Nº2
SecurMax es una empresa fundada hace cinco años que presta servicios de seguridad a supermercados,
proporcionando guardias de seguridad especializados en la prevención y detección del "hurto hormiga”1 y robos
con intimidación en las salas de supermercados. Estimaciones de la Asociación Gremial de Supermercados de Chile
indican que a causa de este este tipo de delitos los supermercados pierden entre 150 y 200 millones de dólares
anuales, cifra que se incrementaba año tras año, con nuevas formas de robo cada vez más variadas, “creativas” y
violentas. Por esta razón, la demanda por seguridad en la industria de supermercados estaba creciendo a tasas altas
y constantes.
SecurMax fue uno de los primeros proveedores de servicios de seguridad en el mercado. Esta compañía ha basado
su éxito en una estrategia de diferenciación basada en la alta efectividad, confiabilidad y calidad de sus servicios.
En cada supermercado que atendía, sus equipos estaban compuestos por un grupo de dos a ocho guardias,
dependiendo del tamaño de la sala de venta. Se esperaba que estos equipos fueran capaces de resolver una amplia
variedad de situaciones de seguridad y servicio en los supermercados que atendían. Esto era clave ya que los clientes
de SecurMax evaluaban el desempeño de la empresa en función de la disminución de la tasa de robos y la calidad
de la relación de los guardias de seguridad con los empleados y clientes en las salas de venta y en base a ello
renovaban o caducaban cada año sus contratos con SecurMax.
Hasta hace un año la compañía había tenido una historia exitosa en materia de rentabilidad, control de robos y
satisfacción con el servicio que entregaba. Ello fue posible porque SecurMax solo tenía equipos de seguridad en
cinco pequeñas cadenas de supermercados con un total de 15 salas de venta. Además, los jefes de seguridad y sus
guardias eran gestionados por la Encargada de Personal de SecurMax, Julieta Segura, quién se hacía cargo
personalmente, y con mucho esfuerzo, de su selección, motivación, capacitación, gestión de compensaciones,
fidelización y supervisión.
Este éxito permitió a SecurMax captar de manera explosiva un número importante de nuevos clientes y salas de
supermercado. Sin embargo, la rápida expansión de la empresa no se tradujo en mejores resultados económicos.
Muchos clientes reclamaban por la excesiva rotación de guardias y el consecuente deterioro en el servicio entregado.
En efecto, durante el último año la rotación de los jefes y guardias se acercaba al 50% anual, el doble histórico de
la empresa y de la industria, la que había sido cercana al 25% al año.
A raíz de la captación de este importante volumen de nuevos clientes Julieta Segura formó un pequeño equipo de
trabajo para responder de mejor forma a la mayor carga laboral derivada del crecimiento repentino de la compañía.
Es así como el proceso de reclutamiento y selección del personal de seguridad comenzaba solicitándole currículos
e información de compensaciones de mercado a una empresa externa que históricamente proveía de candidatos y
estudios de compensaciones para los cargos de guardias, conserjes y personal de aseo a diversas industrias. Luego,
sus colaboradores en el área de personas leían los antecedentes recibidos y, en base a su experiencia,
preseleccionaban candidatos para ser entrevistados. Luego, Julieta efectuaba todas las entrevistas, en donde
intentaba identificar las competencias de honestidad, empatía y una actitud positiva frente al servicio. Junto a los
resultados de las entrevistas se consideraban los antecedentes penales y comerciales de los candidatos, además de
sus experiencias laborales previas.
Posteriormente, los seleccionados pasaban por un día de inducción en el cuál mediante charlas breves se les
informaba sobre la importancia de la calidad del servicio y los valores de SecurMax y se les comunicaba la propuesta
laboral que entregaba la empresa, la que consistía en un sueldo fijo promedio de mercado para los guardias, una
semana adicional de vacaciones por sobre lo legal y su ropa de trabajo. El grueso de la jornada de inducción estaba
dedicada al reconocimiento de su sala de ventas de los recién seleccionados, luego de lo cual los nuevos guardias
contratados iniciaban su primer día de labores y se esperaba de ellos un rendimiento inmediato acorde a los
estándares que diferenciaban a la empresa.
Julieta Segura también consideraba crítico para el negocio el movimiento y reasignación de los equipos de seguridad
a un nuevo supermercado, cada seis meses. Este proceso, en primer lugar, apuntaba a romper la monotonía del
trabajo de estos guardias, y segundo, pretendía desarticular posibles relaciones de exceso de confianza entre
guardias, entre estos y el personal o con los clientes de los supermercados. La experiencia había demostrado que
estas relaciones habían conducido a crear conflictos de interés que muchas veces podían terminar en conductas
1 Pequeños hurtos en cantidades menores pero con alta frecuencia

[pág. 5]
5
negligentes o deshonestas por parte de los guardias, de los empleados de los supermercados, y/o de los clientes. Por
ello, y utilizando el factor sorpresa, los traslados se anunciaban con una semana de anticipación.
Por otra parte, en los últimos meses SecurMax estaba incorporando, adicionalmente al servicio de guardias, sistemas
de monitoreo mediante cámaras de video instaladas en puntos estratégicos de las salas de supermercado y
controladas desde una sala de control remoto en las oficinas centrales de SecurMax. Con esta tecnología la empresa
se posicionaba a la vanguardia del resto de sus competidores, los que no contaban con estos servicios para sus
clientes. Los guardias en cada sala de supermercado, mediante una aplicación en su teléfono celular, tenían la
posibilidad de acceder a la información que generaba el sistema de monitoreo remoto. En una charla de bienvenida
que Julieta daba a los guardias en las diferentes salas de supermercado, entre otros temas, ella planteaba las múltiples
ventajas para SecurMax y sus clientes de esta tecnología de seguridad remota: protección 24/7, monitoreo desde un
mismo lugar de múltiples transmisiones de cámaras en diferentes ubicaciones, alerta temprana de problemas de
seguridad, vídeo grabación de lo ocurrido, bloquear o desbloquear puertas de manera remota de la sala afectada por
un posible robo, entre otras.
Julieta está bajo alta presión desde la Gerencia General de la compañía, ya que el gerente general Ernesto
Tranquilein, le hacía ver que la alta rotación estaba mermando el posicionamiento y los resultados que se esperaban
del crecimiento en clientes que había tenido SecurMax. En concreto, Tranquilein le mencionó a Julieta que:
“nuestras prácticas de gestión de personas, o más bien sus deficiencias, están provocando un aumento de los robos
y una baja satisfacción en nuestros equipos de seguridad. Y ello termina en el 50% de rotación que tenemos en
nuestra personal de seguridad.” Julieta pensaba que la reciente incorporación de tecnología de monitoreo remoto
estaba provocando la renuncia masiva de personal, pero no estaba del todo segura. En este sentido le solicita a usted
que en base a su formación respecto al modelo de gestión estratégica de personas y a la información entregada en
el texto:
a) Describa de qué manera la gestión estratégica de personas actualmente existente en la compañía, y en un contexto
 de incorporación de tecnología en SecurMax, está impactando negativamente en los equipos de seguridad y
 consecuentemente en una alta rotación del personal. Seleccione tres prácticas clave, o sus déficits, que estén
 teniendo mayor impacto en dicha rotación, explicando concretamente cómo están afectando la satisfacción y
 posterior renuncia masiva de los guardias de seguridad.
b) Proponga tres acciones clave de mejora a implementar en materia de gestión estratégica de personas para reducir
 de manera significativa la rotación del personal, señalando de qué forma cada una de sus propuestas permiten
 aumentar la satisfacción de los equipos de seguridad y con ello disminuir la rotación en SecurMax.

[pág. 6]
6
PREGUNTA Nº3
Hoy es 31/12/2022 y hemos conocido el caso de dos amigas que recién salidas de la universidad crearon, hace 5
años, la empresa “Comidas Sanas y Deliciosas” (CSD) la que ha alcanzado gran prestigio en el mercado local. La
empresa se dedica únicamente a la elaboración y venta de comidas sanas, todos sus activos son operacionales y su
financiamiento actual es de un 100% de patrimonio. El negocio que actualmente opera la empresa CSD se espera
genere un flujo de caja operacional anual de $47,5 millones y las dueñas estiman que este sería su flujo de caja
operacional anual esperado por muchos años, en la práctica “a perpetuidad”. Se sabe que la tasa de descuento
relevante para los flujos futuros esperado de la operación actual de la empresa dado sus riesgos es de un 10% anual.
Dado el éxito que ha tenido el negocio, sus dueñas están evaluando hoy, 24:00 hrs del 31/12/2022, la posibilidad de
desarrollar un nuevo proyecto o negocio, que consistiría en una plataforma que le permitirá a la empresa CSD entrar
al negocio de “última milla”, el que se agregaría al actual sistema de ventas en el local que tiene la empresa. A juicio
de las dueñas de la empresa CSD, la probabilidad de que el escenario para el nuevo proyecto sea favorable y por lo
tanto sus resultados esperados sean positivos, tanto desde el punto de vista comercial como financiero, es de un
30%. Por otro lado, estiman un 70% de probabilidades que el escenario sea desfavorable o negativo, en cuyo caso
ellas no emprenderían el nuevo negocio.
El nuevo negocio requeriría de una inversión inicial de $50 millones y ellas estiman que, en el caso de un escenario
positivo para el nuevo negocio, se podría esperar que éste genere anualmente, a partir del 31/12/23, un flujo de caja
operacional anual de $18 millones a perpetuidad (adicionales a los $47,5 millones anuales que genera la actual
operación de la empresa). Dadas las características del nuevo negocio, se estima que la tasa de descuento relevante
para sus flujos de caja esperados es de 12% anual. Tanto los flujos de caja esperados como el riesgo del negocio
que CSD opera actualmente se mantendrían.
Como una forma de revisar las probabilidades de que se presente un escenario positivo o negativo para el nuevo
negocio, las dueñas han contratado un estudio de mercado, cuyo costo es de $0 millones, que les permitiría estimar
con mayor precisión lo que podría ser su mercado y en definitiva su nivel de ventas e ingresos en el caso de
desarrollar el nuevo proyecto de comercialización. Luego de conocidos los resultados del estudio de mercado, ellas
tomarían la decisión de desarrollar o no este nuevo proyecto. Las dueñas han decidido que en el caso que la
investigación de mercado muestre resultados esperados positivos, ellas emprenderían de inmediato el nuevo
negocio, es decir lo harían a partir del 1/1/2023.
Por otra parte, se sabe que las dueñas de CSD han decidido que toda nueva inversión, será financiada manteniendo
su actual estructura de financiamiento (100% Patrimonio).
Suponga que el mercado de capitales (MC) es eficiente en su forma “semi-fuerte” y que no hay impuestos, inflación
ni costos de transacción.
Se pide responder las preguntas que se le irán planteando a continuación y en cada caso fundamentar
ordenadamente sus respuestas con los cálculos necesarios para su desarrollo:
1. Suponga que en este momento son las 24:00 hrs del 31/12/2022 y que la información respecto de las expectativas
 futuras del negocio que actualmente opera la empresa es conocida y compartida por el mercado. Por otro lado,
 las dueñas de la empresa han decidido dar a conocer al mercado toda la información de la que ellas disponen
 relativa al nuevo proyecto, pero todavía sin conocer los resultados de la investigación de mercado. ¿Cuál debiera
 ser en este momento el valor de mercado total de la empresa CSD, dada la información relativa a las operaciones
 que ella actualmente desarrolla considerando además la información que sus dueñas han dado a conocer respecto
 del nuevo proyecto?
2. Suponga ahora que a las 08:00 hrs del 1/1/2023, las dueñas informan al mercado que los resultados del estudio
 que habían contratado indican un escenario positivo para el nuevo proyecto, de manera que ellas emprenderán
 el nuevo negocio. En este momento, por lo tanto, el mercado internaliza toda la información relativa al nuevo
 negocio de última milla.
 Sin embargo, y dado que las dos amigas no cuentan con recursos para el financiamiento de los $50 millones
 necesarios para emprender el nuevo negocio, han decidido invitar a su amigo Don Jacinto a que aporte como
 capital los $50 millones que se necesitan. Así Don Jacinto pasaría a ser propietario de una parte de la empresa
 CSD, que incluye tanto el negocio que ellas actualmente operan como el nuevo negocio de última milla.

[pág. 7]
7
 Se Pide: Determine el mínimo porcentaje de la propiedad de CSD que Don Jacinto debiera estar dispuesto a
 recibir para aportar los $50 millones.
 Nota: Por “mínimo porcentaje”, entiéndase aquel porcentaje que lo dejaría indiferente entre aportar o no los
 $50 millones.
3. Suponga ahora que Don Jacinto ha decidido pedir un 16% de la propiedad de CSD a cambio de los $50 millones
 de su eventual aporte de capital. Las dueñas, no están dispuestas a entregar dicho porcentaje de la propiedad y
 dado que ellas saben que la única opción que tienen de incorporar a un nuevo socio es a Don Jacinto y que ellas
 no disponen de recursos para aportar como capital, han decidido recurrir al Banco para solicitar un préstamo por
 los $50 millones que requieren. El Banco ha ofrecido prestarles los $50 millones, pero por distintas
 imperfecciones del mercado de capitales, esto haría subir la tasa de descuento relevante para la evaluación del
 nuevo proyecto, de modo tal que el nuevo VAN del proyecto de última milla sería de $75 millones. Dado lo
 anterior, ellas saben que las únicas opciones de llevar a cabo el nuevo proyecto son incorporando a Don Jacinto
 como socio con algún porcentaje de propiedad de la empresa o financiar los $50 millones que les faltan con la
 deuda que les está ofreciendo el Banco. Se sabe que el valor que tenía la empresa como resultado de sus actuales
 operaciones, antes del nuevo proyecto, no se vería afectado
 Se Pide: Determine el máximo porcentaje (%) de propiedad de la empresa CSD, que las amigas debieran estar
 dispuestas a entregar a Don Jacinto a cambio de su aporte de $50 millones.
 Nota: Por “máximo porcentaje” entienda aquel porcentaje que a las amigas les dejaría indiferente entre
 incorporar a Don Jacinto como nuevo socio o recurrir al Banco para el financiamiento de los $50 millones.

[pág. 8]
8
PREGUNTA Nº4
En el mercado automotriz, existen importantes diferencias en la forma en que el público percibe la calidad de los
automóviles en diferentes dimensiones. Por ejemplo, en la encuesta anual del año 2022 de la empresa internacional
de estudios de mercado Consumer Reports aparece la empresa Toyota, de origen japonés, como aquella con los
vehículos percibidos con mayor “confiabilidad” por los consumidores, quiénes mostraban un alto nivel de
satisfacción tanto con esta marca, así como con cada uno de sus modelos. En el segundo lugar de preferencias en la
variable confiabilidad se ubicaban dos empresas alemanas: BMW y Mercedes-Benz. A una cierta distancia, el tercer
lugar lo ocupaban Ford y General Motors (GM).
Un especialista de la industria de automóviles definía confiabilidad como:
 “La falta de problemas y fallas en el funcionamiento de su motor. Adicionalmente se entiende que un
 vehículo tiene un conjunto de piezas mecánicas y electrónicas que deben trabajar juntas como un
 sistema coherente e integrado. La confiabilidad consiste en diseñar ese conjunto de procesos y piezas
 de forma que se reduzcan al mínimo las posibles fallas.
 Para conseguir la confiabilidad una marca de autos tiene que desarrollar y aplicar su conocimientos
 y experiencia en el diseño, planificación de la producción, la elección correcta de materiales e
 innumerables pruebas de esfuerzo, de tests en carretera y miles de kilómetros en todo tipo de
 condiciones. Cuando llega el automóvil al concesionario de venta todas las piezas del vehículo,
 además de su motor, han debido ser puestas a prueba y validada su confiabilidad. Desde el primer
 tornillo del motor hasta el último resorte del asiento.”
De hecho, el informe Consumer Reports tenía un capítulo especial en el que se transcribían testimonios de clientes
que fueran representativos de un número significativo de ellos. En uno de estos comentarios, un dueño “histórico”
de la marca nipona, indicaba que “un Toyota nunca te falla, cumple exactamente con la promesa que te hacen cuando
uno va a la automotora y compra el auto”.
Pero no todo es dulce para Toyota. Numerosos sitios de internet especializados en el sector automotriz orientados a
púbicos de especialistas y expertos en la industria de automóviles, constataban que los autos Toyota traen
equipamiento más básico y utilizan materiales más económicos que los vehículos de competidores como Ford y
GM que tienen precios de venta al público de sus automóviles similares a los del fabricante japonés.
La fabricación de automóviles
Las distintas marcas de automóviles desarrollan básicamente las mismas etapas para la fabricación de su producto
final, siendo las principales el diseño de un prototipo, el diseño completo del proceso de fabricación, producción
del motor y partes y piezas del vehículo, ensamblaje, control de calidad, acabado y logística de abastecimiento y
despacho. A su vez, todas las empresas fabricantes de automóviles implementan un alto grado de externalización
(del orden de 70%-80%) de sus procesos y actividades, a través de proveedores especializados en cada una de las
etapas de fabricación.
Al mismo tiempo, sin embargo, se observan diferencias en la forma en que las marcas de automóviles llevan adelante
dichas estrategias de externalización hacia proveedores de la industria. Es así como Toyota diseña internamente el
proceso completo de sus operaciones de fabricación y logística y fabrican ellos mismos sus motores. En cambio,
Ford y GM deciden externalizar la producción de motores y diseño de procesos a otras empresas ubicadas
generalmente en otros países para lograr niveles de costos inferiores a los de sus competidores japoneses.
La decisión a la que está enfrentada Toyota
En el último Directorio de la compañía, uno de sus directores, muy sensible a los comentarios de los públicos
especializados, reaccionó a lo señalado en los sitios expertos, solicitando revisar la conveniencia de continuar con
la estrategia de diseñar internamente el proceso completo de sus operaciones de fabricación y logística y de fabricar
ellos mismos sus motores, que hasta ahora la compañía ha venido llevando a cabo. La argumentación entregada por
el director fue la siguiente:
 “No es posible seguir tolerando que se diga que los autos que produce Toyota tienen equipamiento
 más básico que otros competidores, y que utilizan materiales relativamente más básicos, pero al
 mismo precio de venta de los vehículos de nuestros competidores Ford y GM. Para evitar esa
 distorsión definitivamente debiéramos tener costos más competitivos e intensificar aun más nuestra

[pág. 9]
9
 estrategia de externalización, ampliándola hacia el diseño de los procesos de fabricación y la
 producción de los motores, y con ello lograr vender nuestros vehículos a un precio por debajo del de
 nuestros competidores”.
En relación a lo señalado a usted se le pide que:
a) Indique si le parece correcto o incorrecto para Toyota la propuesta del citado Director. Justifique su respuesta.
Inmediatamente un segundo director salió al paso de su colega indicando que, “en principio, la mayor
externalización de Toyota puede ser contraproducente para su estrategia competitiva. Sin embargo, puede haber
características tanto en la industria de proveedores de componentes y servicios como en el mercado de vehículos a
la venta, que harían deseable la ampliación y profundización de dicha externalización hacia todas nuestras
actividades, manteniendo el nivel de diferenciación competitiva de Toyota frente a sus clientes.”
En relación a lo señalado a usted se le pide que:
b) Indique qué características en la industria de automóviles deberían existir de modo que el planteamiento del
 segundo director en cuanto a la ampliación y profundización de la externalización pueda ser adecuado para la
 posición competitiva de Toyota. Refiérase en particular a características en: (i) la intensidad de la competencia
 de proveedores y (ii) la intensidad de la competencia en el mercado final a clientes. Justifique su respuesta.
Finalmente, un tercer director indicó que “si se decide una mayor externalización en todas nuestras actividades
planteada por mi segundo colega, habría que considerar aspectos clave de nuestra gestión con nuestros proveedores
externos si queremos mantener nuestro posicionamiento competitivo”.
En relación a lo señalado a usted se le pide que:
c) Indique una práctica clave de la gestión de Toyota con sus proveedores que permita mantener el posicionamiento
 competitivo de la empresa en el contexto de una ampliación y profundización de la externalización. Justifique
 su respuesta.

[pág. 10]
10
PREGUNTA Nº5
La mayor inflación y el menor dinamismo de la actividad observado en años recientes han llevado al consumidor
chileno a privilegiar la búsqueda de alternativas más económicas. En este sentido, son cada vez más los
consumidores que optan por marcas propias de las principales cadenas de supermercados del país. De acuerdo a un
informe de Euromonitor International, las ventas de productos de marcas propias en Chile aumentaron 27% entre
2019 y 2021, pasando de US$896,5 millones a US$1.140 millones. Las ventas de marcas propias en la categoría de
productos lácteos es la que más crecimiento ha mostrado (45%), pasando sus ingresos de US$110,6 millones a
US$160,7 millones en el mismo período.
En este contexto, la Key Account Manager (KAM) –ejecutiva a cargo de la relación con una cadena de
supermercados específica—de una importante marca de leches, está preocupada por la pérdida de participación de
mercado de su marca como consecuencia del crecimiento de la marca propia de la cadena de supermercado. Para
entender mejor las consecuencias de distintos cursos de acción, la KAM encarga a su equipo de analítica avanzada
hacer un análisis del comportamiento de compra del consumidor de la categoría leches en esta cadena de
supermercado. El equipo de analítica realiza preliminarmente un análisis de segmentación usando un algoritmo de
K-medias, basado en distintas variables sociodemográficas y de comportamiento de un panel de consumidores1, el
cuál identifica a tres segmentos distintos de consumidores. En una segunda etapa, el equipo de analítica estima un
modelo de elección de marca para cada uno de los segmentos de clientes identificados por el algoritmo de análisis
de clusters (K-medias). El estudio considera tres marcas tradicionales: A (marca a cargo de la KAM), B y C; y una
marca propia de la cadena de supermercados.
Específicamente, utilizando los datos del panel de consumidores, que indica las compras realizadas en la categoría
leches, los analistas estiman un modelo logístico multinomial (también conocido como multinomial logit o regresión
logística) que asume que la parte observable de la función de utilidad del consumidor depende de las siguientes
variables: (1) Precio (en miles de pesos); (2) Presencia de la marca en una exhibición especial2 realizada en la sala
de ventas del supermercado (variable dicotómica que toma el valor 1 si la marca está presente en una exhibición
especial y cero de otro modo); (3) Presencia de la marca en un catálogo semanal publicado por la cadena de
supermercado (variable dicotómica que toma el valor 1 si la marca es destacada en el catálogo y 0 de otro modo).
Además, todas las estimaciones incluyen constantes asociadas a las marcas incluidas en el análisis.
La siguiente tabla presenta los resultados de la estimación para cada uno de los segmentos de consumidores.
 Segmento 1 Segmento 2 Segmento 3
 Marca A 1.715*** -0.677*** 1.946***
 (0.145) (0.145) (0.169)
 Marca B 0.641*** -0.258*** 0.962***
 (0.054) (0.029) (0.059)
 Marca C 0.735*** -0.319*** 0.571***
 (0.081) (0.080642) (0.048)
 Precio -0.367*** -0.659*** -0.122***
 (0.024) (0.028) (0.012)
 Exhibición Especial 0.491*** 0.773*** 0.265***
 (0.120) (0.182) (0.137)
 Catálogo Publicitario 0.231*** 0.481*** 0.115***
 (0.009) (0.134) (0.06)
 # de Observaciones 2160 1250 3240
 Pseudo R-cuadrado 0.21 0.34 0.29
 Errores estándar en paréntesis. (***) indica significancia al 1%.
 La constante de marca de la marca propia se encuentra normalizada a cero.
1 Asuma que el panel de consumidores es representativo de los segmentos de la población.
2 Exhibición especial corresponde a cabezas de góndola, pasillos centrales, entrada, etc, que no es la ubicación habitual
de la marca, y que genera mayor exposición a la marca, por ser una ubicación de alto tráfico.

[pág. 11]
11
La siguiente tabla presenta las participaciones de mercado predichas por el modelo logístico, para cada segmento
de clientes, además del tamaño relativo de cada segmento:
 Segmento 1 Segmento 2 Segmento 3
 Marca A 35% 17% 42%
 Marca B 26% 22% 28%
 Marca C 21% 25% 19%
 Marca Propia 18% 36% 11%
 Tamaño Relativo (segmento) 32% 19% 49%
Responda las preguntas que se realizan a continuación:
1. ¿Cómo caracterizaría a cada uno de los segmentos identificados en el análisis de clusters en base a los resultados
 de las estimaciones del modelo de elección de marca? En particular, describa a cada uno de los segmentos en
 relación con las siguientes características: (i) Valoración de cada marca; (ii) Sensibilidad al precio; (iii)
 Sensibilidad a exhibiciones especiales; y (iv) Sensibilidad a publicidad (aparición de marca en catálogo
 publicitario).
2. i) ¿Por qué cree Ud. que el equipo de analítica decidió realizar un análisis de K-medias previo a la estimación
 del modelo de elección de marca?
 ii) Dado el objetivo de la KAM, mencione una ventaja y una desventaja de estimar el modelo de elección de
 marca usando la muestra completa de clientes versus el procedimiento de dos etapas, que estima el modelo de
 elección de marca para cada segmento identificado usando K-medias.
3. Con el objetivo de apoyar a la KAM, diseñe dos acciones de marketing orientadas a aumentar la participación
 de mercado en base a un presupuesto dado. Justifique las características de sus acciones en base a las preferencias
 y características de los segmentos.

[pág. 12]
12
PREGUNTA Nº6
La ausencia de oportunidades de arbitraje es una de las piedras angulares en la valoración de activos financieros.
Las relaciones de arbitraje pueden ser aplicadas a múltiples mercados, pero quizás las más importantes se refieren
a mercados cambiarios. Los mercados cambiarios son mercados de gran liquidez y profundidad en el sistema
financiero mundial. Esto aplica no solo al mercado de cambio spot, sino que también a los mercados de contratos
futuros o forward. Por ejemplo, el mercado de contratos forward entre el peso chileno (CLP) y el dólar
estadounidense (US) tiene un volumen diario de transacciones que es aproximadamente el doble que el volumen de
transacciones del mercado de cambio spot entre las mismas monedas. Inversionistas institucionales y extranjeros
(por ejemplo, grandes bancos internacionales) son participantes activos del mercado forward.
Una de las relaciones de arbitraje más importante en los mercados cambiarios es la conocida como paridad cubierta
de tasas de interés:
 𝑆𝑡
 1 + 𝑅𝑢𝑠,𝑡+𝑗 = (1 + 𝑅𝑐𝑙𝑝,𝑡+𝑗 ) ×
 𝐹𝑡+𝑗
Donde 𝑅𝑢𝑠,𝑡+𝑗 y 𝑅𝑐𝑙𝑝,𝑡+𝑗 corresponden a las tasas de interés en depósitos a plazo en dólares y pesos respectivamente.
El tipo de cambio en el mercado spot (𝑆𝑡 ) se mide en pesos por dólar. El precio en un contrato forward (𝐹𝑡+𝑗 )
también se mide en pesos por dólar. Un contrato forward es un acuerdo tomado hoy (𝑡) de vender o comprar dólares
a un precio conocido 𝐹𝑡+𝑗 en una fecha futura (𝑡 + 𝑗). En la ecuación de arriba, tanto las tasas de interés como los
contratos forward se refieren a los mismos plazos (por ejemplo, 𝑗 = 3 meses).
En términos muy sencillos, esta paridad muestra que, si una persona tiene M pesos chilenos, y quiere invertir hoy a
3 meses plazo (es decir, j = 3) para obtener dólares en j = 3, tiene dos opciones que debieran ser equivalentes. La
primera es transformar hoy los M pesos a dólares al tipo de cambio spot vigente (St), y depositar los dólares
resultantes en un banco, a 3 meses plazo, a la tasa de interés 𝑅𝑢𝑠,𝑡+3 . La segunda alternativa es depositar hoy en un
banco, a 3 meses plazo, los M pesos chilenos a la tasa de interés 𝑅𝑐𝑙𝑝,𝑡+3, pero asegurando hoy, a través de un
contrato forward, el tipo de cambio 𝐹𝑡+3 al cual se convertirán en dólares los pesos obtenidos en el depósito bancario,
cuando éste venza en 3 meses más. En otras palabras:
 𝑀 1
 × (1 + 𝑅𝑢𝑠,𝑡+3 ) = 𝑀 × (1 + 𝑅𝑐𝑙𝑝,𝑡+3 ) ×
 𝑆𝑡 𝐹𝑡+3
La igualdad anterior pone de manifiesto que la cifra de M pesos chilenos es irrelevante y que, para que no haya
oportunidades de arbitraje, se debe cumplir que:
 𝑆
 (1 + 𝑅𝑢𝑠,𝑡+3 ) = (1 + 𝑅𝑐𝑙𝑝,𝑡+3 ) × 𝐹 𝑡
 𝑡+3
Sobre la base de la información que se le ha presentado, responda las preguntas que se le formulan a continuación
entregando los fundamentos correspondientes:
a) Considere, sólo para efectos de esta primera pregunta (a) los siguientes datos: tipo cambio spot (para comprar o
vender) = $832; tipo de cambio del contrato forward (para comprar o vender) = $864; tasa de interés en dólares para
invertir o endeudarse a 3 meses (no es necesario trimestralizar) = 4%; tasa de interés en pesos para invertir o
endeudarse (no es necesario trimestralizar) = 8%. Un economista amigo -experto en macroeconomía internacional-
le dice que la expectativa actual que tiene el mercado sobre el tipo de cambio spot que prevalecerá en 3 meses más
(es decir, 𝐸𝑡 (𝑆𝑡+3 )) es de $900 y no el tipo de cambio observado en el contrato forward ($864). Su amigo argumenta
entonces que existe una oportunidad de arbitraje en este mercado. Explique por qué sí o por qué no es verdadero lo
que dice su amigo macroeconomista.

[pág. 13]
13
La siguiente información se le presenta para responder las preguntas b) y c) que se formulan más adelante.
Desde la crisis financiera del año 2008, el cumplimiento de algunas relaciones de arbitraje empezó a deteriorarse.
Por ejemplo, en la figura adjunta se reporta la cross-currency basis (CCB) a 3 meses del peso chileno que está
definida como las desviaciones observadas en la paridad cubierta de tasas de interés:
 𝑆𝑡
 𝐶𝐶𝐵𝑐𝑙𝑝,𝑡+𝑗 ≡ (1 + 𝑅𝑢𝑠,𝑡+𝑗 ) − (1 + 𝑅𝑐𝑙𝑝,𝑡+𝑗 ) ×
 𝐹𝑡+𝑗
 CCB 3m (%)
 2,00
 1,00
 0,00
 14.feb.2007 14.feb.2010 14.feb.2013 14.feb.2016 14.feb.2019
 -1,00
 -2,00
 -3,00
 -4,00
 -5,00
 -6,00
 Fuente: Banco Central de Chile (tasas on-shore)
Por ejemplo, la CCB del peso chileno llegó a niveles de aproximadamente -5% (anualizada) en septiembre de 2008.
Al igual que en otras monedas mundiales, la CCB del peso ha convergido lentamente hacia niveles cercanos al cero
después de la crisis del 2008. En el caso chileno, la CCB volvió a ampliarse durante el estallido social de octubre
2019 y durante la crisis covid (marzo 2020).
b) ¿Cómo podría un arbitrador aprovecharse de una CCB negativa? Explique una estrategia de inversión que usted
recomendaría si ese fuera el caso. Sea concreto en términos de las distintas operaciones que debe realizar el
arbitrador. Suponga que este arbitrador tiene acceso ilimitado a mercados de depósitos y préstamos en dólares y
pesos chilenos, y a los mercados spot y forward del peso chileno. Para facilitar su respuesta Ud. puede utilizar, si lo
estima conveniente, los siguientes datos válidos solo para esta pregunta (b): tipo cambio spot (para comprar o
vender) = $832; tipo de cambio del contrato forward (para comprar o vender) = $845; tasa de interés en dólares para
invertir o endeudarse a 3 meses (no es necesario trimestralizar) = 4%; tasa de interés en pesos para invertir o
endeudarse (no es necesario trimestralizar) = 10,5%.
c) ¿Por qué podría una CCB negativa mantenerse por un tiempo prolongado como sucedió en el periodo 2008-2011
o 2018-2019? Sea breve y preciso en los mecanismos que Ud. describe en su respuesta.

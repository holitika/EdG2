# Examen de grado · Enunciado-Adm-enero-2026

Fuente: examen anterior

> OCR (escaneo): pueden haber errores de lectura


E E ESCUELA DE ADMINISTRACIÓN
E FACULTAD DE ECONOMÍA Y ADMINISTRACIÓN
IA
EXAMEN DE GRADO
Ingeniería Comercial
Mención: Administración de Empresas
INFORMACIÓN GENERAL E INSTRUCCIONES:
L Este examen contiene seis preguntas. El alumno puede responder las seis preguntas. Para aprobar el examen, el alumno
deberá obtener una calificación de "Pase" en al menos tres de las seis preguntas que se presentan.
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos hojas que sólo
se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar hojas adicionales. No
se debe descorchetear el enunciado recibido ni las hojas de respuesta.
3. Para responder no está permitido usar el reverso de las hojas ni una tercera hoja (sólo las 2 hojas recibidas).
4. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga que los
datos que ha recibido están correctamente calculados y que no han sido tergiversados.
5. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la realidad de
las empresas que allí se mencionan.
6. Si como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados dichos
supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
7. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la misma
ponderación al momento de ser evaluadas.
8. Las preguntas de enunciado se podrán hacer solamente al Profesor Julio Gálvez, Presidente de la Comisión de Examen de
Grado, quien recorrerá las salas en el horario de consultas indicado más abajo.
9. NO está autorizado el uso de calculadoras que permitan almacenar "textos” (calculadoras alfanuméricas, etc.). El
cumplimiento de esta norma es de absoluta responsabilidad del alumno.
10. Usted NO debe escribir su nombre en las hojas de respuesta.
11. No está permitido salir de la sala durante el examen. En casos muy excepcionales, y bajo determinadas condiciones, el
Presidente de la Comisión de Examen de Grado podrá autorizar la salida de un(a) alumno(a).
12. No está permitido el uso, para fin alguno, de teléfonos celulares en la sala ni relojes inteligentes, los que deberán estar
apagados y guardados en las mochilas adelante.
13. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el examen.
14. Al terminar el examen, Ud. debe entregar únicamente las hojas que ha recibido para responder y que se han identificado
con un número. Si a Ud. se le han entregado hojas en blanco y sin numerar para que las pueda usar como “borrador”, esas
hojas no se deben entregar con las respuestas.
Fecha : 26 de enero de 2026
Duración —: 9:00 horas a 12:00 horas
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá el Profesor Julio Gálvez,
en forma individual, entre las 9:30 y 9:50 hrs. (aprox.), y luego entre las 10:45 y 11:15 hrs. (aprox.).
-----
PREGUNTA N*1
En un informe de 2019 desarrollado por una empresa consultora internacional se explicaba un proceso de adquisición
de una empresa por parte de otra en el mercado del transporte de buses interurbanos en Alemania. A continuación se
presenta un extracto de dicho informe: “En 2016, el mayor operador de transporte de buses interurbanos de Alemania,
Flixbus cuya participación alcanzaba el 80% del mercado total, adquirió al segundo operador del país, Postbus que
mantenía un 15% del mercado nacional y operaba una serie de rutas fuera de la región norte de Alemania. Tanto antes
como con posterioridad a la adquisición Flixbus era el único operador en la región norte de Alemania, tradicionalmente
la más rentable.”
Este informe fue el resultado del análisis de más de 6.000 rutas en el norte de Alemania. El informe identificó que tras
la adquisición, Flixbus redujo su número de terminales y paraderos propios, lo que implicó también reducir el número
total de rutas activas en el norte de Alemania. Flixbus también redujo la frecuencia promedio de servicios por ruta en
esa región. Al mismo tiempo, la compañía alemana decidió aplicar una leve baja en los precios por trayecto, de manera
de compensar los inconvenientes que la reducción de sus servicios podría causar en los clientes.
Mapa de Alemaria y Zona Norte del País (destacada en rojo)
O O, O A ES de hos AA a O LR Zona None de Alemaras
7 E Tr A
ÓN " O MA e > AN Se
AN E E ASA
DIR E NA 7 ás A ME Ca: A dd
o y 5 tt a, QQ.
Bes. Ae 0.
O O SS ON A a BR
ÓN 1 an
En una de las entrevistas realizadas como parte del informe, se capturó también las opiniones de diversos ejecutivos de
Flixbus y la industria. En uno de estos testimonios, un gerente regional de Flixbus lo resumía así: “Sabíamos que menos
rutas y frecuencia implicaba un costo para el cliente. Por ello decidimos aplicar una pequeña reducción de nuestras
tarifas por viaje de modo que la demanda no se resintiera.”
La siguiente tabla es parte de la información contenida en el informe antes mencionado, el cual resume algunos
indicadores relevantes antes y después de la adquisición.
Evolución de la red y precios - Norte de Alemania
premenca promo semana! (por ruta)
preco prometo portae (O
peupación prometo 14)
La operación de adquisición fue aprobada por las autoridades de competencia alemanas bajo el argumento de que el
mercado seguía siendo contestable y que la presión competitiva provenía, en parte, del transporte aéreo, ferroviario y
del automóvil privado, ampliamente extendidos en el país.
2
-----
Se pide responder:
1. En relación con la situación de FlixBus en Alemania, un analista de la industria señalaba que: “no entiendo la lógica
del cambio de estrategia de FlixBus. Antes de la adquisición de Postbus, la empresa FlixBus mantenía un gran
número de paraderos propios y un importante número de rutas, alta frecuencia y precios en el promedio de las tarifas
anivel nacional. Sin embargo, luego de la adquisición de Postbus, Flixbus disminuyó el número de rutas, y entregó
una menor frecuencia de viajes en la zona norte del país en donde seguía siendo el único operador de servicios de
buses interurbanos.”
En su calidad de experto(a), habiendo conocido las medidas adoptadas por Flixbus de manera posterior a la
adquisición de Postbus (reducción de terminales, paraderos, rutas y frecuencias y leve disminución de precios),
¿cómo explica la estrategia competitiva de Flixbus antes de esta adquisición?
2. FlixBus no sólo se ha expandido en Alemania sino también a otros países. De hecho FlixBus ha decidido ingresar al
mercado chileno, aunque ha descartado comprar alguna empresa local ya que debido a su agresiva política de
expansión internacional no cuenta con caja ni financiamiento adicional para adquirir alguna compañía de buses en
Chile. En nuestro país, el mercado de buses presenta una alta concentración y es dominado por la empresa Turbus,
que alcanza un 55% del mercado con rutas en las principales zonas del país.
En el último directorio de Turbus varios asistentes manifestaron su temor por la entrada al mercado chileno de la
empresa de buses alemana. Sin embargo, la discusión no solo quedó en el diagnóstico, sino que se elaboraron tres
medidas para disuadir la entrada de Flixbus al mercado chileno. Las medidas propuestas eran las siguientes:
a. Aumentar frecuencia de buses entre terminales, arrendando buses para dicho propósito.
b. Invertir en campañas comunicacionales para reforzar el valor de la marca Turbus.
c. Aumentar inversión en terminales y paraderos propios para entregar un servicio más exclusivo a los pasajeros.
Como experto(a) en dirección de empresas y estrategia de negocios se le pide que responda lo siguiente,
fundamentando sus respuestas:
2.1 ¿Qué criterios debería utilizar Turbus para evaluar la capacidad disuasiva frente a la entrada de Flixbus?
2.2 Ordene de más a menos efectiva estas potenciales acciones en relación a su capacidad para disuadir la entrada
de Flixbus a Chile. Discuta como estas medidas cumplen los criterios que usted incluyó en la letra a).
3
-----
PREGUNTA N2
Usted trabaja para la cadena de supermercados chilena “Chile Lindo”, con locales en varias regiones del país. Se le ha
pedido evaluar la apertura de un nuevo local en Lima, Perú, lo cual representaría la primera expansión internacional de
esta empresa. Para el desarrollo de este proyecto de inversión del nuevo local, la empresa “Chile Lindo”, ocupará un
terreno de su propiedad ubicado en el centro de Lima, que actualmente no se está utilizando, por el cual pagó al momento
de su compra MUSD 12.000 (miles de dólares americanos) y sobre el cual existe una oferta de una empresa inmobiliaria
para comprarlo al contado por la suma de MUSD 20.000 (luego de considerar cualquier impuesto que para “Chile
Lindo” pudiera significar la venta de dicho terreno). Por otro lado, “Chile Lindo”, deberá desembolsar MUSD 15.000
en las instalaciones de la sala del supermercado y MUSD 1.000 como inversión el capital de trabajo inicial. El estudio
de impacto vial solicitado por la municipalidad de Lima ya fue realizado y tuvo un costo de MUSD 200. Las ventas,
costos y gastos esperados el primer año de operación de la sala de supermercado son los siguientes:
Ventas MUSD 14.000
Costo de venta (no incluye depreciación) MUSD 9.500
Gastos de Administración y Ventas (no incluye depreciación) MUSD 1.200
Nota: Todos los ingresos y gastos del proyecto que se quiere evaluar, con la sola excepción del gasto por depreciación
anual, son flujos de caja que se producen al término de cada año.
Otros datos:
+ Las instalaciones de la sala del supermercado se deprecian linealmente en 15 años y al término del año 15 tanto su
valor residual para efectos contables como su valor comercial es de MUSD 0.
e La tasa de impuestos a las utilidades de las empresas es de 27%.
+ La vida útil u horizonte durante el cual se espera que el proyecto genere beneficios es de 15 años.
+ Al término de su primer año de operaciones la empresa deberá aumentar en MUSD 20 su inversión en capital de
trabajo.
+ A partir del año 2 y hasta el año 15, se espera que los flujos de caja netos del proyecto en MUSD y que usted obtuvo
para fines del año 1, crezcan cada año a una tasa constante del 2% anual, con respecto al año anterior.
+ La tasa de costo del capital promedio ponderado (WACC) después de impuestos de la compañía chilena se supone
constante e igual a 6% (en USD).
+ Suponga que inmediatamente después de los 15 años de duración del proyecto, el terreno se puede vender al contado
en MUSD 30.000 (neto de impuestos) y que también se recupera completamente el capital de trabajo inicial (MUSD
1.000). El resto de capital de trabajo acumulado durante la vida del proyecto se utiliza en pagar el total de los costos
de desmantelamiento de las instalaciones de la sala del supermercado y limpieza del terreno para su venta,
alcanzando justo para ese propósito y no generando efecto tributario alguno.
Se Pide:
1. Dada la información y los supuestos ya mencionados, y otros que usted considere necesario explicitar, se pide
responder lo siguiente: ¿Es este un proyecto del cuál la empresa pueda esperar que haya creación de valor financiero?
Su respuesta debe presentar tanto el resultado a la pregunta (MUSD) como el detalle de su desarrollo
Nota: Recuerde que la fórmula para obtener el Valor Presente (VP) de una anualidad de pago
F para el primer año de un flujo, por n años, con tasa de crecimiento constante de g% anual con respecto al año
anterior, y tasa de descuento r% anual, es:
Y
yp = E _ (9) ]
r-9 1+r
. 4
-----
2. El ejecutivo a cargo de la expansión internacional ha planteado lo siguiente: “Dado que la empresa había comprado
y pagado el terreno que se usaría para el proyecto hace ya varios años, no corresponde imputar como parte de la
inversión en la evaluación económica de este proyecto valor alguno al terreno, por tratarse de un costo hundido y
por lo tanto irrelevante”. ¿Esta Ud. de acuerdo con el planteamiento del ejecutivo? Fundamente su respuesta de
manera conceptual.
3. Un Director de la empresa le comenta: “este proyecto tiene un riesgo y costo de financiamiento particulares, lo cual
invalida el análisis anterior usando el WACC. Por ejemplo, la industria de supermercados en Perú es distinta, por
la mayor informalidad en el comercio y la mayor relevancia del canal tradicional (por ejemplo, almacenes de
barrio), y que la hace más sensible al ciclo económico. A su vez, en Perú los créditos hipotecarios (para financiar
la compra del terreno) son a tasas de interés inferiores a las observadas actualmente en Chile.”
Se pide responder:
3.1 ¿Qué supuesto relativo al riesgo del nuevo proyecto tiene el análisis presentado por usted en la pregunta N*1
usando el WACC que se le entregó?
3.2 Dado que el proyecto se desarrollaría en Perú y no en Chile ¿Qué ajustes o modificaciones Ud. sugeriría hacer
en la evaluación del proyecto que Ud. ha presentado de modo de incorporar el punto de vista que ha hecho ver
el Director con relación al WACC? Para esta pregunta se espera una respuesta cualitativa, no cuantitativa.
5
-----
PREGUNTA N*3
La industria mundial del vino atraviesa una transformación estructural marcada por una doble presión simultánea: una
caída sostenida en el volumen consumido y un aumento persistente de los costos y la volatilidad productiva. De acuerdo
con la Organización Internacional del Vino (OIV), el consumo global disminuyó desde 248 millones de hectólitros en
2017 a una proyección de 214 millones en 2025, lo que representa una contracción acumulada del 14%, el declive más
prolongado registrado en los últimos cincuenta años.
Más allá del volumen, el cambio es cualitativo y cultural. El vino ya no se consume de la misma manera ni en los
mismos contextos. Desde comienzos de la década del 2000, se observa una reducción significativa del consumo durante
las comidas y un aumento del consumo fuera de ellas, en contextos más fragmentados y menos ritualizados. Este
fenómeno se ve reforzado por tendencias sociodemográficas: disminución del tamaño de los hogares en países OCDE
(de 3,2 a 2,1 personas entre 2000 y 2024), menor frecuencia de comidas familiares y mayor dispersión de los horarios
laborales.
Incluso dentro de los momentos de consumo, el vino enfrenta una competencia creciente por ocasiones. Cerveza
artesanal y cócteles sofisticados han adoptado códigos históricamente asociados al vino —relato de origen, narrativa
sensorial, diseño de envases— desplazándolo como opción preferente. Sin embargo, el principal sustituto no alcohólico
ha sido el agua embotellada premium, categoría que crece a una tasa anual del 6,5% desde 2018.
Desde una perspectiva generacional, el desafío es aún más profundo. En mercados maduros, los Baby Boomers (nacidos
1946-1964) concentran el 62% del volumen total consumido. Cada cohorte posterior muestra una caída significativa en
el consumo de vino respecto de la generación anterior a igual edad: Generación X (nacidos entre 1965-1980, -35%),
Millennials (nacidos entre 1981-1996, -48%) y se espera algo similar en la Generación Z (nacidos entre 1997-2012, -
60%). Estudios recientes indican que Millennials y Gen Z prefieren cócteles premezclados, bebidas RTD (ready-to-
drink), spritzers! y alternativas sin o con bajo contenido alcohólico. Entre las razones destacan la percepción del vino
como una bebida “demasiado formal”, la complejidad del proceso de selección, la baja transparencia en información
nutricional y su escasa alineación con tendencias de moderación y bienestar.
Paradójicamente, este contexto ha dado origen a un segmento emergente que privilegia “beber menos, pero mejor”.
Estos consumidores reducen la frecuencia, pero están dispuestos a pagar precios premium por vinos con historia,
autenticidad, atributos de sustentabilidad (orgánico, biodinámico), formatos que favorecen la moderación y experiencias
diferenciadas, como el enoturismo y los clubes de venta directa (D2C). En paralelo, el mercado de vinos Sin/Poco
Alcohol (No/Low Alcohol) creció un 13% en volumen durante 2024 en los diez principales mercados del mundo, y el
e-commerce de vino ya representa el 18% de las ventas en mercados desarrollados, frente al 6% en 2019.
En este contexto opera Viña Ladera, un productor chileno de tamaño medio con ventas anuales entre USD 35 y 45
millones. Su estructura de ventas se concentra en exportaciones (70%), principalmente a Estados Unidos (35%), Reino
Unido (20%) y Brasil (15%), mientras que el mercado doméstico representa el 30% restante.
El portafolio actual de la viña se distribuye en tres grandes líneas. La línea Base, con precios a público entre USD 7 y
12 la botella, concentra el 75% del volumen producido (aproximadamente 850 mil cajas de 9 litros) y opera con
márgenes de 28-32%. Se compone principalmente de variedades tradicionales (Cabernet Sauvignon, Merlot, Sauvignon
Blanc y Chardonnay) y se distribuye masivamente a través de importadores los que a su vez le distribuyen a
supermercados y mayoristas, con alta dependencia de promociones. Su posicionamiento es percibido como “confiable,
pero genérico”.
1 Un Spritzer (o Spritz) es una bebida refrescante y burbujeante a base de vino (generalmente blanco) y agua con gas, que se sirve fría, con
hielo, y a menudo se adorna con limón o frutas
6
-----
La línea Gran Reserva, con precios a público entre USD 15 y 22 la botella, representa el 20% del volumen producido
(225 mil cajas) y genera márgenes superiores (38-42%). Incluye variedades como Carmenere, Syrah y Pinot Noir, y se
distribuye de manera directa y selectiva en tiendas especializadas y restaurantes de nivel medio-alto. Su narrativa se
apoya en la “calidad del vino chileno”, pero carece de una diferenciación clara frente a competidores similares.
Finalmente, la venta de vino a granel representa el 5% del volumen producido, con márgenes bajos (8-12%) y cumple
principalmente una función táctica de manejo de inventarios, sin aportar valor de marca.
Desde el punto de vista de marcas, Viña Ladera presenta debilidades relevantes. El reconocimiento asistido de marca
(brand awareness) en mercados clave alcanza solo un 18% (frente a 35-45% de competidores principales), mientras que
el awareness espontáneo es de apenas 4%. Su Net Promoter Score (NPS) es +22, considerado neutral, y las asociaciones
predominantes se limitan a “vino chileno” y “buena relación precio-calidad”, sin atributos distintivos claros.
Durante 2023, la viña enfrentó una presión creciente por parte de sus importadores en Estados Unidos y Reino Unido,
quienes exigieron mayores descuentos para sostener promociones al consumidor final. Estos importadores operan
portafolios amplios (40-80 marcas), privilegian alta rotación con mínimo soporte de marketing y buscan márgenes
objetivo entre 35% y 40%.
Frente a este escenario, el Directorio definió para 2026 un mandato estratégico claro. En el plano financiero, se exige
un crecimiento mínimo de 8% en valor de ventas ($), mantener un margen EBITDA de 16% y reducir la dependencia
de los dos principales importadores desde el 55% actual a menos del 45% en un plazo de tres años. Como restricciones,
se establece que no habrá inversión en nueva capacidad productiva y la viña no le comprará vino a terceros.
Se pide responder:
1. A partir de los cambios estructurales en el consumo de vino descritos en el caso conteste las siguientes preguntas:
a. Evalúe críticamente el portafolio actual de Viña Ladera.
b. Proponga una redefinición del foco estratégico de segmentación que permita cumplir simultáneamente los
objetivos de crecimiento en valor de ventas y margen, considerando las restricciones del Directorio.
c. Señale y explique además los dos principales riesgos de su propuesta. Justifique claramente su respuesta.
2. A partir de la información del caso, proponga y justifique dos decisiones concretas de estrategia de canales que
Viña Ladera podría implementar para lograr el requerimiento del Directorio. Señale y explique además el principal
riesgo de cada decisión propuesta. Justifique claramente su respuesta.
2 El Net Promoter Score (NPS) es un indicador de lealtad y recomendación del cliente, muy usado en marketing, experiencia
de cliente y estrategia. Mide qué tan dispuestos están tus clientes a recomendar tu producto, servicio o empresa a Otras
personas.
7
-----
PREGUNTA N'4
Ganga es una de las empresas de retail con mayor trayectoria en Chile. Su modelo de negocios se ha construido sobre
una amplia cobertura territorial, una oferta diversa de productos y la capacidad de operar a gran escala de manera
coordinada y confiable a través de todas sus salas de venta. Además, históricamente, la compañía había puesto especial
énfasis en la gestión de su personal ya que su permanencia y compromiso con la empresa eran clave para lograr la
diferenciación que se buscaba.
En los últimos años, el entorno competitivo del retail se ha vuelto más exigente: mayor penetración del comercio
electrónico, presión por costos, consumidores más informados y un contexto legal y de relaciones laborales con mayor
conflictividad. En este escenario, Ganga ha optado por un posicionamiento que no descansa exclusivamente ni en el
bajo precio ni en la digitalización pura, sino en sostener una experiencia de compra predecible, tanto en tiendas físicas
como en canales digitales, para un segmento amplio de clientes.
Esta propuesta de valor supone una promesa clara: independientemente de la tienda, el formato o el momento, el cliente
debería encontrar disponibilidad de productos, atención oportuna y estándares similares de servicio. La ventaja
competitiva no proviene, por tanto, de innovaciones extraordinarias, sino de la capacidad de establecer metas claras y
ejecutar procesos operacionales cotidianos de forma disciplinada, estandarizada y simultánea a lo largo de todo el país
para el logro de dichos objetivos. En este sentido, la sostenibilidad del negocio se encuentra estrechamente vinculada a
las personas y a la forma en que la organización gestiona su desempeño y la forma en que el personal, y particularmente
las jefaturas a cargo de los diferentes equipos en las tiendas, toman decisiones.
Este enfoque ha permitido a la empresa ejecutar campañas comunicacionales complejas de manera simultánea, reducir
quiebres de stock y mantener niveles aceptables de servicio en contextos de operación normal. Como señalaba un
ejecutivo senior: “cuando el sistema funciona como está diseñado, los resultados llegan”.
El rol clave de las jefaturas en situaciones bajo presión
En papel de las jefaturas de las tiendas en Ganga es clave para el cumplimiento de objetivos operacionales, comerciales
y laborales. En períodos estables estas metas habitualmente se cumplen. Sin embargo, es en los períodos de alta presión
(lanzamiento de nuevas colecciones o liquidaciones que requieren precisión en la ejecución, eventos promocionales a
nivel nacional o acciones comerciales en respuesta a tácticas agresivas de los competidores), cuando las competencias
de las jefaturas y sus equipos se ponen a prueba.
En estos escenarios de mayor complejidad, particularmente en los últimos años en donde las exigencias al negocio del
retail se han vuelto más demandantes, es que, crecientemente los jefes han ido imponiendo un alto nivel de presión
sobre sus equipos. Si bien Ganga ha establecido políticas generales respecto al cumplimiento de todas las leyes y
normativas laborales existentes en materia de trato, respeto a las jornadas de trabajo, calidad de vida y salud mental, los
jefes tienden en muchas ocasiones a poner un alto nivel de presión, exigencia e incluso un trato agresivo con el objeto
de cumplir las metas asignadas.
Si bien en algunas tiendas, líderes con mayor experiencia logran combinar el cumplimiento de metas con un manejo
cuidadoso de situaciones laborales complejas, durante estos períodos de mayor estrés comercial un número importante
de jefaturas tienden a orientar sus decisiones fundamentalmente en función del sistema de evaluación del desempeño y
el esquema de incentivos variables que tiene Ganga. Estos se centran básicamente en si las metas comerciales se están
alcanzando y en las mejoras que requieren implementarse para que el equipo alcance sus objetivos, dejando de lado la
gestión de las relaciones laborales.
Consecuencias legales
En 2021, el Segundo Juzgado de Letras del Trabajo de Santiago acogió una demanda por prácticas antisindicales,
cuestionando decisiones de ciertas jefaturas de Ganga que afectaron el ejercicio de la actividad sindical. Estas medidas
apuntaban a evitar negociaciones con las organizaciones sindicales y lograr reducir costos laborales. Además, apuntando
a las metas operacionales exigidas, varias jefaturas han ido tomando decisiones arbitrarias en materia de beneficios
$
-----
laborales (becas, seguros de salud y pago de horas extra) favoreciendo a algunos trabajadores que las jefaturas
denominaban como “más comprometidos con la empresa” y eliminando estos beneficios para quienes les parecían
menos “colaboradores”. Por otra parte, un número relevante de jefaturas han estado despidiendo trabajadores sin una
causal justificada en su afán por mejorar los resultados operacionales de sus tiendas.
La tabla que se muestra a continuación describe los principales fallos que han afectado negativamente a Ganga en los
últimos años, derivados de las decisiones de determinadas jefaturas en la empresa.
Fallos laborales relevantes
2021 [Prácticas antisindicales Juzgado del Trabajo
2023 ¡[Discriminación laboral Corte Suprema Sentencia confirmada
2025 l¡Despido injustificado Corte Suprema Indemnización = $50 millones
Efectos acumulados y dilemas abiertos
Tras cada uno de estos fallos, la organización adoptó medidas correctivas puntuales, principalmente orientadas a reforzar
procedimientos y controles específicos. Sin embargo, las jefaturas no contaban con instancias sistemáticas para revisar
internamente las decisiones tomadas, analizar alternativas posibles o extraer aprendizajes individuales y compartidos a
nivel organizacional. Como resultado, varias jefaturas perciben que deben actuar con rapidez y firmeza, pero sin tener
plena claridad respecto de dónde están los límites aceptables en situaciones complejas. Adicionalmente, algunos jefes
reconocen que, frente al riesgo de equivocarse, optan por escalar decisiones hacia niveles superiores o aplicar las reglas
de manera estrictamente formal, aun cuando intuyen que el contexto requeriría un análisis más fino.
Más allá de las consecuencias legales, comienzan a observarse otros efectos también persistentes: malestar laboral,
desconfianza en las jefaturas, mayor cautela de los jefes en la toma de decisiones y aumento del escalamiento jerárquico
ante situaciones de negocio bajo presión. Al mismo tiempo, los indicadores operativos del negocio continúan mostrando
niveles aceptables de cumplimiento.
Se pide responder:
1. En la reciente reunión del comité ejecutivo de Ganga uno de los ejecutivos presente preguntaba: “El análisis de
los resultados financieros junto a lo que se observa en materia laboral me tienen confundido. Entiendo que hay
múltiples variables que inciden en nuestros resultados, pero ¿quién me puede describir cuáles son las tres
competencias clave que requieren las jefaturas para lograr el desarrollo de nuestra estrategia de negocios de
manera sostenible? Además, ¿alguien me puede explicar cómo cada una de esas competencias favorecen el logro
de dicha estrategia?” A usted se le pide que una respuesta a las dos preguntas que el gerente está haciendo para
aclarar sus dudas.
2. Durante esa misma reunión, el Gerente de Operaciones de Tiendas señalaba: “Nuestro sistema de evaluación del
desempeño e incentivos variables por resultados premia el cumplimiento riguroso de metas y procedimientos. Eso
debería ser condición suficiente para que las jefaturas tomen las decisiones adecuadas alineadas con nuestra
estrategia, incluso en situaciones complejas. Basta observar nuestros resultados operacionales para comprobar
lo que digo.” Por su parte, la Gerenta de Sostenibilidad, no estaba del todo de acuerdo con las afirmaciones de su
colega y señaló que “hay varias medidas clave que deben incorporarse en el sistema de evaluación del desempeño
e incentivos variables” para lograr los objetivos de negocio de nuestra empresa de manera sostenible. En su calidad
de experto se le pide que indique tres medidas que pueden complementar al sistema de evaluación de desempeño
e incentivos variables existente y permitan el logro de los objetivos de negocio de Ganga de manera sostenible.
9
-----
PREGUNTA N*5
A comienzos de 2025, AndeSur Corredores, una empresa dedicada a la operación y mantención de corredores logísticos
estratégicos a lo largo del país, se encontraba en un momento clave de su desarrollo. Tras varios años de expansión
sostenida, la compañía había consolidado contratos estables con clientes de largo plazo, lo que le permitió acceder a
financiamiento en condiciones muy favorables.
Sin embargo, informes recientes de analistas financieros comenzaron a advertir que el nivel de endeudamiento de la
empresa, si bien manejable, podría generar inquietud entre inversionistas más conservadores. Frente a este escenario, el
directorio decidió realizar un análisis integral para comprender cómo su estructura de capital afecta tanto el valor de la
firma como sus decisiones futuras de inversión.
Situación Financiera Actual:
AndeSur financia actualmente sus activos con un 25 % de deuda y un 75 % de patrimonio, todo sobre la base de valores
económicos. Gracias a la estabilidad de sus ingresos y a la solidez de sus contratos, el mercado considera que la deuda
de la empresa es libre de riesgo, por lo que exige una tasa de interés anual de 4 %.
Las acciones de la empresa presentan un “beta” de 0,75, reflejando una exposición moderada al riesgo sistemático del
mercado.
La administración espera generar flujos de caja de $26 millones a perpetuidad, provenientes de sus activos.
El IPSA se considera como el portafolio de mercado y ofrece un retorno esperado de 20 % anual. Asuma la existencia
de un mercado de capitales perfecto, sin impuestos, costos de transacción ni asimetrías de información, y que se cumple
la hipótesis de eficiencia en el mercado de capitales.
Se Pide responder las preguntas siguientes, presentando los cómputos que la fundamentan sus respuestas:
1. Determine el valor de mercado de la compañía AndeSur.
2. Durante una sesión estratégica del directorio, algunos miembros manifestaron su preocupación por la señal que el
nivel de deuda podría estar enviando al mercado. Como respuesta, se propuso emitir acciones a precio de mercado
y recomprar parte de la deuda existente, de modo que esta represente solo un 10 % del financiamiento total de los
activos. ¿Cuál será el retorno exigido por los accionistas de AndeSur inmediatamente después de la operación de
recompra de deuda? ¿Cuál será el valor de mercado de la empresa AndeSur?
3. Suponga ahora que después de la recompra de deuda mencionada en la pregunta anterior, el equipo de operaciones
AndeSur presenta al directorio un proyecto de modernización que permitiría mejorar la eficiencia en el uso de
recursos y reducir costos de manera significativa. El proyecto requiere una inversión inicial de $60 millones y
generaría un flujo de caja de $15,6 millones anuales a perpetuidad. Se estima que el riesgo del proyecto es similar
al de las actuales inversiones o activos de AndeSur.
El directorio toma la decisión de llevar a cabo el nuevo proyecto y financiar la inversión inicial requerida mediante
la emisión de nuevas acciones a su precio de mercado. Simultáneamente, la empresa anuncia al mercado el nuevo
proyecto y su forma de financiamiento.
3.1 ¿Cuál será el valor de mercado de AndeSur inmediatamente después del anuncio del proyecto de
modemización, pero antes de la emisión de nuevas acciones necesaria para su financiamiento?
3.2 Si actualmente AndeSur tiene un único dueño, quien no desea suscribir la emisión de nuevas acciones, ¿qué
porcentaje de la propiedad retiene el dueño de AndeSur luego de la emisión de las acciones?
10
-----
PREGUNTA N%6
En años recientes el retail media ha adquirido un rol crecientemente importante en el ecosistema del retail y el e-
commerce. Por retail media se entiende la venta de espacios digitales de publicidad por parte de los retailers (canal de
E rr” EN] venta al comprador final) a marcas de proveedores, para activar campañas en sus canales digitales
E a E E (sitio web/app) o dentro del local (in-store, ej., pantallas digitales o señalización digital),
de AN Mn típicamente apoyándose en audiencias seleccionadas con datos históricos de los clientes del retailer
Md pE (first-party data). Por ejemplo, durante una visita al supermercado, el cliente puede ver en una
a pantalla digital ubicada cerca de la góndola de cereales un aviso de la marca Nestlé (“Fitness en
E : E oferta / nuevo sabor”), pagado por esa marca al retailer. En Chile, todos los grandes retailers han
y O E Ñ incorporado redes de retail media (RMN) a sus operaciones.
Pc
Desde el punto de vista de los proveedores y sus marcas, la promesa del retail media es que permite aprovechar el
conocimiento basado en datos del retailer para entregar mensajes personalizados y/o contextualmente relevantes,
combinando la precisión del marketing digital con la inmediatez de los ambientes de retail (online y presenciales). Para
la toma de decisiones por parte de la empresa avisadora, la pregunta relevante es si una campaña se justifica en términos
de ventas y margen incremental. Este desafío de medición es particularmente importante en ambientes presenciales (in-
store), donde la exposición al segmento objetivo, no siempre se observa directamente y las campañas pueden coincidir
temporalmente con otras acciones comerciales (precio, folleto o catálogo impreso de ofertas, exhibiciones especiales)
o, con variaciones de demanda que ocurren al mismo tiempo que se implementa una campaña.
En este contexto, la marca Fitness de Nestlé, una marca de cereales para el desayuno, está interesada en evaluar el
impacto de campañas de retail media in-store sobre sus resultados de ventas y margen. Para ello, el equipo de analítica
de la marca ha utilizado datos transaccionales de un panel de consumidores durante un período de 104 semanas. Los
datos están disponibles a nivel de hogar-visita: cada observación corresponde a una visita de un hogar al supermercado
y registra si en esa visita el hogar compró cereal y, si compró, qué marca eligió.
En particular, el equipo de Nestlé ha estimado un modelo logit para describir la elección de marcas en la categoría. Las
marcas consideradas en el modelo se presentan en la tabla a continuación.
PL: Marca propia del Supermercado (Private Labej)
EN: Fitness (Nestlé)
0: No tompra cereal (outsido option; utilidad deterministica = 0]
El modelo considera que, en cada visita de un hogar al supermercado, el hogar elige comprar una unidad de cereal de
una de las marcas disponibles o no comprar cereal (outside option), cuya utilidad determinística se normaliza a 0. Esto
es, la elección se considera a nivel de marcas.
La tabla siguiente describe cada una de las variables del modelo:
Preciojt: USD por unidad del producto de marca j en la visita t
Folleto_jt: 1 si un producto de la marca j aparece destacado en folleto durante la visita t, ); O en caso contrario
Exhibición_jt: 1 si un producto de la marca j estuvo en cabecera de góndola durante la visita t, ); O en caso contrario
durante la visita t (p. ej., pantallas digitales / digital signage); O en caso contrario.
Los resultados del estudio se presentan en la Tablas 1 y 2 a continuación:
u
-----
Tabla 1. Estadística descriptiva del Panel (promedios del período)
[USD, Precio al público]
Nota: La opción “no-choice” o “no-compra” es considerada la opción base en el modelo con variables Precio, Folleto,
Exhibición y RMN iguales a cero. La constante de esta opción es igual a la utilidad sistemática y es igual a 0.
Tabla 2. Parámetros estimados (Logit Multinomial)
¡Constante rn] 050 | 0x0]
loteo [030 | 006 |
Pseuio | 029
pomino ] 00 UNA
Se pide responder:
1. Nestlé está evaluando lanzar una nueva campaña de retail media in-store para su marca Fitness (FN). El retailer
ofrece una activación de retail media con un costo de US$ 14.000 para un período de campaña en la que se proyectan
1 millón de visitas. Suponga que la contribución para Nestlé por cada unidad vendida de (EN) es US$ 1. Considere
como escenario base aquel en que ambas marcas tienen Folleto = Exhibición = RMN = 0, y que los precios de cada
marca son los precios a público promedio del período estudiado. Como dato adicional, las probabilidades de elección
predichas por el modelo en este escenario base (RMN = 0) son:
Py : no compra cereal =0,678 | Compare con un escenario alternativo en que solo Fitness activa retail media
Pp, : marca propia = 0,264 (RMN = 1 para FN), manteniendo todo lo demás constante. En base a la
. información presentada en las tablas 1 y 2, evalúe si conviene invertir en la
Pen : Fitness = 0,058 A .
activación in-store de RMN para Fitness.
Para responder debe calcular lo siguiente:
a. Calcule las probabilidades de elección predichas por el modelo en el escenario con campaña.
b. Calcule el beneficio neto incremental esperado para Nestlé (en US$) asociado a la campaña.
e. Con base en (ii), indique si Nestlé debiera invertir en el paquete RMN bajo la regla: invertir solo si el beneficio
neto incremental esperado es mayor que cero. Explique brevemente.
2. Considere la misma campaña de retail media in-store para Fitness (FN) que en la pregunta anterior, pero ahora desde
la perspectiva del retailer. Suponga que el margen unitario del retailer (precio retail menos precio por mayor pagado
por el supermercado a la marca) por unidad es de USD$0,80 para la marca propia (PL) y de USD$0,30 para Fitness
de Nestlé (FN). Suponga también que implementar la campaña implica un costo incremental para el retailer de
US$ 3.000.
a. Antes de hacer cualquier cálculo, ¿Esperaría que el margen total del retailer por ventas en la categoría cereales
(considerando el millón de visitas) aumente o disminuya cuando solo FN activa RMN? Justifique brevemente en
forma cualitativa. En su justificación, indique dos posibles fuentes de ese cambio.
b. Calcule el margen total esperado del retailer por ventas (en US$) en el escenario base (RMN = 0) y en el escenario
con campaña (RMN = 1 solo para FN), así como el beneficio neto esperado del retailer, producto de la venta de
la activación in-store RMN a Nestlé.
2
-----


# Examen de grado · enunciado-e-g--1-21-parte-1-y-2

Fuente: examen anterior

[pág. 1]
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Esta parte del examen contiene las preguntas número 1, 2 y 3 en cinco páginas que están numeradas
 correlativamente, después de esta carátula, con los números 1 al 5 (ambos inclusive).
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con dos
 hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas, ni utilizar
 hojas adicionales.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta. Suponga
 que los datos que ha recibido están correctamente calculados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente a la
 realidad de las empresas que allí se mencionan.
5. Si, como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente indicados
 dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen la
 misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente a la Profesora Marta Del Sante A., Presidente de la
 Comisión de Examen de Grado, quien responderá sólo a través del correo examen.admuc@gmail.com en el
 horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas, etc.). El
 cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. Manténgase permanentemente conectado a su sesión de Zoom con la cámara encendida y el micrófono en
 silencio. Cualquier inconveniente que se le presente con la cámara o el micrófono, siga el protocolo señalado en
 el punto 12 del instructivo que Ud. recibió.
11. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante el
 examen.
12. Al terminar el examen, Ud. debe remitir al correo señalado en el instructivo que Ud. recibió, solamente el
 cuadernillo con las hojas de respuesta (6 en total) y el Código de Honor en formato pdf.
Fecha : 20 de enero de 2021
Duración : 105 minutos (9:00 horas aprox a 10:45 horas aprox).
Envío de respuestas : 10 minutos (10:45 horas aprox a 10:55 horas aprox).
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá la
 Profesora Marta Del Sante, por correo, entre las 9:20 y 9:30 hrs. (aprox.), y luego entre las
 10:00 y 10:10 hrs. (aprox.).

[pág. 2]
1
PREGUNTA Nº1
Para bien o para mal, Starbucks ha logrado acaparar el mercado mundial de las cafeterías, ofreciendo una
experiencia que va más allá del producto o la bebida como tal. Nestlé lo sabe, y por ello decidieron desembolsar
$500 millones de dólares el año 2017 para adquirir la parte mayoritaria de la marca Blue Bottle.
Blue Bottle es una marca que pertenecía hasta el año 2017 a Bottle Coffee Company. W. James Freeman fundó está
compañía en los 2000 en Oakland, California, con la idea de tostar el café en pequeñas cantidades y así vender el
café recién tostado directamente a las casas haciendo home-delivery.
El café de Blue Bottle se caracteriza por la calidad de sus granos, las técnicas de tostado y las preparaciones refinadas
que han ido variando la cultura del café en la actualidad. De esta forma, el café pasó de ser visto como un commodity
a convertirse en un producto de lujo, como pueden ser actualmente el vino o la cerveza artesanal.
A partir de lo anterior, Blue Bottle Coffee se convirtió en un referente en el mundo del café premium enfocada a
los fanáticos del café ya sea en sus locales físicos como a su creciente base de clientes que mantienen una suscripción
online mensual, de la cual reciben tanto las últimas novedades de los productos de la marca como las compras que
llevan a cabo.
Blue Bottle Coffee nació para aquellas personas que buscan un tostador artesanal que ofrezca café de mayor calidad,
de “origen responsable” y con un buen servicio al cliente. La propuesta de valor de la marca busca diferenciarse por
la calidad del producto, solo se sirve café tostado en las últimas 48 horas para que sea degustado en el punto álgido
de sabor. Estos valores y posicionamiento le ayudan a diferenciarse de otras grandes cadenas que compiten en su
mercado.
La marca ha desarrollado guías, vídeos y cursos sobre cómo comprar, almacenar y preparar un buen café. De esta
manera se alinean con su propuesta de valor y muestran su amor por el producto y les ayuda a justificar el precio
más alto a pagar por su producto.
En el año 2006, W.James Freeman se dio cuenta de la importancia de las tiendas físicas para que el consumidor
pudiera vivir la experiencia completa del café además de construir un concepto único en el diseño de las tiendas. El
primer local fue abierto en San Francisco y se diferencian de otras cadenas de café no sólo por la calidad de éste
sino que también por el diseño de éstos. En lugar de adoptar un modelo estandarizado, sus cafeterías son elegantes,
modernas y reflejan las características únicas del barrio en el que se encuentran. Esto crea una atmósfera en la que
uno no solo disfruta de la taza de café, sino que se siente muy bien al mismo tiempo. Asimismo, caminando por la
calle y a decenas de metros de distancia, los consumidores pueden apreciar claramente como destaca la imagen de
la Botella Azul haciéndose fácilmente reconocible por todos.
Las tiendas eran visitadas por consumidores jóvenes exploradores y con estilo que buscaban atributos más allá del
café. El concepto del café era de calidad superlativa y experiencial debido a la forma en la que se preparaba y servía
lo que le permitía cobrar entre 2 a 3 veces el valor de un café en Starbucks. Los consumidores buscaban ser parte
de un grupo especial que tenían en común la inquietud por tener experiencias sensoriales únicas. Se podían apreciar
en Manhattan y en California filas de consumidores millennials y hípsters esperando por un café especial no
industrial. Poco a poco diversos inversionistas relacionados con la industria tecnológica como Garrett Camp (Uber),
Evan Williams (Twitter) y Kevin Systrom (Instagram) comenzaron a invertir en esta empresa para mejorar la
calidad de los productos, hacerlos más sustentables y expandir los locales en Estados Unidos y Japón.
El Gerente de Marketing a nivel global del Negocio de Café en Nestlé, Cliff Mc Gregor, miraba con mucha
detención la evolución de esta marca y veía como las ventas en Estados Unidos de Blue Bottle crecían 5 a 6 veces
más rápido que las marcas de café de Nestlé: Nescafé y Nespresso. La primera de ellas está orientada a un mercado
más masivo, el cual consume café instántaneo en polvo y que se caracteriza por tener una producción del tipo más
industrial. Para estos segmentos de mercado Nestlé tiene las siguientes marcas: Nescafé Fina Selección, Nescafé

[pág. 3]
2
Clásico, Nescafé Dolca, Nescafé Decaf y Nescafé Expresso. Por su parte, Nespresso es una marca que está orientada
al segmento premium, la cual cuenta con locales propios donde se vende un café en granos envasado en cápsulas
de alta calidad.
Dado que el nuevo CEO de Nestlé, Mark Schneider, le pidió a todos los Gerentes Globales de Marketing ideas de
nuevas marcas para ser adquiridas, Cliff presentó Blue Bottle como una tremenda oportunidad de largo plazo dado
el aporte de capital de marca que Blue Bottle podía hacer al portafolio de marcas de cafés de Nestlé. Finalmente en
2017, Nestlé adquiere el 68% de la propiedad de la marca Blue Bottle y sus 50 tiendas en U$500 millones. Decide
que la administración se siga manteniendo totalmente independiente a Nestlé.
De acuerdo al Gerente de Marketing de Nestlé, Blue Bottle le da una porción más grande del mercado de Estados
Unidos, el más grande del mundo. Además, ofrece oportunidades para que Nestlé crezca en el café listo para beber
y café tostado y molido, especialmente a través de suscripciones en línea.
Se pide responder:
a) El Gerente de Finanzas aprobó con muchas dificultades la compra de Blue Bottle ya que su evaluación del valor
 de las tiendas físicas y la fábrica no era más de U$50 millones. De acuerdo a sus conocimientos del concepto
 de valor de marca, ¿cuáles serían a su juicio los tres principales argumentos que habría entregado Cliff
 McGregor para que Nestlé invirtiera 10 veces ese valor? Justifique claramente su respuesta.
b) El mes pasado, el CEO de Nestlé le pide a Cliff Mc Gregor una presentación de cómo ha andado el negocio.
 Cliff con mucho orgullo le muestra los excelentes resultados en ventas, utilidades e indicadores de marca por
 sobre los presupuestados. El CEO le pide a Cliff analizar la opción de que Blue Bottle se transforme en una
 marca del portfolio de Nescafé de manera de capitalizar mejor esos buenos resultados. Considerando alguno de
 los modelos de arquitectura de marca que usted conoce, ¿debería Cliff McGregor apoyar o no la idea del CEO
 de incorporar la marca Blue Bottle al portafolio de la marca Nescafé? Justifique su elección utilizando el modelo
 de arquitectura de marca seleccionado.

[pág. 4]
3
PREGUNTA Nº2
“Esta pandemia nos hace reflexionar sobre las prioridades que nuestro personal tiene respecto de su trabajo. Al
mismo tiempo, y en una empresa que vende servicios informáticos, como la nuestra, orientada a la calidad de las
soluciones que entregamos y a una relación personalizada y de largo plazo con nuestros clientes, debemos analizar
la efectividad de las prácticas de gestión de personas que implementamos. Más aún, el hecho de que el 100% de
nuestros equipos estén laborando en teletrabajo, le agrega grados de complejidad a nuestra tarea gerencial”.
Estas eran algunas de las reflexiones de Juan Carlos Bodoque, gerente general de “62 Segundos” (62S), al recibir
los resultados de un estudio encargado sobre los factores que influían en la satisfacción con el teletrabajo en su
empresa1. Bodoque sabía que tenía que mantener su reconocida diferenciación en el mercado, que tanto le había
costado obtener. Al mismo tiempo, tenía muy claro que 62S enfrentaba restricciones presupuestarias ya que la caída
de actividad a nivel general en la economía durante 2020 también había golpeado a su empresa.
Bodoque, se detuvo en una lámina del estudio que resumía los factores que tenían mayor impacto en la satisfacción
con el teletrabajo, la que se muestra a continuación:
 Calidad de vida laboral que
 incluye la carga de trabajo, los
 niveles de estrés que se generan y 0,33
 las posibilidades de tomar algún
 descanso en la jornada laboral
 Espacio físico adecuado en el Adaptabilidad Individual
 0,31
 hogar para hacer teletrabajo
 0,07 0,24
 Liderazgo que entregue un Productividad
 adecuado feedback en R²: 0,21
 condiciones de teletrabajo a las Satisfacción Teletrabajo
 personas, que responda R²: 0,51
 consultas de sus equipos a 0,13 Continuidad Teletrabajo
 tiempo y que haga coaching para R²: 0,23
 entregar herramientas que 0,02 0,48
 mejoren el teletrabajo de su
 personal a cargo
 Coordinación efectiva
 Contar con los equipos,
 conectividad y otros insumos 0,11
 para realizar teletrabajo
 Nivel de adecuación de los
 diferentes cargos a las
 condiciones de teletrabajo en
 cuanto a la posibilidad de 0,05
 trabajar desde el hogar o la
 necesidad de realizar
 presencialmente las labores
Mediante un modelo causal previamente definido, se encontraron que son cinco variables externas a la persona que
explican (de manera estadísticamente significativa), la satisfacción de los empleados de 62S con el trabajo a
distancia. A su vez, se determinó que la satisfacción con el teletrabajo impacta positivamente la productividad de
los trabajadores en sus labores y el deseo de continuar teletrabajando en el futuro. El modelo incluye dos variables
personales como son la capacidad de adaptación y de coordinación de cada persona a la nueva forma de trabajo
analizada. También aparecen los “coeficientes de ruta” (cuadrados pequeños), que son ponderaciones de regresión
lineal utilizados para examinar el vínculo causal entre las variables. Por ej., al mejorar en un punto la evaluación
que los trabajadores tienen de su líder, la Satisfacción con el Teletrabajo se incrementa en 0,13 puntos, como indica
el modelo. Por último, se muestra el coeficiente R2, que indica la proporción de la varianza total de la variable
explicada por la regresión, reflejando la bondad del ajuste del modelo a la variable que se pretende explicar.
1 Para su análisis, considere que, desde el punto de vista estadístico, el estudio presentado es técnicamente correcto y confiable.

[pág. 5]
4
Al revisar los mismos datos, el gerente de Operaciones de 62S, Tulio Triviño, señaló: “Por fin en recursos humanos
contamos con datos duros para tomar decisiones. El estudio de teletrabajo y en particular las variables que explican
de manera causal la satisfacción con el teletrabajo y luego la productividad del personal junto a su deseo de
permanecer en dicha modalidad laboral, nos entregan un mensaje claro: debemos gestionar y dedicar recursos a
dichas variables si queremos mantener nuestra diferenciación y por lo tanto el liderazgo en el mercado. Esas son las
variables que marcan la diferencia y vinculan nuestra gestión de personal con el logro de nuestras metas.”
Por su parte, Policarpo Avendaño, el gerente de Personas de la compañía, que también había tenido acceso a la
investigación, comentó en una reciente reunión del equipo ejecutivo que: “si bien el estudio sobre motivación en
condiciones de teletrabajo es riguroso, no apunta a lo que la empresa necesita para motivar a sus equipos. Son otras
las variables que debemos gestionar para lograr que las personas de 62S contribuyan de manera significativa, con
sus esfuerzos y capacidades, a mantener nuestros objetivos de diferenciación en el mercado.”
Se pide responder:
 1. Partiendo de la base del comentario de Tulio Triviño, señale dos consideraciones que se deben tener usted
 en cuenta para hacer una adecuada gestión de dichas variables. Justifique su respuesta
 2. ¿Comparte la opinión de Policarpo Avendaño? Fundamente su respuesta de manera precisa.

[pág. 6]
5
PREGUNTA Nº3
El pasado 24 de diciembre de 2020 la compañía chilena SQM (Sociedad Química y Minera de Chile) anunció la
idea de impulsar un aumento de capital por aproximadamente US$1.100 millones.1 Dicho aumento de capital
representaría aproximadamente un 10% de la capitalización bursátil total de SQM a la fecha. Los fondos serían
usados para financiar, en parte, el plan de expansión de US$1.900 millones de la compañía en los años 2021-2024.
Suponga que este plan de expansión era desconocido para el mercado antes del 24 de diciembre 2020. La expansión
considera el crecimiento de las operaciones de litio, nitrato y yodo. Gran parte de las inversiones se realizarían en
Chile, en particular en el desierto de Atacama, donde están las mayores reservas de litio del mundo. Además de
múltiples aplicaciones industriales, el litio es usado en baterías de dispositivos electrónicos, y últimamente en
baterías de autos eléctricos.
El mismo día del anuncio, la acción de SQM cerró su cotización bursátil con una caída de 4,21% (desde un precio
cierre de $35.180 el 23 de diciembre a un precio cierre de $33.698 el 24 de diciembre). El IPSA (índice que permite
medir el desempeño del mercado accionario chileno) cerró ese mismo día con una caída de 0,55%. El beta de las
acciones de SQM se estima que es igual a 0,9. La caída del precio de SQM después del anuncio contrasta con las
alzas que había experimentado la acción en el último tiempo, en línea con la recuperación del precio del litio a nivel
mundial. Algunos analistas estimaban que, después del anuncio, el precio de la acción de SQM debería permanecer
“plano” hasta que se llevara a cabo la junta de accionistas del próximo 22 de enero 2021, donde formalmente se
sometería a votación el aumento de capital. El aumento de capital no puede ser ejecutado sin esa aprobación.
Suponiendo que el mercado bursátil chileno es eficiente y que no existen fricciones informacionales, es decir, todos
los partícipes del mercado (inversionistas minoritarios, controladores, corredores de bolsa, etc.) cuentan con la
misma información, a Ud. se le pide responder las preguntas que se le formulan a continuación, entregando los
fundamentos correspondientes:
a) ¿Cómo es posible interpretar la caída del precio de la acción de SQM, frente al anuncio del aumento de capital,
 el 24 de diciembre de 2020? ¿Qué “cuentas” parecería estar sacando el mercado frente a este anuncio?
b) Considere ahora que pueden existir asimetrías de información entre los participantes del mercado bursátil y los
 controladores de SQM. Suponga que no existe ninguna otra fricción que diferencie este mercado de un mercado
 clásicamente eficiente. ¿Cómo puede ayudar la información asimétrica a explicar la caída en precio después del
 anuncio? Sea breve y preciso en su descripción de los elementos necesarios para racionalizar esta reacción de
 mercado bajo el supuesto de que existe información asimétrica. Compare sus conclusiones de (a) y (b).
c) Suponga que usted está analizando las perspectivas futuras de la acción de SQM con la información disponible
 después del anuncio, es decir, usted está haciendo su análisis al cierre del 24 de diciembre 2020. ¿Cuál es la
 mejor predicción del precio de SQM que usted puede hacer hoy, al cierre del 24 de diciembre de 2020, para el
 día 22 enero 2021, justo antes de que se lleve a cabo junta de accionistas? ¿Es razonable esperar una mantención
 del precio alrededor de los $33.698, es decir, un precio aproximadamente “plano” hasta la junta de accionistas,
 como sugieren algunos analistas? ¿Es predecible una recuperación de la caída del 24 de diciembre o, por el
 contrario, una profundización de la caída? Justifique su respuesta.
1 SQM tiene dos series de acciones, A y B. El aumento de capital y todos los precios reportados en esta pregunta se
refieren a SQM-B. Para efectos de responder esta pregunta, Ud. puede ignorar la existencia de dos series de acciones y
responder como si solo existiera una serie.

[pág. 7]
INFORMACIÓN GENERAL E INSTRUCCIONES:
1. Esta parte del examen contiene las preguntas número 4, 5 y 6 en cinco páginas que están numeradas
 correlativamente, después de esta carátula, con los números 1 al 5 (ambos inclusive).
2. Para contestar cada pregunta, Ud. dispone de dos carillas de hojas tamaño carta, es decir, Ud. cuenta con
 dos hojas que sólo se pueden utilizar por el anverso. Para responder, no se debe usar el reverso de las hojas,
 ni utilizar hojas adicionales.
3. Para responder, utilice solamente la información que se le ha entregado en el enunciado de la pregunta.
 Suponga que los datos que ha recibido están correctamente calculados.
4. No necesariamente toda la información que se entrega en las distintas preguntas corresponde exactamente
 a la realidad de las empresas que allí se mencionan.
5. Si, como parte de alguna de sus respuestas Ud. hace uso de uno o más supuestos, deje expresamente
 indicados dichos supuestos. Ciertamente, los supuestos no pueden llegar a cambiar el tema ni el sentido de
 la pregunta.
6. Cuando dentro de un tema del examen se presentan varias preguntas, no necesariamente todas ellas tienen
 la misma ponderación al momento de ser evaluadas.
7. Las preguntas de enunciado se podrán hacer solamente a la Profesora Marta Del Sante A., Presidente de la
 Comisión de Examen de Grado, quien responderá sólo a través del correo examen.admuc@gmail.com en el
 horario de consultas indicado más abajo.
8. NO está autorizado el uso de calculadoras que permitan almacenar "textos" (calculadoras alfanuméricas,
 etc.). El cumplimiento de esta norma es de absoluta responsabilidad del alumno.
9. Usted NO debe escribir su nombre en las hojas de respuesta.
10. Manténgase permanentemente conectado a su sesión de Zoom con la cámara encendida y el micrófono en
 silencio. Cualquier inconveniente que se le presente con la cámara o el micrófono, siga el protocolo señalado
 en el punto 12 del instructivo que Ud. recibió.
11. Cada alumno(a) es responsable de disponer de los medios para el conocimiento personal de la hora durante
 el examen.
12. Al terminar el examen, Ud. debe remitir al correo señalado en el instructivo que Ud. recibió, solamente el
 cuadernillo con las hojas de respuesta (6 en total) y el Código de Honor en formato pdf.
Fecha : 21 de enero de 2021
Duración : 105 minutos (9:00 horas aprox a 10:45 horas aprox).
Envío de respuestas : 10 minutos (10:45 horas aprox a 10:55 horas aprox).
Consultas : Las consultas que puedan surgir sobre el enunciado de las preguntas, las responderá la
 Profesora Marta Del Sante, por correo, entre las 9:20 y 9:30 hrs. (aprox.), y luego entre
 las 10:00 y 10:10 hrs. (aprox.).

[pág. 8]
1
PREGUNTA Nº4
El 4 de enero recién pasado, los accionistas de Fiat Chrysler (FCA) y de Peugeot S.A. (Grupo PSA) dieron su
aprobación a la mega fusión de estos dos colosos de la industria automotriz, convirtiéndose así en el cuarto mayor
fabricante de autos del planeta. Con una producción de poco de más de 8 millones de vehículos e ingresos por 203
mil millones de dólares, se espera que Stellantis (nombre de la empresa fusionada) juegue un papel clave en la
industria en especial en la nueva era de la electrificación, que ya cuenta con desarrollos de otras empresas que llevan
la delantera. La nueva empresa contará con más de 400 mil empleados y albergará 14 marcas emblemáticas como
Citroën, Maserati, Fiat, Opel, Peugeot, Alfa Romeo, Chrysler, Dodge y Jeep. El presidente de Stellantis será John
Elkann, actual Presidente de FCA.
El comunicado que informaba al mercado acerca de esta operación indicaba lo siguiente: “La entidad fusionada
estará particularmente bien posicionada para proporcionar soluciones de movilidad innovadoras, limpias y
sostenibles. Las ganancias en eficiencia derivadas de mayores volúmenes, así como los beneficios de unir las
fortalezas y competencias de las dos compañías, asegurarán que el negocio combinado pueda ofrecer a todos sus
clientes los mejores productos, tecnologías y servicios de su clase y responder con mayor agilidad al cambio que
tiene lugar en este sector tan exigente".
Lo que está en juego
Diversos documentos publicados estiman que la fusión tendrá costos administrativos directos del orden de US$
4.900 millones (honorarios de abogados, indemnizaciones de personal, otros ajustes, etc.) y se espera ahorrar en el
tiempo una cifra equivalente a US$ 6.130 millones por año, como consecuencia de "optimizar las inversiones en
plataformas de vehículos, familias de motores y nuevas tecnologías, al tiempo que lograr ahorros por el aumento
en la escala", señalaba Elkann.
Analistas de la industria señalaban que la fortaleza de FCA estaba en los mercados de Norteamérica y
Latinoamérica, mientras que la de PSA en el europeo. Sin embargo, ambas empresas son consideradas débiles en
los mercados estratégicos de China e India. A modo de referencia y considerando la empresa fusionada, el 46% de
los ingresos provendrían del mercado europeo, el 43% del mercado norteamericano, y sólo un 11% del resto de los
mercados mundiales.
Se espera que PSA aporte a la fusión sus capacidades de diseño y tecnología, y los trabajos que ha comenzado a
desarrollar en vehículos eléctricos e híbridos. La fusión le viene bien a PSA por el crecimiento potencial en el
mercado norteamericano y por sus altos costos de producción, investigación y desarrollo dado el mayor volumen
de operación que se proyectaría.
Lo que no parece estar claro es qué aporta a la fusión el Grupo FCA, que en los últimos años ha enfrentado malos
resultados en las evaluaciones que realiza el medio especializado y referente en la industria “Consumer Reports”.
En efecto, información entregada por esta publicación muestra evaluaciones en rangos deficientes para varias de las
marcas de FCA. Por ejemplo, en pruebas en autopistas, importantes marcas de FCA han sido evaluadas en rangos
bajos entre competidores de sus respectivas categorías. Del mismo modo, las calificaciones en confiabilidad y
economía de combustible no fueron mejores para varias de las marcas de FCA.
Sin perjuicio de lo anterior, según especialistas lo peor de algunas de las marcas del grupo FCA es que no han
logrado responder con rapidez a las tendencias cambiantes en las preferencias de los consumidores en todo el
mundo, quienes buscan diseños atractivos, estilo, mayor potencia, pero con menor consumo, eficiencia y seguridad
lo que inevitablemente lleva a un mayor enfoque en la innovación.
Dos empresas, dos estilos
Pero las diferencias no están solo en los aportes proyectados para cada uno de los actores de esta fusión. También
están en la forma en cómo cada empresa ha sido gestionada hasta ahora. El Grupo PSA (Peugeot) se ha caracterizado
por un ambiente de innovación en su gestión, con atención en el desarrollo de productos y en el diseño. Sus prácticas
de gestión también son innovadoras, incentivando la gestión autónoma, la multifuncionalidad en sus cargos y el uso
de herramientas de gestión de vanguardia como sistemas de incentivos multivariados, matrices de control de
desempeño y procesos de evaluación sofisticados. Por su parte FCA (Fiat Chrysler) ha sido una empresa más
tradicional, con un sistema propio heredado desde su fundación, muy basado en políticas y pautas definidas y muy

[pág. 9]
2
claras. Su esencia ha estado en optimizar el costo del producto, aunque ello pudiera haber afectado otras variables
sensibles como el diseño de los modelos. Al final, “un precio bajo es lo que busca el consumidor”, según declaraba
uno de los ejecutivos de FCA.
Considerando sólo la información que se presenta en el caso, responda las siguientes preguntas.
 1. Desde un punto de vista netamente conceptual de Estrategia Corporativa, ¿bajo qué condiciones una fusión
 como la planteada cumpliría el objetivo que se espera tenga una buena fusión? ¿Qué elementos, también
 conceptuales, determinan el hecho que se cumpla o no lo anterior?
 2. Entrando ahora de lleno a la fusión descrita entre FCA y PSA y considerando sólo los elementos planteados
 en el caso, ¿Se justifica una fusión como la anunciada desde un punto de vista de una buena estrategia
 corporativa? Argumente y justifique.
 3. Para que esta fusión se implemente exitosamente, ¿cuáles son los tres principales riesgos que se deberían
 gestionar –y que deben ser enfrentados con prioridad– por parte del Presidente de Stellantis John Elkann?

[pág. 10]
3
PREGUNTA Nº5
El mercado de galletas en Chile llega a $ 200 mil millones anuales en ventas según datos de la empresa de
investigación de mercado Nielsen Chile, y viene creciendo a un ritmo de 1% en supermercados y más de 4% en el
canal tradicional de almacenes. Las empresas que lideran este mercado son Costa (Costa, Vivo) que tiene una
participación de 36%, Nestlé (McKay) con 32% y Arcor (Dos-en-Uno, Bon-o-Bon) con 13%. El resto del mercado
se distribuye entre fabricantes pequeños y marcas propias.
En la categoría de galletas dulces, los dos fabricantes más grandes, Costa y Nestlé, han introducido en el último
tiempo varias innovaciones de galletas con trocitos de frutos secos y chocolates. Arcor no ha sido tan activo en estas
innovaciones y los ejecutivos del área de marketing de Arcor consideran que esto puede explicar la disminución en
su participación de mercado en esta categoría. En respuesta a lo anterior, los ejecutivos del área galletas de Arcor
preparan un plan que consiste en lanzar nuevas galletas con trocitos de frutos secos para competir de mejor forma
con Costa y Nestlé. Para esto encargan una propuesta metodológica a una empresa de investigación para realizar un
estudio de mercado que permita estimar las preferencias de los consumidores en la categoría de galletas dulces. La
propuesta enviada por la empresa de estudios tiene las siguientes características técnicas:
Estudio: Análisis Conjunto con método de Perfil Completo (Método Indirecto)
Muestra: 720 casos con cuestionario aplicado a personas que consumen regularmente galletas dulces
Atributos y Niveles: Los atributos y niveles considerados en el estudio se presentan en la tabla siguiente.
 Atributo Nivel 1 Nivel 2 Nivel 3 Nivel 4
 Marca Arcor Costa Nestlé
 Formato* Mini Rollo Familiar
 Fruto Seco Avellanas Cranberries Frambuesas Manzanas
 Precio $1.000 $1.500 $2.000 $2.500
 (*) Formato Mini es pequeño, como colación y para escolares. Formato rollo o tubo es el formato tradicional de las galletas para 2 ó 3 personas.
 Formato familiar es un formato más grande orientado a toda la familia.
Resultados: Los resultados del estudio, en cuanto a preferencias de los consumidores, se entregarán a nivel agregado
(para la muestra completa) y para segmentos de edad y sexo.
Cuando la propuesta del estudio se le presenta al directorio de Arcor, tres de sus miembros hacen los siguientes
comentarios:
Director 1: No parece necesario hacer un estudio en base a encuestas cuando se tiene disponible la información del
panel de consumidores de la empresa de investigación de mercado Nielsen Chile (equivalente a Panel de Kantar
World Panel) con las compras efectivas de cada consumidor y con el precio pagado. Se podría usar un modelo de
elección de marca con esta información de compras efectivas.
Director 2: Los resultados a nivel agregado, o con segmentaciones por variables demográficas, son muy poco útiles
para una empresa relativamente pequeña como Arcor. A nivel agregado, siempre Costa y Nestlé aparecerán con las
mayores preferencias.
Director 3: Hay atributos que no están presentes en el estudio, como por ejemplo los logos de Alto en Azúcar,
Calcio y Grasas. Me parece que la ausencia de estos atributos puede sesgar significativamente los resultados.
Sobre la base de la información que se le ha presentado, a Ud. se le pide responder las siguientes preguntas,
entregando los fundamentos correspondientes:
 a) Considerando el comentario del Director 1, ¿existe alguna ganancia con la metodología que propone la
 empresa de investigación de mercado? Justifique su respuesta.
 b) Según el comentario del Director 2, ¿es posible con los resultados de la metodología que se propone, hacer
 segmentaciones más finas (detalladas) según preferencias de los consumidores? Justifique su respuesta.
 c) ¿Está usted de acuerdo con el comentario del Director 3, en el sentido de que la ausencia del atributo Logo
 (Alto en Azúcar, Calcio y Grasa) puede sesgar significativamente los resultados del estudio? Justifique su
 respuesta.

[pág. 11]
4
PREGUNTA Nº6
La empresa minera “El Litio Dorado”, acaba de construir un túnel para el uso privado de sus camiones, que
permite acortar el camino entre dos ciudades en 40 kms. y evita transitar por cuestas muy pronunciadas.
El monto de la inversión inicial en el túnel (costo de construcción y de sus vías de acceso) fue de $10.000.000 ($ de
hoy) y los costos de mantenimiento y reparación anual del túnel, que son función exclusiva de la variable tiempo
(no dependen de la densidad del tráfico), ascienden a $65.000 anuales, los que se deben pagar en efectivo al final
de cada año.
Para ayudar a cubrir sus costos, la empresa decidió abrir el túnel al público y cobrar un peaje. Dado que mañana
será la inauguración del túnel al público, la empresa se ha visto obligada a fijar rápidamente y sin mayor análisis el
precio que cobrará por el peaje (derecho a usar el túnel) a los vehículos que decidan usarlo, por supuesto en el
entendido que los camiones de la propia empresa no pagarían dicho peaje. El precio que ha fijado es de $250 por
vehículo.
Se estima que la demanda anual por el uso del túnel es una función del siguiente tipo:
 q = 6.000 – 2p (ver Nota #1)
Donde: q = Número de vehículos que paga peaje en el año
 p = Precio del peaje por vehículo, en pesos.
Nota #1: Esta función de demanda, excluye a los camiones de la propia empresa que podrían llegar a usar el túnel
Para todos los proyectos que se deban evaluar, suponga que:
  Todos los costos y gastos anuales, lo mismo que las reinversiones que haya que hacer anualmente, son
 flujos de caja que se producen al término de cada año.
  No hay inflación y tampoco IVA.
  Hay una única tasa de descuento relevante y ésta es de 10% anual.
Se Pide:
1. Suponiendo que:
  La empresa dueña del túnel ha fijado un único valor del peaje de $250 por vehículo, distinto de los
 vehículos de la propia empresa, que use el túnel.
  Por el hecho de poder usar el túnel, la empresa ahorra $20.000 al año (menores egresos de caja al término
 de cada año) por concepto de sus propios costos de transporte.
  Si al término de cada año de operación del túnel la empresa reinvierte $88.000, el túnel tendría una vida
 útil de infinitos años y una depreciación de $100.000 por año hasta el infinito.
  La tasa de impuesto a la renta de las empresas privadas es de 40% sobre sus utilidades.
 Suponiendo que para la empresa no hay otros costos o beneficios involucrados como resultado del túnel que
 acaba de construir y que el túnel no genera cambio alguno en los demás ingresos y egresos de caja de la empresa
 como un todo, a usted se le pide que obtenga:
 a. El Valor Actual Neto o Valor Presente Neto (VAN) que tiene para la empresa el túnel que acaba de
 construir, teniendo en cuenta los $10.000.000 que tuvo que invertir.
 b. La Tasa Interna de Retorno (TIR) que tiene para la empresa el túnel que acaba de construir, teniendo en
 cuenta los $10.000.000 que tuvo que invertir.
 Nota #2: Usted debe presentar el detalle de los cómputos que sustentan sus respuestas.

[pág. 12]
5
2. Luego de 5 años de funcionamiento del túnel, el Gobierno ha estudiado la situación del túnel y teniendo en
 cuenta que el costo marginal de usar el túnel por vehículo es cero y que, por lo tanto, según el Gobierno, no se
 debería cobrar peaje, éste ha decidido negociar con la empresa dueña del túnel.
 El Gobierno ha decidido ofrecerle a la empresa un convenio, por medio del cual se compromete a pagarle un
 monto (en $) por cada vehículo que use el túnel (excluidos los vehículos de la empresa), en cuyo caso la
 empresa no cobraría peaje a los vehículos que usen el túnel, sino que se lo cobraría directamente al Gobierno.
 El Gobierno ha informado que, en caso de no llegar a un acuerdo con la empresa, procederá a construir otro
 túnel a 2 kms. de distancia del que actualmente tiene la empresa y canalizaría por el nuevo túnel el total del
 tráfico público, cobrando peaje cero. El costo de construcción del túnel para el Gobierno alcanza a los
 $16.500.000 ($ de hoy) y el costo de mantener el nuevo túnel sería de $80.000 al año, los que se pagarían al
 final de cada año. Suponga que si al término de cada año de operación del túnel el Gobierno reinvierte
 $120.000, el túnel tendría una depreciación anual de $100.000 y una vida útil de infinitos años.
 A Ud. se le solicita calcular el monto en pesos ($) del máximo valor por vehículo que use el túnel (excluidos
 los vehículos de la empresa), que la empresa dueña del túnel puede cobrar al Gobierno, de modo que éste (el
 Gobierno), esté indiferente entre aceptar ese convenio o construir su propio túnel. Fundamente su respuesta
 mostrando los cálculos necesarios y suponga que el Gobierno no paga impuestos.
 Ayuda:
  Recuerde la función de demanda entregada al inicio de la pregunta.
  Recuerde el supuesto de que la tasa de descuento siempre es de 10% anual.
3. Suponga ahora que el Gobierno decidiera eliminar el subsidio al uso del túnel que Ud. determinó en el punto
 anterior, para concentrar la ayuda económica en las múltiples familias y empresas que han sido afectadas por
 la pandemia del Covid 19. Concretamente, el Gobierno le otorga plena libertad a la empresa dueña del túnel
 para que ésta fije el precio del peaje a cobrar por cada vehículo que atraviesa el túnel.
 Suponiendo que se mantiene vigente toda la información entregada para el desarrollo de la pregunta “1”,
 excepto el precio de $250 a cobrar por vehículo, a Ud. se le pide determinar el precio del peaje por vehículo,
 que la empresa “El Litio Dorado” debiera cobrar a cada vehículo, si su objetivo fuese maximizar el total de sus
 ingresos anuales. Fundamente su respuesta mostrando los cálculos necesarios.

# Lo que más pregunta el examen

Temas que se repiten en los exámenes anteriores de cada ramo. Úsalo con los comandos «Repaso DP», «Repaso DE», «Repaso TF», «Repaso DF», «Repaso FM» y «Repaso MA».

## Dirección de Personas (DP)

estrategia y ajuste (AMO y alineamiento), incentivos y evaluación del desempeño, selección, contrato psicológico y rotación, cultura y diversidad, capacitación

## Dirección de Empresas (DE)

cinco fuerzas e industria, ventaja competitiva y VRIO, modelos de negocio y plataformas, estrategia corporativa (fusiones, diversificación, integración vertical y alianzas)

## Teoría Financiera (TF)

portafolios, CAPM y beta, eficiencia de mercado, arbitraje y derivados (paridad cubierta, CDS y cobertura), bonos y tasas, estructura de capital

## Finanzas II (DF)

VAN con flujos incrementales y reemplazo, valor de empresa frente a patrimonio y deuda, WACC, capital de trabajo, opciones reales y múltiplos

## Fundamentos de Marketing (FM)

marca y arquitectura, canales y marketplace, precio y guerras de precios, valor del cliente y customer journey

## Marketing Analytics (MA)

conjoint y disposición a pagar, logit y elección de marca, segmentación con k-medias, mapas perceptuales, diseño de investigación


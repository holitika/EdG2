# Temario y sesiones de estudio

Cada sesión tiene un código (por ejemplo DE 1). Para hacerla, escribe en tu IA: «Sesión DE 1».

## Sección 1 · Dirección

### Dirección de Personas (DP)

**Clases en orden del temario**

- Tema 1 · Introducción
- Tema 2 · Análisis y diseño de cargos
- Tema 3 · Reclutamiento y selección
- Tema 4 · Capacitación
- Tema 5 · Desempeño
- Tema 6 · Compensaciones, incentivos y beneficios
- Tema 7 · Talento y desarrollo de carrera
- Tema 8 · Salidas
- Tema 9 · Satisfacción laboral y cultura
- Tema 10 · Seguridad e higiene, disciplina
- Tema 11 · Relaciones laborales

**Sesiones de estudio**

#### Sesión DP 1 · Tema 1 · Introducción, estrategia y planificación de RR.HH. (modelo AMO, alineamiento, contrato psicológico)
- Clases: Tema 1 · Introducción
- Preguntas: Resolver marzo 2009 (Estrategia y ajuste, manual p. 88, respuesta p. 222); Leer agosto 2009 (Estrategia y ajuste, manual p. 90, respuesta p. 222)

#### Sesión DP 2 · Temas 2 y 3 · Diseño de puestos, reclutamiento y selección
- Clases: Tema 2 · Análisis y diseño de cargos; Tema 3 · Reclutamiento y selección
- Preguntas: Resolver marzo 2011 (Selección, cultura y retención, manual p. 130, respuesta p. 242); Leer agosto 2012 (Gestión por competencias, manual p. 106, respuesta p. 229)

#### Sesión DP 3 · Temas 4 y 5 · Capacitación y gestión del desempeño
- Clases: Tema 4 · Capacitación; Tema 5 · Desempeño
- Preguntas: Resolver enero 2016 (Indicadores, incentivos y cultura, manual p. 116, respuesta p. 234); Leer agosto 2015 (Formalización y productividad, manual p. 104, respuesta p. 228)

#### Sesión DP 4 · Tema 6 · Compensaciones, incentivos y beneficios
- Clases: Tema 6 · Compensaciones, incentivos y beneficios
- Preguntas: Resolver agosto 2011 (Incentivos por procesos o resultados, manual p. 112, respuesta p. 232); Leer enero 2014 (Incentivos y selección alineados, manual p. 114, respuesta p. 233); Leer agosto 2016 (Incentivos estrechos versus amplios, manual p. 108, respuesta p. 230)

#### Sesión DP 5 · Temas 7 y 8 · Talento, carrera y gestión de salidas
- Clases: Tema 7 · Talento y desarrollo de carrera; Tema 8 · Salidas
- Preguntas: Resolver enero 2013 (Bono de retiro y relaciones laborales, manual p. 75, respuesta p. 214)

#### Sesión DP 6 · Temas 9 a 11 · Clima, cultura, seguridad y relaciones laborales
- Clases: Tema 9 · Satisfacción laboral y cultura; Tema 10 · Seguridad e higiene, disciplina; Tema 11 · Relaciones laborales
- Preguntas: Resolver enero 2012 (Alineamiento de prácticas con servicio, manual p. 71, respuesta p. 213); Leer enero 2015 (Reforma laboral y alineamiento, manual p. 122, respuesta p. 237)

#### Sesión DP 7 · Integración · el sistema completo de personas y cómo responder un caso
- Preguntas: Resolver agosto 2014 (Sistema completo de RR.HH., manual p. 137, respuesta p. 244); Leer marzo 2010 (Estrategia y ajuste, manual p. 92, respuesta p. 223)
- Nota: Repaso integrador del ramo, sin clase nueva

### Dirección de Empresas (DE)

**Clases en orden del temario**

- Clase 8 · Ventajas competitivas y estrategias genéricas
- Clase 9 · Logro y sustentación de ventajas competitivas
- Clase 10 · Modelos de negocio
- Clase 11 · Estrategia de negocio
- Clase 12 · Mapas estratégicos
- Clase 13a · Agenda estratégica
- Clase 13b · Estrategia corporativa
- Clase 14 · Decisiones de diversificación
- Clase 15 · Concepto de implementación
- Clase 16 · Estructura organizacional
- Clase 17 · Control de gestión
- Clase 18 · Sistemas de incentivos
- Clase 19 · Sistemas de evaluación de desempeño
- Clase 24 · Ética y gestión de empresas

_Las clases 1 a 7 y 20 a 23 no están en la carpeta. Se ve desde el programa del curso._

**Sesiones de estudio**

#### Sesión DE 1 · Temas I y II · Proceso estratégico y análisis competitivo (cinco fuerzas)
- Preguntas: Resolver marzo 2009 (Industria/competencia, manual p. 172, respuesta p. 258); Leer agosto 2013 (Posicionamiento y eficiencia, manual p. 202, respuesta p. 271); Leer agosto 2011 (Cinco fuerzas y captura de valor, manual p. 152, respuesta p. 250)
- Nota: Sin diapositivas en la carpeta: se ve desde el programa del curso (JT caps. 1 a 3; Porter)

#### Sesión DE 2 · Tema III · Ventaja competitiva, estrategias genéricas y sustentación (VRIO)
- Clases: Clase 8 · Ventajas competitivas y estrategias genéricas; Clase 9 · Logro y sustentación de ventajas competitivas
- Preguntas: Resolver enero 2016 (Modelos productivos y ventaja, manual p. 200, respuesta p. 270); Leer agosto 2012 (Entrada y reacción competitiva, manual p. 162, respuesta p. 254)

#### Sesión DE 3 · Tema IV · Modelos de negocio y estrategia de negocio
- Clases: Clase 10 · Modelos de negocio; Clase 11 · Estrategia de negocio
- Preguntas: Resolver marzo 2011 (Modelo de negocio y ventaja competitiva, manual p. 198, respuesta p. 269); Leer enero 2015 (Guerra de precios en cloud, manual p. 168, respuesta p. 256)

#### Sesión DE 4 · Tema V · Estrategia corporativa, diversificación e integración vertical
- Clases: Clase 13b · Estrategia corporativa; Clase 14 · Decisiones de diversificación
- Preguntas: Resolver enero 2013 (Integración vertical/adquisición, manual p. 190, respuesta p. 266); Leer enero 2014 (Alianzas y ventaja sostenible, manual p. 148, respuesta p. 248)

#### Sesión DE 5 · Tema VI · Implementación: estructura, mapas estratégicos, agenda y control de gestión
- Clases: Clase 15 · Concepto de implementación; Clase 16 · Estructura organizacional; Clase 12 · Mapas estratégicos; Clase 13a · Agenda estratégica; Clase 17 · Control de gestión
- Preguntas: Resolver agosto 2015 (Evolución de estrategia y organización, manual p. 166, respuesta p. 256)

#### Sesión DE 6 · Temas VI y VII · Incentivos, evaluación del desempeño y ética
- Clases: Clase 18 · Sistemas de incentivos; Clase 19 · Sistemas de evaluación de desempeño; Clase 24 · Ética y gestión de empresas
- Preguntas: Leer agosto 2014 (Cooperación sectorial y redes, manual p. 156, respuesta p. 251)

## Sección 2 · Finanzas

### Teoría Financiera (TF)

**Clases en orden del temario**

- L1 · Introducción
- L2 · Arbitraje y derivados
- L3 · Decisiones
- L4 · Análisis media-varianza
- L5 · CAPM
- L6 · APT
- L7 · HME y finanzas conductuales
- L9 · Estructura de capital
- L10 · Política de dividendos

_La L8 no está en la carpeta. Se ve desde el programa del curso._

**Sesiones de estudio**

#### Sesión TF 1 · I · Introducción: mercados, retornos, tasas y bonos (curva y duración)
- Clases: L1 · Introducción
- Preguntas: Resolver enero 2012 (Curva de tasas, spreads y duración, manual p. 88, respuesta p. 203); Leer enero 2016 (Pesos, UF e inflación, manual p. 113, respuesta p. 214)
- Nota: Bonos no tiene diapositivas propias en TF (falta la L8): se ve con apoyo de la clase 17 de Finanzas II

#### Sesión TF 2 · II.A · Arbitraje, forwards, futuros y opciones (paridad put-call y binomial)
- Clases: L2 · Arbitraje y derivados
- Preguntas: Resolver agosto 2016 (Opciones y paridad, manual p. 108, respuesta p. 212); Leer agosto 2011 (Diversificación y tipo de cambio, manual p. 93, respuesta p. 205)

#### Sesión TF 3 · II.B y II.C · Decisiones bajo incertidumbre y análisis media-varianza
- Clases: L3 · Decisiones; L4 · Análisis media-varianza
- Preguntas: Resolver marzo 2010 (Riesgo y portafolios, manual p. 120, respuesta p. 217); Leer enero 2013 (Opciones y cobertura por estados, manual p. 107, respuesta p. 212)

#### Sesión TF 4 · II.D · CAPM y APT
- Clases: L5 · CAPM; L6 · APT
- Preguntas: Resolver agosto 2015 (Alfa, beta y elección de fondos, manual p. 72, respuesta p. 196)

#### Sesión TF 5 · II.E · Eficiencia de mercado y finanzas conductuales
- Clases: L7 · HME y finanzas conductuales
- Preguntas: Resolver enero 2015 (Eficiencia de mercado y fondos, manual p. 95, respuesta p. 205); Leer agosto 2013 (Apalancamiento, múltiplos y eficiencia, manual p. 73, respuesta p. 196)

#### Sesión TF 6 · III · Estructura de capital y política de dividendos
- Clases: L9 · Estructura de capital; L10 · Política de dividendos
- Preguntas: Resolver enero 2014 (Deuda, estados y debt overhang, manual p. 90, respuesta p. 204); Leer agosto 2014 (Gordon y crecimiento sostenible, manual p. 102, respuesta p. 208)

### Finanzas II (DF)

**Clases en orden del temario**

- Clase 1 · Fundamentos
- Clase 2 · Financial manager
- Clase 3 · Liquidez, rentabilidad y riesgo
- Clase 4 · Riesgo-retorno
- Clase 5 · Costo de capital
- Clase 6 · WACC y estructura de capital
- Clase 7 · WACC y deuda óptima
- Clase 8 · Análisis financiero
- Clase 9 · Razones financieras
- Clase 10 · Caso NVIDIA
- Clase 11 · Caso CCU (3 archivos)
- Clase 12 · Planificación financiera
- Clase 13 · Crecimiento y financiamiento
- Clase 14 · Patrones de financiamiento
- Clase 15 · Patrones de financiamiento (Roher)
- Clase 16 · Modelos de financiamiento
- Clase 17 · Financiamiento de largo plazo
- Clase 18 · Administración del inventario
- Clase 19 · Administración de crédito
- Clase 20 · Administración de caja
- Clase 21 · Determinación de flujos
- Clase 23 · Criterios de evaluación de proyectos
- Clase 24 · Evaluación de proyectos y empresas
- Clase 25 · Casos especiales
- Clase 26 · Opciones reales
- Clase 27 · Múltiplos

_La clase 22 no está en la carpeta. Se ve desde el programa del curso._

**Sesiones de estudio**

#### Sesión DF 1 · I · Administrador financiero, liquidez, rentabilidad, riesgo y apalancamiento
- Clases: Clase 1 · Fundamentos; Clase 2 · Financial manager; Clase 3 · Liquidez, rentabilidad y riesgo; Clase 4 · Riesgo-retorno
- Preguntas: Resolver enero 2013 (Riesgo operacional y deuda, manual p. 182, respuesta p. 247)

#### Sesión DF 2 · I · Costo de capital, WACC y deuda óptima
- Clases: Clase 5 · Costo de capital; Clase 6 · WACC y estructura de capital; Clase 7 · WACC y deuda óptima
- Preguntas: Resolver agosto 2012 (WACC, beta y emisión de acciones, manual p. 192, respuesta p. 251); Leer enero 2012 (APV y escudo tributario, manual p. 127, respuesta p. 219)

#### Sesión DF 3 · II · Análisis financiero, razones y casos (NVIDIA y CCU)
- Clases: Clase 8 · Análisis financiero; Clase 9 · Razones financieras; Clase 10 · Caso NVIDIA; Clase 11 · Caso CCU (3 archivos)
- Preguntas: Resolver enero 2014 (DuPont, ROA y ROE, manual p. 137, respuesta p. 225)

#### Sesión DF 4 · III · Planificación financiera, ciclo de efectivo y FER
- Clases: Clase 12 · Planificación financiera; Clase 13 · Crecimiento y financiamiento
- Preguntas: Resolver enero 2016 (FER (fondos externos requeridos), manual p. 141, respuesta p. 226)

#### Sesión DF 5 · III y IV · Patrones de financiamiento y financiamiento de largo plazo (bonos)
- Clases: Clase 14 · Patrones de financiamiento; Clase 15 · Patrones de financiamiento (Roher); Clase 16 · Modelos de financiamiento; Clase 17 · Financiamiento de largo plazo
- Preguntas: Resolver agosto 2015 (Aumento de capital y derechos, manual p. 131, respuesta p. 222)

#### Sesión DF 6 · V · Capital de trabajo: inventarios, crédito y caja
- Clases: Clase 18 · Administración del inventario; Clase 19 · Administración de crédito; Clase 20 · Administración de caja
- Preguntas: Resolver agosto 2016 (Liquidez y capital de trabajo, manual p. 162, respuesta p. 237)

#### Sesión DF 7 · VI · Flujos de caja relevantes y tasa de descuento de un proyecto
- Clases: Clase 21 · Determinación de flujos
- Preguntas: Resolver marzo 2011 (Flujo de caja incremental y VAN, manual p. 143, respuesta p. 227); Leer agosto 2011 (Proyecto, deuda y nuevo socio, manual p. 170, respuesta p. 241)
- Nota: La clase 22 (tasa de descuento) no está en la carpeta: esa parte se ve desde el programa

#### Sesión DF 8 · VI · Criterios de evaluación (VAN, TIR, payback) y valoración de empresas
- Clases: Clase 23 · Criterios de evaluación de proyectos; Clase 24 · Evaluación de proyectos y empresas
- Preguntas: Resolver agosto 2013 (Perpetuidad, VAN y patrimonio, manual p. 168, respuesta p. 241); Leer agosto 2014 (Alternativas productivas y VAN, manual p. 129, respuesta p. 220); Leer enero 2015 (FCF, perpetuidad y financiamiento, manual p. 139, respuesta p. 225)

#### Sesión DF 9 · VI · Tópicos especiales: distinta vida útil, reemplazo, racionamiento y riesgo
- Clases: Clase 25 · Casos especiales
- Preguntas: Resolver agosto 2010 (Flujos/VAN/TIR, manual p. 153, respuesta p. 232); Leer marzo 2009 (Flujos/VAN/TIR, manual p. 147, respuesta p. 229)

#### Sesión DF 10 · VI y VII · Opciones reales y valoración por múltiplos
- Clases: Clase 26 · Opciones reales; Clase 27 · Múltiplos
- Preguntas: Resolver agosto 2018 (Árbol de decisión y opción real, manual p. 193, respuesta p. 252)

## Sección 3 · Marketing

### Fundamentos de Marketing (FM)

**Clases en orden del temario**

- Clase introductoria
- N°1 · Clase introductoria (v2023)
- N°3 · Modelos de negocios
- N°4 · Estrategias competitivas y centralidad en el cliente
- N°5 · Conducta del consumidor y shopper
- N°6 · Segmentación de mercado
- N°7 · Investigación de mercado
- N°8 · Posicionamiento
- N°10 · Estrategia de productos
- N°12 · Estrategias de servicios
- N°13 · Canales de distribución
- N°15 · Marketing digital
- N°18 · Ética y responsabilidad social
- Estrategias de precios
- Estrategias de marcas
- Comunicaciones
- Repaso prueba 1
- Repaso prueba 2
- Repaso examen 2023

**Sesiones de estudio**

#### Sesión FM 1 · Introducción, modelos de negocio y estrategias competitivas
- Clases: Clase introductoria; N°1 · Clase introductoria (v2023); N°3 · Modelos de negocios; N°4 · Estrategias competitivas y centralidad en el cliente
- Preguntas: Resolver marzo 2009 (Valor/cliente, manual p. 176, respuesta p. 289); Leer agosto 2015 (Plataforma de dos lados y surge pricing, manual p. 154, respuesta p. 278)

#### Sesión FM 2 · Conducta del consumidor, shopper e investigación de mercado
- Clases: N°5 · Conducta del consumidor y shopper; N°7 · Investigación de mercado
- Preguntas: Resolver agosto 2010 (Investigación, manual p. 142, respuesta p. 271); Leer agosto 2009 (Valor/cliente, manual p. 178, respuesta p. 291)

#### Sesión FM 3 · Segmentación y posicionamiento
- Clases: N°6 · Segmentación de mercado; N°8 · Posicionamiento
- Preguntas: Resolver enero 2014 (Nuevo producto, posicionamiento y canibalización, manual p. 150, respuesta p. 276); Leer marzo 2010 (Valor/cliente, manual p. 180, respuesta p. 292)

#### Sesión FM 4 · Estrategias de marcas
- Clases: Estrategias de marcas
- Preguntas: Resolver agosto 2013 (Capital y posicionamiento de marca, manual p. 124, respuesta p. 260); Leer enero 2013 (Marcas propias y posicionamiento, manual p. 146, respuesta p. 273); Leer enero 2015 (Respuesta competitiva y esencia de marca, manual p. 164, respuesta p. 283)

#### Sesión FM 5 · Estrategia de productos y de servicios
- Clases: N°10 · Estrategia de productos; N°12 · Estrategias de servicios
- Preguntas: Resolver enero 2016 (Premiumización y prueba de producto, manual p. 160, respuesta p. 281); Leer agosto 2016 (Servicio, precio y canal, manual p. 170, respuesta p. 287)

#### Sesión FM 6 · Estrategias de precios
- Clases: Estrategias de precios
- Preguntas: Resolver agosto 2012 (Promociones y plataforma de descuentos, manual p. 162, respuesta p. 282)

#### Sesión FM 7 · Canales de distribución
- Clases: N°13 · Canales de distribución
- Preguntas: Resolver marzo 2011 (Canales y cadena de valor, manual p. 122, respuesta p. 259); Leer agosto 2011 (Precio, difusión y canales, manual p. 156, respuesta p. 279)

#### Sesión FM 8 · Comunicaciones, marketing digital y ética
- Clases: Comunicaciones; N°15 · Marketing digital; N°18 · Ética y responsabilidad social
- Preguntas: Resolver agosto 2014 (Respuesta de marketing y regulación, manual p. 166, respuesta p. 284)

### Marketing Analytics (MA)

**Clases en orden del temario**

- Clase 1 · Introducción
- Clase 2 · Analítica y toma de decisiones
- Clase 3 · Lab 1: datos de ventas en retail
- Clase 4 · Analítica predictiva y causal
- Clase 5a · Estudios cualitativos
- Clase 5b · Introducción a la segmentación
- Clase 6 · Segmentación a priori: RFM
- Clase 7 · Clusters: métodos jerárquicos
- Clase 8 · Clusters (parte 2)
- Clase 9 · Clusters: Lab 3
- Clase 10 · Posicionamiento: introducción
- Clase 11 · Factores y mapas perceptuales
- Clase 12 · MDS y análisis de preferencias
- Clase 13 · Analítica de clientes
- Clase 14 · Valor económico del cliente
- Clase 15 · CLV contractual: beta-geométrico
- Clase 16 · CLV contractual: beta-geométrico (II)
- Clase 17 · CLV no contractual: Pareto/NBD
- Clase 18 · Modelos de predicción de respuesta
- Clase 19 · Árboles de decisión
- Clase 20 · Evaluación de modelos de clasificación
- Clase 21 · Predicción de fuga y retención
- Clase 22 · Cross-selling y canasta de compras
- Clase 23 · Analítica de textos
- Clase 24 · Modelación de tópicos
- Clase 25 · Modelos de elección de marca
- Clase 26 · Logit multinomial: ajuste
- Clase 27a · Logit multinomial: simulación
- Clase 27b · Análisis conjunto
- Clase 28 · Análisis conjunto (II)
- Clase 29 · Análisis conjunto: simulador

**Sesiones de estudio**

#### Sesión MA 1 · U1 · Analítica y decisiones, analítica predictiva y causal, estudios cualitativos
- Clases: Clase 1 · Introducción; Clase 2 · Analítica y toma de decisiones; Clase 3 · Lab 1: datos de ventas en retail; Clase 4 · Analítica predictiva y causal; Clase 5a · Estudios cualitativos
- Preguntas: Resolver agosto 2014 (Necesidad y diseño de investigación, manual p. 242, respuesta p. 328); Leer enero 2014 (Causalidad publicitaria, manual p. 195, respuesta p. 300)

#### Sesión MA 2 · U2 · Segmentación: RFM y análisis de clusters
- Clases: Clase 5b · Introducción a la segmentación; Clase 6 · Segmentación a priori: RFM; Clase 7 · Clusters: métodos jerárquicos; Clase 8 · Clusters (parte 2); Clase 9 · Clusters: Lab 3
- Preguntas: Resolver agosto 2011 (Calidad de clustering, manual p. 193, respuesta p. 299); Leer agosto 2015 (Factores, segmentos y targeting, manual p. 213, respuesta p. 312)

#### Sesión MA 3 · U3 · Posicionamiento: factores, MDS y preferencias
- Clases: Clase 10 · Posicionamiento: introducción; Clase 11 · Factores y mapas perceptuales; Clase 12 · MDS y análisis de preferencias
- Preguntas: Resolver agosto 2013 (Factorial y segmentación, manual p. 215, respuesta p. 312); Leer enero 2012 (ANOVA y análisis factorial, manual p. 187, respuesta p. 297)

#### Sesión MA 4 · U4 · Valor del cliente (CLV): beta-geométrico y Pareto/NBD
- Clases: Clase 13 · Analítica de clientes; Clase 14 · Valor económico del cliente; Clase 15 · CLV contractual: beta-geométrico; Clase 16 · CLV contractual: beta-geométrico (II); Clase 17 · CLV no contractual: Pareto/NBD

#### Sesión MA 5 · U5 y U6 · Predicción de respuesta, fuga, cross-selling y analítica de textos
- Clases: Clase 18 · Modelos de predicción de respuesta; Clase 19 · Árboles de decisión; Clase 20 · Evaluación de modelos de clasificación; Clase 21 · Predicción de fuga y retención; Clase 22 · Cross-selling y canasta de compras; Clase 23 · Analítica de textos; Clase 24 · Modelación de tópicos

#### Sesión MA 6 · U7 · Elección de marca y logit multinomial
- Clases: Clase 25 · Modelos de elección de marca; Clase 26 · Logit multinomial: ajuste; Clase 27a · Logit multinomial: simulación
- Preguntas: Resolver enero 2020 (Logit y heterogeneidad, manual p. 231, respuesta p. 322)

#### Sesión MA 7 · U8 · Análisis conjunto y simulador de mercado
- Clases: Clase 27b · Análisis conjunto; Clase 28 · Análisis conjunto (II); Clase 29 · Análisis conjunto: simulador
- Preguntas: Resolver enero 2016 (Participación y conjoint, manual p. 245, respuesta p. 330)

#### Sesión MA 8 · U9 a U11 · Difusión (Bass), decisiones de precios y marketing mix
- Preguntas: Resolver agosto 2019 (Difusión de Bass, manual p. 207, respuesta p. 309); Leer agosto 2012 (Diseño muestral, manual p. 209, respuesta p. 310)
- Nota: Sin diapositivas en la carpeta: se ve desde el programa del curso


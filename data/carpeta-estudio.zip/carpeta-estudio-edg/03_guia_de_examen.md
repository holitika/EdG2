# Guía del examen y de los simulacros

## Formato
- 3 secciones: Dirección (DP y DE), Finanzas (TF y DF) y Marketing (FM y MA).
- 2 preguntas por sección, una por ramo. En total 6 preguntas.
- Se rinde con cronómetro: 30 minutos por pregunta, máximo 2 carillas cada una, y calculadora no programable.
- Una sección cuenta como aprobada solo si pasan sus dos preguntas.

## Simulacros
- Un simulacro es un examen completo de 3 horas: una sección por hora.
- Los exámenes de 2023-08, 2024-01, 2024-08, 2025-01, 2025-08, 2026-01 y 2026-08 se reservan para los simulacros. No abras sus preguntas ni respuestas antes de hacerlos.
- Corrige el mismo día, sección por sección, con la pauta del manual (el examen de 2026-08 no trae pauta: corrígelo con tu IA).
- Después del simulacro anota tus 5 lagunas por sección en 05_registro_de_errores.md.

## Cómo responder una pregunta de examen
1. Lee el caso completo y subraya qué te piden exactamente.
2. Identifica el concepto o modelo que corresponde (marco teórico).
3. Aplícalo al caso con los datos del enunciado. En preguntas de cálculo, deja el procedimiento a la vista.
4. Cierra con una conclusión o recomendación concreta.
5. Revisa que respondiste todo lo que pedía, en máximo 2 carillas.

## Cronómetro de sección
Con tu IA: «Cronómetro de sección». Resuelves 2 preguntas en 30 minutos cada una y luego las corriges.

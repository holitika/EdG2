# Dirección de Empresas · 8A305A-Ventajas Competitivas y Estrategias Genericas 1

Fuente: clase de Dirección de Empresas

[pág. 1]
Ventaja Competitiva y Estrategias Genéricas
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Ventaja Competitiva y
 Estrategias Genéricas
 José Rivera Izam
 José Rivera Izam

[pág. 2]
Ventaja Competitiva y Estrategias Genéricas
Objetivo de la Estrategia y Ventaja Competitiva
 Competencia Imperfecta Competencia Perfecta
 CMe CMe
 P CMg CMg
 P D
 D
 IMg
 Q Q
 (D=IMg=Precio)
 Ventaja Competitiva
 José Rivera Izam

[pág. 3]
Ventaja Competitiva y Estrategias Genéricas
¿Qué es la Ventaja Competitiva?
 Es un atributo o conjunto de ellos, que es logrado por la empresa
 de manera superior a sus competidores de relevancia, gracias a
 la combinación que realiza de sus actividades estratégicas,
 generando como resultado retornos sobrenormales que se
 traduzcan en valor para los accionistas (retornos mayores al
 costo de oportunidad de los recursos invertidos en ella).
 La ventaja competitiva busca desmarcar a la empresa de sus
 competidores (posición única), tanto en el presente como en el
 futuro (sustentabilidad de los retornos).
 Su creación, logro y mantención es responsabilidad y
 compromiso de la organización.
 José Rivera Izam

[pág. 4]
Ventaja Competitiva y Estrategias Genéricas
Características de las Ventajas Competitivas
 Surge de Actividades Estratégicas Diferentes
 Las actividades diferentes deben ser Únicas
 El resultado debe ser Unico y Valorado por clientes (imperfección)
 El cliente debe Experimentar efectivamente el resultado
 La valoración debe traducirse en Disposición a Pagar
 La disposición a pagar debe superar al Costo de Producción
 El Precio pagado debe superar al Costo de Producción
 La empresa debe ser capaz de Sustentar todo lo anterior
 El resultado final de lo anterior es Creación de Valor
 José Rivera Izam

[pág. 5]
Ventaja Competitiva y Estrategias Genéricas
Relación Empresa – Cliente
Disposición a Pagar y Precio
 Valor
 Económico
 Total del Potencial
 beneficio
percibido por
 el Cliente
 Total del Costo
 Económico para
 la Empresa
 José Rivera Izam

[pág. 6]
Ventaja Competitiva y Estrategias Genéricas
Relación Empresa – Cliente
Disposición a Pagar y Precio
 ¿Cuál es el Precio?
 Precio
 Total del Valor
 beneficio Económico
percibido por creado por
 el Cliente la Empresa
 Total del Costo
 Económico para
 la Empresa
 José Rivera Izam

[pág. 7]
Ventaja Competitiva y Estrategias Genéricas
Brecha Disposición a Pagar - Precio
 Rivalidad Competitiva (+)
 Diferenciación de la Oferta (-)
 Costos de Cambio (-)
 Posibilidad de Discriminación de Precios (-)
 José Rivera Izam

[pág. 8]
Ventaja Competitiva y Estrategias Genéricas
Ventaja Competitiva y Calidad del Atributo
 Factores Higiénicos
 Factores Motivacionales
 José Rivera Izam

[pág. 9]
Ventaja Competitiva y Estrategias Genéricas
 Ventajas Competitivas
Estrategias Genéricas
 Michael Porter
 José Rivera Izam

[pág. 10]
Ventaja Competitiva y Estrategias Genéricas
Estrategia de liderazgo en Costos
 En la estrategia de liderazgo en costos, la ventaja la provee el
 ser el competidor de menores costos. Esto por sí mismo genera
 mayor margen en un mercado competitivo.
 Para captar mayor demanda (generando imperfección), el
 competidor líder en costos aprovecha su ventaja de costos la
 que se puede traducir o no en un precio relativo más bajo.
 El logro de la posición anterior requiere de la generación y
 aprovechamiento de economías de escala, de aprendizaje y de
 ámbito.
 José Rivera Izam

[pág. 11]
Ventaja Competitiva y Estrategias Genéricas
 Competidor Líder en Costos
 Mercado Competitivo
 CTind
 CTee
 P D
 Retorno
 Económicos
Sobrenormales Q
 José Rivera Izam

[pág. 12]
Ventaja Competitiva y Estrategias Genéricas
Estrategia de Diferenciación
En la estrategia de diferenciación la ventaja consiste en
entregar intencionalmente un atributo distinto a la competencia,
por el cual el cliente está dispuesto a pagar más, y que este
premio es superior a los mayores costos.
Aumentar los atributos del producto de forma que agreguen
valor a los clientes a través de mejor tecnología, imagen de
marca, servicios, etc.
Aumenta el valor percibido de los productos y/o servicios de la
empresa, en relación al valor percibido de los productos y /o
servicios del competidor.
Crea preferencias en el cliente hacia los productos y/o servicios
de la empresa.
 José Rivera Izam

[pág. 13]
Ventaja Competitiva y Estrategias Genéricas
 Competidor con Diferenciación
 Empresa sin Empresa con
 DIFERENCIACIÓN DIFERENCIACIÓN
 CMgee
 CTind Pee
 CTee
Pind Dind
 Dee
 IMee
 Qind Qff
 Retorno
 Sobre Normal
 José Rivera Izam

[pág. 14]
Ventaja Competitiva y Estrategias Genéricas
Valor Estratégico de la Diferenciación
 Capacidad para neutralizar amenazas
 Disuade a
 Entrantes
 Reduce Industria
 poder de Reduce
 clientes Firma Rivalidad
 Local
 Amenazas
 Reduce Aminora a
 poder de Sustitutos
 proveedores
 ¿Cuál es el Valor Estratégico del Liderazgo en Costos?
 José Rivera Izam

[pág. 15]
Ventaja Competitiva y Estrategias Genéricas
 Ventajas Competitivas y Estrategias
 Genericas
¿Una Estrategia Genérica constituye
 una Ventaja Competitiva?
 José Rivera Izam

[pág. 16]
Ventaja Competitiva y Estrategias Genéricas
Estrategia Genérica y Ventaja Competitiva
 La estrategia genérica se traducirá en ventaja
 competitive sostenible, si su resultados es:
 • Valorada
 • Única
 • Difícil de Imitar
 • Cuidada por la Organización
 José Rivera Izam

[pág. 17]
Ventaja Competitiva y Estrategias Genéricas
Posiciones Competitivas Sólidas
Liderazgo en Costos y Diferenciación
 Empresas con Líderes en
 Diferenciación Costo
 Retorno sobre la
 Inversión
 Atrapado en el medio
 Baja participación de Alta participación de
 Mercado/Precio Elevado Mercado/Precio Bajo
 José Rivera Izam

[pág. 18]
Ventaja Competitiva y Estrategias Genéricas
Una mirada al Logro de la Ventaja Competitiva
 Metiéndose dentro de la Empresa
 ACTIV. DE APOYO
 INFRAESTRUCTURA DE LA EMPRESA
 ADMINISTRACION DE RECURSOS HUMANOS
 DESARROLLO TECNOLOGICO M
 A
 ABASTECIMIENTO
 R
 G
 E
 LOGISTICA OPERACIO- LOGISTICA MERCADO- SERVICIO N
 INTERNA NES EXTERNA TECNIA Y
 VENTAS
 ACTIVIDADES PRIMARIAS
 José Rivera Izam

[pág. 19]
Ventaja Competitiva y Estrategias Genéricas
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Ventaja Competitiva y
 Estrategias Genéricas
 José Rivera Izam
 José Rivera Izam

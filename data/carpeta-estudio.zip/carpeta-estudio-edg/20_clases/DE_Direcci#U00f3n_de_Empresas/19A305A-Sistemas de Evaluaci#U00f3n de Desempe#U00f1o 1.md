# Dirección de Empresas · 19A305A-Sistemas de Evaluación de Desempeño 1

Fuente: clase de Dirección de Empresas

[pág. 1]
Sistemas de Dirección
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Evaluación de Desempeño
 José Rivera Izam
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 2]
Sistemas de Dirección
Diseño de Sistemas de Dirección
Incidiendo en la Conducta de las Personas
 ¿Cómo se evalúa la Unidad Organizacional?
 SISTEMA DE CONTROL DE GESTION
 ¿Cómo se evalúa el Desempeño Personal?
 SISTEMA DE EVALUACION DE DESEMPEÑO
 ¿Cómo se retribuye a las Personas?
 SISTEMA DE INCENTIVOS
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 3]
Sistemas de Dirección
Estrategia
 Sistemas de
 Evaluación de
 Desempeño
Estructura
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 4]
Sistemas de Dirección
Evaluación Formal Sistemática
 La evaluación formal sistemática suele ser
 semestral o anual. Tiene cuatro objetivos básicos:
 Permitir que los empleados conozcan, de manera formal, la percepción
 que la organización tiene acerca de su desempeño presente.
 Identificar a los empleados que son candidatos y merecen aumentos,
 mejoras y ascensos por méritos.
 Localizar a los empleados que necesitan mayor capacitación.
 Identificar y comunicar formalmente a los candidatos de quienes la
 organización requiere una mejora, cambio de actitud y mejor desempeño.
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 5]
Sistemas de Dirección
¿Quién es el Responsable de la Evaluación
de Desempeño?
 El Superior que califica al Subordinado
 Un Grupo de Homólogos que califica a un
 compañero
 Un Grupo de Subordinados que califican a su jefe
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 6]
Sistemas de Dirección
Pasos del Proceso de Evaluación de
Desempeño
 1. Definir clara y transparente de los objetivos de la Evaluación
 de Desempeño.
 2. Conceptos Evaluativos y Construcción del Instrumento
 -Cumplimiento de Objetivos
 -Actitudes deseadas
 -Resultados logrados
 3. Formación de Actores: evaluadores y evaluados.
 4. Comunicación de la Evaluación: presentación de los resultados
 al evaluado de una manera que sea fácil de entender, y en la
 que se puedan identificar fácilmente las áreas en las que debe
 mejorar.
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 7]
Sistemas de Dirección
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Evaluación de Desempeño
 José Rivera Izam
 José
 JoséRivera
 RiveraIzam
 Izam

# Dirección de Empresas · 9A305A-Logro y Sustentación de Ventajas Competitivas 1

Fuente: clase de Dirección de Empresas

[pág. 1]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
 Escuela de Administración
 Pontificia Universidad Católica de Chile
 Creación y Sustentación de
 Ventajas Competitivas:
Recursos, Capacidades y Habilidades
 José Rivera Izam
 José Rivera Izam

[pág. 2]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
 Bloques y Cadena de Valor
ACTIV. DE APOYO
 INFRAESTRUCTURA DE LA EMPRESA
 ADMINISTRACION DE RECURSOS HUMANOS
 DESARROLLO TECNOLOGICO M
 A
 ABASTECIMIENTO
 R
 G
 E
 LOGISTICA OPERACIO- LOGISTICA MERCADO- SERVICIO N
 INTERNA NES EXTERNA TECNIA Y
 VENTAS
 ACTIVIDADES PRIMARIAS
 José Rivera Izam

[pág. 3]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
Formación de la Ventaja Competitiva
 Calidad
 Superior
 Superior
 Eficiencia Ventaja capacidad de
 Superior Competitiva satisfacción
 al cliente
 Innovación
 Superior
 José Rivera Izam

[pág. 4]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
 Bloques y Cadena de Valor
ACTIV. DE APOYO
 INFRAESTRUCTURA DE LA EMPRESA
 ADMINISTRACION DE RECURSOS HUMANOS
 DESARROLLO TECNOLOGICO M
 A
 ABASTECIMIENTO
 R
 G
 E
 LOGISTICA OPERACIO- LOGISTICA MERCADO- SERVICIO N
 INTERNA NES EXTERNA TECNIA Y
 VENTAS
 ACTIVIDADES PRIMARIAS
 José Rivera Izam

[pág. 5]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
Logro y realización de
Ventajas Competitivas
Resource-Based View
 José Rivera Izam

[pág. 6]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
The Resource-Based View
 • responde a la pregunta: ¿por qué algunas empresas
 poseen un mejor desempeño económico que otras?
 • permite buscar y encontrar fuentes para la realización
 de ventajas competitivas
 • asume que los recursos y capacidades que posee
 una empresa constituyen los principales inductores
 de la ventaja competitiva y del logro del desempeño
 superior
 José Rivera Izam

[pág. 7]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
The Resource-Based View
Recursos y Capacidades
 Recursos: son activos tangibles e intangibles
 controlados por la empresa, los cuales pueden ser
 usados para concebir y complementar su estrategia
 Capacidades: son un subconjunto de los recursos
 de la compañía y se definen como activos tangibles
 e intangibles disponibles para complementar la
 ventaja que otros recursos permitan
 José Rivera Izam

[pág. 8]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
The Resource-Based View
 Dos supuestos base del RBV
 • Heterogeneidad de los Recursos
 » distintas empresas poseen diferentes recursos
 » algunos recursos son valorados y otros no
 • Inamovilidad de los Recursos
 » es costoso para una empresa que no posee
 cierto recursos, adquirirlo o desarrollarlo
 » ciertos recursos no pueden traspasarse de una
 empresa a otra con facilidad
 José Rivera Izam

[pág. 9]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
Análisis VRIO para los Recursos
 • Value
 • Rarity
 • Imitability
 • Organization
 Si una empresa posee recursos, valorados, únicos, difíciles de
 imitar, y la empresa protege organizacionalmente a dichos
 recursos, entonces la empresa debiera poseer y sustentar su
 ventaja competitiva
 José Rivera Izam

[pág. 10]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
RBV y Bloques de Formación
 CAPACIDADES RECURSOS
 HABILIDADES DISTINTIVAS
 Capacidad de
 Eficiencia Calidad Innovación
 Satisfacción
 Superior Superior Superior
 al Cliente
 José Rivera Izam

[pág. 11]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
 Sustentación de
 Ventajas Competitivas
Posicionamiento y Sustentación
 José Rivera Izam

[pág. 12]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
 Durabilidad de la Ventaja Competitiva
Barreras Capacidad Dinamismo Gestión
 para la de los de la de la
Imitación Competidores Industria Empresa
 DURABILIDAD DE LA VENTAJA
 José Rivera Izam

[pág. 13]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
Amenazas a la Sustentación
 Amenaza a la capacidad de GENERAR Rentas
 Amenaza a la capacidad de APROPIARSE de las Rentas
 José Rivera Izam

[pág. 14]
Creación y Sustentación de las Ventajas Competitivas:
 Recursos, Capacidades y Habilidades
 Escuela de Administración
 Pontificia Universidad Católica de Chile
 Creación y Sustentación de
 Ventajas Competitivas:
Recursos, Capacidades y Habilidades
 José Rivera Izam
 José Rivera Izam

# Dirección de Empresas · 24A305A-Etica y Gestion de Empresas 1

Fuente: clase de Dirección de Empresas

[pág. 1]
Etica y Dirección de Empresas
 Escuela de Administración
 Pontificia Universidad Católica de Chile
 Etica y Dirección de Empresas
 José Rivera Izam
 José Rivera Izam
 Etica y Dirección de Empresas
Análisis de Situaciones Dimensiones
 Económica
 Social
 Etica
 José Rivera Izam
 Page 1
 1

[pág. 2]
Etica y Dirección de Empresas
Calidad Etica de una Acción
 La calidad ética de una acción esta determinada
 no por las consecuencias observables de esa
 acción, sino por las motivaciones que impulsaron
 al decisor a realizarla
 José Rivera Izam
 Etica y Dirección de Empresas
Principios Etico-Prudenciales
 Bondad Intrínseca de fines y medios
 Imparcialidad
 Proporcionalidad
 José Rivera Izam
 Page 2
 2

[pág. 3]
Etica y Dirección de Empresas
Responsabilidad Moral Personal
 Responsabilidad
 Conocimiento Consentimiento
 Voluntariedad
 José Rivera Izam
 Etica y Dirección de Empresas
Definición de Empresa
 La empresa es una comunidad de personas que
 mediante trabajo solidario aplicado sobre unos
 recursos trata de aportar a la sociedad productos
 y servicios con valor económico añadido
 José Rivera Izam
 Page 3
 3

[pág. 4]
Etica y Dirección de Empresas
 Concepción Reduccionista
 • Recursos Humanos
 • Recursos Financieros
 • Materiales y Equipos
 • Información y Tecnología
 Dirección
 ORGANIZACION
 BENEFICIOS
 José Rivera Izam
 Etica y Dirección de Empresas
Definición amplia de Empresa
 Sociedad
 Civil
 Accionistas Empleados
 Trabajo
 Recursos Objetivos
 Solidario
 Empresa:
 Comunidad de Personas
 José Rivera Izam
 Page 4
 4

[pág. 5]
Etica y Dirección de Empresas
Finalidad de una Empresa
 Generar un vea con honradez
 Distribuir equitativamente el vea generado
 Proporcionar productos y servicios que sirvan o puedan servir al
 desarrollo humano.
 Usar con moderación los recursos
 Proporcionar puestos de trabajo dignos y eficientes
 Favorecer el desarrollo personal de los trabajadores
 Buscar la autocontinuidad de la empresa
 Facilitar en lo posible la actividad de otras empresas
 José Rivera Izam
 Etica y Dirección de Empresas
Persona y trabajo
 Efectos Inmanent.
 CAMBIOS EN TRABAJO EN
 LA PERSONA
 LA PERSONA
 - Psicosomáticos
 - Intelectuales
 - Volitivos
 ACCION
 ACCION DE
 TRABAJAR
 Efectos Trascend
 TRABAJO EN
 PRODUCCION EL ENTORNO
 José Rivera Izam
 Page 5
 5

[pág. 6]
Etica y Dirección de Empresas
 Dirigir Empresas: un desafío complejo
 que exige estar a la altura…
 José Rivera Izam
 Etica y Dirección de Empresas
Empresa: Visión de Largo Plazo
 Econó-
 ENTORNO NACIONAL ENTORNO NACIONAL
 mico
 E INTERNACIONAL E INTERNACIONAL
 Tecno- Competi- Provee-
 dores dores Polit.
 lógico legal
 EMPRESA
 Clientes Perso-
 Social nas Ecoló-
 gico
 José Rivera Izam
 Page 6
 6

[pág. 7]
Etica y Dirección de Empresas
Significado de la
Dirección de Empresas
 Sociedad
 Empresa Persona
 José Rivera Izam
 Etica y Dirección de Empresas
Dirigir de manera simplificada …
 Elegir el futuro
 Estructurar la
 Organización
 Organizar la
 Convivencia
 José Rivera Izam
 Page 7
 7

[pág. 8]
Etica y Dirección de Empresas
Una Visión
Trascendente e
integradora de Resultados de
 Sentido
una
Organización
Real
 PERSONAS Y
 cristinapzrr@gmail.com
 SU TRABAJO
 id s
 R
 iv o
 ad
 ct ad
 e
 Ef su
 ra ult
 ic lta
 At e s
 ie d
 nc os
 R
 ia
 José Rivera Izam
 Etica y Dirección de Empresas
 … finalmente …
 ¿Cuál es el sentido de haber
 estudiado esta carrera?
 José Rivera Izam
 Page 8
 8

[pág. 9]
Etica y Dirección de Empresas
La Fábula del Pescador
Un Empresario se encuentra en la playa con un pescador recostado en la arena,
sin hacer nada, al lado de su bote, junto a un par de pescados colgando de unos
hilos. El empresario se acercó y le preguntó …
- ¿Por qué no estás en alta mar pescando?
- Y ¿para qué?, le preguntó el pescador.
- Porque si pescas mas, con los ingresos podrás comprar un bote más grande, y con esos
 recursos podrás comprar varios botes más.
- Y ¿para qué?, le volvió a preguntar el pescador.
- Para llegar a tener una flota de botes pesqueros.
- Y ¿para qué?, lo inquirió nuevamente el pescador.
- El empresario se rio y dijo: porque así llegarías a tener mucho dinero y luego de unos 10
 o 15 años te podrías retirar tranquilo, dormir hasta tarde y descansar todo lo que
 quisieras.
- El pescador lo miró y le dijo: ¿Y acaso no es eso lo que estoy haciendo ahora?
 José Rivera Izam
 Etica y Dirección de Empresas
 Sea un profesional con Valores
 Hechos No Palabras
 https://www.youtube.com/watch?v=vckz6EAn30Y
 https://www.youtube.com/watch?v=hHElT_bA3Ss
 José Rivera Izam
 Page 9
 9

[pág. 10]
Etica y Dirección de Empresas
 Algunos Comentarios Finales …
- El verdadero sentido de un trabajo bien hecho es mas que tener un buen resultado económico.
 Requiere una trascendencia a través de lo logrado.
- La mera acumulación material sin un sentido genera un resultado vacío y no logra felicidad. Y no
 olvide que el fin último de todos es alcanzar la felicidad.
- Todo acto humano, toda acción, se justifica siempre y cuando haya un para qué que la explique y
 le dé fundamento. Ese para qué debe respetar al otro en su dignidad, y engrandecerlo a Ud. como
 gestor de la acción. Debe hacerlo a Ud. mismo crecer.
- Da lo mismo lo que digas o lo que pienses. Lo importante es lo que hagas. Al final, la forma en
 cómo Ud. decida actuar determinará el tipo de persona que será para Ud. mismo, y para quienes lo
 rodean.
- Sea consecuente entre su discurso público y privado, su actuar público y privado.
- No se olvide que al final, por el hecho de ser sujetos libres, tenemos la capacidad de elegir. Elija lo
 bueno, lo que lo engrandece, lo que lo hace crecer.
- Buena Suerte para todos.
- José Rivera Izam
 Etica y Dirección de Empresas
 Escuela de Administración
 Pontificia Universidad Católica de Chile
 Etica y Dirección de Empresas
 José Rivera Izam
 José Rivera Izam
 Page 10
 10

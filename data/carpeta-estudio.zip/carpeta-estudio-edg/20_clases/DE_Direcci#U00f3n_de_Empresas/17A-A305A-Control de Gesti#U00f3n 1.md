# Dirección de Empresas · 17A-A305A-Control de Gestión 1

Fuente: clase de Dirección de Empresas

[pág. 1]
Sistemas de Dirección
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Sistema de Dirección
 EL CONTROL DE GESTIÓN
 José Rivera Izam
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 2]
Sistemas de Dirección
Diseño de Sistemas de Dirección
Incidiendo en la Conducta de las Personas
 ¿Cómo se evalúa la Unidad Organizacional?
 SISTEMA DE CONTROL DE GESTION
 ¿Cómo se evalúa el Desempeño Personal?
 SISTEMA DE EVALUACION DE DESEMPEÑO
 ¿Cómo se retribuye a las Personas?
 SISTEMA DE INCENTIVOS
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 3]
Sistemas de Dirección
El Control de Gestión
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 4]
Sistema de Dirección
Visión Tradicional del Control
 Proyecciones Presupuestarias
 Mediciones Proyectadas Vs. Realidad
 PROBLEMAS
  Relación con otras Areas
  Control orientado a medir Cifras
  Visión Integral de la Empresa
 José Rivera Izam

[pág. 5]
Sistema de Dirección
Control de Gestión
 Herramienta de apoyo a la dirección de empresas,
 la cual por medio de información generada
 periódicamente, permite conocer que esta
 ocurriendo en cada momento en las áreas,
 divisiones o negocios que se consideren
 fundamentales.
 José Rivera Izam

[pág. 6]
Sistema de Dirección
Objetivo del Control de Gestión
 Lograr que el Comportamiento de las Personas
 permita el logro de los Objetivos de la empresa
 Progreso y crecimiento empresarial
 Continuidad y estabilidad en el tiempo
 José Rivera Izam

[pág. 7]
Sistema de Dirección
Relaciones Fundamentales
 en el Control de Gestión
 José Rivera Izam

[pág. 8]
Sistema de Dirección
Estrategia
 Control de Gestión
 José Rivera Izam

[pág. 9]
Sistema de Dirección
Estrategia Empresarial y Control de Gestión
 Diagnóstico Actual
 Misión / Negocios
 Ventajas Competitivas
 Definición de Objetivos
 Planes de Inversiones
 Implementación
 José Rivera Izam

[pág. 10]
Sistema de Dirección
 Control de
 Gestión
Estructura
 José Rivera Izam

[pág. 11]
Sistema de Dirección
Estrategia
 Control de
 Gestión
Estructura
 José Rivera Izam

[pág. 12]
Sistema de Dirección
 Control de Gestión
 SEÑALES
Claridad en Responsabilidades
 José Rivera Izam

[pág. 13]
Sistema de Dirección
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Sistema de Dirección
 EL CONTROL DE GESTIÓN
 José Rivera Izam
 José Rivera Izam

# Dirección de Empresas · 14A305A-Decisiones Diversificación 1

Fuente: clase de Dirección de Empresas

[pág. 1]
Estrategia Corporativa – Decisiones de Diversificación
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Estrategia Corporativa:
Decisiones de Diversificación
 José Rivera Izam
 José Rivera Izam

[pág. 2]
Estrategia Corporativa – Decisiones de Diversificación
Decisiones de Diversificación
 Una estrategia de diversificación se Justifica en
 la medida que agregue Valor a la corporación.
 La creación de valor se logra combinando
 habilidades y recursos de los diferentes negocios.
 José Rivera Izam

[pág. 3]
Estrategia Corporativa – Decisiones de Diversificación
Generación de Negocio
Crecimiento - Diversificación
 Desarrollo
 Expansión Mercados
 Negocios
 Existentes
 Ajustes a
 ALTERNATIVAS DE los existentes
 CRECIMIENTO
 Diversificación Relacionada
 hacia
 nuevos
 Negocios
 No relacionada
 José Rivera Izam

[pág. 4]
Estrategia Corporativa – Decisiones de Diversificación
¿Por qué las Empresas
 se Diversifican?
 José Rivera Izam

[pág. 5]
Estrategia Corporativa – Decisiones de Diversificación
 ¿Por qué las Empresas se diversifican?
Para mantener el negocio competitivamente atractivo
Esta explicación busca afectar el ciclo de vida y los márgenes del
negocio, el que presenta ciertas características de “reducción del
valor”.
Para aumentar las utilidades de los accionistas
Esta explicación predice que a través de algún tipo de sinergia o
imperfección del mercado se crea valor y por lo tanto son
“maximizadoras de valor”.
Razones “No maximizadoras de valor”
La premisa básica es que los administradores, como agentes,
persiguen su propio interés y por esto sus decisiones pueden ir en
contra del beneficio del accionista.
 José Rivera Izam

[pág. 6]
Estrategia Corporativa – Decisiones de Diversificación
Ciclo de Vida
 $
 Ventas Totales
 Tiempo
 Embrionario Expansión Estabilización Declinación
 José Rivera Izam

[pág. 7]
Estrategia Corporativa – Decisiones de Diversificación
Efecto Shake Out del Sector
 $
 Costos
 Vol. Acum.
 José Rivera Izam

[pág. 8]
Estrategia Corporativa – Decisiones de Diversificación
Efecto Shake Out del Sector
 $
 Precios
 Costos
 Vol. Acum.
 José Rivera Izam

[pág. 9]
Estrategia Corporativa – Decisiones de Diversificación
Factores Creadores de Valor
en la Diversificación
 Estos factores predicen que a través de algún tipo de
 sinergia o imperfección de mercado se crea valor y por
 lo tanto son “maximizadoras de valor”.
  Economías de escala y/o ámbito
  Aumento del poder de mercado
  Costos de transacción
  Sinergias de administración o financieras
  Creación de mercado de capitales interno
  Diversificación del riesgo
 José Rivera Izam

[pág. 10]
Estrategia Corporativa – Decisiones de Diversificación
Riesgos asociados a
 la Diversificación
 José Rivera Izam

[pág. 11]
Estrategia Corporativa – Decisiones de Diversificación
Costos Burocráticos
Aunque la diversificación puede crear valor para una compañía, con
frecuencia termina generando todo lo contrario.
Un importante número de estudios académicos apoyan la
conclusión de que la diversificación excesiva tiende a reducir, en
vez de mejorar, la rentabilidad de la compañía.
Una de las razones que explica lo anterior son los costos
burocráticos, los cuales están relacionados con la cantidad de
negocios y las necesidades de coordinación.
 José Rivera Izam

[pág. 12]
Estrategia Corporativa – Decisiones de Diversificación
Límites de la Diversificación
 La existencia de costos burocráticos establece un límite
 en el tamaño de la diversificación que se puede seguir
 en forma rentable.
 Por esto se debe diversificar sólo cuando el valor
 creado por tal estrategia exceda los costos burocráticos
 asociados a la expansión que incorpora actividades de
 negocios adicionales.
 José Rivera Izam

[pág. 13]
Estrategia Corporativa – Decisiones de Diversificación
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Estrategia Corporativa:
Decisiones de Diversificación
 José Rivera Izam
 José Rivera Izam

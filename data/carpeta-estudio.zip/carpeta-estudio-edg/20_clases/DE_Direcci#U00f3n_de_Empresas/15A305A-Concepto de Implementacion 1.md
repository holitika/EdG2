# Dirección de Empresas · 15A305A-Concepto de Implementacion 1

Fuente: clase de Dirección de Empresas

[pág. 1]
El Concepto de Implementación de la Estrategia Competitiva
 Escuela de Administración
 Pontificia Universidad Católica de Chile
El Concepto de Implementación de la
 Estrategia Competitiva
 José Rivera Izam
 José Rivera Izam

[pág. 2]
El Concepto de Implementación de la Estrategia Competitiva
Implementación de Estrategia
Procesos de Alineamiento de la Estrategia
 Despliegue de Objetivos Estratégicos
 Mapas Estratégicos
 Agenda Estratégica
 Control y Seguimiento
 José Rivera Izam

[pág. 3]
El Concepto de Implementación de la Estrategia Competitiva
Implementación de la Estrategia
 La mayoría de las compañías invierten tiempo y
 recursos en el desarrollo de Planes Estratégicos.
 Muchos de estos planes nunca se llegan a materializar,
 no cumpliéndose los resultados esperados.
 La razón de lo anterior se debe a un deficiente proceso
 de implementación.
 José Rivera Izam

[pág. 4]
El Concepto de Implementación de la Estrategia Competitiva
Implementación de la Estrategia
 La fase de la implementación es un enigma y una
 fuente de frustración en muchas compañías.
 Las diferencias internas, políticas mal concebidas,
 procesos formales inexistentes o mal diseñados y
 problemas de comunicación y de poder, son sólo
 algunos de los obstáculos que pueden hacer fracasar
 el esfuerzo de implementación.
 José Rivera Izam

[pág. 5]
El Concepto de Implementación de la Estrategia Competitiva
La Dificultad de la Implementación
 Formulación
 Implementación
 Control
 José Rivera Izam

[pág. 6]
El Concepto de Implementación de la Estrategia Competitiva
La Relación tangible-intangible ha cambiado con
los años
 Activos 38% 62%
 Intangibles 85%
 Activos
 Tangibles 62% 38%
 15%
 HACE 40 AÑOS HACE 20 AÑOS HOY
 6
 José Rivera Izam

[pág. 7]
El Concepto de Implementación de la Estrategia Competitiva
Los activos intangibles son hoy importantes
fuentes de generación de valor
 El 80% del valor
 de las organizaciones
 modernas deriva
 de los activos
 intangibles
 Capital de Capital
 Capital Humano + Información
 + Organizacional
 •Habilidades •Sistemas •Cultura
 •Capacitación •Base de datos •Estructura
 •Conocimiento •Redes •Incentivos
 •Trabajo de equipo
 7
 José Rivera Izam

[pág. 8]
El Concepto de Implementación de la Estrategia Competitiva
Elementos de la Implementación
 Según un estudio realizado en 500 compañías en USA, existen en la mayoría de las
 empresas cuatro elementos esenciales en el proceso de implementación.
 Clima - Cultura - Valores
 Sistemas de
 Personas Dirección
 Areas Claves Estructura
 Organizacional
 José Rivera Izam

[pág. 9]
El Concepto de Implementación de la Estrategia Competitiva
 Escuela de Administración
 Pontificia Universidad Católica de Chile
El Concepto de Implementación de la
 Estrategia Competitiva
 José Rivera Izam
 José Rivera Izam

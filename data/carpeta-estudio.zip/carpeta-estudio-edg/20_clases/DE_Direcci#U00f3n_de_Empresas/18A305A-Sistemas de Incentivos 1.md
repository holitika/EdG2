# Dirección de Empresas · 18A305A-Sistemas de Incentivos 1

Fuente: clase de Dirección de Empresas

[pág. 1]
Sistemas de Dirección
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Sistema de Incentivos
 José Rivera Izam
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 2]
Sistemas de Dirección
Diseño de Sistemas de Dirección
Incidiendo en la Conducta de las Personas
 ¿Cómo se evalúa la Unidad Organizacional?
 SISTEMA DE CONTROL DE GESTION
 ¿Cómo se evalúa el Desempeño Personal?
 SISTEMA DE EVALUACION DE DESEMPEÑO
 ¿Cómo se retribuye a las Personas?
 SISTEMA DE INCENTIVOS
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 3]
Sistemas de Dirección
Estrategia
 Sistema de
 Incentivos
Estructura
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 4]
Sistemas de Dirección
Sistemas de Incentivos
Algunos Conceptos
 Salario Total
 Tarifas de Remuneraciones :
 Tiempo Trabajado
 Salario Total
 Costo de Remuneraciones :
 Unidades Producidas
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 5]
Sistemas de Dirección
Aspectos relevantes por definir en la
determinación del Sistema de Incentivos
 Determinación de los Conceptos Retributivos
 Definición de los Niveles Retributivos
 Definición de los Niveles de Aumento
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 6]
Sistemas de Dirección
Sistemas de Incentivos y de Directivos
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 7]
Sistemas de Dirección
Sistema de Incentivos de Directivos
Características
 Flexibilidad: el sistema de remuneración debe poder acoplarse a las
 variables de la estrategia de la empresa.
 Multidimensionalidad: el Sistema de Incentivos debe incluir varias
 dimensiones, de manera de hacerlo flexible.
 Atractividad: el Sistema de Incentivos debe generar desafíos e
 incentivar el logro de satisfacción y motivación en el directivo, que se
 traduzca en un apoyo decidido a la estrategia de la empresa.
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 8]
Sistemas de Dirección
Composición Fijo - Variable
 PARTE FIJA PARTE VARIABLE
 NIVEL EN LA
 (Porcentaje sobre (Porcentaje sobre
 JERARQUIA
 remuneración total) remuneración total)
 Alto Menor proporción Mayor proporción
 + - +
 - + -
 Alto Mayor proporción Menor proporción
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 9]
Sistemas de Dirección
Cumplimiento de Objetivos y Renta Variable
 Nivel de consecución del Proporción a pagar de la Renta
 objetivo Variable
 105% 115%
 100% 100%
 90% 75%
 80% 50%
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 10]
Sistemas de Dirección
Esquema General de un Sistema de
Incentivos de Ejecutivos
 Un Sistema de Incentivos bien diseñado debe ser completo, utilizar los
 distintos componentes de los que se dispone, balancear el esfuerzo de
 corto y largo plazo, estimular el trabajo individual y en equipo en las
 proporciones que la estrategia de la empresa lo requiere.
 Dedicación al: Corto Plazo Largo Plazo
 Trabajo Individual Renta Fija Plan de Jubilación
 Participación en el valor de
 Trabajo en Equipo Renta Variable
 la empresa (acciones, etc.)
 José
 JoséRivera
 RiveraIzam
 Izam

[pág. 11]
Sistemas de Dirección
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Sistema de Incentivos
 José Rivera Izam
 José
 JoséRivera
 RiveraIzam
 Izam

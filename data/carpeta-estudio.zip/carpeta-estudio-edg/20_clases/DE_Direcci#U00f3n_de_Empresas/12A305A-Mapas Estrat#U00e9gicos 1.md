# Dirección de Empresas · 12A305A-Mapas Estratégicos 1

Fuente: clase de Dirección de Empresas

[pág. 1]
Mapas Estratégicos
 Escuela de Administración
 Pontificia Universidad Católica de Chile
 Mapas Estratégicos
 José Rivera Izam
CODELCO 1 José Rivera Izam
 Mapas Estratégicos
 Mapas Estratégicos
 Es una herramienta de gestión que interrelaciona los objetivos
 estratégicos de una compañía. Permite apreciar la causalidad
 en el cumplimiento de los objetivos estratégicos.
 Entrega una representación de los objetivos estratégicos
 críticos para la empresa y de las relaciones fundamentales
 entre ellos como inductores del logro del resultado
 organizacional deseado.
 Constituye al mismo tiempo una forma de interrelacionar
 objetivos estratégicos con impulsos estratégicos y
 perspectivas prioritarias para la organización.
CODELCO 2 José Rivera Izam
 1

[pág. 2]
Mapas Estratégicos
 Mapas Estratégicos
 Permiten conceptualizar la interrelación entre objetivos
 estratégicos intangibles (activos intangibles) con los
 resultados “duros” del negocio, afectando así la
 intencionalidad estratégica. “Todo lo que pase en una
 organización tiene una repercusión para el negocio.”
 Es una ayuda para definir las prioridades (niveles de
 criticidad) de los objetivos estratégicos y orientar los
 esfuerzos coordinada y coherentemente en la tareas propias
 de la implementación de la estrategia.
 CODELCO 3 José Rivera Izam
 Mapas Estratégicos
Conceptualización del Mapa Estratégico
 Mejorar el valor para los accionistas
 • Precio acción • Retorno sobre el capital empleado
Perspectiva Estrategia de crecimiento de Ingresos
Financiera Estrategia de productividad
 Construir Aumentar valor Mejorar estructura Mejorar uso
 Retornos para los clientes de costos de activos
 • Ingreso de nuevas • Utilidad Clientes • Costos operativos • Utilización de
 fuentes por unidad producida activos
 Liderazgo de Producto
Perspectiva
Cliente Cercanía con el cliente
  
 Excelencia Operacional
  
 • Adquisición, retención y
 satisfacción de clientes
Perspectiva Transformarse en un
 Aumentar valor para Alcanzar excelencia
 Crear retornos buen ciudadano corporativo
Procesos a través de
 los clientes a través operacional a través
 a través de los procesos
Internos innovaciones
 de la administración de los procesos
 regulatorios y medio
 de procesos operativos y logísticos
 ambiental
Perspectiva
Aprendizaje y Competencias de los empleados Tecnología Cultura corporativa
Crecimiento
 CODELCO Planificación Estratégica División El Teniente 4 José Rivera Izam
 2

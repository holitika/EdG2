# Dirección de Empresas · 13A305A-Agenda Estratégica 1

Fuente: clase de Dirección de Empresas

[pág. 1]
La Agenda Estratégica
 Escuela de Administración
 Pontificia Universidad Católica de Chile
 La Agenda Estratégica
 José Rivera Izam
CODELCO 1 José Rivera Izam
 La Agenda Estratégica
 ¿Qué es la Agenda Estratégica?
 Es un instrumento que sintetiza un conjunto de iniciativas, planes e
 instancias de control, los cuales permiten a la empresa materializar y
 concretar la posición estratégica deseada.
 El principal objetivo de la agenda estratégica es congregar al equipo de
 trabajo, coordinar esfuerzos y aglutinar el entusiasmo de todos en torno el
 proyecto estratégico.
 Es la programación específica que materializa la Misión definida. Se
 construye por negocio y se origina desde la Misión de cada uno de ellos.
 Es un instrumento de trabajo periódico para el nivel superior. Es una carta
 de navegación para monitorear el trabajo estratégico a lo largo del tiempo.
CODELCO 2 José Rivera Izam
 1

[pág. 2]
La Agenda Estratégica
 Elementos de la Agenda Estratégica
 Objetivos Estratégicos: indican los resultados que se deben lograr para
 materializar la posición deseada.
 Lineamientos Estratégicos: grandes ámbitos de trabajo para conseguir los
 objetivos estratégicos.
 Planes Generales: iniciativas globales que permiten lograr cada uno de los
 lineamientos estratégicos.
 Planes Específicos: iniciativas específicas que permiten lograr cada uno de
 los planes generales.
 Responsables: miembros del equipo de trabajo que son responsables de
 lineamientos y/o de planes.
 Hitos de Control: resultados intermedios que muestran el grado de avance en
 cuanto al desarrollo de los planes específicos.
 Presupuestos: consecuencias financieras de la posición estratégica que se
 desea lograr.
CODELCO 3 José Rivera Izam
 La Agenda Estratégica
 Escuela de Administración
 Pontificia Universidad Católica de Chile
 La Agenda Estratégica
 José Rivera Izam
CODELCO 4 José Rivera Izam
 2

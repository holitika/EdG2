# Dirección de Empresas · 11A305A-Estrategia de Negocio 1

Fuente: clase de Dirección de Empresas

[pág. 1]
Formulando la Estrategia de Negocios
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Estrategia de Negocios
 José Rivera Izam
 José Rivera Izam

[pág. 2]
Formulando la Estrategia de Negocios
 ¿Cuál es mi negocio?
¿Cuál debiera ser mi negocio?
 ¿Cuál será mi negocio?
 José Rivera Izam

[pág. 3]
Formulando la Estrategia de Negocios
“Lo que nuestro negocio es no lo determina el
 productor, sino el consumidor. No lo define el
nombre de la compañía, los estatutos …, sino
 la necesidad que el consumidor satisface
 cuando compra un producto o servicio”
 P.Drucker
 José Rivera Izam

[pág. 4]
Formulando la Estrategia de Negocios
Formulación de Estrategia de Negocio
 La Misión del Negocio
 Escrutinio interno Análisis externo a
 a nivel de negocios nivel de negocios
 Formulación de la
 estrat. de negocios
 Programación
 estratégica
 Presupuesto
 Control de gestión
 José Rivera Izam

[pág. 5]
Formulando la Estrategia de Negocios
Misión de Negocio
 Es una declaración duradera de la Visión específica
 que de su negocio tiene una empresa, esencial para
 determinar sus Objetivos y formular sus Acciones
 Estratégicas.
 En esencia indica lo que quiere ser, a quién desea
 servir y cómo quiere competir una organización.
 José Rivera Izam

[pág. 6]
Formulando la Estrategia de Negocios
Multiplicidad de Objetivos
 Abstracto Largo
 Plazo
 Propósito Objetivos
 Generales
 de la
 Empresa
 Misión
 Objetivo
 Corto de la
 Objetivos Unidad
 Concreto Plazo
 Funcional
 José Rivera Izam

[pág. 7]
Formulando la Estrategia de Negocios
Tipo de Información en una Estrategia
 Narrativa
 Presupuesto
 Mediciones de Desempeño
 José Rivera Izam

[pág. 8]
Formulando la Estrategia de Negocios
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Estrategia de Negocios
 José Rivera Izam
 José Rivera Izam

# Dirección de Empresas · 16A305A-Estructura Organizacional 1

Fuente: clase de Dirección de Empresas

[pág. 1]
Conceptos Fundamentales de Estructura Organizacional
 Escuela de Administración
Pontificia Universidad Católica de Chile
Conceptos Fundamentales de
 Estructura Organizacional
 José Rivera Izam
 José Rivera Izam

[pág. 2]
Conceptos Fundamentales de Estructura Organizacional
Modelo de Implementación
 Clima - Cultura - Valores
 Sistemas de
 Personas Dirección
 Areas Claves Estructura
 Organizacional
 José Rivera Izam

[pág. 3]
Conceptos Fundamentales de Estructura Organizacional
Estructura Organizacional
 Sistemas de Sistemas de
 Planificación Control
 ESTRUCTURA
 ORGANIZACIONAL
 Sistemas de Sistemas de
 Información Incentivos
 CLIMA ORGANIZACIONAL
 CULTURA ORGANIZACIONAL
 RESULTADOS
 José Rivera Izam

[pág. 4]
Conceptos Fundamentales de Estructura Organizacional
¿Cuál es la Esencia del Estructura Organizacional?
 ¿Cuál es su Propósito?
 Lograr la Estrategia definida. Alinear los Encargos para hacer
 realidad la posición futura definida
 Objetivos Objetivos de
 Individuales Unidades
 Objetivos
 Corporativos
 José Rivera Izam

[pág. 5]
Conceptos Fundamentales de Estructura Organizacional
Estructura Organizacional
Conclusiones
 No es el organigrama
 Su objetivo es organizar a las personas para
 facilitar el logro de los resultados
 Base para la implementación de la estrategia
 Nexo entre los sistemas de dirección
 José Rivera Izam

[pág. 6]
Conceptos Fundamentales de Estructura Organizacional
Principales Elementos que determinan
el Diseño Organizacional
 Objetivos Estratégicos
 Lineamientos y Planes Estratégicos
 Areas Claves
 Capacidades, Recursos y Habilidades
 Características del Entorno Competitivo
 José Rivera Izam

[pág. 7]
Conceptos Fundamentales de Estructura Organizacional
Tipos de Estructuras Organizacionales
Organización Funcional
 PRESIDENTE
 PRODUCCIÓN FINANZAS COMERCIAL
 José Rivera Izam

[pág. 8]
Conceptos Fundamentales de Estructura Organizacional
Tipos de Estructuras Organizacionales
Organización por Producto/Mercado
 Organigrama por producto/mercado de una empresa manufacturera
 División Geográfica
 PRESIDENTE
 VICEPRESIDENTE VICEPRESIDENTE VICEPRESIDENTE VICEPRESIDENTE
 Mercadotecnia Finanzas Producción Recursos Humanos
 VICEPRESIDENTE VICEPRESIDENTE VICEPRESIDENTE
 América del Latinoamérica y Europa, Africa y
 Norte Lejano Oriente Medio Oriente
 José Rivera Izam

[pág. 9]
Conceptos Fundamentales de Estructura Organizacional
El Dilema Estructura - Estrategia
 Estrategia
 Estructura
 José Rivera Izam

[pág. 10]
Conceptos Fundamentales de Estructura Organizacional
Elementos de una Estructura Organizacional
 Organigrama
 Descripción de Cargos
 Mecanismos de Coordinación
 José Rivera Izam

[pág. 11]
Conceptos Fundamentales de Estructura Organizacional
Metodología para Diseñar una Estructura
Organizacional
 Diagnóstico
 Estrategia
 Estructura Ideal
  Dimensión horizontal
  Tamaño de estructura base
  Niveles jerárquicas esenciales
  Forma de integración de las unidades
 Estructura Posible
 José Rivera Izam

[pág. 12]
Conceptos Fundamentales de Estructura Organizacional
 Escuela de Administración
Pontificia Universidad Católica de Chile
Conceptos Fundamentales de
 Estructura Organizacional
 José Rivera Izam
 José Rivera Izam

# Dirección de Empresas · 10A305A-Modelos de Negocio 1

Fuente: clase de Dirección de Empresas

[pág. 1]
Modelos de Negocio
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Modelos de Negocio
 José Rivera Izam
 José Rivera Izam

[pág. 2]
Modelos de Negocio
Auge de los Modelo de Negocio
 En los últimos años la innovación en modelos de negocio
 ha sido una de los principales inductores de los esfuerzos
 estratégicos de empresas a lo largo del mundo.
 La evidencia empírica muestra que la Innovación en
 Modelos de Negocio permite mejorar la habilidad de la
 organización tanto para crear como para capturar valor.
 José Rivera Izam

[pág. 3]
Modelos de Negocio
Fuerzas Impulsoras que facilitan la preocupación
 Avances en tecnologías de la información y comunicación
 (los llamados e-business contribuyeron al despegue del concepto).
 Aumento en la complejidad del ambiente de negocios
 La hipercompetencia y la maduración de múltiples mercados invita a la
 constante reinvención de los modelos de negocio
 Dificultad para sustentar ventajas competitivas
 Imitación, sustitución y velocidad en movimientos de competidores
 José Rivera Izam

[pág. 4]
Modelos de Negocio
¿Qué es un Modelo de Negocio?
 En términos generales es la forma en como operan las compañías
 En términos más específicos, un Modelo de Negocio consiste en:
 • Elegir un set de alternativas (opciones) respecto a cómo operar la empresa
 • Seleccionar un set de consecuencias derivadas desde las opciones
 Algunas consideraciones derivadas de lo anterior:
 • Las alternativas seleccionadas deben estar conectadas a la creación y captura
 de valor por parte de la compañía
 • La gestión que se haga sobre las opciones tiene consecuencias
 • La relación entre opciones y consecuencias se basa en ciertos supuestos
 José Rivera Izam

[pág. 5]
Modelos de Negocio
Qué es un Modelo de Negocio
Un instrumento de gestión que establece los pilares a través de
los cuales una compañía construye su valor en el mediano y
largo plazo de forma sustentable. Lo anterior se logra por
medio de la elección de un conjunto de opciones y sus
correspondientes consecuencias.
Un Modelo de Negocio genera un marco de referencia que
permite dirigir la actuación y centrar la atención en aquellos
énfasis que establecen la forma en cómo debe operar la
empresa, de manera de materializar el proceso de creación y
captura de valor en el tiempo.
 José Rivera Izam

[pág. 6]
Modelos de Negocio
Modelo de Negocio
 Propuesta de Valor / Segmento de Cliente
 ¿Cómo obtengo Retornos? ¿Procesos / Operaciones Claves?
 ¿Cómo hago mi Negocio?
 ¿Cómo logro generar Retornos?
 José Rivera Izam

[pág. 7]
Modelos de Negocio
Un esquema para operacionalizar
 la construcción de un
 Modelo de Negocio
 José Rivera Izam

[pág. 8]
Modelos de Negocio
Operacionalización de un Modelo de Negocio
 Propuesta de Valor al Cliente
 Necesidad Segmento
 Precio relativo
 Formula para la
 Obtención de Utilidades
 • Modelo de Ingreso
 • Estructura Costos
 • Modelo Margen
 • Velocidad de los Recursos
 Recursos Claves Procesos Claves
 Actividades, operaciones, procesos
 Necesarios para construir la
 esenciales a desarrollar para hacer
 propuesta de Valor
 que la propuesta de valor sea
 sustentable
 José Rivera Izam

[pág. 9]
Modelos de Negocio
 Escuela de Administración
Pontificia Universidad Católica de Chile
 Modelos de Negocio
 José Rivera Izam
 José Rivera Izam

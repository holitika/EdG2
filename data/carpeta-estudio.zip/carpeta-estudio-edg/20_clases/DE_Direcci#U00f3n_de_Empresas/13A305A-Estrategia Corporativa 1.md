# Dirección de Empresas · 13A305A-Estrategia Corporativa 1

Fuente: clase de Dirección de Empresas

[pág. 1]
Formulando la Estrategia Corporativa
 Escuela de Administración
 Pontificia Universidad Católica de Chile
Formulando la Estrategia Corporativa
 José Rivera Izam
 José Rivera Izam

[pág. 2]
Formulando la Estrategia Corporativa
Preocupaciones Centrales para el
Desempeño Superior
 Búsqueda Sinergias
 Búsqueda de Escala
 Directrices Corporativas
 José Rivera Izam

[pág. 3]
Formulando la Estrategia Corporativa
Preocupaciones de la Gerencia Corporativa
 Configurar Portafolio de Negocio
  Generar Negocios
  Segmentar Negocios
 Dirigir la Gestión sobre los Recursos
  Asignación de Recursos
  Gestión del Personal Directivo Clave
 José Rivera Izam

[pág. 4]
Formulando la Estrategia Corporativa
Generación de Negocio
Crecimiento - Diversificación
 Desarrollo
 Expansión Mercados
 Negocios
 Existentes
Generación de Negocios Ajustes a
 ALTERNATIVAS DE los existentes
 CRECIMIENTO
 Diversificación Relacionada
 hacia
 nuevos
 Negocios
 No relacionada
 José Rivera Izam

[pág. 5]
Formulando la Estrategia Corporativa
Generación de Negocios
 Valor Presente Neto
  Evaluación de Proyectos
 Posicionamiento Estratégico
  Generación de Proyectos
 José Rivera Izam

[pág. 6]
Formulando la Estrategia Corporativa
Asignación de Recursos
 Decisión Centralizada
 Criterio de Asignación
 Creación de Valor
 Ventaja Competitiva
 José Rivera Izam

[pág. 7]
Formulando la Estrategia Corporativa
Estrategia Corporativa
 Corporación
 Escrutinio interno Análisis del Medio
 a nivel corporativo: Externo a nivel corporativo:
 La visión de la firma Inteligencia de la firma
 Formulación de la Estrat.
 a nivel de la empresa
 Asignación de
 Recursos
 Infraestructura de
 Gestión
 José Rivera Izam

[pág. 8]
Formulando la Estrategia Corporativa
Dimensiones Corporativa
Visión de la Corporación
 Misión de la Empresa
 Filosofía de la Empresa
 José Rivera Izam

[pág. 9]
Formulando la Estrategia Corporativa
 Escuela de Administración
 Pontificia Universidad Católica de Chile
Formulando la Estrategia Corporativa
 José Rivera Izam
 José Rivera Izam

# Dirección de Personas · Tema 1 - introducción

Fuente: clase de Dirección de Personas

[pág. 1]
TEMA 1: INTRODUCCION,
ESTRATEGIA Y PLANIFICACIÓN
 DE RECURSOS HUMANOS
 DIRECCION DE PERSONAS
 Escuela de Administración
 Julio 2013
 Alejandra Mehech C.

[pág. 2]
Programa
✓ Introducción y objetivos
✓ Contenidos del Curso
✓ Calendario de pruebas
✓ Metodología del curso
✓ Evaluaciones
✓ Normas del curso
 ❖ Mail: amehech@uc.cl
 ❖ Teléfono: +569-93215169

[pág. 3]
Introducción
 La gestión de personas será,
 sin duda alguna, un tema
 muy importante en toda su
 carrera profesional y además
 estará presente durante
 toda ella

[pág. 4]
¿Dónde aplicarán estos conocimientos?
 Opción 1 Opción 2
 ✓ Finanzas ✓ Generalista
 ✓ Marketing de Recursos
 ✓ Tecnología Humanos
 ✓ Estudios ✓ Especialista
 ✓ Producción en gestión de
 ✓ Operaciones Personas

[pág. 5]
Claves de una carrera exitosa
¿Habilidades duras / técnicas?
 ¿Habilidades blandas?

[pág. 6]
Ciclo de Gestión de Personas
 Reclutamiento
 Gestión de la
 cultura Selección
 y del cambio
 Gestión
 del ambiente
 Formación
 Integración, Inducción, Capacitación interno
Gestión del
 liderazgo Desempeño / Desarrollo
 Evaluación, feedback
 Compensaciones
 Salarios, incentivos, beneficios Gestión de las
 comunicaciones
 internas
 Gestión de Talento / Sucesión
 las relaciones
 laborales
 Salidas
 Marco Legal

[pág. 7]
Ciclo de Gestión de Personas
¿Qué pasa si hacemos alguna
 parte del ciclo mal?

[pág. 8]
Cuando el ciclo no funciona bien o
 cuando no “vemos” los cambios
 Luego de ganar tres
 Lehman Brothers anillos de la NBA de
El "hombre del Ser ascendido al piso 31 manera consecutiva "No nos gusta
 año" en 1938 equivalía a ganarse la con los Chicago Bulls, como suenan, y la
según la revista lotería. Mientras un Michael Jordan decidió música de la
Time era Adolfo trader que generaba abandonar el guitarra está
 Hitler para la empresa US$ 10 baloncesto para pasando de moda"
 millones podía ganar un incursionar en el dijeron los de Decca
 bono de US$ 250 mil, béisbol. Apenas Recording Company
 cada uno de los conectó para .202 en en 1962 al
 ejecutivos más cercanos su breve paso con los rechazar a los
 a Fuld recibía US$ 25 Birmingham Barons de Beatles
 millones la categoría AA.
 Ronald Reagan, ex-
 presidente de los
Estados Unidos y ex Inmigración Redes Sociales - IA
 -actor de cine, fue El fenómeno de la Las redes sociales y la
rechazado para el rol inmigración que se ha IA generarán
 principal en una dado en los últimos movimientos al interior
 película de 1964 años requerirá de de las empresas que
 llamada "The Best competencias distintas escaparán del control
 Man" porque "no en los liderazgos y en de la administración
 tenía apariencia de la gestión de las
 presidente" culturas de las
 empresas

[pág. 9]
¿Cómo se logran las ventajas
competitivas a través de las Personas?
– Cuando las personas tienen / aportan
 valor para la organización
– Cuando son excepcionales y no están
 disponibles para los competidores
– Cuando son difíciles de imitar
– Cuando están organizadas para lograr
 sinergia
…cuando se administra adecuadamente
 el ciclo de gestión de personas

[pág. 10]
Desafíos de RRHH vs. desafíos de la
 empresa
 ¿En qué se parecen?
 ¿En qué se diferencia?

[pág. 11]
Principales desafíos en la administración de RRHH
 Administrar el
 Ser Global cambio
 Resistencia al cambio,
 ESG global Cambio continuo,
 culturas, leyes, Programas formales
 prácticas de de administración del
 negocio cambio
 Adaptarse a nuevas
 Tecnologías
 Nuevas habilidades y
 conocimientos,
 Trabajo a distancia,
 Entrenamiento /formación
 SIRRHH
 IA en procesos de
 gestión de personas

[pág. 12]
Principales desafíos en la administración de RRHH
 Administrar el Responder al Mercado
 Talento Entender y satisfacer al
 cliente
 Nuevas Reingenería / eficiencia
 competencias, operativa (costos, calidad,
 Flexibilidad servicio y velocidad)
 laboral
 Contención de
 Costos
 Downsizing,
 Outsourcing o
 subcontratación

[pág. 13]
Principales desafíos en la administración de RRHH
 Mejoras en la Productividad
 MOTIVACIÓN
 AMBIENTE
 SERVICIOS
✓ Enriquecimiento
 del puesto ✓ Herramientas de
 ✓ Reclutamiento
✓ Empowerment de trabajo
 ✓ Selección
 empleados ✓ Relaciones
 ✓ Capacitación
 interpersonales
✓ Promociones ✓ Desarrollo
✓ Coaching ✓ Equipos
 ✓ Compensaciones
✓ Retroalimentación ✓ Apoyo del líder
 ✓ Bienestar
 ✓ Cultura
✓ Recompensas

[pág. 14]
Otros retos / oportunidades…
 son momentos de cambios
 Cambios culturales
 Cambios demográficos
 Derechos de los empleados
 Diversidad cultural Privacidad
 Distribución por edad Actitud hacia el trabajo
 Nivel educacional Diversidad e inclusión
 Conciliación
¿Qué le aporta la diversidad a las empresas?

[pág. 15]
Responsabilidades del Gerente de RRHH
 1. Consejo y asesoría
 2. Servicio
 3. Formulación e implementación
 de políticas
 4. Defensa del empleado

[pág. 16]
Competencias del Gerente de RRHH
 Dominio del Negocio
 • Conocimiento del negocio
 • Habilidades de negocios
 • Orientación al Cliente
 • Relaciones Externas
 Credibilidad Personal
 • Confianza
 • Relaciones interpersonales
 • Valores vividos
 • Determinación
 Dominio del Cambio
 Dominio de RRHH
 • Habilidades
 • Proceso de empleo interpersonales e
 • Evaluación de desempeño influencia
 • Sistema de recompensas • Habilidades para la
 • Comunicación solución de problemas
 • Diseño de la • Sistema de recompensas
 organización • Inventiva y creatividad

[pág. 17]
¿Qué entendemos por
 planificación estratégica?
 Conjunto de procedimientos
para tomar decisiones acerca de
 los objetivos de largo plazo de
 una organización

[pág. 18]
¿Qué se entiende por
 planificación estratégica de
 Recursos Humanos?
Conjunto de actividades de recursos
 humanos que permiten a una
 organización lograr sus objetivos
 estratégicos

[pág. 19]
Elementos importantes para el
 éxito de un plan estratégico
✓ La formulación del PE considera a las personas
 (capacidades actuales)
✓ La implementación considera una buena
 asignación / readecuación de recursos
 (construcción de capacidades futuras)
✓ Coherencia y alineamiento
 ¿Cómo sé que la gestión de personas
 es importante para la organización?

[pág. 20]
Construyendo un Plan Estratégico (1)
 ✓ Declaración de la razón de ser de la
 organización
 Propósito
 ✓ En general es una frase corta y
 “motivadora”
✓ Google: “Organizar la información del mundo y hacerla
 universalmente accesible y útil”
✓ Latam: ”Cuidamos que los sueños lleguen a su destino”
✓ Entel: “Existimos para acercar las infinitas posibilidades que
 da la tecnología y así transformar responsablemente la
 sociedad”
✓ BCI: “Atrevernos a hacer una diferencia”

[pág. 21]
Construyendo un Plan Estratégico (1)
✓ Declaración de acerca hacia a donde se
 Misión /
 dirige la empresa y lo que puede llegar a
 ser en el futuro
✓ Aclara la dirección a largo plazo y la
 intención de su estrategia
 Visión
✓ BCI: “Aspiramos ser líderes regionales en innovación, cercanía y
 experiencia de clientes y ser reconocidos como la mejor empresa para
 trabajar y desarrollarse”
✓ Mercado Libre: “Democratizamos el comercio y los servicios
 financieros para transformar la vida de millones de personas en
 américa latina”
✓ Clínica Alemana: “Promover y satisfacer en forma integral el cuidado
 de la salud y bienestar de las personas y contribuir al desarrollo del
 conocimiento médico en beneficio de la sociedad, de manera sostenible
23 e innovadora en todos sus ámbitos de acción”

[pág. 22]
Construyendo un Plan Estratégico (1)
 ✓ Sólidas y perdurables creencias y principios en los
 que se basa la empresa para tomar sus decisiones
Valores ✓ Parámetros fundamentales sobre cómo actuará
 la empresa con los clientes, empleados,
 accionistas, la sociedad, etc..
 ✓ Límites respecto a qué comportamientos se
 consideran éticos y aceptables (cultura organizacional)

[pág. 23]
Construyendo un Plan Estratégico (1)
 Valores

[pág. 24]
Construyendo un Plan Estratégico (2)
 Análisis del ambiente competitivo
 Esquema de las 5 fuerzas
 Nuevos
 Competidores
 Proveedores Empresas Clientes
 Rivales
 Sustitutos

[pág. 25]
Construyendo un Plan Estratégico (3)
 Análisis interno
Actitudes y Habilidades y
creencias conocimientos
 Cultura Competencias
 Análisis del
 ambiente
 interno
 ✓ Trabajadores con
 conocimiento
 estratégicos
 ✓ Trabajadores de apoyo
 Composición
 ✓ Socios y habilidades
 complementarias

[pág. 26]
Construyendo un Plan Estratégico (3)
 Análisis interno
 Pronósticos de demanda y de
 oferta de empleados
 Inventario de Mapas de
 habilidades sucesión
 Equilibrio
 Escasez - Excedente

[pág. 27]
Construyendo un Plan Estratégico (4)
 Formulación de la Estrategia
 Análisis FODA
Diseño / elección de un curso de acción coherente
 Estrategia Corporativa Dónde y cuándo competir: elección de dominio
 Concentración Integración
 Estrategia de Negocios Cómo la empresa creará valor
 Bajo costo Diferenciación
 Estrategia Funcional Garantizar el alineamiento
 Externo Interno

[pág. 28]
Construyendo un Plan Estratégico (5)
 Implementación de la Estrategia
 (solo)medio
“lo bien iniciado ya está está hecho”
 medio hecho”
 FIGURE 2–8 EL MODELO 7-S

[pág. 29]
Construyendo un Plan Estratégico (6)
 Evaluación y valoración
✓ Benchmarking
✓ Medición del alineamiento Estratégico
 ✓ Balance Scorecard
 ✓ Adaptabilidad Interna: prácticas de RRHH alineadas
 entre sí para asegurar reforzamiento mutuo
✓ Aseguramiento de la flexibilidad Estratégica o
 la capacidad/adaptabilidad para el cambio
 Balance Scorecard: marco de trabajo que
 ayuda a los gerentes a traducir las metas
 estratégicas en objetivos operativos

[pág. 30]
Construyendo un Plan Estratégico (6)
 Evaluación y valoración: algunos
 indicadores de RRHH
✓ Rendimiento sobre la inversión en Capital Humano:
 utilidades / gastos de personal
✓ Costos de separación: indemnización anual/ ingresos
 anuales por empleado
✓ Gastos de personal / ingresos
✓ Inversión en capacitación / ingresos
✓ Costo de contratación
✓ Tiempo promedio en cubrir una vacante
✓ Rotación: voluntaria y no voluntaria
✓ Ausentismo: días perdidos totales / días totales trabajado

[pág. 31]
Porqué fallan las PE
✓ Misión poco clara y despliegue limitado
✓ Visión poco atractiva y motivante – no apela
 a la emoción
✓ Pobre análisis de los datos e información para
 la preparación del plan
✓ Poca conciliación entre el largo y el corto
 plazo
✓ Seguimiento inadecuado
✓ Implementación no sistemática

[pág. 32]
Porqué fallan las PE
La implementación obliga a salir de la zona de confort

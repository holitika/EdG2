# Dirección de Personas · Tema 3 - reclutamiento y selección

Fuente: clase de Dirección de Personas

[pág. 1]
TEMA 3: RECLUTAMIENTO Y
 SELECCIÓN
 DIRECCIÓN DE PERSONAS
 Escuela de Administración
 Julio 2013
 Alejandra Mehech C.

[pág. 2]
Reclutamiento,
 ¿porqué es
 importante?

[pág. 3]
Elementos de una estrategia de reclutamiento
1
 ¿Por qué alguien querría
 trabajar en esta empresa?
 ¿Quién es el
 responsable de
 reclutar? MARCA
 ¿Qué posiciones y
 competencias son
 DECISION FOCO más importantes?
 ¿Lo
 necesitamos TIMING UBICACION
 ahora o en
 el futuro? ¿Dónde
 METODO necesitamos
 talento?
 ¿Cuáles son las mejores
 fuentes para encontrar
 talentos?

[pág. 4]
Claves del reclutamiento
• “Muchos” postulantes para cada puesto
• Buenos “reclutadores” – rol de la línea
• Buena descripción/especificación del cargo –
 no sobrevender
• Imagen de marca – no sobrevender
• Proceso continuo,
 cuando corresponda

[pág. 5]
Tipos de reclutamiento
INTERNO ¿Versus? EXTERNO

[pág. 6]
INTERNO Reclutamiento Interno
 Ventajas
• Los candidatos están fácilmente
 disponibles
• Se premia el desempeño
• Se capitaliza la inversión
• Menos incertidumbre en su desempeño
• Es más barato

[pág. 7]
INTERNO Reclutamiento Interno
 Consideraciones
• ¿Influye el tamaño de la organización?
• ¿Depende del cargo que se esté buscando?
• ¿Cómo se resuelven los conflictos internos?
• ¿Movimientos sin promoción - existen?
• ¿Conservamos conocimiento o compramos
 conocimiento?
• Ojo con la endogamia, nepotismo y “compadrazgo”
• Clave para la política de retención y desarrollo
• Proceso debe ser claro, conocido y transparente

[pág. 8]
INTERNO Reclutamiento Interno
 ¿Cómo se
 hace?
• Publicación interna de
 vacantes
• Identificación de talento a
 través de evaluaciones de
 desempeño
• Inventario de habilidades y
 mapas de reemplazo

[pág. 9]
INTERNO Reclutamiento Interno
 Señales de advertencia de un
 “débil banco” de talento
• Tarda mucho tiempo en cubrir puestos clave
• Puestos claves cubierto exclusivamente por
 candidatos externos
• Vacantes cubiertas con “dudas” en capacidades de
 los postulantes
• Reemplazos no tiene éxito en el desempeño del
 cargo

[pág. 10]
EXTERNO Reclutamiento Externo
 ¿Por qué optar por el
 reclutamiento externo?
• No existen candidatos internos
• Hay que cubrir muchas plazas simultáneamente
• Requerimiento de competencias muy específicas
• La estructura no provee “competencias” para el
 próximo nivel organizacional
• Traer nuevas ideas y actitudes desde el
 “mercado”
• “Comprar” carteras de clientes / ingresos

[pág. 11]
Reclutamiento Externo
12
 EXTERNO
 Fuentes de
 reclutamiento externo
 Sin cita / CV
 espontáneo
 activo
 Ferias de empleo
 Instituciones Educativas
 CANDIDATO
 Sindicatos Redes sociales
 Agencias de empleo
 Bolsas de trabajo
 Referencias de
 empleados Anuncios
 pasivo
 Head Hunters
 EMPRESA
 pasiva activa

[pág. 12]
EXTERNO Reclutamiento Externo
 Currículos
 espontáneos
• La cantidad a recibir puede ser grande en
 empresas importantes y en tiempos de
 “escasez” de trabajo
• Es necesario disponer de una buena base de
 datos
• Muchos no tienen la formación / competencias
 para las posiciones de la empresa
• Hay que dar señal de “preocupación”; cuidar la
 imagen de marca

[pág. 13]
EXTERNO Reclutamiento Externo
 Referencias de
 empleados
• En general tienen buen desempeño
• Hay que hacerle seguimiento
• ¿Se arriesgan a recomendar a un mal
 compañero?
• Ojo con la endogamia
• Ojo con el nepotismo - ¿qué hacemos con los
 familiares?

[pág. 14]
EXTERNO Reclutamiento Externo
 Anuncios
 • Medios
 • Creatividad
 • Contenido

[pág. 15]
EXTERNO Reclutamiento Externo
 Sitios de Empleo: portales
 para candidatos activos
• Eficiencia
• Acceso
• Masividad

[pág. 16]
EXTERNO Reclutamiento Externo
 Redes Sociales especializadas:
 candidatos pasivos
• Costo
• Masividad
• Cantidad de
 información
 disponible

[pág. 17]
EXTERNO Reclutamiento Externo
Ferias de Empleo
• ¿Cuándo?
• ¿Costo por
 contacto?
• ¿Qué aporta?

[pág. 18]
EXTERNO Reclutamiento Externo
 Head
 Hunters
 • ¿Costo?
 • ¿Qué cargos?
 • ¿Es fácil reclutar
 ejecutivos?
 • ¿Es fácil que se
 adapten a la empresa?

[pág. 19]
EXTERNO Reclutamiento Externo
 Instituciones Educación Superior
 • Gran cantidad /
 variedad
 • ¿Quién presenta?
 • Cargos específicos
 • Costos asociados

[pág. 20]
EXTERNO Reclutamiento Externo
 Otros

[pág. 21]
EXTERNO Reclutamiento Externo
 • ¿algunas?
 • ¿todas?
 • ¿cuál es la clave?

[pág. 22]
EXTERNO Reclutamiento Externo
 La clave es medir
• Costo
• Índices de resultado:
 ✓ Encuestas de satisfacción con personal
 reclutado
 ✓ Tiempo en disponibilizar la terna
 ✓ Tasa de esfuerzo de reclutamiento (seleccionados/presentados)
 ✓ Evaluación de desempeño nuevos contratados
 ✓ Rotación nuevos contratados

[pág. 23]
Selección: ¡saber elegir!
 Predecir desempeño
 Adaptación cultural

[pág. 24]
Del reclutamiento a la selección
 ¿Cómo elegir al correcto?

[pág. 25]
La selección…
¿Cuál es la persona clave para este
 cargo y esta empresa?
Hay que “afinar la
 puntería” entre
persona, el puesto y
 la empresa

[pág. 26]
La selección…
 • Una mala selección es muy “cara”
 • No es una tarea fácil ni un proceso “ligero”
 • En el extremo se pone en juego el futuro de la
 empresa
Cómo saber cuándo nos equivocamos-costos asociados
• Baja productividad
• Errores en la operación del negocio
• Alta inversión en formación / no conoce el trabajo
• Mal clima / quejas del equipo, pares y colaboradores
• Quejas de clientes
• Alta rotación

[pág. 27]
Meta de selección:
 maximizar los aciertos
 Alto
 ERROR ACIERTO
 Pronóstico Inexacto
 (la persona hubiera Pronóstico Exacto
Desempeño en el puesto
 tenido éxito en el (La persona tiene
 puesto) éxito en el puesto)
 ACIERTO ERROR
 Pronóstico Exacto
 (la persona no Pronóstico Inexacto
 hubiera tenido éxito (la persona fracasa
 en el puesto) en el puesto)
 Bajo
 Bajo Alto
 Éxito pronosticado

[pág. 28]
Selección – el proceso
• Análisis de puestos
 Competencias individuales: conocimientos,
 habilidades, capacidades, actitud, experiencia
• Adaptación al puesto – persona
 Entrevista, pruebas, referencias
• Adaptación persona - organización
 Entrevistas para verificar afinidad con valores
 de la empresa

[pág. 29]
Selección – el proceso
Preselección de reclutados
 (evaluación inicial)
 Entrevistas de RRHH
 (y/o de la línea)
 • Los pasos pueden variar
 Pruebas antes del empleo
 • Se puede rechazar en
 Investigación de referencias
 y antecedentes
 cualquier etapa
 Pre-selección de RRHH • ¿Selección interna vs.
 externa?
 Entrevista del supervisor
 (o del equipo)
 Exámenes médicos
 Decisión de contratar

[pág. 30]
Evaluación Inicial
Cartas de presentación y currículos
 • Formato no estándar
 • Reseña de estudios
 • Trabajos anteriores
 • Otros: idiomas, habilidades específicas
 • Hobbies y otras actividades
 • ¿Referencias y pretensiones de sueldo?
En general tienden a “exagerar” y omiten información
poco favorable
¿Cómo almacenar y tabular lo que llega?

[pág. 31]
Evaluación Inicial
Solicitudes de empleo
 • Formato estructurado
 • Se pueden utilizar distintos medios; el más
 común es en línea
 • Su almacenamiento es más eficiente
 • Se pueden utilizar sitios propios o bien sitios
 abiertos (laborum, boomeran, universidades,
 etc…)
Ojo con la información que se puede solicitar

[pág. 32]
Importante
• La información que se recoja debe ser confiable y válida
 • Confiable: grado en que la información obtenida por las pruebas
 y otros procedimientos entregan datos comparables en el tiempo
 • Válida: grado en el cual una prueba o procedimiento de selección
 mide los atributos de una persona (mide lo que quiere medir)

[pág. 33]
Importante
• La información se obtiene en forma “legal”
 (antecedentes comerciales, pruebas de drogas, etc…)
• Se cuida la privacidad de la información de los
 participantes del proceso

[pág. 34]
Pruebas
 Medida estándar y objetiva que se usa para medir
 conocimiento, habilidades, capacidades y otras
 características
• Existen innumerables tipos de pruebas
• Es importante verificar que sean confiables y válidas y estén
 “normalizadas” para Chile
• A veces requieren personas capaces de administrar e interpretar
 resultados
• Hay que asegurarse de usar la prueba “adecuada”
• Analizar costo / beneficio de su aplicación

[pág. 35]
Pruebas
Tipos de pruebas
 • De conocimiento del puesto (CPA)
 • De muestra del trabajo (peluquero)
 • De habilidad cognitiva – CI
 • Inventarios de personalidad e intereses (CPI, Myers-Briggs,
 Caliper, Thurstone, Roschard…)
 • De honestidad e integridad - polígrafo
 • De idiomas
 • De centros de evaluación (assesment center)
 • Habilidades físicas
 • Exámenes médicos (¿test de embarazo?)
 • Detección de drogas (¿requiere autorización previa?)

[pág. 36]
Verificación de la información
Google

[pág. 37]
Verificación de la información
Referencias por teléfono o mail
 • ¿Cuál es su relación con el candidato?
 • ¿Cuáles fueron las fechas de empleo del candidato?
 • ¿Cuál fue el título y las responsabilidades generales del
 candidato?
 • ¿En qué áreas fue sobresaliente? ¿En cuáles necesita mejorar?
 • ¿Cómo maneja las situaciones conflictivas y el stress?
 • ¿Por qué razón dejó el candidato su organización?
 • ¿Recontrataría a esta persona?
 • ¿Tiene alguna información adicional que quiera compartir con
 nosotros?

[pág. 38]
Verificación de la
 información
Otros antecedentes
 • Educación
 • Certificado de empleo anterior
 (imposiciones…)
 • Antecedentes penales (registro
 civil, página del poder judicial)
 • Antecedentes comerciales OJO
 (Dicom, Equifax)

[pág. 39]
Entrevista
• ¿Quién(es) entrevista(n)?
• ¿De qué depende?
• ¿Cuáles son los problemas con que nos encontramos?
• ¿Por qué se utilizan?
 ✓ Es práctica
 ✓ Sirve para otros propósitos (relaciones públicas)
 ✓ Los entrevistadores tienen fe y confianza en su juicio

[pág. 40]
Tipos de Entrevistas
 Entrevista No Dirigida
Entrevistador no discute ni interrumpe Usa las pausas
El entrevistador no hace comentarios Sólo da respuestas breves
Entrevistador escucha con cuidado Preguntas amplias y abiertas
Máxima libertad al entrevistado Utiliza preguntas de seguimiento
 • Se obtiene información muy subjetiva y poco comparable
 • Baja validez y confiabilidad
 • Es más utilizada para entrevistas de altos ejecutivos

[pág. 41]
Tipos de Entrevistas
Entrevista Estructurada
• Set de preguntas estandarizadas (del análisis de puesto)
• Provee información comparable
• Tienen el doble de probabilidad de predecir desempeño

[pág. 42]
Tipos de Entrevistas
Entrevista Situacional
• Variación de entrevista estructurada
• Entrega al postulante un incidente “hipotético” y se le
 pide una respuesta ante él
Ejemplo
Es la víspera de sus vacaciones programadas. Tiene las
maletas hechas y está listo para partir. Justo antes de
acostarse recibe una llamada de la planta. Ha surgido un
problema que sólo usted puede manejar. Le piden
ocuparse de la situación. ¿Qué haría?

[pág. 43]
Tipos de Entrevistas
Entrevista de Descripción del Comportamiento
• Variación de entrevista situacional
• En vez de preguntar evento “hipotético” se refiere a
 eventos reales del ocupante y cómo actuó ante ellos

[pág. 44]
Otros modelos de entrevista
Entrevista de panel y entrevistas secuenciales
• Más de un entrevistador
• Acuerdo inmediato post – entrevista
• Puede ser más confiable
• Puede acortar el período de decisión

[pág. 45]
Investigación sobre entrevistas: principales hallazgos
1. Las entrevistas estructuradas son más confiables que las no
 estructuradas
2. Los entrevistadores están más influenciados por la información
 desfavorable que por la favorable
3. La confiabilidad entre observadores aumenta cuando hay más
 información acerca del puesto que se va a cubrir
4. Un prejuicio se establece pronto durante la entrevista y esto tiende a
 ser seguido por una decisión favorable o una desfavorable
5. La inteligencia es el rasgo que se puede estimar con más validez en
 una entrevista, pero la información de ésta no agrega nada a los
 datos de la prueba
6. Los entrevistadores pueden explicar por qué consideran que es
 probable que un solicitante sea un empleado insatisfactorio, pero no
 por qué el solicitante puede ser satisfactorio

[pág. 46]
Investigación sobre entrevistas: principales hallazgos
7. Los datos objetivos escritos parecen ser más importantes que la
 apariencia física al determinar juicios. Esto aumenta con la
 experiencia en las entrevistas
8. Un entrevistado recibe una evaluación más extrema
 (positiva/negativa) cuando está precedido por un entrevistado de
 valor opuesto (positiva/negativa)
9. Las habilidades y la motivación interpersonales probablemente se
 evalúan mejor con la entrevista
10. Darle al solicitante tiempo para hablar disminuye la probabilidad de
 que el entrevistador se forme primeras impresiones rápidas y
 proporciona una muestra de conducta mayor
11. Tanto las interacciones no verbales como las verbales influyen en las
 decisiones
12. Los entrevistadores experimentados califican a los solicitantes en el
 mismo orden, aunque difieren en la proporción que aceptarán y tienen
 a ser más selectivos que los menos experimentados

[pág. 47]
El Entrevistador
• Es fundamental contar con entrevistadores capacitados
• Características:
 ✓ Capacidad de escucha
 ✓ Objetividad
 ✓ Madurez
• Debe evitar:
 ✓ Hablar demasiado
 ✓ Emitir opinión
 ✓ Prejuicios

[pág. 48]
11 reglas básicas para entrevistadores
 1. Comprenda el puesto
 2. Establezca un plan de entrevistas
 3. Mantenga un buen ambiente para la comunicación y
 escuche activamente
 4. Preste atención a las señales no verbales
 5. Proporcione información tan libre y honesta como sea
 posible
 6. Utilice preguntas con efectividad
 7. Separe los hechos de las deducciones
 8. Reconozca sesgos y estereotipos
 9. Evite el “efecto halo” (juzgar sólo por un punto)
 10.Controle el curso de la entrevista
 11. Estandarice las preguntas planteadas

[pág. 49]
¿Cómo se toma la decisión?
 “PUEDE HACER”
 _________________________________
• Conocimiento
• Habilidades
• Capacidades
 DESEMPEÑO EN
 EL PUESTO
 “HARÁ”
 _________________________________
 • Personalidad
 • Valores
 • Motivación

[pág. 50]
¿Cómo se toma la decisión?
 Algunas consideraciones
• ¿Mayor potencial o cubrir necesidad actual?
• Características del puesto: rotación, tipo de
 competencias requeridas, escasez de talentos
• Grado y nivel salarial
• ¿Sobrecalificado?
 Al final…entre candidatos equivalentes…
 ¿cómo elijo?

# Dirección de Personas · Tema 2 - analisis y diseño de cargos

Fuente: clase de Dirección de Personas

[pág. 1]
TEMA 2: ANALISIS Y DISEÑO
 DE PUESTOS DE TRABAJO
 DIRECCIÓN DE PERSONAS
 Escuela de Administración
 Julio 2013
 Alejandra Mehech C.

[pág. 2]
¿Qué es un puesto o cargo?
PUESTO: grupo de actividades y deberes relacionados, desarrollado por
 uno o más empleados
FAMILIA DE PUESTOS: grupo de puestos individuales con
 características similares
 Puesto
 Puesto Puesto Puesto

[pág. 3]
Requisitos de un Puesto
DESCRIPCIÓN DEL PUESTO
 ¿QUÉ ES?
 Resumen de lo que hace y
 tareas esenciales del puesto
 ¿DÓNDE SE USA?
 Reclutamiento
 Selección
 Capacitación
ESPECIFICACIÓN DEL PUESTO
 Evaluación de
 ¿QUÉ ES? desempeño
 Conocimientos, habilidades y
 Compensaciones
 capacidades que debe reunir la
 persona para desarrollar el
 puesto

[pág. 4]
Competencias Laborales
 SABER
 Conocimientos: Habilidades:
 Conjunto de Capacidad para
 saberes para ejecutar una
 ejecutar una función
 función
 SABER HACER
 Actitudes:
 Disposición o
 postura frente a
 la ejecución de la
 función
QUERER HACER

[pág. 5]
Análisis de puestos
 Obtener información de lo que se hace en
 ¿Qué
 un puesto: deberes, tareas, actividades y
 es?
 las competencias requeridas por el puesto
¿Cómo
 Investigación sistemática que da como
 se
 resultado 20 ó 30 tareas
 hace?
¿Cuál es
 el Descripciones y especificaciones del puesto
output?

[pág. 6]
Análisis de puestos: el proceso
 DESCIPCION DEL
 PUESTO
 • Tareas
 • Deberes
FUENTES DE DATOS
 • Responsabilidades
• Analistas de
 DATOS DEL
 puestos
 PUESTO
• Empleado
 • Tareas FUNCIONES DE RECURSOS
• Supervisor
 • Estándares de HUMANOS
 desempeño • Reclutamiento
 • Responsabilidades • Selección
 • Conocimientos • Capacitación y desarrollo
 requeridos • Evaluación de desempeño
 • Habilidades • Administración de la
 requeridas compensación
 • Experiencia
METODOS DE necesaria
RECOPILACIÓN DE • Entorno del
DATOS puesto ESPECIFICACIÓN
• Entrevistas • Deberes DEL PUESTO
• Cuestionarios • Equipo utilizado • Habilidades
• Observaciones requeridas
• Registros • Conocimientos
 requeridos
 • Capacidades
 necesarias
 • Exigencias físicas

[pág. 7]
Análisis de puestos
¿Quién hace el análisis de un puesto?
¿Cuál es el rol del supervisor y el gerente
del área?
¿Qué problemas tiene el proceso?

[pág. 8]
¿Por qué es importante una buena
definición de un puesto de trabajo?
 • Claridad organizacional
 • Productividad: Influye en el logro de los
 objetivos de la organización
 • Satisfacción y motivación de los
 empleados
 • Retención

[pág. 9]
Claves para el análisis de puestos
 • Conocimiento del negocio
 • Analista entrenado
 • Apoyo de la línea
 • Sistemas adecuados

[pág. 10]
Otros retos del análisis de puestos
• Cambios constantes: de la organización, del
 entorno, la tecnología, etc…
• Cambios en las responsabilidades del ocupante
 en función con el desempeño y la experiencia
 de los ocupantes
• Puestos a la medida de los ocupantes
• Ocupantes sobre-calificados para la posición

[pág. 11]
Formulario descripción de cargo

[pág. 12]
Problemas con las descripciones
• Vagas; poca guía y malentendidos
• Falta de actualización
• Problemas legales
• Restan flexibilidad, limitan el alcance

[pág. 13]
Redacción de las descripciones
• Redacción clara, simple y breve, evitar frases
 innecesarias
• Utilizar verbos en tiempo “presente”
• Usar ocasionalmente cuando la tarea es
 esporádica y puede cuando la tarea la
 desempeñan sólo algunos ocupantes del puesto
• Ojo con: tarea tediosa (falta de compromiso
 de la línea) y empresas pequeñas

[pág. 14]
Diseño de Puestos
Actividad que mejora los puestos por medio de
consideraciones tecnológicas y humanas con el fin
de aumentar la eficiencia de la organización y la
satisfacción laboral del empleado en su puesto
Se relaciona con el cambio, la modificación y el
enriquecimiento de los puestos para captar los
talentos de los empleados mientras mejoran el
desempeño de la organización
Puede ser una consecuencia del análisis de
puestos

[pág. 15]
Bases para el Diseño de puestos
 Objetivos de la organización
 para el puesto, los cuales
 incluyen las tareas, lo deberes
 y las responsabilidades a
 desempeñar
 Las cuestiones de ingeniería
industrial que se centran en Las consideraciones
 EL ergonómicas que impliquen
 los procesos eficientes de
producción y en mejoras del PUESTO capacidades y limitaciones
 método de trabajo (Taylor humanas garantizando su
 bienestar físico
 – Fayol)
 Las cuestiones del
 comportamiento reflejadas en
 los diferentes talentos,
 capacidades y habilidades de los
 empleados

[pág. 16]
Métodos de diseños de puestos: comportamiento
 1.- Características del puesto (Hackman y
 Oldman)
 Modelo que se basa en 3 estados sicológicos del
 ocupante del puesto que mejoran el desempeño,
 la motivación, el ausentismo y la rotación
 1. Experimenta lo “significativo” del trabajo
 2. Tiene conocimiento de los resultados del
 trabajo
 3. Experimenta la “responsabilidad” por los
 resultados del trabajo

[pág. 17]
Métodos de diseños de puestos: comportamiento
 1.- Características del puesto (Hackman y
 Oldman)…continuación
 5 características del puesto:
 a) Variedad de habilidades
 b) Identidad con la tarea
 c) Importancia de la tarea
 d) Autonomía
 e) Retroalimentación

[pág. 18]
Métodos de diseños de puestos: comportamiento
 2.- Enriquecimiento del puesto (Herzberg)
 Enriquecer el puesto para que este sea más
 gratificante o satisfactorio agregando tareas
 más significativas (expansión vertical)
 Cumplir con necesidades superiores:
 autorrealización y autoestima
 Aumentar autonomía, responsabilidad, nivel de
 dificultad, autoridad y control de resultados,
 nuevas tareas, tareas específicas para aumentar
 crecimiento profesional

[pág. 19]
A tener en consideración…
 • No son la panacea para solucionar problemas de
 sueldos, prestaciones y otros
 • No todos los métodos son para todos los
 ocupantes de los puestos (hay personas que
 gustan de la monotonía)
 • Se requieren ciertas condiciones de los ocupantes
 de los puestos: motivación y capacidades
 • Es deseable la participación de los empleados
 expertos
 • Ojo con la cultura organizacional (innovación) y
 con los jefes (autonomía y responsabilidad)

[pág. 20]
Diseño de puestos: top-down – bottom up
 Enfoque top down
 foco en la tarea
 Ingeniería
 Ergonomía
 Industrial
 Enriquecimiento Empowerment
 Enfoque bottom up
 foco en la persona

[pág. 21]
Incorporación de la flexibilidad en el
 diseño de puestos de trabajo
 • Horarios de trabajo flexible
 • Semana de trabajo reducida
 • Puesto compartido
 • Teletrabajo
 ¿Ventajas / Desventajas?

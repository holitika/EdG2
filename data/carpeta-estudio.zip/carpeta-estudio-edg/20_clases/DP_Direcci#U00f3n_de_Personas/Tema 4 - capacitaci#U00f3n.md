# Dirección de Personas · Tema 4 - capacitación

Fuente: clase de Dirección de Personas

[pág. 1]
TEMA 4: CAPACITACIÓN Y
 DESARROLLO
 DIRECCIÓN DE PERSONAS
 Escuela de Administración
 Julio 2013
 Alejandra Mehech C.

[pág. 2]
Definición
Cualquier esfuerzo de la organización para
fomentar el aprendizaje de sus miembros para
el corto plazo (capacitación) o el largo plazo
para sus futuras responsabilidades (desarrollo)
 • Conocimientos
 • Habilidades (saber hacer) - Capacidades
 (potencial para aprender a hacer)
 • Actitudes

[pág. 3]
Capacitación y Desarrollo y
 otras funciones de RRHH
 Capacitación para apoyar al Provee herramientas
 Reclutamiento
 reclutamiento adicionales a los capacitados
 La capacitación permite Si es efectiva puede reducir
 contratar postulantes menos Selección las necesidades de
 calificados capacitación
 La capacitación ayuda al logro Base para detectar
 Evaluación de
 del desempeño – entrega necesidades de capacitación y
 herramientas de liderazgo
 Desempeño medición de sus resultados
 La capacitación y desarrollo
 Adm. de Base para determinar nivel
 puede conducir a aumentos
 salariales Compensaciones de renta
 La cooperación sindical
La capacitación puede incluir un Relaciones
 puede facilitar los esfuerzos
 rol para los sindicatos Laborales de capacitación

[pág. 4]
Expectativas de la capacitación
Contribuir a las metas generales de
la organización:
 ✓ resultados / productividad
 ✓ nuevos procesos / productos / tecnologías
 ✓ nueva legislación
 ✓ habilidades de liderazgo
 ✓ Cambio cultural
 ✓ Nuevos temas de interés: inclusión, ESG,
 flexibilidad laboral, calidad, entre muchos
 otros
 ✓ etc…
 Debe estar alineada con la
 estrategia de la empresa

[pág. 5]
Capacitación
 ¿GASTO O
 INVERSIÓN?

[pág. 7]
Modelo estratégico de capacitación
 FASE 4:
 -------------------
 Evaluación
 FASE 3: -------------------
 ------------------- • Reacciones
 • Aprendizaje
 Implementación
 • Comportamiento
 FASE 2: ------------------- (transferencia)
 ------------------- • Métodos en el • Resultados
 Diseño puesto
 • Métodos fuera del
 ------------------- puesto
 • Objetivos
 FASE 1: • Desarrollo gerencial
 instruccionales
 --------------------- • Disposición y
 Evaluación de motivación de los
 necesidades capacitados
 • Principios de
 ---------------------
 aprendizaje
• Análisis de la • Características de
 organización los instructores
• Análisis de las tareas
• Análisis de las
 personas

[pág. 8]
Fase 1: Evaluación de
 Necesidades de capacitación
 Análisis de
 --------------- …del entorno, las estrategias y los
 recursos para determinar dónde
• La organización enfatizar la capacitación
 …de las actividades que se van a
 desempeñar para determinar los
• Las tareas conocimientos, habilidades y capacidades
 necesarias
 …del desempeño, conocimiento y
• Las personas habilidades para determinar quién
 necesita capacitación

[pág. 9]
Fase 2: Diseño del programa
 Diseño
-----------------
• Objetivos Lo que queremos que aprendan, las
 instruccionales actitudes que queremos cambiar. Deben
 enfocarse en el “desempeño”
• Disposición y
 motivación de los Lo que pueden y quieren aprender los
 asistentes a la capacitación
 capacitados
• Principios de Elementos que aumentan la probabilidad de
 aprendizaje aprendizaje
• Características de Habilidades de enseñanza de los
 los instructores capacitadores / facilitadores

[pág. 10]
Fase 2: principios de aprendizaje
 Establecimiento
 Modelando
 de metas
 Diferencias
 Importancia
 Individuales: como
 de la
 aprende cada uno
 presentación Principios
 de
 Aprendizaje
 Retroalimentación
 y esfuerzo Práctica activa y
 repetición
 Aprendizaje
 masivo frente Aprendizaje
 a distribuido: # global frente a
 de sesiones y aprendizaje parcial
 duración

[pág. 13]
Fase 3: Implementación del programa –
 cómo elegir el método de enseñanza
• Naturaleza de la capacitación: conocimiento,
 habilidades, actitudes, etc…
• Cuánta gente será capacitada (% del total)
• Distribución geográfica de los participantes
• Requerimientos de certificación
• Importancia de los “resultados” de la
 capacitación

[pág. 14]
Fase 3: Implementación del programa

[pág. 15]
Fase 3: Implementación del programa
 Empleados no directivos
 ------------------------------------
 1. Capacitación en el puesto (OJT)
 2. Aprendizaje práctico
 3. Instrucción de aula
 4. Instrucción programada
 (aprendizaje auto-dirigido)
 5. Métodos audiovisuales
 6. Simuladores
 7. E-learning

[pág. 16]
Fase 3: Implementación del programa
 Empleados Directivos
 Experiencias en el puesto
 ------------------------------- -------------------------------
 1. Experiencias en el puesto 1. Coaching / Mentoring
 2. Seminarios y Conferencias 2. Reemplazos
 3. Estudios de casos 3. Transferencia lateral
 4. Juegos de negocios 4. Rotación de puestos
 5. Juego de roles 5. Proyectos especiales
 6. Modelamiento del
 comportamiento

[pág. 17]
Fase 4: Evaluación del programa
 Criterios para evaluar la capacitación
 Reacciones
 Comportamiento
 Aprendizaje
 (transferencia)
 Resultados
 (ROI)

[pág. 18]
Otros programas de Capacitación
• Integración / Onboarding / Inducción
• Capacitación en habilidades básicas (leer,
 escribir, etc…)
• Capacitación cruzada (polifuncionalidad)
• Capacitación de equipos
• Capacitación en temas especiales (ética,
 inclusión, liderazgo femenino, etc…)

[pág. 19]
Otros temas a tener en cuenta
• ¿Voluntaria / obligatoria, por invitación / por
 inscripción?
• ¿Qué hago con las inasistencias?, ¿Qué pasa si
 reprueban?
• ¿Capacitación interna o externa?
• Invitaciones, reservas /arriendos de salas, medios
 disponibles, materiales, etc…
• Sistemas de información
• Becas de estudios

# Dirección de Personas · Tema 11 - Relaciones Laborales

Fuente: clase de Dirección de Personas

[pág. 1]
TEMA 11: RELACIONES
 LABORALES
 DIRECCIÓN DE PERSONAS
 Julio 2013
 Escuela de Administración
 Alejandra Mehech C.

[pág. 2]
Relaciones Laborales
• ¿Qué entendemos por Relaciones Laborales?
• ¿Por qué surgen los sindicatos?
 1. Necesidad económica
 2. Prácticas gerenciales insatisfactorias
 3. Necesidad social
• Sindicatos y política
• Sindicatos y movimientos sociales

[pág. 3]
Sindicatos: aspectos legales
• En empresas con más de 50 trabajadores: 25 de ellos
 podrían constituir un sindicato, representando al menos 10%
 de la totalidad de los trabajadores. Si no existe sindicato, 8
 personas podrían crear uno
• En empresas con menos de 50 trabajadores, 8 de ellos,
 representando al 50% de la empresa, podrán conformar un
 sindicato
• El directorio sindical (con fuero) estará conformado por
 entre 1y 9 personas dependiendo del tamaño de la
 organización
 • < 25 - 1
 • 25 y 249 - 3
 • 250 y 999 - 5
 • 1.000 y 2.999 - 7
 • >3000 - 9

[pág. 4]
Sindicatos: aspectos legales
• El fuero sindical se extingue 6 meses después de haber dejado
 la Directiva Sindical
• Los dirigentes sindicales tienen derecho a un número de horas
 sindicales, remuneradas, dependiendo del tamaño de la
 organización
• 3 o más sindicatos podrán formar una Federación y 3 ó más
 federaciones o 20 ó más sindicatos podrán formar una
 Confederación
• Los afiliados a un sindicato deberán pagar una cuota sindical,
 monto establecido en los estatutos del mismo. Asimismo, las
 Federaciones y Confederaciones podrán cobrar una cuota a sus
 asociado

[pág. 5]
Sindicatos: Prácticas antisindicales
• Impedir la libre sindicalización
• Obstaculizar la formación o el funcionamiento del sindicato
• Negarse a entregar información de la empresa para la
 negociación colectiva
• Otorgar ”beneficios” para estimular la no constitución de un
 sindicato
• Favoritismo a no sindicalizados
• Presión / despidos / discriminación
• Extender beneficios de sindicalizados a no sindicalizados sin la
 autorización del sindicato
• Reemplazo de trabajadores en huelga

[pág. 6]
Zona de negociación e influencia
 Historia de
 negociación entre
 las partes
 Leyes y reglas
 Influencias
 administrativas
 económicas
 Límite máximo
 Resultados de la
 preferidos por administración
 el sindicato
 INFLUYENTES
 FACTORES
 Rango esperado Rango esperado
 de resultados de resultados
 deseados por el deseados por la
 sindicato administración
 Resultados
 Límite mínimo
 preferidos por la
 del sindicato
 administración
Personalidades de Otros resultados
 los negociadores negociados
 Opinión
 pública

[pág. 7]
Sindicatos: Negociación Colectiva
• Hay personas que están impedidas de negociar: en general los
 gerentes y subgerentes, siempre que conste en sus contratos
 individuales
• Materias de negociación: remuneraciones, beneficios, condiciones
 comunes de trabajo y adecuaciones de vida familiar
• La empresa sólo puede negociar con sindicatos
• Negociación inicia con la presentación del proyecto de contrato
 colectivo por parte del sindicato hasta 60 días antes del
 vencimiento del contrato vigente
• La respuesta del empleador debe contener el piso mínimo de
 negociación y tiene 10 días desde que le entregan el proyecto
• Entrega de información por parte del empleador: planilla de
 remuneraciones de sindicalizados, valor actualizado de beneficios,
 costos globales de mano de obra, información que incida en la
 política futura de inversiones de la empresa
• En la mesa de negociación debe haber al menos una mujer

[pág. 8]
Sindicatos: Negociación Colectiva
• Si el 50% o más de los afiliados la rechazan la última oferta del
 trabajador se declara la huelga – mediación obligatoria
• Si luego de votada la huelga se utiliza la mediación de la Dirección del
 Trabajo, la huelga se podría hacerse efectiva al 5to. día de la votación
• Durante la huelga queda suspendida la relación laboral
• No existe reemplazo durante la huelga (externo e interno)
• Los trabajadores en huelga podrán descolgarse a partir del día 16
• Servicios mínimos (proteger bienes e instalaciones de la empresa,
 prevenir accidentes laborales, garantizar prestación de servicios de
 utilidad pública y necesidades básicas, la economía del país o la
 seguridad nacional) deben acordarse 180 días antes del inicio de las
 negociaciones
• Extensión de beneficios a no sindicalizados sólo con autorización del
 sindicatos
• Los contratos colectivos podrán durar 2 ó 3 años

[pág. 9]
Medidas finales
• Mediación obligatorias DT
• Huelga
• Buenos oficios

[pág. 10]
Ciclo de Gestión de Personas
 Reclutamiento
 Gestión de la
 cultura Selección
 y del cambio
 Gestión
 del ambiente
 Formación
 Integración, Inducción, Capacitación interno
Gestión del
 liderazgo Desempeño / Desarrollo
 Evaluación, feedback
 Compensaciones
 Salarios, incentivos, beneficios Gestión de las
 comunicaciones
 internas
 Gestión de Talento / Sucesión
 las relaciones
 laborales
 Salidas
 Marco Legal

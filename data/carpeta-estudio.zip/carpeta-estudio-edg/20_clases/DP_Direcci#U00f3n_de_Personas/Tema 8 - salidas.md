# Dirección de Personas · Tema 8 - salidas

Fuente: clase de Dirección de Personas

[pág. 1]
TEMA 8: GESTIÓN DE
 SALIDAS
 DIRECCIÓN DE PERSONAS
 Julio 2013
 Escuela de Administración
 Alejandra Mehech C.

[pág. 2]
Gestión de Salidas
 ¿Por qué es
importante hacerlo
 bien?
 ¿Qué elementos deben
 ser una preocupación
 para la empresa?

[pág. 3]
Tipos de salidas
• Renuncia
• Despidos:
 • Desempeño
 • Reestructuración o ajuste de dotación
 (“eficiencia”)
 • Falta Grave (a las obligaciones que impone el
 contrato)

[pág. 4]
Antes de tomar decisiones de despido
• Considere que, cuando hay que tomar medidas
 drásticas, la sensación de justicia es esencial
• Nunca salidas indiscriminadas o sin base justificada
• El criterio de selección para permanecer debiera ser el
 valor aportado a la empresa y no la edad u otros
 puntos similares
• Cuando el despido es por falta grave revise la
 responsabilidades…ojo con el rol de las jefaturas

[pág. 5]
Despidos por mal desempeño
• Si un despido se realiza por mal desempeño, la
 entrevista debería ser el final de un proceso de
 evaluación y comunicación constante
• No debería haber sorpresas al darle la noticia,
 porque ha tenido varias advertencias previas

[pág. 6]
Despidos por restructuraciones
• Si se trata de una restructuración o reducción de
 dotación es clave dar a conocer que no hay
 responsabilidad del empleado en esta decisión.
• La comunicación debiera centrarse en:
 • La contribución del trabajador a la organización
 • Los criterios que se han seguido para despedirlo

[pág. 7]
Antes de tomar decisiones de despido
por reestructuración
• Antes de despedir piense en otras alternativas: reducción
 de horarios y sueldos; externalización o racionalizar su
 producción
• Planes anticipados para suavizar los traumas del despido:
 outplacement, capacitación y empleabilidad, jubilaciones
 anticipadas selectivas, fondos de indemnización
 especiales…
• Comunique las razones para ejecutar la restructuración,
 explique por qué tienen que hacerla. Si usted no lo hace,
 otros explicarán su versión. En particular los sindicatos
• Asegure a los que se quedan. Es mejor una operación
 profunda que sucesivas superficiales

[pág. 8]
Despedir de forma clara,
 breve y sincera
• Una de las funciones más incómodas para un jefe es el
 despido de algún colaborador
• Una entrevista de despido se debe preparar y
 estructurar en tres partes:
 • Comunicar la noticia
 • Dar las razones por las que se ha llegado al despido
 • Decir cuáles son los siguientes pasos

[pág. 9]
¿Quién debe comunicar el despido?
• El jefe inmediato, eventuamente acompañado de
 alguien del departamento de recursos humanos, que
 será el encargado de quitar presión y explicar los
 pasos a seguir
• Es importante comunicar el despido en los tres
 primeros minutos de la entrevista para que el
 empleado pueda expresar su malestar y cuestionar el
 porqué de la situación.

[pág. 10]
¿Cómo y dónde comunicar el
 despido?
• La entrevista no debe exceder de veinte minutos
• En una sala tranquila y sin interrupciones
• Cuidados con el uso de la oficina del jefe
 • La reunión podría alargarse y no podríamos levantarnos
 e irnos y concluir así la reunión
 • Si es en la oficina del jefe es más difícil manejar los
 sentimientos de ambos

[pág. 11]
¿Cómo se comunica el despido?
• De manera objetiva y documentada, el jefe explicará
 las razones del despido sin debatirlas ni
 argumentarlas
• El jefe no debe
 • mantener una actitud defensiva
 • sentirse obligado a convencer al despedido
• Lo mejor es decirle la verdad al empleado y que el
 proceso sea lo más claro posible

[pág. 12]
¿Cuándo comunicar el despido?
• El mejor momento para realizar la entrevista de
 despido es a comienzos de semana a primera hora,
 para que el empleado tenga tiempo de adaptarse a
 la nueva situación antes del fin de semana
• No es aconsejable despedir un día viernes, ni al final
 de la jornada laboral
• Lo anterior dependerá del tipo de despido a realizar:
 no es lo mismo despedir por falta grave que por
 desempeño (por ejemplo)

[pág. 13]
Síndrome del superviviente
• Un despido por reestructuración o reducción produce
 un efecto en los que “quedan”
• El síndrome del superviviente puede hacer que la
 moral de los que permanecen decaiga
• Por eso, es fundamental comunicar al resto de la
 organización los motivos de un despido
 • Respetando el prestigio de los desvinculados
 • Reafirmando que los despidos se han realizado bajo los
 parámetros conocidos (y lógicos)
• Hay que cuidar a los que “quedan”
• La sensación de justicia es esencial

[pág. 14]
Las 4 claves para un despido
• Decir la verdad
• No discutir ni debatir
• Manejar las emociones
• Comprometerse con la decisión

[pág. 15]
1) Decir la verdad
• Los motivos deben estar claramente expuestos
• No se deberá andar con rodeos ni buscar excusas o
 falsas explicaciones de la decisión
• Esto genera poca credibilidad y puede herir mucho
 más que la verdad misma
• En este concepto se incluye el de no tratar de
 "vender" la decisión, intentando demostrar que la
 misma lo beneficia o que es una "oportunidad"

[pág. 16]
2) No discutir ni debatir
Si la decisión de desvinculación está tomada, lo
mejor es:
 • comunicarla lo más rápidamente posible, sin entrar
 en disquisiciones que no aportarán nada a ninguna
 de las partes
 • No dejar "puertas abiertas" que generen falsas
 expectativas en el empleado despedido

[pág. 17]
3) Manejar las emociones
• Si bien la decisión puede ser traumática tanto para
 el que la comunica como para el que recibe la
 noticia, es evidente que el despedido lleva la peor
 parte
• Es importante que no se reprima la expresión de
 dolor del empleado desvinculado, y que al mismo
 tiempo se lo ayude brindándole un espacio de
 contención y escucha
• Decirle al despedido "esto también es difícil para mi"
 no ayuda en la comunicación de la decisión

[pág. 18]
4) Comprometerse con la decisión
• Es importante no disociarse con la decisión,
 expresando que uno está en desacuerdo con la misma
• El que comunica el despido debe tomar la decisión
 como propia y transmitirla de manera clara
 • No es correcto decir que uno es el que transmite la
 decisión de otra persona, aunque esto sea realmente
 cierto
• El empleado despedido puede sentir que, en realidad,
 no tiene con quién hablar

[pág. 19]
OUTPLACEMENT: VENTAJAS
• Preocupación por la empleabilidad
• Contención / acogida física / apoyo sicológico
• Re - evaluación de carrera
• Asesoramiento en el proceso de reinserción laboral
• Confección de redes de contacto
• Apoyo en emprendimientos personales

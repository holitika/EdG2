# Dirección de Personas · Tema 6 - compensaciones incentivos beneficios

Fuente: clase de Dirección de Personas

[pág. 1]
TEMA 6: ADMINISTRACIÓN
 DE COMPENSACIONES,
INCENTIVOS Y BENEFICIOS
 DIRECCIÓN DE PERSONAS
 Julio 2013
 Escuela de Administración
 Alejandra Mehech C.

[pág. 2]
¿POR QUÉ TRABAJAMOS?

[pág. 3]
¿CUÁNDO TRABAJAMOS FELICES?
• Trabajo desafiante
• Buenos ambientes de trabajo
• Buenos jefes
• Carrera profesional interesante
• Recompensa “adecuada”

[pág. 4]
Compensación
Incluye todas las formas de pago
y recompensa que los empleados
 reciben por el desempeño de su
 puesto

[pág. 5]
Componentes de la Compensación
 Directa Indirecta No Monetaria
 • Programas de
• Sueldos y • Beneficios reconocimiento
 Salarios • Trabajo gratificante
 • Tiempo no
• Incentivos trabajado • Apoyo de la
 organización
 • Servicios al
• Bonos empleado • Ambiente de trabajo
• Comisiones • Etc… • Flexibilidad
 • Buen jefe

[pág. 6]
¡¡Importante!!!
Alinear las formas de compensar
con los objetivos y la cultura de
 la empresa
 Planeación estratégica de las
 compensaciones

[pág. 7]
Compensación Estratégica
Pago por:
 ¿Puesto?
 o
 ¿Competencias y
 aporte al éxito de la
 empresa ?

[pág. 8]
Pagos por desempeño
• Bonos
• Comisiones
• Incentivos de grupo/equipo
• Participación en las utilidades
----------------------------------
• Bandas salariales
 ¿Problemas para medir el mérito?

[pág. 9]
Equidad de pago
El pago constituye una medida cuantitativa del valor
relativo del trabajo de un empleado
Equidad de pago es la PERCEPCION de que la
compensación recibida es igual al valor del trabajo
realizado
¿Efectos en la motivación?
 Equidad de pago:
 • Externa
 • Interna
 Interna
 • Individual

[pág. 10]
¿Confidencialidad en el pago?

[pág. 11]
¿Cómo se determina el pago?
 Factores Internos Factores Externos
• Estrategia de • Condiciones del
 compensación mercado de trabajo
• Valor del puesto • Tasa de pago del
 área
• Desempeño del PAGO
 empleado • Costo de la vida
 • Negociación
• Capacidad de colectiva
 pago de la
 empresa • Requisitos legales

[pág. 12]
Evaluación de puestos
1. Sistema de alineación de puestos
 • Los puestos se ordenan con base a su valor relativo
 • Es barato y de fácil implementación cuando existen pocos
 puestos
 • No proporciona una medida muy exacta del valor de cada
 posición
 • No indica la diferencia del grado de importancia de cada
 posición (escala ordinal)
2. Sistema de clasificación de puestos
 • Los puestos se clasifican en base a categorías predefinidos
 • Criterios habitualmente utilizados: responsabilidad en el
 trabajo, habilidad, conocimiento
 • Sistema simple

[pág. 13]
Evaluación de puestos
3. Sistema de puntos
 • Procedimiento cuantitativo de evaluación
 • Se definen los factores compensables, por ejemplo:
 responsabilidad fiscal, liderazgo, trabajo en equipo,
 responsabilidad del proyecto, etc…
 • Para cada factor se definen categorías con puntaje previamente
 asignado y una ponderación
4. Método de perfiles HAY
 • Es una variante del sistema de puntos
 • Se utiliza principalmente en posiciones gerenciales pero sirve
 para todos los puestos de una empresa
 • Tres factores comunes: conocimientos, actividad mental,
 responsabilidades

[pág. 14]
Herramientas de pago:
 equidad externa
• Encuestas de sueldos y salarios
 • Pago a los empleados de otras empresas en el mercado de trabajo
 relevante
 • En ocasiones también se recoge información de beneficios
• Indispensable contar con sistema de evaluación de puestos
• Es necesario “homologar” los cargos
• Resguardar calidad de la información
 La información recogida se debe traducir en:
 Una Curva Salarial

[pág. 15]
Curva Salarial
Gráfica de puntos que representa la relación entre el valor
relativo de los puestos y sus tasas salariales
 FIGURE 9–6 CURVA DEL SALARIO A MANO ALZADA
© 2007 Thomson/South-Western.
All rights reserved.

[pág. 16]
Curva Salarial
La curva debe traducirse en rango de tasas o salarios
 Rango de tasa única Rango de tasas creciente
 © 2007 Thomson/South-Western. All rights reserved

[pág. 17]
Pago basado en competencias
• El enfoque predominante es el pago por valor del puesto
• Desventajas: no recompensa habilidades ni conocimientos,
 no alienta el aprendizaje y la participación y limita la
 flexibilidad
• Pago basado en competencias: basado en el nivel de
 habilidad del empleado, en la cantidad de habilidades que
 posee o en el aumento del conocimiento del puesto
• Ventajas: mejora la productividad, el aprendizaje,
 compromiso y mejora la flexibilidad
• Desventajas: difícil de medir – implementar
• Se utilizan bandas de compensación más amplias

[pág. 18]
Metas de una política de
 compensación estratégica
1. Recompensar a los empleados por su desempeño
 anterior
2. Seguir siendo competitivos en el mercado
3. Mantener la equidad de salario
4. Entrelazar el desempeño futuro con las metas
5. Controlar el presupuesto de compensación
6. Atraer nuevos empleados
7. Reducir la rotación innecesaria

[pág. 19]
Para lograr estas metas se
deben establecer políticas que
orienten la toma de decisiones

[pág. 20]
Políticas de Compensación
1. En qué lugar de la curva de mercado se ubicará la
 empresa (por sobre, al medio o por debajo)
2. La amplitud de la banda salarial (renta de
 ingreso o reclutamiento y capacidad de
 crecimiento)
3. Intervalos en los cuales se garantizan los
 incrementos de pagos y el grado al cual el mérito
 o la antigüedad influirán en ellos
4. Aceptación del programa de pagos por parte de
 los empleados
5. Niveles de pago necesario para facilitar el logro
 de una sólida posición financiera

[pág. 21]
Finalmente…medir, medir, medir
• Ayuda a la empresa a detectar posibles problemas de
 compensación
• Permite tomar decisiones de compensación más
 transparentes
• Mejora la alineación de las decisiones de compensación
 con los objetivos organizacionales
Indicadores a utilizar (ejemplo):
 • PRE (posición relativa en la escala) o Comparatio
 • % de aumentos realizados a personas con buena evaluación
 • Tasa de rotación
 • % de personas con aumentos de renta por mérito, promoción,
 etc..
 • Gasto anual en aumentos de renta vs. presupuesto

[pág. 22]
Planes de Incentivos
 ¿Porqué existen?
 • Flexibilidad
 • Permite alinear intereses
 (empresa – empleado)
 • Se puede usar para ejercer
 justicia y equidad
DESEMPEÑO - METRICAS - ALINEAMIENTO
MOTIVACIÓN PARA DAR EL MÁXIMO

[pág. 23]
Planes de Incentivos
 Pago por Pago por
 versus
 desempeño antigüedad
 ¿De qué dependen?
 • Factores económicos
 • Factores políticos / legales
 • Ambiente cultural
FILOSOFÍA: compromiso compartido…¿incluso las
 utilidades?

[pág. 24]
Planes de incentivos
 Ayuda a distinguir
 entre los buenos y los
 no tanto…
 y a atraer y
 retener al
 talento

[pág. 25]
Ventajas de un plan de incentivos
• Concentran los esfuerzos de los empleados en objetivos específicos
 del desempeño
• Son fuente de motivación real donde gana la empresa y el
 empleado
• Incrementan la equidad y la sensación de justicia de la organización
• Se distribuye el éxito entre los responsables de producirlo
• Son costos variables asociados a resultados
• Se vincula directamente con el desempeño del negocio
• Pueden fomentar el trabajo en equipo
• Son un medio para recompensar o atraer a los empleados de alto
 desempeño y potencial, sobre todo cuando los presupuestos de
 sueldos son bajos

[pág. 26]
LA CLAVE ES
 EL DISEÑO

[pág. 27]
Planes de incentivos EXITOSOS
 Indicadores que Metas desafiantes
 fomentan el pero alcanzables
 comportamiento
 deseado
 Involucra a los
 empleados en el
 Medible diseño; les parece
 “justo”
 Vínculo claro entre Fórmulas de pago
 desempeño y pago simples y
 comprensibles

[pág. 28]
Cuidados de un plan de incentivos
• Es clave una buena definición de en qué medir
 a cada grupo de personas
• El incentivo se gana por desempeño destacado
• Se debe siempre volver a la base – no es un
 derecho adquirido
• El proceso debe ser formal y bien administrado

[pág. 29]
Tipo de planes de incentivos
• Trabajo a destajo (por producción)
• Plan de hora estándar
• Bonos
• Pagos por mérito (incrementos)
• Premios de incentivos y reconocimientos
• Incentivos de ventas

[pág. 30]
Paquete de compensaciones
 para profesionales
 /ejecutivos
 • Sueldo base
 • Incentivos de corto plazo
 • Incentivos de largo plazo
 • Beneficios ejecutivos

[pág. 31]
Otros tipos de incentivos
• Compensación de equipo
• Planes para la empresa: participación
 de utilidades, opciones de acciones

[pág. 32]
¡¡Importante!!!
• Problemas éticos
• Corto vs. Largo plazo
• Limitaciones legales

[pág. 33]
Planes de Beneficios
• Beneficios médicos
• Beneficios de conciliación familiar
• Beneficios de períodos sabáticos
• Pago de tiempos no trabajado
• Pago de licencias médicas
• Días adicionales de vacaciones
• Programas de retiro
• Planes de pensiones
• Programas de ayuda al empleado
• Otros pagos: aguinaldos, vacaciones, estacionamiento,
 diario, teléfono, etc…

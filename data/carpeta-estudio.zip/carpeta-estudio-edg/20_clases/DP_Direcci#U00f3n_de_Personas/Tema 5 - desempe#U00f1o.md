# Dirección de Personas · Tema 5 - desempeño

Fuente: clase de Dirección de Personas

[pág. 1]
TEMA 5: GESTIÓN DEL
 DESEMPEÑO
 DIRECCIÓN DE PERSONAS
 Escuela de Administración
 Julio 2013
 Alejandra Mehech C.

[pág. 2]
Administración del
 Desempeño
Proceso mediante el cual se crea un
 ambiente laboral en el que las
 personas pueden desempeñarse al
 máximo de sus capacidades

[pág. 3]
Pasos en el proceso de
 Administración del desempeño
 Paso 1
 Establecer objetivos
 para alinearlos con
 objetivos de alto nivel
 Paso 6 Paso 2
Decisión post-evaluación Conversaciones continuas Establecimiento de
 sobre el desempeño
 (compensaciones, expectativas y
 El objetivo final es mejorar
 promoción, formación, estándares de conducta
 etc…) Proceso anual (o bianual) en
 (alineando objetivos)
 el que se evalúa el
 desempeño
 Mejora comprensión de lo
 que se espera de él
 Paso 5 Paso 3
 Entrega las clave para el
 Sesión formal de éxito Retroalimentación
 revisión anual Dónde se necesitan mejorar continua del desempeño
 y por qué durante el ciclo
 Paso 4
 Preparación del supervisor
 Evaluación de desempeño para evaluar el desempeño
 por parte del supervisor

[pág. 4]
¿ ?
¿Cuándo hay que gestionar el desempeño?
¿Es un proceso formal o informal?
¿Qué pasa si no lo hacemos?
¿De quién es la responsabilidad?

[pág. 5]
Un proceso de administración de
 desempeño es exitoso cuando…
• Se comprende por qué y para qué se
 hace
• Está conectado con los objetivos del
 negocio
• Cuenta con jefes que tienen las
 competencias y habilidades adecuadas

[pág. 6]
Cuando se hace bien…
• Efecto “equitativo” en:
 ✓ Compensaciones
 ✓ Promociones
 ✓ Salidas
• Planes de carrera y sucesión
• Formación
 AYUDA A MEJORAR Y A
 MODELAR CONDUCTAS

[pág. 7]
Propósitos de una
 Evaluación de Desempeño
 DESARROLLO
 ADMINISTRATIVOS
 • Retroalimentación
• Compensaciones
 para la mejora
• Análisis de puestos
 • Capacitación
• Documentar
 • Planificación de
 decisiones
 carrera
 “Lo que no se
 mide no existe”

[pág. 8]
Razones por las que falla el proceso
1. Falta de compromiso directivo con el proceso
2. Estándares de desempeño poco claros
3. Sesgos del evaluador
4. Gran demanda de trabajo “operativo” (formularios)
5. Uso para fines “inapropiados” o contradictorios
6. Poca preparación y competencias del supervisor
7. Periodicidad (anual, bianual, trimestral, mensual…)
8. Falta de relación entre el puesto y lo que se espera
 en él

[pág. 9]
Algunos cuestionamientos…
1. La equidad del proceso
2. Desempeño individual vs. desempeño del equipo
3. Capacidad de discriminar entre el buen y el mal
 desempeño
4. Foco en el corto plazo vs. en el largo plazo
 ¿FÁCIL O DIFÍCIL?

[pág. 10]
Desarrollo de un programa efectivo
1. Estándares de desempeño
 Criterios para definir en estándar de desempeño
 ✓ Medible / Objetivo
 ✓ Entendible
 ✓ Alcanzable
 ✓ Controlable

[pág. 11]
Desarrollo de un programa efectivo
1. Estándares de desempeño
Contaminación de
criterios:
Factores fuera del
control del empleado Confiabilidad:
que influyen en su Medidas son
 70 consistentes entre
desempeño Medidas de desempeño
 7560
 50 evaluadores y en el
 tiempo
 Zona de
Relevancia
 evaluación válida
estratégica: Deficiencia de criterios:
Estándares Grado en que éstos
individuales captan todas las
directamente Desempeño real responsabilidades del
relacionados con los empleado (relación con
objetivos estratégicos el puesto)

[pág. 12]
Desarrollo de un programa efectivo
2. El evaluador del desempeño

[pág. 13]
Desarrollo de un programa efectivo
2. El evaluador del desempeño
 e) Evaluación de equipos: evaluación que reconoce
 el logro del equipo en lugar del desempeño
 individual
 f) Evaluación de clientes: busca la evaluación tanto
 de los clientes externos como de los internos
 g) Evaluación en 360°: la suma de todas las
 evaluaciones anteriores pero en una sola
 instancia de evaluación

[pág. 14]
Desarrollo de un programa efectivo
2. El evaluador del desempeño: evaluación en 360°
 DESVENTAJAS
 VENTAJAS
 • Sistema complejo
 • La retroalimentación puede ser
 • Se recogen varias perspectivas
 intimidante
 en forma simultánea
 • Puede haber opiniones contradictorias,
 • Mejor calidad de la información
 aunque válidas desde su respectivo
 • Puede reducir los prejuicios / punto de vista
 sesgos al tener mayor cantidad
 • Requiere capacitación de evaluadores y
 de evaluadores
 evaluados
 • Puede aumentar el
 • Puede existir “manipulación” por
 autodesarrollo del empleado
 colusión entre evaluadores y evaluados
 (retroalimentación de colegas y
 otros) • No es posible responsabilizar a los
 evaluadores (anonimato)

[pág. 15]
Desarrollo de un programa efectivo
2. El evaluador del desempeño: últimas consideraciones
 • ¿Anónimas?
 • ¿Obligatorias?

[pág. 16]
Desarrollo de un programa efectivo
3. Capacitación de los evaluadores
 “Lo que no es importante es el formato (de la
 evaluación) ni la escala (de medición). Lo que sí es
 importante es que los jefes puedan observar de manera
 objetiva el desempeño de las personas y den
 retroalimentación objetiva de ese desempeño”
 Gerente de Recursos Humanos

[pág. 17]
Desarrollo de un programa efectivo
3. Capacitación de los evaluadores
 Es importante establecer un plan de formación de los
 evaluadores que permita comprender:
 ✓ Objetivos del sistema de evaluación de desempeño
 ✓ En que se utilizará la evaluación
 ✓ La mecánica del sistema de evaluación
 ✓ Debilidades y problemas de los sistemas de
 evaluación

[pág. 18]
Desarrollo de un programa efectivo
3. Capacitación de los evaluadores
 a) Errores de evaluación
 • De tendencia central Distribución
 • De indulgencia o severidad Forzada
 Calibración del
 • De eventos recientes
 desempeño
 • De contraste o efecto “halo”
 • De similitud con el evaluador
 b) Retroalimentación
CONSISTENCIA, CONSISTENCIA, CONSISTENCIA

[pág. 19]
Métodos de evaluación de desempeño
1. De rasgos: mide el grado en el cual el empleado
 posee ciertas características (confiabilidad, iniciativa,
 liderazgo, creatividad, etc…)
 • Escalas Gráficas: cada empleado es calificado con base a una escala
 de características
 • Escalas estándar mixtas: se basa en la comparación con un
 estándar (mejor, igual o peor que)
 • Elección forzada: evaluador elije entre declaraciones diseñadas para
 distinguir entre desempeño exitoso y no exitoso
 • Ensayo: evaluador redacta una declaración donde describe el
 comportamiento del empleado

[pág. 20]
Métodos de evaluación de desempeño
2. Conductuales: se utilizan descripciones de
 comportamiento en una escala o serie continua
 • Incidente crítico: evento inusual que indica un desempeño superior
 o inferior del empleado en alguna parte del puesto
 • Lista de verificación del comportamiento: el evaluador verifica
 declaraciones de una lista que él piensa que son las características
 del desempeño del empleado
 • Escala de evaluación basada en el comportamiento (BARS): consta
 de una serie de escalas verticales, una para cada dimensión
 importante del desempeño del puesto
 • Escala de observación del comportamiento (BOS): mide la
 frecuencia del comportamiento observado

[pág. 21]
Métodos de evaluación de desempeño
3. De Resultados: mide los resultados del trabajo de los
 empleados
 • Medidas de productividad: evaluación basada en medidas
 cuantitativas, por ejemplo, ventas, número de contactos con
 clientes, etc…
 • Administración por Objetivos: filosofía de la administración que
 consiste en que se establezcan objetivos de mutuo acuerdo y
 después éstos se utilicen como bases para la evaluación
 • Balance Score Card: la evaluación considera información financiera,
 de cliente, de procesos y de aprendizaje (es similar a la
 administración por objetivos)

[pág. 22]
Métodos de evaluación de desempeño
 Modelo de Administración por Objetivos

[pág. 23]
Métodos de evaluación de desempeño
 Ventajas Desventajas
Método de 1.- Barato 1.- Alto potencial de errores de
Rasgos 2.- Usa dimensiones significativas calificación
 3.- Fáciles de usar 2.- No sirven para el counseling
 3.- No sirven para asignar
 recompensas
 4.- No sirven para decisiones
 promoción
Métodos 1.- Usa dimensiones específicas 1.- Su desarrollo / uso puede
Conductuales 2.- Aceptable para empleados y tomar mucho tiempo
 superiores 2.- Desarrollo costoso
 3.- Útiles para la retroalimentación 3.- Puede tener errores de
 4.- Justos para tomar decisiones calificación
 de recompensa y promoción
Método de 1.- Menos sesgos subjetivos 1.- Su desarrollo / uso ocupa
Resultados 2.- Aceptable para empleados y mucho tiempo
 superiores 2.- Puede fomentar el corto
 3.- Enlazan el desempeño individual plazo
 con el desempeño de la org. 3.- Puede usar criterios
 4.- Fomenta la fijación de objetivos contaminados
 mutuos 4.- Puede usar criterios
 5.- Bueno para tomar decisiones deficientes

[pág. 24]
Entrevistas de Evaluación
Finalmente: quizás la parte más importante del proceso
 Tipos de Entrevista:
 • Hablar y vender: persuadir para
 generar cambio de comportamiento
 • Hablar y escuchar: señalar fortalezas y
 aspectos de mejora y luego escuchar
 sentimientos del empleado respecto de
 la evaluación
 • Solución de Problemas: centrada en el
 desarrollo del empleado – llegar a
 acuerdos para mejorar desempeño

[pág. 25]
Entrevistas de Evaluación: algunos tips
 Pedir autoevaluación Cambio de comportamiento,
 al empleado no la persona
 Enfocarse en la solución de
 Invitar a participar
 problemas
 Mostrar aprecio Dar apoyo
 Establecer metas y plan de
 Minimizar la crítica
 acción
 Seguimiento frecuente

[pág. 26]
Entrevista de Evaluación:
 IMPORTANTE
 Prepararse:
 evaluador y
 evaluado
 Oportunidad
Consistencia y
 y decisión ambientación
 Franqueza y
 amabilidad

[pág. 27]
Recordar el objetivo:
 mejorar el desempeño
 Fuentes del mal desempeño
 SABER QUERER PODER
 Competencias y Entorno y personales:
 Motivación:
 habilidades: • Equipos / materiales
 • Ambición de carrera
 • Diseño del puesto
• Técnicas • Metas y
 • Condiciones económicas
 Interpersonales expectativas
 • Reglas, políticas, leyes
• Solución de • Satisfacciones y
 y regulaciones
 problemas frustraciones
 • Apoyo de la
• Capacidad analítica • Percepción de
 administración
• Comunicación justicia
 • “Herramientas”
• Limitaciones físicas • Relaciones con otros
 personales
 Plan de Trabajo

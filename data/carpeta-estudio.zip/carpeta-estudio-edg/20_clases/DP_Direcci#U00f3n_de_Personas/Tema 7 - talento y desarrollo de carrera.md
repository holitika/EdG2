# Dirección de Personas · Tema 7 - talento y desarrollo de carrera

Fuente: clase de Dirección de Personas

[pág. 1]
TEMA 7: GESTIÓN DE
TALENTO Y CARRERA
 DIRECCIÓN DE PERSONAS
 Julio 2013
 Escuela de Administración
 Alejandra Mehech C.

[pág. 2]
Planes de Carrera
 ¿Cómo se relaciona
 con las otras
funciones del ciclo de
 Recursos Humanos?

[pág. 3]
El papel de RRHH
 PASO 1: PASO 2:
----------------------------------- -----------------------------------
 Hacer coincidir necesidades Oportunidades y requerimientos
----------------------------------- -----------------------------------
• Generar contexto de apoyo • Identificar las necesidades de
• Comunicar la dirección de la competencias futuras
 • Establecer las progresiones del
 empresa
 puesto y las rutas de carrera
• Establecimiento mutuo de metas • Equilibrar promociones,
 y planeación transferencias, salidas
 • Establecer rutas de carrera duales
 PASO 3:
 PASO 4: -----------------------------------
----------------------------------- Calibrar el potencial
Iniciativas de desarrollo de carrera -----------------------------------
----------------------------------- • Medir competencias (evaluaciones)
• Proporcionar counseling de carrera • Establecer inventarios de talento
• Proporcionar capacitación para la • Establecer planes de sucesión
 autoadministración de carrera • Utilizar centros de evaluación
• Proporcionar retroalimentación del (assesment centers)
 desarrollo

[pág. 4]
Planes de Carrera
 ¿Quién es el
 que debe
 preocuparse
 de la carrera
 profesional?
La meta: hacer coincidir las
 necesidades individuales con
 las de la organización

[pág. 5]
Planes de Carrera:
la función del empleado
 Iniciar y administrar
 su propia carrera

[pág. 6]
Planes de Carrera:
 la función del empleado
Capacidades Intereses
Conocimientos
 Valores Habilidades
…debe activamente buscar su camino

[pág. 7]
Planes de Carrera:
la función de la empresa
 Generar un contexto
 favorable para el
 desarrollo de carrera

[pág. 8]
Planes de Carrera:
 la función de la empresa
Política de Oportunidades
desarrollo
Información Apoyo
Retroalimentación
 …debe estar en las metas, cultura y
 filosofía de RRHH de la empresa

[pág. 9]
Planes de carrera
Iniciativa individual Contexto empresa
 Desarrollo profesional

[pág. 10]
Oportunidades y requerimientos de carrera
• Análisis de competencias
• Identificación de progresiones laborales y rutas
 de carrera
• Reconocer diferentes rutas de carrera
 (promoción, transferencia, democión, salida)

[pág. 11]
Oportunidades y requerimientos de carrera
 ¿Mérito?
 Principio de
Promoción ¿Antigüedad?
 Peter
 ¿Potencial?
 Promoción hasta el
A otras áreas: nivel de
 ¿desarrollo o incompetencia
 deslealtad?
 Asegurar Servicio de
 Salida
 empleabilidad Outplacement

[pág. 12]
Oportunidades y requerimientos de carrera
• Rutas de carreras duales: ¿por qué?
• ¿Especialista o generalista?
• ¿En una empresa o en varias?

[pág. 13]
Etapas de carrera
Etapa 5: final de la carrera (de los 55 años a la jubilación)
Seguir siendo productivo en el trabajo, conservar la autoestima, prepararse
para el retiro efectivo
Etapa 4: mitad de la carrera (de los 40 a los 55 años)
Reconsiderar las metas del inicio de carrera y del principio de la edad adulta.
Reafirmar o modificar metas, tomar decisiones apropiadas para la edad adulta.
Seguir siendo productivos
Etapa 3: Inicio de carrera (de los 25 a los 40 años)
Aprender el puesto, reglas y normas de la organización. Adaptarse a la
ocupación y organización elegida y a su cultura, aumentar competencias
personales, perseguir las metas
Etapa 2: ingreso a la organización (de los 18 a los 25)
Obtener oferta(s) de trabajo de organizaciones deseadas, seleccionar el puesto
apropiado basándose en información completa y precisa, experimentar y
arriesgarse
Etapa 1: preparación para el trabajo (de los 0 a los 25 años)
Desarrollar una autoimagen, evaluar ocupaciones alternativas, desarrollar una
opción ocupacional inicial, obtener educación necesaria, desarrollar habilidades
básicas

[pág. 14]
Trampa de la Meseta
• Estructural: marca el fin de las promociones
• De contenido: aburrimiento por trabajo rutinario
• De vida: pérdida de identidad y autoestima cuando no
 hay avances en su carrera / ”vida”

[pág. 15]
Cómo ayudar al desarrollo de carrera
• Informar con claridad las expectativas respecto a los
 empleados para que sepan qué se espera de ellos durante su
 carrera en la organización
• Dar a los empleados la oportunidad de ser transferidos a
 otras áreas/oficinas
• Proporcionar a los empleados un plan de sucesión claro y
 minucioso
• Fomentar el desempeño por medio de recompensas y
 reconocimientos
• Dar a los empleados el tiempo y los recursos que necesiten
 para considerar las metas de carrera a corto y a largo plazo
• Animar a los empleados a valorar de manera continua sus
 habilidades y dirección de carrera

[pág. 16]
Cómo ayudar al desarrollo de
 carrera desde RRHH
• Talleres / formación (en desarrollo de carrera)
• Counseling de carrera
• Mentoring
• Trabajo en red o networking

[pág. 17]
Cómo ayudar al desarrollo de
 carrera desde RRHH
• Programas de jóvenes
• Techo de cristal (avance de las mujeres)
• Políticas de conciliación / corresponsabilidad / inclusión
• Sesgos inconscientes

[pág. 18]
Funciones del Mentoring
 Los buenos mentores Los buenos mentees
----------------------------- ---------------------------
• Escuchan y comprenden • Escuchan
• Retan y estimulan el • Actúan tomando en
 aprendizaje cuenta los consejos
• Preparan • Muestran compromiso
• Aumentan la confianza Mentoring para aprender
 en uno mismo de éxito • Dejan el ego a un lado
• Proporcionan consejos • Piden retroalimentación
 sabios • Son de mente abierta
• Enseñan con ejemplos • Están dispuestos a
• Actúan como modelos a cambiar
 seguir • Son proactivos
• Comparten experiencias
• Ofrecen estímulos

[pág. 19]
Desarrollo de carrera personal
• Elección de una carrera (aprovechar el período formativo)
• Autoevaluación / autoconocimiento
• Desarrollo de competencias y habilidades personales
• Elección de la empresa
• Convertirse en emprendedor
• Mantener una carrera en perspectiva: intereses fuera del
 trabajo, balance trabajo/familia, planeación del retiro

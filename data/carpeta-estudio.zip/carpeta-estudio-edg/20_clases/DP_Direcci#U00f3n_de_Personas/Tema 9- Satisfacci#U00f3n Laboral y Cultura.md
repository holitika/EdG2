# Dirección de Personas · Tema 9- Satisfacción Laboral y Cultura

Fuente: clase de Dirección de Personas

[pág. 1]
TEMA 9: CLIMA
ORGANIZACIONAL Y
 OTROS
 DIRECCIÓN DE PERSONAS
 Julio 2013
 Escuela de Administración
 Alejandra Mehech C.

[pág. 2]
Clima Organizacional
Características Motivación de los
 Clima
 del sistema miembros de la Comportamiento
 Organizacional Organización
Organizacional
▪ Expresión personal de la ▪ Cualidad o propiedad del
 “percepción” que los ambiente organizacional, que
 trabajadores y directivos se perciben o experimentan los
 forman de la organización a miembros de la organización,
 la que pertenecen y que y que influyen en su
 incide directamente en el comportamiento
 desempeño de la
 organización

[pág. 3]
Clima Organizacional
El comportamiento de un miembro de la organización no
solo es el resultado de los factores organizacionales
existentes, sino que depende de las percepciones que tenga
el trabajador de cada uno de estos factores
 Clima positivo: logro, afiliación, poder, productividad,
 baja rotación, satisfacción, adaptación,
 innovación, etc…
 Clima negativo: inadaptación, alta rotación, ausentismo,
 poca innovación, baja productividad, etc…

[pág. 4]
Claridad Orientación
 Remuneración
 estratégica al
 e
 incentivos servicio
 Condiciones Orientación
 de a
 trabajo Dimensiones resultados
 del Clima
Crecimiento
 Organizacional
 Estilo de
 y liderazgo
 desarrollo
 Pertenencia
 y Trabajo
 compromiso en equipo
 Comunicación

[pág. 5]
Grupo Santander 2012
Aumento Porcentual de 1,86% (+)

[pág. 6]
Grupo Santander 2012
 Resultados por Dimensión

[pág. 7]
Dimensiones Mejor y Peor
 Evaluadas

[pág. 8]
Grupo Santander
 Alzas y Bajas mas importante por pregunta
Alzas
Bajas

[pág. 9]
Great Place to Work
“Un gran lugar para trabajar es aquel en el que
uno confía en las personas para las que trabaja,
está orgulloso de lo que hace y disfruta de las
personas con las que trabaja” — Robert
Levering, co-fundador, Great Place to Work®

[pág. 10]
Great Place to Work:
la visión del empleado

[pág. 11]
Engagement
▪ Engagement es una medida del compromiso
 emocional de los empleados con su trabajo y con los
 objetivos de su empresa lo que los lleva a estar
 dispuestos a realizar un esfuerzo adicional en su
 trabajo
▪ Engagement no es lo mismo que satisfacción ni
 felicidad laboral
▪ Hacer cambios para mejorar la satisfacción de los
 empleados no necesariamente llevará a que mejoren
 los resultados de la organización

[pág. 12]
Engagement

[pág. 13]
Engagement
 Resultados Santander Chile
 Comparativa
 Porcentaje respuestas favorables
 HP SF País
 Dimensiones
 Compromiso 12 9 18 7
 Apoyo
 12 5 10 0 Autoridad y empowerment 75 8
 Organizativo
 Claridad directiva 84 8
 Preguntas más valoradas % fav.
 Colaboración 73 9
 La empresa espera un alto nivel de desempeño de sus empleados 95
 Sé cuáles son los resultados que se esperan de mí en mi trabajo 91 Compensación y beneficios 63 9
 Se me trata con respeto como persona 91
 Confianza en la dirección 79 11
 Comprendo bien la estrategia y los objetivos de la empresa 90
 Si un cliente tiene una reclamación o queja, hacemos todo lo Formación 60 8
 90
 posible por satisfacerle
 Gestión del desempeño 76 8
 Preguntas menos valoradas % fav.
 Oportunidades de desarrollo 70 10
 Considero que se me paga de manera justa por el trabajo que
 50
 realizo Orientación al cliente 81 7
 Entiendo que mi retribución es justa considerando la retribución
 de otras personas que realizan un trabajo similar al mío en otras 54 Recursos 74 13
 empresas
 Mi trabajo me deja el tiempo necesario para aprovechar las
 54 Respeto y reconocimiento 77 12
 oportunidades de formación relacionadas con mi puesto
 Los empleados nuevos reciben la formación necesaria para hacer
 54 Trabajo, estructura y procesos 76 14
 bien su trabajo
 La empresa retiene a los empleados con talento 57 Porcentaje respuestas favorables
 Diferencia en p.p. de Santander Chile Vs. Grupo Santander
 (HP) Diferencia en p.p. de Santander Chile Vs. Norma de Alto Desempeño Resultados Santander Chile 2014
 (SF) Diferencia en p.p. de Santander Chile Vs. Norma de Sector Financiero
(País) Diferencia en p.p. de Santander Chile Vs. Norma País

[pág. 14]
Felicidad Organizacional
▪ Felicidad organizacional es la capacidad de la
 organización para coordinar recursos y gestión para
 hacer una oferta de valor para los trabajadores que
 balancee la salud financiera de la compañía y el
 bienestar psicosocial de los trabajadores
▪ Felicidad en el trabajo es la percepción personal y
 subjetiva de los trabajadores acerca de su bienestar,
 florecimiento y salud en el trabajo
▪ Felicidad organizacional implica gestionar tres focos:
 condiciones de trabajo, procesos operacionales y gestión
 de personas

[pág. 15]
CULTURA
ORGANIZACIONAL

[pág. 16]
¿Qué es la Cultura
 Organizacional?
• Un sistema de significados compartidos por
 los miembros de la organización
• Los valores culturales son creencias
 compartidas, supuestos y sentimientos acerca
 de los que es bueno, normal, racional,
 valorable, etc…

[pág. 17]
La función general de la
 Cultura
La cultura es el “pegamento
 social” que ayuda a
mantener a una organización
unida, proveyendo estándares
 apropiados respecto de lo
 que los empleados pueden o
 no pueden decir o hacer

[pág. 18]
Funciones de la Cultura en
 una empresa
 1. Define fronteras
 2.Transmite un sentido de
 identidad
 3.Compromiso con algo +
 grande que el interés
 personal
 4.Incrementa la estabilidad del
 sistema social (organización)
 5.Sirve como mecanismo de
 control que moldea
 actitudes y comportamiento

[pág. 20]
Elementos de la Cultura Organizacional
 Artefactos
 • Historias/leyendas
 • Rituales/ceremonias Visible
 • Lenguaje organizacional
 • Estructuras físicas/decoración
 Valores compartidos
 • Creencias conscientes
 • Evalúa lo que es bueno o malo,
 correcto o incorrecto
 Invisible
 (bajo la superficie)
 Supuestos compartidos
 • Creencias o percepciones
 inconscientes,
 • Modelos mentales o ideales

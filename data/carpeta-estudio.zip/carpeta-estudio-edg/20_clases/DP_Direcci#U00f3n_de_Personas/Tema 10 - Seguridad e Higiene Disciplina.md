# Dirección de Personas · Tema 10 - Seguridad e Higiene Disciplina

Fuente: clase de Dirección de Personas

[pág. 1]
TEMA 10: SEGURIDAD E
HIGIENE EN EL TRABAJO
 DIRECCIÓN DE PERSONAS
 Julio 2013
 Escuela de Administración
 Alejandra Mehech C.

[pág. 2]
Higiene y Seguridad
 ¿Por qué nos
debemos preocupar
 como empresa de
 este tema?
 ¿Qué pasa si no
 lo hacemos?

[pág. 3]
Higiene y Seguridad
Los accidentes laborales y las
enfermedades profesionales son costosas
para los empleados y para la empresa

[pág. 4]
Costos
• Motivación
• Productividad
• Ausentismo
• Costos directos de atención médica
• Incidencia en primas (mutuales de seguridad)
• Indemnizaciones / demandas
• Reputación corporativa

[pág. 5]
¿De qué hay que preocuparse?
• Accidentes laborales
• Enfermedades profesionales
• Enfermedades comunes
• Asaltos / Robos
• Acoso laboral / sexual
• Equipos de manejo de crisis

[pág. 6]
Algunas Leyes
• Ley N° 16.744 aprueba seguro social contra riesgos de accidentes del
 trabajo y enfermedades profesionales
• Código del Trabajo, artículo 153, de la formulación del Reglamento Interno
 de Orden, Higiene y Seguridad
• Ley 20.005 tipifica y sanciona el acoso sexual
• Ley 20.607 tipifica y sanciona el acoso laboral
• Ley N° 20.123 regula el trabajo en régimen de subcontratación, el
 funcionamiento de las empresas de servicios transitorios y el contrato de
 trabajo de servicios transitorios
• Resolución exenta 1448, Ministerio de Salud, Protocolo de vigilancia de
 riesgos Psicosociales en el trabajo (CEAL-SM/Suseso)
• Ley 21.643 tipifica y sanciona la violencia en el trabajo (Ley Karin)

[pág. 7]
Reglamento interno y su
uso…un ejemplo
https://consejominero.cl/wp-
content/uploads/2024/10/RIOHS-CM-logo-act.pdf

[pág. 8]
¿Es sólo un problema legal?
Fundamentalmente es un tema
de sensibilidad por las personas

[pág. 9]
Creación de un ambiente
 seguro de trabajo
• Promoción de la conciencia de seguridad
• Rol de los supervisores: inducción, capacitación,
 reforzamiento
• Capacitación: primeros auxilios, uso de extintores,
 conducción defensiva, procedimientos de emergencia,
 etc…
• Aplicación de normas: leyes, normativas, sanciones,
 multas, despidos, etc…
• Investigación y registro de accidentes
 Objetivo: proteger al trabajador de daños físicos,
 condiciones insalubres y actos inseguros

[pág. 10]
Mutuales

[pág. 11]
Evolución tasa de Accidentabilidad
 Tasa de accidentes del trabajo: número de accidentes por cada 100 trabajadores
 Días perdidos: número total de días perdidos / total de accidentes

[pág. 12]
Accidentabilidad por Actividad Económica
Actividades Económicas 2022 2023 Variación Días perdidos 2023
Industrias Manufactureras 4,0 3,8 -5% 19,8
Transporte 3,5 3,3 -5,71% 23,8
Agricultura y Pesca 3,6 3,5 -2,78% 21,5
Construcción 3,6 3,1 -13,89% 20,8
Comercio 2,8 2,6 -7,14% 16,6
Tasa promedio nacional 2,8 2,6 -7,14% 18,3
Servicios 2,0 2,0 0% 13,2
Electricidad, agua, gas 1,3 1,4 7,69% 19,1
Minería 1,0 0,9 -10% 32,4

[pág. 13]
Temas relacionados
 • Comidas / casinos
 • Programa de Salud / bienestar /
 exámenes médicos
 • Programa de orientación / ayuda al
 empleado
 • Programa de control de adicciones
 • Ergonomía en el trabajo

[pág. 14]
TEMA 10: DISCIPLINA
 LABORAL
 DIRECCIÓN DE PERSONAS
 Escuela de Administración
 Julio 2013
 Alejandra Mehech C.

[pág. 15]
Antes Ahora
• Sueldos • Disciplina justa
• Salud y • Privacidad
 seguridad
 • Diversidad e
• Pago por horas inclusión
 extras
 • Derechos de los
 empleados
 • Conducta fuera
 del trabajo

[pág. 16]
Derechos de los empleados
• De protección del trabajo
• Despido injustificado
• Denuncia de una situación ilegal en la empresa
• Protección contra el acoso laboral y la
 violencia en el trabajo
• Privacidad
• Deshaucio por parte del empleado

[pág. 17]
Derecho de privacidad
• Monitoreo de empleados (filmaciones
 y conversaciones telefónicas)
• Correos electrónicos
• Pruebas de consumo de drogas
• Conductas fuera de la empresa
• Romances en el lugar de trabajo
• Arte corporal, aseo y vestimenta

[pág. 18]
Problemas disciplinarios
 Asistencia Desempeño en el trabajo
• Ausentismo • No concluir asignaciones de trabajo
 injustificado • Elaborar productos o servicios de calidad inferior
• Ausentismo crónico • Incapacidad para cumplir con los requisitos de
• Impuntualidad productividad establecidos
 injustificada
 /excesiva Problemas de conducta en el trabajo
• Retirarse sin
 permiso • Intimidación o bullying • No reportar lesiones
 • Intoxicación en el trabajo • Descuido
 Deshonestidad y • Insubordinación
 • Dormir en el trabajo
 relacionados • Juegos violentos /
 • Utilizar un idioma abusivo
• Robo payasadas
 o amenazador
• Falsificar documentos de • Fumar en lugares no
 la empresa autorizados • Posesión de narcóticos o
 • Peleas alcohol en la empresa
• Dañar de manera
 intencional propiedad de • Apuestas • Posesión de armas de
 la empresa fuego y otro tipo de
 • No usar los elementos
• Compartir información de protección personal armas en la empresa
 privada de la empresa (epp) • Acoso sexual

[pág. 19]
Un modelo disciplinario
 Política Definición de Violación de las Investigación de
disciplinaria de disciplina normas de la la ofensa del
la organización organización empleado
 Entrevista Disciplina
 disciplinaria progresiva Proceso debido Causa justa Despido
 El debido proceso
 • Rol de los códigos de
 conducta: establecimiento de
 las normas de actuación
 • Necesidad de investigar y
 documentar

[pág. 20]
Alternativas de solución
• Líneas de denuncia
• Comité de “quejas” (sistema de
 revisión de los colegas)
• Ombudsman
• Mediación
• Arbitraje

# Fundamentos de Marketing · Clase n5 Conducta del consumidor y shopper V23

Fuente: clase de Fundamentos de Marketing

[pág. 1]
Conducta del
Consumidor
 FRANCISCO ROCCA

[pág. 2]
Definición
 La conducta del
 consumidor se refiere
 al estudio de los
 procesos y
comportamientos ,que
 utilizan los
 consumidores para
 elegir los productos y
 servicios incluyendo
 sus respuestas
emocionales, mentales
 y conductuales.
 FRANCISCO ROCCA

[pág. 3]
¿Cuál es el objetivo de entender la conducta de los
consumidores’
 Optimizar el valor de cada cliente
 mediante una estrategia de
 centralidad en el cliente y en su
 experiencia con la marca para
 captar, mantener y desarrollar
 clientes rentables.
 FRANCISCO ROCCA

[pág. 4]
¡Consumir es una conducta!
 ACTITUDES
 ACTITUDES MOTIVACIONES
 PERCEPCIONES INFLUENCIA CULTURAL
 INFLUENCIA
 “INFLUENCERS” CULTURAL
 INFLUENCIA SOCIAL
 INFLUENCIA
 MEMORIA Y APRENDIZAJE
 “INFLUENCERS” SOCIAL
 FRANCISCO ROCCA

[pág. 5]
Facetas del consumidor
 01 CONSUMIDOR. CONSUMER
 MARKETING
 SHOPPER
 02 COMPRADOR.
 MARKETING
 INDUSTRIAL
 CONSUMIDOR MARKETING
 03 INDUSTRIAL.
 FRANCISCO ROCCA

[pág. 6]
¿Los consumidores somos
 racionales?
 FRANCISCO ROCCA

[pág. 7]
FRANCISCO ROCCA

[pág. 8]
Racionalidad del consumidor
En la práctica…. El proceso de decisión de los
• Nos cambiamos de marca aun consumidores
 cuando la que usamos satisface • Es tanto emocional como racional
 nuestras necesidades • No se acuerda de todo
• El proceso de selección de un • Toma atajos
 producto es relativamente
 automático • No está siempre motivado
• Nuestra conducta está afectada por • Es sensible a los efectos del medio.
 el razonamiento lógico y las
 emociones
• El sistema emocional es la primera
 fuerza que actúa sobre nuestros
 procesos mentales y conducta
 FRANCISCO ROCCA

[pág. 9]
Toma de Decisiones del Consumidor.
 • Decisiones Racionales/Cognitivas.
 (Intrínsecos)
 • Decisiones Emocionales.
 (Extrínsecos)
 FRANCISCO ROCCA

[pág. 10]
Factores más frecuentes que afectan el
comportamiento
 1 2 3 4 5
 EMPRESA
 CULTURA SOCIAL PERSONAL PSICOLOGICO MARCAS

[pág. 11]
Aspectos Culturales
• Depende de los valores comunes
 respecto a temas tales como:
 • Ahorro, Éxito Social, ser moderno, la
 igualdad de los sexos y sus roles, el rol de
 la familia, la disposición al trabajo, el
 consumo de bienes, la definición de
 calidad de vida, lujo vs austeridad
 • Aspectos éticos, concepción generalizada
 de lo bueno y lo malo, valores religiosos
 • Interpretación de las Comunicaciones y
 sus códigos culturales
 FRANCISCO ROCCA

[pág. 12]
Aspectos Sociales del Entorno
• Grupos de Referencia
 • La Familia, Los amigos, el círculo directo,
 sus amigos en Facebook, etc.
 (colegas, vecinos, socios, compatriotas)
 • Auto clasificación y los patrones de
 consumo
• Grupos aspiracionales
 • Rol de los testimoniales y Líderes de
 opinión
 • Ej. influencers
 • Rol del Estilo de Vida
• Grupos Socio-económicos
 • ¿Qué son?¿Cómo se llega a ellos?¿es
 relevante?
 FRANCISCO ROCCA

[pág. 13]
Factores Psicológicos : Personalidad
Apertura a experiencias
(inventivo/curioso vs.
 consistente/cauto).
Nivel de conciencia
(eficiente/organizado vs.
 relajado/descuidado)
Extraversión
(energético vs. solitario/reservado).
Agradable
(amistoso/apasionado vs.
 frío/distante).
Neurótico
(sensible/nervioso vs.
 seguro/confiado)
 FRANCISCO ROCCA

[pág. 14]
Factores Psicológicos :Motivación
• MOTIVACION
 • ¿Cuál es la razón que nos hace
 actuar de cierta forma?
 • Maslow jerarquizó las
 necesidades del ser humano:
 • Autorrealización (autodesarrollo y
 realización
 • Estima (aceptación, status)
 • Sociales (pertenencia, amor)
 • Seguridad (seguridad, protección)
 • Fisiológicas (hambre, sed)
 FRANCISCO ROCCA

[pág. 15]
Factores Psicológicos: Percepción
 FRANCISCO ROCCA

[pág. 16]
El proceso de reconocimiento de necesidades
 Estilo de Vida Deseado Situación Actual
 La forma en que el consumidor. Factores temporales afectando
 le gustaría vivir y sentir al consumidor
 Estado Deseado: Estado Actual
 Condición en que le gustaría Condición en la que se percibe
 estar a esta altura del T° estar
 NATURALEZA DE LA DISCREPANCIA
 Sin Diferencia Estado Deseado Estado actual peor
 mejor que actual al deseado
 SATISFACCION - no acción PROBLEMA
 FRANCISCO ROCCA
 RECONOCIDO

[pág. 17]
Proceso de Toma de Decisiones
Fuerzas Sociales y de Grupo Factores Psicológicos
• Cultura - Subcultura • Motivación- Percepción
• Clases Sociales • Aprendizaje
• Grupos de Referencia • Personalidad - Actitud
 Familia
 Proceso de Decisión de Compra
 Reconocimiento
 Búsqueda de Identificación Evaluación de Decisión de Comportamien
 de necesidad o
 deseo.
 información de Alternativas las Alternativas Compra to Post-Compra
 Información Factores Situacionales
• Fuentes Comerciales • Cuando y donde
• Fuentes Sociales compran?
• Redes Sociales FRANCISCO ROCCA • Por que Compran?

[pág. 18]
FRANCISCO ROCCA

[pág. 19]
Aspectos Conceptuales de la Conducta de Compra
Teoría económica del consumo Teoría del aprendizaje del consumo
• Se analizan las alternativas en • Los consumidores prefieren
 función de su ecuación de Valor. aquellos productos que ya
• Se busca maximizar la inversión conocen y que le han dado
 y la utilidad. buenos resultados, o aquellos
 productos que conocieron
• Supone análisis exhaustivo y tempranamente.
 racional de atributos.
• La satisfacción depende del
 beneficio utilitario
 FRANCISCO ROCCA

[pág. 20]
Aspectos Conceptuales de la Conducta de Compra
Teoría psicoanalítica del consumo Teoría Sociológica del consumo
• Los consumidores prefieren • Los consumidores prefieren
 aquellos productos que aquellos productos que cumplen
 satisfacen sus impulsos con las expectativas sociales y le
 primarios. permite la mejor adaptación al
 grupo, (quedar bien)
 FRANCISCO ROCCA

[pág. 21]
Tipos de decisiones
 FRANCISCO ROCCA

[pág. 22]
Tipos de decisiones que tenemos los consumidores
Decisiones de alta participación/ Decisiones de baja
involucramiento participación/involucramiento
• Son las decisiones de compra que • Son compras que se perciben con
 hay una gran planificación y toman un bajo riesgo y bajo precio.
 mucho tiempo. • No requieren de mucho esfuerzo
• La toma de decisiones puede ser en el análisis .
 muy difícil. • Son bastante rápidas.
• Normalmente son compras de alto • Son compras de rutina.
 valor , de riesgo de tomar una mala
 decisión y la incertidumbre de cuál
 es la mejor alternativa.
 FRANCISCO ROCCA

[pág. 23]
Tipos de decisiones que tenemos los consumidores
Decisiones de Compra Compensatorias Decisiones de Compra No Compensatorias
• Es cuando el consumidor frente • Es cuando la evaluación positiva
 a las debilidades de un producto de una marca no compensa la
 o marca compensa con una evaluación negativa de la misma
 fortaleza del producto. marca en otro atributo.
 FRANCISCO ROCCA

[pág. 24]
Tipos de decisiones que tenemos los consumidores
Decisiones de compra influenciadas
por las empresas
• Innovación en Productos y Servicios.
• Proliferación de Marcas/ Test Market.
• MUS$ en comunicaciones masivas.
• Innovación en formatos de
 distribución y servicios.
• Malls, Cadenas, Catálogos,
 Telemarketing, On Line.
• Medios segmentados.
• Las redes Sociales.
 FRANCISCO ROCCA

[pág. 25]
Customer Journey Map
 (Ruta del cliente)
• Es una herramienta que grafica el viaje
 del cliente, el que comienza con la
 necesidad del cliente y termina cuando
 esta, está satisfecha.
• Permite identificar problemas o
 necesidades de los consumidores en las
 distintas etapas de la experiencia con la
 marca y definir oportunidades de
 mejora
FRANCISCO ROCCA

[pág. 26]
La ruta del cliente (modelo AIDA)
 Diferencia percibida entre Elegir el cuándo, dónde,
 Evaluar o juzgar distintas
 lo deseado y el estado qué y cuál.
 alternativas según
 actual, Reconocimiento de
 percepciones y resultados
 necesidades y metas.
 o consecuencias
 esperados.
Reconocimiento del Búsqueda de Evaluación de Uso post-compra y
 Decisión de elección Proceso de compra
problema información alternativas evaluación
 Combinación de la
 Buscar información información y elección. Experiencia de uso,
 relevante del entorno o ¿Qué criterios uso? evaluación de las
 activo conocimiento desde expectativas versus
 la memoria. percepción. Decisión de
 recompra o de abandono.
 FRANCISCO ROCCA

[pág. 27]
FRANCISCO ROCCA

[pág. 28]
A lo largo de la ruta del cliente, tenemos distintos “touch
points” con el cliente, con un mix de canales offline y online.
 FRANCISCO ROCCA

[pág. 29]
Circular Journey Map de Mckinsey
 2. El consumidor agrega o elimina marcas a
 Este enfoque, reconoce que el proceso no es
 medida que va evaluando éstas como quiera.
 lineal como lo representan los modelos (Shopping y búsqueda de información)
 tradicionales, sino que el proceso de decisión de
 compra es más sofisticado y menos lineal.
1. El consumidor considera un set
inicial de marcas, basado en sus 3. Finalmente, el consumidor
propias percepciones y exposición a 5. Luego de la primera
 selecciona a una marca al momento de
puntos de contacto recientes. experiencia, los clientes
 comprar.
 vuelven.
 4. Luego de adquirir un producto o servicio el
 consumidor arma expectativas basadas en
 experiencias que afectarán la siguiente compra.
 (exposición real al producto o servicio)
 FRANCISCO ROCCA

[pág. 30]
Análisis del viaje del cliente (Journey Map)
 ESTÍMULO
 Ayude a los clientes
 RECOMENDAR a obtener respuestas
 a sus preguntas.
 Premie a los
 consumidores leales.
 Hágalos sentir
 importantes.
 BÚSQUEDA
 Ayude a los
 consumidores a
 encontrarlo.
 USO
 Ayude a los
 consumidores a usar
 el producto servicio
 COMPRA
 Ayude a los
 consumidores a
 comprar su producto
 FRANCISCO ROCCA

[pág. 31]
ENTREGA DE LA ACEPTACIÓN DE
 VISITA DEL PROCESO DEL POST-VENTA
 Etapas CREACION CLIENTE PROPUESTA LA PROPUESTA DESPACHO ENTREGA RECAUDACION
 VENDEDOR PEDIDO Y/O GARANTIAS
 COMERCIAL COMERCIAL
 PAGO
 LLENADO DE LA ANALISIS DE LA CLIENTE
 RECIBIR LA DEFINICIÓN DEL MEDIANTE
 Acciones del RECIBIR AL FICHA Y ENVIO DE LA PROPUESTA Y RECEPCIÓN DEL INFORMA
 PROPUESTA Y TRANSPORTE A TRANSFERENCIA
 cliente VENDEDOR INFORMACIÓN ACEPTACIÓN DE TRANSPORTE PROBLEMA CON
 REVISARLA UTILIZAR , TARJETA O
 SOLICITADA LA MISMA PRODUCTO
 CHEQUES
F
r X X X X
o Emoción del
 X X X X
n cliente
t X X
s PRESENCIAL O PRESENCIAL O
 PRESENCIAL O POR PRESENCIAL O
t Puntos de PRESENCIAL DEL CORREO CORREO CORREO
 CORREO POR CORREO
a contacto VENDEDOR ELECTRONICO ELECTRONICO O ELECTRONICO O
 ELECTRÓNICO ELECTRÓNICO
g LLAMADO LLAMADO
e
 RECIBIR LA ENTRAGAR LA SOLICITAR INGRESO DEL RECIBE
 PRESENTARSE, RETIRO DE
 Acciones del INFORMACIÓN Y PROPUESTA DE INFORMACIÓN PEDIDO AL RECLAMO Y
 PREGUNTAR, SEGUIMIENTO SEGUIMIENTO CHEQUES Y
 personal interno ENVIARLA AL ÁREA ACUERDO A LO NECESARIA PARA CATALOGO 2.0 O CANALIZA CON
 DETECTAR DEL DESPACHO DEL DESPACHO SEGUIMIENTO
 front DE CUENTAS SOLICITADO O LA CREACIÓN DEL ENVIO A ASIST. ÁREA
 NECESIDADES DE PAGOS
 CORRIENTES DETECTADO CLIENTE COMERCIAL ENCARGADA
 DIGITACION Y INGRESO DEL
 Acciones del CREACIÓN DEL APROBACIÓN PAGO EN AS400 REVISIÓN DEL
 PREPARACIÓN Y DESPACHO DE
B personal interno CLIENTE Y ANÁLISIS PRECIO PARA REBAJA DE RECLAMO Y
 FACTURACIÓN LA MERCADERIA
a back DE CRÉDITO APROBACIÓN CUENTA DIGNOSTICO
c CRÉDITO CORRIENTE
k PROCESO DE
 CATALOGO Y LISTA CREACIÓN DE DIGITACIOÓN DEL PROCESO INGRESO DE
 ANALISIS DE
 DE PRECIOS CLIENTE PEDIDO LOGÍSTICO PAGOS
s GARANTÍA
t CARTA DE GENERACIÓN DE
 Procesos de ANÁLISIS DE
a PRESENTACIÓN Y APROBACIONES NOTA DE
 soporte CRÉDITO
g PPT DIGITAL CRÉDITO
e
 FICHAS DE
 PRODUCTOS
 REVISION DE
 PROGRAMA DE
 POLITICA EVITAR LA
 MERCHANDISING
 COMERCIAL O DIGITACIÓN DE
 O MEJORAR Y AGILIZAR
 Oportunidades "ENGANCHE" PARA PEDIDOS POR
 ENTRENAMIENTO LA CREACIÓN DE
 de mejora QUE VENDEDOR PARTE DE
 EN ROMPER EL CLIENTES
 PUEDA CERRAR ASISTENTES
 HIELO CON
 SOLO Y MOTIVAR EL COMERCIALES
 NUEVOS CLIENTES
 CIERRE FRANCISCO ROCCA

[pág. 32]
FRANCISCO ROCCA

[pág. 33]
Caso Nike
 10 minutos
 FRANCISCO ROCCA

[pág. 34]
Que vimos en el día de hoy
• El estudio de la conducta del consumidor nos sirve para entender los
 procesos que utilizamos los consumidores para tomar nuestras decisiones
 de compra.
• Los consumidores el mayor tiempo somo irracionales para la toma de
 decisiones.
• Son muchos los factores que afectan nuestros comportamientos de
 compras.
• Tenemos diferentes tipos de decisión es que estamos enfrentando todos
 los días.
• El customer journey es una aproximación más sofisticada del proceso de
 decisión de los clientes, con implicancias clave en la estrategia de
 marketing
 FRANCISCO ROCCA

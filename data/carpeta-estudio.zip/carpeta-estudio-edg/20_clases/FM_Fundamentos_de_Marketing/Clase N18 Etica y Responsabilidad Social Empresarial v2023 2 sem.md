# Fundamentos de Marketing · Clase N18 Etica y Responsabilidad Social Empresarial v2023 2 sem

Fuente: clase de Fundamentos de Marketing

[pág. 1]
Prof Francisco Rocca

[pág. 2]
Prof Francisco Rocca

[pág. 3]
Historia de la Ética
“Hay malas personas , El fin último del hombre
no malas práctica”. es la felicidad.
 Aristóteles Siglo IV ac
 Prof Francisco Rocca

[pág. 4]
Historia de la Ética
“El bien es lo que se El fin último del hombre es
debe hacer y perseguir y la felicidad cumplir el plan
el mal evitar” de dios
 Santo Tomás de Aquino Siglo XIII
 Prof Francisco Rocca

[pág. 5]
La Historia de la Ética
“Deber moral como “Cumplimiento del
fundamento de la deber moral → Ética
razón” de los deberes.
 Immanuel Kants Siglo XVIII
 Prof Francisco Rocca

[pág. 6]
”Una cosa es buena cuando tiende a preservar la
integridad, estabilidad y belleza de la comunidad
ecológica. Es mala cuando tiende a lo contrario.”
 Aldo Leopold Siglo XX
 Prof Francisco Rocca

[pág. 7]
Definición
• La ética se refiere a los principios y normas que rigen el
 comportamiento humano, y busca establecer lo que es
 considerado moralmente correcto o incorrecto.
• La ética es una disciplina filosófica que busca proporcionar
 fundamentos racionales para la toma de decisiones éticas.
 Prof Francisco Rocca

[pág. 8]
La Moral
• La moral, se refiere a las normas y valores que rigen el comportamiento de
 un individuo o un grupo en particular.
• La moral es una guía interna de cada persona que dicta lo que es correcto
 o incorrecto.
• La Moral es el conjunto de principios, criterios, normas y valores que
 dirigen nuestro comportamiento.Prof Francisco Rocca

[pág. 9]
¿Qué Es La Ética En Los Negocios?
Es el correcto comportamiento de todos
los miembros de una Organización
 Prof Francisco Rocca

[pág. 10]
“La economía necesita ética para
funcionar correctamente. Pero no
 una ética cualquiera sino una
 centrada en la persona, que sea
 capaz de ofrecer un futuro a las
 nuevas generaciones”.
 Arz. Dominique Mamberti Ministro de Exteriores, Vaticano
 Prof Francisco Rocca

[pág. 11]
¿Qué es la ética en las decisiones
 empresariales?
 Responsabilidad es la
“La ética es un elemento capacidad de responder
intrínseco de las decisiones por las propias decisiones.
y de las acciones en razón a
la responsabilidad y la Las decisiones
moralidad de la toma de empresariales y sus
decisiones”. acciones conllevan
 moralidad es decir son
 buenas o malas en cuanto
 si dañan o no a las
 personas
 Prof Francisco Rocca
 Fuente: Ética en la dirección de empresas de Domenec Mele.

[pág. 12]
Como debe ser la ética en las empresas
• Prácticas Organizativas
 – Las prácticas organizativas son los medios que las empresas utilizan para el
 logro de sus objetivos y la dimensión ética tiene que estar presente en
 ellas.
• Carácter moral de sus ejecutivos.
 – Honestidad , diligencia , preocupación por las personas, sentido de
 servicio.
• Liderazgo Ético.
 – Ya que el liderazgo es la capacidad de influir sobre sobre otros, el
 comportamiento ético es clave en esta dimensión.
¡¡El comportamiento ético está en el núcleo del liderazgo!!
 Prof Francisco Rocca

[pág. 13]
¿Existe un área gris en la ética de los negocios?
 Prof Francisco Rocca

[pág. 14]
El Espíritu De Una Decisión Ética
 Actitud hacia el bien
 Intención positiva
Ejecución positiva “El fin no justifica los medios”
 Prof Francisco Rocca

[pág. 15]
Neutralización de la Ética
 Los decisores argumentan que no son personalmente
Negación de Responsabilidad 01 responsables por sus acciones ya que había factores fuera de su
 control. “No tenía otra cosa que hacer. Estaba desesperado”.
 Los decisores alegan que la conducta que violó ciertas normas
Negación del daño 02 éticas no son muy serias por sus consecuencias, dado que nadie
 sufrió por ellas. “Qué tanto problema? Si nadie salió dañado”.
 Los individuos contrarrestan cualquier acusación contra ellos
Negación de la víctima 03 argumentando que la parte afectada se lo merecía- “Si son tan
 tontos como para creérselo todo, es culpa de ellos y no nuestra”.
 Los individuos tratan de rebajar su culpa por la vía de acusar de
Condenando a los que condenan 04 las mismas prácticas a sus superiores o competidores. “Yo sólo
 estaba haciendo lo que otros hacen todo el tiempo”
 Se argumenta que la conducta impropia es sólo un aspecto
Apelando a lealtades
superiores
 05 colateral en su esfuerzo por lograr un bien superior para la
 empresa. “Lo hice porque era lo mejor para todos al final”.
 Prof Francisco Rocca

[pág. 16]
Prof Francisco Rocca

[pág. 17]
Principales leyes de relevancia
LEY DE PROTECCIÓN LEGISLACIÓN REGL. PRODUCTOS INSTITUCIONES PARA LEY DE ABUSO
 AL CONSUMIDOR ANTI-MONOPOLIO FARMACÉUTICOS Y REGULAR Y DE PUBLICIDAD
 Derecho a la COSMETICOS MONITOREAR Publicidad engañosa
 privacidad CUMPLIMIENTO:
 FNE
 Sernac
 Conar
 SNS
 Prof Francisco Rocca

[pág. 18]
Derechos básicos de los consumidores
• Los consumidores tenemos el derecho a
 estar informados sobre los aspectos
 relevantes de un producto/servicio/contrato.
• Los consumidores tenemos derecho a ser
 oídos.
• Los consumidores tenemos el derecho a
 elegir lo que compramos.
• Los consumidores tenemos el derecho a ser
 educados acerca de las compras.
• Los consumidores tenemos el derecho a un
 servicio amable.
• Los consumidores tenemos el derecho a
 devolver un producto que no les satisface.
 Prof Francisco Rocca

[pág. 19]
¿Cómo aplicar la ética en los contenidos revisados a
 lo largo del semestre?
 Prof Francisco Rocca

[pág. 20]
Conductas ilícitas de precios
 1 3
 Fijación de precios Discriminación de precios Competencia desleal
- Precios de mantención o - Por el comprador. - Fijación Horizontal o Colusión.
sugerencias de precios. - Por el vendedor. - Engaño al consumidor (ej. Promociones
- Precios mínimos y máximos. - Uso de premios o descuentos que falsas).
- Acuerdos verticales con la no son por volumen. - Precios Predatorios o “Dumping”.
cadena de distribución
 Prof Francisco Rocca

[pág. 21]
Conductas ilícitas en distribución
 Restricciones verticales impuestas, por una parte
Limitación al territorio geográfico Limitación al proveedor para Obligación de comprar/distribuir
de la concesión o del contrato de vender a otro distribuidor en área la línea completa de productos
distribución. asignada a distribuidor. (acuerdo vinculante o venta
 atada).
Obligación de prestar servicios Obligación de no exportar a otro Fijación de precios de Reventa al
posteriores a la venta. país. distribuidor.
 Prof Francisco Rocca

[pág. 22]
Ética en la investigación de mercado
Las investigaciones de mercado pueden
tener problemáticas éticas relacionadas a
las formas de obtener la información.
Estas problemáticas suelen tratarse en los
códigos profesionales de investigación de
mercado.
Básicamente hacen referencia a las
siguientes exigencias:
– Consentimiento informado.
– Privacidad y confidencialidad.
– Engaño y daño.
– Objetividad en los informes.
 Prof Francisco Rocca

[pág. 23]
Ética en el desarrollo de productos y marca
 Prof Francisco Rocca

[pág. 24]
Conductas ilícitas en comunicación
Publicidad engañosa.
• El delito de publicidad engañosa
 consiste en hacer, por parte de
 los fabricantes o comerciantes,
 alegaciones falsas o manifestar
 características inciertas sobre
 sus productos o servicios en las
 ofertas o publicidad sobre los
 mismos (Fuente: Sernac)
 Prof Francisco Rocca

[pág. 25]
Ética en las comunicaciones
 Publicidad Ética
La publicidad comprende varios
temas éticos:
– Respeto de la dignidad y de los
derechos humanos.
– Publicidad no ofensiva y de buen
gusto.
– Evitar una intromisión excesiva.
– Competencia justa.
– Responsabilidad por el impacto
social.
 Prof Francisco Rocca

[pág. 26]
Ética en las comunicaciones
 Veracidad en la publicidada
Se debe tener especial cuidado con:
– Publicidad que pueda ser engañosa.
– Publicidad exagerada.
– Testimonios y aprobaciones
tergiversados o que no corresponden.
– Demostraciones exageradas, camufladas.
– Maquetas.
 Prof Francisco Rocca

[pág. 27]
Prof Francisco Rocca

[pág. 28]
Categorías de Conductas
 Lo legal y lo ético están muy vinculados
 Discriminación a
 Distribuidores Inhabilidad del Consumidor para
 Fijación de Comparar e Interpretar los Precios
 Precios y territorios
 a Distribuidores
 Garantías
Dumping Falsas de P.
 ILEGALES. ANTIÉTICAS
Atentados contra la
 Publicidad
competencia
 Engañosas
Colusión de precios Comparaciones
 Engañosas
 Denigrar o mentir sobre la Insert your desired Alteración de
 Liquidaciones
 competencia text here.“mentirosas” productos
 Prof Francisco Rocca

[pág. 29]
¡¡En definitiva, siempre hay que actuar
con altos estándares éticos en todas las
 acciones que realicemos!!
 Prof Francisco Rocca

[pág. 30]
Prof Francisco Rocca

[pág. 31]
Definición de RSE
• Es una visión de los negocios que incorpora el respeto por los
 valores éticos, las personas, las comunidades y el medio
 ambiente.
• Esto apunta a tener un balance entre el desarrollo
 económico, el progreso social y la protección del medio
 ambiente
 Prof Francisco Rocca

[pág. 32]
Responsabilidad Empresarial
La sociedad, los medios y los
consumidores estamos cada vez
más preocupados de los impactos
sociales y en el medio ambiente,
que producen los productos que
 Comportamiento
consumimos. ético
 Prof Francisco Rocca

[pág. 33]
Las empresas debemos preocuparnos de…..
• La pobreza.
• De los proveedores
• De la discriminación
• De las minorías étnicas
• Del medio ambiente
• De las condiciones de los trabajadores, la explotación laboral y
 los derechos humanos.
• De la salud de nuestros consumidores
 Prof Francisco Rocca

[pág. 34]
La RSE se desarrolla en dos ámbitos
 Es ,como la organización se desarrolla
 Interno con los grupos de interés externos y
 con su entorno social y
 medioambiental
Se refiere a los aspectos relacionados
con los trabajadores, la gestión ética, del Externo
buen gobierno de la organización , de la
calidad de los productos, temas del
medio ambiente vinculados a la
producción, consumo de recursos y
relaciones laborales
 Prof Francisco Rocca

[pág. 35]
Las 4 áreas foco de RSE
 TRABAJO
 MEDIO
 AMBIENTE
COMUNIDAD CONSUMIDORES
 Prof Francisco Rocca

[pág. 36]
Conceptos relacionados con la RSE
Desarrollo
Sustentable
 Prof Francisco Rocca

[pág. 37]
Conceptos relacionados con la RSE
• Stakeholders (grupos de interés.)
 – Grupos de interés que pueden ser afectados por una organización o
 sus actividades o tener incidencia sobre ellas
 Prof Francisco Rocca

[pág. 38]
Conceptos Relacionados Con La RSE
 Códigos de Buen Gobierno
 Prof Francisco Rocca

[pág. 39]
Conceptos Relacionados Con La RSE
 Reputación Corporativa
 Prof Francisco Rocca

[pág. 40]
Conceptos Relacionados Con
 La RSE
 Acción Social
 Prof Francisco Rocca

[pág. 41]
¿Por qué RSE?
• Consumidores e Inversionistas, cada vez tienen más
 expectativas de las empresas y organizaciones que tienen RSE.
• Los consumidores están más conscientes del entorno:
 Consumismo “Verde y Ético”
• Legislación cada vez con más exigencias ambientales.
• Con la globalización se adoptan mejores prácticas con la
 aceptación y exigencias de los consumidores .
 Prof Francisco Rocca

[pág. 42]
Ventajas de la RSE para la empresa
• Recursos Humanos. • Desarrollo de Negocios.
 – Facilita el reclutamiento ,retención y la moral – Desarrollo de nuevos mercados, productos y
 de las personas. servicios.
 – Atrae a los Talentos – Aumenta las ventas
• Administración del riesgo. • Administración de los recursos.
 – Mejor administración y conservación de los
 – Mas Inversiones en marcas que tengan valor recursos estratégicos.
 ético.
 – Disminuyen los costos. • Relación con los diferentes
• Es un elemento de diferenciación. Stakeholders.
 – Mejoran las relaciones con los stakeholder
 – Genera lealtad de marca internos y externos.
 – Crea reputación de marca – Le permite una mayor libertad a la empresa en sus
 – Crea atractivo de la marca. operaciones, ya que se reducen las intervenciones
 del gobierno y de las ONG
 Prof Francisco Rocca

[pág. 43]
Prof Francisco Rocca

[pág. 44]
La RSE Genera Valor
 Prof Francisco Rocca

# Fundamentos de Marketing · Clase n7 Investigación de mercado VA

Fuente: clase de Fundamentos de Marketing

[pág. 1]
Clase 6
Información del cliente y del mercado
 FRANCISCO ROCCA

[pág. 2]
FRANCISCO ROCCA

[pág. 3]
CONSUMIDOR
 COMPRADOR
 El CONSUMIDOR SE
TRANSFORMA en modalidad
 COMPRADOR
tan pronto cuando se dispara
 una necesidad.

[pág. 4]
CONSUMIDOR COMPRADOR
Es quien consume el producto, pero no necesariamente Es quien compra el producto, pero no necesariamente
lo compra. lo consume.
•Predispuesto a lo emocional, la mente absorbe la •Predispuesto al comportamiento.
 información que construye la percepción y la relación con •La mente absorbe cualquier información que esté
 la marca. relacionada con la forma en que compramos.
•Cambiar a la mentalidad de comprador en cualquier lugar y •La mentalidad del comprador siempre está influenciada por
 en cualquier momento, no sólo en la tienda. la mentalidad del consumidor. FRANCISCO ROCCA

[pág. 5]
Como desarrollar una Estrategia de Shopper
 FRANCISCO ROCCA

[pág. 6]
CUAL? ES LA OPORTUNIDAD DE NEGOCIO
 QUIEN? ES EL COMPRADOR
POR QUE? ESTA COMPRANDO
 COMO? PODEMOS INFLUIR EN SU DECISION DE COMPRA

[pág. 7]
Donde nos enfocamos?
Tamaño del Negocio Ventaja Competitiva
 Ejecución de Excelencia

[pág. 8]
CUAL? ES LA OPORTUNIDAD DE NEGOCIO
 QUIEN? ES EL COMPRADOR
POR QUE? ESTA COMPRANDO
 COMO? PODEMOS INFLUIR EN SU DECISION DE COMPRA

[pág. 9]
Quien es el Shopper?
 • Lo primero es identificar cual es el
 target de la marca.
 • Cual es la principal ocasión de
 consumo para una marca en particular.
 • Determinar quien compra con mas
 frecuencia para esa ocasión en
 particular. Cuales son los datos básicos
 de ese comprador (sociodemográficos,
 socioeconómicos
 • Identificar el lugar y misión donde se
 produce la compra.
 FRANCISCO ROCCA

[pág. 10]
CUAL? ES LA OPORTUNIDAD DE NEGOCIO
 QUIEN? ES EL COMPRADOR
POR QUE? ESTA COMPRANDO
 COMO? PODEMOS INFLUIR EN SU DECISION DE COMPRA

[pág. 11]
Misiones de Compra
• Compra mas planificada • Compra menos planificada
• Mayor elasticidad precio • Menor elasticidad precio
• Mas Alternativas • Menos Alternativas.
• Compras mas grandes • Compras mas chicas
 Misión de Compra Misión de Compra Misión de Compra de
 Abastecimiento Reposición Urgencia/ Inmediata
 FRANCISCO ROCCA

[pág. 12]
CUAL? ES LA OPORTUNIDAD DE NEGOCIO
 QUIEN? ES EL COMPRADOR
POR QUE? ESTA COMPRANDO
 COMO? PODEMOS INFLUIR EN SU DECISION DE COMPRA

[pág. 13]
Entendiendo el camino de compras del comprador.

[pág. 14]
INFORMACIÓN DEL MERCADOS
 Y DEL CONSUMIDOR
 FRANCISCO ROCCA

[pág. 15]
¿Por qué es importante saber lo que
está pasando con los Consumidores?
 FRANCISCO ROCCA

[pág. 16]
Caso Electrolux
 FRANCISCO ROCCA

[pág. 17]
¿Como saber más sobre los consumidores?
 FRANCISCO ROCCA

[pág. 18]
1-Sistemas de Comunicación con Clientes.
Los sistemas de comunicación con clientes
son herramientas que una empresa utiliza
para interactuar, comunicarse y mantener
relaciones efectivas con sus clientes.
Canales de contacto
• Call center (llamadas inbound y outbound)
• Email
• Sucursales y puntos de venta
• WhatsApp
• Chat en línea
• Buzón de reclamos y sugerencias
• Redes sociales
• Eventos presenciales.
 FRANCISCO ROCCA

[pág. 19]
2- Sistemas de información de la fuerza de Ventas
Para sacar el máximo provecho del contacto con clientes, debo
recolectar, estandarizar y analizar la información.
Una herramienta útil es un CRM analítico, que nos permite:
• Modelos de propensión a comprar
• Análisis de segmentos
• Perfiles de clientes
• Medición del valor del cliente
• Análisis de abandono de clientes (Churn Rate)
• Predicción próxima compra
• “Basket Analysis”
• Evaluación de campañas de marketing
• Calificación de prospectos o posibles clientes.
• Análisis de satisfacción
• Venta cruzada o cross sell
• Análisis de riesgo versus valor
 FRANCISCO ROCCA

[pág. 20]
3- Análisis de bases de datos, Data Mining y Big Data
• El Data Mining, es un conjunto de
 técnicas que se realizan para explorar
 grandes cantidades de datos (Big
 Data). Encontrando patrones en los
 datos, el Data Mining nos puede
 ayudar a optimizar la toma de
 decisiones y la estrategia empresarial
 (Business Intelligence).
 FRANCISCO ROCCA

[pág. 21]
3- Análisis de bases de datos, Data Mining y Big Data
 FRANCISCO ROCCA

[pág. 22]
3- Análisis de bases de datos, Data Mining y Big Data
 • ¿Dónde estuvo?
 • ¿Qué hizo?
 • ¿Qué exploró: marcas,
 productos, etc.
 • ¿Qué compró?
 • ¿Puntos de contacto?
 • ¿Con quién compartió?
 FRANCISCO ROCCA

[pág. 23]
La importancia de la protección de los datos de los
 consumidores
 FRANCISCO ROCCA

[pág. 24]
4- Investigación de mercado
• Se puede definir como la recopilación y el análisis de información, en lo que
 respecta al consumidor y del mercado, realizados de forma sistemática o
 expresa, para poder tomar decisiones dentro del campo del marketing
 estratégico y operativo.
• La American Marketing Association(AMA) la define como: «la recopilación
 sistemática, el registro y el análisis de los datos acerca de los problemas
 relacionados con el mercado de bienes y servicios».
 FRANCISCO ROCCA

[pág. 25]
4.La investigación de mercado nos permite….
• Entender el mercado y los consumidores
• Identificar problemas y oportunidades
• Desarrollar planes de acción de marketing
 TOMAR MEJORES DECISIONES
 FRANCISCO ROCCA

[pág. 26]
4- Proceso de la Investigación de Mercado
 Análisis de los
 Resultados
 Técnicas e
 Instrumentos.
 Tipos de ¿Qué haremos con
 Estudios los resultados,
 Objetivos de ¿Qué tipo de
 planes de acción,
 la Instrumentos
 confirmar
 Necesidades Investigación utilizaremos,
 de ¿Qué tipo de hipótesis?
 entrevistas,
 Definición del Información ¿Definir investigación es encuestas etc.?
 Problema claramente el necesaria para
 objetivo de la el objetivo
 ¿Donde vamos a
 investigación? definido?
¿Qué queremos obtener la
saber? información?
¿Cual es el Que Información
problema a ya tenemos?
resolver?
 FRANCISCO ROCCA

[pág. 27]
Tipos de investigación de mercado
 Tipos de investigación de
 Mercado
 Investigación
 Investigación Investigación
 cuantitativa o
 Exploratoria Cualitativa
 concluyente
 Se usa para estudiar un Se usa para levantar y evaluar Se usa para conocer aspectos de
problema que no está claramente información no estandarizada, para los consumidores, usando técnicas
 definido aún. entender motivaciones, estadísticas que permiten
 sentimientos y percepciones de cuantificar la información
 No hay hipótesis a descartar
 los consumidores. recolectada.
 aún.
 Se establece una hipótesis Permite sacar conclusiones y
 tomar decisiones
 Finalmente, valido esas hipótesis con un
 Lo primero que puedo hacer es
 Luego, escucho al cliente, estudio cuantitativo. Es el único que me
 analizar la información que ya
 permite obtener conclusiones
 tengo. Esto permite formular establezco hipótesis representativas y por lo tanto tomar
 mejor el estudio
 decisiones.
 FRANCISCO ROCCA

[pág. 28]
Tipos de investigación de mercado
 Tipos de investigación de
 Mercado
 Investigación
 Investigación Investigación
 cuantitativa o
 exploratoria cualitativa
 concluyente
 Investigación
 Investigación
 Datos internos Datos externos Observación Entrevista causal o
 descriptiva
 experimental
 Volumen de venta Observación Entrevista no
 Fuentes secundarias de Porcentajes
 Costos de marketing participativa y no estructurada o en Causa y efecto
 organizaciones Inf Cuantitativa
Informes control de calidad participativa profundidad
 empresariales privadas o
 Registro de proveedores
 públicas.
 Balances contables
 FRANCISCO ROCCA

[pág. 29]
4- Proceso de la Investigación de Mercado
 INVESTIGACIÓN CUALITATIVA INVESTIGACIÓN CUANTITATIVA
 •Los datos se representan y resumen de forma
•En la investigación cualitativa, la muestra se numérica.
selecciona deliberadamente para incluir a personas,
grupos o casos que proporcionen información rica y •Las muestras son aleatorias es decir cada
relevante para el tema de estudio. miembro de la población tiene una probabilidad
 igual de ser seleccionado en la muestra.
•Permiten entender el comportamiento del
consumidor. •Es ideal para descubrir el quién, qué cuándo,
 dónde.
•Genera información verbal para entender
opiniones y motivaciones. •Genera información numérica para convertirla en
 estadísticas.
•Subjetiva y orientada al proceso.
 •Objetiva y orientada al resultado.
•Pequeñas muestras en ambientes naturales.
 •Muestras grandes para producir resultados
 generalizados y válidos.
 FRANCISCO ROCCA

[pág. 30]
4- Proceso de la Investigación de Mercado
 INVESTIGACIÓN CUALITATIVA INVESTIGACIÓN CUANTITATIVA
● Focus group ● Descriptivo
• Entrevistas en profundidad • Experimental - causal (grupo control)
• Etnografía • Encuestas a clientes, no clientes y
• Netnografía ex-clientes.
• Sesiones de grupo (online o • Clientes misteriosos y paneles de
 presencial) consumidores.
 • Estudios dirigidos a la base de datos.
 • Estudios con muestras aleatorias.
 FRANCISCO ROCCA

[pág. 31]
Estudios Cualitativos /Exploratorios
 • Obtener información General.
 • Obtener ideas, explorar hipótesis para estudios
 posteriores.
 – Motivaciones e Inhibidores de los clientes
 – Beneficios buscados por las
 personas/empresas
 – Percepciones de las distintas marcas/servicios
 – Reacciones a imágenes de empresas
 – Explorar factores clave para la satisfacción del
 cliente
 – Explorar nuevos servicios
 • Definir prioridades de investigación.
 Estos estudios no son concluyentes
 FRANCISCO ROCCA

[pág. 32]
Etnografía
• Técnicas para observar al consumidor en su
 ambiente natural y estudiar su comportamiento en
 su entorno.
 – Es una técnica experiencial , los consumidores son
 analizados en su vida real.
 – Es una técnica exploratoria (no hay hipótesis que se
 quiera descartar), por lo que es ideal para encontrar
 insights inesperados (no vistos por la competencia) del
 comportamiento del consumidor.
• Algunos tipos de etnografías
 – Observación participante: en el hogar u otros entornos
 donde se producen las relaciones con los productos
 – Acompañamiento en el lugar de compra
 – Diarios de vida o registros de actividades
 – Recopilación de material audiovisual del entorno: casa,
 habitación, refrigerador, calle, amigos
 FRANCISCO ROCCA

[pág. 33]
Netnografía
• La Netnografía es la etnografía en las
 comunidades y redes sociales en
 internet.
 – Es un concepto , que surge como respuesta al
 alto uso de internet por parte de los
 consumidores.
 – Es un enfoque cualitativo de investigación del
 consumidor sobre sus interacciones en las redes
 sociales.
 – Es una observación y escucha online no intrusiva
 o aprobada, que busca insights no sesgados
 sobre las necesidades, conductas, percepciones
 de los consumidores, para así identificar
 tendencias y necesidades no cubiertas.
 FRANCISCO ROCCA

[pág. 34]
Estudios Cuantitativos / Descriptivos
 • Son estudios para conocer mas detalles de
 algún fenómeno dado.
 • Son estructurados , se recolecta
 información y se realizan análisis
 estadísticos.
 – Encuestas a Consumidores/No
 Consumidores/Ex-Cconsumidores
 – Paneles de Consumidores
 – Estudios Dirigidos a la Base de Datos
 – Estudios con Muestras aleatorias
 • Ejemplo
 – Conocer % de consumidores que prefieren
 determinado producto.
 – Características sociodemográficas de un
 segmento de mercado.
 FRANCISCO ROCCA

[pág. 35]
Paneles de Consumidores
 FRANCISCO ROCCA

[pág. 36]
Estudios de opinión pública
 FRANCISCO ROCCA

[pág. 37]
FRANCISCO ROCCA

[pág. 38]
Conceptos a tener en cuenta en un estudio de mercado
• Población / Universo: Descripción clara • El tamaño de la muestra: Es una
 y concreta de quien es el público del que porción significativa de la población que
 quiero obtener información, es decir cumple con las características de la
 ¿quién es mi mercado de investigación? investigación reduciendo los costos y el
• Censo: Todas las unidades del Universo, tiempo.
• Muestra: Selección de una parte del • Muestra Representativa: Está integrada
 Universo que va a ser entrevistada y que por personas con intereses similares a
 deberá ser representativa del universo nuestro objeto de estudio, no tiene que
 total ver, con el tamaño.
 • Margen de error: es el porcentaje de
 variación aceptable que existe en los
 resultados de la investigación. Es la
 manera de aceptar que los datos no son
 absolutamente exactos o precisos.
 FRANCISCO ROCCA

[pág. 39]
Resumen final
• El consumidor es quien consume los producto y no necesariamente es el que lo compra, y el
 comprador es el que compra el producto perno necesariamente lo consume, ambos pueden ser la
 misma persona.
• Para el desarrollo de una estrategia de shopper tenemos que analizar la oportunidad , entender al
 comprador ,analizar sus misiones de compra y entender el camino de compras para poder influir en sus
 compras.
• La investigación de mercado es una herramienta fundamental para conocer más a nuestros clientes y
 potenciales clientes. Dado esto, es algo que las marcas debiesen realizar constantemente.
• Existen distintas fuentes de información disponibles y tipos diferente tipos de investigación de mercado.
• Es fundamental definir bien cuál es el objetivo de la investigación de mercado que queremos llevar a
 cabo.
• Una vez finalizada la etapa de investigación, se deben tomar decisiones o definir planes de acción de
 acuerdo a los resultados.
• Nuevas técnicas como la Netnografía han surgido en el contexto de la economía digital .
• Los sistemas de información de ventas nos entrega información valiosa de nuestros compradores.
• El big data y data mining permiten recolectar una gran cantidad de datos de los clientes. El desafío es
 interpretar esta data para tomar decisiones de valor para la empresa.
 FRANCISCO ROCCA

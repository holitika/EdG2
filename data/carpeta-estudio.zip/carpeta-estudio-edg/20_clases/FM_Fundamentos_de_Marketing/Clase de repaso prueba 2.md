# Fundamentos de Marketing · Clase de repaso prueba 2

Fuente: clase de repaso

[pág. 1]
Ayudantía Prueba 2

[pág. 2]
Pregunta 1
El crecimiento que han tenido las aplicaciones ha sido exponencial, y hoy tenemos aplicaciones para todo tipo de empresas y actividades.
Los gimnasios no han sido ajenos a este fenómeno, desarrollándose desde hace años varias aplicaciones para hacer entrenamiento en la casa o en el lugar donde estés. Las 2 aplicaciones más populares son Jefit y Nike Training Club.
Tanto Jefit como Nike Training Club ofrecen membresías de un año por US$ 70. Sin embargo, Nike Training Club también ofreció una opción de suscripción mensual con un precio de $13 mensuales mientras que Jefit ofreció una suscripción de por vida por un precio de $400. Nike Training Club también incluyó una prueba gratuita de 14 días con su suscripción de un año y una prueba gratuita de 7 días con su opción de suscripción mensual.
De acuerdo a un estudio realizado para ver la disposición a pagar de los consumidores de app de los gimnasios, ésta depende de la frecuencia de uso que los consumidores hagan de la aplicación. Los resultados de este estudio fueron que para las personas que usan la aplicación menos de una vez a la semana, pero al menos una vez al mes (usuarios poco frecuentes), están dispuestos a pagar un monto promedio anual de $58.80, mientras que aquellos que usarían la aplicación más de una vez al día (los usuarios más frecuentes o intensivos) estarían dispuestos a pagar una cantidad anual promedio de $281,88.
Preguntas:
De acuerdo a lo visto en clases, explique claramente si el valor de US$70 de Nike Training Club es el precio correcto y si la prueba gratuita le conviene o no a Nike Training Club. Haga todos los supuestos que estime conveniente. Justifique claramente su respuesta. 
De acuerdo a lo visto en clases, explique claramente si el valor de la membrecía de por vida ofrecida por Jefit es un precio adecuado y que riesgos ve para Jefit el no tener membresías mensuales y pruebas gratuitas. Haga todos los supuestos que estime conveniente. Justifique claramente su respuesta.

[pág. 3]
Pregunta a)
¿Qué es lo que tienen que hacer en este caso?
Evaluar si la estrategia de precios es la adecuada para los segmentos objetivos a los cuales las apps quieren llegar.
¿Cuáles son los conceptos  claves que tienen que tener para responder?
La disposición a pagar de cada segmento

[pág. 4]
Respuesta a)
En este caso para saber si el precio es el adecuado para Nike Training Club hay que analizar cuál es el segmento objetivo al que quiere llegar Nike y la estrategia de precio que quiere seguir. Si está orientado a los consumidores más profesionales, que tendrían un uso más intensivo de la aplicación, y su estrategia es de Descreme, el precio sería incorrecto, ya que este segmento tiene una significativa mayor DAP promedio (asumiendo baja varianza). Si, por el contrario, la estrategia es de Penetración, entonces el precio podría ser correcto, ya que le deja al segmento objetivo excedente relevante, gatillando mayor volumen. 
Al contrario, si su segmento objetivo es de los usuarios poco frecuentes o moderados, el precio podría ser inadecuado, ya que, dependiendo de la varianza en torno al promedio de 58, el precio de 70 podría dejar fuera a un número significativo de potenciales clientes, ya que su DAP es inferior al precio de Nike.  Nuevamente, también depende de la estrategia de precios deseada por NIKE, descreme o penetración con el segmento de baja frecuencia. Si es descreme, puede haber una proporción de ese segmento con DAP mayor a 70, pero muy cercana a ese número, y por lo tanto, obtiene una porción alta de la DAP.  Si es mejor o no depende de los volúmenes resultantes. 
La prueba gratuita ofrecida por la aplicación de Nike ofrece la ventaja de un compromiso a corto plazo para los clientes con un precio relativamente económico para aquellos con objetivos deportivos y de rendimiento profesional, y dentro del rango de usuarios moderados de la aplicación. Sin embargo, puede aumentar la tasa de abandono al tener sólo un compromiso mensual (menor barrera de salida). La suscripción mensual también reduce la barrera del costo de entrada para probar la aplicación sin comprometerse con una suscripción anual. Nuevamente esto va a depender del mercado objetivo definido por Nike, esto podría ser un beneficio para Nike particularmente para capturar los usuarios moderados e intensivos en el uso ya que podrían percibir el beneficio entregado de la aplicación, o también podría ser negativo para Nike ya que podrían alejar a los usuarios que no logran desarrollar un hábito de utilización de la aplicación en el corto período de tiempo.

[pág. 5]
Pregunta b)
¿Qué es lo que tienen que hacer en este caso?
Evaluar los efectos positivos y negativos de la membrecía de por vida.
¿Cuáles son los conceptos  claves que tienen que tener para responder?
Estimación de la vida útil del cliente.

[pág. 6]
Respuesta b
La opción de suscripción de por vida de Jefit podría ser beneficiosa para Jefit desde el punto de vista netamente financiero, si asumimos que es poco probable que los usuarios se queden más de 5,7 años ($400/70). Pero tener a muchos clientes enojados, porque no usan la aplicación, pero ya pagaron, puede ser muy mala influencia y publicidad. 
Sin embargo, existe un riesgo para Jefit si subestiman la vida útil del cliente (y un riesgo para el cliente si sobrestiman la vida útil de Jefit). 
Además, al no ofrecer una opción de suscripción mensual o incluir pruebas gratuitas en sus ofertas, Jefit mantiene el costo de entrada relativamente alto, particularmente para los usuarios nuevos en la categoría, así como para aquellos que actualmente usan otra aplicación.

[pág. 7]
Ejercicio 1
El gerente de marketing de Xerox se encuentra evaluando la estrategia de venta de un nuevo producto que ha desarrollado la empresa para el mercado americano. 
El nuevo producto se denomina “Xerox: Book in Time”, el cual permitía producir un libro de 300 páginas por sólo US$7. Esto era una enorme ventaja comercial en un mercado donde dichas economías estaban disponibles para las imprentas sólo cuando el volumen de producción supera el 1,000,000 de libros. Este nuevo sistema de impresión estaba integrado por una impresora de documentos, una impresora de cubierta a color y un encuadernador. Esta nueva máquina de Xerox tenía una capacidad de producción de 60 libros/hora, pudiendo trabajar las 24 horas del día durante 260 días del año. Xerox estimaba que podía venderles este nuevo producto a sus clientes a un precio de US$1,5 millones la unidad, además de permitirle entrar a nuevos segmentos de negocios para las empresas que ya poseían un equipo de esta marca. 
La industria de los libros a nivel de editoriales se encontraba altamente concentrada, ya que sólo doce editoriales concentraban el 85% de la producción de libros. El mercado de las imprentas era distinto, ya que existían 40.000 imprentas en Estados Unidos, sin embargo 25 de ellas representaban el 50% del mercado.
Uno de los grandes problemas de la industria de los libros era la alta devolución que tenían las editoriales de los mayoristas y tiendas de libros, sobre todo en aquellos libros escolares y universitarios. Asimismo, otro problema en la industria era la cantidad de títulos que se encontraban descontinuados producto de que no existía una demanda mínima que justificara el costo de producción. Se estimaba que el número de libros agotados y aquellos que tenían una producción limitada alcanzaba a 263 millones de unidades. 
Un libro de 300 páginas tenía un precio promedio de venta público de US$25. En general, de ese precio de venta a público los canales de distribución (entre el mayorista y tienda de libros) se llevaban un 48% del total, mientras que el resto se repartía entre el autor y la editorial.
El gerente de marketing estaba considerando toda la gama de oportunidades para comercializar este nuevo producto. Dentro de las alternativas las dos que resultaban más atractivas eran: a) ofrecerles este producto a los autores, imprentas, mayoristas, cadenas de librerías (que venden fundamentalmente libros) o b) que Xerox entrara al negocio del servicio de producción de libros a pedido. 
Si Xerox decidía comercializar este nuevo producto, tal como lo hacía con todo su portfolio de productos, el precio de venta sería de US$1,5 millones por equipo. Por el contrario, si Xerox decidía entrar al negocio de libros a pedido, proyectaba que obtendría un margen de 25% sobre el precio de venta (igual al que obtenían actualmente los canales de distribución). Asimismo, estimaba que necesitaba vender 250.000 libros para alcanzar el punto de equilibrio. 
De acuerdo a la información entregada conteste lo siguiente:
La gerencia de marketing tiene dudas en cuanto a cómo comercializar este nuevo producto. Xerox cuenta con dos opciones: vender las máquinas o entrar al negocio del servicio de publicación de libros a pedido. Si la utilidad neta para Xerox bajo cualquiera de las dos alternativas alcanza a un 13,6% de las ventas, ¿qué sistema de comercialización es más rentable para la empresa?

[pág. 8]
¿Qué es lo que tienen que hacer en este caso?
Comparar ambas alternativas, vender u ofrecer el servicio de producción de libros y ver cuál es más rentable para Xerox.
¿Cuáles son las cifras claves que tienen que tener para responder?
Mercado potencial ,Ingresos, márgenes y costos de cada alternativa para evaluar.

[pág. 9]
Cálculos
¿Capacidad máxima de la maquina?
	60 libros por hora x 24 hrs x 260 días=374,400 libros
Opción 1: Venta de la maquina
	Déficit de libros 263 millones263,000,000/374,400 =702 máquinas para cubrir el déficit de libros.
	Ingresos por venta de máquinas = 702 maquinas x US$1.5 millones=US$ 1,053,000,000
	Utilidades = US$1 053,000,000x 13,6%=US$143,208.000
Opción 2: Servicio de producción de libros a pedido
	Costo de impresión por libro: US$7
	250,000 libros a un 25% de margen para lograr el punto de equilibrio.
	Precio= US$7/0.75= US$9,3 – Costo variable US$ 7 =US$2,3 de margen.
	Capacidad máxima= 60 libros por hora x 24 hrs x 260 días=374,400 libros
	Ingreso potencial por maquina=374,400 x $9.30 = $3.48 millones.
	El déficit de libros no cambia=263 millones de libros y se necesitan las 702 máquinas para cubrirlo.
	Ingresos totales de esta alternativa= 702 maq. x US$3.48 millones c/u = US$ 2,443 millones .
	 US$ 2,443 millones  de ingresos x 13, 6% de margen= US$332 mil millones de utilidad.

Para Xerox, considerando sólo los efectos económicos, el sistema de libros a pedidos es más rentable que el negocio de vender las máquinas. Además, hay que considerar que una vez vendida la máquina no hay más retorno. En cambio, con el servicio de libros a pedido la máquina tiene un mayor potencial de ingresos (toda su vida útil).

[pág. 10]
Disagro
La empresa Disagros es un fabricante y formulador de insumos químicos para la agricultura tales como fertilizantes (nutrición vegetal) y pesticidas (protección salud de vegetales).  Tiene su planta de fabricación cerca de Curicó, al sur de Santiago.  Desde hace más de 50 años que vende sus productos en Chile exclusivamente a través de distribuidores ubicados en las principales zonas agrícolas del país, desde Copiapó (zona Norte) hasta Puerto Montt (zona sur).  Los clientes finales son los agricultores de diversos cultivos como maíz, rapps, papas, frutas y hortalizas.  
 Un nuevo gerente general, que viene de otra industria, ha decido revaluar la estrategia de distribución de Disagros y contemplar la posibilidad de establecer una cadena de sucursales de venta directa en las principales ciudades agrícolas de Chile. Para ello ha pedido un estudio de mercado a una prestigiosa empresa de investigación de mercado para conocer mejor las expectativas de los agricultores.  También ha contratado a una empresa de auditoría y consultoría para que estima los costos efectivos durante el año 2021 de una serie de actividades realizadas por sus principales distribuidores Copenal y Natura, ambos considerados representativos del perfil de distribuidores (aprox. 16 distribuidores) con los que trabaja Disagros a lo largo del país.
La empresa de investigación de mercado identificó 3 segmentos de clientes: Los Grandes Agricultores 1, caracterizados por tener grandes extensiones de cultivos, gestión profesionalizada, uso intensivo de tecnología y contar con personal técnico (agrónomo) propio.  Los Grandes Agricultores 2, se diferencian de los anteriores en que es el dueño del predio quien con su familia gestiona el campo, no tiene personal técnico empleado y tienen limitaciones de capital.  Finalmente, el segmento de agricultores pymes (pequeños y medianos), altamente fragmentado en el país, con cultivos de tamaño relativo pequeño, sin mayor calificación educacional, restricciones serias de capital y viven exclusivamente de la venta de sus productos.  Cada muestra representativa del segmento respondió en cuánto valoraba los servicios que se le presentaban:





Preguntas
De acuerdo con la información recibida, ¿qué le sugieren hacer en relación con la estrategia de distribución al nuevo Gerente General de Disagros? ¿Debería un canal propio para atender a sus clientes? Justifiquen claramente su respuesta. 
De acuerdo con la información entregada, ¿cómo debiera implementar el nuevo gerente general de Disagros la estrategia de distribución por ustedes planteada.? Justifiquen claramente su respuesta.

[pág. 11]
¿Qué es lo que tienen que hacer en este caso?
Como Disagro puede llegar de la forma más eficiente sus clientes, en forma directa o continuar con su sistema de distribución.
¿Cuáles son los elementos claves del problema?
La eficiencia del servicio de sus distribuidores y la valoración de sus clientes sobre los servicios demandados.

[pág. 12]
Solución
Indice de costo de realizar las tareas (100 es el mayor costo) |  |  | 
 | Disagros | Comercial Natura | Copenal
Visita Tecnica a campos | 90 | 55 | 100
Despacho Insumos hasta campos | 100 | 45 | 75
Bodegaje de stock por mes | 30 | 60 | 100
Charlas tecnicas | 50 | 65 | 100
Credito 30 dias | 100 | 80 | 65
Mix de producto | 100 | 45 | 40
Estimación del desempeño de cada agente  (100 es el mejor índice de desempeño) |  |  | 
 | Disagros | Comercial Natura | Copenal
Visita Técnica a campos | 100 | 70 | 55
Despacho Insumos hasta campos | 30 | 58 | 80
Bodegaje de stock por mes | 60 | 45 | 85
Charlas tecnicas | 90 | 60 | 30
Credito 30 dias | 55 | 20 | 90
Mix de producto | 10 | 90 | 100
 | Ponderación Desempeño (100 es el mejor indice de desempeño |  | 
 | Disagro | Comercial Natura | Copenal
Visita Tecnica a campos | 90 | 38,5 | 55
Despacho Insumos hasta campos | 30 | 26,1 | 60
Bodegaje de stock por mes | 18 | 27 | 85
Charlas tecnicas | 45 | 39 | 30
Credito 30 dias | 55 | 16 | 58,5
Mix de producto | 10 | 40,5 | 40
Valoración de los servicios | Grandes agricultores 1 | Grandes agricultores 2 | Agricultores PYME
Visita Tecnica a campos | 15 | 35 | 40
Despacho Insumos hasta campos | 25 | 15 | 5
Bodegaje de stock por mes | 25 | 5 | 5
Charlas tecnicas | 10 | 30 | 10
Credito 30 dias | 20 | 15 | 25
Mix de producto | 5 | 0 | 15
Las tareas de despacho, no debiera hacerlas Disagro ya que sus Distribuidores pueden hacerlas a menor costo y de mejor forma. Los segmentos de agricultores, especialmente los más grandes valoran la oportunidad del despacho hasta el campo y no pueden equivocarse en esta tarea. Lo mismo el financiamiento donde un distribuidor como Copenal claramente tiene ventajas.
Las visitas y charlas técnicas debiera hacerlas Disagro a los segmentos Agricultores Medianos y Pymes, ya que las hace mejor y a menor costo que sus distribuidores, y son valoradas por esos segmentos.
Claramente para llegar a satisfacer al segmento 3 respecto de poder comprar una variado mix en el mismo punto de venta, el miembro del canal que mejor y a menor costo puede hacerlo es Copenal y no Disagros .
¿Qué es lo que primero harían ustedes para analizar una estrategia de distribución?
Ver cuáles son los distribuidores más eficientes en cada una de las tareas desde el punto de vista del desempeño.
En conclusión, no parece factible ir adelante con la idea de tener un canal directo exclusivo ya que ni siquiera el segmento de los Grandes Agricultores valora lo que Disagros puede hacer mejor o a menor costo.  Necesita de las competencias de sus distribuidores para agregar valor a los distintos segmentos

[pág. 13]
Ejercicio 3
Suponga que usted es un fabricante de botas y desea mejorar su capacidad productiva, para lo cual necesita hacer una inversión en máquinas de $600 MM, y aumentar su presupuesto de marketing en $50 MM (para poder vender las botas extra que produzca). Las botas tienen un precio de venta de $2,000 y un costo variable de $1,000 cada una. 
 Con las inversiones propuestas usted podrá alcanzar un 5% del mercado. 
 Actualmente el mercado total son 15,000,000 de unidades. Con la mejora que usted piensa llevar a cabo le quedara capacidad ociosa en la máquina antigua, por lo que si realiza una inversión incremental de $200 MM usted ahora podría producir botines, los cuales expandirían el mercado actual en un 20%. 
Con los botines y las botas usted podría llegar a un 10% de este mercado expandido, realizando una inversión en publicidad para los botines de $100 MM. Los botines se podrían vender a $1,500 el par y el costo variable sería de $750 por unidad. Se espera que las ventas de los botines canibalicen en un 25% la venta de las botas.  
De acuerdo a la información entregada conteste lo siguiente:
 Desde un punto de vista netamente económico, ¿lanzaría los botines al mercado? Justifique claramente su respuesta.

[pág. 14]
¿Qué es lo que tienen que hacer en este caso?
Si ampliar la capacidad de producción e incorporar un nuevo producto generando las inversiones en maquinarias y marketing es rentable o no.
¿Cuáles son las cifras claves?
Recuperación de la inversión, márgenes de contribución, canibalización, participación de mercado.

[pág. 15]
Solución
Primero hay que analizar el mercado de las botas.
Inversión en máquinas: $600 MM
Demanda esperada: 5% del mercado (mercado actual 15 MM de unidades), es decir, 750,000.
Precio: $2,000 por unidad
Margen: $1,000 por unidad
Ventas:750.000* $2.000=$1,500 Millones; 
M. Bruto: 750.000 * $1000 =$750MM
Presupuesto de Marketing: $50 MM
Utilidad= $750 MM- $50MM =$700 MM
Retorno sobre la inversión= 700/600 = 16,6%
Nuevo Producto.
Inversión Incremental en máquinas: $200 MM.
Demanda esperada: el bajo precio permite expandir el mercado 20% (18MM de unidades), ambos productos se esperan capturen 10% del mercado expandido = 18MM de unidades
Precio $1500
Margen $750
Presupuesto de Marketing: $100M
Canibalización:25%

Utilidades botas: Tamaño del mercado x participación de mercado x (1- canibalización) x el margen – costo fijo
18MM x 5% x 0,75 x $1000- 50MM=625 MM

Utilidad Botines: Tamaño del Mercado x part Mercado x (1+canibalización) x Margen – Costo Fijo
Utilidad Botines: 18MM x 5%x1,25x750-100MM=743.75 MM

Utilidad Total = Utilidad Botas + Utilidad Botines
Utilidad total:1,368.75 MM
Retorno sobre la inversión:71% (1368.75/800)

Si conviene.

[pág. 16]
Ejercicio 4
La industria vitivinícola es una de las más relevantes para nuestro país. Se debe destacar que el vino en Chile representa un 5,7% de las exportaciones que no son cobre, un 16,5% de las exportaciones agropecuarias y, adicionalmente, un aporte de U$205 millones de dólares de recaudación fiscal por pago de IVA e ILA (Impuesto a la Ley de Alcoholes).
 Las ventas totales de la industria del vino a nivel local alcanzan a U$1,000 millones incluyendo el vino embotellado y en caja. Aun cuando nuestro país es considerado uno de los 10 productores de vino más importantes del mundo, el consumo local es bajo comparado a otros países, alcanzando a aproximadamente 17 litros per cápita (entre los mayores de 18 años).
 La población total de nuestro país alcanza a aproximadamente a 19 millones de personas, de las cuales el 60% es mayor a 18 años. De la población mayor de 18 años sólo un 50% consume vino. El resto prefiere productos sustitutos como la cerveza, los espumantes, el pisco y/ los destilados, y un 10% no consume bebidas alcohólicas.
 El gerente de marketing y ventas de una importante viña de nuestro país, con una participación en valor del 30% del mercado local, había proyectado aumentar las ventas de vino en el mercado interno en un 10% con respecto al año 2021. Sin embargo, el gerente general de la viña pensaba que ese crecimiento era muy conservador, por lo que tenía como meta un crecimiento de un 20% en valor con respecto al año anterior. 
 La viña vende casi todas las cepas que se encuentran en el mercado: cabernet sauvignon, carmenere, merlot, pinot noir, syrah, malbec, ensamblajes, sauvignon blanc y chardonnay.  La viña vende tanto vino en cajas como en botellas y el precio promedio ponderado de una unidad (botella y caja) alcanza a U$3.
 De acuerdo a la información entregada por la Asociación de Vinos de Chile, el 30% de las personas que toman vinos eligen vino embotellado, mientras que el 70% restante prefiere vino en caja. Asimismo, el 20% de los que toman vinos consumen 2 unidades a la semana (botella o caja), mientras que el 80% sólo consumía una unidad. 
 De acuerdo a la información entregada determine cuál de las dos estrategias que se presentan a continuación le permite al gerente de marketing de la viña lograr o superar la meta establecida por el gerente general. Para contestar lo anterior se le pide que mida los efectos incrementales para cada una de las estrategias. 
Aumentar la frecuencia de consumo de vino. Determine cuál sería el efecto si las personas que actualmente toman vino de la marca comenzarán a hacerlo 6 veces por semana (52 semanas al año) en vez de 65 veces trimestralmente. 
Aumentar el número de personas que tomen vino por sobre sustitutos de este (ej: cerveza, pisco, espumante y destilados). Determine el efecto de convencer a un 5% de población que consumen productos sustitutos al vino para que comiencen a hacerlo, asumiendo que tienen el consumo promedio de un cliente que ya consume vino

[pág. 17]
¿Qué es lo que tienen que hacer en este caso?
Cuál de las dos estrategias permite lograr un crecimiento de un 20% que es el objetivo de la gerencia general. Aumentar la frecuencia de consumo o ampliar la base de consumidores capturando consumidores que consumen productos sustitutos al vino.
¿Cuáles son las cifras claves?
Cuantificación del mercado, unidades consumidas por segmento, consumo mensuales, trimestrales y anuales, gasto promedio por persona, Ingresos incrementales, participaciones de mercado, captura de nuevos consumidores.

[pág. 18]
Solución
Aumentar la frecuencia de consumo de vino
Ventas 2021 US$300 millones en el mercado local
Meta de la viña obtener una venta de un 20% adicional que son $360 millones en el año
Aumento incremental de $60 millones.
Consumo actual de la marca son 5 veces por semana o 260 veces al año (5 x 52 semanas)
Son 52 semanas divido por 4 trimestres = 13 semanas por trimestre; por lo que 65/13 =5
Entre los que toman vinos tenemos dos segmentos: los que toman dos unidades a la semana (20%) y los que toman 1 unidad por semana (80%). Lo anterior implica que 1,2 unidades por semana son tomadas en promedio por persona a la semana. (2 x 0.2 + 1 x 0.8 = 1.2).

Si el año tiene 52 semanas, entonces el número promedio de unidades consumidas por persona al año son = 312 unidades (260 x 1,2). Dado que el precio promedio de una unidad es de U$3, el gasto promedio de una persona al año en vino es de U$936.

Si ahora comienzan a tomar vino de la marca 6 veces/semana (52 semanas), entonces tomarán vino de la marca 312 veces en el año (6 x 52 semanas).
El número de unidades tomadas en promedio a la semana por persona se mantiene en 1.2 unidades.

Por lo tanto, el número de unidades tomadas por una persona al año sería de 374,4 unidades (312 x 1.2). 
Dado que precio promedio de una unidad es de U$3, el gasto promedio de una persona al año en vino de la marca sería de U$1,123.2 (lo que implica un crecimiento de un 20%).

Si la empresa vendió en el mercado local U$300 millones y cada cliente gastó en promedio U$936, entonces la viña contaba con 320,513 clientes aproximadamente (312,512.82).
Ahora si estos 320,513 clientes gastan U$1,123.2 per cápita, entonces las ventas totales de la viña durante el 2022 alcanzarían a U$360.0000. 
Es decir, la estrategia que llevaría el gerente de marketing le permitiría lograr la meta establecida por el gerente general.

[pág. 19]
Solución
b)Aumentar el número de personas que tomen vino por sobre sustitutos de este (ej: cerveza, pisco, espumante y destilados). Determine el efecto de convencer a un 5% de población que consumen productos sustitutos al vino para que comiencen a hacerlo, asumiendo que tienen el consumo promedio de un cliente que ya consume vino.
La población total de nuestro país es: 19 millones
60% mayor de 18 años (mercado relevante): 11.4 millones
50% mayor de 18 años consume vino: 5.7 millones
40% mayor de 18 años consume sustitutos: 4,560,000
10% no consume bebidas alcohólicas: 1,140,000 
Actualmente número de personas que consumen productos sustitutos al vino es: 4,560,000. 

Que ocurre si un 5% comienza a tomar vino?
4,560,000. x 5%= 228.000 nuevos clientes.
228,000 nuevos clientes x 1.2 unidades/año = 273,600 unidades incrementales al año, lo que en valor significa U$820,800 (273,600 unidades x U$3)
Sin embargo, la viña tiene el 30% del mercado total. 
Luego, el efecto incremental para la viña será de U$246,240, lo que está muy lejos del incremento necesario para alcanzar la meta (U$60 millones).

[pág. 20]
Ejercicio 5
Consideremos una empresa que trata de vender un nuevo producto al propietario de una fábrica de juguetes  que necesita un sistema de filtración de aire.
El dueño de la fábrica tiene 2 opciones, el producto nuevo de este vendedor y la siguiente mejor alternativa ya consolidada , ofrecida por otra empresa , cada una con las características que se especifican a continuación.





Supongamos que el sistema se va a usar durante 1 año (la fábrica cerrará en un año) durante un tiempo total de 2,500 horas.
Además, se asume que el costo de una falla del sistema para el fabricante de juguetes ascendería a US$100.000  ( debido al paro de la producción que se daría durante las reparaciones) y que el proveedor del sistema de filtración se hará cargo del costo de cualquier falla del sistema a partir del primer día.
Dada esta información  cual es  el valor  económico que el nuevo producto tendría  para el comprador potencial

[pág. 21]
Solución
Valor Económico 
VE=precio de la 2ª mejor alternativa + ahorros previstos a una falla del sistema – costos operativos adicionales
VE= $75.000+((20%x $100.000)-(1%x$100.000))-((2500 hrs x $15/hrs)-(2500 hrs x 10/hr)) 
VE= $75.000+$19,000-$12.500
VE= $81.500

Esto significa que, con esta estructura de costos, un comprador plenamente informado  y racional se mostraría indiferente entre la siguiente mejor alternativa  con un precio de $75.000 y el producto nuevo en $81.500

[pág. 22]
Ejercicio 6
Los programas de protección antivirus existentes se basan en bases de datos de virus que deben actualizarse constantemente a medida que surgen nuevos virus. Una licencia de protección antivirus típica cuesta $4,500 por año para sitios de menos de 500 computadores. 
La actualización regular de las bases de datos cuesta alrededor de $80 en pérdida de productividad por computadora instalada por año. Incluso con la actualización regular de las bases de datos, existe la posibilidad de que virus no contabilizados infecten los sistemas informáticos de una empresa. 
Los expertos en protección antivirus estiman que, con el software de protección antivirus actual, la probabilidad de que una empresa experimente exactamente un daño completo del sistema a causa de un virus en un año es del 8%.
La probabilidad de que experimente exactamente dos de estos daños en un año es del 3%. La probabilidad de más de dos daños es prácticamente nula.
Un daño completo del sistema, que suele durar un día, costaría (en beneficios por pérdida de ventas) $40.000 dólares a una empresa de retail con 250 computadores y $85.000 dólares a una empresa de servicios financieros típica con la misma cantidad de computadores.
Cortex Software Inc. está a punto de presentar un nuevo software de protección antivirus llamado DNX. DNX se basa en un simulador de virus mutante (MRS) que, según Cortex, revolucionará el panorama de la protección antivirus. Básicamente, el MRS elimina la necesidad de actualizar las bases de datos de virus. 
Es extremadamente poderoso y, como resultado, aumenta la probabilidad de detectar archivos infectados. Los investigadores de Cortex estiman que las empresas equipadas con DNX tienen solo un 2% de probabilidad de experimentar una falla completa del sistema causada por virus en un año y una probabilidad del 0% de experimentar más de una falla de este tipo.
Si bien el precio de una licencia de sitio DNX aún no se ha establecido, se estima que los clientes que adopten el software incurrirían en costos de inicio (excluyendo la licencia de sitio) de $50 por computador en instalación, configuración, capacitación, etc.
Pregunta Utilizando un horizonte de un año y sin asumir otros costos de infección de virus o software, calcule el valor económico del DNX para una empresa típica de retail con 250 computadores funcionando con software de protección antivirus existente.

[pág. 23]
Solución
La idea básica del valor económico es considerar el costo total de propiedad, que es el costo de poseer un producto durante toda su vida útil. El valor económico para el cliente (VEC) es el precio máximo que los clientes pagarán por un nuevo producto que es igual a los ahorros de usar el nuevo producto más el precio de compra del producto que se usa actualmente.  Para una empresa típica de retail con 250 computadores que funcionan con un software de protección antivirus existente:
Costo total con protección antivirus existente = costo de licencia + costo de uso + costo de prob de daño
Costo de la licencia = $4,500
Costo de uso = $80 x 250 computadores = $20,000 (costo de actualización)
Costo de Prob de daño = (8% x 1 + 3% x 2) x $ 40,000 = $5,600
Costo total con protección antivirus existente = ($4,500 + $20,000 + $5,600)= $30,100 
Costo total con DNX = costo de licencia + costo de uso + costo de desglose
Costo de la licencia = x
Costo de uso = $50 x 250 computadores = $12,500 (costo inicial)
Costo de de Prob de daño = (2% x 1) x $40,000 = $800
Costo total con DNX = x + $13,300
El VEC de DNX es el costo de licencia x para el cual el costo total con DNX es igual al costo total sin DNX, es decir, $30,100.
VEC DNX = x = $30,100 - $13,300 = $16,800

# Fundamentos de Marketing · Clase N15 marketing digital v2023 2sem

Fuente: clase de Fundamentos de Marketing

[pág. 1]
Prof: Francisco Rocca
 Francisco Rocca

[pág. 2]
¿Qué es Marketing Digital?
• El marketing digital es la aplicación de las estrategias
 de comercialización llevadas a cabo en los medios
 digitales. Todas las técnicas del mundo off-line son
 imitadas y traducidas a un nuevo mundo, el mundo
 online.
• En el ámbito digital aparecen nuevas características
 como la inmediatez, la irrupción de las redes sociales
 y las herramientas que nos permiten hacer
 mediciones reales.
 Francisco Rocca

[pág. 3]
Modelo de mercados masivos Modelo de red de clientes
 Francisco Rocca

[pág. 4]
Francisco Rocca

[pág. 5]
Ecosistema Digital
Los usuarios buscamos distintas actividades o tipo de
información cuando accedemos a los medios de
comunicación digitales, por ejemplo:
 WEB BLOG RRSS APP
 Si buscan información Si buscan Si quieren seguir una Y con las Apps, los
 de marca o conversación, marca, saber sus usuarios se acercan
 entretenimiento, lo novedades y participar más a la marca y se
 encuentran en la WEB comentarios, debate, en promociones se relacionan de manera
 lo encuentran unen a las RRSS y más directa y
 en el BLOG Microsites constante
 Promocionales (engagement)
 Francisco Rocca

[pág. 6]
¿Para qué podemos usar internet y los
 medios digitales?
Visibilidad de marca: Segmentación: Flexibilidad: Resultados: Economía: ahorro de Fidelización:
 impactante y con Podemos dirigir Vemos los resultados Medición de gastos, tiempo y permiten generar
 alcance global. anuncios a un público de una campaña en resultados y esfuerzo, y genera lazos más fuertes con
 tiempo real, de modo retroalimentación mayor ROI que los nuestros clientes, y
 determinado, que podemos ajustar inmediata medios tradicionales. construir una
 logrando así y optimizarla en la comunidad online
 campañas mucho medida necesaria. más amplia de la que
 más eficientes podríamos en el
 mundo offline.
 Francisco Rocca

[pág. 7]
¿Cuáles son los objetivos del
 marketing digital?
• Alcanzar la audiencia correcta.
• Interactuar con la audiencia.
• Motivar a la audiencia a una
 acción (“call to action”).
• Maximizar el retorno sobre la
 inversión (ROI).
 Francisco Rocca

[pág. 8]
Medios Sociales
 • Las audiencias tienen acceso
 prácticamente a “infinitas”
 opciones digitales.
 • Se produce una gran fragmentación
 de los medios.
 • Lo que tenemos que preguntarnos
 es: ¿cómo determinar dónde están
 mis audiencias objetivo?
Fuente:ediscoverytoday.com Francisco Rocca

[pág. 9]
¿Cómo llegamos a las audiencias
relevantes?
 ELECCION
 FIJANDO CREANDO
 DEL MEDIO
 OBJETIVOS CONTENIDOS
 DIGITAL RELEVANTES
 Francisco Rocca

[pág. 10]
Fijación de objetivos a través de RACE
 ALCANCE-REACH
 Construir conciencia y
 visibilidad de marca
 maximizando su
 exposición
COMPROMETER-ENGAGE
 ACTIVIDAD-ACT
 Construir relaciones de Fomentar las
 largo plazo con interacciones con la
 clientes y fan de la marca a travéz de
 marca para lograr el CONVERTIR-CONVERT actividades en los
 objetivo de retención medios digitales
 Lograr los objetivos de
 marketing, como
 lograr fans, leads o
 ventas en los medios
 digitales.
 Francisco Rocca

[pág. 11]
Fijación de objetivos RACE
 Objetivo de Alcance:
REACH – ALCANCE ● Construir conciencia, percepción o visibilidad de la marca,
 producto o servicio.
• Construir conciencia y ●
 ●
 Se trata de generar la mayor exposición posible.
 Maximizar la cantidad y frecuencia que las personas se
 visibilidad de marca, ●
 exponen a nuestros avisos.
 Generalmente, lo medimos en “impresiones”, que son la
 maximizando su cantidad de veces que las personas son “expuestas” al
 contenido.
 exposición. Ejemplos:
 • Contenidos de calidad
 • Utilizar palabras clave y hashtags
 • Impresión en banner.
 • Aviso en rrss
 • Views en YouTube
 • Atraer tráfico a nuestra web, blog.
 Francisco Rocca

[pág. 12]
Fijación de objetivos RACE
 REACH - ALCANCE
Teletón busca llegar a todos los
chilenos para que se sumen con
donaciones.
Mide alcance e impresiones.
 Francisco Rocca

[pág. 13]
ACT – ACTIVIDAD Objetivo de Actividad:
• Fomentar interacciones a través • Fomentar interacciones en las RRSS, nuestro
 sitio, App, blog, portales de terceros o
 de la generación de actividad. cualquier medio digital.
 • Persuadir a las audiencias a participar e
 interactuar con la marca, con terceros o entre
 ellos.
 ¿Cómo hacerlo?
 • Preguntar por un producto, realizar un concurso o
 participar de un webinar.
 Claves son las interacciones en las RRSS,
 foros o sitios de reseñas:
 ● Crecientemente la gente quiere participar.
 ● Hay que estar preparado para contestar y estar
 atentos a lo que se “dice” de nosotros.
 Francisco Rocca

[pág. 14]
Fijación de objetivos RACE
ACT – ACTIVIDAD
• Fomentar interacciones a través
 de la generación de actividad.
 Francisco Rocca

[pág. 15]
Fijación de objetivos RACE
CONVERT – CONVERTIR Objetivo de Convertir:
• Alcanzar los objetivos de • Llevar a los prospectos a una acción
 marketing cómo lograr fans, concreta, a movilizarse.
 leads o ventas.
 ¿Cómo hacerlo?
 • Agregar un producto al carro de compras,
 comprar un producto, suscribirse a un
 servicio, bajar una App, llenar un
 formulario, registrarse, etc.
 Algunas recomendaciones:
 • Hay que hacerle fácil las cosas a las
 personas, evitar los “roces”, clics o pasos
 innecesarios.
 • Debemos tener llamados a la acción
 claros, visibles y atractivos.
 Francisco Rocca

[pág. 16]
Fijación de objetivos RACE
CONVERT – CONVERTIR
• ¿Como mide la conversión la
 Teletón?
 Francisco Rocca

[pág. 17]
ENGAGE – COMPROMETER Objetivo de Comprometer:
 • Construir relaciones de largo plazo con las
• Construir una relación de largo audiencias.
 plazo con los fans y clientes. • Crear lealtad de marca.
 • Intentar generar la recompra.
 ¿Cómo lograrlo?
 • Se puede utilizar la presencia social, los emails, las
 interacciones directas o cualquier otro medio digital.
 • La idea es mantener un contacto permanente, donde los
 clientes son lo más importante.
 • Los programas de recompensas son los más famosos.
 Algunas consideraciones:
 • Se puede medir como la adquisición de fans, likes o
 contenido compartido.
 • También considera la acumulación de emails de
 • Permiso, suscripción a newsletters, ratings positivos o
 recomendaciones en diferentes portales.
 Francisco Rocca

[pág. 18]
ENGAGE – COMPROMETER
• Comprometer a la sociedad a
 donar
 Francisco Rocca

[pág. 19]
¿Cómo llegamos a las audiencias
relevantes?
 ELECCION
 FIJANDO CREANDO
 DEL MEDIO
 OBJETIVOS CONTENIDOS
 DIGITAL RELEVANTES
 Francisco Rocca

[pág. 20]
• Uno de los objetivos más
 importantes del
 marketing digital es
 atraer visitas a los
 medios propios de la
 compañía.
 Francisco Rocca

[pág. 21]
Tipos de medios digitales

[pág. 22]
Tráfico Directo
• El tráfico directo de una página web es
 todo aquel que nos llega a través de
 usuarios que han tecleado
 directamente una URL en la página de
 direcciones del navegador que estén
 usando.
• Es un buen indicador del valor de tu
 marca.
• Está compuesto por personas que ya
 conocen la empresa y vuelven para ver
 más cosas, por recomendaciones boca a
 boca, por personas que gustan tanto del
 contenido que lo marcaron como
 favorito o por apariciones relevantes
 offline (revista o diario, algo que
 escucharon en la TV o la radio).
• Un buen trabajo de marca y de asesoría
 de prensa debería contribuir con esto y
 puede ser evaluado.
 FRANCISCO ROCCA

[pág. 23]
Tráfico
 Orgánico
• Son todas aquellas visitas
 que provienen de la página
 de resultados de un
 buscador, ya sea Google,
 Yahoo, Bing o cualquier
 otro.
• Son usuarios con interés
 por la temática de una
 página, y realizan la
 búsqueda por palabras
 claves.
• Estrategias de SEM y SEO.
 Francisco Rocca

[pág. 24]
90% del tráfico web es
capturado en la primera
página .
 Francisco Rocca

[pág. 25]
Tráfico Orgánico
¿Qué es SEO?
• Search Engine Optimization, "optimización para
 motores de búsqueda". Consiste en estrategias
 de optimización que se implementan en las
 páginas de un sitio web o blog para mejorar su
 posicionamiento en los buscadores.
• Este se centra en mejorar la posición de una
 página web a nivel orgánico o de forma natural
 en los resultados de búsqueda.
• El objetivo final, es el de aumentar también la
 calidad del tráfico orgánico que recibimos, para
 que de esa manera podamos potenciar las
 conversiones de nuestra página web.
• En el caso de SEO , no se paga por estar en una
 mejor posición.
• El funcionamiento del SEO es via palabras claves
 que las personas buscan en los motores de
 búsqueda y la optimización de los contenidos ,
 como también la creación de contenidos
 relevantes Francisco Rocca

[pág. 26]
Tráfico Orgánico
¿Qué es SEM?
• Search Engine Marketing o SEM, es el
 sistema publicitario de Google, por el
 que el anunciante paga para aparecer
 (pay por clik)en las búsquedas o en su
 red de contenidos, mediante la
 inversión en las palabras clave (key
 words) predefinidas y por un sistema de
 remates configurado por adWords.
• Objetivos:
 • Generar interés
 • Ayuda a la toma de decisiones
 • Llamar la atención
 • Refuerzo de marca
• Se ve a través de tráfico, leads, ventas, ,
 atención al cliente y branding. Francisco Rocca

[pág. 27]
Tráfico Orgánico
Peugeot está lanzando una nueva
camioneta: New Landtrek y está
pagando por aparecer en las
búsquedas de google de “Toyota
Hilux” (key Word).
 Francisco Rocca

[pág. 28]
Resultado de la búsqueda
 FRANCISCO ROCCA

[pág. 29]
Social Media Marketing
• Social media marketing (SMM) es
 una forma de marketing en Internet
 que utiliza sitios web de redes
 sociales como herramienta de
 marketing
• El objetivo de SMM es producir
 contenido que los usuarios
 compartirán con su red social para
 ayudar a una empresa a aumenta
 la exposición de la marca y ampliar
 el alcance a los clientes
 Francisco Rocca

[pág. 30]
¿Por qué una marca debe estar presente en las RRSS?
 Las 4P del mktg digital
Personalización Participación Peer to peer Predictive
Diseñar productos a la Involucrar a los clientes en Testimonios, modelling
medida. mktg mix. recomendaciones de
Es posible elegir paquetes Es posible participar mediante Herramientas para predecir el
 personas reales.
personalizados las necesidades del afiliación Es posible observar testimonios y comportamiento del cliente.
cliente reviews además de calificar el servicio Mantienen registros de los viajes que
 has realizado con ellos.
 Francisco Rocca

[pág. 31]
Foco de las diferentes plataformas
 Francisco Rocca

[pág. 32]
Ventajas y
 desventajas del SMM
Ventajas
• Aumenta el reconocimiento de marca
• Mayor tráfico entrante (inbound traffic)
• Mejora los rankings de los motores de búsqueda
• Mayores tasas de conversión
• Mayor satisfacción de los consumidores
• Aumenta la lealtad de marca
• Mayor autoridad de marca.
Desventajas
• Retroalimentación negativa.
• Potencial de vergüenza.
• Es Intensivo en tiempo
• El contenido social tiene una vida útil muy corta.
• Resultados positivos tardan en llegar.
 FRANCISCO ROCCA

[pág. 33]
Medios
utilizados en el
marketing
digital
 FRANCISCO ROCCA

[pág. 34]
E-Mail Marketing
 • Utilización del correo electrónico para
 hacer una campaña o informar al cliente.
 A diferencia de otras herramientas,
 permite realizar una oferta personalizada
 y exclusiva a cada persona.
 • Uso de los blogs para que la gente se una
 a la lista de mails y reciba información
 periódica de cosas que le interesan.
￮ Ejemplo de Email Marketing: ¿Por qué The Hustle ofrece regalar un auto Tesla sólo por suscribirte a su newsletter?
 Francisco Rocca

[pág. 35]
FRANCISCO ROCCA

[pág. 36]
Referidos
• El marketing de referidos consiste
 en que como empresa se entrega
 una remuneración económica,
 descuentos si son clientes o algún
 premio a quien refiere sus
 productos o servicios.
• Generalmente es promovido entre
 la base de clientes y se entrega lo
 prometido cuando la referencia se
 convierte en cliente.
 Francisco Rocca

[pág. 37]
Afiliados
• El marketing de afiliados es un
 modelo de negocio en línea en el
 que una persona (el afiliado)
 promociona productos o
 servicios de otras empresas a
 través de enlaces de afiliados,
 como banners ,elementos
 gráficos y recibe una comisión
 por cada venta o acción generada
 a través de su promoción.
 Francisco Rocca

[pág. 38]
Influencers
• El marketing de influencers identifica a
 personas con fuerte presencia en redes y
 aprovechan su influencia en seguidores o
 suscriptores para promover un producto o
 servicio.
• La idea es que tengan una afinidad con la
 marca y su segmento objetivo, así como
 credibilidad y confianza.
• Ayudan a fortalecer y aumentar la conciencia
 y afinidad de marca entre el segmento
 objetivo.
• En general, se les paga una tarifa fija, a
 diferencia de los Afiliados, donde el pago es
 por resultado (venta, en general).
 Francisco Rocca

[pág. 39]
Blogs
• Sitio web que recopila
 cronológicamente textos o artículos
 de uno o varios autores.
• Habitualmente, en cada artículo,
 los lectores pueden escribir sus
 comentarios y el autor darles
 respuesta, de forma que es posible
 establecer un diálogo.
• El uso o temática de cada blog es
 particular, los hay personal,
 periodístico, empresarial o
 corporativo
 Francisco Rocca

[pág. 40]
Mobile Marketing
 • Obtención de datos.
 • Experiencias personalizadas.
 • Incremento del compromiso.
 • Comunicación directa con notificaciones
 in-app y push.
 • Fidelización de los usuarios.
 • Reactivación de usuarios y reducción de
 la tasa de abandono.
 • Estrategia de precios adaptada al
 modelo de negocio (premium versus
 freemium).
 • Optimización y seguimiento de
 procesos.
 • Mejor posicionamiento.
 • Remarketing o retargeting.
Francisco Rocca

[pág. 41]
Remarketing o retargeting
• Con el remarketing conseguimos
 mostrar el anuncio sólo a las personas
 que previamente han visitado el sitio
 web pudiendo diferenciar entre:
• Los que han abandonado sin realizar
 una conversión y, los que han
 realizado una conversión.
 Google pone término a las cookies durante este año 2023 y apuesta por FLoC
 Francisco Rocca

[pág. 42]
Banners
Banners
El objetivo principal es la visibilidad de
anuncios (público objetivo bien definido).
Según la definición de Google, “se trata de un
conjunto de más de 2 millones de sitios web,
videos y aplicaciones donde pueden aparecer
tus anuncios. Los sitios de la Red de Display
llegan a más del 90% de los usuarios de Internet
en todo el mundo”.
 FRANCISCO ROCCA

[pág. 43]
Videos
Es uno de los recursos más
efectivos para atraer la atención
de un cliente potencial y mejor
aún, aumentar el engagement de
cualquier campaña de Marketing
Digital.
Su mayor obstáculo es el rechazo
de los usuarios a los formatos pre-
roll (otro de los anuncios
comúnmente eliminados por los
bloqueadores de publicidad).
 FRANCISCO ROCCA

[pág. 44]
Monitoreo y Análisis
• Todos los datos que los Principales Métricas
 ecosistemas digitales producen • Procedencia de nuestras visitas.
 deben ser monitoreados a través • Número de visitas a la web con respecto a
 de fuentes externas e internas. un período determinado.
• Lo más importante de la analítica • Visitantes únicos: número de visitantes no
 web es convertir los datos puros duplicados que han accedido al sitio web en
 en información que nos permita un período de tiempo
 tomar decisiones inteligentes • Qué medio social consigue llevar más tráfico
 (Business Intelligence). al site y la calidad de esas visitas.
 • Qué contenidos tienen más engagement
 (tiempo de permanencia y porcentaje de
 rebote).
 • Cómo están funcionando las campañas.
 • Dispositivo por el que han ingresado las
 visitas (mobile, desktop o Tablet)
 Francisco Rocca

[pág. 45]
Monitoreo y análisis
 Francisco Rocca

[pág. 46]
Medición
Conceptos Básicos
• CPC (Costo Por Clic) – El costo que debe pagar el anunciante cada vez que
 se hace clic sobre su anuncio.
• Impresiones – las veces que se muestra un anuncio.
• CTR (Porcentaje de Clics) – N° de clics / impresiones x100. Nos informa del
 rendimiento de un anuncio.
• Tasa de conversión – N° de conversiones obtenidas / visitas (o visitantes,
 depende) x 100.
• ROI (Return of investment) – Beneficio que se obtiene de los anuncios en
 comparación con lo que se ha invertido en ellos. El retorno de la inversión
 (ROI) mide la relación entre los beneficios y los costes publicitarios.
 Francisco Rocca

[pág. 47]
Conceptos claves para evaluar campañas comunicacionales y
 estrategias de adquisición y retención de clientes.
 •Life time (LT): tiempo
Lifetime Value (LTV): (meses, años) que
Cuánto ingreso traen los permanecen los clientes
clientes al negocio. en la empresa, antes de
 que se vayan.
 •Customer Adquisition
•Churn: tasa de abandono Cost (CAC): costo de los
(mensual o anual) de los esfuerzos de venta y de
clientes. marketing para adquirir un
 cliente.
 CLV
 47
•Customer Lifetime Value
(CLV): valor de un cliente.
 Francisco Rocca

[pág. 48]
Ejemplo ¿Cuál es el valor de un cliente para Entel ?
Supongamos que:
1.Los clientes pagan en promedio $50.000 mensuales
2.El 4% de los clientes abandona la compañía todos los meses (churn) = 4% mensual→ LT = 1 / o,o4 mensual = 25 meses
3.Para adquirir 10 clientes, la empresa invierte $5.000.000 en actividades de ventas y $10.000.000 en publicidad CAC =
($15.000.000 / 10 = 1.500.000)
 ¿Cuál es el valor para Entel de un cliente?
 LTV = $50.000 / mes x 25 meses = $1.250.000 el ingreso
 promedio por cliente
 CAC = $1.500.000 costo de adquisición promedio por cliente
 CLV = $1.250.000 - $1.500.000 = -250.000 < 0
 Otra forma de verlo: Ratio = LTV / CAC = $1.250.000 /
 $1.500.000 = 0,83 < 1
 La compañía debería gastar HASTA $1.250.000 en adquirir un
 cliente….en este caso está gastando más
 Francisco Rocca

[pág. 49]
¿Qué acciones harían bajar el CAC?
• Aumentar la retención de clientes a través de un mejor servicio.
• Adquirir nuevos clientes que calcen con el segmento al que quiere
 llegar.
• Ofrecer otros productos a los clientes (cross – selling).
• Disminución de costos operacionales.
• Aumento de los precios.
 Francisco Rocca

[pág. 50]
¿Qué acciones harían subir el LTV?
• Aumentar el boca a boca (WOM).
• Aumentar los medios ganados.
• Realizar una estrategia de medios que permita alocarlos en forma
 más optimizada y eficiente.
• Aumentar el uso de canales offline.
 Francisco Rocca

[pág. 51]
En el marketing Digital: Funnel
 Prospectar: hacer una campaña a
 clientes potenciales, por primera vez.
 Retargeting: hacer una campaña
 sobre clientes a los que ya se había
 dirigido una campaña anteriormente.
 Francisco Rocca

[pág. 52]
¿Por qué es importante el contenido On line?
THE NEW CURRENCY
IN A DIGITAL WORLD IS TRUST
 Francisco Rocca

[pág. 53]
¿Cómo llegamos a las audiencias
relevantes?
 ELECCION
 FIJANDO CREANDO
 DEL MEDIO
 OBJETIVOS CONTENIDOS
 DIGITAL RELEVANTES
 Francisco Rocca

[pág. 54]
Marketing de contenidos
El marketing de contenidos es el tipo de
marketing que se centra en crear, publicar
y distribuir contenido relevante para tu
audiencia objetivo, con el propósito de
atraer clientes nuevos de una manera no
intrusiva.
En este proceso es clave despertar el
interés de este cliente con la información
perfecta en el momento ideal. Por lo que
se necesitan distintos contenidos para
responder a las dudas del cliente en
cualquiera de sus fases en el ciclo de
compra.
 Francisco Rocca

[pág. 55]
Tipos de creación de contenidos
 Contenido Propio: Generado por el Generado en el
 MARKETING DE usuario entorno
 CONTENIDOS
 Artículos de blog. Foros. Redes sociales.
 Descripción de productos. Crítica de productos. Sitios de video.
 Noticias. Rating de productos. Blogs de la industria.
 Tutoriales. Testimoniales. Sitios de prensa
 Whitepapers, casos. Concursos. online.
 E-books, guías. Interacciones en RRSS Revistas online.
 Webinars Preguntas y respuestas. Web de terceros.
Campañas de comunicación Grupos o comunidades
 .
 Francisco Rocca

[pág. 56]
Creación de contenidos relevantes
• Llamar a la Acción.
• Calidad de los Contenidos →SPAM
• Activar las conversaciones.
• Dar respuestas a los consumidores.
• Ser Honesto, y abierto
• Ofrecer herramientas a los
 consumidores.
• Repetir las campañas normales en
 la Web.
 Francisco Rocca

[pág. 57]
Ejemplos de Marketing de contenidos de acuerdo a cada etapa
 del viaje del cliente:
 PAGINA WEB BLOG Ebooks y Whitepapers Videos Testimoniales
En la página de precios Ayudar al cliente a Permite ofrecer A través de vídeos con
 o de servicios las informarse y a crearse información entrevistas a
 marcas pueden comparativa de testimoniales se
demostrar porque son una opinión sobre un distintas soluciones a transmiten
 la mejor opción. tema determinado. su problema o experiencias positivas
 necesidad. de otros clientes con la
 marca.
 Francisco Rocca

[pág. 58]
Campaña Don`t mess with Mother Earth
 La campaña “No te
 metas con madre” de
 Apple Logró 39
 millones de views y
 81.000. likes.
 Consistía en un video
 de la naturaleza
 completamente
 grabado con el
 iPhone XS,
 conmemorando el
 día de la Tierra.
 Francisco Rocca

[pág. 59]
La campaña “No te
 metas con madre” de
 Apple Logró 39
 millones de views y
 81.000. likes.
 Consistía en un video
 de la naturaleza
 completamente
 grabado con el
 iPhone XS,
 conmemorando el
 día de la Tierra.
Francisco Rocca

[pág. 60]
Lo que vimos hoy
• El marketing digital es la aplicación de las estrategias de comercialización llevadas al mundo
 digital y es clave para la adquisición de clientes, a través de la llegada a las audiencias relevantes.
• Para llegar a las audiencias relevantes, es clave fijar un objetivo, elegir los medios digitales y crear
 un contenido relevante para los clientes.
• Respecto a los objetivos, el modelo RACE nos muestra cuatro objetivos posibles: Reach (alcance),
 Actividad, Conversión y Engagement.
• Respecto a los medios, el marketing digital cuenta con distintos medios digitales, entre los que
 encuentran los propios (como el sitio web), los pagados (como el pay per click, display ads) y los
 ganados (redes sociales).
• Vimos diferentes conceptos claves para evaluar campañas comunicacionales y estrategias de
 adquisición y retención de clientes.
• La creación de contenido relevantes para el público objetivo se denomina “marketing de
 contenido” y es importante porque ayuda a las empresas a generar tráfico, confianza en los
 consumidores y aumentar las conversiones.
• Toda la estrategia de marketing digital, de medios y contenidos, debe ser la apropiada para cada
 una de las etapas de la ruta de compra del cliente; buscando pasar del reconocimiento de la
 marca hasta la lealtad hacia ella.
 Francisco Rocca

# Fundamentos de Marketing · Clase de estrategias de marcas v2 2 sem 2023

Fuente: clase de Fundamentos de Marketing

[pág. 1]
Estrategias de Marcas
 Prof: Francisco Rocca

[pág. 2]
¿Que es una marca?
Una Marca es un nombre, un término
, un signo, un símbolo un diseño o una
combinación de ellos que logran una
relación con los consumidores y que
identifica a los productos o servicios
de una empresa y que los diferencia
de la competencia.
Definición de The American Marketing Association

[pág. 3]
Características de las marcas
• Son un activo económico de naturaleza
 intangible (uno de los más importantes
 activos, junto a la cartera de clientes).
• Son un componente crítico para lo que la
 empresa representa.
• Implica un grupo de promesas al cliente:
 confianza, consistencia y expectativas.
• Las marcas fuertes, tienen un
 posicionamiento en la mente del
 consumidor que puede ser descrito por
 todos (aunque no sea consumidor de ella).

[pág. 4]
La marca como elemento estratégico
• El manejo de la marca es estratégico, más que un grupo
 aislado de actividades.
• El manejo de la marca es central para crear valor para el
 cliente, no sólo una imagen.
• El manejo de la marca es una herramienta clave para crear y
 mantener ventajas competitivas.
• Las estrategias de marca deben ser construidas dentro del mix
 comercial.

[pág. 5]
¿POR QUE CONSTRUIR MARCA ES TAN
 IMPORTANTE?

[pág. 6]
• Son parte importante del
 Valor Económico de una
 Compañía.
• Maximizan la creación de
 valor a los accionistas vía
 capitalizar el valor que se es
 capaz de entregar a los
 clientes.

[pág. 7]
143,2 billions

[pág. 8]
Financial Times

[pág. 9]
El valor de la marca

[pág. 10]
Que es Valor de Marca?
• El Valor de Marca es un activo
 de las empresas.
• Ese activo hay que hacerlo
 crecer tanto en el consumidor
 como en el comprador.

[pág. 11]
El camino emocional del consumidor
 A MAYOR AMOR POR LA MARCA..
 LOYAL Que me Amen
 Que me Quieran
 LOVE
 Que me conozcan
 LIKE y les guste
 Que sepan que
 AWARNESS existo
+Disposición a Pagar
+ Lealtad
+ Recomendación y Protección
+Frecuencia de consumo

[pág. 12]
Que es el Valor de Marca?
Es el valor agregado entregado por la marca, a los
productos o servicios de una empresa que son
reflejado en la forma en que los consumidores ,
piensan , sienten y actúan respecto de una marca
determinada.

[pág. 13]
¿Como construimos amor y valor de marca?
• Desarrollando contenidos para
 el segmento de la marca.
• Teniendo un adecuado
 posicionamiento de la marca.
• Tener una adecuada
 arquitectura de marca.
• Desarrollar una adecuada
 comunicación de marca.

[pág. 14]
El valor de una marca
 “Es un conjunto de activos y pasivos,
relativos a la lealtad de marca, el reconocimiento
 recordación, la calidad percibida y las
 asociaciones de marca”
 (AAKER)
 “Es el efecto diferencial que el conocimiento
 de marca ejerce sobre la respuesta del
 consumidor al marketing de esa marca”
 (KELLER)

[pág. 15]
Componentes del valor de marca según David Aaker
 La capacidad que tiene una marca de ser reconocida por
 consumidores potenciales y que sea correctamente
 1 asociada con sus productos.
 Conocimiento Se refiere a la percepción de los consumidores sobre la
 de la Marca. calidad global de la marca. Es decir, la evaluación del
 Calidad rendimiento de ciertos factores de la marca que son
 Percibida. 2
 importantes para ellos y comparados con la competencia.
 Por lo tanto, una razón de compra muy importante
 David Asociación Las imágenes o símbolos que los consumidores asocian con
 de Marca 3
 Aaker una marca o un beneficio por ej la manzana de Apple.
 Proveen de una diferenciación difícilmente copiable.
 Se refiere a la fidelidad de los consumidores lo que se
 Lealtad de 4 traduce en menores costos de marketing , atrae a nuevos
 Marca.
 consumidores y nos permite un apalancamiento comercial
 Otros Activos para otras áreas de negocio.
 de la Marca.
 5 Patentes , marcas registradas, que ayudan a colocar
 barreras de entrada y mantener la ventaja competitiva

[pág. 16]
Componentes del valor de marca que producen
 valor
 Valor al consumidor
 • Facilita la interpretación y procesamiento
 de la información.
 • Le da seguridad a la decisión de compra.
 • Le proporciona mayor satisfacción de uso.
 Valor para la empresa.
 • Da mayor eficiencia y efectividad en los
 planes de marketing.
 • Mayores precios y márgenes.
 • Permite realizar extensiones de marca.
 • Permite diferenciarse frente a los canales
 • Le da una ventaja competitiva sostenible.

[pág. 17]
FIDELIDAD/LEALTAD
 ¿Cómo crea Valor?
 • Reduce los costos de
 Marketing.
 • Atrae nuevos clientes.
 • Aumenta el valor presente de
 los clientes: mejores precios,
 repetición compra, etc.
 • Tiempo para responder a la
 competencia

[pág. 18]
CONOCIMIENTO
¿Cómo Crea Valor?
 • Ancla que une asociaciones
 • Familiaridad y agrado
 • Compromiso
 • Primer paso para considerar la
 marca

[pág. 19]
CALIDAD PERCIBIDA
¿Cómo Crea Valor?
 • Razón de compra cuando no
 existe toda la información.
 • Diferenciación.
 • Interés por el detallista
 • Extensiones de marca.
 • Precio Premium, dispuesto a
 pagas más

[pág. 20]
ASOCIACIONES
¿Cómo crea Valor?
 • Ayuda al proceso de
 información.
 • Razón de compra
 • Crea sentimientos positivos
 • Extensiones

[pág. 21]
MIDIENDO EL VALOR DE MARCA

[pág. 22]
15 top brands 2022

[pág. 24]
El Método Interbrand
 Método Interbrand de Valoración
 mercado, estabilidad,
 Análisis Análisis Análisis
 Análisis liderazgo, tendencia, apoyo
 Análisis Análisis
 Financiero del de
 dela
 lamarca
 Financiero delmercado
 mercado marca
 publicitario, extensión
 geográfica y protección
 Proyección legal.
 Proyección Papel
 Papel Fuerza
 Fuerza
 Ganancias
 Ganancias de
 dela
 la Esencia
 Esencia
 (EVA)
 (EVA) Marca Marca
 Marca Marca
Tipo de Marca %
 Ganancias
 Ganancias Tasa
 Tasa
 de
 deMarca de
 Marca deRiesgo
 Riesgo
 (BVA)
 (BVA)
Marca Líder Internacional 70 +
Marca Internacional Fuerte 50 -70
Marca Líder Nacional 50 -65 Valor
 Valorde
 deMarca
 Marca
Marca Fuerte Nacional 40 -50
Marca Promedio 30 -40
Marca bajo promedio bajo 30
 Dimensiones de Máximo
 Significado Marca A Marca B Marca C
 Medición Puntaje
 Mercado Vulnerabilidad a los cambios de la demanda debido a nuevos gustos y tecnologías. 10 7 6 8
 Estabilidad Habilidad para mantener una franquicia de consumo. 15 11 10 7
 Liderazgo Habilidad para influir el mercado. 25 18 19 9
 Internacionalidad Marca global, cross cultural - nacional. 25 17 5 2
 Tendencia Atractivo para el consumidor de largo plazo. 10 6 6 7
 Soporte Fortaleza de la comunicación. 10 8 7 7
 Protección Seguridad para proteger los aspectos legales y/o derechos de los dueños. 5 5 3 4
 Total 100 72 56 44

[pág. 26]
Estrategias de marcas
 Formas de Potenciar la Marca
 NUEVOS POTENCIAR
 FRANCHISING
 SEGMENTOS LA MARCA
EXTENSION DE LINEA
 EN LA MISMA ESTIRAR LA MARCA
 CATEGORÍA
EXTENSION EN OTRAS
 LINEAS O OTRAS CO BRANDING
 CATEGORIAS

[pág. 27]
Extensión de línea en la misma Categoría
• Extender la línea significa que la empresa añada productos
 adicionales en la misma categoría y con la misma marca.

[pág. 28]
Extensión en otras líneas o categorías
• Llevar la marca a una categoría distinta o industria diferente.

[pág. 29]
Estirar la marca hacia arriba o hacia abajo
• Crear modificaciones a la marcas para llegar a un mercado mas
 premium o de menor valor.

[pág. 30]
Beneficios de una extensión de marca
• Capitaliza el principal activo de la • Facilita la distribución con los canales
 empresa, que es su marca. (ya hay una relación) y con ello la
• Mejora la imagen de marca si la prueba por parte de los clientes
 categoría en la que extiende sea afín. • Menores costos de introducción y de
• Reduce el riesgo percibido por los los programas de seguimiento
 consumidores (ya que se traspasa el • Eficiencias en los proceso de empaque
 capital de marca), especialmente en y etiquetado
 productos nuevos. • Hace más eficiente el gasto
• Comunicación inmediata de beneficios promocional
 (sólo a través de la marca). • Evita el costo de desarrollar una nueva
• Crea oportunidades para vender en marca
 otras categorías. • Menor riesgo de lanzamiento

[pág. 31]
Riesgos de una extensión de marca
• Puede diluir el significado de la marca • Puede tener éxito pero disminuir la
 madre. identificación con alguna categoría.
• Un fracaso del nuevo producto o • Puede tener éxito pero puede
 servicio puede dañar la marca madre . canibalizar las ventas de la marca
• Puede confundir o frustrar a los madre.
 consumidores. • Puede eliminar la opción de
• Puede dañar la credibilidad de la desarrollar una nueva marca.
 empresa.
• Puede encontrarse con resistencia en
 los canales de distribución.

[pág. 32]
¿Extensiones Posibles?
Scotch (pegamentos)?
Nestlé (cerveza) ?
Disney (jardínes Infantiles)?
Haagen-Dazs (chocolate )?
Heineken (pop corn)?
Colgate (Chicles)?
Fisher-Price (shampoo para guaguas)?
Braun (afeitadoras desechables)?

[pág. 33]
Cobranding
• Definición:
 – Es cuando se juntan las fuerzas de dos marcas para ofrecer
 un producto o servicio en conjunto. Normalmente los
 productos de cada una de las marcas son complementarios .

[pág. 34]
Cobranding
• ¿Quién nos puede aportar asociaciones complementarias?
• ¿Qué asociaciones de marca son débiles?
• ¿Quién tiene esas asociaciones fuertes?
• ¿Cómo se benefician ambas marcas? ¿qué aporta cada uno?
 – Ej.: Mastercard-Banco Santander-Lan Chile
 – Ej.: Nestlé con Disney,

[pág. 35]
Franquicia de Marca
• Una franquicia de marca es un modelo de negocio en el que
 una empresa (franquiciadora) otorga a un tercero
 (franquiciado) el derecho de operar un negocio bajo su marca,
 utilizando sus sistemas, procesos y soporte, a cambio de un
 pago fijo (fee) o pagos mensuales (% sobre las ventas) y a
 veces, una inversión inicial

[pág. 36]
La Identidad de marca
 Personalidad
 ¿Cuál es el estilo personal y único de
 la marca?
 Valores
 ¿Qué valores centrales del consumidor están
 siendo asociados a la marca
 Premios Emocionales
 ¿Cómo se siente el consumidor al interactuar con la marca?
 Beneficios Funcionales
 ¿Qué es lo que los atributos harán por el consumidor?
 Atributos
 ¿Cuales son los atributos tangibles, medibles que diferencian al
 producto/servicio?

[pág. 38]
Arquitectura de Marca

[pág. 39]
Como se organizan las marcas

[pág. 40]
Branded House
Una única marca para todas
las necesidades.
• Este modelo se basa en usar una
 única marca corporativa a nivel
 de toda la compañía y sus líneas
 de negocios. Incluye todos los
 servicios y productos que
 comercializa la empresa. En
 resumen, en este modelo hay
 una única marca que identifica a
 la corporación: la marca madre.

[pág. 41]
House of Brands
Una marca para cada estrategia.
• La arquitectura de marca
 independiente es el modelo que
 más se aleja de la marca madre. En
 este modelo se generan marcas con
 baja o nula relación con la marca
 principal. De manera que cada
 marca cuenta con unos recursos y
 una propuesta de valor propia.
• Con este modelo se pueden atender
 varios nichos del mercado.

[pág. 42]
Híbridas
• La arquitectura de marca híbrida
 es un agregado de los modelos
 anteriores, más allá de un
 modelo particular. Como su
 nombre lo dice, es un modelo de
 marcas que se basa en diferentes
 modelos de arquitectura que se
 usan simultáneamente en las
 diferentes líneas de negocio.

[pág. 43]
Marcas Endosadas
La arquitectura de marca endosada
es una combinación de las marcas
de la empresa o del producto a
través del apoyo de la marca
corporativa. Es un apoyo explícito
que se beneficia de la imagen, la
confianza, la habilidad y la
capacidad que tiene la marca
corporativa.

[pág. 44]
Branding en la era digital

[pág. 45]
Digitalización de los procesos de compra..

[pág. 46]
Lograr que los consumidores
conecten con la marcas cuando
realmente les interese

[pág. 47]
El posicionamiento sigue siendo un factor estratégico fundamental.

[pág. 48]
De la comunicación unidireccional de la marca
cambiamos al dialogo con la marca

[pág. 49]
Las estrategias de marca deben ser
coherentes en todos los puntos de
contacto.

[pág. 50]
Resumen
• El manejo de las marcas es una herramienta para crear y mantener
 ventajas competitivas.
• Las marcas se crean en la mente del consumidor.
• Los consumidores no compran productos compran marcas.
• Las marcas crean valor a las compañía y las marcas tienen valor en si
 misma.
• Las marcas son el activo mas valioso que tienen las empresas.
• El desarrollo de las marcas es un proceso de negocios que debe ser
 estratégicamente integrado a toda la organización .
• Existen estrategias para hacer crecer el patrimonio de las marcas.

# Fundamentos de Marketing · Clase de Repaso Prueba 1

Fuente: clase de repaso

[pág. 1]
Clase de Repaso Prueba 1
12/9/23
FRANCISCO ROCCA

[pág. 2]
Pregunta teléfonos móviles plegables
¿Que se busca?
Identificar la etapa del camino de compra y que sucede con el consumidor en la etapa.
Como influir al comprador en cada etapa con diferentes acciones que podamos realizar
Uso post-compra y evaluación
Proceso de compra
Decisión de elección
Evaluación de alternativas
Búsqueda de información
Reconocimiento del problema
En esta etapa podemos influir con la creación de artículos sobre el nuevo Find N2 Flip , comunicar experiencias positivas de clientes que usan la marca, Webchat, contar con múltiples y variadas ofertas, campañas con influencers, participar de eventos presenciales donde esté la generación Z, etc. Lo anterior, permitirá educar al consumidor, y aumentar su confianza en OPPO.
En este momento el consumidor selecciona una marca para comprar es el el momento de la compra. En esta etapa es necesario crear en el cliente un sentido de urgencia a fin de gatillar la compra.
Los consumidores suman o restan marcas a medida que evalúan lo que quieren. En esta etapa debemos hacerle llegar al consumidor la mayor cantidad de información posible para que elija nuestro producto en el momento de la compra.
Campaña de mailing personalizado, campaña de marketing directo, diferentes formas y medios de pago, ofertas llamativas e imperdibles, alianza con distribuidores donde compre la generación Z, etc. Lo anterior, permitirá que el consumidor sienta la necesidad de concretar la compra del celular.
Reconocimiento del problema y búsqueda de información, el consumidor considera un conjunto inicial de marcas, basado en la percepción de marca y la exposición a los puntos de contactos recientes. 
En esta etapa tenemos que llamar la atención del consumidor, para ello debemos despertar el interés y la curiosidad.
Posibles acciones e intervenciones: comunicaciones en las redes sociales, en las páginas web, en medios tradicionales, email marketing, social ads, etc. Lo anterior, permitirá al consumidor generar un set inicial de posibles alternativas.
Después de comprar el consumidor genera expectativas basadas en la experiencia para informar el próximo viaje de decisión. En esta etapa necesitamos el feedback del cliente y conseguir fidelizarlo.
Encuestas de satisfacción, programa de fidelización, videos con recomendaciones y líderes de opinión usando el celular, etc. Lo anterior, permitirá conocer la experiencia del consumidor y generar lealtad en nuestra cartera de clientes.
FRANCISCO ROCCA

[pág. 3]
Pregunta Google Vs Bing
¿Que es lo que se espera que contesten ?
¿Microsoft es una empresa centrada en el cliente?
Si lo es, ya que desarrolló competencias para entender las necesidades insatisfechas de sus clientes en cuanto a la búsqueda en internet por lo cual invirtió y desarrolló en OpenAI para agregar esta nueva funcionalidad de Bing.
¿Como Bing obtuvo información relevante para construir el New Bing? 
Primero la base de datos interna de Bing ,en que maneja datos de duración en su buscador, frecuencia de uso, cambios a otros buscadores, fidelidad a su buscador, etc., con lo cual puede construir un perfil de sus clientes como también los de su competencia que es Google y hacer un análisis de la segmentación de los usuarios de los buscadores y ver los comportamientos de cada segmento. 

Estudios Cualitativos, Microsoft podría haber explorado nuevos servicios o factores clave para la satisfacción del usuario, generando hipótesis sobre cuáles podrían ser las frustraciones, aprehensiones y beneficios buscados por los usuarios. También podría haber hecho estudios de observación como son los estudios netnográficos, para buscar insights  sobre las necesidades, conductas, percepciones de los consumidores, para así identificar tendencias y necesidades no cubiertas, durante la navegación en Bing.

Estudios  Cuantitativos, podría haber descrito y determinado características de distintos grupos de usuarios de los motores de búsqueda, cuantificado su tamaño (están aspirando a tomar usuarios de Google), identificar las diferencias en percepciones y conductas, atributos valorados, mediante muestras aleatorias de una población de usuario y no usuarios de los motores de búsqueda.  Asimismo, después de cada sesión de búsqueda podría haber hecho una encuesta aleatoria de satisfacción (ej. Le sirvió esta información) de una muestra de clientes de distintos segmentos, o bien recibir feedback de parte de éstos en cuanto a la facilidad de uso, la rapidez, las mejoras que se le podrían hacer en el buscador Bing.
FRANCISCO ROCCA

[pág. 4]
Preguntas Pintura Bonita
¿A que apunta el caso y las preguntas?
Validar o no la estrategia planteada por el gerente de marketing y ver la posición competitiva de Pintura bonita
Lo primero que hay que hacer es ver como esta conformado el mercado de las pinturas para ver la posición competitiva de la empresa.
El caso nos dice que :
Tamaño del mercado es de U$80 millones
La Región Metropolitana representa un 60% de la venta, mientras que la zona sur sólo un 40%
El segmento hogar representa el 70% de la venta en la Región Metropolitana y un 90% en la zona sur
La Región Metropolitana exhibe un pequeño crecimiento mientras que la zona sur crece rápidamente
FRANCISCO ROCCA

[pág. 5]
Que nos dicen las cifras?
A primera vista el segmento hogar (versus el profesional) o el segmento Región Metropolitana (versus la zona sur) ofrecen un atractivo mayor dado su tamaño.
El volumen del segmento hogar está probablemente un poco exagerado dado que el 50% del volumen en el segmento hogar Región Metropolitana es capturado por las marcas de las grandes tiendas, las cuales tienen como ventaja competitiva el precio. 
(Información del caso” las principales cadenas ferreteras controlaban el 50% del mercado de pinturas en la Región Metropolitana y se esperaba que su participación siguiera creciendo en el futuro)
El tamaño del segmento de mercado hogar/región Metropolitana sin las cadenas ferreteras  es de U$16,8 millones, o cercano a los U$14,4 millones del segmento profesional urbano
¿Es este el segmento potencial para Pintura Bonita?
Mercado Total
FRANCISCO ROCCA

[pág. 6]
¿Que nos dicen las cifras de Pintura Bonita?
Las ventas de Pintura Bonita están distribuidas de igual forma entre la Región Metropolitana y la zona sur
La Región Metropolitana representa un 50% de las ventas
Un 70% de las ventas de Pintura Bonita en la Región Metropolitana fueron hacia los profesionales y 30% al segmento hogar o los compradores del tipo “do it yourself”
Un 70% de las ventas en la zona sur fueron dirigidas al segmento hogar mientras que un 30% al segmento profesional
Pintura Bonita captura el 15% total del mercado. Sin embargo, la participación de mercado es muy distinta en cada segmento. Pintura Bonita cuenta con un:
34% del mercado de profesionales
18,75% del mercado de la zona sur
56,3% del mercado profesional/Región Metropolitana
10,7% del mercado hogar/Región Metropolitana
FRANCISCO ROCCA

[pág. 7]
La estrategia comercial propuesta por el Gerente de Marketing consistía en dirigir los esfuerzos al segmento hogar en la Región Metropolitana, ya que era el segmento con el mayor tamaño de mercado y en donde la empresa tenía la menor participación de mercado en relación al resto de los segmentos. Es la correcta? Por que ?
El segmento de mercado menos atractivo para Pintura Bonita es el Segmento Hogar/Región Metropolitana (aún cuando es el más grande). Las razones son las siguientes:
Mercado de la RM no muestra crecimiento
Pintura Bonita es una pintura premium que apunta al segmento profesional
En la RM las grandes cadenas distribuidores (Sodimac, Easy y Construmart) están creciendo a través de la compra de las ferreterías independientes. Es de esperar que estas cadenas aumentan su participación de mercado a costa de las ferreterías independientes
Pintura Bonita no tiene presencia en las grandes cadenas, las cuales ofrecen la marca de precio y la marca propia.
La participación de mercado de Pintura Bonita debiera ir cayendo en el tiempo.
¿Dónde debería priorizar sus esfuerzos Pintura Bonita en el corto plazo?
Zona Sur/Hogar
La zona sur está creciendo a una tasa anual del 20% anual durante los próximos 5 años
La participación de Pintura Bonita es del 14,6% (hay espacio para crecer sobre todo antes de que aparezcan las grandes cadenas de distribución)
No existen grandes cadenas en la zona sur, sólo ferreterías independientes
Pintura Bonita no tiene competencia en este mercado de otras marcas
FRANCISCO ROCCA

[pág. 8]
La estrategia comercial propuesta por el Gerente de Marketing consistía en dirigir los esfuerzos al segmento hogar en la Región Metropolitana, ya que era el segmento con el mayor tamaño de mercado y en donde la empresa tenía la menor participación de mercado en relación al resto de los segmentos. Es la correcta?
¿Dónde debería priorizar sus esfuerzos Pintura Bonita en el largo plazo?
RM y Zona Sur/Profesional
El mercado donde mejor encaja la marca es en el mercado profesional (de acuerdo a la conducta de compra de los clientes)
Aun cuando la RM no está creciendo, la empresa puede aumentar la penetración en el mercado profesional (actualmente tiene un 29% de participación)
La zona sur está creciendo a una tasa anual del 20% anual durante los próximos 5 años, sin embargo, el mercado profesional es pequeño (sólo $3,2 millones) y Pintura Bonita cuenta con una participación del 56,3%. Aquí lo que debiera hacer Pintura Bonita es defender su participación de mercado.
En el largo plazo debiera focalizarse en este mercado (es esperable que aparezcan marcas competidoras y grandes distribuidores en la zona sur).
FRANCISCO ROCCA

[pág. 9]
¿Cuales son los cambios del modelo de negocios ?
Item modelo de negocios | Antes : con local físico+ Quinoa para llevar | Despues : Solo delivery via Dark Kitchen
Segmentos | Apunta a dos segmentos: personas que valoran la experiencia de salir a comer a un local y además las personas que quieren pedir delivery a sus casas. | Ahora apuntaría a un solo segmento, el que pide delivery a su casa. 
Propuesta de valor | Propuesta de valor para ambos segmentos descritos arriba. | Propuesta solo para personas que quieren delivery.
Estructura de costos | Costos altos asociados al local físico y además al sector habilitado para delivery “Quinoa para llevar” | Estructura de costos más liviana porque solo depende de las dark kitchens. OJO que ya tenía el local, no es partir de cero, podría no vender las cosas del restaurant físico.
Flujos de ingresos | Recibe de dos fuentes: local y delivery. Puede complementar ambas cosas y dividir el riesgo. | Se concentrará en una sola fuente de ingreso, el que viene de delivery. Puede diversificar a través de distintas apps.
Alianzas clave | Apps de delivery
Arrendador del lugar estratégico donde está ubicado. | Apps de delivery, pero aumenta el poder de negociación de éstas porque dependerá en un alto % de ellas (supuesto).
Proveedor de dark kitchens.
Recursos clave | Equipo de cocina, ingredientes, recetas.
Lugar con decoración, flores, etc.
Limpieza del local. | Equipo de cocina, ingredientes, recetas.
FRANCISCO ROCCA

[pág. 10]
Esta correcto el camino definido por Pasta Comino?
Desde el punto de vista de creación de valor a sus clientes, no debería seguir la propuesta de Pasta Comino por las siguientes razones:
Ya tiene un local exitoso, con una propuesta de valor valorada por su segmento de clientes. Se llena a la hora de almuerzo y en la tarde, y genera utilidades. ¿Por qué cerrarlo?.
Los mismos clientes que van presencial son los principales promotores del restaurant porque valoran la propuesta de valor entregada en formato presencial; y pueden atraer nuevos clientes para el local físico o delivery.
Tiene segmentos definidos y propuesta de valor para ambos (los que valoran ir presencial y los que quieren pedir por delivery), por lo que podría profundizar en entender y mejorar la experiencia de cada uno, pero cerrar podría ser anticipado y riesgoso desilusionando a un segmento importante.
El segmento que va presencial no necesariamente de trasladará a cliente de servicio delivery porque valoran cosas diferentes y tienen necesidades distintas. Puede significar perder a este segmento que se irá con la competencia.
Contar solo con un servicio de delivery a través de una dark kitchen puede debilitar la propuesta de valor de Quinoa si existen segmentos que se crucen, por ejemplo, que prefieren probar primero presencial y luego piden delivery, o viceversa.
FRANCISCO ROCCA

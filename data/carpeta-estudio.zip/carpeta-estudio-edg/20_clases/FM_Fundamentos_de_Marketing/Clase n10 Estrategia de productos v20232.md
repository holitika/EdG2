# Fundamentos de Marketing · Clase n10 Estrategia de productos v20232

Fuente: clase de Fundamentos de Marketing

[pág. 1]
ESTRATEGIAS DE PRODUCTO
 Prof: Francisco Rocca
 Francisco Rocca

[pág. 2]
¿Qué es un producto?
• Producto es lo que se ofrece al mercado para su,
 adquisición, uso o consumo, y que satisface una
 necesidad.
• Los productos no solo son bienes tangibles, también
 incluyen, los servicios, personas, lugares,
 organizaciones, ideas o mezclas de ellos.
 Francisco Rocca

[pág. 3]
De los productos a las marcas
Producto es un conjunto de atributos y de beneficios
valorados por las personas porque satisfacen una o más
necesidades
 Territorio de los Productos Territorio de las Marcas
 Funcional y Emocional e
 Tangible Intangible
 Hidrata, entrega Me hace sentir bien, me
 carbohidratos de siento Re-energizado,
 rápida asimilación y Disfruto
 aporta electrolitos
 Francisco Rocca

[pág. 4]
Conceptos claves en la estrategia de productos
 1 2 3
 Portafolio de
 El producto Ampliado. Ciclo de vida del
 productos y servicios
 producto
• Desarrollo e innovación de • Propuesta de valor • Etapas del ciclo de vida
 productos. • Experiencias • Ciclo en las innovaciones
• Políticas de productos : Gestión • Servicios tecnológicas
 de portafolio . .
• Ampliación de la categoría
• Extensiones de línea
 Francisco Rocca

[pág. 5]
Desarrollo e innovación de productos nuevos
 Francisco Rocca

[pág. 6]
¿Por que creen ustedes que las empresas
 desarrollan nuevos productos?
 Francisco Rocca

[pág. 7]
5 factores de difusión/comunicación de una innovación
 de acuerdo a Everett M. Rogers
1. Ventaja Relativa . El grado de diferencia que lo hace mejor que otras alternativas que
 satisfacen mismas necesidades. (ahorro en costos, tiempo, menor esfuerzo, etc.) sin
 embargo también podría ser en base beneficios subjetivos como el status y el prestigio.
2. Facilidad de Prueba. El grado en que una innovación pueda ser probada por los clientes
 en forma directa.
3. Observabilidad . El grado en que una innovación o sus impactos pueden ser vistos por
 otros que los puedan adoptar. Si potenciales adoptantes no ven que sus pares la usan
 será más difícil que la adopten .
4. Compatibilidad. El grado en que la innovación es consistente con valores existentes,
 experiencias pasadas y las necesidades de los potenciales usuarios.
5. Complejidad. El grado en que la innovación es vista como compleja de entender o de usar
 FACILIDAD DE ADOPCIÓN
 Francisco Rocca

[pág. 8]
Ejemplo: Kindle de Amazon
• Ventaja Relativa: Dado que trata de reemplazar al libro físico, tiene
 muchas ventajas (menor espacio, más liviano, fácil portabilidad de
 muchos libros, etc.
• Facilidad de prueba: Fácil de utilizar.
• Observabilidad: Existen muchos dando vueltas.
• Compatibilidad: Absolutamente compatible con la forma de lectura.
• Complejidad: Fácil de usar y de entender cómo comprar libros.
Dados estos factores, podemos decir que estamos frente a un
producto de rápida adopción.
 Francisco Rocca

[pág. 9]
Proceso de decisión de lanzamiento de
productos nuevos
 Decisión de Decisión de Decisión Decisión de Revisión Post-
 Continuar Desarrollo de Lanzar Producir Lanzamiento
 Valorar si la Evaluar el Desarrollar y Preparar el Ejecutar u
 idea es potencial evaluar la lanzamiento ajustar la idea
 realizable y estratégico de idea de acuerdo a
 si el fit la idea antes la respuesta
 estratégico de asignar del mercado.
 de la idea recursos.
 corresponde
 .
 Francisco Rocca

[pág. 10]
Espectro de productos nuevos
 Alta
 Nuevas Categorías Productos
 totalmente nuevos
Novedad para la empresa
 Reducción de
 costos
 Extensión de líneas
 Mejoras a productos Reposicionamiento
 existentes
 Francisco Rocca Alta
 Novedad para el mercado

[pág. 11]
Tipos de productos nuevos
1. Nueva categoría
2. Extensión de línea
3. Mejora a productos
 existentes
4. Reposicionamiento
5. Reducción de costos
6. Producto totalmente nuevo
 Francisco Rocca

[pág. 12]
Nuevas categorías
• Las categorías son grupos de productos
 formados por ítems complementarios o
 sustitutos para satisfacer las
 necesidades del consumidor.
 – Por ejemplo, la categoría de higiene se
 compone por productos como
 acondicionadores, jabones, hidratantes, entre
 otros.
• Un ejemplo de nuevo producto en nueva
 categoría es cuando Falabella, empresa
 de retail, decide entrar a la categoría de
 bancos y entidades financieras.
• Cirque du Solei fue ambicioso y creó una
 nueva categoría en el mundo de la
 entretención: circo para adultos, sin
 animales, caro como una obra de teatro.
 Francisco Rocca

[pág. 13]
Extensión de línea
• Una extensión de línea,
 consiste en añadir nuevos
 productos dentro de la misma
 categoría y bajo la misma
 marca. Esto es, añadir nuevos
 sabores, presentaciones, formas,
 colores o nuevos atributos.
 – Dove: Las diferentes
 presentaciones, tamaños y colores
 de los productos Dove para aseo
 personal.
 Francisco Rocca

[pág. 14]
Extensión de línea
• Una adición a una línea,
 consiste en añadir nuevos
 productos dentro de la misma
 categoría y bajo la misma marca,
 pero a un segmento distinto.
 – Dove: Lanzamiento de productos de
 limpieza para hombres.
 Francisco Rocca

[pág. 15]
Mejoras a productos existentes
• Mejoras a un producto de
 nuestro portafolio, buscando
 mejorar la experiencia, aumentar
 propuesta de valor y mejorar
 nuestras ventajas competitivas,
 o copiar a la competencia.
 – Samsung: refrigerador con
 dispensador automático de agua
 con gas.
 Francisco Rocca

[pág. 16]
Reposicionamiento
• Los productos mantienen sus
 características físicas
 similares, pero ofrecen distinta
 imagen o percepción para el
 consumidor.
• ¿Qué quiere transmitir Coca
 Cola con su cambio de
 imagen para la Coca Cola
 Zero?
 Francisco Rocca

[pág. 17]
Reducción de costos
• La reducción de costos es el
 proceso utilizado por las
 empresas para reducir sus
 costos y aumentar sus
 ganancias.
• Dependiendo de los servicios o
 productos de una compañía, las
 estrategias pueden variar. Cada
 decisión en el proceso de
 desarrollo del producto afecta el
 costo.
 Francisco Rocca

[pág. 18]
Producto totalmente nuevo
• Producto realmente
 innovador que se presenta
 por primera vez.
• Innovación de producto.
 Es una novedad tanto
 para el mercado como
 para la empresa.
 Francisco Rocca

[pág. 19]
Por que fracasan los productos nuevos
 Francisco Rocca

[pág. 20]
Algunos fracasos icónicos
 Francisco Rocca

[pág. 21]
Por que tienen éxito los productos nuevos
• Entienden el comportamiento del consumidor y proceso
 de decisión de compra de éste.
• Entienden las necesidades y deseos de los
 consumidores.
• Saben la sensibilidad que tienen los consumidores al
 precio.
• Tienen un buen sistema de investigación de mercado que
 permite identificar las necesidades de cada tipo de
 consumidor.
 Francisco Rocca

[pág. 22]
Por que tienen éxito los productos nuevos
• Entregan una buena publicidad, promoción, canales de
 distribución y apoyo del personal de venta al mercado
 objetivo.
• Unen el desarrollo de nuevos productos a los objetivos
 corporativos de la empresa.
• Coordinan muy bien las funciones de investigación y
 desarrollo y marketing de manera de asegurar que el
 producto desarrollado satisfaga las necesidades de los
 consumidores.
 Francisco Rocca

[pág. 23]
Política de productos: Administración del
 portafolio de productos
 Francisco Rocca

[pág. 24]
Decisiones claves de una empresa sobre la política de
 productos
1. La amplitud de productos.
 – Número de categorías de productos que comercializa una
 empresa.
2. Longitud de productos.
 – Número total de productos que se comercializan
3. Profundidad de productos.
 – Número de variaciones de cada producto de la categoría. (SKU)
4. El diseño de elementos del producto.
 – Se refiere a las especificaciones de diseño de producto.
 Francisco Rocca

[pág. 25]
Ej.: Cartera de productos Unilever
 Francisco Rocca

[pág. 26]
En que circunstancias las empresas deciden ampliar la
 cantidad de categorías
Cuando el flujo de ganancias
probablemente se correlaciona
negativamente con el flujo de
ganancia de los negocios ya
existentes. Aprovechar un activo clave de
 le empresa que es la base de
 la oferta actual de productos.
 AMPLITUD
 Aprovechar los productos que se
 complementan en su uso y
 permitir así que la empresa sea un
 proveedor de solución integral.
 Francisco Rocca

[pág. 27]
Factores a considerar para ampliar la profundidad de la categoría.
 Heterogeneidad de los consumidores y de las
 01 especificaciones que requiere cada segmento.
 Capacidad de adaptar la oferta al segmento y
 02 que este perciba que el producto fue diseñado
 para ellos.
 Que tenga un impacto competitivo y
 03 que logre una ventaja competitiva.
 PROFUNDIDAD
 DE LA 04 Impacto en el tamaño de la categoría.
 CATEGORÍA
 Impacto sobre los márgenes de la
 05 empresa.
 06 El Patrimonio de la marca.
 07 Reacción del Retail
 Francisco Rocca

[pág. 28]
Estrategias de productos
 Francisco Rocca

[pág. 29]
Estrategias de productos
Estrategia de superposición
• La empresa decide competir con su propia marca.
 – Estrategias Comunes:
 • Promover líneas competidoras
 • Proporcionar marcas privadas.
 • Fabricantes de equipos originales (OEM)
 Francisco Rocca

[pág. 30]
Promover líneas competidoras
 Procter & Gamble (P&G)
 Francisco Rocca

[pág. 31]
Ser proveedor de marcas privadas
 Francisco Rocca

[pág. 32]
Fabricantes de equipos originales (OEM) ORIGINAL
EQUIPMENT MANUFATURES
 Francisco Rocca

[pág. 33]
Extensiones de línea
 Francisco Rocca

[pág. 34]
Extensiones de línea versus extensiones de
 marca
Extensión de línea Extensión de marca
• Estrategia de producto. • Estrategia de marca.
• Lanzar productos dentro de • Lanzar productos en una
 una misma categoría. nueva categoría.
Ej.: Zara expande su línea de Ej.: Zara se expande a la
productos con sección sport, categoría de decoración del
sección formal, sección casual, hogar con “Zara Home”.
etc.
 Francisco Rocca

[pág. 35]
Formas que toman las extensiones de línea
 Francisco Rocca

[pág. 36]
¿Por que las extensiones de línea?
• Necesidades de los consumidores.
• Oportunidades en mercados que el producto tiene poca o
 nula resistencia/competencia.
• Utilización de la capacidad instalada de producción.
• Fortalecer la actual tecnología.
• Minimizar el riesgo financiero por el aumento de ventas.
• Segmentación de consumidores
 Francisco Rocca

[pág. 37]
¿Por que las extensiones de línea?
• Amplitud de productos y precios
• Ganancias de corto plazo
• Intensidad competitiva
• Presiones del comercio.
Se estima que el 80% de los productos nuevos son
extensiones de línea
 Francisco Rocca

[pág. 38]
Problemas y riesgos de las extensiones de línea
• Aumento de los costos de producción
• Se abren oportunidades a la competencia.
• La relación con el comercio se complejiza.
• Ideas de productos subexplotadas (Pequeñas ideas→ Mayor
 riesgo).
• Los productos pueden tener poca relevancia dentro de la
 línea (ya que son muchos)
• Puede existir menor lealtad de marca
• A veces existe estancamiento de la demanda por algunas
 categorías, entonces no tiene sentido crecer en ellas
 Francisco Rocca

[pág. 39]
Directrices para las extensiones de línea
• Mejorar los sistemas de medición de costos.
• Asignar recursos a los productos ganadores.
• Investigar la conducta del consumidor
• Coordinar el marketing de la línea de productos.
• Proyección de la venta de la línea de productos.
• Comprender los costos y beneficios incrementales de los nuevos productos
• Coordinar el marketing mix de la línea de productos (consistencia entre cada
 uno)
• Trabajar en conjunto con los canales para lograr su apoyo al lanzar los
 nuevos productos
• Administrar la eliminación de productos dentro de la línea
 Francisco Rocca

[pág. 40]
Consideraciones para las decisiones de extensión
 de líneas de producto.
1. Nivel en el que el nuevo producto es un sustituto parcial
 de los actuales,
 – Hay que considerar los efectos de canibalización.
2. Nivel en el que el nuevo producto es complementario
 con los actuales.
 – Considerar efectos positivos (ventas adicionales).
3. Costo del status quo (costo de oportunidad), el que se
 produce al dejar abierta la posibilidad de que otra
 empresa introduzca este nuevo producto.
 Francisco Rocca

[pág. 41]
Implicancias financieras de una extensión de línea
 Impacto en las
 utilidades
 Costos Costo de
 Impacto en Impacto de la
 Impacto de la incrementales de Oportunidad
 productos venta de productos
 canibalización. la extensión de
complementarios nuevos.
 línea.
 Volumen nuevo Volumen Costos por Pérdida por no
 Volumen x MCc
 x MCn canibalizado extender la hacer nada
 MCc Margen de
 MCn Volumen x (MCn- línea de (competencia
 contribución del
 Margen de Mce) productos). podría hacerlo)
 producto
 contribución del Margen de No es gratis la
 complementario
 producto nuevo contribución del extensión de
 producto existente producto
 Francisco Rocca

[pág. 42]
Concepto de producto ampliado
 Producto
Todo lo ampliado y transformado que
puede ser el producto en el futuro:
 Potencial:
experiencia de servicio, de uso, de Experiencias
desecho.
(asesoramiento, servicio post venta, Producto
confianza, anticipación, agilidad, Consiste en el set de atributos que
cordialidad, etc.)
 Ampliado: Marca y los consumidores esperan cuando
 servicios aceptan comprar el producto:
 marca, complementos, imagen,
 Excede las expectativas de servicios.
 los clientes ofreciendo Producto (contenido, garantías, precio,
 beneficios y atributos que Esperado calidad, variedad de opciones,
 están diseñados para marca, etc.)
 deleitarlos.
 Producto
 Básico Se refiere a los beneficios
 básicos que están siendo
 ofrecidos: atributos
 básicos y tangibles
 Francisco Rocca

[pág. 43]
Ejemplo un Gimnasio
 Producto
SPA, asesoramiento nutricional ,
personalización
 Potencial:
 Experiencias
 Producto
 Ambiente grato, imagen del
 Ampliado: Marca y gimnasio, amplitud de maquinarias
 servicios de ejercicios, amplios horarios
 para el uso, precio adecuado.
 Entrenador personal,
 Seguimiento de los Producto
 progresos obtenidos. Esperado
 .
 Producto
 Básico Membrecía para utilización
 de las instalaciones del
 gimnasio
 Francisco Rocca

[pág. 44]
Nike puede crecer no sólo mejorando o
 sacando nuevas líneas de zapatilla o
 vestuario.
 Nike ha potenciado la experiencia del
 cliente en sus tiendas o con sus
 aplicaciones deportivas.
Francisco Rocca

[pág. 45]
Ciclo de vida de los productos
• Los productos tienen una vida
 limitada.
• Las ventas del producto pasan por
 distintas etapas, cada cual supone
 desafíos diferentes para el
 vendedor.
• Contribuye a hacer una
 planificación estratégica de
 marketing.
• Ayuda a la empresa a identificar
 cuando un producto requiere
 ayuda, rediseño, revigorizar o
 sacarlo del mercado.
 Francisco Rocca

[pág. 46]
Ciclo de vida de los productos
 ? Star Cash Cow Dog
 Madurez
 Ventas
 Tiempo
 Francisco Rocca

[pág. 47]
Ciclo de vida de un producto y objetivos de Marketing
 ? Star Cash Cow Dog
 CREAR CONCIENCIA Y
 Maturity
 PRUEBA DE PRODUCTO.
 Expansión del Mercado.
 Sales
 Producto y Publicidad
 Time
 Francisco Rocca

[pág. 48]
Ciclo de vida de un producto y objetivos de Marketing
 ? Star Cash Cow Dog
 Madurez
 Sales
 AUMENTAR AL MAXIMO
 LA PARTICIPACION DE
 MERCADO.
 Penetrar el Mercado.
 Publicidad y Producto.
 Time
 Francisco Rocca

[pág. 49]
Ciclo de vida de un producto y objetivos de Marketing
 ? Star Cash Cow Dog
 Madurez
 Sales
 AUMENTRA AL MAXIMO
 LA UTILIDAD
 DEFENDIENDO LA
 PARTICIPACION DE
 MERCADO.
 Precio y Publicidad
 Time
 Francisco Rocca

[pág. 50]
Ciclo de vida de un producto y objetivos de Marketing
 ? Star Cash Cow Dog
 REDUCIR GASTOS Y Maturez
 “EXPRIMIR U ORDEÑAR”
 EL PRODUCTO
 Sales
 Productividad.
 Publicidad Moderada
 Time
 Francisco Rocca

[pág. 51]
Algunas características comunes de las
 diferentes etapas.
 INTRODUCCIÓN CRECIMIENTO MADUREZ DECLINACIÓN
 Aumento rápido Caída en
 VENTAS Bajas Ventas Ventas estables
 de las ventas ventas
 Alto Costo por Costo promedio Costo bajo por Costo bajo por
 COSTOS
 Cliente por cliente cliente cliente
 Aumentan Disminuyen
 UTILIDADES Negativas Altas utilidades
 utilidades utilidades
 Primeros en
 CLIENTES Innovadores Mayoría Atrasados
 adaptarlos
COMPETIDORES Pocos Aumentan Estables Disminuyen
 Francisco Rocca

[pág. 52]
Estrategias de Marketing por etapas
 INTRODUCCIÓN CRECIMIENTO MADUREZ DECLINACIÓN
 Ofrecer un Diversificar Eliminar
 Producto
 PRODUCTO producto marcas y productos
 ampliado
 básico modelos débiles
 Usar un plus Precio Precio Rebajar el
 PRECIO
 de costo entrada competencia precio
 Distribución Distribución Distribución Distribución
DISTRIBUCIÓN
 selectiva intensiva más intensiva selectiva
 Crear interés Acentuar
 Crear Retener
PUBLICIDAD en mercado diferencias y
 conciencia clientes leales
 masivo beneficios
 Promoción de Reducir al
PROMOCIÓN Reducir Reducir
 prueba mínimo
 Francisco Rocca

[pág. 53]
Crossing the chasm (Geoffrey Moore)
CRUZANDO EL
ABISMO,
IMPORTANCIA DEL
LANZAMIENTO
PARA QUE SEA
EXITOSO
 Francisco Rocca

[pág. 54]
Ciclo de vida de los Mercados
 ? Star Cash Cow Dog
 Fragmentaciòn
 Ventas
 Tiempo
 Francisco Rocca

[pág. 55]
Concepto integrado
¿Cual es la solución Oportunidades/ ¿Cual es la
 Posicionamiento. Problemas.
 técnica? Como será percibido Que esta pasando
 oportunidad o el
 Cual es el el concepto. en el mercado. problema?
 posicionamiento? Donde será vendido y Cuales son las
 a que precio. oportunidades/
 problemas
 Soluciones
 Técnicas. Necesidades de
 Cuales son las consumidores y clientes.
 características , Cuales son las necesidades
 requerimientos y no cumplidas.
 especificaciones Podemos crear necesidades
 en las oportunidades
 Segmentación. Concepto
 Cuales son los Cual es la proposición para
 segmento que cumplir las necesidades de
 los consumidores
 queremos llegar.
 ¿A quien le va a Hay mercados
 servir? secundarios?
 Por que lo Proposición de Valor a Consumidores ¿Cual es Concepto?
 comprarían? y Clientes.
 Cuales son los beneficio funcionales y
 emocionales. Cual es la promesa, cual es la
 ecuación de valor ganadora
 Francisco Rocca

# Fundamentos de Marketing · Clase N4 Estrat Competitivas y Centralidad en el cliente VA

Fuente: clase de Fundamentos de Marketing

[pág. 1]
Ventaja Competitiva y Centralidad en el Cliente
 Prof: Francisco Javier Rocca
 Profesor: Francisco Rocca J

[pág. 2]
Definición
Una ventaja competitiva es cualquier característica de una
empresa, país o persona que la diferencia de otras colocándole en
una posición relativa superior para competir.
Es decir, cualquier atributo que la haga más competitiva que las
demás empresas y que le permita atraer mas consumidores.
 Profesor: Francisco Rocca J

[pág. 3]
VENTAJAS COMPETITIVAS
 ¿Cómo se logran las
 ventajas
 competitivas?
 Profesor: Francisco Rocca J

[pág. 4]
De dos Maneras….
LIDERAZGO EN COSTOS DIFERENCIACIÓN
 Profesor: Francisco Rocca J

[pág. 5]
Liderazgo en Costos
 Profesor: Francisco Rocca J

[pág. 6]
La Cadena de Valor
 Infraestructura de la Empresa
 Administración de Recursos Humanos
 Desarrollo e Innovación Tecnológica M
SECUNDARIAS
 A
 Abastecimiento R
 G
 Conocimiento del Mercado E
 N
 Operaciones
 Marketing y
 Logística de
 Logística de
 Servicio
 Entrada
 Ventas
 Salida
PRIMARIAS
 Profesor: Francisco Rocca J

[pág. 7]
¿Cuales creen ustedes que son los focos
 primarios para estas empresas?
 INDUSTRIA Logística de Operaciones Logística Marketing Servicio
 Entrada Externa y Ventas
Walmart X X
Restaurant X X X
Apple X X
Coca-Cola X X
Bancos X
 Francisco Rocca

[pág. 8]
¿La reducción de costos trae necesariamente una mejor
 relación de valor?
 Francisco Rocca

[pág. 9]
Como Reducir Costos?
 Francisco Rocca

[pág. 10]
Diferenciación
Profesor: Francisco Rocca J

[pág. 11]
Algunos Factores de Diferenciación
 POR
 ASPECTO O RESULTADOS
 FORMA. . DURABILIDAD. ESTILO.
 1 3 5 7 9
 2 4 6 8
PRECIOS CARACTERISTICAS CALIDAD. CONFIABILIDAD. FACILIDAD EN
 EL SERVICIO
 Profesor: Francisco Rocca J

[pág. 12]
+ = Ventaja Competitiva
 Profesor: Francisco Rocca J

[pág. 13]
Ventaja Competitiva es
 una ventaja o característica, que
una empresa tiene respecto a otras
 empresas competidoras, lo que la
hace diferente y permite atraer más
 consumidores.
 Profesor: Francisco Rocca J

[pág. 14]
Para que exista una ventaja competitiva sostenible se
 requiere que nuestras capacidades sean:
 V R I O
 Valiosas Raras Inimitables o Organizadas para
 no sustituibles agregar valor
 La capacidad La capacidad es La capacidad es La capacidad está
 provee directa y especial, escasa, muy costosa de ser organizada,
 tangiblemente poco común y sólo imitada por mis estructurada, tiene
 beneficios a los es poseída por competidores, y al un equipo y una
 consumidores unos pocos mismo tiempo, línea clara de
(Creación de listas (Experiencia al nadie más puede reporte, tiene
 y seguir a cliente en proveer el mismo procesos,
consumidores con Starbucks) valor (Coca Cola) información,
 gustos similares indicadores, etc.
 Spotify) (innovación en 3M)
 Profesor: Francisco Rocca J

[pág. 15]
La Centralidad en el Cliente
 (“Customer Centricity”)
 Profesor: Francisco Rocca J

[pág. 16]
Definición
• La centralidad en el cliente consiste en alinear el desarrollo y
 entrega de productos o servicios de una empresa con las
 necesidades actuales y futuras de los clientes de manera de
 maximizar el valor financiero o a largo plazo de la empresa.
 Profesor: Francisco Rocca J

[pág. 17]
¿De acuerdo a esta definición ,que empresas creen ustedes
 que son fuertes en la centralidad en el cliente?
 Profesor: Francisco Rocca J

[pág. 18]
Centralidad en el cliente
 Objetivo de la empresa:
Objetivo de la empresa:
 maximizar el valor de los
maximizar el valor de los
 accionistas
accionistas maximizando las
 Buscando la heterogeneidad
utilidades , a través del
 de los clientes, distinguiendo
volumen y las reducciones de
 clientes rentables y los no
costos.
 rentables
 Se focaliza en la rentabilidad
Crecimiento se hace a futura: valor de por vida del
través de extensión de cliente (LTV) por sobre las
 FOCO EN EL FOCO EN
producto y la participación PRODUCTO EL CLIENTE utilidades pasadas
de mercado es el indicador Éxito surge a través de una
clave. mejor adquisición, retención
 y desarrollo de clientes
Estructura de sus Estructura organizacional
organizaciones orientada al centrada en el cliente
producto. Ventaja competitiva:
Ventaja competitiva: expertise en el
expertise en el producto relacionamiento con clientes
 más valiosos

[pág. 19]
¿Como Hacerlo?
• Personalizar las interacciones con los consumidores
• Crear contenidos relevantes y con significado
• Reducir los tiempos de respuesta
• Desarrollo de experiencia omnicanal
• Innovación en productos, servicios y experiencias.
• Priorizar la confianza y transparencia
 Profesor: Francisco Rocca J

[pág. 20]
Los 4 Pilares del Foco en el Cliente
 Capacidad de entender Métricas para evaluar
 Cliente en el centro Alineados con el Cliente
 y predecir conductas la Conducta del
 de las decisiones Interno y externo
 del Cliente Cliente
Cultura Configuración de Sistemas de
 Capacidades Políticas de
Corporativa Información recursos humanos
 CAPITAL DE MARCA
 VALOR PARA Y DEL CLIENTE
 Profesor: Francisco Rocca J

[pág. 21]
1-Cultura Corporativa
 Para ser exitosos en la implementación de una
 estrategia y modelo operacional centrado en el
 cliente, la empresa debe tener una cultura que este alineada y
que sus líderes cultiven esa mentalidad y valores en los empleados.
 Profesor: Francisco Rocca J

[pág. 22]
1-Cultura Corporativa
 Principios Disney:
 “Escuchar”
 “Anticipar”
 “Personalizar”
 “Hacer de lo mundano, magia”
 Profesor: Francisco Rocca J

[pág. 23]
1-Cultura Corporativa
 “El verdadero test de una cultura
 no está en lo que la organización
 dice de ella misma, sino cómo sus
 actos la reflejan”
 George Day, “The Market-driven Organization”
“Culture is not the most important
thing, it’s the only thing” “We are Ladies & Gentlemen serving Ladies & Gentlemen”
 Ritz-Carlton Hotels Motto
Costco’s CEO, Jim Sinegal
 Profesor: Francisco Rocca J

[pág. 24]
¿Qué preguntas se harían ustedes día a día para tomar
 decisiones centradas en el cliente?
 Profesor: Francisco Rocca J

[pág. 25]
Cultura Corporativa
Preguntas claves en el día a día!!
• ¿Cómo vería esto el cliente?
• ¿Cómo afectará esta decisión al cliente?
• ¿Este contacto ayuda a resolver el problema del cliente?
• ¿Si cambiamos este proceso, aumentará el valor percibido para el
 cliente?
• ¿Cómo mejoramos la experiencia del cliente desde su punto de vista?
• ¿Qué valora el cliente de nuestros servicios y productos?
• ¿Qué distintos tipos de clientes tenemos? SEGMENTACION!!!!
 Profesor: Francisco Rocca J

[pág. 26]
Factores claves para una cultura del cliente
 En base a qué actúan, monitorean y miden los
 Factores empleados
•Insight de clientes. •Las necesidades del cliente y su satisfacción.
•Predicciones del cliente. •Las necesidades y oportunidades potenciales
•Insight de los competidores . •Fortalezas y debilidades de los competidores.
•Predicciones de los competidores •Potenciales competidores y sustitutos
•Visión periférica •Tendencias políticas, económicas, sociales,
 tecnológicas.
•Colaboración entre funciones. •Interactuar, compartir información y trabajar
 en forma colaborativa entre equipos distintos
 para servir al cliente.
•Alineamiento estratégico
 •La visión, misión, objetivos estratégicos
 asociados al cliente.
 Profesor: Francisco Rocca J

[pág. 27]
2-Capacidades de entender y predecir a los clientes
Capacidades para “Sentir” al cliente:
• Observación en terreno : Mercado, tiendas,
 Lugares de reunión de consumidores).
• “Un día en la vida del cliente”
 (Front & Back Office)
• Herramientas de “escucha”: Call Centers, Contact
 Centers, Chatbots, blogs, ferias, RRSS, comunidades
 profesionales, Consejo Clientes y/o distribuidores
 etc.
• Procesos Continuos de Investigación de Mercados:
 Actitudes, conductas, percepciones, satisfacción,
 intención de recomendar (NPS), imagen de marca.
• Bases de Datos, CRM y Data Mining
 Profesor: Francisco Rocca J

[pág. 28]
2-Capacidades de entender y predecir a los clientes
 • Visitar e interactuar con los clientes
 (¿Prog. Inmersión Clientes?)
 • Buscar el feedback de los clientes
 • Gestión del ciclo de reclamos
 • Medir Satisfacción y otras actitudes
 (Recomendación, Intención de cambio, etc)
 • Compartir y difundir experiencias + y – del cliente
 • Establecer prioridades a partir de las necesidades
 del cliente
 • Necesidades higiénicas y funcionales versus
Customer Insight diferenciadoras y emocionales
 Profesor: Francisco Rocca J

[pág. 29]
2-Capacidades de entender y predecir a los clientes
 • Innovación inspirada en el cliente y
 sus necesidades,
 • Anticipar necesidades emergentes
 • Foco en necesidades latentes
 (cliente desconoce) y futuras (aun
 no existen)
 • Cercanía a clientes y co-creación
 • Usuarios claves y líderes de
 opinión pueden inspirar
 Customer Foresight • Tolerancia al fracaso!
 Profesor: Francisco Rocca J

[pág. 30]
2-Capacidades de entender y predecir a los clientes
Journey Map
• Es una herramienta que grafica el viaje del cliente, el que comienza con la necesidad del cliente y
 termina cuando esta está satisfecha.
• Permite identificar problemas o necesidades de los consumidores en las distintas etapas de la
 experiencia con la marca y definir oportunidades de mejora
 Profesor: Francisco Rocca J

[pág. 31]
2-Capacidades de entender y predecir a los clientes
 Profesor: Francisco Rocca J

[pág. 32]
3-Sistemas de información de clientes
Preguntas del día a día que tenemos
que hacernos:
 ● ¿Qué métricas se están usando para
 gestionar la cartera de clientes?
 ● ¿Qué tan profunda es la base de
 datos de los clientes?
 ● ¿Qué reportes sobre cartera de
 clientes se usan y quienes tienen
 acceso?
 ● ¿Qué procesos internos existen para
 analizar esta información y tomar
 decisiones?
 Profesor: Francisco Rocca J

[pág. 33]
¿Cuáles son las principales métricas para medir el éxito con
 el cliente?
 Profesor: Francisco Rocca J

[pág. 34]
3-Sistemas de información de clientes
 Estructura de una Base de Datos
 DATA
Segmentación:
 WAREHOUSE
•Nombre , rut
•Datos de contacto
•Segmento al que Reportes
pertenece
Registro de
transacciones:
•Producto comprado
•Fecha
•Monto Proceso Reportes Ad-hoc
•Método de pago
•Canal de venta.
Registro de
contacto:
•Llamado o visita del
cliente a las tiendas o Análisis por clientes
pagina web.
•Campañas
 Enfoque Relacional
comerciales
 Profesor: Francisco Rocca J

[pág. 35]
Ciclo de la relación cliente - empresa: ¿Qué información necesito para gestionar
la relación con el cliente, cómo la obtengo y qué hago con ella?
 S
 Desarrollo y
 Gestión de las Retención de
 Adquisición Rentabilización Reactivación y
 Primeras Clientes Valiosos
 de Clientes Clientes Recuperación de
 experiencias
 Clientes
 PROGRAMAS Y CAMPAÑAS DE MARKETING (CRM)
 ANÁLISIS DE LAS BASES DE DATOS (DATA MINING)
 DATOS DE LOS CLIENTES (BIG DATA)
 47

[pág. 36]
4-Políticas de recursos humanos alineadas con el cliente
 Profesor: Francisco Rocca J

[pág. 37]
4-Políticas de recursos humanos alineadas con el cliente
Sistemas de Incentivos “Orientados al cliente”
• Premios y reconocimientos en base a acciones
 relacionadas con el cliente y la innovación.
• Componentes variables atados a resultados de
 métricas de clientes:
 • índice satisfacción (NPS), Tasa de abandono de
 clientes (Churn), ganancia que un cliente le
 genera a una empresa (LTV).
• Bonos en base a resultados cualitativos:
 • Imagen de marca, percepción de Servicios
 Profesor: Francisco Rocca J

[pág. 38]
Paradoja de la centralidad en el cliente
Cuanto más nos centremos en los clientes más valiosos, más necesitaremos a los otros
clientes alrededor, con el propósito de tener un equilibrio estable para toda la empresa.
• La centralidad en el cliente, no sugiere que los consumidores menos valiosos sean
 ignorados o eliminados.
• Es importante tener una proporción saludable de esos clientes, de manera de agregar
 estabilidad en la base total de consumidores
• Si una empresa tiene cientos o miles de clientes, es importante encontrar el equilibrio justo
 entre estar realmente centrado en los segmentos que considera realmente valiosos y estar
 centrado en el producto con los clientes restantes que no son tan valiosos (ser
 operativamente eficientes con ellos)
• La empresa seguirá enfocando una cantidad desproporcionada de I+D en los clientes muy
 buenos, desarrollando productos para ellos, con la esperanza de hacer esos mismos
 productos atractivos para los clientes menos valiosos.
 Profesor: Francisco Rocca J

[pág. 39]
Analicen el caso de Sky Airlines
 10 minutos
 Profesor: Francisco Rocca J

[pág. 40]
Como resumen de lo que vimos hoy:
• Para tener una ventaja competitiva en el mercado , tenemos que liderar en costos y generar una
 diferenciación en el mercado.
• Las ventajas competitivas que tenemos que desarrollar tiene que ser valiosas, Inimitables, raras o
 escazas y que agreguen valor a los consumidores.
• La centralidad en el cliente hoy es algo clave para el desarrollo de las empresas.
• Los consumidores esperan que las empresas entiendan sus necesidades y expectativas y ante esto, las
 empresas deben responder ajustando sus procesos internos y actuar bajo el paradigma de la
 centralidad en el cliente.
• Esto ha hecho que las compañías cambien el foco tradicional en el producto, hacia una búsqueda
 constante del diseño y mejoras de la experiencia de clientes.
• Las distintas acciones que implica la centralidad en el cliente pueden agruparse en cuatro pilares:
 cultura, capacidad de entender y predecir a los clientes, sistemas de información y políticas de
 recursos humanos.
• La empresa debe enfocarse en los clientes de alto valor, diseñando para ellos, pero sin descuidar al
 resto de la cartera de clientes.
 Profesor: Francisco Rocca J

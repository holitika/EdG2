# Fundamentos de Marketing · Clase n12 Estrategias Servicios 2 sem 2123

Fuente: clase de Fundamentos de Marketing

[pág. 1]
Marketing de Servicio
 Prof: Francisco Rocca

[pág. 2]
Definición de la esencia del servicio
• Un servicio, es la acción o conjunto de actividades destinadas a
 satisfacer una determinada necesidad de los consumidores,
 brindando un producto intangible y personalizado.
• Es una actividad económica que no da lugar a la propiedad.

[pág. 3]
Industrias de servicios
 Gobierno Entretención Hotelería Correo
 Salud Transporte Diseño y asesoría Educación

[pág. 4]
Características de los servicios
 INSEPARABLE
 INTANGIBLE Producción y consumo en
 Naturaleza Ej: Los seguros forma simultánea. Participación
 del servicio Ej: alojamiento en un hotel del cliente
 SERVICIO
 Capacidad de HETEROGÉNEA
 almacenar o PERECIBLE Forma de
 Variable, depende quién entrega
 inventariar No pueden almacenarse.
 presta y dónde se presta el
 Ej: consulta médica, servicio.
 vacaciones
 Ej: servicio de correo

[pág. 5]
¡Quienes proveen
productos, también
entregan un servicio!
El servicio resume la
forma en que un
producto llega al cliente.

[pág. 6]
Modelo de Brechas

[pág. 7]
Modelo de Brechas de Calidad de Servicio
 Necesidades Experiencia
 El Boca a Boca
 personales anterior
 Servicio
 Esperado
Consumidores
 GAP 1
 Percepción de la Empresa de las
 expectativas del consumidor.
EMPRESA

[pág. 8]
Modelo de Brechas de Calidad de Servicio
 Diferencias entre las
 expectativas de los
 consumidores y lo que la
 Servicio empresa cree que los
 Esperado consumidores quieren.
Consumidores • Solución Investigación de
 mercado.
 GAP 1
 Percepción de la Empresa de las
 expectativas del consumidor.
EMPRESA

[pág. 9]
Modelo de Brechas de Calidad de Servicio
 Servicio
 Esperado
Consumidores
 No tener los diseños y
 estándares adecuados de
 GAP 1 servicios lo que se traduce en
 Diseños Estándar de servicio dificultad para transformar
 al cliente necesidades de los clientes
 vagamente expresadas en
 GAP 2 estándares específicos de
 Percepción de la Empresa de las calidad.
 expectativas del consumidor.
 Sol: Incorporar al cliente en el
EMPRESA desarrollo

[pág. 10]
Modelo de Brechas de Calidad de Servicio
 Servicio
 Esperado
Consumidores
 Servicio Entregado No entregar los estándares
 de servicio se refiere a la
 GAP 1 GAP 3 motivación y a las
 Diseños Estándares de capacidad de los
 servicio al cliente empleados para entregar
 los servicios de acuerdo a
 GAP 2
 los estándares.
 Percepción de la Empresa de las Sol: Selección,
 expectativas del consumidor.
 entrenamiento y sist.
EMPRESA Evaluación desempeño..

[pág. 11]
Modelo de Brechas de Calidad de Servicio
 Servicio
 Esperado
Consumidores
 No hay match entre lo
 prometido y el performance
 del servicio.
 Sol: diseño de estándares y
 capacitación
 Comunicación
 Servicio Entregado Externa a Clientes
 GAP 4
 GAP 1 GAP 3
 Diseños de Standards de
 servicio al cliente
 GAP 2
 Percepción de la Empresa de las
 expectativas del consumidor.
EMPRESA

[pág. 12]
Modelo de Brechas de Calidad de Servicio
 Servicio
 Esperado
Consumidores
 Gap 5
 Servicio
 Percibido
 Comunicación
 Servicio Entregado Externa a Clientes
 GAP 4
 GAP 1 GAP 3
 Diseños de Standards de
 servicio al cliente
 GAP 2
 Percepción de la Empresa de las
 expectativas del consumidor.
EMPRESA

[pág. 13]
Las 5 Dimensiones de un Servicio de Calidad
 (Parasuraman, Berry, Zeithaml)
 Capacidad de
 Aspectos respuesta Seguridad
 Confiabilidad Empatía
 tangibles (rapidez) percibida
Ambiente de La habilidad La disposición El grado de Nivel de
oficinas, atención para proveer lo para ayudar a personalización conocimientos y
a público, plantas, prometido en los clientes y del servicio y la cortesía de los
equipos móviles, forma precisa y darles un capacidad del empleados, así
apariencia del confiable. servicio oportuno empleado para como su habilidad
personal, imagen y rápido. “ponerse en los para transmitir
corporativa zapatos” del confianza y
 cliente. credibilidad.
 32

[pág. 14]
El encuentro con el Servicio
Ocurre en cada momento que el consumidor
interactúa con la empresa y usa esa
oportunidad para juzgar la calidad del servicio.

[pág. 15]
¿Como hacer seguimiento al Servicio?

[pág. 16]
Entender las expectativas y
 percepciones de los consumidores
• Identificación de consumidores insatisfechos.
• Monitoreo del resultado del servicio.
• Valor del performance propio vs. la competencia.
• Valorar las brechas de los consumidores entre las expectativas y
 percepciones.
• Medir efectividad de los cambios.
• Determinar expectativas de nuevos servicios.

[pág. 17]
Algunas herramientas para evaluar el servicio y la
 satisfacción del cliente.
• El Índice Net Promoter Score NPS.
 – Es una medida para saber a cuántos de tus clientes le gusta tu servicio lo suficiente como
 para recomendarla a otras personas.
• Encuesta de Satisfacción del Cliente.
• Customer Satisfaction Score CSAT o Escala de Satisfacción al cliente.
 – Se mide inmediatamente después de que finaliza el contacto con la empresa.
• CES (Customer Effort Score)
 – Busca establecer un puntaje midiendo la facilidad de resolución de un problema.
• CLI (Customer Loyalty Index)
 – Permite evaluar cómo el cliente percibe los servicios proporcionados.
• ISCX
 – Es el Indicador de compromiso, sirve para visualizar el porcentaje de clientes que declaran
 sin reservas su satisfacción, se muestran fieles y están predispuestos a recomendarlo

[pág. 18]
Matriz de Resultados
ALTO
 Alto ⚫ ⚫
 Leverage
 Atributos a Mejorar Atributos a Mantener
 ⚫
 ⚫ ⚫ ⚫
 Importancia
 ⚫
 Bajo
 ⚫
 ⚫ Leverage
 ⚫
 Atributos a eliminar o Atributos a Desincentivar
 mantener
BAJO
 ALTO
 Costos

[pág. 19]
Beneficios de un buen servicio
• Aumenta la lealtad de los clientes,
 producto de su nivel de satisfacción.
• Atrae nuevos clientes gracias a la
 comunicación boca a boca, lo que es
 mucho más efectivo para la empresa en
 términos de costos, que tratar de captar
 nuevos clientes.
• Oportunidad para una mayor venta
 cruzada (cross - selling) debido al mayor
 conocimiento de las necesidades de los
 clientes.

[pág. 20]
Beneficios de un buen servicio
• En relación a los empleados, los beneficios
 se ven producto de una mayor satisfacción,
 moral y compromiso con la organización.
• Aumenta la imagen de marca, y hace menos
 sensibles a los clientes a la variable precio.
• Reduce los costos (de los errores
 publicitarios y operacionales).
• Aumenta la productividad y las ventas,
 participación de mercado, rentabilidad y
 desempeño del negocio.

[pág. 21]
El Servicio de calidad genera utilidades
 Disminución
 de costos
 RETENCIÓN Frecuencia
 DE de compra
 CLIENTES
 Precios Aumento de
 Premium los
 CALIDAD márgenes
 DE
 SERVICIO Aumento Aumento
 del Market de las
 share utilidades
 BUEN
 Reputación Aumento de
 SERVICIO
 las ventas
 Genera
 boca a
 boca

[pág. 22]
¿Y qué pasa si el servicio es malo?
• ¡Un mal servicio implica un alto costo en
 reputación!
• Hoy, los clientes comparten rápidamente
 sus malas experiencias cuando buscan
 soporte y las respuestas que obtienen no
 son satisfactorias.
 51

[pág. 23]
Ejemplos
• FEDEX
• United Airlines

[pág. 24]
Lo que vimos hoy
• Características de los servicios.
• Modelo de brechas y de expectativas de los consumidores respecto del
 servicio.
• Es importante tener clara la percepción de servicio por parte del consumidor.
• Las 5 Dimensiones de un Servicio de Calidad.
• Los empleados de las compañías son claves en la entrega de calidad de
 servicio, por lo que tienen que ser capacitados en forma permanente y tener
 los incentivos adecuados.
• Algunas herramientas para evaluar el servicio y la satisfacción del cliente.
• La calidad del servicio al consumidor genera valor y crea lealtad hacia las
 marcas , pero un mal servicio destruye mucho valor.

# Fundamentos de Marketing · Clase Estrategias de Precios V12

Fuente: clase de Fundamentos de Marketing

[pág. 1]
ESTRATEGIAS DE PRECIOS
 Prof: Francisco Rocca

[pág. 2]
Las decisiones de precios
 ¡El precio es la
 única variable
 que captura
 valor!
• Es el valor que el consumidor esta dispuesto a pagar por los
 beneficios que el producto o servicio le entrega.
• Las decisiones de precios, determinan el tipo de consumidores y los
 competidores que la empresa atraerá.
• Un solo error en la decisión de precios puede anular todas las demás
 actividades del marketing mix.

[pág. 3]
Al ser flexible, es una variable que se manipula
Precio y marketing mix en los momentos difíciles….
• Es el elemento mas flexible del marketing
 mix.
 – Precio puedo cambiarlo en cualquier
 momento.
 – El producto requiere de mucho tiempo para
 cambiarlo.
 – La distribución requiere meses de
 negociaciones.
 • Entrar en nuevos canales de venta.
 – La comunicación requiere semanas de
 elaboración.
 • Contratos de los medios, desarrollo de las
 campañas.

[pág. 4]
Elementos del precio

[pág. 5]
El precio es solo la punta del iceberg en la ecuación
precio-valor recibido por el cliente
 • Costos de adquisición
 • Costos de mantención
 • Costos financieros (crédito)
 • Costos de uso
 • Costos de cambio
 • Costos de instalación
 • Costos de propiedad (leasing)

[pág. 6]
Principios básicos de los precios
• Es la herramienta para capturar del valor creado, no para cubrir
 los costos.
• La rentabilidad positiva es consecuencia de entregar mas valor
 que la competencia y tener eficiencias en costos.
• El precio se fija en base a variables externas , como son la
 disposición a pagar del consumidor , la sensibilidad al precio y la
 intensidad competitiva.
• En la mayoría de los casos, un costeo por cliente y actividades
 relacionada nos provee el piso de la estrategia de precios,

[pág. 7]
Significado del precio
• El precio significa más que simplemente la cantidad de dinero
 que tiene que entregar una parte, para asegurarse el producto
 o servicio.
• El precio además entrega información acerca de :
 – La calidad
 – La durabilidad
 – La reputación del fabricante
 – La reputación del canal de distribución.

[pág. 8]
Roles del Precio
• Rol de Negocio: Generador de márgenes.
• Rol Comunicador: Posicionamiento del Valor.
• Rol de Segmentación: discriminando por la disposición a pagar.
• Rol Económico: Asignador de recursos
• ROL PRINCIPAL:
 CAPTAR EL VALOR CREADO

[pág. 9]
Modelos de precios

[pág. 10]
Consideraciones de precio
 Precio como indicador de Valor
• Los consumidores combinamos el precio con los beneficios percibidos derivados, de
 una oferta para determinar el valor.
• El valor es la relación entre los beneficios percibidos y el precio.
• Esto muestra que para un precio dado, el valor aumenta a medida que aumentan los
 beneficios percibidos y viceversa

[pág. 11]
Precio como indicador de valor.
• Los consumidores no compramos
 precios bajos, compramos de acuerdo
 al valor que representa para nosotros
 el producto o servicio.
• Las estrategias de precios se realizan
 para un segmento objetivo, dada una
 propuesta de valor, no para un
 producto.
• Valor del Consumidor = Beneficios
 Percibidos por el consumidor- Costos
 Percibidos por el consumidor

[pág. 13]
Conceptos de Precio
Esfuerzo de Valor Objetivo Valor Económico (Valor Objetivo)
 Marketing (Costo de la alternativa +valor diferencial del desempeño)
 Valor Percibido
 Precios
 sustitutos Incentivo consumidor a comprar
 (precios de =(valor percibido – precio)
 referencia) Precio del Producto
 Incentivo empresa a vender
 =(precio – costos)
 Costo del Producto

[pág. 14]
Valor Económico
• El valor económico es el valor que un
 consumidor bien informado debiera
 o debería atribuir al producto. Este
 puede ser muy diferente para los
 consumidores.
• Cuando existen varias opciones de
 elección , el valor económico se
 expresa en términos relativos
 respecto a las alternativas evaluadas.

[pág. 15]
Valor Percibido
• La disposición a pagar de un
 consumidor esta dada por el valor
 que ese consumidor percibe del Beneficios percibidos: una combinación de atributos físicos,
 atributos de los servicios, disponibilidad de soporte técnico en
 producto y este es normalmente relación al uso del producto, así como también el precio de compra y
 otros indicadores de calidad percibida (por ej, imagen de marca)
 menor que el valor económico.
 Valor percibido= Beneficios Percibidos Precio percibido: costo total percibido por el comprador. Es decir
 precio de compra más otros costos asociados, como el costo en
 Precio (Costos Totales) tiempo, esfuerzo, costos de adquisición, transporte, instalación
 pedidos, sumado a los costos post compra, como la reparación,
• La labor de marketing es acercar el
 mantención, riesgo de fracaso, etc.
 valor percibido al valor económico,
 transformando a los consumidores
 desinformados o escépticos en
 consumidores informados y
 racionales.

[pág. 16]
Conceptos de demanda que influyen en el
 valor percibido
1. Los precios de referencia.
2. La disposición a pagar.
3. La elasticidad o sensibilidad
 a los precios.
4. Aspectos psicológicos del
 precio

[pág. 17]
1. Precios de referencia
 La comparación de los costos y
 beneficios de los productos sustitutos
 dan lugar a un valor de referencia.
 Es un precio psicológico
Los consumidores
determinamos el valor al juzgar
el valor y la conveniencia de
una oferta en relación con los
sustitutos que satisfacen la
misma necesidad.

[pág. 18]
1.Precios de referencia
• Los consumidores no respondemos a
 precios absolutos, sino a precios
 relativos.
• El precio de referencia es aquel sobre
 el cual se compara y toma decisiones
 (decisión de compra, elección de
 marca y volumen de compra).
• Existen dos tipos:
 – El precio de referencia interno: en la
 memoria.
 – El precio de referencia externo: estímulo
 como publicidad, otros precios en el
 contexto de compra, “antes vs hoy”, etc.

[pág. 19]
1.Precios de referencia
 ¿Cómo se forman?
Es la resultante de la combinación de
diversos factores:
 – Último precio pagado (o el promedio, o
 el más reciente).
 – Basado en experiencia histórica, el precio
 más frecuente.
 – El precio “justo” o lo que “yo creo que
 debería pagar”.
 – El precio de la marca preferida.
 – Una percepción de precio promedio de
 las marcas conocidas.
 – Precio esperado a futuro.
 – La situación de consumo.

[pág. 20]
2.Disposición a pagar
• La disposición a pagar del consumidor se
 refiere al monto máximo que un
 consumidor estaría dispuesto a pagar por
 un determinado producto o servicio.
• Esta medida puede variar según las
 preferencias, el contexto y la situación
 financiera de cada consumidor.
• En general, la disposición a pagar está
 determinada por los beneficios que el
 consumidor espera obtener del producto o
 servicio, así como por los precios de
 productos similares en el mercado.
• Depende del valor percibido

[pág. 21]
3.Elasticidad precio de la demanda (E)
• La elasticidad precios mide
 la respuesta del
 consumidor ante un
 cambio de precios.
E=Cambio % en la cantidad demandada
 Cambio %en el precio

[pág. 22]
La sensibilidad de precios es alta cuando…
• Producto
 – Tiene baja diferenciación.
 – Es fácilmente comparable
 – No es crítico para la misión de compras.
• Precio
 – Es fácilmente comparable.
 – Es relativamente alto.
 – Cuando existen precios de referencia.
 – No es necesario como señal de calidad
• Consumidor
 – Poco sofisticado
 – No existen costos compartidos
 – Es capaz de cambiarlo fácilmente
 – No esta motivado por el prestigio

[pág. 23]
Esta sensibilidad de precios es diferente para
 diferentes consumidores
• Porque varía el número de sustitutos.
• Porque varía la conveniencia (Alto
 deseo de conveniencia, baja
 sensibilidad).
• Porque varía la presión de tiempo
 (baja presión, alta sensibilidad).
• Porque varía el periodo de compra
 (periodo peak tiene baja sensibilidad,
 mientras fuera de temporada, la
 sensibilidad es baja)
• Porque varía la cantidad de
 proveedores (si hay pocos
 proveedores alternativos, la
 sensibilidad en baja)

[pág. 24]
Factores que afectan la sensibilidad al precio
 1 2 3 4
 EFECTO VALOR ÚNICO EFECTO DEL GASTO EFECTO EFECTO DEL
 (NO HAY SUSTITUTOS) PRECIO-CALIDAD BENEFICIO FINAL
Menor sensibilidad si el Mientras mayor es la Menor sensibilidad en el Mientras mayor es el % del
producto es percibido importancia del gasto precio en productos de alta gasto del producto como
como único (ej: trabajo de como % del ingreso. calidad, prestigio o parte de una solución total
un artista), (Ej: arriendo de un dpto., exclusividad, y por lo tanto (seguros, agencia de viaje),
diferenciándose por la crédito de consumo), mayor disposición al pago. menor sensibilidad y
marca, y aumentando la mayor sensibilidad al mayor disposición al pago.
disposición al pago. precio.

[pág. 25]
4.Precios Psicológicos
• La estrategia de precios psicológicos se enfoca en las emociones del
 consumidor, en el valor que este percibe de un producto o servicio que
 tiene un impacto significativo en su comportamiento de compra y en la
 percepción de valor .
• Algunos ejemplos de técnicas de precios psicológicos utilizadas :
 – Precio de referencia: Se establece un precio de referencia más alto para un
 producto o servicio y se ofrece un descuento, lo que crea la percepción de una
 buena oferta. Por ejemplo, un producto puede tener un precio "recomendado"
 más alto, pero se vende a un precio "rebajado".
 – Precios terminados en 9: Establecer el precio en un número que termine en 9
 (por ejemplo, $9.99 en lugar de $10) puede dar la ilusión de que el producto es
 más barato y asequible.
 – Precios de packs o bundles: Se ofrecen productos o servicios en un paquete
 combinado a un precio ligeramente más bajo que si se compraran por separado.

[pág. 26]
Ejercicio en clases Nike y Resell (10 min)
 La empresa Nike es una de las más grandes del mundo en la industria de las zapatillas.
 Diversos modelos y estilos de zapatillas se lanzan anualmente al mercado. En algunos
 casos, se realizan ediciones “limitadas” (diseños especiales, alianzas con famosos, etc.) de
 algunos modelos, lo que ha dado pie a la generación de un mercado de “reventa” (resell)
 de amplias proporciones. Fanáticos de la marca son capaces de dormir fuera de las
 tiendas para poder acceder y comprar estas ediciones, las que, en un porcentaje menor,
 son revendidas a precios significativamente mayores.
Este mercado corresponde a casi el 4% de las ventas totales de zapatillas e incluye zapatillas de las marcas Nike,
Adidas, Asics y otras. Ya existe un término para este consumidor especial (“los Sneakerheads”) que invierte sumas
considerables y tiempo en conseguir estas zapatillas, las guardan y luego de un tiempo las ponen en el mercado.
Se ha desarrollado este mercado de resell y ya existen varios sitios web (eBay y RRSS) y tiendas especializadas
(StockX, Goat, Stadium Goods). En el caso de Stock X opera como una bolsa de comercio de sneakers, con remates,
indicadores de precios, índices de volatilidad, etc. Los precios de reventa pueden alcanzar 5-10 veces su precio
original en tienda y el comprador hasta puede gestionar portfolios de zapatillas, tal como si fueran acciones de
empresas. Suponga que uno de los ejecutivos de Nike planteaba en reunión de Gerentes que le parecía que las
grandes diferencias de precios obtenidas por la reventa por parte de sus clientes, estaba dejando “plata sobre la
mesa”. Sugería incrementar significativamente el precio de venta original de las series limitadas o especiales. El
gerente de Ventas se negaba a esta propuesta y pedía aumentar los volúmenes de estas ediciones, sin cambiar los
precios, para así capturar mayor valor y ventas, en líneas de alta demanda.
Pregunta: Analice la conveniencia de hacer cambios en la política de precios y producción de Nike para estas
líneas de productos con reventa. Argumente usando conceptos del curso.

[pág. 28]
¿Que es el valor económico?
• El valor económico es el valor que
 un consumidor bien informado
 debiera o debería atribuir al
 producto. Esto puede ser muy
 diferente para los consumidores.
• Cuando existen varias opciones de
 elección , el valor económico se
 expresa en términos relativos
 respecto a las alternativas
 evaluadas.
¡Cuesta mucho demostrarle al cliente
cuál es el valor económico!

[pág. 29]
Como es el procesos para determinar el valor
 económico de un producto
1. Identifique las oportunidades para
 generar valor a través de productos o
 procesos.
2. Identifique los costos de los
 productos competitivos o procesos
 (valores de referencia).
3. Identifique todos los factores que
 diferencian el producto o servicio.
4. Determine el valor para el
 consumidor de esos factores
 diferenciadores (el valor diferencial) .
5. Sume el valor referencial y el valor de
 la diferenciación para determinar el
 valor económico total.

[pág. 30]
Como es el procesos para determinar el valor
 económico de un producto
• El valor de diferenciación es
 el valor para el cliente
 (positivo y/o negativo) de
 cualquier diferencia entre su
 producto y el producto de
 referencia competitivo.

[pág. 31]
Análisis del valor económico
• Factores que diferencian el
 producto.
 – Desempeño superior (inferior)
 – Mayor o menor confianza
 – Características adicionales
 (reducidas)
 – Costos de mantención mas bajos
 (altos)
 – Costos de puesta en marcha mas
 altos (bajos).
 – Servicios mas rápidos (lentos)

[pág. 32]
Precios que reflejan el valor del
cliente. Costos del cliente
 asociados con el uso del
 producto
Si podemos determinar el valor
económico de usar nuestro Costos Post-
 compra
producto (X) al cliente (incluyendo Precio de compra
 Costos iniciales
 (modificaciones
 (mantención,
 capacitación,
 del producto iniciales,
 inventario,
las ventajas en costos y valor capacitación)
 financiamiento,
 reemplazo)
incremental) versus el uso de un
producto competitivo (Y), entonces VECx = Precio Y - (Costos iniciales de X + Costos post
 compra de X) + Valor incremental de X vs Y
podemos usar el precio según el
valor dado por el cliente.

[pág. 33]
Ejercicio Servicio Nacional de Salud
• El Servicio Nacional de Salud (SNS) está muy preocupado por los pacientes que se infectan mientras están en el
 hospital tratándose otras enfermedades más importantes. Algunas de las infecciones pueden ser atribuidas a la
 ropa, toallas, y a las sábanas de las camas que no fueron completamente desinfectadas. Los estudios señalan
 que tres de cada cien pacientes ingresados al hospital adquieren infecciones debido a las razones anteriores.
 Tales infecciones resultan en una estadía adicional de 6 días por paciente en el hospital.
• Además, uno de cada cien mil pacientes muere debido a infecciones adquiridas en el hospital que se pueden
 atribuir directamente a la ropa, toallas y sábanas de las camas. Cada día extra en el hospital se le cobra a la SNS,
 por el propio hospital, y el costo para la SNS es de U$100 (costo por día extra). La familia del paciente que muere
 por una infección es normalmente compensada en U$10,000 por el hospital (costo que no es traspasado al SNS).
• La compañía LG ha desarrollado una nueva máquina que permite un nuevo sistema de lavado que utiliza vapor a
 alta presión y velocidad, de tal forma que elimina las infecciones adquiridas en la ropa, toallas y sábanas de
 cama. Los estudios señalan que la incidencia de infecciones se reduce a sólo un paciente por cien. Las
 infecciones también son menos graves y el número adicional de días en el hospital es de sólo tres. Además, se
 eliminan las muertes de los pacientes causadas por infecciones.
• Cada máquina tiene una vida útil para el lavado de 10,000 pacientes (ropa, toallas y sábanas que ocupa un
 paciente mientras está en el hospital), después de lo cual debe ser reemplazada. Para el propósito de este
 análisis, la estadía de los pacientes también puede incluir los días adicionales que un paciente tiene que estar si
 es infectado (es decir la máquina sigue teniendo una vida útil para 10,000 pacientes). GL está teniendo
 dificultades para convencer a los hospitales para comprar la máquina, la cual tiene un precio de U$5,000.
• De acuerdo a la información anterior, explique claramente, y utilizando análisis cuantitativos, por qué los
 hospitales no están dispuestos a comprar la máquina de GL. ¿Qué estrategia de precios debería seguir GL para
 comercializar su nueva máquina? Justifique claramente sus cálculos y respuesta.

[pág. 34]
Estrategias de Precios

[pág. 35]
Factores que presionan los precios
 02
 01 Legislaciones Presión Social
 por
 Más restrictivas
 Transparencia 03
 Precios
 Mayor Cambios
 competencia Tecnológicos
 Inter categoría
 09 de
 Productos .
 Factores que 04
 presionan los
 Aumento de la Omnicanalidad
 Concentración precios
 08
 Acceso
 Inteligente 05
 a Bases de Consumidor
 Madurez y Más Educado
 Datos
 saturación de
 07 los Mercados
 06

[pág. 36]
Una estrategia de precios pueden buscar diferentes
objetivos

[pág. 37]
Junto con el objetivo buscado, ¿qué más debe
 tener la marca en consideración para
 desarrollar una estrategia de precios?
 La banda de precios sobre la que me puedo
 mover: el techo lo pondrá la demanda y el piso lo
 pondrán mis costos.

[pág. 38]
Banda de precios
 Competencia Imagen de Marca
 Elasticidad Valor Económico. Valor Percibido .Leyes
EL “TECHO”
 Ancho de la banda
EL “PISO”
 Costos Riesgo Guerra Imagen de Marca
 Relevantes Precios y Leyes

[pág. 39]
Influencia del conocimiento del mercado y de la competencia en
 el establecimiento de precios
 PROFUNDO
CONOCIMIENTO DEL MERCADO Precio reactivo al Precio orientado al
 cliente mercado
 (obsesión por el cliente) (orientación al mercado)
 ALGUNO
 Precio orientado al Precio reactivo a la
 costo competencia
 (obsesión por la
 ( enfoque Interno) competencia)
 NINGUNO
 NINGUNO ALGUNO PROFUNDO
 CONOCIMIENTO DE LA COMPETENCIA

[pág. 40]
Enfoques para una estrategia de precios (5C)
 01 02 03 04 05
 BASADO EN COSTOS BASADO EN LA
Consiste en calcular el costo COMPETENCIA BASADO EN EL INCENTIVO AL CANAL
por unidad producida y La empresa establece el precio CONSUMIDOR ¿Cuál es el incentivo para que CAPACIDAD INSTALADA
agregarle un margen de utilidad de acuerdo a la competencia. el canal ofrezca el producto?
 De acuerdo a la teoría ¿Cómo satisfacer/crear una
Este método se caracteriza por Este método es simple y de marketing, el mejor • Impulsor: Ventas/mktg.
 • Preocupación: Los miembros demanda de mercado con el
ser simple, sin embargo, barato . La empresa pasa a ser precio es aquel que el
presenta dos desventajas: “tomadora de precios” del canal están más motivados fin de utilizar la
 consumidor está
• No considera las reacciones Preocupación: A veces es dispuesto a pagar. por la “ganancia” que por el capacidad ociosa?
 de los consumidores ni de la complejo determinar quién es En función de las “valor para el cliente” • Impulsor: Ventas/Mktg y
 competencia mi competencia relevante? características de la Producción
• No existe input de Entender quién es y la Transacción. • Preocupación: Mantener
 marketing. capacidad y voluntad de Preocupación: difícil de la eficiencia operacional.
 reacción. calcular.
 .

[pág. 41]
Precios que reflejan el valor del consumidor
 Precios basados en el valor producen buenas estrategias de precios
 Satisfacción Necesidad vs competencia
Menos
 ? X X
 Un mayor precio Igual Precio de la
 X
 puede ser cobrado competencia
 Un mayor precio Un mayor precio
 Más
 puede ser cobrado puede ser cobrado ?
 Costos vs productos de la competencia

[pág. 42]
Discriminación de precios
• La discriminación de precios es
 una práctica que consiste en
 cobrar por el mismo bien o
 servicio, distintos precios a
 diferentes consumidores. Esto, a
 pesar de que el costo de
 proveerlos es el mismo.

[pág. 43]
Discriminación de precios
Primer grado o discriminación Segundo grado:
perfecta: • Ocurre cuando el vendedor ofrece
• Ocurre cuando el vendedor conoce distintas opciones de combinaciones
 la disposición a pagar de cada del producto o servicio para inducir que
 consumidor y le cobra el precio los consumidores se auto seleccionen.
 máximo que está dispuesto a pagar De esta forma, el vendedor cobra
 por cada unidad. En este caso, el precios distintos por los mismos bienes
 vendedor se apropia de todo el o servicios, pero los consumidores que
 excedente del consumidor. compran la misma combinación
 pagarán lo mismo.
 • El ejemplo más común son los
 descuentos por cantidad.

[pág. 44]
Discriminación de precios
• Tercer grado:
Ocurre cuando el vendedor cobra
diferentes precios a diferentes grupos
de consumidores. Es uno de los tipos
de discriminación más utilizados.
Por ejemplo, en los billetes de avión y
otros tipos de transporte, las
compañías telefónicas y las salas de
cine cobran diferentes precios a niños,
estudiantes, tercera edad y otros
grupos identificables.

[pág. 45]
Estrategias de precios
1. Estrategia de penetración
2. Estrategia de descreme
3. Estrategia de reducción de precios
4. Estrategia de mantención de precios.
5. Estrategia de precios de prestigio.
6. Estrategia de precios segmentada / dinámica.

[pág. 46]
Estrategia de Penetración
• Consiste en establecer un precio bajo al inicio del ciclo de vida , y generar un gran
 volumen de ventas.
• Objetivos:
 – Desalentar a la competencia mediante el logro de una alta participación de mercado y logra ventajas
 de costos mediante las economías de escala.
 – Utilidades vienen dadas por el volumen.
• Requisitos:
 – El producto debe lograr un tamaño de mercado importante para que las ventajas en costos sean
 reales.
 – La demanda tiene que ser muy elástica al precio.
• Resultados esperados:
 – Altos volúmenes de venta y gran participación de mercado.
 – Bajos Márgenes, las utilidades vienen por el volumen.
 – Reducción de los costos unitarios debido a las economías de escala..

[pág. 47]
Estrategia de Precios de Descreme
Consiste en establecer un precio alto al inicio del ciclo de vida , y se va disminuyendo
gradualmente para capturar otros consumidores .
• Objetivos:
 – Maximización de utilidades en el corto plazo.
• Requisitos:
 – Uso intensivo de todas las variables de marketing en especial la comunicación.
 – Fuerte gasto promocional para la introducción del producto para convencer al consumidor a comprar el
 producto.
 – Demanda inelástica.
 – Ausencia de competidores y de sustitutos.
 – Producto superior , difícil de copiar
• Resultados esperados:
 – Recuperación de inversiones y costos en el corto plazo

[pág. 48]
Comparación de dos estrategias: descreme v/s
penetración

[pág. 49]
Estrategias de “Mantención” de precios en productos ya
 establecidos en el mercado.
• Son para mantener posiciones en el mercado (Share y
 rentabilidad) .
 – Objetivo: Mantener el status quo.
 – Requisitos:
 • Productos que no son afectados por la competencia y el entorno.
 • Cuando existe incertidumbre en el resultado de un cambio de precios.
 – Resultados esperados:
 • Status Quo de la empresa en su posición en el mercado.

[pág. 50]
Estrategias de “Reducción” de precios en productos ya
 establecidos en el mercado.
• Objetivos:
 – Defensa frente a reducciones de precios de la competencia.
 – Ataque para ganarle participación a la competencia.
 – Respuesta a necesidades de los consumidores frente a cambios en el entorno.
• Requisitos.
 – La empresa tiene que ser solida en lo financiero como competitivamente.
 – Tener un buen entendimiento de la función de demanda.
• Resultados esperados.
 – Bajos márgenes.
 – Altas ganancias de participación dependiendo de la respuestas de la competencia y de la
 elasticidad de precios.
• Las reducciones de precio más usadas son:
 – Descuentos por cantidad
 • Abonos más baratos que entradas individuales
 – Reducciones por temporada
 • Anticipa las ventas

[pág. 51]
Opciones para reaccionar ante la competencia en precios
 EL COMPETIDOR ES :
 MAS DÉBIL NEUTRAL O MAS FUERTE
LA REACCIÓN DE PRECIOS ES :
 MUY COSTOSA IGNORAR ACOMODARSE
 ATACAR DEFENDER
 JUSTIFICADA EN
 COSTOS

[pág. 52]
Estrategias Precio de Prestigio
• El precio tiene una influencia
 psicológica en la evaluación que hace
 una persona de un producto.
 – Un precio alto aumenta las expectativas y
 por ende reduce el riesgo.
 – Un precio alto representa un “sello de
 calidad”
• La relación entre el precio y la calidad
 le permite a una organización
 establecer precios altos dado el
 prestigio de la marca que significa
 consumir ciertos productos

[pág. 53]
Estrategias de Precios dinámicos.
Es cuando se cobran precios diferentes por el mismo producto.
• Objetivos:
 – Maximizar el beneficio en función de la competencia y de lo
 que los consumidores estén dispuestos a pagar.
 – El énfasis esta en el resultado mas que en el volumen.
• Requisitos.
 – Necesidad de mucha información para implementar la
 estrategia . Usualmente esta estrategia se implementa por
 mercado, por producto, por tiempo, por GSE.
• Resultados esperados.
 – Mejoras en los resultados.
 – Aumento de los costos administrativos y de ventas.
 – Probables problemas legales por discriminación de precios.

[pág. 54]
Fijación Dinámica de Precios
• Revenue o Yield Management :
 demanda fluctuante, inventario
 perecible, altos costos fijos, diversidad
 de valor percibido y elasticidad precio
• Gestión de Mark-down: Inventario
 perecible (obsolescencia, moda)
• Precios Dinámicos: precio es una
 variable resultante de oferta y
 demanda en cada momento (ej.
 Modelos en Internet) o de la
 personalización del precio en base a
 características, conductas y perfil del
 comprador

[pág. 55]
Hay dos categorías de conductas
 Inhabilidad del Consumidor
Fijación de Discriminación para Comparar
 Precios e Interpretar los Precios
Liderazgo
 Anti- Justicia y Garantías
En Precios Verdad
 Competitivas Falsas de P.
 al Consumidor
 Final .
Paralelismo
 En Precios
 Comparaciones
Acuerdos Engañosas
De Precios Precios Liquidaciones
 Predatorios “Mentirosas”

[pág. 56]
Que vimos hoy…
• La variable precio es de suma importancia dentro de las estrategias de marketing ya
 que es la recupera el valor creado en el mercado de todas las acciones de marketing que
 la empresa realiza.
• Existen diferentes estrategias de precios ya que hay diferentes factores que las afectan y
 el costo no es el único factor a considerar para una estrategia de precio.
• Al implementar una estrategia de precios se persiguen diferentes objetivos.
• Conceptos claves: valor económico, valor percibido, disposición a pagar, elasticidad
 precios y precio referencia.
• Componentes claves de una estrategia de precios: objetivos, banda y estructura de
 precios, definición competitiva y control de gestión.
• Las definiciones de precios deben ser éticas y legales , nos debemos a nuestros
 consumidores. Las empresas deben competir en forma leal y profesional.

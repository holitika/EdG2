# Fundamentos de Marketing · Clase introductoria

Fuente: clase de Fundamentos de Marketing

[pág. 1]
Mercados I y Fundamentos de Marketing
 Introducción al Curso
 Profesor Francisco Rocca 1

[pág. 2]
Francisco Rocca , Ingeniero Comercial
 Casado y con 9 nietos
 Experiencia Laboral
 Experiencia Académica
 Profesor Francisco Rocca 2

[pág. 3]
Profesor Francisco Rocca 3

[pág. 4]
Que veremos hoy
1. Descripción del curso y metodología
2. Evaluaciones
3. Información relevante.
 Profesor Francisco Rocca 4

[pág. 5]
¿QUÉ LES GUSTARÍA LLEVARSE AL FINAL DE ESTE CURSO?
 Profesor Francisco Rocca 5

[pág. 6]
¿EN QUÉ LES GUSTARÍA
TRABAJAR CUANDO EGRESEN?
 Profesor Francisco Rocca 6

[pág. 7]
Durante el curso analizaremos…
 El rol de Marketing bajo Creación de valor para
Rol del Marketing en las nuevas tendencias los consumidores,
 las empresas. empresariales y de los clientes , empresa y la
 consumidores
 Profesor Francisco Rocca sociedad. 7

[pág. 8]
OBJETIVOS DEL
 CURSO.
 Se busca que los Se pretende que los
Buscar desarrollar en Formular a nivel
 alumnos sean capaces alumnos entiendan el
 los alumnos la general, estrategias y
 de evaluar estrategias marketing como una
 capacidad para políticas comerciales,
 alternativas y forma de pensar, más
analizar y evaluar los dado el conocimiento
 proponer planes de que como un área
 distintos problemas de las distintas
 acción de acuerdo a los funcional aislada
propios de marketing herramientas
 objetivos, dentro de una
 disponibles. empresa.

[pág. 9]
Metodología
Profesor Francisco Rocca 10

[pág. 10]
Bibliografía
• Texto Guía: Dirección de Marketing, Philip Kotler (últimos 3
 años), Prentice Hall.
• No hay preguntas específicas del libro, pero se asume que lo
 han revisado.
• Set de lecturas seleccionadas disponibles en la página web del
 curso.
• Sitios de interés que están disponibles en el programa.
 Profesor Francisco Rocca 11

[pág. 11]
Evaluaciones
 Prueba 2
 Trabajos en
 Prueba 1 clase y Tareas.
 17,5%
Controles
de Casos y
 Examen
 Lecturas
 NOTA Final
 (5)
 FINAL DEL
 CURSO

[pág. 12]
Controles de lectura y casos
Durante el curso se llevarán a cabo cinco controles durante el semestre.
• Los controles incluyen la bibliografía correspondiente y el caso correspondiente.
• Lo que se busca es evaluar la capacidad de aplicar los conceptos aprendidos de las lecturas, como
 también evaluar individualmente el caso asignado.
• Deberán preparar cada caso en grupo o en forma personal, sin embargo, la evaluación del caso será
 individual.
• No se podrán usar ni los casos ni los apuntes de las lecturas durante los Controles.
Fechas Controles de Casos y Lecturas
• Control #1: Viernes 25 de agosto
• Control #2: Viernes 22 de septiembre
• Control #3: Viernes 13 de octubre
• Control #4: Jueves 26 de Octubre
• Control #5: Viernes 24 de noviembre
 Profesor Francisco Rocca 13

[pág. 13]
Controles de lectura y casos
• Se eliminará un Control de Caso y Lectura, el cual corresponderá a la peor nota obtenida
 por el estudiante de los cinco controles rendidos.
• El estudiante que falta a sólo un control no necesita presentar ningún tipo de justificativo. El
 control no rendido por la razón que sea, justificada o no en la Secretaría de Estudios,
 corresponderá al control eliminado de los cinco programados en el curso.
• Si algún estudiante falta a más de un control, y cuenta con justificación de Secretaría de
 Estudios (por todos los controles inasistidos), podrá dar un control recuperativo en la última
 clase.
• Se podrá justificar como máximo dos controles de lectura del total de cinco controles
• En el control recuperativo entran todas las lecturas del curso más un nuevo caso que será
 asignado, y reemplazará la nota de los controles justificados.
 Profesor Francisco Rocca 14

[pág. 14]
Controles y trabajos en clase
• Durante el desarrollo de las clases se llevarán a cabo diferentes tipos de actividades
 como, por ejemplo: trabajos, tareas, participación en discusión de casos, problemas,
 análisis de la contingencia, controles sorpresa , etc.
• Estas actividades tienen una ponderación de un 15%.
• Aquellos alumnos que no estén presentes en el desarrollo de estas actividades
 obtendrán nota 1.
• En general, las actividades que se llevarán en clases no serán avisadas con
 anticipación y no existe justificación para aquellos alumnos que falten.
• La idea es hacer aproximadamente 10 de este tipo de actividades durante el
 semestre y los alumnos tendrán la posibilidad de eliminar las dos peores que
 obtengan (se incluyen las inasistencias).
• La primera clase el profesor les asignará un grupo con el cual deberán realizar las
 tareas grupales durante todo el semestre. Los grupos estarán conformados por 3
 estudiantes, elegidos por el profesor.
 Profesor Francisco Rocca 15

[pág. 15]
Pruebas
• Durante el curso se harán dos pruebas , que cada una de ellas
 corresponden a un 17,5% de la nota final.
• En las pruebas se controla lo pasado durante las clases , no se
 realizan pregunta directamente de los controles de lectura ni
 de los casos, pero todos los conceptos aprendido en las
 lecturas y casos pueden ser preguntado en las pruebas.
 Profesor Francisco Rocca 16

[pág. 16]
Examen Final
• El examen incluirá toda la materia del curso excluyendo las lecturas y
 casos del curso, pero todos los conceptos aprendido en las lecturas y
 casos pueden ser preguntado en el examen.
• Se exige una nota mínima de un 3,0 en el examen para aprobar el
 curso.
• Aquellos estudiantes que obtengan menos de un 3,0 en el examen, pero
 que sin embargo tuviesen un promedio ponderado superior a 4,0 en el
 curso, reprobarán con nota 3,9.
• Es decir, es requisito para aprobar el curso obtener una nota 3,0 o
 superior en el examen.
 Profesor Francisco Rocca 17

[pág. 17]
Requisitos para rendir examen
Independiente del motivo y cantidad de justificaciones, el requisito mínimo para que un estudiante
pueda rendir examen del curso son:
• Haber sido evaluado en al menos el 50% del porcentaje total del curso sin considerar la
 ponderación del examen.
• Ejemplo: Si el examen del curso tiene una ponderación delal menos un 35% de la ponderación
 final del curso 30% del total del curso, el estudiante deberá haber sido calificado en [= 50% x (1 –
 0,3)].
• El estudiante que no cumpla con el requisito antes señalado no tendrá derecho a rendir el
 examen.
• El estudiante que por no cumplir requisitos no pueda rendir el examen y tenga nota de
 presentación inferior a 4,0, se le mantendrá la nota de presentación como calificación final del
 curso. Si, por el contrario, el estudiante tiene una nota de presentación igual o mayor a 4,0 y no
 pueda rendir el examen por no cumplir con el punto 1 antes señalado, será calificado con una
 nota final en el curso de 3,9.
• El estudiante que cumple con este requisito para rendir el examen del curso y justifica
 debidamente la inasistencia a este, será calificado con nota P en el curso y podrá rendir el examen
 pendiente en la fecha definida y publicada por la Facultad de Ciencias Económicas y
 Administrativas. La nota será modificada una vez corregido el examen recuperativo..
 Profesor Francisco Rocca 18

[pág. 18]
INASISTENCIA A EVALUACIONES Y RECORRECCIONES
• Respecto de inasistencias a las evaluaciones, sólo se justificará a aquellos estudiantes que realicen el
 proceso de justificación ante la Subdirección de Asuntos Estudiantiles de la Facultad de Economía y
 Administración, dentro de los plazos reglamentarios (3 días hábiles siguientes a la fecha de la
 evaluación).
• Si algún estudiante falta a la Prueba I o II, y cuenta con justificación de la Secretaría de Estudios,
 realizará una prueba recuperativa la semana siguiente a la semana de pruebas. En caso de que un
 estudiante falte a alguna de las pruebas parciales y no cuente con justificación obtendrá nota 1. Sólo
 se puede justificar la inasistencia a una de las pruebas.
• Si algún estudiante falta a más de un control de lectura y caso, y cuenta con justificación de
 Secretaría de Estudios (por todos los controles que no asistió), podrá dar un control recuperativo en
 la última clase. En el control recuperativo entran todas las lecturas del curso más un nuevo caso que
 será asignado, y reemplazará la nota del control justificado.
• La nota del Control Recuperativo se calculará utilizando la misma escala usada para el control que el
 estudiante faltó. Se podrá faltar como máximo a dos controles de lectura del total de cinco controles.
 Profesor Francisco Rocca 19

[pág. 19]
Recorrecciones
• Las solicitud de recorrecciones se entregarán al profesor COMO
 MÁXIMO 3 DÍAS DESPUÉS DE LA ENTREGA DEL CONTROL Y/O PRUEBA
 con nota adjunta (a través de un mail al profesor) que explique y
 fundamente claramente la solicitud de recorrección. No habrá
 excepciones.
• Todo proceso de recorrección involucra la revisión completa de la
 evaluación, por lo que la nota puede subir, bajar o mantenerse.
 Profesor Francisco Rocca 20

[pág. 20]
Comportamiento Esperado
• La Escuela de Administración considerará como copia o actos deshonestos el hecho de que los
 estudiantes transcriban como ideas propias cosas que ya han sido publicadas por otras personas
 antes.
• Es responsabilidad de todos los estudiantes de este curso velar por el cumplimiento del Código de
 Honor. Se espera una conducta respetuosa de sus compañeros y con el profesor durante las clases.
 Ello implica puntualidad, respeto por las opiniones del resto y buen comportamiento en clases. Les
 agradeceré apagar los celulares al entrar a clases. Se espera una excelente disposición a aprender,
 discutir y participar en clases.
• Para las evaluaciones que se hagan en los trabajos de clases se podrá ocupar cualquier dispositivo
 electrónico, sin embargo, el estudiante deberá estar presente para llevar a cabo la evaluación
 (control sorpresa, trabajo en grupo, análisis de caso, etc.).
• En caso de que un estudiante haga una evaluación de manera remota se le considerará ausente y se
 le pondrá un 1,0 en dicha evaluación sin derecho a eliminarla. Si un estudiante reincide en esta
 conducta, además de lo ya señalado, se llevará el caso a la Secretaría de Estudios para que se aplique
 la sanción correspondiente.
• Los alumnos que sean sorprendidos copiando en algunas de las actividades de clases tendrán nota 1
 en la actividad y será informada la rectoría de la situación. Esta nota no es borrable ya que se
 mantendrá para el promedio.
 Profesor Francisco Rocca 21

[pág. 21]
Contenidos del curso
Introducción al Conducta del Información del cliente y del
marketing Modelo de Negocios consumidor y comprador mercado
 Introducción Escoger el valor
 Análisis cuantitativo y Estrategia de
 Centralidad en el Segmentación de
 metodología de casos Posicionamiento
 cliente mercados
 Comunicaciones
Estrategia de Estrategia de integradas al Inteligencia artificial y Ética en el marketing
Marca precios marketing marketing
 Crear valor Capturar valor Comunicar el valor
 Estrategia de producto y Estrategia de canales Marketing digital
 servicios de distribución y Imarketing y Metaverso
 ventas

[pág. 22]
METODOLOGÍA PARA LA
RESOLUCIÓN DE CASOS

[pág. 23]
¿Que es un caso?
 Es la descripción de una situación real
 que un ejecutivo ha enfrentado en
 algún momento.
 • Definir el problema.
 • Evaluar los cursos alternativos de
 acción y recomendar e implementar
 un plan de acción para resolver la
 situación.
 • Limitaciones
 – Escasez de información y de tiempo
 para analizar los datos disponibles.
 – Incertidumbres y la ausencia de
 medios para reducirlas.

[pág. 24]
El método de casos
 La preparación de los casos se hace en
 etapas:
 1. Preparación individual para la reunión
 grupal.
 2. Discusión en grupos.
 3. Sesión de discusión general
 Se aprende participando, más que
 escuchando.

[pág. 25]
Preparación Individual
 • Buscar la información relevante pasando por alto lo irrelevante y
 superfluo, interprete los hechos, razone y evalué posibles cursos de
 acción y comentar a sus compañeros su decisión.
 • Los casos no son lineales, ya que están escritos para servir de base a
 una discusión.
 • Diferentes visiones aparecen como consecuencia de la inclusión de
 información que a veces no relevante o redundante.
 • Tips
 – Hagan una rápida lectura inicial para identificar la situación y el entorno
 del ejecutivo.
 – Aquí podrán ver la visión y las alternativas planteadas por el
 protagonista, no confíe en ellas, confíe en su propio análisis.
 – Luego de esta rápida lectura, lea con mayor atención subrayando la
 información mas relevante.
 – En esta etapa hay que entrar de lleno en el problema planteado en el
 caso.
 – La clave esta en determinar las decisiones que hay que tomar, cuales son
 los objetivos a considerar y a partir de eso, efectuar la mejor selección
 entre las alternativas.

[pág. 26]
Discusión con el grupo
 • Una buena reunión es aquella en la que
 se han compartido las ideas que todos
 han descubierto y las distintas visiones
 de los participantes.
 • Piensen que los otros alumnos se
 beneficiarán de sus aportes.
 • No se debe perseguir el consenso o
 cambiar la visión individual de cada
 participante, sino enriquecerla con otros
 puntos de vista.
 • No utilicen esta instancia para realizar
 una lectura colectiva del caso, no es
 productivo van a perder tiempo.

[pág. 27]
Análisis general del caso
 • Es fundamental la participación activa en las
 discusiones.
 • Un aspecto esencial para el aprendizaje por el
 método del caso es que, la mayor cantidad de
 participantes haga la presentación de sus
 puntos de vista y defienda sus posiciones.
 • Hay que escuchar atentamente para entender
 y criticar constructivamente las posiciones de
 otros.
 • Es muy raro que la discusión grupal no agregue
 nuevas perspectivas a las posiciones
 individuales.
 • El saber comunicar correctamente las propias
 ideas a diversos auditorios es una necesidad.

[pág. 28]
SHOW CIRCUIT FROZEN DOG DINNER

[pág. 29]
Profesor Francisco Rocca 37

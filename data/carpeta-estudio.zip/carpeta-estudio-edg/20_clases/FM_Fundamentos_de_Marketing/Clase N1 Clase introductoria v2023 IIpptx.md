# Fundamentos de Marketing · Clase N1 Clase introductoria v2023 IIpptx

Fuente: clase de Fundamentos de Marketing

[pág. 1]
Introducción
Profesor Francisco Rocca 1

[pág. 2]
¿Que es Marketing para
 ustedes?
 Profesor Francisco Rocca 2

[pág. 3]
Contenido del curso
 Conducta del
Introducción al Modelo de consumidor y Información del cliente y del
marketing Negocios comprador mercado
 Introducción Escoger el valor
 Análisis cuantitativo y Estrategia de
 Centralidad en el Segmentación de
 metodología de casos Posicionamiento
 cliente mercados
 Comunicaciones
Estrategia de Estrategia de integradas al Inteligencia artificial y Ética en el
Marca precios marketing marketing marketing
 Crear valor Capturar valor Comunicar el valor Tecnología en marketing
 Estrategia de producto Estrategia de Marketing digital
 y servicios canales de Imarketing y Metaverso
 distribución y
 ventas

[pág. 4]
¿Donde debe estar el Foco?
 En las necesidades de los
 consumidores, y el valor
 que les podemos entregar.
 Profesor Francisco Rocca 12

[pág. 5]
El foco son las necesidades de los consumidores!!
• “La clave para alcanzar las
 metas de la organización
 consiste en determinar las
 necesidades y deseos del
 segmento/mercado objetivo
 y satisfacerlas en forma
 más efectiva y eficiente
 que los competidores”
 Profesor Francisco Rocca 13

[pág. 6]
Para esto tenemos que desarrollar un proceso de Marketing
Como creamos valor?
• Entender el mercado y las
 necesidades de los clientes.
• Diseñar una estrategia de Marketing
 centrada en el valor a los clientes.
• Diseñar un programa de marketing
 integrado que entregue un valor
 superior.
• Atraer a los clientes, fidelizarlos y
 construir relaciones rentables; y crear
 clientes felices.
• Capturar valor desde los clientes para
 generar utilidades y una relación
 rentable con los clientes.
 Profesor Francisco Rocca 14

[pág. 7]
El concepto de Valor
 Beneficios Percibidos Costos Percibidos
• Mejores atributos. • Gasto en $$
• Mejores beneficios. • Gasto en tiempo.
• Servicios • Costo en esfuerzo.
 complementarios. • Costos psicológicos.
• Imagen de Marca. • Costos de cambio.
• Responsabilidad social. • Costos futuros.
 Valor = Beneficios - Costos
 Profesor Francisco Rocca 15

[pág. 8]
Subjetividad del valor
• Los valores de los consumidores
 son subjetivos, y percibimos de
 manera diferente las marcas.
• Nuestra percepción acerca de lo
 que valoran los consumidores
 (funcional) pueden ser muy
 diferentes de los que ellos
 realmente valoran (psicológicos).
• Debemos entender y tener cuidado
 de cómo nos perciben los
 consumidores.
• Es fundamental testear y medir.
 Profesor Francisco Rocca 16

[pág. 9]
La Evolución del Marketing
¿Cómo ha ido
evolucionando el
marketing para crear valor
a consumidores que
cambian rápidamente y
cada día son más
exigentes?
 Profesor Francisco Rocca 18

[pág. 10]
Los modelos de
 negocios y la entrega
 de valor son un
 concepto dinámico que
 constantemente migra
 por efecto de cambios
 en el consumidor,
 competencia, entorno y
 cambios tecnológicos.
Profesor Francisco Rocca 23

[pág. 11]
El Entorno
 ¿Cuál es el entorno
 que nos rodea como
 marca, y cómo me
 afecta?
 Profesor Francisco Rocca 39

[pág. 12]
Factores de Entorno Remoto
Macro Fuerzas Tendencias
 Profesor Francisco Rocca 40

[pág. 13]
Las Empresas
 La Política
 La Sustentabilidad
Los Movimientos Sociales
 Profesor Francisco Rocca 41

[pág. 14]
Factores del entorno cercano que afectan a las marcas
 según Michael Porter
COMPETIDORES COMPRADORES PROVEEDORES SUSTITUTOS
POTENCIALES
Amenaza de entrada Poder de negociación Poder de negociación Amenaza de productos
de nuevos del cliente. del proveedor. sustitutos.
competidores.
 Profesor Francisco Rocca 42

[pág. 15]
Análisis FODA
 Profesor Francisco Rocca 43

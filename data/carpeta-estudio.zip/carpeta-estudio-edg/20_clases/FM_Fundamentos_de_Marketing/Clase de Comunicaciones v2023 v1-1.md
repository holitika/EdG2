# Fundamentos de Marketing · Clase de Comunicaciones v2023 v1-1

Fuente: clase de Fundamentos de Marketing

[pág. 1]
Prof. Francisco Rocca

[pág. 2]
Comunicaciones Integradas (CIM)
• Las comunicaciones integradas son una forma de examinar todo el
 proceso de marketing desde el punto de vista del receptor,
 convirtiendo a desconocidos en clientes y promotores de la marca

[pág. 3]
Para entregar una
estrategia
coherente, todos
los elementos de
marketing y de
comunicación
deben estar
INTEGRADOS y ser
coherente con el
posicionamiento
de la marca y
transmitir un solo
mensaje

[pág. 4]
Desafíos de CIM en Marketing
1. Coherencia entre los distintos puntos de
 contacto con el cliente. Consistencia con la
 propuesta de valor.
2. Sinergia, para reforzar el posicionamiento y
 el valor de marca.
3. Complementariedad para llegar desde el
 reconocimiento de marca hasta la lealtad
 del cliente para estar presentes en la ruta de
 compra del cliente.
4. Eficiencias en el uso (en términos
 económicos y de alcance).
5. Desarrollar una estrategia comunicacional e
 implementar planes de comunicación.

[pág. 7]
Rol de CIM
 Reforzar el mensaje
 Construir notoriedad Estimular a la acción
 Asociaciones y creencias
Conseguir un nivel de notoriedad Reforzar el mensaje para mantener, Motivar al mercado objetivo para
determinado en relación con la a lo largo del tiempo, el nivel llevar a cabo una acción específica
marca ,organización, sus deseado de recuerdo en relación a corto plazo (call to action).
productos y servicios. con la imagen, beneficios básicos y
 nombre de la compañía y sus
 marcas.

[pág. 8]
Pero existen filtros a la comunicación
 Exposición Atención Comprensión Retención
Mensaje selectiva selectiva selectiva selectiva
 Exposición selectiva es el Atención hacia El receptor interpreta Es recordar la información
 proceso cognitivo que hace los objetos o los mensajes de que le conviene a los
 que tendamos a buscar, estímulos que acuerdo a principios individuos, influenciado por
 aceptar y atender a los nos resultan subjetivos para las necesidades, actitudes y
 mensajes que concuerdan relevantes : ajustarlos a su otros factores psicológicos.
 con sus creencias y Ejemplo cuando posición: Ejemplo Las Ejemplo Una persona con
 actitudes, evitando filtramos los personas con fuertes afinidad política hacia un
 información que ponga en mails que no son creencias religiosas determinado partido político
 duda aquello en lo que importantes. pueden filtrar la puede prestar atención y
 creen. información para que retener principalmente las
 Ejemplo Ignorar la esté en línea con sus noticias y opiniones que
 comunicación política a la convicciones religiosa apoyan su postura
 cual no es afín.
 ¡Los consumidores retenemos sólo una parte
 de lo que nos comunican las empresas!

[pág. 9]
Piensen en 3 marcas de shampoo que se le venga a la mente y
traten de describir lo siguiente:
• La publicidad utilizada por cada una de las marcas.
• El logotipo de la marca.
• Su slogan
• Otros elementos diferenciadores.

[pág. 11]
Las estrategias en Comunicaciones
¿Cómo es el proceso comunicacional para lograr
 captar la atención?

[pág. 12]
Las tres estrategias clave en comunicaciones para captar la
atención
 Estrategia Estrategia de Estrategia
 conceptual medios creativa
 Los mensajes, el El dónde, cuándo El cómo.
 qué y los por y cuánto.
 qué.

[pág. 13]
El plan comunicacional: principales decisiones
 (6M de las comunicaciones).
MARKET MISSION MESSAGE MEDIA MONEY MEASUREMENT
Segmento Objetivos Mensaje Ejecución de Presupuesto Evaluación
 medios
Con quien Qué queremos que Qué queremos Cuánto Evaluación de la
queremos hablar ocurra: decir Dónde (medios), necesitamos campaña
 cuándo y qué tan gastar
 Construir
 seguido lo
 patrimonio/equity de
 deberíamos decir
 marca (largo plazo)
 Aumentar las
 intenciones de
 compra y sus
 precursores (corto
 plazo)

[pág. 14]
El segmento : ¿A quiénes les vamos a hablar?
• Definir los segmentos objetivos,
 que pueden ser:
 – Clientes finales.
 – Influenciadores.
 – Canales de distribución.
 – Fuerza de venta.

[pág. 15]
Objetivo: ¿Qué queremos que ocurra?
Informar Recordar Persuadir
Contarle al mercado acerca Recordarles a los Construir preferencia de
de un nuevo producto. consumidores que marca.
Sugerir nuevos usos para un pueden necesitar el Incentivar el cambio de
producto. producto en el futuro. marca.
Informarle al mercado de Cambiar la percepción
un cambio de precios. Recordarles a los que tienen los
Explicar cómo funciona el consumidores dónde consumidores en
producto. pueden comprarlo. relación al producto.

[pág. 16]
Objetivo: ¿Que queremos que ocurra?
 Tipos de objetivos
 Objetivos de publicidad Objetivos promocionales
Foco: Marca Foco: Producto
• Aumentar el gasto de los clientes en • Motivar una mayor frecuencia de compra.
 nuestros productos. • Inducir a que los potenciales prospectos que
• Aumentar la base de clientes. prueben el producto o servicios.
• Aumentar la demanda por la categoría. • Educar acerca de los beneficios.

[pág. 17]
El Mensaje: ¿Que queremos decir?
Desarrollar una posición y una
personalidad:
 – Focalizarse en los beneficios a los
 consumidores y las relaciones
 positivas con la marca.
Concepto creativo “gran idea”:
 – Visualización frase, video, imagen,
 etc.
 – Combinación de ambas.
Publicidad atractiva
 – Significativa y relevante para el
 cliente.
 – Creíble.
 – Distinta de la competencia.

[pág. 18]
El Mensaje: ¡¡¡Que sea creativo!!!

[pág. 19]
El plan de medios
• Alcance y frecuencia.
• Elegir entre los distintos tipos de medios
 – Deben ser adecuados para la audiencia
 (segmento objetivo) al que queremos
 comunicar
• Medios que utiliza el segmento objetivo,
 como y cuando los usa. Dependerá del
 producto y del mensaje.
 – Seleccionar los medios a utilizar , en base a
 un análisis de costos y beneficios.
• Tiempo que usarán los medios
 Calendarizar la publicidad durante el
 curso del año

[pág. 20]
Hoy, cada vez hay un mayor uso de medios no
 tradicionales
¿Cuáles son los medios tradicionales?
 Televisión, radio, prensa, relaciones públicas y promociones.
Cuáles son los medios no Tradicionales
 Marketing directo y Medios sociales, marcas que aparecen en
 películas o programas de televisión, mensajería y publicidad al correo
 personal, etc.

[pág. 22]
La ejecución: Pros y contras de los medios
 tradicionales y no tradicionales de publicidad.
 Medios Tradicionales Medios No Tradicionales: Medios Sociales
LO QUE PUEDE HACER: LO QUE PUEDE HACER:
Llegar a grandes audiencias. Llegar directamente a la persona u hogar que se quiere, en forma
Crear conciencia y familiaridad. personalizada.
Construir imagen de marca. Es una comunicación bidireccional e interactiva (hay respuestas,
Posicionar el producto o servicio. feedback).
Describir el producto o servicio. Es más fácil medir el resultado de la publicidad.
Apoyar introducción nuevos productos. Entregar mensajes distintos a cada persona o grupo.
 PRINCIPALES PROBLEMAS:
PRINCIPALES PROBLEMAS:
 Varía mucho en cuanto a precisión; depende de la calidad de la base de
La comunicación es unidireccional (no hay feedback ni
 datos.
interacción).
 Invasivo, puede molestar a la audiencia.
Potencial de confusión o malentendidos.
 Baja tasa de respuesta en correos
Difícil lograr impacto en las ventas en el corto plazo.
 Saturación.
 22

[pág. 23]
¿Qué medios deberíamos usar en cada una
 de las etapas del viaje de compra del
 cliente?
Cada medio cumple su rol, tiene distinto impacto y costo…todos
deben actuar en forma coherente y complementándose:
No podemos decir a priori que hay medios mejores que otros!

[pág. 24]
Foco de las distintas plataformas

[pág. 25]
El presupuesto: ¿Cuál será el presupuesto de
 comunicaciones?
1. Presupuesto histórico (lo
 invertido cada año) y/o lo que
 podemos gastar dado los
 recursos de la empresa.
2. Porcentaje de las ventas: ¿es un
 gasto variable o una inversión?
3. Share of voice de la
 competencia (porcentaje del
 total que hace la industria).
4. Por objetivos y tareas a cumplir.

[pág. 26]
La evaluación
Medir la efectividad es crítico tanto
para distribuidores como para
proveedores, ya que determina la
rentabilidad.
1. Puede existir un alto volumen
 de recursos comprometidos.
2. Sin evaluaciones es imposible
 aprender qué resulta y qué no.
3. Pueden transformarse en un
 juego entretenido, pero inútil.

[pág. 27]
La Evaluación, algunas métricas de evaluación de
 la publicidad
• Reach (alcance): número de
 personas diferentes o hogares
 expuestos a la publicidad.
• Frequency (frecuencia): número
 promedio de veces que un
 individuo está expuesto a un
 aviso publicitario.
• Gross rating points (GRPs):
 Alcance X Frecuencia.
 Aunque Ripley tuvo más ALCANCE el ruido publicitario término siendo más bajo que el de Paris debido a que
 su frecuencia media fue más débil.

[pág. 28]
La Evaluación, algunas métricas de evaluación de la
 publicidad
• Rating: % de hogares en un
 mercado que están sintonizados
 a un canal y programa específico
 en un minuto.
• Cost per thousands (CPM): Es el
 costo de la publicidad dividido
 por el número en miles de
 individuos expuestos.

[pág. 29]
La evaluación: Elasticidad de la
 publicidad
Cambio porcentual que genera en el volumen de ventas el
aumento de un 1% en el gasto publicitario.

[pág. 30]
Evaluación: ROI
ROI = Beneficios incrementales ganados – Costo de la inversión en Marketing
 Costo de la inversión en Marketing
La medición del ROI también debe considerar el largo plazo ya que las
comunicaciones eficientes permiten a las empresas generar activos a largo
plazo como es el patrimonio de marca que le permite producir utilidades
futuras.

[pág. 31]
La Evaluación: La evaluación del programa
 publicitario debe ser en función del objetivo
 planteado.
• ¿Se está comunicando bien lo que la marca quiere comunicar?
• ¿El segmento objetivo comprendido el mensaje?
• ¿Si fuera una promoción, logró la comunicación aumentar las
 ventas?

[pág. 33]
Ejemplo campaña gennials, banco
 falabella
MARKET MISSION MESSAGE MEDIA MONEY MEASUREMENT
Segmento Objetivos Mensaje Ejecución de medios Presupuesto Evaluación
Hombres y mujeres Aumentar base de Banco Falabella: el Mix de medios Sin información En un mes de campaña,
de edad media consumidores para banco de los Gennials tradicionales y no creció 967% en cuentas
digitalizados productos del banco. tradicionales corrientes, 353% en
 clientes CMR, 96% en
 créditos de consumo y
 224% en Súper Avance.
 Las visitas a la web
 crecieron 12% en abril y
 34% en mayo

[pág. 34]
La evaluación ,la publicidad tiene un efecto
 multiplicador
El mensaje puede perdurar en el
tiempo
• La publicidad continúa
 generando efecto en las ventas a
 medida que pasa el tiempo, pero
 este efecto es cada vez menor.

[pág. 35]
La evaluación ,la publicidad tiene un efecto
 multiplicador
Conciencia de la publicidad y
frecuencia del mensaje.
• El awareness por parte del
 cliente respecto a la campaña de
 marketing (conciencia) va
 aumentando en el tiempo, pero a
 tasas decrecientes

[pág. 36]
Brief Creativo

[pág. 37]
¿Que es un brief creativo?
• El brief es información necesaria
 para desarrollar una campaña
 publicitaria.
• Este debe ser claro ya que es una
 herramienta fundamental para el
 proceso de comunicación.
• El brief se realiza en forma
 conjunta con la agencia de
 publicidad.

[pág. 41]
Francisco Rocca

[pág. 42]
Storytelling
• El storytelling es el término que se usa para referirse a
 «contar historias». ... El crear historias alrededor de
 tu marca es una estrategia que hará que empatices
 más con tu audiencia y crees vínculos con ella.
• Y eso significa fidelizar a tus clientes, ventas
 recurrentes; e incluso, convertirte en una marca
 amada.
 Francisco Rocca

[pág. 43]
Los 4 elementos de una historia
Mensaje Caracteres Conflicto Trama
Un fuerte mensaje Identificables e Es la fuerza impulsora Las buenas historias son
ideológico o una lección imborrables caracteres del proceso en las dinámicas y avanzan
moral a menudo pueblan nuestras buenas historias. por un camino
permea las historias historias favoritas. Obliga a los héroes a evolutivo.
más memorables. Caracteres como actuar y presenta A menudo, una buena
El mensaje define la nosotros o que dificultades trama al comienzo atrae
premisa central de la representan el tipo de insuperables para a la audiencia que se
historia y la resolución persona que aspiramos superar. engancha con la
exitosa de ésta, prueba a ser, llaman nuestra Los villanos son una historia.
su veracidad. atención y generan contraparte importante
 empatía. de los héroes..
 Suele ser la marca.

[pág. 44]
Arquetipos de tramas y caracteres
• Ejemplos
 • Venciendo al monstruo (ej: Harry Potter)
 • Pobreza a la riqueza (ej: David v/s Goliat; La Cenicienta)
 • La búsqueda (ej: El Señor de los Anillos)
 • Renacer (ej: La Bella y la Bestia)
 • Tragedia (ej: Romeo y Julieta)
 Francisco Rocca

[pág. 45]
Ejemplo de historias de marca
• Un nivel fundamental es todo sobre la marcas: qué es, cómo
 pensamos, recordamos o nos relacionamos con ella
 Vence al monstruo Historias de Un lugar mágico
 de tu limitación pequeño lujo y entretenido
 Francisco Rocca

[pág. 46]
Etapas diseño de narración de una historia
 ¿Cuál es la ¿Cuál es el ¿Cuál es la ¿Cuáles
 ¿Quién es la historia? plataformas usará
 misión dela objetivo del
 audiencia? para distribuirla?
 marca? negocio?
 Historia de la marca Puntos de dolor Logros de la historia de Idea Elección de la
 Misión de la marca Puntos de pasión marca: Estructura plataforma
 Propósito de la marca Motivadores Ventas Compromiso de la
 Propuesta de valor Problemas Motivación audiencia
 Facilitadores para Liderazgo de
 lograr metas pensamiento

[pág. 47]
Como estructurar una historia
 Francisco Rocca

[pág. 48]
Estructura de la historia “reunión google”
 Francisco Rocca

[pág. 49]
Francisco Rocca

[pág. 50]
Lo que vimos hoy
• Las comunicaciones integradas en marketing (CIM) tienen como objetivo informar, recordar
 y persuadir a los consumidores para que respondan de cierta forma al producto, mensaje o
 servicio.
• Las CIM disponen de distintas herramientas, las que deben actuar en forma coordinada y
 coherente con la propuesta de valor y posicionamiento de la empresa
• La estrategia comunicacional implica definir qué se quiere comunicar (estrategia
 conceptual), dónde y cuándo (estrategia de medios) y cómo se quiere comunicar (estrategia
 creativa).
• El plan comunicacional implica definir a quiénes les queremos comunicar, por qué, cuál será
 el mensaje, los medios y la frecuencia con la que aparecerá este mensaje. Además, se debe
 definir un presupuesto para la campaña y luego hacer una evaluación.
• Hoy, la comunicación es cada vez más a través de medios digitales, los que tienen varios
 beneficios por sobre los tradicionales, como su menor costo.
• Como podemos contar una historia atractiva para comunicar lo que queremos comunicar

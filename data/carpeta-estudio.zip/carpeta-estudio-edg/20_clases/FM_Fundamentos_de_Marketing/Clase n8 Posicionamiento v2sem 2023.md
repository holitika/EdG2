# Fundamentos de Marketing · Clase n8 Posicionamiento v2sem 2023

Fuente: clase de Fundamentos de Marketing

[pág. 1]
FRANCISCO ROCCA

[pág. 2]
Partamos desde la Esencia
 01
 SEGMENTACIÓN
 02
 03
 MERCADO
 POSICIONAMIENTO OBJETIVO

[pág. 3]
¿Que es el posicionamiento de marca?
 • El posicionamiento de marca es el lugar que
 ocupa una marca en la mente de sus
 consumidores en relación con otros
 competidores en el mismo mercado.
 • Es la percepción que los consumidores tienen
 de una marca en función de sus atributos,
 valores, beneficios y características distintivas.
 • El objetivo del posicionamiento de marca es
 crear una imagen y una identidad única para
 la marca que la diferencie y sea relevante
 para su segmento objetivo.
 • Debemos encontrar posiciones no ocupadas
 por otras marcas y que sean importantes y
 significativas para los consumidores.
 FRANCISCO ROCCA

[pág. 4]
Que nos permite hacer el posicionamiento
• Diferenciar nuestra marca de
 la competencia.
• Generar constante interés en
 la marca al destacar sus
 atributos más importantes.
• Permite proteger a la marca
 de los ataques de la
 competencia
 FRANCISCO ROCCA

[pág. 5]
Los consumidores somos los que
determinamos el posicionamiento
de una marca según la reacción
que esta les provoca.
 FRANCISCO ROCCA

[pág. 6]
¿Que se Posiciona?
 FRANCISCO ROCCA

[pág. 7]
Un buen posicionamiento debe ser…
 Diferenciador Relevante para el consumidor
 Memorable
 FRANCISCO ROCCA

[pág. 8]
Las estrategias de posicionamiento
 1.DISTINCIÓN 2.COMPETENCIA
 Cuáles son las características Cómo son percibidas las distintas
 distintivas a las que los
 consumidores reaccionan
 1 2 marcas competidoras en relación
 a estas características?
 favorablemente?
4.MARKETING 3.POSICIÓN COMPETITIVA
¿Cuáles son los medios de ¿Cuál es la mejor posición para
marketing más apropiados ocupar en este segmento?
para ocupar y defender esa
posición?
 4 3 Depende de:
 • Posición ocupada por la
 competencia
 • Expectativas de los consumidores

[pág. 9]
Estrategias de Posicionamiento
 Es una combinación entre el
 segmento DONDE
 competiremos y la ventaja
 comparativa de CÓMO
 vamos a competir
 FRANCISCO ROCCA

[pág. 10]
Estrategias de posicionamiento
 ¿En que están basadas?
 Relación Ocasión de Seguridad Facilidad en
precio calidad consumo tecnología
Estilo de Vida Mobiliario con
 Durabilidad Precios Bajos
 estilo a bajo
 precio
 FRANCISCO ROCCA

[pág. 11]
Como se construye un posicionamiento?
A través del desarrollo de una
 propuesta comercial única,
 diferente y superior.
 FRANCISCO ROCCA

[pág. 12]
FRANCISCO ROCCA

[pág. 13]
1-¿Como se construye el posicionamiento?
1. Definir los puntos de paridad (POP) y los puntos de diferencia
 (POD) con la competencia.
2. Creación de una declaración de posicionamiento.
 FRANCISCO ROCCA

[pág. 14]
Diagrama de Venn
 (Estructura del posicionamiento)
 “POINT OF PARITY (POP)”
 Atributos Asociaciones que hacen los consumidores y que
 beneficios Necesidad de no son exclusivas de la marca, sino más bien de
 irrelevantes los
 POD la categoría o los competidores
 Nuestros consumidores
Oferta de puntos de
 diferenciación Brecha de
la marca insatisfacción
 ”POINT OF DIFFERENCE (POD)”
 POP
 POD Asociaciones que hacen los consumidores que son
 POP
 irrelevantes Sus puntos de exclusivas de la marca, destacando algún atributo
 diferencia
 que es relevante y positivo para ellos.
 Es necesario contar con la diferenciación para que
 Oferta de la exista!
 competencia

[pág. 15]
1-¿Como se construye el posicionamiento?
• POP (Point of Parity)
 – Los puntos de paridad son aquellos elementos que se consideran
 obligatorios para que una marca se considere un competidor legítimo
 en su categoría específica. Asociaciones que son compartidas por
 otras marcas.
• Dos Tipos
 – Categoría: atributos que son de una categoría en especial.(Cerveza:
 quita la sed )
 – Competitiva: POP que niegan los POD de tus competidores. (El
 verdadero sabor cola con una caloría “Pepsi One”)
 FRANCISCO ROCCA

[pág. 16]
1-¿Como se construye el posicionamiento?
• POD (Point of Difference)
 – Fuertes , favorable y tiene que tener una única asociación con la marca.
 – Puede ser cualquier tipo de atributo o beneficio percibido por el
 consumidor.
• Dos tipos de POD
 – Atributos basados en:
 • Lo funcional que generen diferencias inherentes al producto, (mayores
 funcionalidades). Ej: Omo lava mas blanco
 • Basados en la imagen de marca que generen diferencias (afecto,
 experiencias etc.) Ej:Nike (desempeño, tecnología innovadora y éxito
 deportivo)
 FRANCISCO ROCCA

[pág. 17]
1-Como se deciden los POP y POD
POP
• Análisis de la categoría.
 – ¿Que atributos tienen mis competidores? tendré que tener esos
 atributos o mi competencia tienen ya POD .
• POD son mas difíciles de decidir.
• No usar POD desde el punto del producto , tienen que ser del
 punto de vista del consumidor.
 FRANCISCO ROCCA

[pág. 18]
1-Criterios para definir los POD
• Tienen que ser Relevantes
• Tienen que ser Distintivos.
• Tienen que ser Creíbles.
• Tienen que ser Realizables.
• Tienen que ser Comunicables.
• Tiene que ser Sustentables.
 FRANCISCO ROCCA

[pág. 19]
1-¿Como se construye el posicionamiento?
 • Destaca los atributos
 compartidos en la categoría
 (POP) pero resalta el desempeño
 superior de la marca “OMO
 remueve las manchas difíciles”
 FRANCISCO ROCCA

[pág. 20]
1-¿Como se construye el posicionamiento?
 • Añadir nuevos atributos,
 beneficios o valor para atraer
 mas consumidores. Ej
 Subway se posiciono como la
 opción sana de la comida
 rápida
 FRANCISCO ROCCA

[pág. 21]
2-¿Como se construye el posicionamiento?
• El proceso se realiza creando una Declaración de
 Posicionamiento, que informa sobre el valor único que
 ofrece la marca a un segmento del mercado en
 particular.
• Sintetiza la propuesta de valor de la marca.
• Responde al ¿Por que debo comprarlo?
 FRANCISCO ROCCA

[pág. 22]
Elementos de una declaración de Posicionamiento
 Formato para la propuesta de posicionamiento
 (el beneficio funcional más importante o atributo asociado al producto-
 La Marca PROVEE distintivo, importante, sustentable, claro, superior, rentable, y creíble)
 (descripción del segmento– ‘Quién’ (Necesidades de uso [problema a ser resuelto], Contexto
 PARA compra; ojalá definido por sus valores QUE de uso [cuándo, cómo, dónde usado], y/o beneficios
 y estilo de vida.) sicológicos deseados)
 (Marco competitivo—clase de producto y posibles sustitutos). Marco de referencia. ¿En
EN COMPARACIÓN A qué categoría está?
 PORQUE TIENE (Características claves y discriminantes que soportan la promesa) razón para creer
 29

[pág. 23]
Ejemplo
FRANCISCO ROCCA

[pág. 24]
Ejemplo
FRANCISCO ROCCA

[pág. 25]
Mapas de posicionamiento
• Los consumidores usamos por lo general entre 2 a 4
 dimensiones o variables cuando pensamos en una categoría
 de productos o servicios.
• Las dimensiones más relevantes para los consumidores se
 pueden graficar en un mapa de posicionamiento.
• En el mapa de posicionamiento, se localizan las posiciones de
 los actuales y posibles competidores respecto a las
 dimensiones.
• Es subjetivo, ya que depende de percepciones
 FRANCISCO ROCCA

[pág. 26]
Objetivo de los mapas de posicionamiento
• Su objetivo es identificar
 las dimensiones
 relevantes de evaluación
 y localizar las posiciones
 de los actuales y
 potenciales productos en
 estas dimensiones.
 FRANCISCO ROCCA

[pág. 27]
Mapa de Posicionamiento
 FRANCISCO ROCCA

[pág. 28]
Mapas de Posicionamiento
 FRANCISCO ROCCA

[pág. 29]
¿Cómo usar esta herramienta?
• Ubicarse en el mapa y también a la competencia.
• Comprobar que no estemos en un cuadrante malo o incoherente
 (ejemplo: percibidas como de baja calidad y de alto precio).
• Identificar espacios donde ya hay muchos competidores y evitarlos.
• Identificar espacios desocupados que puedan ser “nichos de
 mercado” .
• Decidir el lugar para posicionarse y diferenciarse de la competencia .
• Diseñar e implementar el mix de marketing coherente con el
 posicionamiento.
 FRANCISCO ROCCA

[pág. 30]
¿Cuando reposicionar una marca?
Cuando cambian algunos de los elementos de una declaración de
Posicionamiento vistos anteriormente.
• Para quién, para cuando, y para donde.
 – Nos cambio el segmento o queremos ampliar las ocasiones de consumo o que el
 consumidor cambie sus hábitos de comprar.
• Qué valor estamos entregando.
 – Nuevas declaraciones de propuesta de valor para ajustarse a las nuevas necesidades de
 los consumidores. Estas no pueden ser contrarias a las ya existentes deben construirse
 sobre las actuales.
• Grupo Competitivo
 – Cuando cambia el set de competidores.
• Por que y como?
 – Creación de nuevos productos mejorados que refuerzan el valor anterior de la marca.
 FRANCISCO ROCCA

[pág. 31]
¿Cuándo reposicionar una marca?
• Marca tiene una mala imagen, confusa o inexistente.
• Necesidad de alinearse con las tendencias del mercado
 (digitalización).
• Dificultad de permanecer tanto tiempo en la mente del
 consumidor.
• Adquisición de una ventaja competitiva potente que debe reflejarse
 en el posicionamiento de marca.
• Renovación de la cultura de la empresa.
• Entrada de un nuevo competidor con una propuesta de valor
 superior.
 FRANCISCO ROCCA

[pág. 32]
ANTES DESPUÉS
 FRANCISCO ROCCA

[pág. 33]
Un posicionamiento exitoso es cuando…
• El segmentos objetivo lo internalizan con rapidez
• Fluye con naturalidad.
• Diferencia la marca de otros productos de la misma categoría.
• Vincula la marca con lo que quieren los segmentos objetivos.
• Permite que los segmentos objetivos vean la marca de una
 manera clara.
• Facilita el entendimiento de la marca.
• Ser los primeros.
 FRANCISCO ROCCA

[pág. 34]
Beneficios de un buen Posicionamiento
• Liderazgo en sus industrias o categorías.
• Marcas fuertes generan consistencia y credibilidad para el
 crecimiento en otras áreas o segmentos de negocio.
• Es una promesa creíble del valor entregado.
• Es el único elemento diferenciador con respecto a otras
 marcas en un mundo crecientemente comoditizado.
• Es el determinante de las estrategias de marketing.
 FRANCISCO ROCCA

[pág. 35]
Trabajo en grupo
Caso NOTCO (10 minutos)
 FRANCISCO ROCCA

[pág. 36]
Caso de Inditex
 FRANCISCO ROCCA

[pág. 37]
Inditex
 Fundación 1963
Zara Fundador : Amancio Ortega
 Empleados totales 164.997
Pull and Bear
 Mercados 202
Massimo Dutti Tiendas 5.800
 Visitas a la web 16 millones de visitas diarias
Bershka
 Vtas fuera de España 56%
Stradivarius
 Facturación( 2022) 32.569 mill de Euros +17,5% vs. aa
Oysho Utilidad 4.130 mill de Euros +27.5% vs. aa
Zara Home
f
 Ecuación de valor
 Innovación + Adaptabilidad al consumidor local + Rapidez de producción +
 Logística +Información
 FRANCISCO ROCCA

[pág. 38]
Posicionamiento de sus marcas
 FRANCISCO ROCCA

[pág. 39]
Las marcas Inditex en el mundo
 FRANCISCO ROCCA

[pág. 40]
ESTILO: Elegancia y seguimiento de tendencias a bajo precio
SEGMENTO OBJETIVO: Consumidores de todas las edades que buscan ropa
moderna y a la moda a precios asequibles
 Mujeres y hombres modernos y elegantes
 “ZARA, SIEMPRE UN PASO POR DELANTE, ES UN MOTOR DE CAMBIO EN EL
 PANORAMA DE LA MODA, CON TENDENCIAS E INSPIRACIÓN AL ALCANCE DE
 TODOS. SU RAZÓN DE SER ES PROPORCIONAR A CADA PERSONA, SEA QUIEN
 SEA, LA MODA QUE MERECE: SIEMPRE ACTUAL, INSPIRADORA Y PRODUCIDA DE
 MANERA RESPONSABLE.”
 FRANCISCO ROCCA

[pág. 41]
ESTILO: Casual y deportiva, respetando 3 principios: moda, precio y calidad.
SEGMENTO OBJETIVO: Consumidor joven y urbano que busca ropa
casual, cómoda y asequible con un enfoque en la ropa de estilo informal,
deportiva y de calle.
 “Pull&bear captura el espíritu de una juventud vibrante. La marca, que combina lúdicamente las
 últimas influencias de la escena internacional de clubs, los movimientos sociales globales y el
 mundo del arte y de la música, hace de la moda algo divertido para los que van a la vanguardia de
 la cultura.”
 FRANCISCO ROCCA

[pág. 42]
ESTILO: Moda de gran calidad, con imagen de marca a precios medios.
SEGMENTO OBJETIVO: Hombres y mujeres que buscan un estilo más clásico y atemporal.
 “MASSIMO DUTTI ES EL PARADIGMA DE UNA VISIÓN DEPURADA DE LA ELEGANCIA NATURAL EN
 NUESTRO MUNDO DE HOY. CREA MODA SOFISTICADA CON LA QUE RESPONDER A LAS DEMANDAS
 DE GENTE URBANA, INDEPENDIENTE, PARA LA QUE UN ESTILO DE CALIDAD ES EL REFLEJO”.
 FRANCISCO ROCCA

[pág. 43]
ESTILO: encuentro vanguardista de la moda, la música y el arte de la calle.
SEGMENTO OBJETIVO: Adolescentes que buscan tendencias mas atrevidas y
provocadoras
 “BERSHKA SE MUEVE EN LA CONFLUENCIA DE MÚSICA, TECNOLOGÍA Y COMUNIDAD SOCIAL. BUSCA UNA
 EXPERIENCIA VANGUARDISTA Y ENVOLVENTE CON LA QUE CONECTAR A LA JUVENTUD URBANA MÁS A COOL CON
 LAS TENDENCIAS EMERGENTES MÁS ROMPEDORAS DE LA MODA. ”
 FRANCISCO ROCCA

[pág. 44]
ESTILO: moda internacional con diseños de vanguardia.
SEGMENTO OBJETIVO: Mujeres jóvenes con un carácter muy dinámico, que
quieren vestir la última moda: elegir qué les gusta de cada tendencia y combinarlo
creando un estilo propio y único.
 “EN UN CONTEXTO DE TENDENCIAS EN CONSTANTE EVOLUCIÓN, STRADIVARIUS APUESTA POR EL ESTILO
 PERDURABLE DE CREER EN NOSOTROS MISMOS. TRANSFORMA LAS ÚLTIMAS TENDENCIAS EN UNA MODA QUE
 NOS PERMITA EXPRESARNOS CON COMODIDAD, CUANDO Y DONDE QUERAMOS. .
 FRANCISCO ROCCA

[pág. 45]
ESTILO: últimas tendencias en ropa interior y homewear.
SEGMENTO OBJETIVO: Mujer joven y moderna de poder adquisitivo medio alto
 “OYSHO TIENDE SOBRE LO ETERNO Y LO ACTUAL LA MIRADA DE UNA ELEGANCIA
 FEMENINA Y PODEROSA. SUS PRENDAS SON UNA CELEBRACIÓN DE LA MUJER Y DE LA
 SILUETA FEMENINA EN LA QUE SE CONJUGA MODA Y ELEGANCIA CON CONFORT Y
 CALIDAD PARA LAS MUJERES ACTIVAS Y MODERNAS DE TODO EL MUNDO.
 FRANCISCO ROCCA

[pág. 46]
ESTILO: artículos de moda para vestir y decorar la casa.
SEGMENTO OBJETIVO: familias jóvenes de clase media que buscan las últimas tendencias de la moda
para su hogar, calidad a buen precio.
 “ZARA HOME INFUNDE UN DISEÑO SOFISTICADO Y ATEMPORAL EN TODO UN MUNDO
 DE PRODUCTOS QUE ENALTECEN NUESTRO DÍA A DÍA Y ABREN NUEVOS CAMINOS PARA
 LA EXPRESIÓN.”
 FRANCISCO ROCCA

[pág. 47]
Que vimos hoy…
• El posicionamiento es la forma en la que nuestros clientes piensan y sientan respecto a la
 marca y nos permite diferenciarnos de la competencia y tener nuestra propia identidad.
• Para diseñar un posicionamiento, debemos considerar los atributos que los clientes valoran
 de nuestra marca y buscar posiciones que no estén ocupadas por la competencia
• Existen distintas estrategias de posicionamiento, algunas basadas en los atributos del
 producto, el tamaño, precios bajos, tipo de usuario, ocasión de uso, calidad del producto,
 etc.
• La declaración de posicionamiento es una frase que comunica interna y externamente la
 esencia del posicionamiento de la empresa: qué proveen, a quién, qué necesidad satisface y
 cómo lo hace.
• El mapa de posicionamiento es una herramienta que permite graficar los actores de una
 industria en base a las variables más relevantes de esta. Visualizarlos y considerarlo
 contribuyen a definir estrategias de posicionamiento exitosas.
 FRANCISCO ROCCA

# Fundamentos de Marketing · Clase N3 Modelos de negocios

Fuente: clase de Fundamentos de Marketing

[pág. 1]
Francisco Rocca

[pág. 2]
Definición
Un modelo de negocio
describe las bases sobre
las que una empresa
crea, proporciona y
capta valor
 Francisco Rocca

[pág. 3]
Crecimiento
Los modelos de negocios son CLAVE
 para el crecimiento de las
 compañías.
 Francisco Rocca

[pág. 4]
¿Por que crecer?
 01
 NECESIDADES DE
ATRACCIÓN DE TALENTO INVERSIÓN
 Imagen de marca 02 Utilidades
 Utilidades Participación de Mercado
ATRACCIÓN DE
INVERSIONISTAS PRESIÓN COMPETIDORES
 O SUSTENTABILIDAD
 Imagen de marca 04 Participación de Mercado
 Retorno de inversión Ventas
 .
 Ventas
 Utilidades 03

[pág. 5]
¿Como crecer?
• El cambio en el Matriz de Ansoff
 comportamiento de los
 consumidores, el avance
 tecnológico, la aparición
 de nuevos actores en el
 mercado, implica que los
 modelos de negocios
 estén en constante
 evolución.
 Francisco Rocca

[pág. 6]
¿Como crecer?
Desarrollo de mercados Fidelización o penetración de mercado.
• Productos actuales en nuevos • Productos actuales en mercados
 mercados. actuales.
• La estrategia consiste en identificar • La estrategia consiste en aumentar la
 nuevos mercados, donde los participación de mercado del
 productos actuales pueden ser producto o servicio actual.
 valorados y comercializados con • Para aumentar la penetración en el
 éxito. mercado se deben realizar actividades
• Pueden ser: publicitarias y de promoción, para
 – Nuevos segmentos de mercado. aumentar el consumo de los clientes
 – Nuevos canales de distribución. actuales o atraer a nuevos clientes del
 – Mercados extranjeros. mismo segmento
 Francisco Rocca

[pág. 7]
¿Como crecer?
Desarrollo de productos. Diversificación
• Nuevos productos en mercados actuales. • Productos nuevos en nuevos mercados.
• Desarrollar productos nuevos (calidad, • La estrategia consiste en crear productos
 funcionalidad, diseño, etc.) para ser nuevos y llevarlos a nuevos mercados.
 vendidos en el mercado actual. • Implica una combinación de las
• Puede ser: actividades de desarrollo de productos y
 • Nuevas gamas de productos (con mayor desarrollo de mercados.
 calidad) • Es una estrategia riesgosa, de alto retorno
 • Crear productos con nuevos modelos si es realizada con éxito.
 • Realizar mejoras técnicas o de diseño
 • Crear nuevas versiones (sabores, colores, etc.) • Se puede realizar con la misma marca o
• Implica actividades como el diseño y usar otro.
 lanzamiento de productos.
 Francisco Rocca

[pág. 8]
Principales componentes de un modelo de
 Four Steps Infographic
 negocios Slides
 ¿a quién? ¿Cómo nos organizamos?
 Segmento Como nos Estructura
 Objetivo. Estructuramos
 de costos
 01 03
 Flujo de
 Propuesta Ingresos
 de Valor .
Disposición 02 04
a pagar
 ¿Cómo ganamos dinero?
 ¿Qué prometemos?

[pág. 9]
2 Propuesta de valor
 Trata de resolver problemas
 de los Consumidores y
 7 Actividades clave satisfacer las necesidades del 4 Relación con el cliente
 mediante la realización de cliente con propuestas de se establecen y mantienen con
 una serie de actividades valorr cada segmento de Consumidores
 fundamentales
 1 Segmentos
8 Red de partners de
 Algunas actividades se
 externalizan y algunos
 Consumidores
 recursos se adquieren Uno o varios
 fuera de la empresa segmentos de
 Consumidores
 5 Flujos de ingreso
 9 Estructura de costos 3 Canales de distribución y Los ingresos son el resultado de
 Los elementos del modelo de 6 Recursos clave
 son los medios necesarios para
 comunicaciones propuestas de valor ofrecidas
 con éxito a los Consumidores.
 negocio dan como resultado la Las propuestas de valor se
 estructura de costos. ofrecer y entregar los elementos entregan a los Consumidores a
 descriptos anteriormente través de la comunicación, la
 distribución y los canales de venta
Source:Business Model Generation . Francisco Rocca

[pág. 10]
Modelo de negocios de Canvas
 Francisco Rocca

[pág. 11]
Propuesta de Valor
• ¿Por qué mi segmento me debe
 elegir? ¿Qué me diferencia de la
 competencia?
• ¿Qué valor estamos entregando a
 nuestros clientes?
• ¿Qué ventaja competitiva tengo
 respecto a mi competencia?
• ¿Qué problemas resolvemos?
• ¿Qué necesidad satisfacemos?
• ¿Qué tipo de producto ofrecemos?
 Francisco Rocca

[pág. 12]
Para definir la Propuesta de Valor necesitamos definir
 primero el perfil de cada segmento
 Perfil para cada segmento
 •Qué beneficios logra el
 segmento del producto o
 servicio (Incluye utilidad
 funcional o social o emociones Ganancias
 positivas
 • Las tareas que tiene que
 completar el segmento
 • Los problemas de fondo que
 Trabajos del intenta resolver
 segmento
 •Qué molesta a su segmento
 •Qué le hace perder el sueño Dolores
 •Cuáles son sus principales
 frustraciones
 14

[pág. 13]
Ejemplo: Perfil del segmento de de Uber para el segmento
 Usuarios
 Perfil de cada segmento de segmento
 Ganancias
 •Viajar en un auto
 mejor que un taxi
 •Servicio de calidad Trabajos
 •Eficiencia del segmento
 •Autos Limpios
 •Seguridad
 Buscan viajar
 Dolores
 •No hay
 transparencia
 •No les satisface la
 oferta de taxi
 •Poca seguridad
 15

[pág. 14]
Ejemplo, definir la propuesta de valor de Uber
 Propuesta de valor Perfil de cada segmento de cliente
 Generadores de
 Ganancia ¿Cómo sus servicios y Ganancias
 productos pueden generar
 ganancias a los Segmentos? •Viajar en un auto
Productos y • Diferentes tipos de mejor que un taxi
 servicios transportes. •Servicio de calidad Trabajos del Cliente
 • Buena presentación. •Eficiencia
 • Choferes especializados. •Autos Limpios
 ¿Qué servicios y • Cobros por recorrido. •Seguridad
 productos ofrecerá? Buscan viajar
•Un Uber siempre
disponible. Calmantes Dolores
•Seguridad
•Disponibilidad cuando •No hay transparencia
lo necesite. •No les satisface la oferta de
•Diferentes tipos de ¿Cómo vamos a aliviar los taxi
auto. dolores? •Poca disponibilidad
 • Valor del viaje conocido de •Poca seguridad de viajar en
 antemano. Taxi
 • Oferta de autos diversa
 • Un Uber en tu ubicación
 en pocos minutos.
 16

[pág. 15]
Modelo de negocios vs. Plan de Negocios
MODELO DE NEGOCIOS PLAN DE NEGOCIOS
•Es la fórmula que permite definir cómo •Es una guía con los pasos necesarios
entregaremos un producto y servicio a un para que se cumplan las metas del
determinado segmento de clientes. negocio.
 •Permite definir objetivos
•Permite estructurar cómo funcionará la
 organizacionales, cómo se trabajarán
empresa, en base a la propuesta de valor.
 dentro de la organización.
•Permite comprender todos los •Define las acciones internas que llevará
elementos necesarios para llegar con la cada área de trabajo para cumplir con el
propuesta de valor a los clientes. plan.
 Francisco Rocca

[pág. 16]
Proceso de un plan de negocios
 Identificar Priorizar Visualizar Medir
 Selección de
 Análisis situación Desarrollo de la Desarrollo de los Seguimiento y
 Análisis FODA objetivos y Presupuestos
 actual estrategia planes medición
 prioridades
 18

[pág. 17]
¿Cómo la Transformación Digital ha irrumpido en los Modelos de
 Negocios?
 Francisco Rocca

[pág. 18]
Propuesta de valor al 1952 1999 2001 2006
consumidor
Buena Música X X X X
Acceso instantáneo X X X
Gran selección de música en los X X X
dedos del consumidor
Elegir la canción que uno quiera X X X
Gratis X X
Portabilidad X X
 Francisco Rocca

[pág. 19]
Fintech
Francisco Rocca

[pág. 20]
Definición de modelos de negocios de plataformas
“Una plataforma es un negocio que crea valor a través de facilitar la
interacción directa entre dos o mas tipos de clientes.” Andrei Hagiu y
Julin Roberts
• ¿Cómo se diferencia de los modelos tradicionales?
 – Tienen distintos tipos de clientes
 – Las partes tienen interacción directa.
 – Tiene el rol de facilitadores
 Francisco Rocca

[pág. 21]
Francisco Rocca

[pág. 22]
Existen 4 tipos de modelos de negocios en las
 plataformas
 1. Intercambio/Marketplace 2. Hardware/Software Standards
Vendedor Comprador Desarrolladores Desarrolladores
 de Software de Software
Arrendador Arrendatario
Chofer Pasajeros
 Consumidores
 3. Sistemas de transacciones 4. Medios de soporte publicitarios
 Comercio Compradores
 Avisadores Audiencia
 Francisco Rocca
 Bancos

[pág. 23]
Otros ejemplos de modelos de negocios
 Francisco Rocca

[pág. 24]
Separación
 Francisco Rocca

[pág. 25]
Long Tail
• Este es el concepto de vender menos de mas , y consiste en vender
 muchos productos de nicho, los cuales se venden en menores
 volúmenes. Se requiere bajo inventario y una fuerte plataforma de
 productos para los interesados.
 Francisco Rocca

[pág. 26]
Modelo de precios Freemium

[pág. 27]
5- Modelos Abiertos
Open Innovation Marketplace
 Francisco Rocca

[pág. 28]
Evolución del valor económico
• Cómo los modelos de negocios
 han migrado del foco en
 productos al foco en experiencias
 del cliente con la marca.
• Vivimos en la Economía de la
 Experiencia.
• Las empresas han basado sus
 modelos de negocio cada vez
 más en ofrecer una experiencia
 de calidad en las distintas etapas
 del viaje del cliente.
 Francisco Rocca

[pág. 29]
PROGRESIÓN DEL VALOR ECONÓMICO
 Teoría de Jim Gilmore y Joe Pine (1999). A medida que la economía progresa, la experiencia es más valorada.
DIFERENCIACIÓN
 EXPERIENCIAS
 Entregar experiencias
 SITUACIÓN SERVICIOS NECESIDADES DE
 COMPETITIVA Proveer servicios LOS CLIENTES
 BIENES
 COMMO Fabricar bienes
 DITIES
SIN DIFERENCIACIÓN Extraer commodities
 PRECIOS DE ESTRATEGIA DE PRECIOS
 MERCADO PRECIOS PREMIUM
 40

[pág. 30]
PROGRESIÓN DEL VALOR ECONÓMICO
 De la uva a un tour en una viña
DIFERENCIACIÓN
 Entregar experiencias
 SITUACIÓN NECESIDADES DE
 COMPETITIVA Proveer servicios LOS CLIENTES
 Fabricar bienes
SIN DIFERENCIACIÓN Extraer commodities
 PRECIOS DE ESTRATEGIA DE PRECIOS
 MERCADO PRECIOS PREMIUM
 41

[pág. 31]
Buscando la excelencia y la innovación en cada experiencia
 de nuestros clientes: el “Customer Journey”
Experiencia
 Experiencia Experiencia Experiencia Experiencia
de
 de entrega de uso de soporte promocional
búsqueda
 Experiencia Experiencia
 Experiencia de Experiencia Experiencia de
 de compra comunicacional
 facturación de servicio demostraciones
 Francisco Rocca

[pág. 32]
Resumen.
• Los modelos de negocios son la base para que las empresas puedan crear,
 capturar, y entregar valor.
• Los modelos de negocios son claves para el crecimiento.
• Un modelo de negocios es dinámico, pudiendo ser modificado, rediseñado, o
 adaptarlo en base a los cambios que son continuos y rápidos.
• Los modelos de negocios son para experimentar nuevas oportunidades de
 negocios.
• No hay un modelo de negocio único , existen diferentes modelos de negocios
 que son desarrollados de acuerdo a la empresa.
• La Transformación Digital ha irrumpido en los Modelos de Negocios.
• Hoy en día el valor y la diferenciación esta en la experiencia que podamos dar a
 nuestros consumidores
 Francisco Rocca

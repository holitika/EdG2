# Fundamentos de Marketing · Clase de repaso examen 2023

Fuente: clase de Fundamentos de Marketing

[pág. 1]
Clase de repaso examen final
 Noviembre 2023

[pág. 2]
Información del cliente y
Introducción Modelo de Conducta del
 del mercado
al marketing Negocios consumidor
 Introducción Escoger el valor
 Análisis cuantitativo Estrategia de
 Centralidad en el Segmentación de
 y metodología de Posicionamiento
 cliente mercados
 casos
 Comunicaciones
 Inteligencia artificial y
Estrategia de Estrategia de integradas al
 marketing
Marca precios marketing
 Crear valor Capturar valor Comunicar el valor
 Estrategia de Ética en el
 Estrategia de Marketing digital
 producto y servicios marketing
 canales de
 distribución y
 ventas

[pág. 3]
Esquema para enfrentar una pregunta
 ¿Qué situación plantea la pregunta respecto de la
 información existente en el caso?
 ¿De qué materia me están preguntando?
 ¿Qué solución le doy a la problemática planteada con las
 materias aprendidas?
 ¿Razones del por qué estoy dando esa solución?

[pág. 4]
Ejemplo de pregunta de Barbie prueba 1
 Fracaso de la compañía en el lanzamiento de Barbie en el
 mercado Chino
 ¿Qué hicieron mal?
 Desconocimiento de las consumidoras chinas
 ¿Cómo conocer a las consumidoras chinas?
 Obteniendo información del consumidor
 ¿Materia del curso?
 Investigación de mercado
 ¿Qué tipo de estudios me servirían para entender el
 comportamiento de las consumidoras objetivo?
 Estudios cualitativos
 ¿Por qué los estudios cualitativos?

[pág. 5]
Conceptos Claves
Análisis cuantitativo Modelo de negocios Centralidad en el Conducta del Consumidor. Información del Posicionamiento
• Margen Bruto Un modelo de cliente. Cómo los consumidores mercado y del cliente. El lugar que ocupa mi
• Punto de equilibrio negocios es una Es cuando se pone al toman decisiones de Transformar los datos marca en la mente del
• Canibalización descripción de cómo cliente en el centro de compra y cómo se ven en información. consumidor.
• Costos fijos una empresa planea todas las actividades y afectados por diversos Tipos de estudios de • POD vrs POP
• Costos variables generar ingresos y decisiones de una factores mercado. • Mapas de
Siempre aplicar obtener beneficios organización. Proceso de toma de • Cualitativos posicionamiento.
• ¿Cómo crear valor a • Cultura corporativa. decisiones del consumidor. • Cuantitativos • Declaración de
 los consumidores y • Capacidades para 1.Reconocimiento del Importancia de las posicionamiento.
 clientes? entender al cliente problema decisiones basadas en • Reposicionamiento
• La ruta del cliente es • Sistemas de 2.Búsqueda de información datos
 clave para evaluar la Información 3.Evaluación de alternativas
 Segmentación
 creación de valor. • Recursos humanos 4.Decisión de compra
 Es el proceso de
• El marketing mix Retencion de clientes y 5.Post compra
 identificar grupos de
 considera las 4 P el valor de los clientes ¿Qué objetivos tengo como
 personas o empresas
 cliente y el LTV . marca en cada etapa?
 que tienen
 posicionamiento. ¿Cuáles son los medios más
 necesidades y/o
• Creación de ventajas adecuados para cada
 comportamientos de
 competitivas etapa?
 compra similares y que
 reaccionan de similar
 manera a las acciones
 de marketing.
 • Variables de
 segmentación.
 • Quienes son mis
 consumidores

[pág. 6]
Conceptos Claves
 Ahora viene la estrategia que es lo más concreto
 Estrategias de Precio
Estrategia de Marca Arquitectura de Marca Estrategias de Estrategias de Es la única variable con la que capturamos el
Una marca identifica a • Monolítica productos Servicios. valor creado. Tiene un rol como indicador de
los productos o • Endosada Desarrollo de • Características. valor.
servicios de una • Independientes productos nuevos. • Intangibles Indicador de Captura de Valor
empresa y que la • Hibridas • Nueva categoría • Inseparables Valor
diferencia de la Estrategias de marcas • Extensión de línea • Perecibles
competencia logrando • Extensión de marca • Mejoras a productos • Heterogéneos.
una relación con los • Estirar la marca existentes. Modelo de brechas
consumidores, las • Cobranding • Reducción de costos Dimensiones del
marcas tienen un • Marcas propias. • Totalmente nuevos. servicio.
valor. Existen pro y contras Extensión de línea. • Tangibilidad
Como crear valor a de cada una de las • Pro y contras • Confiabilidad
través de una marca estrategias, que hay • Canibalización
 + • Seguridad
 Conceptos de demanda que influyen en el
 valor percibidos.
Aaker que evaluar • Complementariedad • Empatía • Precios de referencia
• Reconocimiento • Costo de oportunidad • Rapidez • Disposición a pagar
• Fidelidad Ciclo de vida El servicio de calidad • Elasticidad precios
• Asociaciones • Introducción genera valor y la • Aspectos psicológicos de los precios.
 positivas • Crecimiento experiencia de los Banda de precios
• Calidad percibida • Madurez clientes es clave Estrategias de precios.
 • Declinación • Penetración
 • Descreme
 • Reducción
 • Mantención
 • Prestigio
 • Segmentada/Dinámica

[pág. 7]
Conceptos Claves
Canales de Distribución Comunicaciones Marketing Digital Inteligencia Artificial Ética y Responsabilidad social
Estructura de canales Integradas Definición de Objetivos En el contexto del empresarial (RSE)
• Exclusiva Estrategia • Reach marketing, la IA se utiliza • La ética se refiere a los
• Selectiva Comunicacional • Act para recopilar y analizar principios y normas que rigen
• Intensiva • Segmento • Convert grandes cantidades de el comportamiento humano,
Estrategia • Objetivos • Engage datos, identificar considerando lo moralmente
• Niveles de servicios • Mensaje Medios a utilizar patrones y tendencias, correcto o incorrecto.
 demandados • Medios Tradicionales y • Medios Ganados automatizar tareas y • La moral, se refiere a las
• Funciones comerciales digitales • Medios propios tomar decisiones basadas normas y valores que rigen el
• Selección de • Presupuesto • Medios pagados en algoritmos, comportamiento de un
 intermediarios • Medición Estrategias que facilitan el diseño individuo o un grupo en
• Administración. + • SEM de técnicas inteligentes particular.
Omnicanalidad vrs ¿Cómo podemos influir • SEO para la automatización • “La ética es un elemento
Multicanalidad. al consumidor en todo el Evaluación de campañas. de la experiencia con intrínseco de las decisiones y
La ruta de compra y la viaje de compras? CPC Costo por click el cliente. de las acciones en razón a la
omnicanalidad CPM Costo por mil • Machine learning responsabilidad y la moralidad
 CTR % de clicks • Deep learning de la toma de decisiones”.
 TC Tasa de conversión • Neutralización de la ética.
 ROI • Lo legal vs. lo Ético.
 LTV Life time value • La RSE busca tener un balance
 LT Life Time entre el desarrollo económico,
 Churn Tasa de abando el progreso social y la
 CAC Costos de adquirir un protección del medio
 cliente. ambiente
 CLV valor de un cliente

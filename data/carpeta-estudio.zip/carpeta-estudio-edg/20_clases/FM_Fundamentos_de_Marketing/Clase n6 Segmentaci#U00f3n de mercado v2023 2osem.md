# Fundamentos de Marketing · Clase n6 Segmentación de mercado v2023 2osem

Fuente: clase de Fundamentos de Marketing

[pág. 1]
SEGMENTACION DE MERCADO
 FRANCISCO ROCCA

[pág. 2]
Definición
Es el proceso de identificar grupos de personas o empresas que tienen
necesidades y/o comportamientos de compra similares y que reaccionan de
similar manera a la acciones de marketing.

[pág. 3]
Características de los segmentos
HOMOGENEIDAD
Lo mas homogéneos posibles a los que
 HETEROGENEIDAD
pertenecen al mismo segmento o Lo mas heterogéneos posibles
grupo. respecto a los otros segmentos o
Tienen comportamientos , grupos.
motivaciones y necesidades similares.
 FRANCISCO ROCCA

[pág. 4]
¿Por que creen ustedes que segmentamos?
 FRANCISCO ROCCA

[pág. 5]
¿Cuál es el objetivo de la segmentación?
 El objetivo es crear un valor particular para
 cada segmento, que sea rentable para la
 organización en el tiempo y diferenciable de
 la competencia.
 • Nos permite conocer profundamente a los
 consumidores.
 • Podemos crear ofertas de marketing y
 comunicaciones relevantes para cada
 consumidor específico.
 • Crear estrategias comerciales específicas.
 • Aumentar las utilidades.
 • Concentrar los esfuerzos y recursos.
 FRANCISCO ROCCA

[pág. 6]
La esencia del concepto de segmentación
 DISCRIMINACIÓN DINAMISMO ¿LO CORRECTO?
 Lo relevante es
 descubrir las La segmentación No existen a
 variables de es un concepto priori
 segmentación dinámico, variables de
 que me debido segmentación
 permitan al constante “correctas”
 discriminar el cambio en el
 mercado en consumidor,
 forma rentable, comprador y la
 a oferta
 través de competitiva
 propuestas de
 valor
 diferenciadas.

[pág. 7]
Características de una buena segmentación
 MEDIBLE SUSTENTABLE
 Que pueda cuantificarse el mercado
 potencial y medir el desempeño si
 01 Que tenga un tamaño
 económicamente viable
 02
 decidimos entrar en él.
 ACCESIBLE ACCIONABLE
Que se pueda llegar en forma adecuada
a los segmentos (distribución, servicios,
 03 Que sea factible definir propuestas de
 valor para satisfacer al segmento
 04
etc.). definido.
 RENTABLE DIFERENCIABLE
Que nuestra inversión nos entregue un
retorno razonable en relación a la
inversión en tiempo y recursos requeridos.
 05 Que podamos crear una ventaja
 diferenciadora en este segmento.
 06

[pág. 8]
Aspectos importantes de la segmentación
• Los mercados se segmentan en base a consumidores y no a
 los productos.
• Se debe basar la segmentación en las diferentes
 necesidades de los consumidores.
• Se debe elegir los segmentos en base al atractivo de mercado
 que tengan y las fortalezas con que cuente la empresa.
• Un mismo producto se puede dirigir a distintos segmentos,
 pero se corre el riesgo de perder el foco
 FRANCISCO ROCCA

[pág. 9]
Estrategias de marketing según su segmentación
 Marketing Marketing Marketing de Micro
 Masivo Segmentado Nicho Segmentación
 Empresas con Son estrategia de Son estrategia de marketing que se
estrategias centradas en Son estrategias que tienen marketing en que se centra en segmentos de mercado muy
 hablar de sus diferentes propuestas de centran en solo un específicos con el objetivo de ofrecer
 productos/servicios y valor para diferentes segmento de productos, servicios y mensajes de
 sus características Ej grupos de consumidores, consumidores. marketing altamente personalizados
 Retail Ej: Coca-Cola Ej: Consumidores Ej: Personas con alergias alimentarias.
 Veganos

[pág. 10]
Preguntas clave para segmentar un mercado :
 ¿Qué mercados y ¿Dónde podemos crear
 01 necesidades debemos
 servir?
 valor más que nadie? Calce
 de la propuesta de valor
 04
 ¿Criterios para priorizar:
 crecimiento, rentabilidad, ¿En qué segmento podemos
02 barreras, competencia,
 potencial, etc.?
 capturar ese valor antes que
 la competencia? 05
 ¿Posibilidades de
 03 construir una posición
 fuerte?
 ¿Costos de entrada y
 competencia? 06

[pág. 11]
La Segmentación Paso a Paso
1 Investigar las necesidades
 actuales y potencial de usuarios.
 2 Analizar los distintos comportamientos
 de los consumidores en su categoría.
3 Seleccionar las variables de
 segmentación.
 4 Cuantificar los segmentos.
5 Determinar atractivo de
 segmento.
 6 Seleccionar los segmentos mas
 rentables.
7 Desarrollar un plan para diferenciar su
 propuesta de valor a cada segmento
 seleccionado. 8 Seleccionar los medios de
 comunicación y canales de distribución
 para llegar al segmento en forma
 eficiente

[pág. 12]
Variables de Segmentación de mercados
“Su empresa nada tiene que hacer en mercados donde no pueda ser la mejor.”
 Philip Kotler, Profesor de Marketing Kellogg School, Northwestern University
 FRANCISCO ROCCA

[pág. 13]
Las variables clásicas de segmentación
 VARIABLES SOCIODEMOGRÁFICAS
 Edad, Sexo, Nivel Social, Cultura,
 1
 BENEFICIOS BUSCADOS ingresos, Ocupación Empleo
 educación etc..
 Comodidad, Valor, seguridad,
 estatus.
 5
 2
 Principales VARIABLES PSICOGRÁFICAS
 variables de
 segmentación Personalidad, Estilos de Vida
 Gustos Personales, intereses,
 4 opiniones.
 3
VARIABLES DE COMPORTAMIENTO .
 Fidelidad, Frecuencia de uso,
 Ocasión de consumo ,tipo de VARIABLES GEOGRAFICAS
 usuario, comportamiento de País , región, ciudad, zona urbana
 compras. /Rural, clima

[pág. 14]
Las variables clásicas de segmentación de los consumidores
 industriales
 VARIABLES DEMOGRÁFICAS
 Tipo de industria, tamaño, número de años en el
 1
 BENEFICIOS BUSCADOS mercado, factores financieros (ventas, utilidades,
Comodidad, Valor, seguridad, la calidad participación de mercado), ciclo de vida de los
percibida, la economía que aporta, la
imagen que proyecta.
 5 productos y uso final del producto.
 2
 Principales POR USO FINAL DEL PRODUCTO
. variables de
 segmentación Tipo de producto, la frecuencia
 de uso y la variedad de usos.
 4
 3
 VARIABLES GEOGRAFICAS .
 País , región, ciudad, zona
 urbana /Rural, clima POR CRITERIO DE COMPRA
 Centros de poder centralizados v/s descentralizados
 Estructura de poder: finanzas, marketing, producción
 De acuerdo a lo que buscan: precio, calidad, servicio,
 confiabilidad.

[pág. 15]
Variables de Segmentación
• A priori no existen variables de segmentación correctas o
 incorrectas.
• Lo relevante es descubrir la(s) variable(s) de segmentación que
 me permitan discriminar el mercado en forma rentable, a
 través de propuestas de valor diferenciadas.
• Es un concepto dinámico por el constante cambio en el
 consumidor-comprador y la oferta competitiva
 FRANCISCO ROCCA

[pág. 16]
¿Como elegir la mejor variable?
• Para segmentar no necesariamente se utiliza una sola variable ,
 lo habitual es que se utilicen una combinación de ellas.
 – Quien es nuestro consumidor?
 – Cual es el comportamiento de compra?
 – Por que compran un producto en particular?
 FRANCISCO ROCCA

[pág. 17]
VEAMOS ALGUNAS VARIABLES DE
 SEGMENTACIÓN
 FRANCISCO ROCCA

[pág. 18]
Segmentación por tipo de usuario
• Nuevo a la categoría
• Nuevo a la marca
• Antiguedad como cliente.
• Ex cliente
• Con características especiales
 FRANCISCO ROCCA

[pág. 19]
Más ejemplos de variables
• Segmentando por Valor Presente del Cliente (A,B,C)
• Segmentando por Costo de servir al Cliente
• Por sensibilidad al Precio
• Segmentando por disponibilidad de dinero “Money in the
 Pocket”
 FRANCISCO ROCCA

[pág. 20]
Diferentes tipos de consumidores por valor
 Consumidores + Valiosos: Retener
 Consumidores con mas potencial de
 crecimiento: Hacer Crecer
 Consumidores Marginales: Business
 as usual?
 ‘Bajo Cero’ :
 Se dejan?
 Costo de Servir
 Source: Peppers & Rogers Group
 Segmentos de consumidores
 Valor Actual Valor Estrategico( Participación Potencial)
 FRANCISCO ROCCA

[pág. 21]
Usando Google Analytics para segmentar
• Los diez segmentos de Google Analytics en orden aproximado de valor para los
 especialistas en marketing son:
 – Segmentación por referente / fuente de tráfico
 – Segmentación por tipo de visitante
 – Segmentación por Ubicación / Geografía
 – Segmentación por contenido visto
 – Segmentación por tipo de página de aterrizaje
 – Segmentación por Acción realizada
 – Segmentación por Valor
 – Segmentación por Demografía.
 – Segmentación por compromiso
 – Segmentación por plataforma tecnológica
 Fuente: Smartinsights
 Dave Chaffey

[pág. 22]
Segmentación por Ciclo de Vida
Jóvenes Solteros y Jóvenes con Familias Nido Vacío Jubilados
parejas sin Hijos Hijos Maduras
 FRANCISCO ROCCA

[pág. 23]
Segmentación por la Ley de Pareto
 CONSUMIDORES RENTABILIDAD
 20% 80%

[pág. 24]
Segmentación por beneficios buscados
• Calidad y atributo del productos.
• Rapidez de respuesta
• Calidad del servicio
• Precios
• Servicios tecnológicos
• Imagen proyectada por la marca.
 FRANCISCO ROCCA

[pág. 25]
EJ: Segmentación por beneficios buscados
 Energía Disminución del transito
 lento
 Dieta Diferentes
 funciones
 FRANCISCO ROCCA

[pág. 26]
Segmentación por intensidad y frecuencia de
 uso
• Compra anual, mensual, semanal, diaria.
• Comprador intensivo, regular, ocasional
 FRANCISCO ROCCA

[pág. 27]
¿Cual es la variable de Segmentación?
 Modernidad y Gente joven

[pág. 28]
¿Cual es la variable de Segmentación?
 Seguridad y Prestigio

[pág. 29]
¿Cual es la variable de Segmentación?
 Sofisticación e imagen
 proyectada por de Marca

[pág. 30]
¿Cual es la variable de Segmentación?
 Buscadores de precios

[pág. 31]
Estrategia de segmentación Zoom
Pensando en la herramienta zoom,
que tomó protagonismo durante la
pandemia, ¿cuáles serían tres
variables de segmentación
relevantes para la Compañía, que le
permitan crear segmentos
definidos?
 FRANCISCO ROCCA

[pág. 32]
Que vimos hoy
El proceso de segmentación nos permite:
• Nos permite conocer mas profundamente al consumidor.
• El objetivo de la segmentación es buscar la o las variables que permiten
 discriminar el mercado en forma diferenciadora respecto a la competencia
• Entregar una propuesta de valor mas ajustada al consumidor.
• Genera foco en las acciones de marketing.
• Permite ser mas eficiente en el uso de los recursos de marketing.
• La comunicación con el consumidor se hace mas eficiente y directa.
• Las variables de segmentación son múltiples.
 FRANCISCO ROCCA

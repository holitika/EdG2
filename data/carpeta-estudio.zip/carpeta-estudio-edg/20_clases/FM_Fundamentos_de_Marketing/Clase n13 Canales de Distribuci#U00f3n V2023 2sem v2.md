# Fundamentos de Marketing · Clase n13 Canales de Distribución V2023 2sem v2

Fuente: clase de Fundamentos de Marketing

[pág. 1]
Canales de Distribución
 Prof: Francisco Rocca
 Profesor :Francisco Rocca

[pág. 2]
Definición
Los canales de distribución o canales de Son las etapas por las que debe pasar un
comercialización son un conjunto de producto antes de ser comercializado.
organizaciones interdependientes
involucradas en el proceso de hacer de
que un producto y/o servicio estén
disponibles para su uso y consumo para
el consumidor final o el consumidor
industrial .
 Productor Es adquirido por un Es adquirido por un Es adquirido por un
 fabrica el mayorista que son minorista que son consumidor final
 producto empresas de gran empresas pequeñas para satisfacer sus
 capacidad de con contacto con el necesidades o deseos
 almacenaje consumidor final
 Profesor :Francisco Rocca

[pág. 3]
La cadena de distribución de cerveza Corona en Chile
 Fabricante Distribuidores Retail Consumidor
 Supermercados final
 ABInbev Embonor y
 Embotelladora Almacenes
Mayor grupo Negocios de barrio
 Andina
cervecero en Botillerias
 el mudo
 Profesor :Francisco Rocca

[pág. 4]
¿Por qué creen ustedes que los productores no
 venden directamente a los consumidores?
 Profesor :Francisco Rocca

[pág. 5]
Las razones son ………..
 • Los productores no tienen los suficientes
 recursos financieros para llevar a cabo
 ventas directas
 • La venta directa no es factible si existen
 muchos compradores y se necesita llegar
 a la mayor cantidad de consumidores.
 • El usar canales de distribución les permite
 a las empresas liberar recursos de
 manera de invertirlos en el negocio en el
 cual se encuentran.
 • Por qué los intermediarios son más
 eficientes.
 Profesor :Francisco Rocca

[pág. 6]
Entonces …¿Qué hacen los canales de distribución por los
 fabricantes?
 • Conectan al productor con el consumidor.
 • Posibilitan llegar a un mayor número de
 consumidores finales, generando más
 ventas.
 • Dan mayor alcance comercial al contar
 con servicio de bodegaje y transporte que
 permiten llegar a distintos puntos
 geográficos.
 • Dan una ventaja competitiva cuando hay
 una estrategia adecuada de llegar al
 segmento objetivo y posicionar la marca
 con ellos.
 • Permite que los productos lleguen de
 manera óptima y segura a los clientes
 finales, optimizando el proceso de
 distribución
 Profesor :Francisco Rocca

[pág. 7]
Estructura de los canales de distribución
 Canal Directo
Recorrido corto de comercialización. El productor
vende al consumidor final sin intermediarios
Es ampliamente usado por el e-commerce, ya sea
para la entrega de productos físicos o digitales.
(ejemplo: plataforma de e-commerce de la empresa)
Ventajas:
• Se puede llegar con un menor precio al
 consumidor final al eliminar los intermediarios Productor Consumidor final
• Retroalimentación directa del consumidor.
• Unifica el trabajo de promoción y distribución
Desventajas
• Requiere tiempo y dedicación
• El canal directo es de un alto costo
 Profesor :Francisco Rocca

[pág. 8]
Estructura de los canales de distribución
 Canal Indirecto
Intervienen intermediarios en el proceso hasta
que llega el producto al consumidor final.
Ventajas:
• Mayor eficacia al lograr un mayor alcance y
 oportunidad de llegar a los clientes .
• Menor costo de almacenamiento.
Desventajas
• Precio mayor al consumidor, ya que cada parte Productor mayorista Minorista o Consumidor final
 de la cadena se lleva un margen. retail
• Menor control por parte del productor.
• Puede generar tiempos más largos si la cadena
 es más larga.
 Profesor :Francisco Rocca

[pág. 9]
Niveles de los canales de Distribución
 Fuerza de Venta ; Sitio WEB
 Productor Retailer
 Consumidor
 Online
 Retailer
 Mayorista Retailer
 Mayorista Distribuidor Retailer
 Profesor :Francisco Rocca

[pág. 10]
Principios en la estructura de los canales de
 distribución
Se pueden eliminar o sustituir las organizaciones en la estructura
de canales. No obstante, las funciones que realizan estas
organizaciones no se pueden eliminar.
Cuando se eliminan las organizaciones , sus funciones se derivan
hacia atrás o hacia adelante en el canal y por consiguiente, las
asumen otros miembros.
 Profesor :Francisco Rocca

[pág. 11]
Distribución Intensiva
 • La empresa busca el mayor
 número de puntos de venta
 posible para asegurar la
 máxima cobertura del
 territorio de ventas y una
 cifra de ventas elevadas.
 • Facilita la compra por parte
 del cliente final
 Profesor :Francisco Rocca

[pág. 12]
Distribución Selectiva.
• Se selecciona a algunos
 distribuidores para la venta.
• Es para productos un poco más
 especializados y en donde el
 consumidor compara características
 y precios de los productos.
• Algunas características para
 seleccionas a estos distribuidores
 pueden ser su calidad de servicio,
 el tamaño del distribuidor
 referente a las ventas, y la
 competencia técnica siendo
 importante el servicio de Post
 Venta.
 Profesor :Francisco Rocca

[pág. 13]
Distribución Exclusiva.
 • Es cuando un solo distribuidor recibe
 el derecho de vender la marca y se
 compromete a no vender marcas
 competitivas en la misma categoría.
 • Esta estrategia es útil cuando el
 fabricante quiere diferenciar su
 producto por una política de alta
 calidad, de prestigio o de calidad de
 servicio.
 • En este tipo de distribución el
 productor tiene un mayor control del
 canal
 Profesor :Francisco Rocca

[pág. 14]
Estructura del canal
 Distribución
 Exclusiva Selectiva Intensiva
Variable
 Número de
 Pocos Intermedio Muchos
distribuidores
Diferenciación Alta Media o Baja Baja
 Márgenes Altos Medios Bajos
Control sobre
 Elevado Tiende a ser elevado Escaso
 el canal
 Cobertura Cobertura Alto costo
 Riesgos Insuficiente Insuficiente
 Profesor :Francisco Rocca Pérdida de control

[pág. 15]
Que rol cumplen los canales de distribución…
Promoción y comunicación→ Desarrollar y diseminar la comunicación y promoción a intermediarios y clientes
Almacenamiento→ Almacenar y mover físicamente los productos
Transporte→ Enviar los productos del fabricante al cliente final
Asumir riesgos→ Vigilar la transferencia de propiedad de los productos
Pedidos→ Poner órdenes de compra a los productores
Pagos→ Facilitar los pagos
Información→. Entregar información al productor del público objetivo, mercado, etc.
Negociación →Negociar precio y transferencia de propiedad
Financiamiento→ Financiar inventarios
 Profesor :Francisco Rocca

[pág. 16]
La fijación de precios y los canales de distribución
•El poder de negociación de •El precio que fija el canal •El fabricante o importador
los canales influye en el puede venir sugerido pueden en forma conjunta
precio de venta. directamente por el fabricante con el canal acordar
•A mayor poder de o importador. descuentos, (fabricante
negociación , se pueden •Obj: Se sugieren rangos de trata de que sean
negociar menores precios. precios para evitar esporádicos para no dañar
 competencia entre los la marca y la relación con
 distribuidores que afecten el los otros canales.)
 posicionamiento de la marca
 Profesor :Francisco Rocca

[pág. 17]
Definición de la estrategia de distribución
 ¿En base a qué factores determinamos la mejor
 estrategia de canales para llegar de la mejor
 manera posible a nuestro cliente?
 Profesor :Francisco Rocca

[pág. 18]
Estrategia de distribución
 Selección específica
 de los intermediarios
 Definir objetivos
 Evolución y
 de la distribución.
 selección de
 los canales
 Definir: Administración del canal de alternativos.
Análisis del distribución:
 Cobertura
consumidor final: - Manejo de conflictos.
 Número de niveles
Segmentación - Evaluación de la
 Funciones comerciales de eficiencia y eficacia.
Nivel de servicios las partes del canal.
demandados. Coordinación del sistema:
 - Administración (ej:
 incentivos)
 - Contractual
 (Franquicias)
 - Vertical (Cadena
 propia)
 Profesor :Francisco Rocca

[pág. 19]
Consideraciones en la elección de un canal de distribución
Características Características
 Características
 de los de los productos
 de la empresa
consumidores. y/o servicios
• Hábitos de compra •Carácter Perecedero. • Deseo de controlar los
 •Naturaleza técnica del producto canales.
• Sensibilidad al precio
 Industrial/ Servicio. • Servicios dados por el
• Niveles de servicios •Precio estimado de venta.
 demandados. productor.
 •Calidad
 • Recursos financieros.
• Preferencias en como •Importancia de las marcas
 • Poder relativo
 compran y pagan. •Marcas privadas
 •Necesidad de complementos
 •Nivel de competencia
 Profesor :Francisco Rocca

[pág. 20]
El Posicionamiento y la Distribución
 LA PERSONALIDAD DEL PRODUCTO
 ES AFECTADA, POTENCIADA O DAÑADA
 POR LA IMAGEN DEL DISTRIBUIDOR
 Profesor :Francisco Rocca

[pág. 21]
El Posicionamiento y la Distribución
 Profesor :Francisco Rocca

[pág. 22]
Dado lo anterior ¿en qué tipo de canales debería y en cuáles no comercializarse
estos productos?
 Profesor :Francisco Rocca

[pág. 23]
Diseño de un canal de distribución
 Profesor :Francisco Rocca

[pág. 24]
Diseño de un canal de distribución
 Profesor :Francisco Rocca

[pág. 25]
Las funciones comerciales surgen de los niveles de servicios
demandados (NSD) por el segmento objetivo
 Profesor :Francisco Rocca

[pág. 26]
Asignación de tareas al interior del canal
 • La asignación de tareas y funciones
 comerciales, así como su intensidad, debe
 hacerse en función de:
 – Costos (¿quién lo hace al menor costo?)
 – Desempeño (¿quién cumple mejor con los
 NSD?)
 – Estratégico (¿Cuál es mi rol clave ante el
 cliente?)
 Profesor :Francisco Rocca

[pág. 27]
Análisis de los canales para determinar oportunidades y
 amenazas. Paso a paso.
• Identificar a cada participante del canal y especificar la
 labor que cumple:
 – Brokers, agentes, distribuidores, retailers.
 – También podría incluir transporte, empresas de
 bodegaje.
• Construya una figura financiera para sus canales:
 – Márgenes brutos y netos, volumen y SKU ofrecidos,
 costos (o beneficios).
• Revise los factores del medio/entorno que pudieran estar
 afectando sus canales.
 – Por ejemplo, regulaciones, tecnología, competencia.
• Resultado: haga un resumen de las amenazas y
 oportunidades:
 – Evalúe el riesgo (% de su negocio que es vulnerable a
 los problemas que pudieran existir con el canal)
 – Oportunidades de crecimiento, alianzas estratégicas,
 etc.
 Profesor :Francisco Rocca

[pág. 28]
Desagregar el desempeño por canal
 Para realizar el análisis, es necesario que sea en forma detallada y no agregada,
 ya que eso puede ocultar problemas y oportunidades
 Ej.: con una marca de café
 Otros
Margen neto por canal 10% 12% 15% 10%
% del volumen que representa cada canal 30% 20% 40% 10%
% que representa el producto en el volumen de la 10% 8% 20% 5%
categoría en el canal – categoría: café
Crecimiento del volumen de la categoría del producto 5% 6% 10% 3%
vendido a través de cada canal
 Profesor :Francisco Rocca

[pág. 29]
Estrategias promocionales al canal
• La estrategia de push tradicional consiste en orientar
 los esfuerzos de comunicación (promoción) a los
 intermediarios con el objetivo de que el
 intermediario promocione más la marca e incentive a
 los consumidores a comprar un producto el objetivo
 es crear la oferta para el consumidor. Ej. descuentos,
 pago por espacios.
• La estrategia push en marketing digital se basa en
 enviar mensajes y promociones directamente a los
 usuarios sin que ellos los soliciten explícitamente.
 Ej,notificaciones a los usuarios para informarles
 sobre promociones, actualizaciones de productos o
 eventos importantes, mails promocionales, mensajes
 de texto, publicidad en redes sociales, publicidad en
 app móviles.
 Prof: Francisco Rocca

[pág. 30]
Estrategias promocionales al canal
• Esta estrategia concentra los esfuerzos de
 promoción sobre el consumidor final, evitando a
 los intermediarios.
• El objetivo es crear la demanda en el consumidor.
• La estrategia pull en marketing digital se enfoca en
 atraer a los consumidores hacia una marca o
 producto mediante la creación de contenido
 atractivo y relevante.
 • Ej.: En canales tradicionales, publicidad en
 medios como TV , Diarios, Radio.
 • Ej.: En canales digitales, SEO, SEM, marketing
 de contenidos
 Prof: Francisco Rocca

[pág. 31]
OMNICANALIDAD
 Profesor :Francisco Rocca

[pág. 32]
“A medida que las empresas se enfocan en
satisfacer las necesidades personalizadas de
cada cliente, tiende a desaparecer el límite entre
el comercial online y offline, y nace la
omnicanalidad que es el “new retail”
 Jack Ma, fundador,
 ex CEO de Alibaba
 Profesor :Francisco Rocca

[pág. 33]
Diferencias entre canales
 MONOCANALIDAD MULTICANALIDAD OMNICANALIDAD
Un solo canal Múltiples canales trabajan de forma
 independiente. Totalmente inmersivo donde todos los
 canales trabajan juntos.
 Es clave la habilitación de la tecnología.
 Profesor :Francisco Rocca

[pág. 34]
Profesor :Francisco Rocca

[pág. 35]
Omnicanalidad
Multicanalidad versus omnicanalidad
A diferencia de la estrategia multicanal, donde lo
que importa son los diferentes medios para
contactarse con el cliente, en la experiencia
omnicanal el consumidor es el centro de la
estrategia.
 Diferencias Claves
 Profesor :Francisco Rocca

[pág. 36]
Omnicanalidad Estrategia Omnicanal
Habilidad para ofrecer la posibilidad a los clientes
de comprar e interactuar con la marca cómo, Comprende al conjunto de herramientas que usa
cuándo y dónde ellos quieran una compañía para llegar a sus clientes y cómo las
 aprovecha para hacer más dinámica la
 comunicación y la interacción.
 Su objetivo final es construir una mejor experiencia
 del cliente, y de esta forma, generar mayor fidelidad
 hacia la marca y aumentar las posibilidades de
 compra.
 Profesor :Francisco Rocca

[pág. 37]
El Comprador Omnicanal
 Compra
 ON- LINE OFF-LINE
 Investiga, Compra , Explora
 ON- LINE
 ROBOF
 ROBO BOPIS Webrooming
 OFF- LINE
 COMPRADOR
 Showrooming
 TRADICIONAL
 Profesor :Francisco Rocca

[pág. 38]
Cómo lograr una estrategia omnicanal
TRABAJAR EN CONJUNTO CON LAS CONOCE BIEN TU PÚBLICO ELIGE LOS CANALES DONDE TUS ADOPTA UN SISTEMA QUE TE
 ÁREAS QUE ESTÁN (SEGMENTO OBJETIVO). CLIENTES PODRÁN INTERACTUAR PERMITA DARLE SEGUIMIENTO A
 INVOLUCRADAS. CON TU EMPRESA. LA OMNICANALIDAD.
 Profesor :Francisco Rocca

[pág. 39]
La ruta de compra y la omnicanalidad
• Todos los esfuerzos de marketing, en el
 espacio digital y tradicional, deben tener una
 estrategia enfocada en la centralidad del
 cliente (distintos segmentos) y orientada a
 fortalecer la ruta de compra en los locales,
 móvil y web; fortaleciendo la consistencia de
 la experiencia y con ello, la lealtad de los
 clientes.
• Las marcas deben lograr la integración entre
 canales on-line y off -line, de manera que el
 shopper siempre tenga opción de resolver sus
 inquietudes y construir vinculación con las
 marcas, en cualquier momento del proceso
 de compra y en el medio de compra que más
 le acomode.
 Profesor :Francisco Rocca

[pág. 40]
A lo largo de la ruta del cliente, tenemos distintos “puntos de contacto” con el
cliente, con un mix de canales offline y online.
 Profesor :Francisco Rocca

[pág. 41]
¿Cómo es una experiencia omnicanal?
• El cliente decide en qué canal interactuar y recibe la
 misma experiencia en cada uno de ellos
• Las plataformas tienen la misma optimización y
 rendimiento para facilitar y mejorar la experiencia
 de compra
• La información en cada canal es la misma. Por
 ejemplo, se anuncian las mismas promociones
 online y offline para el cliente. Si hay un descuento
 determinado para el cliente, este es anunciado en
 sucursales, banners en redes sociales, campañas de
 mailing, etc.
• Los clientes pueden ver los productos en forma
 online y probarlos en forma física, contactar para
 buscar más información.
• Con omnicanalidad es posible realizar compras
 online y luego devolver en la tienda física
 Profesor :Francisco Rocca

[pág. 42]
Ejemplo:
 • Las compras se pueden seguir
 desde cualquier dispositivo
 • Es posible devolver los
 productos frente a problemas y
 el dinero regresa a la misma
 cuenta donde fue pagado
 fácilmente
 • Atención al cliente frente a
 cualquier inconveniente
 Profesor :Francisco Rocca

[pág. 43]
Ejemplo:
 • Sitio web ofrece localización
 de las tiendas físicas, tienda
 en línea, aplicación para
 Android y iOs
 • Opción de entrega de
 productos a domicilio y peak
 up en tiendas
 • Servicio de atención via chat
 online
 • Múltiples opciones de pago
 Profesor :Francisco Rocca

[pág. 44]
Ejemplo
 • El gigante de belleza Sephora crea
 una experiencia omnicanal que
 conecta las compras en línea de sus
 consumidores con sus visitas a
 tiendas físicas.
 – Talleres de belleza y transformaciones
 de regalo.
 – Tablets en tienda para acceder a la
 Beaty Bag de su cuenta mientras
 compran.
 – Impulsa a su clientela a realizar
 compras al ayudarle a ajustar sus
 opciones de entre la amplia variedad
 de productos.
 Profesor :Francisco Rocca

[pág. 45]
Transformaciones necesarias en omnicanalidad
• Rediseño de la cadena de suministro para responder a
 exigencias de canales on-line y off-line, con el objeto de dar
 flexibilidad al consumidor, con tiempos cortos de respuesta,
 entregas completas, además de manejo certero de
 devoluciones.
 Curbside - Drive Thru Robots entregan productos
 Servicio Click & Collect Cliente compra online y
 Cliente compra online y puede Implementación de nuevas
 puede retirar sin tener que formas de retiro automáticas sin
 retirar en locales en un cierto
 estacionarse o ingresar a la interacción humana
 número de días.
 estacionamientos
 Profesor :Francisco Rocca

[pág. 46]
Transformaciones necesarias en omnicanalidad
Otras soluciones que están creciendo con fuerza buscando
mejorar la experiencia omnicanal, de cara a la operación interna
de la compañía, son:
 Mini bodegas Dark store Tecnología y transformación
 Para almacenar stock del Centro integral de cultural
 ecommerce de última milla, servicios logísticos donde Sistemas de Información de
 con precios más altos y una se visualizan nuevas Inventarios
 estrategia de crecimiento startups e inversiones de CRM
 enfocada en zonas urbanas de los retailers, Tecnología de integración de
 alta demanda. supermercados y apps
 Profesor :Francisco Rocca de experiencia online con in-store
 delivery

[pág. 47]
Competencias necesarias para la omnicanalidad
 App Integrada
Comunicaciones Entregar al cliente experiencias consistentes
personalizadas con la marca y sin barreras entre canales
 Programa Lealtad
 Unificado x canales
 Métodos de Pago
Base Datos Unificada de transversales
Conducta a través de
canales
 Click & Collect
 Hacer visibles los inventarios Campañas de conversión
 en Tiendas y Online a cualquier canal-sin
 sesgos ni asimetrías de
 Devoluciones/cambios incentivos
 a través de los canales
 Opciones de Wi-Fi en Tienda
Servicios a Clientes Precios Entrega
 Integrados Consistentes
 Profesor :Francisco Rocca

[pág. 48]
Lo que vimos hoy
• Los canales de distribución permiten que un producto y / o servicio lleguen a los consumidores. Existen
 porque no siempre es eficiente y eficaz que un productor llegue directamente a los clientes
• Hay empresas que usan varios niveles (canales) antes de llegar al canal de distribución. Algunos de los
 actores involucrados son los mayoristas, intermediarios y retailers.
• Los canales cumplen distintos roles, tales como el transporte, almacenaje y la información a los clientes y
 también la retroalimentación a los productores sobre el mercado.
• En el diseño de la estrategia de distribución se debe considerar el posicionamiento de la marca
• Es importante realizar una evaluación del mix de canales para buscar oportunidades de mejora y posibles
 riesgos
• La omnicanalidad es la habilidad para ofrecer la posibilidad a los clientes de comprar e interactuar con la
 marca cómo, cuándo y dónde ellos quieran; hoy es algo exigido por los clientes en la búsqueda de
 experiencias simples, rápidas y amigables.
• El fuerte aumento del e-commerce y la inmediatez de entrega a los clientes ha hecho que las empresas
 busquen soluciones para reducir el tiempo y esfuerzo en la entrega de los productos comprados a los
 clientes.
• Otra forma de canal de distribución son los sistemas de franquicias
 Profesor :Francisco Rocca

# Teoría Financiera · L6 APT

Fuente: clase de Teoría Financiera

[pág. 1]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
 Teorı́a Financiera
 Arbitrage Pricing Theory
 Consuelo Silva
 Escuela de Administración PUC
 4 de mayo de 2023
 1 / 32

[pág. 2]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
Temas
 1 APT
 2 APT - Multi-F
 3 Modelo de Fama-French (1992)
 4 Momentum
 5 Conclusiones
 2 / 32

[pág. 3]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
Introducción
 • Al estudiar el CAPM encontramos que tiene ciertas limitaciones empı́ricas.
 • Una posible reacción es pensar que el CAPM no captura todos los riesgos
 que preocupan a un inversionista.
 • ¿ Qué pasarı́a si los inversionistas se precuparan por otros riesgos además
 del riesgo de mercado?
 3 / 32

[pág. 4]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT
 • APT = Arbitrage Pricing Theory. (Ross 1976)
 • Es una teorı́a sobre retornos esperados alternativa al CAPM .
 • El APT no se basa en el análisis media-varianza como el CAPM, sino que
 en propiedades estadı́sticas de los retornos de activos.
 • Las grandes fuerzas que determinan los precios en el APT son la
 diversificación y el arbitraje.
 • Las conclusiones a las que llega el APT pueden ser similares a las del
 CAPM, pero partiendo de supuestos muy distintos.
 • Al contrario del CAPM, el APT puede fácilmente generalizarse para
 acomodar diferentes anomalı́as.
 4 / 32

[pág. 5]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT
 • Supongamos que corremos la regresión:
 Rit − RF = αi + β i (Rct − RF ) + ϵit (1)
 • A veces es llamada “market model” o “single index model”.
 • Se parece al CAPM a primera vista, pero no lo es:
 • No hemos dicho que Rc sea el retorno de mercado, β i es sólo el coeficiente
 de una regresión lineal, no el beta del CAPM.
 • Rct es el retorno de un activo o portafolio que captura lo movimientos
 comunes entre activos (factor).
 • ϵit es el retorno residual después de “limpiar” las fuentes de
 co-movimiento entre activos. En promedio este residuo es cero: E(ϵi ) = 0.
 5 / 32

[pág. 6]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT - Supuesto Clave
 • Consideremos que existen N activos:
 R1t − RF = α1 + β 1 (Rct − RF ) + ϵ1t
 ..
 .
 RNt − RF = αN + β N (Rct − RF ) + ϵNt
 • El gran supuesto del APT es que esos residuos no están
 correlacionados a través de activos, es decir,
 E(ϵi ϵj ) = 0 para todo activo i ̸= j (2)
 • Entonces el riesgo residual, ϵit , de cada acción es idiosincrático, es decir,
 no está relacionado al riesgo residual de cualquier otra acción.
 6 / 32

[pág. 7]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT
 • En otras palabras, la gran caracterı́stica de Rc es que es capaz de capturar
 los movimientos comunes de un grupo grande de activos y dejar residuos
 que son independientes o idiosincráticos.
 • El retorno de un activo puede desviarse de αi + β i (Rct − RF ), pero esa
 desviación no ocurrirá simultáneamente para todo un grupo de activos (o
 si no deberı́a estar capturada por Rc ).
 7 / 32

[pág. 8]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT - Principal implicancia
 • La principal implicancia del APT es que los αi de activos individuales
 deben ser aproximadamente cero, es decir en general serán muy pequeños
 en valor absoluto.
 • ¿Por qué?
 8 / 32

[pág. 9]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT - Intuición
 Consideremos que existen N activos. Si formamos un portafolio equal-weighted
 con estos activos su retorno es:
 Rpt − RF = αp + β p (Rct − RF ) + ϵpt (3)
 donde
 α1 α
 αp = + ... + N
 N N
 β1 βN
 βp = + ... +
 N N
 ϵ1 ϵN
 ϵp = + ... +
 N N
 9 / 32

[pág. 10]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT - Intuición
 Si αp > 0 podrı́amos aprovechar una oportunidad de arbitraje para obtenerlo:
 • Formamos un portafolio Q cuyo retorno está dado por (de (3)),
 RQt = (Rpt − RF ) − β p (Rct − RF ) = αp + ϵpt (4)
 • Lo que hicimos fue tomar el coeficiente del factor (beta) como pesos en un
 portafolio.
 • Los factores son portafolios y se pueden transar, por lo que en la ecuación
 (3) el beta es el coeficiente de la regresión, pero en la ecuación (4)
 representa pesos de un portafolio.
 • Nuestro portafolio Q corresponde a tomar posición larga en el portafolio p y
 tomar posición corta en el factor y en el activo libre de riesgo usando los
 betas como ponderadores.
 10 / 32

[pág. 11]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT - Intuición
 • Retorno esperado del portafolio Q:
 E[RQt ] = E[αp + ϵpt ] = αp
 • Varianza del portafolio Q:
 Var(RQt ) = Var(αp + ϵpt ) = Var(ϵpt )
 ϵ ϵ 
 = Var 1 + ... + N
 N N
 " #
 σϵ21 σϵ2N 1 σϵ2i σ¯ϵ 2
 =
 N 2
 + ... +
 N 2
 =
 N ∑ N
 =
 N
 • Las covarianzas no aparecen en esta fórmula porque hemos asumido que los
 residuos ϵi no están correlacionados a través de activos.
 • Pero σ¯ϵ 2 → 0 cuando N → ∞. Entonces, la varianza idiosincrática de este
 N
 portafolio también tiende a cero. Si el portafolio contiene suficientes activos
 para ser un portafolio diversificado, la varianza del residuo del portafolio es
 mı́nima.
 La oportunidad de arbitraje tenderá a desaparecer =⇒ en equilibrio αp = 0
 11 / 32

[pág. 12]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT - Intuición
 • Veamos por qué αp = 0 usando el retorno esperado por unidad de riesgo:
 E[RQt ] E [ α p + ϵp ] αp
 SR = = q =
 σQ Var(α + ϵ ) σϵp
 p p
 • Supuesto: |SR| < A. Hay una cota superior para el Sharpe Ratio, ya que
 un SR muy alto no dura mucho, no sobreviven.
 • Por lo tanto σϵ2p pequeño implica alfas pequeño.
 • La implicancia es que αp es pequeño si σϵ2p es pequeño, y deberı́a ser cero
 si σϵ2p −→ 0.
 12 / 32

[pág. 13]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT - Intuición
 • Lo anterior implica que los activos individuales pueden tener alfas distintos
 de cero, pero no por mucho. Deben ser aproximadamente cero. De lo
 contrario se puede convertir en una oportunidad de arbitraje.
 • Si muchos activos tienen alfas distintos de cero, se pueden agrupar en un
 portafolio bien diversificado y crear una oportunidad de arbitraje
 13 / 32

[pág. 14]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT y Retornos Esperados
 • Entonces, para la mayorı́a de activos:
 Rit − RF ≈ β i (Rct − RF ) + ϵit (5)
 • En promedio:
 E[Rit − RF ] ≈ β i E[Rct − RF ] (6)
 • Si Rc = Rm , es decir, si el portafolio c corresponde al mercado, llegamos a
 la misma ecuación del CAPM, pero desde supuestos distintos.
 14 / 32

[pág. 15]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT
Ejemplo (BKM)
 Pregunta Considere un modelo donde los retornos de los activos siguen el
 modelo de APT de un factor. Suponga que la tasa libre de riesgo es de 4 % y
 que el portafolio A, el factor relevante en este modelo, tiene un retorno
 esperado de 10 %. Considere que existe además un portafolio bien diversificado
 C, con un beta de 0.5, y un retorno esperado de 6 %. Existe alguna
 oportunidad de arbitraje? Es el alpha de C distinto de cero?
 a. No hay oportunidad de arbitraje, el alpha es igual a cero.
 b. Si hay oportunidad de arbitraje, el alpha es igual a cero.
 c. Si hay oportunidad de arbitraje, el alpha es de 1 %.
 d. Si hay oportunidad de arbitraje, el alpha es de -1 %.
 e. Si hay oportunidad de arbitraje, el alpha es de 6 %.
 15 / 32

[pág. 16]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT
Ejemplo (BKM)
 • El retorno esperado del portafolio C si se cumple APT debe ser,
 E(RC ) =Rf + β C (E(RAt ) − Rf )
 E(RC ) = β C E(RAt ) + (1 − β C )Rf
 E(RC ) =0,5 ∗ 0,1 + 0,5 ∗ 0,04
 E(RC ) =0,07
 • El retorno esperado según APT es de 7 %, pero el retorno esperado actual
 es de 6 % =⇒ existe una oportunidad de arbitraje:
 αC =E(RC ) − β C E(RAt ) − (1 − β C )Rf
 αC =0,06 − 0,07
 αC = − 0,01
 • αC < 0 el activo está sobrevalorado! Para aprovechar la oportunidad de
 arbitraje compramos el portafolio replicador: 50 % A y 50 % F, y vendemos
 (corto) el portafolio C. 16 / 32

[pág. 17]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT
Ejemplo (BKM)
 El αp de cualquier portafolio diversificado debe ser cero. Por lo tanto, para
 cualquier portafolio p.
 E(Rpt ) =Rf + β p (E(Rct ) − Rf )
 17 / 32

[pág. 18]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT vs. CAPM
 • Hemos derivado la misma relación entre retornos esperados y betas sin
 basarnos en el análisis media varianza.
 • Tampoco requerimos optimizar, sólo asumimos la ausencia de arbitraje.
 • La suposición clave fue que el riesgo residual del modelo (los ϵi ) no están
 correlacionados entre diferentes acciones.
 • Como este riesgo residual es completamente diversificable, no recibe un
 premio en términos de exceso de retorno y sólo la covarianza con el factor
 (mercado) es premiada.
 • Bajo este nuevo enfoque, el “factor”puede ser cualquier portafolio bien
 diversificado que satisfaga esta suposición.
 • No necesita ser el portafolio de toda la riqueza, por lo tanto no nos importa
 la crı́tica de Roll.
 18 / 32

[pág. 19]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
Diferencias entre APT y CAPM
 • CAPM
 • Requiere optimización media varianza y usa argumento de equilibrio.
 • Proporciona una expresión para el retorno esperado de todos los activos de
 la economı́a
 • APT
 • No requiere el supuesto que los inversionistas sean optimizadores
 media-varianza.
 • Requiere la ausencia de arbitraje, lo que es una suposición mucho más débil.
 • Pero APT también requiere una cierta estructura sobre los retornos, esta
 suposición es más fuerte.
 • En este caso lo importante no serı́a que el mercado fuera un portafolio eficiente,
 si no que fuera capaz de agotar las fuentes de movimiento común entre activos.
 19 / 32

[pág. 20]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT Multi-factorial
 • En general podemos pensar que es necesario incluir K portafolios o factores
 para poder capturar todas las fuentes de movimiento común entre activos.
 • Los factores no son necesariamente retornos de portafolios, si no que
 pueden ser variables macro como la inflación, el crecimiento del PGB, el
 crecimiento de una cierta industria (ej: el cobre para Chile), etc.
 20 / 32

[pág. 21]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
APT Multi-factorial
 • La versión multi-factorial del APT es:
 K
 Rit − RF = αi + ∑ β ik (Rkt − RF ) + ϵit
 k =1
 • La implicancia clave del APT es que los alfas son aproximadamente cero
 para todo activo, y por lo tanto:
 K
 E[Rit − RF ] ≈ ∑ β ik E[Rkt − RF ] (7)
 k =1
 21 / 32

[pág. 22]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
¿Cómo elegir los factores?
 • En general el primer factor es el retorno de un portafolio de “mercado”.
 • Podemos usar nuestra intuición para identificar factores que es “probable”
 o que “pareciera” que los inversionistas consideran importantes.
 • Factores que es probable que los inversionistas consideran:
 • Factores macroeconómicos (tasas de interés, inflación, producción
 industrial)
 • Factores que pareciera que los inversionistas consideran:
 • Fama y French popularizaron el enfoque de usar portafolios de acciones
 formados en base a caracterı́sticas comunes que la evidencia empı́rica ha
 demostrado afectan los retornos (tamańo, book to market, etc)
 22 / 32

[pág. 23]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
Modelo de Factores de Fama-French (1992)
 • Modelo con 3 factores
 • Mercado: retorno de ı́ndice de mercado (tipo CAPM)
 • Tamaño: diferencia entre retorno de acciones de firmas pequeñas y grandes
 (SMB)
 • Book-to-market: diferencia entre retornos de acciones con alta y baja razón
 book-to-market (HML)
 • Estos 3 factores capturan más del 90 % de la variación de retornos en
 portafolios USA. No hay mucha variación que quede por explicar.
 23 / 32

[pág. 24]
APT
 100
 1000
 10000
 100000
 0.1
 1
 10
 192607
 192812
 193105
 193310
 193603
 193808
 194101
 194306
 194511
 194804
 APT - Multi-F
 195009
 195302
 195507
 value
 growth
 195712
 196005
 196210
 196503
 196708
 197001
 197206
 (log scale)
 197411
 197704
 Modelo de Fama-French (1992)
 197909
 198202
 198407
 198612
 198905
 Cumulative return by BE/ME 1926-2005
 199110
 199403
 Momentum
 199608
 199901
 200106
 200311
 Conclusiones
24 / 32

[pág. 25]
APT
 1
 0.1
 10
 100
 1000
 10000
 192607 100000
 192812
 193105
 193310
 193603
 193808
 194101
 194306 big
 194511
 small
 194804
 APT - Multi-F
 195009
 195302
 195507
 195712
 196005
 196210
 196503
 196708
 197001
 197206
 (log scale)
 197411
 197704
 Modelo de Fama-French (1992)
 197909
 198202
 198407
 198612
 Cumulative return by size 1926-2005
 198905
 199110
 199403
 Momentum
 199608
 199901
 200106
 200311
 Conclusiones
25 / 32

[pág. 26]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
Modelo FF
 • Para cada activo:
 Rit − RF = αi + β im (Rmt − RF ) +
 + β iHML HMLt + β iSMB SMBt + ϵit
 donde
 HMLt = Rhigh,t − Rlow,t
 SMBt = Rsmall,t − Rbig,t
 • Como todo modelo APT, deberı́a cumplirse que αi = 0.
 26 / 32

[pág. 27]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
Modelo de Carhart
 • Para cada activo:
 Rit − RF = αi + β im (Rmt − RF ) +
 + β iHML HMLt + β iSMB SMBt + β iUMD UMDt + ϵit
 donde
 HMLt = Rhigh,t − Rlow,t
 SMBt = Rsmall,t − Rbig,t
 UMDt = Rwinners,t − Rlosers,t
 • Donde Rwinners,t y Rlosers,t son los retornos de portafolios de acciones que
 subieron los últimos x meses (o dı́as o semanas) y las que bajaron
 27 / 32

[pág. 28]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
Construcción factores
Ejemplo: Momentum
 28 / 32

[pág. 29]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
Evaluación de Desempeño
 • αi en el modelo de Fama French Carhart puede ser considerada como una
 medida de la habilidad “extra” del portfolio manager
 • ¿Son capaces los fondos mutuos de generar un retorno en exceso de los
 factores de riesgo?
 • FF encuentran que el αi (neto de comisiones) es negativo para una gran
 mayorı́a de los fondos actively- managed en USA. (Luck versus Skill in the
 Cross Section of Mutual Fund Returns, Fama and French, 2010).
 29 / 32

[pág. 30]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
Fama and French (2010)
 30 / 32

[pág. 31]
APT APT - Multi-F Modelo de Fama-French (1992) Momentum Conclusiones
Ventajas y desventajas de APT
 • Ventajas
 • Nos da una descripción adecuada de riesgo y retorno
 • Factores son razonables, justificables
 • No necesita atarse a portafolios especı́ficos
 • Desventajas
 • No hay una guı́a respecto de qué variables son factores
 • ¿Qué patrones mirar?
 • Tentación de salir de pesca
 • Factores pueden cambiar
 • Requerimientos de datos crecen al aumentar número de factores
 • No es fácil encontrar factores capaces de capturar comovimientos y dar
 residuos idiosincráticos
 31 / 32

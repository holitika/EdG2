# Teoría Financiera · L7HME y BF SV

Fuente: clase de Teoría Financiera

[pág. 1]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
 Teorı́a Financiera
 Hipótesis Mercados Eficientes y Behavioral Finance
 Consuelo Silva
 Escuela de Administración PUC
 15 de mayo de 2023
 1 / 35

[pág. 2]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Temas
 1 Hipótesis de Mercados Eficientes
 2 Qué mueve los precios
 3 Behavioral Finance
 4 Lı́mites al Arbitraje
 5 Conclusiones
 2 / 35

[pág. 3]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Preguntas claves clase de hoy
 1 ¿Qué significa que los mercados sean “eficientes” y cuáles son las
 implicancias?
 2 ¿Son eficientes los mercados financieros en la práctica?
 3 ¿Qué tipo de noticias son las que mueven los precios?
 3 / 35

[pág. 4]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Repaso - CAPM y APT
 CAPM:
 E(Ri ) = α + RF + β i (E(RM ) − RF )
 APT:
 E(RP ) = α + RF + β 1P F + ... + β nP Fn
 Caso particular APT, si F = E(RM ) − RF :
 E(RP ) = α + RF + β p (E(RM ) − RF )
 Para que no hayan posibilidades de arbitraje α debe ser igual a cero en ambos
 modelos.
 4 / 35

[pág. 5]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
The Challenger crash
 Enero 28, 1986, 11:39am:
 • 11:47am: confirma cohete explotó
 • Fabricantes señalan que no tienen comentarios (Lockheed, Martin
 Marietta, Rockwell, Morton-Thiokol).
 Figura: the Challenger Disaster
 ... 7 meses después, investigación culpa a Morton-Thiokol.
 5 / 35

[pág. 6]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
The Challenger crash
 458 M.T. Maloney, J.H. Mulherin / Journal of Corporate Finance 9 (2003) 453–479
 Figura: Fig. 1. Intraday
 Intraday Stockstock priceMovements
 Price movements following
 Followingthe the
 challenger disaster.Disaster
 Challenger
 6 / 35

[pág. 7]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Introducción
 • Un mercado eficiente es aquel donde toda la información relevante está
 incorporada en los precios de los activos financieros (Kendall, 1953).
 • Hay varios tipos de información:
 • Histórica: precios y retornos pasados, volumen de transacciones, etc.
 • Pública: información histórica y futura sobre las compañı́as, balances y
 EERR, sus proyectos, etc. que haya sido divulgada al mercado.
 • Privada: información sólo disponible a algunos inversionistas.
 • Mientras más información incorporen los precios diremos que el mercado
 es más eficiente.
 7 / 35

[pág. 8]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Eficiencia de Mercado
Formas
 • Las definiciones de formas de eficiencia responden una pregunta esencial
 • ¿Qué información está disponible?
 • Forma débil: precios incorporan toda la información histórica
 • Forma semi-fuerte: precios incorporan toda la información pública
 • Forma fuerte: precios incorporan toda la información existente incluyendo
 la información privada
 8 / 35

[pág. 9]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Implicancias
Comentarios
 • En un mercado eficiente no podemos generar inversiones que entreguen
 retornos sobrenormales en promedio usando únicamente información
 ampliamente disponible por el mercado
 • Sobrenormal: promedio superior a lo que corresponde a compensación por
 riesgo (ajustado por β o por factores de riesgo (en APT))
 • Promedio: que ocurra de manera consistente, porque alguien por pura
 suerte puede ganarle al mercado. . .
 • La pregunta es si puede repetirlo o no
 9 / 35

[pág. 10]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Implicancia 1
 • Los precios cambian sólo al revelarse información nueva al mercado. Por el
 contrario, si la información ya era conocida o no es relevante los precios no
 deberı́an cambiar.
 • Ejemplo: retorno ante anuncios de takeovers.
 • Los retornos de empresas “target” al anunciarse un takeover reflejan el
 premio del eventual takeover. Al minuto de efectuarse el takeover el precio
 no cambia; la información ya estaba incorporada.
 • Contra-ejemplos:
 • Retornos “punto com”.
 10 / 35

[pág. 11]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Efectos de anuncios de takeover
 11 / 35

[pág. 12]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
 Fuente: Cooper et al (2001)
 12 / 35

[pág. 13]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Implicancia 2
 • Toda nueva información o noticia es incorporada inmediatamente a los
 precios
 • Es decir, no podemos “ganarle al mercado” consistentemente
 • Qué pasarı́a si sabemos que los precios aumentarán en una semana?
 • Visto de otra manera: oportunidades de ganarle al mercado con información
 pública son aleatorias y de muy corta duración =⇒ precios siguen un
 random walk
 • Ejemplo:
 • Fondos mutuos activos pierden respecto de fondos mutuos pasivos (que
 repliquen ı́ndices de mercado)
 • Contra ejemplo:
 • Warren Buffett: Berkshire Hathaway tuvo un retorno anualizado de aprox.
 20 % entre 1964 y 2015 versus un retorno de aprox. 10 % del S&P500.
 13 / 35

[pág. 14]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Nueva Información y Precios
 Fuente: http://www.bloomberg.com/
 14 / 35

[pág. 15]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Nueva Información y Precios
 Fuente: http://www.bloomberg.com/
 15 / 35

[pág. 16]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
 16 / 35

[pág. 17]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Implicancia 3
 • No se puede ganar al mercado usando información disponible para los
 demás inversionistas
 • Ejemplos
 • El análisis técnico, es decir, estrategias de inversión basadas en información
 histórica de precios y retornos, no deberı́a dar ganancias de manera
 consistente.
 • Contra ejemplo
 • Estrategias momentum
 https:
 //www.ft.com/video/2452d265-ef0e-4f7f-b0b2-ca1dc076ff33
 17 / 35

[pág. 18]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
High Frequency Trading
 • Aprox. 50 % de todo el volumen transado en EEUU no es por personas
 sino que por computadores.
 • Computadores en vez de personas tomas decisiones de inversión en
 milisegundos
 • El largo de los cables importa
 • Spread Networks en 2010 invirtió 300 millones de dólares para tener un
 cable más corto entre NY y Chicago que redujo el tiempo de 16 a 13
 milisegundos.
 http:
 //www.radiolab.org/story/267195-million-dollar-microsecond/
 18 / 35

[pág. 19]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Movimientos en Precios de Activos
Noticias
 • Si mercados son eficientes =⇒ sólo noticias deberı́an mover los precios
 • ¿Qué es noticias? ¿Cuáles noticias deberı́an generar efectos en precios?
 19 / 35

[pág. 20]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Movimientos en Precios de Activos
Noticias
 • Para entender las fuentes de variación en precios es útil recordar la fórmula
 de valor presente:
 flujos esperados
 precio =
 tasa de decuento
 • Las noticias pueden ser de dos tipos:
 • Sobre flujos (cambios en valores esperados)
 • Sobre tasas de descuento
 • Precio del riesgo en el mercado (por ej., E(Rm ) − RF en el CAPM)
 • Cantidad de riesgo de la empresa (por ej., β i en el CAPM).
 20 / 35

[pág. 21]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Cambios en retornos - tasa de descuento
 • El retorno lo podemos descomponer en dos partes
 Rt+1 =Et (Rt+1 ) + ϵt+1 (1)
 • ¿Qué restricción impone la HME sobre ϵ?
 • La HME nos dice que Et (ϵt+1 ) = 0, es decir, las noticias son verdaderamente
 impredecibles. Si fueran predecibles ya estarı́an incorporadas en los precios.
 • Pero ϵ no necesita ser 0 siempre
 • Cuando hay noticias tenemos ϵ ̸= 0
 21 / 35

[pág. 22]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Cambios en retornos
 • Alternativamente podemos pensar en
 Rt+1 = retorno “normal” + retorno “anormal”
 • El retorno “normal” es el retorno apropiado dado el perfil de riesgo del
 activo.
 • La HME dice que el retorno “anormal” debe ser cero en promedio. Un
 retorno anormal que es positivo en promedio es una violación de la HME
 22 / 35

[pág. 23]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Son entonces eficientes los mercados?
 • Existen suficientes anomalı́as en la evidencia empı́rica para justificar la
 búsqueda de oportunidades.
 • Sin embargo, el mercado es suficientemente competitivo para que las
 oportunidades más “fáciles”sean explotadas rápidamente
 • En general, los mercados son eficientes, pero existen oportunidades!
 23 / 35

[pág. 24]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Behavioral Finance
 Algunos patrones que observamos en los mercados parecen ser incompatibles
 con los agentes que hemos estudiado hasta ahora...
 24 / 35

[pág. 25]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
 Fuente: Cooper et al (2001)
 25 / 35

[pág. 26]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Behavioral Finance
 • Es de alguna manera una hipótesis alternativa a eficiencia de mercado.
 • Para que existan oportunidades de arbitraje necesitamos precios que no
 son los correctos.
 • Behavioral finance plantea la existencia de “errores” en los precios
 basándose en dos condiciones que deben cumplirse simultáneamente:
 • La gente se equivoca o es incapaz de procesar toda la información relevante.
 • Existen lı́mites al arbitraje que impide que los inversionistas que son capaces
 de identificar esos errores (los “arbitradores”) puedan hacer una ganancia
 explotando las equivocaciones de los inversionistas “ingenuos”.
 26 / 35

[pág. 27]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Sesgos
 Considere 2 loterı́as:
 • Loterı́a A: $240.000
 • Loterı́a B: $1.000.000 con 25 %, $0 con 75 %.
 Cuál prefiere?
 27 / 35

[pág. 28]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Sesgos
 Considere 2 loterı́as:
 • Loterı́a C: -$750.000
 • Loterı́a D: -$1.000.000 con 75 %, $0 con 25 %.
 Cuál prefiere?
 28 / 35

[pág. 29]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Sesgos
 • Prospect theory (Kahneman y Tversky, 1979)
 • Loss aversion: la utilidad no depende del nivel de riqueza, si no en los
 cambios de riqueza a partir de los niveles iniciales
 • Traders toman mucho más riesgo en las sesiones de la tarde en las que han
 sufrido pérdidas durante la mañana (Coval & Shummway, JF 2005)
 • Exceso de confianza
 • Hombres transan 45 % más que las mujeres y esto reduce su retorno en 1 %
 anual aproximadamente respecto a las mujeres (“Boys will be boys” Barber
 y Odean, 2001)
 • Disposition effect
 • Tendencia de los inversionistas de vender acciones que han aumentado de
 precio y de no vender acciones que han caı́do de precio.
 29 / 35

[pág. 30]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Sesgos
 • Anchoring
 • Tomar decisiones en base a un hecho/dato irrelevante para la decisión,
 ignorando otra información importante.
 • Analistas pueden estar anclados a sus pronósticos de ganancias de las
 empresas, descartando nueva información que contradiga la anterior.
 • Los analistas entonces no reaccionan tanto como deberı́an a nuevas noticias
 que vayan en contra de sus pronósticos. Esto genera que sus estimaciones
 sean un rezago de la información, en vez de un pronóstico.
 • Respresentatividad
 • Inferir patrones basados en una muestra pequeña y extrapolar tendencias.
 • Consistente con sobrerreacción y corrección en los mercados.
 Y muchos más...
 30 / 35

[pág. 31]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
¿Qué limita a los arbitradores?
 • Para que persistan los “errores” en los precios, los arbitradores deben estar
 de manos atadas, de lo contrario el precio se corregirı́a rápidamente.
 • ¿Qué lı́mites existen a los arbitradores?
 • Horizontes largos (fundamental risk): la corrección del error puede tomar
 tiempo. Comprometer fondos por tanto tiempo puede ser imposible.
 Keynes:”The market can stay irrational longer than you can stay solvent.”
 • Costos de implementación: dificultad al explotar la oportunidad. Vender
 corto tiene algunos costos (e.g. devolver el activo rápidamente -horizonte de
 inversión- , lı́mites).
 • Riesgo de modelo: Riesgo de que el modelo usado no sea el correcto, la
 oportunidad es aún riesgosa.
 31 / 35

[pág. 32]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Ejemplo 1: Royal Dutch Petroleum y Shell transport
 • Se unieron en 1907 y acordaron repartir sus utilidades en 60 % para Royal
 Dutch y 40 % para Shell.
 • Entonces uno esperarı́a que la razón entre el precio de sus acciones fuera
 60/40 = 1,5.
 • Pero la razón entre sus valores se ha distanciado por largos perı́odos de
 tiempo de esta razón de 1.5.
 • Si hubieran intentado arbitrar en febrero de 1993, recién hubieran obtenido
 ganancias en 1999.
 32 / 35

[pág. 33]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Ejemplo 1: Royal Dutch Petroleum y Shell transport
 33 / 35

[pág. 34]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Ejemplo 2: Equity Carve-outs
 • 3Com vende 5 % de su spin-off Palm en 1999.
 • 95 % restante serı́a distribuı́do 6 meses después entre los accionistas de
 3Com (cada uno recibe 1.5 acciones de Palm)
 • Las acciones de 3Com deberı́an ser al menos 1.5 acciones de Palm. Pero
 fué menor.
 • Lı́mites para vender corto Palm. Todas las acciones disponibles de Palm
 habı́an sido vendidas corto.
 • La oportunidad de mantuvo por 2 meses.
 34 / 35

[pág. 35]
Hipótesis de Mercados Eficientes Qué mueve los precios Behavioral Finance Lı́mites al Arbitraje Conclusiones
Conclusiones
 • Muchos errores en los precios son probablemente difı́ciles de “explotar”
 por los arbitradores y por lo tanto persistirán.
 • Muchas aparentes oportunidades de arbitraje no son tales cuando se
 piensa en implementar estas estrategias de inversión en la práctica.
 • Los mercados son bastante eficientes, sobre todo si son lı́quidos. Los
 precios generalmente reflejan la información disponible. Pero, los precios
 también pueden alejarse de los ”fundamentals”. ¿Representan estas
 situaciones verdaderas oportunidades de hacerse millonario? Difı́cil, pero
 puede ser...
 35 / 35

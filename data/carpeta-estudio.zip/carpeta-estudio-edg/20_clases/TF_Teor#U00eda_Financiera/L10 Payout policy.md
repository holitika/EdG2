# Teoría Financiera · L10 Payout policy

Fuente: clase de Teoría Financiera

[pág. 1]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
 Teorı́a Financiera
 Polı́tica de Dividendos
 Consuelo Silva
 Escuela de Administración PUC
 26 de junio de 2023
 1 / 29

[pág. 2]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Temas
 1 Introducción
 2 Funcionamiento
 3 Dividendos y Valor de la Empresa
 4 Fricciones
 2 / 29

[pág. 3]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
 3 / 29

[pág. 4]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Introducción
 • Pregunta clave: ¿Depende el valor de la empresa de cómo se reparten los
 flujos en el tiempo?
 • ¿En un mercado de capitales perfecto?
 • ¿y en la práctica?
 4 / 29

[pág. 5]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Introducción
 • Una empresa tiene varios usos posibles para su flujo de caja libre (free cash
 flow):
 • Puede retener estos fondos para:
 1 Invertir en proyectos nuevos
 2 Aumentar sus reservas
 • Puede pagar a sus accionistas:
 1 Pagando dividendos
 2 Recomprando acciones
 3 Entregando un dividendo en acciones
 5 / 29

[pág. 6]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Evidencia Empı́rica
 • En Chile
 • Por ley las empresas (sociedades anónimas abiertas) deben repartir un
 mı́nimo de 30 % de las utilidades del ejercicio
 • En Estados Unidos
 • Promedio de razón dividendos en efectivo sobre utilidades en 2012 fue
 alrededor de 15 %.
 6 / 29

[pág. 7]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
1.- Dividendos en efectivo
 • Decisión de pago de dividendos por el directorio
 • Fecha de cierre: sólo reciben pagos accionistas en el registro
 • Pero el registro demora un par de dı́as después de haber comprado la
 acción:
 • Fecha “con dividendo” (cum dividend)
 • Fecha “ex dividendo”
 • Pcon = Pex + D
 • En Fecha de pago, empresa otorga un pago igual por cada acción.
 • No todos los dividendos son iguales: extraordinarios por ej.
 7 / 29

[pág. 8]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
2.- Recompra de Acciones
 • Alternativamente para “pagar” a sus accionistas, una empresa puede
 recomprar (parte) de sus acciones:
 • La forma más común (al menos en EEUU), es recomprando directamente
 en el mercado
 • A lo largo de varios dı́as
 • Idea es que cada accionista puede vender un porcentaje de las acciones
 que tenga, para terminar con parte de su riqueza en acciones y parte en
 efectivo que le pagan por las que vendió.
 8 / 29

[pág. 9]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
3.- Dividendo en Acciones
 • Alternativamente para “pagar” a sus accionistas, una empresa puede
 repartir acciones adicionales a sus accionistas:
 • Ejemplo, una empresa declara un dividendo en acciones de 10 %
 • Accionistas recibirá 1 acción adicional por cada 10 que posea
 9 / 29

[pág. 10]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Ejemplo 1
 • El valor de una firma está dado solamente por el valor un proyecto de
 inversión (ya hecho):
 • Flujos de $500 en t=0 y $500 en t=1 sin incertidumbre
 • Financiamiento 100 % acciones
 • Tasa libre de riesgo = 10 %
 • Pregunta Polı́tica 1: ¿Cuál es el valor de la empresa si ésta tiene una
 polı́tica de repartir el 100 % de sus flujos a sus accionistas al momento de
 recibirlos?
 1 $ 1000
 2 $ 954,55
 3 $ 909,09
 4 $ 867,77
 5 No sé
 10 / 29

[pág. 11]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Ejemplo
 • Polı́tica 1: tasa de dividendos 100 %. Cada periodo se entregará un
 dividendo de $500:
 500
 VP = 500 + = 954,55
 1,1
 • Valor de la empresa es 954,55
 11 / 29

[pág. 12]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Ejemplo 1
 • El valor de una firma está dado solamente por el valor un proyecto de
 inversión (ya hecho):
 • Flujos de $500 en t=0 y $500 en t=1 sin incertidumbre
 • Financiamiento 100 % acciones
 • Tasa libre de riesgo = 10 %
 • Pregunta Polı́tica 2: ¿Cuál es el valor de la empresa si ésta decide
 aumentar en $100 el dividendo en t=0, para lo cual emite deuda libre de
 riesgo, que se compromete a pagar en t=1?
 1 $ 1054,55
 2 $ 963,64
 3 $ 954,55
 4 $ 867,77
 5 No sé
 12 / 29

[pág. 13]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Ejemplo 1
 • Polı́tica 2: aumentar dividendo en perı́odo 1
 • Para financiarlo debe levantar nuevos fondos. Pide prestado $100 hoy por lo
 que debee devolver $110 en el siguiente perı́odo.
 • Flujos serán $600 y $390. Por lo que el valor de la firma es,
 390
 600 + =954,55
 1,1
 • Es decir, el valor de la firma no cambia al cambiar la polı́tica de dividendos.
 13 / 29

[pág. 14]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Ejemplo 2: Dividendos vs. Recompra
 • Supongamos una empresa que no tiene deuda, tiene $20M en efectivo, y
 generará flujos de $48M por año a perpetuidad que repartirá el mismo año
 que se generan como dividendo.
 • Suponga que el CCPP de esta empresa es 12 %.
 • El valor de la empresa hoy es entonces:
 $48M
 Valor Empresa = $20M + = $420M
 12 %
 • Suponga que la empresa tiene 10M de acciones.
 • Actualmente la empresa está decidiendo entre repartir los $20M a través
 de un dividendo o a través de una recompra de acciones. Si un inversionista
 posee una acción de esta empresa, ¿qué decisión maximizarı́a su riqueza?
 14 / 29

[pág. 15]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Ejemplo 2: Dividendos vs. Recompra
 Si la empresa paga dividendos:
 • Si la empresa tiene 10M de acciones, el precio hoy por acción es de $42.
 • Si la empresa opta por un dividendo total de $20M, cada inversionista
 recibirá $2 por acción.
 • El valor de la acción pasará de $42 en la fecha “con dividendo” a $40 en
 la fecha “ex dividendo”
 • Por lo tanto la riqueza final de un inversionista que tiene 1 acción será de
 $2 en efectivo más $40 en la acción.
 15 / 29

[pág. 16]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Ejemplo 2: Dividendos vs. Recompra
 Si la empresa recompra acciones:
 • Recomprará $20M/$42 = 0.476M de acciones.
 • Por lo tanto quedarı́an sólo 9.524M de acciones en circulación.
 • Si el inversionista decide vender se quedará con $42 en efectivo, pero ¿cuál
 será su riqueza si decide no vender su acción?
 16 / 29

[pág. 17]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Ejemplo 2: Dividendos vs. Recompra
 • Los flujos futuros no cambian, por lo que cada año habrán $48M a repartir.
 • Pero ahora hay 9.524M de acciones en circulación, por lo tanto el
 dividendo por acción será:
 $48M
 = $5,04
 9,524M
 • Como la acción hoy es el valor presente de todos los dividendos futuros:
 $5,04
 Phoy,recompra = = $42
 12 %
 • Es decir la riqueza final de un inversionista que tiene 1 acción será de $42
 (ya sea en efectivo si decide vender o en acciones si decide no vender)
 17 / 29

[pág. 18]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Modigliani y Miller
 • Modigliani y Miller escribieron otro teorema de irrelevancia similar al de
 estructura de capital:
 En mercados de capitales perfectos, manteniendo intacta la polı́tica de
 inversión, la polı́tica de dividendos de una firma es irrelevante y no afecta
 el precio (inicial) de sus acciones
 • El supuesto clave es el mismo de M&M para estructura de capital: la
 inversión ya está hecha; sólo estudiamos cómo distribuir los flujos en el
 tiempo.
 • La intuición básica es que cualquier “re-empaquetamiento” temporal de
 dividendos (pagar antes o después) no puede producir cambios en el valor
 de la empresa porque serı́a arbitrable.
 18 / 29

[pág. 19]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Dividendos y Fricciones
 • Al igual que con la estructura de capital, la clave para que la polı́tica de
 dividendo afecte el valor de la empresa es que haya fricciones que nos
 “alejen” de mercados de capitales perfectos:
 • Las teorı́as que se pueden desarrollar son análogas al caso de la estructura
 de capital:
 1 Impuestos
 2 Problemas de Agencia
 3 Información Asimétrica
 19 / 29

[pág. 20]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
¿Qué parece importar?
 Fuente: Brav, Graham, Harvey, Michaely, 2005, “Payout Policy in the 21st Century”
 20 / 29

[pág. 21]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Impuestos
 • Accionistas deben pagar impuestos sobre ganancias de capital y sobre
 dividendos.
 • Si estas tasas son distintas, los accionistas no estarán indiferentes respecto
 a la polı́tica de pago de la empresa.
 • Históricamente en EEUU los dividendos han tenido una tasa mayor de
 impuesto
 21 / 29

[pág. 22]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Impuestos
 • Definamos como τd y τg las tasas de impuestos sobre dividendos y
 ganancias de capital respectivamente.
 • Un inversionista que compra una acción justo antes de que pase a ser “ex
 dividendo”:
 • obtendrá una ganancia después de impuestos por el dividendo de
 (1 − τd ) Div
 • sufrirá una pérdida después de impuestos de (1 − τg )(Pcon − Pex )
 • Por lo tanto, para que comprar una acción justo antes de que pase a ser
 “ex dividendo” no represente una oportunidad de arbitraje se debe cumplir
 que:
 (1 − τd ) Div = (1 − τg )(Pcon − Pex )
 22 / 29

[pág. 23]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Impuestos
 • Podemos reescribir (1 − τd ) Div = (1 − τg )(Pcon − Pex ), como:
 1 − τd τd − τg
  
 Pcon − Pex = Div × = Div × 1 − = Div × (1 − τd∗ )
 1 − τg 1 − τg
 • Ası́ definimos la tasa efectiva de impuestos sobre dividendos como:
 τd − τg
 τd∗ =
 1 − τg
 • Notar que pasa si τg = τc
 23 / 29

[pág. 24]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Impuestos
 • Algunos ejemplo con datos de EEUU
 • Inversionista individual largo plazo: τ ∗ = 15 %
 d
 • Inversionista individual 1 año plazo: τ ∗ = 0 %
 d
 • Fondos de Pensiones: τ ∗ = 0 %
 d
 • Empresas: τ ∗ = −38 %
 d
 • “Tax clienteles”: polı́tica de dividendos de empresa podrı́a depender de
 quiénes son dueños de sus acciones:
 24 / 29

[pág. 25]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Problemas de Agencia
 • Al igual que con la estructura de capital, la clave para que la polı́tica de
 dividendo sea relevante es que existan decisiones de inversión que
 dependan de los dividendos pagados.
 • Problemas de agencia: Los dividendos son una manera de no dejar
 fondos dando vuelta en la empresa que pueden ser desperdiciados por la
 administración.
 • Pero por otro lado retener fondos en la empresa sirve para no tener que
 levantar fondos externos si aparecen nuevas oportunidades de inversión.
 25 / 29

[pág. 26]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Información Asimétrica
 • Al igual que con la estructura de capital, la clave para que la polı́tica de
 dividendo sea relevante es que existan decisiones de inversión que
 dependan de los dividendos pagados.
 • Información asimétrica: las empresas ”buenas”sacrifican oportunidades
 de inversión pagando dividendos altos para mostrarle al mercado que son
 buenas. El mecanismo es muy similar al problema de información
 asimétrica en emisiones de acciones.
 26 / 29

[pág. 27]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Suavización de Dividendos (GM)
 • Empresas tienden a suavizar los dividendos (“dividend smoothing”)
 • Creencia de que esto es preferido por inversionistas
 Fuente: Libro Berk DeMarzo
 27 / 29

[pág. 28]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Información Asimétrica
 • Aumentar dividendos es una señal de fortaleza (dividend signaling
 hypotheses)
 • La implicancia empı́rica es que anuncios de dividendos deberı́an ir
 acompañados de subidas en el precio de la acción. La evidencia al respecto
 no es tan clara.
 28 / 29

[pág. 29]
Introducción Alternativas Dividendos y Valor de la Firma Fricciones Conclusiones
Conclusiones
 • Empresas tienen varias opciones para distribuir recursos a los accionistas
 • En mercados de capitales perfectos, M&M establece que estas polı́tica de
 pagos no afectan el valor de la empresa
 • Por ejemplo la acción de una empresa debiera caer por el valor del dividendo
 cuando pasa de “con dividendo” a “ex dividendo”
 • Mercados reales no son perfectos y hay fricciones
 • Impuestos
 • Problemas de agencia
 • Asimetrı́as de información
 • Empresas saben de estas imperfecciones y ajustan sus polı́ticas de
 dividendo según éllas
 • Tax clienteles
 • Dividend smoothing
 29 / 29

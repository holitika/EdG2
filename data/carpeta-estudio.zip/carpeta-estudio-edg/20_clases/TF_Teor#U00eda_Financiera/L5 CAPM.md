# Teoría Financiera · L5 CAPM

Fuente: clase de Teoría Financiera

[pág. 1]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
 Teorı́a Financiera
 Capital Asset Pricing Model
 Consuelo Silva
 Escuela de Administración PUC
 25 de abril de 2023
 1 / 60

[pág. 2]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Temas
 1 Portafolios Tangencial y de Mercado
 Portafolio de Mercado
 2 Derivación del CAPM
 3 Implicancias
 4 Evidencia Empı́rica
 5 Aplicaciones
 6 Conclusiones
 2 / 60

[pág. 3]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Introducción
 Preguntas claves:
 • ¿Cuál es el retorno esperado (o exigido) de una acción en equilibrio?
 • ¿Cuál es el precio de equilibrio de una acción?
 • ¿En qué portafolios debieran invertir los individuos en equilibrio?
 3 / 60

[pág. 4]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Introducción
 El CAPM es un modelo de equilibrio que:
 • Predice la relación entre riesgo y retorno esperado de los activos
 • Es parte fundamental de las teorı́as financieras modernas
 • Es parte fundamental de las decisiones financieras en el mundo real
 4 / 60

[pág. 5]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Introducción
 • Demanda por activos para retornos dados: teorı́a de portafolios
 • Pero no hemos estudiado esto en equilibrio
 • Especı́ficamente, equilibrio en mercado de activos
 • Nos interesa poder decir algo para E(Ri )
 • ¿Existen variables que nos permitan entender los retornos esperados de
 distintos activos?
 • ¿Cómo lo haremos?
 1 Partiremos de los resultados derivados hasta ahora: decisiones de portafolio
 de individuos (“demanda”)
 2 Derivaremos condiciones para retornos en equilibrio
 3 Elemento crucial: portafolio tangencial
 • ¿Qué queremos encontrar?
 • Relaciones de equilibrio para E(Ri )
 5 / 60

[pág. 6]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Portafolio de Mercado
Portafolio de Mercado
Definición
 Definición (Portafolio de Mercado)
 El portafolio de mercado es aquel que contiene todos los activos riesgosos
 disponibles en el mercado
 • Supongamos que tenemos n activos riesgosos
 • Capitalización de mercado de activo i es
 CAPi =pi × qi
 donde pi es el precio por acción y qi es el número de acciones
 • La capitalización de mercado total, o valor del portafolio de mercado, es la
 suma de las capitalizaciones individuales
 n
 CAPM = ∑ CAPi
 i=1
 • Portafolio de mercado está dado por ponderadores
 CAPi
 ωiM = (1)
 CAPM
 6 / 60

[pág. 7]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Derivación
 • Principales supuestos:
 1 Ausencia de fricciones: Todos los activos son transables, no hay costos de
 transacción y todos los inversionistas pueden endeudarse y prestar a la tasa
 libre de riesgo (Rf ).
 2 Inversionistas MV: Inversionistas mantienen portafolios eficientes
 (optimizan media-varianza).
 3 Expectativas homogéneas: Todos los inversionistas tienen las mismas
 expectativas sobre volatilidades, correlaciones y rendimientos esperados (no
 hay diferencias de opinión)
 • Además asumiremos en principio que todos los inversionistas invierten con
 el mismo horizonte (1 perı́odo).
 7 / 60

[pág. 8]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
CAPM
Resultado Principal
 • Los supuestos anteriores implican:
 1 Teorema del Fondo Mutuo (ya lo conocı́amos): Todos los inversionistas
 tienen un portafolio que es una combinación del activo libre de riesgo y del
 mismo portafolio de activos riesgos (portafolio tangente).
 • Aversión al riesgo sólo afecta cuanto se invierte en el activo libre de riesgo (más
 mientras más averso).
 • Implicancia: todos los inversionistas mantienen activos riesgosos en la misma
 proporción.
 2 Resultado principal del CAPM: En equilibrio el portafolio de mercado es
 el portafolio óptimo de activos riesgosos (portafolio tangencial).
 8 / 60

[pág. 9]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
CAPM
Intuición Equilibrio
 • El resultado principal del CAPM implica que en equilibrio la razón entre
 los ponderadores del portafolio óptimo, wi
 wj será igual a la razón entre sus
 capitalizaciones bursátiles CAPi
 CAPj .
 • Intuición: ¿Qué pasarı́a si inesperadamente hay buenas noticias sobre el
 activo i, y tras reestimar las distribuciones de retornos, optimizamos y
 encontramos que:
 wi CAPi
 ≥
 wj CAPj
 9 / 60

[pág. 10]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
CAPM
Intuición Equilibrio
 Dos efectos que operan en la misma dirección restablecerı́an el equilibrio:
 1 La desigualdad anterior, implica que hay más capital persiguiendo el activo
 i que el valor de todas sus acciones.
 Esto pondrı́a presión sobre el precio de sus acciones (pi ), de manera que
 CAPi aumentarı́a.
 2 Por otro lado este aumento en el precio del activo i, disminuirı́a su retorno
 esperado, lo que llevarı́a a disminuir el interés de los inversionistas por este
 activo, bajando el valor del ponderador óptimo wi .
 Estas dos fuerzas (aumento en CAPi y disminuición en wi ), continuarı́an hasta
 que el equilbrio sea restablecido y se vuelva a cumplir que : w CAPi
 wj = CAPj
 i
 10 / 60

[pág. 11]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Implicancias del CAPM
 Si el CAPM es válido entonces el portafolio de mercado es el portafolio
 tangente. Esto implica:
 1 Frontera eficiente es la combinación de ALR y portafolio de mercado.
 2 El riesgo de un activo está dado por su covarianza con el portafolio de
 mercado.
 3 El riesgo sistemático, es decir el que está correlacionado con el mercado,
 es recompensado.
 • Se paga el riesgo con mayor retorno esperado.
 4 Riesgo no correlacionado con el mercado no es recompensado.
 • Riesgo idiosincrático sobrante no recibe pago =⇒ Se elimina con
 diversificación
 Notar que si el CAPM es válido un inversionista no necesita resolver el
 problema de optimización media-varianza, ya que puede aprovechar el análisis
 de otros inversionistas, y usar el portafolio de mercado como su portafolio
 óptimo de activos riesgosos.
 11 / 60

[pág. 12]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Lı́nea Mercado de Capitales
The Capital Market Line (CML)
 • Bajo el CAPM, las mejores posibilidades de riesgo-retorno son
 combinaciones del ALR y el portafolio de mercado.
 • Portafolios en la CML están determinados por la fracción ω invertida en el
 portafolio de mercado.
 12 / 60

[pág. 13]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Lı́nea Mercado de Capitales
The Capital Market Line (CML)
 Ret. Esper. = Rf + ω (E(RM ) − Rf )
 Volatilidad = ω σM
 13 / 60

[pág. 14]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Lı́nea Mercado de Valores
Security Market Line (SML)
 • Recordemos de nuestro análisis de portafolio óptimo de unas semanas
 atrás que el retorno requerido que hace al activo “i“ atractivo dado el
 portafolio “p“:
 σi
 E ( Ri ) = Rf + ρip × × (E(Rp ) − Rf )
 |{z} |{z} σp | {z }
 Tasa Fracción del Premio por
 |{z}
 libre de riesgo que Riesgo riesgo
 riesgo es común relativo portafolio “p“
 de “i“
 | {z }
 β ip
 | {z }
 Premio por riesgo activo “i“
 14 / 60

[pág. 15]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Lı́nea Mercado de Valores
Security Market Line (SML)
 • Ahora si el CAPM es válido, todos los inversionistas tienen el portafolio de
 mercado por lo que la medida correcta de riesgo es el beta del activo con
 respecto al portafolio de mercado:
 σi σ
 β iM = ρi,M = i,M
 2
 σM σM
 • Intuición: Beta mide el riesgo de mercado
 • es proporcional al riesgo que el activo contribuye al potafolio óptimo (M)
 • Beta es la “sensibilidad”de la acción al mercado.
 • Es decir, es el % de cambio esperado en el valor de la acción ante un
 cambio de 1 % en el valor de mercado.
 • Ejemplo:
 • si beta=1.3, entonces si el valor del mercado aumenta en 10 %, entonces el
 valor del stock aumenta en 13 %
 • si beta=0.7, entonces si el valor del mercado aumenta en 10 %, entonces el
 valor del stock aumenta en 7 %
 15 / 60

[pág. 16]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Lı́nea Mercado de Valores
Security Market Line (SML)
 • El premio por riesgo de una acción i es igual a beta veces el premio por
 riesgo de mercado:
  
 E(Ri ) − Rf = β iM E(RM ) − Rf
 • β iM es la medida de riesgo relevante, determina su contribución al riesgo
 del portafolio M.
 16 / 60

[pág. 17]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Lı́nea Mercado de Valores
Security Market Line (SML)
 Algunos casos especiales:
 • Si β iM = 1 =⇒ E(Ri ) = E(RM )
 • Si β iM = 0 =⇒ E(Ri ) = Rf (implica que el activo es libre de riesgo?)
 • Si β iM < 0 =⇒ E(Ri ) < Rf , por qué?
 17 / 60

[pág. 18]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Lı́nea Mercado de Valores
Security Market Line (SML)
 Los retornos esperados de todos los activos estan ordenados en la SML:
 E(Ri ) = RF + β iM (E(RM ) − RF )
 Es posible encontrar activos sobre/bajo la SML?
 18 / 60

[pág. 19]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Lı́nea Mercado de Capitales y Lı́nea Mercado de Valores
 Riesgo Total (CML) vs. Beta (SML)
 19 / 60

[pág. 20]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Lı́nea Mercado de Valores
Security Market Line (SML)
 • pregunta: Suponga que desabolladurı́as ‘Toponcito” tiene un beta de -0.3.
 Suponga además que la tasa libre de riesgo es de 3 % y que el retorno
 esperado del portafolio de mercado es de 7 %. ¿Cuál es el retorno esperado
 de “Toponcito” según el CAPM?
 a -2.1 %
 b -1.2 %
 c 0.9 %
 d 1.8 %
 e No sé
 20 / 60

[pág. 21]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Betas en el mundo real
 • Beta no es “una cosa estadı́stica extraña”.
 • Oro vs tecnologı́a y durables
 21 / 60

[pág. 22]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Riesgo de un Activo
Componentes
 • ¿Cómo podemos descomponer riesgo/volatilidad de un activo en CAPM?
 • Escribamos el retorno de un activo en el perı́odo t como
 Ri − Rf = β iM (RM − Rf ) + ϵi
 | {z } |{z}
 parte sistemática parte no sistemática
 donde E(ϵi ) = 0 y Cov(RM , ϵi ) = 0
 • Si calculamos la varianza obtenemos:
 σi2 = β2 σM 2
 + σϵ2i (2)
 |{z} | iM
 {z } |{z}
 riesgo total riesgo sistemático riesgo no-sistemático
 • Esto muestra que el riesgo sistemático es sólo parte de la volatilidad.
 • El riesgo no sistemático, por definición, no debe tener correlación con el
 riesgo sistemático
 22 / 60

[pág. 23]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Riesgo de un activo
Componentes
 • Ejemplo: un activo con β iM = 1,5, σi2 = 0,5 y σM 2 = (0,25)2
 • pregunta ¿Qué fracción del riesgo (varianza) es no-sistemático?
 a 18.1 %
 b 35.9 %
 c 71.9 %
 d No sé
 23 / 60

[pág. 24]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Riesgo de un activo
Componentes: Ejemplo
 • El riesgo sistemático es
 β2iM σM
 2
 =1,52 0,252 = 0,140625
 • El riesgo no sistemático es
 σϵ2i =σi2 − β2iM σM
 2
 =0,5 − 0,140625 = 0,359375
 • Como fracción del riesgo total es
 σϵ2i 0,359375
 = =0,71875
 σi2 0,5
 24 / 60

[pág. 25]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Riesgo y retorno de un activo
 • Sólo el riesgo sistemático es compensado!
 E(Ri ) =RF + β iM (E(RM ) − RF )
 • por qué?
 25 / 60

[pág. 26]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Riesgo y retorno de un activo
 • Tomemos Exxon, con retorno E(R)Exxon y volatilidad σExxon .
 • Podemos encontrar el mismo retorno con un portafolio eficiente?
 26 / 60

[pág. 27]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Propiedades de los Beta
 • pregunta ¿Cuál es el beta de un activo libre de riesgo y el de mercado?:
 a β Rf = 1 y β M > 1
 b β Rf = 0 y β M ≥ 1
 c β Rf = 0 y β M = 1
 d No sé
 27 / 60

[pág. 28]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Propiedades de los Beta
 • El beta de un activo libre de riesgo es siempre 0:
 Cov(RF , RM ) ρ σ σ
 βF = 2
 = F,M 2F M = 0
 σM σM
 • El beta del portafolio de mercado es 1:
 Cov(RM , RM ) ρ σ σ
 βM = 2
 = M,M 2M M = 1
 σM σM
 28 / 60

[pág. 29]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Propiedades de los Beta
 • El beta de un portafolio es igual al promedio ponderado de los betas de los
 activos que lo componen:
 n
 β p = ∑ ωi β i
 i=1
 ωi es la participación del activo i en el portafolio.
 • ωi β i : contribución del activo i.
 • Activos con igual beta tienen el mismo riesgo total?.
 29 / 60

[pág. 30]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Propiedades de los Beta
Ejercicio
 • pregunta: Suponga que Benjamı́n y Sofı́a son los únicos inversionistas que
 existen, por lo que entre ambos tienen en sus portafolios todos los activos
 financieros disponibles. El portafolio de Benjamı́n representa el 60 % del
 valor total de los activos disponibles y tiene un beta de 1.4 ¿Cuál es el
 beta del portafolio de Sofı́a?
 a 0.2
 b 0.4
 c 1
 d 1.4
 e No sé
 30 / 60

[pág. 31]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Beta Activos vs Beta Patrimonio
 • Usando el hecho de que el beta de un portafolio es igual al promedio
 ponderado de los betas de los activos que lo componen, podemos
 encontrar la relación entre el beta de los activos de una empresa (A) y el
 beta de su patrimonio (E) y de su deuda (D):
 E D
 βA = β + β
 E+D E E+D D
 31 / 60

[pág. 32]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Beta Activos vs Beta Patrimonio - Ejemplo
 • Suponga que usted quiere encontrar la tasa de descuento adecuada para
 una inversión en un nuevo centro de ski.
 • Para ello usted estima el beta de la empresa Ski Resorts Chile, mediante
 una regresión del precio de la acción de Ski Resorts Chile y el mercado
 (IPSA por ejemplo). Suponga que el beta estimado para la acción de Ski
 Resorts es de 2.8 y que esta empresa tiene un 50 % de deuda y un 50 % de
 patrimonio.
 • Asuma un retorno esperado de mercado de 8 % y la tasa libre de riesgo de
 3 % y que el beta de la deuda de Ski Resorts Chile es de 0.
 • pregunta La tasa de descuento según el CAPM para mi inversión es:
 a 17 %
 b 10 %
 c 7%
 d No sé
 32 / 60

[pág. 33]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Beta Activos vs Beta Patrimonio - Ejemplo
 • Suponga que usted quiere encontrar la tasa de descuento adecuada para
 una inversión en un nuevo centro de ski.
 • Para ello usted estima el beta de la empresa Ski Resorts Chile, mediante
 una regresión del precio de la acción de Ski Resorts Chile y el mercado
 (IPSA por ejemplo). Suponga que el beta estimado para la acción de Ski
 Resorts es de 2.8 y que esta empresa tiene un 50 % de deuda y un 50 % de
 patrimonio.
 • Asuma un retorno esperado de mercado de 8 % y la tasa libre de riesgo de
 3 % y que el beta de la deuda de Ski Resorts Chile es de 0.
 • pregunta ¿Cómo cambia la tasa de descuento si hubiera asumido que el
 beta de la deuda de Ski Resorts Chile es 0.5?
 a Tasa de descuento aumenta.
 b Tasa de descuento no cambia.
 c Tasa de descuento disminuye.
 d No sé.
 33 / 60

[pág. 34]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Resumen - CAPM
 • Los inversionistas pueden eliminar algunos riesgos (riesgo idiosincrático)
 diversificando en diferentes sectores y regiones.
 • Algunos riesgos, como una recesión mundial, no pueden ser eliminados
 (riesgo sistemático), por lo que un portafolio bien diversificado será
 todavı́a riesgoso.
 • El premio por riesgo exigido a un activo estará determinado por el riesgo
 que contribuye dicho activo al portafolio diversificado (portafolio óptimo)
 • Dicha contribución está capturada por el “beta”del activo.
 34 / 60

[pág. 35]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Test del CAPM
 • Derivamos relación entre retorno esperado y β
 E(Rit ) − Rf ,t = β i (E(RM,t ) − Rf ,t )
 • Para testear al CAPM hacemos dos pasos
 1 Primero estimamos αi , β i para cada acción usando retornos históricos en
 una regresión en la serie de tiempo.
 Rit − Rf ,t = αi + β i (RM,t − Rf ,t ) + ϵit
 2 Una vez que tenemos los betas podemos graficarlos respecto a los retornos
 promedio de los activos y ver cómo se ve la SML.
 35 / 60

[pág. 36]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Test del CAPM - Paso 1
 Paso 1 Primero estimamos αi , β i para cada acción usando retornos históricos en
 una regresión en la serie de tiempo:
 Rit − Rf ,t = αi + β i (RM,t − Rf ,t ) + ϵi,t
 36 / 60

[pág. 37]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Test del CAPM - Paso 1
 37 / 60

[pág. 38]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Test del CAPM - Paso 1
 38 / 60

[pág. 39]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Test del CAPM - Paso 2
 Paso 2 Una vez que tenemos los betas de distintas empresas podemos graficarlos
 respecto a los retornos promedio de los activos y ver cómo se “ve” la SML.
 • La predicción del CAPM es que αi = 0 para cada uno de los activos.
 • Pero, siempre habrá desviaciones en α’s porque estamos estimando la SML
 con una muestra especı́fica, esto no es indicación necesaria de que el CAPM
 está fallando. Acordémonos de que la teorı́a es sobre retornos esperados,
 que no son observables, y tenemos que hacer inferencia sobre ellos usando
 retornos realizados que si son observables.
 • Un test más razonable es si el conjunto de los alfas es cero.
 39 / 60

[pág. 40]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Test del CAPM - Paso 2
 • Podemos usar estos betas estimados β̂ i en una regresión en el corte
 transversal:
 Ri − Rf = γ0 + γ1 β̂ i + ϵi
 • Si el CAPM se cumple entonces se debiera cumplir que:
 γ0 → 0,
 γ1 → RM − Rf
 40 / 60

[pág. 41]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Evidencia Empı́rica
 The Capital Asset Pricing Model: Theory and Evidence 33
 Figure 2
 Average Annualized Monthly Return versus Beta for Value Weight Portfolios
 Formed on Prior Beta, 1928 –2003
 18
 Average annualized monthly return (%)
 16
 14
 12
 10
 Average returns
 8 predicted by the
 CAPM
 6
 0.5 0.7 0.9 1.1 1.3 1.5 1.7 1.9
 Figura:
 line, with an intercept equal Fama and French
 to the risk-free rate, R(2004)
 f , and a slope equal to the
 expected excess return on the market, E(R M ) ⫺ R f . We use the average one-month
 Treasury bill rate and the average excess CRSP market return for 1928 –2003 to
 estimate the predicted line in Figure 2. Confirming earlier evidence, the relation
 between beta and average return for the ten portfolios is much flatter than the
 Sharpe-Lintner CAPM predicts. The returns on the low beta portfolios are too high, 41 / 60

[pág. 42]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Efectos Tamaño y Valor (Size and Value Effects)
 A comienzos de los años 80 se descubrió que:
 • Size effect: empresas pequeñas entregan retornos superiores a las
 empresas grandes.
 • A pesar de que el beta de las empresas pequeñas es mayor que el de las
 grandes, la diferencia no es suficiente para explicar el exceso de retorno.
 • Value effect: empresas con alto valor en la razón entre el valor contable y
 el valor de mercado (BM) (“acciones value”), entregan retornos superiores
 a empresas con valor menos en esta razón (“acciones growth”).
 • Este resultado es particularmente sorprendente dado que las “acciones
 value”tienen betas menores que las “acciones growth”.
 42 / 60

[pág. 43]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
 Eugene F. Fama and Kenneth R. French 43
Value effect (Efecto Valor)
 Figure 3
 Average Annualized Monthly Return versus Beta for Value Weight Portfolios
 Formed on B/M, 1963–2003
 17
 Average annualized monthly return (%)
 10 (highest B/M)
 16
 15 9
 8
 14 7
 6
 13
 Average returns 5 3
 12 4 2
 predicted by
 11 the CAPM
 10 1 (lowest B/M)
 9
 0.7 0.8 0.9 1 1.1 1.2
 Figura: Fama and French (2004)
 market proxies, like the value-weight portfolio of U.S. stocks, that lead to rejections 43 / 60

[pág. 44]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Fama-French (1992)
 • Analizan la capacidad de 3 factores para explicar retornos: betas, tamanño
 de la empresa (valor de mercado del patrimonio), razón book/market.
 Ri − Rf =αi + β i,1 (RM − Rf ) + β 2 HML + β 3 SMB + ϵi
 44 / 60

[pág. 45]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Fama-French (1992)
 • Los dos factores adicionales explican parte significativa de la variación en
 retornos: a menor tamaño mayor retorno, a mayor razón BM mayor
 retorno.
 • El beta no explica los retornos una vez que controlamos por estos dos
 factores.
 • Estos factores pueden ser proxy de factores especı́ficos de riesgo que el
 mercado “paga” no capturados por el beta.
 • Existe mucha investigación en este debate.
 45 / 60

[pág. 46]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Otras Anomalı́as
 Un área importante de la investigación en finanzas se ha dedicado a estudiar
 anomalı́as. Algunas de las más importantes:
 • Reversión de corto plazo: acciones con buen rendimiento el mes pasado
 tienden a tener peor desempeño el mes siguiente.
 • Momentum: acciones con buen rendimiento el año pasado (excluyendo
 mes anterior) tienden a tener mejor desempeño el mes siguiente.
 • Monday dummy (French, 1980) : existe un efecto negativo del lunes, lo
 que significa esencialmente que los retornos promedios de los dias lunes
 son negativos.
 • January dummy (+) (Roll, 1983; Reinganum, 1983): los retornos
 promedios del mes de enero son significativamente más altos que los
 retornos promedios de los otros once meses del año.
 • Drift post anuncio de utilidades: precio de acciones que sorprenden al
 mercado con buenas utilidades tienden a saltar al momento del anuncio y
 luego continúan subiendo por un tiempo.
 46 / 60

[pág. 47]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Respuestas a la Evidencia Empı́rica
 1 Evidencia es consecuencia de mucha gente buscando anomalı́as y son
 particulares al perı́odo en cuestión. En el futuro debieran desaparecer.
 Incluso si existieron en algún momento estas anomalı́as, debieran
 desaparecer por acción de arbitradores. Esto ha pasado en parte con el size
 effect, pero no con el value effect o momentum.
 2 No son animalı́as reales ( Crı́tica de Roll): Es imposible testear el CAPM
 porque no podemos observar el verdadero portafolio de mercado. Pensar
 en activos que no se transan como el capital humano.
 47 / 60

[pág. 48]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Respuestas a la Evidencia Empı́rica
 3. Fricciones en los mercados financieros como imposibilidad de hacer ventas
 cortas, existencia de costos de transacción, liquidez, etc.
 48 / 60

[pág. 49]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Respuestas a la Evidencia Empı́rica
 4. Multiples factores de riesgo: El CAPM no es lo suficientemente general y
 necesitamos un modelos más completos que incorporen estas anomalı́as.
 5. Behavioral finance: Las anomalı́as son causados por sesgos psicológicos
 de los inversionistas que resultan en mercados ineficientes.
 49 / 60

[pág. 50]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Aplicaciones CAPM
Ejemplos
 1 Calcular tasas de retorno exigido a un activo
 • Ejercicio clásico requiere usar empresas “comparables”para determinar el β
 de los activos y usar las propiedades de los β que vimos un par de
 diapositivas atrás para ajustar por los posibles diferentes niveles de
 endeudamiento.
 2 Medición de desempeńo
 • Ajustamos por riesgo –usando β
 • Comparar retorno esperado CAPM con valores históricos
 50 / 60

[pág. 51]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Aplicaciones CAPM - Ejemplo
 • pregunta Una empresa está evaluando una inversión que le cuesta $110
 hoy que darı́a flujos de $70 y $70 en uno y dos años más respectivamente.
 • Esta inversión se cree está en la misma clase de riesgo que las operaciones
 actuales de la firma. Usted sabe que el β de la firma es 2, que la tasa libre
 de riesgo es 5 % y además se estima que el retorno esperado del mercado
 es 10 %. ¿Determine si la empresa debe realizar esta inversión y su VPN?
 a Sı́ se debiera hacer esta inversión, el VPN es $3.8
 b Sı́ se debiera hacer esta inversión, el VPN es $11.7
 c No se debiera hacer esta inversión, el VPN es $-3.1
 d No sé como resolver este problema
 51 / 60

[pág. 52]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Aplicaciones CAPM - Ejemplo
 • Una empresa está evaluando una inversión que le cuesta $110 hoy que
 darı́a flujos de $70 y $70 en uno y dos años más respectivamente.
 • Esta inversión se cree está en la misma clase de riesgo que las operaciones
 actuales de la firma. Usted sabe que el β de los activos de la firma es 2,
 que la tasa libre de riesgo es 5 % y además se estima que el retorno
 esperado del mercado es 10 %. ¿Determine si la empresa debe realizar esta
 inversión y su VPN?
 • Primero calculamos la tasa correspondiente usando el CAPM:
 E(Rinv ) =Rf + β A (E(RM ) − Rf ) = 15 %
 • Ahora calculamos el VPN:
 70 70
 VPN = − 110 + + = 3,8
 1,15 1,152
 52 / 60

[pág. 53]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Alfa (α) de Jensen
 • Recordemos qué representa α:
 • Es la porción del exceso de retorno de un activo o portafolio que no es
 explicado por riesgo sistemático (β)
 • Según el CAPM
 E[Rit ] = Rf + β iM (E[RMt ] − Rf )
 • Supongamos que calculamos el retorno esperado de nuestro portafolio según el CAPM
 y obtenemos 15.6 %
 • Pero en la realidad el retorno fue 17 %
 • Tenemos una diferencia de un 1.4 %, esto es el α.
 • Matemáticamente es la diferencia entre el retorno esperado y la predicción de CAPM:
 E[Rit ] = Rf + β iM (E[RMt ] − Rf ) + αi (3)
 | {z } |{z}
 E[Ri ] según la SML Distancia sobre/bajo la SML
 • ¿Qué nos dice CAPM acerca de α?
 • Deberı́a ser 0 para todos los activos
 • ¿Qué pasa si encontramos un activo con αi > 0?
 53 / 60

[pág. 54]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Alfa (α) de Jensen
 • Esta medida se conoce como α de Jensen: si el modelo está correcto (no
 sólo CAPM) nos da el retorno anormal.
 • Idea: α nos da una medida de desempeño:
 • En nuestro ejemplo anterior (α = 1,4 %) el fund manager dirá que tuvieron
 un buen desempeño.
 • Se suponı́a que según el CAPM tendrı́a un rendimiento determinado, pero
 en realidad se obtuvo un rendimiento que fue mayor en un 1.4 %.
 • y seguramente argumentará que la razón se debió a la buena gestión de su
 parte.
 • En resumen, ¿qué nos indica αJ ?
 • Positivo −→
 • Cero −→
 • Negativo −→
 54 / 60

[pág. 55]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Alfa (α) de Jensen
 55 / 60

[pág. 56]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
 56 / 60

[pág. 57]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Alfa (α) de Jensen
 pregunta (BKM) La acción XYZ tiene un retorno esperado de 12 % y un beta
 de 1. La acción ABC tiene un retorno esperado de 13 % y un beta de 1.5. El
 retorno esperado del mercado es de 11 % y la tasa libre de riesgo es 5 %. Cuál
 es el alpha de cada acción?
 1 Alfa de XYZ = -1 %, Alfa de ABC = 1 %
 2 Alfa de XYZ = 1 %, Alfa de ABC = -1 %
 3 Ambos tienen alfa igual a cero.
 4 No sé.
 57 / 60

[pág. 58]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Alfa (α) de Jensen
 pregunta (BKM) La acción XYZ tiene un retorno esperado de 12 % y un beta
 de 1. La acción ABC tiene un retorno esperado de 13 % y un beta de 1.5. El
 retorno esperado del mercado es de 11 % y la tasa libre de riesgo es 5 %. De
 acuerdo al CAPM, qué acción conviene comprar?
 1 XYZ está sobrevalorada, por lo tanto conviene comprarla.
 2 XYZ está subvalorada, por lo tanto conviene comprarla.
 3 ABC está sobrevalorada, por lo tanto conviene comprarla.
 4 ABC está subvalorada, por lo tanto conviene comprarla.
 58 / 60

[pág. 59]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Alfa (α) de Jensen
 • Alpha:
 α = E[R] − [RF + β(E[Rm] − RF )]
 αXYZ = 0,12 − [0,05 + 1 × (0,11 − 0,05)] = 0,01
 αABC = 0,13 − [0,05 + 1,5(0,11 − 0,05)] = −0,01
 ABC está debajo de la SML, mientras que XYZ está sobre.
 • XYZ está subvalorada, por lo tanto conviene comprarla.
 59 / 60

[pág. 60]
Portafolios Tangencial y de Mercado Derivación del CAPM Implicancias Evidencia Empı́rica Aplicaciones Conclusio
Conclusiones
 • CAPM es ampliamente usado – debe tener ventajas. . .
 • Atractivo de CAPM
 • Es fácil de implementar
 • Simple y “razonable”
 • distinción de riesgos sistemático y no-sistemático
 • simple modelo de pricing
 • anclado en teorı́a de portafolio
 • Pero también tiene problemas
 • No es claro que se pueda testear directamente:
 • se necesita estimar retornos y β.
 • elemento clave es esencialmente inobservable: portafolio de mercado.
 • Modelos alternativos pueden tener mejor performance
 • CAPM multi-factor
 • APT y más factores.
 60 / 60

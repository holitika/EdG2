# Teoría Financiera · L4 Análisis MV

Fuente: clase de Teoría Financiera

[pág. 1]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
 Teorı́a Financiera
 Análisis Media Varianza
 Consuelo Silva
 Escuela de Administración PUC
 11 de abril de 2023
 1 / 68

[pág. 2]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Motivación
 • Objetivo: En qué activos invertir y cómo se determinan los precios.
 • Plan establecido:
 1 Repaso funciones de utilidad
 • Cómo modelar a los inversionistas: aproximadamente sólo quieren tener alto
 retorno y baja volatildiad
 2 Qué implica esta aproximación para la demanda de activos: análisis
 Media-Varianza
 3 Usamos argumento de equilibrio (demanda=oferta) para obtener el famoso
 CAPM.
 • ¿ Funciona? y extensiones
 4 ¿Son eficientes los mercados?
 5 Behavioral Finance
 2 / 68

[pág. 3]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Motivación
 • En qué activos riesgosos debemos invertir?
 • Cómo decide el inversionista su portafolio óptimo?
 • Ejemplo: por qué activos esta compuesto el IPSA, los fondos de pensiones,
 etc?
 3 / 68

[pág. 4]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Temas
 1 Refrescando Conocimientos
 Covarianza
 Combinaciones de Variables Aleatorias
 2 Diversificación
 Intuición: 2 activos
 Riesgo Sistemático
 Resumen
 3 Portafolios Riesgosos y Portafolios Eficientes
 2 Activos Riesgosos
 n Activos Riesgosos
 Resumen
 Portafolio riesgosos y ALR
 4 Decisión Individual
 Lecturas: BKM cap. 6.4 a 6.6 y cap. 7.
 4 / 68

[pág. 5]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Covarianza
Covarianza y Correlación
Definición
 • Recordando: Covarianza – definición
 n
 Cov(X, Y) =σXY = ∑ πi (xi − E(X))(yi − E(Y)) (1)
 i=1
 • La correlación es
 σXY
 ρXY = (2)
 σX σY
 5 / 68

[pág. 6]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Combinaciones de Variables Aleatorias
Media y Varianzas de Combinaciones
 • Definamos Z = aX + bY, a, b constantes
 • Entonces tenemos
 E(Z) =aE(X) + bE(Y) (3)
 2 2
 V (Z) =a V (X) + b V (Y) + 2abCov(X, Y)
 =a2 V (X) + b2 V (Y) + 2abσX σY ρXY (4)
 • Covarianza
 Cov(aX, bY) =abCov(X, Y)
 6 / 68

[pág. 7]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Combinaciones de Variables Aleatorias
Retornos y Varianzas de Portafolios
n activos
 • Llamaremos ωi a la participación de activo i en portafolio
 • Activos 1, . . . , n
 • Retornos: Ri → E(Ri ), σi
 • Portafolio: ponderadores ωi , ∑i ωi = 1
 n
 Rp = ∑ ωi Ri (5)
 i=1
 • Momentos retorno portafolio
 • Media:
 n
 E(Rp ) = ∑ ωi E(Ri ) (6)
 i=1
 • Varianza:
 n n
 σp2 = ∑ ∑ ωi ωj σij (7)
 i=1 j=1
 7 / 68

[pág. 8]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Intuición: 2 activos
Varianza de un Portafolio
2 Activos
 • Varianza de un portafolio de dos activos
 σR2 P = ωA
 2 2
 σA + ωB2 σB2 + 2ωA ωB σAB
 • La covarianza se puede escribir como σAB = ρAB σA σB
 σR2 P =ωA
 2 2
 σA + ωB2 σB2 + 2ωA ωB ρAB σA σB (8)
 • ¿Cómo es el σ del portfolio vs promedio de σ de activos individuales?
 • Algunos casos especiales
 ρ=1 σR2 P = ωA
 2 2
 σA + ωB2 σB2 + 2ωA ωB σA σB
 = (ωA σA + ωB σB )2
 ρ=0 σR2 P = ωA
 2 2
 σA + ωB2 σB2
 ρ = −1 σR2 P = ωA
 2 2
 σA + ωB2 σB2 − 2ωA ωB σA σB
 = (ωA σA − ωB σB )2
 8 / 68

[pág. 9]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Intuición: 2 activos
Varianza de un Portafolio
2 Activos
 • La desviación estándar
 ρ=1 σRP = (ωA σA + ωB σB )
 q
 ρ=0 σRP = ωA 2 σ2 + ω 2 σ2
 A B B
 ρ = −1 σRP = |ωA σA − ωB σB )|
 • Para cualquier ρ < 1 tendremos que σRP < ωA σA + ωB σB
 • Esto es diversificación
 • Repartiendo los recursos entre distintos activos se reduce la exposición a las
 fluctuaciones de activos particulares.
 • Ejemplo: portafolio con acciones de COPEC vs. portafolio con acciones de
 COPEC y LATAM.
 • Ejemplo: portafolio con acciones vs. portafolio con acciones y oro.
 9 / 68

[pág. 10]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Intuición: 2 activos
Varianza de un Portafolio
2 Activos
 • ¿Podemos hacer un portafolio con cero varianza? Apalancamiento perfecto
 si ρ = −1
 • σRP = |ωA σA − (1 − ωA )σB |
 • ωA = σB /(σA + σB )
 10 / 68

[pág. 11]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Intuición: 2 activos
Portafolio con n Activos
Varianza
 • Noten que podemos escribir la fórmula de la varianza de la siguiente
 manera
 n n n n
 σp2 = ∑ ∑ ωi ωj σij = ∑ ωi2 σi2 + ∑ ∑ ωi ωj σij
 i=1 j=1 i=1 i=1 j̸ =i
 | {z } | {z }
 A B
 • Los términos A y B tienen una interpretación natural;
 (A) Suma de riesgos propios
 (B) Suma de riesgos cruzados
 11 / 68

[pág. 12]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Intuición: 2 activos
Portafolio con n Activos
¿Cuánto puedo diversificar?
 • Pensemos en el caso de muchos activos =⇒ n se acerca a ∞
 • Trabajemos con un portafolio con ponderación igual para todos los activos
 n n
 σp2 = ∑ (1/n)2 σi2 + ∑ ∑(1/n)(1/n)σij
 i=1 i=1 j̸ =i
 n n
 =(1/n)2 ∑ σi2 + (1/n)2 ∑ ∑ σij
 i=1 i=1 j̸ =i
 • Definamos
 ∑ni=1 σi2
 σ2 =
 n
 ∑ni=1 ∑j̸=i σij
 σij =
 n2 − n
 • En la última expresión usamos n2 − n porque ese es el número de términos
 que tenemos en los riesgos cruzados
 12 / 68

[pág. 13]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Intuición: 2 activos
Portafolio con n Activos
¿Cuánto puedo diversificar?
 • Ahora usamos las última dos ecuaciones en la fórmula para la varianza del
 portfolio
 σp2 =(1/n)2 nσ2 + (1/n)2 (n2 − n)σij
 σ2 σij
 = + σij −
 n n
 • El primer y el último término del lado derecho convergen a 0 cuando n
 crece
 • Nos quedamos con σij que corresponde a una “covarianza promedio” de
 los activos
 • Este valor nos muestra la varianza que podrı́amos alcanzar en un portafolio
 altamente diversificado (y con ponderadores iguales para todos los activos)
 13 / 68

[pág. 14]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Intuición: 2 activos
Portafolio con n Activos: Ejemplo Diversificación
 • Supongamos que tenemos un portafolio con ponderadores iguales para
 todas las acciones.
 • Suponga retornos independientes con volatilidad 40 % y E(R)=10 %.
 14 / 68

[pág. 15]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Riesgo Sistemático
Riesgo Sistemático
 • Riesgo sistemático
 • Riesgo “agregado” que puede afectar a todos los instrumentos financieros
 de la economı́a de manera conjunta. Este riesgo no puede ser eliminado
 mediante diversificación.
 • ¿Qué tipo de variables o shocks son potenciales fuentes de riesgo
 sistemático?
 • Algunos ejemplos
 1 Crecimiento agregado incierto
 2 Cambios en tasas de descuento (aversión al riesgo, tasas de interés)
 3 Sorpresas en variables macroeconómicas
 4 ...CORONAVIRUS!
 15 / 68

[pág. 16]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Riesgo Sistemático
Riesgo No Sistemático
 • “Por diferencia” el riesgo no sistemático es la parte del riesgo que afecta
 solamente a un activo o un grupo de activos especı́fico. Este riesgo puede
 ser eliminado al tener portafolios suficientemente diversificados.
 • Ejemplos
 • Shocks en variables especı́ficas para un sector (shocks sectoriales). Ejemplo:
 sequı́a y sector agrı́cola.
 • Siniestros y accidentes locales. Ejemplo: estallido social, chalecos amarillos
 en Francia, etc.
 • etc.
 • ¿Es relevante este riesgo para un inversionista?
 • No, al inversionista profesional sólo le preocupa el riesgo sistemático
 • ¿Por qué?
 16 / 68

[pág. 17]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Resumen
Diversificación
Resumen
 • Lecciones de diversificación
 1 Reduce riesgo
 2 Pero esto tiene un lı́mite –no todo riesgo es eliminable con diversificación
 • En un portafolio bien diversificado
 • Varianza de cada activo contribuye poco
 • Covarianzas determinan el riesgo del portafolio
 17 / 68

[pág. 18]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Motivación
 • ¿Cuáles son las combinaciones de media-varianza que se pueden alcanzar?
 • Si existe más de un portafolio con igual varianza, ¿cuál es el relevante?
 • ¿Y si hay más de uno con igual retorno esperado?
 • Con 2 activos: respuestas son simples
 • Con igual varianza, seleccionar mayor retorno esperado
 • Selección de portafolios → portafolios eficientes
 18 / 68

[pág. 19]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
2 Activos Riesgosos
Intuición
Caso simple: 2 activos riesgosos
 • Recordemos que
 E(Rp ) =ω1 E(R1 ) + (1 − ω1 )E(R2 )
 σp2 =ω12 σ12 + (1 − ω1 )2 σ22 + 2ω1 (1 − ω1 )σ12
 • Podemos escribir
 E(Rp ) − E(R2 ) E ( Rp ) − E ( R1 )
 ω1 = = 1−
 E(R1 ) − E(R2 ) E(R2 ) − E(R1 )
 • Por lo que
 E ( Rp ) − E ( R2 ) 2 2 E ( Rp ) − E ( R1 ) 2 2
    
 σp2 = σ1 + σ2
 E ( R1 ) − E ( R2 ) E ( R2 ) − E ( R1 )
 E ( Rp ) − E ( R2 ) E ( Rp ) − E ( R1 )
   
 +2 σ12
 E ( R1 ) − E ( R2 ) E ( R2 ) − E ( R1 )
 =⇒ ecuación cuadrática entre E(Rp ) y σp2
 19 / 68

[pág. 20]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
2 Activos Riesgosos
Intuición
Caso simple: 2 activos riesgosos
 • Recordemos que
 E(Rp ) =ω1 E(R1 ) + (1 − ω1 )E(R2 )
 σp2 =ω12 σ12 + (1 − ω1 )2 σ22 + 2ω1 (1 − ω1 )σ12
 • Podemos escribir
 E(Rp ) − E(R2 ) E ( Rp ) − E ( R1 )
 ω1 = = 1−
 E(R1 ) − E(R2 ) E(R2 ) − E(R1 )
 • Por lo que
 E ( Rp ) − E ( R2 ) 2 2 E ( Rp ) − E ( R1 ) 2 2
    
 σp2 = σ1 + σ2
 E ( R1 ) − E ( R2 ) E ( R2 ) − E ( R1 )
 E ( Rp ) − E ( R2 ) E ( Rp ) − E ( R1 )
   
 +2 σ12
 E ( R1 ) − E ( R2 ) E ( R2 ) − E ( R1 )
 =⇒ ecuación cuadrática entre E(Rp ) y σp2
 19 / 68

[pág. 21]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
2 Activos Riesgosos
Intuición
Caso simple: 2 activos riesgosos
 • Recordemos que
 E(Rp ) =ω1 E(R1 ) + (1 − ω1 )E(R2 )
 σp2 =ω12 σ12 + (1 − ω1 )2 σ22 + 2ω1 (1 − ω1 )σ12
 • Podemos escribir
 E(Rp ) − E(R2 ) E ( Rp ) − E ( R1 )
 ω1 = = 1−
 E(R1 ) − E(R2 ) E(R2 ) − E(R1 )
 • Por lo que
 E ( Rp ) − E ( R2 ) 2 2 E ( Rp ) − E ( R1 ) 2 2
    
 σp2 = σ1 + σ2
 E ( R1 ) − E ( R2 ) E ( R2 ) − E ( R1 )
 E ( Rp ) − E ( R2 ) E ( Rp ) − E ( R1 )
   
 +2 σ12
 E ( R1 ) − E ( R2 ) E ( R2 ) − E ( R1 )
 =⇒ ecuación cuadrática entre E(Rp ) y σp2
 19 / 68

[pág. 22]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
2 Activos Riesgosos
Portafolio de 2 Activos Riesgosos
 • Correlación positiva perfecta (ρ = 1)
 • En este caso no hay beneficios de diversificar.
 20 / 68

[pág. 23]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
2 Activos Riesgosos
Portafolio de 2 Activos Riesgosos
 • Caso general (−1 < ρ < 1)
 • Cuando no hay correlación perfecta, el riesgo es diversificado.
 • ¿Cuáles portafolios son eficientes?
 21 / 68

[pág. 24]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
2 Activos Riesgosos
Portafolio de 2 Activos Riesgosos
 • Correlación negativa perfecta (ρ = −1)
 • En este caso podemos formar un portafolio de cero varianza.
 22 / 68

[pág. 25]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
2 Activos Riesgosos
Portafolio de Mı́nima Varianza
 • En el gráfico anterior, un punto de gran interés es el portafolio de mı́nima
 varianza (PMV).
 • Este portafolio es el de menor riesgo posible.
 • Vamos a encontrar los ponderadores de los activos A y B del PMV.
 • Definamos como wPMVA a este ponderador para el activo A.
 • wPMVB = 1 − wPMVA
 • Notar que en ese punto, la derivada de la varianza (y volatilidad) con
 respecto a los ponderadores de los activos es cero (“lı́nea vertical en ese
 punto“).
 23 / 68

[pág. 26]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
2 Activos Riesgosos
Portafolio de Mı́nima Varianza
 • La varianza de un portafolio es:
 σp2 = w2A σA2 + (1 − wA )2 σB2 + 2wA (1 − wA )σAB
 • La condición de primer orden (derivada igual a 0):
 ∂σp2
 = 2wA σA2 − 2(1 − wA )σB2 + 2(1 − wA )σAB − 2wA σAB = 0
 ∂wA
 • Resolviendo para wPMVA :
 σB2 − σAB
 wPMVA =
 σA2 + σB2 − 2σAB
 24 / 68

[pág. 27]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
2 Activos Riesgosos
Portafolio de Mı́nima Varianza
 • La varianza de un portafolio es:
 σp2 = w2A σA2 + (1 − wA )2 σB2 + 2wA (1 − wA )σAB
 • La condición de primer orden (derivada igual a 0):
 ∂σp2
 = 2wA σA2 − 2(1 − wA )σB2 + 2(1 − wA )σAB − 2wA σAB = 0
 ∂wA
 • Resolviendo para wPMVA :
 σB2 − σAB
 wPMVA =
 σA2 + σB2 − 2σAB
 24 / 68

[pág. 28]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
2 Activos Riesgosos
Portafolio de Mı́nima Varianza
 • Para el caso (ρ = −1), podemos obtener un portafolio libre de riesgo:
 1 Si ρ = −1, tenemos:
 σp2 = (wA σA − (1 − wA )σB ))2
 • Resolviendo para σA :
 σB
 wPMVA =
 σA + σB
 25 / 68

[pág. 29]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
n Activos Riesgosos
n Activos Riesgosos
 • ¿Qué pasa si agregamos un tercer activo riesgoso?
 26 / 68

[pág. 30]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
n Activos Riesgosos
n Activos Riesgosos
Derivación Gráfica
 Figura: Conjunto de portafolios de mı́nima varianza: mı́n σp dado E(RP )
 27 / 68

[pág. 31]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
n Activos Riesgosos
n Activos Riesgosos
Derivación Gráfica
 Figura: Conjunto de portafolios de mı́nima varianza: mı́n σp dado E(RP )
 28 / 68

[pág. 32]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
n Activos Riesgosos
n Activos Riesgosos
Derivación Gráfica
 Figura: Conjunto de portafolios eficientes: aparte de ser de mı́nima varianza,
 máx E(Rp ) sujeto a un valor σp dado.
 29 / 68

[pág. 33]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
n Activos Riesgosos
n Activos Riesgosos
 • Con varios activos riesgosos la forma de la frontera de mı́nima varianza
 sigue siendo una hipérbola como en el caso con dos activos riesgos.
 • Pero en este caso los activos individuales ya no son parte de la frontera de
 mı́nima varianza.
 • Sólo portafolios optimizados usando la información de la distribución de
 probabilidad de los retoros (varianzas, covarianzas y retorno), estarán
 sobre la frontera.
 30 / 68

[pág. 34]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
n Activos Riesgosos
n Activos Riesgosos
Intuición
 • Selección de portfolios sigue mismo proceso “intuitivo”
 • Descartar portfolios “interiores”
 • Seleccionar portafolio de mayor retorno si hay más de uno con igual σ
 • Obtenemos frontera eficiente
 • Observaciones
 1 Agregar activos mueve la frontera hacia arriba y la izquierda
 31 / 68

[pág. 35]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
n Activos Riesgosos
n Activos Riesgosos
Problema Formal
 • Harry Markowitz, premio Nobel de economı́a en el año 1990 desarrolla una
 teorı́a de selección de carteras para resolver este problema
 • Estudia los efectos del riesgo, retorno, diversificación y correlación entre
 los activos de un portfolio para encontrar una serie de carteras de mı́nima
 volatilidad a las que llama “eficientes”
 32 / 68

[pág. 36]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
n Activos Riesgosos
n Activos Riesgosos
Problema Formal
 • Matemáticamente
 n n
 mı́n
 n
 σp2 = ∑ ωi2 σi2 + ∑ ∑ ωi ωj σij
 { ωi } i=1 i=1 i=1 j̸ =i
 n
 Sujeto a E(Rp ) = ∑ ωi E(Ri ) ≥ R∗
 i=1
 • ¿Cuántas variables de decisión hay en este problema?
 • En la práctica:
 • Usar Solver en Excel u otro programa con métodos numéricos
 • Usar matrices
 33 / 68

[pág. 37]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Resumen
Resumen
 • Concepto de diversificación: Si ρ < 1
 1 Reduce riesgo
 2 Pero esto tiene un lı́mite –no todo riesgo es eliminable con diversificación:
 riesgo sistemático y no sistemático
 • Selección de portafolios: riesgo-retorno
 1 Frontera de mı́nima varianza y frontera eficiente
 34 / 68

[pág. 38]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Portafolio con Activo Libre de Riesgo
 • Ahora vamos a introducir un activo libre de riesgo (σf = 0).
 • Queremos determinar cuánto invertir en el activo libre de riesgo, en otras
 palabras, cuánto riesgo tomar.
 • Llamemos E(R1 ) y E(Rf ) al retorno esperado del activo riesgoso y libre de
 riesgo respectivamente.
 • El retorno esperado del portafolio está dado por:
 E(Rp ) = ω1 E(R1 ) + (1 − ω1 )Rf
 • Podemos reescribir esta expresión como:
  
 E(Rp ) = Rf + ω1 E(R1 ) − Rf (1)
 | {z }
 Premio por riesgo de 1
 35 / 68

[pág. 39]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Portafolio con Activo Libre de Riesgo
 • La varianza del portafolio está dado por:
 σp2 = ω12 σ12
 • Y la desviación estándar:
 σp = ω1 σ1
 • Podemos despejar el ponderador del activo riesgoso: ω1 = σσp
 1
 • Reemplazando en nuestra ecuación (1) y reordenando:
 !
 E(R1 ) − Rf
 E ( Rp ) = Rf + σp
 σ1
 • Notar que el retorno esperado del portafolio es una función lineal de su
 volatilidad.
 • Esta ecuación se conoce como Capital Allocation Line (CAL)
 36 / 68

[pág. 40]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Capital Allocation Line
 37 / 68

[pág. 41]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Capital Allocation Line
 • Notar que en nuestro ejemplo actual de un activo riesgoso y un activo libre
 de riesgo, todas las combinaciones posibles tienen el mismo Sharpe ratio,
 que es igual al Sharpe ratio del activo riesgoso
 • Pero si agregamos más activos riesgosos, podemos buscar una
 combinación de éstos que nos entregue un mejor Sharpe ratio, es decir,
 una mejor relación riesgo retorno.
 38 / 68

[pág. 42]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
N Activos Riesgosos y Activo Libre de Riesgo
 • Ahora vamos tras la pregunta de cuál es el portafolio óptimo.
 • La idea es que vamos a mezclar un portafolio de activos riesgos con el
 activo libre de riesgo
 • ¿Pero cuál?
 • Vuelta al concepto: frontera eficiente implica max retorno dada una
 volatilidad.
 • Primer paso: sabemos que ALR + 1 activo riesgoso nos da una lı́nea recta.
 • Pensemos en el caso de 2 activos, 1 y 2, con ρ1,2 < 1
 • Agreguemos un ALR =⇒ ¿cómo mezclarlos?
 39 / 68

[pág. 43]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
2 Activos Riesgosos y Activo Libre de Riesgo
 • Combinamos con activo libre de riesgo, con RALR = 5 %
 • Combinemos ALR con el portafolio de mı́nima varianza (PMV).
 • wALR > 0 reduce riesgo, pero también retorno esperado.
 • wALR < 0 (leverage) incrementa riesgo y retorno esperado.
 40 / 68

[pág. 44]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
2 Activos Riesgosos y Activo Libre de Riesgo
 • Hay un único portafolio óptimo
 • Está en la lı́nea tangente a la frontera eficiente.
 • Este Portafolio Tangente es óptimo independiente de las preferencias por
 riesgo.
 41 / 68

[pág. 45]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
2 Activos Riesgosos y Activo Libre de Riesgo
 • El portafolio óptimo es aquél con la mayor pendiente, o Sharpe ratio:
 E(Rp ) − Rf Exceso de retorno esperado
 Sp = =
 σp Volatilidad
 42 / 68

[pág. 46]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
N Activos Riesgosos y Activo Libre de Riesgo
 • Al agregar más activos riesgos la frontera eficiente mejora.
 43 / 68

[pág. 47]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Elección del Portafolio Óptimo
 • Concluimos que el portafolio óptimo de activos riesgosos era el portafolio
 tangente.
 • ¿Cómo elegimos activos para formar el portafolio tangente?
 • Para responder esta pregunta analizamos la condición de primer orden
 para cada i = 1, ..., n:
 ∂E(Rp )  ∂σp
 E(Rp ) − Rf
 ! σp − E(Rp ) − Rf
 ∂Sp ∂ ∂ωi ∂ωi
 = = =0
 ∂ωi ∂ωi σp σp2
 Reordenando:
 ∂E(Rp )
  
 ∂ω E(Rp ) − Rf
  i =
 ∂σp σp
 | {z }
 ∂ωi
 Sp
 44 / 68

[pág. 48]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Elección del Portafolio Óptimo
 • ¿Cómo cambia E(Rp ) si cambiamos ωi marginalmente (invertimos un
 poco más en activo i)?
 ∂E(Rp )
 −→ Calcular ∂ωi
 • Notemos primero que para cualquier portafolio:
 n
 E(Rp ) =Rf + ∑ ωk (E(Rk ) − Rf )
 k =1
 • Ejemplo 3 acciones:
 n
 E ( Rp ) = Rf + ∑ ωk (E(Rk ) − Rf )
 k =1
 = Rf + ω1 (E(R1 ) − Rf ) + ω2 (E(R2 ) − Rf ) + ω3 (E(R3 ) − Rf )
 • Entonces
 ∂E(Rp )
 = E(Ri ) − Rf
 ∂ωi
 45 / 68

[pág. 49]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Elección del Portafolio Óptimo
 • La varianza del portafolio es:
 n n
 σp2 = ∑ ωk2 σk2 + ∑ ∑ ωk ωj σkj
 k =1 k =1 j̸ =k
 • ¿Cómo cambia σp si cambiamos ωi marginalmente?
 ∂σ
 −→ Calcular ∂ωpi
 46 / 68

[pág. 50]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Elección del Portafolio Óptimo Derivación
 • Usando regla de la cadena se obtiene
 ∂σp2 ∂σp2 ∂σp ∂σp ∂σp 1 ∂σp
 2
 = = 2σp ⇒ =
 ∂ωi ∂σp ∂ωi ∂ωi ∂ωi 2σp ∂ωi
 • Derivando la varianza, ejemplo 3 acciones
 3 3
 σp2 = ∑ ωk2 σk2 + ∑ ∑ ωk ωj σkj
 k =1 k =1 j̸ =k
 = w21 σ12 + w22 σ22 + w23 σ32 + 2w1 w2 σ1,2
 + 2w1 w3 σ1,3 + 2w2 w3 σ2,3
 ∂σp2 n
 = 2ω2 σ22 + 2w1 σ1,2 + 2w3 σ2,3 = 2 ∑ ωj σ2,j
 ∂ω2 j=1
 = 2Cov(R2 , Rp ) = 2σ2,p
 47 / 68

[pág. 51]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Elección del Portafolio Óptimo Derivación
Revisar en la casa
 • Derivando la varianza caso general:
 n n
 σp2 = ∑ ωk2 σk2 + ∑ ∑ ωk ωj σkj
 k =1 k =1 j̸ =k
 ∂σp2
 = 2ωi σi2 + 2 ∑ ωj σij
 ∂ωi j̸ =i
 n
 = 2 ∑ ωj σij
 j=1
 = 2Cov(Ri , Rp ) = 2σi,p
 48 / 68

[pág. 52]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Elección del Portafolio Óptimo Derivación
Revisar en la casa
 • Finalmente tenemos:
 2
 ∂σp 1 ∂σp
 =
 ∂ωi 2σp ∂ωi
 ∂σp2
 = 2σi,p
 ∂ωi
 • Llegando a:
 2
 ∂σp 1 ∂σp 1 σi,p ρip σi σp
 = = 2σ = = = ρip σi
 ∂ωi 2σp ∂ωi 2σp i,p σp σp
 49 / 68

[pág. 53]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Portafolio Óptimo y Retorno Requerido
 • Tenı́amos
 ∂E(Rp )
 ∂ωi E(Rp ) − Rf
 =
 ∂σp σp
 | {z }
 ∂ωi
 Sp
 E(Ri ) − Rf E ( Rp ) − Rf
 • Reemplazando =
 ρip σi σp
 • Reordenamos esta fórmula:
 σi
 E(Ri ) = Rf + ρip × (E(Rp ) − Rf )
 σp
 • Como es la condición de primer orden del ratio de sharpe, esto es válido
 sólo para el portafolio tangente!
 50 / 68

[pág. 54]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Activos Individuales y Portafolio Tangente
 • Hemos encontrado una expresión para el premio por riesgo que demandará
 un inversionista por poseer un activo:
 σi
 E(Ri ) = Rf + ρiT × × ( E ( RT ) − Rf )
 |{z} |{z} σT | {z }
 Fracción del
 |{z}
 Tasa Premio por
 libre de riesgo que Riesgo riesgo
 riesgo es común relativo portafolio T
 de i
 | {z }
 β iT
 | {z }
 Premio por riesgo activo i
 • El riesgo está medido por beta:
 σi
 β i,T = ρi,T ×
 σT
 51 / 68

[pág. 55]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Ejercicio 1a
 Pregunta
 • Suponga que su suegro lo llama para pedirle consejo sobre sus inversiones.
 Él actualmente tiene $100.000 invertidos en una portfolio con un retorno
 esperado de 10.5 % y volatilidad de 8 %.
 • Suponga que la tasa libre de riesgo es 5 % y que la cartera tangente tiene
 un rendimiento esperado de 18.5 % y volatilidad de 13 %.
 (a) ¿ Cuál cartera le recomendarı́a a su suegro para maximizar el retorno
 esperado sin aumentar el riesgo?
 1 100 % en portafolio tangente y 0 % en ALR.
 2 61,5 % en portafolio tangente y 38,5 % en ALR.
 3 78.4 % en portafolio tangente y 21,6 % en ALR.
 4 Su portafolio ya es óptimo, no puede mejorar su relación riesgo retorno.
 5 No sé como resolver la pregunta
 52 / 68

[pág. 56]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio riesgosos y ALR
Ejercicio 1b
 Pregunta
 • Suponga que su suegro lo llama para pedirle consejo sobre sus inversiones.
 Él actualmente tiene $100.000 invertidos en una portfolio con un retorno
 esperado de 10.5 % y volatilidad de 8 %.
 • Suponga que la tasa libre de riesgo es 5 % y que la cartera tangente tiene
 un rendimiento esperado de 18.5 % y volatilidad de 13 %.
 (b) ¿ Cuál cartera le recomendarı́a a su suegro para minimizar el riesgo
 manteniendo su retorno esperado?
 1 0 % en portafolio tangente y 100 % en ALR.
 2 40,7 % en portafolio tangente y 59,3 % en ALR.
 3 27.1 % en portafolio tangente y 72.9 % en ALR.
 4 Es imposible disminuir el riesgo, manteniendo el mismo retorno esperado.
 5 No sé como resolver la pregunta
 53 / 68

[pág. 57]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Decisión Individual y Análisis MV
 • Hasta ahora: preferencias media-varianza nos llevaron al portafolio
 tangente:
 • Tiene el máximo Sharpe ratio, para cada volatilidad nos da el retorno
 máximo posible que puede obtener un inversionista.
 • Pero depende sólo de las combinaciones de retornos esperados y
 varianzas-covarianzas, no de la aversión al riesgo.
 • Nivel de aversión al riesgo no afecta portafolio de activos riesgosos.
 • Aún no hemos definido exactamente el rol que juegan las preferencias
 individuales, en particular el grado de aversión al riesgo.
 54 / 68

[pág. 58]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio óptimo -Teorema del Fondo Mutuo
 • Si asumimos que:
 1 Todos los inversionistas tienen preferencias media-varianza.
 2 Todos están de acuerdo en los mismos retornos esperados y varianzas
 3 Todos tienen acceso a los mismos activos y tasa libre de riesgo
 4 Mercado de un perı́odo
 • Entonces: Teorema del Fondo Mutuo
 • Todos los inversionistas tienen portafolios que son combinaciones del activo
 libre de riesgo y del portafolio tangente (que es el mismo para todos).
 • Aversión al riesgo sólo afecta cuanto se invierte en el activo libre de riesgo (más
 mientras más averso).
 • Implicancia: todos los inversionistas mantienen activos riesgosos en la misma
 proporción.
 55 / 68

[pág. 59]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio Óptimo - Vuelta a Función de Utilidad
 • Recordemos que hemos aproximado la función de utilidad de los
 inversionistas sobre un portafolio por:
 1
 E(Rp ) − (RRA)σp2
 2
 56 / 68

[pág. 60]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio óptimo - Solución Gráfica
 57 / 68

[pág. 61]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Portafolio Óptimo - Solución Análitica
 • Para cada inversionista podemos encontrar sus ponderadores óptimos en el
 portafolio tangente (T) y en el activo libre de riesgo (ALR):
 1
 máx E(Rp ) − (RRA)σp2
 wT 2
 1
 = Rf + wT (E(RT ) − Rf ) − (RRA)w2T σT2
 2
 • La condición de primer orden es:
 E(RT ) − Rf − RRA × wT σT2 = 0
 • Resolviendo para el ponderador del portafolio tangente:
 RT − Rf ST
 wT = =
 RRA × σT2 RRA × σT
 58 / 68

[pág. 62]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Teorema del Fondo Mutuo - Ejemplo
 • Volvamos a nuestros activos A y B.
 • E[RA ] = 30 % y σA = 0,2
 • E[RB ] = 10 % y σB = 0,1
 • Suponga que la tasa libre de riesgo es 5 %
 • Habı́amos encontrado que el portafolio tangente se construı́a con
 wA = 62 % y wB = 38 %
 • E(RT ) = 22,4 %.
 • σT = 13,33 %.
 • Supongamos 2 inversionistas, cada uno tiene $100k para invertir, pero
 diferentes grados de aversión al riesgo:
 Inv. 1 RRA=19.59
 Inv. 2 RRA=4.90
 • Encuentre los montos invertidos por cada inversionista en cada activo (A,
 B, y ALR)
 59 / 68

[pág. 63]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Teorema del Fondo Mutuo - Ejemplo
 Hab’iamos encontrado:
 60 / 68

[pág. 64]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Teorema del Fondo Mutuo - Ejemplo
 Clickers - 5 opciones
 • Antes de resolver, intuitivamente, qué espera usted?
 1 Inv. 2 con RRA=4.90 invertirá un % mayor de su portafolio de acciones en
 la acción más riesgosa A
 2 Inv. 2 con RRA=4.90 invertirá un % mayor de su portafolio de acciones en
 la acción menos riesgosa B
 3 Inv. 2 con RRA=4.90 invertirá un % mayor en acciones y un % mayor que
 Inv. 1 de su portafolio de acciones en la acción más riesgosa A.
 4 Inv. 2 con RRA=4.90 invertirá un % mayor en acciones y un % igual a Inv. 1
 de su portafolio de acciones en la acción más riesgosa A.
 5 No sé como resolver la pregunta
 61 / 68

[pág. 65]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Teorema del Fondo Mutuo - Ejemplo
 • Por Teorema del Fondo Mutuo ambos van a invertir en el mismo
 portafolio de activos riesgosos (portafolio tangente).
 • Necesitamos determinar cuánto invertirá cada uno en el portafolio
 tangente (T) y en el activo libre de riesgo (ALR).
 • Sea wTi el ponderador en el portafolio tangente para el individuo i:
 Inv. 1 Tiene RRA=19,59:
 RT − Rf 0, 224 − 0, 05
 wT1 = = = 0,5
 RRA × σT2 19,59 × 0, 13332
 Inv. 1 invertir’a 50 % en activos riesgosos.
 Inv. 2 Tiene RRA=4,9:
 RT − Rf 0, 224 − 0, 05
 wT2 = = =2
 RRA × σT2 4, 9 × 0, 13332
 Inv. 2 invertir’a 200 % en activos riesgosos.
 62 / 68

[pág. 66]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Teorema del Fondo Mutuo - Ejemplo
 • Por Teorema del Fondo Mutuo ambos van a invertir en el mismo
 portafolio de activos riesgosos (portafolio tangente).
 Inv. 1 Invertir’a 50 % en activos riesgosos, por lo tanto:
 • wALR = 50 % ⇒ $50k en activo ALR.
 • wA1 = 50 % × 62 % = 31 % ⇒ $31k en activo A.
 • wB1 = 50 % × 38 % = 19 % ⇒ $19k en activo B.
 Inv. 2 Invertir’a 200 % en activos riesgosos, por lo tanto:
 • wALR = −100 % ⇒ Se endeudar’a por $100k.
 • wA2 = 200 % × 62 % = 124 % ⇒ $124k en activo A.
 • wB2 = 200 % × 38 % = 76 % ⇒ $76k en activo B.
 63 / 68

[pág. 67]
Repaso Diversificación Portafolios Riesgosos y Portafolios Eficientes Decisión Individual
Teorema del Fondo Mutuo - Ejemplo
 64 / 68

[pág. 68]
Repaso Media y Varianza
Media y Varianza
Repaso
 • Primero, revisión de un par de conceptos
 • Cuando tenemos una variable que puede tomar distintos valores (una
 variable aleatoria) podemos calcular una serie de medidas (momentos)
 • Por ahora nos enfocaremos en dos: esperanza o media, y varianza (y la
 desviación estándar)
 • La media o esperanza de una variable X se define como
 n
 E(X) = ∑ pi xi (9)
 i=1
 • Mientras que la varianza y la desviación estándar se definen como:
 n
 V (X) = ∑ pi (xi − E(X))2 (10)
 i=1
 q
 σX = V (X ) (11)
 • pi es la probabilidad de observar el valor xi
 65 / 68

[pág. 69]
Repaso Media y Varianza
Media y Varianza
Repaso
 • Práctica: muchas veces observamos series ex-post =⇒ observamos
 realizaciones
 • Podemos calcular esperanzas y varianzas muestrales con los datos
 observados
 • Media
 ∑ni=1 xi
 X̄ = (12)
 n
 • Varianza
 ∑ni=1 (xi − X̄)2
 V (X ) = (13)
 n−1
 q
 σX = V (X) (14)
 66 / 68

[pág. 70]
Repaso Media y Varianza
Media y Varianza
Ejemplo
 • Consideremos una activo que tiene los siguientes retornos
 Escenario Bueno Regular Malo
 Probabilidad 0.1 0.7 0.2
 Retorno (en %) 20 5 -5
 • Media
 E(X) =0,1 × 20 + 0,7 × 5 + 0,2 × −5
 =4,5
 67 / 68

[pág. 71]
Repaso Media y Varianza
Media y Varianza
Ejemplo
 • Varianza
 V (X) =0,1 × (20 − 4,5)2 + 0,7 × (5 − 4,5)2 + 0,2 × (−5 − 4,5)2
 =42,25
 • Desviación estándar
 √
 σX = 42,25 = 6,5
 68 / 68

# Teoría Financiera · L2 Arbitraje y Derivados

Fuente: clase de Teoría Financiera

[pág. 1]
Temario Arbitraje LOOP Derivados
 Teorı́a Financiera
 Arbitraje y Derivados
 Consuelo Silva
 Escuela de Administración PUC
 19 de marzo de 2024
 1 / 58

[pág. 2]
Temario Arbitraje LOOP Derivados
Objetivos clase
 1 Entender el concepto de arbitraje y ley de un solo precio en finanzas
 2 Entender las estrategias de inversión a seguir cuando no se cumple la
 ausencia de arbitraje
 2 / 58

[pág. 3]
Temario Arbitraje LOOP Derivados
Temario
 1 Arbitraje
 2 LOOP
 3 Derivados
 Forwards y Futuros
 Opciones
 Paridad Put-Call
 Modelo Binomial
 Black-Scholes
 Lecturas: BKM caps. 20.1-20.5, 21.1-21.3, 22, 23.1.
 3 / 58

[pág. 4]
Temario Arbitraje LOOP Derivados
Definición de Arbitraje
 Arbitraje, un concepto clave para las finanzas.
 • La idea es que sabiendo el precio de algunos activos, vamos a usar
 argumentos de (ausencia de) arbitraje para encontrar el precio relativo de
 otros activos.
 4 / 58

[pág. 5]
Temario Arbitraje LOOP Derivados
Definición de Arbitraje
 • Una oportunidad de arbitraje consiste en la posibilidad de hacer una
 ganancia sin correr riesgo
 • Especı́ficamente:
 • Muy importante: “sin correr riesgo”: en ninguna circunstancia debe existir
 pérdida.
 • La ganancia no necesita ser inmediata (puede darse hoy o bajo alguna
 eventualidad futura.)
 • La ganancia puede ser variable (incluyendo no ganar nada).
 • Al realizar arbitraje lo que hacemos es construir portafolios que entreguen
 los mismos pagos (Replicación).
 • “Comprar barato y vender caro”
 5 / 58

[pág. 6]
Temario Arbitraje LOOP Derivados
Definición de Arbitraje
 • Una oportunidad de arbitraje consiste en la posibilidad de hacer una
 ganancia sin correr riesgo
 • Especı́ficamente:
 • Muy importante: “sin correr riesgo”: en ninguna circunstancia debe existir
 pérdida.
 • La ganancia no necesita ser inmediata (puede darse hoy o bajo alguna
 eventualidad futura.)
 • La ganancia puede ser variable (incluyendo no ganar nada).
 • Al realizar arbitraje lo que hacemos es construir portafolios que entreguen
 los mismos pagos (Replicación).
 • “Comprar barato y vender caro”
 5 / 58

[pág. 7]
Temario Arbitraje LOOP Derivados
Ejemplo Simple de Arbitraje
 • Suponga que existen dos empresas A y B, cuyo precio por acción hoy es $4
 y $6 respectivamente.
 • Suponga que usted puede comprar un activo financiero (fondo “Ganador”)
 que promete en un año más un pago igual al valor de un portafolio que
 tiene 1 acción de A y 2 de B.
 • Suponga que el valor del fondo “Ganador” hoy es de $13.
 • Pregunta:Cómo podrı́a usted aprovechar esta oportunidad de arbitraje?
 A Hoy: Vender 1 acción de A y dos de B y comprar el fondo Ganador.
 B Hoy: Vender 1 acción de B y dos de A y comprar el fondo Ganador.
 C Hoy: Vender el fondo Ganador y comprar 1 acción de A y dos de B.
 D Hoy: Vender el fondo Ganador y comprar 1 acción de B y dos de A.
 E No sé
 Concepto venta corta
 6 / 58

[pág. 8]
Temario Arbitraje LOOP Derivados
Arbitraje
 • ¿Cómo usamos el concepto de arbitraje?
 • Si oportunidades de arbitraje son fáciles de ejecutar ⇒ desaparecen
 • Entonces podemos usar la ausencia de oportunidades de arbitraje para
 valorar activos
 • Intuitivamente: si podemos “copiar” un activo, “en equilibrio” el valor debe
 ser el mismo
 7 / 58

[pág. 9]
Temario Arbitraje LOOP Derivados
Ley de un solo precio (Law of One Price, LOOP)
 • Si no existen oportunidades de arbitraje entonces:
 Si dos o más activos entregan el mismo flujo, entonces deben tener el
 mismo precio.
 • También conocida como la teorı́a de la cajita feliz (Cochrane):
 El precio de una cajita feliz (en ausencia de fricciones) debe ser el mismo
 que la suma de los precios de las papas fritas, hamburguesa, bebida y
 juguete.
 8 / 58

[pág. 10]
Temario Arbitraje LOOP Derivados
Activos Derivados
 • Activos derivados: son los activos cuyo precio depende del precio de otro
 activo, que se denomina activo subyacente.
 • No entregan propiedad ni derechos de control.
 • Un derivado es simplemente un contrato entre un comprador y un vendedor
 (suma cero).
 9 / 58

[pág. 11]
Temario Arbitraje LOOP Derivados
Activos Derivados
 • Dos tipos principales de derivados:
 • Contratos que fijan un precio: Permite fijar hoy un precio (o tasa) en el
 futuro. Ejemplo
 • Forward: compromiso hoy de ejecutar una cierta transacción en el futuro
 • Futuros: contratos estandarizados y formalizados, transados en mercados
 financieros
 • Contratos que “protegen“ el precio: Funcionan como un seguro frente a
 caı́das (o subidas) del precio (o tasa). Ejemplo:
 • Opciones (put, call): entregan la opción de comprar o vender un activo a un
 determinado precio
 10 / 58

[pág. 12]
Temario Arbitraje LOOP Derivados
Activos Derivados
 • Warren Buffet en su carta anual a los inversionistas de Berkshire
 Hathaway en 2002:
 We view them as time bombs, both for the parties that deal in them and the
 economic system [...] The derivatives genie is now well out of the bottle, and
 these instruments will almost certainly multiply in variety and number until
 some event makes their toxicity clear [...] In our view, however, derivatives are
 financial weapons of mass destruction, carrying dangers that, while now latent,
 are potentially lethal.
 11 / 58

[pág. 13]
Temario Arbitraje LOOP Derivados
Activos Derivados
 • En Chile también existe polémica (EMOL 01 junio, 2014)
 12 / 58

[pág. 14]
Temario Arbitraje LOOP Derivados
Activos Derivados
 • Por otro lado (Pérez-González y Yun, 2013):
 [W]e exploit the introduction of weather derivatives as a natural experiment.
 Weather derivatives are financial contracts whose payoffs are contingent on
 weather conditions [...] we show that weather derivatives lead to an
 economically large and statistically robust increase in firm value [...]
 hedging leads to an increase in M-B ratios of at least 6 %.
 13 / 58

[pág. 15]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Forwards
Definiciones
 Principales caracterı́sticas:
 • Dos partes acuerdan intercambiar un ı́tem en el futuro (commodity,
 moneda, acciones) a un precio especificado hoy: el precio forward.
 • El precio para entrega inmediata del ı́tem es el precio spot.
 • No hay intercambio de dinero en el presente.
 • El valor de carátula del contrato es la cantidad de ı́tem a ser
 intercambiado multiplicado por el precio forward.
 • Parte compradora: toma una posición larga. Parte vendedora: toma una
 posición corta.
 14 / 58

[pág. 16]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Forwards
Posición corta y posición larga
 El comprador (posición larga) del forward debe:
 • Aceptar el ı́tem en la fecha de maduración.
 • Pagar el precio acordado al momento de maduración.
 El vendedor (posición corta) del forward debe:
 • Entregar el ı́tem en la fecha de maduración.
 • Aceptar el precio acordado al momento de maduración.
 15 / 58

[pág. 17]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Forwards
Ejemplo
 • Suponga que Tata Coffee Ltd. cosechará su siembra de café en un mes
 más.
 • Suponga que Starbucks sabe que necesitará comprar su principal insumo,
 café, en un mes más.
 • Ambos están expuestos al riesgo de variaciones en el precio del commodity
 (commodity risk).
 • Este riesgo se puede eliminar firmando un contrato de compra-venta de
 café a un precio especificado hoy.
 16 / 58

[pág. 18]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Forwards
Ejemplo
 “Starbucks hedges arabica coffee through price-to-be-fixed green coffee
 contracts. As of September 30, 2012, Starbucks had committed to purchasing
 green coffee totaling $557 million under fixed-price contracts...” (Streetinsider,
 December 2012)
 17 / 58

[pág. 19]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Futuros
Definiciones
 • Un futuro es un forward estandarizado transado en la bolsa de comercio.
 • La bolsa especifica el ı́tem, tamaño de contrato, lugar y fecha de entrega
 del ı́tem.
 • Las transacciones se realizan por medio de la bolsa, una contraparte
 central transfiere los pagos de una parte a la otra.
 18 / 58

[pág. 20]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Futuros
Definiciones
 • Future Price: Precio de intercambio futuro acordado en el contrato.
 • Margin requirement: colateral exigido al momento de contratar el futuro.
 • Settlement Price: Precio futuro al final del dı́a.
 • Open Interest: Número de contratos abiertos al final del dı́a.
 19 / 58

[pág. 21]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Futuro
Futuros: London Metal Exchange
 Fuente: London Metal Exchange. Valores para Noviembre 26, 2014
 20 / 58

[pág. 22]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Futuros
Cómo funciona en la práctica?
 • Suponga usted toma una posición larga en un futuro a Enero el Noviembre
 25, 2013. El corredor le exigirá una cantidad $x como colateral (margin
 requirement).
 • En Noviembre 26, el precio cayó en $ − 0, 41. Usted perdió $410 (1000
 barriles). Esta cantidad es transferida a la cuenta de quienes han tomado
 una posición corta en este contrato.
 • Este proceso se repite sucesivamente hasta la fecha de vencimiento del
 contrato, i.e., en Enero.
 • En cada perı́odo la ganancia es Ft − Ft−1
 • Al vencimiento T (Enero) FT = ST (donde ST es el precio del activo
 subyacente en T)
 • Ganancia al vencimiento: ST − F0
 21 / 58

[pág. 23]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Forwards - Gráfico Flujos al Vencimiento
 • Supongamos que hoy vence un contrato Forward en que nos
 comprometimos a comprar una acción de Amazon por $50.
 • Pregunta: ¿Cuáles son los flujos al vencimiento de esta posición si el
 precio de la acción de Amazon es (i) $25 y (ii) $60?
 A (i) $25 y (ii) $60
 B (i) -$25 y (ii) $60
 C (i) $25 y (ii) -$10
 D (i) -$25 y (ii) $10
 E No sé como calcularlo
 22 / 58

[pág. 24]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Forwards - Gráfico Flujos al Vencimiento
 • Supongamos que hoy vence un contrato Forward en que nos
 comprometimos a comprar una acción de Amazon por $50.
 • Los flujos al vencimiento (tiempo T) del contrato Forward serán:
 23 / 58

[pág. 25]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Forward - Posición Corta
 Pregunta: Cómo son los flujos al vencimiento (T) para una posición corta
 (comprometido a vender) como función del precio del activo subyacente?
 24 / 58

[pág. 26]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Futuros
Precio del futuro
 Supongamos que se necesita obtener un activo (stock, S) en una fecha
 determinada en el futuro. Hay dos formas de realizarlo:
 • Comprar el activo ahora y guardarlo hasta la fecha objetivo
 • Adoptar una posición larga de futuros
 • Cada estrategia debe tener un resultado equivalente.
 Cuál es el precio del futuro? Lo encontramos usando el concepto de arbitraje.
 25 / 58

[pág. 27]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Futuros
Precio del futuro
 Estrategia Posición FC t = 0 FC t = T
 Estrategia A Comprar Activo −S0 ST
 Estrategia B Posición larga futuro 0 ST − F0
 −F0
 Invertir F0 /(1 + r)T a tasa LR (1+r)T
 F0
 −F0
 Total para B (1+r)T
 ST
 F0 /(1 + r)T =S0
 F0 =S0 (1 + r)T
 26 / 58

[pág. 28]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Futuros
Ejercicio en clase
 1 Suponga que el oro de vende actualmente a $280 la onza. Si la tasa de
 interés libre de riesgo es del 0.5 % mensual, cuál debiese ser el precio de un
 contrato de futuros a 6 meses?
 2 Suponga que el precio spot del oro es de $280 la onza, la tasa de interés
 es de 0.5 % mensual y el precio futuro del contrato a 6 mese es de $288.
 Cómo podrı́a aprovechar la oportunidad de arbitraje?
 27 / 58

[pág. 29]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Contratos forward y futuros sobre divisas
 • Suponga que Ud. tiene 1 USD ahorrado, pero que en un año más necesita
 tener pesos. ¿Qué puede hacer?
 1 Vender hoy el dolar que tiene ahorrado. Por ello, Ud. recibe S pesos, los
 cuales son depositados a una tasa de interés libre de riesgo en pesos, la que
 denominamos Rclp .
 2 Depositar el dólar hoy a un año, a una tasa de interés libre de riesgo en
 dolares Rusd . En un año más, vender los dólares a un precio forward fijado
 hoy el que denominamos F.
 28 / 58

[pág. 30]
Temario Arbitraje LOOP Derivados
Forwards y Futuros
Contratos forward y futuros sobre divisas
 • Ambas estrategias parten con 1 USD y terminan con pesos en un año más:
 • Flujo final estrategia 1: S × (1 + Rclp )
 • Flujo final estrategia 2: F × (1 + RUSD )
 • En ausencia de arbitraje, ambos flujos deben ser iguales:
 S × (1 + Rclp ) = F × (1 + RUSD )
 • Ası́, el precio Forward F (divisas) queda:
 1 + Rclp
 F=S
 1 + RUSD
 29 / 58

[pág. 31]
Temario Arbitraje LOOP Derivados
Opciones
Opciones
Definiciones
 • Las opciones se denominan “call” o “put” dependiendo de si dan derecho
 a vender o comprar
 • Opción put: derecho a vender a un precio determinado (precio de ejercicio
 o strike price)
 • Opción call: derecho a comprar . . .
 • Las opciones también especifican una fecha para el ejercicio
 • Opciones europeas: fecha pre-determinada especifica exactamente cuando
 puede ser ejercida
 • Opciones americanas: fecha especifica el perı́odo en el cual pueden ser
 ejercidas
 • Relación a precio de ejercicio
 • In the money: ejercerlas da un beneficio
 • Out of the money: lo contrario
 30 / 58

[pág. 32]
Temario Arbitraje LOOP Derivados
Opciones
Ejemplo Call Option
 Pregunta:
 Sólo por hoy tenemos la opción de comprar una acción de Amazon por $50
 (call option). Qué hacer si el precio de la acción es:
 $40:
 A) Ejerzo la opción y obtengo una ganancia de $40
 B) Ejerzo la opción y obtengo una ganancia de $10
 C) Ejerzo la opción y obtengo una pérdida de $-10
 D) No ejerzo la opción y obtengo una pérdida de $-10
 E) No ejerzo la opción y obtengo un flujo de $0
 F) No sé
 31 / 58

[pág. 33]
Temario Arbitraje LOOP Derivados
Opciones
Ejemplo Call Option
 Ejemplo:
 Sólo por hoy tenemos la opción de comprar una acción de Amazon por $50
 (call option). Qué hacer si el precio de la acción es:
 $40:
 • Podemos comprar en el mercado por $40 o usar nuestra opción para
 comprar una acción por $50.
 • Mejor comprar la acción directamente en el mercado, por lo que no
 usamos nuestra opción y ésta expira.
 • ¿Cuál es el pago de nuestra call option? ⇒ No ejercemos la opción por lo
 que no hay pagos:
 • Entonces, Pago = $0
 32 / 58

[pág. 34]
Temario Arbitraje LOOP Derivados
Opciones
Ejemplo Call Option
 Ejemplo:
 Sólo por hoy usted tiene la opción de comprar una acción de Amazon por $50
 (call option). Qué hacer si el precio de la acción es:
 $60:
 • Podemos comprar en el mercado por $60 o usar nuestra opción para
 comprar una acción por $50.
 • Mejor usar la opción y pagar sólo $50 para obtener la acción.
 • ¿Cuál es el pago de nuestra call option?
 • Ejercemos la opción y pagamos el precio de ejercicio de $50.
 • Después vamos al mercado y vendemos la acción por $60.
 • Entonces obtenemos un pago (sin riesgo) de $10.
 • Entonces, Pago = $10
 33 / 58

[pág. 35]
Temario Arbitraje LOOP Derivados
Opciones
Ejemplo Put Option
 Pregunta:
 Sólo por hoy tenemos la opción de vender una acción de Amazon por $50 (put
 option). Qué hacer si el precio de la acción es:
 $40:
 A Ejerzo la opción y obtengo una ganancia de $40
 B Ejerzo la opción y obtengo una ganancia de $10
 C Ejerzo la opción y obtengo una pérdida de $-10
 D No ejerzo la opción y obtengo una pérdida de $-10
 E No ejerzo la opción y obtengo un flujo de $0
 F No sé
 34 / 58

[pág. 36]
Temario Arbitraje LOOP Derivados
Opciones
Ejemplo Put Option
 Ejemplo:
 Sólo por hoy tenemos la opción de vender una acción de Amazon por $50 (put
 option). Qué hacer si el precio de la acción es:
 $40:
 • Si tuviéramos una acción la podrı́amos vender en el mercado por $40 o
 usar nuestra opción y venderla por $50.
 • Serı́a mejor usar la opción y recibir $50.
 • ¿Cuál es el pago de nuestra put option?
 • Vamos al mercado y compramos una acción por $40.
 • Inmediatamente ejercemos nuestra put option y vendemos esta acción por
 $50.
 • Entonces obtenemos un pago (sin riesgo) de $10.
 • Entonces, Pago = $10
 35 / 58

[pág. 37]
Temario Arbitraje LOOP Derivados
Opciones
Ejemplo Put Option
 Ejemplo:
 Sólo por hoy tenemos la opción de vender una acción de Amazon por $50 (put
 option). Qué hacer si el precio de la acción es:
 $60:
 • Si tuviéramos una acción la podrı́amos vender en el mercado por $60 o
 usar nuestra opción y venderla por $50.
 • Serı́a mejor vender la acción directamente en el mercado por $60 y dejar
 que la opción expire.
 • ¿Cuál es el pago de nuestra put option? ⇒ No ejercemos la opción por lo
 que no hay pagos:
 • Entonces, Pago = $0
 36 / 58

[pág. 38]
Temario Arbitraje LOOP Derivados
Opciones
Opciones
Flujos
 • Los flujos de una opción dependen del precio que efectivamente se observe
 • En el ejemplo el precio de ejercicio es $50
 • ¿Cúales son los flujos de una call como función del precio spot (ST ) en la
 fecha de expiración T?
 • Si ST > 50 se tiene ST − 50, pero si ST < 50 se tiene 0
 • ¿Cúales son los flujos de una put como función de ST en la fecha de
 expiración?
 • Si ST < 50 se tiene 50 − ST , pero si ST > 50 se tiene 0
 • Aquı́ pueden ver claramente que una opción remueve parte de la variación
 en el precio
 37 / 58

[pág. 39]
Temario Arbitraje LOOP Derivados
Opciones
Opciones
Flujos
 • Más formalmente, si llamamos X al precio de ejercicio, el flujo de las
 opciones está dado por
 • Call option: máx (0, ST − X)
 • Put option: máx (X − ST , 0)
 • ¿Cómo se verı́a un gráfico de estos flujos?
 38 / 58

[pág. 40]
Temario Arbitraje LOOP Derivados
Opciones
Opciones
Flujos de una Call
 Pagos de una opción Call
 con precio de ejercicio X
 45°
 X ST
 39 / 58

[pág. 41]
Temario Arbitraje LOOP Derivados
Opciones
Opciones
Flujos de una Put
 Pagos de una opción Put
 con precio de ejercicio X
 45°
 X ST
 40 / 58

[pág. 42]
Temario Arbitraje LOOP Derivados
Opciones
Vendiendo Opciones
 Intuición:
 • Ahora, usted está al otro lado del contracto.
 • Tiene que asumir que su contraparte va a ejercer la opción que usted le
 vendió de manera óptima
 • Las ganancias de su contraparte serán sus pérdidas.
 41 / 58

[pág. 43]
Temario Arbitraje LOOP Derivados
Opciones
Vendiendo una opción Put
 Asuma que usted le vendió a una amiga una opción put que vence hoy con un
 precio de ejercicio de $50. Cuál será su flujo si el precio de la acción es:
 $40:
 • Asuma que su amiga tiene una acción. Entonces ella puede vender su
 acción en el mercado por $40 o puede usar la opción put para vendérsela a
 usted por $50.
 • Ella va a usar su opción para recibir $50 y hacer una ganancia de $10.
 • ¿Cuál es su flujo de caja?
 • Entonces tendrá que comprarle la acción por $50.
 • Pero la acción en el mercado vale sólo $40.
 • Entonces usted tuvo una pérdida de $10.
 42 / 58

[pág. 44]
Temario Arbitraje LOOP Derivados
Opciones
Vendiendo una opción Put
 Asuma que usted le vendió a una amiga una opción put que vence hoy con un
 precio de ejercicio de $50. Cuál será su flujo si el precio de la acción es:
 $60:
 • Asuma que su amiga tiene una acción. Entonces ella puede vender su
 acción en el mercado por $60 o puede usar la opción put para vendérsela a
 usted por $50.
 • Ella no va a usar su opción porque puede obtener un mejor precio
 vendiendo la acción en el mercado directamente.
 • ¿Cuál es su flujo de caja?
 • Como la opción no fue ejercida entonces su flujo es $0.
 43 / 58

[pág. 45]
Temario Arbitraje LOOP Derivados
Opciones
Vendiendo una opción Put
 Su contraparte tiene el derecho de venderle una acción por $50.
 Precio acción 0 20 40 50 60 80 100
 Flujo opción Put vendida −50 −30 −10 0 0 0 0
 44 / 58

[pág. 46]
Temario Arbitraje LOOP Derivados
Opciones
Flujos en T al vender opciones
 Pregunta: ¿Cuál de los siguientes gráficos describe los flujos de una posición
 corta en una Call con K=$50?
 45 / 58

[pág. 47]
Temario Arbitraje LOOP Derivados
Opciones
Opciones
Algunas estrategias
 • Combinaciones de opciones permiten generar perfiles de pagos particulares
 • Algunas estrategias
 • Protective put
 • Covered calls
 • Straddle
 • Collar
 • Protective put: limitar valor de pérdida por posición en un activo
 • Una acción más una opción put –precio de ejercicio X
 • Payoff (flujo) tiene un piso de X
 • Covered calls: “write” opción call y compra acción
 • Payoff de estrategia tiene techo en X
 46 / 58

[pág. 48]
Temario Arbitraje LOOP Derivados
Opciones
Paridad Put-Call
Flujos
 • ¿Cuál es el precio de una opción?
 • Para esto podemos usar una estrategia de arbitraje
 • Esta relación se conoce como la “paridad put-call”
 Considere las siguientes dos estrategias de inversión:
 • Alternativa 1: Invertir en una acción y una put (con exercise price X)
 • Alternativa 2: Invertir en un bono libre de riesgo (con principal de X) y
 una call (con exercise price X).
 47 / 58

[pág. 49]
Temario Arbitraje LOOP Derivados
Opciones
Paridad Put-Call
Alternativa 1: Acción + put
 Cuáles son los pagos de esta estrategia?:
 Posición Si ST < X ST < X
 Acción ST ST
 Put X − ST 0
 Acción + Put X ST
 48 / 58

[pág. 50]
Temario Arbitraje LOOP Derivados
Opciones
Paridad Put-Call
Alternativa 2: Bono + call
 Cuáles son los pagos de esta estrategia?:
 Posición Si ST < X ST < X
 Bono X X
 Call 0 ST − X
 Bono + Call X ST
 49 / 58

[pág. 51]
Temario Arbitraje LOOP Derivados
Opciones
Paridad Put-Call
Paridad Put-Call
 Ambas estrategias entregan los mismos pagos. Por lo tanto, para que no exista
 arbitraje se debe cumplir,
 X
 P1 + S1 = + C1
 1+r
 50 / 58

[pág. 52]
Temario Arbitraje LOOP Derivados
Opciones
Paridad Put-Call
Ejemplo
 • ¿Cómo aplicamos esto?
 • Supongamos una acción y tenemos opciones put y call
 • Precio de ejercicio es 100, valor de compra de una put es $5 y de una call
 es $1,2
 • Con un precio spot de 96, y si asumimos que T es corto y consideramos
 r = 0 tenemos
 X
 P1 + S1 = + C1
 1+r
 5 + 96 vs. 100 + 1,2
 • Existe una differencia de $0,2 entre los dos portafolios.
 51 / 58

[pág. 53]
Temario Arbitraje LOOP Derivados
Opciones
Paridad Put-Call
Ejemplo
 Pregunta: ¿Cómo aprovecharı́a esta oportunidad de arbitraje?
 A vendo put + acción y compro bono + call
 B compro put + acción y vendo bono + call
 C compro put + call y vendo bono + acción
 D vendo put + call y compro bono + acción
 E No sé.
 52 / 58

[pág. 54]
Temario Arbitraje LOOP Derivados
Opciones
Modelo Binomial
Motivación y Supuestos
 • Modelo que nos permite valorar opciones: encontrar P y C
 • Es sencillo y captura intuición detrás de modelos más complejos
 • Modelo de Black y Scholes corresponde a este mismo modelo pero con un
 proceso más complejo para describir valor de la acción
 • El escenario es simple:
 1 Tenemos una acción con precio actual S0
 2 Entre hoy y la fecha de expiración el precio puede subir a Su , o bajar a Sd
 3 La tasa de interés libre de riesgo es rf
 • Podemos usar arbitraje para ponerle precio a la opción
 53 / 58

[pág. 55]
Temario Arbitraje LOOP Derivados
Opciones
Modelo Binomial
Precio de una Opción Call
 • Veamos los flujos de los activos disponibles:
 “Sube” “Baja”
 Acción Su Sd
 Opción call Cu Cd
 Deuda/Bono ( 1 + rf ) (1 + rf )
 • ¿Cómo encontramos el portfolio que replica la opción?
 • Necesitamos encontrar las cantidades de bonos y acciones que replican los
 pagos de la opción
 54 / 58

[pág. 56]
Temario Arbitraje LOOP Derivados
Opciones
Modelo Binomial
Precio de una Call (cont.)
 • Necesitamos resolver el siguiente sistema
 Su ∆ + (1 + r)B =Cu
 Sd ∆ + (1 + r)B =Cd
 • Podemos resolver estas ecuaciones para encontrar las participaciones en el
 portafolio:
 Cu − Cd
 ∆=
 Su − Sd
 C − Sd ∆
 B =− d
 1 + rf
 • Entonces ahora podemos calcular el precio de una opción call
 C = S∆ + B
 55 / 58

[pág. 57]
Temario Arbitraje LOOP Derivados
Opciones
Modelo Binomial
Comentarios finales
 • La fórmula nos da el precio de una call: ¿cómo obtenemos una put?
 • Además este modelo también se puede extender para varios perı́odos:
 • En cada perı́odo hay dos posibles movimientos: “sube” y “baja”
 • Ası́ se pueden construir las trayectorias, ¡intuición es la misma!
 • Black y Scholes incopora un modelo en tiempo continuo que incoropora
 explı́citamente volatilidad, no incorpora dividendos
 56 / 58

[pág. 58]
Temario Arbitraje LOOP Derivados
Opciones
Modelo Black-Scholes
La Fórmula
 • Propuesta en 1973 por Black y Scholes, y separadamente por Merton
 (Premios Nobel en 1997: Scholes y Merton)
 • Bajo cierto supuestos derivan la siguiente expresión
 C0 =S0 N (d1 ) − X exp(−rT )N (d2 ) (1)
 ln(S0 /X) + (r + σ2 /2)T
 d1 = √
 σ T
 √
 d2 =d1 − σ T
 • Donde
 • C0 : valor actual de opción call
 • S0 : valor actual del activo
 • X : valor de ejercicio
 • r : tasa de interés libre de riesgo
 • T : tiempo faltante para fecha de ejercicio (en años)
 • σ : desviación estándar retorno anual compuesto continuamente
 • N (z) : probabilidad de que una variable normal estándar tenga un valor
 menor a z
 • Si generamos una observación aleatoriamente esperamos que una fracción N (z)
 de ellas sea menor a z
 57 / 58

[pág. 59]
Temario Arbitraje LOOP Derivados
Opciones
Intuición
 • Algunos elementos interesantes:
 • El retorno esperado no aparece directamente en la fórmula
 • Esta fórmula asume que no hay dividendos
 • Hay dos probabilidades que representan eventos
 • ¿Qué busca esta fórmula?
 • Intuición es simple: queremos saber si la opción va a terminar “in the
 money”
 58 / 58

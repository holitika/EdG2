# Teoría Financiera · L9 Estructura de Capital

Fuente: clase de Teoría Financiera

[pág. 1]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
 Teorı́a Financiera
 Estructuras de Capital
 Consuelo Silva
 Escuela de Administración PUC
 9 de junio de 2023
 1 / 125

[pág. 2]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Temas
 1 Introducción
 2 Costo de Capital
 3 Modigliani y Miller
 4 M&M e Impuestos
 5 Modelo de Trade-off
 6 Problemas de Agencia
 7 Información Asimétrica
 8 Conclusiones
 2 / 125

[pág. 3]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Primera parte del curso
 • Hasta ahora: demanda por activos.
 • Cómo medir riesgo y como ponerle precio.
 • Tomamos como dados los activos y sus caracterı́sticas:
 • Ajuste se da por precios, no por ajuste en oferta.
 • ¿Pero de dónde vienen estos activos?
 • Deben ser “creados” por alguien.
 • Emisión es justamente eso.
 • Se intenta recaudar recursos para distintos propósitos.
 3 / 125

[pág. 4]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Segunda parte del curso
 • Nuevo objetivo: entender como las empresas toman sus decisiones de
 financiamiento.
 • ¿Cómo debe una empresa financiar una inversión?:
 • ¿Endeudarse (emitir deuda)?
 • ¿Vender acciones?
 • ¿Usar utilidades retenidas?
 • Estudiaremos cómo se determina la composición del lado derecho del
 balance
 4 / 125

[pág. 5]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Hoja de ruta
 • Partiremos hoy con mercados perfectos sin fricciones
 • Luego introduciremos gradualmente diferentes fricciones y estudiaremos
 cómo afectan nuestros análisis efectos:
 • Impuestos
 • Costos de bancarrota.
 • Costos de agencia.
 • Asimetrı́as de información.
 5 / 125

[pág. 6]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Estructura de Capital en las Noticias
 6 / 125

[pág. 7]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Estructura de Capital en las Noticias
 7 / 125

[pág. 8]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Estructura de Capital “óptima”
 • La combinación de fuentes alternativas de capital es conocida como su
 estructura de capital.
 • Deuda: Bonos, deuda con bancos, etc.
 • Patrimonio: Acciones, acciones preferentes, etc..
 • “Estructura de Capital óptima” es la combinación de activos emitidos por
 la firma que maximiza su valor.
 • La misión ahora es encontrar el nivel de apalancamiento (leverage) que
 maximiza el valor.
 • El valor de una empresa es:
 FC1
 Vempresa = FC0 + + ...
 1 + rempresa
 • ¿Cómo puede el leverage afectar el valor de la empresa?
 • Afectando los flujos de caja
 • Afectando la tasa de descuento
 8 / 125

[pág. 9]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Hechos Estilizados
Apalancamiento por Industria en EEUU 2007
 9 / 125

[pág. 10]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Hechos Estilizados
Un Resumen Breve
 • Algunos hechos estilizados
 1 Empresas con flujos de caja estables, y que tienen activos usables como
 colateral tienen altas razones de deuda.
 2 Firmas riesgosas, con bajos flujos de cajas actuales, y firmas con activos
 intangibles tienen promedios menores.
 3 Compañı́as cuyo valor viene principalmente de crecimiento asociado a
 intangibles (ej. capital intelectual) tienen menores razones de deuda.
 4 Compañı́as más rentables se endeudan menos, usan recursos internos.
 5 Precios de acciones caen luego del anuncio de nuevas emisiones de acciones,
 y aumentan cuando se anuncia un acuerdo de préstamo con bancos
 6 Relación entre las caracterı́sticas de la industria y el nivel de deuda:
 • Papeleras, aerolı́neas tienen altos niveles de deuda
 • Farmacéuticas bajo niveles de deuda.
 10 / 125

[pág. 11]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Costo Capital Promedio Ponderado
Weighted Average Cost of Capital (WACC)
 • Pensemos en la hoja de balance de una firma
 • RA retorno exigido para los activos de la empresa.
 • RE retorno exigido por dueños del patrimonio.
 • RD retorno exigido por dueños de deuda de la empresa (por ahora
 asumimos que no hay impuestos).
 11 / 125

[pág. 12]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Costo Capital Promedio Ponderado (CCPP)
Weighted Average Cost of Capital (WACC)
 • La mayorı́a de las empresas usa una mezcla de deuda y patrimonio
 (acciones) para financiarse.
 • Si una empresa se endeuda o emite acciones, los inversionista demandarán
 un premio por riesgo para compensar el riesgo que están tomando.
 • El riesgo, y por tanto el premio por riesgo, variarán según tipo de activo
 financiero.
 • El costo de capital total de la empresa es un promedio ponderado de sus
 diferentes fuentes de financiamiento:
 • Costo Capital Promedio Ponderado (CCPP)
    
 Patrimonio Deuda
 CCPP = RA = RE + RD
 Patrimonio + Deuda Patrimonio + Deuda
 12 / 125

[pág. 13]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Costo Capital Promedio Ponderado (CCPP)
Weighted Average Cost of Capital (WACC)
 • ¿Cómo se relaciona el CCPP con el valor de la empresa?
 FC1 FC2 FCn
 Vf = + +...+
 1 + RA (1 + RA )2 (1 + RA )n
 • La estructura de capital óptima será aquella que minimice el CCPP:
 • El retorno exigido a la deuda es generalmente menor al exigido al
 patrimonio.
 • ¿ Implica esto que las empresas debieran preferir deuda?
 13 / 125

[pág. 14]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Una Idea Común: La Deuda es “Barata”
 14 / 125

[pág. 15]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Una Idea Común: La Deuda es “Barata”
 15 / 125

[pág. 16]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Apalancamiento, Riesgo y Retorno
 • ¿Qué hace riesgosa a una acción?
 • Riesgo de los activos: asociado al negocio de la empresa.
 • Riesgo financiero: Amplificación del riesgo producto del apalancamiento.
 • Ejemplo: Inversión de $1000 financiada 100 % con patrimonio con pagos
 (prob. = 1/2):
 2016 2017 Retornos
 Boom Crisis Boom Crisis E[R] Vol
 -1000 1400 900 40 % -10 % 15 % +- 25 %
 • Como la empresa se financia 100 % con patrimonio, los inversionistas
 demandan un 15 % de retorno, este es el costo del capital de la firma.
 • Si asumimos que la tasa libre de riesgo es 5 %, entonces el premio por
 riesgo requerido es de 10 %:
 RE = Rf + Premio por riesgo = 5 % + 10 % = 15 %
 16 / 125

[pág. 17]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Apalancamiento, Riesgo y Retorno
 • Supongamos que la empresa se endeuda por $500 (tasa 5 %).
 • ¿Qué pasa con el riesgo y el retorno del patrimonio?
 2016 2017 Retornos
 Boom Crisis Boom Crisis E[R] Vol
 Patrimonio no -1000 1400 900 40 % -10 % 15 % +- 25 %
 apalancado
 Flujos Deuda 500 -525 -525 5% 5% 5% +- 0 %
 Patrimonio apa- -500 875 375 75 % -25 % 25 % +- 50 %
 lancado
 • Introducir apalancamiento duplica el riesgo del patrimonio:
 • Los flujos de caja más seguros van a los tenedores de deuda.
 • Como resultado, la volatilidad del patrimonio aumenta.
 • Para compensar al riesgo del patrimonio, el premio por riesgo también se
 duplica:
 RE = Rf + 2 × Premio por riesgo = 5 % + 2 × 10 % = 25 %
 17 / 125

[pág. 18]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Apalancamiento, Riesgo y Retorno
 • ¡Cambiar la estructura de capital no cambio el CCPP!
 • CCPP de la empresa con 100 % patrimonio:
 E D
 CCPP = RE + RD = 1 × 15 % + 0 × 5 % = 15 %
 E+D E+D
 • CCPP de la empresa con apalancamiento:
 E D 1 1
 CCPP = RE + RD = × 25 % + × 5 % = 15 %
 E+D E+D 2 2
 18 / 125

[pág. 19]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Apalancamiento, Riesgo y Retorno
 • Apalancamiento financiero aumenta el riesgo y el retorno exigido al
 patrimonio.
 • La deuda es pagada primero por lo que tiene nada (o poco) de riesgo.
 • En un mercado de capitales perfecto:
 • Aumentar el apalancamiento no cambia el CCPP
 • A pesar de que la deuda sea “barata”, el costo del patrimonio aumenta de
 manera tal que elimina cualquier beneficio.
 • Aumentar el apalancamiento no cambio el valor de la firma:
 • V(patri. no apalancado) = V(deuda) + V(patri. apalancado)
 • “Todo = Suma de las partes”
 • Modigliani Miller (M&M) Theorem (1958).
 19 / 125

[pág. 20]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
M&M
Notación
 • V: valor de mercado de la empresa –activos
 • VL : valor de mercado de una empresa con deuda (“levered”).
 • VU : valor de mercado de empresa sin deuda (“unlevered”).
 • E: valor de mercado del patrimonio (“equity”).
 • D: valor de mercado de la deuda
 • RA : CCPP de una empresa
 • RU : CCPP de una empresa sin deuda (RUnlevered
 A )
 • EBIT: resultado operacional antes de impuestos
 20 / 125

[pág. 21]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
M&M
Supuestos
 • Se asume un mercado de capitales perfecto
 • Supuestos
 1 Inversionistas y empresas pueden transar los mismos activos financieros a
 los mismos precios que son iguales al valor presente de sus flujos futuros.
 2 No hay impuestos, costos de transacción, o costos de emisión asociados a
 transacciones de activos financieros.
 3 La decisión de financiamiento no cambia los flujos generados por las
 inversiones, ni entrega nueva información sobre éstos
 21 / 125

[pág. 22]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
M&M
Proposición 1
 Proposición 1 de M&M
 En un mercado de capitales perfecto, la estructura de financiamiento de una
 empresa es irrelevante para el valor de mercado de ésta.
 • Plan de inversiones y operaciones ya son conocidos.
 • La razón D/E no afecta los flujos totales ni su valor presente.
 • Matemáticamente
 EBIT EBIT
 VL = VU ⇒ Levered
 = ⇒ RLevered
 A = RU
 RA RU
 22 / 125

[pág. 23]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
M&M
Proposición 2
 Proposición 2 de M&M
 El retorno demandado al patrimonio apalancado es igual al retorno demandado
 al patrimonio no apalancado más una prima por riesgo que es proporcional a la
 razón entre los valores de mercado de la deuda y patrimonio.
 • Matemáticamente,
 RLevered
 A = RU
 E D
 R + R = RU
 E+D E E+D D
 D
 RE =RU + ( R − RD )
 E U
 23 / 125

[pág. 24]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
M&M
Proposición 2
 • En el ejemplo anterior
 • Si 100 % equity:
 RE =RU
 RE =15 %
 • Si deuda es 50 %
 D
 RE =RU + (R − RD )
 E U
 500
 RE =15 % + (15 % − 5 %)
 500
 RE =25 %
 24 / 125

[pág. 25]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
CCPP con M&M
 25 / 125

[pág. 26]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Apalancamiento “Hecho en Casa”
 • La decisión de apalancamiento de la empresa es irrelevante para el
 inversionista:
 • Si firma emite deuda y acciones, inversionistas que no quieren estar
 apalancados pueden comprar ambos activos.
 • Si la firma no tiene deuda, los inversionistas pueden replicar el
 apalancamiento deseado usando un préstamo personal.
 • Ejemplo (vuelta a DF Corp):
 • Para lograr los mismo flujos que la empresa apalancada el inversionista
 puede comprar la empresa sin apalancamiento usando un préstamo de $500
 (tasa 5 %):
 2016 2017 Retornos
 Boom Crisis Boom Crisis E[R] Vol
 Patrimonio no apa- -1000 1400 900 40 % -10 % 15 % +- 25 %
 lancado
 Flujos préstamo per- 500 -525 -525 5% 5% 5% +- 0 %
 sonal
 Flujo final inversionis- -500 875 375 75 % -25 % 25 % +- 50 %
 ta
 26 / 125

[pág. 27]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Apalancamiento “Hecho en Casa”
 • Ejemplo (vuelta a DF Corp):
 • Para lograr los mismo flujos que la empresa no apalancada el inversionista
 puede comprar acciones de la empresa apalancada y prestar (comprar
 deuda):
 2016 2017 Retornos
 Boom Crisis Boom Crisis E[R] Vol
 Patrimonio apalanca- -500 875 375 75 % -25 % 25 % +- 50 %
 do
 Flujos préstamo per- -500 525 525 5% 5% 5% +- 0 %
 sonal
 Flujo final inversionis- -1000 1400 900 40 % -10 % 15 % +- 25 %
 ta
 27 / 125

[pág. 28]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo
 Pregunta
 Una firma que opera en un mercado de capitales perfecto tiene activos
 financiados en 20 % con deuda y el resto con patrimonio. La deuda no tiene
 riesgo y paga un interés anual de 10 %. El retorno esperado sobre el portafolio
 de mercado es 18 %, el beta de las acciones de la firma es 0.75. La firma espera
 generar flujos operacionales de $370 a perpetuidad.
 I) Calcule el retorno exigido por los accionistas, y el CCPP
 a) RE = 18, 0 % y CCPP = 16, 0 %
 b) RE = 14,8 % y CCPP = 18,0 %
 c) RE = 16, 0 % y CCPP = 14,8 %
 d) RE = 18,0 % y CCPP = 14,8 %
 28 / 125

[pág. 29]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo
 • Problema:
 • Estamos buscando:
 • RE , β A y CCPP
 • Tenemos:
 • β E = 0,75
 • RM = 0,18
 • Rf = 0,1
 • Solución:
 • RE = Rf + β E (RM − Rf ) = 0,1 + 0,75(0,18 − 0,1) = 0,16
 • β A = E β E + D β D = (1 − 0,2) × 0,75 + 0,2 × β D
 E+D E+D
 No nos dan β D ...
 Pero sı́ nos dicen que la deuda es libre de riesgo =⇒ β D = 0.
 =⇒ β A = 0,8 × 0,75 + 0,2 × 0 = 0,6
 29 / 125

[pág. 30]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo
 • Solución (cont.):
 • Nos falta el CCPP. Tenemos dos alternativas, podemos usar el promedio
 ponderado del costo de capital del patrimonio y deuda, o podemos usar el
 beta que acabamos de calcular:
 i. Usando los costos de capital:
 E D
 CCPP = RA = RE + RD = 0,8 × 0,16 + 0,2 × 0,1 = 14,8 %
 E+D E+D
 ii. Usando el β A :
 CCPP = RA = Rf + β A (RM − Rf ) = 0,1 + 0,6(0,18 − 0,1) = 14,8 %
 30 / 125

[pág. 31]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo
 Pregunta
 Una firma que opera en un mercado de capitales perfecto tiene activos
 financiados en 20 % con deuda y el resto con patrimonio. La deuda no tiene
 riesgo y paga un interés anual de 10 %. El retorno esperado sobre el portafolio
 de mercado es 18 %, el beta de las acciones de la firma es 0.75. La firma espera
 generar flujos operacionales de $370 a perpetuidad.
 ii) Suponga que la firma duplica su deuda y recompra acciones. Calcule el
 retorno exigido por los accionistas y el CCPP.
 a) RE = 18, 0 % y CCPP = 16, 0 %
 b) RE = 14,8 % y CCPP = 18,0 %
 c) RE = 16, 0 % y CCPP = 14,8 %
 d) RE = 18,0 % y CCPP = 14,8 %
 31 / 125

[pág. 32]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Volvamos al CCPP bajo M&M
 32 / 125

[pág. 33]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo deuda riesgosa
 • ¿Qué está pasando cuando la “curva de la deuda empieza a subir?”
 • Volvamos al ejemplo de nuestra empresa que requerı́a una inversión de
 $1000 y que podı́a obtener $1400 ó $900 según el estado de la economı́a.
 • En el escenario de Boom económico, la empresa podrá devolver el 100 %
 de la deuda, independiente del valor prestado.
 • Sin embargo, en el escenario de crisis, la empresa a lo más dispondrá de
 $900 para pagar la deuda:
 • Por lo tanto los inversionistas sólo prestarán un máximo de
 $900/1.05=$857.1 a la tasa libre de riesgo.
 • A partir de ese nivel de deuda, la deuda pasa a ser riesgosa, es decir β D > 0
 y el retorno exigido para la deuda será mayor a 5 %.
 33 / 125

[pág. 34]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo deuda riesgosa
 • La siguiente tabla presenta los costos de capital para el patrimonio, deuda
 y activos (CCPP), para diferentes niveles de deuda:
 RE RD E D
 E D E+D RE + E+D RD =CCPP
 1000 0 15 % 5.0 % 1,0 × 15,0 % + 0,0 × 5,0 % =15 %
 800 200 17.5 % 5.0 % 0,8 × 17,5 % + 0,2 × 5,0 % =15 %
 500 500 25 % 5.0 % 0,5 × 25,0 % + 0,5 × 5,0 % =15 %
 100 900 75 % 8.3 % 0,1 × 75,0 % + 0,9 × 8,3 % =15 %
 34 / 125

[pág. 35]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo deuda riesgosa
 • ¿De dónde vienen el RD = 8,3 %?
 • Suponga que la deuda es tal que paga $1050 en el escenario de boom y
 $900 en el escenario de crisis.
 • En el escenario de boom entregará 16.67 % de retorno, mientras que en el
 escenario de crisis entregará 0 % (900 es todo lo que dispone la empresa
 para pagar deuda).
 • Tiene entonces un retorno esperado de 8.3 %.
 35 / 125

[pág. 36]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Fricciones
 • Hasta el momento hemos asumido que tenemos un mercado de capitales
 perfecto:
 • No hay impuestos ni costos de bancarrota.
 • No hay costos de agencia.
 • No hay asimetrı́as de información.
 • Todos los activos tiene el precio correcto o “justo”.
 • Implicancia clave: Para que la estructura de financiamiento genere valor,
 debe existir alguna imperfección de mercado que afecte los flujos de caja.
 36 / 125

[pág. 37]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Fricciones
 • Hasta el momento hemos asumido que tenemos un mercado de capitales
 perfecto.
 • Para que la estructura de financiamiento genere valor, debe existir alguna
 imperfección de mercado que afecte los flujos de caja.
 • Impuestos
 • Costos de bancarrota.
 • Asimetrı́as de información.
 • Costos de agencia.
 • Impuestos Corporativos:
 • ¿Puede el apalancamiento financiero reducir los impuestos que tiene que
 pagar una empresa, y ası́ aumentar su valor?
 37 / 125

[pág. 38]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
M&M –Introduciendo Impuestos Corporativos
 • Supongamos dos firmas con EBIT (constante) de $1000 c/u
 • Valor de activos es $4000, Rd = 10 %, τc = 35 %
 • Firma U sólo patrimonio, firma L tiene 50 % deuda
 • Veamos los estados de resultados
 Sin impuestos Con impuestos
 U L U L
 EBIT 1000 1000 1000 1000
 Intereses 0 (200) 0 (200)
 EBT 1000 800 1000 800
 Impuestos (35 %) 0 0 (350) (280)
 Utilidad 1000 800 650 520
 Disponible para cada inversionista:
 Utilidad disponible para los accionistas 1000 800 650 520
 Intereses pagados a los acreedores 0 200 0 200
 Total disponible para los todos
 los inversionistas 1000 1000 650 720
 38 / 125

[pág. 39]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
M&M – Impuestos Corporativos
 • ¿De dónde viene la diferencia?
 • Diferencia para total inversionistas = $720-$650=$70
 • Ahorro por impuesto (tax shield) = $350-$280=$70
 • La deuda proporciona una ventaja tributaria (tax shield) que reduce los
 impuestos cada año:
 Reducción Impuestos = (Tasa Imp. Corp) × (Pagos Interés)
 • Esta reducción en impuestos aumenta el valor de la empresa para los
 inversionistas:
 VL = VU + PV (futuras ventajas tribut. )
 donde,
 PV(futuras ventajas tribut.) = τc × PV(futuros pagos interés)
 • Caso especial 1: Nivel target D/E (supondremos este caso en adelante)
 • Caso especial 2: Nivel deuda permanente,
 • Si el precio de la deuda está correcto: D =PV(futuros pagos interés)
 VL = VU + τc × D (1)
 39 / 125

[pág. 40]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Derivando la Ventaja Tributaria
 • ¿Cómo llegamos a la ecuación (1)?
 • Para firma sin leverage los flujos después de impuestos son:
 Flujo =(1 − τc )EBIT
 • Para la firma con leverage:
 Flujo =(1 − τc )(EBIT − Rd D) + Rd D
 =(1 − τc )EBIT + τc Rd D
 • Con flujos a perpetuidad (y suponiendo D constante) tenemos que
 (1 − τc )EBIT
 VU =
 RU
 ( 1 − τc )EBIT τc Rd D
 VL = + = VU + τc D
 RU Rd |{z}
 benef. tributario
 40 / 125

[pág. 41]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
CCPP con Impuestos
 • Hemos concluido que la deuda tiene ventaja tributaria: PV(tax shield)
 • ¿Qué sucede con el costo de capital?
 • Por cada $1 de interés pagado, la empresa obtiene un beneficio tributario de
 $0,35
 • ¡El costo neto después de impuestos de pagar $ en intereses es sólo de $0,65!
 • La tasa de interés efectiva después de impuestos es de RD (1 − τc )
 • CCPP antes de impuestos (no cambia con apalancamiento):
 E D
 CCPPpre−tax = R + R = RU
 E+D E E+D D
 • CCPP con impuestos (disminuye con apalancamiento):
 E D D
 CCPP = R + R (1 − τc ) = RU − τc RD
 E+D E E+D D E+D
 41 / 125

[pág. 42]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
CCPP con M&M e Impuestos
 42 / 125

[pág. 43]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo: CCPP con M&M e Impuestos (Berk & DeMarzo)
 Pregunta: Wester Lumber Co. espera tener un flujo de caja libre de $4.25
 millones, el cual se espera que crezca al 4 % anual a perpetuidad. La firma
 tiene un costo de capital del patrimonio de 10 % y un costo de capital de la
 deuda de 6 %. El impuesto corporativo es de 35 %. Si la empresa mantiene un
 ratio deuda/patrimonio de 0.50, cuál es el valor de su ahorro por impuesto (tax
 shield)?
 • $91 millones
 • $107 millones
 • $16 millones
 • $1.4875 millones
 • No se puede calcular
 43 / 125

[pág. 44]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
M&M
Recapitulando
 • Principales conclusiones
 • Sin impuestos el valor de la firma es independiente de la estructura de
 financiamiento
 • Decisiones de financiamiento son irrelevantes
 • Con impuestos, valor de firma aumenta con la razón D/E
 • Es mejor tener más financiamiento por deuda
 • En ningún momento hemos asumido que deuda deba ser libre de riesgo
 • Tampoco hemos entrado en los costos de quiebra, reorganización o
 dificultades financieras (“financial distress”)
 44 / 125

[pág. 45]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
“Big Picture”
 45 / 125

[pág. 46]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Evidencia Empı́rica
 • Desde 2006, empresas en Bélgica pueden descontar impuestos en función
 del valor libro de su patrimonio (deducción = Patrimonio*RD )
 Fuente: “Capital Structure and Taxes: What Happens When You (Also) Subsidize Equity?” Panier,
 Pérez-González y Villanueva (2015)
 46 / 125

[pág. 47]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Hoja de ruta
 • Mercados perfectos sin fricciones
 • Luego introduciremos gradualmente diferentes fricciones y estudiaremos
 cómo afectan nuestros análisis efectos:
 • Impuestos
 • Costos de bancarrota
 • Costos de agencia.
 • Asimetrı́as de información.
 47 / 125

[pág. 48]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Apalancamiento óptimo
 Si los impuestos fueran la única fricción, el óptimo serı́a un 100 % de deuda,
 pero las empresas no aprovechan completamente el beneficio tributario
 =⇒ ¿Cuál es el tradeoff?
 48 / 125

[pág. 49]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Apalancamiento Financiero y Quiebra
 • La caracterı́stica clave de la deuda (vs. patrimonio) es que los pagos de
 interés de la deuda tienen que hacerse.
 • Si estos pagos son muy altos, la firma en algún momento puede encontrar
 imposible cumplir con sus compromisos de deuda y entrará en situación de
 no pago (default).
 • ¿Es afectado el valor de la firma por el riesgo de quiebra?
 49 / 125

[pág. 50]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Apalancamiento Financiero y Quiebra
 Considere una empresa que enfrenta dos escenarios: uno bueno donde el valor
 de los activos será de $150 y uno malo donde los activos de la firma valdrán
 $80. La firma tiene dos alternativas de financiamiento, sólo patrimonio o emitir
 además deuda por $100.
 Sin deuda Con deuda
 Bueno Malo Bueno Malo
 Valor deuda - - 100 80
 Valor Equity 150 80 50 0
 Total inversionistas 150 80 150 80
 • ¿Era necesario para Modigliani-Miller que la deuda sea libre de riesgo (es
 decir, sin posibilidad de quiebra)?
 • ¡No! MM simplemente asume que en caso de quiebra los flujos de los
 activos no se ven afectados.
 • ¿Pero en la realidad, son los flujos negativamente afectados por una
 quiebra?
 50 / 125

[pág. 51]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Costos Directos e Indirectos de Dificultades Financieras
 • Los costos de quiebra, como los impuestos, reducen el valor de la firma:
 VL = E + D
 • Hay costos directos del proceso de quiebra y también costos indirectos
 asociados a dificultades financieras de la empresa (financial distress).
 51 / 125

[pág. 52]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Costos Directos de Quiebra
 • La quiebra es un proceso engorroso:
 • Costos legales, contables y de consultorı́a.
 • Estos costos tienden a ser grandes en magnitud:
 • United Airlines: $8.6 millones de usd/mes.
 • Enron: $750 millones de usd.
 • Worldcom/MCI: $657 millones de usd.
 • Pero tienden a ser un porcentaje pequeño del valor de la empresa antes de
 quiebra. Datos para EEUU:
 • Empresas grandes (Chap. 11): 4 % en promedio.
 • Empresas pequeñas (Chap 7): 12 % aprox. en promedio
 =⇒ Pero no parecen tan altos, esperarı́amos ver mayores niveles de deuda
 si esto fuera todo.
 52 / 125

[pág. 53]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Costos Indirectos de Quiebra
 • Más allá de los costos directos del proceso de quiebra, hay costos
 adicionales asociados a las dificultades financieras.
 • Algunos costos aparecen por ineficiencias en el proceso de negociación
 entre ejecutivos y acreedores:
 • Ventas apresuradas (fire sales) de activos.
 • Demora en liquidaciones eficientes (apuesta a resucitar).
 • Algunos costos están asociados a la dificultad de mantener compromisos
 en el caso de quiebra:
 • Problemas con cuentas por pagar (proveedores recortando los plazos o
 desapareciendo)
 • Clientes pueden desaparecer
 • Costos de empleados pueden aumentar
 • Problemas con cuentas por cobrar (deudores esperan que empresa vaya a
 desaparecer)
 53 / 125

[pág. 54]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
 Costos de Quiebra
 Qué empresas tendrı́an mayores costos de quiebra?
 • Empresas con negocios de operaciones más complejas (dificultad para
 valorar activos)
 • Con un gran número de acreedores (dificultad para el concenso)
 • Empresas cuyo producto depende del soporte futuro de la firma
 • Empresas con activos poco lı́quidos
 54 / 125

[pág. 55]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
 Costos de Quiebra
 • La existencia de estos costos de quiebra implica que ya no podemos
 asumir mercados perfectos
 • MM asume que los flujos de caja de los activos de la firma no dependen
 de su estructura de capital
 • Sin embargo, hemos visto que firmas con deuda incurrirán en costos de
 quiebra que reducen los flujos de caja disponibles para los inversionistas.
 55 / 125

[pág. 56]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo en clases - Parte 1A (Berk deMarzo)
 Suponga una empresa que cuyos activos pueden tener mañana un valor de 150
 ó 80 con igual probabilidad. Suponga que no tiene riesgo sistemático por lo que
 puede descontar todos los flujos a la tasa libre de riesgo de 5 %.
 Resolvamos primero juntos el caso en que no hay deuda....
 Pregunta
 Encuentre el valor del patrimonio.
 1 $85.71
 2 $150
 3 $23.81
 4 $109.52
 5 No sé como calcularlo
 56 / 125

[pág. 57]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo en clases - Parte 1B (Berk deMarzo)
 Suponga una empresa que cuyos activos pueden tener mañana un valor de 150
 ó 80 con igual probabilidad. Suponga que no tiene riesgo sistemático, por lo
 que puede descontar todos los flujos a la tasa libre de riesgo de 5 %.
 Pregunta
 Encuentre el valor del patrimonio y la deuda, respectivamente si la empresa
 tiene una deuda con valor de car’atula de $100.
 1 $85.71 y $23.81
 2 $25 y 75
 3 $23.81 y $85.71
 4 $14.26 y $42.58
 5 No sé como calcularlo
 57 / 125

[pág. 58]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo en clases - Parte 1B (Berk deMarzo)
 • Qué empresa vale más?
 58 / 125

[pág. 59]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo en clases - Parte 2A (Berk deMarzo)
 Suponga una empresa que cuyos activos pueden tener mañana un valor de 150
 ó 80 con igual probabilidad. Suponga que no tiene riesgo sistemático, por lo
 que puede descontar todos los flujos a la tasa libre de riesgo de 5 %.
 Suponga ahora que hay costo de quiebra de $20 que se deben pagar si la deuda
 no se puede pagar completa.
 Pregunta
 Encuentre el valor del patrimonio si la empresa tiene una deuda con valor cara
 de $100.
 1 $25
 2 $23.81
 3 $14.26
 4 $4.76
 5 No sé como calcularlo
 59 / 125

[pág. 60]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo en clases - Parte 2B (Berk deMarzo)
 Suponga una empresa que cuyos activos pueden tener mañana un valor de 150
 ó 80 con igual probabilidad. Suponga que no tiene riesgo sistemático, por lo
 que puede descontar todos los flujos a la tasa libre de riesgo de 5 %.
 Suponga ahora que hay costo de quiebra de $20 que se deben pagar si la deuda
 no se puede pagar completa.
 Pregunta
 Encuentre el valor de la deuda de la empresa con valor cara de $100.
 1 $85.71
 2 $76.19
 3 $66.67
 4 No sé como calcularlo
 60 / 125

[pág. 61]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo en clases - Parte 2 (Berk deMarzo)
 • Cuánto vale ahora la firma?
 61 / 125

[pág. 62]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Costos de “Estres” Financiero
Probabilidad vs Tamaño
 • Con costos de estres financiero podemos pensar en la siguiente relación
 VL =VU + PV (taxshield) − Q(D) (2)
 donde Q(D) son los costos de estres financiero, y son crecientes en D
 • Podemos pensar en estos costos como dos componentes:
 Q(D) = P(D) × CE(D)
 | {z } | {z }
 prob estres costo cond en estres
 • ¿Cómo podemos pensar en ambos elementos?
 • Probabilidad
 • Cobertura de intereses
 • Volatilidad de resultado operacional
 • Costos
 • Directos
 • Indirectos
 62 / 125

[pág. 63]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Modelo de Tradeoff
 • El apalancamiento óptimo equilibra el beneficio tributario de la deuda con
 los costos directos e indirectos de dificultades financieras.
 63 / 125

[pág. 64]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Modelo de Trade-off
 • costos de quiebra vs beneficio tributario
 • Mayor uso de deuda implica trade-off:
 • Reduce el pedazo de torta que se lleva el gobierno
 • Aumenta el tamaño esperado de la pérdida de torta
 • Existe un (D/E)∗ que es óptimo –maximiza el valor de la firma
 64 / 125

[pág. 65]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Recapitulando
 • MM: Estructura de capital afecta valor de la empresa si y sólo si afecta los
 flujos de sus activos:
 • Impuestos corporativos: Los intereses de la deuda pueden ser descontados.
 Deuda puede aumentar los flujos después de impuestos y por tanto el valor.
 • Modelo de trade-off: empresas seleccionan nivel óptimo de deuda
 balanceando:
 • El beneficio tributario de la deuda
 • Los costos de dificultades financieras
 65 / 125

[pág. 66]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Fricciones
 • Para que la estructura de financiamiento genere valor, debe existir alguna
 imperfección de mercado que afecte los flujos de caja.
 • Impuestos
 • Costos de bancarrota.
 • Problemas de agencia.
 • Asimetrı́as de información.
 66 / 125

[pág. 67]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Temas: Problemas de agencia
 1 Problemas de agencia entre tenedores de deuda y accionistas:
 • Debt Overhang
 • Risk-shifting
 2 Problemas de agencia entre accionistas y gerentes:
 • Over-Investment of Free Cash Flow
 67 / 125

[pág. 68]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Problemas de Agencia
 • Decisiones de inversión son afectadas por estructura de
 financiamiento existente
 • Flujos no son independientes de las decisiones de financiamiento pasadas
 • Diferencias claves entre equity y deuda:
 • Deuda tiene prioridad de pago: derechos residuales vs derechos senior
 • Los accionistas tienen el poder de decisión sobre inversiones
 • Lo que es mejor para la empresa (deuda + equity), puede no ser lo mejor
 para los accionistas.
 • Esto no implica necesariamente tomar decisiones más riesgosas.
 68 / 125

[pág. 69]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Financiamiento con Deuda
 Beneficios: Costos:
 • Beneficio tributario (tax shield): • Costos de dificultades financieras
 reduce los impuestos que se (quiebra)
 pagan.
 • Debt overhang: NO inversión en
 proyectos con VPN>0.
 • Incentivos: Reduce sobreinversión
 • Risk-shifting: Sobreinversión
 (proyectos con VPN<0) del flujo
 (proyectos con VPN<0).
 de caja libre.
 69 / 125

[pág. 70]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Debt Overhang
 • No es posible levantar el financiamiento necesario para invertir en
 proyectos aún cuando estos generen valor. Los accionistas no se benefician
 del proyecto por lo que no tienen incentivos a invertir en el.
 • La firma entonces subinvierte (under-investment), deja de invertir en
 proyectos rentables.
 70 / 125

[pág. 71]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Debt Overhang
Ejemplo
 Pregunta
 • Firma con flujos inciertos de 100 ó 20 con igual probabilidad
 • Deuda actual implica un pago de 50 mañana
 • Empresa es por sólo un perı́odo
 • No hay descuento
 • Empresa descubre una oportunidad de inversión segura, costo es 10 y
 entrega un flujo de 15
 • Inversión sólo puede ser financiada por accionistas actuales
 ¿Si usted fuera el dueño de todas las acciones de la empresa, usted invertirı́a en
 esta oportunidad de inversión?
 1 Sı́
 2 No
 71 / 125

[pág. 72]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Debt Overhang
Ejemplo
 • Solución
 • Valor de mercado del patrimonio (E) y la deuda (D) son:
 E =50/2 = 25 D = (50 + 20)/2 = 35
 • Valor de la empresa es 60
 • Veamos el valor del patrimonio si se hace la inversión
 E = 65/2 = 32,5
 • ∆E = 7,5 < 10 =⇒ no financian proyecto
 • ¿Dónde está el resto de los flujos?
 • Los recibe la deuda: D = (50 + 35)/2 = 42,5
 72 / 125

[pág. 73]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Debt Overhang
 • Inversión no se hace
 • A pesar que valor presente neto del proyecto es positivo ($5) y eso afectarı́a
 positivamente al valor de la empresa
 • ¿Por qué se lleva la deuda parte de los flujos?
 • Porque tienen derechos senior sobre ellos
 • En el estado “malo” los accionistas no reciben todos los flujos nuevos
 73 / 125

[pág. 74]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Debt Overhang
 • Cuando una firma esta cercana a la quiebra, podrı́a elegir no financiar
 proyectos con VPN>0 (under-investment)
 • El no invertir en los proyectos con VPN>0 es costoso para los acreedores y
 para el valor de la firma.
 74 / 125

[pág. 75]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo Real Debt Overhang
 • Crisis Financiera 2008
 • Bancos no realizaban préstamos que parecı́an “razonables”.
 • Una explicación es que los que querı́an endeudarse eran demasiado
 riesgosos y en verdad era mejor no realizar los préstamos
 • Pero alternativamente puede ser un problema de debt overhang
 • Los mismos bancos argumentaban que no podı́an levantar el capital
 necesario para realizar estos proyectos con VPN positivo
 • Un objetivo primordial de las medidas de los gobiernos durante la crisis fue
 proporcional capital nuevo a los bancos, para aliviar su problema de debt
 overhang y ası́ aumentar la disponibilidad de crédito al resto de la
 economı́a.
 75 / 125

[pág. 76]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Risk-shifting
 • Distintos derechos sobre flujos: “apostando con dinero ajeno”
 • En ciertas circunstancias el dinero apostado no es del accionista. . . eran
 flujos que la deuda recibirı́a
 • El riesgo (o la variabilidad) de los flujos se le traspasa a los acreedores
 • Accionistas pueden preferir hacer proyectos que reducen valor de la
 empresa (proyectos con VPN<0):
 • Pero tienen retorno positivo para ellos
 • Acreedores absorben la diferencia
 76 / 125

[pág. 77]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Risk-shifting
Intuición
 • Estructura de capital pre-existente afecta decisiones de inversión futuras
 • En el margen los incentivos cambian, accionistas y acreedores reciben partes
 distintas de los flujos de la empresa
 • Parecido a opciones: una vez que no se cubre la deuda, variación se la lleva
 el acreedor
 • Si se cubre la deuda, la ganancia adicional va para el accionista
 77 / 125

[pág. 78]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Risk-shifting
Ejemplo
 Pregunta
 • Empresa tiene flujos posibles de $100 (estado bueno) y $50 (estado malo);
 probabilidad 50 %
 • Deuda actual implica un pago de 70 mañana
 • Empresa es por sólo un perı́odo
 • No hay descuento
 • Empresa tiene oportunidad de inversión que cuesta $8 hoy y tiene flujos
 mañana de $10 (estado bueno) y $0 (estado malo)
 • Inversión sólo puede ser financiada por accionistas actuales
 ¿Si usted fuera el dueño de todas las acciones de la empresa, usted invertirı́a en
 esta oportunidad de inversión?
 1 Sı́
 2 No
 78 / 125

[pág. 79]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Risk-shifting
Ejemplo
 • Solución
 • Notemos que el VPN del proyecto es negativo: VPN=10/2-8=-3
 • A la empresa no le conviene hacer el proyecto
 • ¿Pero qué deciden los accionistas?
 • Valor de mercado del patrimonio (E) y la deuda (D) son:
 E =30/2 = 15 D = (70 + 50)/2 = 60
 • Valor de la empresa es 75
 • Veamos el valor del patrimonio si se hace la inversión
 E = 40/2 = 20
 • ∆E = 5 < 8 =⇒ accionistas deciden no financiar nuevo proyecto
 79 / 125

[pág. 80]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Risk-shifting
Ejemplo
 Pregunta
 • Empresa tiene flujos posibles de $100 (estado bueno) y $50 (estado malo);
 probabilidad 50 %
 • Deuda actual implica un pago de 70 mañana
 • Empresa es por sólo un perı́odo
 • No hay descuento
 • Suponga ahora que empresa tiene oportunidad de inversión que cuesta $8
 hoy y tiene flujos mañana de $20 (estado bueno) y $ − 10 (estado malo)
 • Inversión sólo puede ser financiada por accionistas actuales
 ¿Si usted fuera el dueño de todas las acciones de la empresa, usted invertirı́a en
 esta oportunidad de inversión?
 1 Sı́
 2 No
 80 / 125

[pág. 81]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Risk-shifting
Ejemplo
 • Solución
 • Notemos que el VPN del proyecto es negativo: VPN=10/2-8=-3
 • A la empresa no le conviene hacer el proyecto
 • ¿Pero qué deciden los accionistas?
 • Valor de mercado del patrimonio (E) y la deuda (D) son:
 E =30/2 = 15 D = (70 + 50)/2 = 60
 • Valor de la empresa es 75
 • Veamos el valor del patrimonio si se hace la inversión
 E = 50/2 = 25
 • ∆E = 10 > 8 =⇒ accionistas deciden Sı́ financiar nuevo proyecto
 81 / 125

[pág. 82]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Risk-shifting
Ejemplo
 • Solución
 • ¿De dónde salen estos “nuevos” flujos de $5 (el proyecto sólo nos daba
 $10/2=5)?
 • Los pierden los tenedores de la deuda: D = (70 + 40)/2 = 55
 • ∆D = 55 − 60 = −5
 • Inversión sı́ se hace
 • A pesar que valor presente neto del proyecto es negativo ($-3) y eso
 afectarı́a negativamente al valor de la empresa
 • ¿Por qué la deuda sale perjudicada?
 • En el estado “malo” los accionistas ya no tenı́an nada que perder
 82 / 125

[pág. 83]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Risk-shifting
 • Cuando la firma está cercano a la quiebra, los accionistas pueden
 beneficiarse de decisiones que aumentan el riesgo de la firma
 considerablemente, incluso si tienen VPN<0 (sobre inversión).
 • Si la firma invierte en proyectos con VPN<0 el valor de la firma se reduce.
 Los acreedores anticipan este comportamiento y pagan menos por la
 deuda de la firma.
 83 / 125

[pág. 84]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo Real Risk-Shifting
 • Terex Corporation: producı́a tractores y otras maquinarias
 • Acción habı́a caı́do 60 %
 • Muchos inversionistas pensaban que la compañı́a tenı́a un alto riesgo de
 quiebra
 • Tandolph Lenz, el CEO y presidente del directorio, que era dueño del 53 %
 de las acciones decidió realizar la compra de otro empresa, usando deuda a
 pesar de los problemas
 • Esta compra fue catalogada como altamente especulativa
 • ¿Qué creen que pasó con el precio de las acciones y de los bonos de Terex?
 • Precio acción subió de $11.6 a $12.
 • Valor de los bonos disminuyó considerablemente
 84 / 125

[pág. 85]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
 Cómo reducir los problemas de agencia?
 1.- Pactos en el contrado de deuda (Covenants): Sirven para limitar la
 flexibilidad de los accionistas o de la gerencia:
 2.- Vencimiento de la deuda: El plazo de la deuda puede servir para disminuir
 ciertos problemas de agencia
 3.- Deuda convertible: Tenedores de bonos pueden decidir convertir sus bonos
 a acciones de la empresa.
 85 / 125

[pág. 86]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Deuda e Incentivos: El lado positivo
 • Tomar deuda puede afectar los incentivos de la gerencia de la firma
 • Un mayor nivel de apalancamiento (leverage) financiero puede ayudar a
 que el CEO tome mejores decisiones.
 • Dado lo anterior, emitir deuda puede comprometer de manera creı́ble a la
 gerencia a entregar un mayor esfuerzo en favor de sus accionistas.
 86 / 125

[pág. 87]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Over-Investment of Free Cash Flow (Jensen)
 • Hasta el momento hemos asumido que los gerentes actúan en completo
 beneficio de los accionistas (dueños) de la empresa.
 • Pero si los gerentes no son necesariamente los dueños esto no es
 necesariamente verdad.
 • En la práctica control y propiedad están separados: conflicto de interés
 entre gerentes y accionistas.
 • Si la posibilidad de ser despedido es baja, los gerentes pueden tomar
 decisiones que los benefician a costa de los accionistas
 87 / 125

[pág. 88]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Free Cash Flow de Jensen
 • Evidencia: Tyco y Dennis Kozlowski:
 en.wikipedia.org/wiki/Dennis Kozlowski
 Video: https://www.youtube.com/watch?v=8rcxO6urHTE
 88 / 125

[pág. 89]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
 89 / 125

[pág. 90]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
$6000us Shower Curtains
 Fuente: Huffington Post
 90 / 125

[pág. 91]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Over-Investment of Free Cash Flow (Jensen)
 • Elemento crucial: recursos que no son usados pueden ser usados por los
 administradores
 • Tradicionalmente, decisiones que dan beneficio directo o indirecto al
 administrador, pero que tienen un VPN<0.
 • La deuda aumenta el valor de la firma porque compromete a la firma a
 pagar intereses en el futuro, por lo tanto, reduce el flujo de caba
 disponible para malas inversiones.
 91 / 125

[pág. 92]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Problemas de Agencia
 • Decisiones de inversión son afectadas por estructura de
 financiamiento existente
 • Flujos no son independientes de las decisiones de financiamiento pasadas
 • Diferencias claves entre equity y deuda:
 • Deuda tiene prioridad de pago: derechos residuales vs derechos senior
 • Los accionistas tienen el poder de decisión sobre inversiones
 • Lo que es mejor para la empresa (deuda + equity), puede no ser lo mejor
 para los accionistas.
 92 / 125

[pág. 93]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Financiamiento con Deuda
 Beneficios: Costos:
 • Beneficio tributario (tax shield): • Costos de dificultades financieras
 reduce los impuestos que se (quiebra)
 pagan. • Debt overhang: NO inversión en
 proyectos con VPN>0.
 • Incentivos: Reduce sobreinversión • Risk-shifting: inversión en
 del flujo de caja libre. proyectos con VPN<0.
 93 / 125

[pág. 94]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Fricciones
 • Para que la estructura de financiamiento genere valor, debe existir alguna
 imperfección de mercado que afecte los flujos de caja.
 • Impuestos
 • Costos de bancarrota.
 • Problemas de agencia.
 • Asimetrı́as de información.
 94 / 125

[pág. 95]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
El Mercado de los Limones
 • George Akerlof (Nobel 2001)
 • Ejemplo: 5 tipos de Toyota Camrys usados a la venta:
 • Tipo A: valor $8,000
 • Tipo B: valor $6,000
 • Tipo C: valor $5,000
 • Tipo D: valor $4,000
 • Tipo E: valor $2,000
 • Usted quiere comprar un auto, pero no puede identificar su calidad.
 • ¿Cuánto estarı́a dispuesto a pagar si todos los tipos tienen la misma
 probabilidad?
 • ⇒ Promedio equal-weighted: $5,000
 • Pero entonces ¿quiénes estarı́an dispuestos a vender?
 95 / 125

[pág. 96]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
El Mercado de los Limones
 • Sólo aquellos vendedores con un auto de valor $5,000 o inferior
 • Sabiendo esto, ¿cuánto estarı́a dispuesto usted a ofrecer?
 • ⇒ 1/3 × $5,000 + 1/3 × $4,000 + 1/3 × $2,000 = $3,667
 • ¿Pero quiénes querrı́an vender ahora?
 • Sólo aquellos vendedores con un auto de valor $3,667 o inferior
 • Sabiendo esto, ¿cuánto estarı́a dispuesto usted a ofrecer?
 • ⇒ $2,000
 éste es el “market for lemons”: Sólo personas con autos de bajo valor van a
 estar vendiendo
 96 / 125

[pág. 97]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Pero quién más vende su auto en la práctica
 • Las personas que se mudan, que quieren comprar un modelo mejor, que
 necesitan cambiar a un auto más familiar...
 • ¿Cuál es la primera pregunta que usted debiera hacer cuando compre un
 auto usado?
 • ¿Por qué estás vendiendo?
 • Lo mismo debiera aplicar a los mercados financieros
 • Usted debe entender por qué los ejecutivos, insiders, venture capitalists le
 están vendiendo un activo a usted!
 97 / 125

[pág. 98]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
mmmmhhhhh...
 Fuente: El Mercurio
 98 / 125

[pág. 99]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Decisiones de Estructura de Capital como Señales
 • Mercados de capitales perfectos asumen:
 • Inversionistas y gerentes tienen la misma información sobre la firma
 • Las acciones y bonos de la empresa tienen el precio correcto basado en esta
 información
 • En realidad, los gerentes pueden tener información superior
 • En base a esta información, las acciones de las empresas pueden estar sobre
 o subvaloradas
 • ¿Qué implica esto para la estructura de capital?
 • Las decisiones de estructura de capital pueden señalizar la información
 superior de los gerentes a los inversionistas
 • “Una acción vale más que mil palabras”
 99 / 125

[pág. 100]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Acciones como señales
 • ¿Pero qué constituye una señal valiosa?
 • Acciones costosas que comunican información privada no directamente
 observable para otros
 • No emitir acciones aunque esto implique dejar pasar un proyecto con VPN > 0.
 • Tomar deuda: si es una firma solvente no tendrán problemas de hacer el pago, si
 no, podrı́a quebrar (Ross, 1977).
 100 / 125

[pág. 101]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Equity señaliza debilidad
 • Firmas preferirán no emitir acciones cuando están subvaloradas
 • ¿Por qué? Emitir acciones subvaloradas representa un costo para las
 accionistas actuales.
 • Firmas esperarán hasta que el precio sea justo antes de emitir:
 • Vender al precio “correcto” implica que compradores obtienen VPN=0.
 • Firmas preferirán emitir acciones cuando están sobrevaloradas
 • Por esto es importante tener restricciones a “insider trading”
 101 / 125

[pág. 102]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Zynga vs. Facebook
 102 / 125

[pág. 103]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Implicancias de emisión de Equity
 • Quiénes son entonces los que están emitiendo?
 • Si observamos una emisión de acciones, es una buena o mala señal?
 103 / 125

[pág. 104]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Implicancias de emisión de Equity
 • Precio de sus acciones cae cuando anuncian la emisión de acciones
 (alrededor de un 3 %, Asquith and Mullins (1986))
 • Las firmas tratan de emitir acciones cuando las asimetrı́as de información
 son menores. Por ejemplo, después del anuncio de utilidades. La caı́da en
 el precio de las acciones es menor.
 104 / 125

[pág. 105]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Efectos en los precios de anuncios de emisión
 105 / 125

[pág. 106]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Deuda señaliza fortaleza
 • La deuda hace que firma arriesgue quebrar:
 • y el posible despedido de los altos ejecutivos de la firma
 • Gerentes van a endeudarse si tienen confianza en que van a poder cumplir
 con los pagos de la deuda
 • Emitir deuda en general señaliza confianza en el futuro de la firma
 • El valor de la deuda es menos sensible a asimetrı́a de información sobre la
 firma que el valor del equity
 • En otras palabras, heterogeneidad en la calidad de los proyectos afectan al
 valor del equity más que al valor de la deuda
 • Razón: la deuda se paga primero
 106 / 125

[pág. 107]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Un Pecking Order
 • En presencia de asimetrı́as de información emitir acciones es una señal que
 la acción está sobrevalorada
 • Malas oportunidades de inversión
 • Como resultado, la empresa querrá usar fuentes de financiamiento cuyos
 precios son menos sensibles a la asimetrı́a de información:
 1 Utilidades retenidas (alternativa menos sensible)
 2 Deuda
 3 Equity (alternativa más sensible)
 107 / 125

[pág. 108]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Patrones de financiamiento
 • Patrones de financiamiento agregado para gastos de capital para firmas en
 EEUU.
 • En el agregado, empresas tienden a recomprar acciones y emitir deuda.
 • La mayor parte de los gastos de capital se financian con las utilidades
 retenidas.
 Fuente: Federal Reserve Flow of Funds.
 108 / 125

[pág. 109]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo
 • Supongamos que hay 2 tipos de empresas: buenas y malas.
 • Las empresas buenas tienen activos ya instalados que valen $100, y las
 empresas malas tienen activos que valen sólo $20.
 • Los dueños actuales de cada empresa saben perfectamente el valor real de
 los activos ya instalados.
 • El mercado no conoce la calidad de los activos con certeza, si no que
 asigna una probabilidad de 10 % a que la empresa sea buena y 90 % a que
 sea mala.
 • Aparece un proyecto nuevo que requiere una inversión de $1 y retorna $2,
 es decir, este proyecto tiene VPN>0. Todos conocen las caracterı́sticas de
 este nuevo proyecto.
 • Ambas empresas consideran emitir acciones para financiar el nuevo
 proyecto.
 • Suponga que eventualmente los tipos de cada firma serán revelados al
 mercado, pero en ese momento la opción de esta nueva inversión ya no
 existe.
 109 / 125

[pág. 110]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo
 • A la empresa buena le conviene emitir dependiendo de qué precio le asigne
 el mercado a sus acciones.
 pregunta
 • Veamos el caso de la empresa buena: ¿preferirá emitir acciones o dejar
 pasar este proyecto?
 1 Emite para invertir
 2 Deja pasar el proyecto
 3 No sé como responder el problema
 110 / 125

[pág. 111]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo
 • Supongamos inicialmente que el mercado al decidir el precio de una acción
 toma un promedio ponderado de los tipos de empresa posibles. Como no
 hay desacuerdo sobre el nuevo proyecto, éste se contabiliza entero.
 Asumamos que no hay descuento para simplificar:
 P = 100 ∗ 0,1 + 20 ∗ 0,9 + 2 = 30
 111 / 125

[pág. 112]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo
 • Los dueños actuales deben vender acciones por $1 para financiar la
 1
 inversión y por lo tanto retienen una fracción (1 − 30 ) de la propiedad.
 • Los dueños valoran la fracción que retienen en:
  
 1
 1− (100 + 2) = 98,6
 30
 • Si no emiten acciones son dueños de algo vale 100.
 • Por lo tanto, los dueños de la empresa buena deciden no emitir: no les
 conviene diluir la propiedad. El mercado los subvalora al “confundirlos”
 con empresas malas.
 • El mercado sabe que la empresa buena no va a emitir a pesar de que a
 priori no sabe qué empresa es buena o mala.
 • Dejar de emitir acciones funciona como una señal: no emitiendo acciones
 (o emitiendo deuda) le comunico al mercado que soy una empresa buena.
 112 / 125

[pág. 113]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo
 • ¿Y a la empresa mala le conviene emitir?
 pregunta
 • Veamos el caso de la empresa mala: ¿preferirá emitir acciones o dejar
 pasar este proyecto?
 1 Emite para invertir
 2 Deja pasar el proyecto
 3 No sé como responder el problema
 113 / 125

[pág. 114]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Ejemplo
 • El mercado sabe que a las buenas no les conviene emitir y, por lo tanto, la
 empresa al emitir le revela al mercado quien es. El mercado la valora en:
 P = 20 + 2 = 22
 • ¿Les conviene a estos dueños emitir? Sı́:
  
 1
 1− (20 + 2) = 21 vs. 20
 22
 • A la empresa mala siempre le va a convenir emitir porque (por definición
 en este ejemplo) el mercado nunca la puede sub-valorar.
 114 / 125

[pág. 115]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
¿Cuándo emitir?
 • Si la reacción de mercado es usualmente negativa: ¿hay momentos buenos
 para emitir acciones?
 • Observamos que las emisiones se concentran en el tiempo; hay “clusters”
 de emisiones.
 • Estos clusters tienden a coincidir con precios altos (razones como P/U o
 bolsa-libro) .
 • La correlación entre emisiones (normalizadas por mkt cap) y la razón
 bolsa-libro es 0.68 en el mercado americano (1920-2005)
 • Los periodos históricos de más emisiones son 1929-1930 y 1997-2000 justo
 antes de crisis.
 115 / 125

[pág. 116]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Motivos para emitir
 230 J.R. Graham, C.R. Harvey / Journal of Financial Economics 60 (2001) 187}243
 Fig. 7. Survey evidence on some of the factors that a!ect the decision to issue common stock. The
 survey is based on the responses of 392 CFOs.
 either indicates that executives focus more than they should on earnings dilution 116 / 125

[pág. 117]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Patrones temporales
 Fuente: Financial Times
 117 / 125

[pág. 118]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
IPOs (“Initial Public offering”)
 Fuente: El Mercurio (2017)
 118 / 125

[pág. 119]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Resumen
 • Cuando los managers tienen mejor información que los inversionistas, hay
 asimetrı́as de información. Consecuencias:
 • La emisión de acciones es en general una mala señal y los inversionistas
 ajustarán a la baja su visión del precio de la acción y por lo tanto lo que
 están dispuestos a pagar por nuevas acciones (los compradores sufren
 “selección adversa”)
 • Los managers pueden usar deuda para señalizar de manera creı́ble que la
 firma es de “buena calidad”.
 119 / 125

[pág. 120]
Introducción Costo de Capital Modigliani y Miller M&M e Impuestos Modelo de Trade-off Problemas de Agencia
Resumen
 • Es más probable que los managers emitan acciones cuando ellos
 saben/creen que la firma está sobrevalorada
 • El precio de las acciones tenderá a disminuir cuando se anuncie la emisión
 de acciones.
 • Empresas tenderán a emitir acciones cuando las asimetrı́as de información
 sean bajas
 • Managers que crean que la acción de su empresa está subvalorada preferirán
 emitir activos cuyo precio sea menos sensible a asimetrı́as de información
 • Pecking Order:
 1 Utilidades retenidas
 2 Deuda
 3 Acciones
 • Managers de otras empresas imitarán este comportamiento para evitar
 enviar malas señales a los inversionistas.
 120 / 125

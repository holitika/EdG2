# Teoría Financiera · L3 Decisiones

Fuente: clase de Teoría Financiera

[pág. 1]
Mercados Completos Mercados de Activos
 Teorı́a Financiera
 Decisiones bajo incertidumbre
 Consuelo Silva
 Escuela de Administración PUC
 22 de marzo de 2023
 1 / 35

[pág. 2]
Mercados Completos Mercados de Activos
Temas
 1 Utilidad Esperada
 2 Aversión al Riesgo
 3 Optimalidad y Equilibrio
 4 Mercados de Activos
 5 Preferencias Media-Varianza
 2 / 35

[pág. 3]
Mercados Completos Mercados de Activos
Introducción
 • ¿Para dónde vamos?: En qué activos invertir y cómo se determinan los
 precios.
 • Objetivo: entender cómo enfrentamos decisiones de inversión con
 incertidumbre.
 3 / 35

[pág. 4]
Mercados Completos Mercados de Activos
Valor Esperado
 • Un activo tiene pagos en un cierto tiempo en el futuro, que denotamos por
 X.
 • Los flujos son inciertos por lo que X es una variable aleatoria
 • Pensemos que hay n escenarios alternativos
 • Cada escenario tiene probabilidad de ocurrencia πi y pago xi
 • El valor esperado de una cantidad incierta es el promedio ponderado de los
 distintos valores que puede tomar la variable en cuestión:
 E(X) = π1 x1 + π2 x2 + . . . + πn xn
 4 / 35

[pág. 5]
Mercados Completos Mercados de Activos
Describiendo el Riesgo
Variabilidad
 • La variablidad la podemos medir la varianza o la volatilidad (raı́z cuadrada
 de la varianza).
 h i
 σX2 = E (X − E(X))2 = π1 (x1 − E(X))2 + . . . + πn (xn − E(X))2
 • La varianza es el promedio ponderado de las desviaciones (con respecto al valor
 esperado).
 5 / 35

[pág. 6]
Mercados Completos Mercados de Activos
Maximización de Utilidad Esperada
 • Gráficos que muestran tres tipos de relación entre flujos y utilidad
 Utilidad Utilidad Utilidad
 Flujo Flujo Flujo
 • Gráfico (A): utilidad marginal decrece, es decir, la utilidad adicional que
 reporta un incremento de $1000 es menor a medida que crece el flujo de
 dinero.
 • Gráfico (B): utilidad marginal no depende del flujo de dinero, es siempre la
 misma (constante).
 • Gráfico (C): en este caso la utilidad marginal crece con el flujo de dinero.
 6 / 35

[pág. 7]
Mercados Completos Mercados de Activos
Maximización de Utilidad Esperada
 • Maximización de utilidad esperada: al elegir entre diversas alternativas en
 situaciones de incertidumbre, las personas eligen aquella que maximiza su
 utilidad esperada.
 • Los inversionistas evalúan el valor de un activo pensando en la utilidad que
 derivan de cada pago.
 • Usamos la función de utilidad esperada
 E[U (w)] = π1 U (w1 ) + π2 U (w2 ) + · · · + πn U (wn )
 donde wi es la riqueza final si ocurre el evento i
 7 / 35

[pág. 8]
Mercados Completos Mercados de Activos
Utilidad Esperada
Actitudes Frente al Riesgo
 • Ejemplo: Un individuo debe elegir entre las siguientes opciones:
 1 Opción 1: Ganar $200 con certeza
 2 Opción 2: Ganar ya sea $300 o $100, ambos con probabilidad 0.5 (valor
 esperado es $200)
 • ¿Qué opción prefiere Ud.? Depende si es
 • Averso al riesgo
 • Neutral al riesgo
 • Amante del riesgo
 8 / 35

[pág. 9]
Mercados Completos Mercados de Activos
Utilidad Esperada
Actitudes Frente al Riesgo
 • Opción 1: Ganar $200 con certeza. Opción 2: Ganar ya sea $300 o $100,
 ambos con probabilidad 0.5.
 Utilidad Utilidad Utilidad
 Flujo Flujo Flujo
 • Según los gráficos, la utilidad de cada opción es:
 • Gráfico A:
 U ($200) = 165 versus 0,5U ($300) + 0,5U ($100) = 140
 • Gráfico B:
 U ($200) = 120 versus 0,5U ($300) + 0,5U ($100) = 120
 • Gráfico C:
 U ($200) = 75 versus 0,5U ($300) + 0,5U ($100) = 97,5
 9 / 35

[pág. 10]
Mercados Completos Mercados de Activos
Utilidad Esperada
Actitudes Frente al Riesgo – Averso al riesgo
 • Un individuo se dice averso al riesgo si es que prefiere una inversión
 con flujo seguro, a tomar una inversión riesgosa con el mismo flujo
 esperado.
 • Se supone que es la actitud más común. Consistente con comportamiento
 observado en muchas situaciones
 • Recordando utilidades:
 • A: U ($200) = 165 versus 0,5U ($300) + 0,5U ($100) = 140
 • B: U ($200) = 120 versus 0,5U ($300) + 0,5U ($100) = 120
 • C: U ($200) = 75 versus 0,5U ($300) + 0,5U ($100) = 97,5
 • Comportamiento consistente con gráfico A. Aversos al riesgo tienen una
 utilidad marginal decrecience. Es decir, se puede representar con una
 función U (w) que es cóncava (U0 (w) decreciente en w).
 10 / 35

[pág. 11]
Mercados Completos Mercados de Activos
Utilidad Esperada
Actitudes Frente al Riesgo – Neutro al riesgo
 • Un individuo se dice neutro al riesgo si es que le da lo mismo ganar
 una suma fija o recibir una suma incierta cuyo valor esperado es igual
 a la suma fija.
 • Como veı́amos en el ejemplo, un individuo neutro al riesgo es indiferente
 entre la opción 1 y 2, ya que en ambos casos su ingreso esperado es $200
 • Recordando las utilidades:
 • A: U ($200) = 165 versus 0,5U ($300) + 0,5U ($100) = 140
 • B: U ($200) = 120 versus 0,5U ($300) + 0,5U ($100) = 120
 • C: U ($200) = 75 versus 0,5U ($300) + 0,5U ($100) = 97,5
 • Consistente con gráfico B. Neutrales al riesgo tienen utilidad marginal
 constante. En términos de U (w) corresponde a U0 (w) constante.
 11 / 35

[pág. 12]
Mercados Completos Mercados de Activos
Utilidad Esperada
Actitudes Frente al Riesgo – Preferente al riesgo
 • Un individuo se dice amante del riesgo si entre un ingreso incierto con
 valor esperado igual al ingreso fijo, prefiere el ingreso incierto.
 • Comportamiento menos común de observar
 • Recordando las utilidades:
 • A: U ($200) = 165 versus 0,5U ($300) + 0,5U ($100) = 140
 • B: U ($200) = 120 versus 0,5U ($300) + 0,5U ($100) = 120
 • C: U ($200) = 75 versus 0,5U ($300) + 0,5U ($100) = 97,5
 • Consistente con gráfico C. En términos de U (w) corresponde a U0 (w)
 creciente en w.
 12 / 35

[pág. 13]
Mercados Completos Mercados de Activos
Temas
 1 Utilidad Esperada
 2 Aversión al Riesgo
 3 Optimalidad y Equilibrio
 4 Mercados de Activos
 5 Preferencias Media-Varianza
 13 / 35

[pág. 14]
Mercados Completos Mercados de Activos
Aversión al riesgo
Concepto
 • Al averso al riesgo le duelen más las pérdidas de lo que le gustan las
 ganancias: prefiere evitar una pérdida de $10 antes que generar una
 ganancia de $10.
 • Enfrentado a una ganancia o pérdida de igual monto, la pérdida genera un
 cambio mayor en la utilidad (en valor absoluto).
 • Esto también implica que existirá un premio por riesgo.
 • El premio por riesgo es la suma de dinero que una persona aversa al riesgo
 está dispuesta a pagar para evitar enfrentar tomar una decisión bajo
 incertidumbre.
 14 / 35

[pág. 15]
Mercados Completos Mercados de Activos
Aversión al riesgo
Premio por riesgo
 • Volvamos a nuestro ejemplo, opción 1 ganar $200 con certeza,
 U ($200) = 165. Opción 2 ganar ya sea $300 o $100 con igual
 probabilidad. Utilidad esperada $140
 • ¿Qué ingreso sin riesgo me reportarı́a la misma utilidad que $140?
 Utilidad
 Flujo Flujo
 Esperado
 • El flujo sin riesgo que me reporta la misma utilidad que el escenario incierto
 es $160. Esto se conoce como equivalente cierto
 • Equivalente cierto: es el nivel de riqueza que deja al individuo indiferente
 entre tomar este monto sin incertidumbre y participar en una loterı́a
 15 / 35

[pág. 16]
Mercados Completos Mercados de Activos
Aversión al riesgo
Premio por riesgo
 • ¿Cuánto está dispuesto a sacrificar con objeto de evitar la situación con
 ingreso incierto?
 Utilidad
 Flujo Flujo
 Esperado
 • Estarı́a dispuesto a sacrificar $40, que corresponden a la diferencia entre el
 ingreso de $200 y el ingreso cierto (seguro) que le resporta la misma
 utilidad que la situación incierta.
 • Este es el premio por riesgo, es decir, es la diferencia entre el pago esperado
 y el equivalente cierto.
 16 / 35

[pág. 17]
Mercados Completos Mercados de Activos
Aversión al Riesgo
Medidas
 • El nivel de aversión al riesgo depende de la curvatura de la función U (·).
 Para medir la aversión al riesgo queremos mirar U00 (w), la tasa a la que
 U0 (w) decrece con w.
 • Coeficiente de aversión absoluta al riesgo (ARA)
 U00 (w)
 A(w) = −
 U 0 (w)
 • A mayor ARA menor será el monto total de su riqueza que un individuo
 invertirá en activos riesgosos.
 • Coeficiente de aversión relativa al riesgo (RRA)
 U00 (w)
 R(w) = − w = wA(w)
 U 0 (w)
 • A mayor RRA menor será la proporción de su riqueza que un individuo
 invertirá en activos riesgosos.
 s
 17 / 35

[pág. 18]
Mercados Completos Mercados de Activos
Temas
 1 Utilidad Esperada
 2 Aversión al Riesgo
 3 Optimalidad y Equilibrio
 4 Mercados de Activos
 5 Preferencias Media-Varianza
 18 / 35

[pág. 19]
Mercados Completos Mercados de Activos
Activos Arrow-Debreu (AD)
Definición
 • Seguiremos usando utilidad esperada. Supongamos:
 • Dos perı́odos: t = 0 (hoy) y t = 1 (mañana).
 • 2 escenarios distintos “estados de la naturaleza”: s = 1 y s = 2
 • Activo Arrow-Debreu: paga 1 unidad de un bien especificado (que puede
 ser dinero) si y sólo si en t = 1 ocurre un estado de la naturaleza
 determinado.
 • Llamemos qs al precio de un activo AD hoy (t = 0) que paga $1 en t = 1
 si estado s ocurre.
 • Estos precios nos ayudarán a entender los precios de activos
 19 / 35

[pág. 20]
Mercados Completos Mercados de Activos
Activos Arrow-Debreu
Ejemplo
 Supongamos que no hay oportunidades de arbitraje:
 • Cuál es el precio de una acción (accion1) que paga $2 en s = 1, y $0 en
 s=2
 Activos
 accion1 ... AD1 AD2
 Pago en s1 2 1 0
 Pago en s2 0 0 1
 Precio hoy Paccion1 q1 q2
 • Tener esta acción es equivalente a un portfolio con dos AD1 .
 • Entonces por LOOP: Paccion1 = 2 q1
 20 / 35

[pág. 21]
Mercados Completos Mercados de Activos
Activos Arrow-Debreu
Ejemplo
 • En general, si los precios de los activos AD son conocidos, podemos
 ponerle precio a cualquier otro activo dados sus pagos en cada estado de
 la naturaleza.
 • Pregunta: ¿Cuál es el precio de una acción (accion2) que paga $1 en
 s = 1, y $3 en s = 2. (Suponga que no hay oportunidades de arbitraje)
 Activos
 accion2 ... AD1 AD2
 Pago en s1 1 1 0
 Pago en s2 3 0 1
 Precio hoy Paccion2 q1 q2
 A Paccion2 = q1 + q2
 B Paccion2 = q1 + 3 q2
 C Paccion2 = q1 × 3 q2
 D No sé como calcularlo.
 21 / 35

[pág. 22]
Mercados Completos Mercados de Activos
Mercados Completos
Concepto
 • Una caracterı́stica esencial de los activos AD es el potencial de replicar
 pagos de cualquier activo
 • Consideremos el mismo caso de dos perı́odos y dos estados
 • Si tenemos activos AD para ambos estados, todo activo puede ser valorado
 por arbitraje
 • Esto corresponde a una situación donde tenemos mercados completos
 22 / 35

[pág. 23]
Mercados Completos Mercados de Activos
Mercados Completos
Concepto
 • Un mercado es completo si a partir de los activos existentes podemos
 encontrar el precio del activo puro (AD) para cada estado.
 • Necesitamos tantos activos con pagos linealmente independientes como
 estados posibles.
 • Si hay menos activos que número de estados, inmediatamente sabemos que
 el mercado es incompleto
 • Si hay igual o mayor número de activos que de estados, tenemos que
 determinar cuántos son linealmente independientes.
 • Si X es la matrix de pagos, entonces matemáticamente:
 ∃X −1 ⇔ rango(X) = S
 ⇔ ∃ S activos con pagos L.I.
 23 / 35

[pág. 24]
Mercados Completos Mercados de Activos
Activos AD–Problema del Agente
 • Supongamos inversionista con una riqueza W0
 • La probabilidad de ocurrencia de cada estado mañana es π1 y π2
 • Llamaremos q1 y q2 a los precios de los activos AD en t = 0 (precios de
 los estados) que pagan si ocurre el estado 1 ó 2 respectivamente
 • El inversionista compra w1 acciones del activo AD que paga en el
 escenario 1, y w2 acciones del que paga en el escenario 2
 ⇒ Como cada activo AD paga 1 en el estado respectivo, su riqueza en
 cada estado será w1 y w2
 24 / 35

[pág. 25]
Mercados Completos Mercados de Activos
Activos AD
Problema del Agente
 • El inversionista toma estos precios como dados y resuelve:
 máx U = E[u(w)] = π1 u(w1 ) + π2 u(w2 )
 w1 ,w2
 sujeto a: W0 = q1 w1 + q2 w2
 • Entonces:
 máx π1 u(w1 ) + π2 u(w2 ) + λ(W0 − q1 w1 − q2 w2 )
 w1 ,w2
 • Las condiciones de primer orden (CPO) son
 π1 u0 (w1 ) = λq1
 π2 u0 (w2 ) = λq2
 • Más la restricción presupuestaria
 25 / 35

[pág. 26]
Mercados Completos Mercados de Activos
Activos AD
Problema del Agente
 • Usando las CPO podemos escribir:
 π 1 u 0 ( w1 ) π u 0 ( w2 )
 = 2
 q1 q2
 • El agente iguala la utilidad marginal “esperada” por peso ($) en cada
 estado
 26 / 35

[pág. 27]
Mercados Completos Mercados de Activos
Optimalidad
Precios activos AD y probabilidades
 • Podemos reescribir las CPO:
 u0 (w1 ) q1 /π1
 =
 u0 (w2 ) q2 /π2
 | {z } | {z }
 Utilidad marginal (relativa) Razón precio-probabilidad (relativa)
 • Plan óptimo:
 • Invertir menos en activos que tienen precios elevados en relación a su
 probabilidad de ocurrir
 • Hacer esto hasta que la utilidad marginal en esos estados sea suficiente para
 justificar su alta razón precio-probabilidad
 27 / 35

[pág. 28]
Mercados Completos Mercados de Activos
Temas
 1 Utilidad Esperada
 2 Aversión al Riesgo
 3 Optimalidad y Equilibrio
 4 Mercados de Activos
 5 Preferencias Media-Varianza
 28 / 35

[pág. 29]
Mercados Completos Mercados de Activos
Desde precios de activos AD a precios de cualquier activo
 • Sigamos con el ejemplo de dos estados.
 • Hasta el momento hemos encontrados los precios de cada estado q1 y q2
 (precios de los activos AD).
 • ¿Pero cuál es la relación con activos más generales?
 • El precio de un activo i que paga $zi,1 en el estado 1 y $zi,2 en el estado 2,
 está dado por:
 pi = q1 zi,1 + q2 zi,2
 $zi,j
 (OJO: $1 = zi,j , cantidad de activos ADi,j )
 29 / 35

[pág. 30]
Mercados Completos Mercados de Activos
Mercados de Activos
Problema de optimización
 • Veamos el problema del inversionista:
 • Suponga un activo i (i=1,2) que paga zi,1 en el estado 1 y zi,2 en el estado
 2
 • Ahora tenemos dos activos no AD =⇒ pagan en ambos estados en
 distintas proporciones.
 • Sean a1 y a2 el número de activos 1 y 2 que compra el inversionista, con
 precios hoy p1 y p2 .
 máx π1 u(a1 z1,1 + a2 z2,1 ) + π2 u(a1 z1,2 + a2 z2,2 )
 a1 ,a2
 + λ(W − a1 p1 − a2 p2 )
 donde zi,s es el pago del activo i en el estado s.
 • Las CPO son
 z1,1 π1 u0 (w1 )+z1,2 π2 u0 (w2 ) = λp1 (1)
 0 0
 z2,1 π1 u (w1 )+z2,2 π2 u (w2 ) = λp2 (2)
 30 / 35

[pág. 31]
Mercados Completos Mercados de Activos
Mercados de Activos
Intrución CPO
 • Llegamos a la siguiente condición
 p1 z π u0 (w ) + z1,2 π2 u0 (w2 )
 = 1,1 1 0 1 (3)
 p2 z2,1 π1 u (w1 ) + z2,2 π2 u0 (w2 )
 31 / 35

[pág. 32]
Mercados Completos Mercados de Activos
Temas
 1 Utilidad Esperada
 2 Aversión al Riesgo
 3 Optimalidad y Equilibrio
 4 Mercados de Activos
 5 Preferencias Media-Varianza
 32 / 35

[pág. 33]
Mercados Completos Mercados de Activos
Media-Varianza
Motivación
 • Hasta ahora: utilidad consumo en distintos estados
 • Necesita describir todos y cada uno de los estados
 • ¿Podemos resumir esta información en menos variables?
 • Podemos usar variables aletatorias y distribuciones de probabilidad
 • Parámetros de distribuciones: ejemplo, Bernoulli –moneda al aire
 • Tradicionalmente usamos
 • Media – retorno esperado
 • Varianza – “volatilidad”
 • ¿Es posible resumir sólo en estos parámetros?
 33 / 35

[pág. 34]
Mercados Completos Mercados de Activos
Preferencias Media-Varianza
Como aproximación a preferencias generales
 • Supuesto: pagos inciertos, media µ, varianza σ2
 • Aproximación de Taylor de función u(c) alrededor de µ
 u0 ( µ ) u00 (µ) u000 (µ)
 u(c) =u( µ ) + (c − µ ) + (c − µ )2 + (c − µ )3 + . . .
 1! 2! 3!
 • Calculamos E(u(c)),
 u0 ( µ ) u00 (µ)
 E(u(c)) =u(µ) + E((c − µ)) + E((c − µ)2 )
 1! | {z } 2! | {z }
 =0 = σ2
 u000 (µ)
 + E((c − µ)3 ) + . . .
 3!
 u00 (µ) 2 u000 (µ)
 U =u( µ ) + σ + E((c − µ)3 ) + . . . (4)
 2! 3!
 000
 • Si preferencias tiene u y mayores todas iguales a 0 −→ µ y σ resumen 2
 información
 • Si µ y σ2 resumen toda la información relevante para comparar loterı́as
 34 / 35

[pág. 35]
Mercados Completos Mercados de Activos
Preferencias Media-Varianza
Una forma funcional
 • Preferencias “cuadráticas” definidas sobre media y varianza
 a
 U ({c}) =E(u(c)) = E(c) − V (c), a>0 (5)
 2
 • Definamos:
 • µc = E(c)
 • σ2 = V (c) − varianza
 • σ − desviación estándar
 • Racionalización: aproximación a funciones de utilidad más generales
 35 / 35

# Teoría Financiera · L1 Intro

Fuente: clase de Teoría Financiera

[pág. 1]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
 Teorı́a Financiera
 Introducción a los Mercados Financieros
 Consuelo Silva
 Escuela de Administración PUC
 6 de marzo de 2024
 1 / 33

[pág. 2]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Temas Administrativos
 • Ayudantı́a: Viernes módulo 6
 • Atención de alumnos:
 • Jueves 16:00pm a 17:20pm
 • Fijar por correo reunión en otro horario
 • Ir a golpear puerta. . . opción riesgosa
 • ¿Qué esperar de este curso?
 • Reglas del juego
 • Enfoque: mezclar intuición y formalidad
 2 / 33

[pág. 3]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Temas Administrativos
 • Evaluaciones
 • Tareas 20 % (10 % cada una)
 • Pruebas y examen: 80 % (25 % cada prueba, 30 % el examen)
 • Todo cuenta en promedio final
 • Y las tareas pueden hacerlos reprobar el curso
 • Toda tarea debe ser entregada dentro del plazo, sin excusas
 • Pregunta más frecuente: ¿son muy difı́ciles las pruebas?
 • Son (relativamente) largas
 • Tareas
 • Grupos definidos por ustedes (3 personas, mismas todo el semestre)
 • Informe escrito más respaldo de trabajo con datos cuando corresponda
 • Entregar vı́a canvas
 • Preguntas más largas que las de pruebas + Preguntas con datos +
 Preguntas tipo prueba
 • Pueden trabajar en grupos grandes PERO informe debe ser redactado por
 separado por cada grupo
 3 / 33

[pág. 4]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Anuncios y otros
 • Revisar perı́odicamente el calendario en Canvas
 • Secciones
 4 / 33

[pág. 5]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Otra Información
 • Profesor
 • Assistant Professor PUC
 • Ing. Comercial y Magister en Economı́a PUC
 • PhD Economı́a Tilburg University
 • Correo: consuelosilva@uc.cl
 • Areas de investigación: intermediación financiera, regulación bancaria y
 estabilidad financiera
 • Materiales
 • Libros de texto: apoyo pero no lectura obligatoria
 • ¿Preguntas?
 5 / 33

[pág. 6]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Temario
 1 Algunas preguntas que estudian las finanzas
 2 Estructura general de los mercados financieros
 3 Retornos: definición, real vs. nominal, portafolios
 4 Indices Accionarios
 • Lecturas: BKM caps. 1 y 5 (incluyendo apéndice)
 6 / 33

[pág. 7]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
¿Qué estudian las finanzas?
 Fuente: CBSnews, 26 de Julio 2018.
 7 / 33

[pág. 8]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
¿Qué estudian las finanzas?
 Fuente: Financial times, 3 de Febrero 2020.
 8 / 33

[pág. 9]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
¿Qué estudian las finanzas?
 9 / 33

[pág. 10]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
¿Qué estudian las finanzas?
 Muchas preguntas. . . Algunas preguntas que nosotros estudiaremos:
 • ¿Cuál deberı́a ser precio de una acción de la empresa XYZ?
 • Más general, ¿existe alguna razón o variable que pueda explicar la
 evolución de los precios de distintos activos financieros?
 • ¿Cómo explicamos las decisiones financieras de las personas y hogares?
 • ¿Existen ciertos instrumentos/activos financieros que deberı́an formar
 parte importante de nuestro portafolio?
 • ¿Está toda la información reflejada en los precios de mercado de los
 activos?
 • ¿Existe alguna ventaja para una firma de usar financiamiento accionario
 (capital) versus deuda?
 • ¿Pueden existir conflictos entre la administración y los dueños de una
 empresa? ¿O entre los dueños?
 10 / 33

[pág. 11]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Finanzas y el trabajo académico
 • Las finanzas son un gran área dentro de la economı́a
 • Dentro de la economı́a enfoque en temas relacionados a transacciones que
 involucran tiempo e incertidumbre
 • Por ej. deuda, compra de activos con promesas de pago a futuro
 • Avances de las finanzas están marcados por ciertos eventos especiales
 1 Gran Depresion: burbuja, corrida, colapso mercado financiero
 2 Markowtiz y la teorı́a de portafolio; Modigliani-Miller y la estructura de
 capital y polı́tica de dividendos; Sharpe, Lintner y Black y el CAPM
 3 Merton, Black y Scholes y (ausencia de) arbitraje, derivados y finanzas en
 tiempo continuo
 4 Microestructura e ingenierı́a financiera
 5 Interacción con otras áreas de economı́a: macroeconomı́a, economı́a
 internacional, organización industrial, . . .
 6 Crisis subprime y la “Gran recesión”
 • Otros: inclusión financiera/alfabetización financiera, finanzas de hogares
 (household o consumer finance), intermediación financiera y estabilidad
 financiera.
 11 / 33

[pág. 12]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Mercados Financieros
Mercados financieros
Estructura
 • Los activos financieros entregan
 • derechos sobre los flujos
 • y/o propiedad sobre activos reales
 • Estos activos se transan en mercados financieros
 • Transacciones en mercado financiero permiten mover fondos entre
 ahorrantes y los que demandan fondos
 • Intermediación e intermediarios financieros
 • Ahorrantes son tı́picamente personas; demandantes, empresas.
 • Intermediarios financieros (en teorı́a) facilitan flujo de fondos de varias
 maneras:
 • Información
 • Creación de nuevos instrumentos
 • Monitoreo de inversiones reales
 12 / 33

[pág. 13]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Definición
Retorno: Definición
 • Medida usual para evaluar desempeño de activos e inversiones
 • Tipico ejemplo en Chile: retorno de los fondos de pensiones
 • Distintas “definiciones” de retorno: plazos, “tiempo”
 • Antes de definir retornos, introduzcamos un poco de notación
 • Pt : precio de un activo financiero en t
 • Dt : dividendo pagado por un activo financiero en t
 • Ahora podemos definir el retorno bruto entre t y t + 1, (1 + Rt+1 ), de un
 activo:
 Pt+1 + Dt+1 Pt+1 Dt + 1
 1 + Rt + 1 ≡ = +
 Pt P P
 | {zt } | {zt }
 Ganancia de cap. div. yield
 • El retorno neto es Rt+1
 13 / 33

[pág. 14]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Algunas Definiciones
Retorno Logaritmico
 • El retorno logaritmico, rt , es sencillamente el logaritmo natural del retorno
 bruto
  
 Pt + Dt
 rt ≡ ln(1 + Rt ) = ln
 Pt−1
 • En general, se considera que rt es una aproximación a Rt
 • Esto se deriva del hecho que
 ln(1 + ϵ) ≈ ϵ
 si ϵ es “pequeño” (cercano a 0)
 • ¿Qué tan buena es la aproximación?
 • para 0,1, ln(1 + 0,1) es 0,09531
 • para 0,01, ln(1,01) es 0,00995
 • para 0,5, ln(1,5) es 0,405465
 • Aproximación ayuda a calcular retornos netos y múltiples perı́odos
 • Se debe recordar que son aproximadamente iguales
 14 / 33

[pág. 15]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Algunas Definiciones
Retorno Logarı́tmico (cont.)
 1
 0.5
 -0.5 -0.25 0 0.25 0.5 0.75 1
 -0.5
 -1
 15 / 33

[pág. 16]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Algunas Definiciones
Retornos multiperı́odos
 • Supongamos que queremos evaluar el desempeño de un activo en un
 perı́odo de 10 años, ¿cuál es el retorno?
 • Usamos el retorno entre t y t + 10
 • ¿Cuál es la idea detrás de esto?
 • En general para comparaciones sobre N perı́odos pensamos esto como N
 inversiones de 1 perı́odo
 • En el caso de 2 perı́odos, retorno bruto de invertir entre t y t + 1 retorno es
 1 + Rt+1
 • Reinvertimos en t + 1 hasta t + 2 retorno neto es Rt+2
 • Esto nos da el retorno neto entre t y t + 2, Rt,t+2 ,
 1 + Rt,t+2 ≡ (1 + Rt+1 ) (1 + Rt+2 )
 • Equivalente a N inversiones consecutivas en el mismo activo:
 • Cada perı́odo se cierra la posición anterior y se vuelve a invertir todo el monto
 recibido
 16 / 33

[pág. 17]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Algunas Definiciones
Retornos multiperı́odos (cont.) - Tasa equivalente
 • Tasa equivalente por perı́odo (mes por ejemplo):
 q
 1 + Rmes
 t,t+2 = (1 + Rt+1 ) (1 + Rt+2 )
 • Usando retornos logarı́tmicos y nuestra aproximación obtenemos que
 Tasa equivalente:
 rmes
 t,t+2 = (1/2) × [ln (1 + Rt+1 ) + ln (1 + Rt+2 )]
 = (1/2) × [rt+1 + rt+2 ]
 Tasa multiperiodo:
 rt,t+2 = [ln (1 + Rt+1 ) + ln (1 + Rt+2 )]
 = rt+1 + rt+2
 • Retorno logarı́tmico multiperı́odo es suma de retornos logarı́tmicos
 • Retorno logarı́tmico equivalente mensual es promedio simple
 • Pero tasa equivalente es el promedio geométrico de los retornos brutos de
 cada perı́odo
 17 / 33

[pág. 18]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Real vs. Nominal
Retornos nominales versus reales
 • Retornos fueron definidos usando Pt que es el precio del activo en t
 • Pero valor de $1 en distintos perı́odos no es el mismo
 • Existencia de inflación significa que el valor real de $1 cambia en el tiempo
 • Se pueden comprar menos “bienes”
 • Necesitamos diferenciar retornos en pesos de retornos “reales”
 • Se usa una medida de la evolución del poder adquisitivo: usualmente el
 ı́ndice de precios al consumidor –IPC
 • La inflación en el perı́odo t, Πt es
 IPCt
 1 + Πt =
 IPCt−1
 18 / 33

[pág. 19]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Real vs. Nominal
Retornos nominales versus reales (cont.)
 • Definimos el retorno real como
 Pt + 1 + D t + 1
 IPCt+1
 1 + Rreal
 t+1 = Pt
 IPCt
 1 + Rt + 1 1 + Rt + 1
 = =
 IPCt+1 1 + Π t+1
 IPCt
 • También podemos usar los retornos logarı́tmicos
 • Tomamos la última expresión y aplicamos logaritmo a ambos lados
  
 rreal
 t+1 ≡ ln 1 + Rt+1
 real
 = ln (1 + Rt+1 ) − ln (1 + Πt+1 )
 = rt + 1 − π t + 1
 donde πt+1 está definida como ln (1 + Πt+1 )
 19 / 33

[pág. 20]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Ret. Portafolios
Retorno de un portafolio
 • Muchas veces estamos interesados en el retorno de un conjunto de activos
 o de instrumentos
 • Un portafolio es un conjunto de activos con una cierta caracterı́stica en
 común o que se transan en un mercado común
 • Si podemos calcular el precio del portafolio, el retorno se calcula igual que
 el de un activo
 • Flujos en un perı́odo dividido por el costo de adquirir el portafolio hoy
 • Pero también podemos obtener el retorno del portafolio como función del
 retorno de los activos
 • Si tenemos un portafolio con una acción de la empresa A y otra de la
 empresa B
 =⇒ retorno del portafolio es un promedio de retornos de las acciones
 • En particular tenemos que si hay dos activos, A y B, en el portafolio e
 invertimos una fracción α en el activo A, entonces
 1 + Rport
 t =α(1 + RA B
 t ) + (1 − α )(1 + Rt ) (1)
 20 / 33

[pág. 21]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Ret. Portafolios
Ejemplo: Portafolio de dos acciones
 • Los ponderadores son fáciles de obtener
 • Pensemos en la construcción del portafolio (suponiendo que son dos
 acciones)
 • Compramos a acciones de A, b acciones de B
 • Precios de mercado son PA B
 t y Pt
 • Costo del portafolio es Pport
 t = PA B
 t × a + Pt × b
 • Supongamos que no hay dividendos y que los precios son Pit+1
 • Entonces el flujo es PA B
 t + 1 × a + Pt + 1 × b
 • El retorno bruto está dado por
 PA B
 t + 1 × a + Pt + 1 × b
 1 + Rport
 t+1 =
 PA B
 t × a + Pt × b
 PA PA
 t+1 × a PB PB × b
 = t
 A A B
 + tB A t+1 B
 Pt Pt × a + Pt × b Pt Pt × a + Pt × b
 PA
 t+1 PAt ×a
 PB PB × b
 = + t+B1 A t
 PAA B
 Pt × a + Pt × b
 t Pt Pt × a + PBt × b
 = (1 + RA B
 t+1 ) α + (1 + Rt+1 )(1 − α )
 21 / 33

[pág. 22]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Ret. Portafolios
Retorno de un portafolio: fórmula general
 • Ecuación (1) se puede generalizar
 n
 1 + Rport
 t = ∑ αi (1 + Rit ) (2)
 i=1
 donde n es el número de activos y ∑i αi = 1 (o 100 %)
 • ¿Qué tipo de activos son básicamente un portafolio?
 • Fondos mutuos
 • Los ı́ndices accionarios pueden ser formulados como portafolios de acciones
 22 / 33

[pág. 23]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Indices como portafolios
 • Indices son portafolios que representan el retorno de un mercado
 • IPSA para el mercado de la Bolsa de Santiago
 • MERVAL – Buenos Aires; BOVESPA – Sao Paulo; DJIA –NYSE
 • Indices más especı́ficos, ej. ı́ndices sectoriales –NASDAQ
 • La diferencia más clara entre estos ı́ndices son los activos incluidos
 • Pero incluso con los mismos activos, ponderadores (αi ) pueden diferir
 23 / 33

[pág. 24]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Tipos
Tipos de Indices
 • Básicamente tres tipos:
 • Equal weighted
 • Price weighted
 • Value weighted
 • Equal weighted: la riqueza se invierte en partes en iguales en cada uno de
 lo n activos
 1
 αi = , ∀i = 1, . . . , n
 n
 • Price weighted: el ponderador está dado por la razón entre el precio de
 los activos y la suma de los precios de todos los activos
 Pi
 αi =
 P1 + . . . + Pn
 24 / 33

[pág. 25]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Tipos
Tipos de Indices (cont)
 • Value weighted: el ponderador corresponde a la razón entre el valor de
 mercado de la firma y el valor de mercado del total de firmas
 Vi
 αi =
 V1 + . . . + Vn
 donde Vi = Pi Ai y Ai es el número de acciones emitidas de i
 25 / 33

[pág. 26]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Tipos
Composición IPSA
Informativo de Agosto de 2018
 Fuente: Bolsa de Comercio de Santiago, 2018.
 26 / 33

[pág. 27]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Tipos
Detalles IPSA
Informativo de Agosto de 2018
 Fuente: Bolsa de Comercio de Santiago, 2018.
 27 / 33

[pág. 28]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Estadı́sticas históricas de retornos
 • Dos métricas usuales para evaluar retornos son el promedio (o media) y la
 desviación estándar:
 1 T
 T t∑
 R= Rt
 =1
 v
 T
 u
 u 1 2
 σ=t ∑
 T − 1 t=1
 Rt − R
 • Como su nombre lo sugiere, σ es la desviación tı́pica que una variable
 experimenta respecto de su media.
 • Si una distribución es normal, el retorno observado estará aprox. un:
 • 68 % de las veces dentro de ± una desviación estándar de R
 • 95 % de las veces dentro de ± dos desviación estándar de R
 • 99.7 % de las veces dentro de ± tres desviación estándar de R
 • Muchas cosas se distribuyen aproximadamente normal (¡de ahı́ el nombre!)
 • Retornos accionarios diarios o semanales tienen distribuciones con colas un
 poco más abultadas
 28 / 33

[pág. 29]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Estadı́sticas históricas de retornos
Retornos históricos en USA
 • Consideremos los retornos anuales promedio de un ı́ndice accionario
 value-weighted de cobertura amplia en USA y los Treasury bills entre 1926
 y 2012
 Retornos T-bills Acciones
 Nominales 3.59 % 8.01 %
 Reales 0.63 % 4.97 %
 • En términos reales, el premio por riesgo accionario (equity premium) fue
 4.3 % en USA.
 • La desviación estándar histórica de los retornos accionarios reales es de
 aprox 21 % anual en USA.
 29 / 33

[pág. 30]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Estadı́sticas históricas de retornos
Retornos Nominales Históricos en USA - 1927-2013
 30 / 33

[pág. 31]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Estadı́sticas históricas de retornos
Retornos (nominales) históricos en Chile
 Retornos del IPSA han sido bastante buenos en las últimas décadas,
 especialmente a comienzos de los 1990s, pero con volatilidad
 Año Retorno IPSA Año Retorno IPSA Año Retorno IPSA
 1989 62 % 1999 43 % 2009 51 %
 1990 65 % 2000 -4 % 2010 38 %
 1991 166 % 2001 9% 2011 -15 %
 1992 21 % 2002 -15 % 2012 3%
 1993 69 % 2003 48 % 2013 -14 %
 1994 42 % 2004 21 %
 1995 1% 2005 9%
 1996 -12 % 2006 37 %
 1997 13 % 2007 13 %
 1998 -23 % 2008 -22 %
 • Promedio 1989-2013: 24.3 %
 • Desviación Estándar 1989-2013: 41.0 %
 31 / 33

[pág. 32]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Estadı́sticas históricas de retornos
Retornos (reales) históricos en Chile
 Año Retorno IPSA Año Retorno IPSA Año Retorno IPSA
 1989 34 % 1999 40 % 2009 53 %
 1990 30 % 2000 -8 % 2010 34 %
 1991 124 % 2001 6% 2011 -19 %
 1992 8% 2002 -18 % 2012 1%
 1993 50 % 2003 47 % 2013 -17 %
 1994 30 % 2004 18 %
 1995 -6 % 2005 5%
 1996 -17 % 2006 34 %
 1997 6% 2007 5%
 1998 -26 % 2008 -27 %
 • Promedio 1989-2013: 15.5 %
 • Desviación Estándar 1989-2013: 33.6 %
 32 / 33

[pág. 33]
Temario Introducción Retornos Indices Estadı́sticas Históricas de Retornos
Retornos históricos en Chile
IPSA, log10-nivel mensual 1980-2014:1 (1980:12 = 100)
 5
 4
 3
 2
 1
 1980m1 1985m1 1990m1 1995m1 2000m1 2005m1 2010m1 2015m1
 fecha
 IPSA IPSA, real
 33 / 33

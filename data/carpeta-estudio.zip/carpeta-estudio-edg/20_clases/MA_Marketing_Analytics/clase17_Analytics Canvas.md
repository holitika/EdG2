# Marketing Analytics · clase17_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 CLV EN CONTEXTOS NO
 CONTRACTUALES: MODELO
 PARETO/NBD
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Clase Anterior: CLV en Contextos
 Contractuales
2
  Estimación de función de supervivencia usando
 modelo beta-geométrico
  Estimación de parámetros 𝛼 y 𝛽 vía máxima
 verosimilitud
  Función de supervivencia BG:
 𝐵(𝛼, 𝛽 + 𝑡)
 𝑆 𝑡 𝛼, 𝛽 =
 𝐵(𝛼, 𝛽)

[pág. 3]
Aplicación: Estimación de CLV para
 Nuevos Clientes
3
 Función de supervivencia
 proyectada usando
 𝑇 modelo BG
 𝑆(𝑡) ∙ 𝑚𝑡 𝛼 = 0.668
 𝐸 𝐶𝐿𝑉 = ෍ 𝛽 = 3.806
 (1 + 𝑑)𝑡
 𝑡=1
 7
 𝑆(𝑡) ∙ 200 + 5 𝑡 − 1
 𝐸 𝐶𝐿𝑉 = ෍
 (1 + 0.1)𝑡
 𝑡=1

[pág. 4]
Estimación de Valor de Base de Clientes
4
  Modelo BG también nos permite estimar el valor residual de
 un cliente ya adquirido:
 ∞
 𝑆(𝑡|𝑡 > 𝜏 − 1) ∙ 𝑚𝑡
 𝐸 𝑅𝐿𝑉|𝐴𝑐𝑡𝑖𝑣𝑜 ℎ𝑎𝑠𝑡𝑎 𝜏 − 1 = ෍
 (1 + 𝑑)𝑡−𝜏
 𝑡=𝜏
 Valor de Vida
 Residual 𝑡 = 𝜏, 𝜏 + 1, 𝜏 + 2, …

[pág. 5]
Valor de Vida Residual del Cliente
5
  Timing
 𝑡
 1 2 … 𝜏 𝜏+1 𝜏+2 …
 Clientes observados justo antes de
 renovar en el período 𝜏

[pág. 6]
Sesgo en Función de Supervivencia
 Estimada
6
  Un problema en el uso de 𝑆(𝑡|𝑡 > 𝜏 − 1) es que el
 modelo no condiciona en sobrevivencia hasta 𝜏 − 1
  Distribución beta usada en el modelo no tiene en cuenta que
 quienes sobreviven tienen una mayor probabilidad de
 renovación
  Es necesario ajustar la distribución beta para tener en
 cuenta que estos clientes tienen mayor probabilidad de
 renovar (vs. cliente promedio ex-ante)
  Fader & Hardie (Marketing Science, 2009)

[pág. 7]
Ajuste de E[RLV] en el Modelo BG
 Fader & Hardie (2009)
7
  Asumiendo por simplicidad márgenes constantes, el E[RLV] de
 un cliente geométrico está dado por
 𝐸 𝑅𝐿𝑉|𝐴𝑐𝑡𝑖𝑣𝑜 ℎ𝑎𝑠𝑡𝑎 𝜏 − 1 = 𝑚 ∙ 𝐷𝐸𝑅𝐿
 Vida residual
 esperada
 donde, descontada
 1+𝑑
 𝐷𝐸𝑅𝐿 = (1 − 𝜃)
 𝑑+𝜃

[pág. 8]
DERL de Cliente Beta-Geométrico
 Enfoque “naïve”
8
 1
 1+𝑑
 𝐷𝐸𝑅𝐿 = න (1 − 𝜃) 𝑓 𝜃|𝛼, 𝛽 𝑑𝜃
 0 𝑑+𝜃
 DERL de cliente Dist. Beta
 activo hasta 𝜏-1
 No toma en cuenta que 𝜃 es menor para
 cliente activo hasta 𝜏-1

[pág. 9]
Actualización de Probabilidad Beta
9
  Para tomar en cuenta que cliente se mantiene activo hasta 𝜏-1
 usamos Teorema de Bayes
  Recordar:
 𝑃 𝐴 𝐵 ∙ 𝑃(𝐵)
 𝑃 𝐵𝐴 =
 𝑃(𝐴)

[pág. 10]
Actualización de Probabilidad Beta
10
  Para tomar en cuenta que cliente se mantiene activo hasta 𝜏-1
 usamos Teorema de Bayes:
 𝑆 𝜏 − 1|𝜃 𝑓 𝜃|𝛼, 𝛽
 𝑓 𝜃|𝛼, 𝛽, 𝐴𝑐𝑡𝑖𝑣𝑜 ℎ𝑎𝑠𝑡𝑎 𝜏 − 1 =
 𝑆 𝜏 − 1|𝛼, 𝛽
 • 𝑓 𝜃|𝛼, 𝛽 : distribución previa (prior)
 • 𝑆 𝜏 − 1|𝜃 : probabilidad condicional de permanecer activo hasta 𝜏 − 1
 • 𝑆 𝜏 − 1|𝛼, 𝛽 : probabilidad marginal de permanecer activo hasta 𝜏-1

[pág. 11]
DERL de Cliente Beta-Geométrico
 Enfoque Correcto
11
 verosimilitud
 prior
 1
 1 + 𝑑 𝑆 𝜏 − 1|𝜃 𝑓 𝜃|𝛼, 𝛽
 𝐷𝐸𝑅𝐿 = න (1 − 𝜃) 𝑑𝜃
 0 𝑑+𝜃 𝑆 𝜏 − 1|𝛼, 𝛽
 marginal
 𝑓 𝜃|𝛼, 𝛽, 𝐴𝑐𝑡𝑖𝑣𝑜 ℎ𝑎𝑠𝑡𝑎 𝜏 − 1

[pág. 12]
CLV en Contextos No Contractuales
12
  En contextos no contractuales la fuga es no
 observada
  Concepto de “tasa de retención” no está bien definido
  En general,
 σ𝑇𝑡=1 𝑃(𝐴𝑐𝑡𝑖𝑣𝑜𝑡 ) ∙ 𝑚𝑡
 𝐸 𝐶𝐿𝑉 =
 (1 + 𝑑)𝑡

[pág. 13]
CLV en Contextos No Contractuales:
 Modelo Pareto-NBD
13
  Schmittlein et al. (Management Science, 1987)
  Modelo Pareto-NBD modela dos procesos:
  Frecuencia de compra
  Vida del cliente
  Asume que transacciones pueden ocurrir en
 cualquier momento del tiempo

[pág. 14]
Supuestos de Modelos Probabilísticos
14
 Modelo
 Pareto/NBD • Compras en supermercados • Marketplaces (Ej. Amazon
 • Vuelos Prime)
 Continuas • Estadías en hoteles
 • Compras en App
 • Viajes en Uber, Lyft
 • Visitas al médico
 Oportunidades
 para
 Transacción • Campañas de organización • Suscripción a revistas
 de caridad
 • Suscripción a plataformas de
 • Asistencia a eventos streaming
 Discretas
 • Membresía en gimnasio
 No Contractual Contractual
 Contexto de Negocios

[pág. 15]
Modelo Pareto/NBD: Etapas en la Relación
 con el Cliente
15
  Supuesto 1. Los clientes pasan por dos etapas en su relación
 con la empresa: Activos por un período de tiempo; luego de
 vuelven permanentemente inactivos
 × × × ×
 𝑡
 Cliente Activo Cliente Permanentemente
 Inactivo

[pág. 16]
Proceso de Compras del Cliente
16
  Supuesto 2. Mientras se encuentra activo, número
 de transacciones de un cliente sigue proceso Poisson
 𝑒 −𝜆𝑡 (𝜆𝑡)𝑥
 𝑃 𝑋(𝑡) = 𝑥 |𝜆 = , 𝑥 = 0, 1, 2. . .
 𝑥!
 𝑋(𝑡) = Número de compras en perí𝑜𝑑𝑜 𝑑𝑒 duració𝑛 t
  = Tasa de compras por unidad de tiempo

[pág. 17]
Media y Varianza de Proceso Poisson
17
 𝐸 𝑋(𝑡) = 𝜆𝑡
 𝑣𝑎𝑟 𝑋(𝑡) = 𝜆𝑡

[pág. 18]
Comportamiento de Compra Poisson
Ejemplo
 Supongamos que la tasa de compras de un cliente es  = 2
 ¿Cuál es la probabilidad de que el individuo haga a lo menos
 una transacción en dos períodos?

[pág. 19]
Proceso de Tiempo entre Compras
19
  Una implicancia del Supuesto 1 es que el “tiempo entre
 compras (consecutivas)” se distribuye Exponencial
 𝑓 𝑡𝑗 − 𝑡𝑗−1 𝜆 = 𝜆 ∙ 𝑒 −𝜆 𝑡𝑗 −𝑡𝑗−1 𝑡𝑗 > 𝑡𝑗−1 > 0
 Tiempo entre Compras 𝑡𝑗 = período de j-ésima compra
 cdf asociada: 𝐹 𝑡𝑗 − 𝑡𝑗−1 𝜆 = 1 − 𝑒 −𝜆 𝑡𝑗 −𝑡𝑗−1

[pág. 20]
Heterogeneidad en Frecuencia de
Compras
 Modelo Poisson asume tasa de compras promedio 
 constante entre clientes
 Homogeneidad en comportamiento de compras es poco
 realista
 Necesitamos incorporar heterogeneidad en procesos de
 compra entre clientes
 Modelo asume que tasa de compra  se distribuye
 Gamma

[pág. 21]
Heterogeneidad en Frecuencia de
Compras
 Supuesto 3. Las tasas de compra promedio siguen una
 distribución Gamma
 𝛼 𝑟 𝜆𝑟−1 𝑒 −𝛼𝜆
 𝑔 𝜆|𝑟, 𝛼 = , 𝜆>0
 Γ 𝑟
  Donde Γ denota la función gamma: Γ(𝑛) = (𝑛 − 1)!
  r > 0, 𝛼 > 0

[pág. 22]
Funciones de Densidad Gamma
𝑟 = 1, 𝛼 = 4 𝑟 = 2, 𝛼 = 4
 𝑟 es el
 parámetro
 de forma
𝑟 = 1, 𝛼 = 10 𝑟 = 2, 𝛼 = 10
 𝑟 = 2, 𝛼 = 10

[pág. 23]
Distribución Gamma: Media y Varianza
 𝑟
 𝐸 𝜆 =
 𝛼
 𝑟
 𝑣𝑎𝑟 𝜆 = 2
 𝛼

[pág. 24]
Modelo NBD o Poisson-Gamma
24
  Mixtura de procesos Poisson usando distribución
 Gamma
 ∞
 𝑃 𝑋(𝑡) = 𝑥|𝛼, 𝑟 = න 𝑃 𝑋(𝑡) = 𝑥|𝜆 ⋅ 𝑔 𝜆|𝑟, 𝛼 𝑑𝜆
 0

[pág. 25]
Modelo NBD o Poisson-Gamma
25
  Mixtura de procesos Poisson usando distribución
 Gamma
 Γ 𝑟+𝑥 𝛼 𝑟 𝑡 𝑥
 𝑃 𝑋(𝑡) = 𝑥|𝛼, 𝑟 =
 Γ 𝑟 Γ 𝑥+1 𝛼+𝑡 𝛼+𝑡

[pág. 26]
Modelo Poisson-Gamma o NBD
 Momentos de la distribución NBD:
 𝑟
 𝐸 𝑋(𝑡) = 𝑡
 𝛼
 𝑟 𝑡
 𝑣𝑎𝑟 𝑋(𝑡) = 𝑡 1 +
 𝛼 𝛼

[pág. 27]
Modelo Poisson-Gamma: Ejemplo
27
 • Suponga que se estima un modelo Poisson-Gamma con
 parámetros
 𝑟 = 2; 𝛼=4
 • ¿Cuál es la probabilidad de que el cliente haga al menos
 una compra en un período?

[pág. 28]
Duración de “Vida” del Cliente
28
  Supuesto 4. La vida (no observada) del cliente 𝜏,
 sigue un proceso exponencial con tasa de abandono
 𝜇:
 𝑓 𝜏 𝜇 = 𝜇 ∙ 𝑒 −𝜇𝜏 𝜏>0

[pág. 29]
Duración de “Vida” del Cliente
29
  Momentos de la distribución exponencial:
 1 1
 𝐸 𝜏|𝜇 = 𝑉𝑎𝑟 𝜏|𝜇 = 2
 𝜇 𝜇
  Función de supervivencia asociada:
 𝑆 𝑡 𝜇 = 1 − 𝐹 𝑡 𝜇 = 𝑒 −𝜇𝑡

[pág. 30]
Duración de Vida del Cliente: Ejemplo
30
  Suponga un cliente con tasa de abandono 𝜇 = 0.2
 1. ¿Cuál es la duración esperada de la vida del cliente?
 2. ¿Cuál es la probabilidad de que el cliente se
 encuentre activo en 𝑡 = 1?

[pág. 31]
Función de Supervivencia Exponencial
31
 𝜇 = 0.2

[pág. 32]
Heterogeneidad en Tasa de Abandono
32
  Supuesto 5. La tasa de abandono del cliente, 𝜇, sigue un
 proceso gamma:
 𝛽 𝑠 𝜇 𝑠−1 𝑒 −𝛽𝜇
 ℎ 𝜇|𝑠, 𝛽 = , 𝜇 > 0; s, β > 0
 Γ 𝑠

[pág. 33]
Modelo Pareto Tipo II
33
  Mixtura de exponenciales usando gamma como
 función de mezcla
 ∞
 𝑓 𝜏 𝑠, 𝛽 = න 𝑓 𝜏 𝜇 𝑔 𝜇 𝑠, 𝛽 𝑑𝜇
 0

[pág. 34]
Modelo Pareto Tipo II
34
  Mixtura de exponenciales usando Gamma como
 función de mezcla
 𝑠+1
 𝑠 𝛽
 𝑓 𝜏 𝑠, 𝛽 =
 𝛽 𝛽+𝜏

[pág. 35]
Duración de Vida del Cliente
35
  Esperanza de distribución Pareto (tipo II)
 𝛽
 𝐸[𝜏|𝑠, 𝛽] = 𝑠 > 1
 𝑠−1
  Función de supervivencia asociada
 𝑠
 𝛽
 𝑆 𝜏 𝑠, 𝛽 = 1 − 𝐹 𝜏 𝑠, 𝛽 =
 𝛽+𝜏

[pág. 36]
Modelo Pareto (Tipo II): Ejemplo
36
  Suponga un cliente con 𝑠 = 2 y 𝛽 = 5
  ¿Cuál es la probabilidad de que el cliente sobreviva hasta
 𝑡 = 1?

[pág. 37]
Modelo Pareto: Función de Supervivencia
37
 𝑠 = 2y𝛽 = 5

[pág. 38]
Resumen de Submodelos NBD y Pareto
38
  Frecuencia de Compra
  Transacciones siguen proceso Poisson
 Modelo NBD
  Tasa de compras se distribuye Gamma 𝛼, 𝑟
  Vida del Cliente
  Vida del cliente se distribuye Exponencial
 Modelo Pareto
  Tasa de abandono se distribuye Gamma 𝛽, 𝑠

[pág. 39]
Supuesto de Independencia
39
  Supuesto 6. La tasa de compras 𝜆 y la tasa de
 abandono 𝜇 varían independientemente entre
 individuos.

[pág. 40]
Estimación del Modelo Pareto/NBD
40
  Estimación de parámetros 𝛼, 𝑟, 𝛽, 𝑠 vía MV
  Datos: Cohorte de N clientes donde cliente i
  Realizó 𝑥𝑖 transacciones en el período (0, 𝑇𝑖 ]
  Su última transacción ocurrió en 𝑡𝑥
 𝑖
  Tres métricas resumen el historial de compras
  Frecuencia, 𝑥𝑖
  Recencia, 𝑡𝑥
 𝑖
  Tiempo transcurrido desde primera compra, 𝑇𝑖

[pág. 41]
Estimación del Modelo Pareto/NBD
41
  Función de (log) verosimilitud toma la forma:

[pág. 42]
Par et o/ NBD Li k el i hood Funct i on
L( r , α , s,β | x , t x , T )
 α−β
 Γ( r + x ) α r β s s 2 F1 r + s + x , s + 1; r + s + x + 1; α + t x
 =
 Γ( r ) r + s+ x ( α + t x ) r + s+ x
 α−β
 r + x 2 F1 r + s + x , s; r + s + x + 1; α + T
 + , if α ≥ β
 r + s+ x ( α + T ) r + s+ x
L( r , α , s,β | x , t x , T )
 β− α
 Γ( r + x ) α r β s s 2 F1 r + s + x , r + x ; r + s + x + 1; β + t x
 =
 Γ( r ) r + s+ x ( β + t x ) r + s+ x
 β− α
 r + x 2 F1 r + s + x , r + x + 1; r + s + x + 1; β + T
 + , if α ≤ β
 r + s+ x ( β + T ) r + s+ x
 42
 137
Función de Verosimilitud
Estimación del Modelo Pareto/NBD

[pág. 43]
CLVTools
43
  Librería que permite estimar parámetros de modelos
 probabilísticos usados en estimaciones de CLV
  Modelos (frecuencia + vida del cliente)
  Pareto/NBD
  BG/BB
  Modelo de valor monetario
  Gamma/Gamma

[pág. 44]
Modelo Pareto/NBD en CLVTools
 Datos
44
  Cohorte de 250 clientes de retailer especializado en
 vestuario
  Período: "2005-01-03" "2006-07-16"

[pág. 45]
Modelo Pareto/NBD en CLVTools
 Datos
45

[pág. 46]
Modelo Pareto/NBD en CLVTools
 Datos
46

[pág. 47]
Modelo Pareto/NBD en CLVTools
 Datos: Frecuencia de Transacciones
47

[pág. 48]
Preparación de Datos para Estimación
48

[pág. 49]
Preparación de Datos para Estimación
49

[pág. 50]
Estimación del Modelo Pareto/NBD
50

[pág. 51]
Predicciones de CLV
51

[pág. 52]
Predicciones de CLV
52

[pág. 53]
Distribución de E[CLV]
53

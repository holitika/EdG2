# Marketing Analytics · clase27_P2_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 DISEÑO DE NUEVOS PRODUCTOS:
 ANÁLISIS CONJUNTO
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Motivación
2
  Lanzamiento de nuevos
 productos juega un rol clave en
 el crecimiento y rentabilidad de
 firmas
  Nuevos productos representan
 del orden de 25%-30% del
 crecimiento en ventas/utilidades
  Firmas requieren rediseñar
 productos o desarrollar nuevos
 productos en etapa de
 madurez/declinación de PLC

[pág. 3]
Alta Tasa de Fracaso en Lanzamiento de
 Nuevos Productos
3
  ~40% de nuevos productos fracasan en etapa de
 introducción
  De cada 7-10 conceptos de nuevos productos 1 es
 un éxito comercial
  Sólo 13% de firmas reporta que sus esfuerzos en
 nuevos productos alcanzan objetivos de utilidades
 anuales

[pág. 4]
Enfoques Típicos en NPD
4
  Intuición gerencial
  Recomendaciones de ingenieros de diseño
  Pruebas de concepto
  Pruebas de mercado

[pág. 5]
Diseño de Nuevos Productos en Firmas
Orientadas al Consumidor
 Clave poder medir preferencias por configuraciones
 alternativas de producto
 Uso de datos provenientes de encuestas
  Datos históricos insuficientes en este contexto
 Métodos consideran productos como un conjunto de
 atributos
 ¿Cómo valora el cliente distintos niveles de atributos?

[pág. 6]
Productos como Conjunto de Atributos:
Ejemplo Smartwatch
 Ej. Smartwatch – Atributos:
  Vida útil de batería
  Uso como celular
  Uso como dinero móvil
  Peso
  Pulso
  Marca
  Precio

[pág. 7]
Características de Smartwatch
 ¿Cómo describimos un smartwatch en términos de sus características?
 Vida de Pago
 Atributo Batería Celular Móvil Peso Pulso Marca Precio
 12 hrs No No 30 grs. No Samsung $ 199.990
 Niveles de 18 hrs Sí Sí 60 grs. Sí Apple $ 249.990
 Atributos
 1 día 90 grs. $ 299.990
 2 días $ 399.990
 3 posibles Smartwatches que podemos construir
 MODELO I 12 hrs, Celular, Pago Móvil, Pulso, 60 grs., Apple
 MODELO II 2 días, Celular, 30 grs., Apple
 MODELO III 1 día, Celular, Pago Móvil, Pulso, 60 grs., Samsung

[pág. 8]
Productos como Conjunto de Atributos
 Utilidad de configuración de producto es la suma
 de utilidades asociadas a cada atributo:
 𝑢𝑆 = 𝑢𝑆𝑏 + 𝑢𝑆𝑣 + 𝑢𝑆𝑐 + 𝑢𝑆𝑝𝑚 +𝑢𝑆𝑝𝑢 + ⋯
 Marca Vida Uso Pago Frecuencia
 Útil como Móvil Cardíaca
 Celular

[pág. 9]
Niveles de Atributos e Importancias
 Utilidades parciales pueden expresarse como el
 producto entre el nivel del atributo y su importancia
 𝑢𝑆𝑎 = 𝑤𝑎 𝑥𝑎

[pág. 10]
Metodologías en Medición de
Preferencias
 Método directo o auto-explicado
  Evaluación de atributos individuales
  Compositional
 Método indirecto (Análisis Conjunto)
  Evaluación de perfil/producto completo
  Descomposicional

[pág. 11]
Método Directo o Autoexplicado
 Pregunta directamente:
 1. Importancia de atributos en decisión de compra
 ◼ Ej. “Asigne 100 puntos entre distintos atributos de acuerdo a
 su importancia”
 2. Evaluación de distintas opciones en esos atributos
 ◼ Ej. “Evalúe su preferencia por [duración de la batería] en
 escala 0-10”

[pág. 12]
Método Directo en Caso Smartwatch
12
  Respuestas de Participante:
 Atributo Importancia (0-100)
 Duración de Batería 15
 Uso como Celular 20
 Uso como Dinero Móvil 10
 Peso 10
 Pulso 5
 Marca 15
 Precio 25

[pág. 13]
Método Directo en Caso Smartwatch
13

[pág. 14]
¿Qué Perfil de Productos Prefiere
 Participante?
14
 Atributo Producto 1 Producto 2
 Duración de Batería 24 hrs. 18 hrs.
 Uso como Celular Sí Sí
 Uso como Dinero Móvil Sí No
 Peso 30 grs. 60 grs.
 Pulso No No
 Marca Samsung Apple
 Precio $249.990 $249.990

[pág. 15]
¿Qué Perfil de Productos Prefiere
 Participante?
15
 Atributo Producto 1 Utilidad Producto 2 Utilidad
 Duración de Batería 24 hrs. 0.9 18 hrs. 0.45
 Uso como Celular Sí 2.0 Sí 2.00
 Uso como Dinero Móvil Sí 0.0 No 0.00
 Peso 30 grs. 1.0 60 grs. 0.60
 Pulso No 0.0 No 0.00
 Marca Samsung 1.2 Apple 1.50
 Precio $249.990 1.5 $249.990 1.50
 Total 6.60 6.05

[pág. 16]
Método Directo: Limitaciones
 Dificultad de juzgar importancia de atributos y
 niveles
 No captura trade-offs entre atributos
 No permite incluir interacciones entre atributos
 Sujeto a sesgos
 Estudios empíricos muestran que no captura bien preferencias

[pág. 17]
Análisis Conjunto: Idea Básica
 Participantes no evalúan atributos individuales
 Evalúan perfiles completos de producto
 Idea: Podemos inferir valor de un atributo variando
 niveles de atributos experimentalmente y
 observando evaluaciones
 ~14.000 estudios que usan AC realizados
 anualmente en EE.UU.

[pág. 18]
Análisis Conjunto: Idea Básica (cont.)
 Input: Datos de preferencias globales
  Evaluación de perfil completo
  Rating, ranking, o escogencia
 Output: Descomposición de preferencias globales
 en utilidades parciales
  Utilidad promedio de cada atributo

[pág. 19]
Aplicación: Caso Courtyard by Marriott ©

[pág. 20]
Caso Courtyard by Marriott ©
 A comienzos de los ’80 Marriott Corporation enfrentaba
 escasez de buenas ubicaciones para sus hoteles
 Decidió desarrollar una nueva cadena de hoteles orientada
 a clientes insatisfechos
 Segmentación a priori: Viajeros por negocios vs. viajeros
 por placer
 Pregunta clave: ¿Qué tipo de hotel ofrecer para atraer
 viajeros desde ofertas competitivas?

[pág. 21]
Caso Courtyard by Marriott ©
 Marriott contrató equipo de consultores externos (Green,
 Wind et al.) para estudiar preferencias de viajeros
  Trade-offs entre distintos atributos de cadena hotelera
 Objetivo: Determinar el diseño óptimo de nueva cadena
 hotelera
 Equipo consultor realizó estudio a gran escala que involucró
 encuestar a viajeros por negocios y por placer
  Valoración de atributos de un hotel

[pág. 22]
Caso Courtyard by Marriott ©
Atributos Incluidos en Estudio
 Factores externos
  Forma del edificio, diseño de exteriores, tipo y ubicación de
 piscina, tamaño de hotel
 Servicios de alimentación
  Tipo y ubicación del restorán, room service, máquinas
 expendedoras y tiendas, cocina-en-habitación
 Lounge
  Ubicación, atmósfera y tipo de gente (clientela)

[pág. 23]
Caso Courtyard by Marriott ©
Atributos Incluidos en Estudio
 En total estudio consideró 50 atributos
 2-8 niveles por atributo
  Ej. Sala de ejercicios: ninguna – básica – bien equipada
 Consultores usaron técnica de Análisis Conjunto
 Diseño óptimo: Cadena Courtyard by Marriott ©
 Posterior aplicación a Residence Inn, Fairfield Inn y
 Marriott Suites

[pág. 24]
24

[pág. 25]
Metodologías en Análisis Conjunto
 Método Basado en Evaluación de Perfiles (Ratings-
 based Conjoint)
  Enfoque tradicional
  Análisis: Regresión Múltiple
 Método Basado en Elecciones (Choice-based Conjoint)
  Participante escoge una alternativa
  Análisis: Logit multinomial

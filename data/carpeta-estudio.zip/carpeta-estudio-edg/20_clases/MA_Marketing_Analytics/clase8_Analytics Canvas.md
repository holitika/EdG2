# Marketing Analytics · clase8_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 ANÁLISIS DE CLUSTERS PARTE 2
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Clase Anterior: Análisis de Clusters
2
  Introducción al análisis de
 clusters
  Metodologías basadas en
 proximidades
  Clustering jerárquico
  Clustering basado en
 partición
  Foco en clustering jerárquico
 (aglomerativo)

[pág. 3]
Idea de Métodos Jerárquicos
3
  Construyen jerarquía de clusters en base
 a proximidad entre clusters
  No entregan directamente número de
 clusters a extraer
  Analista debe decidir número de
 clusters presentes en la data
  Decisiones:
  Medida de proximidad/similitud a
 utilizar
  Criterio de enlace o vinculación
  Número de clusters a extraer

[pág. 4]
Inputs en Clustering Jerárquico
4
 ❑Matriz de Datos ❑Matriz de Distancias
 Bases de Segmentación
 Consumidores

[pág. 5]
Método Jerárquico (aglomerativo)
 Algoritmo de Solución
5
 1. Asignar cada cliente a un cluster separado.
 2. Calcular matriz de distancias entre cada par de clusters.
 3. Combinar clusters más cercanos en base a matriz de
 distancias.
 4. Recalcular distancias entre nuevo cluster y antiguos.
 5. Repetir pasos 3 y 4 hasta que todos los clusters queden
 agrupados en un único cluster.

[pág. 6]
Uso del Dendrograma en Determinación
 de Número de Clusters
6

[pág. 7]
Uso de Scree Plot en Determinación del
 Número de Clusters a Extraer
7
  Scree plot muestra cómo
 cambia la dispersión
 interior en función del
 número de clusters
  El “codo” es indicativo de
 que clusters adicionales
 aportan poco a aumentar
 la homogeneidad intra
 cluster

[pág. 8]
Número de Clusters: Índice Calinski-Harabasz
8
 𝑆𝑆 𝑒𝑛𝑡𝑟𝑒 𝐶𝑙𝑢𝑠𝑡𝑒𝑟𝑠 𝑁 − 𝐾
 𝐶𝐻𝑘 =
 𝑆𝑆 𝑖𝑛𝑡𝑒𝑟𝑖𝑜𝑟 𝑎 𝐶𝑙𝑢𝑠𝑡𝑒𝑟𝑠 𝐾 − 1

[pág. 9]
Número de Clusters: Coeficiente
 Silhouette Promedio
9
 𝑏 𝑖 − 𝑎(𝑖)
 𝑆(𝑖) =
 max(𝑏 𝑖 , 𝑎 𝑖 )
 𝑆(𝑖) ∈ −1,1

[pág. 10]
Influencia de Escala de Medición
10
  Una cuarta decisión en el análisis de clusters jerárquico
 tiene que relación con la escala en que se miden las
 variables de segmentación
  Diferencias en escala de medición pueden influir sobre
 la solución
  Ejemplo:
  Ingreso en $
  Satisfacción (escala 0-100)

[pág. 11]
Datos Originales
11
 ⋮ ⋮ ⋮ 𝑛 = 80

[pág. 12]
Descripción de Variables de
 Segmentación
12

[pág. 13]
Scatterplot de Datos Originales
13

[pág. 14]
Usamos Distancia Euclidiana
14
 2
 𝑑 𝐶1 , 𝐶2 = (𝐼𝑛𝑔𝑟𝑒𝑠𝑜𝐶1 − 𝐼𝑛𝑔𝑟𝑒𝑠𝑜𝐶2 )2 +(𝑆𝑎𝑡𝑖𝑠𝑓𝑎𝑐𝑐𝑖ó𝑛𝐶1 − 𝑆𝑎𝑡𝑖𝑠𝑓𝑎𝑐𝑐𝑖ó𝑛𝐶2 )2

[pág. 15]
Dendrograma: ¿Cuántos Clusters Extraer?
15

[pág. 16]
¿Cómo Mitigar Problema de Escala de
 Medición?
16
 ❑ Normalización más habitual: Número de desviaciones standard
 respecto a la media
 Transformamos cada variable usando:
 σ𝑛𝑖=1 𝑥𝑖𝑗
 𝑥𝑖𝑗 − 𝑥𝑗ҧ 𝑥𝑗ҧ =
 𝑧𝑖𝑗 = 𝑛
 𝑠𝑥𝑗
 1/2
 σ𝑛𝑖=1(𝑥𝑖𝑗 −𝑥𝑗ҧ )
 𝑗 = 1, … , 𝑝 𝑠𝑥𝑗 =
 𝑛−1

[pág. 17]
Scatterplot de Datos Estandarizados
17

[pág. 18]
Dendrograma de Datos Estandarizados:
 ¿Cuántos Clusters Extraer?
18

[pág. 19]
19 APLICACIÓN
 ANÁLISIS DE CLUSTERS JERÁRQUICO EN
 CADENA DE COMIDA RÁPIDA

[pág. 20]
Percepciones de McDonald’s
20
  ¿Existen segmentos de consumidores con una imagen
 distinta de McDonald’s?
  ¿En qué segmentos debiera enfocarse McDonald’s y
 qué mensajes dirigir a esos segmentos?
  Encuesta a 1453 consumidores australianos sobre
 sus percepciones de McDonald’s

[pág. 21]
Percepciones de McDonald’s: Datos
21
Bases de Segmentación

[pág. 22]
Segmentación en McDonald’s
 Evaluaciones Promedio
22

[pág. 23]
Matriz de Distancias
 Distancia Gower
23

[pág. 24]
Dendrograma Asociado
 ¿Cuántos Clusters Extraer?
24

[pág. 25]
Dendrograma Asociado
 ¿Cuántos Clusters Extraer?
25

[pág. 26]
Scree Plot Asociado
26

[pág. 27]
Perfil de Segmentos
27

[pág. 28]
28
 Métodos de Partición: K-Medias

[pág. 29]
K-Medias: Idea Básica
29
  Método más comúnmente usado en segmentación
  Menos computacionalmente intensivos que métodos jerárquicos
  Define clusters de modo de minimizar la variación intra-cluster
 total:
 𝐾 𝐾
 ෍ 𝑊𝑘 = ෍ ෍ (𝑥𝑖 − 𝑐𝑘 )2
 𝑘=1 𝑘=1 𝑥𝑖 ∈𝑘

[pág. 30]
K-Medias
 Algoritmo de Solución
30
 1. Especificamos número de clusters, 𝐾

[pág. 31]
K-Medias
 Algoritmo de Solución
31
 1. Especificamos número de clusters, 𝐾
 2. Seleccionamos 𝐾 observaciones aleatoriamente
 como “centroides” iniciales

[pág. 32]
K-Medias
 Algoritmo de Solución
32
 1. Especificamos número de clusters, 𝐾
 2. Seleccionamos 𝐾 observaciones aleatoriamente
 como “centroides” iniciales
 3. Calculamos distancias entre observaciones y
 centroides

[pág. 33]
K-Medias
 Algoritmo de Solución
33
 1. Especificamos número de clusters, 𝐾
 2. Seleccionamos 𝐾 observaciones aleatoriamente
 como “centroides” iniciales
 3. Calculamos distancias entre observaciones y
 centroides
 4. Asignamos cada observación a su centroide más
 cercano y formamos clusters

[pág. 34]
K-Medias
 Algoritmo de Solución (cont.)
34
 5. Para cada cluster, recalculamos su centroide

[pág. 35]
K-Medias
 Algoritmo de Solución (cont.)
35
 5. Para cada cluster, recalculamos su centroide
 6. Reasignamos observaciones a sus centroides más
 cercanos y formamos clusters

[pág. 36]
K-Medias
 Algoritmo de Solución (cont.)
36
 5. Para cada cluster, recalculamos su centroide
 6. Reasignamos observaciones a sus centroides más
 cercanos y formamos clusters
 7. Repetimos pasos 5-6 hasta que:
 ▪ Centroides no cambian (convergencia) ó
 ▪ Se alcanza el máximo número de iteraciones

[pág. 37]
K-Medias: Ejemplo Simple
37
 ❑Evaluación de 7 clientes de ID Precio Marca
 dos atributos: Importancia A 59 95
 del precio y lealtad a la B 92 93
 marca C 80 80
 ❑Evaluaciones en escala 0- D 60 70
 100 E 89 68
 F 69 52
 G 40 40

[pág. 38]
K-Medias Ejemplo Simple
38
 ❑Supongamos que
 decidimos dividirlos en
 dos segmentos
 ❑Paso 1: K = 2

[pág. 39]
Paso 2. Escogemos aleatoriamente dos puntos
 como centroides iniciales
39
  cc1 y cc2 son dos puntos
 escogidos aleatoriamente
 𝑐𝑐1 = (82, 90)
 𝑐𝑐2 = (78, 62)

[pág. 40]
Paso 2. Escogemos aleatoriamente dos puntos
 como centroides iniciales
40
  cc1 y cc2 son dos puntos
 escogidos aleatoriamente
 𝑐𝑐1 = (82, 90)
 𝑐𝑐2 = (78, 62)

[pág. 41]
Paso 3. Calculamos distancias desde cada
 observación a cada centroide
41
 ID Precio Marca Dcc1 Dcc2 Cluster
 A 59 95 23.54 38.08 1
 B 92 93 10.44 34.01 1
 C 80 80 10.20 18.11 1
 D 60 70 29.73 19.70 2
 E 89 68 23.09 12.53 2
 F 69 52 40.16 13.45 2
 G 40 40 65.30 43.91 2
 cc1 82 90
 cc2 78 62

[pág. 42]
Paso 4. Asignamos observación al centroide más
 cercano
42
 ID Precio Marca Dcc1 Dcc2 Cluster
 A 59 95 23.54 38.08 1
 B 92 93 10.44 34.01 1
 C 80 80 10.20 18.11 1
 D 60 70 29.73 19.70 2
 E 89 68 23.09 12.53 2
 F 69 52 40.16 13.45 2
 G 40 40 65.30 43.91 2
 cc1 82 90
 cc2 78 62

[pág. 43]
Pasos 3 y 4. Calculamos distancias desde cada observación a
 cada centroide y lo asignamos al más cercano
43

[pág. 44]
Paso 5. Para cada cluster recalculamos
 centroide
44
 ID Precio Marca Dcc1 Dcc2 Cluster
 A 59 95 23.54 38.08 1
 B 92 93 10.44 34.01 1
 C 80 80 10.20 18.11 1
 D 60 70 29.73 19.70 2
 E 89 68 23.09 12.53 2
 F 69 52 40.16 13.45 2
 G 40 40 65.30 43.91 2
 cc1' 77.0 89.3
 Nuevos centroides
 cc2' 64.5 57.5

[pág. 45]
45

[pág. 46]
Paso 6. Recalculamos distancias a
 centroides…
46
 ID Precio Marca Dcc1' Dcc2' Cluster
 A 59 95 18.87 37.90 1
 B 92 93 15.44 44.91 1
 C 80 80 9.80 27.32 1
 D 60 70 25.74 13.29 2
 E 89 68 24.48 26.66 1
 F 69 52 38.18 7.11 2
 G 40 40 61.67 30.11 2
 cc1' 77.0 89.3
 cc2' 64.5 57.5

[pág. 47]
Paso 6. … y reasignamos objetos a
 centroide más cercano
47
 ID Precio Marca Dcc1' Dcc2' Cluster
 A 59 95 18.87 37.90 1
 B 92 93 15.44 44.91 1
 C 80 80 9.80 27.32 1
 D 60 70 25.74 13.29 2
 E 89 68 24.48 26.66 1
 F 69 52 38.18 7.11 2
 G 40 40 61.67 30.11 2
 cc1' 77.0 89.3
 cc2' 64.5 57.5

[pág. 48]
Paso 7. Repetimos proceso hasta
 convergencia
48
  Convergencia alcanzada cuando objetos dejan de
 ser reasignados entre clusters
  Nota: Convergencia a óptimo local (no global)

[pág. 49]
Dependencia de Resultados de
 Asignación Inicial
49
  Algoritmo de K-medias encuentra un óptimo local (no
 global)
  Resultados dependen de la asignación aleatoria
 inicial en el Paso 1
 ➢ Importante repetir procedimiento usando distintos puntos
 iniciales
 ➢ Seleccionamos como mejor solución aquella que minimiza
 la función objetivo

[pág. 50]
Aplicación: Segmentación en Mercado de SUVs
50
  Concesionaria de automóviles
 interesada en identificar
 potenciales compradores de
 SUVs
  Datos: 5000 individuos
  Edad
  Educación (básica-media-
 universitaria)
  Número de hijos
  ¿Tiene o ha tenido SUV?

[pág. 51]
Estadística Descriptiva
 summary(autos.df)
51
 ## edad educacion suv nhijos
 ## Min. :22.00 Min. :1.000 Min. :0.0000 Min. :0.000
 ## 1st Qu.:30.00 1st Qu.:2.000 1st Qu.:0.0000 1st Qu.:1.000
 ## Median :43.00 Median :2.000 Median :1.0000 Median :3.000
 ## Mean :41.12 Mean :2.305 Mean :0.5736 Mean :2.501
 ## 3rd Qu.:51.00 3rd Qu.:3.000 3rd Qu.:1.0000 3rd Qu.:4.000
 ## Max. :77.00 Max. :3.000 Max. :1.0000 Max. :5.000
 ## educ_basica educ_media educ_univ
 ## Min. :0.0000 Min. :0.0000 Min. :0.000
 ## 1st Qu.:0.0000 1st Qu.:0.0000 1st Qu.:0.000
 ## Median :0.0000 Median :0.0000 Median :0.000
 ## Mean :0.1496 Mean :0.3954 Mean :0.455
 ## 3rd Qu.:0.0000 3rd Qu.:1.0000 3rd Qu.:1.000
 ## Max. :1.0000 Max. :1.0000 Max. :1.000

[pág. 52]
Selección de Número de Segmentos
 Scree Plot
52

[pág. 53]
Selección de Número de Segmentos
53

[pág. 54]
K-Medias: Solución de K = 4
54
 autos_km4 <- kcca(autos.std, 4, family=kccaFamily("kmeans"), weights=NULL,
 group=NULL, control=NULL, simple=FALSE, save.data=FALSE)

[pág. 55]
K-Medias: Solución de K = 4
55

[pág. 56]
Perfil de Segmentos
56

# Marketing Analytics · clase5_P2_Analytics 2024

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 INTRODUCCIÓN A LA
 SEGMENTACIÓN DE MERCADOS
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Parte I: Modelos para Decisiones
 Estratégicas
2
  Paradigma Segmentación-Targeting-
 Posicionamiento (S-T-P)
  Foco en metodologías para:
  Segmentación
  Posicionamiento

[pág. 3]
Concepto de Segmentación de Mercados
3
  Idea de distinguir subgrupos de consumidores con
 distintos gustos y necesidades
  Inspirado en trabajo de Joan Robinson (Robinson,
 1933) en competencia imperfecta y discriminación
 de precios
  Aplicado a Marketing por Wendell Smith en 1956
  Enorme impacto sobre la práctica del marketing

[pág. 4]
¿Qué entendemos por Segmentación de
 Mercados?
4
 “Market segmentation involves viewing a heterogenous
 market as a number of smaller homogeneous markets,
 in response to differing preferences, attributable to
 the desires of consumers for more precise satisfaction
 of their varying wants”
 Wendell R. Smith (Journal of Marketing, 1956)

[pág. 5]
Idea Clave: Heterogeneidad de Preferencias
5

[pág. 6]
Segmentación: Starbucks vs. Dunkin’ Donuts
6

[pág. 7]
Beneficios de la Segmentación
7
 Mejor Ajuste
 Mejor entre Ventaja
 Comprensión Fortalezas de Competitiva Mejores
 de Organización a Largo Resultados de
 Diferencias y Plazo en la
 entre Necesidades Segmentos Organización
 Consumidores del Meta
 Consumidor

[pág. 8]
Segmentación en Proceso S-T-P
8
 SEGMENTACIÓN TARGETING POSICIONAMIENTO
 • Agrupación de • Evaluación del • Definición de
 clientes en atractivo de propuesta de
 base a cada segmento valor para
 necesidades • Selección de segmento(s) meta
 similares segmentos • Desarrollo de un
 • Perfil de cada meta plan de acción
 segmento
 No necesariamente secuencial

[pág. 9]
¿Qué define una Segmentación Efectiva?
9
 1. Identificabilidad
 2. Sustancialidad
 3. Accesibilidad
 4. Responsividad
 5. Estabilidad
 6. Accionabilidad

[pág. 10]
Elementos de un Análisis de
 Segmentación
10
  Bases de Segmentación
  Enfoque de Segmentación
  Método de Segmentación

[pág. 11]
Bases de Segmentación: Definición
11
 “Conjunto de variables o características
 usadas para asignar potenciales clientes a
 grupos homogéneos”
 Wedel & Kamakura (2000), “Market Segmentation: Concepts and Methodological Foundations”

[pág. 12]
Bases de Segmentación
12
 General Producto-Específica
 Observable Culturales, geográficas, Status de usuario,
 demográficas y variables frecuencia de uso, lealtad
 socioeconómicas a tienda, situaciones
 No Observable Psicográficas, valores, Psicográficas, beneficios,
 personalidad y estilos de percepciones, elasticidades,
 vida atributos, preferencias,
 intención
 Fuente: Wedel & Kamakura (2000)

[pág. 13]
¿Qué Bases de Segmentación son
 Superiores?
13
 Fuente: Wedel & Kamakura (2000)

[pág. 14]
Enfoques de Segmentación
14
  Segmentación A-Priori
  Segmentación Ad-Hoc o A-Posteriori

# Marketing Analytics · clase2_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 ANALÍTICA Y TOMA DE
 DECISIONES
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Agenda
2
  ¿Qué entendemos por marketing analytics?
  Breve historia de marketing analytics
  Datos en Marketing Analytics
  Analítica en el proceso de toma de decisiones: Marco
 Analítico
  Analítica Exploratoria
  Lab 1: Exploración de ventas de bebida probiótica

[pág. 3]
¿QUÉ ENTENDEMOS POR
 “MARKETING ANALYTICS”?
3

[pág. 4]
“Marketing analytics involves the collection,
 management, and analysis –descriptive, diagnostic,
 predictive, and prescriptive– of data to obtain insights
 into marketing performance, maximize the effectiveness
 of instruments of marketing control, and optimize firms’
 return on investment (ROI)”
 Wedel & Kannan (Journal of Marketing, 2016)
 • Interdisciplinario: Marketing + negocios, estadística, economía,
 econometría, sicología, ciencias de la computación
4

[pág. 5]
Market Share Models CLV
 Models
 RFM
 ANOVA Conjoint HB
 Regression Cluster
 Segment. MNL Latent Structural
Analytics MDS Class
 1900 1925 1950 1975 2000 2025
 Data
 Transaction Clickstream Video
 Survey Eye Diary POS Search Social
 Tracking Panels Scanning
 Location
 5
 Adaptado de Wedel & Kannan (Journal of Marketing, 2016) Digital Data

[pág. 6]
Historia de Marketing Analytics
 Pre WWW
6
  Etapa 1 (~1900-1960): Descripción de condiciones
 de mercado
  Etapa 2 (~1960-1975): Desarrollo de modelos
 basados en teoría económica y psicología
  Etapa 3 (~1975-1995): Evaluación de políticas de
 marketing

[pág. 7]
Etapa 1: ~1900-1960
 Descripción de Condiciones de Mercado
7
  Trabajo de Charles Coolidge
 Parlin para Curtis Publishing
 Company en Boston (1911)
  Recolección de datos de
 mercado para orientar
 inversión publicitaria de
 clientes
  Década de 1920 intensiva en
 el uso de encuestas

[pág. 8]
Etapa 1: ~1900-1960
 Descripción de Condiciones de Mercado
8
  A.C. Nielsen fundada en
 1923
  Medición de ventas en
 tiendas
  Medición de audiencias
 de radio y TV (1930s-
 1950s)
 https://www.chicagobooth.edu/research/kilts/research-data/nielseniq
  Primeros estudios de
 “eye tracking”

[pág. 9]
Etapa 1: ~1900-1960
 Descripción de Condiciones de Mercado
9
  Uso de datos de panel para estudiar comportamiento
 de compra en los ’40 (diarios)
  Estudio de datos internos de clientes (~1930-1940)
  Ventas por catálogo – Marketing Directo
  RFM
  Énfasis en métodos estadísticos (métodos multivariados)
  Análisis de clusters en segmentación
  MDS y posicionamiento

[pág. 10]
Etapa 2: ~1960-1975
 Desarrollo de Modelos
10
  Modelos probabilísticos de comportamiento de compra
 (Ehrenberg, 1959)
  Identificación de regularidades empíricas
  Difusión de innovaciones (Bass, 1969)
  Aplicación de modelos de la epidemiología
  Modelación de preferencias
  Logit multinomial, MNL (McFadden, 1974)
  Análisis conjunto (Green & Rao, 1971)

[pág. 11]
Modelo de Difusión de Innovaciones
 Bass (1969)
11

[pág. 12]
Hito Clave: Introducción de Lector de
Código de Barras
 “A historic moment came at 8.01 am on 26 June 1974
 when Clyde Dawson, director of research and
 development for Marsh Supermarkets, bought a 10-
 pack of Wrigley’s Chewing Gum in his company’s
 store in Troy, Ohio –the first purchase made in the first
 store to be fully equipped with scanners which could
 read the new Uniform Product Codes (UPC).”
 Morton, 1994, p.101

[pág. 13]
Etapa 3: ~1975-1995
 Evaluación de Políticas de Marketing
13
  Clubes de lealtad → Scanner panel data
  Aplicación de MNL a decisiones del marketing mix
 (Guadagni & Little, 1983)
  Uso de MMM por P&G, Unilever, etc. (efectividad
 de acciones de marketing)
  Heterogeneidad en preferencias (HB)

[pág. 14]
Historia de Marketing Analytics
 Siglo XXI
14
 Datos Métodos
  Comentarios en RRSS / foros  Análisis de sentimientos (text
 online / reseñas analytics)
  Clickstream  Topic modeling (text analytics)
  Geolocalización  Análisis de redes sociales
 (SNA)
  Fotos/ilustraciones
  Deep learning, Random
 Forests, XGBoost

[pág. 15]
15
 TIPOS DE DATOS

[pág. 16]
Tipos de Datos en Marketing Analytics
16
  Taxonomías alternativas:
 1. Método de captura: Intrusivo vs. No Intrusivo
 2. Formato: Estructurado vs. No Estructurado
 3. Fuente: Interna vs. Externa

[pág. 17]
Métodos Intrusivos: Encuestas
17
  Especialmente útiles en:
  Medición de intenciones y actitudes
  Aprendizaje sobre clientes potenciales
  Nuevos productos
  Usados en distintas áreas de marketing (segmentación,
 posicionamiento, CRM, diseño de productos, precios, etc.)
  Crecientemente implementados utilizando plataformas online
 (Qualtrics, Prolific, etc.) e ”in situ”
  Desventajas: Baja tasa de participación, sesgos

[pág. 18]
Métodos No Intrusivos
18
  Capturan comportamiento efectivo del consumidor
  Compra, búsqueda, respuesta a publicidad, posteo en RRSS,
 reseñas, etc.
  Gran ventaja: Comportamiento pasado es un mejor predictor de
 comportamiento futuro versus…
  Información sobre intenciones
  Información socio-demográfica
  Muchas veces recolectados como parte de la operación del negocio
  Bajo costo de adquisición

[pág. 19]
CARACTERÍSTICAS SOCIO-DEMOGRÁFICAS NO SON
 BUENOS PREDICTORES DE COMPORTAMIENTO…
19

[pág. 20]
Datos Estructurados vs. No Estructurados
20
 Datos Estructurados organizados matricialmente…

[pág. 21]
Datos Estructurados vs. No Estructurados
21
 Datos No Estructurados no organizados matricialmente (texto,
 imágenes, video, etc.)
 “Hermoso teléfono impecable su calidad a
 muy buen precio y recibido antes de la
 fecha y sus audífonos inalámbricos
 geniales van muy bien con el teléfono”

[pág. 22]
Pre-historic time
 Early 2000s
 Last few
 years
 1983-early 2000s
 Mid 2000s…
22
 © Professor Oded Netzer Fuente: Netzer (2020)

[pág. 23]
Datos y Decisiones en Analítica
23
  Datos son clave en marketing
 analytics
  Pero no son el punto de partida
 de una iniciativa de analítica
  Proyecto de analítica debe
 estar orientado a resolver un
 problema
  Apoyo a la toma de decisiones

[pág. 24]
Toma de Decisiones basada en Analítica
 Marco Conceptual
24
 Objetivos de Negocios
 Problemas de Negocios
 Ideas de Negocios
 Analítica:
 Exploratoria/Descriptiva
 Predictiva | Causal
 Intuición de Negocios
 Decisiones de Negocios (optimización)
 Escalamiento
 Adaptado de Anderson & Zettelmeyer (2021)

[pág. 25]
Problema de Negocios en el Origen de un
 Proyecto de Analítica
25
 Objetivos Problemas Iniciativas de
 Analítica
 - Crecimiento de - Baja tasa de - Modelo de
 base de clientes respuesta predicción de
 - Satisfacción del respuesta/fuga
 - Bajo NPS
 cliente - Test A/B de impacto
 - Aumento de de acción
 - Limitar fuga
 “churn”
 … … …

[pág. 26]
26
 Tipos de Analítica

[pág. 27]
Analítica Exploratoria o Descriptiva
27
  Tipo de analítica más comúnmente
 utilizado
  80%-90% de empleados en labores
 de analítica (área de BI)
  Descripción del pasado
  Involucra cómputo de estadísticas
 simples, gráficos, figuras, etc.
  Crecimiento en ventas por tienda,
 número de visitas a sitio web, etc.
  Típicamente presentado en dashboards
 e informes

[pág. 28]
¿Crea Valor la Analítica Exploratoria?
28

[pág. 29]
El Valor de la Analítica Descriptiva:
 Evidencia de Retailers Online
29
  Adopción de dashboard por 1500 retailers online
  Características de dashboard:
  Software recolecta y analiza data de sitio web de retailer
 y otros canales de pago/venta (Amazon, Paypal, Stripe)
  Genera métricas y reportes visuales en distintos KPIs:
 Ventas, tamaño de canasta promedio, % repetición de
 compra, CAC, CLV
  Integra y agrega data de distintas fuentes (Ej. Google
 Analytics)

[pág. 30]
El Valor de la Analítica Descriptiva:
 Evidencia de Retailers Online
30
  Usos de dashboard:
  Monitoreo de KPIs
  Análisis de ingresos por canal (plataformas)
  Monitoreo de Martechs (Google Analytics, Sales Force,
 etc.)

[pág. 31]
¿Tiene Valor la Analítica Exploratoria?
 ¿Cuándo?
31
  Adopción tiene un impacto de 4%-10% en ingresos
 semanales
  Entre adoptantes sólo usuarios de benefician
  Beneficios provienen de monitorear y optimizar otras
 herramientas de martech (Google Analytics, Sales
 Force, etc.)
  Efecto vía complementariedad
  No hay impacto directo sobre en toma de decisiones

[pág. 32]
Otras Tareas de la Analítica Exploratoria
32
  Comprensión de construcción y calidad de datos
  Comprensión de la variabilidad en los datos

[pág. 33]
Comprensión de Construcción y Calidad
 de Datos
33
  Construcción y calidad de datos clave para correcta interpretación
 de resultados de analítica
  Datos de fuentes externas: Poca claridad sobre método de recolección y
 confiabilidad
  Clara definición de variables (¿A quién corresponden datos
 demográficos? ¿Cuál es el nivel de agregación?)
  Integración de datos (Ej. compras online y offline)
  Representatividad (Ej. reseñas online)
  Visualización de estructura de data y estadística básica útiles en
 detectar anomalías

[pág. 34]
Comprensión de Variabilidad en Datos
34
 Input Output
 • E-mail promocional • Conversiones
 • Publicidad online • Clickthrough
 • Etc. • Etc.
 Analítica requiere observar variabilidad (entre clientes, mercados en el
 tiempo, etc.) tanto en outputs como en inputs

[pág. 35]
Importancia de observar Variabilidad
35
 𝑆𝑎𝑡𝑖𝑠𝑓𝑎𝑐𝑐𝑖ó𝑛 = 𝛼 + 𝛽 ∙ 𝑇𝑖𝑒𝑚𝑝𝑜 𝑑𝑒 𝐸𝑛𝑡𝑟𝑒𝑔𝑎 + 𝜀
 𝑦 𝑥
 𝐶𝑜𝑣(𝑥, 𝑦)
 𝛽መ =
 𝑉𝑎𝑟(𝑥)

[pág. 36]
Ejemplo Etiquetado Nutricional
36

[pág. 37]
Importancia de “Generar” Variabilidad
37
  Típicamente, buena ejecución de negocios impide
 observar variabilidad necesaria para analítica
  Ej. Ausencia de variación de precios entre tiendas
 Walmart; ausencia de variación en tiempos de entrega
 de Amazon Prime
  Variabilidad puede ser generada deliberadamente
 con propósitos de analítica

[pág. 38]
38

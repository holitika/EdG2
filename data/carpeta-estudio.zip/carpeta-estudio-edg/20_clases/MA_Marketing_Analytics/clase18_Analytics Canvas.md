# Marketing Analytics · clase18_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 MODELOS DE PREDICCIÓN DE
 RESPUESTA
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Clase Anterior
2
  Predicción de CLV en contextos no contractuales:
 Modelo Pareto/NBD
  Uso de CLVTools
  Probabilidad de que cliente esté activo
  Predicción de transacciones
  Valor de transacciones usando modelo Gamma-
 Gamma

[pág. 3]
Uso de Estimaciones de CLV
3
  Segmentación (“value-based segmentation”)
  Adquisición de nuevos clientes
  Campañas de marketing personalizadas
  Asignación de recursos para retención de clientes
  Asignación de recursos para apoyo al cliente

[pág. 4]
4

[pág. 5]
CLV vs. Métricas Tradicionales en Selección
de Clientes de Alto Valor
▪ Multinacional especializada en hardware y software computacional (B2B)
0 30 48
 Tiempo
 (meses)
 ➢ Uso de datos de comportamiento ➢ Seguimiento de clientes seleccionados
 ➢ Computo de métricas (CLV, RFM, PCV, SOW) ➢ Computo de utilidad neta
 ➢ Selección de clientes en base a métrica ➢ Comparación de desempeño entre métricas
 Venkatesan & Kumar (Journal of Marketing, 2004)

[pág. 6]
Fuente: V. Kumar (2008), “Customer Lifetime Value – The Path to Profitability”
6

[pág. 7]
CLV vs. Métricas Tradicionales
 Venkatesan & Kumar (2004)
7
  Clientes de manufacturero B2B seleccionados en base a
 su puntaje CLV generaron
  40% más ingresos promedio
  42% más margen bruto
  45% más valor neto
  Versus clientes seleccionados en base a métricas
 tradicionales
  Basadas en comportamiento histórico: RFM, PCV, SOW

[pág. 8]
Extensiones y Limitaciones
8
  Modelo básico (retención) asume que una vez perdido el cliente no vuelve
  Modelo migratorio permite que cliente regrese luego de inactivo
  Modelación basada en procesos de Markov
  Foco puramente financiero inapropiado en algunos contextos
  Ej. Aplicación en industria de la salud plantea dilemas éticos
  CLV no considera valor de referencias, WOM, señalización
  Referencias de clientes pueden generar importante valor
  Difícil de cuantificar e incorporar en cálculos de CLV

[pág. 9]
CLV y Modelos de Respuesta
9
  ¿Cómo podemos incrementar el CLV de un cliente?
  Repetición de compra
  Mayor valor (up-selling y cross-selling)
  Aumentando la vida del cliente (retención)
  Decisiones anteriores se benefician de modelos predictivos
 sobre respuesta del cliente
  Probabilidad de responder a oferta
  Probabilidad de fuga

[pág. 10]
Analítica Predictiva busca Anticipar el Futuro
10
 • Involucra construir y usar modelos matemáticos que hacen
 predicciones en base a patrones extraídos de datos históricos
 1/6/2023 1/6/2024
 Observation
 Window
 Prediction
 Window
 12 months 6 months

[pág. 11]
Tipos de Modelo Predictivo
11
  Modelos Estadísticos
  Modelos de Machine Learning

[pág. 12]
Modelos Estadísticos
12
  Analista decide forma funcional y predictores
  Ej. regresión lineal, regresión logística
  Simples: Hacen un mayor número de supuestos
 sobre el PGD
  Tendencia a mayor sesgo y menor varianza (menor
 propensión a overfit data de training)
  Interpretables

[pág. 13]
Modelos de Machine Learning
13
  Modelo aprende patrones a partir de los datos
  Tienden a ser altamente flexibles
  Tendencia a menor sesgo pero alta varianza
  Necesidad de evitar “overfitting”
  Flexibilidad les permite mejoras en poder predictivo
  Menos interpretables (“caja negra”)
  Redes neuronales artificiales, árboles de decisión, modelos
 de ensamble (random forests, XGBOOST, etc.)

[pág. 14]
Modelos Predictivos de Respuesta
14
 ❑ Múltiples aplicaciones en analítica de clientes requieren predecir
 variables cualitativas
 ▪ ¿Cliente dejará de ser cliente durante el próximo mes/trimestre/año?
 ▪ ¿Cliente volverá a comprar durante el próximo mes/trimestre/año?
 ▪ ¿Cliente responderá a una oferta?
 ▪ ¿Cliente comprará otro producto de la empresa?
 Todas estas preguntas tienen como respuesta: Sí / No
 ¿Cómo predecimos este tipo de respuesta?

[pág. 15]
ANALÍSIS DE VARIABLES CUALITATIVAS
▪ Incorporación de variables cualitativas a un análisis predictivo
 requiere codificación de variables
 1 Cliente decide terminar suscripción
 𝑦
 ¿Fuga? 0 Cliente decide no terminar suscripción
 Posibles valores
 de 𝑦

[pág. 16]
APLICACIÓN: PREDICCIÓN DE FUGA
 ▪ Crecientemente, firmas son proactivas y realizan actividades de
 retención
▪ Modelos predictivos permiten determinar qué clientes presentan
 mayor riesgo de fuga
▪ Componente clave de programas de gestión de pérdida de clientes
▪ Presupuestos limitados implican que actividades de retención deben
 ser focalizadas
▪ Programas de retención dirigidos a clientes que no están en riesgo
 de fuga podría tener efectos no deseados

[pág. 17]
Ejemplo Simple
17
  CMO de empresa de telefonía interesada en
 predecir fuga
  Features:
  Probabilidad de recomendar (usada en Net Promoter
 Score). Escala 1-10

[pág. 18]
CMO INTUYE QUE FUGA PUEDE ESTAR
 RELACIONADA CON PROB. DE RECOMENDAR
18
 𝑝𝑡𝑟 en escala 1-10

[pág. 19]
EXPLORACIÓN DE DATOS
19
 ¿Qué % de los clientes decide terminar su relación con la empresa?

[pág. 20]
¿ES LA PROB. DE RECOMENDAR UN POTENCIAL
 PREDICTOR DE FUGA?
20
 ❑ Relación entre “Fuga” y
 “Probabilidad de Recomendar”
 ❑ ¿Qué sugieren los datos? ¿Existe
 relación entre probabilidad de
 recomendar y fuga?
 ❑ ¿Qué nos dice un modelo de
 Regresión Lineal?

[pág. 21]
Ajuste de Modelo Lineal
21
 𝑦 = 𝛽0 + 𝛽1 ∙ 𝑝𝑡𝑟 + 𝜀
 fuga 𝑦 ∈ {0, 1}

[pág. 22]
Ajuste de Modelo Lineal
22
 𝑦 = 𝛽0 + 𝛽1 ∙ 𝑝𝑡𝑟 + 𝜀
 fuga 𝑦 ∈ {0, 1} 𝐸[𝑦|𝑝𝑡𝑟] = 𝑃 𝑦 = 1 𝑝𝑡𝑟
 𝑃 𝑦 = 1 𝑝𝑡𝑟 = 𝛽0 + 𝛽1 ∙ 𝑝𝑡𝑟
 Modelo asume relación lineal entre 𝑝𝑡𝑟 y probabilidad de fuga

[pág. 23]
Ajuste de Modelo Lineal
23
 ❑ Notar que:
 ▪ Predicciones pueden tomar valores
 entre 0 y 1
 Interpretación de
 “probabilidad de fuga”
 ▪ Efecto de cambio en variable 𝑝𝑡𝑟
 es constante

[pág. 24]
APLICACIÓN DE REGRESIÓN LINEAL ES
 PROBLEMÁTICO EN ESTE CONTEXTO
24
 ❑ ¿Qué problemas tiene el ajuste del
 modelo lineal?
 ▪ Probabilidad de fuga puede ser
 mayor que 1 o menor que 0
 ▪ ¿Es razonable que el efecto sea
 constante para cualquier valor de
 la “probabilidad de recomendar”?

[pág. 25]
Modelación usando Regresión Logística
25
  El modelo de regresión logística se hace cargo de
 los dos problemas anteriores
  Probabilidad de fuga acotada al intervalo [0, 1]
  Cambio en probabilidad de fuga ante un cambio en
 satisfacción (ptr) mayor cuando probabilidad de fuga
 es cercano a 0,5 (versus extremos)

[pág. 26]
Modelación usando Regresión Logística
26
 ❑ Regresión logística asume que el riesgo de fuga es lineal en
 el (los) predictor(es)
 𝑣 = 𝛽0 + 𝛽1 ∙ 𝑥
 𝑣 es un índice que mide riesgo de fuga del cliente

[pág. 27]
MODELACIÓN USANDO REGRESIÓN LOGÍSTICA
27
 ❑ Modelo usa transformación logística para garantizar que la
 probabilidad ajustada se encuentre en intervalo [0, 1]
 𝑒𝑣
 𝑃 𝑦=1𝑥 =
 1 + 𝑒𝑣
 Función logística

[pág. 28]
Probabilidad de Fuga versus 𝑥 en
 Modelo Logístico
28
 𝑑𝑝 𝑒𝑣
 = 𝑣 2
 =𝑝∙ 1−𝑝
 𝑑𝑣 1+𝑒
 𝑑𝑝 𝑑𝑝 𝑑𝑣 Efecto es máximo
 = = 𝛽1 𝑝 ∙ 1 − 𝑝
 𝑑𝑥 𝑑𝑣 𝑑𝑥 cuando 𝑝 = 0.5
 Nota: 𝑝 ≡ 𝑃 𝑦 = 1 𝑥

[pág. 29]
29
 (𝛽1 = 1)

[pág. 30]
RELACIÓN ENTRE ÍNDICE DE RIESGO Y
 PROBABILIDAD DE FUGA
30
 ❑ Podemos escribir la probabilidad
 Probabilidad Logística
 de que 𝑦 = 1 como
 0.8
 𝑃𝑟𝑜𝑏𝑎𝑏𝑖𝑙𝑖𝑑𝑎𝑑
 𝑒 (𝛽0 +𝛽1 ∙𝑥)
 0.4
 𝑃 𝑦=1𝑥 =
 1 + 𝑒 (𝛽0 +𝛽1 ∙𝑥)
 0.0
 -6 -4 -2 0 2 4 6
 𝑣
 u

[pág. 31]
Probabilidad de Fuga y Satisfacción
 (𝑝𝑡𝑟): Ajuste de Modelo Logístico
31
 ❑ Notar que ahora:
 ▪ Predicciones sólo toman valores
 entre 0 y 1
 ▪ Cambios en “prob. de
 recomendar” influyen poco en los
 extremos
 ▪ Efecto es máximo para clientes cuya
 prob. de fuga es cercana a 0,5

[pág. 32]
Conveniente Interpretar Modelo en
 Términos de “Odds Ratio”
32
  Odds Ratio: Ratio entre probabilidad de ocurrencia
 y no ocurrencia
 𝑝
 𝑂𝑅 =
 1−𝑝

[pág. 33]
Odds Ratios vs. Probabilidades
33
 𝑝 1−𝑝 OR
 0.25 0.75 1/3
 0.50 0.50 1
 0.75 0.25 3
 0.80 0.20 4

[pág. 34]
Interpretación en Términos de “Odds
 Ratio”
34
 ▪ Conveniente reescribir el modelo logit como:
 𝑝
 𝑙𝑜𝑔 = 𝛽0 + 𝛽1 𝑝𝑡𝑟
 1−𝑝
 OR
 Probabilidad de
 recomendar
 Nota: 𝑝 ≡ 𝑃 𝑦 = 1 𝑝𝑡𝑟

[pág. 35]
Odds Ratio vs. Probabilidades
35
 4
 0
 3
 𝑟𝑎𝑡𝑖𝑜)
 Ratio
 Log Chances
 -2
 Chances
 2
 log(𝑜𝑑𝑑𝑠
Odds
 -4
 1
 -6
 0
 0.0 0.2 0.4 0.6 0.8 0.0 0.2 0.4 0.6 0.8
 Probabilidad de Éxito Probabilidad de Éxito

[pág. 36]
Modelo Logístico: Implementación en R
36
 Modelo lineal generalizado
 Variable respuesta binaria

[pág. 37]
37

[pág. 38]
INTERPRETACIÓN DE RESULTADOS
38
OR si 𝑝𝑡𝑟 𝑙𝑜𝑔 𝑂𝑅 = 8,4 − 2,1 ∙ 𝑝𝑡𝑟
aumenta en
1 unidad
 𝑂𝑅′
 − 1 = 𝑒𝑥𝑝 −2.1 − 1 = −0,878
 𝑂𝑅
 Un aumento en 1 punto en la …asociado a una caída de
 probabilidad de un 87,8% en las chances de
 recomendar… fuga

[pág. 39]
Efecto Parcial en Modelo Logístico
39
 𝑙𝑜𝑔 𝑂𝑅 = 8,4 − 2,1 ∙ 𝑝𝑡𝑟
 𝑙𝑜𝑔 𝑂𝑅′ = 8,4 − 2,1 ∙ (𝑝𝑡𝑟 + 1)
 ⇒ 𝑙𝑜𝑔 𝑂𝑅′ − 𝑙𝑜𝑔[𝑂𝑅] = −2,1
 𝑂𝑅′
 ⇒ 𝑙𝑜𝑔 = −2,1
 𝑂𝑅
 ⇒ 𝑂𝑅′
 = 𝑒𝑥𝑝(−2,1)
 𝑂𝑅

[pág. 40]
Efecto Parcial
 Cambio Infinitesimal en 𝑥
40
 • En el límite, ante un cambio infinitesimal en el predictor
 𝑑𝑂𝑅
 = 𝛽1 ∙ 𝑑𝑥
 𝑂𝑅

[pág. 41]
41 𝐷𝑒𝑣𝑖𝑎𝑛𝑐𝑒 = −2 ∙ [log 𝐿𝑖𝑘𝑒𝑙𝑖ℎ𝑜𝑜𝑑(𝑚𝑜𝑑𝑒𝑙𝑜 − log 𝐿𝑖𝑘𝑒𝑙𝑖ℎ𝑜𝑜𝑑(𝑚𝑜𝑑𝑒𝑙𝑜 𝑠𝑎𝑡𝑢𝑟𝑎𝑑𝑜 ]

[pág. 42]
42 𝐴𝐼𝐶 = 𝑅𝑒𝑠𝑖𝑑𝑢𝑎𝑙 𝐷𝑒𝑣𝑖𝑎𝑛𝑐𝑒 + 2𝑘

[pág. 43]
USO DE MODELACIÓN PREDICTIVA EN FUGA
❑ Supongamos que clientes renuevan contrato cada 12 meses
❑ Nos interesa anticipar esa fuga cuando cliente lleva (ej.) 6 meses
❑ Usamos datos de clientes que completaron ciclo de 12 meses
 ▪ Observamos su decisión de fuga a los 12 meses
 ▪ Observamos sus características (uso del servicio, respuesta a ofertas,
 interacciones con servicio al cliente, variables sociodemográficas)
 durante primeros 6 meses

[pág. 44]
USO DE MODELACIÓN PREDICTIVA EN FUGA (2)
❑ Estimamos (o entrenamos) el modelo usando datos de clientes que
 completaron un ciclo de 12 meses
 ▪ Predictores observados durante primeros 6 meses
 ▪ Respuesta: Decisión de fuga en el mes 12
❑ Problema: Para saber si el modelo predice bien necesitamos
 probarlo en “nueva data”
 No es posible esperar a que se genere “nueva data” (demasiado tarde)

[pág. 45]
USO DE MODELACIÓN PREDICTIVA EN FUGA (3)
❑ Solución: Partición aleatoria de datos históricos
 ▪ Muestra de entrenamiento (training) usada en estimación
 ▪ Muestra de validación (testing) usada en evaluación
❑ Si modelo predice con precisión, lo aplicamos a datos de clientes
 que llevan 6 meses para estimar su probabilidad de fuga y dirigir
 programas

[pág. 46]
USO DE MODELACIÓN PREDICTIVA EN FUGA
 CLIENTES OBSERVADOS POR 12 MESES CLIENTES QUE LLEVAN 6 MESES
 Variables predictivas: Variables predictivas:
 - Usos - Usos
 - Respuestas - Respuestas
 - Interacciones con call center - Interacciones con call center
 - Variables sociodemográficas - Variables sociodemográficas
 Resultado: Churn o No Churn Resultado Desconocido
 Estimación de Modelo Si modelo predice bien
 Predicción Predicción
 de Churn de Churn
 Training Sample Testing Sample Fuente: Adaptado de Anderson & Zettelmeyer (2021)

[pág. 47]
ENTRENAMIENTO Y VALIDACIÓN DEL MODELO
47
 ❑Separamos muestra en training (7.000) y testing (3.000)
 ❑Estimamos modelo usando training data y predecimos para
 valores de 𝑝𝑡𝑟 en testing data

[pág. 48]
Evaluación de Predicciones
48
  Existen distintas métricas para evaluar predicciones de
 modelo de clasificación
  Procedimiento tradicional en Marketing:
  Análisis de deciles y uso de “Curva de Ganancias” + ”Área bajo
 la Curva de Ganancias” (AUC)
  Métricas más ampliamente utilizadas:
  Métricas derivadas de matriz de confusión (sensibilidad, etc.)
  Curva ROC y “Área bajo Curva ROC” (AUC)

[pág. 49]
Evaluación de Predicciones: Ganancias
49
  Procedimiento involucra ordenar a todos los clientes (muestra de
 prueba) de acuerdo a su probabilidad de churn predicha por el
 modelo
  Clasificamos a los clientes en 10 deciles
  Decil 1 incluye a clientes con mayor probabilidad de fuga
  Identificamos # clientes que efectivamente se fugan en cada decil
 (ganancias)
  % de ganancias definidas como # de clientes que efectivamente se
 fugan en un decil por total de clientes fugados

[pág. 50]
Ejemplo: Tabla de Ganancias y Ganancias Acumuladas
 Decil # Clientes # Churners % Churners Cum. Gains Cum Gains %
 1 300 29610% de clientes
 0.28 con mayor296 0.28
 2 300 276probabilidad de fuga
 0.26 572 0.54
 3 300 219 0.21 791 0.75
 4 300 138 0.13 929 0.88
 5 300 79 0.07 1008 0.95
 6 300 30 0.03 1038 0.98
 7 300 14 0.01 1052 1.00
 8 300 5 0.00 1057 1.00
 9 300 0 0.00 1057 1.00
 10 300 0 0.00 1057 1.00
50 Total 3000 1057 1.00

[pág. 51]
Ejemplo: Tabla de Ganancias y Ganancias Acumuladas
 Ganancias
 Decil # Clientes # Churners % Churners Cum. Gains Cum Gains %
 # de clientes que
 1 300 296 0.28 296 0.28
 efectivamente se fuga
 2 300 276 0.26 572 0.54
 3 300 219 0.21 791 0.75
 4 300 138 0.13 929 0.88
 5 300 79 0.07 1008 0.95
 6 300 30 0.03 1038 0.98
 7 300 14 0.01 1052 1.00
 8 300 5 0.00 1057 1.00
 9 300 0 0.00 1057 1.00
 10 300 0 0.00 1057que se
 Total de clientes 1.00
51 Total 3000 1057 fuga
 1.00

[pág. 52]
Ejemplo: Tabla de Ganancias y Ganancias Acumuladas
 Decil # Clientes # Churners % Churners Cum. Gains Cum Gains %
 296
 1 300 296 0.28 296
 0.28 = 0.28
 1057
 2 300 276 0.26 572 0.54
 3 300 219 0.21 791 0.75
 4 300 138 0.13 929 0.88
 5 300 79 0.07 1008 0.95
 6 300 30 0.03 1038 0.98
 7 300 14 0.01 1052 1.00
 8 300 5 0.00 1057 1.00
 9 300 0 0.00 1057 1.00
 10 300 0 0.00 1057 1.00
52 Total 3000 1057 1.00

[pág. 53]
Ejemplo: Tabla de Ganancias y Ganancias Acumuladas
 Decil # Clientes # Churners % Churners Cum. Gains Cum Gains %
 1 300 296 0.28 296 0.28
 2 300 276 0.26 572 0.54
 3 300 219 0.21 791 0.75
 4 300 138 0.13 929 0.88
 5 300 79 0.07 1008 0.95
 6 300 30 0.03 1038 0.98
 7 300 14 0.01 1052 1.00
 8 300 5 0.00 1057 1.00
 9 300 0 0.00 1057 1.00
 10 300 0 0.00 1057 1.00
53 Total 3000 1057 1.00

[pág. 54]
EVALUACIÓN DE PREDICCIONES
 CURVA DE GANANCIAS ACUMULADAS Y AUC
54
 1
 “Curva” de
 Porcentaje de “Churners”
 Ganancias
 0.8
 Acumuladas
 asociada a
 0.6
 0.54 selección
 aleatoria de
 0.4
 “churners”
 0.28
 0.2
 0
 0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1
 Porcentaje de Clientes

[pág. 55]
EVALUACIÓN DE PREDICCIONES
 CURVA DE GANANCIAS ACUMULADAS Y AUC
55
 1
 𝐴𝑈𝐶 = 0,788
 Porcentaje de “Churners”
 0.8
 0.9 – 1.0 = Excelente
 0.6 0.8 – 0.9 = Bueno
 0.7 – 0.8 = Regular
 0.4 < 0.6 = Pobre
 0.2
 0
 0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1
 Porcentaje de Clientes

[pág. 56]
EVALUACIÓN DE PREDICCIONES
 GRÁFICO DE GANANCIAS ACUMULADAS Y AUC
56
 1 Curva
 𝐴𝑈𝐶 = 0,788
 Ideal
 Porcentaje de “Churners”
 0.8
 0.9 – 1.0 = Excelente
 0.6 0.8 – 0.9 = Bueno
 0.7 – 0.8 = Regular
 0.4 < 0.6 = Pobre
 0.2
 0
 0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1
 Porcentaje de Clientes

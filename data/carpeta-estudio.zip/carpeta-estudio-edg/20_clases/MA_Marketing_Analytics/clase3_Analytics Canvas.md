# Marketing Analytics · clase3_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 LAB 1: ANÁLISIS DE DATOS DE
 VENTAS EN RETAIL
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Agenda
2
  Análisis de base de datos típica de retail usando R
  Carga de librerías y datos
  Exploración de la estructura de la data
  Estadística descriptiva
  Visualización de evolución de ventas
  Visualización de variables correlacionadas con ventas
  Análisis de potenciales determinantes de demanda

[pág. 3]
¿Qué es R?
3
  Lenguaje de programación especializado en
 manipulación, visualización y análisis estadístico
  Gratis y de código abierto
  Múltiples paquetes desarrollados por usuarios
  ~ 21.000 (https://cran.r-project.org/web/packages/)
  R Studio es un IDE desarrollado para facilitar
 interacción con R

[pág. 4]
PRIMERA SESIÓN DE R
 R STUDIO
4
 Símbolo “>“ indica que R
 está listo para recibir input

[pág. 5]
PRIMERA SESIÓN DE R
 R STUDIO
5
 Objetos en memoria
 de trabajo
 Símbolo “>“ indica que R
 está listo para recibir input

[pág. 6]
PRIMERA SESIÓN DE R
 R STUDIO
6
 Objetos en memoria
 de trabajo
 Gráficos
 Símbolo “>“ indica que R
 está listo para recibir input

[pág. 7]
En Canvas
7

# Marketing Analytics · clase13_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 ANALÍTICA DE CLIENTES:
 INTRODUCCIÓN
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Plan
2
  ¿Qué entendemos por Analítica de Clientes?
  Relación con estrategia de centricidad en el cliente
  Ejemplos de uso de analítica de clientes en
 empresas centradas en el cliente
  Auditoría de la base de clientes

[pág. 3]
¿Qué Entendemos por Analítica de
 Clientes?
3
 “Sub-disciplina de la analítica de marketing
 que involucra la recolección, manejo, análisis y
 explotación estratégica de datos granulares
 sobre el comportamiento, características y
 actitudes de los clientes”
 Unidad de Análisis: Cliente individual

[pág. 4]
Características Distintivas de la Analítica
 de Clientes
4
  Análisis de datos granulares a nivel de cliente individual
  Aplicable a organizaciones con/sin fines de lucro, contextos
 B2C/B2B
  Datos incluyen comportamiento de clientes
  Historial de transacciones
  Respuesta a campañas
  Clickstream
  Orientación a alcanzar objetivos estratégicos

[pág. 5]
¿Qué Entendemos por “Cliente”?
5
 “Persona que compra en un establecimiento o
 utiliza los servicios de un profesional o un
 establecimiento.”
 Diccionario de la RAE

[pág. 6]
¿Qué Entendemos por “Cliente”?
6
  ¿Es necesario que exista un pago?
  Usuarios de Google, personas atendidas por NGO
  ¿Quien paga o quien usa el producto?
  Pasaje en vuelo corporativo, MBA pagado por
 empleador
  Clave: Consistencia en el análisis
  Diferentes definiciones para diferentes propósitos

[pág. 7]
Analítica de Clientes es el Motor de una
 Estrategia Cliente-Céntrica
7
 “Estrategia consistente en la alineación del
 desarrollo y entrega de productos y servicios de
 la compañía con las necesidades actuales y
 futuras de un conjunto selecto de clientes en
 orden a maximizar el valor de largo plazo de la
 firma.”
 Fader (2020), “Customer Centricity”
 Regla 80-20

[pág. 8]
¿Qué Caracteriza a una Organización
 Cliente-Céntrica?
8
  Capacidad de seguir el comportamiento del cliente
 en el tiempo
  Uso de métricas granulares orientadas al futuro
  Reconoce a clientes valiosos como motor de
 crecimiento
  Desarrollo de productos no visto como fin en sí
 mismo

[pág. 9]
¿Verdadero o Falso?
9
 “Una cultura cliente-céntrica reconoce que el
 cliente siempre tiene la razón”
 Verdadero
 Falso

[pág. 10]
Etapas Clave en Relación con Cliente
 01 02 03
 ADQUISICIÓN DESARROLLO RETENCIÓN
 ¿Qué prospectos ¿Cómo aumentar ¿Cómo evitar fuga
 atraer? valor del cliente? de clientes?

[pág. 11]
Etapa de Adquisición
▪ Organización cliente-céntrica enfocada en
 ➢ Identificar a clientes más valiosos Dificultad: Ausencia de datos
 ➢ Encontrar prospectos similares de comportamiento
▪ Enfoque habitual
 ➢ Publicidad en medios masivos
 ➢ Marketing directo basado en datos socio-demográficos
 ➢ Fader & Hardie: CLV varía más intra segmento que entre segmentos
▪ Enfoque más selectivo
 ➢ Profile & Score (Ej. FB “lookalike audiences”)
 ➢ Referencias

[pág. 12]
Etapas de Desarrollo y Retención
❑ Desarrollo. ¿Cómo aumentamos el valor de nuestros clientes?
 ▪ Modelos de direccionamiento de campañas
 ▪ Modelos de cross-selling
 ▪ Market basket analysis
 ▪ Sistemas de recomendación
❑ Retención. ¿Cómo evitar fuga de clientes más valiosos?
 ▪ Modelos de predicción de fuga
 ▪ Modelos de uplift

[pág. 13]
13 Ejemplo: Harrah´s Entertainment Inc.

[pág. 14]
Contexto
14
  Compañía operadora de casinos en EEUU
  Tamaño de industria: $31.000 millones en ‘99
  Operaba 21 casinos en 17 ciudades hacia el año 2000
  Phil Satre (Chairman y CEO) había liderado expansión
 de la compañía desde 1984
  Crecimiento explosivo
  Altamente rentable

[pág. 15]
Ubicación Geográfica de Propiedades
 de Harrah´s
15

[pág. 16]
Situación de Harrah’s a fines de 1990s
16
  Competidores habían entrado en mercados en que operaba
 Harrah’s con mejores propiedades
  The Mirage, GMM en Las Vegas
  Opciones estratégicas: (1) Innovación de producto; (2)
 Liderazgo en costos; (3) Mejorar relaciones con clientes
  CEO opta por foco en lealtad del cliente
  Programa de lealtad Total Gold lanzado en 1997
  Limitación: Propiedades autónomas
  Desempeño en 1998 inferior al esperado

[pág. 17]
Diagnóstico e Iniciativas
17
  Gary Loveman, nuevo COO/CMO
  Uso poco efectivo de data transaccional
  Baja lealtad: 36 centavos de dólar gastados en Harrah’s
 por cada $1 de gasto en casinos
  Iniciativas
  Cambio en estructura organizacional
  Construcción de marca y mejora de servicio
  Explotación de oportunidades de relaciones con clientes

[pág. 18]
Componentes Clave del Programa de
 CRM de Harrah’s
18
  Total Gold Program
  Motiva a clientes a consolidar juego
  Datos permiten ejecutar estrategias de marketing directo
  Programa de analítica de clientes
  Identificación de segmento de jugadores cross-market
  Identificación de clientes de alto valor (82% de ingresos
 asociado a 26% de clientes)
  Uso de modelos predictivos y analítica causal para
 aumentar valor vía ofertas de marketing dirtecto

[pág. 19]
Lecciones del Caso Harrah’s
19
  Importancia de conocer bien al cliente
  Importancia del foco en el Valor de Largo Plazo del
 Cliente
  Importancia de modelos predictivos y la combinación
 de modelos y decisiones gerenciales
  Estrategia de marketing basada en datos puede
 generar resultados sobresalientes si es integrada
 dentro de una estrategia de negocios coherente

[pág. 20]
Aplicación de Estrategia
Cliente-Céntrica basada en
Datos

[pág. 21]
Profunda Crisis a Mediados de 2012
21
  Intensa competencia de
 retailers online
  Hubert Joly asume como
 nuevo CEO en septiembre
 50% de pérdida de valor
  ¿Qué hizo Joly para sacar bursátil en 6 años previos
 a Best Buy de crisis?

[pág. 22]
Diagnóstico y Estrategia
22
  Práctica extendida de show-rooming
  Joly adopta política de “igualación
 de precios”
  Fortalecimiento de canal online
  Uso de red de tiendas como puntos de
 despacho
  Análisis de datos a nivel de clientes:
 Tiendas físicas importantes

[pág. 23]
Estrategia Cliente-Céntrica basada en
 Datos
23
  Análisis de datos revela segmento de
 alto valor
  55% de ingresos proveniente de clientes
 que requieren ayuda experta e
 instalación
  Creciente demanda por expertise de
 “smart appliances”
 • Capacitación constante de personal de tiendas
 • Equipamiento de GeekSquad para soporte e instalación

[pág. 24]
Contraste con Firma Producto Céntrica
 Cliente Céntrica Producto Céntrica
 FOCO EN CLIENTE INDIVIDUAL FOCO EN PRODUCTO
 RELACIONES TRANSACCIONES
 RETENCIÓN/DESARROLLO DE CLIENTES ADQUISICIÓN DE CLIENTES
 RENTABILIDAD DEL CLIENTE RENTABILIDAD DEL PRODUCTO

[pág. 26]
26 Auditoría de la Base de Clientes

[pág. 27]
¿Qué es una Auditoría a la Base de
 Clientes?
27
 “Revisión sistemática del comportamiento de
 compra de los clientes de una firma usando
 los datos capturados por sus sistemas de
 transacciones”
 Fader, Hardie & Ross (2022), “The Customer-Base Audit”
 Análisis exploratorio y diagnóstico

[pág. 28]
Tres Dimensiones en Datos
 Transaccionales
28
 ¿Quién compra?
 ¿Cuándo compra?
 ¿Qué compra?
 Fader, Hardie & Ross (2022)

[pág. 29]
Perspectiva Tradicional
29

[pág. 30]
Perspectiva Focal en Analítica de Clientes
30

[pág. 31]
Perspectiva Focal en Analítica de Clientes
 Transacciones en el Tiempo
31
 adquiridos en
 periodo 1
 adquiridos en
 periodo 2
 .
 .
 .

[pág. 32]
Auditoría de la Base de Clientes en
 Madrigal
32
  Retailer multi-canal y multi-categoría
  Tiendas físicas + ventas online
  Vestuario, calzado, alimentos, etc.
  Programa de lealtad le permite seguir a clientes en
 el tiempo
  > 3MM de clientes en 2019
  Datos para 2016-2019

[pág. 33]
Madrigal: Desempeño Anual
33
 $583
 $477.9
 $405
 $389.4
 $280
 $231.4
 $178.7 $191.2

[pág. 34]
Organización del Análisis: “5 Lentes”
34
  Lente 1: Análisis de corte transversal de clientes
  Lente 2: Comparación intertemporal de
 comportamiento de compra
  Lente 3: Análisis de cohorte de clientes
  Lente 4: Comparación inter-cohorte
  Lente 5: Análisis general de base de clientes

[pág. 35]
Lente 1: Análisis de Corte Transversal de
 Clientes
35

[pág. 36]
Análisis: 3 D’s
36
  Examen de Distribuciones de resultados (gasto,
 utilidad)
  Uso de Descomposiciones de resultados en métricas
 clave (Ej. AOV, AOF, márgenes)
  Análisis de Deciles de clientes

[pág. 37]
¿Qué Sugiere la Distribución del Gasto
 Total en 2019?
37

[pág. 38]
Análisis de Deciles
38

[pág. 39]
Descomposición del Gasto Total
39
 𝐺𝑎𝑠𝑡𝑜 𝑇𝑜𝑡𝑎𝑙 = # 𝑇𝑟𝑎𝑛𝑠𝑎𝑐𝑐𝑖𝑜𝑛𝑒𝑠 × Gasto Prom. por Trans.

[pág. 40]
Componentes del Gasto Total
40

[pág. 41]
Heterogeneidad en Utilidades
41

[pág. 42]
Análisis de Deciles
42
 20% de
 clientes
 representan
 un 58% de
 utilidad

[pág. 43]
Descomposición de Utilidad
43
 𝑈𝑡𝑖𝑙𝑖𝑑𝑎𝑑 𝑇𝑜𝑡𝑎𝑙 = #𝐶𝑙𝑖𝑒𝑛𝑡𝑒𝑠 × 𝑀𝑎𝑟𝑔𝑒𝑛 × 𝐴𝑂𝑉 × 𝐴𝑂𝐹

[pág. 44]
Descomposición de la Utilidad
44
 Fader, Hardie & Ross (2022)

[pág. 45]
Descomposición de Utilidad
45

[pág. 46]
Lentes 3 y 4: Análisis de Cohortes de
 Clientes
46
  Análisis de cohortes permite seguir a mismos clientes en
 el tiempo
  Tipos de análisis
  Descomposición de ingresos/utilidades de cohorte individual
  Análisis de repetición de compra
  Comparación de ingresos/utilidades entre cohortes (C3)

[pág. 47]
Ingresos Trimestrales de Cohorte
 Q1/2016
47
 294.450 individuos
 hicieron su primera
 compra en Madrigal el
 1er trimestre de 2016

[pág. 48]
Descomposición de Ingresos de Cohorte
48
𝐼𝑛𝑔𝑟𝑒𝑠𝑜𝑠 𝐶𝑜ℎ𝑜𝑟𝑡𝑒 = 𝑇𝑎𝑚𝑎ñ𝑜 𝑑𝑒 𝐶𝑜ℎ𝑜𝑟𝑡𝑒 × % 𝑀𝑖𝑒𝑚𝑏𝑟𝑜𝑠 𝐴𝑐𝑡𝑖𝑣𝑜𝑠 × 𝐴𝑂𝐹 × 𝐴𝑂

[pág. 49]
Descomposición de Ingresos de Cohorte
49
 Fader, Hardie & Ross (2022)

[pág. 50]
Descomposición de Ingresos de Cohorte
 (parte 1)
50

[pág. 51]
Descomposición de Ingresos de Cohorte
 (parte 2)
51

[pág. 52]
% de Cohorte que Repite Compra
52

[pág. 53]
Comparación de Resultados entre
 Cohortes
53
 $MM ‘000

[pág. 54]
Comparación entre Cohortes: Gráfico C3
54

[pág. 55]
Comparación entre Cohortes: Gráfico C3
 Utilidades ($ MM)
55

[pág. 56]
Comparación entre Cohortes: Gráfico C3
 # de Clientes
56

[pág. 57]
Adquisición de Nuevos Clientes
57
 1832
 1492 1517
 1273
 ‘000

[pág. 58]
¿Es Saludable la Base de Clientes de
 Madrigal?
58
  Adquisición de Clientes
  Retención
  Rentabilidad (profits)

[pág. 59]
Meta de Utilidades y Adquisición de
 Clientes
59
  Meta de utilidades 2020 = $ MM 320
  Tasa de retención de utilidades = 64% (supuesto)
  Utilidad por cliente adquirido = $72 (supuesto)
  ¿Cuántos clientes necesita adquirir Madrigal en
 2020 para cumplir su meta? ¿Es factible?

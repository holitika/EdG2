# Marketing Analytics · clase25_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 MODELOS DE ELECCIÓN DE
 MARCA
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Agenda
2
  Motivación de modelos de elección de marca
  Modelos de elección discreta y logit multinomial
  Especificación
  Estimación e implementación en R
  Bondad de ajuste

[pág. 3]
Proceso de Decisión de Compra del Consumidor
3
 1. Reconocimiento de Necesidad
 2. Búsqueda de Información
 3. Evaluación de Alternativas:
 -Percepción
 -Preferencia
 4. Decisión de Compra
 5. Decisiones Post-compra

[pág. 4]
Modelos de Elección de Marca
4
  ¿Qué factores influyen sobre la decisión de comprar una
 determinada marca?
  ¿Cómo puede el marketing mix influir sobre la decisión de
 compra?
  Distintos enfoques a modelación de elección de marca
  Modelos de elección discreta modelan preferencias del
 consumidor
  Elección de marca basada en preferencias por distintas
 marcas (conjunto de atributos)

[pág. 5]
Tipos de Preguntas Modelos de Elección
 Discreta Ayudan a Responder
5
  ¿Debería una marca de cereales
 para el desayuno invertir en
 exhibiciones especiales?
  ¿Cuál es su impacto esperado en
 demanda y utilidades?

[pág. 6]
Tipos de Preguntas Modelos de Elección
 Discreta Ayudan a Responder
6
  Fabricante de pan envasado
 está considerando
 incrementar el precio de una
 de sus marcas
  ¿Cómo se espera que impacte
 las ventas de la marca y de
 otras marcas del fabricante?

[pág. 7]
Tipos de Preguntas Modelos de Elección
 Discreta Ayudan a Responder
7
  Manufacturero de jugos naturales
 está considerando extender su línea
 de productos
  ¿Qué efectos esperaría encontrar
 en sus ventas en la categoría?
  Ventas incrementales vs.
 canibalización

[pág. 8]
Modelos de Elección Discreta
 Contexto
8
  Existen 𝑖 = 1, … , 𝐼 consumidores
  Cada consumidor en una ocasión de compra dada
 escoge entre 𝐽 marcas
  Alternativas son mutuamente excluyentes y colectivamente
 exhaustivas
  “No compra” puede ser incluida como alternativa
  Consumidor escoge una única marca

[pág. 9]
Modelos de Elección Discreta
 Contexto
9
  Para un consumidor 𝑖, queremos entender los
 determinantes de la probabilidad de que escoja la
 marca 𝑗 en la ocasión de compra 𝑡
 𝑃𝑟 𝑦𝑗𝑡 = 1 𝒙 = 𝑓(𝒙)
 Vector 𝒙 típicamente incluye variables del marketing mix (precios, publicidad, etc.)

[pág. 10]
Modelación de Probabilidad de Elección
 Supuesto de Utilidad Aleatoria
10
  Preferencias del consumidor representadas por una
 función de utilidad indirecta de la forma:
 𝑢𝑗𝑡 = 𝛽𝑗 + 𝛽1𝑗 𝑥1𝑗𝑡 + 𝛽2𝑗 𝑥2𝑗𝑡 + ⋯ + 𝛽𝑚𝑗 𝑥𝑚𝑗𝑡 + 𝜖𝑗𝑡
 Componente determinístico Componente
 aleatorio

[pág. 11]
Utilidad Aleatoria: Ejemplo
11
 𝑢𝑗𝑡 = 𝛽𝑗 + 𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑗𝑡 + 𝛽𝑓 𝐹𝑒𝑎𝑡𝑗𝑡 + 𝛽𝑑 𝐷𝑖𝑠𝑝𝑗𝑡 + 𝜖𝑗𝑡

[pág. 12]
Utilidad Aleatoria: Ejemplo
12
 𝑢𝑗𝑡 = 𝛽𝑗 + 𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑗𝑡 + 𝛽𝑓 𝐹𝑒𝑎𝑡𝑗𝑡 + 𝛽𝑑 𝐷𝑖𝑠𝑝𝑗𝑡 + 𝜖𝑗𝑡
 Componente determinístico incluye variables del marketing mix:
 • 𝑃𝑟𝑒𝑐𝑖𝑜𝑗𝑡 : Precio de marca 𝑗 en ocasión de compra 𝑡 ($)
 • 𝐹𝑒𝑎𝑡𝑗𝑡 : Dummy de promoción destacada (“feature advertising”)
 • 𝐷𝑖𝑠𝑝𝑗𝑡 : Dummy de exhibición especial “in-store”

[pág. 13]
Promoción Destacada (“feature ad”)
13

[pág. 14]
Exhibición Especial (“in-store displays”)
14

[pág. 15]
Constantes Específicas a las Alternativas (ASC)
15
  Las 𝛽𝑗 juegan un rol importante en el modelo
  Capturan influencias distintas de variables
 observables sobre preferencias
  Preferencia intrínseca por la marca
  Características de la marca no explícitamente
 incorporadas en el modelo

[pág. 16]
Supuesto de Racionalidad
16
  Consumidor compara distintas alternativas y escoge
 aquella que le reporta una mayor utilidad
 𝑃𝑟 𝑦𝑗𝑡 = 1 𝒙 = 𝑃𝑟 𝑢𝑗𝑡 = max 𝑢𝑘𝑡
 𝑘

[pág. 17]
Supuesto de Racionalidad
17
  Consumidor compara distintas alternativas y escoge
 aquella que le reporta una mayor utilidad
 Si 𝐽 = 2 (marcas “A” y “B”):
 𝑃𝑟 𝑦𝐴𝑡 = 1 𝒙 = 𝑃𝑟 𝑢𝐴𝑡 ≥ 𝑢𝐵𝑡

[pág. 18]
Supuestos Distribucionales
18
  Finalmente, el modelo introduce supuestos sobre la
 distribución del error (componente aleatorio):
 𝑢𝑗𝑡 = 𝑣𝑗𝑡 + 𝜀𝑗𝑡
 SD.1: 𝜀𝑗𝑡 y 𝑣𝑗𝑡 son ortogonales

[pág. 19]
Supuestos Distribucionales
 Modelo Logit Multinomial
19
  SD.2: Errores 𝜀𝑗𝑡 son independientes entre
 alternativas y ocasiones de compra
  SD.3: Errores 𝜀𝑗𝑡 se distribuyen T1EV (o Gumbel)
 Resultado Importante:
 Si el error se distribuye T1EV entonces la diferencia
 entre errores sigue una distribución logística

[pág. 20]
Probabilidad de Elección de Marca en
 Logit Multinomial
20
 • Bajo los supuestos anteriores, la probabilidad de que el
 consumidor 𝑖 escoja la marca 𝑗 en la ocasión de compra 𝑡 es:
 𝑒 𝑣𝑖𝑗𝑡
 Pr 𝑦𝑖𝑗𝑡 = 1|𝒙 = 𝐽
 σ𝑘=1 𝑒 𝑣𝑖𝑘𝑡

[pág. 21]
Derivación Probabilidad Logit
 Multinomial - Caso 𝐽 = 2
21
  Dos marcas: A y B
 𝑃𝑟 𝑦𝐴𝑡 = 1 = 𝑃𝑟 𝑢𝐴𝑡 ≥ 𝑢𝐵𝑡

[pág. 22]
Derivación Probabilidad Logit
 Multinomial - Caso 𝐽 = 2
22
  Dos marcas: A y B
 𝑃𝑟 𝑦𝐴𝑡 = 1 = 𝑃𝑟 𝑢𝐴𝑡 ≥ 𝑢𝐵𝑡
 = 𝑃𝑟 𝑣𝐴𝑡 + 𝜖𝐴𝑡 ≥ 𝑣𝐵𝑡 + 𝜖𝐵𝑡

[pág. 23]
Derivación Probabilidad Logit
 Multinomial - Caso 𝐽 = 2
23
  Dos marcas: A y B
 𝑃𝑟 𝑦𝐴𝑡 = 1 = 𝑃𝑟 𝑢𝐴𝑡 ≥ 𝑢𝐵𝑡
 = 𝑃𝑟 𝑣𝐴𝑡 + 𝜖𝐴𝑡 ≥ 𝑣𝐵𝑡 + 𝜖𝐵𝑡
 = 𝑃𝑟 𝜖𝐴𝑡 − 𝜖𝐵𝑡 ≥ −(𝑣𝐴𝑡 − 𝑣𝐵𝑡 )

[pág. 24]
Derivación Probabilidad Logit
 Multinomial - Caso 𝐽 = 2
24
  Dos marcas: A y B
 𝑃𝑟 𝑦𝐴𝑡 = 1 = 𝑃𝑟 𝑢𝐴𝑡 ≥ 𝑢𝐵𝑡
 = 𝑃𝑟 𝑣𝐴𝑡 + 𝜖𝐴𝑡 ≥ 𝑣𝐵𝑡 + 𝜖𝐵𝑡
 = 𝑃𝑟 𝜖𝐴𝑡 − 𝜖𝐵𝑡 ≥ −(𝑣𝐴𝑡 − 𝑣𝐵𝑡 )
 = 𝑃𝑟 𝜖𝐴𝑡 − 𝜖𝐵𝑡 < 𝑣𝐴𝑡 − 𝑣𝐵𝑡

[pág. 25]
Derivación Probabilidad Logit
 Multinomial - Caso 𝐽 = 2
25
  Dos marcas: A y B
 𝑃𝑟 𝑦𝐴𝑡 = 1 = 𝑃𝑟 𝑢𝐴𝑡 ≥ 𝑢𝐵𝑡
 = 𝑃𝑟 𝑣𝐴𝑡 + 𝜖𝐴𝑡 ≥ 𝑣𝐵𝑡 + 𝜖𝐵𝑡
 = 𝑃𝑟 𝜖𝐴𝑡 − 𝜖𝐵𝑡 ≥ −(𝑣𝐴𝑡 − 𝑣𝐵𝑡 )
 = 𝑃𝑟 𝜖𝐴𝑡 − 𝜖𝐵𝑡 < 𝑣𝐴𝑡 − 𝑣𝐵𝑡
 Probabilidad acumulada

[pág. 26]
Derivación Probabilidad Logit
 Multinomial - Caso 𝐽 = 2
26
  Por SD3, 𝜖𝐴𝑡 y 𝜖𝐵𝑡 se distribuyen T1EV
 (𝜖𝐴𝑡 − 𝜖𝐵𝑡 ) ∽ 𝑙𝑜𝑔𝑖𝑠𝑡𝑖𝑐𝑎

[pág. 27]
Derivación Probabilidad Logit
 Multinomial - Caso 𝐽 = 2
27
  Por SD3, 𝜖𝐴𝑡 y 𝜖𝐵𝑡 se distribuyen T1EV
 (𝜖𝐴𝑡 − 𝜖𝐵𝑡 ) ∽ 𝑙𝑜𝑔𝑖𝑠𝑡𝑖𝑐𝑎
  Función de probabilidad acumulada logística
 1
 𝐹 𝑧 = −∞ < 𝑧 < ∞
 1 + exp(−𝑧)

[pág. 28]
Derivación Probabilidad Logit
 Multinomial - Caso 𝐽 = 2
28
  Obtenemos:
 𝑃𝑟 𝑦𝐴𝑡 = 1 = 𝑃𝑟 𝜖𝐴𝑡 − 𝜖𝐵𝑡 < 𝑣𝐴𝑡 − 𝑣𝐵𝑡
 1
 =
 1 + exp(−(𝑣𝐴𝑡 − 𝑣𝐵𝑡 ))

[pág. 29]
Propiedades de Probabilidades Logit
29
 1. Probabilidad 𝑃𝑖𝑗𝑡 se encuentra entre 0 y 1
 2. Suma de probabilidades entre alternativas es 1
 3. Relación entre 𝑃𝑖𝑗𝑡 y 𝑣𝑖𝑗𝑡 tiene forma de 𝑆
 4. Sólo diferencias en utilidades afectan 𝑃𝑖𝑗𝑡
  Implica que sólo 𝐽 − 1 constantes de marca pueden
 identificarse

[pág. 30]
Relación entre Probabilidad Logit y
Utilidad Determinística
 1.2
𝑃𝑖𝑗𝑡
 1
 0.8
 0.6
 0.4
 0.2
 0
 𝑣𝑖𝑗𝑡
 13
 55
 61
 67
 73
 79
 85
 91
 97
 19
 25
 31
 37
 43
 49
 1
 7
 103
 109
 151
 157
 115
 121
 127
 133
 139
 145
 Probabilidad de elegir j

[pág. 31]
Sólo J-1 Constantes de Marca Pueden
 Identificarse
31
  Supongamos por simplicidad 2 marcas y función de
 utilidad indirecta
 𝑢𝑗𝑡 = 𝛽𝑗 + 𝜖𝑗𝑡
 𝑃𝑟 𝑦𝐴𝑡 = 1 = 𝑃𝑟 𝜖𝐴𝑡 − 𝜖𝐵𝑡 < 𝛽𝐴 − 𝛽𝐵
 Sólo diferencia puede identificarse
 Prodecimiento típico: Normalizar una de las ASC a cero

[pág. 32]
Probabilidad Logit Multinomial
 Ejemplo Simple
32
  3 marcas: A, B, C
  Función de utilidad indirecta:
 𝑢𝑗𝑡 = 𝛽𝑗 + 𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑗𝑡 + 𝜖𝑗𝑡
  Coeficientes estimados:
 𝛽𝐴 = 1; 𝛽𝐵 = −1; 𝛽𝑝 = −2

[pág. 33]
Probabilidad Logit Multinomial
 Ejemplo Simple
33
 ෍ exp(𝒗𝒌)
 Marca Precio 𝜷𝒋 𝜷𝒑 𝒗𝒋 exp(𝒗𝒋 ) Pr(𝑦𝑗 = 1)
 A 1.2 1 -2 -1.4 0.247 0.498 0.495
 B 1.0 -1 -2 -3.0 0.050 0.498 0.100
 C 0.8 0 -2 -1.6 0.202 0.498 0.405

[pág. 34]
Estimación vía Máxima Verosimilitud
34
  Datos de elecciones de 𝐼 consumidores entre 𝐽
 alternativas
  Estimador escoge valores de coeficientes que
 maximizan probabilidad conjunta de la muestra
  Probabilidad de que consumidor 𝑖 escoja marca 𝑗:
 𝐽
 ෑ 𝑃𝑖𝑗𝑡 𝑦𝑖𝑗𝑡
 𝑗=1

[pág. 35]
Estimación de Parámetros vía Máxima
 Verosimilitud
35
  Función de verosimilitud considera elecciones de
 todos los consumidores y ocasiones de compra:
 𝐼 𝑇 𝐽
 𝐿(𝜷) = ෑ ෑ ෑ 𝑃𝑖𝑗𝑡 𝑦𝑖𝑗𝑡
 𝑖=1 𝑡=1 𝑗=1

[pág. 36]
Aplicación: Estimación de Modelo Logit
 Multinomial en Categoría Crackers
36
  Muestra de 136
 consumidores que hacen
 3156 visitas en total
  4 marcas:
  Nabisco
  Keebler
  Sunshine
  Marca Propia

[pág. 37]
chid choice alt disp feat price lastchoice
 1 0 keebler 0 0 1.09 0
 1 1 nabisco 0 0 0.99 1
 1 0 private 0 0 0.71 0
 1 0 sunshine 0 0 0.99 0
 2 0 keebler 0 0 1.09 0
 2 0 nabisco 0 0 1.09 1
 2 0 private 0 0 0.78 0
 2 1 sunshine 1 0 0.49 0
 3 0 keebler 0 0 1.09 0
 3 1 nabisco 0 0 0.89 0
 3 0 private 0 0 0.78 0
 3 0 sunshine 0 0 1.03 1
 4 0 keebler 0 0 1.09 0
 4 1 nabisco 0 0 1.19 1
 4 0 private 0 0 0.64 0
 4 0 sunshine 0 0 1.09 0

[pág. 38]
Crackers: Modelo a Estimar
38
  Función de utilidad indirecta
 𝑢𝑖𝑗𝑡 = 𝛽𝑗 + 𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑗𝑡 + 𝛽𝑓 𝐹𝑒𝑎𝑡𝑗𝑡 + 𝛽𝑑 𝐷𝑖𝑠𝑝𝑗𝑡 + 𝜀𝑖𝑗𝑡
  Probabilidad de elección de marca 𝑗:
 𝑒 (𝛽𝑗 +𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑗𝑡 +𝛽𝑓 𝐹𝑒𝑎𝑡𝑗𝑡 +𝛽𝑑 𝐷𝑖𝑠𝑝𝑗𝑡 )
 𝑃𝑖𝑗𝑡 =
 σ𝐽𝑘=1 𝑒 (𝛽𝑘 +𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑘𝑡+𝛽𝑓 𝐹𝑒𝑎𝑡𝑘𝑡 +𝛽𝑑 𝐷𝑖𝑠𝑝𝑘𝑡 )

[pág. 39]
Estadística Descriptiva
39
  Participaciones de cada marca

[pág. 40]
Estadística Descriptiva
 Variables del Marketing Mix
40

[pág. 41]
Estimación en R
41
  Librería gmnl
  Sintaxis:

[pág. 42]
Estimación en R
42
  Resultados:

[pág. 43]
¿Cuán bueno es el Ajuste del Modelo?
43
  Objetivo de estimación es
 maximizar función de log
 verosimilitud (𝐿𝐿)
  Bondad de ajuste basada
 en valor de 𝐿𝐿 en el
 óptimo
  Métrica más utilizada:
 Pdeudo R-cuadrado de
 McFadden

[pág. 44]
Pseudo R-Cuadrado
 Pseudo-R2 basado en comparación de:
  𝐿𝐿 𝛽መ : Valor de función de LL evaluada en coeficientes estimados
  𝐿𝐿 0 : Valor de la función de LL en modelo nulo
 2
 𝐿𝐿 𝛽መ
 𝜌 =1−
 𝐿𝐿 0

[pág. 45]
Pseudo R-Cuadrado
 Pseudo-R2 (McFadden R-sq) se basa en comparación de:
  𝐿𝐿 𝛽መ : Valor de función de LL evaluada en coeficientes estimados
  𝐿𝐿 0 : Valor de la función de LL en modelo nulo
 𝐿𝐿 𝛽መ
 2
 𝜌 =1− 𝜌2 ∈ (0,1)
 𝐿𝐿 0
 Empíricamente 𝜌2 ∈ 0.2,0.4 indica un muy buen ajuste

[pág. 46]
Estimación Logit en Categoría Crackers:
Bondad de Ajuste

[pág. 47]
Inclusión de Variable de Lealtad de
 Marca
47
  Evidencia empírica sugiere que variable importante
 en la estimación es alguna medida de lealtad de
 marca (Ej. Guadagni & Little, 1983)
  Potencial medida de lealtad de marca es la última
 marca comprada
 𝑙𝑎𝑠𝑡𝑐ℎ𝑜𝑖𝑐𝑒𝑖𝑗𝑡 = 1 si consumidor 𝑖 escogió marca 𝑗 en 𝑡 − 1

[pág. 48]
Estimación Incluyendo “Last Choice”
48

[pág. 49]
Estimación Incluyendo “Last Choice”
 Bondad de Ajuste
49

[pág. 50]
Efectos Parciales
50
  Desde el punto de vista de la toma de decisiones
 de marketing, más importante que la bondad de
 ajuste son los efectos parciales de las variables del
 marketing mix
  ¿Cómo medimos el impacto de distintas acciones de
 marketing sobre la probabilidad de compra?

# Marketing Analytics · clase24 Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 MODELACIÓN DE TÓPICOS Y
 PREDICCIÓN
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Agenda
2
  Clase anterior: Introducción a la analítica de textos
  Enfoque bolsa de palabras (BoW)
  Exploración de datos
 ◼ Visualización de frecuencias, correlaciones entre términos, etc.
  Hoy: Análisis de datos textuales típicos
  Modelación de tópicos
  Análisis de Sentimientos
  Predicción usando datos textuales

[pág. 3]
Desafíos de Analítica de Textos
3
 Definición de
 Definición de Objetivos de la Analítica de Textos
 Problema
 Encuestas
 Emails Blogs Artículos
 Estado
 Medios
 Desorganizado Sociales
 Reseñas
 Estado
 Organizado Insights, recomendaciones o output de analítica

[pág. 4]
Enfoque de “Bolsa de Palabras”
4
  Reducción de complejidad vía tokenization
  Términos individuales o n-gramas
  Representación de texto como “bolsa de palabras”
  Trata documentos como si fuesen construidos tomando
 muestras aleatorias con reemplazo de una bolsa que
 contiene un vocabulario fijo

[pág. 5]
Representación “Bolsa de Palabras”
5
 “Hermoso teléfono impecable su calidad a
 muy buen precio y recibido antes de la
 fecha y sus audífonos inalámbricos
 geniales van muy bien con el teléfono”
 Hermoso teléfono impecable su calidad a muy …
 1 2 1 1 1 1 2 …

[pág. 6]
Etapas Claves en Analítica de Textos
6
 Transformación Análisis
 Organización Selección de en Arreglo (descripción,
 del Texto Features Numérico visualización,
 (tdm-dtm) predicción)

[pág. 7]
7
 Bastani, Namavari & Shaffer (Expert Systems with Applications, 2019)

[pág. 8]
8 Descripción y Visualizaciones

[pág. 9]
Gráfico de Frecuencias
9

[pág. 10]
10

[pág. 11]
Visualización de Asociaciones con
 “Apologies”
11

[pág. 12]
Dendrograma Jerárquico
12

[pág. 13]
Análisis Típicos usando Datos Textuales
13
  Modelación de tópicos
  Análisis de Sentimientos
  Modelos de Respuesta basados en Datos Textuales

[pág. 14]
14
 Topic Modeling

[pág. 15]
Importancia de Modelación de Tópicos
15
  ¿Cuáles son los temas clave tratados en grandes volumenes de
 datos no estructurados?
  Permite aprender de:
  “Pain points” de consumidores
  Detección de tendencias emergentes
  Creación de contenidos (¿Qué topicos resuenan mejor con audiencia
 meta?)
  Técnica de reducción de dimensionalidad

[pág. 16]
Topic Modeling
 Ejemplo (we8there.com)
16
 “Normalmente no escribiría una reseña sobre Waffle
 House pero esto lo amerita. Los trabajadores Amanda,
 Amy, Chery, James y J.D. son el equipo más agradable
 que he visto. Aunque fue sólo almuerzo, B.L.T y chili, fue
 grandioso. Lo mejor fue la música de Rock & Roll de los
 50s, no demasiado fuerte ni baja. Esta es una rara
 excepción a lo que todos Uds. pueden pensar que un
 Waffle House es. Sigan con el buen trabajo”.

[pág. 17]
Topic Modeling
 Ejemplo (we8there.com)
17
 “Normalmente no escribiría una reseña sobre Waffle
 House pero esto lo amerita. Los trabajadores Amanda,
 Amy, Chery, James y J.D. son el equipo más agradable
 que he visto. Aunque fue sólo almuerzo, B.L.T y chili, fue
 grandioso. Lo mejor fue la música de Rock & Roll de los
 50s, no demasiado fuerte ni baja. Esta es una rara
 excepción a lo que todos Uds. pueden pensar que un
 Waffle House es. Sigan con el buen trabajo”.

[pág. 18]
Topic Modeling
 Ejemplo (we8there.com)
18
 “Normalmente no escribiría una reseña sobre Waffle Tópico:
 House pero esto lo amerita. Los trabajadores Amanda,
 Amy, Chery, James y J.D. son el equipo más agradable ▪ Servicio
 ▪ Tipo de comida
 que he visto. Aunque fue sólo almuerzo, B.L.T y chili, fue
 ▪ Ambiente
 grandioso. Lo mejor fue la música de Rock & Roll de los
 50s, no demasiado fuerte ni baja. Esta es una rara
 excepción a lo que todos Uds. pueden pensar que un
 Waffle House es. Sigan con el buen trabajo”.

[pág. 19]
Latent Dirichlet Allocation
19
  Metodología más comúnmente utilizada en extracción
 de tópicos
  Trata tópicos como variables aleatorias latentes
  Análogo a factores en análisis factorial
  Modelo generativo
  Basado en proceso generador de documentos
  Tópicos estimados usando análisis bayesiano jerárquico

[pág. 20]
Latent Dirichlet Allocation
 Modelo Generador de Documentos
20
 ▪ Frecuencia de término 𝑡 en documento 𝑑 determinada por
 1. Probabilidad de que tópico 𝑘 esté representado en 𝑑: 𝜃𝑑𝑘
 2. Probabilidad de término 𝑡 en tópico 𝑘: 𝛽𝑘𝑡

[pág. 21]
Latent Dirichlet Allocation
 Modelo Generador de Documentos
21
 ▪ Frecuencia de término 𝑡 en documento 𝑑 determinada por
 1. Probabilidad de que tópico 𝑘 esté representado en 𝑑: 𝜃𝑑𝑘
 2. Probabilidad de término 𝑡 en tópico 𝑘: 𝛽𝑘𝑡
 ▪ Probabilidad de que 𝑡 se encuentre en documento 𝑑:
 𝑃 𝑡 𝑑 = 𝜃𝑑1 𝛽1𝑡 + 𝜃𝑑2 𝛽2𝑡 + … + 𝜃𝑑𝐾 𝛽𝐾𝑡
 Número de tópicos, K, predeterminado

[pág. 22]
Proceso Generador de Documentos
 Ejemplo
22
  Supongamos que 𝐾 = 2
  Ej. “servicio”, 𝑘
 = 1; “tipo de comida”, 𝑘 = 2
  Probabilidades de tópicos en documento:
 𝜃𝑑1 = 0.9; 𝜃𝑑2 = 0.1
  Probabilidad de término 𝑡 = “Profesional” en documento:
 𝑃 𝑡 𝑑 = 0.9𝛽1𝑡 + 0.1𝛽2𝑡

[pág. 23]
“Préstamo
 Automotriz”
 “Agencia de
 Cobranza”
 “Comunicaciones”
 3 tópicos más
 importantes
23
 Bastani, Namavari & Shaffer (Expert Systems with Applications, 2019)

[pág. 24]
Outputs del Análisis
24
  Distribución de palabras por tópico, 𝛽𝑘
  Ayudan en etiquetado de cada tópico
  Proporción de tópicos por documento, 𝜃𝑑
  Asignación de tópicos por palabra (término)

[pág. 25]
Ejemplo: Artículos de Associated Press
25
 ❑Modelo de K = 2 tópicos ajustado a artículos de Associated Press
 ▪ 2246 artículos de noticias publicados alrededor de 1988
 ▪ Librería topicmodels
 • Estimación de modelo LDA:

[pág. 26]
26

[pág. 27]
Ejemplo: Artículos de Associated Press
 Términos con más Alta Probabilidad de Ocurrencia en Cada
 Tópico
27
 ¿Qué representa
 cada tópico?

[pág. 28]
28
 Análisis de Sentimientos

[pág. 29]
Análisis de Sentimientos
29
  Extracción de intención emocional de autor(a) del texto
 (Ej. Contento/a, enojado/a, etc.)
  Uso de diccionarios (subjectivity lexicons)
  Distintos marcos conceptuales para definir emociones
  Ej. Plutchik’s Wheel of Emotion (8 emociones primarias)
  R sentiment library distingue entre 6 emociones (enojo,
 desagrado, miedo, felicidad, tristeza y sorpresa)

[pág. 30]
Plutchik’s Wheel of Emotion
 Emociones primarias:
 1) Enojo
 2) Miedo
 3) Tristeza
 4) Repugnancia
 5) Sorpresa
 6) Anticipación
 7) Confianza
 8) Alegría
30

[pág. 31]
Polaridad de un Documento
31
  Enfoque más simple distingue entre sentimientos
 positivos, negativos y neutros
  Análisis de polaridad
  Puede ser más preciso que enfoque que distingue
 entre múltiples emociones
  Ej. “sorpresa” puede tener connotación positiva o
 negativa

[pág. 32]
Aplicación: Análisis de Sentimientos en
 Airbnb
32
  ¿Qué características de propiedades de Airbnb son
 mencionadas en comentarios positivos/negativos?
  Datos: Comentarios de usuarios
 (huéspedes/arrendatarios) sobre su estadía
  1000 listados en Boston, MA, seleccionados
 aleatoriamente

[pág. 33]
Análisis de Sentimientos en Airbnb
 Cálculo de Polaridad
33
  Librería qdap en R determina puntaje de
 polaridad basado en cálculos aritméticos simples
  Usa diccionario desarrollado por la Universidad de
 Illiois, Chicago (6.800 palabras etiquetadas)
  Considera “valence shifters”: “No”, “Jamás”, “Muy”,
 “Extremadamente”, etc.

[pág. 34]
Análisis de Sentimientos en Airbnb
 Cálculo de Polaridad usando qdap
34
  Función de polaridad busca palabras positivas y negativas usando
 diccionario
  Función crea cluster de términos incluyendo las 4 palabras precedentes y
 las 2 siguientes a palabra polar
  Palabras neutras se cuentan como cero. Palabras positivas/negativas que
 forman base del cluster se cuentan como +1/-1. Palabras restantes no neutrales
 se consideran “valence shifters” y amplifican o reducen el valor de la palabra
 polar (por defecto) en factor 1.2/0.8
  Todos los valores del cluster se suman obteniendo un gran total
  Gran total se divide por la raíz cuadrada de todas las palabras en el
 pasaje

[pág. 35]
Análisis de Polaridad usando qdap
 Ejemplo Simple
35
  Comentarios:

[pág. 36]
Análisis de Polaridad usando qdap
 Ejemplo Simple
36

[pág. 37]
Análisis de Polaridad usando qdap
 Ejemplo Simple
37

[pág. 38]
Comentarios en Airbnb
38

[pág. 39]
Análisis de Sentimientos en Airbnb
 Distribución de Polaridad
39

[pág. 40]
Sentiment Analysis en Airbnb
 Nube de Palabras Comparativa
40

[pág. 41]
Predicción Usando Datos Textuales
41
  Ejemplo: Predicción de recomendación en tienda de
 ropa
  Target: Recomienda (1) / No recomienda (0)
  Features: Frecuencia de tokens en documento

[pág. 42]
Predicción usando Datos Textuales
42

[pág. 43]
43

[pág. 44]
44
 True positive rate
 0.0 0.2 0.4 0.6 0.8 1.0
 0.0
 0.2
 0.4
 0.6
 False positive rate
 0.8
 1.0
 0.14 0.31 0.48 0.65 0.82 0.99
 𝐴𝑈𝐶 = 0.813682

[pág. 45]
𝐴𝑈𝐶 = 0.9830892
45

[pág. 46]
Aplicación: Uso de Texto en Predicción
 de No Pago de Préstamos
46
 Netzer, Lemaire and Herzenstein, “When words Sweat: Identifying Signals for Loan Default in the Text of Loan Applications”,
 Journal of Marketing Research, 2019
 ¿Cuál de los siguientes solicitantes de préstamo tiene una mayor
 probabilidad de no pago?
 Solicitante #1: “Soy una persona Solicitante #2: “Si bien el último año en
 trabajadora, casado/a por 25 años, y nuestro nuevo hogar ha sido grandioso,
 tengo dos niños maravillosos. Por favor, el techo tiene una filtración y necesito un
 permítame explicar por qué necesito préstamo por $2000 para cubrir los
 ayuda. Usaría el préstamo de $2000 costos de la reparación. Pago todas las
 para reparar mi techo. Gracias, Dios lo cuentas (ej. préstamo automotriz, cable,
 bendiga, y prometo pagarle de vuelta.” servicios públicos) a tiempo.”

[pág. 47]
Idea Básica del Estudio
47
  Prestamistas (ej. bancos) basan decisión de préstamo en: (1)
 Solidez financiera; (2) Demografía; (3) Información de
 préstamo (monto, tasa, etc.); (4) Información obtenida de
 interacción con solicitante
  Texto de solicitud de préstamo podría entregar información
 predictiva de probabilidad de pago
  Intenciones, personalidad, circunstancias
  Análogo a lenguaje corporal detectado en interacciones con solicitante

[pág. 48]
Contexto
48
  Aplicación de herramientas
 de text mining y ML a
 120.000 solicitudes de
 préstamo
  Plataforma de
 crowdfunding prosper
 (prosper.com)

[pág. 49]
Comparación de Capacidad Predictiva
 con vs. sin Data de Texto
49

[pág. 50]
Comparación de Capacidad Predictiva:
 Curvas ROC
50

[pág. 51]
Palabras Indicativas de Pago
 Relacionadas
 Relativas a al tiempo
 “yo”
 Futuro Relativas
 financiero más
 auspicioso
 Alfabetismo
51
 financiero

[pág. 52]
Palabras Indicativas de No Pago
 Explicaciones
 Desesperación/
 Ruego Influencias
 Externas
 Dificultades
 en General
 Futuro
 Dificultades
 Financieras
 Relacionadas
 a Tiempo
 Palabras que
 apelan a
 prestamista Relacionadas
 con Trabajo
52 Palabras
 Extremas

[pág. 53]
Conclusiones
53
  Solicitudes escritas por quienes no pagan incluyen
 palabras/temas
  Relacionadas con la familia del/la solicitante
  Dificultades financieras/generales
  Menciones de Dios
  Menciones del futuro cercano
  Ruegos de ayuda
  Uso de verbos en presente y futuro

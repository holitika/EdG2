# Marketing Analytics · clase29 Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 ANÁLISIS CONJUNTO: ANÁLISIS Y
 SIMULADOR DE MERCADO
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Clase Anterior
2
  Uso de análisis conjunto en estimación de
 preferencias
  Productos vistos como un conjunto de atributos
  Cada atributo puede tomar distintos niveles
  Individuos evaluan perfiles completos de productos
  Técnicas econométricas utilizadas para estimar
 utilidades por niveles de atributos

[pág. 3]
Ejemplo: Preferencias por Smartwatch
3
 Vida de Pago
 Atributo Batería Celular Móvil Peso Pulso Marca Precio
 12 hrs No No 30 grs. No Samsung $ 199.990
 Niveles de 18 hrs Sí Sí 60 grs. Sí Apple $ 249.990
 Atributos
 1 día 90 grs. $ 299.990
 2 días $ 399.990

[pág. 4]
Modelo Conjunto Aditivo
Función de Utilidad Aleatoria
 𝑢𝑗 = 𝑢1𝑗 + 𝑢2𝑗 + ⋯ + 𝑢𝑟𝑗 + 𝜀𝑗
Utilidad de
perfil de Utilidades
producto 𝑗 parciales

[pág. 5]
Productos como Conjunto de Atributos
Smartwatch
 𝑢𝑆 = 𝑢𝑆𝑏 + 𝑢𝑆𝑣 + 𝑢𝑆𝑐 + 𝑢𝑆𝑝𝑚 +𝑢𝑆𝑝𝑢 + ⋯ + 𝜖𝑆
 Marca Vida Uso Pago Frecuencia
 Batería como Móvil Cardíaca
 Celular

[pág. 6]
Modelo Conjunto Aditivo
Utilidades Parciales
▪ Modelación más habitual (uso de dummies):
 𝑢𝑎𝑗 = 𝛽𝑎1 𝐷𝑎1,𝑗 + 𝛽𝑎2 𝐷𝑎2,𝑗 + ⋯ + 𝛽𝑎𝑚−1 𝐷𝑎𝑚−1,𝑗
 𝛽𝑎1 , 𝛽𝑎2 , … , 𝛽𝑎𝑚−1 𝑠𝑜𝑛 𝑐𝑜𝑒𝑓𝑖𝑐𝑖𝑒𝑛𝑡𝑒𝑠
 𝐷𝑎1,𝑗 , 𝐷𝑎2,𝑗 , … , 𝐷𝑎𝑚−1,𝑗 𝑠𝑜𝑛 𝑑𝑢𝑚𝑚𝑖𝑒𝑠 (𝑚 = 𝑁ú𝑚𝑒𝑟𝑜 𝑑𝑒 𝑛𝑖𝑣𝑒𝑙𝑒𝑠)

[pág. 7]
Recolección de Datos y Estimación
7
  Participantes evalúan distintos perfiles de producto
  Perfiles determinados en base a diseño
 experimental
  Estimación de utilidades asociadas a distintos
 niveles de atributos usando métodos econométricos
  Regresión múltiple
  Logit multinomial

[pág. 8]
Datos Estimación Smartwatch
perfil vida18 vida24 vida48 peso30 peso60 pulso apple precio19 precio24 precio29 R
 1 1 0 0 0 1 1 0 1 0 0 74
 2 0 0 1 0 0 1 0 1 0 0 87
 3 0 1 0 1 0 0 1 1 0 0 92
 4 0 0 0 0 0 0 1 1 0 0 65
 5 0 0 0 1 0 1 0 0 1 0 75
 6 0 1 0 0 1 0 0 0 1 0 82
 7 0 0 1 1 0 1 1 0 1 0 99
 8 1 0 0 0 0 0 1 0 1 0 64
 9 0 1 0 0 0 1 0 0 0 1 59
 10 0 0 0 0 0 0 0 0 0 1 57
 11 1 0 0 1 0 1 1 0 0 1 98
 12 0 0 1 0 1 0 1 0 0 1 71
 13 0 0 1 1 0 0 0 0 0 0 66
 14 1 0 0 1 0 0 0 0 0 0 68
 15 0 0 0 0 1 1 1 0 0 0 50
 16 0 1 0 0 0 1 1 0 0 0 66
 Matriz de Diseño Respuesta

[pág. 9]
Análisis de Regresión: Smartwatch
  Especificación:
 𝑅 = 𝛽0 + 𝛽𝑉𝐵18 𝐷𝑉𝐵18 + 𝛽𝑉𝐵24 𝐷𝑉𝐵24 + 𝛽𝑉𝐵 𝐷𝑉𝐵48 + 𝛽𝐶𝑒𝑙 𝐷𝐶𝑒𝑙
 +𝛽𝑝𝑚 𝐷𝑝𝑚 +𝛽𝑝𝑒60 𝐷𝑝𝑒60 + 𝛽𝑝𝑒30 𝐷𝑝𝑒30 + 𝛽𝑝𝑢 𝐷𝑝𝑢
 +𝛽𝐴𝑝𝑝𝑙𝑒 𝐷𝐴𝑝𝑝𝑙𝑒 +𝛽𝑝199 𝐷𝑝199 + 𝛽𝑝249 𝐷𝑝249 + 𝛽𝑝299 𝐷𝑝299 + 𝜀
  Perfil base es arbitrario
Modelo Base: Samsung, 12 hrs. de batería, sin servicio celular ni pago móvil, peso de 90 grs., $399.990

[pág. 10]
Resultados Estimación Smartwatch
 . reg R vida18 vida24 vida48 celular pago peso30 peso60 pulso apple precio19 precio24 precio29
 Source SS df MS Number of obs = 16
 F(12, 3) = 20.18
 Model 3156.32601 12 263.027168 Prob > F = 0.0153
 Residual 39.1114875 3 13.0371625 R-squared = 0.9878
 Adj R-squared = 0.9388
 Total 3195.4375 15 213.029167 Root MSE = 3.6107
 R Coef. Std. Err. t P>|t| [95% Conf. Interval]
 vida18 9.304907 2.617947 3.55 0.038 .9734296 17.63638
 vida24 13 2.553151 5.09 0.015 4.874733 21.12527
 vida48 14.05491 2.617947 5.37 0.013 5.72343 22.38638
 celular 10.90187 1.911878 5.70 0.011 4.817419 16.98632
 pago_movil 3.966667 1.864558 2.13 0.123 -1.967189 9.900522
 peso30 19.78037 2.3154 8.54 0.003 12.41174 27.14901
 peso60 8.107477 2.517105 3.22 0.049 .0969253 16.11803
 pulso 6.366667 1.864558 3.41 0.042 .4328108 12.30052
 apple 4.625 1.805351 2.56 0.083 -1.120431 10.37043
 precio19 21.94509 2.617947 8.38 0.004 13.61362 30.27657
 precio24 17.5 2.553151 6.85 0.006 9.374733 25.62527
 precio29 13.69509 2.617947 5.23 0.014 5.363616 22.02657
 _cons
 _cons 28.56289
 28.56289 3.460286
 3.460286 8.25
 8.25 0.004
 0.004 17.55072
 17.55072 39.57506
 39.57506

[pág. 11]
Utilidades Parciales Estimadas
  Ecuación estimada:
 𝑅෠ = 28.6 + 9.3𝐷𝑉𝐵18 + 13𝐷𝑉𝐵24 + 14.1𝐷𝑉𝐵48 + 10.9𝐷𝐶𝑒𝑙
 +4.0𝐷𝑝𝑚 +8.1𝐷𝑝𝑒60 + 19.8𝐷𝑝𝑒30 + 6.4𝐷𝑝𝑢
 +4.6𝐷𝐴𝑝𝑝𝑙𝑒 +21.9𝐷𝑝199 + 17.5𝐷𝑝249 + 13.7𝐷𝑝299
  Utilidad del modelo base: 28.6
Modelo Base: Samsung, 12 hrs. de batería, sin servicio celular ni pago móvil, peso de 90 grs., $399.990

[pág. 12]
Utilidades Parciales Estimadas
12
 Atributo Nivel ෡
 𝜷 Atributo Nivel ෡
 𝜷
 18 h. 9.3 $199 21.9
 Duración Batería 24 h. 13.0 Precio $249 17.5
 48 h. 14.1 $299 13.7
 ¿Celular? Sí 10.9 Peso 60 g. 8.1
 ¿Pago Móvil? Sí 4.0 30 g. 19.8
 ¿Pulso? Sí 6.4 Marca Apple 4.6
 Utilidad modelo base = 28.6

[pág. 13]
Funciones de Utilidad Parcial
 Vida Útil Celular Pago Móvil
16 14.05 12 10.90 4 3.97
14 13.00 10
 3.5
12 3
10 9.30 8
 2.5
8 6 2
6 1.5
 4
4 1
 2
2 0.5
0 0 0
 12 horas 18 horas 24 horas 48 horas No Sí No Sí
 Peso Marca Precio
 5 25
 25
 19.78 4.5 4.63 21.95
 20 4
 3.5
 20
 17.50
 15 3 15 13.70
 2.5
 10 8.11 2 10
 1.5
 5 1 5
 0.5
 0 0 0
 30 grs 60 grs 90 grs Apple Samsung 199990 249990 299990 399990

[pág. 14]
Interpretación de Utilidades Parciales
14
  Utilidades parciales medidas en escala de intervalo
 Podemos comparar diferencias entre utilidades parciales
 Adición de constante no cambia interpretación
 Ratios entre utilidades parciales no son interpretables

[pág. 15]
Interpretación de Utilidades Parciales
 Ejemplo
15
 Color Utilidad Marca Utilidad
 Azul 30 A 20
 Rojo 20 B 40
 Verde 10 C 10

[pág. 16]
Interpretación de Utilidades Parciales
 Ejemplo
16
 Color Utilidad Marca Utilidad
 Azul 30 A 20
 Rojo 20 B 40
 Verde 10 C 10
 ¿El Color Rojo es tan preferido como la Marca A?

[pág. 17]
Interpretación de Utilidades Parciales
 Ejemplo
17
 Color Utilidad Marca Utilidad
 Azul 30 A 20
 Rojo 20 B 40
 Verde 10 C 10
 ¿El Color Rojo es tan preferido como la Marca A?
 ¿El Color Azul es 3 veces más preferido que el Color Verde?

[pág. 18]
¿Cuál de los siguientes modelos es
preferido por el consumidor?
 Modelo I  Modelo II
 Samsung  Apple
 Duración batería: 24 h  Duración batería: 48 h
 Celular: Sí  Celular: No
 Pago Móvil: Sí  Pago Móvil: No
 Monitoreo de pulso: Sí  Monitoreo de pulso: No
 Peso 60 grs.  Peso 30 grs.
 $299.990  $299.990

[pág. 19]
Utilidades de Modelos Alternativos
19
 Atributo Modelo I
 Nivel Ut. Parcial
 Marca Samsung 0
 Vida Batería 24h 13
 Celular Sí 10.9
 Pago Móvil Sí 3.97
 Peso 60g 8.11
 Pulso Sí 6.37
 Precio $299.990 13.7
 Utilidad total 56.05 + 28.6

[pág. 20]
Utilidades de Modelos Alternativos
20
 Atributo Modelo II
 Nivel Ut. Parcial
 Marca Apple 4.63
 Vida Batería 48h 14.05
 Celular No 0
 Pago Móvil No 0
 Peso 30g 19.78
 Pulso No 0
 Precio $299.990 13.7
 Utilidad total 52.16 + 28.6

[pág. 21]
¿Qué Atributos son más Importantes en la
Decisión de Compra?
 Importancia relativa de atributos
 max 𝜷𝒂 − min(𝜷𝒂 )
 𝐼𝑎 =
 σ𝑘 max 𝜷𝒌 − min(𝜷𝒌 )
 𝜷𝒂 = (𝛽𝑎1 , … , 𝛽𝑎𝑚 )

[pág. 22]
Utilidades Parciales Estimadas
22
 Atributo Nivel ෡
 𝜷 Atributo Nivel ෡
 𝜷
 18 h. 9.3 $199 21.9
 Duración Batería 24 h. 13.0 Precio $249 17.5
 48 h. 14.1 $299 13.7
 ¿Celular? Sí 10.9 Peso 60 g. 8.1
 ¿Pago Móvil? Sí 4.0 30 g. 19.8
 ¿Pulso? Sí 6.4 Marca Apple 4.6

[pág. 23]
Importancia de Atributos
23
 Atributo max 𝜷𝒂 − min(𝜷𝒂) 𝑰𝒂
 Duración Batería 14.1
 Celular 10.9
 Pago Móvil 4.0
 Pulso 6.4
 Precio 21.9
 Peso 19.8
 Marca 4.6
 81.7
 ෍ max 𝜷𝒌 − min(𝜷𝒌)
 𝑘

[pág. 24]
Importancia de Atributos
24
 Atributo max 𝜷𝒂 − min(𝜷𝒂) 𝑰𝒂
 Duración Batería 14.1 0.173
 Celular 10.9 0.133
 Pago Móvil 4.0 0.049
 Pulso 6.4 0.078
 Precio 21.9 0.268
 Peso 19.8 0.242
 Marca 4.6 0.056
 81.7
 ෍ max 𝜷𝒌 − min(𝜷𝒌)
 𝑘

[pág. 25]
Número de Niveles e Importancia de
 Atributos
25
  El número de niveles incluidos puede influir sobre la
 relevancia del atributo (Currim, Weinberg & Wittink, 1981)
  Ejemplo: Estudio sobre cámaras digitales
  Atributos: Marca (3 niveles) y Precio
  Estimación alternativa usando 2 vs 3 niveles para
 Precio

[pág. 26]
Influencia de Número de Niveles en
 Importancia de Atributos
26
 Puntos de precio: $999-$1,599 Puntos de precio: $999-$1,299
 Marca Utilidad Parcial Marca Utilidad Parcial
 A 3.5 A 3.5
 B 2.5 B 2.5
 C 0 C 0
 Precio Precio
 $999 5.5 $999 3.0
 $1299 3.5 $1299 0
 $1599 0

[pág. 27]
Influencia de Número de Niveles en
 Importancia de Atributos
27
 Puntos de precio: $999-$1,599
 Marca Utilidad Parcial
 A 3.5 3.5
 𝐼𝑀𝑎𝑟𝑐𝑎 = = 0.39
 B 2.5 5.5 + 3.5
 C 0
 Precio 5.5
 𝐼𝑃𝑟𝑒𝑐𝑖𝑜 = = 0.61
 $999 5.5 5.5 + 3.5
 $1299 3.5
 $1599 0

[pág. 28]
Influencia de Número de Niveles en
 Importancia de Atributos
28
 Puntos de precio: $999-$1,299
 Marca Utilidad Parcial
 A 3.5 3.5
 𝐼𝑀𝑎𝑟𝑐𝑎 = = 0.54
 B 2.5 3.5 + 3.0
 C 0
 Precio 3.0
 𝐼𝑃𝑟𝑒𝑐𝑖𝑜 = = 0.46
 $999 3.0 3.5 + 3.0
 $1299 0

[pág. 29]
Disposición a Pagar por un Atributo
29
  Cuando un atributo es medido en unidades monetarias
 (ej. precio) podemos usar estimaciones para calcular
 WTP
  ¿Cuánto tendría que recibir el consumidor para aceptar
 renunciar al atributo?
  Concepto clave: Utilidad marginal del ingreso
  WTP obtenido como ratio entre utilidad parcial del
 atributo y la utilidad marginal del ingreso

[pág. 30]
Disposición a Pagar por un Atributo
 Ejemplo
30
  Preferencias sobre consolas de video
  Atributos y niveles:
  Memoria: 8 GB – 16 GB – 32 GB
  Garantía: Sí – No
  Precio: $100 - $200 - $300

[pág. 31]
Disposición a Pagar por un Atributo
 Ejemplo
31
  Resultados estimación:
 𝑢ො = 50 + 100𝑀𝑒𝑚16 + 120𝑀𝑒𝑚32 + 10𝐺𝑎𝑟𝑎𝑛𝑡í𝑎 − 0.5𝑝𝑟𝑒𝑐𝑖𝑜
 ¿Cuánto está dispuesto a pagar el consumidor por la garantía
 (para un mismo nivel de memoria)?

[pág. 32]
Participación de Preferencias y
 Simulador de Mercado
32
  Participación de preferencias miden proporción de
 preferencia asignada a una opción en función de
 sus atributos
  Requieren definir “regla de participación”
  Simulador de mercado: Cambios en participaciones
 derivados de cambios en configuración de atributos

[pág. 33]
Reglas de Participación
33
 ❑ Regla Logit:
 𝑒 𝑢𝑗
 𝑚𝑗 =
 σ𝐽𝑘=1 𝑒 𝑢𝑘
 ❑ Regla de Potencia Alfa:
 𝑢𝑗𝛼
 𝑚𝑗 = 𝛼>0
 σ𝐽𝑘=1 𝑢𝑘𝛼

[pág. 34]
Reglas de Participación
34
 ❑ Regla Logit:
 𝑒 𝑢𝑗
 𝑚𝑗 =
 σ𝐽𝑘=1 𝑒 𝑢𝑘
 ❑ Regla de Potencia Alfa:
 𝑢𝑗𝛼 Regla de Bradley-Terry-Luce
 𝑚𝑗 = 𝛼>0
 σ𝐽𝑘=1 𝑢𝑘𝛼 asume 𝛼 = 1

[pág. 35]
Reglas de Participación
35
 1.05
 0.85
 0.65
 0.45
 0.25
 0.05
 -0.15
 0.5 1 2 3 logit

[pág. 36]
36 Ejemplo: Preferencias por Quitamanchas
 Green & Wind (Harvard Business Review)

[pág. 37]
Ejemplo: Nuevo Quitamanchas
 Empresa interesada en comercializar un nuevo aparato
 que quita manchas de alfombras y tapices
 5 atributos clave:
 1. Diseño
 2. Marca
 3. Precio
 4. Sello de aprobación (otorgado por revista especializada)
 5. Garantía

[pág. 38]
Ejemplo Quitamanchas de Alfombras
Atributos y Niveles
 Diseño (3) Diseños alternativos:
  A, B, C
 Marca (3)
  KR2 (Marca 1), Glory (Marca 2), Bissell (Marca 3)
 Precio (3)
  $1.19, $1.39, $1.59
 Sello de aprobación (2)
  Sí, No
 Garantía (2)
  Sí, No
 ¿Número de perfiles en diseño factorial completo?

[pág. 39]
Perfiles a Evaluar
Diseño Factorial Fraccional
 Diseño Marca Precio Aprobado Garantia Ranking
 1A 1 1.19 No No 13
 2A 2 1.39 No Yes 11
 3A 3 1.59 Yes No 17
 4B 1 1.39 Yes Yes 2
 5B 2 1.59 No No 14
 6B 3 1.19 No No 3
 7C 1 1.59 No Yes 12
 8C 2 1.19 Yes No 7
 9C 3 1.39 No No 9
 10 A 1 1.59 Yes No 18
 11 A 2 1.19 No Yes 8
 12 A 3 1.39 No No 15
 13 B 1 1.19 No No 4
 14 B 2 1.39 Yes No 6
 15 B 3 1.59 No Yes 5
 16 C 1 1.39 No No 10
 17 C 2 1.59 No No 16
 18 C 3 1.19 Yes Yes 1

[pág. 40]
Estimación de Utilidades Parciales
  Especificación:
 𝑅 = 𝛽0 + 𝛽𝐷𝐴 𝐷𝐷𝐴 + 𝛽𝐷𝐵 𝐷𝐷𝐵 + 𝛽𝑀1 𝐷𝑀1 + 𝛽𝑀2 𝐷𝑀2 +
 𝛽1.19𝐷1.19 +𝛽1.39𝐷1.39 + 𝛽𝐴 𝐷𝐴 + 𝛽𝐺 𝐷𝐺 + 𝜀
  R corresponde al ranking re-escalado
Modelo Base: Diseño C, Marca 3, Sin Sello de Aprobación, Sin Garantía, Precio = $1.59

[pág. 41]
Análisis: Estimación por MCO
 . reg r a b marca_1 marca_2 p_119 p_139 aprobado garantia
 Source SS df MS Number of obs = 18
 F(8, 9) = 65.62
 Model 476.333333 8 59.5416667 Prob > F = 0.0000
 Residual 8.16666667 9 .907407407 R-squared = 0.9831
 Adj R-squared = 0.9682
 Total 484.5 17 28.5 Root MSE = .95258
 r Coef. Std. Err. t P>|t| [95% Conf. Interval]
 a -4.5 .5499719 -8.18 0.000 -5.744123 -3.255877
 b 3.5 .5499719 6.36 0.000 2.255877 4.744123
 marca_1 -1.5 .5499719 -2.73 0.023 -2.744123 -.255877
 marca_2 -2 .5499719 -3.64 0.005 -3.244123 -.755877
 p_119 7.666667 .5499719 13.94 0.000 6.422544 8.91079
 p_139 4.833333 .5499719 8.79 0.000 3.58921 6.077456
 aprobado 1.5 .4762897 3.15 0.012 .4225579 2.577442
 garantia 4.5 .4762897 9.45 0.000 3.422558 5.577442
 _cons 4.833333 .6350529 7.61 0.000 3.396744 6.269923

[pág. 42]
Coeficientes Estimados Quitamanchas
 Parámetro Coeficiente
 Intercepto 4.83
 Diseño A -4.50
 Diseño B 3.50
 Marca 1 -1.50
 Marca 2 -2.00
 Precio 1.19 7.67
 Precio 1.39 4.83
 Aprobación 1.50
 Garantía 4.50

[pág. 43]
Preguntas
43
  ¿Cuál es el número mínimo de perfiles a evaluar?
  ¿Qué características posee un quitamanchas ideal para un
 consumidor con las preferencias estimadas?
  ¿Qué atributos son más relevantes para el consumidor?
  Suponga que el consumidor paga $1.19 por el quitamanchas sin
 sello de aprobación.
  ¿Cuál es su máxima disposición a pagar por el sello de
 aprobación?
  ¿Cómo cambiaría su respuesta si el consumidor actualmente paga
 $1.39 por el quitamanchas?

[pág. 44]
Simulador de Mercado
 Configuraciones Iniciales
44
 Atributo Nuestro Prod. Competidor 1 Competidor 2
 Diseño A B C
 Marca 1 2 3
 Precio $1.19 $1.39 $1.59
 Garantía No No Sí
 Sello de Aprobación No Sí No
 Supuesto (simplificador): Preferencias del Consumidor son Representativas

[pág. 45]
Atributo Nivel Nuestro Prod. Comp. 1 Comp. 2
 Valor Ut. Par. Valor Ut. Par. Valor Ut. Par.
 Diseño A 1 -4.5 0 0.0 0 0.0
 B 0 0.0 1 3.5 0 0.0
 Marca 1 1 -1.5 0 0.0 0 0.0
 2 0 0.0 1 -2.0 0 0.0
 Precio 1.19 1 7.67 0 0.0 0 0.0
 1.39 0 0.0 1 4.83 0 0.0
 Garantía Sí 0 0.0 0 0.0 1 4.5
 Aprobación Sí 0 0.0 1 1.5 0 0.0
 Intercepto 1 4.83 1 4.83 1 4.83
 Ut. Total 6.50 12.66 9.33
45

[pág. 46]
Ejemplo: Quitamanchas
 Regla Logit
46
 Producto Utilidad Participación
 Total
 Nuestro 6.50 0.002
 Competidor 1 12.66 0.963
 Competidor 2 9.33 0.034
 Total 28.49 1.000

[pág. 47]
Ejemplo: Quitamanchas
 Regla Logit
47
 Producto Utilidad Participación exp(6.5)
 Total exp 6.5 + exp 12.66 + exp(9.33)
 Nuestro 6.50 0.002
 Competidor 1 12.66 0.963
 Competidor 2 9.33 0.034
 Total 28.49 1.000

[pág. 48]
Simulador de Mercado
 Cambio en Configuración de Nuestro Producto
48
  ¿Cómo cambiarían las participaciones si nuestro
 producto incluye Sello de Aprobación y Garantía?
  Recalculamos utilidad de nuestro producto bajo
 nueva configuración
  Aplicamos regla logit para calcular nuevas
 participaciones

[pág. 49]
Atributo Nivel Nuestro Prod. Comp. 1 Comp. 2
 Valor Ut. Par. Valor Ut. Par. Valor Ut. Par.
 Diseño A 1 -4.5 0 0.0 0 0.0
 B 0 0.0 1 3.5 0 0.0
 Marca 1 1 -1.5 0 0.0 0 0.0
 2 0 0.0 1 -2.0 0 0.0
 Precio 1.19 1 7.67 0 0.0 0 0.0
 1.39 0 0.0 1 4.83 0 0.0
 Garantía Sí 1 4.5 0 0.0 1 4.5
 Aprobación Sí 1 1.5 1 1.5 0 0.0
 Intercepto 1 4.83 1 4.83 1 4.83
 Ut. Total 12.50 12.66 9.33
49

[pág. 50]
Nuevas Participaciones
 Regla Logit
50
 Producto Utilidad Participación exp(12.5)
 Total exp 12.5 + exp 12.66 + exp(9.33)
 Nuestro 12.50 0.451
 Competidor 1 12.66 0.531
 Competidor 2 9.33 0.019
 Total 28.49 1.000

[pág. 51]
Limitaciones de Simulador de Mercado
51
  No considera disponibilidad y conocimiento de
 productos alternativos
  Asume que competidores no responden
 estratégicamente

# Marketing Analytics · clase26_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 MODELO LOGIT MULTINOMIAL:
 AJUSTE Y EFECTOS PARCIALES
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Clase Anterior: Modelos de Elección de Marca
2
  ¿Qué factores influyen sobre decisión de compra?
  Enfoques
  Modelos probabilísticos (Ej. NBD/Dirichlet)
  Modelos de elección discreta
  Modelos de elección discreta permiten entender
 influencia de variables del marketing mix

[pág. 3]
Clase Anterior: Modelos de Elección Discreta
3
  Modelación:
  Consumidor 𝑖 escoge una marca entre 𝐽 alternativas
  Utilidad depende linealmente de atributos e incluye
 componente aleatorio:
 𝑢𝑖𝑗𝑡 = 𝛽𝑗 + 𝛽1𝑗 𝑥1,𝑖𝑗𝑡 + 𝛽2𝑗 𝑥2,𝑖𝑗𝑡 + ⋯ + 𝛽𝑚𝑗 𝑥𝑚,𝑖𝑗𝑡 + 𝜖𝑖𝑗𝑡
  Consumidores son racionales: Escogen alternativa que les
 reporta mayor utilidad

[pág. 4]
Clase Anterior: Modelos de Elección Discreta
4
  Modelación:
  Consumidor 𝑖 escoge una marca entre 𝐽 alternativas
  Utilidad depende linealmente de atributos e incluye
 componente aleatorio:
 𝑢𝑖𝑗𝑡 = 𝑣𝑖𝑗𝑡 + 𝜖𝑖𝑗𝑡
  Consumidores son racionales: Escogen alternativa que les
 reporta mayor utilidad

[pág. 5]
Clase Anterior: Modelo Logit Multinomial
5
  Modelo logit multinomial asume 𝜖𝑗𝑡 independientes
 y distribuidos T1EV (o Gumbel)
  Probabilidad de elección de marca 𝑗:
 𝑒 𝑣𝑖𝑗𝑡
 Pr 𝑦𝑖𝑗𝑡 = 1|𝒙 = 𝐽
 σ𝑘=1 𝑒 𝑣𝑖𝑘𝑡

[pág. 6]
Propiedades de Probabilidades Logit
6
 1. Probabilidad 𝑃𝑖𝑗𝑡 se encuentra entre 0 y 1
 2. Suma de probabilidades entre alternativas es 1
 3. Relación entre 𝑃𝑖𝑗𝑡 y 𝑣𝑖𝑗𝑡 tiene forma de 𝑆
 4. Sólo diferencias en utilidades afectan 𝑃𝑖𝑗𝑡
  Implica que sólo 𝐽 − 1 constantes de marca pueden
 identificarse

[pág. 7]
Otra Implicancia de 4: No es Posible Incluir
 Variables Demográficas Directamente
7
  Supongamos por simplicidad 2 marcas y función de
 utilidad indirecta
 𝑢𝑖𝑗𝑡 = 𝛽𝑗 + 𝛽𝑖𝑛𝑔𝑟𝑒𝑠𝑜 𝐼𝑛𝑔𝑟𝑒𝑠𝑜𝑖 + 𝜖𝑖𝑗𝑡

[pág. 8]
Otra Implicancia de 4: No es Posible Incluir
 Variables Demográficas Directamente
8
  Supongamos por simplicidad 2 marcas y función de
 utilidad indirecta
 𝑢𝑖𝑗𝑡 = 𝛽𝑗 + 𝛽𝑖𝑛𝑔𝑟𝑒𝑠𝑜 𝐼𝑛𝑔𝑟𝑒𝑠𝑜𝑖 + 𝜖𝑖𝑗𝑡
 𝑃𝑟 𝑦𝑖𝐴𝑡 = 1 = 𝑃𝑟 𝜖𝑖𝐴𝑡 − 𝜖𝑖𝐵𝑡 < 𝛽𝐴 − 𝛽𝐵

[pág. 9]
Estimación de Parámetros vía Máxima
 Verosimilitud
9
  Función de verosimilitud considera elecciones de
 todos los consumidores y ocasiones de compra:
 𝐼 𝑇 𝐽
 𝐿(𝜷) = ෑ ෑ ෑ 𝑃𝑖𝑗𝑡 𝑦𝑖𝑗𝑡
 𝑖=1 𝑡=1 𝑗=1

[pág. 10]
Aplicación: Estimación de Modelo Logit
 Multinomial en Categoría Crackers
10
  Muestra de 136
 consumidores que hacen
 3156 visitas en total
  4 marcas:
  Nabisco
  Keebler
  Sunshine
  Marca Propia

[pág. 11]
chid choice alt disp feat price lastchoice
 1 0 keebler 0 0 1.09 0
 1 1 nabisco 0 0 0.99 1
 1 0 private 0 0 0.71 0
 1 0 sunshine 0 0 0.99 0
 2 0 keebler 0 0 1.09 0
 2 0 nabisco 0 0 1.09 1
 2 0 private 0 0 0.78 0
 2 1 sunshine 1 0 0.49 0
 3 0 keebler 0 0 1.09 0
 3 1 nabisco 0 0 0.89 0
 3 0 private 0 0 0.78 0
 3 0 sunshine 0 0 1.03 1
 4 0 keebler 0 0 1.09 0
 4 1 nabisco 0 0 1.19 1
 4 0 private 0 0 0.64 0
 4 0 sunshine 0 0 1.09 0

[pág. 12]
Crackers: Modelo a Estimar
12
  Función de utilidad indirecta
 𝑢𝑖𝑗𝑡 = 𝛽𝑗 + 𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑗𝑡 + 𝛽𝑓 𝐹𝑒𝑎𝑡𝑗𝑡 + 𝛽𝑑 𝐷𝑖𝑠𝑝𝑗𝑡 + 𝜀𝑖𝑗𝑡
  Probabilidad de elección de marca 𝑗:
 𝑒 (𝛽𝑗 +𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑗𝑡 +𝛽𝑓 𝐹𝑒𝑎𝑡𝑗𝑡 +𝛽𝑑 𝐷𝑖𝑠𝑝𝑗𝑡 )
 𝑃𝑖𝑗𝑡 =
 σ𝐽𝑘=1 𝑒 (𝛽𝑘 +𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑘𝑡+𝛽𝑓 𝐹𝑒𝑎𝑡𝑘𝑡 +𝛽𝑑 𝐷𝑖𝑠𝑝𝑘𝑡 )

[pág. 13]
Estadística Descriptiva
13
  Participaciones de cada marca

[pág. 14]
Estadística Descriptiva
 Variables del Marketing Mix
14

[pág. 15]
Estimación en R
15
  Librería gmnl
  Sintaxis:

[pág. 16]
Estimación en R
16
  Resultados:

[pág. 17]
¿Cuán bueno es el Ajuste del Modelo?
17
  Objetivo de estimación es
 maximizar función de log
 verosimilitud (𝐿𝐿)
  Bondad de ajuste basada
 en valor de 𝐿𝐿 en el
 óptimo
  Métrica más utilizada:
 Pseudo R-cuadrado de
 McFadden

[pág. 18]
Pseudo R-Cuadrado
 Pseudo-R2 basado en comparación de:
  𝐿𝐿 𝛽መ : Valor de función de 𝐿𝐿 evaluada en coeficientes estimados
  𝐿𝐿 0 : Valor de la función de 𝐿𝐿 en modelo nulo
 2
 𝐿𝐿 𝛽መ
 𝜌 =1−
 𝐿𝐿 0

[pág. 19]
Pseudo R-Cuadrado
 Pseudo-R2 basado en comparación de:
  𝐿𝐿 𝛽መ : Valor de función de 𝐿𝐿 evaluada en coeficientes estimados
  𝐿𝐿 0 : Valor de la función de 𝐿𝐿 en modelo nulo
 𝐿𝐿 𝛽መ
 2
 𝜌 =1− 𝜌2 ∈ (0,1)
 𝐿𝐿 0
 Empíricamente 𝜌2 ∈ 0.2,0.4 indica un muy buen ajuste

[pág. 20]
Estimación Logit en Categoría Crackers:
Bondad de Ajuste

[pág. 21]
Inclusión de Variable de Lealtad de
 Marca
21
  Evidencia empírica sugiere que variable
 importante en la estimación es alguna
 medida de lealtad de marca (Ej.
 Guadagni & Little, 1983)
  Potencial medida de lealtad de marca:
 última marca comprada
 𝑙𝑎𝑠𝑡𝑐ℎ𝑜𝑖𝑐𝑒𝑖𝑗𝑡 = 1 si consumidor 𝑖 escogió marca 𝑗 en 𝑡 − 1

[pág. 22]
Estimación Incluyendo Dummy de Última
 Compra
22

[pág. 23]
Estimación Incluyendo Dummy de Última
 Compra - Bondad de Ajuste
23

[pág. 24]
Efectos Parciales
24
  Desde el punto de vista de la toma de decisiones
 de marketing, más relevante que la bondad de
 ajuste son los efectos parciales de las variables del
 marketing mix
  Dos tipos de efectos parciales
  Cambios en atributo de la propia marca
  Cambios en atributo de otra marca

[pág. 25]
Efectos Parciales
25
 • Para un consumidor y ocasión de compra dados,
 𝑒 𝑣𝑗
 Pr 𝑦𝑗 = 1|𝒙 ≡ 𝑃𝑗 =
 σ𝐽𝑘=1 𝑒 𝑣𝑘
 𝑣𝑗 = 𝛽𝑗 + 𝛽1𝑗 𝑥1𝑗 + 𝛽2𝑗 𝑥2𝑗 + ⋯ + 𝛽𝑚𝑗 𝑥𝑚𝑗
 Cambio en 𝑥𝑚𝑗 afecta tanto probabilidad de compra de 𝑗 como de otras marcas

[pág. 26]
Efectos Parciales: Caso Crackers
26
 𝑒 𝑣𝑁
 𝑃𝑁 = 𝑣
 𝑒 𝑁 + 𝑒 𝑣𝑆 + 𝑒 𝑣𝐾 + 𝑒 𝑣𝑃
 𝑣𝑁 = 𝛽𝑁 + 𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑁 + 𝛽𝑓 𝐹𝑒𝑎𝑡𝑁 + 𝛽𝑑 𝐷𝑖𝑠𝑝𝑁 + 𝛽𝑙 𝐿𝑎𝑠𝑡𝑁
 𝑣𝑆 = 𝛽𝑆 + 𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑆 + 𝛽𝑓 𝐹𝑒𝑎𝑡𝑆 + 𝛽𝑑 𝐷𝑖𝑠𝑝𝑆 + 𝛽𝑙 𝐿𝑎𝑠𝑡𝑆
 𝑣𝐾 = 𝛽𝐾 + 𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝐾 + 𝛽𝑓 𝐹𝑒𝑎𝑡𝐾 + 𝛽𝑑 𝐷𝑖𝑠𝑝𝐾 + 𝛽𝑙 𝐿𝑎𝑠𝑡𝐾
 𝑣𝑃 = 𝛽𝑃 + 𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑃 + 𝛽𝑓 𝐹𝑒𝑎𝑡𝑃 + 𝛽𝑑 𝐷𝑖𝑠𝑝𝑃 + 𝛽𝑙 𝐿𝑎𝑠𝑡𝑃

[pág. 27]
Efectos Parciales
Cambios en Atributo de la Propia Marca
 ¿Cuál es el efecto parcial de un aumento en el precio de
 Nabisco sobre su probabilidad de elección?
 𝜕𝑃𝑁
 =?
 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑁

[pág. 28]
Efectos Parciales
Cambio en Atributo de la Marca
 𝜕𝑃𝑁 𝜕 𝑒 𝑣𝑁
 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑁
 = 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑁 𝑒 𝑣𝑁 +𝑒 𝑣𝑆 +𝑒 𝑣𝐾 +𝑒 𝑣𝑃

[pág. 29]
Efectos Parciales
Cambio en Atributo de la Marca
 𝜕𝑃𝑁 𝜕 𝑒 𝑣𝑁
 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑁
 = 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑁 𝑒 𝑣𝑁 +𝑒 𝑣𝑆 +𝑒 𝑣𝐾 +𝑒 𝑣𝑃
 𝑒 𝑣𝑁 + 𝑒 𝑣𝑆 + 𝑒 𝑣𝐾 + 𝑒 𝑣𝑃 𝑒 𝑣𝑁 𝛽𝑝 − 𝑒 𝑣𝑁 𝑒 𝑣𝑁 𝛽𝑝
 =
 (𝑒 𝑣𝑁 + 𝑒 𝑣𝑆 + 𝑒 𝑣𝐾 + 𝑒 𝑣𝑃 )2

[pág. 30]
Efectos Parciales
Cambio en Atributo de la Marca
 𝜕𝑃𝑁
 = 𝛽𝑝 𝑃𝑁 − 𝛽𝑝 𝑃𝑁2
 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑁
 𝜕𝑃𝑁
 = 𝛽𝑝 𝑃𝑁 (1 − 𝑃𝑁 )
 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑁
 Notar que 𝑃𝑁 no es constante. Debe ser evaluada en vector de 𝒙

[pág. 31]
Efecto Parcial
 Precio
 0.1
 0.2
 0.3
 0
 0.05
 0.15
 0.25
 0.00
 0.04
 0.07
 0.11
 0.14
 0.18
 0.21
 0.25
 0.29
 0.32
 0.36
 0.39
 0.43
 0.47
 0.50
 0.54
 0.57
 0.61
 0.64
 0.68
 0.72
 0.75
 0.79
Probabilidad de Elección de Nabisco
 0.82
 0.86
 0.89
 0.93
 0.97
 Efecto de Cambio Marginal en Propio
 Supuesto: 𝛽𝑝 =1

[pág. 32]
Curva de Demanda en Modelo Logit
32
 1
 𝑃𝑗 =
 1 + 𝐾 ∙ 𝑒 −(𝛼+𝛽𝑝 𝑝𝑟𝑒𝑐𝑖𝑜𝑗 )
 Efecto parcial
 máximo

[pág. 33]
Elasticidades con Respecto a un Atributo
33
  Mejor métrica del impacto de un atributo
  Cambio porcentual en probabilidad de compra ante un
 aumento de 1% en atributo
  Independiente de unidad de medida de atributo
  Elasticidad propio precio:
 𝜕𝑃𝑗 𝑝𝑟𝑒𝑐𝑖𝑜𝑗
 𝐸𝑗,𝑝𝑟𝑒𝑐𝑖𝑜𝑗 =
 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑗 𝑃𝑗

[pág. 34]
Elasticidad Propio Precio
34
  ¿Elasticidad propio precio de Nabisco?
 𝜕𝑃𝑁 𝑝𝑟𝑒𝑐𝑖𝑜𝑁
 𝐸𝑁,𝑝𝑟𝑒𝑐𝑖𝑜𝑁 =
 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑁 𝑃𝑁
 Efecto Parcial

[pág. 35]
Elasticidad Propio Precio
35
  ¿Elasticidad propio precio de Nabisco?
 𝑝𝑟𝑒𝑐𝑖𝑜𝑁
 𝐸𝑁,𝑝𝑟𝑒𝑐𝑖𝑜𝑁 = 𝛽𝑝 𝑃𝑁 (1 − 𝑃𝑁 )
 𝑃𝑁
 Efecto Parcial

[pág. 36]
Elasticidad Propio Precio
36
  ¿Elasticidad propio precio de Nabisco?
 𝑝𝑟𝑒𝑐𝑖𝑜𝑁
 𝐸𝑁,𝑝𝑟𝑒𝑐𝑖𝑜𝑁 = 𝛽𝑝 𝑃𝑁 (1 − 𝑃𝑁 )
 𝑃𝑁
 Efecto Parcial
 𝐸𝑁,𝑝𝑟𝑒𝑐𝑖𝑜𝑁 = 𝛽𝑝 𝑝𝑟𝑒𝑐𝑖𝑜𝑁 (1 − 𝑃𝑁 )

[pág. 37]
Matriz de Elasticidades: Caso Crackers
37
 ¿Son consistentes estas elasticidades con maximización de profits?

[pág. 38]
Elasticidad Propio Precio y Precios
 Óptimos
38
 • Para una firma que posee poder de mercado:
 𝑝−𝑐 1
 =−
 𝑝 𝐸𝑗,𝑝𝑟𝑒𝑐𝑖𝑜𝑗
 ¿Cuál es el precio óptimo de Nabisco si sus
 costos marginales son iguales a $0.5?

[pág. 39]
Precio Óptimo de Nabisco
39
 𝑝∗ − 𝑐 1
 ∗
 =
 𝑝 1.822
 𝑝∗ =1.108

[pág. 40]
Precio Óptimo de Nabisco
40
 𝑝∗ − 𝑐 1
 ∗
 =
 𝑝 1.822
 𝑝∗ =1.108

[pág. 41]
Efectos Parciales Cruzados
Cambio en Atributo de otra Marca
▪ ¿Cómo cambia la probabilidad de compra de
 Nabisco ante un aumento en el precio de Sunshine?
 𝜕𝑃𝑁
 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑆
 = ?

[pág. 42]
Efectos Marginales Cruzados
Cambio en Atributo de otra Marca
 𝜕𝑃𝑁 𝜕 𝑒 𝑣𝑁
 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑆
 = 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑆 𝑒 𝑣𝑁 +𝑒 𝑣𝑆 +𝑒 𝑣𝐾 +𝑒 𝑣𝑃

[pág. 43]
Efectos Marginales Cruzados
Cambio en Atributo de otra Marca
 𝜕𝑃𝑁 𝜕 𝑒 𝑣𝑁
 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑆
 = 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑆 𝑒 𝑣𝑁 +𝑒 𝑣𝑆 +𝑒 𝑣𝐾 +𝑒 𝑣𝑃
 −𝑒 𝑣𝑁 𝑒 𝑣𝑆 𝛽𝑃
 = 𝑣
 (𝑒 𝑁 + 𝑒 𝑣𝑆 + 𝑒 𝑣𝐾 + 𝑒 𝑣𝑃 )2

[pág. 44]
Efectos Marginales Cruzados
Cambio en Atributo de otra Marca
 𝜕𝑃𝑁
 = −𝛽𝑝 𝑃𝑁 𝑃𝑆
 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑆

[pág. 45]
Elasticidad Precio Cruzada
45
  ¿Elasticidad precio cruzada de Nabisco respecto a
 Sunshine?
 𝜕𝑃𝑁 𝑝𝑟𝑒𝑐𝑖𝑜𝑆
 𝐸𝑁,𝑝𝑟𝑒𝑐𝑖𝑜𝑆 =
 𝜕𝑝𝑟𝑒𝑐𝑖𝑜𝑆 𝑃𝑁
 Efecto Marginal
 Cruzado

[pág. 46]
Elasticidad Precio Cruzada
46
  ¿Elasticidad precio cruzada de Sunshine respecto a
 Nabisco?
 𝑝𝑟𝑒𝑐𝑖𝑜𝑆
 𝐸𝑁,𝑝𝑟𝑒𝑐𝑖𝑜𝑆 = −𝛽𝑝 𝑃𝑁 𝑃𝑆
 𝑃𝑁

[pág. 47]
Elasticidad Precio Cruzada
47
  ¿Elasticidad precio cruzada de Sunshine respecto a
 Nabisco?
 𝑝𝑟𝑒𝑐𝑖𝑜𝑆
 𝐸𝑁,𝑝𝑟𝑒𝑐𝑖𝑜𝑆 = −𝛽𝑝 𝑃𝑁 𝑃𝑆
 𝑃𝑁
 𝐸𝑁,𝑝𝑟𝑒𝑐𝑖𝑜𝑆 = −𝛽𝑝 𝑃𝑆 𝑝𝑟𝑒𝑐𝑖𝑜𝑆
 ¿Qué signo tiene esta elasticidad? ¿Tiene sentido?

[pág. 48]
Matriz de Elasticidades: Caso Crackers
48

[pág. 49]
¿Por qué 𝑃−𝑗 cambian en la misma
 proporción?
49
 ▪ Supongamos que el precio de Nabisco aumenta un 1%
 ▪ ¿Por qué las probabilidades de compra de Keebler
 y Sunshine aumentan ambas en 2.06%?
 ▪ Ratio entre probabilidades de compra no depende
 del precio (y otros atributos) de Nabisco

[pág. 50]
¿Por qué 𝑃−𝑗 cambian en la misma
 proporción?
50
 𝑃𝑆 𝑒 𝑣𝑆 /(𝑒 𝑣𝑁 + 𝑒 𝑣𝑆 + 𝑒 𝑣𝐾 + 𝑒 𝑣𝑃 )
 = 𝑣
 𝑃𝐾 𝑒 𝐾 /(𝑒 𝑣𝑁 + 𝑒 𝑣𝑆 + 𝑒 𝑣𝐾 + 𝑒 𝑣𝑃 )

[pág. 51]
¿Por qué 𝑃−𝑗 cambian en la misma
 proporción?
51
 𝑃𝑆 𝑒 𝑣𝑆 /(𝑒 𝑣𝑁 + 𝑒 𝑣𝑆 + 𝑒 𝑣𝐾 + 𝑒 𝑣𝑃 )
 = 𝑣
 𝑃𝐾 𝑒 𝐾 /(𝑒 𝑣𝑁 + 𝑒 𝑣𝑆 + 𝑒 𝑣𝐾 + 𝑒 𝑣𝑃 )
 ↑ 𝑝𝑟𝑒𝑐𝑖𝑜𝑁 ⟹ ↑ 𝑃𝑠 , 𝑃𝐾

[pág. 52]
¿Por qué 𝑃−𝑗 cambian en la misma
 proporción?
52
 𝑃𝑆 𝑒 𝑣𝑆 /(𝑒 𝑣𝑁 + 𝑒 𝑣𝑆 + 𝑒 𝑣𝐾 + 𝑒 𝑣𝑃 )
 = 𝑣
 𝑃𝐾 𝑒 𝐾 /(𝑒 𝑣𝑁 + 𝑒 𝑣𝑆 + 𝑒 𝑣𝐾 + 𝑒 𝑣𝑃 )
 ↑ 𝑝𝑟𝑒𝑐𝑖𝑜𝑁 ⟹ ↑ 𝑃𝑠 , 𝑃𝐾
 𝑃𝑆 𝑒 𝑣𝑆 𝑃𝑠 y 𝑃𝐾 deben aumentar en la
 = 𝑣 misma proporción
 𝑃𝐾 𝑒 𝐾

[pág. 53]
¿Por qué 𝑃−𝑗 cambian en la misma
 proporción?
53
 𝑃𝑆 𝑒 𝑣𝑆 /(𝑒 𝑣𝑁 + 𝑒 𝑣𝑆 + 𝑒 𝑣𝐾 + 𝑒 𝑣𝑃 )
 = 𝑣
 𝑃𝐾 𝑒 𝐾 /(𝑒 𝑣𝑁 + 𝑒 𝑣𝑆 + 𝑒 𝑣𝐾 + 𝑒 𝑣𝑃 )
 𝑃𝑆 𝑒 𝑣𝑆
 = 𝑣 Independencia de Alternativas
 𝑃𝐾 𝑒 𝐾 Irrelevantes

[pág. 54]
Independencia de Alternativas Irrelevantes
54
  En modelo logit existe sustitución proporcional entre
 alternativas
  Elasticidades cruzadas idénticas entre marcas
  Puede ser problemático en ciertos contextos
  Ej. ¿Si sube el precio de un BMW esperamos que la
 demanda de Audi y Chery aumenten en igual
 proporción?

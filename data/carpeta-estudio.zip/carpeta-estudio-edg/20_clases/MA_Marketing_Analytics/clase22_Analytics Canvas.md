# Marketing Analytics · clase22_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 CROSS-SELLING Y ANÁLISIS DE
 CANASTA DE COMPRAS
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
¿Qué Entendemos por Cross-selling?
2
  Actividades orientadas a
 incrementar número de productos
 adquiridos por cliente
  Aumento en “share-of-wallet” de
 la firma
  Múltiples canales:
  Offline via representante de
 ventas
  Online via sistemas de
 recomendación
  Email marketing

[pág. 3]
Impacto de Cross-Selling sobre CLV
3
 𝑇
 𝑃(𝐴𝑐𝑡𝑖𝑣𝑜𝑡 )𝑚𝑡
 𝐸[𝐶𝐿𝑉] = ෍
 1+𝑑 𝑡
 𝑡=1
 Mayores esfuerzos de cross-selling impactan en:
 • Aumentos en m hoy
 • Aumentos en m en el futuro
 • Aumentos en 𝑃(𝐴𝑐𝑡𝑖𝑣𝑜𝑡 )

[pág. 4]
¿Cómo Influyen los Esfuerzos de Cross-Selling
 sobre Retención?
4
  Dos mecanismos
  Aumento en costos de
 cambio (“switching
 costs”)
  Mejor servicio a clientes
 que compran múltiples
 productos/servicios
 Kamakura et al. (2003)

[pág. 5]
Cross-Selling y Retención de Clientes
5
 Cross-selling Productos Costos de
 Adquiridos “Switching”
 Retención
 de Clientes
 Servicio al Satisfacción
 Cliente del Cliente
 Fuente: Blattberg, Kim & Neslin (2008)

[pág. 6]
¿Qué Sabemos sobre las Actividades de Cross-
 selling de las Firmas?
6

[pág. 7]
“The Dark Side of Cross-Selling”
 Shah & Kumar, HBR 2012
7
  Análisis sistemático de actividades de C-S en grandes
 empresas
  Entrevistan a ejecutivos de 36 firmas de EEUU y Europa
  Más de un 90% realizaron campañas de C-S
  Todas esas firmas encontraron que esfuerzos incrementaron
 utilidades promedio por cliente
  Declaran que dirigirían esfuerzos de C-S a cualquier cliente

[pág. 8]
Análisis Detallado de Impacto en
 Utilidades
8
  Shah & Kumar (HBR, 2012) analizan datos de clientes para 5 firmas
 Fortune 1000
  Servicios financieros (B2B); IT (B2B); banco comercial; retailer de
 vestuario
  4 a 7 años de historial de compras
  Utilidad promedio es mayor para clientes que hacen compra
 cruzada
  Pero 1/5 clientes que hacen C-S no son rentables
  Margen (ingresos – CV – costos de marketing) negativo
  Representan un 70% de pérdidas a nivel de cliente

[pág. 9]
Tipos de Clientes Problemáticos
9
  Identifican 4 segmentos de clientes problemáticos
 1. Demandantes de Servicio
 2. Reversores de Ingreso
 3. Maximizadores de Promociones
 4. Limitadores de Gasto
 Conclusión: Targeting indiscriminado de cross-selling es indeseable

[pág. 10]
Analítica y Cross-Selling
10
  Pregunta clave: ¿Qué productos ofrecer a qué
 clientes y cuándo?
  Tres tipos de modelo
  Próximo producto a comprar (NPTB)
  Modelos que además consideran cuándo
  Modelos que además consideran la probabilidad de
 que el cliente responda a la oferta de cross-selling

[pág. 11]
Modelos NPTB
11
  Modelos predictivos de propensión de comprar un
 determinado producto
  Metodología análoga a modelos de respuesta (ej.
 regresión logística)
  Diferencia clave:
  Especificación de timing
  Features incluidos

[pág. 12]
Modelo NPTB: Variables
12
  Target:
 1 𝑠𝑖 𝑐𝑙𝑖𝑒𝑛𝑡𝑒 𝑖 𝑐𝑜𝑚𝑝𝑟𝑎 𝑝𝑟𝑜𝑑𝑢𝑐𝑡𝑜 𝑗 𝑒𝑛 𝑡
 𝑦𝑖𝑗𝑡 = ቐ
 0 𝑑𝑒 𝑜𝑡𝑟𝑜 𝑚𝑜𝑑𝑜
  Features: Productos que el cliente poseía y características
 del cliente en 𝑡 − 1

[pág. 13]
Modelo NPTB: Especificación
13
  Índice de inclinación a comprar producto 𝑗 en 𝑡:
 𝐾 𝑀
 𝑣𝑖𝑗𝑡 = 𝛽0𝑗 + ෍ 𝑎𝑘𝑗 𝑃𝑟𝑜𝑝𝑖𝑒𝑑𝑎𝑑𝑖𝑘,𝑡−1 + ෍ 𝛽𝑚𝑗 𝐶𝑎𝑟𝑎𝑐𝑡𝑖𝑚
 𝑘=1 𝑚=1
 • 𝑎𝑘𝑗 : Afinidad entre producto 𝑘 y producto 𝑗
 • 𝑃𝑟𝑜𝑝𝑖𝑒𝑑𝑎𝑑𝑖𝑘,𝑡−1 : 𝐷𝑢𝑚𝑚𝑦 = 1 𝑠𝑖 𝑐𝑙𝑖𝑒𝑛𝑡𝑒 𝑝𝑜𝑠𝑒𝑒 𝑝𝑟𝑜𝑑𝑢𝑐𝑡𝑜 𝑘 𝑒𝑛 𝑡 − 1

[pág. 14]
Modelo NPTB: Especificación
14
  Probabilidad de comprar producto 𝑗 en 𝑡:
 1
 𝑃𝑟𝑜𝑏𝑖𝑗𝑡 =
 − 𝛽0𝑗+σ𝐾 𝑀
 𝑘=1 𝑎𝑘𝑗 𝑃𝑟𝑜𝑝𝑖𝑒𝑑𝑎𝑑𝑖𝑘,𝑡−1 + σ𝑚=1 𝛽𝑚𝑗 𝐶𝑎𝑟𝑎𝑐𝑡𝑖𝑚
 1+𝑒
 𝐾 + 𝑀 + 1 parámetros
 Una ecuación por cada producto 𝑗

[pág. 15]
Modelo NPTB: Especificación
15
  Recordemos que esto implica que el log de las odds
 es lineal en predictores
 𝐾 𝑀
 𝑝𝑖𝑗𝑡
 𝑙𝑜𝑔 = 𝛽0𝑗 + ෍ 𝑎𝑘𝑗 𝑃𝑟𝑜𝑝𝑖𝑒𝑑𝑎𝑑𝑖𝑘,𝑡−1 + ෍ 𝛽𝑚𝑗 𝐶𝑎𝑟𝑎𝑐𝑡𝑖𝑚
 1 − 𝑝𝑖𝑗𝑡
 𝑘=1 𝑚=1

[pág. 16]
Aplicación a Banco Comercial
 Knott, Hayes & Neslin (JIM 2022)
16
  Set de productos
  Cuenta Corriente Básica (“Base Checking”)
  Cuenta Corriente sin Comisiones (“No-Fee Checking”)
  Cuenta de Ahorros Básica (“Base Savings”)
  Cuenta de Ahorros sin Comisiones (“No-Fee Savings”)
  Depósito a Plazo (“CDs”)

[pág. 17]
Estimaciones de Relaciones de Afinidad
17
 exp(𝑎𝑘𝑗 )
 ¿Qué podemos concluir?

[pág. 18]
¿Cuán bien lo hace el Modelo NPTB?
18
  Uso del modelo en direccionamiento de oferta de
 préstamo bancario
  Clientes seleccionados si préstamo bancario es top 2 en
 probabilidad de NPTB predicha
  Comparación con dos alternativas
  Regla heurística basada en juicio gerencial
  Potenciales clientes (prospectos)
  Uso de experimento de campo

[pág. 19]
Performance del Modelo
 Resultados de Experimento de Campo
19

[pág. 20]
20 MARKET BASKET ANALYSIS

[pág. 21]
Market Basket Analysis y Cross-Selling
21
  Conjunto de técnicas para analizar datos
 transaccionales
  Uso de análisis de reglas de asociación para identificar
 dependencias entre productos comprados
  Productos comprados juntos con frecuencia pueden
 indicar qué productos ofrecer a clientes que sólo
 compran uno de ellos

[pág. 22]
¿Qué es una Regla de Asociación?
22
  Análisis de reglas de asociación busca encontrar reglas del
 tipo:
 Si un cliente compra items 𝑋 = {𝑖1 , 𝑖2 , … } 𝑋, 𝑌 conocidos
 como itemsets
 entonces también comprará items 𝑌 = {𝑗1 , 𝑗2 , … }
 Denotado como
 𝑋→𝑌

[pág. 23]
¿Qué es una Regla de Asociación?
23
  Análisis de reglas de asociación busca encontrar reglas del
 tipo:
 Si un cliente compra items 𝑋 = {𝑖1 , 𝑖2 , … }
 entonces también comprará items 𝑌 = {𝑗1 , 𝑗2 , … }
 Denotado como
 𝑋→𝑌
 Antecedente Consecuente

[pág. 24]
Ejemplo: Cervezas y Pañales
24
  Regla descubierta por
 Vicepresidente de
 Consulting de NCR en los
 1990s
 {𝑃𝑎ñ𝑎𝑙𝑒𝑠} → {𝐶𝑒𝑟𝑣𝑒𝑧𝑎}
 (en transacciones entre 5 p.m. y 7 p.m.)

[pág. 25]
¿Cómo Selecciona el Algoritmo Reglas de
 Asociación?
25
  Tres criterios de evaluación:
 1. Support
 2. Confidence
 3. Lift

[pág. 26]
Support de Item-Set
26
  Fracción de transacciones que contiene todos los
 items del item-set
 𝑡: 𝑋 ⊆ 𝑡
 𝑆𝑢𝑝𝑝𝑜𝑟𝑡 𝑋 =
 𝑇

[pág. 27]
Support de Regla
27
  Fracción de transacciones que contiene ambos
 itemsets de la regla
 𝑆𝑢𝑝𝑝𝑜𝑟𝑡 𝑋 → 𝑌 = 𝑆𝑢𝑝𝑝𝑜𝑟𝑡(𝑋 ∪ 𝑌)
 𝑡: (𝑋 ∪ 𝑌) ⊆ 𝑡
 =
 𝑇
 Cuán frecuentemente observada es la regla

[pág. 28]
Market Basket Analysis: Ejemplo
28
 Transacciones Items Comprados (market basket)
 1 Leche, jugo de naranjas, helados, cerveza, jabón
 2 Leche, helados, cerveza
 3 Leche, jugo de naranjas, detergente
 4 Leche, helados, pizza
 5 Leche, jugo de naranjas, jabón

[pág. 29]
Criterios de Evaluación
 Support
29
  ¿Cuál es el support de las siguientes reglas?
 {Leche} {Jugo de Naranjas}
 {Leche} {Cerveza}

[pág. 30]
Criterios de Evaluación
 Support
30
  ¿Cuál es el support de las siguientes reglas?
 𝑆𝑢𝑝𝑝𝑜𝑟𝑡 𝐿𝑒𝑐ℎ𝑒 → 𝐽𝑢𝑔𝑜 𝑑𝑒 𝑁𝑎𝑟𝑎𝑛𝑗𝑎𝑠 = 0.6
 𝑆𝑢𝑝𝑝𝑜𝑟𝑡 𝐿𝑒𝑐ℎ𝑒 → 𝐶𝑒𝑟𝑣𝑒𝑧𝑎 = 0.4

[pág. 31]
Matriz de Asociaciones o Co-ocurrencias
31
 Leche Jugo de N. Helado Cerveza Jabón Detergente Pizza
 Leche 5 3 3 2 2 1 1
 Jugo de N. 3 3 1 1 2 1 0
 Helado 3 1 3 2 1 0 1
 Cerveza 2 1 2 2 1 1 0
 Jabón 2 2 1 1 2 0 0
 Detergente 1 1 0 1 0 1 0
 Pizza 1 0 1 0 0 0 1
 𝑇 = 5

[pág. 32]
Matriz de Support
32

[pág. 33]
Support como Criterio de Evaluación
33
  Support mide cuán frecuentemente observada es una regla
  Pero no necesariamente identifica cuán fuerte es la
 dependencia entre antecedente y consecuente
  Si antecedente es muy popular, es probable que el support de
 cualquier regla basada en ese antecedente sea alto
  Ejemplo: 𝑆𝑢𝑝𝑝𝑜𝑟𝑡 𝐿𝑒𝑐ℎ𝑒 → 𝐽𝑎𝑏ó𝑛 = 0.4
 𝑆𝑢𝑝𝑝𝑜𝑟𝑡 𝐽𝑢𝑔𝑜 𝑑𝑒 𝑁𝑎𝑟𝑎𝑛𝑗𝑎𝑠 → 𝐽𝑎𝑏ó𝑛 = 0.4
 ¿Son ambas reglas igualmente interesantes?

[pág. 34]
Criterios de Evaluación
 “Confidence” o Predictibilidad
34
  Mide cuán predecible es el itemset 𝑌 usando el
 itemset 𝑋
 𝑆𝑢𝑝𝑝𝑜𝑟𝑡(𝑋 ∪ 𝑌)
 𝐶𝑜𝑛𝑓𝑖𝑑𝑒𝑛𝑐𝑒 𝑋 → 𝑌 =
 𝑆𝑢𝑝𝑝𝑜𝑟𝑡(𝑋)
 Interpretable como probabilidad condicional

[pág. 35]
Criterios de Evaluación
 “Confidence”
35
  ¿Qué valor toma “confidence” para estas reglas?
 {Leche} {Jabón}
 {Jugo de Naranjas} {Jabón}

[pág. 36]
Confidence como Criterio de Evaluación
36
  En general, Confidence permite identificar reglas
 en que el consecuente depende de antecedente
  Pero puede ser engañosa en ciertos casos
  Consideremos regla:
 {Helados} {Jugo de Naranja}

[pág. 37]
Confidence como Criterio de Evaluación
37
 0.2
 𝐶𝑜𝑛𝑓𝑖𝑑𝑒𝑛𝑐𝑒 𝐻𝑒𝑙𝑎𝑑𝑜𝑠 → 𝐽𝑢𝑔𝑜 𝑑𝑒 𝑁𝑎𝑟𝑎𝑛𝑗𝑎𝑠 = = 0.33
 0.6

[pág. 38]
Confidence como Criterio de Evaluación
38
 0.2
 𝐶𝑜𝑛𝑓𝑖𝑑𝑒𝑛𝑐𝑒 𝐻𝑒𝑙𝑎𝑑𝑜𝑠 → 𝐽𝑢𝑔𝑜 𝑑𝑒 𝑁𝑎𝑟𝑎𝑛𝑗𝑎𝑠 = = 0.33
 0.6
 Sin embargo, ¿Cuál es la probabilidad incondicional de observar “Jugo de
 Naranjas” en una transacción? P {𝐽𝑢𝑔𝑜 𝑑𝑒 𝑁. } = 0.6

[pág. 39]
Confidence como Criterio de Evaluación
39
 0.2
 𝐶𝑜𝑛𝑓𝑖𝑑𝑒𝑛𝑐𝑒 𝐻𝑒𝑙𝑎𝑑𝑜𝑠 → 𝐽𝑢𝑔𝑜 𝑑𝑒 𝑁𝑎𝑟𝑎𝑛𝑗𝑎𝑠 = = 0.33
 0.6
 Sin embargo, ¿Cuál es la probabilidad incondicional de observar “Jugo de
 Naranjas” en una transacción? P {𝐽𝑢𝑔𝑜 𝑑𝑒 𝑁. } = 0.6
 Presencia de “Helados” no es verdaderamente
 informativo sobre “Jugo de Naranjas"
 Lift es una métrica que ayuda a mitigar este problema

[pág. 40]
Criterios de Evaluación
 “Lift” (Mejora o Impacto)
40
  Lift tiene en cuenta popularidad de consecuente
 𝐶𝑜𝑛𝑓𝑖𝑑𝑒𝑛𝑐𝑒(𝑋, 𝑌)
 𝐿𝑖𝑓𝑡(𝑋, 𝑌) =
 𝑆𝑢𝑝𝑝𝑜𝑟𝑡(𝑌)

[pág. 41]
Criterios de Evaluación
 “Lift” (Mejora o Impacto)
41
  Lift tiene en cuenta popularidad de consecuente
 𝐶𝑜𝑛𝑓𝑖𝑑𝑒𝑛𝑐𝑒(𝑋, 𝑌)
 𝐿𝑖𝑓𝑡(𝑋, 𝑌) =
 𝑆𝑢𝑝𝑝𝑜𝑟𝑡(𝑌)
 • Puede interpretarse como Prob. de co-
 ocurrencia de X e Y
 𝑃(𝑋, 𝑌) en relación a Prob.
 𝐿𝑖𝑓𝑡(𝑋, 𝑌) = de co-ocurrencia
 𝑃(𝑋)𝑃(𝑌)
 bajo independencia

[pág. 42]
Lift: Ejemplo
42
  Una tienda de productos gourmet encuentra una
 relación entre compra de vino y queso
 𝑃 Vino, Queso = 0.64
 𝐶𝑜𝑛𝑓𝑖𝑑𝑒𝑛𝑐𝑒 𝑉𝑖𝑛𝑜 → 𝑄𝑢𝑒𝑠𝑜 = 0.8
 𝑃 Vino = 0.80

[pág. 43]
Criterios de Evaluación
 “Lift” (Mejora o Impacto) Cont.
43
  Aparentemente “Vino” es un buen predictor de “queso”
  Si alguien compra vino con una probabilidad de 0.8 también
 va a comprar queso

[pág. 44]
Criterios de Evaluación
 “Lift” (Mejora o Impacto) Cont.
44
  Aparentemente “Vino” es un buen predictor de “queso”
  Si alguien compra vino con una probabilidad de 0.8 también
 va a comprar queso
  Supongamos que el queso es también un producto con
 alto support
 𝑃 Queso = 0,80
 ¿Qué problema tiene la regla Vino → Queso ?

[pág. 45]
Búsqueda de Reglas de Asociación
45
  Las tres métricas anteriores capturan propiedades distintas de item
 sets
  Support – Cuán frecuentemente ocurre el item set
  Confidence – Cuán fuerte es la relación condicional
  Lift – Cuánto más común es el item set que lo que esperaríamos bajo
 independencia
  Procedimiento típico: Inspeccionar reglas que exceden un mínimo en
 Support y Confidence
  ¿Cuáles son particularmente interesantes? ¿Tienen un Lift suficientemente
 alto?

[pág. 46]
Búsqueda de Reglas de Asociación y
 “Maldición de la Dimensionalidad”
46
  En contextos en que existe un gran
 volumen de items número de itemsets
 es enorme
  Número de itemsets aumenta
 exponencialmente con número de items
  Si un supermercado tiene 60.000 SKUs,
 número de 9reglas 𝑋 → 𝑌 a evaluar
 ~3,6 × 10
  Reglas con bajo Support pueden ser
 engañosas: Alto Confidence pero
 irrelevantes
  Importancia de agregar en
 categorías más amplias

[pág. 47]
Implementación en R
47
  Librería arules incluye funciones para encontrar y
 visualizar reglas de asociación
  Algoritmo a priori
  Para cada item set evalúa posibles reglas que expresan
 asociación sobre un support mínimo
  Retiene reglas que presentan confidence sobre un umbral
  arulesViz permite visualizar reglas encontradas

[pág. 48]
Aplicación: Datos de Transacciones de
 Supermercado
48
  Un mes de transacciones en tienda de
 supermercados de EE.UU.
  N = 9.835 transacciones (canastas de compra)
  Ítems agregados en 169 categorías
  Ej. Café, Agua Embotellada, Margarina, Leche Entera

[pág. 49]
49

[pág. 50]
50

[pág. 51]
51

[pág. 52]
Reglas encontradas
 usan 157 items
 # de reglas
 encontradas
52

[pág. 53]
53

[pág. 54]
54

[pág. 55]
55

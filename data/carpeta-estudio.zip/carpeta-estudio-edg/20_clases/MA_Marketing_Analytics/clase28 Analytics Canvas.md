# Marketing Analytics · clase28 Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 DISEÑO DE NUEVOS PRODUCTOS:
 ANÁLISIS CONJUNTO
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Motivación
2
  Lanzamiento de nuevos
 productos juega un rol clave en
 el crecimiento y rentabilidad de
 firmas
  Nuevos productos representan
 del orden de 25%-30% del
 crecimiento en ventas/utilidades
  Firmas requieren rediseñar
 productos o desarrollar nuevos
 productos en etapa de
 madurez/declinación de PLC

[pág. 3]
Alta Tasa de Fracasos en Introducción de
 Nuevos Productos
3
  ~40% de nuevos productos
 fracasan en etapa de
 introducción
  De cada 7-10 conceptos de
 nuevos productos 1 es un
 éxito comercial
  ~13% de firmas reporta que
 nuevos productos alcanzan
 objetivos de utilidades
 anuales

[pág. 4]
Diseño de Nuevos Productos en Firmas
Orientadas al Consumidor
 Clave medir preferencias por configuraciones
 alternativas de producto
 Simulación de participación de nuevo producto
 Métodos consideran productos como un conjunto de
 atributos
 ¿Cómo valora el cliente distintos niveles de
 atributos?

[pág. 5]
Productos como Conjunto de Atributos:
Ejemplo Smartwatch
 Ej. Smartwatch – Atributos:
  Vida de batería
  Uso como celular
  Uso como dinero móvil
  Peso
  Pulso
  Marca
  Precio

[pág. 6]
Características de Smartwatch
 Vida de Pago
 Atributo Batería Celular Móvil Peso Pulso Marca Precio
 12 hrs No No 30 grs. No Samsung $ 199.990
 Niveles de 18 hrs Sí Sí 60 grs. Sí Apple $ 249.990
 Atributos
 1 día 90 grs. $ 299.990
 2 días $ 399.990
 3 posibles Smartwatches que podemos construir
 MODELO I 12 hrs, Celular, Pago Móvil, Pulso, 60 grs., Apple
 MODELO II 2 días, Celular, 30 grs., Apple
 MODELO III 1 día, Celular, Pago Móvil, Pulso, 60 grs., Samsung

[pág. 7]
Metodologías en Medición de
Preferencias
 Método directo o auto-explicado
  Evaluación de atributos individuales
  Composicional
 Método indirecto (Análisis Conjunto)
  Evaluación de perfil/producto completo
  Descomposicional

[pág. 8]
Análisis Conjunto: Idea Básica
 Participantes evalúan (o escogen) perfiles completos de
 producto
 Podemos inferir valoración de atributo variando niveles de
 atributos experimentalmente y observando evaluaciones
  Estimación vía métodos econométricos
 Input: Datos de preferencias globales
 Output: Descomposición de preferencias globales en
 utilidades parciales

[pág. 9]
Metodologías en Análisis Conjunto
 Método Basado en Evaluación de Perfiles (Ratings-
 based Conjoint)
  Enfoque tradicional
  Análisis: Regresión Múltiple
 Método Basado en Elecciones (Choice-based Conjoint)
  Participante escoge una alternativa
  Análisis: Logit multinomial

[pág. 10]
Análisis Conjunto: Evaluación de Perfiles
❑ Evalúe con puntaje 0-100 los siguientes relojes:
 Marca Samsung Marca Apple
 Vida Batería 18 horas Vida Batería 12 horas
 Celular No Celular Sí
 Pago Móvil No Pago Móvil No
 Peso 60 grs. Peso 60 grs.
 Pulso Sí Pulso No
 Precio $199.990 Precio $299.990

[pág. 11]
Análisis Conjunto: Método basado en
Elección
❑ ¿Cuál de los siguientes relojes escogería?
 Marca Samsung Marca Apple
 Vida Batería 18 horas Vida Batería 12 horas
 Celular No Celular Sí
 Pago Móvil No Pago Móvil No
 Peso 60 grs. Peso 60 grs.
 Pulso Sí Pulso No
 Precio $199.990 Precio $299.990

[pág. 12]
Modelo Conjunto Aditivo
Función de Utilidad Aleatoria
 𝑢𝑗 = 𝑢1𝑗 + 𝑢2𝑗 + ⋯ + 𝑢𝑟𝑗 + 𝜀𝑗

[pág. 13]
Modelo Conjunto Aditivo
Función de Utilidad Aleatoria
 𝑢𝑗 = 𝑢1𝑗 + 𝑢2𝑗 + ⋯ + 𝑢𝑟𝑗 + 𝜀𝑗
Utilidad de
perfil de Utilidades
producto 𝑗 parciales

[pág. 14]
Productos como Conjunto de Atributos
Smartwatch
 𝑢𝑆 = 𝑢𝑆𝑏 + 𝑢𝑆𝑣 + 𝑢𝑆𝑐 + 𝑢𝑆𝑝𝑚 +𝑢𝑆𝑝𝑢 + ⋯ + 𝜖𝑆
 Marca Vida Uso Pago Frecuencia
 Batería como Móvil Cardíaca
 Celular

[pág. 15]
Modelo Conjunto Aditivo
Utilidades Parciales: Atributos Categóricos
▪ Variables categóricas representadas vía conjunto de dummies
 𝑢𝑎𝑗 = 𝛽𝑎1 𝐷𝑎1,𝑗 + 𝛽𝑎2 𝐷𝑎2,𝑗 + ⋯ + 𝛽𝑎𝑚−1 𝐷𝑎𝑚−1,𝑗
 𝛽𝑎1 , 𝛽𝑎2 , … , 𝛽𝑎𝑚−1 𝑠𝑜𝑛 𝑐𝑜𝑒𝑓𝑖𝑐𝑖𝑒𝑛𝑡𝑒𝑠
 𝐷𝑎1,𝑗 , 𝐷𝑎2,𝑗 , … , 𝐷𝑎𝑚−1,𝑗 𝑠𝑜𝑛 𝑑𝑢𝑚𝑚𝑖𝑒𝑠 (𝑚 = 𝑁ú𝑚𝑒𝑟𝑜 𝑑𝑒 𝑛𝑖𝑣𝑒𝑙𝑒𝑠)

[pág. 16]
Modelo Conjunto Aditivo
Utilidades Parciales: Atributos Categóricos
▪ Variables dummy codificadas como:
 1 si j incluye nivel a1
 𝐷𝑎1,𝑗 = ቊ
 0 de otro modo
 𝑚 representa el nivel base o de referencia

[pág. 17]
Modelo Conjunto Aditivo
Utilidades Parciales: Atributos Categóricos
▪ Ej. Marca: Apple, Samsung
 𝑢𝑏𝑗 = 𝛽𝐴𝑝𝑝𝑙𝑒 𝐷𝐴𝑝𝑝𝑙𝑒,𝑗
▪ Utilidad parcial de Samsung normalizada a cero

[pág. 18]
Modelo Conjunto Aditivo
 Utilidades Parciales: Atributos Cuantitativos
▪ Dos opciones: (1) Tratarlos como variables continuas;
 (2) Tratarlos como variables discretas
▪ Ej. Precio: $199; $299; $399
▪ Modelación como variable continua:
 𝑢𝑝𝑗 = 𝛽𝑝 𝑃

[pág. 19]
Implica Relación Lineal entre Utilidad
 Parcial y Atributo
19
 𝑢𝑝
 𝛽𝑝
 𝑃𝑟𝑒𝑐𝑖𝑜

[pág. 20]
Modelo Conjunto Aditivo
Utilidades Parciales: Atributos Cuantitativos
▪ Modelación como variable discreta:
 𝑢𝑝𝑗 = 𝛽𝑝199 𝐷𝑗𝑝199 + 𝛽𝑝299 𝐷𝑗𝑝299

[pág. 21]
Modelo Conjunto Aditivo
Utilidades Parciales: Atributos Cuantitativos
▪ Tratamiento como variable discreta:
 𝑢𝑝𝑗 = 𝛽𝑝199 𝐷𝑗𝑝199 + 𝛽𝑝299 𝐷𝑗𝑝299
 Si el precio del perfil j es $199,
 𝑢𝑝𝑗 = 𝛽199

[pág. 22]
Implica Relación No Lineal entre Utilidad
 Parcial y Atributo
22
 𝑢𝑝
 $199 $299 $399 𝑃𝑟𝑒𝑐𝑖𝑜

[pág. 23]
Etapas en Desarrollo de Análisis Conjunto
1. Selección de atributos y niveles
2. Diseño de perfiles y recolección de datos
3. Estimación de utilidades parciales (“part worths”)
 e interpretación
4. Simulación y optimización

[pág. 24]
Etapa 1: Selección de Atributos y Niveles
 Paso clave en el diseño de estudios de AC
 Atributos deben ser relevantes
 Obtenidos de: (1) Estudios de mercado previos; (2)
 Focus groups /entrevistas; (3) Fuentes externas (Ej.
 “Consumer Reports”); (4) Juicio gerencial
 Número debe ser manejable (típicamente ≤ 7)

[pág. 25]
Etapa 1: Selección de Atributos y Niveles
 Número de niveles entre 3-4 por atributo
  Balance entre realismo, carga cognitiva y poder
 estadístico
 Balanceado entre atributos
  Atributos con más niveles aparecen artificialmente
 como más relevantes (efecto “número de niveles”)
 Mutuamente excluyentes

[pág. 26]
Etapa 1: Selección de Atributos y Niveles
Consideraciones
 Cuanto mayor el número de atributos a testear, mayor
 el requerimiento de datos para un mismo nivel de
 precisión
 Cuanto más tangibles y comprensibles los niveles más
 válidos los resultados
 Mientras mayor la distancia entre dos niveles
 consecutivos más difícil determinar cómo un cliente
 evaluaría un nivel intermedio

[pág. 27]
Etapa 2: Diseño de Perfiles y
Administración de Encuesta
 Diseño de perfiles (estímulos) basado en
 metodología de diseño experimental
 ¿Qué combinaciones de niveles utilizar?
 Diseño factorial completo (full factorial)
  Utiliza todas las combinaciones de niveles posibles
  Capaz de estimar efectos principales e interacciones
  Poco utilizado en la práctica (fatiga de participantes)

[pág. 28]
Ejemplo: Diseño Factorial Completo
28
  Análisis conjunto de tres atributos
 Marca Color Precio
 A Rojo $50
 B Azul $100
 C $150

[pág. 29]
Perfil Marca Color Precio
 1 A Rojo $50
 2 A Azul $50
 3 A Rojo $100
 4 A Azul $100
 5 A Rojo $150
 6 A Azul $150
 7 B Rojo $50
 8 B Azul $50
 9 B Rojo $100
 10 B Azul $100
 11 B Rojo $150
 12 B Azul $150
 13 C Rojo $50
 14 C Azul $50
 15 C Rojo $100
 16 C Azul $100
 17 C Rojo $150
29 18 C Azul $150

[pág. 30]
Etapa 2: Diseño de Perfiles y
Administración de Encuesta (...)
 Diseño Factorial Fraccional
  Usa un subconjunto del total de perfiles posible
  Diseño comúnmente usado es el diseño factorial
 fraccional ortogonal
  Diseño ortogonal permite estimar “efectos principales”
 y ciertas interacciones
 Típicamente 16-20 perfiles

[pág. 31]
31

[pág. 32]
Diseño de Perfiles: Caso Smartwatch
32
  Diseño factorial completo
  Vida Batería: 4 niveles
  Uso como Celular: 2 niveles
  Uso para Pago Móvil: 2 niveles
  Peso: 3 niveles 4 × 2 × 2 × 3 × 2 × 2 × 4 = 768
  Monitoreo de pulso: 2 niveles
  Marca: 2 niveles
  Precio: 4 niveles
  Usamos diseño factorial fraccional con 16 perfiles

[pág. 33]
Ejemplo Smartwatch: Perfiles a Evaluar
 perfil vida_bateria celular pago_movil peso pulso marca precio
 1 18 0 0 60 1 Samsung 199990
 2 48 1 1 90 1 Samsung 199990
 3 24 0 1 30 0 Apple 199990
 4 12 1 0 90 0 Apple 199990
 5 12 0 0 30 1 Samsung 249990
 6 24 1 1 60 0 Samsung 249990
 7 48 1 0 30 1 Apple 249990
 8 18 0 1 90 0 Apple 249990
 9 24 0 0 90 1 Samsung 299990
 10 12 1 1 90 0 Samsung 299990
 11 18 1 1 30 1 Apple 299990
 12 48 0 0 60 0 Apple 299990
 13 48 0 1 30 0 Samsung 399990
 14 18 1 0 30 0 Samsung 399990
 15 12 0 1 60 1 Apple 399990
 16 24 1 0 90 1 Apple 399990

[pág. 34]
Etapa 3: Estimación de Utilidades
Parciales
 Método de estimación depende del método
 utilizado
  Evaluación de perfiles: Regresión Múltiple
  Elección de perfil: Logit multinomial

[pág. 35]
Análisis de Regresión: Smartwatch
 Posible especificación (¿por qué no es única?):
 𝑅 = 𝛽0 + 𝛽𝑉𝐵18 𝐷𝑉𝐵18 + 𝛽𝑉𝐵24 𝐷𝑉𝐵24 + 𝛽𝑉𝐵 𝐷𝑉𝐵48 + 𝛽𝐶𝑒𝑙 𝐷𝐶𝑒𝑙
 +𝛽𝑝𝑚 𝐷𝑝𝑚 +𝛽𝑝𝑒60 𝐷𝑝𝑒60 + 𝛽𝑝𝑒30 𝐷𝑝𝑒30 + 𝛽𝑝𝑢 𝐷𝑝𝑢
 +𝛽𝐴𝑝𝑝𝑙𝑒 𝐷𝐴𝑝𝑝𝑙𝑒 +𝛽𝑝199 𝐷𝑝199 + 𝛽𝑝249 𝐷𝑝249 + 𝛽𝑝299 𝐷𝑝299 + 𝜀
 Perfil base es arbitrario

[pág. 36]
Análisis de Regresión: Smartwatch
 Posible especificación (¿por qué no es única?):
 𝑅 = 𝛽0 + 𝛽𝑉𝐵18 𝐷𝑉𝐵18 + 𝛽𝑉𝐵24 𝐷𝑉𝐵24 + 𝛽𝑉𝐵 𝐷𝑉𝐵48 + 𝛽𝐶𝑒𝑙 𝐷𝐶𝑒𝑙
 +𝛽𝑝𝑚 𝐷𝑝𝑚 +𝛽𝑝𝑒60 𝐷𝑝𝑒60 + 𝛽𝑝𝑒30 𝐷𝑝𝑒30 + 𝛽𝑝𝑢 𝐷𝑝𝑢
 +𝛽𝐴𝑝𝑝𝑙𝑒 𝐷𝐴𝑝𝑝𝑙𝑒 +𝛽𝑝199 𝐷𝑝199 + 𝛽𝑝249 𝐷𝑝249 + 𝛽𝑝299 𝐷𝑝299 + 𝜀
 Perfil base es arbitrario
 ¿Qué rol juega 𝛽0?

[pág. 37]
Análisis de Regresión: Smartwatch
  Posible especificación (¿por qué no es única?):
 𝑅 = 𝛽0 + 𝛽𝑉𝐵18 𝐷𝑉𝐵18 + 𝛽𝑉𝐵24 𝐷𝑉𝐵24 + 𝛽𝑉𝐵 𝐷𝑉𝐵48 + 𝛽𝐶𝑒𝑙 𝐷𝐶𝑒𝑙
 +𝛽𝑝𝑚 𝐷𝑝𝑚 +𝛽𝑝𝑒60 𝐷𝑝𝑒60 + 𝛽𝑝𝑒30 𝐷𝑝𝑒30 + 𝛽𝑝𝑢 𝐷𝑝𝑢
 +𝛽𝐴𝑝𝑝𝑙𝑒 𝐷𝐴𝑝𝑝𝑙𝑒 +𝛽𝑝199 𝐷𝑝199 + 𝛽𝑝249 𝐷𝑝249 + 𝛽𝑝299 𝐷𝑝299 + 𝜀
  Perfil base es arbitrario
Modelo Base: Samsung, 12 hrs. de batería, sin servicio celular ni pago móvil, peso de 90 grs., $399.990

[pág. 38]
Datos Estimación Smartwatch
perfil vida18 vida24 vida48 peso30 peso60 pulso apple precio19 precio24 precio29 R
 1 1 0 0 0 1 1 0 1 0 0 74
 2 0 0 1 0 0 1 0 1 0 0 87
 3 0 1 0 1 0 0 1 1 0 0 92
 4 0 0 0 0 0 0 1 1 0 0 65
 5 0 0 0 1 0 1 0 0 1 0 75
 6 0 1 0 0 1 0 0 0 1 0 82
 7 0 0 1 1 0 1 1 0 1 0 99
 8 1 0 0 0 0 0 1 0 1 0 64
 9 0 1 0 0 0 1 0 0 0 1 59
 10 0 0 0 0 0 0 0 0 0 1 57
 11 1 0 0 1 0 1 1 0 0 1 98
 12 0 0 1 0 1 0 1 0 0 1 71
 13 0 0 1 1 0 0 0 0 0 0 66
 14 1 0 0 1 0 0 0 0 0 0 68
 15 0 0 0 0 1 1 1 0 0 0 50
 16 0 1 0 0 0 1 1 0 0 0 66
 Matriz de Diseño Respuesta

[pág. 39]
Resultados Estimación Smartwatch
 . reg R vida18 vida24 vida48 celular pago peso30 peso60 pulso apple precio19 precio24 precio29
 Source SS df MS Number of obs = 16
 F(12, 3) = 20.18
 Model 3156.32601 12 263.027168 Prob > F = 0.0153
 Residual 39.1114875 3 13.0371625 R-squared = 0.9878
 Adj R-squared = 0.9388
 Total 3195.4375 15 213.029167 Root MSE = 3.6107
 R Coef. Std. Err. t P>|t| [95% Conf. Interval]
 vida18 9.304907 2.617947 3.55 0.038 .9734296 17.63638
 vida24 13 2.553151 5.09 0.015 4.874733 21.12527
 vida48 14.05491 2.617947 5.37 0.013 5.72343 22.38638
 celular 10.90187 1.911878 5.70 0.011 4.817419 16.98632
 pago_movil 3.966667 1.864558 2.13 0.123 -1.967189 9.900522
 peso30 19.78037 2.3154 8.54 0.003 12.41174 27.14901
 peso60 8.107477 2.517105 3.22 0.049 .0969253 16.11803
 pulso 6.366667 1.864558 3.41 0.042 .4328108 12.30052
 apple 4.625 1.805351 2.56 0.083 -1.120431 10.37043
 precio19 21.94509 2.617947 8.38 0.004 13.61362 30.27657
 precio24 17.5 2.553151 6.85 0.006 9.374733 25.62527
 precio29 13.69509 2.617947 5.23 0.014 5.363616 22.02657
 _cons
 _cons 28.56289
 28.56289 3.460286
 3.460286 8.25
 8.25 0.004
 0.004 17.55072
 17.55072 39.57506
 39.57506

[pág. 40]
Interpretación
40
  ¿Qué indica el R-cuadrado de la estimación?
  ¿Cuál es el número mínimo de perfiles necesarios
 para estimar el modelo?

[pág. 41]
Utilidades Parciales Estimadas
  Ecuación estimada:
 𝑅෠ = 28.6 + 9.3𝐷𝑉𝐵18 + 13𝐷𝑉𝐵24 + 14.1𝐷𝑉𝐵48 + 10.9𝐷𝐶𝑒𝑙
 +4.0𝐷𝑝𝑚 +8.1𝐷𝑝𝑒60 + 19.8𝐷𝑝𝑒30 + 6.4𝐷𝑝𝑢
 +4.6𝐷𝐴𝑝𝑝𝑙𝑒 +21.9𝐷𝑝199 + 17.5𝐷𝑝249 + 13.7𝐷𝑝299
  Utilidad del modelo base: 28.6
Modelo Base: Samsung, 12 hrs. de batería, sin servicio celular ni pago móvil, peso de 90 grs., $399.990

[pág. 42]
Smartwatch: Utilidades Parciales
 Atributo Utilidad Atributo Utilidad
 Vida Útil de Batería Precio
 12 0 399990 0
 18 9.3 299990 13.7
 24 13 249990 17.5
 48 14.05 199990 21.95
 Funcionalidad Celular Pulso
 No 0 No 0
 Sí 10.9 Si 6.37
 Pago Móvil Marca
 No 0 Samsung 0
 Sí 3.97 Apple 4.63
 Peso
 90 0
 60 8.11
 30 19.78
 Utilidad modelo base 28.56

[pág. 43]
Funciones de Utilidad Parcial
 Vida Útil Celular Pago Móvil
16 14.05 12 10.90 4 3.97
14 13.00 10
 3.5
12 3
10 9.30 8
 2.5
8 6 2
6 1.5
 4
4 1
 2
2 0.5
0 0 0
 12 horas 18 horas 24 horas 48 horas No Sí No Sí
 Peso Marca Precio
 5 25
 25
 19.78 4.5 4.63 21.95
 20 4
 3.5
 20
 17.50
 15 3 15 13.70
 2.5
 10 8.11 2 10
 1.5
 5 1 5
 0.5
 0 0 0
 30 grs 60 grs 90 grs Apple Samsung 199990 249990 299990 399990

[pág. 44]
¿Qué sugieren los resultados sobre las
preferencias por los siguientes modelos?
 Modelo I  Modelo II
 Samsung  Apple
 Duración batería: 24 h  Duración batería: 48 h
 Celular: Sí  Celular: No
 Pago Móvil: Sí  Pago Móvil: No
 Monitoreo de pulso: Sí  Monitoreo de pulso: No
 Peso 60 grs.  Peso 30 grs.
 $299.990  $299.990

[pág. 45]
Utilidades de Modelos Alternativos
45
 Atributo Modelo I
 Nivel Ut. Parcial
 Marca Samsung 0
 Vida Batería 24h 13
 Celular Sí 10.9
 Pago Móvil Sí 3.97
 Peso 60g 8.11
 Pulso Sí 6.37
 Precio $299.990 13.7
 Utilidad total 56.05

[pág. 46]
Utilidades de Modelos Alternativos
46
 Atributo Modelo II
 Nivel Ut. Parcial
 Marca Apple 4.63
 Vida Batería 48h 14.05
 Celular No 0
 Pago Móvil No 0
 Peso 30g 19.78
 Pulso No 0
 Precio $299.990 13.7
 Utilidad total 52.16

[pág. 47]
¿Qué Atributos son más Importantes en la
Decisión de Compra?
 Importancia relativa de atributos
 max 𝛽𝑎 − min(𝛽𝑎 )
 𝐼𝑎 =
 σ𝑘 max 𝛽𝑘 − min(𝛽𝑘 )

[pág. 48]
Atributo Utilidad Atributo Utilidad
 Vida Útil de Batería Precio
 12 0 399990 0
 18 9.3 299990 13.7
 24 13 249990 17.5 max 𝛽𝑉𝐵 − min(𝛽𝑉𝐵) = 14.05
 48 14.05 199990 21.95
 Funcionalidad Celular Pulso
 No 0 No 0
 Sí 10.9 Si 6.37
 Pago Móvil Marca
 No 0 Samsung 0
 Sí 3.97 Apple 4.63
 Peso
 90 0
 60 8.11
 30 19.78
48Utilidad modelo base 28.56

[pág. 49]
Vida útil Ut. Par. D Ia
12 horas 0.00
18 horas 9.30
24 horas
48 horas
 13.00
 14.05 14.05 0.17
 Importancia relativa de
 Celular
 atributo “vida útil de la
No 0.00 batería”
Sí 10.90 10.90 0.13
Pago Móvil
No 0.00
Sí 3.97 3.97 0.05
 Peso
30 grs 19.78 19.78 0.24
60 grs 8.11
90 grs 0.00
 Pulso
No 0.00 Atributos más importantes
Sí 6.37 6.37 0.08
 Marca
Apple 4.63 4.63 0.06
Samsung 0.00
 Precio
 199990 21.95 21.95 0.27
 249990 17.50
 299990 13.70
 399990 0.00
 Suma D 81.64 1.00

[pág. 50]
Número de Niveles e Importancia de
 Atributos
50
  El número de niveles incluidos puede influir sobre la
 relevancia del atributo
  Ejemplo: Estudio sobre cámaras digitales
  Atributos: Marca (3 niveles) y Precio
  Estimación alternativa usando 2 vs 3 niveles para
 Precio

[pág. 51]
Influencia de Número de Niveles en
 Importancia de Atributos
51
 Puntos de precio: $999-$1,599 Puntos de precio: $999-$1,299
 Marca Utilidad Parcial Marca Utilidad Parcial
 A 3.5 A 3.5
 B 2.5 B 2.5
 C 0 C 0
 Precio Precio
 $999 5.5 $999 3.0
 $1299 3.5 $1299 0
 $1599 0

[pág. 52]
Influencia de Número de Niveles en
 Importancia de Atributos
52
 Puntos de precio: $999-$1,599
 Marca Utilidad Parcial
 A 3.5 3.5
 𝐼𝑀𝑎𝑟𝑐𝑎 = = 0.39
 B 2.5 5.5 + 3.5
 C 0
 Precio 5.5
 𝐼𝑃𝑟𝑒𝑐𝑖𝑜 = = 0.61
 $999 5.5 5.5 + 3.5
 $1299 3.5
 $1599 0

[pág. 53]
Influencia de Número de Niveles en
 Importancia de Atributos
53
 Puntos de precio: $999-$1,299
 Marca Utilidad Parcial
 A 3.5 3.5
 𝐼𝑀𝑎𝑟𝑐𝑎 = = 0.54
 B 2.5 3.5 + 3.0
 C 0
 Precio 3.0
 𝐼𝑃𝑟𝑒𝑐𝑖𝑜 = = 0.46
 $999 3.0 3.5 + 3.0
 $1299 0

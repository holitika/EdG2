# Marketing Analytics · clase11_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 ANÁLISIS DE FACTORES Y
 MAPAS PERCEPTUALES
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Temas de Clase Anterior
2
  Concepto de posicionamiento
  Uso de Mapas Perceptuales
  Introducción al Análisis de Factores

[pág. 3]
Posicionamiento
3
 “... es el proceso de crear una imagen distintiva y significativa
 de la oferta de la compañía en la mente de los clientes”
 Chernev (2019), “Strategic Marketing Management: The Framework”

[pág. 4]
Mapas Perceptuales y Posicionamiento
 Fuerte
 Old Milwaukee
 •
 Budweiser
 • Beck’s •
 Meister Brau Ocasiones • Heineken
 • Miller • especiales
 •
Económica •
 Stroh’s
 Coors Premium
 • Michelob
 • Coors
 Miller • Light
 Old • Lite
 Milwaukee Light
 Light Moore & Pessemier (1993)

[pág. 5]
Construcción de Mapas Perceptuales:
 Técnicas
5
  Basadas en Evaluación de atributos
  Análisis de Factores
  Basadas en Juicios de similitud
  Escalamiento multidimensional (MDS)

[pág. 6]
6
 Análisis de Factores

[pág. 7]
Análisis de Factores en Construcción de
 Mapas Perceptuales
7
  Método de reducción de la dimensionalidad
  Grupo de dimensiones (factores) latentes pueden
 explicar variación en un gran número de atributos
 ▪ arribo a tiempo ▪ experiencia placentera
 ▪ de acuerdo a plan Experiencia
 ▪ calidad servicio a bordo
 Seriedad a Bordo
 ▪ solución de problemas ▪ asientos cómodos
 ▪ itinerarios confiables ▪ experiencia confortable

[pág. 8]
Análisis Factorial
 Formulación Matemática
8
 ❑Modelo asume relación lineal entre atributos observables y
 factores subyacentes
 𝑥𝑖 = 𝑙𝑖1 𝑓1 + 𝑙𝑖2 𝑓2 +. . . +𝑙𝑖𝑟 𝑓𝑟 + 𝜓𝑖 𝑒𝑖
 ▪ Tanto los factores como el componente único tienen media 0 y varianza 1
 ▪ Factores no correlacionados entre sí y no correlacionados con 𝑒

[pág. 9]
Análisis Factorial
 Formulación Matemática
9
 ❑Ecuación Fundamental del Análisis de Factores
 𝑋 = 𝐿 ∙ 𝐹 + Ψ𝐸

[pág. 10]
Análisis Factorial
 Descomposición de Varianza
10
 ❑Varianza de 𝑥𝑖 puede descomponerse como:
 𝑟
 2
 𝜎𝑖 = ෍ 𝑙𝑖𝑗 + 𝜓𝑖2
 2
 𝑗=1
 Comunalidad Componente
 específico a
 variable i

[pág. 11]
Análisis Factorial
 Descomposición de Varianza
11
 ❑Usando notación matricial:
 𝑅 = 𝐿𝐿′ + Ψ
 Matriz de Matriz de Matriz de
 correlaciones loadings correlaciones entre
 entre atributos componentes
 específicos

[pág. 12]
Estimación basada en Descomposición Espectral
 de Matriz de Correlaciones Ajustada
12
 𝑅∗ = 𝐶𝐷𝐶 ′ = (𝐶𝐷1/2 )(𝐶𝐷1/2 )′
 Matriz ortogonal Matriz diagonal (𝑝 × 𝑝)
 con eigenvectores en (eigenvalores en
 columnas diagonal principal)
 ℎ12 ⋯ 𝑟1𝑝
 𝑅∗ = ⋮ ⋱ ⋮
 𝑟𝑝1 ⋯ ℎ𝑝2

[pág. 13]
Eigenvectores, Eigenvalores y Factores
13
  Factores corresponden a eigenvectores de 𝑅∗
 Extensión/compresión del factor
 𝑅 ∗ ∙ 𝑓𝑗 = 𝜆𝑗 𝑓𝑗
 Proyección sobre factor 𝑗 (dirección de máxima varianza)
 𝑓𝑗 es la dirección en el espacio de atributos en la cual se maximiza la varianza
 Eigenvector asociado a eigenvalor más alto explica una mayor varianza

[pág. 14]
Dirección de Factor Maximiza Varianza
 Explicada
14

[pág. 15]
Dirección de Factor Maximiza Varianza
 Explicada
15

[pág. 16]
Interpretación de Eigenvalores
16
  Eigenvalor asociado a factor 𝑗:
 𝑝
 2
 𝜆𝑗 = ෍ 𝑙𝑖𝑗
 𝑖=1
  Varianza total explicada por factor 𝑗

[pág. 17]
¿Cuántos Factores?
17
  Análisis factorial entrega potencialmente tantos factores como
 atributos
  Contribución marginal de cada factor a explicar varianza es
 decreciente (por construcción)
  Reducción de la dimensionalidad requiere seleccionar 𝑟 < 𝑝
  Herramientas
  Scree plot
  Criterio de Kaiser
  Análisis paralelo

[pág. 18]
Uso de Scree Plot
18
 Yong & Pearce (2013)

[pág. 19]
¿Cuántos Factores Sugiere Retener el
 Scree Plot?
19

[pág. 20]
Criterio de Kaiser
20
  Recordar que las variables (atributos) se encuentran
 estandarizadas
  Criterio de Kaiser utiliza el umbral de 1 para
 decidir si mantener un factor
 𝜆𝑗−1 > 1 y 𝜆𝑗 ≤ 1 ⇒ Retenemos 𝑗 − 1 factores

[pág. 21]
Análisis Paralelo
21
  Simulación de múltiples muestras aleatorias de
 igual tamaño que datos observados
  Igual número de observaciones y variables
  Visualización:
  Eigenvalores basados en data real y eigenvalues
 promedio de data simulada vs.
  Número de factores

[pág. 22]
22

[pág. 23]
Varianza Explicada por Factores
23
  Consideración adicional: % de varianza explicada por
 factores
  Trade-off % explicado vs parsimonia
  Típicamente 70%-80% considerado bueno
  Peterson (Marketing Letters, 2000) analiza 803 análisis
 de factores publicados en marketing
  Varianza explicada promedio = 56,6% (rango 8%-99%)

[pág. 24]
Cargas Factoriales y Nombre de
 Factores: Ejemplo Linea Aerea
24

[pág. 25]
Aplicación: Percepciones en Categoría
 Cereales para el Desayuno
25
 ▪ Cadena de supermercados interesada en
 entender posicionamiento de su marca propia
 ▪ Estudio basado en evaluación de 11 marcas
 de cereales para el desayuno:
 Avena Quaker Fitness Vivo Integral
 Cheerios Froot Loops Zucaritas
 Chocapic Milo Marca Propia
 Cornflakes Quadritos

[pág. 26]
Ejemplo: Percepciones en Categoría
 Cereal para el Desayuno
26
 Participantes evalúan marcas en los siguientes 10 atributos
 (escala 1-7)
 • Natural • Bajo en Calorías
 • Bajo en Azúcar • Buen Valor
 • Saludable • Líder
 • Delicioso • Adulto
 • Llenador • Económico

[pág. 27]
Evaluaciones Promedio por Marca
27

[pág. 28]
Estandarización de Atributos Previo a Análisis
 Factorial
28

[pág. 29]
29

[pág. 30]
30

[pág. 31]
31

[pág. 32]
Caso Cereales: Solución de 2 Factores
32

[pág. 33]
¿Qué problema vemos en
 esta matriz de loadings?
33

[pág. 34]
Interpretación: Rotación de Factores
34
 ❑ Solución obtenida no es única
 Podemos encontrar múltiples 𝐿’s que producen la misma descomposición
 Si 𝑇 es una matriz ortogonal (𝑇 ′ 𝑇 = 𝐼), la matriz de loadings 𝐿𝑇 ′ resulta en
 una descomposición equivalente
 𝑅 = 𝐿𝑇 ′ 𝐿𝑇 ′ ′ + Ψ
 ⇔ 𝑅 = 𝐿𝐿′ + Ψ

[pág. 35]
Interpretación de Factores: Rotación Ortogonal
35
 ▪ Solución inicial podría ser
 𝑓2 difícil de interpretar si
 distintas variables
 presentan cargas similares
 en factores
 𝑓1

[pág. 36]
Interpretación de Factores: Rotación Ortogonal
36
 ▪ Solución inicial podría ser
 𝑓2′ 𝑓2
 𝑓1′ difícil de interpretar si
 distintas variables
 presentan cargas similares
 𝜙 en factores
 𝜙 𝑓1 ▪ Solución: Rotar
 ortogonalmente los ejes
 ▪ Explota hecho que loadings
 que maximizan la varianza
 común no son únicos

[pág. 37]
Interpretación de Factores: Rotación Ortogonal
37
 𝑓2 ′
 ▪ Ejes post-rotación
 usados como ejes del
 mapa perceptual
 𝑓1 ′

[pág. 38]
Obtención de Solución para 2 Factores
 Rotación Varimax
38
 cereales_fa2 <- factanal(cereales_percep,
 factors = 2, rotation = "varimax", scores
 = "regression")
 Especificamos uso de rotación

[pág. 39]
39

[pág. 40]
40 ¿Qué nombre le damos a cada factor?

[pág. 41]
Comunalidades
 Varianza de Atributos Explicada por Factores (%)
41
 Nota: 𝑐𝑜𝑚𝑚𝑢𝑛𝑎𝑙𝑖𝑡𝑦 = 1 − 𝑢𝑛𝑖𝑞𝑢𝑒𝑛𝑒𝑠𝑠
 Típicamente la comunalidad es representada en el mapa perceptual vía la
 longitud del vector de atributos

[pág. 42]
Eigenvalores
 Varianza Total Explicada por Factores (%)
42

[pág. 43]
Visualización en Mapa Perceptual
43
 ¿Cómo traducimos los resultados del AF a un Mapa Perceptual?
 Dos tipos de objetos a incluir:
 Marcas Puntos en el espacio 𝑓1 , 𝑓2
 Atributos Vectores (dirección + magnitud)

[pág. 44]
Mapa Perceptual
 Representación de Marcas
44
  Mapa perceptual representa cada marca en espacio de
 factores
  Usamos puntajes factoriales (“factor scores”) para localizar
 marcas en el mapa
  Método de “regresión”: Coordenadas obtenidas como suma
 ponderada de puntajes del atributo de cada marca
  Ponderadores dados por cargas factoriales

[pág. 45]
Mapa Perceptual
 Representación de Marcas
45
  Ejemplo: Puntajes Factoriales de Quadritos
 𝑓1,𝑄𝑢𝑎𝑑𝑟𝑖𝑡𝑜𝑠 = 𝑙𝑛𝑎𝑡𝑢𝑟𝑎𝑙,1 ∙ 𝑥𝑛𝑎𝑡𝑢𝑟𝑎𝑙,𝑄𝑢𝑎𝑑𝑟𝑖𝑡𝑜𝑠 + 𝑙𝑏𝑎𝑗𝑜𝑎𝑧𝑢𝑐𝑎𝑟,1 ∙ 𝑥𝑏𝑎𝑗𝑜𝑎𝑧𝑢𝑐𝑎𝑟,𝑄𝑢𝑎𝑑𝑟𝑖𝑡𝑜𝑠 + ⋯
 𝑓2,𝑄𝑢𝑎𝑑𝑟𝑖𝑡𝑜𝑠 = 𝑙𝑛𝑎𝑡𝑢𝑟𝑎𝑙,2 ∙ 𝑥𝑛𝑎𝑡𝑢𝑟𝑎𝑙,𝑄𝑢𝑎𝑑𝑟𝑖𝑡𝑜𝑠 + 𝑙𝑏𝑎𝑗𝑜𝑎𝑧𝑢𝑐𝑎𝑟,2 ∙ 𝑥𝑏𝑎𝑗𝑜𝑎𝑧𝑢𝑐𝑎𝑟,𝑄𝑢𝑎𝑑𝑟𝑖𝑡𝑜𝑠 + ⋯

[pág. 46]
46

[pág. 47]
47

[pág. 48]
Mapa Perceptual: Atributos
48
  Representados como vectores desde el origen en
 dirección a coordenadas dadas por loadings
  En algunos mapas longitud es proporcional a
 varianza explicada por factores

[pág. 49]
49

[pág. 50]
50

# Marketing Analytics · clase4_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 ANALÍTICA PREDICTIVA Y
 ANALÍTICA CAUSAL
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Agenda
2
 ¨ Analítica predictiva
 ¤ ¿Qué entendemos por analítica predictiva?
 ¤ Ejemplos del uso de analítica predictiva en marketing
 ¤ Proceso de modelación predictiva
 ¤ Tipo de modelos predictivos
 ¤ Supuestos de la analítica predictiva
 ¨ Analítica causal
 ¤ Aplicaciones en marketing
 ¤ Concepto de relación causal y métodos de estimación

[pág. 3]
Toma de Decisiones basada en Analítica
 Marco Conceptual
3
 Objetivos de Negocios
 Problemas de Negocios
 Ideas de Negocios
 Analítica:
 Exploratoria/Descriptiva
 Predictiva | Causal
 Intuición de Negocios
 Decisiones de Negocios (optimización)
 Escalamiento
 Adaptado de Anderson & Zettelmeyer (2021)

[pág. 4]
4
 Analítica Predictiva

[pág. 5]
¿Qué entendemos por analítica
 predictiva?
5
 “Arte de construir y usar modelos que hacen
 predicciones basados en patrones extraídos de
 datos históricos”
 Kelleher et al. (2015), “Fundamentals of Machine Learning for
 Predictive Data Analytics”
 Anticipar el futuro en base a patrones históricos

[pág. 6]
Aplicaciones Típicas en Marketing
 Predicción de Fuga de Clientes (“Churn”)
6
 ¨ ¿Qué clientes presentan una mayor
 propensión a al fuga?
 ¨ Uso de datos históricos de no
 renovación (0-1) y potenciales
 factores que explican fuga (uso,
 demografía, etc.)
 ¨ Modelo entrega predicción de
 probabilidad de fuga en función de
 predictores
 ¨ Resultados usados en programas de
 retención proactivos

[pág. 7]
Aplicaciones Típicas en Marketing
 Cross-selling y Upselling
7
 ¨ ¿Qué clientes tienen mayor
 propensión a comprar producto
 relacionado o de mayor margen?
 ¨ Uso de datos históricos de compra
 (0-1), tiempo como cliente, número
 de transacciones, productos
 comprados, etc.
 ¨ Modelo entrega predicción de
 probabilidad de compra
 ¨ Resultados usados en campañas
 de ofertas de productos

[pág. 8]
Aplicaciones Típicas en Marketing
 Análisis de Sentimientos
8
 ¨ ¿Qué sentimientos están
 asociados al uso de ciertos
 términos?
 ¨ Reseñas, interacción con call
 centers, etc.
 ¨ Modelo entrega predicción de
 probabilidad de que texto sea
 positivo/neutro/negativo
 ¨ Resultados usados en relaciones
 con clientes, diseño de
 productos, etc.

[pág. 9]
Analítica Predictiva Involucra Anticipar el
 Futuro
9
 1/6/2023 1/6/2024
 Ventana de
 observación
 Ventana de
 predicción
 12 meses 6 meses

[pág. 10]
Etapas en el Proceso de Modelación
 Predictiva
10
 1. Construcción
 de variables
• Respuesta o
 target
• Predictores o
 features
 𝑥, 𝑦

[pág. 11]
Etapas en el Proceso de Modelación
 Predictiva
11
 1. Construcción 2. Construcción
 de variables de modelo
 • Estadístico
• Respuesta o tradicional/
 target Machine
• Predictores o Learning
 features • Clasificación/
 ”regresión”
 𝑥, 𝑦 𝑓 𝑥

[pág. 12]
Etapas en el Proceso de Modelación
 Predictiva
12
 1. Construcción 2. Construcción 3. Entrenamiento
 de variables de modelo del modelo
 • Estadístico • Estimación de
• Respuesta o tradicional/ parámetros /
 target Machine relaciones x-y
• Predictores o Learning • Datos de
 features • Clasificación/ entrenamiento
 ”regresión”
 𝑥, 𝑦 𝑓 𝑥 𝑓% 𝑥

[pág. 13]
Etapas en el Proceso de Modelación
 Predictiva
13
 1. Construcción 2. Construcción 4. Evaluación
 3. Entrenamiento
 de variables de modelo • R-cuadrado,
 del modelo
 • Estadístico RMSE
 • Estimación de
• Respuesta o tradicional/ • Curva ROC,
 parámetros /
 target Machine sensibilidad,
 relaciones x-y
• Predictores o Learning etc.
 • Datos de
 features • Clasificación/ entrenamiento
 ”regresión”
 𝑥, 𝑦 𝑓 𝑥 𝑓% 𝑥 min 𝐸𝐶𝑀 𝑥

[pág. 14]
Evaluación involucra Minimización de
 Errores de Predicción
14
 ,
 𝐸𝐶𝑀 𝑥 = 𝐸 (
 𝑦 − 𝑓(𝑥)

[pág. 15]
Evaluación involucra Minimización de
 Errores de Predicción
15
 ,
 𝐸𝐶𝑀 𝑥 = 𝐸 (
 𝑦 − 𝑓(𝑥)
 ! !
 &
 𝐸𝐶𝑀 𝑥 = 𝐸 𝑓(𝑥) − 𝑓(𝑥) + 𝐸 𝑓& 𝑥 − 𝐸 𝑓(𝑥)
 & + 𝜎"!
 Sesgo2 Varianza Error
 irreducible

[pág. 16]
Recordar: Componentes del Error de
 Predicción
16
 Sesgo: Error introducido por aproximar un problema
 complejo del mundo real con un modelo simple
 Varianza: Error asociado a la sensibilidad a la data
 de entrenamiento
 Error irreducible: Error que no puede eliminarse aún
 disponiendo de infinitos datos

[pág. 17]
Dos Grandes Tipos de Modelo Predictivo
 (Importante Distinguir entre ellos para un Tomador de Decisiones)
17
 ¨ Modelos Estadísticos
 ¨ Modelos de Machine Learning

[pág. 18]
Modelos Estadísticos
18
 ¨ Analista decide forma funcional y predictores
 ¨ Ej. regresión lineal, regresión logística
 ¨ Simples: Hacen un mayor número de supuestos
 sobre el PGD
 ¤ Tendencia a mayor sesgo y menor varianza (menor
 propensión a overfit data de training)
 ¨ Interpretables

[pág. 19]
Ejemplo: Probabilidad de Recomendar
19
 ¨ Modelo predictivo de probabilidad de recomendar
 producto/tienda/servicio en base a interacciones
 con call center:
 ¤ Tiempo de espera en llamada (toh)
 ¤ Antiguedad de agente (tenure)
 𝑝𝑡𝑟 = 𝛽- + 𝛽.𝑡𝑜ℎ + 𝛽/𝑡𝑒𝑛𝑢𝑟𝑒 + 𝜀

[pág. 20]
“Probabilidad de Recomendar”
20

[pág. 21]
Resultados de Entrenamiento del Modelo son
 Interpretables
21

[pág. 22]
Modelos de Machine Learning
22
 ¨ Modelo aprende patrones a partir de los datos
 ¨ Tienden a ser altamente flexibles
 ¨ Tendencia a menor sesgo pero alta varianza
 ¤ Necesidad de evitar “overfitting”
 ¨ Flexibilidad les permite mejoras en poder predictivo
 ¨ Ej. redes neuronales artificiales, árboles de decisión,
 modelos de ensamble (random forests, XGBOOST, etc.)
 ¨ Menos interpretables (“caja negra”)

[pág. 23]
Arquitectura de Red Neuronal Simple
23
 Input Output
 Layer Layer
 𝑥!
 𝑤!
 𝑥" 𝑤"
 𝑥# 𝑤#
 ∑ 𝜑(0) 𝑦
 ⋮
 ⋮
 𝑤$ Combination Activation Output
 Function Function
 𝑥$
 Inputs Weights

[pág. 24]
Ejemplo: Deep Neural Networks
24

[pág. 25]
Modelos Estadísticos vs Machine Learning
25
 ¨ Gran ventaja de modelos estadísticos: Interpretabilidad
 ¤ Analista especifica relación entre X e Y
 ¤ Puedo entender cómo una variable X afecta a Y
 ¨ Gran ventaja de los modelos de ML: Predicciones más
 precisas
 ¤ Modelos capaces de aprender relaciones altamente no
 lineales

[pág. 26]
SUPUESTOS DE LA ANALÍTICA PREDICTIVA
q Situación recurrente en el tiempo
 ¿Qué clientes tienen mayor riesgo de fuga?
 ¿Qué clientes tienen mayor propensión a volver a comprar?
 ¿Qué clientes tienen una mayor propensión a responder a una oferta?
 ¿Qué clientes tienen una mayor propensión a comprar un producto más
 premium de la compañía?
 SUPUESTO CLAVE: INVARIANZA SITUACIONAL

[pág. 27]
Analítica Predictiva
SUPUESTO CLAVE: FUTURO SE VA A PARECER AL PASADO
Cambios en el “proceso generador de datos” (entorno económico / de negocios) alteran
desempeño del modelo

[pág. 28]
Analítica Causal

[pág. 29]
Analítica Causal: Midiendo el Efecto de
 Iniciativas de Negocios
29
 ¨ Muchas decisiones involucran entender impacto de acciones de
 marketing sobre comportamiento del consumidor
 Precios Compras
 Promociones Vistas
 Campaña de retención Churn
 Calidad de servicio Satisfacción
 … …
 ¿Cómo evaluamos el impacto de iniciativas?

[pág. 30]
¿Qué entendemos por “Relación Causal”?
30
 ¨ Respuestas de filósofos modernos:
 “If a person eats of a particular dish, and dies as a consequence,
 that is, would not have died if he had not eaten it, people would be
 apt to say that eating of that dish was the source of his death”
 John Stuart Mill (1843), “A System of Logic”.
 “Causation is something that makes a difference, and the difference
 it makes must be a difference from what would have happened
 without it”
 David Lewis (1973), “Causation”.

[pág. 31]
Contrafactuales y Resultados Potenciales
31
 ¨ Concepto clave: Comparación con “contrafactual”
 ¨ Estadísticos del s. XX (Neyman, 1923) introducen notación y
 principios que permiten estimar relaciones causales
 ¨ Concepto de “resultados potenciales” (Ej. Anuncio en FB)
 𝑌 1 = 𝐶𝑜𝑛𝑣𝑒𝑟𝑠𝑖ó𝑛 𝑝𝑜𝑡𝑒𝑛𝑐𝑖𝑎𝑙 𝑠𝑖 𝑝𝑒𝑟𝑠𝑜𝑛𝑎 𝑒𝑠 𝑒𝑥𝑝𝑢𝑒𝑠𝑡𝑎 𝑎 𝑎𝑣𝑖𝑠𝑜 𝑒𝑛 𝐹𝐵
 𝑌 0 = 𝐶𝑜𝑛𝑣𝑒𝑟𝑠𝑖ó𝑛 𝑝𝑜𝑡𝑒𝑛𝑐𝑖𝑎𝑙 𝑠𝑖 𝑝𝑒𝑟𝑠𝑜𝑛𝑎 𝑛𝑜 𝑒𝑠 𝑒𝑥𝑝𝑢𝑒𝑠𝑡𝑎 𝑎 𝑎𝑣𝑖𝑠𝑜 𝑒𝑛 𝐹𝐵

[pág. 32]
Efecto Causal de Aviso en FB
32
 ¨ ¿Cuál es el efecto causal de la publicidad sobre la conversión?
 Efecto Causal = 𝑌% 1 − 𝑌% 0
 ¨ Problema fundamental de la inferencia causal: No es posible
 observar simultáneamente ambos resultados potenciales!
 ¨ Solución: Foco en efecto causal promedio (ATE) + Supuesto de
 Independencia

[pág. 33]
Efecto Causal Promedio
33
 ¨ Efecto causal promedio:
 𝐴𝑇𝐸 = 𝐸 𝑌 1 − 𝐸 𝑌(0)
 ¨ Aún no podemos calcular este efecto causal promedio
 (no observamos resultados potenciales para ambos grupos)
 ¨ Pero podemos estimarlo bajo ciertos supuestos

[pág. 34]
Diferencia en Resultados Promedio
34
 ¨ A partir de los datos podemos estimar la diferencia
 entre resultados promedio:
 𝑆𝐷𝑂 = 𝐸 𝑌|𝐷 = 1 − 𝐸 𝑌|𝐷 = 0
 Conversiones Conversiones 𝐷 = Tratamiento
 promedio de promedio de o intervención
 grupo expuesto grupo no expuesto
 al anuncio al anuncio

[pág. 35]
¿Fue Efectivo el Anuncio en FB?
35
 ( = 0.15 − 0.01 = 0.14
 𝑆𝐷𝑂

[pág. 36]
¿Fue Efectivo el Aviso en FB?
36
 ( = 0.15 − 0.01 = 0.14
 𝑆𝐷𝑂
 • ¿Es este un efecto causal?

[pág. 37]
¿Fue Efectivo el Aviso en FB?
37
 ( = 0.15 − 0.01 = 0.14
 𝑆𝐷𝑂
 • ¿Es este un efecto causal?
 • ¿Qué pasa si FB hace targeting y
 muestra anuncio a quienes tienen
 mayor probabilidad de compra?

[pág. 38]
Correlación ≠ Causalidad
38
 ¨ Correlación entre exposición y conversión
 “contaminada” por un tercer factor (”confounder”)
 ¤ Actividades de direccionamiento del algoritmo de FB
 ¨ Comportamiento optimizador principal razón de que
 correlación rara vez revele relaciones causales
 ¤ Ej. óptimo para FB direccionar anuncio
 ¨ Relaciones causales pueden existir incluso en ausencia
 de correlación (Ej. política monetaria)

[pág. 39]
Simple Diferencia de Resultados y ATE
39
 ¨ En general, 𝐴𝑇𝐸 ≠ 𝑆𝐷𝑂
 ¨ Típicamente 𝐷 está correlacionado con resultados
 potenciales
 ¤ Ej. FB muestra anuncios a personas que tienen una
 mayor propensión a comprar en ausencia del aviso
 SDO va a sobre-estimar el
 verdadero efecto del aviso

[pág. 40]
¿Bajo qué condiciones SDO = ATE?
40
 ¨ Bajo el supuesto de independencia entre 𝐷 e 𝑌(0),
 𝑌(1)
 ¨ Para “ver” esto, conviene clarificar relación entre
 resultados observados, 𝑌, y resultados potenciales
 𝑌! = 𝐷! 𝑌! 1 + (1 − 𝐷! )𝑌! (0)

[pág. 41]
¿Bajo qué condiciones SDO = ATE?
41
 𝑆𝐷𝑂 = 𝐸 𝑌|𝐷 = 1 − 𝐸 𝑌|𝐷 = 0
 𝑆𝐷𝑂 = 𝐸 𝑌(1)|𝐷 = 1 − 𝐸 𝑌(0)|𝐷 = 0
 supuesto de
 𝑆𝐷𝑂 = 𝐸 𝑌(1) − 𝐸 𝑌(0) independencia
 𝑆𝐷𝑂 = 𝐴𝑇𝐸
 Asignación aleatoria del tratamiento permite estimar ATE!

[pág. 42]
Experimentos: Piedra Angular de la
 Inferencia Causal
42
 ¨ Herramienta fundamental en estimación de relaciones causales
 ¨ Asignación aleatoria del tratamiento (𝐷) permite usar
 resultados del grupo control como contrafactual
 ¨ Ventajas:
 ¤ Permite medir verdadero impacto de la intervención
 ¤ No requiere usar modelos sofisticados y resultados son
 simples de interpretar
 ¤ Potencial de utilización para evaluar acciones innovadoras

[pág. 43]
EXPERIMENTACIÓN CLAVE EN INNOVACIÓN DE
COMPAÑÍAS LÍDERES
§ Uso de experimentos controlados
 para mejorar experiencia del cliente
§ + 10.000 experimentos por año
§ Cambios en layout de “landing page”
§ Color de botón de reserva
§ Bundling, etc.
“We call this evidence-based customer-centric product development. All our product
decisions are based on reliable evidence about customer behavior and preferences. We
believe that controlled experimentation is the most successful approach to building
products that customers want”
 Lukas Vermeer, Senior Product Owner Experimentation

[pág. 44]
CADA VEZ MÁS EMPRESAS UTILIZAN EXPERIMENTOS
 PARA INFORMAR TOMA DE DECISIONES
44
 “Our success at Amazon is a
 function of how many
 experiments we do per year,
 per month, per week, per
 day.”
 —JEFF BEZOS, CEO, AMAZON

[pág. 45]
Importancia de la Analítica Causal
45
 “The number-one reason for bad analytics is that
 data not generated as a true experiment is
 presented and interpreted as if it was”
 Anderson and Zettelmeyer (2021), “Leading with AI and Analytics”

[pág. 46]
Analítica Predictiva vs. Analítica Causal
46
 ¨ Distinción muy importante
 ¤ Tipo de preguntas a responder
 ¤ Recursos involucrados (datos históricos vs generados
 experimentalmente)
 ¨ Analítica predictiva sólo requiere de una alta
 correlación entre variables 𝑥 e 𝑦
 ¨ Analítica causal require construir contrafactual
 apropiado

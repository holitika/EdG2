# Marketing Analytics · clase16_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 CLV EN CONTEXTOS
 CONTRACTUALES: MODELO BETA-
 GEOMÉTRICO (II)
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Clase Anterior
2
  CLV en contextos contractuales
  Modelo beta-geométrico de estimación de función
 de supervivencia

[pág. 3]
CLV en Contextos Contractuales
3
 𝑇
 𝑆(𝑡)𝑚𝑡
 𝐸 𝐶𝐿𝑉 = ෍
 (1 + 𝑑)𝑡
 𝑡=1

[pág. 4]
Uso de Modelos Probabilísticos en
 Estimación de CLV
4
 Presente Futuro
 x x x x x x
 𝑡
 Características latentes (𝜙)
 Fader & Hardie (Journal of Interactive Marketing, 2009)

[pág. 5]
Ejemplo: Compañía basada en Modelo de
 Suscripción
5
 Año Regular Premium
 • # de clientes en
 0 1000 1000
 segmentos Premium
 1 631 869
 y Regular 2 468 743
 3 382 653
 • Observamos
 4 326 593
 primeros 7 años
 5 289 551
 • Objetivo: Projectar 6 262 517
 7 241 491
 tasas de retención
 8 223 468
 pera años 8-12
 9 207 445
 10 194 427
 11 183 409
 12 173 394

[pág. 6]
Funciones de Supervivencia Observadas
6

[pág. 7]
Modelo BG: Vida del Cliente
 Gobernada por Distribución Geométrica
7
  Supuesto 1: Individuo permanece como cliente con
 probabilidad de retención (1 − 𝜃)
 Duración de relación con la firma, 𝑇 sigue
 una distribución geométrica (desplazada)
 𝑃 𝑇 = 𝑡 𝜃 = 𝜃(1 − 𝜃)𝑡−1 , 𝑡 = 1, 2, 3, …

[pág. 8]
Heterogeneidad en Probabilidad de
 Retención
8
  Supuesto 2. La heterogeneidad en 𝜃 sigue una
 distribución beta con pdf:
 𝜃 𝛼−1 1 − 𝜃 𝛽−1
 𝑓 𝜃 𝛼, 𝛽 = 0≤𝜃≤1
 𝐵 𝛼, 𝛽
 𝛼, 𝛽 > 0

[pág. 9]
Función Beta
9
 • Definida por integral:
 1
 𝐵 𝛼, 𝛽 = න 𝑧 𝛼−1 1 − 𝑧 𝛽−1 𝑑𝑧
 0
 • En términos de funciones gamma:
 Γ 𝛼 Γ 𝛽
 𝐵 𝛼, 𝛽 = Γ 𝑥 = 𝑥−1 !
 Γ 𝛼+𝛽

[pág. 10]
Distribución Beta
10

[pág. 11]
Probabilidad Beta-Geométrica
11
 𝐵(𝛼 + 1, 𝛽 + 𝑡 − 1)
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 =
 𝐵 𝛼, 𝛽
 • Mixtura de distribuciones geométricas usando como distribución de mezcla la
 distribución beta

[pág. 12]
Función de Supervivencia BG
12
 𝐵(𝛼, 𝛽 + 𝑡)
 𝑆 𝑡 𝛼, 𝛽 =
 𝐵 𝛼, 𝛽
 𝛽+𝑡−1
 𝑟(𝑡|𝛼, 𝛽) =
 𝛼+𝛽+𝑡−1

[pág. 13]
Evolución de Tasa de Retención en Modelo BG
13
 ¿Qué explica
 que 𝑟(𝑡) sea
 creciente en 𝑡?

[pág. 14]
Modelo BG: Ejemplo
14
  Suponga una cohorte de clientes que se comporta BG
  Cada cliente individual tiene una probabilidad de no
 renovar su suscripción igual a 𝜃
  La probabilidad de no renovar se distribuye beta con
 parámetros
  𝛼 =1
  𝛽 = 2

[pág. 15]
Modelo BG: Ejemplo
15
 1. ¿Cuál es la probabilidad de que un cliente de la cohorte
 renueve su contrato en su primera oportunidad de no
 renovar?
 2. ¿Cuál es la probabilidad de que el cliente no renueve en
 el período 2?
 3. Usando las probabilidades calculadas en 1. y 2. ¿Cuál es
 la probabilidad de que el cliente sobreviva hasta el
 período 2 (i.e. renueve en períodos 1 y 2)?
 4. ¿Cuál es la tasa de retención de clientes en el período 2?

[pág. 16]
Modelo BG: Estimación
16
  Estimación vía Máxima Verosimilitud

[pág. 17]
Modelo BG: Estimación
17
  Estimación vía Máxima Verosimilitud
  ¿Qué valores de los parámetros 𝛼, 𝛽 hacen más probable
 observar la muestra?

[pág. 18]
Modelo BG: Estimación
18
  Estimación vía Máxima Verosimilitud
  ¿Qué valores de los parámetros 𝛼, 𝛽 hacen más probable
 observar la muestra?
  En cada período observamos el número de clientes perdidos

[pág. 19]
Modelo BG: Estimación
19
  Estimación vía Máxima Verosimilitud
  ¿Qué valores de los parámetros 𝛼, 𝛽 hacen más probable
 observar la muestra?
  En cada período observamos el número de clientes perdidos
  Probabilidad de perder un cliente en 𝑡:
 𝑃 𝑇 = 𝑡 𝛼, 𝛽

[pág. 20]
Modelo BG: Estimación
20
  Estimación vía Máxima Verosimilitud
  ¿Qué valores de los parámetros 𝛼, 𝛽 hacen más probable
 observar la muestra?
  En cada período observamos el número de clientes perdidos
  Probabilidad de perder un cliente en 𝑡: 𝑃 𝑇 = 𝑡 𝛼, 𝛽
  Probabilidad de perder 𝑛𝑡 clientes en 𝑡 (asumiendo
 independencia):
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 𝑛𝑡

[pág. 21]
Modelo BG: Estimación
21
  Probabilidad de observar la muestra completa (7 años):
 𝑃 𝑑𝑎𝑡𝑎 𝛼, 𝛽 = 𝑃 𝑇 = 1 𝛼, 𝛽 𝑛1 × 𝑃 𝑇 = 2 𝛼, 𝛽 𝑛2 × 𝑃 𝑇 = 3 𝛼, 𝛽 𝑛3
 × 𝑃 𝑇 = 4 𝛼, 𝛽 𝑛4 × 𝑃 𝑇 = 5 𝛼, 𝛽 𝑛5 × 𝑃 𝑇 = 6 𝛼, 𝛽 𝑛6
 7
 × 𝑃 𝑇 = 6 𝛼, 𝛽 𝑛6 × 𝑃 𝑇 = 7 𝛼, 𝛽 𝑛7 × S 7 𝛼, 𝛽 𝑛−σ𝑡=1 𝑛𝑡
 𝑛 = Tamaño de cohorte

[pág. 22]
Función de Verosimilitud
22
 • ¿Qué valores de los parámetros maximizan la probabilidad
 (verosimilitud) de la data?
 𝐿 𝛼, 𝛽 𝑑𝑎𝑡𝑎 = 𝑃 𝑇 = 1 𝛼, 𝛽 𝑛1 × 𝑃 𝑇 = 2 𝛼, 𝛽 𝑛2 × 𝑃 𝑇 = 3 𝛼, 𝛽 𝑛3
 × 𝑃 𝑇 = 4 𝛼, 𝛽 𝑛4 × 𝑃 𝑇 = 5 𝛼, 𝛽 𝑛5 × 𝑃 𝑇 = 6 𝛼, 𝛽 𝑛6
 7
 × 𝑃 𝑇 = 6 𝛼, 𝛽 𝑛6 × 𝑃 𝑇 = 7 𝛼, 𝛽 𝑛7 × S 7 𝛼, 𝛽 𝑛−σ𝑡=1 𝑛𝑡

[pág. 23]
Función de Verosimilitud
23
 • Equivalente a maximizar función de log-verosimilitud
 7 7
 𝐿𝐿 𝛼, 𝛽 𝑑𝑎𝑡𝑎 = ෍ 𝑛𝑡 log[𝑃 𝑇 = 𝑡 𝛼, 𝛽 ] + 𝑛 − ෍ 𝑛𝑡 log[S 7 𝛼, 𝛽 ]
 𝑡=1 𝑡=1

[pág. 24]
Estimación Usando Excel
24
  Ver planilla: modelo_bg_canvas.xlsx
  Maximizaxión de 𝐿𝐿 𝛼, 𝛽 𝑑𝑎𝑡𝑎 usando Solver

[pág. 25]
Supervivencia Observada vs.
 Proyectada: Segmento Regular
25

[pág. 26]
Supervivencia Observada vs. Proyectada:
 Segmento Premium
26

[pág. 27]
Estimación de CLV para Nuevos Clientes
27
  La empresa está considerando adquirir un conjunto de clientes con
 características similares a aquellos en el segmento premium
  ¿Cuánto es lo máximo que debería estar dispuesta a pagar la
 empresa por un cliente?
  Supuestos:
  Clientes se comportan de acuerdo al modelo BG
  Margen: 𝑚𝑡 = 200 + 5(𝑡 − 1)
  𝑇 = 7
  Tasa de descuento 𝑑 = 0.1
  Tasa de adquisición 𝑎 = 0.05 (prob. de conversión de prospecto)

[pág. 28]
Estimación de CLV para Nuevos Clientes
28
 𝑇
 𝑆(𝑡) ∙ 𝑚𝑡
 𝐸 𝐶𝐿𝑉 = ෍
 (1 + 𝑑)𝑡
 𝑡=1
 7
 𝑆(𝑡) ∙ 200 + 5 𝑡 − 1
 𝐸 𝐶𝐿𝑉 = ෍
 (1 + 0.1)𝑡
 𝑡=1

[pág. 29]
Estimación de Valor de Base de Clientes
29
  ¿Podemos usar nuestro modelo BG para calcular el valor
 residual de clientes ya adquiridos?
  No directamente (¿por qué?)
  Distribución beta usada en el modelo no tiene en cuenta
 que, condicional en haber sobrevivido, la probabilidad de
 retención del cliente es mayor
  Es necesario ajustar la distribución beta para tener en
 cuenta que estos clientes tienen mayor probabilidad de
 renovar (vs. cliente promedio ex-ante)

[pág. 30]
Concepto de Valor de Vida Residual
30
  Valor de vida de clientes actuales hasta término de relación
 𝑡
 1 2 … 𝜏 𝜏+1 𝜏+2 …
 Clientes observados justo antes de
 renovar en el período 𝜏

[pág. 31]
Concepto de Valor de Vida Residual
31
  Valor de vida de clientes actuales:
 ∞
 𝑆(𝑡|𝑡 > 𝜏 − 1) ∙ 𝑚𝑡
 𝐸 𝑅𝐿𝑉|𝐴𝑐𝑡𝑖𝑣𝑜 ℎ𝑎𝑠𝑡𝑎 𝜏 − 1 = ෍
 (1 + 𝑑)𝑡−𝜏
 𝑡=𝜏
 𝑡 = 𝜏, 𝜏 + 1, 𝜏 + 2, …

[pág. 32]
Valor de Vida Residual de Cliente
 Geométrico
32
  Asumiendo por simplicidad que los márgenes son constantes, el
 E[RLV] de un cliente geométrico está dado por
 𝐸 𝑅𝐿𝑉|𝐴𝑐𝑡𝑖𝑣𝑜 ℎ𝑎𝑠𝑡𝑎 𝜏 − 1 = 𝑚 ∙ 𝐷𝐸𝑅𝐿
 Vida residual
 esperada
 donde, descontada
 1+𝑑
 𝐷𝐸𝑅𝐿 = (1 − 𝜃)
 𝑑+𝜃

[pág. 33]
DERL de Cliente Beta-Geométrico
 Enfoque “naïve”
33
 1
 1+𝑑
 𝐷𝐸𝑅𝐿 = න (1 − 𝜃) 𝑓 𝜃|𝛼, 𝛽 𝑑𝜃
 0 𝑑+𝜃
 DERL de cliente Dist. Beta
 activo hasta 𝜏-1
 No toma en cuenta que 𝜃 es menor para
 cliente activo hasta 𝜏-1

[pág. 34]
Actualización de Probabilidad Beta
34
  Para tomar en cuenta que cliente se mantiene activo hasta 𝜏-1
 usamos Teorema de Bayes:
 𝑆 𝜏 − 1|𝜃 𝑓 𝜃|𝛼, 𝛽
 𝑓 𝜃|𝛼, 𝛽, 𝐴𝑐𝑡𝑖𝑣𝑜 ℎ𝑎𝑠𝑡𝑎 𝜏 − 1 =
 𝑆 𝜏 − 1|𝛼, 𝛽
 • 𝑓 𝜃|𝛼, 𝛽 : distribución previa (prior)
 • 𝑆 𝜏 − 1|𝜃 : probabilidad de permanecer activo hasta 𝜏 − 1
 • 𝑆 𝜏 − 1|𝛼, 𝛽 : probabilidad marginal de permanecer activo hasta 𝜏-1

[pág. 35]
DERL de Cliente Beta-Geométrico
 Enfoque Correcto
35
 verosimilitud
 prior
 1
 1 + 𝑑 𝑆 𝜏 − 1|𝜃 𝑓 𝜃|𝛼, 𝛽
 𝐷𝐸𝑅𝐿 = න (1 − 𝜃) 𝑑𝜃
 0 𝑑+𝜃 𝑆 𝜏 − 1|𝛼, 𝛽
 marginal
 𝑓 𝜃|𝛼, 𝛽, 𝐴𝑐𝑡𝑖𝑣𝑜 ℎ𝑎𝑠𝑡𝑎 𝜏 − 1

[pág. 36]
36
 ANEXO
 Valor de Vida Residual Esperado de Cliente
 Geométrico

[pág. 37]
Supervivencia Condicional
37
  Si cada cliente individual se comporta geométrico
 𝑆(𝑡)
 𝑆 𝑡 𝑡 >𝜏−1 =
 𝑆(𝜏 − 1)
 (1 − 𝜃)𝑡
 𝑆 𝑡 𝑡 >𝜏−1 = 𝜏−1 = (1 − 𝜃)𝑡−𝜏+1
 1−𝜃

[pág. 38]
RLV de Cliente Geométrico
 Supuesto: Márgenes Constantes
38
 ∞
 1 − 𝜃 𝑡−𝜏+1
 𝐸 𝑅𝐿𝑉|𝐴𝑐𝑡𝑖𝑣𝑜 ℎ𝑎𝑠𝑡𝑎 𝜏 − 1 = 𝑚 ෍
 (1 + 𝑑)𝑡−𝜏
 𝑡=𝜏
 ∞ 𝑡−𝜏
 1−𝜃
 = 𝑚(1 − 𝜃) ෍
 1+𝑑
 𝑡=𝜏
 1+𝑑
 = 𝑚(1 − 𝜃)
 𝑑+𝜃
 DERL

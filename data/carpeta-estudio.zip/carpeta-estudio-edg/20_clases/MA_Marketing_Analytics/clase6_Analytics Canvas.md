# Marketing Analytics · clase6_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 SEGMENTACIÓN A-PRIORI:
 ANÁLISIS RFM
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Agenda
2
  Clase anterior: Introducción a la Segmentación
  Tres elementos de un análisis de segmentación:
  Bases de segmentación
  Enfoque de segmentación
  Método de segmentación

[pág. 3]
Enfoques de Segmentación
3
  Segmentación A-priori
  Segmentación Post-hoc

[pág. 4]
EJEMPLO DE SEGMENTACIÓN A-PRIORI
 SEGMENTACIÓN RFM
4

[pág. 5]
Ejemplo de Segmentación A Priori
 Análisis RFM
5
  Método originado en marketing directo en los ‘60
  Muy utilizado en retail e ecommerce
  Segmentación y direccionamiento de campañas
  Basado en 3 métricas de comportamiento:
  Recencia – Frecuencia – Monto
 ¿Qué tipo de bases de segmentación?
 (Generales/Específicas al producto;
 Observables/No Observables)

[pág. 6]
Market Share Models CLV
 Models
 RFM
 ANOVA Conjoint HB
 Regression Cluster
 Segment. MNL Latent Structural
Analytics MDS Class
 1900 1925 1950 1975 2000 2025
 Data
 Transaction Clickstream Video
 Survey Eye Diary POS Search Social
 Tracking Panels Scanning
 Location
 6
 Adaptado de Wedel & Kannan (Journal of Marketing, 2016) Digital Data

[pág. 7]
RFM: Recencia, Frecuencia y Monto
❑Tres variables clave resumen historia de compras de un cliente:
 R F M
 RECENCIA FRECUENCIA MONTO
 ¿Cuán recientemente ¿Cuántas veces Monto total o promedio
 compró el cliente? Días compró el cliente gastado durante un
 desde última compra durante un período período dado
 dado?
 Correlación Correlación Correlación
 negativa con prob. positiva con prob. positiva con prob.
 de compra de compra. de compra.
 Correlación fuerte Correlación más Correlación más
 con valor débil que R. débil que M

[pág. 8]
Análisis RFM: Set de Datos Típico
 Datos transaccionales
 Registran compras/interacciones de clientes durante un
 determinado período de tiempo
 Variables clave
  ID de cliente
  Fecha de la transacción
  Monto de la transacción
  Información contextual adicional (categoría, etc)

[pág. 9]
Ejemplo de Set de Datos RFM
9
 ID de Cliente Fecha de la Transacción Monto de la Transacción
 001 2024-07-15 $150
 002 2024-06-20 $250
 001 2024-08-10 $120
 003 2024-08-01 $80
 002 2024-08-05 $200

[pág. 10]
Paso 1 en el Análisis RFM
 Construcción de variables (unidad de análisis:
 cliente)
  Recencia: Días desde última compra
  Frecuencia: # de compras en el período
  Monto: Gasto total en el período ($)

[pág. 11]
Agregación: Recencia, Frecuencia y
 Monto
11
 ID de Cliente Recencia Frecuencia Monto
 001 10 2 $270
 002 5 2 $450
 003 18 1 $80

[pág. 12]
Paso 2: Codificación en N-tiles
12
  Escogemos variable de interés (recencia, frecuencia,
 monto)
  Ordenamos datos de más a menos deseable en la
 variable
  Decidimos en cuántos groupos categorizar clientes
  Normalmente 5 grupos (separamos clientes en quintiles)
  Asignamos clientes a grupos
 ◼ Grupo top es quintil 5, siguiente es quintil 4, etc.

[pág. 13]
Codificación en Quintiles
 Recencia
13
  Orden en quintiles de recencia
 compra más
 reciente
 Last purchase:  R=1
 R = 5  R=1
 Group
 Last 1
 purchase: Group 1
 1 day ago 1 day ago
 Last purchase:
 Last purchase: Group 1  R=1
 Group 1
 Grupo 1R=1
 R=1 average average
 1 day1ago
 day ago
 Last
 purchase:
 R=1
 average
  R=1
 response rate
 response rate
 average Group 1 R = 5  R=1
 R=1 response rate
 1 day ago  R=1 response rate
  R=1
 Last purchase:
 1 day ago
  1R=1
 Group  R=1
  R=1
 R = 5  R=1 average
 response rate
 average
  
 R=1R=2
 Group 2
 Group 2
  R=2
 response rate Group 2  R=1
 R=2
 Group 2   R=2
 R=1 average average
 
 Step 1 Step 2 Step 2 StepGrupo 2
  R=2
 3 Step 1
 R=2
 average
 response
 Step 2 rate  R=2 response rate
 R=4
 Step 1 Step 3 response rate Step 3
 average Group 2  R=2
  
  R=2 response rate
 Step 1 Step 2  2R=2
 Step
 Group 3 R=2R=2  R=2 average
 Step 3 R = 4
 1 R=2 average
  R=2
 Step
  R=2 Step 2 response rate
 ...
 . . .. . .
 ...
 ...
 ...
 Step 1 Step 2 response rate
 . . .. . .
 . . . . . .. . .
 Step 3
 ...
 ...
 Group 3  R=5
  R=2
  R=5
 R = 4  R=2
 Group 3 Group 3  R=5
 ...
 average
 ...
 ...
 ...
 ...
  R=5 response rate
 Group 3  R=5
 average average
  R=5  R=5
 ...
 response rate response rate
  R=5  R=5
 Last purchase: Group 3 average  R=5
 320 days ago  R=5 average response rateGroup 3
 Last purchase: Grupo 5
 Last purchase:   R=5R=5 response rate  R=5 average
 compra menos
 320 days ago
 Last purchase:
 320 days ago
  R=5
  R=5 response rate
 Last purchase:  R=5
 reciente
 320 days 320
 agodays ago
 Last purchase:  R=5
 320 days ago

[pág. 14]
Paso 3: Construcción de Índice RFM
14
  Construimos índice RFM vía concatenación de
 códigos R, F, y M
  Orden es importante (R-F-M)
  555, 554, 553, etc.
  125 grupos
 Fuente: Linoff & Berry, 2011
  Asignamos clientes a cada uno de los grupos

[pág. 15]
Enfoques Alternativos de Construir Índice
 RFM
15
  Enfoque de N-tiles Secuenciales
  Creamos quintil para recencia
  Dentro de cada quintil creamos quintiles para
 frecuencia
  Dentro de cada grupo recencia-frecuencia creamos
 quintiles para monto
  Enfoque de agrupamiento intuitivo

[pág. 16]
❑ Enfoque de N-tiles secuenciales
 M
 F
 131
 11
 12 132
 R
 13 133
 1
 14 134
 135
 2 15
 41
 3 441
 42
 442
 43
 4 443
 44
 5 444
 45
 445
 Customer Sorted Once Sorted Five Sorted Twenty-Five
 Database Times per R Times per R Quintile
 Quintile
16
 Fuente: Kumar & Reinarz (2018), “Customer Relationship Management”

[pág. 17]
❑ Enfoque de agrupamiento intuitivo
 Única Compra Repite Compra
 Bajo $ Alto $ Bajo $ Alto $
 0-6 meses
 7-12 meses
 1-2 años
 2-3 años
 3+ años
17

[pág. 18]
Lab 2: RFM en Retailer Online
18
  125.000 transacciones de 6.886 clientes de un retailer online
  Mayo 2011 – Marzo 2015
  Datos:
  ID Cliente
  Monto de compra
  Fecha de compra
  Objetivo: Segmentar base de clientes usando segmentación RFM
  2 o 3 grupos por variable (simplicidad e interpretabilidad)

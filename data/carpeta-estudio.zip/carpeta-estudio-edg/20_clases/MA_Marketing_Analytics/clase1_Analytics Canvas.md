# Marketing Analytics · clase1_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 INTRODUCCIÓN
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Agenda
2
  Motivación del curso
  Ejemplos del uso de analytics en Marketing
  Temas administrativos
  Objetivos
  Evaluaciones
  Organización

[pág. 3]
2º curso de la
 secuencia de
 Marketing
3

[pág. 4]
Marketing Analytics vs. Fundamentos de
 Marketing
4
  FM introduce temas clave de Marketing
  ¿Qué entendemos por Marketing?
  Base en marcos conceptuales
  Metodología intensiva en uso de casos
  MA enfocado en uso de métodos analíticos y datos
 para apoyar toma de decisiones
  Orientación cuantitativa
  Uso de programas computacionales y datos

[pág. 5]
ejemplo marca
 modelo
 varianza
 base mapa
 analyt perfil
 dos
 texto grs publicidad tipo diseño venta total
 producto
 uso año predictiva
 fuent
 parcial
 dato pulsosamsung
 efecto
 promedio
 relación yes
 frecuencia
 peso lealtad preferencia
 factor
 predicción
 consumidor bass
 etc
 appl
 simpl
 estimación clave causal elección valor
 max matriz doc ideal tasa
 mayor conjunto ¿cómo light solución comportamiento
 𝑑𝑑𝑑𝑑
 celular
 market potenci
 palabra client término impacto
 período ¿cuál
 función vida
 número
 compra cluster desempeño
 regresión tiempo
 variabl punto medida precio analíticaresultado
 distancia utilidad
 probabilidad usando decisión
 análisi categoríamétodo nivel cada
 móvil
 basado
 fuga pago
 segmentación
 atributo servicio
 mercado penetración
 participación
5

[pág. 6]
Premisa Fundamental del Curso
6
 Métodos
 Analíticos Mejora en Toma
 de Decisiones
 +
 de Marketing
 Datos

[pág. 7]
Premisa Fundamental del Curso
7
 Métodos •
 •
 Segmentación
 Analíticos Mejora en Toma •
 Posicionamiento
 CRM
 de Decisiones • Diseño de
 + productos
 de Marketing • Precios
 • Promociones
 Datos • Publicidad

[pág. 8]
Premisa Fundamental del Curso
8
 Métodos •
 •
 Segmentación
 Analíticos Mejora en Toma •
 Posicionamiento
 CRM
 de Decisiones • Diseño de
 + productos
 de Marketing • Precios
 • Promociones
 Datos • Publicidad

[pág. 9]
Premisa Fundamental del Curso
9
 Métodos •
 •
 Segmentación
 Analíticos Mejora en Toma •
 Posicionamiento
 CRM
 de Decisiones • Diseño de
 + productos
 de Marketing • Precios
 • Promociones
 Datos • Publicidad

[pág. 10]
Premisa Fundamental del Curso
10
 Métodos •
 •
 Segmentación
 Analíticos Mejora en Toma •
 Posicionamiento
 CRM
 de Decisiones • Diseño de
 + productos
 de Marketing • Precios
 • Promociones
 Datos • Publicidad

[pág. 11]
Impacto del Uso de Analytics en
 Marketing
11
  Potencialmente importantes ganancias en performance
 (Pauwels, 2015)
  Mejora en experiencia de cliente y aumento en ROMI de
 hasta un 20% (Gordon & Perrey, 2015)
  Aumento en ingresos netos de $180 millones y 8% en ROA
 (Germann et al. 2013)
  Mejores resultados en empresas que enfrentan ambientes
 competitivos y necesitades del cliente cambiantes
  Aumento en probabilidad de éxito de nuevos productos

[pág. 12]
Creciente uso de herramientas analíticas y datos en
 empresas
12 Fuente: Christine Moorman, CMO Survey, Feb. 2022

[pág. 13]
Google Trends: Interés en Marketing
 Analytics
13

[pág. 14]
Tres Factores Han Permitido el Creciente
 uso de Analytics en Marketing
14
  Más y mejores datos
  Mayor capacidad de procesamiento
  Mejores técnicas

[pág. 15]
1. Disponemos de Mayor Volumen y Variedad de
Datos que se Generan a Velocidad creciente
 VOLUMEN Volumen medido en zettabytes
 Aumento x60 entre 2010 y 2023
 Proyección de fuerte crecimiento
 VARIEDAD Datos no estructurados
 Diversas fuentes
 3 V’S DE BIG
 Potencial de conocer al
 DATA
 cliente en mayor detalle
 VELOCIDAD 5,9 MM de búsquedas en Google x min
 500 hrs de video en Youtube x min
 347.200 tweets x min

[pág. 16]
Crecimiento Exponencial en Volumen de Datos
 1 zettabyte = 1.000
 millones de terabytes
 Fuente: Statista, 2021

[pág. 17]
Creciente Variedad de Datos
▪ Transacciones usando # de cliente frecuente
▪ Búsqueda en la web
▪ Respuesta a publicidad online
▪ Reseñas de productos, blogs, etc.
▪ Posteos en redes sociales
▪ Videos
▪ Información de geolocalización
▪ Etc.
 Conocimiento más profundo del consumidor

[pág. 18]
2. Mayor Capacidad de Procesamiento de
 Datos
18

[pág. 19]
3. Mejores Técnicas Analíticas
 ▪ Mayor volumen de datos y capacidad de
 procesamiento han impactado en métodos
 ▪ Mejores técnicas econométricas (Ej.
 heterogeneidad en sistemas de
 demanda)
 ▪ Métodos de Machine Learning (Ej. Deep
 Learning, bagging, boosting)
19

[pág. 20]
Ejemplo: Uso de Machine Learning en
 Predicción de Fuga
20
  Fines de 1990s – comienzos de 2000
  Éxito de ML en predicción de fuga limitado
  Modelos de regresión muestran mejor desempeño
  Torneo de data science de Teradata Center de Duke en 2004 para
 predecir fuga
  Ganador usó modelo de regresión logística
  Hacia 2016 modelos de ML ya dominaban en predicción de fuga
  Modelos de Deep Learning basados en Redes Neuronales, RF
  Mayor volumen de datos y capacidad de procesamiento condujo a
 mejores métodos (bagging, boosting, deep learning, etc.)

[pág. 21]
21
 Ejemplos de Uso de Analytics en Marketing

[pág. 22]
Direccionamiento de Cupones en Kroger
22
  Usa analítica para entender al
 consumidor: ¿Hogares con hijos?
 ¿Compras orientadas a lo saludable
 / entretención? etc.
  Uso limitado de variables
 demográficas
  Tasa de canje de cupones vía email
 70% (promedio 7.93%)

[pág. 23]
Diseño de Nuevos Productos en Marriott
23
  Diseño óptimo de nueva
 cadena hotelera
  Uso de “análisis conjunto”
  Estimación de preferencias
 por atributos
  Optimización de
 participación de mercado

[pág. 24]
Determinación de Precios en Amazon
24
  Plataforma de experimentación
 de precios “Pricing Labs”
  Testeo de nuevas políticas de
 precio
  Randomización a nivel de
 producto (no discriminación)
  Cambios en algoritmo de ML
 que asigna precios a grupos
 de productos

[pág. 25]
Amazon Pricing Labs
25

[pág. 26]
Sistema de Recomendaciones en Netflix
26
  Personalización de
 recomendaciones desde
 2000
  “Netflix prize” – 2006
  80% del tiempo de
 streaming asociado a
 personalización de
 recomendaciones

[pág. 27]
Aplicaciones al Retail en Chile:
 Efectividad de Promociones de Precio
27

[pág. 28]
Evaluación de Estrategia Promocional en
 Importante Cadena de Retail
28
  Colaboración académica con una importante cadena
 de supermercados en Chile
  Top 3 a nivel nacional
  Diversos formatos
  Reevaluación de la estrategia promocional
  ¿Cuál es el impacto dinámico de una promoción?
  Consumidores expuestos a descuentos más profundos,
 ¿Responden más o menos a una promoción subsecuente?

[pág. 29]
Midiendo la Efectividad Promocional vía
 Experimentación
29
  Experimento varió profundidad promocional
 aleatoriamente entre tiendas similares
  Fase de intervención: T (30%); C (10%)
  Fase de medición: T (10%); C (10%)
  170 productos, 17 categorías, 10 tiendas

[pág. 30]
Descuentos en Tiendas Tratadas y
 Control
30

[pág. 31]
31

[pág. 32]
¿Qué Aprendimos del Experimento?
32
  Inercia en respuesta a promociones
  Clientes expuestos a una mayor profundidad
 promocional:
  Presentan una probabilidad 22.5% mayor de comprar
 productos en promoción subsecuente
  La proporción de productos promocionados en canasta
 de compra aumenta un 16.6%

[pág. 33]
Aplicaciones al Retail en Chile:
 Impacto de Información Nutricional
33

[pág. 34]
Impacto de Sellos “Alto En” sobre
 Comportamiento de Compra
34
  ¿Cómo responde el
 consumidor a sellos de
 advertencia nutricional?
  ¿Reduce sus compras de
 productos “Alto En”?
  ¿Depende de la
 categoría? ¿Factores
 demográficos?

[pág. 35]
Implementación de Nuevas Regulaciones
35
  Nuevas regulaciones entraron en vigencia en junio de 2016
  Implementación gradual en tiendas de supermercados
  Proveedores comenzaron entregando productos etiquetados
 varios meses previo a la fecha límite
  Observamos un mismo producto con y sin etiqueta en
 distintas tiendas
  Oportunidad de aprender sobre el comportamiento del
 consumidor en relación a información nutricional

[pág. 36]
Datos
36
  Presencia de sellos de un SKU en un día y tienda
 dados
  6 tiendas de supermercado
  3 categorías
  Período de 3 meses alrededor de la fecha límite
  Datos transaccionales a nivel de cliente (club de
 fidelización)

[pág. 37]
Evolución del Etiquetado
37

[pág. 38]
Análisis Econométrico
38
 • Relación entre sellos y compra de productos (nivel SKU):
 • Análisis a nivel de hogares:

[pág. 39]
¿Qué Aprendimos del Análisis?
39
  Cereales
  Volumen cae 6,2 p.p. cuando el producto está etiquetado
 (~reducción de 1-2 unidades del producto por tienda/día)
  Chocolates – Galletas
  Efectos no significativos
  Mayores efectos en familias con hijos pequeños e
 ingresos medios-bajos

[pág. 40]
Heterogeneidad en Impacto de Sellos en
 Demanda (Cereales)
40

[pág. 41]
41 TEMAS ADMINISTRATIVOS

[pág. 42]
Objetivos del Curso
42
 1. Reconocer importancia del uso de datos, modelos y métodos
 cuantitativos en Marketing
 2. Distinguir modelos más importantes utilizados para apoyar las
 decisiones clave de Marketing
 3. Aplicar modelos de marketing a toma de decisiones
 4. Utilizar software econométrico/estadístico a la solución de
 problemas de marketing
 5. Analizar problemas de Marketing e identificar el instrumental
 analítico más apropiado para resolverlos

[pág. 43]
Requisitos
43
  Conceptos de marketing intermedio
  Fundamentos de Marketing (EAA2310)
  Conocimientos previos de estadística y econometría
  Econometría I (EAE2510)
  Familiaridad con software estadístico/econométrico
  Python / R

[pág. 44]
Implementación Computacional
 ❑ Lenguaje de programación especializado en estadística y ML
 ▪ Standard en analítica de negocios y ciencia de datos (junto con Python)
 ▪ Código abierto y gratis
 ▪ Útil en todas las etapas del análisis
 ➢ Preparación y limpieza de datos
 ➢ Estimación / entrenamiento de modelos
 ➢ Predicción y evaluación de modelos
44

[pág. 45]
Algunos Textos de Consulta
45
  “Marketing Analytics Based on First Principles”, Palmatier,
 Petersen & Germann, 2022.
  “Applied Marketing Analytics Using R” Yildirim & Kübler, Sage,
 2023.
  “R for Marketing Research and Analytics”, Chapman and
 McDonnell Feit, 2nd Edition, 2019, Springer.
  “Principles of Marketing Engineering and Analytics”, Lilien,
 Rangaswamy & De Bruyn, 3rd ed., 2018
  “Modern Business Analytics”, Taddy, Hendrix, Harding, 2022.

[pág. 46]
Tipo de Evaluación Ponderación (%)
 Tareas* (3) 20
 Controles y Casos** (3) 20
 Pruebas*** (2) 40
 Examen 20
 (*): Grupales (máximo 3 alumno/as)
46 (**): Individuales

[pág. 47]
Requisitos para Rendir Examen
47
  Haber sido evaluado en al menos un 50% de la ponderación total
 del curso (excluyendo ponderación de examen) (i.e., 40%)
  El alumno que por no cumplir requisitos no pueda rendir el examen
 y tenga nota de presentación inferior a 4,0, se le mantendrá la nota
 de presentación como calificación final del curso.
  Si, por el contrario, el alumno tiene una nota de presentación igual o
 mayor a 4,0 y no pueda rendir el examen por no cumplir con los
 requisitos indicados en el programa de curso, será calificado con
 una nota final en el curso de 3,9.
  No hay eximición

[pág. 48]
Fechas de Evaluaciones
48
  Prueba 1
  Jueves 3 de octubre
 ◼ 17:30-19:30 hrs.
  Prueba 2
  Viernes 8 de noviembre
 ◼ 17:30-19:30 hrs.
  Examen
  Miércoles 11 de diciembre
 ◼ 8:20-10:20 hrs.

[pág. 49]
Calendario de Tareas (tentativo)
49
 Tarea Tópico Fecha Post Fecha Entrega
 1 Analítica Exploratoria 8-Ago 16-Ago
 2 Posicionamiento 29-Ago 6-Sep
 3 Elección de Marca 22-Oct 30-Oct

[pág. 50]
Organización del Curso
50
 • Identificando el Mercado Objetivo: 5Cs • Siete tácticas de marketing: 7Ts
 Chernev & Kotler, “Kellogg on Marketing”, 2023

[pág. 51]
Organización del Curso: Parte I
51
  Parte I: Introducción + Decisiones Estratégicas
  Introducción a Marketing Analytics
 ◼ Tipos de analítica, datos en marketing analytics
  Herramientas de Apoyo a Decisiones Estratégicas
 ◼ Segmentación – Targeting - Posicionamiento
  Análisis de Segmentación
 ◼ División de clientes en grupos homogéneos
 ◼ Técnica estadística: Análisis de Clusters

[pág. 52]
Organización del Curso: Parte I
52
  Parte I (continuación)
  Análisis de Posicionamiento
 ◼ Mapas perceptuales/preferencias
 ◼ Estructura de mercado y análisis competitivo
 ◼ Herramientas analíticas: Análisis de Factores, Escalamiento
 Multidimensional

[pág. 53]
Organización del Curso: Parte II
53
  Parte II: Analítica de Clientes
  Exploración de base de clientes
  Valor Económico del Cliente: CLV
 ◼ Modelos probabilísticos
  Predicción de fuga y respuesta a campañas
 ◼ Regresión logística
 ◼ Machine learning: Árboles de decisión, Random Forests
 ◼ Modelos de uplift
 ◼ Análisis de canasta de compra

[pág. 54]
Organización del Curso: Parte II
54
  Parte II: Analítica de Clientes (cont.)
  Escuchando la voz del cliente: Text analytics
 ◼ Modelo bolsa de palabras, análisis de sentimientos, topic
 modeling
  Modelos de Elección de Marca
 ◼ Preferencias por atributos y estimación de probabilidad de
 compra
 ◼ Modelo Multinomial Logit

[pág. 55]
Organización del Curso: Parte III
55
  Parte III: Modelos para Decisiones Tácticas
  Modelos para decisiones de producto
 ◼ Difusión de innovaciones
 ◼ Estimación de potencial de mercado
 ◼ Modelo de Bass y extensiones
 ◼ Diseño de nuevos productos
 ◼ Análisis Conjunto

[pág. 56]
Organización del Curso: Parte III
56
  Parte III: Modelos para Decisiones Tácticas (cont.)
  Modelos para decisiones de precio
 ◼ Estimación de disposición a pagar
 ◼ Precios óptimos
  Modelos de marketing mix y uso de experimentos
 ◼ Uso y limitaciones de modelos del marketing mix
 ◼ Medición de efectividad de acciones de marketing usando
 tests A/B

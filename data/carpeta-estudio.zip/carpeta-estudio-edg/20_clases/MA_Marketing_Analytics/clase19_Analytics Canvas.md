# Marketing Analytics · clase19_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 PREDICCIÓN DE RESPUESTA:
 ÁRBOLES DE DECISIÓN
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Clase Anterior: Modelo de Regresión
 Logística
2
  Uso de modelo logístico en predicción de respuesta
 𝑒𝑣
 𝑃 𝑦=1𝑥 =
 1 + 𝑒𝑣 𝑒 (𝛽0 +𝛽1 ∙𝑥)
 𝑃 𝑦=1𝑥 =
 1 + 𝑒 (𝛽0 +𝛽1 ∙𝑥)
 𝑣 = 𝛽0 + 𝛽1 ∙ 𝑥

[pág. 3]
Interpretación usando Log Odds
3
  Reformulación del modelo usando log-odds:
 𝑝
 𝑙𝑜𝑔 = 𝛽0 + 𝛽1 𝑥 , 𝑝≡𝑃 𝑦=1𝑥
 1−𝑝
 Efecto de incremento unitario en 𝑥:
 Δ% 𝑒𝑛 𝑂𝑅 = 𝑒𝑥𝑝 𝛽1 − 1

[pág. 4]
4
 PREDICCIÓN DE RESPUESTA: MODELOS DE ML

[pág. 5]
¿QUÉ ENTENDEMOS POR MACHINE LEARNING?
 Inteligencia Artificial AI simbólica o clásica
 ▪ ML es parte del campo de la AI
 (McCarthy, 1956)
 ▪ AI: “Esfuerzo por automatizar
 tareas intelectuales normalmente
 desempeñadas por humanos” Machine Learning
 ▪ AI simbólica: Reglas
 codificadas directamente por
 humanos (Ej. if-else)
 ▪ ML: Máquina es capaz de
 reconocer patrones a partir de
 instancias /ejemplos
5

[pág. 6]
IDEA DE ALGORITMOS DE MACHINE LEARNING
▪ Algoritmo de ML es “entrenado”: Aprende a partir de ejemplos
▪ Algoritmo recibe múltiples ejemplos de una tarea
 Ej. Respuestas de clientes con distintas características
▪ Algoritmo no es “alimentado” con forma funcional
 (a diferencia de modelos estadísticos tradicionales)
▪ Algoritmo encuentra estructura estadística que le permite identificar
 reglas que relacionan features y target
 • Relación input-output desconocida a-priori

[pág. 7]
CLASES DE ML IMPORTANTES EN ANALÍTICA DE
 NEGOCIOS
7
 ❑Aprendizaje No Supervisado
 ▪ Ejemplos no incluyen valor de target (“no etiquetados”)
 ▪ Algoritmo agrupa observaciones similares
 ▪ Análisis de clusters en segmentación
 ❑ Aprendizaje Supervisado
 ▪ Ejemplos si incluyen valor de variable a predecir (“etiquetados”)
 ▪ Algoritmo busca predecir target
 ▪ Recompensa/penalización por acercarse al target
 ▪ Analítica predictiva

[pág. 8]
MODELOS DE MACHINE LEARNING
APRENDIZAJE SUPERVISADO
 ▪ Redes Neuronales Artificiales
 Deep Learning
 ▪ Árboles de Decisión
 Random Forests
 Boosting
 ▪ Support Vector Machines

[pág. 9]
Árboles de Decisión
 Ejemplo Simple
9
  CMO de empresa de telefonía interesada en
 predecir fuga
  Features:
  Probabilidad de recomendar (usada en Net Promoter
 Score). Escala 0 -10
  Tenure: Tiempo en cargo de agente de call center
 (meses)

[pág. 10]
CMO INTUYE QUE FUGA PUEDE ESTAR
 RELACIONADA CON PROB. DE RECOMENDAR
10
 Toma valores 0-10

[pág. 11]
EXPLORACIÓN DE DATOS
11
 ¿Qué % de los clientes decide terminar su relación con la empresa?

[pág. 12]
AJUSTE USANDO ÁRBOLES DE DECISIÓN
▪ Modelos no paramétricos
▪ Conjunto de reglas que dividen
 muestra (clientes) en grupos
 homogéneos respecto a target
▪ Metodología dominante: CART
 (“classification and regression
 trees”)

[pág. 13]
Estructura de Árbol de Decisión
13
 • Cada nodo excepto
 hojas tiene dos hijos
 • Cada nodo excepto raíz
 tiene un padre
 • Clientes divididos en
 Predicción: promedio de 𝑦 en cada hoja 4 grupos

[pág. 14]
Procedimiento de Partición
14
  Algoritmo comienza en nodo raíz incluyendo todas las
 instancias (clientes)
  Decide división (binaria) en base a
  Feature (𝑥)
  Umbral (valor de 𝑥)
  ¿Cómo determina qué feature y umbral usar?
  Maximizando ganancias de información
  Concepto de “Entropía”

[pág. 15]
Concepto de Entropía
15
 • La entropía de una variable aleatoria discreta 𝑋 se define como:
 𝑛
 𝐻 𝑋 = − ෍ 𝑝(𝑥𝑖 ) ∙ 𝑙𝑜𝑔2 (𝑝 𝑥𝑖 )
 𝑖=1
 donde Pr{𝑋 = 𝑥𝑖 } = 𝑝(𝑥𝑖 )
 Entropía medida en bits
 Medida de incertidumbre de un sistema

[pág. 16]
Entropía de Variable Bernoulli
16
  Nos interesa calcular la entropía de una variable que puede
 tomar sólo dos valores
 𝐻 𝑋 = − 𝑝 ∙ 𝑙𝑜𝑔2 𝑝 + 1 − 𝑝 ∙ 𝑙𝑜𝑔2 (1 − 𝑝)

[pág. 17]
Entropía de Variable Bernoulli: Ejemplo
17
  Supongamos que 𝑋 es el resultado de lanzar una
 moneda (no cargada)
 𝐻 𝑋 = − 𝑝 ∙ 𝑙𝑜𝑔2 𝑝 + 1 − 𝑝 ∙ 𝑙𝑜𝑔2 (1 − 𝑝)

[pág. 18]
Entropía de Variable Bernoulli: Ejemplo
18
  Supongamos que 𝑋 es el resultado de lanzar una
 moneda (cargada con Pr 𝑋 = “𝐶𝑎𝑟𝑎” = 0.9)
 𝐻 𝑋 = − 𝑝 ∙ 𝑙𝑜𝑔2 𝑝 + 1 − 𝑝 ∙ 𝑙𝑜𝑔2 (1 − 𝑝)

[pág. 19]
19
 𝐸𝑛𝑡𝑟𝑜𝑝í𝑎
 0.2
 0.4
 0.6
 1
 0
 0.01 0.8
 0.05
 0.09
 0.13
 0.17
 0.21
 0.25
 0.29
 0.33
 0.37
 0.41
 0.45
 0.49
𝑝 0.53
 0.57
 0.61
 0.65
 0.69
 0.73
 0.77
 0.81
 0.85
 0.89
 0.93
 0.97
 Entropía vs. Probabilidad de Éxito

[pág. 20]
Entropía vs. Probabilidad de Éxito
 20
 1
 0.8
 𝐸𝑛𝑡𝑟𝑜𝑝í𝑎
 0.6
 0.4
 Entropía igual a
Entropía igual a cero
 cero 0.2
 No existe
 No existe 0
 incertidumbre
 0.13
 0.45
 0.73
 0.01
 0.05
 0.09
 0.17
 0.21
 0.25
 0.29
 0.33
 0.37
 0.41
 0.49
 0.53
 0.57
 0.61
 0.65
 0.69
 0.77
 0.81
 0.85
 0.89
 0.93
 0.97
 incertidumbre
 𝑝

[pág. 21]
Entropía vs. Probabilidad de Éxito
 21
 1 Entropía máxima
 Máxima
 0.8
 incertidumbre
 𝐸𝑛𝑡𝑟𝑜𝑝í𝑎
 0.6
 0.4
 Entropía igual a
Entropía igual a cero
 cero 0.2
 No existe
 No existe 0
 incertidumbre
 0.13
 0.45
 0.73
 0.01
 0.05
 0.09
 0.17
 0.21
 0.25
 0.29
 0.33
 0.37
 0.41
 0.49
 0.53
 0.57
 0.61
 0.65
 0.69
 0.77
 0.81
 0.85
 0.89
 0.93
 0.97
 incertidumbre
 𝑝

[pág. 22]
EJEMPLO: SELECCIÓN DE UMBRAL
OBJETIVO: REDUCCIÓN DE INCERTIDUMBRE
▪ Supongamos que existe un único feature: EDAD
▪ Dos particiones posibles: 35 años o 65 años
▪ Composición de la muestra:
 Clientes # Clientes # Churn # No Churn
 Todos 1000 500 500
 ≤ 35 500 165 335
 35- 65 200 170 30
 ≥ 65 300 165 135

[pág. 23]
EJEMPLO: SELECCIÓN DE UMBRAL
OBJETIVO: REDUCCIÓN DE INCERTIDUMBRE
▪ En el nodo raíz: 𝑝 = 0.5
▪ Entropía inicial:
 𝐻𝑅𝑜𝑜𝑡 = − 0.5 ∙ 𝑙𝑜𝑔2 0.5 + 1 − 0.5 ∙ 𝑙𝑜𝑔2 (1 − 0.5)
 𝐻𝑅𝑜𝑜𝑡 = 1

[pág. 24]
EJEMPLO: SELECCIÓN DE UMBRAL
OBJETIVO: REDUCCIÓN DE INCERTIDUMBRE
▪ Dos posibles particiones: Umbral en 35 años o 65 años
 Nodo Raíz
 𝐸𝑑𝑎𝑑 > 𝑢𝑚𝑏𝑟𝑎𝑙 𝐸𝑑𝑎𝑑 ≤ 𝑢𝑚𝑏𝑟𝑎𝑙
 Nodo 1 Nodo 2

[pág. 25]
Entropía cuando Umbral es 35 años
25
 Clientes # Clientes # Churn # No Churn
 Todos 1000 500 500
 165
Nodo 1 ≤ 35 500 165 335 𝑝= = 0.33
 500
Nodo 2 35- 65 200 170 30 335
 𝑝= = 0.67
 ≥ 65 300 165 135 500

[pág. 26]
Entropía cuando Umbral es 35 años
26
 𝐻𝑁𝑜𝑑𝑜1 = 0.33 ∙ 𝑙𝑜𝑔2 0.33 + 0.67 ∙ 𝑙𝑜𝑔2 (0.67)
 𝐻𝑃𝑎𝑟𝑡𝑖𝑐𝑖ó𝑛 = 0.5 ∙ 𝐻𝑁𝑜𝑑𝑜1 + 0.5 ∙ 𝐻𝑁𝑜𝑑𝑜2

[pág. 27]
Entropía cuando Umbral es 35 años
27
 Reducción de
 𝐻𝑅𝑜𝑜𝑡 − 𝐻𝑃𝑎𝑟𝑡𝑖𝑐𝑖ó𝑛 = 1 − 0.91 = 0.09
 incertidumbre:

[pág. 28]
▪ Umbral en 35 años
 Nodo Raíz
 𝐸𝑑𝑎𝑑 > 35 𝐸𝑑𝑎𝑑 ≤ 35
𝐻𝑁𝑜𝑑𝑜1 = 0.91 Nodo 1 Nodo 2 𝐻𝑁𝑜𝑑𝑜2 = 0.91
 𝐻𝑃𝑎𝑟𝑡𝑖𝑐𝑖ó𝑛 = 0.91
 𝐺𝑎𝑛𝑎𝑛𝑐𝑖𝑎 𝑑𝑒 𝐼𝑛𝑓𝑜𝑟𝑚𝑎𝑐𝑖ó𝑛 = 0.09

[pág. 29]
Entropía cuando Umbral es 65 años
29
 Clientes # Clientes # Churn # No Churn
 Todos 1000 500 500
 335
Nodo 1 ≤ 35 500 165 335 𝑝= = 0.48
 700
 35- 65 200 170 30
 165
Nodo 2 ≥ 65 300 165 135 𝑝= = 0.55
 300

[pág. 30]
Entropía cuando Umbral es 65 años
30
 Nodo 1 Nodo 2
 > 65 años ≤65 años
 % de Clientes 0.3 0.7
 𝑝 0.55 0.48
 1−𝑝 0.45 0.52
 𝐻𝑁𝑜𝑑𝑜 0.9928 0.9988
 𝐻𝑃𝑎𝑟𝑡𝑖𝑐𝑖ó𝑛 0.99
 𝐻𝑁𝑜𝑑𝑜1 = 0.55 ∙ 𝑙𝑜𝑔2 0.55 + 0.45 ∙ 𝑙𝑜𝑔2 (0.45) 𝐻𝑁𝑜𝑑𝑜2 = 0.48 ∙ 𝑙𝑜𝑔2 0.48 + 0.52 ∙ 𝑙𝑜𝑔2 (0.52)

[pág. 31]
Entropía cuando Umbral es 65 años
31
 Nodo 1 Nodo 2
 > 65 años ≤65 años
 % de Clientes 0.3 0.7
 𝑝 0.55 0.48
 1−𝑝 0.45 0.52
 𝐻𝑁𝑜𝑑𝑜 0.9928 0.9988
 𝐻𝑃𝑎𝑟𝑡𝑖𝑐𝑖ó𝑛 0.99
 𝐻𝑃𝑎𝑟𝑡𝑖𝑐𝑖ó𝑛 = 0.3 ∙ 𝐻𝑁𝑜𝑑𝑜1 + 0.7 ∙ 𝐻𝑁𝑜𝑑𝑜2

[pág. 32]
Entropía cuando Umbral es 65 años
32
 Nodo 1 Nodo 2
 > 65 años ≤65 años
 % de Clientes 0.3 0.7
 𝑝 0.55 0.48
 1−𝑝 0.45 0.52
 𝐻𝑁𝑜𝑑𝑜 0.9928 0.9988
 𝐻𝑃𝑎𝑟𝑡𝑖𝑐𝑖ó𝑛 0.99
 Reducción de
 𝐻𝑅𝑜𝑜𝑡 − 𝐻𝑃𝑎𝑟𝑡𝑖𝑐𝑖ó𝑛 = 1 − 0.99 = 0.01
 incertidumbre:

[pág. 33]
▪ Umbral en 65 años
 Nodo Raíz
 𝐸𝑑𝑎𝑑 > 65 𝐸𝑑𝑎𝑑 ≤ 65
𝐻𝑁𝑜𝑑𝑜1 = 0.99 Nodo 1 Nodo 2 𝐻𝑁𝑜𝑑𝑜2 = 0.99
 𝐻𝑃𝑎𝑟𝑡𝑖𝑐𝑖ó𝑛 = 0.99
 𝐺𝑎𝑛𝑎𝑛𝑐𝑖𝑎 𝑑𝑒 𝐼𝑛𝑓𝑜𝑟𝑚𝑎𝑐𝑖ó𝑛 = 0.01

[pág. 34]
¿Cómo definimos Profundidad del Árbol?
 Reglas de Detención
34
  Necesario especificar cuándo dejar de dividir
 nodos
  Alternativas
  Mínimo # de observaciones en nodo hijo
  Mínimo # de observaciones en nodo hoja
  Mínima reducción de incertidumbre

[pág. 35]
ALGORITMO RECURSIVO
❑ Para cada nodo, comenzando en el nodo raíz:
 1. Determinamos aquella división que maximiza “ganancia de
 información” entre nodos hijo
 2. Dividimos nodo entre nodos hijo a izquierda y derecha
 3. Repetimos pasos 1. y 2. para cada nodo
 Algoritmo se detiene cuando se satisfacen condiciones de retención
 Árbol entrega probabilidad de clase en los nodos terminales (hojas)

[pág. 36]
Implementación en R
36
 fórmula clasificación
 Nota: Reglas de detención (por default):
 • Mínimo número de observaciones en nodo = 20
 • Ajuste (reducción de incertidumbre) superior a 0,01 (cp)

[pág. 37]
Descripción de Nodos
37

[pág. 38]
library(rpart.plot)
 rpart.plot(churn_tree, box.palette = "RdBu", shadow.col = "gray", nn = TRUE)
 1
 0
 0.36
 100%
 2
 yes tenure >= 11 no 3 Predicción si hoja
 0 1
 0.10 0.90 % de “1s”
 68% 32%
 % de clientes
 ptr >= 4 ptr >= 5
 5 6
 1 0
 0.68 0.42
 5% 4%
 tenure >= 15 tenure >= 8
 4 10 11 12 13 7
 0 0 1 0 1 1
 0.05 0.08 0.78 0.31 0.95 0.97
 62% 1% 4% 3% 1% 29%
38

[pág. 39]
Árboles de Decisión: Pros y Cons
39
  Fortalezas
  Intuitivos
  Altamente flexibles (capaces de ajustar relaciones no
 lineales incluyendo interacciones)
  Debilidades
  Alta varianza (tendencia a “overfit”)
  Computacionalmente costosos

[pág. 40]
Potenciales Soluciones
40
  Métodos de Ensamble (“Ensemble Methods”)
  Ej. Random Forests, Boosting (e.g., XGBoost)
  Idea básica:
  Ajustar modelo a muchos sets de datos distintos (más
 simples que original)
  Combinar predicciones de cada uno de los modelos

[pág. 41]
RANDOM FORESTS
 MÉTODO DE ENSAMBLE BASADO EN DOS IDEAS BÁSICAS
 ❑ “BAGGING” (bootstrap aggregating)
 ▪ Obtenemos muchos sets de datos vía bootstrapping
 ▪ Ajustamos un árbol de decisión a cada set de datos
 ▪ Combinamos las predicciones de los árboles (vía voto por mayoría)
 ❑ SELECCIÓN ALEATORIA DE FEATURES
 ▪ Cada árbol utiliza sólo un subconjunto de features
 ▪ Contribuye a que modelos individuales sean independientes entre
 sí (reduciendo varianza de predicciones)
 ▪ Reducción de costos computacionales
41

[pág. 42]
Idea de “Bootstrapping”
42
 Fuente: https://towardsdatascience.com/ensemble-methods-bagging-boosting-and-stacking-c9214a10a205

[pág. 43]
MÉTODOS BASADOS EN ÁRBOLES
 RESUMEN
43
  Árboles de decisión altamente flexibles e intuitivos
  Sin embargo, son inestables; presentan alta variabilidad y
 tendencia al sobreajuste
  Métodos de ensamble (Random Forests, Boosting) permiten
  Reducir varianza
  Conseguir mejores predicciones fuera de muestra
  En años recientes han mostrado mejor desempeño que
 algoritmos basados en ANN en predicción de datos
 estructurados (organizados tabularmente)

[pág. 44]
USO DE MODELACIÓN PREDICTIVA EN FUGA
❑ Supongamos que clientes renuevan contrato cada 12 meses
❑ Nos interesa anticipar esa fuga cuando cliente lleva (ej.) 6 meses
❑ Usamos datos de clientes que completaron ciclo de 12 meses
 ▪ Observamos su decisión de fuga a los 12 meses
 ▪ Observamos sus características (uso del servicio, respuesta a ofertas,
 interacciones con servicio al cliente, variables sociodemográficas)
 durante primeros 6 meses

[pág. 45]
USO DE MODELACIÓN PREDICTIVA EN FUGA (2)
❑ Estimamos (o entrenamos) el modelo usando datos de clientes que
 completaron un ciclo de 12 meses
 ▪ Predictores observados durante primeros 6 meses
 ▪ Respuesta: Decisión de fuga en el mes 12
❑ Problema: Para saber si el modelo predice bien necesitamos
 probarlo en “nueva data”
 No es posible esperar a que se genere “nueva data” (demasiado tarde)

[pág. 46]
USO DE MODELACIÓN PREDICTIVA EN FUGA (3)
❑ Solución: Partición aleatoria de datos históricos
 ▪ Muestra de entrenamiento (training) usada en estimación
 ▪ Muestra de validación (testing) usada en evaluación
❑ Si modelo predice con precisión, lo aplicamos a datos de clientes
 que llevan 6 meses para estimar su probabilidad de fuga y dirigir
 programas

[pág. 47]
USO DE MODELACIÓN PREDICTIVA EN FUGA
 CLIENTES OBSERVADOS POR 12 MESES CLIENTES QUE LLEVAN 6 MESES
 Variables predictivas: Variables predictivas:
 - Usos - Usos
 - Respuestas - Respuestas
 - Interacciones con call center - Interacciones con call center
 - Variables sociodemográficas - Variables sociodemográficas
 Resultado: Churn o No Churn Resultado Desconocido
 Estimación de Modelo Si modelo predice bien
 Predicción Predicción
 de Churn de Churn
 Training Sample Testing Sample Fuente: Adaptado de Anderson & Zettelmeyer (2021)

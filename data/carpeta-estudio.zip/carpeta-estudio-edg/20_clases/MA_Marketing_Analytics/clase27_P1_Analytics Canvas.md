# Marketing Analytics · clase27_P1_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 MODELO LOGIT MULTINOMIAL:
 SIMULACIÓN Y LIMITACIONES
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Clase Anterior
2
  Bondad de ajuste en modelo logit multinomial
  Pseudo R-cuadrado (McFadden)
 𝐿𝐿 መ
 𝛽
 𝜌2 = 1 −
 𝐿𝐿 0

[pág. 3]
Clase Anterior
3
  Efectos parciales y elasticidades
 𝐸𝑁,𝑝𝑟𝑒𝑐𝑖𝑜𝑁 = 𝛽𝑝 𝑝𝑟𝑒𝑐𝑖𝑜𝑁 (1 − 𝑃𝑁 )
 𝐸𝑁,𝑝𝑟𝑒𝑐𝑖𝑜𝑆 = −𝛽𝑝 𝑃𝑆 𝑝𝑟𝑒𝑐𝑖𝑜𝑆

[pág. 4]
Matriz de Elasticidades: Caso Crackers
4

[pág. 5]
Plan para Hoy
5
  Simulación de escenarios contrafactuales
  ¿Cómo cambia la participación de mi marca si llevo a
 cabo acción de marketing?
  Limitaciones del modelo

[pág. 6]
Simulación de Escenarios usando Modelo
 Logit Multinomial
6
  Una vez estimados los parámetros del modelo
 podemos estudiar el efecto de políticas de
 marketing alternativas
  Comparación de participaciones de cada marca en
 escenario base (ej. sin promoción) vs. escenario
 alternativo (ej. con promoción)

[pág. 7]
Simulación de Escenarios: Caso Crackers
7
  4 marcas de crackers
  Nabisco, Keebler, Sunshine, Marca Propia
  Probabilidad de elección de marca 𝑗:
 𝑒 (𝛽𝑗 +𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑗𝑡+𝛽𝑓 𝐹𝑒𝑎𝑡𝑗𝑡+𝛽𝑑 𝐷𝑖𝑠𝑝𝑗𝑡)
 𝑃𝑖𝑗𝑡 =
 σ𝐽𝑘=1 𝑒 (𝛽𝑘 +𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑘𝑡+𝛽𝑓 𝐹𝑒𝑎𝑡𝑘𝑡 +𝛽𝑑 𝐷𝑖𝑠𝑝𝑘𝑡 )

[pág. 8]
Parámetros Estimados
8

[pág. 9]
Simulación de Escenarios: Exhibición
 Especial de Nabisco
9
  Product Manager de Nabisco tiene la opción de hacer
 una exhibición especial de su marca de crackers en un
 supermercado durante un cierto período de tiempo
  Propuesta
  Costo de intervención: $750
  # de compras esperadas en categoría: 100.000
  ¿Debería el Product Manager aceptar la propuesta si el
 margen de contribución de Nabisco es de $0.5?

[pág. 10]
Escenario Base
10
  Asumimos que en el escenario base los precios de cada
 marca son los precios promedio del período
  Precio_Nabisco = $1.09
  Precio_Keebler = $1.13
  Precio_Sunshine = $0.96
  Precio_Private = $0.68
  Ninguna marca hace exhibiciones especiales ni publicidad
 destacada
  ¿Participaciones predichas por el modelo?

[pág. 11]
11

[pág. 12]
𝛽መ𝐾𝑒𝑒𝑏𝑙𝑒𝑟
 𝛽መ𝑁𝑎𝑏𝑖𝑠𝑐𝑜
 𝛽መ𝑆𝑢𝑛𝑠ℎ𝑖𝑛𝑒
 𝛽መ𝑝𝑟𝑖𝑐𝑒
 𝛽መ𝑓𝑒𝑎𝑡
 𝛽መ𝑑𝑖𝑠𝑝
12

[pág. 13]
Escenario Alternativo
13
  En el escenario alternativo el único cambio es que
 Nabisco hace una exhibición especial (𝐷𝑖𝑠𝑝𝑁 = 1)
  Nueva matriz de datos (𝑋):

[pág. 14]
IIA implica que caída en participación es proporcional a
 participaciones iniciales (Keebler, Private y Sunshine)
14

[pág. 15]
¿Debe el Product Manager Aceptar la
 Propuesta?
15
  ¿Cuáles son las ganancias incrementales de la
 intervención?

[pág. 16]
Impacto de Acciones de Marketing y
 Exogeneidad
16
  Análisis anterior descansa e un supuesto clave del
 modelo
 𝑢𝑗𝑡 = 𝑣𝑗𝑡 + 𝜀𝑗𝑡
 SD.1: 𝜀𝑗𝑡 y 𝑣𝑗𝑡 son ortogonales
  ¿Cuándo podría no cumplirse?
  Ej. precios responden a características no observables
  Más complejo de resolver que en modelo lineal

[pág. 17]
Ventajas de Logit
17
  Incorpora variables de decisión
  Entrega fórmula cerrada de probabilidad de
 elección
  Simple de estimar
  Micro fundado: Basado en modelación de toma de
 decisiones de individuos racionales
  Permite análisis contrafactual

[pág. 18]
Potenciales Limitaciones de Logit
18
  Patrones de sustitución poco flexibles
  Propiedad IIA
  No incorpora heterogeneidad (no observable) en
 preferencias
  Modelo compensatorio
  Utilidad es aditiva en atributos

[pág. 19]
Limitaciones del Modelo Logit
 Patrones de Sustitución Potencialmente Restrictivos
19
  Propiedad de Independencia de Alternativas Irrelevantes (IIA)
  Ratio de probabilidades de elección no depende de atributos
 de otras alternativas
 𝐽
 𝑃𝑗 exp 𝑣𝑗 / σ𝑘=1 exp(𝑣𝑘 )
 =
 𝑃𝑙 exp(𝑣𝑙 )/ σ𝐽 exp(𝑣𝑘 )
 𝑘=1

[pág. 20]
Independencia de Alternativas Irrelevantes
20
  Lo anterior implica sustitución proporcional entre
 alternativas
  Equivalentemente, elasticidades cruzadas son
 idénticas entre marcas
  Puede ser poco realista en ciertos contextos

[pág. 21]
IIA y Entrada de Nuevos Competidores
Ejemplo
 Dos marcas de café: D (descafeinado) y R (regular)
 Participación de mercado de cada marca = 50%
 Supongamos que una 3ª marca entra al mercado:
 Marca N
 Marca N es un café descafeinado fabricado por la
 misma firma que produce la Marca D
  Otros atributos de N idénticos a los de D

[pág. 22]
IIA y Entrada de Nuevos Competidores
 ¿Cuáles son las nuevas participaciones que
 esperaríamos observar?
 ¿Cuáles son las nuevas participaciones de acuerdo al
 modelo logit?

[pág. 23]
Limitaciones: IIA
Modelo Nested Logit
 Generalización del modelo logit
  Clase de modelos GEV (valor extremo generalizada)
 Apropiado cuando podemos particionar set de
 alternativas en subconjuntos (“nidos”) a priori
 Ej. Café Regular” vs. Descafeinado; Bebida Cola vs.
 Bebida No Cola
 Propiedad IIA se cumple al interior de nido pero no entre
 nidos

[pág. 24]
Modelo Nested Logit
 Regular Descafeinado
 Nescafé … Monterrey Nescafé … Monterrey

[pág. 25]
Limitaciones del Modelo Logit
 Homogeneidad de Preferencias
25
  Modelo asume que todos los consumidores son
 igualmente sensibles a atributos del producto
 𝑢𝑖𝑗𝑡 = 𝛽𝑗 + 𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑗𝑡 + 𝛽𝑓 𝐹𝑒𝑎𝑡𝑗𝑡 + 𝛽𝑑 𝐷𝑖𝑠𝑝𝑗𝑡 + 𝜀𝑖𝑗𝑡

[pág. 26]
Limitaciones del Modelo Logit
 Homogeneidad de Preferencias
26
  Modelo asume que todos los consumidores son
 igualmente sensibles a atributos del producto
 𝑢𝑖𝑗𝑡 = 𝛽𝑗 + 𝛽𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑗 + 𝛽𝑓 𝐹𝑒𝑎𝑡𝑗 + 𝛽𝑑 𝐷𝑖𝑠𝑝𝑗 + 𝜀𝑖𝑗𝑡
 Coeficientes idénticos para todos los consumidores
 Supuesto facilita la estimación, pero es poco realista

[pág. 27]
Limitaciones del Modelo Logit
 Homogeneidad de Preferencias
27
  Potenciales soluciones
  Estimar modelo para distintos segmentos de consumidores
 ◼ Análisis de segmentación como etapa previa
  Modelo logit multinomial de coeficientes aleatorios (o
 “mixed logit”)
 • Vector de coeficientes sigue una cierta distribución en la población
 • Sensibilidad a atributos es potencialmente distinta entre clientes

[pág. 28]
Mixed Logit
28
 𝑢𝑖𝑗𝑡 = 𝛽𝑖𝑗 + 𝛽𝑖𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑗 + 𝛽𝑖𝑓 𝐹𝑒𝑎𝑡𝑗 + 𝛽𝑖𝑑 𝐷𝑖𝑠𝑝𝑗 + 𝜀𝑖𝑗𝑡
 Vector de coeficientes 𝜷~𝑀𝑁𝑉(𝑩, 𝚺)
 sigue cierta distribución
 de probabilidad

[pág. 29]
Mixed Logit
29
 𝑢𝑖𝑗𝑡 = 𝛽𝑖𝑗 + 𝛽𝑖𝑝 𝑃𝑟𝑒𝑐𝑖𝑜𝑗 + 𝛽𝑖𝑓 𝐹𝑒𝑎𝑡𝑗 + 𝛽𝑖𝑑 𝐷𝑖𝑠𝑝𝑗 + 𝜀𝑖𝑗𝑡
 𝜷~𝑀𝑁𝑉(𝑩, 𝚺)
 Estimación require
 𝑒 𝑣𝑖𝑗𝑡 𝜷 uso de métodos
 𝑃𝑖𝑗𝑡 = න 𝜙 𝜷 𝑑𝜷
 σ𝐽𝑘=1 𝑒 𝑣𝑖𝑘𝑡 𝜷 numéricos

[pág. 30]
Ejemplo: Impacto de Etiquetado
 Nutricional sobre Demanda
30
 ▪ Elección de consumidores en 3 categorías: Cereales, Chocolates,
 Galletas (10 productos en cada categoría)
 ▪ Función de utilidad indirecta:

[pág. 31]
Heterogeneidad en Sensibilidad a Etiquetado
31

[pág. 32]
Supuesto de Utilidad Aditiva en Atributos
 Modelo Compensatorio
32
  Consideremos la siguiente función de utilidad por
 automóviles donde 𝛽𝑝 < 0, 𝛽𝑒 > 0 y 𝛽𝑚 >0:
 𝑢𝑖𝑗 = 𝛽𝑝 𝑝𝑟𝑒𝑐𝑖𝑜𝑗 + 𝛽𝑒 𝐸𝑠𝑝𝑎𝑐𝑖𝑜𝑗 + 𝛽𝑚 𝐸𝑐𝑜𝑓𝑟𝑖𝑒𝑛𝑑𝑙𝑦𝑗 + 𝜀𝑖𝑗
  Modelo asume que consumidor está dispuesto a
 compensar menor cuidado del medio ambiente con
 mayor espacio o menor precio

[pág. 33]
Supuesto de Utilidad Aditiva en Atributos
 Modelo Compensatorio
33
 • Utilidad promedio si automóvil es ecofriendly (𝐸𝑐𝑜𝑓𝑟𝑖𝑒𝑛𝑑𝑙𝑦𝑗 =1)
 𝑣𝑖𝑗 = 𝛽𝑝 𝑝𝑟𝑒𝑐𝑖𝑜𝑗 + 𝛽𝑒 𝐸𝑠𝑝𝑎𝑐𝑖𝑜𝑗 + 𝛽𝑚

[pág. 34]
Supuesto de Utilidad Aditiva en Atributos
 Modelo Compensatorio
34
 • Utilidad promedio si automóvil es ecofriendly (𝐸𝑐𝑜𝑓𝑟𝑖𝑒𝑛𝑑𝑙𝑦𝑗 =1)
 𝑣𝑖𝑗 = 𝛽𝑝 𝑝𝑟𝑒𝑐𝑖𝑜𝑗 + 𝛽𝑒 𝐸𝑠𝑝𝑎𝑐𝑖𝑜𝑗 + 𝛽𝑚
 • Utilidad promedio equivalente si automóvil no es ecofriendly
 (𝐸𝑐𝑜𝑓𝑟𝑖𝑒𝑛𝑑𝑙𝑦𝑗 =0)
 𝑣𝑖𝑗 = 𝛽𝑝 𝑝𝑟𝑒𝑐𝑖𝑜𝑗 ′ + 𝛽𝑒 𝐸𝑠𝑝𝑎𝑐𝑖𝑜𝑗 ′

[pág. 35]
Supuesto de Utilidad Aditiva en Atributos
 Modelo Compensatorio
35
 • Utilidad promedio si automóvil es ecofriendly (𝐸𝑐𝑜𝑓𝑟𝑖𝑒𝑛𝑑𝑙𝑦𝑗 =1)
 𝑣𝑖𝑗 = 𝛽𝑝 𝑝𝑟𝑒𝑐𝑖𝑜𝑗 + 𝛽𝑒 𝐸𝑠𝑝𝑎𝑐𝑖𝑜𝑗 + 𝛽𝑚
 • Utilidad promedio equivalente si automóvil no es ecofriendly
 (𝐸𝑐𝑜𝑓𝑟𝑖𝑒𝑛𝑑𝑙𝑦𝑗 =0)
 𝑣𝑖𝑗 = 𝛽𝑝 𝑝𝑟𝑒𝑐𝑖𝑜𝑗 ′ + 𝛽𝑒 𝐸𝑠𝑝𝑎𝑐𝑖𝑜𝑗 ′
 𝛽𝑚 = 𝛽𝑝 (𝑝𝑟𝑒𝑐𝑖𝑜𝑗′ −𝑝𝑟𝑒𝑐𝑖𝑜𝑗 ) + 𝛽𝑒 (𝐸𝑠𝑝𝑎𝑐𝑖𝑜𝑗′ − 𝐸𝑠𝑝𝑎𝑐𝑖𝑜𝑗 )

[pág. 36]
Alternativa: Modelos No Compensatorios
36
  Modelos no-compensatorios basados en decisiones en 2
 etapas
  Etapa 1: Definición de “set de consideración”
  Sólo incluye alternativas que satisfacen cierto criterio
 (presupuestario, estándares medioambientales, etc.)
  Etapa 2: Aplicación de modelo compensatorio sobre
 alternativas en “set de consideración”
  Estimación es más compleja que en el caso de modelos
 compensatorios

# Marketing Analytics · clase21_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 PREDICCIÓN DE FUGA Y
 PROGRAMAS DE RETENCIÓN
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Modelo de Respuesta: Resumen
2
  Estadísticos Tradicionales
  Regresión logística
  Machine Learning
  Árboles de Decisión
  Random Forests

[pág. 3]
Modelo de Regresión Logística
3
  Uso de modelo logístico en predicción de respuesta
 𝑒𝑣
 𝑃 𝑦=1𝑥 =
 1 + 𝑒𝑣 𝑒 (𝛽0 +𝛽1 ∙𝑥)
 𝑃 𝑦=1𝑥 =
 1 + 𝑒 (𝛽0 +𝛽1 ∙𝑥)
 𝑣 = 𝛽0 + 𝛽1 ∙ 𝑥

[pág. 4]
Interpretación usando Log Odds
4
  Reformulación del modelo usando log-odds:
 𝑝
 𝑙𝑜𝑔 = 𝛽0 + 𝛽1 𝑥 , 𝑝≡𝑃 𝑦=1𝑥
 1−𝑝
 Efecto de incremento unitario en 𝑥:
 Δ% 𝑒𝑛 𝑂𝑅 = 𝑒𝑥𝑝 𝛽1 − 1

[pág. 5]
library(rpart.plot)
 rpart.plot(churn_tree, box.palette = "RdBu", shadow.col = "gray", nn = TRUE)
 1
 0
 0.36
 100%
 2
 yes tenure >= 11 no 3 Predicción si hoja
 0 1
 0.10 0.90 % de “1s”
 68% 32%
 % de clientes
 ptr >= 4 ptr >= 5
 5 6
 1 0
 0.68 0.42
 5% 4%
 tenure >= 15 tenure >= 8
 4 10 11 12 13 7
 0 0 1 0 1 1
 0.05 0.08 0.78 0.31 0.95 0.97
 62% 1% 4% 3% 1% 29%
5

[pág. 6]
RANDOM FORESTS
 MÉTODO DE ENSAMBLE BASADO EN DOS IDEAS BÁSICAS
 ❑ “BAGGING” (bootstrap aggregating)
 ▪ Obtenemos muchos sets de datos vía bootstrapping
 ▪ Ajustamos un árbol de decisión a cada set de datos
 ▪ Combinamos las predicciones de los árboles (vía voto por mayoría)
 ❑ SELECCIÓN ALEATORIA DE FEATURES
 ▪ Cada árbol utiliza sólo un subconjunto de features
 ▪ Contribuye a que modelos individuales sean independientes entre
 sí (reduciendo varianza de predicciones)
 ▪ Reducción de costos computacionales
6

[pág. 7]
Evaluación de Modelos de Clasificación
7
  Métricas basadas en matriz de confusión
  Sensitivity (Recall)
  Specificity
  Accuracy
  Precision
  F1 measure
  Area bajo la curva ROC (AUC-ROC)

[pág. 8]
CURVA ROC Y AUC
 AUC:
 0.9 – 1.0 = Excelente
 0.8 – 0.9 = Bueno
 0.7 – 0.8 = Regular
 < 0.6 = Pobre

[pág. 9]
Uso en Campañas de Retención
9
  Predicciones de fuga son un componente clave de
 direccionamiento de campañas de retención
  Actividades orientadas a salvar a clientes propensos a
 abandonar
  Descuentos especiales, upgrades, etc.
  Adquisición de clientes tiende a ser más cara y
 compleja que la retención
  Costo por cliente 5-25 veces más alto (Gallo, HBR 2014)

[pág. 10]
Enfoques en Direccionamiento de
 Campañas de Retención
10
  Compañías asignan puntaje (score) a cada cliente
 indicando prioridad de contacto
  Campaña dirigida a clientes con scores más altos
  ¿Cómo estimar score de un cliente?
  Distintos enfoques dependiento de sofisticación
 analítica de la empresa

[pág. 11]
Enfoque Tracicional:
 Foco en Propensión a Fuga
11
  Tradicionalmente empresas priorizan contactos en
 base a propensión a la fuga:
 𝑠𝑐𝑜𝑟𝑒 𝑥 = Pr{𝐶ℎ𝑢𝑟𝑛|𝑥}
 Campaña dirigida a clientes con mayor propensión a la fuga

[pág. 12]
Enfoque Tradicional
12
 ID Cliente Pr{𝐶ℎ𝑢𝑟𝑛|𝑥}
 0201 0.961
 0036 0.945 Clientes en Riesgo
 0497 0.932 de Fuga
 0006 0.910
 0334 0.886
 % seleccionado como target basado en regla heurística

[pág. 13]
Enfoque 2: Foco en Uplift
13
  Enfoque 2 reconoce que estrategia de contactar a clientes más
 propensos a fuga podría resultar contraproducente
  Clientes contactados (mayor propensión a fuga)
  Podrían decidir cancelar en respuesta a contacto intrusivo
  Podrían ser recordados de la posibilidad de cancelar contrato
 Importante considerar impacto de campaña sobre
 probabilidad de fuga

[pág. 14]
14
 Propensión a Fuga con y sin Campaña
 Pr{𝐶ℎ𝑢𝑟𝑛|𝑇, 𝑥}
 No Molestar Causas
 Perdidas
 Seguros Persuadibles
 0 Pr{𝐶ℎ𝑢𝑟𝑛|𝑁, 𝑥}

[pág. 15]
Enfoque 2: Foco en Uplift (salvabilidad)
15
  Enfoque 2 prioriza clientes en base a impacto
 incremental de campaña
 uplift x = Pr 𝐶ℎ𝑢𝑟𝑛 𝑁, 𝑥 − Pr{𝐶ℎ𝑢𝑟𝑛|𝑇, 𝑥}
 Prob. de abandono si no Prob. de abandono si es
 es contactado contactado

[pág. 16]
Enfoque 2: Foco en Uplift (salvabilidad)
16
  Enfoque 2 prioriza clientes en base a impacto
 incremental de campaña
 uplift x = Pr 𝐶ℎ𝑢𝑟𝑛 𝑁, 𝑥 − Pr{𝐶ℎ𝑢𝑟𝑛|𝑇, 𝑥}
 Uplift estimado vía test A/B
 Comparación con probabilidad contrafactual
 Aleatorización de contacto entre grupos tratamiento y control

[pág. 17]
Enfoque 2: Foco en Uplift (salvabilidad)
17
  Enfoque 2 prioriza clientes en base a impacto
 incremental de campaña
 uplift x = Pr 𝐶ℎ𝑢𝑟𝑛 𝑁, 𝑥 − Pr{𝐶ℎ𝑢𝑟𝑛|𝑇, 𝑥}
 • En este caso,
 score x = 𝑢𝑝𝑙𝑖𝑓𝑡(𝑥)

[pág. 18]
Enfoque 3: Uplift y CLV
18
  Finalmente, el enfoque 3 reconoce importancia de
 considerar el valor del cliente
 score x = 𝑢𝑝𝑙𝑖𝑓𝑡(𝑥) ∙ 𝐸[𝐶𝐿𝑉]

[pág. 19]
Enfoque 3: Uplift y CLV
19
  Finalmente, el enfoque 3 reconoce importancia de
 considerar el valor del cliente
 score x = 𝑢𝑝𝑙𝑖𝑓𝑡(𝑥) ∙ 𝐸[𝐶𝐿𝑉]
 score x = Pr 𝐶ℎ𝑢𝑟𝑛 𝑁, 𝑥 ∙ 𝐸[𝐶𝐿𝑉] − Pr{𝐶ℎ𝑢𝑟𝑛|𝑇, 𝑥} ∙ 𝐸[𝐶𝐿𝑉]
 Pérdida Esperada sin Canpaña Pérdida Esperada con Campaña

[pág. 20]
Directamente Asociado a ROI de
 Campaña
20
  Suponga que se espera que campaña reduzca probablidad
 de fuga en 15 puntos porcentuales
  El CLV esperado del cliente es $500
  El costo de enviar una oferta de retención es $50
  ¿Cuál es el retorno sobre la inversión (ROI) de la campaña?

[pág. 21]
21
 LAB 4: PREDICCIÓN DE RESPUESTA
 CAMPAÑA DE TELEMARKETING EN
 INSTITUCIÓN FINANCIERA

[pág. 22]
Predicción de Respuesta en Institución
 Financiera
22
  Institución financiera portuguesa interesada en
 predecir respuesta a campaña de telemarketing
  Ofrecimiento de nuevo producto: Depósito a plazo
  Target: Respuesta a campaña
  Features: Datos geodemográficos y
 comportamiento del cliente

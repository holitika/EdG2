# Marketing Analytics · clase7_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 ANÁLISIS DE CLUSTERS:
 MÉTODOS JERÁRQUICOS
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Tópico: Segmentación
2
  División de mercado en subgrupos de consumidores
 similares en cuanto a gustos, preferencias,
 necesidades.
  Proceso de segmentación
  Selección de bases de segmentación
  Selección de enfoque de segmentación
  Método de segmentación

[pág. 3]
Enfoques de Segmentación
3
  A-priori
  Segmentos definidos previo a cualquier análisis
  Ej. “Edad > 35 años vs. < 35 años”, “Alto gasto vs.
 Bajo gasto” , RFM, etc.
  Post-hoc o a-posteriori
  Segmentos descubiertos a partir de los datos
  Principal metodología: Análisis de clusters

[pág. 4]
¿Qué es el Análisis de Clusters?
4
  Conjunto de técnicas
 para encontrar
 subgrupos (clusters) en
 un conjunto de datos
  Método de machine
 learning no
 supervisado

[pág. 5]
Métodos Supervisados vs. No
 Supervisados
5
  Métodos supervisados:
  Observación de features, 𝑋1 , 𝑋2 ,…, 𝑋𝑝 , y respuesta 𝑌
  Objetivo: Predicción
  Métodos no supervisados
  Observación sólo de features , 𝑋1 , 𝑋2 ,…, 𝑋𝑝
  Objetivo: Encontrar estructura intersante en features (Ej.
 agrupación de observaciones o variables)

[pág. 6]
Objetivo del Análisis de Clusters
6
 Dada una colección de 𝑛 objetos (consumidores),
 cada uno de los cuales es descrito por 𝑝
 variables (bases de segmentación) queremos
 derivar una partición en un número de clusters o
 segmentos internamente homogéneos y
 externamente heterogéneos

[pág. 7]
Idea Básica del Análisis de Clusters
7
 Grupos internamente
 homogéneos
 Grupos externamente
 heterogéneos

[pág. 8]
Datos en Análisis de Clusters
8
  Principales fuentes de datos:
  Encuestas
  Datos internos a la organización
  Datos experimentales
  Tamaño muestral
  𝑛 > 60𝑝 (Dolnicar et al., 2014)

[pág. 9]
Estructura de Datos
9
 Bases de Segmentación ❑ EJEMPLO
 𝑥11 ⋯ 𝑥1𝑝
 Clientes
𝑋= ⋮ ⋱ ⋮
 𝑥𝑛1 ⋯ 𝑥𝑛𝑝

[pág. 10]
Metodologías más Comunes
10
  Métodos basados en medidas de Similitud
  “Algoritmos combinatoriales”
  Ej. Métodos jerárquicos, métodos de partición
  Modelación de mixturas
  PGD es mixtura de funciones de densidad
 paramétricas que representan a distintos clusters

[pág. 11]
Métodos Basados en Similitud
11
  Métodos Jerárquicos  Métodos de Partición
  Generan secuencia de  Generan partición en
 particiones anidadas número pre-especificado
  Apropiados para set de
 de clusters
 datos pequeños (cientos de  Método más común: K-
 obs.) Medias
  Computacionalmente  Apropiado para 𝑛 alto ( >
 intensivos miles de observaciones)
 ◼ Requieren computar distancias  Menos computacionalmente
 entre todos los objetos costosos

[pág. 12]
12
 Métodos Jerárquicos

[pág. 13]
¿Qué son los Métodos Jerárquicos?
13
 “Conjunto de algoritmos que construyen
 clusters vía fusión o división en base a
 algún criterio de proximidad”

[pág. 14]
Métodos Jerárquicos: Características y
 Clases
14
  Generan jerarquía de clusters en
 base a proximidad entre clusters
  Output: Gráfico de árbol
 invertido (dendrograma)
 indicando objetos más similares
 entre sí
  Aglomerativos: Agrupamiento
 desde abajo hacia arriba
  Divisivos: Separación desde
 arriba hacia abajo

[pág. 15]
Decisiones Básicas en Análisis de Clusters
 Jerárquico Aglomerativo
15
 1. Medida de proximidad a utilizar
 2. Criterio de enlace o vinculación
 3. Número de clusters a extraer

[pág. 16]
Medidas de Proximidad dependen de
 Tipo de Variable
16
  Variables cuantitativas (escala de intervalo)
  Distancias: Euclidiana, euclidiana al cuadrado, Manhattan, etc.
  Coeficiente de correlación
  Variables categóricas
  Coeficiente de matching, distancia Jaccard, etc.
  Distancia Gower permite combinar distintos tipos de
 variables
  Función 𝑑𝑎𝑖𝑠𝑦(∙) en R

[pág. 17]
Medida de Proximidad más Comúnmente
 utilizada: Distancia Euclidiana
17
 𝑝
 𝑑 𝒙𝟏 , 𝒙𝟐 = ෍(𝑥1𝑗 − 𝑥2𝑗 )2
 𝑗=1
 Distancia entre vectores de 𝑗 𝑖𝑛𝑑𝑒𝑥𝑎 𝑏𝑎𝑠𝑒𝑠 𝑑𝑒 𝑠𝑒𝑔𝑚𝑒𝑛𝑡𝑎𝑐𝑖ó𝑛
 consumidores 1 y 2

[pág. 18]
Distancia Euclidiana
18
 Ejemplo: Segmentación en base a Recencia y Frecuencia
 𝐵 = (3, 4)
 Recencia Frecuencia
 𝑑(𝑨, 𝑩)
Consumidor A 5 2
 Frecuencia
Consumidor B 3 4
 𝐴 = (5, 2)
 Recencia
 𝑑 𝑨, 𝑩 =

[pág. 19]
Variables Categóricas: Coeficiente de
 Matching
19
 𝑁ú𝑚𝑒𝑟𝑜 𝑑𝑒 𝐴𝑡𝑟𝑖𝑏𝑢𝑡𝑜𝑠 𝐶𝑜𝑖𝑛𝑐𝑖𝑑𝑒𝑛𝑡𝑒𝑠
 𝐶𝑜𝑒𝑓𝑖𝑐𝑖𝑒𝑛𝑡𝑒 𝑑𝑒 𝑀𝑎𝑡𝑐ℎ𝑖𝑛𝑔 =
 𝑁ú𝑚𝑒𝑟𝑜 𝑇𝑜𝑡𝑎𝑙 𝑑𝑒 𝐴𝑡𝑟𝑖𝑏𝑢𝑡𝑜𝑠
 Prefiere Leal a la Sensible al
 Comprar Online Marca Precio
 (Sí/No) (Sí/No) (Sí/No)
 Consumidor A Sí Sí No
 Consumidor B Sí No Sí
 Consumidor C Sí Sí Sí
 𝑑 𝐴, 𝐵 =?

[pág. 20]
Transformación de Datos en Matriz de
 Similitudes/Disimilitudes
20
 ❑Matriz de Datos ❑Matriz de Distancias (o
 Bases de Segmentación correlaciones)
 Consumidores

[pág. 21]
Método Jerárquico (aglomerativo)
 Algoritmo de Solución
21
 1. Asignar cada cliente a un cluster separado

[pág. 22]
Método Jerárquico (aglomerativo)
 Algoritmo de Solución
22
 1. Asignar cada cliente a un cluster separado.
 2. Calcular matriz de distancias entre cada par de clusters

[pág. 23]
Método Jerárquico (aglomerativo)
 Algoritmo de Solución
23
 1. Asignar cada cliente a un cluster separado
 2. Calcular matriz de distancias entre cada par de clusters
 3. Combinar clusters más cercanos en base a matriz de
 distancias

[pág. 24]
Método Jerárquico (aglomerativo)
 Algoritmo de Solución
24
 1. Asignar cada cliente a un cluster separado
 2. Calcular matriz de distancias entre cada par de clusters
 3. Combinar clusters más cercanos en base a matriz de
 distancias
 4. Recalcular distancias entre nuevo cluster y antiguos

[pág. 25]
Método Jerárquico (aglomerativo)
 Algoritmo de Solución
25
 1. Asignar cada cliente a un cluster separado
 2. Calcular matriz de distancias entre cada par de clusters
 3. Combinar clusters más cercanos en base a matriz de
 distancias
 4. Recalcular distancias entre nuevo cluster y antiguos
 5. Repetir pasos 3 y 4 hasta que todos los clusters queden
 agrupados en un único cluster

[pág. 26]
Ejemplo: Percepción de Precios y
 Calidad
26

[pág. 27]
Ejemplo: Percepción de Precios y
 Calidad
27
 Paso 1: Cada consumidor es un cluster distinto

[pág. 28]
Paso 2: Cómputo de Matriz de Distancias
28
 Nota: Distancia Euclidiana

[pág. 29]
Paso 3: Agrupamiento de Clusters Más
 Cercanos
29
 Algoritmo forma nuevo cluster: {C8, C9}

[pág. 30]
Visualización de Agrupación
30

[pág. 31]
Paso 4: Re-computo de Matriz de
 Distancias
31

[pág. 32]
Paso 4: Re-computo de Matriz de
 Distancias
32
 Algoritmo identifica nuevo cluster: {C4, C7}

[pág. 33]
Visualización de Agrupación
33

[pág. 34]
Paso 5: Agrupamiento de Clusters y
 Recómputo de Distancias
34
  Algoritmo necesita computar distancias entre cluster
 que incluye múltiples consumidores heterogéneos y
 otros clusters
  {C4, C7}: C4 = (10, 84); C7 = (13, 82)
  Necesitamos definir criterio de enlace o vinculación
 (“linkage”)
  Noción de disimilitud entre grupos de observaciones

[pág. 35]
Criterios de Vinculación más Comúnmente
 Utilizados
35
  Enlace simple (single linkage)
  Distancia mínima entre clusters
  Tendencia a generar clusters de distinto tamaño
 (“chaining effect”)
  Enlace completo (complete linkage)
  Distancia máxima entre clusters
  Tendencia a generar clusters de similar tamaño
  Solución más vulnerable a outliers

[pág. 36]
Ejemplo: Enlace Simple vs. Enlace
 Completo
36
 ❑ Clientes ubicados sobre la recta como sigue:
 𝑐1 𝑐2 𝑐3 𝑐4 𝑐5
 0 1 2 3 4 5 6 7 8 9 10

[pág. 37]
Single-linkage Complete-linkage
 𝑐1 𝑐2 𝑐3 𝑐4 𝑐5 𝑐1 𝑐2 𝑐3 𝑐4 𝑐5
 0 1 2 3 4 5 6 7 8 9 10 0 1 2 3 4 5 6 7 8 9 10
 𝑐1 𝑐2 𝑐3 𝑐4 𝑐5 𝑐1 𝑐2 𝑐3 𝑐4 𝑐5
 0 1 2 3 4 5 6 7 8 9 10 0 1 2 3 4 5 6 7 8 9 10
 𝑐1 𝑐2 𝑐3 𝑐4 𝑐5 𝑐1 𝑐2 𝑐3 𝑐4 𝑐5
 0 1 2 3 4 5 6 7 8 9 10 0 1 2 3 4 5 6 7 8 9 10
 𝑐1 𝑐2 𝑐3 𝑐4 𝑐5 𝑐1 𝑐2 𝑐3 𝑐4 𝑐5
37 0 1 2 3 4 5 6 7 8 9 10 0 1 2 3 4 5 6 7 8 9 10

[pág. 38]
Criterios de Vinculación Más
 Comúnmente Utilizados (cont.)
38
  Enlace promedio (average linkage)
  Distancia media entre clusters
  Menos vulnerable a outliers que completo
  Enlace centroide (centroid linkage)
  Distancia entre centroides de cada cluster
 Ambos tienden a producir clusters con baja
 varianza interior y tamaños similares

[pág. 39]
Criterios de Enlace: ¿Importantes?
39
  El criterio de enlace a utilizar puede hacer una
 diferencia relevante en la solución
  Recomendación: Probar distintos criterios y retener
 soluciones más consistentes

[pág. 40]
Dendrograma Asociado: Interpretación
40

[pág. 41]
¿Cómo Decidir Número de Clusters?
41
  Output de análisis de clusters jerárquico es
 dendrograma, no asignación a clusters
  Metodologías de determinación de número y
 pertenencia a clusters
  Mismo dendrograma
  Scree plot
  Índice CH (Calinski-Harabasz)
  Silhouette

[pág. 42]
¿Cómo usamos el Dendrograma en la
 Decisión de Clusters a Extraer?
42

[pág. 43]
Solución de 3 Clusters
43

[pág. 44]
44

[pág. 45]
Solución de 2 Clusters
45

[pág. 46]
46

[pág. 47]
Número de Clusters: Scree Plot
47

[pág. 48]
Número de Clusters: Índice CH
48
 𝑆𝑆 𝑒𝑛𝑡𝑟𝑒 𝐶𝑙𝑢𝑠𝑡𝑒𝑟𝑠 𝑁 − 𝐾
 𝐶𝐻𝑘 =
 𝑆𝑆 𝑖𝑛𝑡𝑒𝑟𝑖𝑜𝑟 𝑎 𝐶𝑙𝑢𝑠𝑡𝑒𝑟𝑠 𝐾 − 1
 Visualización de Valor del Índice versus Número de
 Clusters

[pág. 49]
Nota: Índice de Calinski-Harabasz
49
 ❑ Más precisamente, fórmula del índice CH o pseudo-F es:
 𝐾 σ 𝑘 𝑛
 σ𝐾 𝑛 𝑐
 𝑘=1 𝑘 𝑘 − 𝑐 2 σ𝑘=1 𝑖=1 𝑑𝑖 − 𝑐𝑘
 2
 𝐶𝐻𝑘 = /
 𝐾−1 𝑁−𝐾
 𝑛𝑘 = 𝑛ú𝑚𝑒𝑟𝑜 𝑑𝑒 𝑜𝑏𝑠𝑒𝑟𝑣𝑎𝑐𝑖𝑜𝑛𝑒𝑠 𝑒𝑛 𝑐𝑙𝑢𝑠𝑡𝑒𝑟 𝑘
 𝑐𝑘 = 𝑐𝑒𝑛𝑡𝑟𝑜𝑖𝑑𝑒 𝑑𝑒 𝑐𝑙𝑢𝑠𝑡𝑒𝑟 𝑘
 𝑐 = 𝑐𝑒𝑛𝑡𝑟𝑜𝑖𝑑𝑒 𝑔𝑙𝑜𝑏𝑎𝑙
 𝑑𝑖 = 𝑣𝑒𝑐𝑡𝑜𝑟 𝑑𝑒 𝑑𝑎𝑡𝑜𝑠 𝑑𝑒 𝑐𝑙𝑖𝑒𝑛𝑡𝑒 𝑖

[pág. 50]
Número de Clusters: Coeficiente CH
50
 ¿Cuántos clusters extraer?

[pág. 51]
Número de Clusters: Coeficiente Silhouette
51
  Basado en dos métricas:
  Cohesión: Distancia
 promedio a todos los otros
 puntos en el cluster (𝑎(𝑖))
  Separación: Distancia
 promedio a todos los
 puntos en el cluster más
 cercano (𝑏(𝑖))

[pág. 52]
Número de Clusters: Coeficiente Silhouette
52
 𝑏 𝑖 − 𝑎(𝑖)
 𝑆(𝑖) =
 max(𝑏 𝑖 , 𝑎 𝑖 )
 𝑆(𝑖) ∈ −1,1

[pág. 53]
53

[pág. 54]
Resumen
 Método Jerárquico Aglomerativo
54
  Punto de partida: Matriz de distancias
  Construcción de jerarquía de clusters (dendrograma)
  Decisión de número de segmentos a extraer
  Dendrograma
  Scree plot
  Índice CH
  Coeficiente Silhouette promedio

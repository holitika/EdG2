# Marketing Analytics · clase12_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 MDS Y ANÁLISIS DE
 PREFERENCIAS
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Plan para Hoy
2
  Mapas perceptuales basados en juicios de similitud
  Escalamiento Multidimensional
  Análisis de preferencias

[pág. 3]
Métodos Basados en Juicios de Similitud
3
  Basados en juicios acerca de cuán similares son las marcas
 /productos/servicios
  Individuos evalúan similitud de pares de objetos
  Tarea: Individuos deben hacer ranking de pares de objetos
  Datos: Matriz de disimilitud
  Especialmente útiles cuando atributos clave son intangibles
  Ej. productos en que experiencia sensorial es relevante

[pág. 4]
Escalamiento Multidimensional (MDS)
4
 “Método que representa mediciones de
 similitud (o disimilitud) entre pares de
 objetos como distancias entre puntos en
 un espacio multidimensional de baja
 dimensionalidad”
 Borg & Groenen, “Modern Multidimensional Scaling: Theory and Applications”, 2nd ed.

[pág. 5]
MDS: Idea Básica
5
  A partir de configuración de
 objetos en mapa podemos
 calcular distancias entre puntos

[pág. 6]
MDS: Idea Básica
6
  A partir de configuración de
 objetos en mapa podemos
 calcular distancias entre puntos
  MDS busca resolver problema
 inverso:
  A partir de datos de disimilitudes
 busca generar configuración de
 puntos en mapa que reflejen
 fielmente esas distancias

[pág. 7]
Juicios de Similitud:
 Mapa perceptual de Series de Netflix
7
 Stranger Things The Witcher The Crown Money Heist Bridgerton

[pág. 8]
Ranking de Series de Netflix
8
 Serie 1 Serie 2 Ranking
 Stranger Things The Witcher 2
 Stranger Things The Crown 8
 Stranger Things Money Heist 5
 Stranger Things Bridgerton 7
 The Witcher The Crown 9
 The Witcher Money Heist 6
 The Witcher Bridgerton 10
 The Crown Money Heist 3
 The Crown Bridgerton 1
 Money Heist Bridgerton 4

[pág. 9]
Matriz de Disimilitudes
9

[pág. 10]
10

[pág. 11]
Idea de Algoritmos de MDS
11
  Configuración de puntos en espacio euclidiano de
 manera de minimizar función que mide discrepancia
 entre:
  Distancias en mapa de baja dimensionalidad
  Distancias originales en espacio de alta
 dimensionalidad

[pág. 12]
Escalamiento Multidimensional (MDS)
 Algoritmo de Solución
12
 1. Configuración inicial de marcas en espacio euclidiano

[pág. 13]
Escalamiento Multidimensional (MDS)
 Algoritmo de Solución
13
 2. Cálculo de distancias entre objetos: 𝑑𝑖𝑗
 𝑑𝑒𝑓

[pág. 14]
Escalamiento Multidimensional (MDS)
 Algoritmo de Solución
14
 3. Regresión de distancias 𝑑𝑖𝑗 sobre disimilitudes
 sicológicas, 𝑝𝑖𝑗
 𝑑𝑖𝑗 = 𝛼 + 𝛽𝑝𝑖𝑗 + 𝑢𝑖𝑗
 Distancia en Disimilitud
 mapa observada

[pág. 15]
Escalamiento Multidimensional (MDS)
 Algoritmo de Solución
15
 3. Regresión de distancias 𝑑𝑖𝑗 sobre disimilitudes
 sicológicas, 𝑝𝑖𝑗
 𝑑𝑖𝑗 = 𝛼 + 𝛽𝑝𝑖𝑗 + 𝑢𝑖𝑗
 4. Obtención de valores ajustados 𝑑መ 𝑖𝑗
 𝑑መ 𝑖𝑗 = 𝛼ො + 𝛽𝑝
 መ 𝑖𝑗

[pág. 16]
Escalamiento Multidimensional (MDS)
 Algoritmo de Solución
16
 5. Cálculo de medida de mal ajuste: Stress
 Similar a (1 − 𝑅2 )
 2
 σ𝑖<𝑗 𝑑𝑖𝑗 − 𝑑መ 𝑖𝑗 en regresión
 𝑆𝑡𝑟𝑒𝑠𝑠 = 2
 ሜ
 σ𝑖<𝑗 𝑑𝑖𝑗 − 𝑑 Stress < 0.05 indica
 buen ajuste

[pág. 17]
Escalamiento Multidimensional (MDS)
 Algoritmo de Solución
17
 6. Si 𝑆𝑡𝑟𝑒𝑠𝑠 > 𝜀, buscar nueva configuración tal que el ranking de 𝑑𝑖𝑗
 sea más cercano al ranking de 𝑝𝑖𝑗
 • Si 𝑑𝑖𝑗 > 𝑑መ 𝑖𝑗 movemos puntos de manera que se acerquen en el espacio
 euclidiano
 • Algoritmos difieren en la manera específica en que obtienen nuevas
 configuraciones
 7. Repetir hasta alcanzar convergencia

[pág. 18]
Escalamiento Multidimensional (MDS)
 Procedimiento Típico: Resumen
18
 1. Configuración inicial de objetos en espacio euclidiano (ej. aleatoria)
 2. Cálculo de distancias entre objetos: 𝑑𝑖𝑗
 3. Regresión simple de distancias 𝑑𝑖𝑗 sobre proximidades sicológicas, 𝑝𝑖𝑗
 4. Obtención de valores ajustados 𝑑መ 𝑖𝑗
 5. Cálculo de medida de mal ajuste (comparación de valores ajustados y
 distancias observadas): Stress
 6. Reconfiguración de puntos si 𝑆𝑡𝑟𝑒𝑠𝑠 > 𝜀
 7. Repetir hasta alcanzar convergencia

[pág. 19]
MDS: Mapa Perceptual de Cereales

[pág. 20]
MDS: Mapa Perceptual de Cereales

[pág. 21]
21

[pág. 22]
22
 Mapas de Preferencias

[pág. 23]
¿Cómo está posicionada MP?
 ¿Es un buen posicionamiento?
23

[pág. 24]
Visualización de Preferencias
24
  Limitación de mapas perceptuales: No proveen
 información sobre preferencias de consumidores
  ¿Qué posiciones son deseables para distintos segmentos de
 clientes?
  Análisis asume que consumidores tienen preferencias
 por distintos atributos de un producto
  ¿Cómo representamos esas preferencias en un mapa
 perceptual?

[pág. 25]
¿Cómo representar preferencias en el
 espacio de factores?
25
  Modelos de representación de preferencias:
 1. Modelo de Vector Ideal
 2. Modelo de Punto Ideal

[pág. 26]
Modelo de Vector Ideal
26
  Consumidores
 prefieren más (o Preferencia
 menos) de un atributo
  Función de
 preferencias lineal
  ¿Ejemplos?
 Atributo

[pág. 27]
Enfoque de Vector Ideal: Interpretación
27
 A, B, C son marcas
 A Vector de
 Preferencias
 C
 B

[pág. 28]
Enfoque de Vector Ideal: Interpretación
28
 A Vector de
 Preferencias
 A B C
 C
 B

[pág. 29]
Modelo de Vector Ideal
 Ejemplo de Analgésicos
29
 Suavidad
 𝑆2
 ¿Cuál es la marca
 preferida por los 𝐴
 Segmentos 1 y 2? 𝐵
 𝑆1
 Efectividad

[pág. 30]
Modelo de Vector Ideal
 Ejemplo de Analgésicos
30
 Suavidad
 𝑆2
 𝑆2𝐴
 𝐴
 𝐵
 𝑆1
 𝑆1𝐴 Efectividad

[pág. 31]
Modelo de Vector Ideal
 Ejemplo de Analgésicos
31
 Suavidad
 𝑆2
 𝑆2𝐴
 𝑆2𝐵 𝐴
 𝐵
 𝑆1
 𝑆1𝐴 𝑆1𝐵 Efectividad

[pág. 32]
Enfoque de Vector Ideal en la Práctica
32
  Método simple de implementación de enfoque de vector ideal
  Participante declara preferencia por cada marca en cierta
 escala (ej. 1-7)
  Regresión de preferencias declaradas sobre “factor scores”
 entrega coordenadas por donde pasa vector de preferencias
 𝑝𝑟𝑒𝑓𝑘 = 𝛽1 𝑓1𝑘 + 𝛽2 𝑓2𝑘 + 𝑢𝑘

[pág. 33]
Representación de Preferencias
 Modelo de Punto Ideal
33
  Clientes poseen un
 nivel ideal del atributo Preferencia
  Puntos localizados más
 lejos del punto ideal
 son menos preferidos
  ¿Ejemplos?
 Punto Ideal
 Atributo

[pág. 34]
Enfoque de Punto Ideal: Interpretación
34
 Punto
 Ideal (I)
 d(I,A)
 d(I,B)
 A
 B

[pág. 35]
Modelo de Punto Ideal
 Ejemplo de Cervezas
35
 Fuerte
 𝑆2
 𝐴
Económica Premium
 𝐵
 𝑆1
 Light

[pág. 36]
Modelo de Punto Ideal
 Ejemplo de Cervezas
36
 Fuerte
 𝑆2
 𝐴
Económica Premium
 𝐵
 𝑆1
 Light

[pág. 37]
Modelo de Punto Ideal
 Ejemplo de Cervezas
37
 Fuerte
 𝑆2
 𝐴 ≻𝑆2 𝐵
 𝐴
 𝐵 ≻𝑆1 𝐴
Económica Premium
 𝐵
 𝑆1
 Light

[pág. 38]
Enfoque de Punto Ideal en la Práctica
38
  Método simple para implementar enfoque de punto
 ideal
  Introducimos “marca ideal” como estímulo adicional a
 ser evaluado por clientes
  Participante evalúa marca ideal en cada uno de los
 atributos incluidos
  Localización de ubicación de marca ideal “promedio”
 para cada segmento

[pág. 39]
Caso Cereales para el Desayuno:
 Representación de Preferencias
39
  Dimensiones:
  Saludable
  Económica
  ¿Vector Ideal o Punto Ideal?
  Datos de preferencias para 3 segmentos de clientes
  Escala 1-7

[pág. 40]
Preferencias Declaradas
 Cereales Para el Desayuno
40
 Nota: Evaluaciones en escala 1-7

[pág. 41]
Preferencias Estandarizadas
41

[pág. 42]
¿Cómo representamos preferencias en el
 espacio 𝑓1 − 𝑓2?
42
  Proyección de preferencias (estandarizadas) sobre
 espacio de factores
  Estimación de ecuación de regresión:
 𝑝𝑠𝑘 = 𝛽1 𝑓1𝑘 + 𝛽2 𝑓2𝑘 + 𝑢𝑘
 Preferencia
 declarada por
 marca 𝑘 de
 segmento 𝑠 “Factor scores” de Marca 𝑘

[pág. 43]
Estimación de Coordenadas de Vectores
 de Preferencias: Datos
43

[pág. 44]
44

[pág. 45]
45

[pág. 46]
Mapa Conjunto (Percepciones-Preferencias)
 Cereales para el Desayuno
46

[pág. 47]
Mapa Conjunto
 Cereales para el Desayuno
47

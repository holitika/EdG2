# Marketing Analytics · clase20_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 EVALUACIÓN DE MODELOS DE
 CLASIFICACIÓN
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Clase Anterior: Árboles de Decisión
2
  Uso de árboles de decisión en predicción de respuesta
  Modelo no paramétrico: Conjunto de reglas de división
  Objetivo: reducción de incertidumbre (respecto a
 probabilidad de respuesta)
  Concepto de entropía (Shannon, 1948)
  Reglas de detención regulan profundidad del árbol

[pág. 3]
Implementación en R
3
 fórmula clasificación
 Nota: Reglas de detención (por default):
 • Mínimo número de observaciones en nodo = 20
 • Ajuste (reducción de incertidumbre) superior a 0,01 (cp)

[pág. 4]
library(rpart.plot)
 rpart.plot(churn_tree, box.palette = "RdBu", shadow.col = "gray", nn = TRUE)
 1
 0
 0.36
 100%
 2
 yes tenure >= 11 no 3 Predicción si hoja
 0 1
 0.10 0.90 % de “1s”
 68% 32%
 % de clientes
 ptr >= 4 ptr >= 5
 5 6
 1 0
 0.68 0.42
 5% 4%
 tenure >= 15 tenure >= 8
 4 10 11 12 13 7
 0 0 1 0 1 1
 0.05 0.08 0.78 0.31 0.95 0.97
 62% 1% 4% 3% 1% 29%
4

[pág. 5]
Descripción de Nodos
5

[pág. 6]
Árboles de Decisión: Pros y Cons
6
  Fortalezas
  Intuitivos
  Altamente flexibles (capaces de ajustar relaciones no
 lineales incluyendo interacciones)
  Debilidades
  Alta varianza (tendencia a “overfit”)
  Computacionalmente costosos

[pág. 7]
Potenciales Soluciones
7
  Métodos de Ensamble (“Ensemble Methods”)
  Ej. Random Forests, Boosting (e.g., XGBoost)
  Idea básica:
  Ajustar modelo a muchos sets de datos distintos (más
 simples que original)
  Combinar predicciones de cada uno de los modelos

[pág. 8]
RANDOM FORESTS
 MÉTODO DE ENSAMBLE BASADO EN DOS IDEAS BÁSICAS
 ❑ “BAGGING” (bootstrap aggregating)
 ▪ Obtenemos muchos sets de datos vía bootstrapping
 ▪ Ajustamos un árbol de decisión a cada set de datos
 ▪ Combinamos las predicciones de los árboles (vía voto por mayoría)
 ❑ SELECCIÓN ALEATORIA DE FEATURES
 ▪ Cada árbol utiliza sólo un subconjunto de features
 ▪ Contribuye a que modelos individuales sean independientes entre
 sí (reduciendo varianza de predicciones)
 ▪ Reducción de costos computacionales
8

[pág. 9]
Idea de “Bootstrapping”
9
 Fuente: https://towardsdatascience.com/ensemble-methods-bagging-boosting-and-stacking-c9214a10a205

[pág. 10]
MÉTODOS BASADOS EN ÁRBOLES
 RESUMEN
10
  Árboles de decisión altamente flexibles e intuitivos
  Sin embargo, son inestables; presentan alta variabilidad y
 tendencia al sobreajuste
  Random Forests permiten
  Reducir varianza
  Conseguir mejores predicciones fuera de muestra
  En años recientes han mostrado mejor desempeño que
 algoritmos basados en ANN en predicción de datos
 estructurados (organizados tabularmente)

[pág. 11]
Uso de Modelación Predictiva en Fuga
11
  Firmas proactivas buscan anticipar fuga de clientes
 ¿Quiénes son más
 propensos a la fuga?
 Renovación
 0 6 12
 Meses desde
 Renovación

[pág. 12]
Uso de Modelación Predictiva en Fuga
12
  Modelo predictivo usa datos de clientes que ya
 completaron ciclo de renovación
  Features: Características de comportamiento (uso
 de servicio, respuesta a ofertas, contactos con
 servicio al cliente) y demográficas (en mes 6)
  Target: Churn (0-1) en mes 12

[pág. 13]
USO DE MODELACIÓN PREDICTIVA EN FUGA
 CLIENTES OBSERVADOS POR 12 MESES CLIENTES QUE LLEVAN 6 MESES
 Variables predictivas: Variables predictivas:
 - Usos - Usos
 - Respuestas - Respuestas
 - Interacciones con call center - Interacciones con call center
 - Variables sociodemográficas - Variables sociodemográficas
 Resultado: Churn o No Churn Resultado Desconocido
 Estimación de Modelo Si modelo predice bien
 Predicción Predicción
 de Churn de Churn
 Fuente: Adaptado de Anderson & Zettelmeyer (2021)

[pág. 14]
¿Cómo Evaluar Poder Predictivo del
 Modelo?
14
  Problema: Para determinar si el modelo predice bien
 necesitamos probarlo en “nueva data”

[pág. 15]
¿Cómo Evaluar Poder Predictivo del
 Modelo?
15
  Problema: Para determinar si el modelo predice bien
 necesitamos probarlo en “nueva data”
  Solución: Partición aleatoria de datos históricos
  Muestra de entrenamiento (training) usada en estimación
  Muestra de validación (testing) usada en evaluación
  Si modelo predice con precisión, lo aplicamos a datos
 de clientes que llevan 6 meses para estimar su
 probabilidad de fuga y dirigir programas

[pág. 16]
USO DE MODELACIÓN PREDICTIVA EN FUGA
 CLIENTES OBSERVADOS POR 12 MESES CLIENTES QUE LLEVAN 6 MESES
 Variables predictivas: Variables predictivas:
 - Usos - Usos
 - Respuestas - Respuestas
 - Interacciones con call center - Interacciones con call center
 - Variables sociodemográficas - Variables sociodemográficas
 Resultado: Churn o No Churn Resultado Desconocido
 Estimación de Modelo Si modelo predice bien
 Predicción Predicción
 de Churn de Churn
 Muestra de Entrenamiento Muestra de Prueba Fuente: Adaptado de Anderson & Zettelmeyer (2021)

[pág. 17]
Evaluación de Modelos de Clasificación
17
  Métricas basadas en matriz de confusión
  Sensitivity (Recall)
  Specificity
  Accuracy
  Precision
  F1 measure
  Area bajo la curva ROC (AUC-ROC)

[pág. 18]
Concepto de Umbral de Clasificación
18
  Modelos predictivos entregan una predicción de
 probabilidad de churn
  Para clasificar a un cliente como churner es
 necesario definir un umbral de clasificación 𝑤
 Pr 𝐶ℎ𝑢𝑟𝑛 ≥ 𝑤 ⟹ 𝐶ℎ𝑢𝑟𝑛𝑒𝑟
 Selección de w divide la muestra entre positivos (churners)
 y negativos (no-churners)

[pág. 19]
Matriz de Confusión
19
  Dado un cierto valor de 𝑤 (típicamente 0.5)
 construimos la matriz de confusión:
 Observación
 Churn No Churn
 Churn TP FP
 Predicción
 No Churn FN TN

[pág. 20]
Matriz de Confusión: Ejemplo
20
 • 𝑤 = 0.5
 Observación
 Churn No Churn
 Churn 132 89 221
 Predicción
 No 479 2300 2779
 Churn
 611 2389 3000

[pág. 21]
Matriz de Confusión: Ejemplo
21
 • 𝑤 = 0.2
 Observación
 Churn No Churn
 Churn 421 751 1172
 Predicción
 No 190 1638 1828
 Churn
 611 2389 3000

[pág. 22]
Métricas Basadas en Matriz de Confusión
22
  Sensitivity (o Recall)
 También
 𝑇𝑃 conocida
 𝑺𝒆𝒏𝒔𝒊𝒕𝒊𝒗𝒊𝒕𝒚 = como TPR
 (𝑇𝑃 + 𝐹𝑁)
 % de churners correctamente predichos
 1 − 𝑠𝑒𝑛𝑠𝑖𝑡𝑖𝑣𝑖𝑡𝑦 = Pr{𝐸𝑟𝑟𝑜𝑟 𝑇𝑖𝑝𝑜 𝐼𝐼}

[pág. 23]
Sensitivity (Recall)
23
 • 𝑤 = 0.5
 Observación
 Churn No Churn
 𝑇𝑃
 Churn 132 89 221 𝑺𝒆𝒏𝒔𝒊𝒕𝒊𝒗𝒊𝒕𝒚 =
Predicción
 (𝑇𝑃 + 𝐹𝑁)
 No 479 2300 2779
 Churn
 611 2389 3000

[pág. 24]
Métricas Basadas en Matriz de Confusión
24
  Specificity
 𝑇𝑁
 𝑺𝒑𝒆𝒄𝒊𝒇𝒊𝒄𝒊𝒕𝒚 =
 (𝑇𝑁 + 𝐹𝑃)
 % de no-churners correctamente predichos
 1 − 𝑠𝑝𝑒𝑐𝑖𝑓𝑖𝑐𝑖𝑡𝑦 = 𝐹𝑃𝑅
 1 − 𝑠𝑝𝑒𝑐𝑖𝑓𝑖𝑐𝑖𝑡𝑦 = Pr{𝐸𝑟𝑟𝑜𝑟 𝑇𝑖𝑝𝑜 𝐼}

[pág. 25]
Specificity
25
 • 𝑤 = 0.5
 Observación
 Churn No Churn
 𝑇𝑁
 Churn 132 89 221 𝑺𝒑𝒆𝒄𝒊𝒇𝒊𝒄𝒊𝒕𝒚 =
Predicción
 (𝑇𝑁 + 𝐹𝑃)
 No 479 2300 2779
 Churn
 611 2389 3000

[pág. 26]
Métricas Basadas en Matriz de Confusión
26
  Accuracy
 𝑇𝑃 + 𝑇𝑁
 𝑨𝒄𝒄𝒖𝒓𝒂𝒄𝒚 =
 (𝑇𝑃 + 𝐹𝑁 + 𝑇𝑁 + 𝐹𝑃)
 % de observaciones correctamente predichas

[pág. 27]
Accuracy
27
 • 𝑤 = 0.5
 Observación
 Churn No Churn
 𝑇𝑃 + 𝑇𝑁
 Churn 132 89 221 𝑨𝒄𝒄𝒖𝒓𝒂𝒄𝒚 =
Predicción
 𝑇𝑜𝑡𝑎𝑙
 No 479 2300 2779
 Churn
 611 2389 3000

[pág. 28]
Métricas Basadas en Matriz de Confusión
28
  Precision
 𝑇𝑃
 𝑷𝒓𝒆𝒄𝒊𝒔𝒊𝒐𝒏 =
 (𝑇𝑃 + 𝐹𝑃)
 % de predicciones de churn correctas

[pág. 29]
Precision
29
 • 𝑤 = 0.5
 Observación
 Churn No Churn
 𝑇𝑃
 Churn 132 89 221 𝑷𝒓𝒆𝒄𝒊𝒔𝒊𝒐𝒏 =
Predicción
 (𝑇𝑃 + 𝐹𝑃)
 No 479 2300 2779
 Churn
 611 2389 3000

[pág. 30]
Métricas Basadas en Matriz de Confusión
30
  𝑀𝑒𝑑𝑖𝑑𝑎 𝐹1
 𝑅𝑒𝑐𝑎𝑙𝑙 ∙ 𝑃𝑟𝑒𝑐𝑖𝑠𝑖𝑜𝑛
 𝑭𝟏 𝒎𝒆𝒂𝒔𝒖𝒓𝒆 = 2 ∙
 𝑅𝑒𝑐𝑎𝑙𝑙 + 𝑃𝑟𝑒𝑐𝑖𝑠𝑖𝑜𝑛
 Media armónica entre Recall y Precision
 𝐹1 𝑚𝑒𝑎𝑠𝑢𝑟𝑒 ∈ (0, 1]

[pág. 31]
Curva ROC ( y AUC)
31
  Herramienta muy utilizada en evaluación de
 desempeño de modelos de clasificación
  Gráfico de valores de TPR (sensitivity o recall) y
 FPR para distintos valores de w
  En general ↓ 𝑤 →↑ 𝑇𝑃𝑅, ↑ 𝐹𝑃𝑅
  Área bajo la curva ROC (AUC-ROC) provee una
 métrica global de desempeño

[pág. 32]
Curva ROC: Ejes
32
 𝑇𝑃 𝑇𝑃𝑅: Proporción de churners
 𝑇𝑃𝑅 = correctamente clasificados como
 𝑇𝑃 + 𝐹𝑁
 churners
 𝐹𝑃𝑅: Proporción de no-churners
 incorrectamente clasificados como
 churners
 𝐹𝑃
 0 𝐹𝑃𝑅 =
 𝐹𝑃 + 𝑇𝑁

[pág. 33]
Curva ROC: Interpretación
33
 𝑇𝑃
 𝑇𝑃𝑅 =
 𝑇𝑃 + 𝐹𝑁
 1
 𝑤=1
 𝐹𝑃
 0 1 𝐹𝑃𝑅 =
 𝐹𝑃 + 𝑇𝑁

[pág. 34]
Curva ROC: Interpretación
34
 𝑇𝑃
 𝑇𝑃𝑅 =
 𝑇𝑃 + 𝐹𝑁
 1
 • Si 𝑤 = 1, ningún cliente es
 clasificado como “churner”
 • 𝐹𝑃 = 𝑇𝑃 = 0
 ⟹ 𝐹𝑃𝑅 = 𝑇𝑃𝑅 = 0
 𝑤=1
 𝐹𝑃
 0 1 𝐹𝑃𝑅 =
 𝐹𝑃 + 𝑇𝑁

[pág. 35]
Curva ROC: Interpretación
35
 𝑇𝑃 𝑤=0
 𝑇𝑃𝑅 =
 𝑇𝑃 + 𝐹𝑁
 1
 𝑤=1
 𝐹𝑃
 0 1 𝐹𝑃𝑅 =
 𝐹𝑃 + 𝑇𝑁

[pág. 36]
Curva ROC: Interpretación
36
 𝑇𝑃 𝑤=0
 𝑇𝑃𝑅 =
 𝑇𝑃 + 𝐹𝑁
 1
 • Si 𝑤 = 0, ningún cliente
 clasificado como “no-churner”
 • 𝑇𝑁 = 𝐹𝑁 = 0
 ⟹ 𝐹𝑃𝑅 = 𝑇𝑃𝑅 = 1
 𝑤=1
 𝐹𝑃
 0 1 𝐹𝑃𝑅 =
 𝐹𝑃 + 𝑇𝑁

[pág. 37]
Curva ROC: Interpretación
37
 𝑇𝑃 𝑤=0
 𝑇𝑃𝑅 =
 𝑇𝑃 + 𝐹𝑁
 1
 • A medida que w baja de 1 tanto
 la 𝑇𝑃𝑅 como la 𝐹𝑃𝑅 tienden a
 aumentar
 • Cuanto más aumente TPR en
 relación al aumento en FPR mejor
 el clasificador
 𝑤=1
 𝐹𝑃
 0 1 𝐹𝑃𝑅 =
 𝐹𝑃 + 𝑇𝑁

[pág. 38]
Curva ROC: Interpretación
38
 • ¿Cómo cambian FPR y TPR para
 𝑇𝑃 𝑤=0
 𝑇𝑃𝑅 = distintos valores de w?
 𝑇𝑃 + 𝐹𝑁
 1 • Trade-off entre FPR y TPR
 𝑤=1
 𝐹𝑃
 0 1 𝐹𝑃𝑅 =
 𝐹𝑃 + 𝑇𝑁

[pág. 39]
Ejemplo
39
 • 𝑤 = 0.5
 Observación
 𝑇𝑃 132
 Churn No Churn 𝑇𝑃𝑅 = =
 𝑇𝑃 + 𝐹𝑁 132 + 479
 Churn 132 89 221
 Predicción
 𝑇𝑃𝑅 = 0.216
 No 479 2300 2779 𝐹𝑃 89
 𝐹𝑃𝑅 = =
 Churn 𝐹𝑃 + 𝑇𝑁 89 + 2300
 𝐹𝑃𝑅 = 0.037
 611 2389 3000

[pág. 40]
Ejemplo
40
 • 𝑤 = 0.2
 Observación
 𝑇𝑃 421
 Churn No Churn 𝑇𝑃𝑅 = =
 𝑇𝑃 + 𝐹𝑁 421 + 190
 Churn 421 751 1172
Predicción
 𝑇𝑃𝑅 = 0.689
 No 190 1638 1828 𝐹𝑃 751
 𝐹𝑃𝑅 = =
 Churn 𝐹𝑃 + 𝑇𝑁 751 + 1638
 𝐹𝑃𝑅 = 0.314
 611 2389 3000

[pág. 41]
Curva ROC
41
 • ¿Cómo cambian FPR y TPR para
 𝑇𝑃 Clasificador perfecto 𝑤=0
 𝑇𝑃𝑅 = distintos valores de w?
 𝑇𝑃 + 𝐹𝑁
 1
 • Trade-off entre FPR y TPR
 𝑤=1
 𝐹𝑃
 0 1 𝐹𝑃𝑅 =
 𝐹𝑃 + 𝑇𝑁

[pág. 42]
ID Churn 𝑝 Clasificación
 w=1 w=0.98 w=0.02 w=0
 1 1 0.99 0 1 1 1
 2 1 0.99 0 1 1 1
 3 1 0.99 0 1 1 1
 4 0 0.01 0 0 0 1
 5 0 0.01 0 0 0 1
 6 0 0.01 0 0 0 1
 7 0 0.01 0 0 0 1
 8 0 0.01 0 0 0 1
 9 0 0.01 0 0 0 1
 10 0 0.01 0 0 0 1
 TPR 0 1 1 1
42
 FPR 0 0 0 1

[pág. 43]
Curva ROC
43
 • ¿Cómo cambian FPR y TPR para
 𝑇𝑃 Clasificador perfecto 𝑤=0
 𝑇𝑃𝑅 = distintos valores de w?
 𝑇𝑃 + 𝐹𝑁
 1
 • Trade-off entre FPR y TPR
 Clasificador Aleatorio
 𝑤=1
 𝐹𝑃
 0 1 𝐹𝑃𝑅 =
 𝐹𝑃 + 𝑇𝑁

[pág. 44]
AUC-ROC
44
  Cuanto más cerca la curva ROC de la esquina
 superior izquierda mejor el performance del modelo
  Capturado por área bajo la curva (AUC)
  ¿Interpretación?
 “Si tomamos aleatoriamente pares de clientes, 1 churner y 1 no-churner,
 ¿Qué probabilidad hay de que la probabilidad predicha de churn del
 churner sea mayor a la del no-churner”

[pág. 45]
CURVA ROC Y AUC
 AUC:
 0.9 – 1.0 = Excelente
 0.8 – 0.9 = Bueno
 0.7 – 0.8 = Regular
 < 0.6 = Pobre

[pág. 46]
Aplicación: Predicción de Churn en Banco
46
  Banco europeo interesado en predicción de churn
  Datos para 10.000 clientes
  Features incluyen
  Características geodemográficas (edad, género, país de
 residencia)
  Características asociadas a comportamiento (riesgo
 crediticio, antiguedad, número de productos, saldo en
 cuenta corriente, etc.)

[pág. 47]
Estructura de Datos
47

[pág. 48]
Descripción de Datos
48

[pág. 49]
Descripción de Datos
49

[pág. 50]
Partición de Muestra
50

[pág. 51]
Modelo de Regresión Logística
 Entrenamiento del Modelo
51

[pág. 52]
Modelo de Regresión Logística
 Uso en Predicción Test data
52

[pág. 53]
Modelo de Regresión Logística
 AUC-ROC
53

[pág. 54]
Árbol de Decisión
 Entrenamiento
54

[pág. 55]
55

[pág. 56]
Árbol de Decisión
 Uso en Predicción
56

[pág. 57]
Modelo de Árbol de Decisión
 AUC-ROC
57

[pág. 58]
Random Forests
 Entrenamiento del Modelo
58

[pág. 59]
Random Forests
 Uso en Predicción
59

[pág. 60]
Random Forests
 AUC-ROC
60

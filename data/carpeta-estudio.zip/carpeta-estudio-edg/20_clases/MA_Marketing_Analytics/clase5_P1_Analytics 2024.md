# Marketing Analytics · clase5_P1_Analytics 2024

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 ESTUDIOS CUALITATIVOS
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
2

[pág. 3]
Importancia de Estudios Cualitativos en
 Marketing
3
  Métodos cuantitativos nos permiten responder
 preguntas del tipo: ¿Qué/Cuál? y ¿Cuánto?
  ¿Qué proporción de nuestros clientes compra usando
 canales online? ¿Cuál es nuestro NPS promedio? ¿Qué
 segmentos existen en nuestra base de clientes?
  ¿Cuánto gasta un cliente promedio por visita? ¿Cuánto
 aumentarían mis ventas si hacemos una campaña
 publicitaria en RRSS vs otros medios digitales?

[pág. 4]
Importancia de Estudios Cualitativos en
 Marketing
4
  Preguntas respecto a motivaciones y percepciones
 del consumidor fuera del ámbito de métodos
 cuantitativos
  Métodos cualitativos permiten responder este tipo
 de preguntas
  ¿Por qué? ¿Cómo?
 Conocimiento más profundo del consumidor

[pág. 5]
Agenda
5
  Aplicaciones de estudios cualitativos a distintas
 áreas de Marketing
  Estudios más comúnmente utilizados
  Entrevistas
  Focus Groups
  Estudios Etnográficos
  Otras metodologías de la era digital

[pág. 6]
Aplicaciones de Métodos Cualitativos en Marketing
 Áreas Estratégicas
6
 Área Pregunta
 Segmentación ¿Por qué algunos grupos de consumidores priorizan ciertos
 beneficios al tomar una decisión de compra?
 Posicionamiento ¿Por qué los consumidores perciben nuestra marca de una
 cierta manera? ¿Cómo esa percepción evoluciona a lo largo
 del recorrido de compra?

[pág. 7]
Aplicaciones de Métodos Cualitativos en Marketing
 Áreas Tácticas
7
 Área Pregunta
 Precio ¿Por qué los consumidores perciben el precio como
 justo/injusto?
 Producto ¿Cómo interactúan los consumidores con nuestro producto?
 ¿Por qué ciertas características funcionan/fallan?
 Comunicaciones ¿Por qué ciertos mensajes resuenan mejor con ciertas
 audiencias?
 Distribución ¿Cómo difieren los procesos de toma de decisiones entre
 canales de compra? ¿Por qué?

[pág. 8]
¿Qué entendemos por métodos
 cualitativos?
8
 "Un conjunto de técnicas interpretativas que buscan describir,
 decodificar, traducir y, en general, comprender el significado, no
 la frecuencia, de ciertos fenómenos que ocurren más o menos
 naturalmente en el mundo social.”
 (Van Maanen,1979)
 Objetivo es obtener una comprensión profunda de un fenómeno

[pág. 9]
Características de Técnicas Cualitativas
9
  Apropiados para responder preguntas del tipo ¿Cómo?
 y ¿Por qué? (vs. ¿Qué/Cuál? ¿Cuánto?)
  Énfasis en interpretación (vs. generalización)
  Métodos estadísticos rara vez utilizados
  “Thick Data” (vs. Big Data)
  Datos no estructurados
  Investigador/a altamente involucrado/a en el
 fenómeno

[pág. 10]
Metodologías Cualitativas Tradicionales
10
  Entrevistas en Profundidad
  Focus Groups
  Estudios etnográficos

[pág. 11]
Entrevistas en Profundidad
11
  Técnica de verbalización directa
  Objetivo es entender perspectiva de entrevistado
  Descubrir valores, necesidades, motivaciones,
 actitudes
  Atención a entrevistado induce sentimientos de
 intimidad y privacidad favoreciendo apertura y
 descubrimiento de insights + profundos
  Amplio continuo en dimensión formal-informal

[pág. 12]
EP varían en grado de formalidad
12
 ▪ No estructuradas ▪ Altamente estructuradas
 ▪ No dirigidas ▪ Completamente dirigidas
 ▪ Conversacionales ▪ Administradas idénticamente
 entre informantes
 Informales Formales
 • Amplia recolección • Fácil de analizar
 de información • Podría no capturar
 • Difíciles de analizar información relevante

[pág. 13]
Entrevistas en Profundidad
 Características
13
  Basadas en preguntas de respuesta abierta
  Preguntas proceden de lo más general a lo más
 particular y focalizado
  Potencial uso de técnicas proyectivas
  Típicamente individuales
  Duración: 1-2 horas
  Instalación especial o ambiente natural de informante
  Número de informantes: 5-50

[pág. 14]
Ejemplo de uso de EP: PepsiCo
14
  ¿Cómo rasgos (valores, actitud frente
 a la vida, necesidades) y modelo
 parental afectan hábitos alimenticios
 de la familia?
  30 EP en casa de madres en
 presencia de hijos (1-12 años)
  2-3 horas
  Uso de técnicas proyectivas (“yo en
 10 años”)
  Uso en estrategias de desarrollo de
 productos (snacks)

[pág. 15]
15 Fuente: Maison (2018)

[pág. 16]
Desafíos y Limitaciones de EP
16
  Costosas de planear, implementar y analizar
  Potencialmente afectada por sesgos:
  Capacidad/estilo de entrevistador/a
  Memoria de entrevistado/a, deseabilidad social

[pág. 17]
Focus Groups
17
 ❑ Discusión grupal de tópico que es “foco de la conversación”
 ❑ Característica distintiva: Uso explícito de interacción de grupo
 para producir datos e insights que serían menos accesibles sin
 esa interacción.
 ▪ Estimular nuevas ideas y concepto de productos
 ▪ Diagnosticar potenciales problemas con nuevo programa/producto
 ▪ Generar impresiones sobre productos, programas, servicios, etc.

[pág. 18]
Focus Groups
 Características
18
 ❑ 8-12 personas (selección usando segmentación)
 ▪ Reciben incentivo por participación
 ❑ Dirigido por moderador profesional
 ▪ Promueve interacción entre participantes
 ▪ Asegura que discusión no se desvía del tópico
 ❑ Potencial uso de técnicas proyectivas

[pág. 19]
Aproximación a Tamaño Muestral
19
 ❑ Cuanto mayor 𝑛 menor la probabilidad de no
 observar un comportamiento significativo o registrar
 una percepción
 ❑ Probabilidad de no observar comportamiento o
 percepción:
 𝑝 = (1 − 𝜋)𝑛
 incidencia de
 comportamiento en
 población

[pág. 20]
Tamaño Muestral y Probabilidad de
 Capturar Comportamiento
20
 Probabilidad de dejar de capturar observación clave en función de tamaño muestral
 Incidencia Poblacional 10 20 30 40 50 60 100 200
 𝜋\n
 0.50 0.0010 0.0000 0.0000 0.0000 0.0000 0.0000 0.0000 0.0000
 0.33 0.0182 0.0003 0.0000 0.0000 0.0000 0.0000 0.0000 0.0000
 0.25 0.0563 0.0032 0.0002 0.0000 0.0000 0.0000 0.0000 0.0000
 0.20 0.1074 0.0115 0.0012 0.0001 0.0000 0.0000 0.0000 0.0000
 0.10 0.3487 0.1216 0.0424 0.0148 0.0052 0.0018 0.0000 0.0000
 0.05 0.5987 0.3585 0.2146 0.1285 0.0769 0.0461 0.0059 0.0000
 0.01 0.9044 0.8179 0.7397 0.6690 0.6050 0.5472 0.3660 0.1340

[pág. 21]
Principales Usos de Focus Groups
21
  Determinar causas de problemas y desarrollar hipótesis
  Conocer y entender al consumidor: ocasiones consumo, usos,
 necesidades
  Desarrollar nuevos productos: ventajas, desventajas, usos
  Desarrollar y evaluar publicidad o promociones: atributos, (des)
 ventajas
  Posicionar productos/marcas: atributos diferenciadores
  Estudios de uso de producto

[pág. 22]
Ejemplos de uso de Focus Groups
22
 • ¿Qué buscan usuarios de una red social?
 • ¿Con qué aspectos de la plataforma se encuentran
 insatisfechos usuarios de Facebook?
 • Mayor queja: “News feed” demasiado lleno
 • Idea: Plataforma simplificada para compartir artículos,
 entretención, noticias y opiniones
 • Realiza focus groups con niños pequeños
 • Alianzas con jardines infantiles y colegios en LA
 • Objetivo: Descubrir qué personajes prefieren los niños,
 feedback sobre series de TV y opiniones sobre
 merchandising.

[pág. 23]
Focus Groups versus Entrevistas en
 Profundidad
23
 Ventajas de FG Desventajas de FG
  Mayor involucramiento debido a  Potencial de contaminación
 interacción con opinión de otras personas
  Mayor participación espontánea  Persona podría sentirse
 (participantes más acompañados incómoda (temas conflictivos)
 y relajados)
  No se puede juntar a las
  Menor tiempo y costo del
 moderador personas en la misma sala
 (competidores o personas de
  Respuesta más rápida difícil acceso)

[pág. 24]
Estudios Etnográficos
24
  Método observacional inmersivo
  Observación e interacción en medio ambiente natural
  Originalmente desarrollados en antropología cultural
  Características
  El grupo es estudiado en su día a día y contexto natural
  Fuentes de información: observaciones y entrevistas informales
  Extracción de significado y funciones del comportamiento del
 grupo

[pág. 25]
¿Por qué Usar Estudios Etnográficos?
25
  Comprensión más rica y auténtica de comportamientos,
 rutinas y procesos
  Capturan contexto en que consumidor interactúa con
 producto/servicio
  Descubrimiento de comportamientos implícitos y actitudes
  Proveen visión más completa de estilos de vida, creencias,
 contexto cultural
  Descubrimiento de necesidades latentes

[pág. 26]
Principales Usos de Estudios Etnográficos
26
  Diseño de productos e innovación
  Recorrido del cliente y experiencia de usuario (UX)
  Percepción de marca y relevancia cultural
  Segmentación de mercados y targeting

[pág. 27]
Ejemplo: Diseño de Nueva Ford F-150
27
 ❑ Uso de métodos observacionales en
 rediseño de nueva F-150
 ❑ Visitas a ranchos y sitios en
 construcción
 ❑ Trabajo en terreno involucró:
 ▪ 5 semanas
 ▪ 850 hrs. con clientes (inc. 4 noches)
 ▪ 1800 páginas de notas
 ▪ 600 videos
 ▪ 18.000 fotografías

[pág. 28]
Diseño de Nueva Ford F-150 2021
 Innovaciones motivadas por estudio
28
 • Palanca de cambios
 abatible permite crear área
 de trabajo plana
 • Asientos reclinables
 prácticamente planos
 permiten a clientes dormir
 cómodos
 • Puerta trasera puede
 doblarse y usarse como
 banca de trabajo
 (incluyendo vara de medir y
 abrazadera)

[pág. 29]
Ejemplo: “Bing Watching” en Netflix
29
  Algoritmo de recomendaciones usa big
 data para anticipar películas/series
 preferidas
  Para entender en profundidad
 experiencia del cliente emplea a
 antropólogos culturales
  ¿Cómo interactúan con plataforma?
  Estudios etnográficos revelaron que
 personas prefieren “maratonear”
  Impacto en modo de distribución de series

[pág. 30]
Ejemplo: Estudios Etnográficos en IKEA
30
  Líder mundial en mobiliario para el hogar
  Usa etnografía para entender estilos de
 vida, valores, aspiraciones y diseñar
 mejores productos
  Investigadores visitan hogares de clientes
 y observan cómo viven, trabajan, juegan,
 etc.
  Insight: Espacios pequeños atestados
  Solución: muebles modulares, sistemas de
 almacenamiento, etc.

[pág. 31]
Metodologías en la Era Digital
31
  Etnografía Digital (Netnografía)
  Bulletin Boards

[pág. 32]
Métodos Cualitativos: Resumen
32
  Proveen información más rica sobre: Actitudes,
 motivaciones, valores
  Metodologías más utilizadas: Entrevistas en
 profundidad, focus groups, estudios etnográficos (+
 bulletin boards y netnografía)
  Potencial uso en toma de decisiones en todas las
 áreas clave de Marketing

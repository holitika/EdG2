# Marketing Analytics · clase14_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 VALOR ECONÓMICO DEL
 CLIENTE
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Clase Anterior
2
  ¿Qué entendemos por analítica de clientes?
  Relación con estrategia de Centricidad en el Cliente
  Auditoría de Base de Clientes

[pág. 3]
Auditoría de la Base de Clientes en
 Madrigal
3
  Retailer multi-canal y multi-categoría
  Tiendas físicas + ventas online
  Vestuario, calzado, alimentos, etc.
  Programa de lealtad le permite seguir a clientes en
 el tiempo
  > 3MM de clientes en 2019
  Datos para 2016-2019

[pág. 4]
Heterogeneidad en Utilidades
4

[pág. 5]
Descomposición de Utilidad
5
 𝑈𝑡𝑖𝑙𝑖𝑑𝑎𝑑 𝑇𝑜𝑡𝑎𝑙 = #𝐶𝑙𝑖𝑒𝑛𝑡𝑒𝑠 × 𝑀𝑎𝑟𝑔𝑒𝑛 × 𝐴𝑂𝑉 × 𝐴𝑂𝐹

[pág. 6]
Descomposición de la Utilidad
6
 Fader, Hardie & Ross (2022)

[pág. 7]
Descomposición de Utilidad
7

[pág. 8]
Lentes 3 y 4: Análisis de Cohortes de
 Clientes
8
  Análisis de cohortes permite seguir a mismos clientes en
 el tiempo
  Tipos de análisis
  Descomposición de ingresos/utilidades de cohorte individual
  Análisis de repetición de compra
  Comparación de ingresos/utilidades entre cohortes (C3)

[pág. 9]
Ingresos Trimestrales de Cohorte
 Q1/2016
9
 294.450 individuos
 hicieron su primera
 compra en Madrigal el
 1er trimestre de 2016

[pág. 10]
Descomposición de Ingresos de Cohorte
10
𝐼𝑛𝑔𝑟𝑒𝑠𝑜𝑠 𝐶𝑜ℎ𝑜𝑟𝑡𝑒 = 𝑇𝑎𝑚𝑎ñ𝑜 𝑑𝑒 𝐶𝑜ℎ𝑜𝑟𝑡𝑒 × % 𝑀𝑖𝑒𝑚𝑏𝑟𝑜𝑠 𝐴𝑐𝑡𝑖𝑣𝑜𝑠 × 𝐴𝑂𝐹 × 𝐴𝑂

[pág. 11]
Descomposición de Ingresos de Cohorte
11
 Fader, Hardie & Ross (2022)

[pág. 12]
Descomposición de Ingresos de Cohorte
 (parte 1)
12

[pág. 13]
Descomposición de Ingresos de Cohorte
 (parte 2)
13

[pág. 14]
% de Cohorte que Repite Compra
14

[pág. 15]
Comparación de Resultados entre
 Cohortes
15
 $MM ‘000

[pág. 16]
Comparación entre Cohortes: Gráfico C3
16
  Información sobre
 adquisición y retención
 de clientes, ingresos,
 utilidades
  Crecientemente
 reportado como parte
 de EEFF

[pág. 17]
Comparación entre Cohortes: Gráfico C3
 # de Clientes
17
 Tasa de retención de
 clientes
 𝑛𝑐𝑜ℎ𝑜𝑟𝑡𝑒,𝑡
 𝑟𝑐𝑜ℎ𝑜𝑟𝑡𝑒,𝑡 = −1
 𝑛𝑐𝑜ℎ𝑜𝑟𝑡𝑒,𝑡−1

[pág. 18]
Adquisición de Nuevos Clientes
18
 1832
 1492 1517
 1273
 ‘000

[pág. 19]
Comparación entre Cohortes: Gráfico C3
 Utilidades ($ MM)
19

[pág. 20]
¿Es Saludable la Base de Clientes de
 Madrigal?
20
  Adquisición de Clientes
  Retención
  Rentabilidad (profits)

[pág. 21]
Meta de Utilidades y Adquisición de
 Clientes
21
  Meta de utilidades 2020 = $ MM 320
  Tasa de retención de utilidades = 64% (supuesto)
  Utilidad por cliente adquirido = $72 (supuesto)
  ¿Cuántos clientes necesita adquirir Madrigal en
 2020 para cumplir su meta? ¿Es factible?

[pág. 22]
22 Valor de Vida del Cliente (CLV)

[pág. 23]
MÉTRICAS TRADICIONALES DE VALOR DEL CLIENTE
 ▪ ¿Cómo estimamos el valor económico del cliente?
 ▪ Métricas tradicionales
 • Gasto total
 • Valor pasado
 • “Share of wallet”
 • RFM
 Problema de métricas tradicionales: Foco en el pasado
23

[pág. 24]
CLIENTE COMO ACTIVO
▪ Estrategia de centricidad en el cliente visualiza a clientes como activos
▪ Adquisición de clientes requiere inversión inicial
 • Publicidad, marketing directo, sampling, etc.
▪ Cliente genera flujos a lo largo de su relación con la empresa
 • Flujos impactados por decisiones de desarrollo y retención
 Fuente: theta.com

[pág. 25]
Valor de Vida del Cliente (CLV)
25
 ▪ Métrica clave en organización cliente-céntrica
 “VP de flujos presentes y futuros
 generados por el cliente a lo largo
 de su relación con la compañía”
 “… unidad de medida sobre la cual se construyen la
 centricidad en el cliente y las firmas centradas en el cliente”
 Fader (2012)

[pág. 26]
Valor de Vida del Cliente: Fórmula
26
 σ𝑇𝑡=1 𝑃(𝐴𝑐𝑡𝑖𝑣𝑜𝑡 ) ∙ 𝑀𝑎𝑟𝑔𝑒𝑛𝑡
 𝐸 𝐶𝐿𝑉 =
 (1 + 𝑑)𝑡

[pág. 27]
Valor de Vida del Cliente: Fórmula
27
 σ𝑇𝑡=1 𝑃(𝐴𝑐𝑡𝑖𝑣𝑜𝑡 ) ∙ 𝑀𝑎𝑟𝑔𝑒𝑛𝑡
 𝐸 𝐶𝐿𝑉 =
 (1 + 𝑑)𝑡
 Flujos futuros
 son inciertos

[pág. 28]
Valor de Vida del Cliente: Fórmula
28
 σ𝑇𝑡=1 𝑃(𝐴𝑐𝑡𝑖𝑣𝑜𝑡 ) ∙ 𝑀𝑎𝑟𝑔𝑒𝑛𝑡
 𝐸 𝐶𝐿𝑉 =
 (1 + 𝑑)𝑡
 (𝑅𝑡 −𝐶𝑡 )
 𝑅𝑡 = 𝐼𝑛𝑔𝑟𝑒𝑠𝑜𝑠 𝑔𝑒𝑛𝑒𝑟𝑎𝑑𝑜𝑠 𝑝𝑜𝑟 𝑒𝑙 𝑐𝑙𝑖𝑒𝑛𝑡𝑒 𝑒𝑛 𝑡
 𝐶𝑡 = 𝐶𝑜𝑠𝑡𝑜𝑠 𝑑𝑒 𝑣𝑒𝑛𝑡𝑎, 𝑚𝑎𝑟𝑘𝑒𝑡𝑖𝑛𝑔 𝑦 𝑠𝑒𝑟𝑣𝑖𝑐𝑖𝑜𝑠 𝑒𝑛 𝑡

[pág. 29]
Valor de Vida del Cliente: Fórmula
29
 σ𝑇𝑡=1 𝑃(𝐴𝑐𝑡𝑖𝑣𝑜𝑡 ) ∙ 𝑀𝑎𝑟𝑔𝑒𝑛𝑡
 𝐸 𝐶𝐿𝑉 =
 (1 + 𝑑)𝑡
 Tasa de descuento considera riesgos
 asociados a flujos futuros

[pág. 30]
¿Cuánto tiempo hacia el futuro?
 ▪ Subjetivo y específico a la industria
 ▪ Típicamente 3-7 años (T más alto en bienes durables)
 ▪ Mayor parte de CLV capturado en primeros 3 años (Gupta & Lehmann, 2005)
 ▪ Dado P 𝐴𝑐𝑡𝑖𝑣𝑜𝑡 decreciente en el tiempo flujos de largo plazo se
 aproximan a cero
 ▪ Aproximación comúnmente utilizada considera horizonte indefinido
30

[pág. 31]
Aplicaciones de CLV
 Adquisición ¿Obsequio a clientes?
 Cota máxima a invertir en Pago a vendedor por adquisición
 01
 adquisición de un nuevo
 cliente. ¿Reducción de upfront fee?
 Desarrollo Evaluación de programas
 Valoración del cliente por Incentivos a ofrecer por aumento
 02
 distintas ofertas de la en compras
 firma.
 Retención Reducción de cargos por
 Incentivos asociados a servicio para clientes en riesgo
 programa de retención.
 03
 ¿Reducir tiempo de espera en
 Mejoras en servicio. call center?

[pág. 32]
Estimación de CLV
32
  Tres grandes componentes
 1. Frecuencia de compra (# de transacciones por
 período)
 2. Valor de transacciones por período
 3. Probabilidad de que cliente permanezca activo

[pág. 33]
Importancia del Contexto de Negocios
33
 Contractual No Contractual
 Telecom, bancos,
 Retail, lineas aéreas,
 plataformas de
 hoteles
 streaming.
 • Fuga observable • Fuga
 noobservable
 • Flujos menos
 volátiles • Flujos menos
 predecibles

[pág. 34]
CLIENTES EN CONTEXTOS CONTRACTUALES Y NO
 CONTRACTUALES
 Netflix: Suscriptores Amazon: Cuentas Activas
 Millones Millones
 STRUCTURED
250.00 350
 Make a big impact with
 300
200.00 professional slides, charts,
 infographics
 250and more.
150.00
 200
 XML
100.00 150
 E-MAIL
 100
 50.00
 50
 0.00
 0
 Q1 2013
 Q3 2013
 Q1 2014
 Q3 2014
 Q1 2015
 Q3 2015
 Q1 2016
 Q3 2016
 Q1 2017
 Q3 2017
 Q1 2018
 Q3 2018
 Q1 2019
 Q3 2019
 Q1 2020
 Q3 2020
 Q1 2021
 Q3 2021
 Q1 2022
 Q1 Q2 Q3 Q4 Q1 Q2 Q3 Q4 Q1 Q2 Q3 Q4 Q1
 '13 '13 '13 '13 '14 '14 '14 '14 '15 '15 '15 '15* '16
 Fuente: Statista Fuente: Statista
 Cliente activo si efectuó orden durante 12 meses
 precedentes.

[pág. 35]
CLV en Contextos Contractuales
35
  Fuga es observable
  𝑃(𝐴𝑐𝑡𝑖𝑣𝑜) directamente asociada a tasa de retención:
 # 𝑑𝑒 𝐶𝑙𝑖𝑒𝑛𝑡𝑒𝑠 𝑅𝑒𝑡𝑒𝑛𝑖𝑑𝑜𝑠
 𝑟𝑡 =
 # 𝑑𝑒 𝐶𝑙𝑖𝑒𝑛𝑡𝑒𝑠 𝑒𝑛 𝑅𝑖𝑒𝑠𝑔𝑜 𝑑𝑒 𝐹𝑢𝑔𝑎

[pág. 36]
CLV en Contextos Contractuales
36
  Fuga es observable
  𝑃(𝐴𝑐𝑡𝑖𝑣𝑜) directamente asociada a tasa de retención:
 # 𝑑𝑒 𝐶𝑙𝑖𝑒𝑛𝑡𝑒𝑠 𝑅𝑒𝑡𝑒𝑛𝑖𝑑𝑜𝑠
 𝑟𝑡 =
 # 𝑑𝑒 𝐶𝑙𝑖𝑒𝑛𝑡𝑒𝑠 𝑒𝑛 𝑅𝑖𝑒𝑠𝑔𝑜 𝑑𝑒 𝐹𝑢𝑔𝑎
 𝑇𝑎𝑠𝑎 𝑑𝑒 𝐶ℎ𝑢𝑟𝑛𝑡 = 1 − 𝑟𝑡

[pág. 37]
CLV en Contextos Contractuales
37
 ❑ Probabilidad de Cliente Activo y Tasa de Retención: Ejemplo
 𝑡=0 𝑡=1 𝑡=2 𝑡=3
 # de clientes 10.000 8.500 7.500 6.700
 𝑟
 𝑃(𝐴𝑐𝑡𝑖𝑣𝑜)

[pág. 38]
CLV en Contextos Contractuales
38
 ❑ Probabilidad de Cliente Activo y Tasa de Retención: Ejemplo
 𝑡=0 𝑡=1 𝑡=2 𝑡=3
 # de clientes 10.000 8.500 7.500 6.700
 𝑟 1,000 0,850 0,882 0,893
 𝑃(𝐴𝑐𝑡𝑖𝑣𝑜)

[pág. 39]
CLV en Contextos Contractuales
39
 ❑ Probabilidad de Cliente Activo y Tasa de Retención: Ejemplo
 𝑡=0 𝑡=1 𝑡=2 𝑡=3
 # de clientes 10.000 8.500 7.500 6.700
 𝑟 1,000 0,850 0,882 0,893
 𝑃(𝐴𝑐𝑡𝑖𝑣𝑜) 0,850 0,750 0,670
 0.85 ∙ 0.882

[pág. 40]
CLV en Contextos Contractuales
40
 𝑇 𝑡 𝑡
 1
 𝐸 𝐶𝐿𝑉 = ෍ 𝑚𝑡 ෑ 𝑟𝑖
 1+𝑑
 𝑡=1 𝑖=1
 𝑆(𝑡) Función de
 Supervivencia

[pág. 41]
Probabilidad de Supervivencia y Tasa de Retención

[pág. 42]
CLV DE CLIENTE DE NETFLIX
 Margen de Cliente de Netflix:
 Un Mes
 Ingresos $12.99
 Costo Variable $1.5
 Gasto de Marketing $0.5
 Margen de Contribución Neto $10.99
 ¿Cuánto tiempo hacia adelante? Vamos a asumir por simplicidad 5 meses
 Tasa de descuento, 𝑑 = 0.1
42

[pág. 43]
Flujos Asociados al Cliente en el Tiempo
 Supuesto: Tasa de Retención, 𝑟 = 0.97
 Mes 0 Mes 1 Mes 2 Mes 3 Mes 4
 Ingresos $12.99 $12.99 $12.99 $12.99 $12.99
 Costo Variable $1.5 $1.5 $1.5 $1.5 $1.5
 Gasto Mktg. $0.5 $0.5 $0.5 $0.5 $0.5
 Margen Neto $10.99 $10.99 $10.99 $10.99 $10.99
 P(Activo) 1.00 0.97 0.94 0.91 0.89
 Prob. de “churn” = 0.03 =(0.97)(0.97)
43

[pág. 44]
Flujos Asociados al Cliente en el Tiempo
 Margen Neto Esperado
 Mes 0 Mes 1 Mes 2 Mes 3 Mes 4
 Ingresos $12.99 $12.99 $12.99 $12.99 $12.99
 Costo Variable $1.5 $1.5 $1.5 $1.5 $1.5
 Gasto Mktg. $0.5 $0.5 $0.5 $0.5 $0.5
 Margen Neto $10.99 $10.99 $10.99 $10.99 $10.99
 P(Activo) 1.00 0.97 0.94 0.91 0.89
 Margen Esperado $10.99 $10.66 $10.34 $10.03 $9.73
 (0.97)$10.99 + (0.03)$0
44

[pág. 45]
Flujos Asociados al Cliente en el Tiempo
 Mes 0 Mes 1 Mes 2 Mes 3 Mes 4
 Ingresos $12.99 $12.99 $12.99 $12.99 $12.99
 Costo Variable $1.5 $1.5 $1.5 $1.5 $1.5
 Gasto Mktg. $0.5 $0.5 $0.5 $0.5 $0.5
 Margen Neto $10.99 $10.99 $10.99 $10.99 $10.99
 P(Activo) 1.00 0.97 0.94 0.91 0.89
 Margen Esperado $10.99 $10.66 $10.34 $10.03 $9.73
 FD 1.00 0.91 0.83 0.75 0.68
 Flujo Descontado $10.99 $9.69 $8.55 $7.54 $6.65
 CLV = $10.99 + $9.69 + $8.55 + $7.54 +$6.65 = $43.41
45

[pág. 46]
¿Es Razonable el Supuesto de Tasa de Retención
 Constante?
▪ Supuesto de tasa de retención constante permite simplificar cálculos y es muy
 utilizado
▪ Sin embargo, evidencia sugiere que tasa de retención de cohorte de clientes es
 creciente en el tiempo (¿por qué?)

[pág. 47]
¿Cómo podemos estimar la Tasa de
 Retención?
47
  Modelos de supervivencia
  Requieren proyección de variables explicativas
  Modelos estocásticos
  Ej. Modelo Beta-Geométrico (Fader & Hardie, 2007)

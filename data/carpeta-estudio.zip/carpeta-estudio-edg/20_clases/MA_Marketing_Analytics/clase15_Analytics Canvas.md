# Marketing Analytics · clase15_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 CLV EN CONTEXTOS
 CONTRACTUALES: MODELO BETA
 GEOMÉTRICO
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Clase Anterior
2
  CLV como métrica clave de organización cliente
 céntrica
  Estimación basada en tres variables clave
  Frecuencia, valor, probabilidad de mantenerse activo
  Distinción entre contextos contractuales y no
 contractuales

[pág. 3]
Valor de Vida del Cliente: Fórmula
3
 σ𝑇𝑡=1 𝑃(𝐴𝑐𝑡𝑖𝑣𝑜𝑡 ) ∙ 𝑀𝑎𝑟𝑔𝑒𝑛𝑡
 𝐸 𝐶𝐿𝑉 =
 (1 + 𝑑)𝑡

[pág. 4]
Estimación de CLV
4
  Tres componentes clave
 1. Frecuencia de compra (# de transacciones por
 período)
 2. Valor de transacciones por período
 3. Probabilidad de que cliente permanezca activo

[pág. 5]
𝑃(𝐴𝑐𝑡𝑖𝑣𝑜) y Tasa de Retención en
 Contextos Contractuales
5
 𝑡=0 𝑡=1 𝑡=2 𝑡=3
 # de clientes 10.000 8.500 7.500 6.700
 𝑟 1,000 0,850 0,882 0,893
 𝑃(𝐴𝑐𝑡𝑖𝑣𝑜) 0,850 0,750 0,670
 Tasa de Retención es una métrica clave en contextos contractuales

[pág. 6]
Función de Supervivencia Captura
 𝑃(𝐴𝑐𝑡𝑖𝑣𝑜) en Función de 𝑡
6
 𝑆 𝑡 = 𝑟1 ∙ 𝑟2 ∙ 𝑟3 ⋯ 𝑟𝑡
 Si conocemos función de supervivencia (𝑆(1), 𝑆(2), … ) podemos obtener
 tasas de retención para cada período recursivamente

[pág. 7]
CLV en Contextos Contractuales
7
 𝑇
 𝑆(𝑡) ∙ 𝑚𝑡
 𝐸 𝐶𝐿𝑉 = ෍
 (1 + 𝑑)𝑡
 𝑡=1

[pág. 8]
Modelos de Predicción de 𝑆(𝑡)
8
  Principales modelos para predecir función de
 supervivencia varios períodos hacia adelante:
  Modelos de regresión (proyección lineal, cuadrática,
 etc.)
  Modelos de supervivencia
  Modelos probabilísticos

[pág. 9]
Uso de Modelos Probabilísticos en
 Estimación de CLV
9
  Comportamiento de compra observado visto como
 el resultado de un proceso estocástico subyacente
 Comportamiento
 x x x x x x observado
 𝑡
 Generado por función de
 𝑓 𝜙
 características latentes del
 cliente (𝜙)

[pág. 10]
Uso de Modelos Probabilísticos en
 Estimación de CLV
10
 Presente Futuro
 x x x x x x
 𝑡
 Características latentes (𝜙)
 Fader & Hardie (Journal of Interactive Marketing, 2009)

[pág. 11]
Proceso de Modelación Estocástica
11
  Especificación de modelo matemático en que
 comportamiento observado es función de características
 latentes del individuo
  Ej. Poisson, exponencial, geométrica, etc.
  Supuesto de cómo estas características varían entre
 individuos: Distribución de mezcla (ej. beta)
  Combinación de 1. y 2. entrega modelo de mixtura que
 caracteriza comportamiento de invididuo

[pág. 12]
Supuestos Dependen de 2 Factores
12
 • Compras en supermercados • Marketplaces (Ej. Amazon
 • Vuelos Prime)
 Continuas • Estadías en hoteles
 • Compras en App
 • Viajes en Uber, Lyft
 • Visitas al médico
 Oportunidades
 para
 Transacción • Campañas de organización • Suscripción a revistas
 de caridad
 • Suscripción a plataformas de
 • Asistencia a eventos streaming
 Discretas
 • Membresía en gimnasio
 No Contractual Contractual
 Contexto de Negocios

[pág. 13]
Estimación de 𝑆(𝑡): Modelo Beta-
 Geométrico
13
  Modela proceso de retención de clientes en
 contextos contractuales
  Clientes individuales tienen cierta probabilidad de
 abandonar (“churn”) en determinado período
  Probabilidad de “churn” heterogénea entre clientes
  Ajustado de datos de número de clientes activos de
 una determinada cohorte

[pág. 14]
Ejemplo: Compañía basada en Modelo de
 Suscripción
14
 Año Regular Premium
 • # de clientes en
 0 1000 1000
 segmentos Premium
 1 631 869
 y Regular 2 468 743
 3 382 653
 • Observamos
 4 326 593
 primeros 7 años
 5 289 551
 • Objetivo: Projectar 6 262 517
 7 241 491
 tasas de retención
 8 223 468
 pera años 8-12
 9 207 445
 10 194 427
 11 183 409
 12 173 394

[pág. 15]
Funciones de Supervivencia Observadas
15

[pág. 16]
Modelo BG: Vida del Cliente
 Gobernada por Distribución Geométrica
16
  Supuesto 1: Individuo permanece como cliente con
 probabilidad de retención (1 − 𝜃)

[pág. 17]
Modelo BG: Vida del Cliente
 Gobernada por Distribución Geométrica
17
  Supuesto 1: Individuo permanece como cliente con
 probabilidad de retención (1 − 𝜃)
 ¿Cuál es la probabilidad de que la vida del cliente acabe en
 𝑇 = 2?

[pág. 18]
Modelo BG: Vida del Cliente
 Gobernada por Distribución Geométrica
18
  Supuesto 1: Individuo permanece como cliente con
 probabilidad de retención (1 − 𝜃)
 Duración de relación con la firma, 𝑇 sigue
 una distribución geométrica (desplazada)
 𝑃 𝑇 = 𝑡 𝜃 = 𝜃(1 − 𝜃)𝑡−1 , 𝑡 = 1, 2, 3, …

[pág. 19]
Ejemplo: Comportamiento Geométrico
19
  Cliente se comporta geométrico con probabilidad
 de retención anual de 0.8
  ¿Cuál es la probabilidad de que su relación con la
 empresa se acabe al año 5?
  ¿Cómo cambia esa probabilidad si su tasa de
 retención annual fuese de 0.9?

[pág. 20]
Modelo Geométrico: Función de
 Supervivencia
20
 • Función de supervivencia
 𝑆 𝑡 𝜃 = (1 − 𝜃)𝑡 , 𝑡 = 1, 2, 3, …
 𝑆 𝑡 = 5 𝜃 = 0.2 = (1 − 0.2)5 = 0.328
 𝑆 𝑡 = 5 𝜃 = 0.1 = (1 − 0.1)5 = 0.590

[pág. 21]
Heterogeneidad en Probabilidad de
 Retención
21
  Supuesto 2. La heterogeneidad en 𝜃 sigue una
 distribución beta con pdf:
 𝜃 𝛼−1 1 − 𝜃 𝛽−1
 𝑓 𝜃 𝛼, 𝛽 = 0≤𝜃≤1
 𝐵 𝛼, 𝛽
 𝛼, 𝛽 > 0

[pág. 22]
Función Beta
22
 • Definida por integral:
 1
 𝐵 𝛼, 𝛽 = න 𝑧 𝛼−1 1 − 𝑧 𝛽−1 𝑑𝑧
 0
 • En términos de funciones gamma:
 Γ 𝛼 Γ 𝛽
 𝐵 𝛼, 𝛽 = Γ 𝑥 = 𝑥−1 !
 Γ 𝛼+𝛽

[pág. 23]
Distribución Beta
23

[pág. 24]
Probabilidad de Retención de Cliente
 Tomado Aleatoriamente
24
  Probabilidad 𝑃(𝑇 = 𝑡) de que el cliente abandone
 en 𝑡:
  Valor esperado de la probabilidad geométrica,
 𝑃 𝑇=𝑡Θ=𝜃
  Ponderación usando probabilidad beta, 𝑓(𝜃|𝛼, 𝛽)

[pág. 25]
Probabilidad Beta-Geométrica:
 Derivación
25
 1
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 = ‫׬‬0 𝑃 𝑇 = 𝑡 Θ = 𝜃 𝑓 𝜃 𝛼, 𝛽 𝑑𝜃
 Geométrica Beta

[pág. 26]
Probabilidad Beta-Geométrica:
 Derivación
26
 1
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 = ‫׬‬0 𝑃 𝑇 = 𝑡 Θ = 𝜃 𝑓 𝜃 𝛼, 𝛽 𝑑𝜃

[pág. 27]
Probabilidad Beta-Geométrica:
 Derivación
27
 1
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 = ‫׬‬0 𝑃 𝑇 = 𝑡 Θ = 𝜃 𝑓 𝜃 𝛼, 𝛽 𝑑𝜃
 1 𝜃 𝛼−1 1−𝜃 𝛽−1
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 = ‫׬‬0 𝜃(1 − 𝜃)𝑡−1 𝑑𝜃
 𝐵 𝛼,𝛽

[pág. 28]
Probabilidad Beta-Geométrica:
 Derivación
28
 1
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 = ‫׬‬0 𝑃 𝑇 = 𝑡 Θ = 𝜃 𝑓 𝜃 𝛼, 𝛽 𝑑𝜃
 1 𝜃 𝛼−1 1−𝜃 𝛽−1
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 = ‫׬‬0 𝜃(1 − 𝜃)𝑡−1 𝑑𝜃
 𝐵 𝛼,𝛽
 1 𝜃 𝛼 1−𝜃 𝛽+𝑡−2
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 = ‫׬‬0 𝑑𝜃
 𝐵 𝛼,𝛽

[pág. 29]
Probabilidad Beta-Geométrica:
 Derivación
29
 1
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 = ‫׬‬0 𝑃 𝑇 = 𝑡 Θ = 𝜃 𝑓 𝜃 𝛼, 𝛽 𝑑𝜃
 1 𝜃 𝛼−1 1−𝜃 𝛽−1
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 = ‫׬‬0 𝜃(1 − 𝜃)𝑡−1 𝑑𝜃
 𝐵 𝛼,𝛽
 1 𝜃 𝛼 1−𝜃 𝛽+𝑡−2
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 = ‫׬‬0 𝑑𝜃
 𝐵 𝛼,𝛽
 𝐵(𝛼 + 1, 𝛽 + 𝑡 − 1)
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 =
 𝐵 𝛼, 𝛽

[pág. 30]
Probabilidad Beta-Geométrica
30
 𝐵(𝛼 + 1, 𝛽 + 𝑡 − 1)
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 =
 𝐵 𝛼, 𝛽

[pág. 31]
Modelo Beta-Geométrico: Ejemplo
31
 • Cliente se comporta BG con 𝛼 = 1 y 𝛽 = 2
 • ¿Cuál es la probabilidad de que no renueve su suscripción en 𝑡 = 3?

[pág. 32]
Similarmente podemos Derivar la Función
 de Supervivencia BG
32
 1
 𝑆 𝑡 𝛼, 𝛽 = ‫׬‬0 𝑆 𝑡 Θ = 𝜃 𝑓 𝜃 𝛼, 𝛽 𝑑𝜃
 1 𝜃 𝛼−1 1−𝜃 𝛽−1
 𝑆 𝑡 𝛼, 𝛽 = ‫׬‬0 (1 − 𝜃)𝑡 𝑑𝜃
 𝐵 𝛼,𝛽
 1 𝜃 𝛼−1 1−𝜃 𝛽+𝑡−1
 𝑆 𝑡 𝛼, 𝛽 = ‫׬‬0 𝑑𝜃
 𝐵 𝛼,𝛽
 𝐵(𝛼, 𝛽 + 𝑡)
 𝑆 𝑡 𝛼, 𝛽 =
 𝐵 𝛼, 𝛽

[pág. 33]
Tasa de Retención en el Modelo BG
33
 𝑆 𝑡 𝛼, 𝛽
 𝑟(𝑡|𝛼, 𝛽) =
 𝑆 𝑡 − 1 𝛼, 𝛽
 𝛽+𝑡−1
 𝑟(𝑡|𝛼, 𝛽) =
 𝛼+𝛽+𝑡−1

[pág. 34]
Tasa de Retención en el Modelo BG
34
 𝑆 𝑡 𝛼, 𝛽
 𝑟(𝑡|𝛼, 𝛽) =
 𝑆 𝑡 − 1 𝛼, 𝛽
 𝛽+𝑡−1
 𝑟(𝑡|𝛼, 𝛽) =
 𝛼+𝛽+𝑡−1
 𝜕𝑟(𝑡|𝛼, 𝛽) 𝜕𝑟(𝑡|𝛼, 𝛽) 𝜕𝑟(𝑡|𝛼, 𝛽)
 < 0, > 0, >0
 𝜕𝛼 𝜕𝛽 𝜕𝑡

[pág. 35]
Evolución de Tasa de Retención en Modelo BG
35
 ¿Qué explica
 que 𝑟(𝑡) sea
 creciente en 𝑡?

[pág. 36]
Modelo BG: Estimación
36
  Estimación vía Máxima Verosimilitud
  ¿Qué valores de los parámetros 𝛼, 𝛽 hacen más probable
 observar la muestra?
  En cada período observamos el número de clientes perdidos
  Probabilidad de perder un cliente en 𝑡: 𝑃 𝑇 = 𝑡 𝛼, 𝛽
  Probabilidad de perder 𝑛𝑡 clientes en 𝑡 (asumiendo
 independencia):
 𝑃 𝑇 = 𝑡 𝛼, 𝛽 𝑛𝑡

[pág. 37]
Modelo BG: Estimación
37
  Probabilidad de observar la muestra completa (7 años):
 𝑃 𝑑𝑎𝑡𝑎 𝛼, 𝛽 = 𝑃 𝑇 = 1 𝛼, 𝛽 𝑛1 × 𝑃 𝑇 = 2 𝛼, 𝛽 𝑛2 × 𝑃 𝑇 = 3 𝛼, 𝛽 𝑛3
 × 𝑃 𝑇 = 4 𝛼, 𝛽 𝑛4 × 𝑃 𝑇 = 5 𝛼, 𝛽 𝑛5 × 𝑃 𝑇 = 6 𝛼, 𝛽 𝑛6
 7
 × 𝑃 𝑇 = 6 𝛼, 𝛽 𝑛6 × 𝑃 𝑇 = 7 𝛼, 𝛽 𝑛7 × S 7 𝛼, 𝛽 𝑛−σ𝑡=1 𝑛𝑡

[pág. 38]
Función de Verosimilitud
38
 • ¿Qué valores de los parámetros maximizan la probabilidad
 (verosimilitud) de la data?
 𝐿 𝛼, 𝛽 𝑑𝑎𝑡𝑎 = 𝑃 𝑇 = 1 𝛼, 𝛽 𝑛1 × 𝑃 𝑇 = 2 𝛼, 𝛽 𝑛2 × 𝑃 𝑇 = 3 𝛼, 𝛽 𝑛3
 × 𝑃 𝑇 = 4 𝛼, 𝛽 𝑛4 × 𝑃 𝑇 = 5 𝛼, 𝛽 𝑛5 × 𝑃 𝑇 = 6 𝛼, 𝛽 𝑛6
 7
 × 𝑃 𝑇 = 6 𝛼, 𝛽 𝑛6 × 𝑃 𝑇 = 7 𝛼, 𝛽 𝑛7 × S 7 𝛼, 𝛽 𝑛−σ𝑡=1 𝑛𝑡

[pág. 39]
Función de Verosimilitud
39
 • Equivalente a maximizar función de log-verosimilitud
 7 7
 𝐿𝐿 𝛼, 𝛽 𝑑𝑎𝑡𝑎 = ෍ 𝑛𝑡 log[𝑃 𝑇 = 𝑡 𝛼, 𝛽 ] + 𝑛 − ෍ 𝑛𝑡 log[S 7 𝛼, 𝛽 ]
 𝑡=1 𝑡=1

[pág. 40]
Estimación Usando Excel
40
  Ver planilla: modelo_bg_canvas.xlsx
  Maximizaxión de 𝐿𝐿 𝛼, 𝛽 𝑑𝑎𝑡𝑎 usando Solver

[pág. 41]
Supervivencia Observada vs.
 Proyectada: Segmento Regular
41

[pág. 42]
Supervivencia Observada vs. Proyectada:
 Segmento Premium
42

[pág. 43]
Estimación de CLV para Nuevos Clientes
43
  La empresa está considerando adquirir un conjunto de clientes con
 características similares a aquellos en el segmento premium
  ¿Cuánto es lo máximo que debería estar dispuesta a pagar la
 empresa por un cliente?
  Supuestos:
  Clientes se comportan de acuerdo al modelo BG
  Margen: 𝑚𝑡 = 200 + 5(𝑡 − 1)
  𝑇 = 7
  Tasa de descuento 𝑑 = 0.1

[pág. 44]
Estimación de CLV para Nuevos Clientes
44
 𝑇
 𝑆(𝑡) ∙ 𝑚𝑡
 𝐸 𝐶𝐿𝑉 = ෍
 (1 + 𝑑)𝑡
 𝑡=1
 7
 𝑆(𝑡) ∙ 200 + 5 𝑡 − 1
 𝐸 𝐶𝐿𝑉 = ෍
 (1 + 0.1)𝑡
 𝑡=1

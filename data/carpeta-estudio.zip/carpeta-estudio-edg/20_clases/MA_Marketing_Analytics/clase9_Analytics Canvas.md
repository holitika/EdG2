# Marketing Analytics · clase9_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 ANÁLISIS DE CLUSTERS: LAB 3
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Métodos de Segmentación
2
  Enfoque de segmentación A-priori
  Ejemplo: RFM
  Métodos de segmentación basados en medida de
 proximidad
  Análisis de Clusters Jerárquico
  Análisis de Clusters de K-Medias

[pág. 3]
Métodos Jerárquicos vs K-Medias
3
  Métodos Jerárquicos  K-Medias
  Generan secuencia de  Generan partición en
 particiones anidadas número pre-especificado
  Apropiados para set de
 de clusters
 datos pequeños (cientos de  Apropiado para 𝑛 alto ( >
 obs.) miles de observaciones)
  Computacionalmente  Menos computacionalmente
 intensivos costosos
 ◼ Requieren computar distancias  Sólo permite uso de
 entre todos los objetos distancia euclidiana

[pág. 4]
4

# Marketing Analytics · clase10_Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 ANÁLISIS DE POSICIONAMIENTO:
 INTRODUCCIÓN
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Agenda para Hoy
2
  Concepto de posicionamiento
  Uso de Mapas Perceptuales
  Introducción al Análisis de Factores

[pág. 3]
Posicionamiento en Proceso S-T-P
3
 SEGMENTACIÓN TARGETING POSICIONAMIENTO
 • Agrupación de • Evaluación del • Definición de
 clientes en atractivo de atributos
 base a cada segmento diferenciadores
 necesidades • Selección de • ¿Cómo queremos
 similares segmentos que el segmento
 • Perfil de cada meta meta perciba la
 segmento marca?

[pág. 4]
¿Qué Entendemos por Posicionamiento?
4
 “Proceso de diseñar la oferta de la compañía de manera que
 ocupe un lugar distintivo en la mente de sus clientes meta; es el
 proceso de crear una imagen distintiva y significativa de la
 oferta de la compañía en la mente de los clientes”
 Chernev (2019), “Strategic Marketing Management: The Framework”

[pág. 5]
¿Cuál es el Posicionamiento de Estas
 Marcas?
5

[pág. 6]
¿Cuál es el Posicionamiento de Estas
 Marcas?
6

[pág. 7]
¿Cuál es el Posicionamiento de Estas
 Marcas?
7

[pág. 8]
¿Cuál es el Posicionamiento de Estas
 Marcas?
8

[pág. 9]
Posicionamiento busca Influir sobre Percepciones
 del Consumidor
9
 Proceso de Toma de Decisiones del Consumidor:

[pág. 10]
Posicionamiento busca Influir sobre Percepciones
 del Consumidor
10
 Proceso de Toma de Decisiones del Consumidor:
 1. Reconocimiento de Necesidad

[pág. 11]
Posicionamiento busca Influir sobre Percepciones
 del Consumidor
11
 Proceso de Toma de Decisiones del Consumidor:
 1. Reconocimiento de Necesidad
 2. Búsqueda de Información

[pág. 12]
Posicionamiento busca Influir sobre Percepciones
 del Consumidor
12
 Proceso de Toma de Decisiones del Consumidor:
 1. Reconocimiento de Necesidad
 2. Búsqueda de Información
 3. Evaluación de Alternativas: Consumidores basan
 -Percepción decisión de compra en
 -Preferencia 2-4 atributos clave

[pág. 13]
Posicionamiento busca Influir sobre Percepciones
 del Consumidor
13
 Proceso de Toma de Decisiones del Consumidor:
 1. Reconocimiento de Necesidad
 2. Búsqueda de Información
 3. Evaluación de Alternativas: Consumidores basan
 -Percepción decisión de compra en
 -Preferencia 2-4 atributos clave
 4. Decisión de Compra
 5. Decisiones Post-compra

[pág. 14]
Uso de Mapas Perceptuales en
 Posicionamiento
14
  Herramienta para representar posición de
 productos en la mente del consumidor
  Resumen información relevante sobre:
  Atributos (dimensiones) clave
  Percepción de competidores en estas dimensiones
  Intensidad de competencia

[pág. 15]
15

[pág. 16]
Mapa Perceptual: Mercado de Cervezas
 Fuerte
 Old Milwaukee
 •
 Budweiser
 • Beck’s •
 Meister Brau • Heineken
 • Miller •
 •
Económica •
 Stroh’s
 Coors Premium
 • Michelob
 • Coors
 Miller • Light
 Old • Lite
 Milwaukee Light
 Light Moore & Pessemier (1993)

[pág. 17]
Mapa Perceptual: Mercado de Cevezas
 Fuerte
 ¿Principal competidor de Heineken?
 Old Milwaukee
 •
 Budweiser
 • Beck’s •
 Meister Brau • Heineken
 • Miller •
 •
Económica •
 Stroh’s
 Coors Premium
 • Michelob
 • Coors
 Miller • Light
 Old • Lite
 Milwaukee Light
 Light
 Moore & Pessemier (1993)

[pág. 18]
Mapa Perceptual: Mercado de Cerveza
en EEUU ¿Qué cerveza es percibida como más “light”?
 Fuerte
 Old Milwaukee
 •
 Budweiser
 • Beck’s •
 Meister Brau • Heineken
 • Miller •
 •
Económica •
 Stroh’s
 Coors Premium
 • Michelob
 • Coors
 Miller • Light
 Old • Lite
 Milwaukee Light
 Light Moore & Pessemier (1993)

[pág. 19]
Representación de Atributos en un Mapa
 Perceptual
19
 ❑ Ejes de mapa perceptual representan grandes dimensiones (“económico-
 premium”, “alto performance- bajo performance”, etc.) en que
 consumidores basan sus decisiones
 ▪ También es posible representar otros atributos en el mapa perceptual
 ▪ Vector desde el origen en la dirección en que el atributo aumenta (atributo
 disminuye en la dirección opuesta)
 ▪ Perpendicular desde vector a marca indica cómo el consumidor percibe la
 marca en ese atributo

[pág. 20]
Atributos en Mapa Perceptual
20
 Dimensión 2
 ¿Qué línea aérea es
 percibida como más Puntualidad
 puntual?
 LA A
 Dimensión 1
 LA B

[pág. 21]
Mercado de Cerveza
Marcas y Atributos
 Fuerte Popular entre
 Fuerte Hombres
 Old Milwaukee
 Mucho cuerpo
 •
 Budweiser
 • Trabajador
 Beck’s •
 Meister Brau
 Manual Ocasiones • Heineken
 • Miller • especiales Comida
 Buen valor • Fuera de casa Premium
Económica •
 Stroh’s
 Coors
 Premium
 • Michelob
 • Coors Popular
 Color
 Miller • Light entre
 Asequible Old
 • Pálido
 Lite Mujeres
 Milwaukee Light Light Menos
 Light llenadora Moore & Pessemier (1993)

[pág. 22]
Mercado de Cerveza en EEUU
Marcas y Atributos ¿Marca más popular entre hombres?
 Fuerte Popular entre
 Fuerte Hombres
 Old Milwaukee
 Mucho cuerpo
 •
 Budweiser
 • Trabajador
 Beck’s •
 Meister Brau
 Manual Ocasiones • Heineken
 • Miller • especiales Comida
 Buen valor • Fuera de casa Premium
Económica •
 Stroh’s
 Coors
 Premium
 • Michelob
 • Coors Popular
 Color
 Miller • Light entre
 Asequible Old
 • Pálido
 Lite Mujeres
 Milwaukee Light Light Menos
 Light llenadora Moore & Pessemier (1993)

[pág. 23]
Interpretación de Mapa Perceptual
 Ángulo entre Vectores de Atributos
23
 ❑ Ángulo formado por dos vectores de atributos indica la correlación entre
 ambos atributos
 Puntualidad Puntualidad
 Confiabilidad
 Entretenimiento a
 bordo
 Cuanto menor el ángulo “Puntualidad” y “Entretenimiento
 formado por los vectores, a Bordo” se encuentran no
 mayor su correlación correlacionados

[pág. 24]
Relación entre Ángulos y Correlaciones
24
 • Coeficiente de correlación entre atributos 𝑥1 y 𝑥2 :
 σ𝑛𝑖=1 𝑥1𝑖 − 𝑥1ҧ 𝑥2𝑖 − 𝑥ҧ2
 𝑟𝑥1 ,𝑥2 = 1ൗ 1ൗ
 σ𝑛𝑖=1 𝑥1𝑖 − 𝑥1ҧ 2 2 σ𝑛 2 2
 𝑥
 𝑖=1 2𝑖 − 𝑥ҧ 2
 −1 ≤ 𝑟𝑥1,𝑥2 ≤ 1

[pág. 25]
Relación entre Ángulos y Correlaciones
25
 • Si 𝑥1 y 𝑥2 se encuentran estandarizados:
 𝑛
 𝑟𝑧1 ,𝑧2 = ෍ 𝑧1𝑖 𝑧2𝑖
 𝑖=1
 −1 ≤ 𝑟𝑧1,𝑧2 ≤ 1

[pág. 26]
Relación entre Ángulos y Correlaciones
26
 • Interpretación geométrica de producto escalar entre
 vectores 𝑧1 y 𝑧2 :
 𝑧1 ∙ 𝑧2 = 𝑧1 ∙ 𝑧2 𝐶𝑜𝑠(𝜃)
 ⇒ 𝑟𝑧1 ,𝑧2 = 𝐶𝑜𝑠(𝜃)

[pág. 27]
Mapas Perceptuales:
 Resumen de Interpretación
27
  Distancias entre productos representan cercanía en la
 mente de consumidores
  Ejes representan dimensiones subyacentes que
 caracterizan cómo consumidores diferencian entre
 alternativas
  Vectores (usados para representar atributos) indican
 tanto magnitud como dirección
  Ángulo entre vectores indica correlación entre atributos

[pág. 28]
Construcción de Mapas Perceptuales:
 Metodologías
28
  Dos clases de metodologías
  Métodos basados en la evaluación de atributos
 ◼ Técnica estadística: Análisis de Factores
  Métodos basados en juicios de similitud
 ◼ Técnica estadística: Escalamiento multidimensional

[pág. 29]
29
 Análisis de Factores

[pág. 30]
Análisis de Factores en Construcción de
 Mapas Perceptuales
30
  Información sobre percepciones de consumidores sobre
 distintos productos en distintos atributos
  Análisis de factores nos permite reducir la información
 contenida en esos atributos en pocas dimensiones
  Facilita visualización y análisis
  Reducción de múltiples dimensiones (atributos) a un mapa
 de 2 dimensiones

[pág. 31]
Evaluación de Atributos
31
 ❑Tradicionalmente medidas usando encuestas
 • Ejemplo (escala Likert):
 El [iPhone] es un smartphone [de diseño atractivo]
 Totalmente en Ni de Acuerdo ni Totalmente de
 En Desacuerdo De Acuerdo
 Desacuerdo en Desacuerdo Acuerdo
 Estudios de posicionamiento requieren medir percepciones en diversos
 atributos para marcas competidoras

[pág. 32]
Objetivo del Análisis de Factores
32
 Reducir un conjunto de variables observables
 (atributos), 𝑥1, 𝑥2, … , 𝑥𝑝 en un conjunto de
 dimensiones latentes 𝑓1, 𝑓2, … , 𝑓𝑟 (𝑟 < 𝑝) que
 combinan las variables observables capturando
 la mayor parte de la información que contienen

[pág. 33]
Idea del Análisis de Factores
33
  Premisa básica del análisis factorial: existen dimensiones
 subyacentes a los atributos
 Factores latentes F1 F2 F3
 Variables observables x1 x2 x3 x4 x5 x6
 En la medida que subconjuntos de atributos 𝑥 se encuentran correlacionados, la
 información que contienen puede ser resumida por un factor 𝐹

[pág. 34]
Factores y Atributos: Percepciones de
 Marca de Smartphones
34
 Atributos: Factor 1: Rendimiento
 - Velocidad de procesamiento
 1. Atractivo del diseño - Vida de la batería
 2. Facilidad de uso
 3. Vida de la batería
 4. Calidad de pantalla Factor 2: Diseño y Experiencia Visual
 5. Velocidad de procesamiento - Atractivo del diseño
 6. Percepción de precio - Calidad de la pantalla
 7. Reputación de marca
 8. Calidad de soporte técnico
 9. Características innovadoras Factor 3: Innovación y Calidad Percibida
 10. Durabilidad - Características innovadoras
 - Reputación de marca

[pág. 35]
Matriz de Correlaciones entre Atributos
 Input Clave del Análisis
35
 1 ⋯ 𝑟1𝑝
 𝑅= ⋮ ⋱ ⋮
 𝑟𝑝1 ⋯ 1

[pág. 36]
Ejemplo: Dimensiones Clave en
 Percepciones de Línea Aérea
36
 # Ítem de cuestionario
 1 ...con Eurojet Ud. siempre arribará a tiempo.
 2 ...el viaje completo con Eurojet tendrá lugar como lo espero.
 3 ... En caso que algo no salga como estaba planificado, Eurojet encontrará una
 buena solución.
 4 ...los itinerarios de Eurojet son confiables.
 5 ...Eurojet le brinda una experiencia de viaje muy placentera.
 6 ...las comodidades abordo son de alta calidad.
 7 ...los asientos de cabina en Eurojet son cómodos.
 8 ...Eurojet ofrece una experiencia abordo confortable.
 … …

[pág. 37]
37

[pág. 38]
38

[pág. 39]
Análisis Factorial Descubre Estructura en
 Matriz de Correlaciones
39
 ❑ Factores subyacentes:
 ▪ arribo a tiempo ▪ experiencia placentera
 ▪ de acuerdo a plan Experiencia
 ▪ calidad servicio a bordo
 Seriedad a Bordo
 ▪ solución de problemas ▪ asientos cómodos
 ▪ itinerarios confiables ▪ experiencia confortable

[pág. 40]
Análisis Factorial
 Formulación Matemática
40
 ❑Modelo asume relación lineal entre atributos observables y
 factores subyacentes
 𝑥𝑖 = 𝑙𝑖1 𝑓1 + 𝑙𝑖2 𝑓2 +. . . +𝑙𝑖𝑟 𝑓𝑟 + 𝜓𝑖 𝑒𝑖 𝑖 = 1, … , 𝑝
 Nota: asumimos una única marca por simplicidad

[pág. 41]
Análisis Factorial
 Formulación Matemática
41
 ❑Modelo asume relación lineal entre atributos observables y
 factores subyacentes
 𝑥𝑖 = 𝑙𝑖1 𝑓1 + 𝑙𝑖2 𝑓2 +. . . +𝑙𝑖𝑟 𝑓𝑟 + 𝜓𝑖 𝑒𝑖 𝑖 = 1, … , 𝑝
 Atributo 𝑖 Componente
 Cargas Factores
 factoriales comunes a específico a
 (loadings) atributos atributo i
 Nota: asumimos una única marca por simplicidad

[pág. 42]
Análisis Factorial
 Formulación Matemática
42
 ❑Modelo asume relación lineal entre atributos observables y
 factores subyacentes
 𝑥𝑖 = 𝑙𝑖1 𝑓1 + 𝑙𝑖2 𝑓2 +. . . +𝑙𝑖𝑟 𝑓𝑟 + 𝜓𝑖 𝑒𝑖
 ▪ Tanto los factores como el componente único tienen media 0 y varianza 1
 ▪ Factores no correlacionados entre sí y no correlacionados con 𝑒

[pág. 43]
Análisis Factorial
 Formulación Matemática
43
 ❑Ecuación Fundamental del Análisis de Factores
 𝑋 = 𝐿 ∙ 𝐹 + Ψ𝐸

[pág. 44]
Análisis Factorial
 Formulación Matemática
44
 ❑Información contenida en un atributo resumida en su varianza:
 𝜎𝑖2 = 𝐸 𝑙𝑖1 𝑓1 + 𝑙𝑖2 𝑓2 +. . . +𝑙𝑖𝑟 𝑓𝑟 + 𝜓𝑖 𝑒𝑖 2
 ❑ Dado que 𝑓’𝑠 son no correlacionados entre sí y no correlacionados con 𝑒
 𝑟
 𝜎𝑖2 = ෍ 𝑙𝑖𝑗 2 + 𝜓𝑖2
 𝑗=1

[pág. 45]
Análisis Factorial
 Descomposición de Varianza
45
 ❑Varianza de 𝑥𝑖 puede descomponerse como:
 𝑟
 2
 𝜎𝑖 = ෍ 𝑙𝑖𝑗 + 𝜓𝑖2
 2
 𝑗=1
 Componente Componente
 explicado por específico a
 factores variable i
 (comunalidad)

[pág. 46]
Análisis Factorial
 Descomposición de Varianza
46
 ❑Usando notación matricial:
 𝑅 = 𝐿𝐿′ + Ψ
 Matriz de Matriz de Matriz de
 correlaciones loadings correlaciones entre
 entre atributos componentes
 específicos

[pág. 47]
Análisis Factorial
 Notación Matricial
47
 1 ⋯ 𝑟1𝑝
 𝑅= ⋮ ⋱ ⋮
 𝑟𝑝1 ⋯ 1
 𝑙11 ⋯ 𝑙1𝑟 𝜓1 ⋯ 0
 𝐿= ⋮ ⋱ ⋮ Ψ= ⋮ ⋱ ⋮
 𝑙𝑝1 ⋯ 𝑙𝑝𝑟 0 ⋯ 𝜓𝑝

[pág. 48]
Análisis Factorial
 Algoritmo de Estimación
48
 1. Input clave: Matriz de correlaciones entre atributos
 1 ⋯ 𝑟1𝑝
 𝑅= ⋮ ⋱ ⋮
 𝑟𝑝1 ⋯ 1

[pág. 49]
Análisis Factorial
 Algoritmo de Estimación
49
 1. Input clave: Matriz de correlaciones entre atributos
 1 ⋯ 𝑟1𝑝
 𝑅= ⋮ ⋱ ⋮
 𝑟𝑝1 ⋯ 1
 2. Aproximación inicial de varianza explicada de cada atributo
 (comunalidad) usando coeficiente de determinación
 ℎ𝑖2 = ෍ 𝑙𝑖𝑗
 2 𝑗 = 1, … 𝑟
 𝑗

[pág. 50]
Análisis Factorial
 Algoritmo de Estimación
50
 3. Comunalidades iniciales usadas para crear R ajustada
 ℎ12 ⋯ 𝑟1𝑝
 𝑅∗ = ⋮ ⋱ ⋮
 𝑟𝑝1 ⋯ ℎ𝑝2

[pág. 51]
Análisis Factorial
 Algoritmo de Estimación
51
 3. Comunalidades iniciales usadas para crear R ajustada
 ℎ12 ⋯ 𝑟1𝑝
 𝑅∗ = ⋮ ⋱ ⋮
 𝑟𝑝1 ⋯ ℎ𝑝2
 4. Descomposición espectral de 𝑅∗
 𝑅∗ = 𝐶𝐷𝐶 ′ = (𝐶𝐷1/2 )(𝐶𝐷1/2 )′ Obtenemos
 eigenvectores y
 Matriz ortogonal Matriz diagonal (𝑟 × 𝑟) eigenvalores
 con eigenvectores en (eigenvalores en 𝐿
 columnas diagonal principal)
 asociados

[pág. 52]
Análisis Factorial
 Algoritmo de Estimación
52
 5. Usando nuevos loadings volvemos a calcular comunalidades
 y actualizamos matriz 𝑅∗

[pág. 53]
Análisis Factorial
 Algoritmo de Estimación
53
 5. Usando nuevos loadings volvemos a calcular comunalidades
 y actualizamos matriz 𝑅∗
 6. Volvemos a realizar descomposición espectral

[pág. 54]
Análisis Factorial
 Algoritmo de Estimación
54
 5. Usando nuevos loadings volvemos a calcular comunalidades
 y actualizamos matriz 𝑅∗
 6. Volvemos a realizar descomposición espectral
 7. Repetimos hasta convergencia (loadings se estabilizan)
 Eigenvectores resultantes son los factores
 Eigenvalores representan % de varianza total
 (de atributos) explicada por cada factor

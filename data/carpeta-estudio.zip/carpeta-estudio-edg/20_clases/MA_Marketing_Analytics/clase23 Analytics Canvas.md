# Marketing Analytics · clase23 Analytics Canvas

Fuente: clase de Marketing Analytics

[pág. 1]
MARKETING ANALYTICS
 INTRODUCCIÓN A LA
 ANALÍTICA DE TEXTOS
2º Semestre, 2024 Prof. Andrés Elberg aelberg@uc.cl

[pág. 2]
Agenda
2
  Importancia y usos de text
 analytics
  Enfoque Bolsa de
 Palabras (BOW)
  Procesamiento de datos
 de texto usando BOW
  Descripción y visualización

[pág. 3]
Marketing Data
 Perspectiva Histórica
3
 pre-1980s 1980s-1990s mid-2000s - present
 • Surveys • Electronic records of • Search data • Blogs, reviews, emails
 • Diary transaction data • Clickstream • Geolocalization
 panels • Customer-level purchasing • Images, videos
 behavior
 • Social media comments
 Datos capturados digitalmente

[pág. 4]
CRECIENTE DISPONIBILIDAD DE DATOS DE TEXTO
 80%-95% de datos de negocios son no estructurados
4
 (mayoritariamente texto; Gandomi & Haider, 2015)

[pág. 5]
Aplicaciones en Marketing
5
  Análisis de Sentimientos
  Monitoreo de Marcas
  Feedback de Producto
  Respuesta a campañas publicitarias en blogs o RRSS
  Análisis de Voz del Cliente
  Extracción de insights de interacciones con cliente
  Identificación de “pain points”, mejora de experiencia, mejora de desarrollo
 de productos
  Transcripciones de call center, feedback en encuestas
  Identificación de tendencias
  Segmentación y posicionamiento

[pág. 6]
Aplicaciones en Marketing
6
 Netzer et al. (2012)

[pág. 7]
¿Qué Entendemos por Analítica de Textos?
7
 “... proceso de extraer información útil, significativa y no trivial a
 partir de texto no estructurado”
 Netzer et al. (Marketing Science, 2012)
 “Metodología asistida por computadores que permite [...]
 cuantificar la información contenida en data textual de la manera
 en que ocurre naturalmente”
 Berger et al. (Journal of Marketing, 2020)

[pág. 8]
Desafío de Analítica de Textos
8
 Definición de
 Definición de Objetivos de la Analítica de Textos
 Problema
 Encuestas
 Emails Blogs Artículos
 Estado
 Medios
 Desorganizado Sociales
 Reseñas
 Estado
 Organizado Insights, recomendaciones o output de analítica

[pág. 9]
Enfoque de “Bolsa de Palabras”
9
  Reducción de complejidad vía tokenization
  Análisis se basa en frecuencia de “tokens”:
 palabras, frases, otros elementos básicos
  Representación de texto como “bolsa de palabras”
  Trata documentos como si fuesen construidos tomando
 muestras aleatorias con reemplazo de una bolsa que
 contiene un vocabulario fijo

[pág. 10]
Representación “Bolsa de Palabras”
10
 “Hermoso teléfono impecable su calidad a
 muy buen precio y recibido antes de la
 fecha y sus audífonos inalámbricos
 geniales van muy bien con el teléfono”
 Hermoso teléfono impecable su calidad a muy …
 1 2 1 1 1 1 2 …

[pág. 11]
Etapas en Analítica de Textos
11
 Transformación Análisis
 Organización Selección de en Arreglo (descripción,
 del Texto Features Numérico visualización,
 (tdm-dtm) predicción)

[pág. 12]
1. Organización del Texto
12
  Organización de texto
 original en Corpus
  Colección de documentos
  Documento visto como
 colección de tokens:
 Corpus Documento Token
  Términos individuales
  n-gramas

[pág. 13]
Ejemplo: Entendiendo Tweets de Servicio
 al Cliente en Delta Airlines
13
  Tweets de Delta de la API de Twitter
  1 de octubre de 2015 – 15 de octubre de 2015
  1377 tweets posteados por agentes de servicio al
 cliente de Delta Airline
  Datos: oct_delta-csv
  Objetivo: Análisis exploratorio para entender
 problemas más comunes enfrentados por agentes

[pág. 14]
Carga de Datos y Reorganización
14

[pág. 15]
Ej. Tweets de Servicio al Cliente en Delta Airlines
15

[pág. 16]
2. Pre-Procesamiento de Datos
 Selección de Features
16
 ❑Reducción del número de características del texto para
 facilitar el análisis.
 Procedimiento típico incluye:
 ▪ Remoción de signos de puntuación, números, etc.
 ▪ Remoción de palabras muy comunes (“stop words”): artículos,
 preposiciones, conjunciones, conjugación de verbo ser, etc.
 ▪ Remoción de palabras extremadamente raras
 ▪ “Stemming”: Reducción de palabras a su raíz

[pág. 17]
2. Pre-Procesamiento de Datos
 Selección de Features
17
 ❑Reducción del número de características del texto para
 facilitar el análisis.
 Ejemplo:
 El servicio es muy bueno.
 servicio muy bueno

[pág. 18]
2. Pre-Procesamiento de Datos
 Tokenización
18
 ❑ Determinación de n-gramas
 ▪ Práctica típica es comenzar análisis con términos individuales
 ▪ Típicamente no más allá de tri-gramas
 ▪ Balance entre significado y costo computacional
 servicio muy bueno
 uni-gramas bi-gramas
 𝑠𝑒𝑟𝑣𝑖𝑐𝑖𝑜 , 𝑚𝑢𝑦 , {𝑏𝑢𝑒𝑛𝑜} 𝑠𝑒𝑟𝑣𝑖𝑐𝑖𝑜. 𝑚𝑢𝑦 , 𝑚𝑢𝑦. 𝑏𝑢𝑒𝑛𝑜

[pág. 19]
19

[pág. 20]
3. Transformación de Texto en Arreglo
 Numérico: tdm
20
 Documento 1 Documento 2 …
 Término 1 0 0 …
 Corpus Término 2 0 1 …
 Término 3 1 0 …
 ⋮ ⋮ ⋮ ⋱
 (term-document-matrix)
 # de ocurrencias (o presencia/ausencia de término en documento

[pág. 21]
Creación de Term-Document-Matrix
21
 tdm<- TermDocumentMatrix(corpus, control =
 list(weighting=weightTf))
 tdm.tweets.m <- as.matrix(tdm)
 dim(tdm.tweets.m)
 ## [1] 2339 1377
 ¿Cuántos términos distintos contienen los 1377 tweets?

[pág. 22]
Extracto de Term-Document-Matrix
22
 tdm.tweets.m[2250:2255, 10:12]
 ## Docs
 ## Terms 10 11 12
 ## watkinshort 0 0 0
 ## way 0 0 0
 ## wayn 0 0 0
 ## weather 0 0 0
 ## web 0 0 0
 ## websit 0 0 0

[pág. 23]
Ejemplo: Reseñas de Restaurant
23

[pág. 24]
24

[pág. 25]
25

[pág. 26]
Ponderación usando TF-IDF
26
  Usado en algunas aplicaciones para reducir
 ponderación de términos que aparecen en múltiples
 documentos
  Refleja importancia de un término en un documento
  Más alta cuanto mayor la frecuencia de un término en
 el documento
  Menor cuando en más documentos del corpus aparezca

[pág. 27]
Term Frequency
27
 ❑ Número de veces que aparece el término normalizado por
 longitud del documento
 # 𝑑𝑒 𝑣𝑒𝑐𝑒𝑠 𝑡𝑒𝑟𝑚𝑖𝑛𝑜 𝑡 𝑎𝑝𝑎𝑟𝑒𝑐𝑒 𝑒𝑛 𝑑𝑜𝑐𝑢𝑚𝑒𝑛𝑡𝑜 𝑑
 𝑇𝐹(𝑡, 𝑑) =
 𝑇𝑜𝑡𝑎𝑙 𝑑𝑒 𝑡é𝑟𝑚𝑖𝑛𝑜𝑠 𝑒𝑛 𝑑𝑜𝑐𝑢𝑚𝑒𝑛𝑡𝑜 𝑑

[pág. 28]
Term Frequency
28

[pág. 29]
Inverse Document Frequency
29
 ❑ Inverso de la frecuencia de un término en el corpus (en logs)
 𝑡𝑜𝑡𝑎𝑙 𝑑𝑒 𝑑𝑜𝑐𝑢𝑚𝑒𝑛𝑡𝑜𝑠 𝑒𝑛 𝑐𝑜𝑟𝑝𝑢𝑠
 𝐼𝐷𝐹(𝑡) = 𝑙𝑜𝑔10
 𝑛ú𝑚𝑒𝑟𝑜 𝑑𝑒 𝑑𝑜𝑐𝑢𝑚𝑒𝑛𝑡𝑜𝑠 𝑞𝑢𝑒 𝑖𝑛𝑐𝑙𝑢𝑦𝑒𝑛 𝑡é𝑟𝑚𝑖𝑛𝑜 𝑡

[pág. 30]
Inverse Document Frequency
30

[pág. 31]
TF-IDF
31
 ❑ Producto de tf e idf
 𝑇𝐹 − 𝐼𝐷𝐹 = 𝑇𝐹(𝑡, 𝑑) × 𝐼𝐷𝐹(𝑡)

[pág. 32]
𝑇𝐹
𝑇𝐹 −
𝐼𝐷𝐹
 32

[pág. 33]
33 Descripción y Visualizaciones

[pág. 34]
¿Cuán importante es un Término en el
 Corpus?
34
  Frecuencia de términos (tf)
 term.freq <- rowSums(tdm.tweets.m)
 freq.df <- data.frame(word= names(term.freq),
 frequency=term.freq)
 Sumamos
 frecuencia
 freq.df <- freq.df[order(freq.df[,2], decreasing
 de cada = T),]
 término
 sobre todos
 los freq.df$word <- factor(freq.df$word, levels =
 documentos
 del corpus
 unique(as.character(freq.df$word)))

[pág. 35]
Uso de Gráficos de Frecuencia
35
  Simples gráficos de frecuencia de términos son un
 buen punto de partida del análisis
  Barplot de términos versus número de veces en que
 aparecen en el corpus
  En sí mismos pueden aportar insights interesantes

[pág. 36]
Gráfico de Frecuencias
36

[pág. 37]
Nubes de Palabras
37
  Tipo de visualización basada en frecuencia muy
 comúnmente utilizada
  Nube de palabras simple: Tamaño de letra captura
 frecuencia de n-grama
  Mayor ventaja: Fácil comprensión
  Deficiencias:
  Uni-dimensional
  Número de palabras presentadas arbitrario

[pág. 38]
38

[pág. 39]
Asociación de Términos
39
  Podemos medir grado de asociación entre un determinado
 término (“término focal”) y otros
  ¿Cuán frecuentemente aparece el término focal junto a otros
 términos en un mismo documento?
  Coeficiente de correlación entre términos en rango [0, 1]
 # 𝑑𝑒 𝑑𝑜𝑐𝑢𝑚𝑒𝑛𝑡𝑜𝑠 𝑒𝑛 𝑞𝑢𝑒 𝐴 𝑦 𝐵 𝑒𝑠𝑡á𝑛 𝑝𝑟𝑒𝑠𝑒𝑛𝑡𝑒𝑠
 𝐶𝑜𝑟𝑟 𝐴, 𝐵 =
 # 𝑡𝑜𝑡𝑎𝑙 𝑑𝑒 𝑑𝑜𝑐𝑢𝑚𝑒𝑛𝑡𝑜𝑠 𝑒𝑛 𝑞𝑢𝑒 𝐴 𝑒𝑠𝑡á 𝑝𝑟𝑒𝑠𝑒𝑛𝑡𝑒
 Término Focal

[pág. 40]
Asociación de Términos
 Ejemplo Simple
40
 Consideremos la siguiente 𝑡𝑑𝑚 simple:
 Doc1 Doc2 Doc3
 Disculpas 1 1 0
 Retraso 1 1 0
 Gracias 0 0 1
 𝐶𝑜𝑟𝑟 𝑫𝒊𝒔𝒄𝒖𝒍𝒑𝒂𝒔, 𝑅𝑒𝑡𝑟𝑎𝑠𝑜 =
 𝐶𝑜𝑟𝑟 𝑮𝒓𝒂𝒄𝒊𝒂𝒔, 𝐷𝑖𝑠𝑐𝑢𝑙𝑝𝑎𝑠 =

[pág. 41]
Asociaciones con “Apologies”
41
 associations <- findAssocs(tdm, 'apolog', 0.11)
 associations <- as.data.frame(associations)
Buscamos todas associations$terms <- row.names(associations)
las asociaciones associations$terms <- factor(associations$terms,
de “apologies” levels = associations$terms)
con coeficiente
de correlación
mayores a 0.11

[pág. 42]
Visualización de Asociaciones con
 “Apologies”
42

[pág. 43]
Distancias entre Términos y
 Dendrograma Jerárquico
43
  Herramienta adicional para estudiar asociación de
 términos
  Al igual que en análisis de clusters, podemos describir
 la cercanía entre distintos términos del corpus usando
 clustering jerárquico.
  Input clave es matriz de distancias entre vectores de
 términos
  Usando ejemplo anterior…

[pág. 44]
Ejemplo de Distancias entre Términos
44
 Doc1 Doc2 Doc3
Disculpas 1 1 0
Retraso 1 1 0
Gracias 0 0 1

[pág. 45]
Ejemplo de Distancias entre Términos
45
 Doc1 Doc2 Doc3 Disculpas Retraso Gracias
Disculpas 1 1 0 Disculpas 0 0 3
Retraso 1 1 0 Retraso 0 0 3
Gracias 0 0 1 Gracias 0
 3 3
 𝑑 𝐺𝑟𝑎𝑐𝑖𝑎𝑠, 𝐷𝑖𝑠𝑐𝑢𝑙𝑝𝑎𝑠 = (0 − 1)2+(0 − 1)2+(1 − 0)2

[pág. 46]
Dendrograma Ejemplo Simple
46
 1.732

[pág. 47]
Dendrograma Jerárquico
47
 tdm2 <- removeSparseTerms(tdm, sparse = 0.96)
 hc <- hclust(dist(tdm2, method = "euclidean"),
 method = "complete")
 Mantenemos
 sólo términos
 con un % de
 ceros menor a
 96%

[pág. 48]
Dendrograma Jerárquico
48

[pág. 49]
49
 Height
 60 80 100 120 140 160
 fit
 size
 love
 top
 look
 wear
 color
 great
 order
 small
 perfect
 fabric
 one
 tri
 littl
 back
 bit
 usual
 run
 Dendrograma Jerárquico
larg
 well
 cute
 work
 Cluster Dendrogram
 length
 much
 bought
 comfort
 materi
 soft
 flatter
 beauti
 nice
 realli
 Ejemplo de Reseñas en Tienda de Ropa Online

[pág. 50]
50
 Height
 60 80 100 120 140 160
 fit
 size
 love
 top
 look
 wear
 color
 great
 order
 small
 perfect
 fabric
 one
 tri
 littl
 back
 bit
 usual
 run
 Dendrograma Jerárquico
larg
 well
 cute
 work
 Cluster Dendrogram
 length
 much
 bought
 comfort
 materi
 soft
 flatter
 beauti
 nice
 realli
 Ejemplo de Reseñas en Tienda de Ropa Online

[pág. 51]
Nubes de Palabras usando más de un
 Corpus
51
  Comparación de palabras más usadas en distintos
 corpus
  Ejemplos
  Tweets de agentes de Delta Airlines vs. Amazon
  Reseñas positivas vs. negativas en tienda de ropa
 online

[pág. 52]
Nubes de Palabras usando más de un Corpus
 Amazon vs. Delta
52
 Commonality Cloud Comparison Cloud

[pág. 53]
Word Cloud Comparativa
 Ejemplo Reseñas Tienda de Ropa
53
 Recomienda
 producto
 No recomienda
 producto

[pág. 54]
Gráfico de Pirámide
 Amazon vs. Delta
54

[pág. 55]
Gráfico de Pirámide
 Tienda de Ropa Online
55

# Finanzas II · 14 Clase_14_Patrones de Financiamiento

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 14: Patrones de Financiamiento
 Profesor: Augusto Orellana
 Abril2026
Prof: Augusto Orellana Clase 14: Patrones 1 / 21

[pág. 2]
Roadmap
1 Short-Term Financial Policy
2 Patrones de Financiamiento
3 Cash Budget
4 Principio de calce
 Prof: Augusto Orellana Clase 14: Patrones 2 / 21

[pág. 3]
Algunas preguntas
Hemos aprendido a proyectar, pero:
 ¿Cuál es el tipo de financiamiento que debe usarse frente a un
 crecimiento esperado en las ventas?
 ▶ Pasivos, equity (acciones, utilidad retenida)?
 ¿Existe un plan financiero óptimo?
 ▶ Flexibilidad vs. rigidez
 Prof: Augusto Orellana Clase 14: Patrones 3 / 21

[pág. 4]
Roadmap
1 Short-Term Financial Policy
2 Patrones de Financiamiento
3 Cash Budget
4 Principio de calce
 Prof: Augusto Orellana Clase 14: Patrones 4 / 21

[pág. 5]
Flexibilidad vs. rigidez financiera
Politica Financiera Flexible
 Gran masa de activos y pasivos de corto plazo
 ▶ Alto nivel de net working capital
 ⋆ Grandes balances de caja y cuentas por cobrar
 ⋆ Alto nivel de inventarios
Politica Financiera Rigida
 Gran masa de activos y pasivos de largo plazo
 ▶ Bajo nivel de net working capital
 ⋆ Pequeños balances de caja y cuentas por cobrar
 ⋆ Bajo nivel de inventarios
 Prof: Augusto Orellana Clase 14: Patrones 5 / 21

[pág. 6]
Politicas financieras y ventas
Politica Financiera Flexible
 Gran masa de activos y pasivos de corto plazo
 ▶ Incrementa ventas → Inventario listo para vender
Politica Financiera Rigida
 Pequeña masa de activos y pasivos de corto plazo
 ▶ Difı́cil incrementar ventas → Poco inventario para responder a cambios
 en demandas
 Prof: Augusto Orellana Clase 14: Patrones 6 / 21

[pág. 7]
Politicas financieras y costos
Carrying costs (costos de almacenamiento)
 Costos de oportunidad asociados a activos de CP
 ▶ Oportunidades de inversión alternativas?
Shortage costs (costos de desabastecimiento)
 Costos de oportunidad asociados a activos de LP
 ▶ Rescatar inversiones anticipadamente por necesidades de liquidez
 Prof: Augusto Orellana Clase 14: Patrones 7 / 21

[pág. 8]
Politicas financieras: Optimalidad
 Prof: Augusto Orellana Clase 14: Patrones 8 / 21

[pág. 9]
Politicas financieras: Optimalidad
 Prof: Augusto Orellana Clase 14: Patrones 9 / 21

[pág. 10]
Roadmap
1 Short-Term Financial Policy
2 Patrones de Financiamiento
3 Cash Budget
4 Principio de calce
 Prof: Augusto Orellana Clase 14: Patrones 10 / 21

[pág. 11]
Patrones de Financiamiento
 Prof: Augusto Orellana Clase 14: Patrones 11 / 21

[pág. 12]
Patrones de Financiamiento
 Ventas no solo aumentan por tendencias de mediano y largo plazo
 (crecimiento) sino tambien por factores estacionales y cı́clicos.
 ▶ Black Friday, Cyberday, Navidad, Dı́a de la Madre
 Aumento permanente de ventas requiere de inversión en activos de
 carácter permanente
 ▶ Fijos o corrientes
 Aumento transitorio de ventas requiere de inversión transitoria en
 activos.
 Prof: Augusto Orellana Clase 14: Patrones 12 / 21

[pág. 13]
Patrones de Financiamiento
 Prof: Augusto Orellana Clase 14: Patrones 13 / 21

[pág. 14]
¿Qué tipo de patrón de financiamiento debemos elegir?
No existe una respuesta definitiva. Un análisis adecuado debe considerar
varios factores:
 1 Reservas de efectivo
 ▶ Evaluar probabilidad de enfrentar dificultades financieras que impidan
 el cumplimiento de obligaciones de corto plazo
 2 Sincronización de vencimientos
 ▶ Financiar activos de LP con deuda de CP implica refinanciamientos
 frecuentes y mayor riesgo, dado que las tasas de corto plazo son más
 volátiles.
 3 Tasas de interés relativas
 ▶ Las tasas de interés de corto plazo suelen ser menores que las de largo
 plazo, por lo que, en promedio, el financiamiento de largo plazo resulta
 más costoso que el de corto plazo.
 Prof: Augusto Orellana Clase 14: Patrones 14 / 21

[pág. 15]
Roadmap
1 Short-Term Financial Policy
2 Patrones de Financiamiento
3 Cash Budget
4 Principio de calce
 Prof: Augusto Orellana Clase 14: Patrones 15 / 21

[pág. 16]
Close-up a la evaluación de reservas de efectivo
Herramienta fundamental en la planificación financiera de corto plazo.
 La empresa tiene un perı́odo promedio de cobro de 45 dı́as, lo que
 implica que la mitad de las ventas realizadas en un trimestre se
 cobrará en el trimestre siguiente.
 Prof: Augusto Orellana Clase 14: Patrones 16 / 21

[pág. 17]
Close-up a la evaluación de reservas de efectivo
 Salidas de efectivo para pagar salarios, capex, etc
 Prof: Augusto Orellana Clase 14: Patrones 17 / 21

[pág. 18]
Close-up a la evaluación de reservas de efectivo
 -10 es el mı́nimo permanente (la firma debe tener siempre como
 mı́nimo)
 -50 es el máximo financiamiento temporal (¿En qué quarter ocurre?)
 Prof: Augusto Orellana Clase 14: Patrones 18 / 21

[pág. 19]
A Short-Term Financial Plan
 Prof: Augusto Orellana Clase 14: Patrones 19 / 21

[pág. 20]
Roadmap
1 Short-Term Financial Policy
2 Patrones de Financiamiento
3 Cash Budget
4 Principio de calce
 Prof: Augusto Orellana Clase 14: Patrones 20 / 21

[pág. 21]
Principio de correspondencia o calce
Activos Permanentes
 Aquellos que sustentan niveles de venta permanentes, deben
 financiarse con fuentes de mediano y largo plazo.
 ▶ Créditos y bonos de MP y LP
 ▶ Patrimonio
 ▶ Pasivo corriente “espontáneo”
Activos Transitorios
 Aquellos que aumentan ante cambios temporales de ventas (ciclos o
 estacionalidad) deben ser financiados con fuentes de corto plazo
 Prof: Augusto Orellana Clase 14: Patrones 21 / 21

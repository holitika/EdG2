# Finanzas II · 7 Clase_7_wacc Deuda Optima

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 7: Costo de Capital & Deuda Óptima
 Profesor: Augusto Orellana
 Marzo 2026
Prof: Augusto Orellana Clase 7: WACC & Deuda Óptima 1 / 10

[pág. 2]
Roadmap
1 Endeudamiento
2 Costos del endeudamiento
3 Optimal Capital Structure
 Prof: Augusto Orellana Clase 7: WACC & Deuda Óptima 2 / 10

[pág. 3]
Roadmap
1 Endeudamiento
2 Costos del endeudamiento
3 Optimal Capital Structure
 Prof: Augusto Orellana Clase 7: WACC & Deuda Óptima 3 / 10

[pág. 4]
Beneficios de la Deuda: Teorı́a vs. Práctica
Con impuestos, existen beneficios de apalancarse (tax-shields):
 Mayor valor de la firma (Recap)
 Mayor beneficios para los shareholders (Recap)
 Menor costo de capital (wacc)
¿Las empresas muestran una preferencia por la deuda?
Se financian prefiriendo internal funds!
 Prof: Augusto Orellana Clase 7: WACC & Deuda Óptima 4 / 10

[pág. 5]
Beneficios de la Deuda: Teorı́a vs. Práctica
¿Las empresas muestran una preferencia por la deuda?
Las firmas mueven su leverage constantemente
 ¿Quizás los tax-shields no son constantes?
Las firmas tienen un leverage menor a un 50%
 Prof: Augusto Orellana Clase 7: WACC & Deuda Óptima 5 / 10

[pág. 6]
Roadmap
1 Endeudamiento
2 Costos del endeudamiento
3 Optimal Capital Structure
 Prof: Augusto Orellana Clase 7: WACC & Deuda Óptima 6 / 10

[pág. 7]
Cost of Financial Distress
Distress Cost= Costo del distress * Probabilidad del distress
Costo del distress:
 1 Costos Directos:
 ▶ Legal fees
 ▶ Professional services
 ▶ 1%-3% of value (Warner, JF 1977)
 2 Costos Indirectos:
 ▶ Perdida de empleados
 ▶ Inversión perdida
 ▶ Perdida de clientes
 ▶ Perdida de suppliers
Probabilidad del distress:
 Prof: Augusto Orellana Clase 7: WACC & Deuda Óptima 7 / 10

[pág. 8]
Roadmap
1 Endeudamiento
2 Costos del endeudamiento
3 Optimal Capital Structure
 Prof: Augusto Orellana Clase 7: WACC & Deuda Óptima 8 / 10

[pág. 9]
Trade-off (Static) Theory: Optimal Debt Level
Optimal Debt
 Mg Benefit Debt = Mg Cost Bankruptcy
 Prof: Augusto Orellana Clase 7: WACC & Deuda Óptima 9 / 10

[pág. 10]
Optimal Debt Level & WACC
 Prof: Augusto Orellana Clase 7: WACC & Deuda Óptima 10 / 10

# Finanzas II · 9 Clase_9_Razones Financieras

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 9: Razones Financieras
 Profesor: Augusto Orellana
 Abril 2026
Prof: Augusto Orellana Clase 9: Razones Financieras 1 / 19

[pág. 2]
Roadmap
1 Liquidez
2 Solvencia
3 Rentabilidad
4 Working Capital
5 Ciclo de Caja
6 Limitaciones
 Prof: Augusto Orellana Clase 9: Razones Financieras 2 / 19

[pág. 3]
Roadmap
1 Liquidez
2 Solvencia
3 Rentabilidad
4 Working Capital
5 Ciclo de Caja
6 Limitaciones
 Prof: Augusto Orellana Clase 9: Razones Financieras 3 / 19

[pág. 4]
Razones Financieras: Liquidez
Capacidad de pago de las obligaciones de corto plazo (1 año o menos)
 Rapidez y facilidad con la que un activo se transforma en efectivo
 Sostenibilidad: Futuro de la empresa
Ratios:
 1 Current ratio (razon corriente): Activo corriente/pasivo corriente
 ▶ Veces que las obligaciones de CP son cubiertas por el activo de CP
 2 Quick/Acid Ratio: (Activo corriente - existencias)/pasivo corriente
 ▶ Existencias: Inventario
 Prof: Augusto Orellana Clase 9: Razones Financieras 4 / 19

[pág. 5]
Roadmap
1 Liquidez
2 Solvencia
3 Rentabilidad
4 Working Capital
5 Ciclo de Caja
6 Limitaciones
 Prof: Augusto Orellana Clase 9: Razones Financieras 5 / 19

[pág. 6]
Razones Financieras: Solvencia de la Deuda
Capacidad de pago de las obligaciones de largo plazo (1 año o más)
 Medir intensidad de uso de deuda por capital invertido
 Medir impacto de riesgos operacionales y financieros (análisis de
 leverage)
Ratios de estructura de capital:
 1 Leverage: Deuda/Activos
 2 Debt-to-Equity: Deuda/Equity
 3 Multiplicador Apalancamiento (Leverage multiplier): Activo/Equity
 4 Deuda largo plazo: (Deuda Largo plazo)/ (Deuda Largo plazo +
 Equity)
 Prof: Augusto Orellana Clase 9: Razones Financieras 6 / 19

[pág. 7]
Razones Financieras: Solvencia de la Deuda
Ratios de solvencia:
 1 Interest coverage ratio (Índice de Cobertura): EBIT/(Interest
 expenses)
 2 Adjusted interest coverage ratio: EBITDA /(Interest expenses)
 Prof: Augusto Orellana Clase 9: Razones Financieras 7 / 19

[pág. 8]
Roadmap
1 Liquidez
2 Solvencia
3 Rentabilidad
4 Working Capital
5 Ciclo de Caja
6 Limitaciones
 Prof: Augusto Orellana Clase 9: Razones Financieras 8 / 19

[pág. 9]
Razones Financieras: Rentabilidad
Capacidad de generar recursos en exceso de los gastos
 Medir rendimiento por peso invertido
 Medida de eficiencia
Ratios de rentabilidad:
 1 ROA: Net Income/Activos
 ▶ ROA: Mg. Utilidad (Profit margin) * Asset Turnover
 2 ROE: Net Income/Equity
 ▶ ROE: Mg. Utilidad (Profit margin) * Asset Turnover* Equity Multiplier
 Net Income Revenues(Sales)
 ROA = x
 Revenues(Sales) Assets
 Net Income Assets
 ROE = x = ROA x Equity Multiplier
 Assets Equity
 Prof: Augusto Orellana Clase 9: Razones Financieras 9 / 19

[pág. 10]
Roadmap
1 Liquidez
2 Solvencia
3 Rentabilidad
4 Working Capital
5 Ciclo de Caja
6 Limitaciones
 Prof: Augusto Orellana Clase 9: Razones Financieras 10 / 19

[pág. 11]
Razones Financieras: Utilización de activos
Eficiencia con la empresa maneja sus activos de CP
 ¿Cuán eficiente o intensivamente utiliza la empresa sus activos?
 ¿Cuánto tiempo necesita la empresa para rotar su inventario?
 1 Rotación de inventarios (RI): Costo de Ventas (COGS)/ Inventarios
 ▶ Cuanto más elevado, más eficiente será la empresa
 2 Perı́odo promedio de inventario (PPI): 365/RI
 ▶ Número de dı́as que le toma a la empresa rotar su inventario
 3 Rotación de cuentas por cobrar (RCC): Ventas/ Cuentas Cobrar
 4 Perı́odo promedio de cobro (PPC): 365/RCC
 ▶ Número de dı́as que le toma a la empresa cobrar la venta a crédito
 Prof: Augusto Orellana Clase 9: Razones Financieras 11 / 19

[pág. 12]
Razones Financieras: Utilización de pasivos
Eficiencia con la empresa maneja sus obligaciones de CP
 1 Rotación de cuentas por pagar (RCP): Costo de Ventas (COGS)/
 Cuentas Pagar
 ▶ Cuantas veces la empresa pagó sus compras a crédito, asumiendo que
 todos sus costos de ventas son a crédito
 2 Perı́odo promedio de pago (PPP): 365/RCP
 ▶ Número de dı́as que le toma a la empresa pagar la compra a crédito:
 Prof: Augusto Orellana Clase 9: Razones Financieras 12 / 19

[pág. 13]
Razones Financieras: Net Working Capital
Capacidad de una firma de operar en el corto plazo
 1 Working Capital (WC): Activo CP - Pasivo CP
 2 Net Working Capital (NWC): Activo CP - Caja - Pasivo CP
 3 Rotación de Capital de Trabajo: Ventas/NWC
 4 Rotación de Activos Fijos: Ventas/ Activo Fijo
 5 Rotación de Activos: Ventas/ Activo Total
 Prof: Augusto Orellana Clase 9: Razones Financieras 13 / 19

[pág. 14]
Roadmap
1 Liquidez
2 Solvencia
3 Rentabilidad
4 Working Capital
5 Ciclo de Caja
6 Limitaciones
 Prof: Augusto Orellana Clase 9: Razones Financieras 14 / 19

[pág. 15]
Razones Financieras: Utilización de activos
Capacidad de convertir inversiones en inventario y en efectivo
 ¿Cuán eficientemente genera y reinvierte el efectivo?
 Prof: Augusto Orellana Clase 9: Razones Financieras 15 / 19

[pág. 16]
Roadmap
1 Liquidez
2 Solvencia
3 Rentabilidad
4 Working Capital
5 Ciclo de Caja
6 Limitaciones
 Prof: Augusto Orellana Clase 9: Razones Financieras 16 / 19

[pág. 17]
Limitaciones del Análisis Financiero
Uso de base devengada
 Los resultados se registran cuando se incurren, no caja.
 1 Utilidad versus flujo de caja
 ⋆ Alta utilidad, pero poca caja real. Ej: vendió a crédito y aún no cobra
 2 Activos que no necesariamente generan caja
 ⋆ Intangibles, cuentas por cobrar, goodwills
Resultado dependiente de la práctica contable
 Dependencia del criterio contable
 1 Provisiones
 ⋆ Dependen de estimaciones (incobrables, juicios, garantı́as)
 2 Depreciaciones y Amortizaciones de intangibles
 3 Indemnizaciones por Años de Servicio
 4 FIFO vs Promedio (inventarios)
 ⋆ FIFO tiende a mostrar utilidad más alta (costo más bajo)
 Prof: Augusto Orellana Clase 9: Razones Financieras 17 / 19

[pág. 18]
Limitaciones del Análisis Financiero
Interpretación: riesgos de comparar sin contexto
 Incluso con números correctos, interpretarlos mal es fácil
 1 Deuda versus Patrimonio
 ⋆ Contexto: Industria, pais, zona geografica, etc
 2 Estacionalidad
 ⋆ Empresas estacionales (retail, turismo, agricultura) pueden verse mal en
 ciertos meses
Importancia del Timing
 Prof: Augusto Orellana Clase 9: Razones Financieras 18 / 19

[pág. 19]
Limitaciones del Análisis Financiero
Earning management/manipulation
 Prof: Augusto Orellana Clase 9: Razones Financieras 19 / 19

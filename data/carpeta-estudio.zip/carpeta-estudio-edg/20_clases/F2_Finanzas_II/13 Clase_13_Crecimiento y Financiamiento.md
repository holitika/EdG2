# Finanzas II · 13 Clase_13_Crecimiento y Financiamiento

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 13: Crecimiento y Financiamiento
 Profesor: Augusto Orellana
 Abril 2026
Prof: Augusto Orellana Clase 13: Crecimiento 1 / 15

[pág. 2]
Roadmap
1 Crecimiento interno
2 Crecimiento sustentable
 Prof: Augusto Orellana Clase 13: Crecimiento 2 / 15

[pág. 3]
Roadmap
1 Crecimiento interno
2 Crecimiento sustentable
 Prof: Augusto Orellana Clase 13: Crecimiento 3 / 15

[pág. 4]
Crecimiento interno
Tasa de crecimiento interno
 Máxima tasa de crecimiento que se puede lograr sin fin externo
 ▶ Sin modificar el nivel de pasivos, pero si equity
 ROA ∗ b
 Internal growth rate =
 (1 − ROA ∗ b)
Donde b = Tasa de Retención de Utilidades
 Prof: Augusto Orellana Clase 13: Crecimiento 4 / 15

[pág. 5]
Crecimiento interno
 Prof: Augusto Orellana Clase 13: Crecimiento 5 / 15

[pág. 6]
Roadmap
1 Crecimiento interno
2 Crecimiento sustentable
 Prof: Augusto Orellana Clase 13: Crecimiento 6 / 15

[pág. 7]
Crecimiento sustentable
¿Cuán rápido pueden crecer las ventas asumiendo márgenes de utilidad,
ratio de D/E y ratio de dividendos/utilidad (‘payout ratio’) fijos?
Tasa de crecimiento sustentable (TCS)
 Máxima tasa de crecimiento dada capacidad de producción,
 estructura de capital y dividendos.
 ▶ Modificando equity y pasivos
 Prof: Augusto Orellana Clase 13: Crecimiento 7 / 15

[pág. 8]
Crecimiento sustentable: Modelo de Higgins
Supuestos
 Activos crecen proporcionalmente con las ventas
 Utilidad neta es un porcentaje fijo de las ventas
 Polı́tica de dividendos (1-b) y una razón deuda/capital (D/E) fija
 Equity fijo
Definiciones
 m= margen de utilidad neta (utilidad neta /ventas)
 D/E = razón deuda a patrimonio
 b = tasa de retención de utilidades
 A/S = razón de activos a ventas (inverso de rotación)
 S0 = ventas anuales último año
 ∆S = aumento en ventas respecto a último año
 Prof: Augusto Orellana Clase 13: Crecimiento 8 / 15

[pág. 9]
Crecimiento sustentable: Modelo de Higgins
Fuente de Fondos:
 ∆ Utilidades:
 m ∗ (S0 + ∆S) ∗ b
 Nueva deuda (para mantener D/E fijo)
 m ∗ (S0 + ∆S) ∗ b ∗ D/E
Uso de Fondos:
 ∆ Activos:
 ∆S ∗ A/S
Tasa de crecimiento sustentable:
 Fuente de Fondos= Uso de Fondos
 ∆S m ∗ b ∗ (1 + D/E )
 tcs = =
 S0 A/S − m ∗ b + (1 + D/E )
 Prof: Augusto Orellana Clase 13: Crecimiento 9 / 15

[pág. 10]
Close-up a la Tasa de Crecimiento Sustentable
Cambios en m, b, A/S :
 dtcs dtcs dtcs dtcs
 >0; >0; <0; >0 (1)
 dm db dA/S dD/E
 A mayor m, la firma genera más utilidades, lo que incrementa las
 utilidades retenidas disponibles
 A mayor b, la firma retiene más utilidades, reduciendo la necesidad de
 financiamiento externo
 A mayor A/S, la firma necesita más activos por unidad de ventas,
 cada expansión de ventas requiere mayor inversión
 Prof: Augusto Orellana Clase 13: Crecimiento 10 / 15

[pág. 11]
Crecimiento Sustentable Aproximado
Proxy de Tasa de crecimiento sustentable
 ROE ∗ b
 Proxy tcs =
 (1 − ROE ∗ b)
Donde b = Tasa de Retención de Utilidades
 Prof: Augusto Orellana Clase 13: Crecimiento 11 / 15

[pág. 12]
Crecimiento Sustentable: Modelo de Higgins
 Prof: Augusto Orellana Clase 13: Crecimiento 12 / 15

[pág. 13]
Crecimiento Sustentable: Proxy
 Prof: Augusto Orellana Clase 13: Crecimiento 13 / 15

[pág. 14]
Crecimiento más allá de la sustentabilidad
 Prof: Augusto Orellana Clase 13: Crecimiento 14 / 15

[pág. 15]
Algunas lecciones
 Prof: Augusto Orellana Clase 13: Crecimiento 15 / 15

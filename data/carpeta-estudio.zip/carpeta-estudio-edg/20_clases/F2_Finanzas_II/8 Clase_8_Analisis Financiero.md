# Finanzas II · 8 Clase_8_Analisis Financiero

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 8: Análisis Financiero
 Profesor: Augusto Orellana
 Marzo 2026
Prof: Augusto Orellana Clase 8: Análisis Financiero 1 / 21

[pág. 2]
Roadmap
1 Objetivos
2 Análisis cualitativo
3 Análisis cuantitativo
 Prof: Augusto Orellana Clase 8: Análisis Financiero 2 / 21

[pág. 3]
Roadmap
1 Objetivos
2 Análisis cualitativo
3 Análisis cuantitativo
 Prof: Augusto Orellana Clase 8: Análisis Financiero 3 / 21

[pág. 4]
Objetivo del Análisis Financiero
“Entender y calificar la posición financiera de la empresa”
 Desempeño: Situación actual de la empresa
 Sostenibilidad: Futuro de la empresa
¿Cómo analizar?: Dos aspectos a considerar
 1 Tipo Analisis:
 ▶ Cualitativo
 ▶ Cuantitativo
 2 Punto de referencia:
 ▶ Empresa: ¿Cómo evoluciona en el tiempo?
 ▶ Grupo comparable (e.g., industria)
 Prof: Augusto Orellana Clase 8: Análisis Financiero 4 / 21

[pág. 5]
Roadmap
1 Objetivos
2 Análisis cualitativo
3 Análisis cuantitativo
 Prof: Augusto Orellana Clase 8: Análisis Financiero 5 / 21

[pág. 6]
Análisis Financiero Cualitativo
¿Por qué es importante el análisis cualitativo?
 Evalúa factores no cuantificables
 Util para diagnosticar desempeño de la empresa
En qué fijarnos?:
 Riesgos y oportunidades
Aplicamos el análisis cualitativo a los dos puntos de referencia:
 1 Empresa
 2 Industria
 Prof: Augusto Orellana Clase 8: Análisis Financiero 6 / 21

[pág. 7]
Análisis Financiero Cualitativo: Empresa
¿En qué cosas fijarnos?
 Fortalezas vs. debilidades
 Capacidad instalada
 Recursos humanos/Administración
 CEO Value
 Prof: Augusto Orellana Clase 8: Análisis Financiero 7 / 21

[pág. 8]
Análisis Financiero Cualitativo: Industria
¿En qué cosas fijarnos?
 ¿Tiene economı́as de escala?
 ¿Es procı́clica? ¿Qué tanto le afecta la inflación?
 ¿Cómo la afecta la regulación?
 Grado de competencia. ¿Hay monoplios?
 Prof: Augusto Orellana Clase 8: Análisis Financiero 8 / 21

[pág. 9]
Covid-19 shock: Ganadores y Perdedores
 Prof: Augusto Orellana Clase 8: Análisis Financiero 9 / 21

[pág. 10]
Contagio across-sectors
 Prof: Augusto Orellana Clase 8: Análisis Financiero 10 / 21

[pág. 11]
Análisis Financiero Cualitativo: Medición
¿Qué herramienta utilizamos para medir?: Análisis de Porter
 Prof: Augusto Orellana Clase 8: Análisis Financiero 11 / 21

[pág. 12]
Análisis Financiero Cualitativo: Medición
 Análisis de Porter: Proveedores
 Numero de proveedores
 Nivel de dependencia/especialización (hold-up risk)
 Nacionales vs. extranjeros (FX risk)
 Prof: Augusto Orellana Clase 8: Análisis Financiero 12 / 21

[pág. 13]
Análisis Financiero Cualitativo: Medición
 Análisis de Porter: Clientes
 Numero de clientes
 Nivel de dependencia/especialización (hold-up risk)
 Nacionales vs. extranjeros (FX risk)
 Lealtad/fidelización
 Post-venta
 Prof: Augusto Orellana Clase 8: Análisis Financiero 13 / 21

[pág. 14]
Análisis Financiero Cualitativo: Medición
 Análisis de Porter: Productos Sustitutos
 Factibilidad tecnica
 Factibilidad economica
 Mecanismo de protección
 Canibalismo entre productos propios (iphone Air vs 17)
 Prof: Augusto Orellana Clase 8: Análisis Financiero 14 / 21

[pág. 15]
Análisis Financiero Cualitativo: Medición
 Análisis de Porter: Entrada de competidores
 Barreras de entrada
 Estrategias de defensa
 Abdnormal returns
 Prof: Augusto Orellana Clase 8: Análisis Financiero 15 / 21

[pág. 16]
Análisis Financiero Cualitativo: Ejemplo 1
 Empresa Pesquera:
 Disponibilidad de Recursos Pesqueros:
 ▶ variabilidad de especies
 Volatilidad del precio de la Harina y Aceite de Pescado:
 ▶ Sensibilidad a precios internacionales
 Riesgo Cambiario:
 ▶ Mayorı́a de empresas son exportadoras
 Regulaciones:
 ▶ Cuotas de pesca y vedas
 Presiones Ambientales
 Prof: Augusto Orellana Clase 8: Análisis Financiero 16 / 21

[pág. 17]
Análisis Financiero Cualitativo: Ejemplo 2
Empresa de Pintura:
 Sensibilidad ante las variaciones de la Actividad Económica:
 ▶ Muy dependiente del sector construcción
 Competencia:
 ▶ Muy fuerte. ¡Muy fácil entrar!
 Costo de la Materia Prima (MP):
 ▶ MP son derivados del petróleo con precios con grandes fluctuaciones
 Riesgo Cambiario:
 ▶ Mayorı́a de empresas importa la MP
 Poder de Negociación de las Tiendas
 ▶ 52% de las ventas son a grandes cadenas (Homecenter, Easy)
 Prof: Augusto Orellana Clase 8: Análisis Financiero 17 / 21

[pág. 18]
Roadmap
1 Objetivos
2 Análisis cualitativo
3 Análisis cuantitativo
 Prof: Augusto Orellana Clase 8: Análisis Financiero 18 / 21

[pág. 19]
Análisis Financiero Cuantitativo
¿Por qué es importante el análisis cuantitativo?
 Sirve para evaluar la eficiencia usando razones financieras
¿Qué usamos?:
 1 Estados Financieros
 2 Razones Financieras
¿Qué nos va a permitir?:
 1 Comparación Intra-industria vs Inter-industria
 2 Técnicas de corte transversal (cross-section) o Serie de Tiempo
 Prof: Augusto Orellana Clase 8: Análisis Financiero 19 / 21

[pág. 20]
Análisis Financiero Cuantitativo: Estados Financieros
Estados Financieros
 En Base Común (%) ¿Por qué?
 Prof: Augusto Orellana Clase 8: Análisis Financiero 20 / 21

[pág. 21]
Análisis Financiero Cuantitativo: Razones Financieras
Metodologı́a: Tres aspectos relevantes
 Liquidez
 Solvencia de la Deuda (Apalancamiento)
 Rentabilidad (Retorno y Rotación de Activos)
Herramientas: Ratios
 No solo un unico ratio
 Es necesario considerar un conjunto de razones financieras
Analisis vertical y horizontal:
 Prof: Augusto Orellana Clase 8: Análisis Financiero 21 / 21

# Finanzas II · 17 Clase_17_Financiamiento de Largo Plazo

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 17: Financiamiento de Largo Plazo
 Profesor: Augusto Orellana
 Mayo 2026
Prof: Augusto Orellana Clase 17: Financiamiento de LP 1 / 18

[pág. 2]
Roadmap
1 Deuda Corporativa
2 Bonos
3 Risk
4 Bond Covenants
5 Deuda Bancaria
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 2 / 18

[pág. 3]
Roadmap
1 Deuda Corporativa
2 Bonos
3 Risk
4 Bond Covenants
5 Deuda Bancaria
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 3 / 18

[pág. 4]
Deuda Corporativa
¿Existe la deuda óptima?
 Teóricamente sı́, pero ¿qué caracterı́sticas debe tener?
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 4 / 18

[pág. 5]
Tipos de Deuda
 Pública vs. privada
 Corto o largo plazo
 Moneda local o extranjera
 Tasa fija o variable
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 5 / 18

[pág. 6]
Principales formas de la deuda corporativa
Deuda de Largo Plazo
 Deuda con Bancos (Bank Debt/Loan)
 Arrendamiento de Largo Plazo (Leasing Financiero)
 Emisión de bonos (bonds)
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 6 / 18

[pág. 7]
Roadmap
1 Deuda Corporativa
2 Bonos
3 Risk
4 Bond Covenants
5 Deuda Bancaria
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 7 / 18

[pág. 8]
Principales Especificaciones del Contrato de Bonos
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 8 / 18

[pág. 9]
Valoración de bonos
Bond Value = PV of coupons + PV of Face Value
  
 1
 1 − (1+r )t FV
 Value = c +
 r (1 + r )t
 c= FV*rc ; rc : coupon rate
 r = ymt: yield to maturity
 t: maturity
 FV: Face value
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 9 / 18

[pág. 10]
Valoración de bonos: Ejemplo
 Un bono tiene un coupon rate del 8% anual, paga intereses en forma
 anual, madura en tres años, y no hace amortizaciones del principal
 sino hasta el término del perı́odo de maduración, ocasión en la que
 devuelve al inversionista la totalidad del principal (UF 1.000) más el
 interés respectivo.
 ¿Cuál será el precio de mercado de este bono si el rendimiento exigido
 (ytm) es de 9% anual? En su respuesta suponga que el próximo
 cupón se paga en un año más y que el bono no contempla una
 cláusula de rescate anticipado ni de prepago.
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 10 / 18

[pág. 11]
Roadmap
1 Deuda Corporativa
2 Bonos
3 Risk
4 Bond Covenants
5 Deuda Bancaria
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 11 / 18

[pág. 12]
Riesgo de Bonos
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 12 / 18

[pág. 13]
Roadmap
1 Deuda Corporativa
2 Bonos
3 Risk
4 Bond Covenants
5 Deuda Bancaria
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 13 / 18

[pág. 14]
Covenants
Definición
 Cláusulas contractuales que limitan acciones del emisor que podrı́an
 reducir su capacidad de pago.
Ejemplos de restricciones
 Lı́mites al pago de dividendos
 Restricciones a nueva deuda
 Requerimientos mı́nimos de capital de trabajo
 Restricciones a venta de activos, fusiones o creación de garantı́as
Implicancias económicas
 Reducen el riesgo de default.
 Permiten a la empresa obtener menores tasas de interés.
 El menor costo de financiamiento puede compensar la pérdida de
 flexibilidad financiera.
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 14 / 18

[pág. 15]
Covenants: Real world example
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 15 / 18

[pág. 16]
Roadmap
1 Deuda Corporativa
2 Bonos
3 Risk
4 Bond Covenants
5 Deuda Bancaria
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 16 / 18

[pág. 17]
Tipos de deudas bancarias
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 17 / 18

[pág. 18]
Prioridades de Pago
 Prof: Augusto Orellana Clase 17: Financiamiento de LP 18 / 18

# Finanzas II · 26 Clase_26_Opciones_Reales-1

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 26: Opciones Reales
 Profesor: Augusto Orellana
 Junio 2026
Prof: Augusto Orellana Clase 26: Opciones Reales 1 / 18

[pág. 2]
Roadmap
1 Motivación
2 Opciones Reales
3 Momento Optimo
4 Opción de Abandono
5 Tamaño óptimo
 Prof: Augusto Orellana Clase 26: Opciones Reales 2 / 18

[pág. 3]
Roadmap
1 Motivación
2 Opciones Reales
3 Momento Optimo
4 Opción de Abandono
5 Tamaño óptimo
 Prof: Augusto Orellana Clase 26: Opciones Reales 3 / 18

[pág. 4]
Prof: Augusto Orellana Clase 26: Opciones Reales 4 / 18

[pág. 5]
Prof: Augusto Orellana Clase 26: Opciones Reales 5 / 18

[pág. 6]
Roadmap
1 Motivación
2 Opciones Reales
3 Momento Optimo
4 Opción de Abandono
5 Tamaño óptimo
 Prof: Augusto Orellana Clase 26: Opciones Reales 6 / 18

[pág. 7]
Opciones Reales
Idea central
Una opción es el derecho, pero no la obligación, de realizar una acción en
el futuro.
 ■ Muchos proyectos entregan flexibilidad para reaccionar a nueva
 información.
 ■ La empresa ejercerá esa flexibilidad sólo si le conviene.
 ■ Por ello, las opciones reales suelen agregar valor al proyecto.
 Invertir hoy puede abrir oportunidades valiosas mañana.
 Prof: Augusto Orellana Clase 26: Opciones Reales 7 / 18

[pág. 8]
¿Qué flexibilidades ofrece un proyecto?
 ■ Timing: esperar.
 ■ Abandono: salir si las cosas salen mal.
 ■ Tamaño: expandir o contraer operaciones.
 ■ Expansión: crecer si las condiciones son favorables.
 VPNEstratégico = VPNTradicional + Valor de las Opciones
 Prof: Augusto Orellana Clase 26: Opciones Reales 8 / 18

[pág. 9]
Roadmap
1 Motivación
2 Opciones Reales
3 Momento Optimo
4 Opción de Abandono
5 Tamaño óptimo
 Prof: Augusto Orellana Clase 26: Opciones Reales 9 / 18

[pág. 10]
Momento óptimo para invertir / desinvertir
Ejemplo. Una empresa forestal posee un bosque que puede talar en
cualquier momento durante los próximos 8 años.
Esperar tiene un costo Esperar tiene un beneficio
 Mayor inversión en caminos Los árboles siguen creciendo
 Más maquinaria y personal Mayor volumen de madera
 Mayor costo de operación Mayores ingresos futuros
 Año de corte 0 1 2 3 4 5 6 7 8
 50 64,4 77,5 89,4 100 109,4 118,7 127,0 134,1
Pregunta
 Si el costo de oportunidad es 10% anual, ¿en qué año deberı́a talarse
 el bosque?
 Prof: Augusto Orellana Clase 26: Opciones Reales 10 / 18

[pág. 11]
Cálculo: VPN marginal y TIR marginal
1. VPN marginal
Traemos cada VPN futuro a valor presente:
 VPNt
 VPN0 (t) =
 (1 + r )t
Por ejemplo, si se corta en el año 4:
 100
 VPN0 (4) = = 68, 3
 (1, 10)4
2. TIR marginal
Calculamos cuánto crece el valor por esperar un año más:
 VPNt
 TIRmarginal,t = −1
 VPNt−1
Por ejemplo, esperar del año 3 al año 4:
 100
 TIRmarginal,4 = − 1 = 11, 9%
 89, 4
 Prof: Augusto Orellana Clase 26: Opciones Reales 11 / 18

[pág. 12]
Momento óptimo para invertir / desinvertir
 VPN marginal:
 t 0 1 2 3 4 5 6 7 8
 VPN0 (t) 50 58,5 64,0 67,2 68,3 67,9 67,0 65,2 62,6
 TIR marginal:
 t 1 2 3 4 5 6 7 8
 ∆% 28,8% 20,3% 15,4% 11,9% 9,4% 8,5% 7,0% 5,6%
Decisión: maximizamos valor cortando en el año 4.
 Prof: Augusto Orellana Clase 26: Opciones Reales 12 / 18

[pág. 13]
Roadmap
1 Motivación
2 Opciones Reales
3 Momento Optimo
4 Opción de Abandono
5 Tamaño óptimo
 Prof: Augusto Orellana Clase 26: Opciones Reales 13 / 18

[pág. 14]
La opción de abandono
DICOREF evalúa un proyecto de un año que requiere hoy una inversión
inicial de $50 millones.
El proyecto permite vender el próximo año 1 millón de toneladas de
cobre refinado. Para ello, DICOREF tiene un contrato que le da el
derecho, pero no la obligación, de comprar cobre a:
 K = $356 por tonelada
El precio futuro del cobre puede ser:
 (
 $500 con probabilidad 50%
 P1 =
 $300 con probabilidad 50%
El costo de oportunidad del capital es 20% anual y no hay impuestos.
Pregunta: ¿Debe DICOREF realizar el proyecto?
 Prof: Augusto Orellana Clase 26: Opciones Reales 14 / 18

[pág. 15]
Valor de la flexibilidad: opción de abandono
Sin flexibilidad
 E [P1 ] = 0, 5(300) + 0, 5(500) = 400
 (400 − 356) × 1MM
 VPN = −50MM + = −13, 33MM < 0
 1, 2
 No conviene
Con flexibilidad
Si P1 = 500 por Ton
 (500 − 356) × 1MM
 VPN = −50 + = 78, 58MM
 1, 2
Si P1 = 300 por Ton
 VPN = −50MM
 E [VPN] = 0, 5(78, 58) + 0, 5(−50) = 14, 29MM
 Sı́ conviene
 Prof: Augusto Orellana Clase 26: Opciones Reales 15 / 18

[pág. 16]
Roadmap
1 Motivación
2 Opciones Reales
3 Momento Optimo
4 Opción de Abandono
5 Tamaño óptimo
 Prof: Augusto Orellana Clase 26: Opciones Reales 16 / 18

[pág. 17]
Tamaño óptimo: flexibilidad de tamaño
Conservas Andinas S.A. evalúa construir una nueva planta.
 Proyecto base:
 ▶ Capacidad: 10 millones de tarros por año
 ▶ Inversión: $17 millones
 ▶ Ventas: $15 millones anuales durante 10 años
 ▶ Costos de producción: $9 millones anuales
 ▶ Impuesto: 46%
 ▶ Depreciación lineal en 10 años, sin valor residual
 ▶ Tasa de descuento: 11.4%
 La capacidad puede variar entre 7 y 13 millones de tarros por año (exclusive).
 Cada millón de tarros adicional (o menos) modifica la inversión en $0.8 millones.
 El costo de producción permanece constante en $0.90 por tarro.
 La demanda responde al precio:
 ▶ Una disminución de $0.05 en el precio aumenta la demanda en 1 millón
 de tarros.
 ▶ Si la capacidad se reduce en al menos 1 millón de tarros, el precio
 puede aumentar y mantenerse hasta $1.55.
 ¿Qué capacidad maximiza el VPN del proyecto?
 Prof: Augusto Orellana Clase 26: Opciones Reales 17 / 18

[pág. 18]
Solución
 Capacidad (millones) 8 9 10 11 12
 Ventas 12,40 13,95 15,00 15,95 16,80
 Costos operacionales (7,20) (8,10) (9,00) (9,90) (10,80)
 Depreciación (1,54) (1,62) (1,70) (1,78) (1,86)
 UFCF 3,52 3,90 4,02 4,09 4,10
 VP(UFCF) 19,89 22,04 22,71 23,11 23,17
 Inversión (15,40) (16,20) (17,00) (17,80) (18,60)
 VPN 4,49 5,84 5,71 5,31 4,57
 Ante el aumento de capacidad, que occure con:
 ▶ Flujos operacionales?
 ▶ Inversión inicial?
 ▶ Tamaño óptimo?
 Prof: Augusto Orellana Clase 26: Opciones Reales 18 / 18

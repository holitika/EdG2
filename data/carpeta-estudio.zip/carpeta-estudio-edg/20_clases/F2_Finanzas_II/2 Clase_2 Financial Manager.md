# Finanzas II · 2 Clase_2 Financial Manager

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 2: Funciones, Objetivos y Decisiones del
 Administrador Financiero
 Profesor: Augusto Orellana
 Marzo 2026
Prof: Augusto Orellana Clase 2: Financial Manager 1 / 27

[pág. 2]
Roadmap
1 Financial Management
2 El Rol del Financial Manager
3 The Agency Problem and Control
4 Importancia de la institucionalidad
5 Más allá de los accionistas
6 Conceptos claves
 Prof: Augusto Orellana Clase 2: Financial Manager 2 / 27

[pág. 3]
Roadmap
1 Financial Management
2 El Rol del Financial Manager
3 The Agency Problem and Control
4 Importancia de la institucionalidad
5 Más allá de los accionistas
6 Conceptos claves
 Prof: Augusto Orellana Clase 2: Financial Manager 3 / 27

[pág. 4]
Corporate Finance: 3 grandes areas
 Presupuesto de capital (Capital Budgeting/Investing)
 ▶ Inversiones de largo plazo (long-term investments) Ej. M&As
 ▶ Tamaño (Beneficios > Costos) vs. Timing vs. Riesgo
 Estructura de capital (Capital Structure/ Financing)
 ▶ Short vs. Long-term financing
 ▶ Deuda vs. Patrimonio (Debt vs. Equity)
 ▶ ¿Importa la combinación?
 Capital de trabajo (Working Capital /Cash Management)
 ▶ WK= activos de corto plazo - pasivos de largo plazo
 ▶ ¿Positivo o negativo?
Q: ¿Por qué creen que son relevantes estas decisiones?
 Prof: Augusto Orellana Clase 2: Financial Manager 4 / 27

[pág. 5]
Roadmap
1 Financial Management
2 El Rol del Financial Manager
3 The Agency Problem and Control
4 Importancia de la institucionalidad
5 Más allá de los accionistas
6 Conceptos claves
 Prof: Augusto Orellana Clase 2: Financial Manager 5 / 27

[pág. 6]
El Rol del Financial Manager
Función Objetivo: Maximizar el valor presente de la compañı́a.
 Valor presente de qué? → Ventas? Beneficios?
 ¿Quiénes reciben esos beneficios?
 Capitalización de Mercado (Market Cap)
 Prof: Augusto Orellana Clase 2: Financial Manager 6 / 27

[pág. 7]
Roadmap
1 Financial Management
2 El Rol del Financial Manager
3 The Agency Problem and Control
4 Importancia de la institucionalidad
5 Más allá de los accionistas
6 Conceptos claves
 Prof: Augusto Orellana Clase 2: Financial Manager 7 / 27

[pág. 8]
The Agency Problem and Control
¿Propiedad (Ownership) = Control?
 Separación de control y propiedad
 ▶ Managers: Residual control rights
 ▶ Shareholders (Inversionistas): Residual ownership rights
 ¿Qué pasa con corporaciones vs. empresas de único dueño?
Problemas de agencia (agency problems)
 ¿Cuál creen que es/son las causas de que existan?
 ¿Cuáles creen que son las consecuencias?
 Prof: Augusto Orellana Clase 2: Financial Manager 8 / 27

[pág. 9]
The Agency Problem and Control
Empire Building (Jensen 1986)
 Unrelated Acquisitions
 Expensive offices
Alineación de inventivos
 Executive Compensation
 ▶ ¿Creen que deberı́a ser fijo (salario) o variable (acciones)?
 Oportunidades de crecimiento/Reputación
Otros mecanismos de control
 Consejo (Board): CEO replacement
 Proxy voting: Accionistas buscan reemplazar consejo
 Takeovers/Hostile Acquisitions
 Prof: Augusto Orellana Clase 2: Financial Manager 9 / 27

[pág. 10]
Roadmap
1 Financial Management
2 El Rol del Financial Manager
3 The Agency Problem and Control
4 Importancia de la institucionalidad
5 Más allá de los accionistas
6 Conceptos claves
 Prof: Augusto Orellana Clase 2: Financial Manager 10 / 27

[pág. 11]
Importancia de la institucionalidad
SARBANES-OXLEY (2002)
 Proteger a los inversionistas
 ▶ Ejemplo: Enron (USA)
 ▶ ¿En Chile?
Tres pilares de SOX
 1 Corporate Responsibility and
 Governance
 2 Internal Controls and Financial
 Reporting Quality
 3 Auditor Independence
 Prof: Augusto Orellana Clase 2: Financial Manager 11 / 27

[pág. 12]
Roadmap
1 Financial Management
2 El Rol del Financial Manager
3 The Agency Problem and Control
4 Importancia de la institucionalidad
5 Más allá de los accionistas
6 Conceptos claves
 Prof: Augusto Orellana Clase 2: Financial Manager 12 / 27

[pág. 13]
Más allá de los accionistas
Importancia de los Stakeholders: Friedman 1970 vs Jensen 2001
 Empleados, clientes, proveedores, estado y sociedad
 Prof: Augusto Orellana Clase 2: Financial Manager 13 / 27

[pág. 14]
Roadmap
1 Financial Management
2 El Rol del Financial Manager
3 The Agency Problem and Control
4 Importancia de la institucionalidad
5 Más allá de los accionistas
6 Conceptos claves
 Prof: Augusto Orellana Clase 2: Financial Manager 14 / 27

[pág. 15]
Conceptos claves del Administrador Financiero
 1 Estados Financieros (Financial Statements)
 ▶ Balance sheet
 ▶ Income Statement
 ▶ Cash flows
 2 Riesgo y Retorno
 ▶ Liquidez
 ▶ Rentabilidad
 ▶ Apalancamiento
 ▶ Valor de Mercado
 Prof: Augusto Orellana Clase 2: Financial Manager 15 / 27

[pág. 16]
Conceptos Claves: Estados Financieros
(1) Balance sheet: Snapshot of a firm
 Muestra valores contables acumulados en el tiempo (stock)
 Prof: Augusto Orellana Clase 2: Financial Manager 16 / 27

[pág. 17]
Conceptos claves del Administrador Financiero
(1) Balance sheet: Estructura de Capital de la firma
 Acreedores: Pasivos (Debt) vs. Accionistas: Patrimonio (Equity)
 Leverage: D/A ; Debt-to-Equity ratio: D/E
 Prof: Augusto Orellana Clase 2: Financial Manager 17 / 27

[pág. 18]
Conceptos claves del Administrador Financiero
Balance sheet: Snapshot of a firm
 ¿Valor de Mercado = Valor Contable?
 Growth vs. Value stocks
 Prof: Augusto Orellana Clase 2: Financial Manager 18 / 27

[pág. 19]
Conceptos claves del Administrador Financiero
Income Statement: Flujo del performance de la firma
 Prof: Augusto Orellana Clase 2: Financial Manager 19 / 27

[pág. 20]
Conceptos claves del Administrador Financiero
Income Statement: Flujo del performance de la firma
 Ebitda: Capacidad de generar beneficios
 Ebit: Resultado operacional (ROA operacional)
 Net Income (Resultado Neto): ROA, EPS, P/E
 Prof: Augusto Orellana Clase 2: Financial Manager 20 / 27

[pág. 21]
Conceptos claves del Administrador Financiero
Income Statement: Flujo del performance de la firma
 Ebitda: Capacidad de generar beneficios
 Ebit: Resultado operacional (ROA operacional OROA)
 Net Income (Resultado Neto): ROA, ROE, EPS, P/E
 Prof: Augusto Orellana Clase 2: Financial Manager 21 / 27

[pág. 22]
Conceptos claves del Administrador Financiero
Income Statement: Flujo del performance de la firma
 Ebitda: Capacidad de generar beneficios
 Ebit: Resultado operacional (ROA operacional)
 Net Income (Resultado Neto): ROA, EPS, P/E
 Prof: Augusto Orellana Clase 2: Financial Manager 22 / 27

[pág. 23]
Conceptos claves del Administrador Financiero
Income Statement: Flujo del performance de la firma
 Ebitda: Capacidad de generar beneficios
 Ebit: Resultado operacional (ROA operacional)
 Net Income (Resultado Neto): ROA, EPS, P/E
 Prof: Augusto Orellana Clase 2: Financial Manager 23 / 27

[pág. 24]
Conceptos claves del Administrador Financiero
 Prof: Augusto Orellana Clase 2: Financial Manager 24 / 27

[pág. 25]
Conceptos claves del Administrador Financiero
Income Statement: Flujo del performance de la firma
 Ebitda: Capacidad de generar beneficios
 Ebit: Resultado operacional (ROA operacional)
 Net Income (Resultado Neto): ROA, EPS, P/E
 Prof: Augusto Orellana Clase 2: Financial Manager 25 / 27

[pág. 26]
Conceptos claves del Administrador Financiero
 Prof: Augusto Orellana Clase 2: Financial Manager 26 / 27

[pág. 27]
Conceptos claves del Administrador Financiero
Cash Flow Statement: Flujo de efectivo de la firma
 Prof: Augusto Orellana Clase 2: Financial Manager 27 / 27

# Finanzas II · 18 Clase_18_Administracion del Inventario

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 18: Administración del Inventario
 Profesor: Augusto Orellana
 Mayo 2026
Prof: Augusto Orellana Clase 18: Administración del inventario 1 / 20

[pág. 2]
Roadmap
1 Administración de Inventarios
2 Métodos de Administración: ABC
3 Métodos de Administración: LEC
4 Conclusión
 Prof: Augusto Orellana Clase 18: Administración del inventario 2 / 20

[pág. 3]
Roadmap
1 Administración de Inventarios
2 Métodos de Administración: ABC
3 Métodos de Administración: LEC
4 Conclusión
 Prof: Augusto Orellana Clase 18: Administración del inventario 3 / 20

[pág. 4]
Administración de Inventarios/Existencias
Costos de mantener inventario
 Costo financiero de recursos inmovilizados
 ▶ Costo de oportunidad
 Costo de almacenamiento
 ▶ e.g., administrativos, control, seguros, impuestos, mermas
Costos de déficit de inventario
 Costos de Reposición: tener que ordenar seguido
 Pérdida de clientes/prioridad
 Producción interrumpida (falta de mantenimiento)
 Prof: Augusto Orellana Clase 18: Administración del inventario 4 / 20

[pág. 5]
Minimizar Costos Totales
 Buscamos estimar especı́ficamente el punto mı́nimo del costo total
 Los costos de mantenimiento (reposición) del inventario aumentan
 (disminuyen) con el inventario (Q).
 Prof: Augusto Orellana Clase 18: Administración del inventario 5 / 20

[pág. 6]
Determinates del inventario
 1 Tamaño de la empresa (e.g., volumen de producción y ventas)
 2 Caracterı́sticas del proveedor y variedad de productos (e.g., volumen,
 estabilidad financiera, conveniencia)
 3 Valor unitario
 4 Costo de mantención (e.g., refrigeración, administración)
 5 Costo oportunidad de la inversión
 6 Estacionalidad de Ventas
 7 Vencimiento / obsolescencia
 8 Penalidad del desabastecimiento (costo de quedarse sin producto)
 9 Economias de escala
 10 Sistema de ventas / distribución (e.g., por órdenes, mayorista,
 minorista)
 11 Localización
 Prof: Augusto Orellana Clase 18: Administración del inventario 6 / 20

[pág. 7]
Roadmap
1 Administración de Inventarios
2 Métodos de Administración: ABC
3 Métodos de Administración: LEC
4 Conclusión
 Prof: Augusto Orellana Clase 18: Administración del inventario 7 / 20

[pág. 8]
Enfoque ABC
Divide el inventario en 3+ grupos según valor y porcentaje
 Grupo A: Estrechamente supervisado y con niveles de inventario
 relativamente bajos
 Grupo C: Artı́culos básicos de inventario (bajo costo). Se piden en
 grandes cantidades.
 Prof: Augusto Orellana Clase 18: Administración del inventario 8 / 20

[pág. 9]
Roadmap
1 Administración de Inventarios
2 Métodos de Administración: ABC
3 Métodos de Administración: LEC
4 Conclusión
 Prof: Augusto Orellana Clase 18: Administración del inventario 9 / 20

[pág. 10]
Modelo del Lote Económico de Compra (LEC)
Enfoque más conocido para establecer explı́citamente un nivel óptimo de
inventario.
Caracterı́sticas:
 Fácil de usar
 Base de modelos más sofisticados. Adaptable para más complejidad
Principales supuestos:
 Único producto con abastecimiento instantáneo
 Demanda es continua y uniforme
 Toda la demanda debe satisfacerse
 Variables del modelo son determinı́sticas
 Prof: Augusto Orellana Clase 18: Administración del inventario 10 / 20

[pág. 11]
Agotamiento del Inventario
El inventario se vende a una tasa constante hasta agotarse.
 Prof: Augusto Orellana Clase 18: Administración del inventario 11 / 20

[pág. 12]
Costos estimados
Costos de Mantenimiento:
 Se estiman en función al promedio de la cantidad de inventario (Q),
 por el costo unitario de almacenamiento (CC)
 Q
 CM = ∗ CC
 2
Costos de Reposición:
 Costos fijos respecto por pedido (F) multiplicado por el numero de
 pedidos (T/Q)
 T: unidades vendidas
 T
 CR = F ∗
 Q
 Prof: Augusto Orellana Clase 18: Administración del inventario 12 / 20

[pág. 13]
Costos Inventario y Cantidad Óptima
Costos Total
 Q T
 CI = ∗ CC + F ∗
 2 Q
Cantidad Optima:
 r
 2T ∗ F
 Q=
 CC
 Prof: Augusto Orellana Clase 18: Administración del inventario 13 / 20

[pág. 14]
Ejemplo 1
 En cada perı́odo la empresa inicia con 100 unidades de inventario y
 las vende completamente. Si el costo unitario de mantenimiento es
 $2, ¿cuál es el costo total de mantenimiento?
 100
 CM = ∗ 2 = 100
 2
 La empresa vende 600 pares de botas al año. ¿Cuántas veces se
 reabastece? Si el costo de reposición es $24 por pedido, ¿cuál es el
 costo total de reposición anual?
 600
 CR = 24 ∗ = 144
 100
 ¿Cuál serı́a el tamaño de pedido óptimo para la empresa? ¿Cuál serı́a
 el costo del inventario?
 r
 ∗ 2 ∗ 600 ∗ 24
 CI = 244 ; Q = = 120
 2
 Prof: Augusto Orellana Clase 18: Administración del inventario 14 / 20

[pág. 15]
Ejemplo 2: Descuentos por Volumen
 La compañı́a competidora H&N también vende 600 unidades por año,
 con un costo de mantenimiento unitario anual de $8, siendo el costo
 del producto (costo de acquirir los insumos) $5 y el costo por pedido
 $24. ¿Cuál será el tamaño de pedido óptimo, costo de inventario total
 y costo del producto?
 r
 ∗ 2 ∗ 600 ∗ 24 60 600
 Q = = 60 ; CI = ∗ 8 + 24 ∗ = 480
 8 2 60
 CP = 3000 ; CT = 480 + 3000 = 3480
 Prof: Augusto Orellana Clase 18: Administración del inventario 15 / 20

[pág. 16]
Ejemplo 2: Descuentos por Volumen
 Ahora considere que se ofrecen descuentos por volumen de pedido
 (descuento en el costo de acquisicion de insumos), ¿conviene ser
 ineficiente en la administración del inventario para acceder al
 descuento por volumen?
 ▶ Q=0-60 ; Descuento = 0%
 ▶ Q=61-120 ; Descuento = 10%
 ▶ Q>120; Descuento = 15%
Si Q ∗ = 61:
 61 600
 ∗ 8 + 24 ∗
 CI = = 480.07
 2 61
 ∆CI = 0.07 ; ∆CP = 5 ∗ 600 ∗ (0.1 − 1) = −300 ; ∆CT = −296.7
 Prof: Augusto Orellana Clase 18: Administración del inventario 16 / 20

[pág. 17]
Caveats
 ¿Costo total en el margen para 61 vs 121 unidades?
 600/61, pedido entero??
 Prof: Augusto Orellana Clase 18: Administración del inventario 17 / 20

[pág. 18]
Roadmap
1 Administración de Inventarios
2 Métodos de Administración: ABC
3 Métodos de Administración: LEC
4 Conclusión
 Prof: Augusto Orellana Clase 18: Administración del inventario 18 / 20

[pág. 19]
Manejo de Inventarios
 Planear hacia atrás:
 ▶ Bienes terminados → Bienes en proceso → Mataerias primas
 Inventario justo a tiempo (JIT): Minimizar inventarios para maximizar
 la rotación
 ▶ Inventarios son objeto de nuevos pedidos y reabastecidos con frecuencia
 ▶ Necesario: alto grado de cooperación entre los proveedores, un grupo
 relativamente reducido y firmemente cohesionado para lograr la
 necesaria coordinación
 Prof: Augusto Orellana Clase 18: Administración del inventario 19 / 20

[pág. 20]
World post-pandemia
 Prof: Augusto Orellana Clase 18: Administración del inventario 20 / 20

# Finanzas II · 16 Clase_16_Modelos de Financiamiento

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
Clase 16: Modelos de Pronóstico de Financiamiento
 Profesor: Augusto Orellana
 Abril 2026
Prof: Augusto Orellana Clase 16: Modelos de Pronóstico 1 / 12

[pág. 2]
Roadmap
1 Métodos de pronóstico
2 Relaciones entre variables
3 Pronóstico financiero integral
4 Ejemplo
 Prof: Augusto Orellana Clase 16: Modelos de Pronóstico 2 / 12

[pág. 3]
Roadmap
1 Métodos de pronóstico
2 Relaciones entre variables
3 Pronóstico financiero integral
4 Ejemplo
 Prof: Augusto Orellana Clase 16: Modelos de Pronóstico 3 / 12

[pág. 4]
Métodos de pronóstico
 1 Método de porcentaje de ventas
 ▶ Ya lo revisamos
 2 Pronósticos de tendencia
 ▶ Pasado como predictor del futuro
 ▶ Buen predictor de estacionalidad
 3 Pronóstico basado en relaciones entre variables
 1 Uso de razones financieras
 2 Métodos estadı́sticos o econométricos
 Prof: Augusto Orellana Clase 16: Modelos de Pronóstico 4 / 12

[pág. 5]
Roadmap
1 Métodos de pronóstico
2 Relaciones entre variables
3 Pronóstico financiero integral
4 Ejemplo
 Prof: Augusto Orellana Clase 16: Modelos de Pronóstico 5 / 12

[pág. 6]
1) Uso de razones financieras
 Variable a estimar = razon ∗ Variable base estimada
Ejemplo:
 Inventarios
 Inventarios = ∗ Activos proyectados
 Activos
 Un caso particular es el ”método de porcentaje de ventas”
 Inventarios
 Inventarios = ∗ Sales proyectados
 Sales
 Prof: Augusto Orellana Clase 16: Modelos de Pronóstico 6 / 12

[pág. 7]
2) Métodos estadı́sticos o econométricos
 Inventarios = α + βSales + ϵ
 Prof: Augusto Orellana Clase 16: Modelos de Pronóstico 7 / 12

[pág. 8]
Roadmap
1 Métodos de pronóstico
2 Relaciones entre variables
3 Pronóstico financiero integral
4 Ejemplo
 Prof: Augusto Orellana Clase 16: Modelos de Pronóstico 8 / 12

[pág. 9]
Pronóstico financiero integral
 Proyección de estados financieros proforma
 ▶ Balance proforma
 ▶ Estado de resultados proforma
 Presupuesto de caja
 ▶ Proyección de flujo de caja operacional
 ▶ Proyección de presupuesto de capital (inversiones y financiamiento)
 Horizonte de tiempo
 ▶ 1 año
 Prof: Augusto Orellana Clase 16: Modelos de Pronóstico 9 / 12

[pág. 10]
Pronóstico financiero integral: Etapas
 1 Presupuesto de ventas
 ▶ Siempre partimos por aqui
 2 Estado de resultados + Flujo de caja
 3 Balance
 Prof: Augusto Orellana Clase 16: Modelos de Pronóstico 10 / 12

[pág. 11]
Roadmap
1 Métodos de pronóstico
2 Relaciones entre variables
3 Pronóstico financiero integral
4 Ejemplo
 Prof: Augusto Orellana Clase 16: Modelos de Pronóstico 11 / 12

[pág. 12]
Pronóstico financiero integral: Etapas
 Con la información que se entrega a continuación, se pide preparar las
 siguientes proyecciones financieras de la empresa “XYZ” para el
 perı́odo enero – junio del próximo año:1
 1 Presupuesto de caja mensual
 2 Necesidades de financiamiento mensual
 3 Plan financiero mensual
 4 Estado de resultados proyectado perı́odo enero junio
 5 Balance proforma al 30 de junio
 1
 Ejemplo desarrollado por el profesor Julio Gálvez. Solo se modificó el nombre de la
empresa.
 Prof: Augusto Orellana Clase 16: Modelos de Pronóstico 12 / 12

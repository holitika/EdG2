# Finanzas II · 15 Clase_15_Patrones de Financiamiento Roher

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
Clase 15: Patrones de Financiamiento: Caso Roher
 Profesor: Augusto Orellana
 Abril 2026
Prof: Augusto Orellana Clase 15: Caso Roher 1/6

[pág. 2]
Roadmap
1 Caso Roher
 Prof: Augusto Orellana Clase 15: Caso Roher 2/6

[pág. 3]
Roadmap
1 Caso Roher
 Prof: Augusto Orellana Clase 15: Caso Roher 3/6

[pág. 4]
Caso Roher
 El gerente de finanzas de “Roher” ha completado su presupuesto de
 caja para los próximos dos años. Los flujos de caja estimados son los
 siguientes (en millones):
 Prof: Augusto Orellana Clase 15: Caso Roher 4/6

[pág. 5]
Caso Roher
 El gerente de finanzas ha seleccionado 5 planes de financiamiento
 alternativos:
 1 Lı́nea de crédito por $3 millones y crédito de largo plazo por $6
 millones al inicio del segundo trimestre
 2 Financiamiento con préstamos bancarios a 90 dı́as según sea necesario
 3 Crédito por $9 millones tomado el segundo trimestre pagadero a largo
 plazo
 4 Lı́nea de crédito por $6,5 millones y crédito de largo plazo por $2
 millones al inicio del segundo trimestre
 5 Crédito de largo plazo por $2 millones y utilizar crédito de proveedores
 según necesidades
 Prof: Augusto Orellana Clase 15: Caso Roher 5/6

[pág. 6]
Caso Roher
 El gerente de finanzas lo contrata para asesorarlo. Responda las
 siguientes preguntas:
 a) Calcular el financiamiento permanente necesario para esta empresa
 b) Calcular el máximo financiamiento temporal y cuando ocurre
 c) Evaluar cada uno de los 5 planes en términos del principio de
 correspondencia o calce
 d) Calcular los costos financieros de los planes 1,2 y 4 para el perı́odo de
 dos años. Utilice la siguiente información:
 ⋆ Tasa de interés deuda de largo plazo 9% anual (interés simple)
 ⋆ Tasa de interés créditos de corto plazo 2% trimestral, simple
 ⋆ Tasa de interés de captación de corto plazo 1,5% trimestral simple
 e) ¿Cuál plan elegirı́a usted considerando los costos financieros y lo
 evaluado en c)?
 El financiamiento se requiere a inicios de cada trimestre
 Prof: Augusto Orellana Clase 15: Caso Roher 6/6

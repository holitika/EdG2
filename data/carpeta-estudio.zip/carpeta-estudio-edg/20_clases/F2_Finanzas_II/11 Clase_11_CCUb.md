# Finanzas II · 11 Clase_11_CCUb

Fuente: clase de Finanzas II

[pág. 1]
COMPAÑÍA CERVECERÍAS UNIDAS S.A. Y SUBSIDIARIAS
 ESTADOS FINANCIEROS CONSOLIDADOS
 (Cifras expresadas en miles de pesos chilenos)
 Correspondiente al ejercicio terminado
 al 31 de diciembre de 2024

[pág. 2]
INFORME DEL AUDITOR INDEPENDIENTE
Santiago, 25 de febrero de 2025
Señores Accionistas y Directores
Compañía Cervecerías Unidas S.A.
Opinión
Hemos efectuado una auditoría a los estados financieros consolidados de Compañía Cervecerías Unidas
S.A. y subsidiarias, que comprenden los estados consolidados de situación financiera al 31 de diciembre
de 2024 y 2023 y los correspondientes estados consolidados de resultados por función, de resultados
integrales, de cambios en el patrimonio y de flujos de efectivo por los años terminados al 31 de diciembre
de 2024, 2023 y 2022 y las correspondientes notas a los estados financieros consolidados.
En nuestra opinión, los estados financieros consolidados adjuntos presentan razonablemente, en todos
sus aspectos significativos, la situación financiera de Compañía Cervecerías Unidas S.A. y subsidiarias
al 31 de diciembre de 2024 y 2023, los resultados de sus operaciones y sus flujos de efectivo por los años
terminados al 31 de diciembre de 2024, 2023 y 2022 de acuerdo con Normas Internacionales de
Información Financiera emitidas por el International Accounting Standards Board.
Base para la opinión
Efectuamos nuestras auditorías de acuerdo con Normas de Auditoría Generalmente Aceptadas en Chile.
Nuestras responsabilidades de acuerdo a tales normas se describen, posteriormente, en los párrafos bajo
la sección “Responsabilidades del auditor por la auditoría de los estados financieros consolidados del
presente informe. De acuerdo a los requerimientos éticos pertinentes, para nuestras auditorías de los
estados financieros consolidados, se nos requiere ser independientes de Compañía Cervecerías Unidas
S.A. y subsidiarias y cumplir con las demás responsabilidades éticas de acuerdo a tales requerimientos.
Consideramos que la evidencia de auditoría que hemos obtenido es suficiente y apropiada para
proporcionarnos una base para nuestra opinión de auditoría.
Responsabilidad de la Administración por los estados financieros consolidados
La Administración es responsable por la preparación y presentación razonable de los estados financieros
consolidados de acuerdo con Normas Internacionales de Información Financiera emitidas por el
International Accounting Standards Board. Esta responsabilidad incluye el diseño, implementación y
mantención de un control interno pertinente para la preparación y presentación razonable de estados
financieros consolidados que estén exentos de representaciones incorrectas significativas, ya sea debido
a fraude o error.

[pág. 3]
Santiago, 25 de febrero de 2025
Compañía Cervecerías Unidas S.A.
2
Al preparar y presentar los estados financieros consolidados, se requiere que la Administración evalúe
si existen hechos o circunstancias que, considerados como un todo, originen una duda sustancial acerca
de la capacidad de Compañía Cervecerías Unidas S.A. y subsidiarias para continuar como una empresa
en marcha por al menos doce meses a partir del final del período que se reporta, sin limitarse a dicho
período.
Responsabilidades del auditor por la auditoría de los estados financieros consolidados
Nuestros objetivos son obtener una seguridad razonable de que los estados financieros consolidados
como un todo, están exentos de representaciones incorrectas significativas debido a fraude o error y
emitir un informe del auditor que incluya nuestra opinión. Una seguridad razonable es un alto, pero no
absoluto, nivel de seguridad y, por lo tanto, no garantiza que una auditoría realizada de acuerdo con
Normas de Auditoría Generalmente Aceptadas en Chile siempre detectará una representación incorrecta
significativa cuando exista. El riesgo de no detectar una representación incorrecta significativa debido a
fraude es mayor que el riesgo de no detectar una representación incorrecta significativa debido a un
error, ya que el fraude puede involucrar colusión, falsificación, omisiones intencionales, ocultamiento,
representaciones inadecuadas o hacer caso omiso de los controles por parte de la Administración. Una
representación incorrecta se considera significativa si, individualmente, o de manera agregada, podría
influir el juicio que un usuario razonable realiza en base a estos estados financieros consolidados.
Como parte de una auditoría realizada de acuerdo con Normas de Auditoría Generalmente Aceptadas
en Chile nosotros:
● Ejercemos nuestro juicio profesional y mantenemos nuestro escepticismo profesional durante toda
 la auditoría.
● Identificamos y evaluamos los riesgos de representaciones incorrectas significativas de los estados
 financieros consolidados, ya sea debido a fraude o error, diseñamos y realizamos procedimientos de
 auditoría en respuesta a tales riesgos. Tales procedimientos incluyen el examen, en base a pruebas,
 de evidencia con respecto a los montos y revelaciones en los estados financieros consolidados.
● Obtenemos un entendimiento del control interno pertinente para una auditoría con el objeto de
 diseñar procedimientos de auditoría que sean apropiados en las circunstancias, pero sin el propósito
 de expresar una opinión sobre la efectividad del control interno de Compañía Cervecerías Unidas
 S.A. y subsidiarias. En consecuencia, no expresamos tal tipo de opinión.
● Evaluamos lo apropiado que son las políticas de contabilidad utilizadas y la razonabilidad de las
 estimaciones contables significativas efectuadas por la Administración y evaluamos lo apropiado de
 la presentación general de los estados financieros consolidados.
● Concluimos si a nuestro juicio existen hechos o circunstancias que, considerados como un todo,
 originen una duda sustancial acerca de la capacidad de Compañía Cervecerías Unidas S.A. y
 subsidiarias para continuar como una empresa en marcha por un período de tiempo razonable.

[pág. 4]
Santiago, 25 de febrero de 2025
Compañía Cervecerías Unidas S.A.
3
Se nos requiere comunicar a los responsables del Gobierno Corporativo, entre otros asuntos, la
oportunidad y el alcance planificados y los hallazgos significativos de la auditoría, incluyendo cualquier
deficiencia significativa y debilidad importante del control interno que identifiquemos durante nuestra
auditoría.
 Renzo Corona Spedaliere
 RUT: 6.373.028-9

[pág. 5]
ÍNDICE
ESTADOS CONSOLIDADOS DE SITUACIÓN FINANCIERA (ACTIVOS) .......................................................... 6
ESTADOS CONSOLIDADOS DE SITUACIÓN FINANCIERA (PASIVOS Y PATRIMONIO)............................... 7
ESTADOS CONSOLIDADOS DE RESULTADOS POR FUNCIÓN ........................................................................ 8
ESTADOS CONSOLIDADOS DE RESULTADOS INTEGRALES .......................................................................... 9
ESTADOS CONSOLIDADOS DE CAMBIOS EN EL PATRIMONIO ................................................................... 10
ESTADOS CONSOLIDADOS DE FLUJOS DE EFECTIVO ................................................................................. 11
NOTA 1 INFORMACIÓN GENERAL ................................................................................................................... 12
NOTA 2 RESUMEN DE LAS PRINCIPALES POLÍTICAS CONTABLES ........................................................... 26
 2.1 Bases de preparación ............................................................................................................................................................ 26
 2.2 Bases de consolidación .......................................................................................................................................................... 26
 2.3 Información financiera por segmentos de operación ............................................................................................................ 27
 2.4 Transacciones en monedas extranjeras y unidades de reajuste ............................................................................................. 28
 2.5 Efectivo y equivalentes al efectivo ......................................................................................................................................... 30
 2.6 Otros activos financieros ....................................................................................................................................................... 30
 2.7 Instrumentos financieros ....................................................................................................................................................... 31
 2.8 Deterioro de activos financieros............................................................................................................................................ 33
 2.9 Inventarios ............................................................................................................................................................................. 34
 2.10 Activos biológicos corrientes ................................................................................................................................................. 34
 2.11 Otros activos no financieros .................................................................................................................................................. 34
 2.12 Propiedades, plantas y equipos ............................................................................................................................................. 34
 2.13 Arrendamientos ..................................................................................................................................................................... 35
 2.14 Propiedades de inversión ...................................................................................................................................................... 36
 2.15 Activos intangibles distintos de plusvalía .............................................................................................................................. 36
 2.16 Plusvalía ................................................................................................................................................................................ 36
 2.17 Deterioro de activos no corrientes distintos de la plusvalía .................................................................................................. 37
 2.18 Activos no corrientes mantenidos para la venta .................................................................................................................... 37
 2.19 Impuesto a las ganancias ...................................................................................................................................................... 37
 2.20 Beneficios a los empleados .................................................................................................................................................... 38
 2.21 Provisiones ............................................................................................................................................................................ 38
 2.22 Reconocimiento de ingresos .................................................................................................................................................. 38
 2.23 Acuerdos comerciales con distribuidores y cadenas de supermercados ............................................................................... 39
 2.24 Costos de venta de productos ................................................................................................................................................ 39
 2.25 Otros ingresos por función .................................................................................................................................................... 40
 2.26 Otros gastos por función ....................................................................................................................................................... 40
 2.27 Costos de distribución ........................................................................................................................................................... 40
 2.28 Gastos de administración ...................................................................................................................................................... 40
 2.29 Medio ambiente ..................................................................................................................................................................... 40
NOTA 3 ESTIMACIONES Y APLICACIONES DEL CRITERIO PROFESIONAL .............................................. 41
NOTA 4 CAMBIOS CONTABLES ........................................................................................................................ 41
NOTA 5 ADMINISTRACIÓN DE RIESGOS ......................................................................................................... 42
NOTA 6 INFORMACIÓN FINANCIERA POR SEGMENTOS DE OPERACIÓN ................................................ 49
NOTA 7 INSTRUMENTOS FINANCIEROS ......................................................................................................... 56
NOTA 8 EFECTIVO Y EQUIVALENTES AL EFECTIVO ................................................................................... 63
NOTA 9 OTROS ACTIVOS NO FINANCIEROS .................................................................................................. 70
NOTA 10 DEUDORES COMERCIALES Y OTRAS CUENTAS POR COBRAR .................................................. 70
NOTA 11 SALDOS Y TRANSACCIONES CON PARTES RELACIONADAS ...................................................... 73
NOTA 12 INVENTARIOS...................................................................................................................................... 80
NOTA 13 ACTIVOS BIOLÓGICOS CORRIENTES ............................................................................................. 81

[pág. 6]
NOTA 14 ACTIVOS NO CORRIENTES MANTENIDOS PARA LA VENTA ....................................................... 82
NOTA 15 COMBINACIONES DE NEGOCIOS ..................................................................................................... 83
NOTA 16 INVERSIONES CONTABILIZADAS POR EL MÉTODO DE LA PARTICIPACIÓN .......................... 85
NOTA 17 ACTIVOS INTANGIBLES DISTINTOS DE PLUSVALÍA .................................................................... 89
NOTA 18 PLUSVALÍA .......................................................................................................................................... 91
NOTA 19 PROPIEDADES, PLANTAS Y EQUIPOS .............................................................................................. 94
NOTA 20 PROPIEDADES DE INVERSIÓN .......................................................................................................... 96
NOTA 21 OTROS PASIVOS FINANCIEROS........................................................................................................ 97
NOTA 22 ARRENDAMIENTOS .......................................................................................................................... 113
NOTA 23 CUENTAS POR PAGAR COMERCIALES Y OTRAS CUENTAS POR PAGAR ................................ 120
NOTA 24 OTRAS PROVISIONES ....................................................................................................................... 120
NOTA 25 IMPUESTOS CORRIENTES, A LAS GANANCIAS Y DIFERIDOS ................................................... 121
NOTA 26 PROVISIÓN POR BENEFICIOS A LOS EMPLEADOS ..................................................................... 125
NOTA 27 OTROS PASIVOS NO FINANCIEROS ............................................................................................... 128
NOTA 28 PATRIMONIO ATRIBUIBLE A LOS PROPIETARIOS DE LA CONTROLADORA......................... 128
NOTA 29 PARTICIPACIONES NO CONTROLADORAS .................................................................................. 133
NOTA 30 COSTOS Y GASTOS POR NATURALEZA ........................................................................................ 135
NOTA 31 OTROS INGRESOS, POR FUNCIÓN ................................................................................................. 135
NOTA 32 OTRAS GANANCIAS (PÉRDIDAS) .................................................................................................... 136
NOTA 33 RESULTADOS FINANCIEROS .......................................................................................................... 136
NOTA 34 EFECTOS DE LAS VARIACIONES EN LAS TASAS DE CAMBIO DE LA MONEDA ...................... 137
NOTA 35 CONTINGENCIAS Y COMPROMISOS ............................................................................................. 141
NOTA 36 MEDIO AMBIENTE ............................................................................................................................ 143
NOTA 37 EVENTOS POSTERIORES ................................................................................................................. 150
 ANEXO I ................................................................................................................................................................................................. 151
 ANEXO II................................................................................................................................................................................................ 153

[pág. 7]
Compañía Cervecerías Unidas S.A. y subsidiarias
Estados Consolidados de Situación Financiera
(Cifras expresadas en miles de pesos chilenos)
 ESTADOS CONSOLIDADOS DE SITUACIÓN FINANCIERA (ACTIVOS)
 Al 31 de Al 31 de
 diciembre de diciembre de
 ACTIVOS Notas 2024 2023
 M$ M$
Activos corrientes
Efectivo y equivalentes al efectivo 8 707.122.815 618.154.016
Otros activos financieros 7 11.899.281 7.440.650
Otros activos no financieros 9 31.143.442 29.674.705
Deudores comerciales y otras cuentas por cobrar 10 506.711.173 446.486.753
Cuentas por cobrar a entidades relacionadas 11 15.501.990 9.040.528
Inventarios 12 459.384.555 425.728.432
Activos biológicos corrientes 13 16.883.106 14.764.284
Activos por impuestos corrientes 25 19.668.196 28.786.247
Total activos corrientes distintos de activos mantenidos para la venta 1.768.314.558 1.580.075.615
Activos no corrientes mantenidos para la venta 14 2.952.282 21.607.472
Total activos no corrientes mantenidos para la venta 2.952.282 21.607.472
Total activos corrientes 1.771.266.840 1.601.683.087
Activos no corrientes
Otros activos financieros 7 30.060.601 29.981.745
Otros activos no financieros 9 13.674.236 12.311.027
Cuentas por cobrar no corrientes 10 5.966.414 3.313.742
Cuentas por cobrar a entidades relacionadas 11 844.344 42.506
Inversiones contabilizadas por método de la participación 16 139.746.921 149.593.180
Activos intangibles distintos de la plusvalía 17 244.632.721 153.123.207
Plusvalía 18 161.583.233 127.592.056
Propiedades, plantas y equipos (neto) 19 1.522.708.449 1.273.987.695
Propiedades de inversión 20 12.666.980 8.121.156
Activos por derechos de uso 22 45.017.172 35.745.221
Activos por impuestos diferidos 25 41.549.079 28.451.658
Total activos no corrientes 2.218.450.150 1.822.263.193
Total activos 3.989.716.990 3.423.946.280
 6
Las notas adjuntas números 1 a 37 forman parte integral de estos Estados Financieros Consolidados

[pág. 8]
Compañía Cervecerías Unidas S.A. y subsidiarias
Estados Consolidados de Situación Financiera
(Cifras expresadas en miles de pesos chilenos)
 ESTADOS CONSOLIDADOS DE SITUACIÓN FINANCIERA ( PASIVOS Y PATRIM ONIO)
 Al 31 de Al 31 de
 PASIVOS Y PATRIMONIO diciembre de diciembre de
 Notas 2024 2023
PASIVOS M$ M$
Pasivos corrientes
Otros pasivos financieros 21 156.202.002 107.151.600
Pasivos por arrendamientos corrientes 22 9.451.551 7.142.360
Cuentas por pagar comerciales y otras cuentas por pagar 23 514.887.185 434.974.163
Cuentas por pagar a entidades relacionadas 11 36.417.518 55.140.630
Otras provisiones a corto plazo 24 2.461.549 2.500.727
Pasivos por impuestos corrientes 25 41.110.171 9.938.664
Provisiones corrientes por beneficios a los empleados 26 48.467.947 38.713.293
Otros pasivos no financieros 27 51.008.288 31.921.197
Total pasivos corrientes 860.006.211 687.482.634
Pasivos no corrientes
Otros pasivos financieros 21 1.234.231.722 1.234.246.107
Pasivos por arrendamientos no corrientes 22 39.782.317 34.061.739
Otras cuentas por pagar 23 45.275 88.596
Cuentas por pagar a entidades relacionadas 11 - 536.083
Otras provisiones a largo plazo 24 2.791.080 217.572
Pasivos por impuestos diferidos 25 127.956.679 86.356.895
Provisiones no corrientes por beneficios a los empleados 26 48.032.415 39.586.368
Otros pasivos no financieros no corrientes 27 4.355.981 3.987.705
Total pasivos no corrientes 1.457.195.469 1.399.081.065
Total pasivos 2.317.201.680 2.086.563.699
PATRIMONIO
Patrimonio neto atribuible a los propietarios de la controladora 28
Capital emitido 562.693.346 562.693.346
Otras reservas (3.288.422) (240.200.116)
Resultados acumulados 965.778.261 895.871.552
Subtotal patrimonio atribuible a los propietarios de la controladora 1.525.183.185 1.218.364.782
Participaciones no controladoras 29 147.332.125 119.017.799
Total patrimonio 1.672.515.310 1.337.382.581
Total pasivos y patrimonio 3.989.716.990 3.423.946.280
 7
Las notas adjuntas números 1 a 37 forman parte integral de estos Estados Financieros Consolidados

[pág. 9]
Compañía Cervecerías Unidas S.A. y subsidiarias
Estados Consolidados de Resultados por Función
(Cifras expresadas en miles de pesos chilenos)
 ESTADOS CONSOLIDADOS DE RESULTADOS POR FUNCIÓN
 Por los ejercicios terminados al 31 de diciembre de
 ESTADOS CONSOLIDADOS DE RESULTADOS POR FUNCIÓN Notas
 2024 2023 2022
 M$ M$ M$
Ingresos por ventas 6 2.904.566.454 2.565.556.067 2.711.434.948
Costos de ventas 30 (1.590.957.777) (1.378.611.966) (1.514.925.309)
Margen bruto 1.313.608.677 1.186.944.101 1.196.509.639
Otros ingresos, por función 31 40.211.510 4.419.789 5.284.666
Costos de distribución 30 (536.420.140) (470.120.810) (504.184.248)
Gastos de administración 30 (214.915.089) (197.256.571) (187.421.796)
Otros gastos, por función 30 (339.783.068) (270.703.334) (278.757.105)
Otras ganancias (pérdidas) 32 (94.937) (13.316.208) (12.669.540)
Ganancias (pérdidas) de actividades operacionales 262.606.953 239.966.967 218.761.616
Ingresos financieros 33 38.102.053 39.402.492 22.870.538
Costos financieros 33 (97.165.278) (77.023.048) (75.930.875)
Participación en utilidad (pérdida) de asociadas y negocios conjuntos contabilizados por
 16 (9.494.703) (19.217.758) (10.978.068)
el método de la participación
Ganancias (pérdidas) de cambio en moneda extranjera 33 (17.797.269) (65.944.570) (20.173.381)
Resultado por unidades de reajuste 33 (10.722.033) (14.025.895) 1.198.565
Utilidad (pérdida) antes de impuestos 165.529.723 103.158.188 135.748.395
Impuestos a las ganancias 25 11.015.074 15.267.255 (263.943)
Utilidad (pérdida) del ejercicio 176.544.797 118.425.443 135.484.452
Utilidad (pérdida) atribuible a:
Propietarios de la controladora 160.944.138 105.652.728 118.168.351
Participaciones no controladoras 29 15.600.659 12.772.715 17.316.101
Utilidad (pérdida) del ejercicio 176.544.797 118.425.443 135.484.452
Utilidad básica por acción (pesos) proveniente de:
Operaciones continuadas 435,57 285,93 319,80
Utilidad diluida por acción (pesos) proveniente de:
Operaciones continuadas 435,57 285,93 319,80
 8
Las notas adjuntas números 1 a 37 forman parte integral de estos Estados Financieros Consolidados

[pág. 10]
Compañía Cervecerías Unidas S.A. y subsidiarias
Estados Consolidados de Resultados Integrales
(Cifras expresadas en miles de pesos chilenos)
 ESTADOS CONSOLIDADOS DE RESULTADOS INTEGRALES
 Por los ejercicios terminados al 31 de diciembre de
 ESTADOS CONSOLIDADOS DE RESULTADOS INTEGRALES Notas
 2024 2023 2022
 M$ M$ M$
 Utilidad (pérdida) del ejercicio 176.544.797 118.425.443 135.484.452
 Otro resultado integral
 Componentes de otro resultado integral que no se reclasificarán al resultado
 del ejercicio, antes de impuestos
 Ganancias (pérdidas) actuariales por planes de beneficios definidos 28 (1.581.040) 1.454.372 (7.103.125)
 Otro resultado integral que no se reclasificará al resultado del ejercicio,
 (1.581.040) 1.454.372 (7.103.125)
 antes de impuestos
 Componentes de otro resultado integral que se reclasificarán al resultado
 del ejercicio, antes de impuestos
 Ganancias (pérdidas) por diferencias de conversión de subsidiarias en el exterior 28 214.519.767 (120.293.386) 9.945.778
 Ganancias (pérdidas) por coberturas de flujos de efectivo 28 4.746.744 (4.379.170) (12.415.374)
 Otro resultado integral que se reclasificará al resultado del ejercicio, antes
 219.266.511 (124.672.556) (2.469.596)
 de impuestos
 Otros componentes de otro resultado integral, antes de impuestos 217.685.471 (123.218.184) (9.572.721)
 Impuestos a las ganancias relativos a componentes de otro resultado
 integral que no se reclasificará al resultado del ejercicio
 Impuesto a las ganancias relacionado con planes de beneficios definidos 28 377.337 (360.233) 1.981.923
 Impuestos a las ganancias relativos a componentes de otro resultado
 377.337 (360.233) 1.981.923
 integral que no se reclasificará al resultado del ejercicio
 Impuestos a las ganancias relativos a componentes de otro resultado
 integral que se reclasificará al resultado del ejercicio
 Impuesto a las ganancias relacionado con coberturas de flujos de efectivo 28 (1.281.621) 1.182.375 3.352.151
 Impuestos a las ganancias relativos a componentes de otro resultado
 (1.281.621) 1.182.375 3.352.151
 integral que se reclasificará al resultado del ejercicio
 Total otros ingresos y gastos integrales del ejercicio 216.781.187 (122.396.042) (4.238.647)
 Ingresos y gastos integrales del ejercicio 393.325.984 (3.970.599) 131.245.805
 Ingresos y gastos integrales atribuibles a:
 Propietarios de la controladora (1) 371.908.216 (14.520.253) 114.609.167
 Participaciones no controladoras 21.417.768 10.549.654 16.636.638
 Ingresos y gastos integrales del ejercicio 393.325.984 (3.970.599) 131.245.805
(1) Correspondería a la utilidad del ejercicio en el caso de que ningún ingreso o gasto se hubiera registrado directamente contra patrimonio.
 9
Las notas adjuntas números 1 a 37 forman parte integral de estos Estados Financieros Consolidados

[pág. 11]
Compañía Cervecerías Unidas S.A. y subsidiarias
Estados Consolidados de Cambios en el Patrimonio
(Cifras expresadas en miles de pesos chilenos)
 ESTADOS CONSOLIDADOS DE CAMBIOS EN EL PATRIMONIO
 Capital emitido Otras reservas
 Ganancias
 (pérdidas) Patrimonio
 Reservas actuariales Otras Total otras Resultados atribuible a los Participaciones Total
 ESTADOS CONSOLIDADOS DE CAMBIOS EN EL PATRIMONIO Reservas de
 Capital pagado de por planes reservas reservas acumulados propietarios de no controladoras Patrimonio
 conversión la controladora
 cobertura de varias
 beneficios
 definidos
 M$ M$ M$ M$ M$ M$ M$ M$ M$ M$
 Saldos al 1 de enero de 2022 562.693.346 (51.745.399) 5.110.606 (5.446.022) (35.175.097) (87.255.912) 832.180.798 1.307.618.232 117.897.071 1.425.515.303
 Cambios
 Dividendos definitivos (1) - - - - - - (48.219.783) (48.219.783) - (48.219.783)
 Dividendos provisorios (2) - - - - - - (49.919.838) (49.919.838) - (49.919.838)
 Dividendos provisionados según política (3) - - - - - - (9.164.337) (9.164.337) - (9.164.337)
 Otros incrementos (disminuciones) en Patrimonio (4) - - - - - - - - (14.698.083) (14.698.083)
 Ingresos y gastos por resultados integrales (6) - 11.706.309 (9.291.567) (4.905.072) (1.068.854) (3.559.184) 118.168.351 114.609.167 16.636.638 131.245.805
 Incremento (disminución) por cambios en la participación de subsidiarias que no impliquen pérdida de control (8) - - - - 102.625 102.625 - 102.625 (540.760) (438.135)
 Incremento (disminución) por otras aportaciones de los propietarios (9) - - - - - - - - 1.648.121 1.648.121
 Total cambios en el patrimonio - 11.706.309 (9.291.567) (4.905.072) (966.229) (3.456.559) 10.864.393 7.407.834 3.045.916 10.453.750
 SALDOS AL 31 DE DICIEMBRE DE 2022 562.693.346 (40.039.090) (4.180.961) (10.351.094) (36.141.326) (90.712.471) 843.045.191 1.315.026.066 120.942.987 1.435.969.053
 Saldos al 1 de enero de 2023 562.693.346 (40.039.090) (4.180.961) (10.351.094) (36.141.326) (90.712.471) 843.045.191 1.315.026.066 120.942.987 1.435.969.053
 Cambios
 Dividendos definitivos (1) - - - - - - (3) (3) - (3)
 Dividendos provisorios (2) - - - - - - (31.961.655) (31.961.655) - (31.961.655)
 Dividendos provisionados según política (3) - - - - - - (20.864.709) (20.864.709) - (20.864.709)
 Otros incrementos (disminuciones) en Patrimonio (4) - - - - - - - - (14.037.509) (14.037.509)
 Efectos por combinación de negocios (5) - - - - - - - - 1.090.587 1.090.587
 Ingresos y gastos por resultados integrales (6) - (118.056.295) (3.150.407) 1.033.532 189 (120.172.981) 105.652.728 (14.520.253) 10.549.654 (3.970.599)
 Otros incrementos (disminuciones) por otros cambios (7) - - - - (28.406.226) (28.406.226) - (28.406.226) - (28.406.226)
 Incremento (disminución) por cambios en la participación de subsidiarias que no impliquen pérdida de control (8) - - - - (908.438) (908.438) - (908.438) (2.296.620) (3.205.058)
 Incremento (disminución) por otras aportaciones de los propietarios (9) - - - - - - - - 2.768.700 2.768.700
 Total cambios en el patrimonio - (118.056.295) (3.150.407) 1.033.532 (29.314.475) (149.487.645) 52.826.361 (96.661.284) (1.925.188) (98.586.472)
 SALDOS AL 31 DE DICIEMBRE DE 2023 562.693.346 (158.095.385) (7.331.368) (9.317.562) (65.455.801) (240.200.116) 895.871.552 1.218.364.782 119.017.799 1.337.382.581
 Saldos al 1 de enero de 2024 562.693.346 (158.095.385) (7.331.368) (9.317.562) (65.455.801) (240.200.116) 895.871.552 1.218.364.782 119.017.799 1.337.382.581
 Cambios
 Dividendos definitivos (1) - - - - - - (10.565.360) (10.565.360) - (10.565.360)
 Dividendos provisorios (2) - - - - - - (43.416.587) (43.416.587) - (43.416.587)
 Dividendos provisionados según política (3) - - - - - - (37.055.482) (37.055.482) - (37.055.482)
 Otros incrementos (disminuciones) en Patrimonio (4) - - - - - - - - (14.775.755) (14.775.755)
 Efectos por combinación de negocios (5) - - - - - - - - 20.756.762 20.756.762
 Ingresos y gastos por resultados integrales (6) - 208.678.212 3.399.936 (1.112.502) (1.568) 210.964.078 160.944.138 371.908.216 21.417.768 393.325.984
 Otros incrementos (disminuciones) por otros cambios (7) - - - - 28.554.665 28.554.665 - 28.554.665 (128.043) 28.426.622
 Incremento (disminución) por cambios en la participación de subsidiarias que no impliquen pérdida de control (8) - - - - (2.607.049) (2.607.049) - (2.607.049) (1.702.590) (4.309.639)
 Incremento (disminución) por otras aportaciones de los propietarios (9) - - - - - - - - 2.746.184 2.746.184
 Total cambios en el patrimonio - 208.678.212 3.399.936 (1.112.502) 25.946.048 236.911.694 69.906.709 306.818.403 28.314.326 335.132.729
 SALDOS AL 31 DE DICIEMBRE DE 2024 562.693.346 50.582.827 (3.931.432) (10.430.064) (39.509.753) (3.288.422) 965.778.261 1.525.183.185 147.332.125 1.672.515.310
(1) Corresponde al diferencial del dividendo definitivo y la política de repartir al menos del 50% de la utilidad (Nota 28 - Patrimonio atribuible a los propietarios de la controladora).
(2) Corresponden a dividendos provisorios que fueron pagados el 29 de noviembre de 2022, el 29 de noviembre de 2023 y el 28 de noviembre de 2024, según lo acordado en Sesión Ordinaria de Directorio.
(3) Corresponde al diferencial entre la política de dividendos mínimo de CCU, de repartir al menos el 50% de la utilidad (Nota 28 - Patrimonio atribuible a los propietarios de la controladora) y el dividendo provisorio pagado al 31 de diciembre.
(4) Corresponde principalmente a dividendos de participaciones no controladoras.
(5) Ver Nota 1 - Información general, letra C) numeral (5) para 2023 y numerales (4) y (12) para 2024.
(6) Ver Nota 28 - Patrimonio atribuible a los propietarios de la controladora.
(7) Ver Nota 1 - Información general, letra C), numerales (4) y (10).
(8) Ver Nota 1 - Información general, letra C), numerales (4), (9) y (13).
(9) Ver Nota 1 - Información general, letra C), numeral (3).
 10
Las notas adjuntas números 1 a 37 forman parte integral de estos Estados Financieros Consolidados

[pág. 12]
Compañía Cervecerías Unidas S.A. y subsidiarias
Estados Consolidados de Flujos de Efectivo
(Cifras expresadas en miles de pesos chilenos)
 ESTADOS CONSOLIDADOS DE FLUJOS DE EFECTIVO
 Por los ejercicios terminados al 31 de diciembre de
 ESTADOS CONSOLIDADOS DE FLUJOS DE EFECTIVO Notas
 2024 2023 2022
 M$ M$ M$
 Flujos de Efectivo Procedentes de (Utilizados en) Actividades de Operación
 Clases de Cobros
 Cobros procedentes de las ventas de bienes y prestación de servicios 3.873.449.090 3.372.357.634 3.293.803.868
 Otros cobros por actividades de operación 57.653.381 37.693.163 42.084.964
 Clases de Pagos
 Pagos a proveedores por el suministro de bienes y servicios (2.716.646.141) (2.312.543.646) (2.450.621.483)
 Pagos a y por cuenta de los empleados (422.143.875) (347.134.212) (362.357.568)
 Otros pagos por actividades de operación (454.451.355) (424.963.285) (397.670.139)
 Flujos de efectivo procedentes (utilizados en) operaciones 337.861.100 325.409.654 125.239.642
 Dividendos recibidos 942.895 1.231.164 3.377.750
 Intereses pagados (68.811.141) (70.452.675) (47.102.233)
 Intereses recibidos 38.007.760 38.534.725 22.867.199
 Impuestos a las ganancias reembolsados (pagados) (14.703.915) (8.959.871) (66.276.733)
 Otras entradas (salidas) de efectivo 32 (5.779.972) 8.334.410 7.831.528
 Flujos de Efectivo Procedentes de (Utilizados en) Actividades de Operación 287.516.727 294.097.407 45.937.153
 Flujos de Efectivo Procedentes de (Utilizados en) Actividades de Inversión
 Flujos de efectivo utilizados para obtener el control de subsidiarias u otros negocios 8 (551.585) (2.000.000) -
 Préstamos a entidades relacionadas - (1.173.884) -
 Cobros a entidades relacionadas 572.254 1.245.265 30.021
 Otros pagos para adquirir participaciones en negocios conjuntos 8 (10.658.097) (7.086.899) (36.465.915)
 Importes procedentes de la venta de propiedades, planta y equipo 52.429.361 1.231.541 3.582.588
 Compras de propiedades, planta y equipo (152.916.896) (124.400.618) (188.669.637)
 Compras de activos intangibles (7.169.288) (5.047.222) (14.933.853)
 Flujos de Efectivo Procedentes de (Utilizados en) Actividades de Inversión (118.294.251) (137.231.817) (236.456.796)
 Flujos de Efectivo Procedentes de (Utilizados en) Actividades de Financiación
 Cobros por cambios en las participaciones en la propiedad en subsidiarias que no dan
 8 17.112.779 - -
 lugar a la pérdida de control
 Pagos por cambios en las participaciones en la propiedad en subsidiarias que no dan
 8 (32.260.503) (3.205.058) (438.105)
 lugar a la pérdida de control
 Importes procedentes de préstamos de largo plazo y bonos - 8.219.455 736.278.842
 Importes procedentes de préstamos de corto plazo y bonos 52.903.303 68.928.016 46.843.478
 Total importes procedentes de préstamos y bonos 52.903.303 77.147.471 783.122.320
 Pagos de préstamos y bonos (74.305.996) (159.420.525) (79.351.110)
 Importes procedentes de la emisión de acciones 2.746.184 2.768.700 1.648.121
 Pagos de pasivos por arrendamiento (16.274.873) (10.704.270) (9.663.757)
 Pagos de préstamos de entidades relacionadas - - (25.000)
 Dividendos pagados (81.797.392) (65.583.416) (158.320.848)
 Otras entradas (salidas) de efectivo (1) 6.840.724 40.960.923 130.322
 Flujos de Efectivo Procedentes de (Utilizados en) Actividades de Financiación (125.035.774) (118.036.175) 537.101.943
 Incremento Neto (Disminución) en el Efectivo y Equivalente al Efectivo, antes del
 44.186.702 38.829.415 346.582.300
 Efecto de los Cambios en la Tasa de Cambio
 Efectos de las variaciones en la tasa de cambio sobre el Efectivo y Equivalente 44.782.097 (17.757.074) (15.068.750)
 Incremento (disminución) de efectivo y equivalentes al efectivo 88.968.799 21.072.341 331.513.550
 Efectivo y Equivalentes al Efectivo, Saldo Inicial 618.154.016 597.081.675 265.568.125
 Efectivo y Equivalentes al Efectivo, Saldo Final 8 707.122.815 618.154.016 597.081.675
(1) Dentro de Otras entradas (salidas) de efectivo, en 2023 se encuentra principalmente el efecto de liquidación de instrumentos de cobertura
 asociados a Obligaciones con el público.
 11
Las notas adjuntas números 1 a 37 forman parte integral de estos Estados Financieros Consolidados

[pág. 13]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 1 Información general
A) Información de la Compañía
Compañía Cervecerías Unidas S.A. (CCU, CCU S.A., la Compañía o la Compañía Matriz) fue constituida en Chile como
sociedad anónima abierta, y se encuentra inscrita en el Registro de Valores de la Comisión para el Mercado Financiero
(CMF), bajo el Nº 0007 y consecuentemente está sujeta a su fiscalización. Cotiza sus acciones en la Bolsa de Comercio de
Santiago de Chile y Bolsa Electrónica de Chile. La Compañía también se encuentra registrada en la Comisión de Bolsa y
Valores de los Estados Unidos de Norteamérica (Securities and Exchange Commission) y cotiza sus American Depositary
Shares (ADS) en la Bolsa de Nueva York (NYSE). Con fecha 3 de diciembre de 2012, la Compañía y JPMorgan Chase Bank,
NA. (en calidad de Depositario) suscribieron una Modificación al Contrato de Depósito que, en lo principal, establece un
cambio del ratio de 5 acciones ordinarias de la Compañía por cada ADR a 2 acciones ordinarias por cada ADR, ello con
efecto al 20 de diciembre de 2012.
Compañía Cervecerías Unidas S.A. es una empresa diversificada de bebidas, con operaciones principalmente en Chile,
Argentina, Uruguay, Paraguay, Colombia y Bolivia. CCU es el mayor cervecero chileno, el segundo cervecero en Argentina,
el segundo mayor productor de gaseosas en Chile, el segundo mayor productor de vinos en Chile, el mayor productor de
agua embotellada, néctares, bebidas deportivas y té helado en Chile y uno de los mayores fabricantes de pisco en Chile.
También participa en el negocio de Home and Office Delivery (“HOD”), un negocio de entrega a domicilio de agua purificada
en botellones mediante el uso de dispensadores; en la industria del ron, otros licores, recientemente en sidras en Chile.
Participa en la industria de las sidras, licores y vinos en Argentina. También participa en la industria de aguas minerales,
gaseosas, aguas, néctares y en la distribución de cerveza en Argentina, Uruguay, Paraguay, Colombia y Bolivia.
Compañía Cervecerías Unidas S.A. es controlada por Inversiones y Rentas S.A. (IRSA), la cual es propietaria en forma
directa e indirecta del 65,87% de las acciones de la Compañía. IRSA es un negocio conjunto entre Quiñenco S.A. y Heineken
Chile SpA., empresa controlada por Heineken International B.V., ambos con una participación patrimonial de un 50%.
El domicilio social y las oficinas principales de la Compañía se encuentran en la ciudad de Santiago en Avenida Vitacura
Nº 2670, comuna de Las Condes y su número de identificación tributaria (Rut) es 90.413.000-1.
Al 31 de diciembre de 2024, la Compañía tiene un total de 9.638 trabajadores, según el siguiente detalle:
 Número de trabajadores
 Matriz Consolidado
Ejecutivos principales 9 14
Gerentes y subgerentes 89 503
Otros trabajadores 334 9.121
Total 432 9.638
Los presentes Estados Financieros son consolidados y están compuestos por el Estado de Situación Financiera, el Estado
de Resultados por Función y Estado de Resultados Integrales, el Estados de Flujos de Efectivo, el Estado de Cambios en el
Patrimonio y las notas complementarias con sus respectivas revelaciones a dichos Estados Financieros Consolidados.
En el presente Estado Consolidado de Situación Financiera, los activos y pasivos se clasifican en función de sus
vencimientos entre corrientes, aquellos con vencimiento igual o inferior a doce meses, y no corrientes, aquellos cuyo
vencimiento es superior a doce meses. A su vez, en el Estado Consolidado de Resultados por Función se presentan los
gastos clasificados por función, identificando en notas las depreciaciones y gastos del personal en base a su naturaleza. El
Estado Consolidado de Flujos de Efectivo se presenta por el método directo.
Las cifras del Estado Consolidado de Situación Financiera y sus notas explicativas respectivas se presentan comparadas
con saldos al 31 de diciembre de 2023 y del Estado Consolidado de Cambios en el Patrimonio, del Estado Consolidado de
Resultado por Función, del Estado Consolidado de Resultados Integrales, del Estado Consolidado de Flujos de Efectivo y
sus notas explicativas respectivas se presentan comparadas con saldos al 31 de diciembre de 2023 y 2022.
Los presentes Estados Financieros Consolidados se presentan en miles de pesos chilenos (M$) y se han preparado a partir
de los registros contables de Compañía Cervecerías Unidas S.A. y de sus subsidiarias. Todos los montos han sido
redondeados a miles de pesos chilenos, excepto cuando se indique lo contrario.
 12

[pág. 14]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
CCU y sus subsidiarias utilizan el peso chileno como moneda de presentación y como moneda funcional, excepto por algunas
subsidiarias en Chile, Estados Unidos, Argentina, Uruguay, Paraguay, Bolivia, Reino Unido y China, que utilizan el dólar
estadounidense, el peso argentino, peso uruguayo, guaraní paraguayo, boliviano, libra esterlina y Yuan, respectivamente.
La moneda funcional del negocio conjunto en Colombia y asociadas en Argentina y Perú es el peso colombiano, peso
argentino y el sol, respectivamente. Sin embargo utilizan el peso chileno como moneda para presentar sus Estados
Financieros y para efectuar sus reportes para la consolidación.
Las subsidiarias que registran su contabilidad en una moneda distinta del peso chileno y que no corresponden a monedas
de un país cuya economía es declarada como hiperinflacionaria, tradujeron sus estados financieros desde su moneda
funcional a la moneda de presentación que es el peso chileno, como sigue: el Estado de Situación Financiera Clasificado y
el Estado de Cambios en el Patrimonio a tipo de cambio de cierre, y el Estado de Resultados por Función, el Estado de
Resultados Integrales y el Estado de Flujos de Efectivo al tipo de cambio diario o promedio mensual, según corresponda.
Para efectos de consolidación, los activos y pasivos de las subsidiarias cuya moneda funcional es distinta del peso chileno,
son traducidos a pesos chilenos usando los tipos de cambio vigentes a la fecha de los Estados Financieros Consolidados
mientras las Ganancias (pérdidas) de cambio en moneda extranjera originadas por la conversión de los activos y pasivos,
son registradas en la cuenta Reservas de conversión dentro de Otras reservas de patrimonio. Los ingresos, costos y gastos
son traducidos al tipo de cambio promedio mensual para los respectivos períodos. Estos tipos de cambios no han sufrido
fluctuaciones significativas durante estos meses, con excepción de las subsidiarias que se encuentran en economías
hiperinflacionarias (ver Nota 2 - Resumen de las principales políticas contables (2.4)).
B) Marcas y licencias
En Chile, su portafolio de marcas en el rubro de cervezas está integrado por Marcas Propias de CCU, Marcas de Licencias
Internacionales y Marcas Craft de Distribución. Dentro de las Marcas Propias de CCU, que corresponden a productos
nacionales, producidos, comercializados y distribuidos por Cervecera CCU Chile Ltda. (“Cervecera CCU”), se encuentran las
marcas Cristal, Escudo, Royal Guard, Morenita, Dorada, Andes, Bavaria y Stones en sus variedades Lemon, Maracuyá,
Mango y Stones 6 (Sensation y Tropical). Entre las Marcas de Licencias Internacionales, en su mayoría producidas, otras
importadas, comercializadas y distribuidas por Cervecera CCU, se encuentran las marcas Heineken, Sol y Coors. Las Marcas
Craft, cervezas creadas y en su mayoría producidas en sus cervecerías de origen, las que en sociedad con Cervecera CCU,
son comercializadas y distribuidas por la Compañía, se componen de las marcas Austral, Polar Imperial, Patagonia,
Kunstmann, Guayacán, D´olbek, Mahina y Volcanes del Sur.
Dentro del Segmento de operación Chile, en la categoría bebidas no alcohólicas CCU cuenta con las marcas Bilz, Pap, Kem,
Kem Xtreme, Nobis, Pop, Rockstar, Cachantun, Mas, Porvenir y Manantial. En cuanto a la categoría HOD, CCU cuenta con
la marca Manantial. La Compañía, directamente o a través de sus subsidiarias, tiene contratos de licencia respecto de las
marcas y productos Pepsi, 7up, Mirinda, H2O!, Gatorlit, Gatorade, Adrenaline Red, Lipton Ice Tea, Crush, Canada Dry Limón
Soda, Canada Dry Ginger Ale, Canada Dry Agua Tónica, Nestlé Pura Vida, Watt´s, Watt´s Selección y Frugo. En cuanto a
la marca de bebida energética Red Bull y a la marca de Agua Mineral Perrier, es el distribuidor exclusivo en Chile. Por otra
parte, a través de una operación conjunta, cuenta con la marca propia Sprim y las licencias de las marcas Vivo y Caricia.
Adicionalmente, en el Segmento de operación Chile, en la categoría del pisco y cócteles, CCU posee las marcas Mistral,
Tres Erres, Campanario, Horcón Quemado, Control Valle del Encanto, Espíritu de Los Andes, La Serena, Iceberg, Hard
Fresh, Ruta Cocktail, Sabor Andino Sour, Horcón Quemado Sour, junto con sus respectivas extensiones de línea en el caso
que aplique. En la categoría de ron, la Compañía cuenta con las marcas Sierra Morena (junto a sus extensiones) y Cabo
Viejo. En la categoría de licores, cuenta con las marcas Kantal, Fehrenberg, Barsol, Puklaro y es distribuidor exclusivo en
Chile de las marcas de Pernod Ricard en el canal tradicional y distribuidor exclusivo en Chile de las marcas de Fratelli Branca
para todos los canales. En la categoría de sidras, la Compañía distribuye la marca Villa Pehuenia y Sidra 1888.
En el mes de enero de 2023 CPCh materializó la adquisición de D&D SpA. (ver Nota 1 - Información general, letra C),
numeral (5)), sumando a su portafolio de marcas La Pizka.
Con fecha 8 de agosto de 2019, CCU anunció que su subsidiaria Compañía Pisquera de Chile S.A. (“CPCh”), actuando a
través de las sociedades Inversiones Internacionales SpA. e International Spirits Investments USA LLC han comunicado a
LDLM Investments LLC su decisión de iniciar un proceso de venta del total de su participación en Americas Distilling
Investments LLC, ascendente al 40%, propietaria de la sociedad peruana Bodega San Isidro S.R.L. y de la marca Barsol.
Dicho proceso de venta iniciado por CPCh no se concretó, debido a que los términos y condiciones descritos en las ofertas
presentadas por los interesados no fueron factibles o satisfactorias.
 13

[pág. 15]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
En Argentina, CCU produce cervezas en sus plantas ubicadas en las ciudades de Salta, Santa Fe y Luján. Sus principales
marcas son Schneider, Imperial, Santa Fe, Salta, Córdoba, Norte, Palermo, Isenbeck, Iguana y Bieckert, a su vez es titular
de contratos de licencia exclusiva para la producción y comercialización de Heineken, Amstel, Sol, Miller Genuine Draft,
Warsteiner, Grolsch y Blue Moon. Asimismo, importa desde Chile la marca Kunstmann. CCU exporta cerveza a diversos
países, principalmente bajo las marcas Schneider, Heineken e Imperial. CCU participa en el negocio de la sidra, donde
fabrica y comercializa las marcas líderes del mercado “Sidra Real”, “La Victoria” y “1888”, además de la marca Pehuenia.
Participa en el negocio de licores, los que se comercializan bajo la marca El Abuelo, además de importar pisco desde Chile.
Dentro de su portafolio de vinos vende y distribuye las marcas de vinos Eugenio Bustos y La Celia y, desde junio de 2019,
ha incorporado a su portafolio de vinos las marcas Colón, Graffigna y Santa Silvia pertenecientes a la bodega Finca La Celia
S.A. (subsidiaria en Argentina de la subsidiaria chilena Viña San Pedro Tarapacá S.A. (“VSPT”)).
Con la adquisición de las participaciones en Aguas de Origen S.A. y Aguas Danone de Argentina S.A., durante el año 2022,
CCU se incorporó al negocio de agua manantial, agua mineral, agua saborizada, participando con sus marcas Villavicencio,
Villa del Sur, Levité, Ser y Brío.
En el Segmento de operación Vinos, CCU a través de su subsidiaria VSPT cuenta con un extenso portafolio de marcas de
vino, producidas por las 8 viñas que conforman el grupo. Destacan entre ellas: Altaïr, Cabo de Hornos, Sideral, 1865, Castillo
de Molina, Epica, Gato (en mercado doméstico) y GatoNegro (en exportaciones) de Viña San Pedro; las líneas Varietal,
Reserva y Gran Reserva de Viña Tarapacá y sus etiquetas Azul, Negra y Roja; Viña Leyda en sus series Reserva, Coastal
Vineyard y Lot; Misiones de Rengo Varietal, Reserva, Cuvée, Gran Reserva Black, Misión y su línea Sparkling; además de
Alpaca, la línea Reserva y Gran Reserva de Viña Santa Helena; y en la categoría espumantes, Viñamar en sus expresiones
Método Tradicional, Extra Brut, Rosé, Moscato, Brut, Brut Unique, Brut Rosé, ICE y Zero Desalcoholizado; además, destaca
Donnaluna en la categoría de cóctel de vino y, finalmente, Manquehuito en la categoría coolers y sangrías. En Argentina a
su vez, destacan las marcas La Celia, Graffigna, Colón y Colón Selecto.
En Uruguay, CCU participa del negocio de aguas minerales con las marcas Nativa y Nix, en gaseosas con la marca Nix, en
néctares con la marca Watt´s, en Isotónicas con la marca FullSport; y en el negocio de Sidra con las marcas Sidra Real y
1888. Adicionalmente, comercializa las marcas importadas de cerveza Heineken, Schneider, Imperial, Escudo Silver,
Kunstmann, Miller y Amstel. En la categoría vinos participa con las marcas Misiones de Rengo, Eugenio Bustos y La Celia,
todas ellas importadas.
En Paraguay, CCU participa en el negocio de bebidas con y sin alcohol. Dentro del portafolio de bebidas sin alcohol, cuenta
con las marcas Pulp, Watt’s, Puro Sol, La Fuente y la bebida isotónica FullSport. Dentro de estas marcas se incluyen propias,
licenciadas e importadas. Por otro lado, en las marcas de bebidas alcohólicas, cuenta con la marca propia de cerveza Sajonia
y adicionalmente con cervezas importadas, que incluyen Heineken, Amstel, Paulaner, Sol, Blue Moon, Schiny y Kunstmann.
En la categoría vinos, distribuye las marcas Misiones de Rengo y La Celia, y en la categoría piscos, distribuye la marca
Mistral. Desde octubre de 2024, a raíz del acuerdo de asociación con el Grupo Vierci, CCU cuenta con la licencia para
comercialización y distribución de bebestibles y snacks de Pepsico correspondientes a las marcas Pepsi, Mirinda, 7Up, Split,
Gatorade, Aquafina, Rockstar, Paso de los Toros, Quaker, Lays, Cheetos, Doritos y Fandango, además de la distribución de
Red Bull.
En Bolivia, CCU participa en el negocio de bebidas sin y con alcohol, a través de su subsidiaria Bebidas Bolivianas BBO S.A.
(“BBO”). Dentro del portafolio de bebidas sin alcohol, BBO cuenta con las marcas Mendocina, Sinalco, Real, De La Sierra.
Dentro de estas marcas se incluyen propias y licenciadas. Por otro lado, las marcas de bebidas con alcohol son Real, Capital,
Cordillera, Uyuni, Amstel y Schneider. Adicionalmente BBO comercializa las marcas importadas de cervezas Heineken.
En Colombia, CCU participa en el negocio de cervezas, a través de su negocio conjunto en Central Cervecera de Colombia
S.A.S. (“CCC”). CCC es titular de contratos de licencia exclusiva para la importación, distribución y producción de la cerveza
Heineken en Colombia desde diciembre de 2014. En diciembre de 2015 se adquirieron los activos de la empresa de cerveza
artesanal “Artesanos de Cerverza” con su marca “Tres Cordilleras”. A partir de abril 2016, se incorporaron las marcas Tecate
y Sol, con un contrato de licencia para elaborar y/o comercializar dichas marcas. En noviembre de 2019 se introdujeron
nuevas marcas, Miller Lite y Miller Genuine Draft. A partir de febrero de 2019 se realizó el lanzamiento de la marca local
Andina. Desde 2019 se comenzó la producción local de la marca Tecate y el lanzamiento de Natu Malta (producto sin alcohol
en base a malta), también se comenzó con la importación y comercialización de la marca Kunstmann y la producción local
de cerveza Heineken. En octubre de 2021 se inició la producción local de la marca Sol.
 14

[pág. 16]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
La duración de las licencias mencionadas anteriormente se detalla a continuación:
 Principales marcas bajo licencia
 Fecha de
 Licencia
 expiración
Aberlour, Absolut, Ballantine's, Beefeater, Blender´s Pride, Borzoi, Chivas Reagal, Cuvee MUMM, Dubonnet, Elyx, G.H. MUMM, Havana Club, Jameson,
Kahlúa, Level, Long John, Longmorn, Malibu, Martell, Olmeca, Orloff, Passport, Pernod, Perrier Jouet, Ricard, Royale Salute, Sandeman, Scapa, Strathisla, Junio 2027
The Glenlivet, Wyborowa, 100 Pipers, para Chile (1)
Amstel para Argentina (2) 10 años renovables
Amstel para Bolivia (9) Agosto 2033
Amstel para Uruguay (16) En proceso
Amstel para Paraguay (1) Septiembre 2027
Austral para Chile (4) Julio 2026
Avena Quaker Extra Fino, Avena Tradicional Fortificada Ca-Fe-Zn, Barra Display Chispa Chocolate, Barra Display Frutilla, Barra Display Vainilla Toffe,
Barra Display Vainilla Toffe, Cheetos, Doritos Queso, Fandangos Presunto, Fandangos Queijo, Honey Graham, Honey Nut, Lays Clásicas, Harina de
Aventa Integral Py, Lays stax SCO, Lays stax Original, TOstitos, Stax Sal, Lay´s Ketchup, Stax Sco Casa, Lays Stax Cheddar, Lays Queso y Pimienta, Octubre 2034
Lays Ceb Car Lto, Cheetos Pali, Aveia Quaker Fr, Granola Quaker Miel y Pasas, Granola Quaker Miel y Almendras, Avena Multisemilla II, Avena
Multisemillas IV, Quaker Avena Instant, Avena Multisemillas I, Barra Display Manzana, Tostitos, Doritos DInamita FH y Lays TA FH para Paraguay
 Diciembre 2028
Blue Moon para Argentina (19)
 renovables
Blue Moon para Paraguay Abril 2028
Coors para Chile (5) Diciembre 2025
Crush, Canada Dry (Ginger Ale, Agua Tónica y Limón Soda) para Chile (6) Diciembre 2028
Fernet Branca, Brancamenta, Punt E Mes, Borghetti, Carpano Rosso y Carpano Bianco para Chile Diciembre 2029
Frugo para Chile Indefinida
Gatorade para Chile (7) Diciembre 2043
Gatorade para Paraguay (21) Abril 2033
Grolsch para Argentina Mayo 2028
Heineken para Bolivia (8) Diciembre 2029
Heineken para Chile y Argentina (9) 10 años renovables
Heineken para Colombia (10) Marzo 2028
Heineken para Paraguay (1) Mayo 2026
Heineken para Uruguay (9) 10 años renovables
Mas para Uruguay (15) Diciembre 2028
Kunstmann para Colombia (1) Julio 2025
Miller para Argentina (10) Diciembre 2026
Miller Lite y Miller Genuine Draft para Colombia (13) Diciembre 2026
Miller para Uruguay (6) Julio 2026
Nestlé Pura Vida para Chile (6) Diciembre 2027
Paulaner para Paraguay Abril 2025
Patagonia para Chile Indefinida
Pepsi, Seven Up y Mirinda para Chile Diciembre 2043
Pepsi, Pepsi Light, Pepsi Max, Pepsi Blue, Pepsi Black, 7up, 7up Free, Mirinda (Guaraná), Mirinda Free (Guaraná), Paso de los Toros, Paso de los Toros
 Abril 2033
Free y Aquafina para Paraguay (21)
Polar Imperial para Chile Indefinida
Red Bull para Chile (11) Indefinida
Red Bull para Paraguay (16) En proceso
Rockstar para Chile (17) Diciembre 2043
Schneider para Bolivia (16) En proceso
Split para Paraguay (16) En proceso
Sol para Argentina (9) 10 años renovables
Sol para Chile (9) 10 años renovables
Sol para Colombia (3) Marzo 2028
Sol para Paraguay (1) Enero 2026
Té Lipton para Chile Diciembre 2030
Tecate para Colombia (3) Marzo 2028
Villavicencio, Villa del Sur, Levite, Brio, Ser, We, Mate Power, Evian y Ser (en polvo) (18) Indefinida
Warsteiner para Argentina (14) Mayo 2028
Watt´s para Uruguay 99 años renovables
Watt's (néctares, bebidas en base a fruta y otros) en envases rígidos, excepto cartón para Chile Indefinida
Watt's (jugos) en envases rígidos, excepto cartón para Chile (20) Diciembre 2028
Watt's para Paraguay (12) Julio 2026
 15

[pág. 17]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
(1) Renovable por periodos sucesivos de 3 años.
(2) Luego del vencimiento inicial, licencia se renueva automáticamente en idénticas condiciones (Rolling Contract), cada año por un período de 10
 años, salvo aviso de no renovación.
(3) El contrato se mantendrá vigente mientras se mantenga vigente el contrato de licencia de Heineken para Colombia.
(4) Licencia renovable por períodos de 2 años, sujeto al cumplimiento de las condiciones establecidas en el contrato.
(5) Luego del vencimiento inicial, licencia se renueva automáticamente en idénticas condiciones (Rolling Contract), cada año por un período de 5
 años, sujeto al cumplimiento de las condiciones establecidas en el contrato.
(6) Licencia se renueva por periodos de 5 años, sujeto al cumplimiento de las condiciones establecidas en el contrato.
(7) Licencia se renovó por un período igual a la duración del Pacto de Accionistas de Bebidas CCU-PepsiCo SpA.
(8) Licencia por 10 años, renovables automáticamente, por períodos de 5 años, salvo aviso de no renovación.
(9) Licencia por 10 años, renovables automáticamente en idénticas condiciones (Rolling Contract), cada año por un período de 10 años, salvo
 aviso de no renovación.
(10) Luego del vencimiento inicial, la licencia se renueva automáticamente cada año por un período de 5 años (Rolling Contract), salvo aviso de no
 renovación.
(11) Contrato indefinido, aviso de término con 6 meses de anticipación.
(12) Sub-licencia se renueva automática y sucesivamente por dos periodos de 5 años cada uno, sujeto a los términos y condiciones estipulados en
 el contrato de Sub-licencia Internacional de 28 de diciembre de 2018 entre Promarca Internacional Paraguay S.R.L. y Bebidas del Paraguay
 S.A.
(13) Licencia se renueva por un periodo de 5 años, sujeto al cumplimiento de las condiciones establecidas en el contrato.
(14) Previo a la expiración del plazo, las partes negociarán su renovación por otros 5 años.
(15) Contrato renovable por periodos sucesivos de 10 años.
(16) Se inició la distribución, contrato en proceso de negociación.
(17) Mientras se encuentre vigente el pacto de accionistas de Bebidas CCU-PepsiCo SpA.
(18) Vigencia indefinida hasta que se configure alguna de las causales de terminación. Incumplimiento esencial, que CCU deje de ser accionista de
 Aguas de Origen S.A. o que alguna sea declarada en quiebra.
(19) Luego del vencimiento inicial, licencia se renueva automáticamente en idénticas condiciones (Rolling Contract), por dos periodos de 5 años,
 sujeto al cumplimiento de las condiciones establecidas en el contrato.
(20) Plazo se renovará automáticamente por períodos iguales y sucesivos de 5 años cada uno, salvo aviso con a lo menos 1 (un) año de anticipación
 al vencimiento del plazo original o de cualquiera de sus prórrogas.
(21) Luego del vencimiento inicial, opera una renovación 4 años, salvo notificacción por escrito de no renovar por al menos un (1) año antes de la
 finalización del vencimiento inicial.
 16

[pág. 18]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
C) Subsidiarias directas e indirectas
Los Estados Financieros Consolidados incluyen las siguientes subsidiarias directas e indirectas, donde el porcentaje de
participación representa el interés económico a nivel consolidado:
 Porcentaje de participación directa e indirecta
 Al 31 de diciembre de
 Subsidiaria Rut País de origen Moneda funcional Al 31 de diciembre de 2024
 2023
 Directo Indirecto Total Total
 Aguas CCU-Nestlé Chile S.A. 76.007.212-5 Chile Peso chileno - 50,0917 50,0917 50,0917
 Cervecera Guayacán SpA. (9) (**) 76.035.409-0 Chile Peso chileno - 30,0005 30,0005 25,0006
 CRECCU S.A. (6) 76.041.227-9 Chile Peso chileno 99,9602 0,0398 100,0000 100,0000
 Cervecería Belga de la Patagonia S.A. (**) 76.077.848-6 Chile Peso chileno - 25,5034 25,5034 25,5034
 Inversiones Invex CCU Dos Ltda. 76.126.311-0 Chile Dólar estadounidense 99,8516 0,1484 100,0000 100,0000
 Bebidas CCU-PepsiCo SpA. (**) 76.337.371-1 Chile Peso chileno - 49,9888 49,9888 49,9888
 CCU Inversiones II SpA. (1) 76.349.531-0 Chile Dólar estadounidense 99,9602 0,0398 100,0000 100,0000
 Cervecería Szot SpA. (10) (**) 76.481.675-7 Chile Peso chileno - - - 25,0006
 Bebidas Carozzi CCU SpA. (**) 76.497.609-6 Chile Peso chileno - 49,9917 49,9917 49,9917
 Bebidas Ecusa SpA. 76.517.798-7 Chile Peso chileno - 99,9834 99,9834 99,9834
 Inversiones Invex CCU Ltda. (2) 76.572.360-4 Chile Dólar estadounidense 66,6519 33,3406 99,9925 99,9925
 Promarca Internacional SpA. (**) 76.574.762-7 Chile Dólar estadounidense - 49,9917 49,9917 49,9917
 CCU Inversiones S.A. (13) 76.593.550-4 Chile Peso chileno 99,0242 0,9533 99,9775 99,9775
 Inversiones Internacionales SpA. 76.688.727-9 Chile Dólar estadounidense - 80,0000 80,0000 80,0000
 Promarca S.A. (**) 76.736.010-K Chile Peso chileno - 49,9917 49,9917 49,9917
 D&D SpA. (5) (**) 76.920.876-3 Chile Peso chileno - 40,8105 40,8105 40,8105
 La Barra S.A. (18) 77.148.606-1 Chile Peso chileno 99,0000 1,0000 100,0000 100,0000
 Mahina SpA. (**) 77.248.551-4 Chile Peso chileno - 25,0458 25,0458 25,0458
 Volcanes del Sur S.A. (17) 77.622.887-7 Chile Peso chileno - 74,9503 74,9503 74,9503
 CirCCUlar SpA. (8) 77.847.898-3 Chile Peso chileno - 99,9773 99,9773 -
 Transportes CCU Ltda. 79.862.750-3 Chile Peso chileno 98,0000 2,0000 100,0000 100,0000
 Fábrica de Envases Plásticos S.A. 86.150.200-7 Chile Peso chileno 95,8904 4,1080 99,9984 99,9984
 Millahue S.A. (11) 91.022.000-4 Chile Peso chileno 99,9773 - 99,9773 99,9621
 Viña San Pedro Tarapacá S.A. (*) (13) 91.041.000-8 Chile Peso chileno - 85,1506 85,1506 84,6824
 Manantial S.A. 96.711.590-8 Chile Peso chileno - 50,5519 50,5519 50,5519
 Viña Altaïr SpA. 96.969.180-9 Chile Peso chileno - 85,1506 85,1506 84,6824
 Cervecería Kunstmann S.A. 96.981.310-6 Chile Peso chileno 50,0007 - 50,0007 50,0007
 Cervecera CCU Chile Ltda. (16) 96.989.120-4 Chile Peso chileno 99,8064 0,1935 99,9999 99,9999
 Embotelladoras Chilenas Unidas S.A. 99.501.760-1 Chile Peso chileno 98,8000 1,1834 99,9834 99,9834
 Comercial CCU S.A. 99.554.560-8 Chile Peso chileno 50,0000 49,9888 99,9888 99,9888
 Compañía Pisquera de Chile S.A. 99.586.280-8 Chile Peso chileno 46,0000 34,0000 80,0000 80,0000
 Aguas de Origen S.A. (12) 0-E Argentina Peso argentino - 50,0970 50,0970 -
 Compañía Cervecerías Unidas Argentina S.A. 0-E Argentina Peso argentino - 99,9939 99,9939 99,9939
 Compañía Industrial Cervecera S.A. (7) 0-E Argentina Peso argentino - 99,9952 99,9952 99,9952
 Finca La Celia S.A. 0-E Argentina Peso argentino - 85,1506 85,1506 84,6824
 Los Huemules S.R.L. 0-E Argentina Peso argentino - 74,9980 74,9980 74,9980
 Bebidas Bolivianas BBO S.A. (3) 0-E Bolivia Boliviano - 51,0000 51,0000 51,0000
 VSPT Winegroup (Shanghai) Limited (15) 0-E China Yuan - 85,1506 85,1506 84,6824
 International Spirits Investments USA LLC 0-E Estados Unidos Dólar estadounidense - 80,0000 80,0000 80,0000
 VSPT US LLC 0-E Estados Unidos Dólar estadounidense - 85,1506 85,1506 84,6824
 VSPT UK Ltd. (14) 0-E Reino Unido Libra esterlina - 85,1506 85,1506 84,6824
 AV S.A. (4) 0-E Paraguay Guaraní paraguayo - 51,0166 51,0166 -
 Bebidas del Paraguay S.A. (4) 0-E Paraguay Guaraní paraguayo - 57,2158 57,2158 55,0070
 Distribuidora del Paraguay S.A. (4) 0-E Paraguay Guaraní paraguayo - 51,0024 51,0024 54,9640
 Promarca Internacional Paraguay S.R.L. (**) 0-E Paraguay Guaraní paraguayo - 49,9917 49,9917 49,9917
 Sajonia Brewing Company S.R.L. 0-E Paraguay Guaraní paraguayo - 56,6436 56,6436 54,4569
 Andrimar S.A. 0-E Uruguay Peso uruguayo - 100,0000 100,0000 100,0000
 Coralina S.A. (19) 0-E Uruguay Peso uruguayo - - - 100,0000
 Marzurel S.A. 0-E Uruguay Peso uruguayo - 100,0000 100,0000 100,0000
 Milotur S.A. 0-E Uruguay Peso uruguayo - 100,0000 100,0000 100,0000
(*) Compañía registrada en la Comisión para el Mercado Financiero.
(**) Sociedades en las cuales la Compañía posee una participación superior o igual al 50% a través de una o más subsidiarias.
 17

[pág. 19]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Adicionalmente a lo presentado en el cuadro anterior se presenta a continuación los porcentajes de participación con derecho
a voto, en cada una de las sociedades. Señalamos que cada accionista dispone de un voto por acción que posea o
represente. El porcentaje de participación con poder de voto representa la suma de la participación directa más la
participación indirecta a través de una subsidiaria.
 Porcentaje de participación con poder de voto
 Al 31 de diciembre de Al 31 de diciembre de
 Subsidiaria Rut País de origen Moneda funcional
 2024 2023
 % %
 Aguas CCU-Nestlé Chile S.A. 76.007.212-5 Chile Peso chileno 50,0917 50,0917
 Cervecera Guayacán SpA. (9) (**) 76.035.409-0 Chile Peso chileno 30,0005 25,0006
 CRECCU S.A. (6) 76.041.227-9 Chile Peso chileno 100,0000 100,0000
 Cervecería Belga de la Patagonia S.A. (**) 76.077.848-6 Chile Peso chileno 25,5034 25,5034
 Inversiones Invex CCU Dos Ltda. 76.126.311-0 Chile Dólar estadounidense 100,0000 100,0000
 Bebidas CCU-PepsiCo SpA. (**) 76.337.371-1 Chile Peso chileno 49,9888 49,9888
 CCU Inversiones II SpA. (1) 76.349.531-0 Chile Dólar estadounidense 100,0000 100,0000
 Cervecería Szot SpA. (10) (**) 76.481.675-7 Chile Peso chileno - 25,0006
 Bebidas Carozzi CCU SpA. (**) 76.497.609-6 Chile Peso chileno 49,9917 49,9917
 Bebidas Ecusa SpA. 76.517.798-7 Chile Peso chileno 99,9834 99,9834
 Inversiones Invex CCU Ltda. (2) 76.572.360-4 Chile Dólar estadounidense 99,9925 99,9925
 Promarca Internacional SpA. (**) 76.574.762-7 Chile Dólar estadounidense 49,9917 49,9917
 CCU Inversiones S.A. (13) 76.593.550-4 Chile Peso chileno 99,9775 99,9775
 Inversiones Internacionales SpA. 76.688.727-9 Chile Dólar estadounidense 80,0000 80,0000
 Promarca S.A. (**) 76.736.010-K Chile Peso chileno 49,9917 49,9917
 D&D SpA. (5) (**) 76.920.876-3 Chile Peso chileno 40,8105 40,8105
 La Barra S.A. (18) 77.148.606-1 Chile Peso chileno 100,0000 100,0000
 Mahina SpA. (**) 77.248.551-4 Chile Peso chileno 25,0458 25,0458
 Volcanes del Sur S.A. (17) 77.622.887-7 Chile Peso chileno 74,9503 74,9503
 CirCCUlar SpA. (8) 77.847.898-3 Chile Peso chileno 99,9773 -
 Transportes CCU Ltda. 79.862.750-3 Chile Peso chileno 100,0000 100,0000
 Fábrica de Envases Plásticos S.A. 86.150.200-7 Chile Peso chileno 100,0000 100,0000
 Millahue S.A. (11) 91.022.000-4 Chile Peso chileno 99,9773 99,9621
 Viña San Pedro Tarapacá S.A. (*) (13) 91.041.000-8 Chile Peso chileno 85,1506 84,6824
 Manantial S.A. 96.711.590-8 Chile Peso chileno 50,5519 50,5519
 Viña Altaïr SpA. 96.969.180-9 Chile Peso chileno 85,1506 84,6824
 Cervecería Kunstmann S.A. 96.981.310-6 Chile Peso chileno 50,0007 50,0007
 Cervecera CCU Chile Ltda. (16) 96.989.120-4 Chile Peso chileno 100,0000 100,0000
 Embotelladoras Chilenas Unidas S.A. 99.501.760-1 Chile Peso chileno 99,9834 99,9834
 Comercial CCU S.A. 99.554.560-8 Chile Peso chileno 100,0000 100,0000
 Compañía Pisquera de Chile S.A. 99.586.280-8 Chile Peso chileno 80,0000 80,0000
 Aguas de Origen S.A. (12) 0-E Argentina Peso argentino 50,0970 -
 Compañía Cervecerías Unidas Argentina S.A. 0-E Argentina Peso argentino 100,0000 100,0000
 Compañía Industrial Cervecera S.A. (7) 0-E Argentina Peso argentino 100,0000 100,0000
 Finca La Celia S.A. 0-E Argentina Peso argentino 85,1506 84,6824
 Los Huemules S.R.L. 0-E Argentina Peso argentino 74,9980 74,9980
 Bebidas Bolivianas BBO S.A. (3) 0-E Bolivia Boliviano 51,0000 51,0000
 VSPT Winegroup (Shanghai) Limited (15) 0-E China Yuan 85,1506 84,6824
 International Spirits Investments USA LLC 0-E Estados Unidos Dólar estadounidense 80,0000 80,0000
 VSPT US LLC 0-E Estados Unidos Dólar estadounidense 85,1506 84,6824
 VSPT UK Ltd. (14) 0-E Reino Unido Libra esterlina 85,1506 84,6824
 AV S.A. (4) 0-E Paraguay Guaraní paraguayo 51,0166 -
 Bebidas del Paraguay S.A. (4) 0-E Paraguay Guaraní paraguayo 57,2158 55,0070
 Distribuidora del Paraguay S.A. (4) 0-E Paraguay Guaraní paraguayo 51,0024 54,9640
 Promarca Internacional Paraguay S.R.L. (**) 0-E Paraguay Guaraní paraguayo 49,9917 49,9917
 Sajonia Brewing Company S.R.L. 0-E Paraguay Guaraní paraguayo 56,6436 54,4569
 Andrimar S.A. 0-E Uruguay Peso uruguayo 100,0000 100,0000
 Coralina S.A. (19) 0-E Uruguay Peso uruguayo - 100,0000
 Marzurel S.A. 0-E Uruguay Peso uruguayo 100,0000 100,0000
 Milotur S.A. 0-E Uruguay Peso uruguayo 100,0000 100,0000
(*) Compañía registrada en la Comisión para el Mercado Financiero.
(**) Sociedades en las cuales la Compañía posee una participación superior o igual al 50% a través de una o más subsidiarias.
 18

[pág. 20]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Los principales movimientos ocurridos en la propiedad de las subsidiarias incluidas en los presentes Estados Financieros
Consolidados son los siguientes:
(1) CCU Inversiones II SpA.
A partir de la disolución de Inversiones Invex CCU Tres Ltda. ocurrida el 1 de julio de 2022, los accionistas de CCU
Inversiones II SpA., correspondiente a CCU S.A. y CCU Inversiones S.A., quedaron con un porcentaje de participación de
99,9511% y 0,0489%, respectivamente.
Con fecha 12 de diciembre de 2022, la Compañía realizó aporte de capital a la subsidiaria CCU Inversiones II SpA. por un
monto de USD 17.000.000 (equivalente a M$ 14.645.670), en donde la Compañía quedó con una participación de 99,9539%
y CCU Inversiones S.A. con un 0,0461%. Lo anterior no generó efectos a nivel consolidado de CCU.
Con fecha 28 de febrero de 2023, la Compañía realizó aporte de capital a la subsidiaria CCU Inversiones II SpA. por un
monto de USD 4.000.000 (equivalente a M$ 3.324.960), en donde la Compañía quedó con una participación de 99,9545% y
CCU Inversiones S.A. con un 0,0455%. Lo anterior no generó efectos a nivel consolidado de CCU.
Con fecha 9 de mayo de 2023, la Compañía realizó aporte de capital a la subsidiaria CCU Inversiones II SpA., por un monto
de USD 1.500.000 (equivalente a M$ 1.190.145), en donde la Compañía quedó con una participación de 99,9547% y CCU
Inversiones S.A. con un 0,0453%. Lo anterior no generó efectos a nivel consolidado de CCU.
Con fecha 26 de enero de 2024, la Compañía realizó aporte de capital a la subsidiaria CCU Inversiones II SpA., por un monto
de USD 41.775.000 (equivalente a M$ 38.055.772), en donde la Compañía quedó con una participación de 99,9602% y CCU
Inversiones S.A. con un 0,0398%. Lo anterior no generó efectos a nivel consolidado de CCU.
(2) Inversiones Invex CCU Ltda.
A partir de la disolución de Inversiones Invex CCU Tres Ltda. ocurrida el 1 de julio de 2022 los accionistas de Inversiones
Invex CCU Ltda., quedaron con las siguientes participaciones, CCU S.A. con un 65,1854% y CCU Inversiones S.A., con un
34,8086%.
Con fecha 25 de mayo de 2023, la Compañía realizó aporte de capital a la subsidiaria Inversiones Invex CCU Ltda., por un
monto de USD 8.150.000 (equivalente a M$ 6.593.595), en donde la Compañía quedó con una participación de un 66,6519%
y CCU Inversiones S.A., con un 33,3481%. Lo anterior no generó efectos a nivel consolidado de CCU.
(3) Bebidas Bolivianas BBO S.A.
Con fecha 26 de abril y 13 de junio de 2022 la subsidiaria CCU Inversiones II SpA. realizó aportes de capital a Bebidas
Bolivianas BBO S.A. por USD 1.019.971 y USD 1.019.971 (equivalentes a M$ 867.771 y M$ 950.695), respectivamente.
Dado que los socios concurrieron en proporción a la participación vigente se mantuvieron los porcentajes de participación.
Con fecha 25 de enero y 25 de mayo de 2023 la subsidiaria CCU Inversiones II SpA. realizó aportes de capital a Bebidas
Bolivianas BBO S.A. por USD 1.784.914 y USD 1.784.914 (equivalentes a M$ 1.437.659 y M$ 1.444.049), respectivamente.
Dado que los socios concurrieron en proporción a la participación vigente se mantuvieron los porcentajes de participación.
Con fecha 21 de febrero, 29 de abril, 12 de julio y 30 de diciembre de 2024 la subsidiaria CCU Inversiones II SpA. realizó
aportes de capital a Bebidas Bolivianas BBO S.A. por USD 1.019.971, USD 509.914, USD 1.087.508 y USD 495.052
(equivalentes a M$ 982.926, M$ 483.235, M$ 925.742 y M$ 454.034), respectivamente. Dado que los socios concurrieron
en proporción a la participación vigente se mantuvieron los porcentajes de participación.
 19

[pág. 21]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
(4) Bebidas del Paraguay S.A., Distribuidora del Paraguay S.A. y AV S.A.
Con fecha 26 de enero de 2023, la Oficina de Control de Activos Extranjeros (OFAC) del Departamento del Tesoro de los
Estados Unidos de América, anunció sanciones en contra del señor Horacio Cartes Jara, a dicha fecha, accionista de
nuestras subsidiarias Bebidas del Paraguay S.A. y Distribuidora del Paraguay S.A. (las "Sociedades Paraguayas").
Con fecha 1 de marzo de 2023, Compañía Cervecerías Unidas S.A. a través de su subsidiaria CCU Inversiones II SpA. firmó
un Acuerdo Privado con los accionistas, a dicha fecha, de las Sociedades Paraguayas, por medio del cual se acordó:
 i) La adquisición de la totalidad de las acciones de que era titular Sarah Cartes Jara en las Sociedades Paraguayas,
 compraventa que se materializó con fecha 1 de marzo de 2023, por un monto total de USD 4.001.920 (equivalente a
 M$ 3.205.058), pasando CCU a ser titular de un 55,0070% y un 54,9640% de Bebidas del Paraguay S.A. y
 Distribuidora del Paraguay S.A. (generando un efecto patrimonial de M$ 908.438), respectivamente; y
 ii) La adquisición por parte de un tercero no relacionado del señor Cartes de la totalidad de acciones que era titular, en
 el plazo máximo que venció el 17 de marzo de 2023 y sujeto a que CCU acuerde con este tercero ciertas
 modificaciones a los acuerdos de accionistas actualmente vigentes de las Sociedades Paraguayas.
Con fecha 16 de marzo de 2023, habiéndose cumplido, las condiciones previstas en el Acuerdo Privado, Sudameris Bank
S.A.E.C.A. (en adelante “Sudameris”) adquirió la totalidad de la participación accionaria del señor Horacio Cartes Jara en las
Sociedades Paraguayas, suscribiendo con CCU los respectivos Acuerdos de Accionistas, que contemplan cláusulas propias
de gobierno corporativo y otras usuales para este tipo de contratos, y un Acuerdo de Opciones Put, por un total de
USD 32.651.973 (valor presente de USD 31.745.078, equivalente a M$ 25.949.059 a la fecha de la suscripción y
USD 32.555.031, equivalente a M$ 28.554.669 al 31 de diciembre de 2023), respecto de las Sociedades Paraguayas (Ver
Nota 2 - Resumen de las principales políticas contables, 2.7 - Instrumentos financieros - Contrato de Opciones).
Con fecha 20 de febrero de 2024, en virtud de lo dispuesto en el Acuerdo de Opciones Put, CCU S.A., a través de sus
subsidiarias CCU Inversiones II SpA. y CCU Inversiones S.A., adquirieron de Sudameris la totalidad de las acciones de que
era titular, esta última en Bebidas del Paraguay S.A. y Distribuidora del Paraguay S.A., por un valor de USD 32.652.006
(equivalente a M$ 31.549.348). En consecuencia, a partir de esta fecha, los únicos accionistas de Bebidas del Paraguay
S.A. y Distribuidora del Paraguay S.A. son CCU Inversiones II SpA. y CCU Inversiones S.A.
Con fecha 14 de octubre de 2024, Compañía Cervecerías Unidas S.A., a través de sus subsidiarias CCU Inversiones II SpA.
y CCU Inversiones S.A., suscribió un contrato de acuerdos vinculantes y definitivos de asociación con Grupo Vierci, quien
detenta la licencia de los bebestibles y la distribución de snacks de PepsiCo en Paraguay, a través de sus sociedades AV
S.A. y AJ S.A. Calidad Ante Todo.
En virtud de dichos acuerdos contenidos en el contrato marco, y una vez cumplidas todas las condiciones del acuerdo, CCU
pasará a ser titular del 51% de las acciones de Bebidas del Paraguay S.A. y de Distribuidora del Paraguay S.A., y se adquiere
la nueva sociedad AV S.A., también en un 51%. El 49% restante de las acciones de tales compañías quedará en manos del
Grupo Vierci.
A la fecha de cierre de estos estados financieros aún no se han perfeccionado todas las estipulaciones del contrato marco,
por lo cual la participación al 31 de diciembre de 2024 del Grupo Vierci, sobre Bebidas del Paraguay S.A. es de un 43%.
El negocio adquirido aportó ingresos por M$ 9.270.041 y una ganancia neta de M$ 108.368 por el período del 14 de octubre
al 31 de diciembre de 2024.
Ver mas información en Nota 15 - Combinaciones de negocios, letra c).
 20

[pág. 22]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Para esta combinación de negocios se determinaron para AV S.A. los valores razonables provisorios de los activos y pasivos
que son los siguientes:
 Valor razonable
 Activos y Pasivos
 M$
Deudores comerciales y otras cuentas por cobrar 5.935.199
Inventarios 5.053.629
Otros activos corrientes 819.009
Total activos corrientes 11.807.837
Propiedades, plantas y equipos (neto) 6.621.135
Activos intangibles distintos de la plusvalía 12.264.118
Activos por derechos de uso 119.480
Total activos no corrientes 19.004.733
Total activos 30.812.570
Pasivos por arrendamientos corrientes 59.618
Cuentas por pagar comerciales y otras cuentas por pagar 10.578.725
Otros pasivos corrientes 1.460.285
Total pasivos corrientes 12.098.628
Pasivos por arrendamientos no corrientes 59.862
Pasivos por impuestos diferidos 1.180.741
Total pasivos no corrientes 1.240.603
Total pasivos 13.339.231
Activos netos identificables adquiridos 17.473.339
Participaciones no controladoras (8.559.035)
Valor de inversión 8.914.304
Contraprestación transferida (18.860.580)
Flujo de efectivo obtenido por combinación de negocio 17.112.779
Otras reservas (7.166.503)
 -
Como consecuencia de los valores razonables señalados anteriormente, se han generado principalmente Intangibles y
Propiedades, plantas y equipos, que se exponen en notas Nota 17 - Activos intangibles distintos de plusvalía y
Nota 19 - Propiedades, plantas y equipos, respectivamente.
(5) D&D SpA.
Con fecha 20 de enero de 2023, la subsidiaria Compañía Pisquera de Chile S.A. concretó la adquisición del 51,0132% de
participación de D&D SpA. (sociedad propietaria de, entre otros activos, de la marca La Pizka), sociedad por acciones que
se dedica a la coctelería congelada que tienen como producto principal el pisco sour envasado. Sus principales productos
son elaborados en la planta de producción ubicada en la comuna de Quilicura, ciudad de Santiago de Chile.
Desde la fecha de la adquisición y hasta el 31 de diciembre de 2023, D&D SpA. reportó una utilidad de M$ 662.355.
Al 31 de diciembre de 2024, la sociedad reportó una utilidad de M$ 190.218.
 21

[pág. 23]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Para esta combinación de negocios se determinaron los valores razonables definitivos de los activos y pasivos, que son los
siguientes:
 Valor razonable
 Activos y Pasivos
 M$
Deudores comerciales y otras cuentas por cobrar 404.882
Inventarios 300.055
Otros activos corrientes 287.574
Total activos corrientes 992.511
Propiedades, plantas y equipos (neto) 607.977
Activos intangibles distintos de la plusvalía 1.962.891
Activos por derechos de uso 26.767
Total activos no corrientes 2.597.635
Total activos 3.590.146
Pasivos por arrendamientos corrientes 26.767
Cuentas por pagar comerciales y otras cuentas por pagar 602.887
Otros pasivos corrientes 97.542
Total pasivos corrientes 727.196
Pasivos por arrendamientos no corrientes 100.755
Pasivos por impuestos diferidos 536.201
Total pasivos no corrientes 636.956
Total pasivos 1.364.152
Activos netos identificables adquiridos 2.225.994
Participaciones no controladoras (1.090.587)
Plusvalia 2.100.677
Valor de inversión 3.236.084
Como consecuencia de los valores razonables señalados anteriormente, se han generado principalmente Intangibles y
Plusvalía, que se exponen en Nota 17 - Activos Intangibles distintos de plusvalía y Nota 18 - Plusvalía, respectivamente.
(6) CRECCU S.A.
Con fecha 9 de enero de 2023, en Junta Extraordinaria de Accionistas de la subsidiaria CRECCU S.A. se acordó la
disminución de capital por M$ 1.500.000, el cual fue devuelto a los accionistas, es decir, a la Compañía y a la subsidiaria
CCU Inversiones S.A. en proporción a su participación.
(7) Compañía Industrial Cervecera S.A. y Sáenz Briones y Cía. S.A.I.C.
Con fecha 3 de abril de 2023, en directorio de Compañía Industrial Cervecera S.A., se aprobó llevar a cabo un proceso de
reorganización societaria entre Compañía Industrial Cervecera S.A. y Sáenz Briones y Compañía S.A.I.C., definiendo una
fecha efectiva de fusión de estas sociedades con fecha 1 de mayo de 2023. Lo anterior no generó impactos significativos
en los estados financieros consolidados.
La fusión se inscribió ante la Inspección de Personas Jurídicas de la Provincia de Salta con fecha 25 de septiembre de 2024
y ante la Inspección General de Justicia de la Ciudad Autónoma de Buenos Aires con fecha 11 de noviembre de 2024.
(8) CirCCUlar SpA.
Con fecha 1 de febrero de 2024, la Compañía a través de su subsidiaria Millahue S.A. constituyó la sociedad CirCCUlar SpA.
en Chile, con un capital social de M$ 10.000.000, dividido en 10.000.000 de acciones ordinarias y nominativas, el cual a la
fecha se encuentra íntegramente pagado. El objeto social de CirCCUlar SpA. es la fabricación, reciclaje y comercialización
de todo tipo de productos e insumos de plásticos.
(9) Cervecera Guayacán SpA.
Con fecha 26 de abril de 2024, la subsidiaria Cervecería Kunstmann S.A. realizó aporte de capital a Cervecera Guayacán
SpA. por un monto de M$ 84.131, quedando la subsidiaria Cervecería Kunstmann S.A. con una participación de un
60,0002%. Lo cual generó un efecto patrimonial positivo a nivel de la Compañía de M$ 31.300.
 22

[pág. 24]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
(10) Cervecería Szot SpA.
De acuerdo a contrato de compra venta de acciones, de fecha 29 de abril de 2024, la subsidiaria Cervecería Kunstmann
S.A., vendió a Cervecería Szot SpA., la totalidad de las acciones que poseía sobre esta última sociedad, que correspondía
a 97.856 acciones ordinarias de una misma serie, y que se encontraban íntegramente pagadas. El monto de la transacción
ascendió a M$ 208.755, el cual generó un efecto patrimonial negativo a nivel de la Compañía de M$ 60.881.
El pago de las acciones, se materializó, mediante la transferencia de dominio de las marcas de Cervecería Szot SpA. a
Cervecería Kunstmann S.A. por un valor de M$ 251.756 y la diferencia de valor de las mismas, ascendente a M$ 43.000,
Cervecería Kunstmann S.A. lo pagó en efectivo en dicho acto.
Con igual fecha, según consta en el contrato de reconocimiento de deuda y transferencia de bienes muebles, Cervecería
Szot SpA., pagó a Cervecería Kunstmann S.A., las deudas producto de las relaciones comerciales por un valor de
M$ 224.393 y también pagó las acciones y prendas pendientes por parte de Representaciones Chile Beer Kevin Michael
Szot E.I.R.L., de acuerdo a contrato de compraventa de acciones de fecha de 28 de agosto de 2020, por un monto de
M$ 49.094. Dichas deudas se pagaron con la transferencia de los activos fijos de Cervecería Szot SpA., por un valor de
M$ 273.487.
(11) Millahue S.A.
En Junta Extraordinaria de Accionistas celebrada el 29 de agosto de 2024, se aprobó aumentar el capital social de
Millahue S.A. en M$ 7.002.652 mediante la emisión de 14.142.310 acciones nominativas.
Con fecha 4 de septiembre de 2024, la Compañía pagó el aporte de capital por M$ 7.000.000, correspondiente a su
participación accionaria de 99,9621%.
En virtud de los dispuesto en la misma Junta Extraordinaria de Accionistas, el período de opción preferente venció 30 días
corridos desde la fecha de la escritura, por lo tanto, la Compañía al 31 de diciembre de 2024 queda con una participación
accionaria de 99,9773%.
(12) Aguas de Origen S.A.
Con fecha 28 de mayo de 2024, CCU Argentina S.A., notificó a Holding Internationale de Boissons S.A.S., el ejercicio de la
opción de compra de acciones, contenida en el acuerdo de accionistas, que le permitía a CCU Argentina S.A., adquirir la
cantidad de 8.471.349 acciones correspondientes al 0,1% de participación del negocio conjunto Aguas de Origen S.A. La
sociedad indicada hasta el 30 de junio de 2024 calificaba como un negocio conjunto de la Compañía, a través de su
subsidiaria CCU Argentina S.A.
Durante el mes julio de 2024, Holding Internationale de Boissons S.A.S., aceptó el ejercicio de la compra de la opción
mencionada en el párrafo precedente y con fecha el 1 de julio de 2024, CCU Argentina S.A. ejerció la opción por un valor de
M$ 47.217, quedando con una participación accionaria del 50,1%.
El negocio adquirido aportó ingresos por M$ 87.643.707 y una pérdida neta de M$ 2.894.151 durante el período del 1 de
julio al 31 de diciembre de 2024.
 23

[pág. 25]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Para esta combinación de negocios por etapas se determinaron los valores razonables provisorios de los activos y pasivos,
que son los siguientes:
 Valor razonable
 Activos y Pasivos
 M$
Deudores comerciales y otras cuentas por cobrar 13.502.497
Inventarios 11.903.064
Otros activos corrientes 2.293.374
Total activos corrientes 27.698.935
Propiedades, plantas y equipos (neto) 8.046.721
Activos intangibles distintos de la plusvalía 25.481.126
Activos por impuestos diferidos 1.545.351
Total activos no corrientes 35.073.198
Total activos 62.772.133
Otros pasivos Financieros 8.351.355
Cuentas por pagar comerciales y otras cuentas por pagar 27.255.032
Otros pasivos corrientes 1.030.235
Total pasivos corrientes 36.636.622
Otras provisiones a largo plazo 1.691.168
Total pasivos no corrientes 1.691.168
Total pasivos 38.327.790
Activos netos identificables adquiridos 24.444.343
Participaciones no controladoras (12.197.727)
Valor de inversión 12.246.616
Plusvalía 5.557.026
Inversión a valor razonable tenida anteriormente (15.128.327)
Utilidad combinación de negocios por etapas (2.628.098)
Flujo de efectivo utilizado para obtener control de subsidiaria (47.217)
 -
Como consecuencia de los valores razonables señalados anteriormente, se han generado principalmente Intangibles,
Plusvalía y Propiedades, plantas y equipos, que se exponen en Nota 17 - Activos Intangibles distintos de plusvalía,
Nota 18 - Plusvalía y Nota 19 - Propiedades, plantas y equipos, respectivamente.
(13) CCU Inversiones S.A. y Viña San Pedro Tarapacá S.A.
Con fecha 7 de septiembre de 2022, la subsidiaria CCU Inversiones S.A. adquirió un 0,1856% adicional de la subsidiaria
Viña San Pedro Tarapacá S.A. por un monto de M$ 438.105, equivalente a 74.000.000 de acciones, quedando con una
participación directa de 84,7015% (indirecta de 84,6824%), lo cual generó un efecto patrimonial a nivel de la Compañía de
M$ 102.625.
Con fecha 21 de noviembre de 2024, la subsidiaria CCU Inversiones S.A. adquirió un 0,4682% adicional de la subsidiaria
Viña San Pedro Tarapacá S.A. por un monto de M$ 711.155 equivalente a 187.146.096 acciones, quedando con una
participación directa de 85,1697% (indirecta de 85,1506%) la cual generó un efecto patrimonial positivo a nivel de la
Compañía de M$ 681.186.
(14) VSPT UK Ltd.
Con fecha 1 de junio de 2022, se constituyó la sociedad VSPT UK Ltd. en Reino Unido, cuyo objeto social es la
comercialización de vinos. Con fecha 1 de junio fue enterado el capital de la sociedad, el cual asciende a £ 1 (equivalente a
$ 1.135,30).
Con fecha 28 de noviembre de 2022 se realizó aumento de capital ascendente a £ 417.399 (equivalente a M$ 431.444).
(15) VSPT Winegroup (Shanghai) Limited
Con fecha 5 de diciembre de 2022, se constituyó la sociedad VSPT Winegroup (Shanghai) Limited en China, cuyo objeto
social es de marketing y promoción de marcas VSPT. El capital comprometido de la sociedad asciende a USD 500.000
(equivalente a M$ 498.230 al 31 de diciembre de 2024).
 24

[pág. 26]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
(16) Cervecera CCU Chile Ltda.
Con fecha 16 de agosto de 2022, la Compañía realizó aporte de capital a la subsidiaria Cervecera CCU Chile Ltda., por un
monto de M$ 6.750.000. Al solo concurrir CCU la participación en dicha subsidiaria quedó en un 99,8064% para CCU y en
un 0,1935% para Millahue S.A. Lo anterior no generó efectos a nivel consolidado de CCU.
(17) Volcanes del Sur S.A.
Con fecha 24 de agosto de 2022, las subsidiarias Cervecería Kunstmann S.A. y Cervecera CCU Chile Ltda. realizaron en
conjunto la compra de las marcas mixtas de Volcanes del Sur S.A. por un monto de M$ 12.950.000. Esta operación generó
una participación directa en Volcanes del Sur S.A. del 50,1% para Cervecería Kunstmann S.A. y de un 49,9% para Cervecera
CCU Chile Ltda.
(18) La Barra S.A.
En Junta Extraordinaria de Accionistas de La Barra S.A., celebrada el 2 de septiembre de 2022, se aprobó realizar un
aumento de capital por un total de M$ 4.500.000, equivalente a 4.500.000 de acciones. La Compañía y la subsidiaria
Cervecera CCU Chile Ltda. materializarán dicho aumento según su porcentaje de participación (99% y 1%, respectivamente).
La fecha efectiva de pago fue el 7 de octubre de 2022. Lo anterior no generó efectos a nivel consolidado de CCU.
(19) Coralina S.A.
De acuerdo a contrato de compra venta de acciones, de fecha 12 de diciembre de 2024, la subsidiaria CCU Inversiones II
SpA., vendió la totalidad de las acciones que poseía sobre la sociedad uruguaya Coralina S.A., que correspondía a 18.000
acciones ordinarias de una misma serie, y que se encontraban íntegramente pagadas. El monto de la transacción ascendió
a US$ 251.556 (equivalentes a M$ 245.471), el cual generó un efecto patrimonial negativo de M$ 107.286.
Acuerdos conjuntos que califican como operaciones conjuntas
Los acuerdos conjuntos que califican como operaciones conjuntas, son los siguientes:
(a) Promarca S.A.
Promarca S.A. es una sociedad anónima cerrada cuya actividad principal es la adquisición, desarrollo y administración de
marcas comerciales y su licenciamiento a los operadores de éstas.
Al 31 de diciembre de 2024, Promarca S.A. registra una utilidad de M$ 7.102.269 (M$ 6.490.044 en 2023 y M$ 7.729.870 en
2022) la cual según política de dicha sociedad se distribuye en un 100%.
(b) Bebidas CCU-PepsiCo SpA. (“BCP”)
El objeto de esta sociedad es la fabricación, producción, elaboración, transformación, transporte, importación, exportación,
compra, venta y en general todo tipo de concentrados y jarabes.
Al 31 de diciembre de 2024, BCP registra una utilidad de M$ 4.766.081 (M$ 5.628.818 en 2023 y M$ 4.781.336 en 2022) la
cual según política de dicha sociedad se distribuye en un 100%.
(c) Bebidas Carozzi CCU SpA. (“BCCCU”)
El objeto de esta sociedad es la producción, comercialización y distribución de bebidas instantáneas en polvo en el territorio
nacional.
Al 31 de diciembre de 2024, BCCCU registra una utilidad de M$ 652.159 (utilidad de M$ 769.486 en 2023 y una pérdida de
M$ 292.979 en 2022).
 25

[pág. 27]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Las compañías mencionadas anteriormente cumplen las condiciones estipuladas en la IFRS 11 para ser consideradas
“operaciones conjuntas”, ya que la administración las ha definido como tal, dado que el control conjunto es sobre el derecho
de los activos y pasivos relacionados al acuerdo conjunto. Los operadores conjuntos comparten todos los intereses en el
activo y pasivo relacionado con el acuerdo conjunto en proporciones específicos y sus ingresos corresponden en un 100%
al royalty cobrado a los operadores conjuntos por la venta de productos que utilizan estas marcas y por las ventas directas
de productos.
Nota 2 Resumen de las principales políticas contables
A continuación se describen las principales políticas de contabilidad adoptadas en la preparación de estos Estados
Financieros Consolidados.
2.1 Bases de preparación
Los presentes Estados Financieros Consolidados al 31 de diciembre de 2024 han sido preparados de acuerdo a las Normas
Internacionales de Información Financiera emitidas por el International Accounting Standards Board (“IFRS Accounting
Standards”), las que han sido aplicadas de manera uniforme en los ejercicios que se presentan.
Los Estados Financieros Consolidados se han preparado bajo el criterio del costo histórico, modificado por la revalorización
de ciertos activos financieros y pasivos financieros (incluyendo instrumentos derivados) a su valor razonable.
La preparación de los Estados Financieros Consolidados conforme a IFRS requiere el uso de ciertas estimaciones contables
críticas. También exige a la Administración que ejerza su criterio profesional en el proceso de aplicación de las políticas
contables de la Compañía. En Nota 3 - Estimaciones y aplicaciones del criterio profesional se revelan las materias que
implican un mayor grado de juicio o complejidad o las materias donde las hipótesis y estimaciones son significativas para los
Estados Financieros Consolidados
A la fecha de emisión de estos Estados Financieros Consolidados se han publicado nuevas Normas, Mejoras, Enmiendas e
Interpretaciones a las normas existentes, las que no han entrado en vigencia o la Compañía no ha adoptado con anticipación,
estas se presentan a continuación y son obligatorias a partir de las fechas indicadas:
 Aplicación obligatoria para
 Nuevas Normas, Mejoras, Enmiendas e Interpretaciones
 ejercicios iniciados en:
Enmienda IAS 21 Efectos de las Variaciones en las Tasas de Cambio de la Moneda Extranjera - 1 de enero de 2025
 Ausencia de convertibilidad de una moneda.
Enmienda IAS 7 Estados de Flujo Efectivo - método del costo. 1 de enero de 2026
Enmienda IFRS 1 Adopción por primera vez de las Normas Internacionales de Información Financiera.
 1 de enero de 2026
 - cambios en referencias a la contabilidad de Coberturas.
Enmienda IFRS 7 e IFRS 9 Instrumentos Financieros - Calificación y medición de instrumentos financieros. 1 de enero de 2026
Enmienda IFRS 10 Estados Financieros Consolidados - evaluación del control "agentes de facto". 1 de enero de 2026
IFRS 18 Presentación e información a revelar en los estados financieros. 1 de enero de 2027
IFRS 19 Subsidiarias que no son de interés público. 1 de enero de 2027
La Compañía estima que la adopción de estas nuevas Normas, Mejoras, Enmiendas e Interpretaciones antes mencionadas,
no tendrán un impacto significativo en los Estados Financieros Consolidados.
Por otra parte, la aplicación de los nuevos pronunciamientos contables, que entraron en vigencia a partir del 1 de enero de
2024, no tuvieron efectos en los Estados Financieros Consolidados de la Compañía.
2.2 Bases de consolidación
Subsidiarias
Subsidiarias son todas las entidades sobre las que la Compañía tiene poder para dirigir las políticas financieras y de
operación, lo que generalmente se deriva de una participación superior a la mitad de los derechos de voto. Al momento de
evaluar si la Compañía controla a otra entidad se considera la existencia y el efecto de los derechos potenciales de voto que
sean actualmente susceptibles de ser ejercidos a la fecha de los Estados Financieros Consolidados Las subsidiarias se
 26

[pág. 28]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
consolidan a partir de la fecha en que se transfiere el control a la Compañía, y se excluyen de la consolidación en la fecha
en que cesa el mismo.
Para contabilizar la adquisición de subsidiarias la Compañía utiliza el método de adquisición. El costo de adquisición es el
valor razonable de los activos entregados, de los instrumentos de patrimonio emitidos y de los pasivos incurridos o asumidos
en la fecha de intercambio. Los activos identificables adquiridos y los pasivos y contingencias identificables asumidos en una
combinación de negocios se valoran inicialmente de acuerdo a su valor razonable a la fecha de adquisición, con
independencia del alcance de las participaciones no controladoras. El exceso del costo de adquisición sobre el valor
razonable de la participación de la Compañía en los activos netos identificables adquiridos se reconoce como plusvalía. Si
el costo de adquisición es menor que el valor razonable de los activos netos de la subsidiaria adquirida, la diferencia se
reconoce directamente, como una utilidad, en el Estado Consolidado de Resultados por Función.
Operaciones conjuntas
Como se explica en Nota 1 - Información general, aquellos acuerdos conjuntos que califican como una operación conjunta,
la Compañía procedió a reconocer su parte en cada uno de los activos, pasivos y resultados con respecto a su participación
en la operación conjunta, de acuerdo a la IFRS 11.
Transacciones entre subsidiarias
En la consolidación se eliminan las transacciones intercompañías, los saldos y las ganancias no realizadas por transacciones
entre las entidades de la Compañía. Las pérdidas no realizadas también se eliminan, a menos que la transacción proporcione
evidencia de una pérdida por deterioro del activo transferido. Cuando es necesario para asegurar su uniformidad con las
políticas adoptadas por la Compañía, se modifican las políticas contables de las subsidiarias.
Participaciones no controladoras
Las participaciones no controladoras se presentan en el rubro Patrimonio del Estado Consolidado de Situación Financiera.
Las ganancias o pérdidas atribuibles a las participaciones no controladoras se presentan en el Estado Consolidado de
Resultados por Función después del resultado del ejercicio atribuible a propietarios de la controladora.
Inversiones contabilizadas por el método de la participación
Negocios conjuntos y asociadas
La Compañía mantiene inversiones en acuerdos conjuntos que califican como negocios conjuntos y que corresponden a un
acuerdo contractual por medio del cual dos o más partes realizan una actividad económica que está sujeta a control conjunto,
y normalmente involucra el establecimiento de una entidad separada en la cual cada controlador tiene una participación
basada en un pacto controlador. A su vez la Compañía mantiene inversiones en asociadas que se definen como aquellas
entidades sobre las que el inversor ejerce influencia significativa pero no tiene control sobre las políticas financieras, ni de
operación y no califica como subsidiaria ni constituye un negocio conjunto.
La Compañía reconoce su participación en acuerdos conjuntos que califican como negocios conjuntos y en asociadas usando
el método de la participación. Los Estados Financieros de los negocios conjuntos y en asociadas en donde participa la
Compañía son preparados para los mismos ejercicios de reporte, usando políticas contables consistentes. Se realizan
ajustes para mantener en línea cualquier política contable diferente que pudiera existir.
Cuando la Compañía contribuye o vende activos a las sociedades que se encuentran bajo control conjunto o que
corresponden a asociadas, cualquier utilidad o pérdida proveniente de la transacción es reconocida en resultados en base a
la naturaleza de la transacción. Cuando la Compañía compra activos de estas sociedades, no reconoce su porción de los
resultados del negocio conjunto sobre la transacción hasta que se vende o realiza el activo.
2.3 Información financiera por segmentos de operación
La Compañía ha definido tres segmentos de operación, los cuales se definieron en base a los ingresos de las actividades
de negocio provenientes de las zonas geográficas donde comercializa sus productos: 1.- Chile, 2.- Negocios Internacionales
y 3.- Vinos.
Los tres segmentos de operación señalados anteriormente, son consistentes con la forma en que se gestiona la Compañía.
Estos segmentos de operación contemplan información financiera separada y los resultados de su operación son revisados
 27

[pág. 29]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
periódicamente por la máxima autoridad en la toma de decisiones de operación de cada segmento para decidir respecto de
la asignación de recursos y para evaluar su desempeño (Ver Nota 6 - Información financiera por segmentos operativos).
El desempeño de los segmentos es evaluado en función de varios indicadores, entre los cuales se menciona el ROA, el
ROADA, el margen ROADA (% de ROADA respecto de los ingresos totales netos del segmento de operación), los volúmenes
y los ingresos por venta. Las ventas entre segmentos son efectuadas bajo términos y condiciones comerciales normales de
mercado.
El Resultado Operacional Ajustado (ROA), es definido por la Compañía como la Utilidad (pérdida) antes de Otras ganancias
(pérdidas), Gastos financieros netos, Utilidad de negocios conjuntos contabilizados por el método de la participación,
Ganancias (pérdidas) de cambio en moneda extranjera, Resultado por unidades de reajuste e Impuestos a las ganancias, y
el ROADA, para propósitos de la Compañía, se define como el Resultado Operacional Ajustado antes de Depreciación y
Amortización.
MSD&A, se refiere a la sigla en inglés para gastos de comercialización, distribución y administración.
Por último, los gastos e ingresos corporativos son presentados en forma separada, dentro de Otros.
2.4 Transacciones en monedas extranjeras y unidades de reajuste
Moneda de presentación y Moneda funcional
La Compañía y subsidiarias de Chile utilizan principalmente el peso chileno ($ o CLP) como su moneda funcional y moneda
de presentación de sus Estados Financieros. La moneda funcional se ha determinado considerando el ambiente económico
en que la Compañía desarrolla sus operaciones y la moneda en que se generan los principales flujos de efectivo. La moneda
funcional de algunas subsidiarias en Chile, China, Estados Unidos, Argentina, Uruguay, Paraguay, Bolivia, Reino Unido y
China es el dólar estadounidense, peso argentino, peso uruguayo, guaraní paraguayo, boliviano, libra esterlina y Yuan,
respectivamente. La moneda funcional del negocio conjunto en Colombia y asociadas en Argentina y Perú es el peso
colombiano, peso argentino y el sol, respectivamente.
Transacciones y saldos
Las transacciones en monedas extranjeras y unidades reajustables son registradas al tipo de cambio de la respectiva
moneda o unidad de reajuste a la fecha en que la transacción cumple con los requisitos para su reconocimiento inicial. Al
cierre de cada Estado Consolidado de Situación Financiera, los activos y pasivos monetarios denominados en monedas
extranjeras y unidades reajustables son traducidos a pesos chilenos al tipo de cambio vigente de la respectiva moneda o
unidad de reajuste. Las Ganancias (pérdidas) de cambio en moneda extranjera originadas, tanto en la liquidación de
operaciones en moneda extranjera, como en la valorización de los activos y pasivos monetarios en moneda extranjera, se
incluyen en el resultado del ejercicio en el rubro Ganancias (pérdidas) de cambio en moneda extranjera, en tanto las
diferencias originadas por los cambios en unidades de reajuste se registran en el rubro Resultado por unidades de reajuste.
Para efectos de consolidación, los activos y pasivos de las subsidiarias cuya moneda funcional es distinta del peso chileno
y no están operando en países cuya economía es considerada hiperinflacionaria, son traducidos a pesos chilenos usando
los tipos de cambio vigentes a la fecha de los Estados Financieros Consolidados mientras las Ganancias (pérdidas) de
cambio en moneda extranjera originadas por la conversión de activos y pasivos, son registradas en la cuenta de Reservas
de conversión dentro de Otras reservas de patrimonio. Los ingresos, costos y gastos son traducidos al tipo de cambio
promedio mensual para los respectivos ejercicios. Estos tipos de cambio no han sufrido fluctuaciones significativas durante
estos meses.
Los resultados y la situación financiera de las entidades del Grupo CCU, que tienen una moneda funcional diferente de la
moneda de presentación, siendo su moneda funcional la moneda de una economía hiperinflacionaria (como es el caso de
las subsidiarias en Argentina a partir del 1 de julio de 2018 según se describe a continuación), se convierten a la moneda de
presentación conforme lo establecen las IAS 21 e IAS 29.
Información financiera en economías hiperinflacionarias
La inflación en Argentina ha mostrado incrementos importantes desde inicios de 2018. La tasa de inflación acumulada de
tres años, calculada usando diferentes combinaciones de índices de precios de consumo, ha superado el 100% durante
varios meses, y sigue incrementándose. La inflación acumulada de tres años calculada usando el índice general de precios
ya ha sobrepasado el 100%. Por lo tanto, conforme lo prescribe la IAS 29, se declaró a Argentina como una economía
hiperinflacionaria a partir del 1 de julio de 2018.
 28

[pág. 30]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Conforme lo anterior, la IAS 29 debe ser aplicada por todas aquellas entidades cuya moneda funcional sea el peso argentino
para los períodos contables terminados con posterioridad al 1 de julio de 2018, como sí la economía siempre hubiese sido
hiperinflacionaria. Al respecto la IAS 29 requiere que los estados financieros de una entidad cuya moneda funcional es la
moneda de un país hiperinflacionario sean reexpresados en términos del poder adquisitivo vigente al final del período sobre
el que se informa. Lo anterior, implica que la reexpresión de partidas no monetarias debe efectuarse desde su fecha de
origen, última reexpresión, tasación u otra fecha particular en algunos casos muy específicos.
El factor de ajuste utilizado en cada caso es el obtenido con base en el índice combinado del Índice de Precios al Consumidor
Nacional (IPC), con el Índice de Precios Mayoristas (IPIM), publicados por el Instituto Nacional de Estadística y Censos de
la República Argentina (INDEC), según la serie elaborada y publicada por la Federación Argentina de Consejos Profesionales
de Ciencias Económicas (FACPCE).
A efectos de consolidación, para las subsidiarias cuya moneda funcional es el peso argentino se ha considerado el párrafo
43 de la IAS 21, el cual requiere que los estados financieros de una subsidiaria que tiene la moneda funcional de una
economía hiperinflacionaria se reexpresen de acuerdo con la IAS 29, antes de ser convertidos a tipo de cambio de cierre de
la fecha de reporte, para que estos sean incluidos en los estados financieros consolidados.
La re-expresión de las partidas no monetarias se realiza desde su fecha de reconocimiento inicial en los estados de situación
financiera y considerando que los estados financieros son preparados bajo el criterio del costo histórico.
La re-expresión por hiperinflación se registrará hasta el período en el que la economía de la entidad deje de ser considerada
como una economía hiperinflacionaria; en ese momento, los ajustes realizados por hiperinflación formarán parte del costo
de los activos y pasivos no monetarios.
A continuación se presentan las Ganancias (pérdidas) derivadas de la posición monetaria neta de las subsidiarias en
Argentina, que se registra en Resultado por unidades de reajuste:
 Por los ejercicios terminados al 31 de diciembre de
 2024 2023 2022
 M$ M$ M$
Ganancias (pérdidas) derivadas de la posición monetaria neta 4.700.583 (5.668.787) 910.811
 29

[pág. 31]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Los tipos de cambio de las principales monedas extranjeras, unidades de reajuste e índices utilizadas en la preparación de
los Estados Financieros Consolidados, son los siguientes:
 Al 31 de Al 31 de Al 31 de
 diciembre de diciembre de diciembre de
 Pesos chilenos por unidad de moneda extranjera o unidad de reajuste 2024 2023 2022
 $ $ $
 Monedas extranjeras
 Dólar estadounidense USD 996,46 877,12 855,86
 Dólar estadounidense promedio mensual acumulado USD promedio 943,74 839,79 872,33
 Euro EUR 1.035,28 970,05 915,95
 Peso argentino ARS 0,97 1,08 4,83
 Peso uruguayo UYU 22,61 22,48 21,36
 Dólar canadiense CAD 693,82 663,98 632,61
 Libra esterlina GBP 1.249,01 1.118,20 1.033,90
 Guaraní paraguayo PYG 0,13 0,12 0,12
 Franco suizo CHF 1.100,57 1.044,56 927,36
 Boliviano BOB 143,17 126,02 122,97
 Dólar australiano AUD 619,92 599,21 583,01
 Corona danesa DKK 138,84 130,14 123,18
 Real brasileño BRL 161,32 180,80 161,96
 Peso colombiano COP 0,23 0,23 0,18
 Yuan CYN 136,24 123,15 122,68
 Unidades de reajuste
 Unidad de fomento (*) UF 38.416,69 36.789,36 35.110,98
 Unidad indexada (**) UI 139,09 132,13 118,93
(*) La Unidad de Fomento (UF) es un índice indexado a la inflación, denominado en pesos chilenos. La UF es calculada diariamente basada en los
cambios que experimenta el ratio de inflación en el mes anterior.
(**) La Unidad Indexada (UI) es un índice indexado a la inflación, denominado en pesos uruguayos. La UI es calculada diariamente basada en los
cambios que experimenta el ratio de inflación en el mes anterior.
 Al 31 de Al 31 de Al 31 de
 Índice utilizado en economías hiperinflacionarias diciembre de diciembre de diciembre de
 2024 2023 2022
 Índice de Precios al Consumo Argentina 7.701,19 3.520,08 1.138,64
 Variación porcentual del Índice de Precios al Consumo Argentina 119,0% 209,1% 95,5%
2.5 Efectivo y equivalentes al efectivo
El efectivo y equivalentes al efectivo incluye el efectivo en caja, los saldos en bancos, los depósitos a plazo en entidades
financieras, las inversiones en cuotas de fondos mutuos y los instrumentos financieros adquiridos con compromiso de
retroventa (pactos), así como todas las inversiones a corto plazo de gran liquidez todos pactados a una tasa de interés fija,
normalmente con un vencimiento de hasta tres meses.
2.6 Otros activos financieros
Los otros activos financieros incluyen valores negociables, contratos derivados en entidades financieras y depósitos a plazo
con vencimientos a más de 90 días.
 30

[pág. 32]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
2.7 Instrumentos financieros
La IFRS 9 - Instrumentos financieros, reemplaza a la IAS 39 - Instrumentos financieros, para los períodos anuales que
comiencen el 1 de enero de 2018 y que reúne tres aspectos de contabilidad y que son: clasificación y medición; deterioro; y
contabilidad de cobertura.
Activos financieros
La Compañía reconoce un activo financiero en el Estado Consolidado de Situación Financiera de acuerdo a lo siguiente:
A la fecha de reconocimiento inicial, la administración de la Compañía clasifica sus activos financieros como: (i) a valor
razonable a través de resultados, (ii) costo amortizado (créditos y cuentas por cobrar) y (iii) a valor razonable con cambios
en Otros resultados integrales (derivados de cobertura). La clasificación depende del propósito para el cual los activos
financieros fueron adquiridos. Para los instrumentos no clasificados a valor razonable a través de resultados, cualquier costo
atribuible a la transacción es reconocido como parte del valor del activo.
El valor razonable de instrumentos que son cotizados activamente en mercados formales está determinado por los precios
de cotización en la fecha de cierre de los Estados Financieros Consolidados Para inversiones donde no existe un mercado
activo, el valor razonable es determinado utilizando técnicas de valorización, entre las que se incluyen: (i) el uso de
transacciones de mercado recientes, (ii) referencias al valor actual de mercado de otro instrumento financiero de
características similares, (iii) descuento de flujos de efectivo y (iv) otros modelos de valuación.
Con posterioridad al reconocimiento inicial la Compañía valoriza los activos financieros como se describe a continuación:
Créditos y cuentas por cobrar
Los créditos y las cuentas por cobrar comerciales se reconocen por el importe de la factura.
La Compañía toma seguros de crédito que cubren aproximadamente el 90% de los saldos de las cuentas por cobrar
individualmente significativas para el mercado nacional y para el mercado internacional, respectivamente, del total de las
cuentas por cobrar, netos de un deducible del 10%.
Una pérdida por deterioro para los saldos por cobrar a nuestros clientes se produce cuando existe una evidencia objetiva de
que la Compañía no será capaz de cobrar todos los importes de acuerdo a los términos originales de las cuentas a cobrar.
Algunos indicadores de que una cuenta por cobrar pueda ser incobrable son las dificultades financieras, inicio de un proceso
de quiebra, una reestructuración financiera y antigüedad de la morosidad de nuestros clientes.
El importe y cálculo de la estimación por pérdida por deterioro, se mide en una cantidad igual a las “Pérdidas Crediticias
Esperadas”, utilizando el enfoque simplificado establecido en la IFRS 9 y para determinar si existe o no deterioro sobre la
cartera se realiza un análisis de riesgo de acuerdo a la experiencia histórica (tres años) sobre la incobrabilidad de la
misma, considerando también otros factores de antigüedad hasta llegar a un 100% de las deudas superiores a 180 días, y
de aquellos casos que, de acuerdo a la política, se estiman pérdidas parciales por deterioro sobre análisis individuales caso
a caso.
La Compañía considera que estos activos financieros podrían estar deteriorados cuando: i) Es poco probable que el deudor
pague sus obligaciones de crédito en su totalidad, sin que la Compañía recurra a acciones tales como la reclamación de
seguros, o ii) El activo financiero ha excedido la fecha de vencimiento acordada contractualmente.
a) Medición de la pérdida esperada
La Pérdida Crediticia Esperada corresponde a la probabilidad de pérdidas crediticias de acuerdo a la historia reciente,
considerando la incobrabilidad de los últimos tres años móviles. Estos ratios históricos se ajustan de acuerdo a la
mensualidad y monto de los diferentes documentos por cobrar comerciales históricos. Complementariamente se analiza la
cartera de acuerdo a su probabilidad de solvencia en el futuro, su historia financiera reciente y las condiciones de mercado,
para determinar la categoría del cliente, para la constitución de provisión en relación a su riesgo definido.
b) Deterioro crediticio
En cada fecha de presentación de los Estados Financieros, la Compañía evalúa si estos activos financieros contabilizados
a costo amortizado, tienen deterioro crediticio. Un activo financiero tiene "deterioro crediticio" cuando ocurren uno o más
eventos que generan un impacto perjudicial en la estimación de los flujos de efectivo futuros. Adicionalmente la Compañía
 31

[pág. 33]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
incluye información de los efectos por modificaciones de los flujos efectivos contractuales (repactaciones), las cuales son
menores y corresponden a casos específicos con clientes estratégicos de la Compañía.
Adicionalmente la Compañía mantiene seguros de crédito para cuentas por cobrar individualmente significativas. Las
pérdidas por deterioro se registran en el Estado de Resultados por Función en el período que se producen.
Los créditos y cuentas por cobrar comerciales corrientes se reconocen a su valor nominal y no se descuentan. La Compañía
ha determinado que el cálculo del costo amortizado no presenta diferencias significativas con respecto al monto facturado
debido a que la transacción no tiene costos significativos asociados.
Pasivos financieros
La Compañía reconoce un pasivo financiero en el Estado Consolidado de Situación Financiera, de acuerdo a lo siguiente:
Préstamos y obligaciones financieras que devengan intereses
Los préstamos y obligaciones financieras que devengan intereses son reconocidos inicialmente al valor razonable de los
recursos obtenidos, menos los costos incurridos directamente atribuibles a la transacción. Después del reconocimiento
inicial, los préstamos y obligaciones que devengan intereses se valorizan al costo amortizado. La diferencia entre el monto
neto recibido y valor a pagar es reconocida en el Estado Consolidado de Resultados por Función durante el período de
duración del préstamo, utilizando el método de interés efectivo.
Los intereses pagados y devengados que corresponden a préstamos y obligaciones utilizadas en el financiamiento de sus
operaciones se presentan bajo Costos financieros.
Los préstamos y obligaciones que devengan intereses, con vencimiento dentro de los próximos doce meses, son clasificados
como pasivos corrientes a menos que la Compañía tenga el derecho incondicional de diferir el pago de la obligación por al
menos doce meses después de la fecha del cierre de los Estados Financieros Consolidados.
Cuentas por pagar comerciales y otras cuentas por pagar
Las cuentas por pagar comerciales y otras cuentas por pagar se reconocen a su valor nominal, debido a que no difiere
significativamente de su valor razonable. La Compañía ha determinado que no existe una diferencia significativa de utilizar
el cálculo del costo amortizado del método de tasa de interés efectiva.
Instrumentos financieros derivados
Todos los instrumentos financieros derivados son reconocidos a la fecha de suscripción del contrato y revaluados
posteriormente a su valor razonable a la fecha de cierre de los Estados Financieros Consolidados. Las utilidades y/o pérdidas
resultantes de la medición a valor razonable son registradas en el Estado Consolidado de Resultados por Función como
utilidades y/o pérdidas por valor razonable de instrumentos financieros a menos que el instrumento derivado califique, esté
designado y sea efectivo como un instrumento de cobertura.
Los instrumentos medidos a valor razonable a través de resultados incluyen activos financieros mantenidos para negociar y
activos financieros que se han designado como tal por la Compañía. Los activos financieros son clasificados como
mantenidos para negociar si son adquiridos con el propósito de venderlos en el corto plazo.
Los instrumentos derivados que son designados como cobertura son contabilizados como coberturas de flujos de caja.
Para calificar un instrumento financiero derivado como instrumento de cobertura para efectos contables, la Compañía
documenta: (i) a la fecha de la transacción o en el momento de su designación, la relación entre el instrumento de cobertura
y la partida protegida, así como los objetivos y estrategias de la administración de riesgos, (ii) la evaluación, tanto a la fecha
de suscripción como en una base continua, de la efectividad del instrumento utilizado para compensar los cambios en el
valor razonable o los flujos de caja de la partida protegida. Una cobertura se considera efectiva cuando los cambios en el
valor razonable o en los flujos de caja del subyacente directamente atribuibles al riesgo cubierto, se compensan con los
cambios en el valor razonable o en los flujos de caja del instrumento de cobertura, con una efectividad comprendida en un
rango de 80% a 125%.
El valor razonable total de los derivados de cobertura se clasifica como Otros activos o Pasivos financieros no corrientes si
el vencimiento de la partida cubierta es superior a 12 meses y como Otros activos o Pasivos financieros corrientes si el
vencimiento restante de la partida cubierta es inferior a 12 meses. El efecto en resultados de estos instrumentos se puede
 32

[pág. 34]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
ver en el rubro Otras ganancias (pérdidas) del Estado Consolidado de Resultados por Función. La porción efectiva del cambio
en el valor razonable de instrumentos derivados que son designados y califican como coberturas de flujos de efectivo es
reconocida inicialmente en Reservas de Cobertura de Flujos de Efectivo en un componente separado del Patrimonio. La
utilidad o pérdida relacionada con la porción inefectiva es reconocida inmediatamente en el Estado Consolidado de
Resultados por Función. Los montos acumulados en patrimonio son reclasificados a resultados en el mismo período en que
la respectiva exposición impacta el Estado Consolidado de Resultados por Función. Cuando una cobertura de flujos de caja
deja de cumplir con los criterios de contabilidad de cobertura, cualquier utilidad o pérdida acumulada que exista en patrimonio
permanece en patrimonio y es reconocida cuando la transacción esperada es finalmente reconocida en el Estado
Consolidado de Resultados por Función. Cuando se tiene la expectativa que una transacción esperada ya no ocurra, la
utilidad o pérdida acumulada que exista en patrimonio se reconoce inmediatamente en el Estado Consolidado de Resultados
por Función.
Los instrumentos derivados se clasifican como mantenidos para negociar a menos que se clasifiquen como instrumentos de
cobertura.
Contrato de Opciones
La opción de venta otorgada, fue reconocida de acuerdo a lo descrito en Nota 1 - Información general, letra C), numeral
(4), registrándose como un pasivo financiero en los estados financieros consolidados.
En relación con las entidades no controladoras, la política adoptada por la Compañía se basa en la prevalencia de la IFRS
10 sobre la IAS 32, por lo que se mantiene contabilizada la participación no controladora, por considerar que los riesgos y
beneficios asociados a su propiedad, han sido retenidos por la participación no controladora.
Finalmente, en relación con la responsabilidad financiera asociada con el Contrato de Opción y en consistencia con la política
contable adoptada en párrafo anterior, el Contrato de Opción se reconoce inicialmente como un pasivo financiero contra
patrimonio y se valora tanto inicialmente como posteriormente por el valor actual del importe a reembolsar, es decir,
descontando el precio de la opción a una tasa que refleje la calificación de riesgo crediticio del emisor del pasivo (ver Nota
7 - Instrumentos financieros).
Depósitos recibidos en garantías de envases y contenedores
Corresponde al pasivo constituido por las garantías en dinero recibidas de los clientes por los envases y contenedores
puestos a su disposición. Representa el valor que será devuelto al cliente cuando éste a su vez los devuelva a la Compañía
en buenas condiciones, junto con el documento original. Este valor se determina mediante la estimación de los envases y
contenedores en circulación que se espera sean devueltos a la Compañía en el transcurso del tiempo, basado en la
experiencia histórica, recuentos en poder de clientes y estudios independientes de la cantidad que está en poder de los
consumidores finales, valorizados al promedio ponderado de las garantías para cada tipo de envase y contenedor.
No se tiene previsto efectuar devoluciones significativas de estos depósitos dentro de los siguientes 12 meses, y se presenta
dentro de pasivos corrientes, en el rubro Otros pasivos financieros, dado que la Compañía no tiene la habilidad legal de
diferir su pago por un período superior a 12 meses. Este pasivo no es descontado ya que es pagadero a la vista, con el
documento original y la devolución de los respectivos envases en buenas condiciones. Este pasivo no contempla cláusulas
de reajuste o aplicación de intereses.
2.8 Deterioro de activos financieros
La Compañía evalúa a cada fecha del Estado Consolidado de Situación Financiera si un activo financiero o grupo de activos
financieros presenta indicios de deterioro.
La Compañía evalúa el deterioro de las cuentas por cobrar en forma colectiva, para lo cual agrupa los activos financieros de
acuerdo con características de riesgo similares que son indicativas de la capacidad de los deudores para cumplir con sus
obligaciones en los términos pactados. Cuando existe evidencia objetiva que se ha incurrido en una pérdida por deterioro de
las cuentas por cobrar, el monto de la pérdida es reconocido en el Estado Consolidado de Resultados por Función, bajo el
rubro Gastos de administración.
Si en un ejercicio posterior, el monto de la pérdida por deterioro disminuye y la disminución puede ser objetivamente
relacionada con un evento que ocurre después del reconocimiento del deterioro, la pérdida por deterioro anteriormente
reconocida es reversada.
 33

[pág. 35]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Cualquier reverso posterior de una pérdida por deterioro es reconocido en resultados en la medida que el valor libro del
activo no excede su valor razonable a la fecha de reverso.
2.9 Inventarios
Los inventarios se valorizan al menor valor entre su costo de adquisición o producción y su valor neto realizable. El costo de
producción de los productos terminados y de los productos en proceso incluye las materias primas, la mano de obra directa,
los gastos indirectos de fabricación basados en una capacidad operativa normal y otros costos incurridos para dejar los
productos en las ubicaciones y condiciones necesarias para su venta, netos de descuentos atribuibles a los inventarios.
El valor neto realizable es el precio de venta estimado en el curso normal de los negocios, menos los gastos de
comercialización y distribución. Cuando las condiciones del mercado generan que el costo de producción supere a su valor
neto realizable, se registra una estimación de deterioro por el diferencial del valor. En dicha estimación de deterioro se
consideran también montos relativos a obsolescencia derivados de baja rotación, obsolescencia técnica y productos retirados
del mercado.
El costo de los inventarios y de los productos vendidos se determina usando el método de Costo Promedio Ponderado (CPP).
La Compañía estima que la mayor parte de los inventarios tienen una alta rotación.
Los materiales y materias primas adquiridas a terceros se valorizan al precio de adquisición y cuando se consumen se
incorporan al valor del costo de los productos terminados usando el método CPP.
2.10 Activos biológicos corrientes
Bajo el rubro Activos biológicos corrientes, la Compañía incluye los costos asociados a la explotación agrícola (uva), los
cuales son activados hasta la fecha en que se efectúa la cosecha, momento en el cual pasan a formar parte del costo de
inventario de los procesos siguientes. A su vez, la Administración considera que los costos asociados a la explotación
agrícola representan una razonable aproximación a su valor razonable.
2.11 Otros activos no financieros
Incluyen principalmente desembolsos por pagos anticipados asociados a Publicidad relacionados a contratos por la
confección de comerciales que están en proceso y que aún no han sido exhibidos (corrientes y no corrientes), pagos de
seguros y anticipos a proveedores en relación a ciertas compras de propiedades, plantas y equipos. Adicionalmente se
incluyen derechos sociales, garantías pagadas relacionadas con arriendos y materiales por consumir relacionados a
implementos de seguridad industrial.
2.12 Propiedades, plantas y equipos
Las propiedades, plantas y equipos (PPE) son registrados al costo histórico, menos depreciaciones acumuladas y pérdidas
por deterioro. El costo incluye tanto los desembolsos directamente atribuibles a la adquisición o construcción del activo, como
así también los costos por intereses incurridos para la construcción de cualquier activo calificado, los que se capitalizan
durante el ejercicio de tiempo que es necesario para completar y preparar el activo para el uso que se pretende. Los
desembolsos posteriores a la compra o adquisición sólo son capitalizados cuando es probable que beneficios económicos
futuros asociados a la inversión fluyan hacia la Compañía y los costos puedan ser medidos razonablemente. Los otros
desembolsos posteriores corresponden a reparaciones o mantenciones y son registrados en el Estado Consolidado de
Resultados por Función cuando son incurridos.
 34

[pág. 36]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
La depreciación de PPE es calculada linealmente basada en la vida útil estimada de dichos bienes, considerando el valor
residual estimado de éstos. Cuando un bien está compuesto por componentes significativos, que tienen vidas útiles
diferentes, cada parte se deprecia en forma separada. Las estimaciones de vidas útiles y valores residuales de PPE son
revisadas y ajustadas, si es necesario, a cada fecha de cierre de los Estados Financieros Consolidados. Las vidas útiles
estimadas de propiedades, plantas y equipos son las siguientes:
 Tipo de bienes Número de años
Terrenos Indefinida
Edificios y construcciones 20 a 60
Maquinarias y equipos 10 a 25
Muebles y enseres 5 a 10
Otros equipos (coolers) 5a8
Envases de vidrio, plásticos y contenedores 3 a 12
Vides en producción 30
Las pérdidas y ganancias por la venta de propiedades, plantas y equipos se calculan comparando los ingresos obtenidos
con el valor en libro y se incluyen en el Estado Consolidado de Resultados por Función.
Las vides mantenidas por la subsidiaria Viña San Pedro Tarapacá S.A. y sus subsidiarias consisten en vides en producción
y formación. Las uvas cosechadas son utilizadas para la posterior producción de vinos.
Las vides en producción son valorizadas al costo histórico menos depreciación y cualquier pérdida por deterioro acumulada.
La depreciación de las vides en producción es realizada sobre una base lineal y se encuentra basada en la vida útil estimada
promedio de producción de 30 años, la cual es evaluada periódicamente. Las vides en formación no se deprecian hasta que
comienzan su producción.
Los costos incurridos en la adquisición y plantación de nuevas vides son capitalizados.
Cuando el valor libro de un activo de propiedad, planta y equipos excede a su monto recuperable, este es reducido
inmediatamente hasta su monto recuperable (Ver Nota 2 - Resumen de las principales políticas contables, 2.17).
2.13 Arrendamientos
Los contratos de arriendo se registran mediante el reconocimiento de un activo por el derecho de uso de los bienes sujetos
a contratos de arrendamiento bajo el rubro Activos por derechos de uso y un pasivo que se presenta dentro de pasivos
corrientes y no corrientes, en el rubro Pasivos por arrendamientos, equivalente al valor presente de los pagos asociados al
contrato. Cabe señalar, que los activos y pasivos derivados de un contrato de arrendamiento se miden inicialmente a su
valor presente.
En cuanto a los efectos en el Estado Consolidado de Resultados por función, mensualmente se reconoce la depreciación
del derecho de uso, dicha depreciación es calculada linealmente durante el plazo del arrendamiento, junto con la
correspondiente cuota de costo financiero asociada a la actualización del pasivo por arrendamiento. Este costo financiero se
reconoce en resultados durante el período de arrendamiento, con el fin de producir una tasa de interés periódica constante
sobre el saldo restante del pasivo. En el caso de modificaciones al contrato de arrendamiento tales como valor del
arrendamiento, plazo, índice de reajustabilidad, tasa de interés asociada, etc., el arrendatario reconoce el monto de la nueva
medición del pasivo por arrendamiento como un ajuste al activo por el derecho de uso. Adicionalmente la Compañía excluyó
de esta contabilización, aquellos contratos con plazos menores a 12 meses y cuyos activos sean de un valor inferior a
USD 5.000. La Compañía reconoce los pagos de arrendamiento asociados con estas operaciones como un gasto lineal
durante el plazo del contrato.
Antes de la entrada en vigencia de la IFRS 16, la Compañía clasificaba los arrendamientos cuando se transferían
sustancialmente todos los riesgos y beneficios asociados a la propiedad del bien. Todos los demás arriendos se
consideraban operativos. Los bienes adquiridos mediante arrendamiento financiero se registraban como activos no
corrientes, valorándose inicialmente al valor presente de los pagos mínimos futuros o a su valor justo si es menor,
reflejándose en el pasivo la correspondiente deuda con el arrendatario. Los pagos realizados se desglosaban entre la
cancelación de la deuda y la carga financiera correspondiente, la cual se registra como Costo financiero del período. En el
 35

[pág. 37]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
caso de arrendamientos operativos, el gasto se contabilizaba linealmente en función de la duración del contrato de
arrendamiento por el valor del servicio devengado.
2.14 Propiedades de inversión
Las propiedades de inversión corresponden a terrenos y edificios mantenidos por la Compañía con la finalidad de generar
plusvalías y no para ser utilizadas en el transcurso normal de sus negocios y son registradas al costo histórico menos
cualquier pérdida por deterioro. Las propiedades de inversión, excluidos los terrenos, se deprecian basada en la vida útil
estimada de dichos bienes considerando el valor residual estimado de estos.
2.15 Activos intangibles distintos de plusvalía
Marcas comerciales
Las marcas comerciales de la Compañía corresponden a activos intangibles de vida útil indefinida que se presentan a su
costo histórico, menos cualquier pérdida por deterioro. La Compañía considera que mediante las inversiones en marketing
las marcas mantienen su valor y por lo tanto se consideran con vida útil indefinida y no son amortizables. Estos activos se
someten a pruebas de deterioro anualmente o cuando existan factores que indiquen una posible pérdida de valor
(Ver Nota 2 - Resumen de las principales políticas contables, 2.17).
Programas informáticos
Las licencias adquiridas de programas informáticos son capitalizadas al valor de los costos incurridos en adquirirlas y
prepararlas para usar los programas específicos. Estos costos se amortizan durante sus vidas útiles estimadas (4 a 7 años).
Los costos de mantenimiento de programas informáticos se reconocen como gasto en el período en que se incurren.
Derechos de agua
Los derechos de agua adquiridos por la Compañía corresponden al derecho de aprovechamiento de aguas existentes en
fuentes naturales y fueron registrados a su valor de compra. Dado que estos derechos son a perpetuidad no son
amortizables, sin embargo anualmente son sometidos a evaluación de deterioro o cuando existen factores que indiquen una
posible pérdida de valor (Ver Nota 2 - Resumen de las principales políticas contables, 2.17).
Derechos de distribución
Corresponde a derechos adquiridos para distribuir diversos productos. Estos derechos se amortizan en sus vidas útiles
estimadas.
Investigación y desarrollo
Los gastos de investigación y desarrollo se reconocen como un gasto en el ejercicio en que se incurren.
2.16 Plusvalía
La plusvalía representa el exceso del costo de adquisición de una combinación de negocios sobre la participación de la
Compañía en el valor razonable de los activos identificables, pasivos y pasivos contingentes de la subsidiaria a la fecha de
adquisición y es contabilizado a su valor de costo menos pérdidas acumuladas por deterioro. La plusvalía relacionada con
adquisiciones de negocios conjuntos se incluye en el valor contable de la inversión.
Para efectos de pruebas de deterioro, la plusvalía es asignada a las Unidades Generadoras de Efectivo (UGE) que se espera
se beneficien de las sinergias de una combinación de negocios. Cada unidad o grupo de unidades (Ver Nota 18 - Plusvalía)
representa el menor nivel dentro de la Compañía al cual la plusvalía es monitoreada para efectos de administración interna
y el cual no es mayor que un segmento de operación. Las UGEs, a las cuales es asignada dicha plusvalía comprada, son
testeadas anualmente por deterioro o con mayor frecuencia cuando hay indicios que una unidad generadora de efectivo
puede estar deteriorada, o que han cambiado algunas de las condiciones de mercado que le son relevantes.
La plusvalía generada en adquisiciones de negocios conjuntos es evaluada por deterioro como parte de la inversión siempre
que haya indicios que la inversión pueda estar deteriorada.
 36

[pág. 38]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Una pérdida por deterioro es reconocida por el monto en que el valor libro de la unidad generadora de efectivo excede su
valor recuperable, siendo el valor recuperable el mayor valor entre el valor razonable de la unidad generadora de efectivo,
menos los costos de venta, y su valor en uso.
Una pérdida por deterioro es asignada primero a la plusvalía para reducir su valor libro y luego a los otros activos de la
unidad generadora de efectivo. Una vez reconocidas las pérdidas por deterioro no son reversadas en los ejercicios
siguientes.
2.17 Deterioro de activos no corrientes distintos de la plusvalía
La Compañía evalúa anualmente la existencia de indicadores de deterioro sobre activos no financieros. Si existen
indicadores, la Compañía estima el monto recuperable del activo deteriorado. De no ser posible estimar el monto recuperable
del activo deteriorado a nivel individual, la Compañía estima el monto recuperable de la unidad generadora de efectivo al
cual el activo pertenece.
Para los activos intangibles de vida útil indefinida, los cuales no son amortizados, en forma anual o antes si se detectan
evidencias de deterioro, se realizan las pruebas necesarias, de modo de asegurar que su valor contable no supere el valor
recuperable.
El monto recuperable es definido como el mayor entre el valor razonable, menos los costos de venta y el valor en uso. El
valor en uso es determinado mediante la estimación de los flujos de efectivo futuros, asociados al activo o unidad generadora
de efectivo, descontados a su valor presente, utilizando tasas de interés, antes de impuestos, que reflejan el valor del dinero
en el tiempo y los riesgos específicos del activo. En el caso que el monto del valor libro del activo exceda a su monto
recuperable, la Compañía registra una pérdida por deterioro en los resultados del ejercicio.
Los demás activos no financieros distintos de plusvalía e intangibles con vida útil indefinida, se someten a pruebas de
pérdidas por deterioro siempre que algún suceso o cambio en las circunstancias del negocio indiquen que el valor libros de
los activos puede no ser recuperable y se reconoce una pérdida por deterioro cuando el valor libros es mayor que su valor
recuperable.
La Compañía evalúa anualmente si los indicadores de deterioro sobre activos no financieros que derivaron en pérdidas
registradas en ejercicios pasados han desaparecido o han disminuido. Si existe esta situación, el monto recuperable del
activo específico es recalculado y su valor libro incrementado si es necesario. El incremento es reconocido en el Estado
Consolidado de Resultados por Función como un reverso de pérdidas por deterioro. El incremento del valor del activo
previamente deteriorado es reconocido sólo si éste proviene de cambios en los supuestos que fueron utilizados para calcular
el monto recuperable. El monto de incremento del activo producto del reverso de la pérdida por deterioro es limitado hasta
el monto que hubiera sido reconocido de no haber existido el deterioro.
2.18 Activos no corrientes mantenidos para la venta
La Compañía clasifica como activos no corrientes mantenidos para la venta las propiedades, plantas y equipos sujetos a
enajenación, para los cuales en la fecha de cierre del Estado Consolidado de Situación Financiera se han iniciado gestiones
activas para su venta.
Estos activos sujetos a enajenación se valorizan al menor valor entre el valor libros y el valor estimado de venta deducidos
los costos necesarios de llevarla a cabo, y dejan de depreciarse desde el momento en que son clasificados como activos no
corrientes mantenidos para la venta.
2.19 Impuesto a las ganancias
El impuesto a las ganancias está conformado por el impuesto a la renta asociado a las obligaciones legales por impuesto a
la renta y los impuestos diferidos reconocidos de acuerdo con la IAS 12. El impuesto a la renta es reconocido en el Estado
Consolidado de Resultados por Función, excepto cuando éste se relaciona con partidas registradas directamente en el
patrimonio, en cuyo caso el efecto de impuesto se reconoce también en patrimonio.
Obligación por impuesto a la renta
Las obligaciones por impuesto a la renta son reconocidas en los Estados Financieros en base a la mejor estimación de las
rentas líquidas imponibles a la fecha de cierre de los Estados Financieros y aplicando la tasa de impuesto a la renta vigente
a dicha fecha en los países en que opera la Compañía.
 37

[pág. 39]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Impuestos diferidos
Los impuestos diferidos son los impuestos que la Compañía espera pagar o recuperar en el futuro por las diferencias
temporarias entre el valor libro de los activos y pasivos para propósitos de reporte financiero y la correspondiente base
tributaria de estos activos y pasivos utilizada en la determinación de las utilidades afectas a impuesto. Los activos y pasivos
por impuestos diferidos son generalmente reconocidos por todas las diferencias temporarias y son calculados a las tasas
que estarán vigentes a la fecha en que los pasivos sean pagados y los activos sean realizados.
Se reconocen impuestos diferidos sobre las diferencias temporarias que surgen en inversiones en subsidiarias y asociadas,
excepto en aquellos casos en que la Compañía pueda controlar la fecha en que revertirán las diferencias temporarias y sea
probable que éstas no se vayan a revertir en un futuro previsible. Los activos por impuestos diferidos, incluidos aquellos
originados por pérdidas tributarias, son reconocidos en la medida que es probable que en el futuro existan utilidades
tributables contra las cuales se puedan imputar las diferencias temporarias deducibles y las pérdidas tributarias no utilizadas.
Los activos y pasivos por impuesto diferido son compensados si existe un derecho legalmente exigible de compensar activos
tributarios contra pasivos tributarios y el impuesto diferido esté relacionado con la misma entidad tributaria.
2.20 Beneficios a los empleados
Vacaciones de los empleados
La Compañía registra el costo asociado a las vacaciones del personal sobre base devengada.
Bonificaciones a empleados
La Compañía reconoce un pasivo y un gasto para bonos cuando está obligada contractualmente o cuando dado el resultado
a determinada fecha se estima que se pagará o devengará a final del año.
Indemnización por años de servicios
La Compañía registra un pasivo por el pago a todo evento de indemnizaciones por años de servicio, correspondiente a
planes de beneficios definidos, derivado de los acuerdos colectivos e individuales suscritos con los trabajadores. Esta
obligación se determina mediante el valor actuarial del costo devengado del beneficio, método que considera diversos
factores en el cálculo, tales como estimaciones de permanencia futura, tasas de mortalidad, incrementos salariales futuros
y tasas de descuentos. Este valor así determinado se presenta a valor actual utilizando el método de beneficios devengados
por años de servicio. Las tasas de descuento se determinan por referencia a curvas de tasas de interés de mercado. Las
pérdidas y ganancias son directamente reconocidas en el Estado Consolidado de Resultados por Función.
De acuerdo a la Enmienda IAS 19, las pérdidas o ganancias actuariales se registran directamente en el Estado Consolidado
de Resultados Integrales, en Patrimonio, y por otra parte, de acuerdo a las políticas de la Compañía, los costos financieros
relacionados al plan de beneficios definidos se registran bajo el rubro Costos financieros en el Estado Consolidado de
Resultados por Función.
2.21 Provisiones
Las provisiones se reconocen cuando: (i) la Compañía tiene una obligación presente, ya sea legal o implícita, como resultado
de eventos pasados; (ii) es probable vaya a ser necesaria una salida de recursos para liquidar la obligación y (iii) el monto
se ha estimado de forma fiable. Los montos reconocidos como provisión son la mejor estimación de la administración a la
fecha de cierre de los Estados Financieros Consolidados y de los desembolsos necesarios para liquidar la obligación.
Los conceptos por los cuales se constituyen provisiones con cargo a resultados corresponden principalmente a juicios civiles,
laborales y tributarios por los que pudiese verse afectada la Compañía (Ver Nota 24 - Otras provisiones).
2.22 Reconocimiento de ingresos
Los ingresos son reconocidos en la medida en que es probable que los beneficios económicos fluyan hacia la Compañía y
puedan ser medidos con fiabilidad. Los ingresos son medidos al valor razonable de los beneficios económicos recibidos o
por recibir y se presentan netos del impuesto al valor agregado, impuestos específicos, devoluciones, descuentos y rappel.
Los ingresos por ventas de bienes se reconocen después de que la Compañía ha transferido al comprador los riesgos y
beneficios inherentes a la propiedad de esos bienes y no mantiene el derecho a disponer de ellos, ni a mantener un control
eficaz; por lo general, esto significa que las ventas se registran al momento del traspaso de riesgos y beneficios a los clientes
 38

[pág. 40]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
en conformidad con los términos convenidos en los acuerdos comerciales y una vez que se satisface la obligación de
desempeño.
En relación a la IFRS 15, la Compañía ha aplicado los criterios establecidos en esta norma para los presentes Estados
Financieros Consolidados.
Venta de productos en el mercado doméstico
La Compañía genera sus ingresos principalmente por la venta de bebestibles tales como cervezas, bebidas gaseosas, aguas
minerales, aguas purificadas, néctares, vinos, sidra y licores, productos que son distribuidos a través de comercios
minoristas, distribuidores mayoristas y cadenas de supermercados y ninguno de ellos actúa como agente comercial de la
Compañía. Los ingresos por ventas en los mercados domésticos, netos del impuesto al valor agregado, impuestos
específicos, devoluciones, descuentos y rappel, se reconocen al momento de la entrega de los productos conjuntamente con
la transferencia de todos los riesgos y beneficios de los mismos y una vez que se satisface la obligación de desempeño.
Exportación
En general las condiciones de entrega de la Compañía en las ventas de exportación se basan en los Incoterms 2000, siendo
las reglas oficiales para la interpretación de términos comerciales emitidos por la Cámara de Comercio Internacional.
La estructura de reconocimiento de ingresos se basa en la agrupación de Incoterms, principalmente en los siguientes grupos:
• "FOB (Free on Board) y similares", donde el comprador organiza y paga por el transporte, por lo tanto, el punto de
 venta es la entrega de las mercancías al transportista contratado por el comprador, momento en que se reconocen
 los ingresos.
• "CIF (Cost, Insurance & Freight) y similares", mediante el cual la Compañía organiza y paga el gasto de transporte
 al exterior y algunos otros gastos, aunque la Compañía deja de ser responsable de las mercancías una vez que
 han sido entregadas a la Compañía marítima o aérea de conformidad con el plazo pertinente. El punto de venta es
 la entrega de la mercancía al transportista contratado por el vendedor para el transporte al destino, momento en
 que se reconocen los ingresos.
En el caso de existir discrepancias entre los acuerdos comerciales y los Incoterms definidos para la operación, primarán los
establecidos en los contratos.
Los ingresos por ventas en los mercados de exportación se reconocen netos de impuestos específicos, devoluciones,
descuentos y rappel, según corresponda y se registran de acuerdo al Incoterm definido y conjuntamente con la transferencia
de todos los riesgos y beneficios de los mismos y una vez que se satisface la obligación de desempeño.
2.23 Acuerdos comerciales con distribuidores y cadenas de supermercados
La Compañía celebra acuerdos comerciales con sus clientes, distribuidores y supermercados a través de los cuales se
establecen: (i) descuentos por volumen y otras variables del cliente; (ii) descuentos promocionales, que corresponden a una
reducción adicional en el precio de los productos vendidos, con ocasión del desarrollo de iniciativas comerciales
(promociones temporales); (iii) pago por servicios y otorgamiento de contraprestaciones (contratos de publicidad y
promoción, uso de espacios preferentes y otros); y (iv) publicidad compartida, que corresponde a la participación de la
Compañía en campañas publicitarias, revistas de promoción y apertura de nuevos puntos de venta.
Los descuentos por volumen y descuentos promocionales se reconocen como una reducción en el precio de venta de los
productos vendidos. Los aportes para publicidad compartida se reconocen cuando se han desarrollado las actividades
publicitarias acordadas con el distribuidor y se registran como gastos de comercialización incurridos, bajo el rubro Otros
gastos por función.
Los compromisos con distribuidores o importadores en el ámbito de las exportaciones se reconocen en base a los acuerdos
comerciales existentes.
2.24 Costos de venta de productos
Los costos de venta incluyen el costo de producción de los productos vendidos y otros costos incurridos para dejar las
existencias en las ubicaciones y condiciones necesarias para su venta. Estos costos incluyen, entre sus principales, los
costos de materias primas, costo de envasado, costos de la mano de obra del personal de producción, la depreciación de
 39

[pág. 41]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
los activos relacionados a la producción, la depreciación de los envases retornables, los pagos por licencias y los costos
operativos y de mantenimiento de plantas y equipos.
2.25 Otros ingresos por función
Los otros ingresos por función comprenden, principalmente, ingresos por venta de activo fijo y otros activos, recuperación
de siniestros, arriendos, y cobros por término anticipado de licencia.
2.26 Otros gastos por función
Otros gastos por función comprenden, principalmente, gastos de publicidad y promoción, las depreciaciones de activos de
venta, gastos de venta, gastos de marketing (conjuntos, letreros, neones en instalaciones de clientes) y las remuneraciones
y compensaciones del personal de marketing y ventas.
2.27 Costos de distribución
Los costos de distribución comprenden todos aquellos gastos necesarios para entregar los productos a los clientes.
2.28 Gastos de administración
Los gastos de administración comprenden las remuneraciones y compensaciones del personal de las unidades de apoyo,
las depreciaciones de oficinas, equipos, instalaciones y muebles utilizados en estas funciones, las amortizaciones de activos
no corrientes y otros gastos generales y de administración.
2.29 Medio ambiente
En caso de existir pasivos ambientales se registran sobre la base de la interpretación actual de las leyes y reglamentos
ambientales, cuando sea probable que una obligación se produzca y el importe de dicha responsabilidad se pueda calcular
de forma fiable.
Los desembolsos asociados a la protección del medio ambiente se imputan al Estado Consolidado de Resultados por
Función cuando se incurren, excepto, las inversiones en obras de infraestructura destinadas a cumplir requerimientos
medioambientales, las cuales se activan siguiendo los criterios contables generales para propiedades, plantas y equipos.
 40

[pág. 42]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 3 Estimaciones y aplicaciones del criterio profesional
La preparación de Estados Financieros Consolidados requiere que la Administración realice estimaciones y utilice supuestos
que afectan los montos incluidos en estos Estados Financieros Consolidados y sus notas relacionadas. Las estimaciones
realizadas y supuestos utilizados por la Compañía se basan en la experiencia histórica, cambios en la industria e información
suministrada por fuentes externas calificadas. Sin embargo, los resultados finales podrían diferir de las estimaciones bajo
ciertas condiciones.
Las estimaciones y políticas contables significativas son definidas como aquellas que son importantes para reflejar
correctamente la situación financiera y los resultados de la Compañía y/o las que requieren un alto grado de juicio por parte
de la Administración.
Las principales estimaciones y aplicaciones del criterio profesional se encuentran relacionadas con los siguientes conceptos:
• La valoración de la plusvalía para determinar la existencia de potenciales pérdidas por deterioro de los mismos
 (Nota 2 - Resumen de las principales políticas contables (2.16) y Nota 18 - Plusvalía).
• La valoración de marcas comerciales para determinar la existencia de pérdidas por deterioro de las mismas (Nota
 2 - Resumen de las principales políticas contables (2.17) y Nota 17 - Activos intangibles distintos de
 plusvalía).
• Las hipótesis empleadas en el cálculo actuarial de las obligaciones con los empleados (Nota 2 - Resumen de las
 principales políticas contables (2.20) y Nota 26 - Provisión por beneficios a los empleados).
• La vida útil de las propiedades, plantas y equipos (Nota 2 - Resumen de las principales políticas contables (2.12)
 y Nota 19 - Propiedades, plantas y equipos) e intangibles (programas informáticos) (Nota 2 - Resumen de las
 principales políticas contables (2.15) y Nota 17 - Activos intangibles distintos de plusvalía).
• Las hipótesis utilizadas para el cálculo del valor razonable de los instrumentos financieros (Nota 2 - Resumen de
 las principales políticas contables (2.7) y Nota 7 - Instrumentos financieros).
• La probabilidad de ocurrencia y el monto de los pasivos de monto incierto o contingentes (Nota 2 - Resumen de
 las principales políticas contables (2.21) y Nota 24 - Otras provisiones).
• La valoración de los activos biológicos corrientes (Nota 2 - Resumen de las principales políticas contables (2.10)
 y Nota 13 - Activos biológicos corrientes).
Estas estimaciones se realizan en función de la mejor información disponible sobre los hechos analizados a la fecha de
emisión de estos Estados Financieros Consolidados. En cualquier caso, es posible que acontecimientos que puedan tener
lugar en el futuro obliguen a modificarlas en los próximos ejercicios, lo que de ocurrir se realizaría de forma prospectiva.
Nota 4 Cambios contables
Los Estados Financieros Consolidados al 31 de diciembre de 2024 no presentan cambios en las políticas contables respecto
de los estados financieros al 31 de diciembre de 2023.
 41

[pág. 43]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 5 Administración de riesgos
Administración de riesgos
Para las empresas donde existe una participación controladora, la Gerencia Corporativa de Administración y Finanzas de la
Compañía provee un servicio centralizado a las empresas del grupo para la obtención de financiamiento y la administración
de los riesgos de tipo de cambio, tasa de interés, liquidez, riesgo de inflación, riesgos de materias primas y riesgo de crédito.
Esta función opera de acuerdo con un marco de políticas y procedimientos que es revisado regularmente para cumplir con
el objetivo de administrar el riesgo proveniente de las necesidades del negocio.
Para aquellas empresas en que existe una participación no controladora (VSPT, CPCh, Aguas CCU-Nestlé S.A., Cervecería
Kunstmann S.A., Bebidas Bolivianas BBO S.A., Bebidas del Paraguay S.A., Distribuidora del Paraguay S.A. y AV S.A.) esta
responsabilidad recae en sus respectivos Directorios y respectivas Gerencias de Administración y Finanzas. El Directorio y
Comité de Directores, cuando procede, es el responsable final del establecimiento y revisión de la estructura de
administración del riesgo, como también de revisar los cambios significativos realizados a las políticas de administración de
riesgos y recibe información relacionada con dichas actividades.
De acuerdo a las políticas de administración de riesgos, la Compañía utiliza instrumentos derivados solo con el propósito de
cubrir exposiciones a los riesgos de tasas de interés y tipos de cambios provenientes de las operaciones de la Compañía y
sus fuentes de financiamiento, de los cuales, algunos son tratados contablemente como coberturas. Las transacciones con
instrumentos derivados son realizadas exclusivamente por personal de la Gerencia de Administración y Finanzas y la
Gerencia de Auditoría Interna revisa regularmente el ambiente de control de esta función. La relación con los clasificadores
de riesgo y el monitoreo de restricciones financieras (covenants) son administrados por la Gerencia de Administración y
Finanzas.
La exposición de riesgos financieros de la Compañía está relacionada principalmente con las variaciones de tipos de cambio,
tasas de interés, inflación, precios de materias primas (commodities), impuestos, cuentas por cobrar a clientes y liquidez.
Con la finalidad de administrar el riesgo proveniente de algunas de estas exposiciones se utilizan diversos instrumentos
financieros.
Para cada uno de los puntos siguientes, y donde aplica, los análisis de sensibilidad desarrollados son solamente para efectos
ilustrativos, ya que en la práctica las variables sensibilizadas rara vez cambian sin afectarse unas a otras y sin afectar otros
factores que fueron considerados como constantes y que también afectan la posición financiera y de resultados de la
Compañía.
Riesgo de tipo de cambio
La Compañía se encuentra expuesta a riesgos de tipo de cambio provenientes de: a) su exposición neta de activos y pasivos
en monedas extranjeras, b) los ingresos por ventas de exportación, c) las compras de materias primas, insumos e inversiones
de capital efectuadas en monedas extranjeras o indexadas a dichas monedas, y d) la inversión neta de subsidiarias
mantenidas en el exterior. La mayor exposición a riesgos de tipo de cambio de la Compañía es la variación del peso chileno
respecto del dólar estadounidense, el euro, el peso argentino, el peso uruguayo, guaraní paraguayo, boliviano y peso
colombiano.
Al 31 de diciembre de 2024, la Compañía mantiene pasivos en monedas extranjeras por el equivalente a M$ 725.459.706
(M$ 673.839.310 al 31 de diciembre de 2023) que en su mayoría están denominadas en dólares estadounidenses. Las
obligaciones con instituciones financieras y obligaciones con el público en monedas extranjeras por M$ 600.172.708 al 31
de diciembre de 2024 (M$ 544.341.120 al 31 de diciembre de 2023) representan un 44% (42% al 31 de diciembre de 2023)
del total de las obligaciones financieras. El 56% (58% al 31 de diciembre de 2023) restante está denominado principalmente
en Unidades de Fomento y pesos chilenos. Adicionalmente, la Compañía mantiene activos en monedas extranjeras por
M$ 621.497.508 (M$ 564.888.883 al 31 de diciembre de 2023) que corresponden principalmente a efectivo y equivalentes
al efectivo y cuentas por cobrar por exportaciones.
Para proteger el valor de la posición neta de los activos y pasivos en monedas extranjeras de sus operaciones en Chile y
Argentina, la Compañía adquiere contratos de derivados (forwards de monedas) para mitigar cualquier variación en el peso
chileno y en el peso argentino respecto de otras monedas.
Respecto de las operaciones de las subsidiarias en el extranjero, la exposición neta pasiva en dólares estadounidenses y
otras monedas extranjeras, después del uso de instrumentos derivados, equivale a M$ 74.315.533 (M$ 42.453.444 al 31 de
diciembre de 2023).
 42

[pág. 44]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Al 31 de diciembre de 2024 la exposición neta en Chile en monedas extranjeras, después del uso de instrumentos derivados,
es pasiva por M$ 4.356.360 (M$ 7.510.628 al 31 de diciembre de 2023).
Del total de ingresos por ventas al 31 de diciembre de 2024 de la Compañía, un 5% (5% en 2023 y 6% en 2022) corresponde
a ventas de exportación efectuadas en monedas extranjeras, principalmente dólares estadounidenses, euro, libra esterlina
y otras monedas y del total de costos directos aproximadamente un 65% (62% en 2023 y 63% en 2022) corresponde a
compras de materias primas e insumos en monedas extranjeras o que se encuentran indexados a dichas monedas. La
Compañía no cubre las eventuales variaciones en los flujos de caja esperados por estas transacciones.
Por otra parte, la Compañía se encuentra expuesta a los movimientos en los tipos de cambio relacionados con la conversión
desde pesos argentinos, pesos uruguayos, guaraníes paraguayos, bolivianos, dólar estadounidense, libra esterlina, yuan,
soles y pesos colombianos a pesos chilenos de los resultados, activos y pasivos de sus subsidiarias en Argentina, Uruguay,
Paraguay, Bolivia, Estados Unidos, Reino Unido y China, negocio conjunto y asociadas en Argentina y Perú y negocio
conjunto en Colombia. La Compañía no cubre los riesgos relacionados con la conversión de las subsidiarias, asociada y
negocio conjunto cuyos efectos son registrados en Patrimonio.
Análisis de sensibilidad al tipo de cambio
El efecto por Ganancias (pérdidas) de cambio en moneda extranjera reconocido en el Estado Consolidado de Resultados
por Función para el ejercicio terminado al 31 de diciembre de 2024, relacionado con los activos y pasivos denominados en
monedas extranjeras asciende a una pérdida de M$ 17.797.269 (M$ 65.944.570 en 2023 y M$ 20.173.381 en 2022).
Considerando la exposición en Chile al 31 de diciembre de 2024, después del uso de instrumentos derivados es pasiva por
M$ 4.356.360 (M$ 7.510.628 al 31 de diciembre de 2023), y asumiendo un aumento/disminución de un 10% en los tipos de
cambio y manteniendo todas las otras variables constantes, tales como tasas de interés, se estima que el efecto sobre los
resultados de la Compañía sería una pérdida/utilidad después de impuesto de M$ 318.014 (M$ 545.052 en 2023 y M$ 43.941
en 2022) asociado a los propietarios de la controladora.
Considerando que aproximadamente el 5% de los ingresos por ventas de la Compañía corresponden a ventas de exportación
efectuadas desde Chile (5% en 2023 y 6% en 2022) y que aproximadamente un 65% (62% en 2023 y 63% en 2022) del total
de costos directos de la Compañía están en dólares estadounidenses o indexados a dicha moneda y asumiendo que las
monedas funcionales se aprecien/deprecien un 10% respecto al dólar estadounidense, manteniendo todas las demás
variables constantes, el efecto hipotético sobre los resultados de la Compañía sería aproximadamente una pérdida/utilidad
después de impuesto por este efecto de M$ 48.376.600 (M$ 41.161.484. en 2023 y M$ 43.950.998 en 2022).
La Compañía, también está sujeta al tipo de cambio de los países donde operan las subsidiarias en el extranjero, ya que el
resultado se convierte a pesos chilenos al tipo de cambio promedio de cada mes, excepto Argentina que utiliza el tipo de
cambio de cierre de la fecha de reporte. El resultado de las operaciones de las subsidiarias en el extranjero acumuladas al
31 de diciembre de 2024 fue una utilidad de M$ 31.554.223, utilidad de M$ 60.164.242 en 2023 y pérdida de M$ 63.345.544
en 2022). Por lo tanto, una depreciación/apreciación del tipo de cambio del peso argentino, uruguayo, guaraní paraguayo y
boliviano respecto del peso chileno de un 10%, generaría hipotéticamente una pérdida/utilidad antes de impuesto
M$ 3.155.422 (M$ 6.016.424 en 2023 y M$ 6.334.554 en 2022).
La inversión neta mantenida en subsidiarias, negocios conjuntos y asociadas que desarrollan sus actividades en el extranjero
al 31 de diciembre de 2024 asciende a M$ 549.120.456, M$ 123.023.739 y M$ 1.813.525, respectivamente (M$ 288.873.649,
M$ 135.198.194 y M$ 1.743.986 al 31 de diciembre de 2023). Asumiendo un aumento o disminución de un 10% en el tipo
de cambio del peso argentino, peso uruguayo, guaraní paraguayo, boliviano o peso colombiano respecto del peso chileno y
manteniendo todas las otras variables constantes, el aumento/disminución mencionado anteriormente resultaría
hipotéticamente en una utilidad/pérdida de M$ 67.395.772 (M$ 42.581.583 en 2023 y M$ 54.791.581 en 2022) que se
registraría con abono/cargo a patrimonio.
La Compañía no cubre los riesgos relacionados con la conversión de moneda de los Estados Financieros de las subsidiarias
que tienen otra moneda funcional, cuyos efectos son registrados en Patrimonio.
 43

[pág. 45]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Riesgo de tasas de interés
El riesgo de tasas de interés proviene principalmente de las fuentes de financiamiento de la Compañía.
Para administrar el riesgo de tasas de interés, la Compañía posee una política de administración de tasas de interés que
busca reducir la volatilidad de su gasto financiero y mantener un porcentaje ideal de su deuda en instrumentos con tasas
fijas. Las obligaciones en instituciones financieras y con el público se encuentran mayormente fijas por el uso de instrumentos
derivados tales como cross currency swaps.
Al 31 de diciembre de 2024 y 31 de diciembre de 2023, luego de considerar el efecto de swaps de tasas de interés y de
monedas, el 100% de las deudas de la Compañía poseen tasas de interés fija.
Los términos y condiciones de las obligaciones con instituciones financieras de la Compañía al 31 de diciembre de 2024,
incluyendo los tipos de cambio, tasa de interés, vencimientos y tasas de interés efectivas, se encuentran detallados en
Nota 21 - Otros pasivos financieros.
Análisis de sensibilidad a las tasas de interés
El Costo financiero total reconocido en el Estado Consolidado de Resultados por Función para el ejercicio terminado al 31
de diciembre de 2024, relacionado principalmente a deudas de corto y largo plazo, asciende a M$ 97.165.278 (M$ 77.023.048
en 2023 y M$ 75.930.875 en 2022).
Riesgo de inflación
La Compañía mantiene una serie de contratos con terceros indexados a UF como así mismo la deuda financiera indexada
a UF, lo que significa que quede expuesta a las fluctuaciones de la UF, generándose incrementos en el valor de dichos
contratos y pasivos en caso de que ésta experimente un crecimiento en su valor producto de la inflación. Este riesgo se ve
mitigado en parte debido a que la Compañía tiene como política a) ajustar sus precios de acuerdo a la inflación, dentro de
las condiciones que permite el mercado, manteniendo de esta manera sus ingresos unitarios en UF relativamente constantes
y b) mantener contratos cross currency swap para cubrir deuda financiera neta en UF si las condiciones del mercado son
favorables para la Compañía.
La inflación en Argentina ha mostrado incrementos importantes desde inicios de 2018. La tasa de inflación acumulada de
tres años, calculada usando diferentes combinaciones de índices de precios de consumo, ha superado el 100% durante
varios meses, y sigue incrementándose. La inflación acumulada de tres años calculada usando el índice general de precios
ya ha sobrepasado el 100%. Por lo tanto, conforme lo prescribe la IAS 29, se declaró a Argentina como una economía
hiperinflacionaria a partir del 1 de julio de 2018 (ver Nota 2 - Resumen de las principales políticas contables (2.4)).
Análisis de sensibilidad a la inflación
El resultado por unidades de reajuste total reconocido en el Estado Consolidado de Resultados por Función para el ejercicio
terminado al 31 de diciembre de 2024, relacionado a ciertos activos, deudas de corto y largo plazo indexados a la Unidad de
Fomento y por la aplicación de la contabilidad hiperinflacionaria en Argentina, corresponde a una pérdida pérdida de
M$ 10.722.033 (pérdida de M$ 14.025.895 en 2023 y utilidad de M$ 1.198.565 en 2022). Asumiendo un aumento/disminución
razonablemente posible de la Unidad de Fomento en aproximadamente 3% en Chile y una inflación de un 30% en Argentina,
y manteniendo todas las otras variables constantes, tales como tasas de interés, el aumento/disminución mencionado
anteriormente resultaría hipotéticamente en una pérdida/utilidad antes de impuesto de M$ 8.948.677 (M$ 11.592.842 al 31
de diciembre de 2023 y M$ 4.681.098 en 2022) en el Estado Consolidado de Resultados por Función.
Riesgo de precio de materias primas
La principal exposición a la variación de precios de materias primas se encuentra relacionada con el abastecimiento de
cebada, malta y latas utilizados en la producción de cervezas, concentrados, azúcar y envases plásticos utilizados en la
producción de bebidas gaseosas y vinos a granel y uvas para la fabricación de vinos y licores.
 44

[pág. 46]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Malta y latas
La Compañía en Chile se abastece de malta proveniente de productores locales y del mercado internacional (principalmente
Argentina). Con los productores locales y argentinos se suscriben compromisos de abastecimiento a largo plazo, en los
cuales el precio de la malta se fija anualmente en función del precio de mercado de la cebada y de los costos de fabricación
establecidos en los contratos.
Las compras y los compromisos tomados exponen a la Compañía al riesgo de fluctuación de precios de estas materias
primas. Por su parte CCU Argentina adquiere toda la demanda de malta de productores locales. Esta materia prima
representa aproximadamente el 8% (8% en 2023 y 6% en 2022) del costo directo del Segmento de operación Chile.
Al 31 de diciembre de 2024 el costo de las latas representa aproximadamente un 22% del costo directo en el Segmento de
operación Chile (21% en 31 de diciembre de 2023 y 24% en 2022). En el Segmento de operación Negocios Internacionales,
el costo de las latas representa aproximadamente un 35% del costo directo de materias primas al 31 de diciembre de 2024
(32% en 2023 y 37% en 2022).
Concentrados, azúcar y envases plásticos
Las principales materias primas utilizadas en la producción de bebidas no alcohólicas son los concentrados, que se adquieren
principalmente de los licenciatarios, el azúcar y las resinas plásticas en la fabricación de envases plásticos y contenedores.
La Compañía se encuentra expuesta a riesgo de fluctuación en los precios de estas materias primas que representan en su
conjunto aproximadamente un 28% (28% en 2023 y 26% en 2022) del costo directo del Segmento de operación Chile.
La Compañía no realiza actividades de cobertura sobre estas compras de materias primas.
Uvas y vinos
Las principales materias primas utilizadas por la subsidiaria Viña San Pedro Tarapacá S.A. para la producción de vinos, son
uvas cosechadas de producción propia y uvas y vinos adquiridos de terceros en forma de contratos de largo plazo y spot.
Aproximadamente el 34% (34% al 31 de diciembre de 2023 y 27% en 2022) del total del abastecimiento de VSPT durante
los últimos 12 meses, se realizó desde sus propios viñedos, de las cuales un 57% (57% al 31 de diciembre de 2023 y 45%
en 2022) corresponden a uva para el mercado de exportación.
El 66% (66% al 31 de diciembre de 2023 y 73% en 2022) del abastecimiento restante es comprado a productores en
modalidad de contratos de largo plazo y spot. Durante los últimos 12 meses, VSPT compró el 56% (48% al 31 de diciembre
de 2023 y 58% en 2022) de la uva y vino necesario de terceros a través de contratos spot. Adicionalmente, las transacciones
de largo plazo representaron un 10% (17% al 31 de diciembre de 2023 y 15% en 2022) sobre el total del abastecimiento.
Debemos considerar que el vino al 31 de diciembre de 2024 representa el 53% (56% al 31 de diciembre de 2023 y 59% en
2022) del costo directo total, es decir, el abastecimiento comprado a productores a través de contrato spot representa el 30%
del costo directo (27% al 31 de diciembre de 2023 y 34% en 2022).
Análisis de sensibilidad de precios de materias primas
El total del costo directo en el Estado Consolidado de Resultados por Función para el ejercicio terminado al 31 de diciembre
de 2024 asciende a M$ 1.232.870.856 (M$ 1.090.286.882 en 2023 y M$ 1.188.930.623 en 2022). Asumiendo un aumento
(disminución) razonablemente posible en el costo directo de cada segmento de un 8% y manteniendo todas las otras
variables constantes, tales como los tipos de cambio, el aumento/disminución resultaría hipotéticamente en una
pérdida/utilidad antes de impuestos de aproximadamente M$ 65.932.456 (M$ 61.638.324 en 2023 y M$ 62.291.401 en 2022)
para el Segmento de operación Chile, M$ 25.188.226 (M$ 17.294.358 en 2023 y M$23.328.732 en 2022) para el Segmento
de operación Negocios Internacionales y M$ 10.532.781 (M$ 9.926.816 en 2023 y M$ 11.714.298 en 2022) para el Segmento
de operación Vinos.
Riesgo de Crédito
El riesgo de crédito al cual está expuesta la Compañía proviene principalmente de a) las cuentas por cobrar comerciales
mantenidas con clientes minoristas, distribuidores mayoristas y cadenas de supermercados de mercados domésticos;
b) cuentas por cobrar por exportaciones; y c) las inversiones financieras mantenidas con bancos e instituciones financieras,
tales como depósitos a la vista, fondos mutuos, instrumentos adquiridos con compromiso de retroventa e instrumentos
financieros derivados.
 45

[pág. 47]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Mercado Doméstico
El riesgo de crédito relacionado a cuentas por cobrar comerciales de mercados domésticos es administrado por la Gerencia
de Administración de Crédito y Cobranza y es monitoreado por el Comité de Crédito de cada unidad de negocio.
El mercado doméstico se refiere principalmente a saldos por cobrar de operaciones realizadas en Chile y representan un
58% del total de las cuentas por cobrar comerciales (65% al 31 de diciembre de 2023). La Compañía posee una amplia base
de clientes que están sujetos a las políticas, procedimientos y controles establecidos por la Compañía. Los límites de crédito
son establecidos para todos los clientes con base en una calificación interna y su comportamiento de pago. Las cuentas por
cobrar comerciales pendientes de pago son monitoreadas regularmente. Adicionalmente, la Compañía toma seguros de
crédito que cubren el 90% de los saldos de las cuentas por cobrar individualmente significativas, cobertura que al 31 de
diciembre de 2024 alcanza a 83% (83% al 31 de diciembre de 2023) del total de las cuentas por cobrar.
Las cuentas por cobrar comerciales que se encuentran vencidas, corresponden a clientes que presentan moras en promedio
de menos de 24 días (24 días al 31 de diciembre de 2023).
Al 31 de diciembre de 2024, la Compañía tenía aproximadamente 1.800 clientes (1.650 clientes al 31 de diciembre de 2023)
que adeudan más que $ 10 millones cada uno y que en su conjunto representan aproximadamente el 89% (89% al 31 de
diciembre de 2023) del total de cuentas por cobrar comerciales. Hubo 373 clientes (305 clientes al 31 de diciembre de 2023)
con saldos superiores a $ 50 millones que representa aproximadamente un 78% (78% al 31 de diciembre de 2023) del total
de cuentas por cobrar. El 88% (88% al 31 de diciembre de 2023) de estas cuentas por cobrar se encuentran cubiertas por
el seguro de crédito antes mencionado.
La Compañía comercializa sus productos a través de clientes minoristas, mayoristas y cadenas de supermercados, siendo
la calidad crediticia de estos de un 99% (99% al 31 de diciembre de 2023).
Al 31 de diciembre de 2024 la Compañía no ha recibido garantías significativas por parte de sus clientes.
La Compañía estima que no son necesarias provisiones de riesgo de crédito adicionales a las provisiones individuales y
colectivas para pérdidas por deterioro determinadas al 31 de diciembre de 2024, que ascienden M$ 7.785.695 (M$ 7.751.305
al 31 de diciembre de 2023), ya que, como se menciona anteriormente un gran porcentaje de las cuentas por cobrar se
encuentran cubiertas por seguros (Nota 10 - Deudores Comerciales y otras cuentas por cobrar).
Mercado Exportación
El riesgo de crédito relacionado a cuentas por cobrar comerciales de exportación es administrado por la Jefatura de Crédito
y Cobranza y es monitoreado por la Gerencia de Administración y Finanzas. Los saldos por cobrar del mercado exportación
de VSPT representan un 11% del total de las cuentas por cobrar comerciales (10% al 31 de diciembre de 2023). VSPT posee
una amplia base de clientes, en más de ochenta países, que están sujetos a las políticas, procedimientos y controles
establecidos por VSPT. Adicionalmente, VSPT toma seguros de créditos que cubren el 90% de las cuentas por cobrar
individualmente significativas, cobertura que al 31 de diciembre de 2024 alcanza al 84% (90% al 31 de diciembre de 2023)
del total de las cuentas por cobrar. Las cuentas por cobrar comerciales pendientes de pago son monitoreadas regularmente.
Aparte de los seguros de crédito, al estar diversificado en diversos países aminora el riesgo de crédito.
Al 31 de diciembre de 2024 hay 85 clientes (73 clientes al 31 de diciembre de 2023) que adeudan más de M$ 65.000 cada
uno y que representan el 95% (93% al 31 de diciembre de 2023) del total de las cuentas por cobrar de VSPT.
Las cuentas por cobrar comerciales de exportación de VSPT que se encuentran vencidas, corresponden a clientes que
presentan mora de menos de 43 días promedio (56 días promedio al 31 de diciembre de 2023).
La Compañía estima que no son necesarias provisiones de riesgo de crédito adicionales a las provisiones individuales y
colectivas determinadas al 31 de diciembre de 2024. Ver análisis de vencimientos de cuentas por cobrar y provisión para
pérdidas por deterioro de cuentas por cobrar (Nota 10 - Deudores Comerciales y otras cuentas por cobrar).
 46

[pág. 48]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Inversiones financieras e instrumentos financieros derivados
Las inversiones financieras corresponden a depósitos a plazo, instrumentos financieros adquiridos con compromiso de
retroventa son pactadas a una tasa de interés fija, con vencimientos inferiores a 3 meses y en instituciones financieras en
Chile, por lo que no se encuentran expuestas a riesgos significativos de mercado. Respecto de los instrumentos financieros
derivados, estos se valorizan a su valor razonable y son contratados solo en el mercado en Chile. A partir del año 2018 se
aplican los cambios, exigidos en la enmienda de IFRS 9, en la valorización de los instrumentos financieros derivados
considerando el riesgo de contraparte (CVA y DVA, por sus siglas en inglés). El efecto de CVA/DVA es calculado a partir de
la probabilidad de default de CCU o de la contraparte, según corresponda, considerando una tasa de recuperación de un
40% para cada instrumento derivado. Dicha probabilidad se obtiene a partir del spread de bonos corporativos con igual
calificación para el caso de CCU, mientras que, para la contraparte, se considera la suma entre el Credit Default Swap (CDS)
de Chile y el CDS del banco Citibank en Estados Unidos. Al 31 de diciembre de 2024 el efecto no es significativo.
Riesgo de impuestos
Nuestros negocios están afectos a distintos impuestos en los países donde operamos, incluyendo entre otros, impuestos a
la renta e impuestos específicos sobre bebidas alcohólicas y no alcohólicas. Un aumento en las tasas de dichos impuestos,
o de cualquier otro, o cambios en las regulaciones de los mismos, podrían afectar en forma negativa nuestras ventas y
rentabilidad.
Riesgo de liquidez
La Compañía administra el riesgo de liquidez a nivel consolidado, siendo la principal fuente de liquidez los flujos de efectivo
provenientes de sus actividades operacionales. Adicionalmente, la Compañía tiene la capacidad de emitir instrumentos de
deuda y patrimonio en el mercado de capitales de acuerdo a sus necesidades.
Para administrar la liquidez de corto plazo, la Compañía se basa en los flujos de caja proyectados para un período móvil de
doce meses y mantiene efectivo y equivalentes al efectivo disponible para cumplir sus obligaciones.
Basado en el actual desempeño operacional y su posición de liquidez, la Compañía estima que los flujos de efectivo
provenientes de las actividades operacionales y el efectivo disponible serán suficientes para financiar el capital de trabajo,
las inversiones de capital, los pagos de intereses, los pagos de dividendos y los requerimientos de pago de deudas, por los
próximos 12 meses y el futuro previsible.
A continuación se resumen los vencimientos de los Otros pasivos financieros de la Compañía, basados en los flujos
contractuales no descontados:
 Vencimiento de flujos contratados
 Valor libro (*) Más de 90 Más de 1 Más de 3
 Al 31 de diciembre de 2024 Más de 5
 Hasta 90 días días hasta 1 año hasta 3 años hasta 5 Total
 años
 año años años
 M$ M$ M$ M$ M$ M$ M$
 Otros pasivos financieros no derivados
 Préstamos bancarios 207.904.935 27.660.050 22.865.553 80.529.312 104.271.082 4.918.795 240.244.792
 Obligaciones con el público 1.157.437.074 15.010.590 103.735.572 106.227.041 62.491.195 1.177.559.067 1.465.023.465
 Obligaciones por arrendamientos 49.233.868 3.217.880 7.862.529 13.956.205 8.530.907 26.162.114 59.729.635
 Depósitos recibidos en garantía de envases y
 11.772.459 - 11.772.459 - - - 11.772.459
 contenedores
 Subtotal 1.426.348.336 45.888.520 146.236.113 200.712.558 175.293.184 1.208.639.976 1.776.770.351
 Pasivos financieros derivados
 Instrumentos financieros derivados 652.079 652.079 - - - - 652.079
 Pasivos de cobertura 12.667.177 1.359.777 2.833.330 5.526.492 5.541.056 - 15.260.655
 Subtotal 13.319.256 2.011.856 2.833.330 5.526.492 5.541.056 - 15.912.734
 Total 1.439.667.592 47.900.376 149.069.443 206.239.050 180.834.240 1.208.639.976 1.792.683.085
(*) Ver clasificación del valor libro en corriente y no corriente en Nota 7 - Instrumentos financieros.
 47

[pág. 49]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
 Vencimiento de flujos contratados
 Valor libro (*) Más de 90 Más de 1 Más de 3
 Más de 5
 Al 31 de diciembre de 2023 Hasta 90 días días hasta 1 año hasta 3 años hasta 5 Total
 años
 año años años
 M$ M$ M$ M$ M$ M$ M$
 Otros pasivos financieros no derivados
 Préstamos bancarios 198.569.040 18.446.613 15.884.136 39.244.074 168.351.944 6.773.214 248.699.981
 Obligaciones con el público 1.089.489.347 13.599.586 43.987.484 168.542.146 70.621.982 1.105.895.648 1.402.646.846
 Obligaciones por arrendamientos 41.204.099 2.417.780 6.258.386 12.657.830 6.149.772 26.518.546 54.002.314
 Depósitos recibidos en garantía de envases y
 11.774.922 - 11.774.922 - - - 11.774.922
 contenedores
 Pasivo por contrato de opción (1) 28.554.669 28.636.699 - - - - 28.636.699
 Subtotal 1.369.592.077 63.100.678 77.904.928 220.444.050 245.123.698 1.139.187.408 1.745.760.762
 Pasivos financieros derivados
 Instrumentos financieros derivados 468.541 468.541 - - - - 468.541
 Pasivos de cobertura 12.541.188 1.428.407 1.869.494 5.742.758 5.757.322 - 14.797.981
 Subtotal 13.009.729 1.896.948 1.869.494 5.742.758 5.757.322 - 15.266.522
 Total 1.382.601.806 64.997.626 79.774.422 226.186.808 250.881.020 1.139.187.408 1.761.027.284
(*) Ver clasificación del valor libro en corriente y no corriente en Nota 7 - Instrumentos financieros.
(1) Ver Nota 1 - Información general, letra C), numeral (4).
Crisis sanitarias, pandemias o el brote de enfermedades contagiosas a nivel global o regional
podrían tener un impacto negativo en nuestras operaciones y posición financiera
Una crisis sanitaria, pandemias o el brote de enfermedades a nivel global o regional podrían tener un impacto negativo en
nuestras operaciones y posición financiera. Esto debido a que estas podrían impedir el normal funcionamiento de la
operación de la Compañía, limitar nuestra capacidad de abastecimiento, producción y distribución, y/o generar una
contracción de la demanda de nuestros productos. Un período prolongado de incertidumbre económica podría tener un
impacto material desfavorable en nuestro negocio, en los resultados de las operaciones, en el acceso a financiamiento y en
la situación financiera general.
Cualquier medida restrictiva prolongada establecida para controlar un brote de una enfermedad contagiosa u otro desarrollo
adverso de salud pública en cualquiera de los mercados objetivos puede tener un efecto material y adverso en las
operaciones comerciales. El alcance del impacto de una pandemia en nuestro negocio y situación financiera dependerá en
gran medida de la evolución futura, incluida la duración de la pandemia, el impacto en los mercados financieros y de capitales
y el impacto relacionado en la confianza de los consumidores y las industrias, todo lo cual es muy incierto y no podrían
predecirse con exactitud.
La Compañía cuenta con planes de contingencia para el cuidado de las personas y la continuidad operacional para enfrentar
eventos de este tipo, pero no podemos asegurar que dichos planes sean suficientes para mitigar un impacto material en
nuestros resultados y posición financiera.
 48

[pág. 50]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 6 Información financiera por segmentos de operación
La Compañía ha definido tres segmentos de operación, los cuales se definieron en base a los ingresos de las actividades
de negocio provenientes de las zonas geográficas donde comercializa sus productos: 1.- Chile, 2.- Negocios Internacionales
y 3.- Vinos.
Los tres segmentos de operación señalados anteriormente, son consistentes con la forma en que se gestiona la Compañía.
Estos segmentos de operación contemplan la información financiera separada y los resultados de su operación son revisados
periódicamente por la máxima autoridad en la toma de decisiones de operación de cada segmento para decidir respecto de
la asignación de recursos y a la evaluación de los resultados.
Segmento de operación Productos y Servicios
Chile Cervezas, Bebidas sin alcohol, Licores y UES.
Negocios Internacionales Cervezas, Sidras, Bebidas sin alcohol y Licores en los mercados de Argentina, Uruguay, Paraguay y Bolivia.
Vinos Vinos, principalmente en los mercados de exportación a más de 80 países.
Por último, los gastos e ingresos de Unidades de Apoyo Corporativo (UAC) son presentados dentro de Otros. Adicionalmente
bajo Otros se presenta la eliminación de las transacciones realizadas entre segmentos.
No existe ningún cliente de la Compañía que represente más del 10% de los ingresos.
El detalle de los segmentos de operación se presenta en los cuadros siguientes:
 49

[pág. 51]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
a) Información por segmentos de operación por los ejercicios terminados al 31 de diciembre de 2024 y 2023:
 Chile Negocios Internacionales Vinos Otros Total
 2024 2023 2024 2023 2024 2023 2024 2023 2024 2023
 M$ M$ M$ M$ M$ M$ M$ M$ M$ M$
 Ingresos por ventas 1.769.032.771 1.714.560.272 823.528.981 566.277.644 254.751.837 234.510.659 - - 2.847.313.589 2.515.348.575
 Otros ingresos 21.367.724 22.428.784 25.507.800 19.740.170 7.724.873 5.495.301 2.652.468 2.543.237 57.252.865 50.207.492
 Ingresos por venta entre segmentos 38.843.163 21.982.179 1.081.496 466.547 20.161.213 12.819.535 (60.085.872) (35.268.261) - -
 Total ingresos 1.829.243.658 1.758.971.235 850.118.277 586.484.361 282.637.923 252.825.495 (57.433.404) (32.725.024) 2.904.566.454 2.565.556.067
 % de cambio año anterior 4,0 - 45,0 - 11,8 - - - 13,2 -
 Costo de venta (1.018.348.069) (953.938.348) (440.460.850) (285.512.340) (170.264.143) (156.502.790) 38.115.285 17.341.512 (1.590.957.777) (1.378.611.966)
 como % del total de ingresos 55,7 54,2 51,8 48,7 60,2 61,9 - - 54,8 53,7
 Margen bruto 810.895.589 805.032.887 409.657.427 300.972.021 112.373.780 96.322.705 (19.318.119) (15.383.512) 1.313.608.677 1.186.944.101
 como % del total de ingresos 44,3 45,8 48,2 51,3 39,8 38,1 - - 45,2 46,3
 MSD&A (1) (608.537.795) (601.496.981) (381.386.158) (243.405.220) (84.387.899) (77.362.794) (12.120.538) (14.007.196) (1.086.432.390) (936.272.191)
 como % del total de ingresos 33,3 34,2 44,9 41,5 29,9 30,6 - - 37,4 36,5
 Otros ingresos (gastos) de operación 3.048.305 1.049.865 (1.485.507) (13.487) 1.169.235 1.058.998 32.793.570 515.889 35.525.603 2.611.265
 Resultado operacional ajustado (2) 205.406.099 204.585.771 26.785.762 57.553.314 29.155.116 20.018.909 1.354.913 (28.874.819) 262.701.890 253.283.175
 % de cambio año anterior 0,4 - (53,5) - 45,6 - - - 3,7 -
 como % del total de ingresos 11,2 11,6 3,2 9,8 10,3 7,9 - - 9,0 9,9
 Gastos financieros, netos - - - - - - - - (59.063.225) (37.620.556)
 Participación en utilidad (pérdida) de asociadas y negocios
 - - - - - - - - (9.494.703) (19.217.758)
 conjuntos contabilizados por el método de la participación
 Ganancias (pérdidas) de cambio en moneda extranjera - - - - - - - - (17.797.269) (65.944.570)
 Resultado por unidades de reajuste - - - - - - - - (10.722.033) (14.025.895)
 Otras ganancias (pérdidas) - - - - - - - - (94.937) (13.316.208)
 Utilidad antes de impuesto 165.529.723 103.158.188
 Impuestos a las ganancias 11.015.074 15.267.255
 Utilidad del ejercicio (4) 176.544.797 118.425.443
 Participaciones no controladoras 15.600.659 12.772.715
 Utilidad de propietarios de la controladora 160.944.138 105.652.728
 Depreciación y amortización 84.673.402 78.823.699 51.659.761 28.010.403 12.673.960 12.165.441 4.227.101 7.119.655 153.234.224 126.119.198
 ROADA (3) 290.079.501 283.409.470 78.445.523 85.563.717 41.829.076 32.184.350 5.582.014 (21.755.164) 415.936.114 379.402.373
 % de cambio año anterior 2,4 - (8,3) - 30,0 - - - 9,6 -
 como % del total de ingresos 15,9 16,1 9,2 14,6 14,8 12,7 - - 14,3 14,8
(1) MSD&A. Se refiere a la sigla en inglés para gastos de comercialización, distribución y administración.
(2) Resultado operacional ajustado (para propósitos de la Administración, lo hemos definido como la Utilidad antes de Gastos Financieros netos, Utilidad (pérdida) de negocios conjuntos y asociadas por el método de la participación,
 Ganancias (pérdidas) de cambio en moneda extranjera, Resultado por unidades de reajuste, Otras ganancias (pérdidas) e Impuestos a las ganancias).
(3) ROADA, del inglés “Operating Result Before Depreciation and Amortization”. Para propósitos de la Administración, el ROADA se define como el Resultado operacional ajustado más Depreciación y Amortización.
(4) La venta de porción de terreno, ubicado en la comuna de Quilicura, Región Metropolitana, realizada con fecha 3 de abril de 2024, según se describe en Nota 14 - Activos no corrientes mantenidos para la venta, letra a),
 generó sobre los resultados consolidados a diciembre de 2024 un incremento en el ROADA por M$ 28.668.933 y un efecto en Utilidad neta por M$ 20.928.321.
 50

[pág. 52]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
b) Información por segmentos de operación por los ejercicios terminados al 31 de diciembre de 2023 y 2022:
 Chile Negocios Internacionales Vinos Otros Total
 2023 2022 2023 2022 2023 2022 2023 2022 2023 2022
 M$ M$ M$ M$ M$ M$ M$ M$ M$ M$
 Ingresos por ventas 1.714.560.272 1.627.114.439 566.277.644 761.302.617 234.510.659 268.794.991 - - 2.515.348.575 2.657.212.047
 Otros ingresos 22.428.784 25.681.177 19.740.170 19.374.495 5.495.301 6.840.932 2.543.237 2.326.297 50.207.492 54.222.901
 Ingresos por venta entre segmentos 21.982.179 20.553.741 466.547 1.886.239 12.819.535 20.713.970 (35.268.261) (43.153.950) - -
 Total ingresos 1.758.971.235 1.673.349.357 586.484.361 782.563.351 252.825.495 296.349.893 (32.725.024) (40.827.653) 2.565.556.067 2.711.434.948
 % de cambio año anterior 5,1 - (25,1) - (14,7) - - - (5,4) -
 Costo de venta (953.938.348) (972.143.151) (285.512.340) (389.025.772) (156.502.790) (183.138.062) 17.341.512 29.381.676 (1.378.611.966) (1.514.925.309)
 como % del total de ingresos 54,2 58,1 48,7 49,7 61,9 61,8 - - 53,7 55,9
 Margen bruto 805.032.887 701.206.206 300.972.021 393.537.579 96.322.705 113.211.831 (15.383.512) (11.445.977) 1.186.944.101 1.196.509.639
 como % del total de ingresos 45,8 41,9 51,3 50,3 38,1 38,2 - - 46,3 44,1
 MSD&A (1) (601.496.981) (544.219.910) (243.405.220) (332.194.128) (77.362.794) (75.131.811) (14.007.196) (16.377.702) (936.272.191) (967.923.551)
 como % del total de ingresos 34,2 32,5 41,5 42,4 30,6 25,4 - - 36,5 35,7
 Otros ingresos (gastos) de operación 1.049.865 (233.217) (13.487) 1.569.929 1.058.998 966.449 515.889 541.907 2.611.265 2.845.068
 Resultado operacional ajustado (2) 204.585.771 156.753.079 57.553.314 62.913.380 20.018.909 39.046.469 (28.874.819) (27.281.772) 253.283.175 231.431.156
 % de cambio año anterior 30,5 - (8,5) - (48,7) - - - 9,4 -
 como % del total de ingresos 11,6 9,4 9,8 8,0 7,9 13,2 - - 9,9 8,5
 Gastos financieros, netos - - - - - - - - (37.620.556) (53.060.337)
 Participación en utilidad (pérdida) de asociadas y negocios - - - - - - - - (19.217.758) (10.978.068)
 conjuntos contabilizados por el método de la participación
 Ganancias (pérdidas) de cambio en moneda extranjera - - - - - - - - (65.944.570) (20.173.381)
 Resultado por unidades de reajuste - - - - - - - - (14.025.895) 1.198.565
 Otras ganancias (pérdidas) - - - - - - - - (13.316.208) (12.669.540)
 Utilidad antes de impuesto 103.158.188 135.748.395
 Impuestos a las ganancias 15.267.255 (263.943)
 Utilidad del ejercicio 118.425.443 135.484.452
 Participaciones no controladoras 12.772.715 17.316.101
 Utilidad de propietarios de la controladora 105.652.728 118.168.351
 Depreciación y amortización 78.823.699 70.252.736 28.010.403 38.909.547 12.165.441 12.328.271 7.119.655 5.006.939 126.119.198 126.497.493
 ROADA (3) 283.409.470 227.005.815 85.563.717 101.822.927 32.184.350 51.374.740 (21.755.164) (22.274.833) 379.402.373 357.928.649
 % de cambio año anterior 24,8 - (16,0) - (37,4) - - - 6,0 -
 como % del total de ingresos 16,1 13,6 14,6 13,0 12,7 17,3 - - 14,8 13,2
(1) MSD&A. Se refiere a la sigla en inglés para gastos de comercialización, distribución y administración.
(2) Resultado operacional ajustado (para propósitos de la Administración, lo hemos definido como la Utilidad antes de Gastos Financieros netos, Utilidad (pérdida) de negocios conjuntos y asociadas por el método de la participación,
 Ganancias (pérdidas) de cambio en moneda extranjera, Resultado por unidades de reajuste, Otras ganancias (pérdidas) e Impuestos a las ganancias).
(3) ROADA, del inglés “Operating Result Before Depreciation and Amortization”. Para propósitos de la Administración, el ROADA se define como el Resultado operacional ajustado más Depreciación y Amortización.
 51

[pág. 53]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Información de ventas por ubicación geográfica:
 Por los ejercicios terminados al 31 de diciembre de
 Ingresos por ventas netas por ubicación geográfica
 2024 2023 2022
 M$ M$ M$
 Chile (1) 2.048.580.027 1.960.179.879 1.896.472.434
 Argentina (2) 696.005.518 479.815.516 700.321.546
 Uruguay 36.576.723 34.750.501 28.961.604
 Paraguay 92.497.797 70.348.122 65.639.419
 Bolivia 30.906.389 20.462.049 20.039.945
 Países extranjeros 855.986.427 605.376.188 814.962.514
 Total 2.904.566.454 2.565.556.067 2.711.434.948
(1) Se incluyen ingresos por ventas netas correspondientes a las Unidades de Apoyo Corporativos y eliminaciones entre ubicaciones geográficas.
 Adicionalmente se incluyen ingresos por ventas netas realizadas por el Segmento de Operación Vinos.
(2) Se incluyen los ingresos por venta realizados por la subsidiaria Finca La Celia S.A. y Los Huemules S.R.L. que se presentan bajo el Segmento
 de Operación Vinos y Segmento de Operación Chile, respectivamente.
Información de ventas por clientes:
 Por los ejercicios terminados al 31 de diciembre de
 Ventas netas
 2024 2023 2022
 M$ M$ M$
 Clientes domésticos 2.770.814.520 2.448.913.805 2.559.606.624
 Clientes exportación 133.751.934 116.642.262 151.828.324
 Total 2.904.566.454 2.565.556.067 2.711.434.948
Información de ventas por categoría de producto:
 Por los ejercicios terminados al 31 de diciembre de
 Ingresos por ventas por categoría
 2024 2023 2022
 M$ M$ M$
 Productos alcohólicos 1.885.902.502 1.618.117.846 1.818.810.903
 Productos no alcohólicos 961.411.087 897.230.729 838.401.144
 Otros (1) 57.252.865 50.207.492 54.222.901
 Total 2.904.566.454 2.565.556.067 2.711.434.948
(1) Otros se compone principalmente de las ventas de subproductos y botellas de envasado incluyendo, pallets y vasos.
Depreciación y amortización relacionada a los segmentos de operación:
 Por los ejercicios terminados al 31 de diciembre de
 Depreciaciones y amortizaciones
 2024 2023 2022
 M$ M$ M$
 Segmento de operación Chile 84.673.402 78.823.699 70.252.736
 Segmento de operación Negocios Internacionales 51.659.761 28.010.403 38.909.547
 Segmento de operación Vinos 12.673.960 12.165.441 12.328.271
 Otros (1) 4.227.101 7.119.655 5.006.939
 Total 153.234.224 126.119.198 126.497.493
(1) En Otros se incluyen las depreciaciones y amortizaciones correspondientes a las Unidades de Apoyo Corporativo.
 52

[pág. 54]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Flujos de efectivos por segmentos de operación:
 Por los ejercicios terminados al 31 de diciembre de
 Flujos de efectivo por Segmentos de operación
 2024 2023 2022
 M$ M$ M$
 Flujos de Efectivo Procedentes de (Utilizados en) Actividades de operación 287.516.727 294.097.407 45.937.153
 Segmento de operación Chile 151.388.387 131.525.546 16.363.598
 Segmento de operación Negocios Internacionales 59.970.855 69.414.222 68.638.330
 Segmento de operación Vinos 40.445.090 21.783.654 6.000.923
 Otros (1) 35.712.395 71.373.985 (45.065.698)
 Flujos de Efectivo Procedentes de (Utilizados en) Actividades de inversión (118.294.251) (137.231.817) (236.456.796)
 Segmento de operación Chile (89.738.925) (60.441.964) (144.848.367)
 Segmento de operación Negocios Internacionales (50.729.308) (38.973.597) (67.910.992)
 Segmento de operación Vinos (11.656.348) (11.310.213) (13.030.601)
 Otros (1) 33.830.330 (26.506.043) (10.666.836)
 Flujos de Efectivo Procedentes de (Utilizados en) Actividades de financiación (125.035.774) (118.036.175) 537.101.943
 Segmento de operación Chile (38.133.807) (27.109.286) 45.534.885
 Segmento de operación Negocios Internacionales 5.058.733 1.426.434 3.751.919
 Segmento de operación Vinos (26.326.863) (5.351.845) (30.597.389)
 Otros (1) (65.633.837) (87.001.478) 518.412.528
(1) En Otros se incluyen las Unidades de Apoyo Corporativo.
Inversiones de capital por segmentos de operación:
 Por los ejercicios terminados al 31 de diciembre de
 Inversiones de capital (adiciones de Propiedad, planta y equipos e Intangibles distintos de la
 plusvalía)
 2024 2023 2022
 M$ M$ M$
 Segmento de operación Chile 90.611.005 80.678.753 146.703.164
 Segmento de operación Negocios Internacionales 52.832.489 36.284.427 42.064.662
 Segmento de operación Vinos 11.711.984 11.600.973 13.869.824
 Otros (1) 4.930.706 883.687 965.840
 Total 160.086.184 129.447.840 203.603.490
(1) En Otros se incluyen las inversiones de capital correspondientes a las Unidades de Apoyo Corporativo.
Activos por segmentos de operación:
 Al 31 de Al 31 de
 diciembre de diciembre de
 Activos por segmentos 2024 2023
 M$ M$
 Segmento de operación Chile 1.801.212.657 1.750.524.550
 Segmento de operación Negocios Internacionales 987.649.086 541.973.292
 Segmento de operación Vinos 459.435.444 433.443.907
 Otros (1) 741.419.803 698.004.531
 Total 3.989.716.990 3.423.946.280
(1) En Otros se incluyen los activos correspondientes a las Unidades de Apoyo Corporativo.
 53

[pág. 55]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Activos por ubicación geográfica:
 Al 31 de Al 31 de
 diciembre de diciembre de
 Activos por ubicación geográfica 2024 2023
 M$ M$
 Chile (1) 2.940.871.838 2.847.015.037
 Argentina (2) 900.201.584 465.498.008
 Uruguay 41.006.180 35.961.224
 Paraguay 56.257.348 32.405.738
 Bolivia 47.985.109 40.639.592
 Otros (3) 3.394.931 2.426.681
 Total 3.989.716.990 3.423.946.280
(1) Se incluyen activos correspondientes a las Unidades de Apoyo Corporativo, eliminaciones entre ubicaciones geográficas e inversiones en
 asociadas y negocios conjuntos. Adicionalmente en Chile se considera parte del Segmento de Operación Vinos que excluye a su subsidiaria de
 Argentina Finca La Celia S.A.
(2) Se incluyen los activos de las subsidiarias Finca La Celia S.A. y Los Huemules S.R.L. que se presentan bajo el Segmento de Operación Vinos y
 Segmento de Operación Chile, respectivamente.
(3) Se incluyen los activos de las subsidiarias VSPT US LLC, VSPT UK Ltd. y VSPT Winegroup (Shanghai) Limited.
Pasivos por segmentos de operación:
 Al 31 de Al 31 de
 diciembre de diciembre de
 Pasivos por segmentos 2024 2023
 M$ M$
 Segmento de operación Chile 776.980.472 703.705.503
 Segmento de operación Negocios Internacionales 456.260.455 265.663.942
 Segmento de operación Vinos 165.011.985 161.313.082
 Otros (1) 918.948.768 955.881.172
 Total 2.317.201.680 2.086.563.699
(1) En Otros se incluye los pasivos correspondientes a las Unidades de Apoyo Corporativo.
 54

[pág. 56]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Información adicional de los Segmentos de operación
A continuación, se presenta una conciliación de nuestra Utilidad (pérdida) del ejercicio, la principal medida de comparación
IFRS con el Resultado operacional ajustado por los períodos al 31 de diciembre de 2024, 2023 y 2022:
 Por los ejercicios terminados al 31 de diciembre de
 2024 2023 2022
 M$ M$ M$
Utilidad (pérdida) del ejercicio 176.544.797 118.425.443 135.484.452
Suma (resta):
Otras ganancias (pérdidas) 94.937 13.316.208 12.669.540
Ingresos financieros (38.102.053) (39.402.492) (22.870.538)
Costos financieros 97.165.278 77.023.048 75.930.875
Participación en utilidad (pérdida) de asociadas y negocios conjuntos contabilizados por el método de
 9.494.703 19.217.758 10.978.068
la participación
Ganancias (pérdidas) de cambio en moneda extranjera 17.797.269 65.944.570 20.173.381
Resultado por unidades de reajuste 10.722.033 14.025.895 (1.198.565)
Impuestos a las ganancias (11.015.074) (15.267.255) 263.943
Resultado operacional ajustado 262.701.890 253.283.175 231.431.156
Depreciaciones y amortizaciones 153.234.224 126.119.198 126.497.493
ROADA 415.936.114 379.402.373 357.928.649
A continuación, se presenta una conciliación de los importes consolidados presentados como MSD&A:
 Por los ejercicios terminados al 31 de diciembre de
 2024 2023 2022
 M$ M$ M$
Estado consolidado de resultados
Costos de distribución (536.420.140) (470.120.810) (504.184.248)
Gastos de administración (214.914.189) (197.256.571) (187.421.796)
Otros gastos, por función (339.783.068) (270.703.334) (278.757.105)
Otros gastos incluidos en "Otros gastos, por función" 4.685.903 1.808.524 2.439.598
Total MSD&A (1.086.431.494) (936.272.191) (967.923.551)
 55

[pág. 57]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 7 Instrumentos financieros
Categorías de instrumentos financieros
A continuación, se presentan los valores libros de cada categoría de instrumentos financieros al cierre de cada ejercicio:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Corriente No corriente Corriente No corriente
 M$ M$ M$ M$
 Instrumentos financieros derivados 3.844.406 - 282.032 -
 Valores negociables e Inversiones en otras sociedades 822.287 - 3.314.469 -
 Activos de cobertura 7.232.588 30.060.601 3.844.149 29.981.745
 Total otros activos financieros 11.899.281 30.060.601 7.440.650 29.981.745
 Deudores comerciales y otras cuentas por cobrar 506.711.173 5.966.414 446.486.753 3.313.742
 Cuentas por cobrar a entidades relacionadas 15.501.990 844.344 9.040.528 42.506
 Total préstamos concedidos y cuentas por cobrar 522.213.163 6.810.758 455.527.281 3.356.248
 Subtotal activos financieros 534.112.444 36.871.359 462.967.931 33.337.993
 Efectivo y equivalentes al efectivo 707.122.815 - 618.154.016 -
 Total activos financieros 1.241.235.259 36.871.359 1.081.121.947 33.337.993
 Préstamos bancarios 41.257.611 166.647.324 24.494.870 174.074.170
 Obligaciones con el público 98.433.154 1.059.003.920 38.650.859 1.050.838.488
 Depósitos recibidos en garantía de envases y contenedores 11.772.459 - 11.774.922 -
 Pasivo por contrato de opción (1) - - 28.554.669 -
 Total pasivos financieros medidos al costo amortizado 151.463.224 1.225.651.244 103.475.320 1.224.912.658
 Instrumentos financieros derivados 652.079 - 468.541 -
 Pasivos de cobertura 4.086.699 8.580.478 3.207.739 9.333.449
 Total pasivos financieros medidos al valor razonable 4.738.778 8.580.478 3.676.280 9.333.449
 Total otros pasivos financieros (*) 156.202.002 1.234.231.722 107.151.600 1.234.246.107
 Obligaciones por arrendamientos 9.451.551 39.782.317 7.142.360 34.061.739
 Total pasivos por arrendamientos (**) 9.451.551 39.782.317 7.142.360 34.061.739
 Cuentas por pagar comerciales y otras cuentas por pagar 514.887.185 45.275 434.974.163 88.596
 Cuentas por pagar a entidades relacionadas 36.417.518 - 55.140.630 536.083
 Total obligaciones comerciales y otras cuentas por pagar 551.304.703 45.275 490.114.793 624.679
 Total pasivos financieros 716.958.256 1.274.059.314 604.408.753 1.268.932.525
(1) Ver Nota 1 - Información general, letra C), numeral (4).
(*) Ver Nota 21 - Otros pasivos financieros.
(**) Ver Nota 22 - Arrendamientos.
 56

[pág. 58]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Valor razonable de instrumentos financieros
Los siguientes cuadros presentan los valores razonables, basado en las categorías de instrumentos financieros, comparados
con el valor libro incluidos en el Estado Consolidado de Situación Financiera:
a) Composición activos y pasivos financieros
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Valor libro Valor razonable Valor libro Valor razonable
 M$ M$ M$ M$
 Instrumentos financieros derivados 3.844.406 3.844.406 282.032 282.032
 Valores negociables e Inversiones en otras sociedades 822.287 822.287 3.314.469 3.314.469
 Activos de cobertura 37.293.189 37.293.189 33.825.894 33.825.894
 Total otros activos financieros 41.959.882 41.959.882 37.422.395 37.422.395
 Deudores comerciales y otras cuentas por cobrar 512.677.587 512.677.587 449.800.495 449.800.495
 Cuentas por cobrar a entidades relacionadas 16.346.334 16.346.334 9.083.034 9.083.034
 Total préstamos concedidos y cuentas por cobrar 529.023.921 529.023.921 458.883.529 458.883.529
 Subtotal activos financieros 570.983.803 570.983.803 496.305.924 496.305.924
 Efectivo y equivalentes al efectivo 707.122.815 707.122.815 618.154.016 618.154.016
 Total activos financieros 1.278.106.618 1.278.106.618 1.114.459.940 1.114.459.940
 Préstamos bancarios 207.904.935 215.234.323 198.569.040 202.837.636
 Obligaciones con el público 1.157.437.074 1.065.681.949 1.089.489.347 963.749.615
 Depósitos recibidos en garantía de envases y contenedores 11.772.459 11.772.459 11.774.922 11.774.922
 Pasivo por contrato de opción (1) - - 28.554.669 28.554.669
 Total pasivos financieros medidos al costo amortizado 1.377.114.468 1.292.688.731 1.328.387.978 1.206.916.842
 Instrumentos financieros derivados 652.079 652.079 468.541 468.541
 Pasivos de cobertura 12.667.177 12.667.177 12.541.188 12.541.188
 Total pasivos financieros medidos al valor razonable 13.319.256 13.319.256 13.009.729 13.009.729
 Total otros pasivos financieros (*) 1.390.433.724 1.306.007.987 1.341.397.707 1.219.926.571
 Obligaciones por arrendamientos 49.233.868 49.233.868 41.204.099 41.204.099
 Total pasivos por arrendamientos (**) 49.233.868 49.233.868 41.204.099 41.204.099
 Cuentas por pagar comerciales y otras cuentas por pagar 514.932.460 514.932.460 435.062.759 435.062.759
 Cuentas por pagar a entidades relacionadas 36.417.518 36.417.518 55.676.713 55.676.713
 Total obligaciones comerciales y otras cuentas por pagar 551.349.978 551.349.978 490.739.472 490.739.472
 Total pasivos financieros 1.991.017.570 1.906.591.833 1.873.341.278 1.751.870.142
(1) Ver Nota 1 - Información general, letra C), numeral (4).
(*) Ver Nota 21 - Otros pasivos financieros.
(**) Ver Nota 22 - Arrendamientos.
El valor libro del efectivo y equivalentes al efectivo, otros activos financieros, pasivos financieros derivados, contrato por
opción y obligaciones por arrendamiento se aproxima al valor razonable debido a la naturaleza de corto plazo de estos
instrumentos o bien por su metodología de valorización, y para préstamos concedidos y cuentas por cobrar, debido al hecho
que cualquier pérdida por recuperabilidad ya se encuentra reflejada en las provisiones de pérdidas por deterioro.
El valor razonable de activos y pasivos financieros no derivados, sin cotización en mercados activos, es estimado mediante
el uso de flujos de caja descontados calculados sobre variables de mercados observables a la fecha de los Estados
Financieros. El valor razonable de los instrumentos derivados es estimado mediante el descuento de los flujos de caja futuros,
determinados sobre información observable en el mercado o sobre variables y precios obtenidos de terceras partes.
El valor razonable de los préstamos bancarios y obligaciones con el público tienen jerarquía de Nivel 2. El pasivo financiero
por Contrato de Opción, se valoriza en el momento inicial y posteriormente, utilizando inputs de nivel 3 mediante la
determinación del valor razonable del precio de mercado para el ejercicio de opción por las acciones representativas del
44,99%, descontado al valor presente aplicando la tasa de riesgo de la Compañía.
 57

[pág. 59]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
b) Instrumentos financieros por categoría:
 Efectivo y
 equivalentes al Valor razonable
 Valor razonable
 efectivo y con cambio en
 con cambio en Total
 Al 31 de diciembre de 2024 préstamos y resultados
 resultado
 cuentas por integrales
 cobrar
 M$ M$ M$ M$
Activos financieros
Instrumentos financieros derivados 3.844.406 - - 3.844.406
Valores negociables e Inversiones en otras sociedades 822.287 - - 822.287
Activos de cobertura - - 37.293.189 37.293.189
Total otros activos financieros 4.666.693 - 37.293.189 41.959.882
Efectivo y equivalentes al efectivo - 707.122.815 - 707.122.815
Deudores comerciales y otras cuentas por cobrar - 512.677.587 - 512.677.587
Cuentas por cobrar a entidades relacionadas - 16.346.334 - 16.346.334
Total activos financieros 4.666.693 1.236.146.736 37.293.189 1.278.106.618
 Valor razonable Pasivos
 Valor razonable
 con cambio en financieros
 con cambio en Total
 Al 31 de diciembre de 2024 resultados medidos al costo
 resultado
 integrales amortizado
 M$ M$ M$ M$
Pasivos financieros
Préstamos bancarios - - 207.904.935 207.904.935
Obligaciones con el público - - 1.157.437.074 1.157.437.074
Depósitos recibidos en garantía de envases y contenedores - - 11.772.459 11.772.459
Instrumentos financieros derivados 652.079 - - 652.079
Pasivos de cobertura - 12.667.177 - 12.667.177
Total Otros pasivos financieros 652.079 12.667.177 1.377.114.468 1.390.433.724
Obligaciones por arrendamientos - - 49.233.868 49.233.868
Cuentas por pagar comerciales y otras cuentas por pagar - - 514.932.460 514.932.460
Cuentas por pagar a entidades relacionadas - - 36.417.518 36.417.518
Total pasivos financieros 652.079 12.667.177 1.977.698.314 1.991.017.570
 58

[pág. 60]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
 Efectivo y
 equivalentes al Valor razonable
 Valor razonable
 efectivo y con cambio en
 con cambio en Total
 Al 31 de diciembre de 2023 préstamos y resultados
 resultado
 cuentas por integrales
 cobrar
 M$ M$ M$ M$
Activos financieros
Instrumentos financieros derivados 282.032 - - 282.032
Valores negociables e Inversiones en otras sociedades 3.314.469 - - 3.314.469
Activos de cobertura - - 33.825.894 33.825.894
Total otros activos financieros 3.596.501 - 33.825.894 37.422.395
Efectivo y equivalentes al efectivo - 618.154.016 - 618.154.016
Deudores comerciales y otras cuentas por cobrar - 449.800.495 - 449.800.495
Cuentas por cobrar a entidades relacionadas - 9.083.034 - 9.083.034
Total activos financieros 3.596.501 1.077.037.545 33.825.894 1.114.459.940
 Valor razonable Pasivos
 Valor razonable
 con cambio en financieros
 con cambio en Total
 Al 31 de diciembre de 2023 resultados medidos al costo
 resultado
 integrales amortizado
 M$ M$ M$ M$
Pasivos financieros
Préstamos bancarios - - 198.569.040 198.569.040
Obligaciones con el público - - 1.089.489.347 1.089.489.347
Depósitos recibidos en garantía de envases y contenedores - - 11.774.922 11.774.922
Instrumentos financieros derivados 468.541 - - 468.541
Pasivos de cobertura - 12.541.188 - 12.541.188
Pasivo por contrato de opción - - 28.554.669 28.554.669
Total Otros pasivos financieros 468.541 12.541.188 1.328.387.978 1.341.397.707
Obligaciones por arrendamientos - - 41.204.099 41.204.099
Cuentas por pagar comerciales y otras cuentas por pagar - - 435.062.759 435.062.759
Cuentas por pagar a entidades relacionadas - - 55.676.713 55.676.713
Total pasivos financieros 468.541 12.541.188 1.860.331.549 1.873.341.278
 59

[pág. 61]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Instrumentos derivados
El detalle de los vencimientos, el número de contratos derivados, los valores razonables y la clasificación de estos
instrumentos derivados por tipo de contrato al cierre de cada ejercicio, es el siguiente:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Número Monto Activo Pasivo Número Monto Activo Pasivo
 contratos nominal contratos nominal
 M$ M$ M$ M$
Cross currency swaps UF/CLP 2 3.500 36.218.088 11.237.316 2 4.625 32.586.117 12.129.230
Menos de 1 año - - 6.157.487 2.656.838 - - 3.844.149 2.795.781
entre 1 y 5 años 2 3.500 11.634.471 8.580.478 2 4.625 15.028.294 9.333.449
Más de 5 años - - 18.426.130 - - - 13.713.674 -
Cross currency swaps
 1 296 1.075.101 - 1 296 1.059.999 49.840
UF/EURO
Menos de 1 año 1 296 1.075.101 - - - - 49.840
entre 1 y 5 años - - - - 1 296 1.059.999 -
Cross currency swaps UF/USD 1 479 - 1.429.861 1 479 179.778 362.118
Menos de 1 año 1 479 - 1.429.861 - - - 362.118
entre 1 y 5 años - - - - 1 479 179.778 -
Subtotal derivados de
 4 37.293.189 12.667.177 4 33.825.894 12.541.188
cobertura
Forwards USD 24 156.838 3.783.635 531.473 22 141.145 252.476 408.679
Menos de 1 año 24 156.838 3.783.635 531.473 22 141.145 252.476 408.679
Forwards Euro 9 12.876 26.092 103.889 6 6.275 3.553 34.468
Menos de 1 año 9 12.876 26.092 103.889 6 6.275 3.553 34.468
Forwards CAD 1 1.830 - 7.347 2 2.000 - 25.394
Menos de 1 año 1 1.830 - 7.347 2 2.000 - 25.394
Forwards GBP 7 1.192 33.795 9.370 3 752 26.003 -
Menos de 1 año 7 1.192 33.795 9.370 3 752 26.003 -
Forwards CHF 1 140 884 - - - - -
Menos de 1 año 1 140 884 - - - - -
Subtotal derivados con efectos
 42 3.844.406 652.079 33 282.032 468.541
en resultados
Total instrumentos 46 41.137.595 13.319.256 37 34.107.926 13.009.729
Estos contratos derivados han sido tomados para proteger la exposición al riesgo de tipo de cambio. En el caso de los
forwards la Compañía no cumple con los requerimientos formales de documentación para ser clasificados como instrumentos
de coberturas, y en consecuencia los efectos son registrados en resultados en la cuenta Otras ganancias (pérdidas).
 60

[pág. 62]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Para el caso de los Cross currency Swaps, estos califican como cobertura de flujos de efectivo asociados a obligaciones con
el público, revelados en Nota 21 - Otros pasivos financieros.
Al 31 de diciembre de 2024
 Valor
 razonable
 Derechos Obligaciones del activo
 (pasivo)
 Entidades Naturaleza de los riesgos que están cubiertos Vencimiento
 neto
 Monto Monto Monto
 Moneda Moneda
 M$ M$ M$
Banco Santander
 Flujo por tipo de cambio en obligaciones con el público UF 83.301.885 CLP 76.113.071 7.188.814 15-03-2032
- Chile
Banco Santander
 Flujo por tipo de cambio en obligaciones con el público UF 71.789.705 CLP 53.997.747 17.791.958 01-06-2027
- Chile
Scotiabank Chile Flujo por tipo de cambio en obligaciones con el público UF 18.426.380 USD 19.856.241 (1.429.861) 01-06-2025
Scotiabank Chile Flujo por tipo de cambio en obligaciones con el público UF 11.404.060 EUR 10.328.959 1.075.101 02-06-2025
Al 31 de diciembre de 2023
 Valor
 razonable
 Derechos Obligaciones del activo
 (pasivo)
 Entidades Naturaleza de los riesgos que están cubiertos Vencimiento
 neto
 Monto Monto Monto
 Moneda Moneda
 M$ M$ M$
Banco Santander
 Flujo por tipo de cambio en obligaciones con el público UF 81.405.269 CLP 79.820.831 1.584.438 15-03-2032
- Chile
Banco Santander
 Flujo por tipo de cambio en obligaciones con el público UF 94.104.646 CLP 75.232.197 18.872.449 01-06-2027
- Chile
Scotiabank Chile Flujo por tipo de cambio en obligaciones con el público UF 17.020.211 USD 17.202.551 (182.340) 01-06-2025
Scotiabank Chile Flujo por tipo de cambio en obligaciones con el público UF 10.558.552 EUR 9.548.393 1.010.159 02-06-2025
En el Estado Consolidado de Resultados Integrales, bajo cobertura de flujos de efectivo se ha reconocido al 31 de diciembre
de 2024 un abono de M$ 4.746.744 (cargo de M$ 4.379.170 al 31 de diciembre de 2023 y cargo de M$ 12.415.374 al 31 de
diciembre de 2022) antes de impuestos, correspondiente al valor razonable de los instrumentos.
Jerarquías de valor razonable
Los instrumentos financieros registrados a valor razonable en el Estado Consolidado de Situación Financiera, se clasifican
de la siguiente forma, basado en la forma de obtención de su valor razonable:
Nivel 1 Valor razonable obtenido mediante referencia directa a precios cotizados, sin ajuste alguno.
Nivel 2 Valor razonable obtenido mediante la utilización de modelos de valorización aceptados en el mercado y
 basados en precios, distintos a los indicados en el nivel 1, que son observables directa o indirectamente a
 la fecha de medición (Precios ajustados).
Nivel 3 Valor razonable obtenido mediante modelos desarrollados internamente o metodologías que utilizan
 información que no son observables o muy poco líquidas.
 61

[pág. 63]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Al cierre de cada ejercicio la Compañía presenta la siguiente estructura de obtención del valor razonable de sus instrumentos
financieros registrados a valor razonable en el Estado Consolidado de Situación Financiera:
 Valor razonable Jerarquía Valor Razonable
 Al 31 de diciembre de 2024 registrado Nivel 1 Nivel 2 Nivel 3
 M$ M$ M$ M$
Instrumentos financieros derivados 3.844.406 - 3.844.406 -
Valores negociables e Inversiones en otras sociedades 822.287 822.287 - -
Activos de cobertura 37.293.189 - 37.293.189 -
Total otros activos financieros 41.959.882 822.287 41.137.595 -
Instrumentos financieros derivados 652.079 - 652.079 -
Pasivo de cobertura 12.667.177 - 12.667.177 -
Total pasivos financieros derivados 13.319.256 - 13.319.256 -
 Valor razonable Jerarquía Valor Razonable
 Al 31 de diciembre de 2023 registrado Nivel 1 Nivel 2 Nivel 3
 M$ M$ M$ M$
Instrumentos financieros derivados 282.032 - 282.032 -
Valores negociables e Inversiones en otras sociedades 3.314.469 3.314.469 - -
Activos de cobertura 33.825.894 - 33.825.894 -
Total otros activos financieros 37.422.395 3.314.469 34.107.926 -
Instrumentos financieros derivados 468.541 - 468.541 -
Pasivo de cobertura 12.541.188 - 12.541.188 -
Total pasivos financieros derivados 13.009.729 - 13.009.729 -
Durante el ejercicio terminado al 31 de diciembre de 2024, la Compañía no ha realizado transferencia de instrumentos entre
las categorías 1 y 2.
Calidad crediticia de activos financieros
La Compañía utiliza dos sistemas de evaluación crediticia para sus clientes: a) los clientes que cuentan con seguro de crédito
son evaluados por los criterios de riesgo externo (informes comerciales, morosidad y protestos que están disponibles en el
mercado local), capacidad de pago y situación patrimonial que exige la Compañía de seguros para poder otorgar cobertura
de crédito; b) el resto de los clientes tiene una evaluación crediticia a través de un modelo de riesgo ABC, el que considera
el riesgo interno (morosidad y protestos), riesgo externo (informes comerciales, morosidad y protestos que están disponible
en el mercado local) y capacidad de pago y situación patrimonial. La tasa de incobrabilidad de los dos últimos años ha sido
poco significativa.
 62

[pág. 64]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 8 Efectivo y equivalentes al efectivo
Los saldos de efectivo y equivalentes al efectivo se componen como sigue:
 Al 31 de Al 31 de Al 31 de
 diciembre de diciembre de diciembre de
 2024 2023 2022
 M$ M$ M$
 Efectivo en caja 358.534 279.521 239.542
 Saldos en bancos 400.213.133 367.146.884 179.097.293
Total efectivo 400.571.667 367.426.405 179.336.835
 Depósitos a plazo 222.861.432 186.368.967 389.303.495
 Instrumentos financieros adquiridos con compromiso de retroventa (pactos) 57.570.583 49.038.418 12.115.866
 Inversiones en cuotas de fondos mutuos 26.119.133 15.320.226 16.325.479
 Inversiones a corto plazo, clasificados como equivalentes al efectivo 83.689.716 64.358.644 28.441.345
Total equivalentes al efectivo 306.551.148 250.727.611 417.744.840
Total 707.122.815 618.154.016 597.081.675
 63

[pág. 65]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
La composición por moneda del efectivo y equivalentes al efectivo al 31 de diciembre de 2024 es la siguiente:
 Dólar Peso Guaraní
 Peso chileno Euro Peso argentino Boliviano Otros Totales
 estadounidense uruguayo paraguayo
 M$ M$ M$ M$ M$ M$ M$ M$ M$
 Efectivo en caja 76.230 778 - 4.246 - - 277.280 - 358.534
 Saldos en bancos 73.236.943 309.986.854 2.520.585 7.291.966 1.864.837 2.795.042 929.088 1.587.818 400.213.133
Total efectivo 73.313.173 309.987.632 2.520.585 7.296.212 1.864.837 2.795.042 1.206.368 1.587.818 400.571.667
 Depósitos a plazo - 222.589.479 - - 271.953 - - - 222.861.432
 Instrumentos financieros adquiridos con compromiso de retroventa (pactos) 57.570.583 - - - - - - - 57.570.583
 Inversiones en cuotas de fondos mutuos 221.200 199.256 - 23.252.691 - 2.445.986 - - 26.119.133
Inversiones a corto plazo, clasificados como equivalentes al efectivo 57.791.783 199.256 - 23.252.691 - 2.445.986 - - 83.689.716
Total equivalentes al efectivo 57.791.783 222.788.735 - 23.252.691 271.953 2.445.986 - - 306.551.148
Totales 131.104.956 532.776.367 2.520.585 30.548.903 2.136.790 5.241.028 1.206.368 1.587.818 707.122.815
La composición por moneda del efectivo y equivalentes al efectivo al 31 de diciembre de 2023 es la siguiente:
 Dólar Peso Guaraní
 Peso chileno Euro Peso argentino Boliviano Otros Totales
 estadounidense uruguayo paraguayo
 M$ M$ M$ M$ M$ M$ M$ M$ M$
 Efectivo en caja 77.058 1.866 - 2.351 - - 198.246 - 279.521
 Saldos en bancos 40.999.695 314.407.436 1.516.762 4.563.501 1.848.902 2.147.017 871.189 792.382 367.146.884
Total efectivo 41.076.753 314.409.302 1.516.762 4.565.852 1.848.902 2.147.017 1.069.435 792.382 367.426.405
 Depósitos a plazo - 185.464.394 - 117.857 786.716 - - - 186.368.967
 Instrumentos financieros adquiridos con compromiso de retroventa (pactos) 49.038.418 - - - - - - - 49.038.418
 Inversiones en cuotas de fondos mutuos 245.651 - - 15.074.575 - - - - 15.320.226
 Inversiones a corto plazo, clasificados como equivalentes al efectivo 49.284.069 - - 15.074.575 - - - - 64.358.644
Total equivalentes al efectivo 49.284.069 185.464.394 - 15.192.432 786.716 - - - 250.727.611
Totales 90.360.822 499.873.696 1.516.762 19.758.284 2.635.618 2.147.017 1.069.435 792.382 618.154.016
 64

[pág. 66]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
La composición por moneda del efectivo y equivalentes al efectivo al 31 de diciembre de 2022 es la siguiente:
 Dólar Peso Peso Guaraní
 Peso chileno Euro Boliviano Otros Totales
 estadounidense argentino uruguayo paraguayo
 M$ M$ M$ M$ M$ M$ M$ M$ M$
 Efectivo en caja 77.160 2.553 - 9.494 - - 150.335 - 239.542
 Saldos en bancos 34.284.961 135.390.795 555.639 2.982.055 1.170.848 2.681.005 532.059 1.499.931 179.097.293
Total efectivo 34.362.121 135.393.348 555.639 2.991.549 1.170.848 2.681.005 682.394 1.499.931 179.336.835
 Depósitos a plazo 1.702.165 387.601.330 - - - - - - 389.303.495
 Instrumentos financieros adquiridos con compromiso de retroventa (pactos) 12.115.866 - - - - - - - 12.115.866
 Inversiones en cuotas de fondos mutuos - - - 16.325.479 - - - - 16.325.479
 Inversiones a corto plazo, clasificados como equivalentes al efectivo 12.115.866 - - 16.325.479 - - - - 28.441.345
Total equivalentes al efectivo 13.818.031 387.601.330 - 16.325.479 - - - - 417.744.840
Totales 48.180.152 522.994.678 555.639 19.317.028 1.170.848 2.681.005 682.394 1.499.931 597.081.675
 65

[pág. 67]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
La composición de los depósitos a plazo es la siguiente:
Al 31 de diciembre de 2024:
 Fecha de Fecha de Monto Tasa de interés
 Entidad financiera Moneda
 colocación vencimiento M$ mensual (%)
Banco Itaú - Uruguay 27-12-2024 03-01-2025 UYU 1.495.089 0,63
Citibank - Uruguay 17-12-2024 18-01-2025 UYU 271.554 0,43
Sumitomo Mitsui Banking Corporation - Estados Unidos 27-12-2024 27-02-2025 USD 169.500.536 0,37
The Bank Of Nova Scotia Toronto - Canadá 29-11-2024 31-01-2025 USD 51.594.253 0,39
Total 222.861.432
Al 31 de diciembre de 2023:
 Fecha de Fecha de Monto Tasa de interés
 Entidad financiera Moneda
 colocación vencimiento M$ mensual (%)
Banco Itaú - Uruguay 28-12-2023 04-01-2024 UYU 449.552 0,64
Banco Supervielle - Argentina 07-12-2023 08-01-2024 ARS 117.857 10,50
Citibank - Uruguay 29-12-2023 02-01-2024 UYU 280.970 0,52
Scotiabank - Uruguay 29-12-2023 29-01-2024 UYU 56.194 0,58
Sumitomo Mitsui Banking Corporation - Estados Unidos 24-11-2023 26-01-2024 USD 141.450.646 0,46
The Bank Of Nova Scotia Toronto - Canadá 08-12-2023 06-03-2024 USD 44.013.748 0,47
Total 186.368.967
Al 31 de diciembre de 2022:
 Fecha de Fecha de Monto Tasa de interés
 Entidad financiera Moneda
 colocación vencimiento M$ mensual (%)
Citibank N.A. - Estados Unidos 19-12-2022 19-01-2023 USD 214.295.932 0,39
Scotia Corredora de Bolsa Chile S.A. 27-12-2022 03-01-2023 CLP 1.702.165 0,96
Sumitomo Mitsui Banking Corporation - Estados Unidos 03-11-2022 03-01-2023 USD 43.316.249 0,35
Sumitomo Mitsui Banking Corporation - Estados Unidos 27-12-2022 26-01-2023 USD 129.989.149 0,37
Total 389.303.495
 66

[pág. 68]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
La composición de los instrumentos financieros adquiridos con compromiso de retroventa (pactos) es la siguiente:
Al 31 de diciembre de 2024:
 Monto Tasa de
 Fecha de Fecha de
 Entidad financiera Activo subyacente (Depósito a plazo) (*) Moneda interés
 colocación vencimiento M$ mensual (%)
 BancoEstado S.A. Corredores de Bolsa - Chile Banco del Estado de Chile 30-12-2024 07-01-2025 CLP 4.083.818 0,45
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Itaú Corpbanca - Chile 30-12-2024 07-01-2025 CLP 4.410.111 0,45
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Santander - Chile 27-12-2024 07-01-2025 CLP 896.018 0,45
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Santander - Chile 27-12-2024 07-01-2025 CLP 4.523 0,45
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Santander - Chile 27-12-2024 07-01-2025 CLP 413.911 0,45
 BancoEstado S.A. Corredores de Bolsa - Chile Scotiabank Chile 27-12-2024 02-01-2025 CLP 1.086.468 0,45
 BancoEstado S.A. Corredores de Bolsa - Chile Scotiabank Chile 27-12-2024 02-01-2025 CLP 14.194 0,45
 BancoEstado S.A. Corredores de Bolsa - Chile Scotiabank Chile 27-12-2024 02-01-2025 CLP 1.220.137 0,45
 BancoEstado S.A. Corredores de Bolsa - Chile Scotiabank Chile 27-12-2024 02-01-2025 CLP 80.644 0,45
 BancoEstado S.A. Corredores de Bolsa - Chile Scotiabank Chile 27-12-2024 07-01-2025 CLP 1.837.442 0,45
 BancoEstado S.A. Corredores de Bolsa - Chile Scotiabank Chile 27-12-2024 07-01-2025 CLP 150.090 0,45
 BancoEstado S.A. Corredores de Bolsa - Chile Scotiabank Chile 30-12-2024 07-01-2025 CLP 7.332 0,45
 BancoEstado S.A. Corredores de Bolsa - Chile Scotiabank Chile 30-12-2024 02-01-2025 CLP 2.949.259 0,45
 BancoEstado S.A. Corredores de Bolsa - Chile Scotiabank Chile 30-12-2024 02-01-2025 CLP 1.184 0,45
 BCI Corredores de Bolsa Chile S.A. Banco Bice - Chile 26-12-2024 02-01-2025 CLP 996.877 0,43
 BCI Corredores de Bolsa Chile S.A. Banco Itaú Corpbanca - Chile 26-12-2024 02-01-2025 CLP 499.111 0,43
 BCI Corredores de Bolsa Chile S.A. Banco Santander - Chile 26-12-2024 02-01-2025 CLP 1.664.112 0,43
 BCI Corredores de Bolsa Chile S.A. Banco Santander - Chile 26-12-2024 02-01-2025 CLP 291.480 0,43
 BCI Corredores de Bolsa Chile S.A. Banco Santander - Chile 26-12-2024 02-01-2025 CLP 235.893 0,43
 BCI Corredores de Bolsa Chile S.A. Banco Santander - Chile 26-12-2024 02-01-2025 CLP 115.219 0,43
 Scotia Corredora de Bolsa Chile Ltda. Banco Bice - Chile 23-12-2024 02-01-2025 CLP 36.685 0,43
 Scotia Corredora de Bolsa Chile Ltda. Banco Bice - Chile 23-12-2024 02-01-2025 CLP 238.387 0,43
 Scotia Corredora de Bolsa Chile Ltda. Banco Bice - Chile 23-12-2024 02-01-2025 CLP 25.272 0,43
 Scotia Corredora de Bolsa Chile Ltda. Banco Bice - Chile 30-12-2024 07-01-2025 CLP 3.854 0,48
 Scotia Corredora de Bolsa Chile Ltda. Banco Bice - Chile 30-12-2024 07-01-2025 CLP 20.224 0,48
 Scotia Corredora de Bolsa Chile Ltda. Banco Bice - Chile 30-12-2024 07-01-2025 CLP 275.970 0,48
 Scotia Corredora de Bolsa Chile Ltda. Banco Central de Chile 30-12-2024 02-01-2025 CLP 2.998.921 0,48
 Scotia Corredora de Bolsa Chile Ltda. Banco Consorcio - Chile 26-12-2024 02-01-2025 CLP 1.200.900 0,45
 Scotia Corredora de Bolsa Chile Ltda. Banco Consorcio - Chile 30-12-2024 07-01-2025 CLP 5.000.800 0,48
 Scotia Corredora de Bolsa Chile Ltda. Banco de Chile 26-12-2024 02-01-2025 CLP 500.375 0,45
 Scotia Corredora de Bolsa Chile Ltda. Banco de Chile 26-12-2024 02-01-2025 CLP 1.494 0,45
 Scotia Corredora de Bolsa Chile Ltda. Banco de Chile 26-12-2024 02-01-2025 CLP 3.501.131 0,45
 Scotia Corredora de Bolsa Chile Ltda. Banco de Chile 30-12-2024 07-01-2025 CLP 8.796.277 0,48
 Scotia Corredora de Bolsa Chile Ltda. Banco de Chile 30-12-2024 07-01-2025 CLP 1.505.371 0,48
 Scotia Corredora de Bolsa Chile Ltda. Banco del Estado de Chile 26-12-2024 02-01-2025 CLP 4.003.000 0,45
 Scotia Corredora de Bolsa Chile Ltda. Banco del Estado de Chile 30-12-2024 02-01-2025 CLP 1.559 0,48
 Scotia Corredora de Bolsa Chile Ltda. Banco del Estado de Chile 30-12-2024 02-01-2025 CLP 1.500.240 0,48
 Scotia Corredora de Bolsa Chile Ltda. Banco Security - Chile 26-12-2024 02-01-2025 CLP 250.323 0,45
 Scotia Corredora de Bolsa Chile Ltda. Banco Security - Chile 26-12-2024 02-01-2025 CLP 305.758 0,45
 Scotia Corredora de Bolsa Chile Ltda. Banco Security - Chile 26-12-2024 02-01-2025 CLP 318.162 0,45
 Scotia Corredora de Bolsa Chile Ltda. Banco Security - Chile 26-12-2024 02-01-2025 CLP 428.029 0,45
 Scotia Corredora de Bolsa Chile Ltda. Banco Security - Chile 26-12-2024 02-01-2025 CLP 699.228 0,45
 Scotia Corredora de Bolsa Chile Ltda. Banco Security - Chile 30-12-2024 07-01-2025 CLP 639.713 0,48
 Scotia Corredora de Bolsa Chile Ltda. Banco Security - Chile 30-12-2024 07-01-2025 CLP 1.838.316 0,48
 Scotia Corredora de Bolsa Chile Ltda. Banco Security - Chile 30-12-2024 07-01-2025 CLP 2.522.771 0,48
 Total 57.570.583
(*) Todos los instrumentos financieros adquiridos con compromiso de retroventa (pactos), corresponden, como activos subyacentes, a depósitos a plazo y
están pactados con una tasa de interés fija.
 67

[pág. 69]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Al 31 de diciembre de 2023:
 Monto Tasa de
 Fecha de Fecha de
 Entidad financiera Activo subyacente (Depósito a plazo) (*) Moneda interés
 colocación vencimiento M$ mensual (%)
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Consorcio - Chile 21-12-2023 04-01-2024 CLP 501.150 0,69
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Consorcio - Chile 29-12-2023 04-01-2024 CLP 499.358 0,70
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Consorcio - Chile 29-12-2023 04-01-2024 CLP 68.791 0,70
 BancoEstado S.A. Corredores de Bolsa - Chile Banco de Chile 21-12-2023 04-01-2024 CLP 44.421 0,69
 BancoEstado S.A. Corredores de Bolsa - Chile Banco de Crédito e Inversiones - Chile 29-12-2023 04-01-2024 CLP 229.595 0,70
 BancoEstado S.A. Corredores de Bolsa - Chile Banco de Crédito e Inversiones - Chile 29-12-2023 04-01-2024 CLP 270.638 0,70
 BancoEstado S.A. Corredores de Bolsa - Chile Banco de Crédito e Inversiones - Chile 21-12-2023 04-01-2024 CLP 1.831.429 0,69
 BancoEstado S.A. Corredores de Bolsa - Chile Banco de Crédito e Inversiones - Chile 29-12-2023 04-01-2024 CLP 96.860 0,70
 BancoEstado S.A. Corredores de Bolsa - Chile Banco de Crédito e Inversiones - Chile 21-12-2023 04-01-2024 CLP 659.321 0,69
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Santander - Chile 21-12-2023 04-01-2024 CLP 1.223.454 0,69
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Itaú Corpbanca - Chile 21-12-2023 04-01-2024 CLP 501.150 0,69
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Santander - Chile 29-12-2023 04-01-2024 CLP 156.239 0,70
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Santander - Chile 29-12-2023 04-01-2024 CLP 88.694 0,70
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Santander - Chile 29-12-2023 04-01-2024 CLP 76.362 0,70
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Santander - Chile 29-12-2023 04-01-2024 CLP 214.256 0,70
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Security - Chile 21-12-2023 04-01-2024 CLP 501.150 0,69
 BancoEstado S.A. Corredores de Bolsa - Chile Scotiabank Chile 28-12-2023 04-01-2024 CLP 800.552 0,69
 BancoEstado S.A. Corredores de Bolsa - Chile Scotiabank Chile 28-12-2023 04-01-2024 CLP 1.501.035 0,69
 BancoEstado S.A. Corredores de Bolsa - Chile Scotiabank Chile 21-12-2023 04-01-2024 CLP 1.503.450 0,69
 BCI Corredores de Bolsa Chile S.A. Banco de Chile 29-12-2023 11-01-2024 CLP 1.979.530 0,70
 BCI Corredores de Bolsa Chile S.A. Banco Itaú Corpbanca - Chile 29-12-2023 11-01-2024 CLP 983.920 0,70
 BCI Corredores de Bolsa Chile S.A. Banco de Chile 28-12-2023 02-01-2024 CLP 1.000.690 0,69
 BCI Corredores de Bolsa Chile S.A. Banco Security - Chile 29-12-2023 11-01-2024 CLP 979.874 0,70
 BCI Corredores de Bolsa Chile S.A. Scotiabank Chile 29-12-2023 11-01-2024 CLP 2.295.554 0,70
 BCI Corredores de Bolsa Chile S.A. Banco Santander - Chile 29-12-2023 11-01-2024 CLP 372.324 0,70
 BCI Corredores de Bolsa Chile S.A. Scotiabank Chile 29-12-2023 11-01-2024 CLP 2.292.952 0,70
 Scotia Corredora de Bolsa Chile S.A. Banco Bice - Chile 28-12-2023 04-01-2024 CLP 1.100.759 0,69
 Scotia Corredora de Bolsa Chile S.A. Banco Consorcio - Chile 29-12-2023 11-01-2024 CLP 700.327 0,70
 Scotia Corredora de Bolsa Chile S.A. Banco de Chile 28-12-2023 02-01-2024 CLP 2.601.795 0,69
 Scotia Corredora de Bolsa Chile S.A. Banco Consorcio - Chile 29-12-2023 11-01-2024 CLP 2.301.073 0,70
 Scotia Corredora de Bolsa Chile S.A. Banco Itaú Corpbanca - Chile 29-12-2023 11-01-2024 CLP 3.001.400 0,70
 Scotia Corredora de Bolsa Chile S.A. Banco de Chile 28-12-2023 04-01-2024 CLP 400.276 0,69
 Scotia Corredora de Bolsa Chile S.A. Banco de Chile 26-12-2023 04-01-2024 CLP 1.501.725 0,69
 Scotia Corredora de Bolsa Chile S.A. Banco de Chile 29-12-2023 11-01-2024 CLP 1.694.812 0,70
 Scotia Corredora de Bolsa Chile S.A. Banco de Chile 29-12-2023 11-01-2024 CLP 1.306.588 0,70
 Scotia Corredora de Bolsa Chile S.A. Banco Santander - Chile 27-12-2023 04-01-2024 CLP 965.912 0,69
 Scotia Corredora de Bolsa Chile S.A. Banco Santander - Chile 27-12-2023 04-01-2024 CLP 135.100 0,69
 Scotia Corredora de Bolsa Chile S.A. Banco de Crédito e Inversiones - Chile 29-12-2023 11-01-2024 CLP 1.965.032 0,70
 Scotia Corredora de Bolsa Chile S.A. Banco de Crédito e Inversiones - Chile 29-12-2023 11-01-2024 CLP 2.737.161 0,70
 Scotia Corredora de Bolsa Chile S.A. Banco Santander - Chile 29-12-2023 11-01-2024 CLP 2.755.387 0,70
 Scotia Corredora de Bolsa Chile S.A. Banco Santander - Chile 29-12-2023 11-01-2024 CLP 2.847.226 0,70
 Scotia Corredora de Bolsa Chile S.A. Banco Security - Chile 29-12-2023 11-01-2024 CLP 350.163 0,70
 Scotia Corredora de Bolsa Chile S.A. Scotiabank Chile 29-12-2023 11-01-2024 CLP 350.163 0,70
 Scotia Corredora de Bolsa Chile S.A. Scotiabank Chile 29-12-2023 02-01-2024 CLP 650.303 0,70
 Scotia Corredora de Bolsa Chile S.A. Scotiabank Chile 29-12-2023 09-01-2024 CLP 1.000.467 0,70
 Total 49.038.418
(*) Todos los instrumentos financieros adquiridos con compromiso de retroventa (pactos), corresponden, como activos subyacentes, a depósitos a plazo y
están pactados con una tasa de interés fija.
 68

[pág. 70]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Al 31 de diciembre de 2022:
 Monto Tasa de
 Fecha de Fecha de
 Entidad financiera Activo subyacente (Depósito a plazo) (*) Moneda interés
 colocación vencimiento M$ mensual (%)
 Banchile Corredores de Bolsa S.A. Banco Itaú Corpbanca - Chile 30-12-2022 03-01-2023 CLP 1.000.300 0,90
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Bice - Chile 22-12-2022 12-01-2023 CLP 802.280 0,95
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Central de Chile 29-12-2022 03-01-2023 CLP 699.139 0,95
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Central de Chile 29-12-2022 05-01-2023 CLP 349.569 0,95
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Central de Chile 27-12-2022 03-01-2023 CLP 1.859.195 0,95
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Consorcio - Chile 27-12-2022 03-01-2023 CLP 143.338 0,95
 BancoEstado S.A. Corredores de Bolsa - Chile Banco de Crédito e Inversiones - Chile 22-12-2022 12-01-2023 CLP 501.425 0,95
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Itaú Corpbanca - Chile 22-12-2022 12-01-2023 CLP 1.486.457 0,95
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Itaú Corpbanca - Chile 22-12-2022 12-01-2023 CLP 519.243 0,95
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Santander - Chile 29-12-2022 03-01-2023 CLP 1.304 0,95
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Santander - Chile 29-12-2022 05-01-2023 CLP 652 0,95
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Security - Chile 27-12-2022 03-01-2023 CLP 426.919 0,95
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Security - Chile 27-12-2022 03-01-2023 CLP 5.447 0,95
 BancoEstado S.A. Corredores de Bolsa - Chile Banco Security - Chile 27-12-2022 03-01-2023 CLP 168.394 0,95
 Scotia Corredora de Bolsa Chile S.A. Banco de Crédito e Inversiones - Chile 30-12-2022 03-01-2023 CLP 797.417 0,96
 Scotia Corredora de Bolsa Chile S.A. Banco Estado de Chile 30-12-2022 03-01-2023 CLP 503.000 0,96
 Scotia Corredora de Bolsa Chile S.A. Banco Estado de Chile 30-12-2022 05-01-2023 CLP 2.500.800 0,96
 Scotia Corredora de Bolsa Chile S.A. Banco Itaú Corpbanca - Chile 22-12-2022 12-01-2023 CLP 350.987 0,94
 Total 12.115.866
A continuación, se presentan los desembolsos efectuados por la adquisición de negocios:
 Por los ejercicios terminados al 31 de
 diciembre de
 2024 2023 2022
 M$ M$ M$
 Desembolsos por adquisición de negocios
 Monto pagado para adquirir participaciones en negocios conjuntos (1) (10.658.097) (7.086.899) (36.465.915)
 Monto pagado por cambios en la propiedad en subsidiarias que no dan lugar a la pérdida de control (2) (32.260.503) (3.205.058) (438.105)
 Monto pagado para obtener el control de subsidiarias (3) (551.585) (2.000.000) -
 Monto cobrado por cambios en la propiedad en subsidiarias que no dan lugar a la pérdida de control (4) 17.112.779 - -
(1) Ver Nota 16 - Inversiones contabilizadas por el método de la participación, numerales (2) y (3).
(2) Ver Nota 1 - Información general, letra C, numeral (4) para el 2024 y 2023 y numeral (13) para el 2024 y 2022.
(3) Ver Nota 15 - Combinaciones de negocios, letra a) y b) para 2024 y a) para 2023.
(4) Ver Nota 15 - Combinaciones de negocios, letra c).
 69

[pág. 71]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 9 Otros activos no financieros
Los saldos de otros activos no financieros se componen como sigue:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Corriente No corriente Corriente No corriente
 M$ M$ M$ M$
 Seguros pagados 3.733.396 91.829 7.023.579 2.605.172
 Publicidad 13.826.543 10.728.679 9.430.148 9.452.969
 Anticipo a proveedores 9.039.012 - 9.860.004 -
 Gastos anticipados 2.609.228 2.671.728 1.736.475 156.307
Total anticipos 29.208.179 13.492.236 28.050.206 12.214.448
 Garantías pagadas 6.898 172.873 - 92.963
 Materiales por consumir 1.074.281 - 754.621 -
 Dividendos por cobrar 854.084 - 869.878 -
 Otros - 9.127 - 3.616
Total otros activos 1.935.263 182.000 1.624.499 96.579
Total 31.143.442 13.674.236 29.674.705 12.311.027
Naturaleza de cada activo no financiero:
a) Seguros pagados: Se incorporan bajo este concepto pagos anuales por pólizas de seguro, los cuales se activan para ser
 amortizados en el período de vigencia del contrato.
b) Publicidad: Corresponde a los contratos de publicidad y promoción relacionados con clientes y proveedores de servicios
 publicitarios que promueven nuestras marcas. Estos contratos son amortizados en el período de vigencia del contrato.
c) Anticipo a proveedores: Corresponde principalmente a servicios, compra de materia prima y agentes de aduana.
d) Gastos anticipados: Servicios pagados por anticipado que dan derecho a prestaciones por un período generalmente de
 12 meses, se van reflejando contra resultado en la medida que se van devengando.
e) Garantías pagadas: Corresponde al pago inicial por el arrendamiento de bienes exigido por el arrendador, con el fin de
 dar seguridad en el cumplimento de las condiciones de contrato pactadas.
f) Materiales por consumir: Refleja las existencias de materiales que corresponden principalmente a insumos de seguridad,
 vestuario o para uso en las oficinas administrativas, como por ejemplo: anteojos, guantes, mascarillas, delantales, etc.
g) Dividendos por cobrar: Dividendos por cobrar a asociadas y negocios conjuntos.
Nota 10 Deudores comerciales y otras cuentas por cobrar
Los saldos de deudores comerciales y otras cuentas por cobrar son los siguientes:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Corriente No corriente Corriente No corriente
 M$ M$ M$ M$
 Segmento de operación Chile 237.369.286 - 230.066.689 -
 Segmento de operación Negocios Internacionales 138.558.576 - 96.340.285 -
 Segmento de operación Vinos 68.720.452 - 61.262.042 -
Total deudores comerciales 444.648.314 - 387.669.016 -
Estimación para pérdidas por deterioro (7.785.695) - (7.751.305) -
Total deudores comerciales - neto 436.862.619 - 379.917.711 -
 Otras cuentas por cobrar 69.848.554 5.966.414 66.569.042 3.313.742
Total otras cuentas por cobrar 69.848.554 5.966.414 66.569.042 3.313.742
Total 506.711.173 5.966.414 446.486.753 3.313.742
 70

[pág. 72]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Las cuentas por cobrar de la Compañía están denominadas en las siguientes monedas o unidades de reajuste:
 Al 31 de Al 31 de
 diciembre de diciembre de
 2024 2023
 M$ M$
Peso chileno 299.240.865 291.976.889
Peso argentino 121.581.952 78.019.455
Dólar estadounidense 52.213.269 43.734.334
Euro 7.817.297 8.114.465
Unidad de fomento 2.606.146 2.261.531
Peso uruguayo 8.684.460 6.514.410
Guaraní paraguayo 15.086.724 13.996.752
Boliviano 3.385.594 2.856.786
Otras monedas 2.061.280 2.325.873
Total 512.677.587 449.800.495
El detalle de la antigüedad de las cuentas por cobrar al 31 de diciembre de 2024 es el siguiente:
 Total Saldos vigentes Saldos vencidos
 0 a 3 meses 3 a 6 meses 6 a 12 meses > 12 meses
 M$ M$ M$ M$ M$ M$
 Segmento de operación Chile 237.369.286 227.786.575 5.823.766 1.143.994 1.430.423 1.184.528
 Segmento de operación Negocios
 138.558.576 125.878.604 10.979.515 58.512 515.247 1.126.698
Internacionales
 Segmento de operación Vinos 68.720.452 61.101.828 7.123.480 359.386 45.864 89.894
Total deudores comerciales 444.648.314 414.767.007 23.926.761 1.561.892 1.991.534 2.401.120
Estimación para pérdidas por deterioro (7.785.695) (2.433.055) (816.441) (708.190) (1.720.870) (2.107.139)
Total deudores comerciales - neto 436.862.619 412.333.952 23.110.320 853.702 270.664 293.981
 Otras cuentas por cobrar 69.848.554 69.335.509 189.703 164.757 97 158.488
Total otras cuentas por cobrar 69.848.554 69.335.509 189.703 164.757 97 158.488
Total corriente 506.711.173 481.669.461 23.300.023 1.018.459 270.761 452.469
 Otras cuentas por cobrar 5.966.414 5.966.414 - - - -
Total no corriente 5.966.414 5.966.414 - - - -
El detalle de la antigüedad de las cuentas por cobrar al 31 de diciembre de 2023 es el siguiente:
 Saldos vencidos
 Total Saldos vigentes
 0 a 3 meses 3 a 6 meses 6 a 12 meses > 12 meses
 M$ M$ M$ M$ M$ M$
 Segmento de operación Chile 230.066.689 222.098.388 4.396.221 959.644 1.210.305 1.402.131
 Segmento de operación Negocios
 96.340.285 89.730.464 5.177.374 433.352 405.212 593.883
Internacionales
 Segmento de operación Vinos 61.262.042 57.181.716 3.858.399 62.884 121.455 37.588
Total deudores comerciales 387.669.016 369.010.568 13.431.994 1.455.880 1.736.972 2.033.602
Estimación para pérdidas por deterioro (7.751.305) (2.393.058) (1.385.596) (600.340) (1.338.709) (2.033.602)
Total deudores comerciales - neto 379.917.711 366.617.510 12.046.398 855.540 398.263 -
 Otras cuentas por cobrar 66.569.042 66.302.808 129.211 109.481 5.253 22.289
Total otras cuentas por cobrar 66.569.042 66.302.808 129.211 109.481 5.253 22.289
Total corriente 446.486.753 432.920.318 12.175.609 965.021 403.516 22.289
 Otras cuentas por cobrar 3.313.742 3.313.742 - - - -
Total no corriente 3.313.742 3.313.742 - - - -
 71

[pág. 73]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
La Compañía comercializa sus productos a través de clientes minoristas, mayoristas y cadenas de supermercados. Al 31 de
diciembre de 2024, las cuentas por cobrar de las tres cadenas de supermercados más importantes de Chile y Argentina
representan el 22% (26% al 31 de diciembre de 2023) del total de dichas cuentas por cobrar.
Tal como se indica en Nota 5 - Administración de Riesgos, en la sección riesgo de crédito, la Compañía toma seguros de
crédito que cubren aproximadamente el 90% de los saldos de las cuentas por cobrar individualmente significativas para el
mercado nacional e internacional, del total de las cuentas por cobrar.
El criterio general para la determinación de la provisión por deterioro ha sido establecido en el marco de la IFRS 9, la que
requiere analizar el comportamiento de la cartera de clientes en el largo plazo para generar un índice de pérdidas crediticias
esperadas por tramos en base a la antigüedad de la cartera. Este análisis entregó los siguientes resultados para la Compañía:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Tasa de pérdida Provisión Tasa de pérdida Provisión
 Valor libro bruto Valor libro bruto
 esperada deterioro esperada deterioro
 M$ M$ M$ M$
 Al día 0,09% 484.110.461 (2.433.055) 0,08% 435.313.376 (2.393.058)
 0 a 3 meses 22,16% 24.116.464 (816.441) 19,50% 13.561.205 (1.385.596)
 3 a 6 meses 61,53% 1.726.649 (708.190) 64,05% 1.565.361 (600.340)
 6 a 12 meses 100,00% 1.991.631 (1.720.870) 100,00% 1.742.225 (1.338.709)
 > 12 meses 100,00% 2.559.608 (2.107.139) 100,00% 2.055.891 (2.033.602)
 Total 514.504.813 (7.785.695) 454.238.058 (7.751.305)
El porcentaje de deterioro determinado para la cartera en cada corte, puede diferir de la aplicación directa de los parámetros
presentados previamente debido a que estos porcentajes son aplicados sobre la cartera descubierta de los seguros de
crédito que toma la Compañía. Los saldos vencidos superiores a 6 meses y respecto de los cuales no se han constituido
estimaciones para pérdidas por deterioro, corresponden principalmente a partidas protegidas por seguros de crédito.
Adicionalmente, existen montos vencidos en este rango, que de acuerdo a política se estiman pérdidas parciales por
deterioro en base a un análisis individual caso a caso.
Por lo expuesto anteriormente, la Administración de la Compañía estima que no se requieren provisiones para pérdidas por
deterioro adicionales a las constituidas de acuerdo con los análisis de antigüedad efectuados a los saldos por cobrar a
nuestros clientes.
En relación al castigo de deudores morosos se efectúa una vez que se han realizado todas las gestiones prejudiciales y
judiciales, y agotados todos los medios de cobro, con la debida demostración de la insolvencia de los clientes. Este proceso
de castigo normalmente demora más de 1 año.
El movimiento de la estimación por pérdidas por deterioro de las cuentas por cobrar es el siguiente:
 Al 31 de Al 31 de
 diciembre de diciembre de
 2024 2023
 M$ M$
 Saldo inicial (7.751.305) (5.689.741)
 Estimación por pérdidas crediticias esperadas para 12 meses (2.339.099) (4.135.572)
 Estimación por pérdidas crediticias de más de 12 meses (74.570) (74.250)
 Provisión por deterioro de cuentas por cobrar (2.413.669) (4.209.822)
 Cuentas por cobrar dadas de baja (incobrable) 987.556 1.025.786
 Reverso de provisiones no utilizadas 1.694.001 102.200
 Estimaciones provenientes de las combinaciones de negocios (1) (441.993) -
 Aumento (disminución) por diferencias de cambio y efecto de conversión 139.715 1.020.272
 Total (7.785.695) (7.751.305)
(1) Ver Nota 1 - Información general, letra C), numeral (12).
Adicionalmente, en Anexo I se presenta Información Adicional requerida por Oficio Circular N° 715 emitido por CMF, de fecha
3 de febrero de 2012, referido a la taxonomía XBRL.
 72

[pág. 74]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 11 Saldos y transacciones con partes relacionadas
Las transacciones entre la Compañía y sus subsidiarias, corresponden a operaciones habituales en cuanto a su objeto y
condiciones. Estas transacciones han sido eliminadas en el proceso de consolidación y no se desglosan en esta nota.
Los montos indicados como transacciones en cuadro adjunto, corresponden a operaciones comerciales con empresas
relacionadas, las que son efectuadas en condiciones similares a las que tendría un tercero, en cuanto a precio y condiciones
de pago. No existen estimaciones de incobrables que rebajen saldos por cobrar y tampoco existen garantías relacionadas
con las mismas.
Condiciones de los saldos y transacciones con empresas relacionadas:
(1) Corresponden a operaciones del giro social pactadas en pesos chilenos, cuya condición de pago es habitualmente a 30
días.
(2) Corresponden a operaciones del giro social pactadas en moneda extranjera, cuya condición de pago es habitualmente a
30 días.
(3) Corresponde a la venta de acciones que la subsidiaria Cervecería Kunstmann S.A. efectuó a Representaciones Chile
Beer Kevin Michael Szot E.I.R.L. de la sociedad Cervecería Szot SpA. El monto total de la transacción ascendió a la suma
de M$ 42.506 correspondiente a la venta de 15.167 acciones. Esta cuenta por cobrar se canceló con fecha 29 de abril de
2024.
(4) Con fecha 20 de enero de 2023, la subsidiaria Compañía Pisquera de Chile S.A. (“CPCh”) formalizó la adquisición del
51,0132% de participación de D&D SpA. El contrato de compraventa de acciones suscrito por CPCh con Panda SpA. y MBB
SpA., acordó que el precio de la compraventa será objeto de incrementos basados en los resultados de D&D SpA.
(5) Corresponde a reconocimiento de deudas por ventas de productos, efectuado con fecha 29 de diciembre de 2023, entre
la subsidiaria Cervecería Kunstmann S.A. y Cervecería Kunstmann Ltda., donde ésta última declara adeudar un monto de
UF 18.421,9, suma que se obliga a pagar a contar del mes de enero de 2024 con un interés anual del 6,6%, en 12 cuotas
iguales y sucesivas de UF 1.590,6.
Adicionalmente, se efectuó un reconocimiento de deudas por ventas de productos con fecha 31 de diciembre de 2024, entre
la subsidiaria Cervecería Kunstmann S.A. y Cervecería Kunstmann Ltda., donde ésta última declara adeudar un monto de
UF 28.365,9, suma que se obliga a pagar a contar del mes de enero de 2025 con un interés anual del 6,8%, en 24 cuotas
iguales y sucesivas de UF 676,6.
En el cuadro de transacciones se han incluido las principales transacciones con entidades relacionadas.
 73

[pág. 75]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
El detalle de las cuentas por cobrar y pagar a entidades relacionadas, es el siguiente:
Cuentas por cobrar a entidades relacionadas
Corriente:
 Al 31 de Al 31 de
 Moneda o diciembre de diciembre de
 País de
 RUT Sociedad Ref. Relación Transacción unidad de 2024 2023
 origen
 reajuste
 M$ M$
6.062.786-K Andrónico Luksic Craig Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 599 205
6.525.286-4 Francisco Pérez Mackenna Chile (1) Presidente del directorio Venta de productos CLP - 61
6.770.473-8 Armin Kunstmann Telge Chile (1) Presidente del directorio de subsidiaria Venta de productos CLP - 33
52.000.721-0 Representaciones Chile Beer Kevin Michael Szot E.I.R.L. Chile (3) Accionista de subsidiaria hasta el 29 de abril de 2024 Venta de acciones CLP - 6.588
52.000.721-0 Representaciones Chile Beer Kevin Michael Szot E.I.R.L. Chile (1) Accionista de subsidiaria hasta el 29 de abril de 2024 Venta de productos CLP - 12.098
76.002.201-2 SAAM Puertos S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 53 55
76.178.803-5 Viña Tabalí S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 1.292 1.272
76.275.453-3 Tech Pack S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 23 23
76.363.269-5 Inversiones Alabama Ltda. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 863 -
76.380.217-5 Hapag-Lloyd Chile SpA. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 8.262 8.602
76.455.830-8 Watts S.A. Chile (1) Relacionada al accionista de operación conjunta de la subsidiaria Venta de productos CLP 6.983 6.522
76.486.051-9 Inversiones Río Elqui SpA. Chile (1) Relacionada al minoritario de subsidiaria Venta de productos CLP 42.814 27.853
76.729.932-K SAAM Logistics S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 13.837 -
76.806.870-4 Transacciones e Inversiones Arizona Ltda. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 13 -
77.003.342-K Origen Patagónico SpA. Chile (1) Relacionada al minoritario de subsidiaria Venta de productos CLP 24.122 -
77.051.330-8 Cervecería Kunstmann Ltda. Chile (1) Relacionada al minoritario de subsidiaria Servicios prestados CLP 51.242 61.708
77.051.330-8 Cervecería Kunstmann Ltda. Chile (1) Relacionada al minoritario de subsidiaria Venta de productos CLP 125.620 219.304
77.051.330-8 Cervecería Kunstmann Ltda. Chile (5) Relacionada al minoritario de subsidiaria Venta de productos CLP 366.922 677.731
77.191.070-K Banchile Corredores de Seguros Ltda. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 771 339
77.755.610-K Comercial Patagona Ltda. Chile (1) Subsidiaria de negocio conjunto Venta de productos CLP 4.065.106 3.440.603
77.755.610-K Comercial Patagona Ltda. Chile (2) Subsidiaria de negocio conjunto Venta de productos USD 14.952 -
78.053.790-6 Servipag Ltda. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 946 866
78.259.420-6 Inversiones PFI Chile Ltda. Chile (1) Accionista de operación conjunta de subsidiaria Servicios prestados CLP 923.426 963.889
78.306.560-6 Inmobiliaria e Inversiones Río Claro S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 109 83
81.095.400-0 Sonacol S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 443 459
81.148.200-5 Ferrocarril de Antofagasta a Bolivia S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 1.661 509
81.805.700-8 Cooperativa Agrícola Control Pisquero de Elqui y Limarí Ltda. Chile (1) Accionista de subsidiaria Anticipo de compra CLP 800.000 800.000
81.805.700-8 Cooperativa Agrícola Control Pisquero De Elqui Y Limarí Ltda. Chile (1) Accionista de subsidiaria Venta de productos CLP 8.414 -
90.160.000-7 Compañía Sud Americana de Vapores S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 2.256 456
90.703.000-8 Nestlé Chile S.A. Chile (1) Accionista de subsidiaria Venta de productos CLP 34.867 31.571
91.021.000-9 Invexans S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 56 58
91.705.000-7 Quiñenco S.A. Chile (1) Accionista de la controladora Venta de productos CLP 5.065 4.739
92.011.000-2 Empresa Nacional de Energía Enex S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 6.594 11.453
94.625.000-7 Inversiones ENEX S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 280.418 245.920
96.536.010-7 Inversiones Consolidadas Ltda. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 1.016 626
96.571.220-8 Banchile Corredores de Bolsa S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 3.677 4.976
96.591.040-9 Empresas Carozzi S.A. Chile (1) Accionista de operación conjunta de subsidiaria Venta de productos CLP 24.438 32.759
96.610.780-4 Portuaria Corral S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 681 596
96.645.790-2 Socofin S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 1.667 372
96.657.210-8 Transportes Fluviales Corral S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 640 471
96.657.690-1 Inversiones Punta Brava S.A. Chile (1) Relacionada a la controladora Venta de productos CLP 610 -
96.767.630-6 Banchile Administradora General Fondos. S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP - 14
96.810.030-0 RDF Media SpA. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 126 424
96.819.020-2 Agrícola El Cerrito S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 26 -
96.847.140-6 Inmobiliaria Norte Verde S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 443 -
96.908.930-0 San Vicente Terminal Internacional S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 7.227 4.735
96.908.970-K San Antonio Terminal Internacional S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 355 875
96.919.980-7 Cervecería Austral S.A. Chile (1) Negocio conjunto Servicios prestados CLP 1.256.883 1.224.351
96.919.980-7 Cervecería Austral S.A. Chile (1) Negocio conjunto Venta de activo fijo CLP 252.072 -
97.004.000-5 Banco de Chile Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 36.214 28.323
99.506.030-2 Muellaje del Maipo S.A. Chile (1) Relacionada al accionista de la controladora Venta de productos CLP 3.248 5.307
0-E Paulaner Brauerei Gruppe GmbH & Co. KGaA Alemania (2) Relacionada al accionista de subsidiaria Venta de productos USD 37.122 -
0-E Aguas de Origen S.A. Argentina (2) Negocio conjunto de subsidiaria hasta el 30 de junio de 2024 Servicios prestados ARS - 1.084.888
0-E Danone Argentina S.A. Argentina (2) Relacionada a la asociada de subsidiaria Venta de productos ARS 11.689 -
0-E Central Cervecera de Colombia San Andrés S.A.S. Colombia (2) Negocio conjunto de subsidiaria Venta de productos USD 14.923 13.136
0-E Nestlé Waters Marketing & Distribution S.A.S. Francia (2) Relacionada al accionista de subsidiaria Servicios prestados Euros 7.247 69.111
0-E Amstel Brouwerijen B.V. Holanda (2) Relacionada al accionista de la controladora Royalty Euros - 46.055
0-E Heineken Brouwerijen B.V. Holanda (2) Relacionada al accionista de la controladora Servicios prestados Euros 21.957 -
0-E Heineken Brouwerijen B.V. Holanda (2) Relacionada al accionista de la controladora Servicios prestados USD 116.343 -
0-E A.J. Boston S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 64 -
0-E AJ S.A. Calidad Ante Todo Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 1.399.570 -
0-E AJ S.A. Calidad Ante Todo Paraguay (2) Relacionada al minoritario de subsidiaria Anticipo de compra USD 2.024.183 -
0-E Alimentos Distribución y Servicios S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 203.491 -
0-E Central de Ventas Tv S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 379 -
0-E Compaña de Desarrollo Agropecuario S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 200 -
0-E Compañía de Desarrollo Inmobiliario S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 27.885 -
0-E Contenidos Dirigidos S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 852 -
0-E Editorial El País S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 893 -
0-E Enex Paraguay S.A.E. Paraguay (2) Relacionada al accionista de la controladora Servicios prestados PYG - 509
0-E Fundación Santa Librada Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 97 -
0-E Hispanoamérica Tv Del Paraguay S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 235 -
0-E Laser Import S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 24 -
0-E Lauralia S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 4 -
0-E Recursos Oportunos S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 11 -
0-E Retail S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 3.151.745 -
0-E Servicios Contables y Sistemas del Py S.A. Paraguay (2) Relacionada de Subsidiaria Venta de productos PYG 1.355 -
0-E Servicios Digitales S.A. Paraguay (2) Relacionada de Subsidiaria Venta de productos PYG 13 -
0-E Talisman S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 1.893 -
0-E Tv Acción S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Venta de productos PYG 1.325 -
0-E Société Des Produits Nestlé S.A. Suiza (2) Relacionada al accionista de subsidiaria Servicios prestados Otras monedas 101.438 -
Totales 15.501.990 9.040.528
 74

[pág. 76]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
No corriente:
 Al 31 de Al 31 de
 Moneda o diciembre de diciembre de
 País de
 RUT Sociedad Ref. Relación Transacción unidad de 2024 2023
 origen
 reajuste
 M$ M$
52.000.721-0 Representaciones Chile Beer Kevin Michael Szot E.I.R.L. Chile (3) Accionista de subsidiaria hasta el 29 de abril de 2024 Venta de acciones CLP - 42.506
77.051.330-8 Cervecería Kunstmann Ltda. Chile (5) Relacionada al minoritario de subsidiaria Venta de productos CLP 844.344 -
Totales 844.344 42.506
Cuentas por pagar a entidades relacionadas
Corriente:
 Al 31 de Al 31 de
 Moneda o diciembre de diciembre de
 País de
 RUT Sociedad Ref. Relación Transacción unidad de 2024 2023
 origen
 reajuste
 M$ M$
52.000.721-0 Representaciones Chile Beer Kevin Michael Szot E.I.R.L. Chile (1) Accionista de subsidiaria hasta el 29 de abril de 2024 Servicios recibidos CLP - 23.375
76.115.132-0 Canal 13 SpA. Chile (1) Relacionada al accionista de la controladora Servicios recibidos CLP 665.792 92.268
76.380.217-5 Hapag-Lloyd Chile SpA. Chile (1) Relacionada al accionista de la controladora Servicios recibidos CLP 27.814 8.363
76.455.830-8 Watts S.A. Chile (1) Relacionada al accionista de operación conjunta de la subsidiaria Compra de productos CLP 468.660 1.218.335
76.486.051-9 Inversiones Río Elqui SpA. Chile (1) Relacionada al minoritario de subsidiaria Servicios recibidos CLP 697 -
76.729.932-K Saam Logistics S.A. Chile (1) Relacionada al accionista de la controladora Servicios recibidos CLP 751.761 513.428
77.003.342-K Origen Patagónico SpA. Chile (1) Relacionada al minoritario de subsidiaria Servicios recibidos CLP 3.097 456
77.450.163-0 Panda SpA. Chile (4) Accionista de subsidiaria Saldo compra de acciones CLP - 250.000
77.486.593-4 MBB SpA. Chile (4) Accionista de subsidiaria Saldo compra de acciones CLP - 250.000
77.755.610-K Comercial Patagona Ltda. Chile (1) Subsidiaria de negocio conjunto Servicios recibidos CLP 119.825 171.590
78.053.790-6 Servipag Ltda. Chile (1) Relacionada al accionista de la controladora Servicios recibidos CLP 2.525 3.671
78.259.420-6 Inversiones PFI Chile Ltda. Chile (1) Accionista de operación conjunta de subsidiaria Compra de productos CLP 3.066.334 1.564.090
81.805.700-8 Cooperativa Agrícola Control Pisquero de Elqui y Limarí Ltda. Chile (1) Accionista de subsidiaria Compra de productos CLP - 27.670
92.011.000-2 Empresa Nacional de Energía Enex S.A. Chile (1) Relacionada al accionista de la controladora Compra de productos CLP 289.011 9.527
94.058.000-5 Servicios Aeroportuarios Aerosan S.A. Chile (1) Relacionada al accionista de la controladora Servicios recibidos CLP 2.384 381
94.625.000-7 Inversiones ENEX S.A. Chile (1) Relacionada al accionista de la controladora Servicios recibidos CLP - 10.966
96.591.040-9 Empresas Carozzi S.A. Chile (2) Accionista de operación conjunta de subsidiaria Compra de productos USD 2.925 16.989
96.591.040-9 Empresas Carozzi S.A. Chile (1) Accionista de operación conjunta de subsidiaria Compra de productos CLP 674.567 782.698
96.591.040-9 Empresas Carozzi S.A. Chile (1) Accionista de operación conjunta de subsidiaria Servicios recibidos CLP - 33.026
96.657.690-1 Inversiones Punta Brava S.A. Chile (1) Relacionada a la controladora Servicios recibidos CLP 59.876 -
96.798.520-1 SAAM Extraportuarios S.A. Chile (1) Relacionada al accionista de la controladora Servicios recibidos CLP 197 -
96.810.030-0 RDF Media SpA. Chile (1) Relacionada al accionista de la controladora Servicios recibidos CLP 34.412 14.676
96.908.930-0 San Vicente Terminal Internacional S.A. Chile (1) Relacionada al accionista de la controladora Servicios recibidos CLP 15 -
96.908.970-K San Antonio Terminal Internacional S.A. Chile (1) Relacionada al accionista de la controladora Servicios recibidos CLP 2.945 288
96.919.980-7 Cervecería Austral S.A. Chile (1) Negocio conjunto Compra de productos CLP 2.489.546 1.908.328
96.919.980-7 Cervecería Austral S.A. Chile (1) Negocio conjunto Royalty CLP 1.055.464 744.554
97.004.000-5 Banco de Chile Chile (1) Relacionada al accionista de la controladora Servicios recibidos CLP 331.390 11.261
0-E Aguas Danone de Argentina S.A. Argentina (2) Asociada de subsidiaria Servicios recibidos ARS 67.088 -
0-E Aguas de Origen S.A. Argentina (2) Negocio conjunto de subsidiaria hasta el 30 de junio de 2024 Consignación ARS - 9.229.527
0-E Danone Argentina S.A. Argentina (2) Relacionada a la asociada de subsidiaria Servicios recibidos ARS 175.594 -
0-E Ecor Ltda. Bolivia (2) Relacionada al minoritario de subsidiaria Servicios recibidos BOB 13.950 91.998
0-E Central Cervecera de Colombia San Andrés S.A.S. Colombia (2) Negocio conjunto de subsidiaria Servicios recibidos USD 60.022 1.963
0-E Danone S.A. Francia (2) Relacionada a la asociada de subsidiaria Servicios recibidos Euros 67.431 -
0-E Evian - S.A. des Eaux Minerales Francia (2) Relacionada al minoritario de subsidiaria Servicios recibidos Euros 61.310 -
0-E Nestlé Waters Management & Technology S.A.S. Francia (2) Relacionada al minoritario de subsidiaria Servicios recibidos Euros 19.125 4.512
0-E Nestlé Waters Marketing & Distribution S.A.S. Francia (2) Relacionada al minoritario de subsidiaria Compra de productos Euros 63.378 29.341
0-E Amstel Brouwerijen B.V. Holanda (2) Relacionada al accionista de la controladora Royalty USD 432.613 -
0-E Amstel Brouwerijen B.V. Holanda (2) Relacionada al accionista de la controladora Royalty Euros 262.340 -
0-E Heineken Brouwerijen B.V. Holanda (2) Relacionada al accionista de la controladora Compra de productos USD 577.618 3.938.038
0-E Heineken Brouwerijen B.V. Holanda (2) Relacionada al accionista de la controladora Royalty Euros 20.536.740 34.041.624
0-E Heineken Brouwerijen B.V. Holanda (2) Relacionada al accionista de la controladora Royalty USD 1.721.042 88.757
0-E Heineken Supply Chain B.V. Holanda (2) Relacionada al accionista de la controladora Compra de productos Euros 26 21
0-E AJ S.A. Calidad Ante Todo Paraguay (2) Relacionada al minoritario de subsidiaria Compra de productos PYG 1.885.846 -
0-E Alimentos Distribución y Servicios S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Servicios recibidos PYG 195.266 -
0-E Central de Ventas TV S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Servicios recibidos PYG 14.073 -
0-E Compañía de Bienes Raíces del Paraguay S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Servicios recibidos PYG 389 -
0-E Compañía de Desarrollo Inmobiliario S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Servicios recibidos PYG 2.935 -
0-E Enex Paraguay S.A.E. Paraguay (2) Relacionada al accionista de la controladora Compra de productos PYG - 1.131
0-E Hispanoamérica Tv del Paraguay S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Servicios recibidos PYG 2.111 -
0-E Laser Import S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Servicios recibidos PYG 282 -
0-E Retail S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Servicios recibidos PYG 186.659 -
0-E Servicios Contables y Sistemas del PY S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Servicios recibidos PYG 947 -
0-E TV Acción S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Servicios recibidos PYG 6.918 -
0-E Yerbatera Campesino S.A. Paraguay (2) Relacionada al minoritario de subsidiaria Servicios recibidos PYG 14.578 -
0-E Société des Produits Nestlé S.A. Suiza (2) Relacionada al minoritario de subsidiaria Royalty Otras monedas - 57.778
Totales 36.417.518 55.140.630
No Corriente:
 Al 31 de Al 31 de
 Moneda o diciembre de diciembre de
 País de
 RUT Sociedad Ref. Relación Transacción unidad de 2024 2023
 origen
 reajuste
 M$ M$
77.450.163-0 Panda SpA. Chile (4) Accionista de subsidiaria Saldo compra de acciones CLP - 268.041
77.486.593-4 MBB SpA. Chile (4) Accionista de subsidiaria Saldo compra de acciones CLP - 268.042
Totales - 536.083
 75

[pág. 77]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Transacciones más significativas y efectos en resultados:
Las transacciones significativas con partes relacionadas por los ejercicios terminados al 31 de diciembre de 2024 y 2023,
son las siguientes:
 2024 2023
 (Cargos)/Abonos (Cargos)/Abonos
 País de
 RUT Sociedad Relación Transacción Montos (Efecto Montos (Efecto
 origen
 Resultado) Resultado)
 M$ M$ M$ M$
6.062.786-K Andrónico Luksic Craig Chile Relacionada al accionista de la controladora Venta de productos 13.557 6.718 5.399 3.509
6.525.286-4 Francisco Pérez Mackenna Chile Presidente del directorio Venta de productos 1.264 709 108 102
6.770.473-8 Armin Kunstmann Telge Chile Presidente del directorio de subsidiaria Venta de productos 245 186 180 171
52.000.721-0 Representaciones Chile Beer Kevin Michael Szot E.I.R.L. Chile Accionista de subsidiaria hasta el 29 de abril de 2024 Venta de acciones 208.755 - - -
76.115.132-0 Canal 13 SpA. Chile Relacionada al accionista de la controladora Servicios recibidos 983.007 (983.007) 1.222.804 (1.222.804)
76.313.970-0 Inversiones Irsa Ltda. Chile Relacionada a la controladora Dividendos pagados 5.120.726 - 2.813.685 -
76.380.217-5 Hapag-Lloyd Chile SpA. Chile Relacionada al accionista de la controladora Servicios recibidos 105.374 (72.313) 138.858 (54.479)
76.455.830-8 Watt´s S.A. Chile Relacionada al accionista de operación conjunta Venta de productos 48.306 36.713 13.333 10.133
76.729.932-K SAAM Logistics S.A. Chile Relacionada al accionista de la controladora Servicios recibidos 528.370 - 450.508 -
76.800.322-K Yanghe Chile SpA. Chile Accionista de subsidiaria Dividendos pagados 891.244 - 1.871.881 -
77.051.330-8 Cervecería Kunstmann Ltda. Chile Relacionada al minoritario de subsidiaria Venta de productos 791.367 494.640 739.372 554.529
77.051.330-8 Cervecería Kunstmann Ltda. Chile Relacionada al minoritario de subsidiaria Servicios recibidos 173.154 (173.154) 145.231 (145.231)
77.051.330-8 Cervecería Kunstmann Ltda. Chile Relacionada al minoritario de subsidiaria Cobro por venta de productos 572.254 23.819 - -
77.450.163-0 Panda SpA. Chile Accionista de subsidiaria Compra de acciones 250.000 - 1.000.000 -
77.486.593-4 MBB SpA. Chile Accionista de subsidiaria Compra de acciones 250.000 - 1.000.000 -
77.755.610-K Comercial Patagona Ltda. Chile Subsidiaria de negocio conjunto Servicios recibidos 820.748 (820.748) 900.166 (900.166)
77.755.610-K Comercial Patagona Ltda. Chile Subsidiaria de negocio conjunto Venta de productos 13.056.638 5.423.136 6.584.400 4.240.894
78.259.420-6 Inversiones PFI Chile Ltda. Chile Accionista de operación conjunta Servicios recibidos 99.376 (99.376) 344.652 (344.652)
78.259.420-6 Inversiones PFI Chile Ltda. Chile Accionista de operación conjunta Compra de productos 23.106.203 - 21.182.529 -
78.259.420-6 Inversiones PFI Chile Ltda. Chile Accionista de operación conjunta Servicios prestados 6.539.386 6.539.386 6.584.400 6.584.400
79.985.340-K Cervecera Valdivia S.A. Chile Accionista de subsidiaria Dividendos pagados 833.684 - 2.023.511 -
81.805.700-8 Cooperativa Agrícola Control Pisquero de Elqui y Limarí Ltda. Chile Accionista de subsidiaria Compra de productos 8.166.757 - 8.533.943 -
81.805.700-8 Cooperativa Agrícola Control Pisquero de Elqui y Limarí Ltda. Chile Accionista de subsidiaria Dividendos pagados 1.465.381 - 1.617.375 -
81.805.700-8 Cooperativa Agrícola Control Pisquero de Elqui y Limarí Ltda. Chile Accionista de subsidiaria Venta de productos 14.604 7.955 12.494 8.249
81.805.700-8 Cooperativa Agrícola Control Pisquero de Elqui y Limarí Ltda. Chile Accionista de subsidiaria Cobro de préstamo - - 71.381 722
90.703.000-8 Nestlé Chile S.A. Chile Accionista de subsidiaria Dividendos pagados 9.428.103 - 6.876.759 -
91.705.000-7 Quiñenco S.A. Chile Accionista de la controladora Venta de productos 20.593 10.239 45.293 33.970
92.011.000-2 Empresa Nacional de Energía Enex S.A. Chile Relacionada al accionista de la controladora Compra de productos 355.449 (355.449) 374.278 (374.278)
92.011.000-2 Empresa Nacional de Energía Enex S.A. Chile Relacionada al accionista de la controladora Servicios recibidos 659.752 (659.752) 445.859 (445.859)
93.920.000-2 Antofagasta Minerals S.A. Chile Relacionada al accionista de la controladora Venta de productos 735 360 259 192
94.625.000-7 Inversiones Enex S.A. Chile Relacionada al accionista de la controladora Venta de productos 2.159.882 936.483 2.235.409 1.587.187
96.427.000-7 Inversiones y Rentas S.A. Chile Controladora Dividendos pagados 44.180.306 - 24.275.754 -
96.427.000-7 Inversiones y Rentas S.A. Chile Controladora Servicios prestados 12.120 12.120 11.602 11.602
96.571.220-8 Banchile Corredores de Bolsa S.A. Chile Relacionada al accionista de la controladora Inversiones 8.900.000 - 95.600.000 -
96.571.220-8 Banchile Corredores de Bolsa S.A. Chile Relacionada al accionista de la controladora Rescate de inversiones 8.903.287 3.287 96.739.832 139.832
96.591.040-9 Empresas Carozzi S.A. Chile Accionista de operación conjunta Venta de productos 169.387 128.734 164.423 156.202
96.591.040-9 Empresas Carozzi S.A. Chile Accionista de operación conjunta Compra de productos 8.450.811 - 7.529.691 -
96.657.690-1 Inversiones Punta Brava S.A. Chile Relacionada al accionista de la controladora Servicios recibidos 118.239 (118.239) 153.253 (153.253)
96.657.690-1 Inversiones Punta Brava S.A. Chile Relacionada al accionista de la controladora Venta de productos 1.343 680 1.313 919
96.689.310-9 Transbank S.A. Chile Relacionada al accionista de la controladora Servicios recibidos 185.941 (185.941) 228.315 (228.315)
96.798.520-1 SAAM Extraportuario S.A. Chile Relacionada al accionista de la controladora Servicios recibidos 13.899 - 130.016 -
96.810.030-0 RDF Media SpA. Chile Relacionada al accionista de la controladora Servicios recibidos 191.714 (191.714) 78.765 (78.765)
96.919.980-7 Cervecería Austral S.A. Chile Negocio conjunto Dividendos percibidos 899.143 - 1.190.908 -
96.919.980-7 Cervecería Austral S.A. Chile Negocio conjunto Venta de productos 103.812 36.334 171.926 123.998
96.919.980-7 Cervecería Austral S.A. Chile Negocio conjunto Compra de productos 24.758.860 - 25.295.168 -
96.919.980-7 Cervecería Austral S.A. Chile Negocio conjunto Servicios prestados 707.709 707.709 406.768 406.768
96.919.980-7 Cervecería Austral S.A. Chile Negocio conjunto Royalty 4.558.224 (4.558.224) 4.552.895 (4.552.895)
97.004.000-5 Banco de Chile Chile Relacionada al accionista de la controladora Intereses - - 15.202 (15.202)
97.004.000-5 Banco de Chile Chile Relacionada al accionista de la controladora Servicios recibidos 2.802 (2.802) 5.589 (5.589)
97.004.000-5 Banco de Chile Chile Relacionada al accionista de la controladora Venta de productos 353.212 257.153 320.417 286.706
97.004.000-5 Banco de Chile Chile Relacionada al accionista de la controladora Derivados 64.956.737 (442.469) 62.119.774 (148.869)
97.004.000-5 Banco de Chile Chile Relacionada al accionista de la controladora Inversiones 28.530.440 - 35.000.000 -
97.004.000-5 Banco de Chile Chile Relacionada al accionista de la controladora Rescate de inversiones 28.866.521 336.081 35.088.765 88.765
0-E Aguas Danone de Argentina S.A Argentina Asociada de subsidiaria Servicios recibidos 218.750 (218.750) - -
0-E Aguas de Origen S.A. Argentina Negocio conjunto de subsidiaria hasta el 30 de junio de 2024 Servicios recibidos 3.124.256 (3.124.256) - -
0-E Aguas de Origen S.A. Argentina Negocio conjunto de subsidiaria hasta el 30 de junio de 2024 Aporte de Capital - - 4.545.020 -
0-E Aguas de Origen S.A. Argentina Negocio conjunto de subsidiaria hasta el 30 de junio de 2024 Compra de productos - - 2.094.249 -
0-E Aguas de Origen S.A. Argentina Negocio conjunto de subsidiaria hasta el 30 de junio de 2024 Servicios prestados 15.482.092 15.482.092 6.905.615 6.905.615
0-E Aguas de Origen S.A. Argentina Negocio conjunto de subsidiaria hasta el 30 de junio de 2024 Venta en consignación 50.722.957 - 50.786.322 -
0-E Aguas de Origen S.A. Argentina Negocio conjunto de subsidiaria hasta el 30 de junio de 2024 Préstamo - - 1.716.741 283.599
0-E Aguas de Origen S.A. Argentina Negocio conjunto de subsidiaria hasta el 30 de junio de 2024 Pago de préstamo - - 545.944 -
0-E Danone Argentina S.A. Argentina Relacionada a la asociada de subsidiaria Compra de productos 1.180 (1.180) - -
0-E Danone Argentina S.A. Argentina Relacionada a la asociada de subsidiaria Servicios recibidos 167.391 (167.391) - -
0-E Ecor Ltda. Bolivia Relacionada al accionista de subsidiaria Servicios recibidos 275.146 (275.146) 38.930 (38.930)
0-E Inversiones BEBINV S.A. Bolivia Relacionada al accionista de subsidiaria Aporte de Capital 2.708.166 - 2.631.809 -
0-E Central Cervecera de Colombia S.A.S. Colombia Negocio conjunto Aporte de Capital 10.658.097 - 4.176.846 -
0-E Central Cervecera de Colombia S.A.S. Colombia Negocio conjunto Reembolso de gastos 349.421 (349.421) - -
0-E Central Cervecera de Colombia S.A.S. Colombia Negocio conjunto Servicios recibidos 337.073 (337.073) 310.546 (310.546)
0-E Amstel Brouwerijen B.V. Holanda Relacionada al accionista de la controladora Royalty 1.592.389 (1.592.389) 479.859 (479.859)
0-E Heineken Brouwerijen B.V. Holanda Relacionada al accionista de la controladora Compra de productos 10.717.369 - 17.637.986 -
0-E Heineken Brouwerijen B.V. Holanda Relacionada al accionista de la controladora Royalty 22.229.029 (22.229.029) 15.409.594 (15.409.594)
0-E Heineken Brouwerijen B.V. Holanda Relacionada al accionista de la controladora Servicios recibidos 130.946 (130.946) 71.520 (71.520)
0-E Aerocentro S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 357 250
0-E Ana Yakisich Paraguay Accionista de subsidiaria Canje de acciones - Entrega de acciones 1.394.986 - - -
0-E Ana Yakisich Paraguay Accionista de subsidiaria Canje de acciones - Adquisición de acciones 4.506.668 - - -
0-E Ana Yakisich Paraguay Accionista de subsidiaria Venta de acciones 8.556.390 - - -
0-E Antonio Vierci Paraguay Accionista de subsidiaria Canje de acciones - Entrega de acciones 1.394.986 - - -
0-E Antonio Vierci Paraguay Accionista de subsidiaria Canje de acciones - Adquisición de acciones 4.506.668 - - -
0-E Antonio Vierci Paraguay Accionista de subsidiaria Venta de acciones 8.556.390 - - -
0-E Banco BASA S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 103 72
0-E Cadena Farmacenter S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 14.606 10.224
0-E Chajha S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 809 566
0-E Consignataria de Ganado S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 62 44
0-E Emprendimientos Hoteleros S.A.E.C.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 1.259 881
0-E ENEX Paraguay S.R.L. Paraguay Relacionada al accionista de la controladora Servicios recibidos 10.094 (10.094) 5.607 (5.607)
0-E ENEX Paraguay S.R.L. Paraguay Relacionada al accionista de la controladora Compra de productos 14.925 - 7.952 -
0-E ENEX Paraguay S.R.L. Paraguay Relacionada al accionista de la controladora Venta de productos 3.319 1.385 53.980 37.786
0-E Ganadería Las Pampas S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 712 498
0-E Gráfica Editorial Inter-Sudamericana S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 45 31
0-E Horacio Cartes Paraguay Relacionada hasta el 16 de marzo de 2023 Dividendos pagados - - 2.513.295 -
0-E La Misión S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 257 180
0-E Palermo S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 4.790 3.353
0-E Pamplona S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 12 9
0-E Prana S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 79 56
0-E Sarah Cartes Paraguay Relacionada hasta el 16 de marzo de 2023 Compra de acciones - - 3.205.058 -
0-E Sudameris Bank S.A.E.C.A Paraguay Relacionada hasta el 20 de febrero de 2024 Compra de acciones 31.549.348 - - -
0-E Tabacalera del Este S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 4.578 3.204
0-E Societé des Produits Nestlé S.A. Suiza Relacionada al accionista de subsidiaria Royalty 666.188 (666.188) 746.462 (746.462)
 76

[pág. 78]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Las transacciones significativas con partes relacionadas por los ejercicios terminados al 31 de diciembre de 2023 y 2022,
son las siguientes:
 2023 2022
 (Cargos)/Abonos (Cargos)/Abonos
 País de
 RUT Sociedad Relación Transacción Montos (Efecto Montos (Efecto
 origen Resultado) Resultado)
 M$ M$ M$ M$
76.115.132-0 Canal 13 SpA. Chile Relacionada al accionista de la controladora Servicios recibidos 1.222.804 (1.222.804) 1.155.452 (1.155.452)
76.178.803-5 Viña Tabalí S.A. Chile Relacionada al accionista de la controladora Servicios prestados - - 1.849 1.849
76.313.970-0 Inversiones Irsa Ltda. Chile Relacionada a la controladora Dividendos pagados 2.813.685 - 8.471.325 -
76.380.217-5 Hapag-Lloyd Chile SpA. Chile Relacionada al accionista de la controladora Servicios recibidos 138.858 54.479 573.035 -
76.486.051-9 Inversiones Río Elqui SpA. Chile Relacionada al minoritario de subsidiaria Pago de préstamo - - 26.088 (1.088)
76.729.932-K SAAM Logistics S.A. Chile Relacionada al accionista de la controladora Servicios recibidos 450.508 - 667.898 -
76.800.322-K Yanghe Chile SpA. Chile Accionista de subsidiaria Dividendos pagados 1.871.881 - 2.240.801 -
77.051.330-8 Cervecería Kunstmann Ltda. Chile Relacionada al minoritario de subsidiaria Servicios recibidos 145.231 (145.231) 144.026 (144.026)
77.051.330-8 Cervecería Kunstmann Ltda. Chile Relacionada al minoritario de subsidiaria Venta de productos 739.372 554.529 832.185 644.128
77.755.610-K Comercial Patagona Ltda. Chile Subsidiaria de negocio conjunto Servicios recibidos 900.166 (900.166) 499.147 (499.147)
77.755.610-K Comercial Patagona Ltda. Chile Subsidiaria de negocio conjunto Venta de productos 6.584.400 4.240.894 11.376.459 7.327.373
78.259.420-6 Inversiones PFI Chile Ltda. Chile Accionista de operación conjunta Servicios prestados 6.584.400 6.584.400 4.136.850 4.136.850
78.259.420-6 Inversiones PFI Chile Ltda. Chile Accionista de operación conjunta Servicios recibidos 344.652 (344.652) - -
78.259.420-6 Inversiones PFI Chile Ltda. Chile Accionista de operación conjunta Compra de productos 21.182.529 - 20.804.801 -
79.985.340-K Cervecera Valdivia S.A. Chile Accionista de subsidiaria Dividendos pagados 2.023.511 - 2.497.851 -
81.805.700-8 Cooperativa Agrícola Control Pisquero de Elqui y Limarí Ltda. Chile Accionista de subsidiaria Dividendos pagados 1.617.375 - 2.655.807 -
81.805.700-8 Cooperativa Agrícola Control Pisquero de Elqui y Limarí Ltda. Chile Accionista de subsidiaria Cobro de préstamo 71.381 722 32.772 2.751
81.805.700-8 Cooperativa Agrícola Control Pisquero de Elqui y Limarí Ltda. Chile Accionista de subsidiaria Venta de productos 12.494 8.249 9.021 5.956
90.703.000-8 Nestlé Chile S.A. Chile Accionista de subsidiaria Dividendos pagados 6.876.759 - 8.447.312 -
91.705.000-7 Quiñenco S.A. Chile Accionista de la controladora Venta de productos 45.293 33.970 39.859 27.941
92.011.000-2 Empresa Nacional de Energía Enex S.A. Chile Relacionada al accionista de la controladora Compra de productos 374.278 (374.278) 293.324 (293.324)
92.011.000-2 Empresa Nacional de Energía Enex S.A. Chile Relacionada al accionista de la controladora Servicios recibidos 445.859 (445.859) 502.566 (502.566)
92.011.000-2 Empresa Nacional de Energía Enex S.A. Chile Relacionada al accionista de la controladora Compra de activo fijo - - 173.828 -
93.920.000-2 Antofagasta Minerals S.A. Chile Relacionada al accionista de la controladora Venta de productos 259 192 1.405 1.042
94.625.000-7 Inversiones Enex S.A. Chile Relacionada al accionista de la controladora Venta de productos 2.235.409 1.587.187 1.953.745 1.387.200
96.427.000-7 Inversiones y Rentas S.A. Chile Controladora Dividendos pagados 24.275.754 - 73.088.417 -
96.427.000-7 Inversiones y Rentas S.A. Chile Controladora Servicios prestados 11.602 11.602 10.557 10.557
96.571.220-8 Banchile Corredores de Bolsa S.A. Chile Relacionada al accionista de la controladora Inversiones 95.600.000 - 149.300.000 -
96.571.220-8 Banchile Corredores de Bolsa S.A. Chile Relacionada al accionista de la controladora Rescate de inversiones 96.739.832 139.832 148.410.149 110.149
96.591.040-9 Empresas Carozzi S.A. Chile Accionista de operación conjunta Compra de productos 7.529.691 - 6.177.739 -
96.591.040-9 Empresas Carozzi S.A. Chile Accionista de operación conjunta Venta de productos 164.423 156.202 137.697 129.228
96.657.690-1 Inversiones Punta Brava S.A. Chile Relacionada al accionista de la controladora Servicios recibidos 153.253 (153.253) 449.860 (449.860)
96.657.690-1 Inversiones Punta Brava S.A. Chile Relacionada al accionista de la controladora Venta de productos 1.313 919 1.177 824
96.689.310-9 Transbank S.A. Chile Relacionada al accionista de la controladora Servicios recibidos 228.315 (228.315) 311.390 (311.390)
96.798.520-1 SAAM Extraportuario S.A. Chile Relacionada al accionista de la controladora Servicios recibidos 130.016 - 243.771 -
96.810.030-0 RDF Media SpA. Chile Relacionada al accionista de la controladora Servicios recibidos 78.765 (78.765) 103.396 (103.396)
96.919.980-7 Cervecería Austral S.A. Chile Negocio conjunto Compra de productos 25.295.168 - 23.629.417 -
96.919.980-7 Cervecería Austral S.A. Chile Negocio conjunto Dividendos percibidos 1.190.908 - 3.374.340 -
96.919.980-7 Cervecería Austral S.A. Chile Negocio conjunto Servicios prestados 406.768 406.768 376.620 376.620
96.919.980-7 Cervecería Austral S.A. Chile Negocio conjunto Royalty 4.552.895 (4.552.895) 5.628.246 (5.628.246)
96.919.980-7 Cervecería Austral S.A. Chile Negocio conjunto Venta de productos 171.926 123.998 146.738 105.831
97.004.000-5 Banco de Chile Chile Relacionada al accionista de la controladora Derivados 62.119.774 (148.869) 77.238.037 (234.142)
97.004.000-5 Banco de Chile Chile Relacionada al accionista de la controladora Intereses 15.202 (15.202) 267.368 (267.368)
97.004.000-5 Banco de Chile Chile Relacionada al accionista de la controladora Inversiones 35.000.000 - 282.850.110 -
97.004.000-5 Banco de Chile Chile Relacionada al accionista de la controladora Servicios recibidos 5.589 (5.589) 42.572 (42.572)
97.004.000-5 Banco de Chile Chile Relacionada al accionista de la controladora Rescate de inversiones 35.088.765 88.765 305.336.443 495.848
97.004.000-5 Banco de Chile Chile Relacionada al accionista de la controladora Venta de productos 320.417 286.706 257.898 230.765
0-E Ecor Ltda. Bolivia Relacionada al accionista de subsidiaria Servicios recibidos 38.930 (38.930) 78.996 (78.996)
0-E Inversiones BEBINV S.A. Bolivia Relacionada al accionista de subsidiaria Aporte de Capital 2.631.809 - 1.648.121 -
0-E Central Cervecera de Colombia S.A.S. Colombia Negocio conjunto Aporte de Capital 4.176.846 - 10.328.704 -
0-E Water Latam S.L. España Controladora de asociada Compra de acciones - - 25.594.237 -
0-E Amstel Brouwerijen B.V. Holanda Relacionada al accionista de la controladora Royalty 479.859 (479.859) 971.055 (971.055)
0-E Heineken Brouwerijen B.V. Holanda Relacionada al accionista de la controladora Compra de productos 17.637.986 - 16.543.178 -
0-E Heineken Brouwerijen B.V. Holanda Relacionada al accionista de la controladora Royalty 15.409.594 (15.409.594) 19.199.831 (19.199.831)
0-E Heineken Brouwerijen B.V. Holanda Relacionada al accionista de la controladora Servicios recibidos 71.520 (71.520) 95.279 (95.279)
0-E Aerocentro S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos 357 250 1.452 1.016
0-E Banco BASA S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos 103 72 1.796 1.257
0-E Cadena Farmacenter S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos 14.606 10.224 14.883 10.418
0-E Cementos Concepción S.A.E. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 2.366 1.656
0-E Chajha S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos 809 566 6.320 4.424
0-E Cigar Trading S.R.L. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 848 593
0-E Club Libertad Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 12.982 9.087
0-E Consignataria de Ganado S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos 62 44 705 493
0-E Emprendimientos Hoteleros S.A.E.C.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos 1.259 881 21.279 14.895
0-E ENEX Paraguay S.R.L. Paraguay Relacionada al accionista de subsidiaria Venta de productos - - 196.738 137.716
0-E Fundación Ramón T. Cartes Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 741 518
0-E Ganadera Las Pampas S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 3.930 2.751
0-E Gráfica Editorial Inter-Sudamericana S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos 45 31 490 343
0-E La Misión S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos 257 180 1.278 894
0-E Palermo S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos 4.790 3.353 9.613 6.729
0-E Pamplona S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos 12 9 1.302 912
0-E Prana S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos 79 56 348 243
0-E QSR S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 339.904 237.933
0-E Saga Gym S.R.L. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos - - 541 379
0-E Tabacalera del Este S.A. Paraguay Relacionada hasta el 16 de marzo de 2023 Venta de productos 4.578 3.204 44.089 30.863
0-E Societé des Produits Nestlé S.A. Suiza Relacionada al accionista de subsidiaria Royalty 746.462 (746.462) 721.098 (721.098)
 77

[pág. 79]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Remuneraciones personal clave de la gerencia
La Compañía es administrada por un Directorio compuesto por nueve miembros, los cuales permanecen por un período de
tres años en sus funciones, pudiendo ser reelegidos.
En Junta Ordinaria de Accionistas celebrada con fecha 12 de abril de 2023, se procedió a la elección de un nuevo Directorio,
resultando electos, por un período de tres años, los señores Andrónico Luksic Craig, Francisco Pérez Mackenna, Pablo
Granifo Lavín, Rodrigo Hinzpeter Kirberg, Carlos Molina Solís, María Gabriela Cadenas, Marc Gross, Rory Cullinan y Vittorio
Corbo Lioi siendo éste último elegido en calidad de director independiente de conformidad con lo dispuesto en el artículo 50
bis de la Ley N° 18.046. El Presidente y Vicepresidente del Directorio, así como los integrantes del Comité de Directores y
Comité de Auditoría, fueron designados en sesión de Directorio celebrada con igual fecha, resultando electo el señor
Andrónico Luksic Craig en el cargo de Presidente y el señor Carlos Molina Solís en el de Vicepresidente. Conforme a lo
establecido en el artículo 50 bis de la Ley N° 18.046, el director independiente señor Vittorio Corbo Lioi designó a los demás
integrantes del Comité de Directores, lo que ocurrió en la misma sesión, el que quedó compuesto por los directores señores
Corbo, Pérez y Molina. El Comité de Auditoría quedó compuesto por los directores señores Corbo y Molina, quienes reúnen
los requisitos de independencia aplicables según el criterio establecido en la Securities Exchange Act de 1934, Sarbanes-
Oxley Act de 2002 y las normas del New York Stock Exchange. Asimismo, el Directorio resolvió que el director señor Pérez
participe en las sesiones del Comité de Auditoría en calidad de observador.
En la referida Junta Ordinaria de Accionistas, se resolvió mantener la remuneración de los directores acordada en la Junta
Ordinaria de Accionistas anterior, consistente en una dieta mensual de UF 100 brutas para cada director y de UF 200 brutas
para el Presidente, por asistencia al Directorio, independiente del número de sesiones que se celebren en el período, más
una cantidad equivalente al 3% de los dividendos que se distribuyeren con cargo a las utilidades de la Compañía, para el
Directorio en su conjunto, calculados sobre un monto máximo equivalente al 50% de la utilidad líquida distribuible del
ejercicio, a razón de una novena parte para cada director y en proporción al tiempo que cada uno hubiere servido en el cargo
durante el año 2023.
En dicha Junta se acordó, asimismo, mantener la remuneración de los directores que integran el Comité de Directores,
consistente en una dieta mensual por asistencia, independiente del número de sesiones que se celebren en el período, de
UF 50 brutas, más lo que le corresponda como porcentaje de los dividendos hasta completar el tercio adicional que establece
el artículo 50 bis de la Ley N° 18.046 sobre Sociedades Anónimas y la Circular N° 1.956 de la Comisión para el Mercado
Financiero; y respecto de aquellos directores que forman parte del Comité de Auditoría, y los designados en calidad de
observadores del mismo, una dieta mensual, por asistencia, independiente del número de sesiones que se celebren en el
período, ascendente a UF 50 brutas.
En sesión extraordinaria de Directorio celebrada el día 28 de septiembre de 2023, el señor Andrónico Luksic Craig presentó
su renuncia a su cargo de Presidente y director, con efecto a contar del día 29 de diciembre de 2023. A continuación, el
Directorio nombró director reemplazante al señor Oscar Hasbún Martínez, debiéndose proceder a la renovación total de
Directorio en la próxima Junta Ordinaria de Accionistas, de conformidad a lo establecido en el artículo 32 de la Ley N° 18.046
sobre Sociedades Anónimas. Finalmente, el Directorio acordó designar al señor Francisco Pérez Mackenna como nuevo
Presidente del Directorio, quien asume esa nueva función luego de hacerse efectiva la renuncia y salida del señor Andrónico
Luksic Craig.
En virtud de lo anterior, y debido a que conforme lo establecido en el artículo 50 bis de la Ley Nº 18.046 sobre Sociedades
Anónimas el Presidente del Directorio no puede integrar el Comité de Directores, salvo que sea el director independiente, en
sesión de Directorio celebrada el día 4 de diciembre de 2023, el señor Pérez renunció a su calidad de miembro del Comité
de Directores y, adicionalmente, de observador del Comité de Auditoría. En la misma sesión el señor Corbo, en su calidad
de único director que cumple con las condiciones de independencia del referido artículo 50 bis, designó como miembro del
Comité de Directores, en reemplazo del señor Pérez, al director señor Hinzpeter, quedando en consecuencia el Comité de
Directores integrado, además del señor Corbo, por los directores señores Molina e Hinzpeter. Asimismo, el Directorio
encomendó al director señor Hinzpeter participar en las sesiones del Comité de Auditoría en calidad de observador. En
consecuencia, el Comité de Auditoría se mantuvo integrado por los directores señores Corbo y Molina, participando el director
señor Hinzpeter en calidad de observador.
En Junta Ordinaria de Accionistas celebrada con fecha 17 de abril de 2024, se procedió a la elección de un nuevo Directorio,
resultando electos, por un período de tres años, los señores Francisco Pérez Mackenna, Pablo Granifo Lavín, Rodrigo
Hinzpeter Kirberg, Carlos Molina Solís, María Gabriela Cadenas, Marc Gross, Rory Cullinan, Oscar Hásbún Martínez y
Vittorio Corbo Lioi siendo éste último elegido en calidad de director independiente de conformidad con lo dispuesto en el
artículo 50 bis de la Ley N° 18.046. El Presidente y Vicepresidente del Directorio, así como los integrantes del Comité de
Directores y Comité de Auditoría fueron designados en sesión de Directorio celebrada con igual fecha, resultando electo el
 78

[pág. 80]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
señor Francisco Pérez Mackenna en el cargo de Presidente y el señor Carlos Molina Solís en el de Vicepresidente. Conforme
a lo establecido en el artículo 50 bis de la Ley N° 18.046, el director independiente señor Vittorio Corbo Lioi designó a los
demás integrantes del Comité de Directores, lo que ocurrió en la misma sesión, el que quedó compuesto por los directores
señores Corbo, Molina y Hinzpeter. El Comité de Auditoría quedó compuesto por los directores señores Corbo y Molina,
quienes reúnen los requisitos de independencia aplicables según el criterio establecido en la Securities Exchange Act de
1934, Sarbanes-Oxley Act de 2002 y las normas del New York Stock Exchange. Asimismo, el Directorio resolvió que el
director señor Hinzpeter participe en las sesiones del Comité de Auditoría en calidad de observador.
En la referida Junta Ordinaria de Accionistas, se resolvió mantener la remuneración de los directores acordada en la Junta
Ordinaria de Accionistas anterior, consistente en una dieta mensual de UF 100 brutas para cada director y de UF 200 brutas
para el Presidente, por asistencia al Directorio, independiente del número de sesiones que se celebren en el período, más
una cantidad equivalente al 3% de los dividendos que se distribuyeren con cargo a las utilidades de la Compañía, para el
Directorio en su conjunto, calculados sobre un monto máximo equivalente al 50% de la utilidad líquida distribuible del
ejercicio, a razón de una novena parte para cada director y en proporción al tiempo que cada uno hubiere servido en el cargo
durante el año 2024.
En dicha Junta se acordó, asimismo, mantener la remuneración de los directores que integran el Comité de Directores,
consistente en una dieta mensual por asistencia, independiente del número de sesiones que se celebren en el período, de
UF 50 brutas, más lo que le corresponda como porcentaje de los dividendos hasta completar el tercio adicional que establece
el artículo 50 bis de la Ley N° 18.046 sobre Sociedades Anónimas y la Circular N° 1.956 de la Comisión para el Mercado
Financiero; y respecto de aquellos directores que forman parte del Comité de Auditoría, y los designados en calidad de
observadores del mismo, una dieta mensual, por asistencia, independiente del número de sesiones que se celebren en el
período, ascendente a UF 50 brutas.
Las remuneraciones de Directores y Ejecutivos principales de la Compañía se compone de la siguiente manera:
Remuneraciones Directores:
 Por los ejercicios terminados al 31 de diciembre de
 2024 2023 2022
 M$ M$ M$
 Comité de Auditoría 61.821 64.704 67.307
 Comité de Directores 65.341 82.379 75.494
 Dieta (*) 1.792.439 1.472.234 1.537.747
 Participación (*) 2.178.909 2.008.338 2.646.357
(*) Incluye dietas y participación devengadas en 2024 y 2023 de directora María Gabriela Cadenas.
Remuneraciones Ejecutivos principales:
 Por los ejercicios terminados al 31 de diciembre de
 2024 2023 2022
 M$ M$ M$
 Comité de Directores 18.585 23.177 20.084
 Dieta 222.709 193.382 224.474
 Participación 17.824 37.437 28.009
Las remuneraciones correspondientes al personal clave al 31 de diciembre de 2024, ascendieron a M$ 9.128.492
(M$ 11.118.126 en 2023 y M$ 9.183.120 en 2022). La Compañía otorga a los ejecutivos principales bonos anuales, de
carácter facultativo y variable, no contractual, que se asignan sobre la base del grado de cumplimiento de metas individuales
y corporativas, y en atención a los resultados del ejercicio.
 79

[pág. 81]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 12 Inventarios
Los saldos de inventario se componen como sigue:
 Al 31 de Al 31 de
 diciembre de diciembre de
 2024 2023
 M$ M$
Productos terminados 178.671.708 156.692.277
Productos en proceso 22.879.506 25.068.819
Materias primas 222.314.812 224.501.917
Existencias en tránsito 24.628.623 11.712.496
Materiales e insumos 15.498.353 13.523.712
Estimación a valor neto realizable y obsolescencia (4.608.447) (5.770.789)
Total 459.384.555 425.728.432
Durante los ejercicios terminados al 31 de diciembre de 2024, 2023 y 2022, la Compañía castigó con cargo a la estimación
a valor neto realizable y obsolescencia del rubro un total de M$ 7.930.817, M$ 5.212.799 y M$ 2.371.770, respectivamente.
Adicionalmente, se presenta una estimación por deterioro de las existencias que incluyen montos relativos a obsolescencia
derivados de la baja rotación, obsolescencia técnica y/o productos retirados del mercado.
El movimiento de la estimación antes mencionada es el siguiente:
 Al 31 de Al 31 de
 diciembre de diciembre de
 2024 2023
 M$ M$
Saldo inicial (5.770.789) (5.280.333)
Estimación por deterioro de inventario (6.769.193) (6.483.906)
Existencias dadas de baja 7.930.817 5.212.799
Efecto conversión 718 780.651
Total (4.608.447) (5.770.789)
Al 31 de diciembre de 2024 y 2023, la Compañía no tiene prendas sobre sus inventarios para garantizar obligaciones
financieras.
No existe inventarios no corriente al 31 de diciembre de 2024 y 2023, debido a que se encuentra disponible para la venta al
público una vez es producido. Las existencias para las que técnicamente su elaboración supone un ciclo superior a doce
meses suponen un total marginal.
 80

[pág. 82]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 13 Activos biológicos corrientes
La Compañía presenta en el rubro activos biológicos corriente el producto agrícola (uva) derivado de las plantaciones en
producción que tiene como destino ser un insumo para el proceso de producción de vinos.
Los costos asociados al producto agrícola (uva) son acumulados hasta la fecha de su cosecha.
Los activos biológicos corrientes se valorizan según lo descrito en Nota 2 - Resumen de las principales políticas
contables, 2.10.
La composición del saldo es la siguiente:
 M$
 Al 1 de enero de 2023
 Costo histórico 16.180.293
 Valor libro 16.180.293
 Al 31 de diciembre de 2023
 Efecto de conversión (2.006.357)
 Adquisiciones 30.554.114
 Disminuciones debidas a cosecha o recolección (30.547.833)
 Otros incrementos (disminuciones) (1) 584.067
 Subtotales (1.416.009)
 Valor libro 14.764.284
 Al 31 de diciembre de 2023
 Costo histórico 14.764.284
 Valor libro 14.764.284
 Al 31 de diciembre de 2024
 Efecto de conversión (173.046)
 Adquisiciones 34.634.429
 Disminuciones debidas a cosecha o recolección (33.400.203)
 Otros incrementos (disminuciones) (1) 1.057.642
 Subtotales 2.118.822
 Valor libro 16.883.106
 Al 31 de diciembre de 2024
 Costo histórico 16.883.106
 Valor libro 16.883.106
(1) Corresponde principalmente al efecto financiero de la aplicación de la IAS 29 “Información Financiera en Economías Hiperinflacionarias”.
 81

[pág. 83]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 14 Activos no corrientes mantenidos para la venta
a) Terrenos
- Con fecha 3 de marzo de 2021, el Directorio de Compañía Cervecerías Unidas S.A., autorizó el proceso de venta de
 porción de terreno, ubicado en la comuna de Quilicura, Región Metropolitana. La promesa de venta de este activo se
 firmó con fecha 3 de diciembre de 2021, sin embargo, esta promesa estaba condicionada al cumplimiento de condiciones
 legales y administrativas por parte de CCU y el prominente comprador, en relación a un proceso de subdivisión, fusión
 de dicho terreno y presentaciones habituales para este tipo de activo. Posteriormente, con fecha 22 de marzo de 2024,
 y una vez cumplidas las condiciones establecidas en la promesa antes descrita, se procedió a la firma de la escritura de
 venta.
 Con fecha 3 de abril de 2024, se concretó venta por M$ 49.681.035. Producto de esta operación, se generó una utilidad
 antes de impuestos a las ganancias ascendente a M$ 28.668.933 y un efecto de utilidad neta de M$ 20.928.321.
- Con fecha 4 de octubre de 2023, el Directorio de Compañía Cervecerías Unidas S.A., autorizó el proceso de venta del
 inmueble identificado como “sitio número dieciocho” ubicado en la comuna de Iquique, Región de Tarapacá. La promesa
 de venta de este activo se firmó con fecha 2 de noviembre de 2023, sin embargo, esta promesa estaba condicionada al
 cumplimiento de condiciones legales y administrativas por parte de CCU. Posteriormente y, una vez cumplidas las
 condiciones establecidas en la promesa antes descrita, con fecha 10 de septiembre de 2024 se firmó la compraventa
 definitiva, documento con el cual se procedió a reclasificar al rubro de Activos no corrientes mantenidos para la venta el
 activo antes descrito.
b) Segmento de Operación Negocios Internacionales
- En el mes de septiembre de 2015, el Directorio de la subsidiaria Sáenz Briones & Cía. S.A.I.C. autorizó la venta del
 inmueble ubicado en la ciudad de Luján de Cuyo, provincia de Mendoza, Argentina. A la fecha de emisión de estos
 Estados Financieros Consolidados la Gerencia de Administración y Finanzas sigue comprometida con un plan de venta
 de este inmueble. Para esto se ha realizado un cambio de la inmobiliaria para ser más activos con la búsqueda de un
 comprador y seguir manteniendo altas las probabilidades de venta.
- Con fecha 24 de junio de 2024, el Directorio de la subsidiaria Compañía Industrial Cervecera S.A. aprobó la venta del
 inmueble ubicado en el parque industrial de Pilar, provincia de Buenos Aires, fecha en que dicho inmueble se reclasificó
 desde Propiedades, plantas y equipos, por un total de M$ 2.183.871, contempla terrenos, construcciones y maquinarias.
 Con fecha 27 de agosto de 2024, se firmó contrato de compraventa, que se mantiene vigente al cierre de los presentes
 estados financieros.
c) Segmento de Operación Vinos
- En el mes de noviembre de 2022, el Directorio de Finca La Celia S.A. autorizó la venta del inmueble identificado como
 Finca Pocito, ubicado en la provincia de San Juan. Con fecha 1 de noviembre de 2022 se firmó el Boleto de Compraventa
 y, junto con la aceptación de la Oferta se materializó el pago parcial convenido y se entregó la tenencia del inmueble. Al
 cierre de estos Estados Financieros Consolidados, sólo queda pendiente la celebración de la escritura traslativa de
 dominio. El efecto de esta venta fue registrado en resultados en el año 2022.
Según se describe en Nota 2 - Resumen de las principales políticas contables, 2.18, los activos no corrientes mantenidos
para la venta han sido registrados al menor valor entre el valor libro y el valor razonable menos los costos de venta al 31 de
diciembre de 2024.
Los activos no corrientes mantenidos para la venta se detallan a continuación:
 Al 31 de Al 31 de
 diciembre de diciembre de
 Activos mantenidos para la venta 2024 2023
 M$ M$
 Terrenos 2.357.031 21.199.533
 Construcciones 591.128 236.886
 Maquinarias 4.123 13.979
 Plantaciones - 157.074
 Total 2.952.282 21.607.472
 82

[pág. 84]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 15 Combinaciones de negocios
a) D&D SpA.
Conforme a lo dispuesto en el contrato de compraventa de acciones celebrado con fecha 7 de junio de 2022 entre la
subsidiaria Compañía Pisquera de Chile S.A. (“CPCh”) como comprador, y por Panda SpA. y MBB SpA., como vendedores
“los Vendedores”, el 29 de diciembre de 2022 CPCh formalizó la adquisición del 51,0132% de las acciones de D&D SpA., a
través de la suscripción de un aumento de capital y luego con fecha 30 de diciembre de 2022 a través de la compra de
acciones a los Vendedores. Ambas operaciones sujetas al cumplimiento de ciertas condiciones, las cuales fueron resueltas
con fecha 20 de enero de 2023.
Dado lo anterior, con fecha 20 de enero de 2023, CPCh realiza el pago por la suma de M$ 1.250.000 (equivalente a 444
acciones a M$ 2.815,315 cada una), a su vez también suscribe y paga 135 acciones emitidas a propósito del aumento de
capital acordado en junta extraordinaria de accionistas de la sociedad, por la que pagó M$ 1.481,481 por cada acción
totalizando la suma de M$ 200.000, quedando así CPCh como titular de 579 acciones representativas del 51,0132% del total
de su capital social. A su vez las partes dejan expresa constancia que han convenido que este precio será objeto de un
incremento basado en los casos y formas señaladas en el contrato de compraventa de acciones.
Con fecha 14 de febrero de 2023, CPCh realiza pago a los Vendedores por M$ 750.000, correspondiente a primer incremento
de precio.
Adicionalmente, por esta combinación de negocios se reconocieron otros incrementos de precio, según lo indicado en
Nota 11 - Saldos y transacciones con partes relacionadas, numeral (4).
Para la combinación de negocios descrita anteriormente, se han determinado los valores razonables de los activos y pasivos
(Ver Nota 1 - Información general, letra C), numeral (5)).
b) Aguas de Origen S.A.
Con fecha 28 de abril de 2022, CCU a través de su subsidiaria, Compañía Cervecerías Unidas Argentina S.A. adquirió el
49% de la propiedad de Aguas Danone de Argentina S.A. (“ADA”), lo que incluye el negocio de aguas minerales, aguas
saborizadas y jugos en polvo con sus marcas Villavicencio, Villa del Sur, Levité, Ser y Brío (la “Transacción”). La Transacción
incluyó compraventas de acciones y aporte de capital en pesos argentinos por un total equivalente a USD 28,8 millones
(M$ 29.428.835).
Según escritura pública del 28 de abril de 2022, la subsidiaria Compañía Cervecerías Unidas Argentina S.A., adquirió 49.000
acciones ordinarias, nominativas no endosables de la sociedad Aguas de Origen S.A. (“ADO”), a un valor de un peso
argentino cada una, quedando con una participación de un 49% de esta sociedad. El pago de esta adquisición se hizo
efectivo el 26 de agosto de 2022.
Cabe señalar que ADO es la continuadora del negocio de Aguas Danone de Argentina S.A. lo que fue efectivo a partir del 1
de diciembre de 2022 como consecuencia de la escisión-fusión aprobada por asambleas de Aguas Danone de Argentina
S.A. y Aguas de Origen S.A. el 30 de junio de 2022.
Con fecha 30 de noviembre de 2022, se realizó una compra de 634.061 acciones equivalentes a M$ 542.974 a Holding
Internationale De Boissons S.A.S. lo que corresponde al 1% de las acciones de ADO, con lo cual desde esa fecha y hasta
el 30 de junio de 2024, la sociedad calificaba como un negocio conjunto de la Compañía.
Con fecha 28 de mayo de 2024, CCU Argentina S.A., notificó a Holding Internationale de Boissons S.A.S., el ejercicio de la
opción de compra de acciones, contenida en el acuerdo de accionistas, que le permitía a CCU Argentina S.A., adquirir la
cantidad de 8.471.349 acciones correspondientes al 0,1% de participación del negocio conjunto Aguas de Origen S.A.
Con fecha 1 de julio de 2024 Holding Internationale de Boissons S.A.S., notificó a CCU Argentina S.A., la aceptación del
ejercicio de la opción de compra de adquirir la cantidad de 8.471.349 correspondiente al 0,1% de acciones del negocio
conjunto Aguas de Origen S.A. Por tanto, desde el 1 de julio de 2024, CCU Argentina S.A., comenzó a consolidar la
información contable de Aguas de Origen S.A, al quedar con una participación accionaria del 50,1% y ejercer control sobre
esta sociedad.
 83

[pág. 85]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Para la combinación de negocios descrita anteriormente, se han determinado los valores razonables provisorios de los
activos y pasivos (Ver Nota 1 - Información general, letra C), numeral (12)).
c) AV S.A.
Con fecha 14 de octubre de 2024, Compañía Cervecerías Unidas S.A. (en adelante “CCU”) a través de sus subsidiarias CCU
Inversiones II SpA. y CCU Inversiones S.A., suscribió un contrato de acuerdos vinculantes y definitivos de asociación con
Grupo Vierci (en adelante “Vierci”), quien detenta la licencia de los bebestibles y la distribución de snacks de PepsiCo en
Paraguay, a través de sus sociedades AV S.A. y AJ S.A. Calidad Ante Todo (en adelante “AJ”).
Conforme a lo descrito en dicho contrato, las partes acordaron consolidar los negocios de CCU, Bebidas del Paraguay S.A.
(en adelante “BDP”) y Distribuidora del Paraguay S.A. (en adelante “DDP”) con el negocio del grupo Vierci, AV S.A. (en
adelante “AV”), considerando los siguientes hitos:
1.- Con la misma fecha, CCU a través de sus subsidiarias CCU Inversiones II SpA. y CCU Inversiones S.A. y Vierci, celebran
un Contrato de Permuta de Acciones de DDP a AV, en virtud del cual CCU entrega, y Vierci recibe el 49% de las acciones
de DDP y a la vez Vierci entrega y CCU recibe el 51% de las acciones de AV.
2.- Conforme a lo dispuesto en el contrato de transferencia de Unidad de Negocio, celebrado con esta misma fecha, entre
BDP y AJ, BDP adquiere la Unidad de Negocios Pepsi. Dicha unidad está compuesta por los activos, derechos, obligaciones,
contratos, licencias y franquicias de este nuevo negocio.
3.- Con la misma la fecha indicada, 14 de octubre de 2024, CCU y Vierci suscriben un contrato de Compraventa de Acciones,
en virtud del cual CCU vende y Vierci adquiere, la cantidad determinada de acciones de BDP necesarias para que luego de
cumplirse las estipulaciones definidas en este contrato Vierci quede con una participación del 49% de BDP.
Dentro de las estipulaciones que establece el contrato de compra venta de acciones, está la capitalización de la prima de
emisión, registrada en el patrimonio de BDP, por las cuales BDP emitió 11.843 nuevas acciones, que formaron parte del
paquete de acciones que CCU vendió a Vierci. Los títulos representativos de las acciones de BDP vendidas por CCU, se
entregaron a Vierci, una vez que la capitalización de la prima de acción fue formalizada, lo que ocurrió con fecha 11 de
diciembre de 2024.
El precio de venta de estas acciones ascendió a USD 17.979.350, equivalente a M$ 17.112.779, el que fue pagado de la
siguiente manera, el mismo 14 de octubre por un monto de USD 8.000.000 y el diferencial de USD 9.979.350, pagado con
fecha 11 de diciembre, que corresponde a la fecha de la entrega de los títulos a Vierci.
A la fecha de cierre de estos estados financieros aún no se han perfeccionado todas las estipulaciones del contrato, por lo
cual la participación al 31 de diciembre de 2024 de Vierci, sobre BDP es de un 43%.
Para la combinación de negocios descrita anteriormente, se han determinado los valores razonables provisorios de los
activos y pasivos (Ver Nota 1 - Información general, letra C), numeral (4)).
 84

[pág. 86]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 16 Inversiones contabilizadas por el método de la participación
Negocios conjuntos y Asociadas
La Compañía registra bajo este rubro sus inversiones en sociedades que califican como negocios conjuntos y asociadas.
El valor proporcional de las inversiones en negocios conjuntos y asociadas es el siguiente:
 Al 31 de Al 31 de
 Porcentaje de
 diciembre de diciembre de
 participación
 2024 2023
 % M$ M$
 Cervecería Austral S.A. 50,00 14.909.658 12.650.998
 Central Cervecera de Colombia S.A.S. 50,00 17.676.953 19.793.183
 Zona Franca Central Cervecera S.A.S. 50,00 105.346.786 106.768.550
 Aguas de Origen S.A. (*) 50,00 - 8.636.461
 Total negocios conjuntos 137.933.397 147.849.192
 Aguas Danone de Argentina S.A. 49,00 917.067 880.815
 Otras sociedades 896.457 863.173
 Total asociadas 1.813.524 1.743.988
 Total 139.746.921 149.593.180
(*) Negocio conjunto de subsidiaria hasta el 30 de junio de 2024.
Los valores antes mencionados incluyen la plusvalía generada en la adquisición de los siguientes negocios conjuntos y
asociadas, que se presentan netos de cualquier pérdida por deterioro:
 Al 31 de Al 31 de
 diciembre de diciembre de
 2024 2023
 M$ M$
 Cervecería Austral S.A. 1.894.770 1.894.770
 Aguas Danone de Argentina S.A. - 72.589
 Aguas de Origen S.A. (*) - 3.017.505
 Total 1.894.770 4.984.864
(*) Negocio conjunto de subsidiaria hasta el 30 de junio de 2024.
La participación en utilidad (pérdida) de negocios conjuntos y asociadas contabilizados por el método de la participación son
las siguientes:
 Por los ejercicios terminados al 31 de diciembre de
 2024 2023 2022
 M$ M$ M$
 Central Cervecera de Colombia S.A.S. (11.959.652) (10.565.966) (9.410.015)
 Zona Franca Central Cervecera S.A.S. 266.580 (1.710.319) (1.965.827)
 Aguas de Origen S.A. (*) (6.782) (9.695.813) 2.533.720
 Cervecería Austral S.A. 2.911.947 2.802.039 2.829.304
 Total negocios conjuntos (8.787.907) (19.170.059) (6.012.818)
 Aguas Danone de Argentina S.A. (651.872) (45.336) (5.272.903)
 Otras sociedades (54.924) (2.363) 307.653
 Total asociadas (706.796) (47.699) (4.965.250)
 Total (9.494.703) (19.217.758) (10.978.068)
(*) Negocio conjunto de subsidiaria hasta el 30 de junio de 2024.
 85

[pág. 87]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Los cambios en las inversiones en negocios conjuntos y asociadas son los siguientes:
 Al 31 de Al 31 de
 diciembre de diciembre de
 2024 2023
 M$ M$
Saldo al inicio 149.593.180 140.926.012
Aportes de Capital para adquirir participaciones en negocios conjuntos 10.658.097 7.086.899
Participación en utilidad (pérdida) de negocios conjuntos y asociadas contabilizados por el método de la participación (9.494.703) (19.217.758)
Dividendos (854.084) (908.640)
Inversión tenida anteriormente (1) (15.128.327) -
Otros (*) 4.972.758 21.706.667
Total 139.746.921 149.593.180
(*) Incluye principalmente efectos por la conversión de los negocios conjuntos.
(1) Ver Nota 1 – Información general, letra C), numeral (12).
En relación a las inversiones contabilizadas bajo el método de participación, cabe mencionar lo siguiente:
(1) Cervecería Austral S.A.
Es una sociedad anónima cerrada que opera una planta elaboradora de cerveza en el extremo sur de Chile, siendo la
cervecera más austral del mundo.
(2) Central Cervecera de Colombia S.A.S. y Zona Franca Central Cervecera S.A.S.
Con fecha 10 de noviembre de 2014, CCU, a través de su subsidiaria CCU Inversiones II SpA., y Grupo Postobón se
asociaron en un acuerdo conjunto, que califica como un negocio conjunto a través de una sociedad por acciones constituida
en Colombia denominada Central Cervecera de Colombia S.A.S. (“CCC”), en la cual CCU Inversiones II SpA. y Grupo
Postobón participan como únicos accionistas en partes iguales. El objeto de CCC, en dicho país, es la elaboración,
comercialización y distribución de cervezas y bebidas no alcohólicas en base a malta (Productos).
Posteriormente, con fecha 16 de agosto de 2017, CCU, a través de su subsidiaria CCU Inversiones ll SpA., adquirió el 50%
de las acciones de una sociedad por acciones constituida en Colombia denominada Zona Franca Central Cervecera S.A.S.
(“ZF CC”), que se relaciona a un acuerdo conjunto y que califica como un negocio conjunto, en la cual CCU y Grupo Postobón
participan como únicos accionistas en partes iguales. El precio de la transacción ascendió a USD 10.204, equivalente a
M$ 6.432. El objeto principal de ZF CC es actuar exclusivamente como usuario industrial de una o varias zonas francas,
produciendo y vendiendo productos tanto de marcas propias como licenciadas a CCC, donde esta última realiza el proceso
de comercialización de dichos productos.
Para los efectos antes indicados, las asociaciones anteriores consideran la construcción de una planta de producción de
cervezas y maltas en zona franca, con una capacidad inicial de 3.000.000 de hectolitros anuales.
Al 31 de diciembre de 2024 y 31 de diciembre de 2023 el monto por aportes de capital a CCC y a ZF CC asciende a
USD 315.150.660 y USD 304.170.191 (equivalentes a M$ 216.941.694 y M$ 206.283.598 según los tipos de cambio a las
fechas de los aportes), respectivamente. Durante el año 2024, se realizó aporte de capital por MCOP 43.000.000, equivalente
a M$ 10.658.097, a través de un cronograma de pagos, donde se liquidó la primera cuota el 22 de febrero de 2024 por el
monto de USD 3.050.330, equivalente a M$ 2.951.256, la segunda cuota el 21 de marzo de 2024 por el monto de
USD 6.417.661, equivalente a M$ 6.263.060 y la tercera cuota el 25 de abril de 2024 por el monto de USD 1.512.478,
equivalente a M$ 1.443.781 (Ver Nota 11 – Saldos y transacciones con partes relacionadas).
(3) Aguas Danone de Argentina S.A. y Aguas de Origen S.A.
Con fecha 30 de marzo de 2023, en Junta Extraordinaria de Accionistas de ADO, se acordó aumento de capital y fijación de
una prima de emisión de acciones por parte del accionista Holding Internationale De Boissons S.A.S., dando lugar a un
aumento de capital social de ARS 1 y a una prima de emisión de acciones por ARS 80.158.267 (equivalentes a M$ 304.411).
En otra Junta Extraordinaria celebrada el mismo día la subsidiaria Compañía Cervecerías Unidas Argentina S.A., realizó
también un aporte de capital social de ARS 1, en consecuencia, ambos accionistas mantuvieron la misma participación en
esta sociedad.
 86

[pág. 88]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Con fecha 6 de junio de 2023, en Junta Extraordinaria de Accionistas de ADO se acordó: (i) capitalizar el saldo existente en
la cuenta de ajuste de capital por la suma de ARS 59.643, emitiéndose acciones liberadas que fueron adjudicadas a los
accionistas Compañía Cervecerías Unidas Argentina S.A. y Holding Internationale de Boissons S.A.S. en proporción a sus
tenencias accionarias; y (ii) aprobar un aumento de capital por la suma de ARS 29.142.000 (equivalentes a M$ 95.601), el
cual fue suscrito e integrado por la subsidiaria Compañía Cervecerías Unidas Argentina S.A. y accionista Holding
Internationale de Boissons S.A.S. en proporción a sus tenencias accionarias. En consecuencia, ambos accionistas
mantuvieron misma participación en esta sociedad.
Con fecha 27 de septiembre de 2023, en Junta Extraordinaria de Accionistas de ADO, se aprobó un aumento de capital
social por la suma de ARS 1 con una prima de emisión por la suma de ARS 1.688.179.074 (equivalentes a M$ 4.373.920) el
cual fue suscrito e integrado en su totalidad por la subsidiaria Compañía Cervecerías Unidas Argentina S.A. En otra Junta
Extraordinaria de Accionistas celebrada el mismo día, se aprobó un aumento de capital por la suma de ARS 1 el cual fue
suscrito e integrado en su totalidad por el accionista Holding Internationale De Boissons S.A.S., en consecuencia, ambos
accionistas mantuvieron la misma participación en esta sociedad.
Con fecha 25 de octubre de 2023, en Junta Extraordinaria de Accionistas de ADO, se aprobó un aumento de capital social
por la suma de ARS 62.811.000 (equivalentes a M$ 159.661) el cual fue suscrito e integrado en partes iguales por la
subsidiaria Compañía Cervecerías Unidas Argentina S.A. y por el accionista Holding Internationale De Boissons S.A.S.
Con fecha 21 de diciembre de 2023, en Junta Extraordinaria de Accionistas de ADO, se aprobó un aumento de capital social
por la suma de ARS 80.385.000 (equivalentes a M$ 86.937) el cual fue suscrito e integrado en partes iguales por la subsidiaria
Compañía Cervecerías Unidas Argentina S.A. y por el accionista Holding Internationale De Boissons S.A.S.
Con fecha 28 de mayo de 2024, CCU Argentina S.A., notificó a Holding Internationale de Boissons S.A.S., el ejercicio de la
opción de compra de acciones, contenida en el acuerdo de accionistas, que le permitía a CCU Argentina S.A., adquirir la
cantidad de 8.471.349 acciones correspondientes al 0,1% de participación del negocio conjunto Aguas de Origen S.A.
Con fecha 1 de julio de 2024 Holding Internationale de Boissons S.A.S., notificó a CCU Argentina S.A., la aceptación del
ejercicio de la opción de compra de adquirir la cantidad de 8.471.349 acciones correspondiente al 0,1% de participación del
negocio conjunto Aguas de Origen S.A.
Por tanto, desde el 1 de julio de 2024, CCU Argentina S.A., comenzó a consolidar la información contable de Aguas de
Origen S.A, al quedar con una participación accionaria del 50,1%, y ejercer control sobre esta sociedad (Ver Nota 1 -
Información general, letra C), numeral (12)).
La Compañía no tiene pasivos contingentes relacionados con los negocios conjuntos y asociadas al 31 de diciembre de
2024.
A continuación, se presentan en forma resumida, las partidas significativas de los Estados Financieros de la principal
asociada y negocios conjuntos al cierre de cada ejercicio:
 Asociada Negocios conjuntos
 Al 31 de Al 31 de Al 31 de Al 31 de
 diciembre de diciembre de diciembre de diciembre de
 2024 2023 2024 2023
 M$ M$ M$ M$
Activos y Pasivos
Activos corrientes 130.158 120.150 85.454.616 130.488.940
Activos no corrientes 3.229.224 1.871.190 323.251.454 360.977.091
Pasivos corrientes 350.258 101.254 123.265.925 106.403.754
Pasivos no corrientes 1.137.511 240.587 10.187.080 96.312.931
 87

[pág. 89]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
 Asociada Negocios conjuntos
 Por los ejercicios terminados al 31 de diciembre de
 2024 2023 2024 2023 2022
 M$ M$ M$ M$ M$
Estado de Resultados (Resumidos)
Ventas netas 175.369 120.587 454.581.166 260.993.102 327.979.632
Resultados operacionales 130.420 (180.321) (3.922.885) (9.292.789) (8.895.582)
Utilidad (pérdida) del ejercicio (1.340.072) (92.524) (16.865.965) (12.227.357) (14.228.664)
Resultado Integral 1.668.405 (908.241) 17.274.249 (11.459.814) (28.781.782)
Depreciación y amortización (235.294) (180.254) (22.286.843) (16.717.848) (16.901.777)
 88

[pág. 90]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 17 Activos intangibles distintos de plusvalía
El movimiento de los activos intangibles, es el siguiente:
 Derechos de
 Marcas Programas Derechos de
 distribución y de Total
 comerciales informáticos agua
 llaves
 M$ M$ M$ M$ M$
 Al 1 de enero de 2023
 Costo histórico 142.547.210 57.375.791 3.199.349 3.569.831 206.692.181
 Amortización acumulada - (33.395.900) - (906.609) (34.302.509)
 Valor libro 142.547.210 23.979.891 3.199.349 2.663.222 172.389.672
 Al 31 de diciembre de 2023
 Adiciones - 7.250.921 - - 7.250.921
 Adiciones por combinaciones de negocios (costo histórico) (2) 1.962.891 - - - 1.962.891
 Bajas (costo histórico) - (81.475) - - (81.475)
 Bajas (amortización) - 74.540 - - 74.540
 Amortización del ejercicio - (10.053.940) - (161.248) (10.215.188)
 Efecto de conversión (costo histórico) (45.306.098) (1.838.630) - (110.812) (47.255.540)
 Efecto de conversión (amortización) - 726.017 - 199.821 925.838
 Otros incrementos (disminuciones) (1) 27.807.102 245.218 - 19.228 28.071.548
 Subtotales (15.536.105) (3.677.349) - (53.011) (19.266.465)
 Valor libro 127.011.105 20.302.542 3.199.349 2.610.211 153.123.207
 Al 31 de diciembre de 2023
 Costo histórico 127.011.105 62.951.825 3.199.349 3.478.247 196.640.526
 Amortización acumulada - (42.649.283) - (868.036) (43.517.319)
 Valor libro 127.011.105 20.302.542 3.199.349 2.610.211 153.123.207
 Al 31 de diciembre de 2024
 Adiciones 251.755 11.267.169 - - 11.518.924
 Adiciones por combinaciones de negocios (costo histórico) (3) 25.481.126 157.532 - 12.106.585 37.745.243
 Adiciones por combinaciones de negocios (amortización) (3) - (71.682) - - (71.682)
 Bajas (costo histórico) (344.502) (199.218) - - (543.720)
 Bajas (amortización) - 80.639 - - 80.639
 Amortización del ejercicio - (6.463.401) - (184.178) (6.647.579)
 Efecto de conversión (amortización) - (17.867) - (408) (18.275)
 Efecto de conversión (costo histórico) (2.395.767) (143.898) - 985.301 (1.554.364)
 Otros incrementos (disminuciones) (1) 46.590.094 4.456.319 - (46.085) 51.000.328
 Subtotales 69.582.706 9.065.593 - 12.861.215 91.509.514
 Valor libro 196.593.811 29.368.135 3.199.349 15.471.426 244.632.721
 Al 31 de diciembre de 2024
 Costo histórico 196.593.811 78.489.729 3.199.349 16.524.048 294.806.937
 Amortización acumulada - (49.121.594) - (1.052.622) (50.174.216)
 Valor libro 196.593.811 29.368.135 3.199.349 15.471.426 244.632.721
(1) Corresponde principalmente al efecto financiero de la aplicación de la IAS 29 “Información Financiera en Economías Hiperinflacionarias”.
(2) Ver Nota 1 - Información general, letra C), numeral (5).
(3) Ver Nota 1 - Información general, letra C), numerales (4) y (12).
La Compañía no mantiene en prenda ni tiene restricciones sobre los intangibles.
 89

[pág. 91]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
El detalle por Unidad Generadora de Efectivo asociado a las marcas comerciales se presenta a continuación:
 Al 31 de Al 31 de
 Unidad Generadora de Efectivo diciembre de diciembre de
 Segmento de operación 2024 2023
 (UGE) M$ M$
 Chile Embotelladoras Chilenas Unidas S.A. 34.177.235 33.181.320
 Manantial S.A. 1.166.000 1.166.000
 Compañía Pisquera de Chile S.A. 1.363.782 1.363.782
 D&D SpA. (1) 1.962.891 1.962.891
 Cervecería Kunstmann S.A. 14.166.999 13.915.244
 Cervecería Szot SpA. - 344.502
 Cervecera Guayacán SpA. 804.705 804.705
 Subtotales 53.641.612 52.738.444
 Negocios Internacionales CCU Argentina S.A. y subsidiarias (2) 108.477.721 41.041.119
 Marzurel S.A. y Milotur S.A. 2.796.692 2.779.956
 Bebidas del Paraguay S.A. y Distribuidora del Paraguay S.A. 3.859.274 3.680.609
 Bebidas Bolivianas BBO S.A. 7.811.229 6.875.725
 Subtotales 122.944.916 54.377.409
 Vinos Viña San Pedro Tarapacá S.A. 20.007.283 19.895.252
 Subtotales 20.007.283 19.895.252
 Total 196.593.811 127.011.105
(1) Ver Nota 1 - Información general, letra C), numeral (5).
(2) Ver Nota 1 - Información general, letra C), numeral (12).
En relación a las pérdidas por deterioro de valor de los activos intangibles, la Administración ha efectuado los test de
deterioros, de los cuales no han surgido deterioros. Respecto de las Marcas comerciales con vida útil indefinida, se ha
utilizado la misma metodología que se señala en Nota 18 - Plusvalía.
 90

[pág. 92]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 18 Plusvalía
El movimiento de la plusvalía es el siguiente:
 Plusvalía
 M$
 Al 1 de enero de 2023
 Costo histórico 136.969.434
 Valor libro 136.969.434
 Al 31 de diciembre de 2023
 Adiciones por combinaciones de negocios (2) 2.100.677
 Otros incrementos (disminuciones) (1) 18.776.632
 Efecto de conversión (30.254.687)
 Subtotales (9.377.378)
 Valor libro 127.592.056
 Al 31 de diciembre de 2023
 Costo histórico 127.592.056
 Valor libro 127.592.056
 Al 31 de diciembre de 2024
 Adiciones por combinaciones de negocios (3) 5.557.026
 Otros incrementos (disminuciones) (1) 29.770.740
 Efecto de conversión (1.336.589)
 Subtotales 33.991.177
 Valor libro 161.583.233
 Al 31 de diciembre de 2024
 Costo histórico 161.583.233
 Valor libro 161.583.233
(1) Corresponde principalmente al efecto financiero de la aplicación de la IAS 29 “Información Financiera en Economías Hiperinflacionarias”.
(2) Ver Nota 1 - Información general, letra C), numeral (5).
(3) Ver Nota 1 - Información general, letra C), numeral (12).
 91

[pág. 93]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
La plusvalía de inversiones adquiridas en combinaciones de negocios son asignadas a la fecha de adquisición a las Unidades
Generadoras de Efectivo (UGE) o grupo de UGEs que se espera se beneficien de las sinergias de la combinación de
negocios. El valor libro de la plusvalía de inversiones asignadas a las UGEs dentro de los segmentos de la Compañía son
los siguientes:
 Al 31 de Al 31 de
 Unidad Generadora de Efectivo diciembre de diciembre de
 Segmento de operación 2024 2023
 (UGE) M$ M$
 Chile Embotelladoras Chilenas Unidas S.A. 25.257.686 25.257.686
 Manantial S.A. 8.879.245 8.879.245
 Compañía Pisquera de Chile S.A. 9.808.550 9.808.550
 Los Huemules S.R.L. 480 509
 D&D SpA. (1) 2.100.677 2.100.677
 Cervecera Guayacán SpA. 456.007 456.007
 Cervecería Szot SpA. (2) - 202.469
 Subtotales 46.502.645 46.705.143
 Negocios Internacionales CCU Argentina S.A. y subsidiarias 54.647.107 27.727.792
 Aguas de Origen S.A. (3) 5.557.026 -
 Marzurel S.A. y Milotur S.A. 5.186.877 5.155.840
 Bebidas del Paraguay S.A. y Distribuidora del Paraguay S.A. 5.702.154 5.401.679
 Bebidas Bolivianas BBO S.A. 11.571.280 10.185.458
 Subtotales 82.664.444 48.470.769
 Vinos Viña San Pedro Tarapacá S.A. 32.416.144 32.416.144
 Subtotales 32.416.144 32.416.144
 Total 161.583.233 127.592.056
(1) Ver Nota 1 - Información general, letra C), numeral (5).
(2) Ver Nota 1 - Información general, letra C), numeral (10).
(3) Ver Nota 1 - Información general, letra C), numeral (12).
La Plusvalía de inversión asignada a las UGEs es sometida a pruebas de deterioro anualmente, o con mayor frecuencia si
existen signos de un potencial deterioro. Estos indicios pueden incluir un cambio significativo en el entorno económico que
afecten a los negocios, nuevas disposiciones legales, indicadores de desempeño operativo o la enajenación de una parte
importante de una UGE. La pérdida por deterioro se reconoce por el monto que excede el monto recuperable de la UGE. El
valor recuperable de cada UGE es determinado como el mayor entre su valor en uso o valor razonable menos los costos de
venta. La Administración considera que el enfoque del valor en uso, determinado mediante el modelo de flujos de caja
descontados, es el método más fiable para determinar los valores recuperables de las UGEs.
La siguiente tabla incorpora las variables más relevantes para aquellas UGEs donde existe Plusvalía y/o Activos intangibles
de vida útil indefinida asignados de relevancia:
 Chile Argentina Uruguay Paraguay Bolivia
 CAPEX estimado año 2025 MM$ 145.087 32.089 2.553 10.367 3.364
 Crecimiento perpetuidad 3,00% 4,00% 5,00% 4,00% 4,38%
 Tasa de descuento 8,26% 20,03% 9,26% 10,71% 15,91%
A continuación, se describen algunas consideraciones aplicadas al momento de determinar los correspondientes valores en
uso de las UGE que tienen Plusvalía y/o Activos intangibles de vida útil indefinida asignados:
Periodo de proyección: Se considera un horizonte de cinco años para todas las unidades/marcas. Se considera
excepcionalmente un periodo de tiempo más prolongado en aquellas unidades/marcas que requieren un periodo de
maduración mayor.
 92

[pág. 94]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Flujos: Para la determinación del valor en uso, la Compañía ha utilizado proyecciones de flujos de efectivo sobre el horizonte
de tiempo descrito precedentemente, basado en los presupuestos, planes estratégicos y proyecciones revisadas por la
Administración para igual periodo de tiempo. Dada la madurez del negocio, dichos presupuestos históricamente han tenido
altas tasas de cumplimiento.
Para la proyección de los flujos de caja, la administración incluyó juicios y suposiciones importantes relacionadas con tasas
de crecimiento perpetuo y tasas de descuento.
Crecimiento perpetuidad: Si bien la Compañía espera crecimiento de volúmenes y precios para el mediano largo plazo, se
asumió un crecimiento nominal de 3% para la perpetuidad de las unidades de Chile, supuesto conservador considerando la
capacidad histórica y la naturaleza de los negocios donde opera la Compañía. Para el caso de Uruguay se utiliza un 5%
correspondiente a la inflación de largo plazo del país. Para Paraguay, se emplea una tasa de perpetuidad del 4%, consistente
con la inflación de largo plazo del país. Para Bolivia se utiliza una tasa de perpetuidad de un 4,4% equivalente a la inflación
de largo plazo del país, más un % del PIB potencial en el largo plazo. En el caso de Argentina se utiliza una tasa de
perpetuidad de un 4%, la cual se componen por la tasa de inflación promedio de Estados Unidos de Norteamérica, más un
% del PIB potencial de cada país en el largo plazo.
Tasa de descuento: Se utilizó la tasa WACC (Weighted Average Cost of Capital) nominal correspondiente a cada país.
Conforme las sensibilidades calculadas en base a las variables de tasas de descuento y crecimiento a perpetuidad, la
Administración determina que ningún cambio razonablemente posible en los supuestos probados podría provocar que el
valor en libros exceda el valor recuperable. En relación a la plusvalía al 31 de diciembre de 2024, la Administración no ha
evidenciado indicios de deterioro.
 93

[pág. 95]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 19 Propiedades, plantas y equipos
El movimiento de las propiedades, plantas y equipos, es el siguiente:
 Activos en
 Terrenos, edificios y Maquinarias y Envases y Muebles, enseres y
 Otros Equipos construcción y vides Vides en producción Total
 construcción equipos contenedores vehículos
 en formación
 M$ M$ M$ M$ M$ M$ M$ M$
 Al 1 de enero de 2023
 Costo histórico 862.106.306 813.091.440 253.015.079 164.415.831 211.047.748 91.014.222 48.703.198 2.443.393.824
 Depreciación acumulada (280.605.555) (443.288.574) (169.929.241) (113.197.301) - (61.286.848) (18.240.003) (1.086.547.522)
 Valor libro 581.500.751 369.802.866 83.085.838 51.218.530 211.047.748 29.727.374 30.463.195 1.356.846.302
 Al 31 de diciembre de 2023
 Adiciones - - - - 138.289.044 - - 138.289.044
 Adiciones por combinaciones de negocios (costo histórico) (2) 181.006 534.269 - - - 79.094 - 794.369
 Adiciones por combinaciones de negocios (depreciación) (2) (18.054) (100.613) - - - (20.076) - (138.743)
 Transferencias 48.036.193 67.714.703 26.923.762 18.748.098 (174.281.473) 12.850.863 7.854 -
 Transferencias a Activos no corrientes mantenidos para la venta (costo histórico) (3) (20.207.777) - - - - - - (20.207.777)
 Efecto conversión (costo histórico) (63.104.205) (113.528.101) (67.485.035) (15.443.833) (30.065.398) (1.280.069) (6.081.394) (296.988.035)
 Enajenación (costo) (409.818) (3.694.017) (1.745.448) (1.013.849) - (469.211) - (7.332.343)
 Enajenación (depreciación) 375.578 3.245.257 1.568.049 1.013.399 - 433.053 - 6.635.336
 Intereses capitalizados - - - - 761.764 - - 761.764
 Depreciación del ejercicio (24.989.553) (33.391.578) (21.216.223) (13.532.247) - (9.853.805) (1.982.689) (104.966.095)
 Efecto conversión (depreciación) 3.365.254 16.180.666 26.110.062 9.095.329 - 280.915 900.299 55.932.525
 Otros incrementos (disminuciones) (1) 36.545.275 63.049.635 25.926.231 2.886.596 13.403.899 65.091 3.686.922 145.563.649
 Bajas del ejercicio (costo) (1.916.386) (2.683.843) (7.033.035) (3.109.155) - (577.033) (2.919.093) (18.238.545)
 Bajas del ejercicio (depreciación) 1.823.097 2.519.811 6.862.886 2.917.906 - 519.197 2.393.347 17.036.244
 Subtotales (20.319.390) (153.811) (10.088.751) 1.562.244 (51.892.164) 2.028.019 (3.994.754) (82.858.607)
 Valor libro 561.181.361 369.649.055 72.997.087 52.780.774 159.155.584 31.755.393 26.468.441 1.273.987.695
 Al 31 de diciembre de 2023
 Costo histórico 861.973.319 829.082.360 229.128.739 167.059.351 159.155.584 102.103.144 44.781.726 2.393.284.223
 Depreciación acumulada (300.791.958) (459.433.305) (156.131.652) (114.278.577) - (70.347.751) (18.313.285) (1.119.296.528)
 Valor libro 561.181.361 369.649.055 72.997.087 52.780.774 159.155.584 31.755.393 26.468.441 1.273.987.695
 Al 31 de diciembre de 2024
 Adiciones - - - - 151.398.096 - - 151.398.096
 Adiciones por combinaciones de negocios (costo histórico) (2) 88.470.136 72.966.245 2.649.396 8.561.542 551.780 4.057.829 - 177.256.928
 Adiciones por combinaciones de negocios (depreciación) (2) (84.333.663) (67.937.215) (2.480.683) (5.769.867) - (2.067.644) - (162.589.072)
 Transferencias 62.753.106 85.199.469 18.204.523 21.287.171 (207.075.134) 12.757.139 6.873.726 -
 Transferencias a Activos no corrientes mantenidos para la venta (costo histórico) (3) (506.853) - - - - - - (506.853)
 Efecto conversión (costo histórico) (9.232.020) (13.285.027) (5.496.314) 330.494 (1.244.492) (65.992) (601.347) (29.594.698)
 Enajenación (costo) (83.937) (2.982.441) (2.818.278) (1.010.239) - (522.389) - (7.417.284)
 Enajenación (depreciación) 82.156 2.799.668 2.714.634 993.355 - 498.166 - 7.087.979
 Intereses capitalizados - - - - 897.679 - - 897.679
 Depreciación del ejercicio (27.890.418) (47.667.987) (29.209.087) (17.226.695) - (10.169.683) (2.420.023) (134.583.893)
 Efecto conversión (depreciación) 5.517.420 3.330.929 1.335.164 (402.828) - (80.968) 125.371 9.825.088
 Otros incrementos (disminuciones) (1) 63.120.877 105.791.787 40.340.406 4.979.101 17.290.371 1.737.930 4.840.400 238.100.872
 Bajas del ejercicio (costo) (140.144) (978.499) (9.870.685) (7.368.902) - (2.292.147) (1.429.284) (22.079.661)
 Bajas del ejercicio (depreciación) 140.084 816.166 9.563.494 7.177.329 - 2.066.297 1.162.203 20.925.573
 Subtotales 97.896.744 138.053.095 24.932.570 11.550.461 (38.181.700) 5.918.538 8.551.046 248.720.754
 Valor libro 659.078.105 507.702.150 97.929.657 64.331.235 120.973.884 37.673.931 35.019.487 1.522.708.449
 Al 31 de diciembre de 2024
 Costo histórico 1.068.381.138 1.079.935.259 273.594.861 194.175.897 120.973.884 118.295.809 57.107.074 2.912.463.922
 Depreciación acumulada (409.303.033) (572.233.109) (175.665.204) (129.844.662) - (80.621.878) (22.087.587) (1.389.755.473)
 Valor libro 659.078.105 507.702.150 97.929.657 64.331.235 120.973.884 37.673.931 35.019.487 1.522.708.449
(1) Corresponde principalmente al efecto financiero de la aplicación de la IAS 29 “Información Financiera en Economías Hiperinflacionarias”.
(2) Ver Nota 1 - Información general, letra C), numeral (5) para 2023 y numerales (4) y (12) para 2024.
(3) Ver Nota 14 - Activos no corrientes mantenidos para la venta.
 94

[pág. 96]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
El saldo de los terrenos al cierre de cada ejercicio es el siguiente:
 Al 31 de Al 31 de
 diciembre de diciembre de
 2024 2023
 M$ M$
 Terrenos 277.836.130 253.143.223
 Total 277.836.130 253.143.223
Los costos por intereses capitalizados durante el ejercicio terminado al 31 de diciembre de 2024 ascendieron a
M$ 897.679 (M$ 761.764 en 2023 y M$ 797.442), utilizando una tasa de capitalización del 3,25 % anual (3,15% en 2023 y
3,64% 2022).
La Compañía, a través de su subsidiaria Viña San Pedro Tarapacá S.A., posee activos biológicos correspondientes a vides.
Las vides en producción son cultivadas tanto en tierras arrendadas como propias. La uva cosechada de estas vides es
utilizada en la elaboración de vinos, comercializados tanto en el mercado doméstico como en el extranjero.
Al 31 de diciembre de 2024, la Sociedad mantiene aproximadamente 4.751 hectáreas de cultivos de vides (en producción y
en inversión), de las cuales 4.300 corresponden a vides en estado productivo. Del total de las hectáreas antes mencionadas
4.139 corresponden a tierras propias y 161 a tierras arrendadas.
Las vides en formación son registradas al costo histórico y sólo comienzan a ser depreciadas cuando son transferidas a la
fase de producción, lo cual ocurre en la mayoría de los casos al tercer año de plantadas, cuando las parras comienzan a
producir uva en forma comercial (en volúmenes que justifican los manejos orientados a la producción y su posterior cosecha).
Durante el año 2024 las plantaciones de vides en producción permitieron cosechar un total aproximado de 70,0 millones de
kilos de uva (63,5 millones de kilos de uva durante el ejercicio 2023).
Por la naturaleza de los negocios de la Sociedad, en el valor de los activos no se considera al inicio una estimación por costo
de desmantelamiento, retiro o rehabilitación.
En relación a las pérdidas por deterioro de Propiedades, plantas y equipos, la Administración ha analizado indicadores
internos y externos y no ha evidenciado indicios de deterioro en éstos al 31 de diciembre de 2024.
La depreciación del ejercicio terminado al 31 de diciembre de 2024 y 2023, registrada en resultado y otros activos es la
siguiente:
 Al 31 de Al 31 de
 diciembre de diciembre de
 2024 2023
 M$ M$
 Registrada en resultado del ejercicio (*) 133.733.218 103.974.693
 Registrada en otros activos 850.675 991.402
 Total 134.583.893 104.966.095
3
(*) Adicionalmente a este monto, en resultado hay registrado M$ 1.092.661 (M$ 1.724.762 en 2023) principalmente de depreciación de activos
agrícolas (barricas), asociado al costo de venta de vino.
 95

[pág. 97]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 20 Propiedades de inversión
El movimiento de propiedades de inversión, es el siguiente:
 Terrenos Edificios Total
 M$ M$ M$
 Al 1 de enero de 2023
 Costo histórico 7.661.029 3.550.177 11.211.206
 Depreciación acumulada - (927.212) (927.212)
 Valor libro 7.661.029 2.622.965 10.283.994
 Al 31 de diciembre de 2023
 Adiciones - 36.101 36.101
 Depreciación del ejercicio - (72.250) (72.250)
 Efecto conversión (costo) (4.013.380) (1.497.425) (5.510.805)
 Efecto conversión (depreciación) - 117.411 117.411
 Otros incrementos (disminuciones) (1) 2.468.404 798.301 3.266.705
 Subtotales (1.544.976) (617.862) (2.162.838)
 Valor libro 6.116.053 2.005.103 8.121.156
 Al 31 de diciembre de 2023
 Costo histórico 6.116.053 2.887.154 9.003.207
 Depreciación acumulada - (882.051) (882.051)
 Valor libro 6.116.053 2.005.103 8.121.156
 Al 31 de diciembre de 2024
 Adiciones - 104.837 104.837
 Depreciación del ejercicio - (117.496) (117.496)
 Efecto conversión (costo) (395.391) (143.640) (539.031)
 Efecto conversión (depreciación) - 8.647 8.647
 Otros incrementos (disminuciones) (1) 3.791.970 1.296.897 5.088.867
 Subtotales 3.396.579 1.149.245 4.545.824
 Valor libro 9.512.632 3.154.348 12.666.980
 Al 31 de diciembre de 2024
 Costo histórico 9.512.632 4.145.248 13.657.880
 Depreciación acumulada - (990.900) (990.900)
 Valor libro 9.512.632 3.154.348 12.666.980
(1) Corresponde principalmente al efecto financiero de la aplicación de la IAS 29 “Información Financiera en Economías Hiperinflacionarias”.
Bajo propiedades de inversión se incluyen en Chile 17 terrenos, 2 oficinas y 1 departamento que se encuentra en proceso
de venta que no generó ingresos para la Compañía en los años 2024 y 2023 (M$ 5.535 en 2022); por otra parte, en Argentina
se encuentran 2 terrenos y 2 inmuebles arrendados, registrando un ingreso por M$ 220.359 al 31 de diciembre de 2024
(M$ 110.554 en 2023 y M$ 84.859 en 2022). Adicionalmente, los gastos del ejercicio asociados al total de estas propiedades
de inversión ascienden a M$ 119.708 (M$ 76.843 en 2023 y M$ 87.399 en 2022).
La valorización de mercado de las propiedades de inversión supera el 100% del valor libro.
El valor razonable de las propiedades de inversión, que representan el 100% del total de las mismas, asciende a
M$ 24.096.979.
La Administración no ha evidenciado indicios de deterioro respecto del valor de las Propiedades de Inversión.
La Compañía no mantiene en prenda ni tiene restricciones sobre ítems de propiedades de inversión.
 96

[pág. 98]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 21 Otros pasivos financieros
Los préstamos y obligaciones financieras que devengan intereses, clasificados por tipo de obligación y por su clasificación
en el Estado Consolidado de Situación Financiera son los siguientes:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Corriente No corriente Corriente No corriente
 M$ M$ M$ M$
 Préstamos bancarios (1) 41.257.611 166.647.324 24.494.870 174.074.170
 Obligaciones con el público (1) 98.433.154 1.059.003.920 38.650.859 1.050.838.488
 Instrumentos financieros derivados (2) 652.079 - 468.541 -
 Pasivos de cobertura (2) 4.086.699 8.580.478 3.207.739 9.333.449
 Depósitos recibidos en garantía de envases y contenedores 11.772.459 - 11.774.922 -
 Pasivo por contrato de opción (3) - - 28.554.669 -
 Total 156.202.002 1.234.231.722 107.151.600 1.234.246.107
(1) Ver Nota 5 - Administración de riesgos.
(2) Ver Nota 7 - Instrumentos financieros.
(3) Ver Nota 1 - Información general, letra C) numeral (4).
 97

[pág. 99]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Préstamos y obligaciones financieras corrientes
Los vencimientos y tasas de interés de estas obligaciones son los siguientes:
Al 31 de diciembre de 2024:
 Vencimientos (*)
 Moneda
 País
 Rut empresa País o unidad Más de 90 días hasta Tipo de Tasa de
 Nombre empresa deudora empresa Rut acreedor Nombre acreedor Hasta 90 días Total
 deudora acreedor de 1 año amortización interés
 deudora
 reajuste
 M$ M$ M$ (%)
 Préstamos bancarios
 76.035.409-0 Cervecera Guayacán SpA. Chile 97.004.000-5 Banco de Chile Chile UF 3.200 4.557 7.757 Mensual 3,39
 76.035.409-0 Cervecera Guayacán SpA. Chile 97.004.000-5 Banco de Chile Chile UF 4.219 8.564 12.783 Mensual 5,65
 76.920.876-3 D&D SpA. Chile 97.006.000-6 Banco de Crédito e Inversiones Chile CLP 7.464 7.599 15.063 Al vencimiento 6,96
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 16.531.581 - 16.531.581 Al vencimiento 6,66
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 779.700 779.700 Al vencimiento 6,78
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 250.700 250.700 Al vencimiento 6,54
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 67.375 2.000.000 2.067.375 Al vencimiento 7,35
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 28.873 28.873 Al vencimiento 7,32
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 16.750 16.750 Al vencimiento 8,04
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 193.832 193.832 Al vencimiento 7,74
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 55.728 55.728 Al vencimiento 8,00
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.018.000-1 Banco Scotiabank Chile Chile CLP 3.033.627 - 3.033.627 Al vencimiento 3,95
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.018.000-1 Banco Scotiabank Chile Chile CLP - 1.654.532 1.654.532 Semestral 3,45
 99.586.280-8 Compañía Pisquera de Chile S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 136.160 - 136.160 Al vencimiento 6,66
 0-E Compañía Industrial Cervecera S.A. Argentina 0-E Banco Citibank Argentina ARS 4.404 - 4.404 Al vencimiento 37,00
 0-E Aguas de Origen S.A. Argentina 0-E Banco Macro Argentina ARS 661.245 - 661.245 Al vencimiento 37,60
 0-E Aguas de Origen S.A. Argentina 0-E Banco BBVA Argentina ARS 6.507.456 - 6.507.456 Al vencimiento 38,61
 0-E Aguas de Origen S.A. Argentina 0-E Banco Patagonia Argentina ARS 2.886.894 - 2.886.894 Al vencimiento 37,90
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 69.185 613.839 683.024 Trimestral 5,61
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 36.748 1.272.408 1.309.156 Trimestral 5,00
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 1.178 818.453 819.631 Semestral 5,50
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 22.421 184.152 206.573 Semestral 5,95
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 13.924 186.120 200.044 Semestral 5,95
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 32.803 959.236 992.039 Semestral 5,95
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 12.190 314.973 327.163 Semestral 5,95
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB - 343.607 343.607 Semestral 5,95
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB - 171.803 171.803 Semestral 5,95
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB - 1.360.111 1.360.111 Semestral 5,95
 Total 30.032.074 11.225.537 41.257.611
(*) El monto basado en los flujos contractuales no descontados se encuentra en Nota 5 - Administración de riesgos.
 Vencimientos (*)
 Moneda
 País
 Rut empresa o unidad Más de 90 días hasta Tipo de Tasa de
 Nombre empresa deudora empresa Serie Número de inscripción País acreedor Hasta 90 días Total
 deudora de 1 año amortización interés
 deudora
 reajuste
 M$ M$ M$ (%)
 Obligaciones con el público
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono J 898 28/06/2018 Chile UF 1.291.794 4.018 1.295.812 Semestral 2,90
 90.413.000-1 Compañía Cervecerías Unidas S.A. (1) Chile Bono L 897 28/06/2018 Chile UF 39.382 29.000.086 29.039.468 Semestral 1,20
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono M 898 28/06/2018 Chile UF 68.567 304.335 372.902 Semestral 1,60
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono Internacional 144A/Regulación S Estados Unidos USD - 8.012.800 8.012.800 Semestral 3,35
 90.413.000-1 Compañía Cervecerías Unidas S.A. (1) Chile Bono P 897 28/06/2018 Chile UF 751.564 21.069 772.633 Semestral 3,35
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono R 1115 20/08/2022 Chile UF 1.159.263 - 1.159.263 Semestral 2,70
 91.041.000-8 Viña San Pedro Tarapacá S.A. (2) Chile Bono D 986 12/12/2019 Chile UF 110.782 57.669.494 57.780.276 Semestral 1,00
 Total 3.421.352 95.011.802 98.433.154
(1) Esta obligación se encuentra cubierta por un contrato Cross Currency Swap. Ver Nota 7 - Instrumentos financieros.
(2) Esta obligación se encuentra parcialmente cubierta por contratos Cross Currency Swap. Ver Nota 7 - Instrumentos financieros.
(*) El monto basado en los flujos contractuales no descontados se encuentra en Nota 5 - Administración de riesgos.
 98

[pág. 100]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Al 31 de diciembre de 2023:
 Vencimientos (*)
 Moneda
 País
 Rut empresa País o unidad Más de 90 días hasta Tipo de Tasa de
 Nombre empresa deudora empresa Rut acreedor Nombre acreedor Hasta 90 días Total
 deudora acreedor de 1 año amortización interés
 deudora
 reajuste
 M$ M$ M$ (%)
 Préstamos bancarios
 76.035.409-0 Cervecera Guayacán SpA. Chile 97.004.000-5 Banco de Chile Chile UF 2.373 5.439 7.812 Mensual 3,39
 76.035.409-0 Cervecera Guayacán SpA. Chile 97.004.000-5 Banco de Chile Chile UF 2.845 8.764 11.609 Mensual 5,65
 76.920.876-3 D&D SpA. Chile 97.006.000-6 Banco de Crédito e Inversiones Chile CLP 13.506 23.703 37.209 Al vencimiento 6,96
 76.920.876-3 D&D SpA. Chile 97.006.000-6 Banco de Crédito e Inversiones Chile CLP 7.054 - 7.054 Al vencimiento 3,50
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 549.050 549.050 Al vencimiento 8,34
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 1.541.550 1.541.550 Al vencimiento 7,17
 91.041.000-8 Viña San Pedro Tarapacá S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 1.363 - 1.363 Al vencimiento 9,60
 91.041.000-8 Viña San Pedro Tarapacá S.A. Chile 76.645.030-K Banco Itaú Corpbanca Chile USD 16.700.666 - 16.700.666 Al vencimiento 5,88
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 79.750 - 79.750 Al vencimiento 8,70
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 34.320 34.320 Al vencimiento 8,58
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 16.750 16.750 Al vencimiento 8,04
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 213.582 - 213.582 Al vencimiento 8,60
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.018.000-1 Scotiabank Chile Chile CLP 32.080 - 32.080 Al vencimiento 3,95
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.018.000-1 Scotiabank Chile Chile CLP - 1.656.358 1.656.358 Semestral 3,45
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 58.367 58.367 Al vencimiento 8,00
 99.586.280-8 Compañía Pisquera de Chile S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 604.555 - 604.555 Al vencimiento 8,66
 0-E Compañía Industrial Cervecera S.A. Argentina 0-E Citibank Argentina ARS 31.389 - 31.389 Diario 130,00
 0-E Compañía Industrial Cervecera S.A. Argentina 0-E BBVA Argentina Euros 177.940 - 177.940 Al vencimiento 19,80
 0-E Compañía Industrial Cervecera S.A. Argentina 0-E Santander Argentina ARS 23.144 - 23.144 Al vencimiento 105,00
 0-E Finca La Celia S.A. Argentina 0-E Banco Patagonia Argentina USD 271 - 271 Al vencimiento 105,00
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 36.016 135.081 171.097 Trimestral 5,00
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 20.366 280.005 300.371 Trimestral 5,00
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 19.734 480.288 500.022 Semestral 5,50
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 3.857 289.853 293.710 Semestral 5,95
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 3.689 277.250 280.939 Semestral 5,95
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 19.383 - 19.383 Semestral 5,50
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 6.589 567.103 573.692 Semestral 5,50
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 3.734 567.103 570.837 Semestral 5,50
 Total 18.003.886 6.490.984 24.494.870
(*) El monto basado en los flujos contractuales no descontados se encuentra en Nota 5 - Administración de riesgos.
 Vencimientos (*)
 Moneda
 País
 Rut empresa o unidad Más de 90 días hasta Tipo de Tasa de
 Nombre empresa deudora empresa Serie Número de inscripción País acreedor Hasta 90 días Total
 deudora de 1 año amortización interés
 deudora
 reajuste
 M$ M$ M$ (%)
 Obligaciones con el público
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono J 898 28/06/2018 Chile UF 1.237.075 3.851 1.240.926 Semestral 2,90
 90.413.000-1 Compañía Cervecerías Unidas S.A. (1) Chile Bono L 897 28/06/2018 Chile UF 42.917 27.813.845 27.856.762 Semestral 1,20
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono M 898 28/06/2018 Chile UF 65.763 291.746 357.509 Semestral 1,60
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono Internacional 144A/Regulación S Estados Unidos USD 7.053.155 - 7.053.155 Semestral 3,35
 90.413.000-1 Compañía Cervecerías Unidas S.A. (1) Chile Bono P 897 28/06/2018 Chile UF 720.004 21.005 741.009 Semestral 3,35
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono R 1115 20/08/2022 Chile UF 1.110.156 - 1.110.156 Semestral 2,70
 91.041.000-8 Viña San Pedro Tarapacá S.A. (2) Chile Bono D 986 12/12/2019 Chile UF 61.750 229.592 291.342 Semestral 1,00
 Total 10.290.820 28.360.039 38.650.859
(1) Esta obligación se encuentra cubierta por un contrato Cross Currency Swap. Ver Nota 7 - Instrumentos financieros.
(2) Esta obligación se encuentra parcialmente cubierta por contratos Cross Currency Swap. Ver Nota 7 - Instrumentos financieros.
(*) El monto basado en los flujos contractuales no descontados se encuentra en Nota 5 - Administración de riesgos.
Préstamos y obligaciones financieras no corrientes
Los vencimientos y tasas de interés de estas obligaciones son los siguientes:
Al 31 de diciembre de 2024:
 Vencimientos (*)
 Moneda
 País Tasa
 Rut empresa Rut País o unidad Más de 1 año Más de 3 años Tipo de
 Nombre empresa deudora empresa Nombre acreedor Más de 5 años Total de
 deudora acreedor acreedor de hasta 3 años hasta 5 años amortización
 deudora interés
 reajuste
 M$ M$ M$ M$ (%)
 Préstamos bancarios
 76.035.409-0 Cervecera Guayacán SpA. Chile 97.004.000-5 Banco de Chile Chile UF 16.324 17.468 15.488 49.280 Mensual 3,39
 76.035.409-0 Cervecera Guayacán SpA. Chile 97.004.000-5 Banco de Chile Chile UF 27.793 31.085 34.830 93.708 Mensual 5,65
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 90.000.000 - 90.000.000 Al vencimiento 6,78
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 30.000.000 - - 30.000.000 Al vencimiento 6,54
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 2.000.000 - - 2.000.000 Al vencimiento 7,32
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 1.000.000 - - 1.000.000 Al vencimiento 8,04
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 6.732.610 - - 6.732.610 Al vencimiento 7,74
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 5.977.327 - 5.977.327 Al vencimiento 8,00
 99.586.280-8 Compañía Pisquera de Chile S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 16.000.000 - - 16.000.000 Al vencimiento 6,66
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 1.227.678 1.227.678 1.688.058 4.143.414 Trimestral 5,61
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 2.544.816 2.544.816 3.181.018 8.270.650 Trimestral 5,00
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 545.636 545.635 - 1.091.271 Semestral 5,50
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 736.608 552.456 - 1.289.064 Semestral 5,95
 Total 60.831.465 100.896.465 4.919.394 166.647.324
(*) El monto basado en los flujos contractuales no descontados se encuentra en Nota 5 - Administración de riesgos.
 99

[pág. 101]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
 Vencimientos (*)
 Moneda
 Rut País o Más de 3 Tasa
 Más de 1 año Tipo de
 empresa Nombre empresa deudora empresa Serie Número de inscripción País acreedor unidad años hasta 5 Más de 5 años Total de
 hasta 3 años amortización
 deudora deudora de años interés
 reajuste
 M$ M$ M$ M$ (%)
 Obligaciones con el público
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono J 898 28/06/2018 Chile UF 10.716 10.598 115.335.804 115.357.118 Semestral 2,90
 90.413.000-1 Compañía Cervecerías Unidas S.A. (1) Chile Bono L 897 28/06/2018 Chile UF 43.447.522 - - 43.447.522 Semestral 1,20
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono M 898 28/06/2018 Chile UF 548.536 548.536 76.969.554 78.066.626 Semestral 1,60
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono Internacional 144A/Regulación S Estados Unidos USD - - 592.159.908 592.159.908 Semestral 3,35
 90.413.000-1 Compañía Cervecerías Unidas S.A. (1) Chile Bono P 897 28/06/2018 Chile UF 56.184 56.184 76.906.398 77.018.766 Semestral 3,35
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono R 1115 20/08/2022 Chile UF - - 152.953.980 152.953.980 Semestral 2,70
 Total 44.062.958 615.318 1.014.325.644 1.059.003.920
(1) Esta obligación se encuentra cubierta por un contrato Cross Currency Swap. Ver Nota 7 - Instrumentos financieros.
 (*) El monto basado en los flujos contractuales no descontados se encuentra en Nota 5 - Administración de riesgos.
Al 31 de diciembre de 2023:
 Vencimientos (*)
 Moneda
 País Tasa
 Rut empresa Rut País o unidad Más de 1 año Más de 3 años Tipo de
 Nombre empresa deudora empresa Nombre acreedor Más de 5 años Total de
 deudora acreedor acreedor de hasta 3 años hasta 5 años amortización
 deudora interés
 reajuste
 M$ M$ M$ M$ (%)
 Préstamos bancarios
 76.035.409-0 Cervecera Guayacán SpA. Chile 97.004.000-5 Banco de Chile Chile UF 15.198 16.263 21.940 53.401 Mensual 3,39
 76.035.409-0 Cervecera Guayacán SpA. Chile 97.004.000-5 Banco de Chile Chile UF 25.276 28.272 47.416 100.964 Mensual 5,65
 76.920.876-3 D&D SpA. Chile 97.006.000-6 Banco de Crédito e Inversiones Chile CLP 15.062 - - 15.062 Al vencimiento 6,96
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 30.000.000 - 30.000.000 Al vencimiento 8,34
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 90.000.000 - 90.000.000 Al vencimiento 7,17
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 2.000.000 - - 2.000.000 Al vencimiento 8,70
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 2.000.000 - - 2.000.000 Al vencimiento 8,58
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 1.000.000 - - 1.000.000 Al vencimiento 8,04
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 6.726.334 - 6.726.334 Al vencimiento 8,60
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.018.000-1 Scotiabank Chile Chile CLP 2.994.217 - - 2.994.217 Al vencimiento 3,95
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.018.000-1 Scotiabank Chile Chile CLP 1.651.019 - - 1.651.019 Semestral 3,45
 96.981.310-6 Cervecería Kunstmann S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 5.967.737 - 5.967.737 Al vencimiento 8,00
 99.586.280-8 Compañía Pisquera de Chile S.A. Chile 97.030.000-7 Banco del Estado de Chile Chile CLP - 16.000.000 - 16.000.000 Al vencimiento 8,66
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 1.080.648 1.080.648 2.026.213 4.187.509 Trimestral 5,00
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 2.240.038 2.240.038 3.920.067 8.400.143 Trimestral 5,00
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 720.432 960.576 - 1.681.008 Semestral 5,50
 0-E Bebidas Bolivianas BBO S.A. Bolivia 0-E Banco Mercantil Santa Cruz S.A. Bolivia BOB 486.291 648.388 162.097 1.296.776 Semestral 5,50
 Total 14.228.181 153.668.256 6.177.733 174.074.170
(*) El monto basado en los flujos contractuales no descontados se encuentra en Nota 5 - Administración de riesgos.
 Vencimientos (*)
 Moneda
 Rut País o Más de 3 Tasa
 Más de 1 año Tipo de
 empresa Nombre empresa deudora empresa Serie Número de inscripción País acreedor unidad años hasta 5 Más de 5 años Total de
 hasta 3 años amortización
 deudora deudora de años interés
 reajuste
 M$ M$ M$ M$ (%)
 Obligaciones con el público
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono J 898 28/06/2018 Chile UF 10.270 10.158 110.456.141 110.476.569 Semestral 2,90
 90.413.000-1 Compañía Cervecerías Unidas S.A. (1) Chile Bono L 897 28/06/2018 Chile UF 55.527.378 13.876.608 - 69.403.986 Semestral 1,20
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono M 898 28/06/2018 Chile UF 526.108 526.108 73.976.883 75.029.099 Semestral 1,60
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono Internacional 144A/Regulación S Estados Unidos USD - - 520.409.088 520.409.088 Semestral 3,35
 90.413.000-1 Compañía Cervecerías Unidas S.A. (1) Chile Bono P 897 28/06/2018 Chile UF 56.014 56.014 73.680.966 73.792.994 Semestral 3,35
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile Bono R 1115 20/08/2022 Chile UF - - 146.434.024 146.434.024 Semestral 2,70
 91.041.000-8 Viña San Pedro Tarapacá S.A. (2) Chile Bono D 986 12/12/2019 Chile UF 55.292.728 - - 55.292.728 Semestral 1,00
 Total 111.412.498 14.468.888 924.957.102 1.050.838.488
(1) Esta obligación se encuentra cubierta por un contrato Cross Currency Swap. Ver Nota 7 - Instrumentos financieros.
(2) Esta obligación se encuentra parcialmente cubierta por contratos Cross Currency Swap. Ver Nota 7 - Instrumentos financieros.
(*) El monto basado en los flujos contractuales no descontados se encuentra en Nota 5 - Administración de riesgos.
Ver detalle del valor razonable de los préstamos bancarios y obligaciones con el público en Nota 7 - Instrumentos
financieros.
Las tasas efectivas vigentes de las obligaciones con el público corresponden a las siguientes:
Bonos Serie J 2,89%
Bonos Serie L 1,21%
Bonos Serie M 0,87%
Bono Internacional 3,30%
Bonos Serie P 3,36%
Bonos Serie R 2,81%
Bonos Serie D 0,53%
 100

[pág. 102]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Los términos y condiciones de las principales obligaciones que devengan intereses al 31 de diciembre de 2024, son los
siguientes:
A) Préstamos bancarios
Banco del Estado de Chile - Préstamos bancarios
a) Con fecha 27 de julio de 2012, Compañía Pisquera de Chile S.A. (CPCh) suscribió un préstamo bancario con el Banco
 del Estado de Chile por un total de M$ 16.000.000, con vencimiento al 27 de julio de 2017.
 Este préstamo devengó intereses a una tasa nominal fija de 6,86% anual y a una tasa efectiva del 7,17% anual (base
 360). La subsidiaria amortizó intereses en forma semestral y la amortización de capital consiste en un solo pago al final
 del plazo establecido.
 Con fecha 27 de julio de 2017 se renovó dicho préstamo, a un plazo de 5 años, con vencimiento al 27 de julio de 2022.
 Este préstamo devenga intereses a una tasa fija de 4,68% anual. La compañía paga intereses en forma semestral y la
 amortización de capital consiste en un solo pago al final del plazo establecido.
 Con fecha 27 de julio de 2022 se renovó dicho préstamo, a un plazo de 5 años, con vencimiento al 27 de julio de 2027.
 Este préstamo devenga intereses a una tasa fija de 8,664% anual. La compañía paga intereses en forma semestral y la
 amortización de capital consiste en un solo pago al final del plazo establecido.
 Con fecha 27 de junio de 2024 se refinanció la tasa, quedando en una tasa fija de 7,608% anual, manteniendo las
 condiciones vigentes del préstamo.
 Con fecha 15 de noviembre de 2024 se refinanció la tasa, quedando en una tasa fija de 6,66% anual, manteniendo las
 condiciones vigentes del préstamo.
 Producto de esta renovación CPCh debe cumplir con cierta obligación de información además de cumplir con los
 siguientes índices financieros, lo que se medirá sobre los Estados Financieros semestrales de CPCh:
 a. Mantener una Cobertura de Gastos Financieros no inferior a tres veces, siendo ésta la relación entre Margen Bruto
 menos Gastos de mercadotecnia, distribución y administración, más Otros ingresos por función, menos Otros
 egresos por función, más Depreciación y amortizaciones, dividido por Costos financieros.
 b. Una razón de endeudamiento no superior a tres veces, medido como Total de pasivos dividido por Patrimonio.
 c. Un Patrimonio mayor a UF 770.000.
 Adicionalmente este crédito obliga a CPCh a cumplir ciertas restricciones de carácter afirmativo tales como, mantener
 seguros, mantener la propiedad de activos esenciales; y también a cumplir ciertas restricciones de carácter negativo,
 tales como no dar en prenda, hipoteca o constituir cualquier caución o derecho real sobre cualquier Propiedad, planta y
 equipo que registre un valor individual contable superior a UF 10.000, excepto bajo los términos establecidos por el
 contrato, entre otros.
 Por otra parte, la Compañía, mediante instrumento privado de fecha 27 de julio de 2022 se obliga a mantener, una
 participación accionaria directa o indirecta de al menos el 50,1%, que le permita el control de su subsidiaria Compañía
 Pisquera de Chile S.A. durante el periodo de vigencia de este crédito.
 Al 31 de diciembre de 2024, la subsidiaria estaba cumpliendo con todos los requerimientos de esta obligación.
b) Con fecha 16 de abril de 2021, la subsidiaria Cervecería Kunstmann S.A. suscribió un préstamo bancario con el Banco
 del Estado de Chile por un total de M$ 1.000.000, a una tasa de interés fija, con vencimiento al 17 de abril de 2023.
 Con fecha 17 de abril de 2023 se renovó dicho préstamo, a un plazo de 3 años, con vencimiento al 17 de abril de 2026.
 La subsidiaria amortiza intereses en forma semestral y capital en un solo pago al final del plazo establecido.
 101

[pág. 103]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
c) Con fecha 21 de abril de 2021, la subsidiaria Cervecería Kunstmann S.A. suscribió un préstamo bancario con el Banco
 del Estado de Chile por un total de M$ 2.000.000, a una tasa de interés fija, con vencimiento al 21 de abril de 2023.
 Con fecha 21 de abril de 2023 se renovó dicho préstamo, a un plazo de 3 años, con vencimiento al 21 de abril de 2026.
 Con fecha 5 de junio de 2024, se refinanció la tasa de interés, manteniendo las demás condiciones vigentes del préstamo.
 La subsidiaria amortiza intereses en forma semestral y capital en un solo pago al final del plazo establecido.
d) Con fecha 19 de julio de 2022, la subsidiaria Cervecería Kunstmann S.A. suscribió un préstamo bancario con el Banco
 del Estado de Chile por un total de M$ 2.000.000, a una tasa de interés fija, con vencimiento al 18 de julio de 2025.
 Con fecha 5 de junio de 2024, se refinanció la tasa de interés, manteniendo las demás condiciones vigentes del préstamo.
 La subsidiaria amortiza intereses en forma semestral y capital en un solo pago al final del plazo establecido.
e) Con fecha 11 de agosto de 2022, la subsidiaria Cervecería Kunstmann S.A. suscribió un préstamo bancario con el Banco
 del Estado de Chile por un total de M$ 6.750.000, a una tasa de interés fija, con vencimiento al 11 de agosto de 2027.
 Con fecha 5 de junio de 2024, se refinanció la tasa de interés, manteniendo las demás condiciones vigentes del préstamo.
 La subsidiaria amortiza intereses en forma semestral y capital en un solo pago al final del plazo establecido.
 Este préstamo bancario señalado anteriormente requiere cumplir ciertos requisitos de carácter informativo y también del
 cumplimiento de ciertos covenants, los que se medirán sobre los Estados Financieros Consolidados semestrales de la
 subsidiaria:
 a. Una Cobertura de Gastos Financieros mayor o igual a tres veces. Para estos efectos, Cobertura de Gastos
 Financieros se define como ROADA dividido por la partida “Gastos Financieros” de los estados financieros
 consolidados del Deudor medidos sobre los últimos doce meses. ROADA se define como el Resultado Operacional
 más la Depreciación del Ejercicio, más amortización de Activos Intangibles.
 b. Una relación Deuda Financiera Neta sobre ROADA inferior o igual a cuatro veces. Para estos efectos se entiende
 por Deuda Financiera Neta la diferencia entre /i/ la suma de la partida “Otros Pasivos Financieros, Corrientes y No
 Corrientes”; y /ii/ la suma de la partida “Efectivo y Equivalente al Efectivo” los estados financieros consolidados del
 Deudor.
 Adicionalmente este crédito obliga a la subsidiaria a cumplir ciertas restricciones de carácter afirmativo tales como,
 cumplir ciertas restricciones de carácter negativo, como no otorgar garantías reales, esto es prendas e hipotecas, para
 garantizar obligaciones propias o de terceros, sin la autorización previa y por escrito del Banco, por un monto igual o
 superior al diez por ciento del total de los activos fijos del Deudor.
 Al 31 de diciembre de 2024, la subsidiaria estaba cumpliendo con todos los requerimientos de esta obligación.
f) Con fecha 12 de mayo de 2023, la subsidiaria Cervecería Kunstmann S.A. suscribió un préstamo bancario con el Banco
 del Estado de Chile por un total de M$ 6.000.000, a una tasa de interés fija, con vencimiento al 12 de mayo de 2028.
 La subsidiaria amortiza intereses en forma semestral y capital en un solo pago al final del plazo establecido.
 Este préstamo bancario señalado anteriormente requiere cumplir ciertos requisitos de carácter informativo y también del
 cumplimiento de ciertos covenants, los que se medirán sobre los Estados Financieros Consolidados semestrales de la
 subsidiaria:
 a. Una Cobertura de Gastos Financieros mayor o igual a tres veces. Para estos efectos, Cobertura de Gastos
 Financieros se define como ROADA dividido por la partida “Gastos Financieros” de los estados financieros
 consolidados del Deudor medidos sobre los últimos doce meses. ROADA se define como el Resultado Operacional
 más la Depreciación del Ejercicio, más amortización de Activos Intangibles.
 102

[pág. 104]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
 b. Una relación Deuda Financiera Neta sobre ROADA inferior o igual a cuatro veces. Para estos efectos se entiende
 por Deuda Financiera Neta la diferencia entre /i/ la suma de la partida “Otros Pasivos Financieros, Corrientes y No
 Corrientes”; y /ii/ la suma de la partida “Efectivo y Equivalente al Efectivo” los estados financieros consolidados del
 Deudor.
 Adicionalmente este crédito obliga a la subsidiaria a cumplir ciertas restricciones de carácter afirmativo tales como,
 cumplir ciertas restricciones de carácter negativo, como no otorgar garantías reales, esto es prendas e hipotecas, para
 garantizar obligaciones propias o de terceros, sin la autorización previa y por escrito del Banco, por un monto igual o
 superior al diez por ciento del total de los activos fijos del Deudor.
 Al 31 de diciembre de 2024, la subsidiaria estaba cumpliendo con todos los requerimientos de esta obligación.
g) Con fecha 13 de abril de 2017, Compañía de Cervecerías Unidas S.A. suscribió un préstamo bancario con el Banco del
 Estado de Chile por un total de M$ 40.000.000 (saldo vigente de M$ 30.000.000 al 31 de diciembre de 2024) a una tasa
 de interés fija, con vencimiento al 13 de abril de 2022.
 Con fecha 13 de abril de 2022 se renovó dicho préstamo, a un plazo de 5 años, con vencimiento al 13 de abril de 2027.
 La Compañía amortiza intereses en forma semestral y la amortización de capital consiste en un solo pago al final del
 plazo establecido.
 Con fecha 31 de marzo de 2023 se pagaron en forma anticipada M$ 10.000.000 al capital adeudado.
 Con fecha 17 de mayo de 2024, se refinanció la tasa de interés, manteniendo las demás condiciones vigentes del
 préstamo.
 Con fecha 15 de noviembre de 2024 se refinanció la tasa, quedando en una tasa fija de 6,54% anual, manteniendo las
 condiciones vigentes del préstamo.
 Al 31 de diciembre de 2024, la Compañía estaba en cumplimiento con todos los requerimientos de esta obligación y
 demás requerimientos específicos que se indican en letra C), numeral 1) Restricciones y cumplimientos de las
 obligaciones financieras.
h) Con fecha 13 de octubre de 2021, Compañía Cervecerías Unidas S.A. suscribió un préstamo bancario con Scotiabank
 Chile por un total de M$ 90.000.000, a una tasa de interés fija, con vencimiento el 6 de abril 2023.
 Con fecha 6 de abril de 2023 se renovó este préstamo con el Banco del Estado de Chile, a un plazo de 5 años, con
 vencimiento el 6 de abril de 2028.
 Con fecha 15 de noviembre de 2024 se refinanció la tasa, quedando en una tasa fija de 6,78% anual, manteniendo las
 condiciones vigentes del préstamo.
 La Compañía amortiza intereses en forma semestral y la amortización de capital consiste en un solo pago al final del
 plazo establecido.
 Al 31 de diciembre de 2024, la Compañía estaba en cumplimiento con todos los requerimientos de esta obligación y
 demás requerimientos específicos que se indican en letra C), numeral 2) Restricciones y cumplimientos de las
 obligaciones financieras.
Banco de Chile – Préstamos bancarios
a) Con fecha 5 de julio de 2021, la subsidiaria Cervecera Guayacán SpA. suscribió un préstamo bancario con el Banco de
 Chile por un total de UF 2.110 (saldo vigente equivalente es de M$ 57.037 al 31 de diciembre de 2024), a una tasa de
 interés fija, con vencimiento el 5 de junio de 2031.
 La subsidiaria amortiza intereses y capital en forma mensual.
b) Con fecha 17 de diciembre de 2021, la subsidiaria Cervecera Guayacán SpA. suscribió un préstamo bancario con el
 Banco de Chile por un total de UF 3.663 (saldo vigente equivalente es de M$ 106.491 al 31 de diciembre de 2024), a una
 tasa de interés fija, con vencimiento el 17 de noviembre 2031.
 103

[pág. 105]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
 La subsidiaria amortiza intereses y capital en forma mensual.
Banco Scotiabank Chile – Préstamos bancarios
a) Con fecha 9 de diciembre de 2019, la subsidiaria Cervecería Kunstmann S.A. suscribió un préstamo bancario con el
 Banco Scotiabank Chile por un total de M$ 10.000.000 (saldo vigente de M$ 1.666.667 al 31 de diciembre de 2024), a
 una tasa de interés fija, con vencimiento al 9 de diciembre de 2025.
 La subsidiaria amortiza intereses y capital en forma semestral, con primer vencimiento el 9 de junio de 2020.
 Este préstamo bancario señalado anteriormente requiere cumplir ciertos requisitos de carácter informativo y también del
 cumplimiento de ciertos covenants, los que se medirán sobre los Estados Financieros Consolidados semestrales de la
 subsidiaria:
 a. Una Cobertura de Gastos Financieros mayor o igual a tres veces. Para estos efectos, Cobertura de Gastos
 Financieros se define como ROADA dividido por la partida “Gastos Financieros” de los Estados Financieros
 Consolidados del Deudor medidos sobre los últimos doce meses. ROADA se define como el Resultado Operacional
 más la Depreciación del Ejercicio, más amortización de Activos Intangibles.
 b. Una relación Deuda Financiera Neta sobre ROADA inferior o igual a cuatro veces. Para estos efectos se entiende
 por Deuda Financiera Neta la diferencia entre /i/ la suma de la partida “Otros Pasivos Financieros, Corrientes y No
 Corrientes”; y /ii/ la suma de la partida “Efectivo y Equivalente al Efectivo” los Estados Financieros Consolidados del
 Deudor.
 Adicionalmente este crédito obliga a la subsidiaria a cumplir ciertas restricciones de carácter afirmativo tales como,
 cumplir ciertas restricciones de carácter negativo, como no otorgar garantías reales, esto es prendas e hipotecas, para
 garantizar obligaciones propias o de terceros, sin la autorización previa y por escrito del Banco, por un monto igual o
 superior al diez por ciento del total de los activos fijos del Deudor.
 Al 31 de diciembre de 2024, la subsidiaria estaba cumpliendo con todos los requerimientos de esta obligación.
b) Con fecha 17 de marzo de 2020, la subsidiaria Cervecería Kunstmann S.A. suscribió un préstamo bancario con el Banco
 Scotiabank Chile por un total de M$ 3.000.000, a una tasa de interés fija, con vencimiento al 16 de marzo de 2025.
 La subsidiaria amortiza interés de forma semestral y la amortización de capital consiste en un solo pago al final del plazo
 establecido.
 Este préstamo bancario señalado anteriormente requiere cumplir ciertos requisitos de carácter informativo y también del
 cumplimiento de ciertos covenants, los que se medirán sobre los Estados Financieros Consolidados semestrales de la
 subsidiaria:
 a. Una Cobertura de Gastos Financieros mayor o igual a tres veces. Para estos efectos, Cobertura de Gastos
 Financieros se define como ROADA dividido por la partida “Gastos Financieros” de los estados financieros
 consolidados del Deudor medidos sobre los últimos doce meses. ROADA se define como el Resultado Operacional
 más la Depreciación del Ejercicio, más amortización de Activos Intangibles.
 b. Una relación Deuda Financiera Neta sobre ROADA inferior o igual a cuatro veces. Para estos efectos se entiende
 por Deuda Financiera Neta la diferencia entre /i/ la suma de la partida “Otros Pasivos Financieros, Corrientes y No
 Corrientes”; y /ii/ la suma de la partida “Efectivo y Equivalente al Efectivo” los estados financieros consolidados del
 Deudor.
 Adicionalmente este crédito obliga a la subsidiaria a cumplir ciertas restricciones de carácter afirmativo tales como,
 cumplir ciertas restricciones de carácter negativo, como no otorgar garantías reales, esto es prendas e hipotecas, para
 garantizar obligaciones propias o de terceros, sin la autorización previa y por escrito del Banco, por un monto igual o
 superior al diez por ciento del total de los activos fijos del Deudor.
 Al 31 de diciembre de 2024, la subsidiaria estaba cumpliendo con todos los requerimientos de esta obligación.
 104

[pág. 106]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
c) Con fecha 18 de febrero de 2020, la subsidiaria Bebidas CCU-PepsiCo SpA. suscribió un préstamo bancario con el Banco
 Scotiabank Chile por un total de M$ 2.000.000 registrando en CCU el 50% en proporción a su participación en esta
 operación conjunta, a una tasa de interés fija, con vencimiento al 18 de febrero de 2023.
 La subsidiaria amortiza interés de forma semestral y la amortización de capital consiste en un solo pago al final del plazo
 establecido.
 Con fecha 18 de febrero de 2023, se realizó el pago de dicho préstamo.
Banco Crédito e Inversiones – Préstamos bancarios
a) Con fecha 18 de mayo de 2020, la subsidiaria D&D SpA. suscribió un préstamo bancario con el Banco de Crédito e
 Inversiones por un total de M$ 69.000 a una tasa de interés fija, con vencimiento al 24 de abril de 2024.
 La subsidiaria amortiza intereses y capital en forma mensual.
 Con fecha 24 de abril de 2024, se realizó el pago de dicho préstamo.
b) Con fecha 23 de julio de 2021, la subsidiaria D&D SpA. suscribió un préstamo bancario con el Banco de Crédito e
 Inversiones por un total de M$ 100.000 (saldo vigente de M$ 15.063 al 31 de diciembre de 2024) a una tasa de interés
 fija, con vencimiento al 16 de junio de 2025.
 La subsidiaria amortiza intereses y capital en forma mensual.
Banco Mercantil Santa Cruz S.A. – Préstamos bancarios
a) Con fecha 26 de junio de 2017, la subsidiaria Bebidas Bolivianas BBO S.A. (BBO) suscribió un préstamo bancario con el
 Banco Mercantil Santa Cruz S.A. por un total de 68.877.500 bolivianos (saldo vigente equivalente a M$ 9.543.058 al 31
 de diciembre de 2024) a una tasa de interés fija, con vencimiento al 4 de abril de 2032.
 La subsidiaria amortiza intereses en forma trimestral, y la amortización de capital comenzó a liquidarse desde el 12 de
 noviembre de 2024 de forma trimestral.
b) Con fecha 31 de mayo de 2019, la subsidiaria BBO suscribió un préstamo bancario con el Banco Mercantil Santa Cruz
 S.A. por un total de 34.300.000 bolivianos (saldo vigente equivalente a M$ 4.757.255 al 31 de diciembre de 2024) a una
 tasa de interés fija, con vencimiento al 21 de julio de 2032.
 La subsidiaria amortiza intereses en forma trimestral y la amortización de capital comenzó a liquidarse desde el 31 de
 octubre de 2024 de forma trimestral.
c) Con fecha 30 de junio de 2022, la subsidiaria BBO suscribió un préstamo bancario con el Banco Mercantil Santa Cruz
 S.A. por un total de 17.150.000 bolivianos (saldo vigente equivalente a M$ 1.909.723 al 31 de diciembre de 2024) a una
 tasa de interés fija, con vencimiento al 25 de junio de 2028.
 La subsidiaria amortizará intereses en forma semestral y la amortización de capital comenzó a liquidarse desde el 25 de
 junio de 2024 de forma semestral.
d) Con fecha 29 de mayo de 2023, la subsidiaria BBO suscribió un préstamo bancario con el Banco Mercantil Santa Cruz
 S.A. por un total de 10.290.000 bolivianos (saldo vigente equivalente a M$ 1.473.215 al 31 de diciembre de 2024) a una
 tasa de interés fija, con vencimiento al 10 de mayo de 2029.
 La subsidiaria amortizará intereses en forma semestral, y la amortización de capital comenzará a liquidarse desde el 10
 de noviembre de 2025 de forma semestral.
 105

[pág. 107]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
B) Obligaciones con el público
Bono Serie H – CCU S.A.
Con fecha 23 de marzo de 2009, y bajo el número 573, CCU S.A. inscribió en el registro de valores la emisión del Bono Serie
H, al portador y desmaterializado, por un total de UF 2 millones con vencimiento el 15 de marzo de 2030, con un descuento
de M$ 156.952, con pagos de intereses semestrales y amortización semestral a partir del 15 de septiembre de 2019,
devengando una tasa de interés fija anual de 4,25%.
Con fecha 15 de septiembre de 2023, la Compañía procedió a prepagar este bono por el total del capital adeudado a esa
fecha, equivalente a M$ 42.757.520.
Por otra parte, el riesgo inflacionario asociado a la tasa de interés, al cual se encontraba expuesto el Bono H, fue mitigado
hasta la misma fecha del prepago, mediante el uso de contratos Cross Currency Swap, el cual dejaba la tasa fija.
Bono Serie J – CCU S.A.
Con fecha 28 de junio 2018, y bajo el número 898, CCU S.A. inscribió en el registro de valores la emisión de Bono Serie J,
al portador y desmaterializados, por un total de UF 3 millones (equivalente a M$ 115.250.070 al 31 de diciembre de 2024)
con vencimiento al 10 de agosto de 2043. Los bonos Serie J, devengarán sobre el capital insoluto expresado en Unidades
de Fomento, un interés anual de 2,9%, compuesto, vencido, calculado sobre la base de semestres iguales de 180 días,
equivalente a 1,4396% semestral. Los intereses se devengarán desde el 10 de agosto de 2018, se pagarán semestralmente
a partir del 10 de febrero de 2019.
La emisión fue suscrita con el Banco BICE en calidad de representante de los tenedores de bonos y de banco pagador y
requieren que la Compañía de cumplimiento a ciertos indicadores financieros respecto de sus Estados Financieros
Consolidados y demás requerimientos específicos que se indican en letra C), numeral 1) Restricciones y cumplimientos
de las obligaciones financieras.
Bono Serie L – CCU S.A.
Con fecha 28 de junio 2018, y bajo el número 897, CCU S.A. inscribió en el registro de valores la emisión de bonos por línea
de títulos de deuda, en el cual se estableció una línea de Bonos a 10 años, con cargo a la cual, el emisor, podrá emitir una
o más series de Bonos dirigidos al mercado general.
Según consta en escritura pública complementaria, de fecha 10 de junio de 2020 se ha colocado el Bono Serie L, al portador
y desmaterializado, por un total de UF 3 millones (saldo vigente equivalente a M$ 72.031.294 al 31 de diciembre de 2024)
con vencimiento al 1 de junio de 2027. Los bonos Serie L, devengarán sobre el capital insoluto expresado en Unidades de
Fomento, un interés anual de 1,20%, compuesto, vencido, calculado sobre la base de semestres iguales de 180 días,
equivalente a 0,5982% semestral. Los intereses se devengarán desde el 1 de junio de 2020, se pagarán semestralmente a
partir del 1 de diciembre de 2020 y el capital será pagado semestralmente a partir del 1 de diciembre de 2023.
La emisión fue suscrita con el Banco BICE en calidad de representante de los tenedores de bonos y de banco pagador y
requieren que la Compañía de cumplimiento a ciertos indicadores financieros respecto de sus Estados Financieros
Consolidados y demás requerimientos específicos que se indican en letra C), numeral 1) Restricciones y cumplimientos
de las obligaciones financieras.
El riesgo de tipo de cambio al que se encuentra expuesto el Bono L, es mitigado mediante el uso de contrato Cross Currency
Swap. Ver detalle de cobertura de la Compañía en Nota 7 - Instrumentos financieros.
Bono Serie M – CCU S.A.
Con fecha 28 de junio 2018, y bajo el número 898, CCU S.A. inscribió en el registro de valores la emisión de bonos por línea
de títulos de deuda, en el cual se estableció una línea de Bonos a 30 años, con cargo a la cual, el emisor, podrá emitir una
o más series de Bonos dirigidos al mercado general.
Según consta en escritura pública complementaria, de fecha 10 de junio de 2020 se ha colocado el Bono Serie M, al portador
y desmaterializado, por un total de UF 2 millones (equivalente a M$ 76.833.380 al 30 de diciembre de 2024) con vencimiento
al 1 de junio de 2030. Los bonos Serie M, devengarán sobre el capital insoluto expresado en Unidades de Fomento, un
interés anual de 1,60%, compuesto, vencido, calculado sobre la base de semestres iguales de 180 días, equivalente a
 106

[pág. 108]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
0,7968% semestral. Los intereses se devengarán desde el 1 de junio de 2020, se pagarán semestralmente a partir del 1 de
diciembre de 2020 y el capital será pagado al final del plazo del bono.
La emisión fue suscrita con el Banco BICE en calidad de representante de los tenedores de bonos y de banco pagador y
requieren que la Compañía de cumplimiento a ciertos indicadores financieros respecto de sus Estados Financieros
Consolidados y demás requerimientos específicos que se indican en letra C), numeral 1) Restricciones y cumplimientos
de las obligaciones financieras.
Bono Serie P – CCU S.A.
Con fecha 15 de marzo 2022, y bajo el número 897, CCU S.A. inscribió en el registro de valores la emisión de bonos por
línea de títulos de deuda, en el cual se estableció una línea de Bonos a 10 años, con cargo a la cual, el emisor, podrá emitir
una o más series de Bonos dirigidos al mercado general.
Según consta en escritura pública complementaria, de fecha 30 de marzo de 2022 se ha colocado el Bono Serie P, al portador
y desmaterializado, por un total de UF 2 millones (equivalente a M$ 76.833.380 al 31 de diciembre de 2024) con vencimiento
al 15 de marzo de 2032. Los bonos Serie P, devengarán sobre el capital insoluto expresado en Unidades de Fomento, un
interés anual de 3,35%, compuesto, vencido, calculado sobre la base de semestres iguales de 180 días, equivalente a 1,6%
semestral. Los intereses se devengarán desde el 15 de marzo de 2022, se pagarán semestralmente a partir del 15 de
septiembre de 2022 y el capital será pagado al final del plazo del bono.
La emisión fue suscrita con el Banco BICE en calidad de representante de los tenedores de bonos y de banco pagador y
requieren que la Compañía de cumplimiento a ciertos indicadores financieros respecto de sus Estados Financieros
Consolidados y demás requerimientos específicos que se indican en letra C), numeral 1) Restricciones y cumplimientos
de las obligaciones financieras.
El riesgo de tipo de cambio al que se encuentra expuesto el Bono P, es mitigado mediante el uso de contrato Cross Currency
Swap. Ver detalle de cobertura de la Compañía en Nota 7 - Instrumentos financieros.
Bono Internacional – CCU S.A.
Con fecha 19 de enero de 2022, la Compañía emitió y colocó en los mercados internacionales bonos por un monto de
USD 600.000.000 (equivalente a M$ 597.876.000 al 31 de diciembre de 2024) con una tasa de interés de 3,350% anual,
pagaderos semestralmente por un plazo de 10 años, y pago de capital en una cuota al vencimiento el 19 enero de 2032, con
sujeción a Regla 144ª y a la Regulación S de la Ley de Valores de los Estados Unidos de América de 1933.
Bono Serie R – CCU S.A.
Con fecha 30 de agosto 2022, y bajo el número 1.115, CCU S.A. inscribió en el registro de valores la emisión de bonos por
línea de títulos de deuda, en el cual se estableció una línea de Bonos a 30 años, con cargo a la cual, el emisor, podrá emitir
una o más series de Bonos dirigidos al mercado general.
Según consta en escritura pública complementaria, de fecha 26 de agosto de 2022 se ha colocado el Bono Serie R, al
portador y desmaterializado, por un total de UF 4 millones (equivalente a M$ 153.666.760 al 31 de diciembre de 2024) con
vencimiento al 15 de septiembre de 2042. Los bonos Serie R, devengarán sobre el capital insoluto expresado en Unidades
de Fomento, un interés anual de 2,70%, compuesto, vencido, calculado sobre la base de semestres iguales de 180 días,
equivalente a 1,3410% semestral. Los intereses se devengarán desde el 15 de septiembre de 2022, se pagarán
semestralmente a partir del 15 de marzo de 2023 y el capital será pagado al final del plazo del bono.
La emisión fue suscrita con el Banco BICE en calidad de representante de los tenedores de bonos y de banco pagador y
requieren que la Compañía de cumplimiento a ciertos indicadores financieros respecto de sus Estados Financieros
Consolidados y demás requerimientos específicos que se indican en letra C), numeral 1) Restricciones y cumplimientos
de las obligaciones financieras.
Bono Serie D – VSPT S.A.
Con fecha 12 de diciembre de 2019, y bajo el número 986, VSPT inscribió en el registro de valores la emisión de bonos por
línea títulos de deuda, en el cual se estableció una línea de Bonos a 10 años, con cargo a la cual, el emisor, podrá emitir una
o más series de Bonos dirigidos al mercado general.
 107

[pág. 109]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Según consta en escritura pública complementaria, de fecha 10 de junio de 2020, se ha colocado el Bono Serie D, al portador
y desmaterializado, por un total de UF 1,5 millones (equivalente a M$ 57.625.035 al 31 de diciembre de 2024) con
vencimiento el 1 de junio de 2025, con pagos de intereses y amortización semestral a partir del 1 de junio de 2020
devengando una tasa de interés fija anual de 1,00%.
La emisión fue suscrita con el Banco BICE, en calidad de representante de los tenedores de bonos y de banco pagador y
requiere que la Sociedad de cumplimiento a los siguientes indicadores financieros respecto de sus Estados Financieros
Consolidados y demás requerimientos específicos.
a. El Emisor deberá mantener al final de cada trimestre un Nivel de Endeudamiento Financiero Neto Consolidado, reflejado
 en cada uno de sus Estados Financieros Consolidados trimestrales, no superior a 1,5 cero veces, definido como la
 razón entre “Deuda Financiera Neta” y “Total Patrimonio Ajustado”, en adelante “Nivel de Endeudamiento Financiero
 Neto Consolidado”. Para determinar el Nivel de Endeudamiento Financiero Neto Consolidado, se basará en los Estados
 Financieros Consolidados trimestrales, y se considerará lo siguiente: /i/ “Deuda Financiera Neta”, la diferencia entre /x/
 el monto insoluto de la “Deuda Financiera”, esto es, la suma de las líneas, corriente y no corriente, Préstamos bancarios,
 Obligaciones con el público y Obligaciones por arrendamientos financieros, contenidas en la Nota Otros pasivos
 financieros, y no será considerada para el cálculo y determinación de la Deuda Financiera Neta, el monto total del
 pasivo por obligación por derechos de uso de activos de la cuenta o subcuenta de "Arrendamientos IFRS Dieciséis",
 corriente y no corrientes, e /y/ el saldo del rubro Efectivo y Equivalentes al Efectivo, contenidos en el Estado Consolidado
 de Situación Financiera del Emisor; y /ii/ “Total Patrimonio Ajustado” la suma de /x/ Total Patrimonio e /y/ la suma de
 las cuentas Dividendos provisorios, Dividendos provisionados según política, así como todas las demás cuentas
 relativas a provisión de dividendos, contenidas en el Estado Consolidado de Cambios en el Patrimonio del Emisor.
b. El Emisor deberá mantener una Cobertura de Gastos Financieros Consolidada no inferior a 2,5 veces, definida como
 la razón entre ROADA y Costos Financieros, en adelante la “Cobertura de Gastos Financieros Consolidada”. Para los
 efectos del cálculo de esta relación, se entenderá por: /i/ “ROADA” la suma de las cuentas Margen bruto y Otros
 ingresos por función, menos las cuentas Costos de distribución, Gastos de administración y Otros gastos por función,
 contenidas en el Estado Consolidado de Resultados por Función de los Estados Financieros Consolidados trimestrales
 del Emisor, y más la línea Depreciaciones y Amortizaciones registrada en la Nota Costos y Gastos por Naturaleza. /ii/
 “Costos Financieros”, la cuenta de igual denominación contenida en el Estado Consolidado de Resultados por Función.
 La Cobertura de Gastos Financieros Consolidada se calculará trimestralmente, sobre la información presentada en
 cada uno de los Estados Financieros Consolidados trimestrales del Emisor, para el periodo de 12 meses consecutivos
 anteriores a la fecha de los Estados Financieros Consolidados correspondientes, incluido el mes de cierre de dichos
 Estados Financieros Consolidados.
c. El Emisor deberá mantener un Patrimonio Ajustado a Nivel Consolidado, reflejado en cada uno de sus Estados
 Financieros Consolidados trimestrales, por un monto a lo menos igual a M$ 100.000.000. Para estos efectos, Patrimonio
 Ajustado corresponde a la suma de /i/ la cuenta Patrimonio atribuible a los propietarios de la controladora contenida en
 el Estado Consolidado de Situación Financiera, y /ii/ la suma de las cuentas Dividendos provisorios, Dividendos
 provisionados según política, así como todas las demás cuentas relativas a provisión de dividendos, contenidas en el
 Estado Consolidado de Cambios en el Patrimonio del Emisor.
d. No efectuar inversiones en instrumentos emitidos por “partes relacionadas” distintas de sus subsidiarias, ni efectuar
 con ellas otras operaciones ajenas a su giro habitual, en condiciones distintas a las establecidas en el contrato
 relacionadas distintas a sus filiales, no efectuar con ellas otras operaciones ajenas a su giro habitual.
e. Se obliga a registrar las provisiones que surjan de contingencias adversas, que a juicio de la administración deban ser
 referidos en los Estados Financieros Consolidados.
El riesgo de tipo de cambio al que se encuentra expuesto el Bono D, es mitigado parcialmente mediante el uso de contratos
Cross Currency Swap. Ver detalle de cobertura de la Compañía en Nota 7 - Instrumentos financieros.
Al 31 de diciembre de 2024, la subsidiaria estaba en cumplimiento con todos los requerimientos de esta obligación.
 108

[pág. 110]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
C) Restricciones y cumplimientos de las obligaciones financieras
1) Covenants - Préstamo Banco del Estado de Chile M$ 30.000.000 - Bonos Serie J, L, M, P.
a. El Emisor deberá mantener al final de cada trimestre un Nivel de Endeudamiento Financiero Neto Consolidado, reflejado
 en cada uno de sus Estados Financieros Consolidados trimestrales, no superior a 1,5 cero veces, definido como la
 razón entre “Deuda Financiera Neta” y “Total Patrimonio Ajustado”, en adelante “Nivel de Endeudamiento Financiero
 Neto Consolidado”. Para determinar el Nivel de Endeudamiento Financiero Neto Consolidado, se basará en los Estados
 Financieros Consolidados trimestrales, y se considerará lo siguiente: /i/ “Deuda Financiera Neta”, la diferencia entre /x/
 el monto insoluto de la “Deuda Financiera”, esto es, la suma de las líneas, corriente y no corriente, Préstamos bancarios,
 Obligaciones con el público y Obligaciones por arrendamientos financieros, contenidas en la Nota Otros pasivos
 financieros, y no será considerada para el cálculo y determinación de la Deuda Financiera Neta, el monto total del
 pasivo por obligación por derechos de uso de activos de la cuenta o subcuenta de "Arrendamientos IFRS Dieciséis",
 corriente y no corrientes, e /y/ el saldo del rubro Efectivo y Equivalentes al Efectivo, contenidos en el Estado Consolidado
 de Situación Financiera del Emisor; y /ii/ “Total Patrimonio Ajustado” la suma de /x/ Total Patrimonio e /y/ la suma de
 las cuentas Dividendos provisorios, Dividendos provisionados según política, así como todas las demás cuentas
 relativas a provisión de dividendos, contenidas en el Estado Consolidado de Cambios en el Patrimonio del Emisor.
b. El Emisor deberá mantener una cobertura de gastos financieros consolidada no inferior a tres veces, definida como la
 razón entre ROADA y Costos Financieros. El ROADA es la suma de las cuentas Margen bruto y Otros ingresos por
 función, menos las cuentas Costos de distribución, Gastos de administración y Otros gastos por función y más la línea
 Depreciaciones y Amortizaciones registrada en la Nota Costos y Gastos por Naturaleza. Por Costos Financieros, la
 cuenta de igual denominación contenida en el Estado Consolidado de Resultados por Función. La Cobertura de Gastos
 Financieros Consolidada se calculará para el periodo de doce meses consecutivos anteriores a la fecha de los Estados
 Financieros Consolidados correspondientes, incluido el mes de cierre de dichos Estados Financieros Consolidados.
c. El Emisor deberá mantener un Patrimonio Ajustado a Nivel Consolidado, reflejado en cada uno de sus Estados
 Financieros Consolidados trimestrales, por un monto a lo menos igual a M$ 312.516.750. Para estos efectos, Patrimonio
 Ajustado corresponde a la suma de /i/ la cuenta Patrimonio atribuible a los propietarios de la controladora contenida en
 el Estado Consolidado de Situación Financiera, y /ii/ la suma de las cuentas Dividendos provisorios, Dividendos
 provisionados según política, así como todas las demás cuentas relativas a provisión de dividendos, contenidas en el
 Estado Consolidado de Cambios en el Patrimonio de los Estados Financieros Consolidados trimestrales del Emisor.
d. Mantener Activos Libres de Gravámenes por un monto igual, a lo menos, a 1,2 veces el monto insoluto de la Deuda
 Financiera sin garantías. Para estos efectos, los activos y las deudas se valorizarán a valor libro. Se entenderá por: /a/
 por Activos Libres de Gravámenes, la diferencia entre /i/ la cuenta Total Activos contenida en el Estado Consolidado
 de Situación Financiera, y /ii/ los activos dados en garantía indicados en la Nota sobre Contingencias y Compromisos
 de los Estados Financieros Consolidados; e /b/ por Deuda Financiera, la definición dada a dicho término se encuentra
 en el Contrato de Emisión.
 109

[pág. 111]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
El cálculo de los índices financieros descritos anteriormente son los siguientes:
 Al 31 de diciembre de 2024
 N° Índices Notas
 M$ Exigido Determinado
 a NIVEL DE ENDEUDAMIENTO CONSOLIDADO ≤ 1,5
 (i) Préstamos bancarios 21 207.904.935
 (ii) Obligaciones con el público 21 1.157.437.074
 (iii) Obligaciones por arrendamientos financieros (**) 22 21.822.970
 (iv) Efectivo y equivalentes al efectivo 8 (707.122.815)
 Deuda financiera neta 680.042.164
 (i) Total Patrimonio 1.672.515.310
 (ii) Dividendos provisionados según política 27 37.055.482
 (iii) Dividendos provisorios 43.416.587
 Total Patrimonio ajustado 1.752.987.379
 Deuda financiera neta / Total Patrimonio ajustado (veces) ≤ 1,50 0,39
 b COBERTURA DE GASTOS FINANCIEROS CONSOLIDADA > 3,00 (ÚLTIMOS DOCE MESES MÓVILES)
 (i) Margen bruto 1.313.608.677
 (ii) Otros ingresos por función 31 40.211.510
 (iii) Costos de distribución 30 (536.420.140)
 (iv) Gastos de administración 30 (214.915.089)
 (v) Otros gastos por función 30 (339.783.068)
 (vi) Depreciación y amortización 30 153.234.224
 ROADA (*) últimos doce meses móviles 415.936.114
 Costos financieros 33 97.165.278
 ROADA/ Costos financieros (veces) (últimos doce meses móviles) > 3,00 4,28
 c PATRIMONIO AJUSTADO A NIVEL CONSOLIDADO > M$ 312.516.750
 (i) Patrimonio atribuible a los propietarios de la controladora 1.525.183.185
 (ii) Dividendos provisionados según política 27 37.055.482
 (iii) Dividendos provisorios 43.416.587
 Patrimonio ajustado > M$ 312.516.750 M$ 1.605.655.254
 d ACTIVOS LIBRES DE GRAVÁMENES CONSOLIDADOS > 1,20
 (i) Total Activos 3.989.716.990
 Activos libres de gravámenes 3.989.716.990
 (i) Préstamos bancarios 21 207.904.935
 (ii) Obligaciones con el público 21 1.157.437.074
 (iii) Obligaciones por arrendamientos financieros (**) 22 21.822.970
 Deuda financiera 1.387.164.979
 Activos libres de gravámenes / Deuda financiera > 1,20 2,88
(*) ROADA, Resultado Operacional Ajustado, se define como el Resultado Operacional Ajustado antes de Depreciación y Amortización.
(**) Bajo este concepto no se incorpora los efectos por aplicación de IFRS 16.
 e. Mantener, directa o indirectamente, la propiedad de más del cincuenta por ciento de los derechos sociales y de las
 acciones suscritas y pagadas, respectivamente, de: /a/ Cervecera CCU Chile Limitada y /b/ Embotelladoras
 Chilenas Unidas S.A.
 f. Mantener una capacidad instalada nominal para la elaboración indistintamente de Cervezas y/o Bebidas
 Analcohólicas y/o Néctares y/o Aguas Minerales y/o Envasadas, en adelante los “Negocios Esenciales”, igual o no
 inferior, ya sea respecto de una o más de las referidas categorías o todas ellas en conjunto, a 15,9 millones de
 hectolitros anuales.
 g. Mantener, directamente o a través de una subsidiaria, la propiedad de la marca comercial “CRISTAL”, denominativa
 o palabra, para cerveza, en la clase 32 del Clasificador Internacional de Productos y Servicios para el registro de
 marcas comerciales.
 110

[pág. 112]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
 h. No efectuar inversiones en instrumentos emitidos por “partes relacionadas” distintas de sus subsidiarias, ni efectuar
 con ellas otras operaciones ajenas a su giro habitual, en condiciones distintas a las establecidas en el Título XVI de
 la Ley sobre Sociedades Anónimas.
Al 31 de diciembre de 2024, la Compañía estaba en cumplimiento con todos los requerimientos de esta obligación.
2) Covenants - Préstamos Banco del Estado de Chile M$ 90.000.000 - Bono Serie R.
a. El Emisor deberá mantener al final de cada trimestre un Nivel de Endeudamiento Financiero Neto Consolidado, reflejado
 en cada uno de sus Estados Financieros Consolidados trimestrales, no superior a 1,5 cero veces, definido como la razón
 entre “Deuda Financiera Neta” y “Total Patrimonio Ajustado”, en adelante “Nivel de Endeudamiento Financiero Neto
 Consolidado”. Para determinar el Nivel de Endeudamiento Financiero Neto Consolidado, se basará en los Estados
 Financieros Consolidados trimestrales, y se considerará lo siguiente: /i/ “Deuda Financiera Neta”, la diferencia entre /x/
 el monto insoluto de la “Deuda Financiera”, esto es, la suma de las líneas, corriente y no corriente, Préstamos bancarios,
 Obligaciones con el público, contenidas en la Nota Otros pasivos financieros, and /ii/ “Total Patrimonio Ajustado” la suma
 de /x/ Total Patrimonio e /y/ la suma de las cuentas Dividendos provisorios, Dividendos provisionados según política, así
 como todas las demás cuentas relativas a provisión de dividendos, contenidas en el Estado Consolidado de Cambios
 en el Patrimonio del Emisor.
b. El Emisor deberá mantener una Cobertura de Gastos Financieros Consolidada no inferior a tres veces, definida como
 la razón entre ROADA y Costos Financieros. Para los efectos del cálculo de esta relación, se entenderá por ROADA la
 suma de las cuentas Margen bruto y Otros ingresos por función, menos las cuentas Costos de distribución, Gastos de
 administración y Otros gastos por función, contenidas en el Estado Consolidado de Resultados por Función de los
 Estados Financieros Consolidados trimestrales del Emisor, y más la línea Depreciaciones y Amortizaciones registrada
 en la Nota Costos y gastos por naturaleza. Por Costos Financieros, la cuenta de igual denominación contenida en el
 Estado Consolidado de Resultados por Función. La Cobertura de Gastos Financieros Consolidada se calculará
 trimestralmente, sobre la información presentada en cada uno de los Estados Financieros Consolidados trimestrales
 del Emisor, para el periodo de doce meses consecutivos anteriores a la fecha de los Estados Financieros Consolidados
 correspondientes, incluido el mes de cierre de dichos Estados Financieros Consolidados.
c. El Emisor deberá mantener un Patrimonio Ajustado a Nivel Consolidado, reflejado en cada uno de sus Estados
 Financieros Consolidados trimestrales, por un monto a lo menos igual a M$ 312.516.750. Para estos efectos, Patrimonio
 Ajustado corresponde a la suma de /i/ la cuenta Patrimonio atribuible a los propietarios de la controladora contenida en
 el Estado Consolidado de Situación Financiera, y /ii/ la suma de las cuentas Dividendos provisorios, Dividendos
 provisionados según política, así como todas las demás cuentas relativas a provisión de dividendos, contenidas en el
 Estado Consolidado de Cambios en el Patrimonio de los Estados Financieros Consolidados trimestrales del Emisor.
d. El Emisor deberá mantener Activos Libres de Gravámenes por un monto igual, a lo menos, a 1,2 veces el monto insoluto
 de la Deuda Financiera sin garantías mantenida por el Emisor. Para estos efectos, los activos y las deudas se
 valorizarán a valor libro. Se entenderá por: /a/ por Activos Libres de Gravámenes, la diferencia entre /i/ la cuenta Total
 Activos contenida en el Estado Consolidado de Situación Financiera, y /ii/ los activos dados en garantía indicados en
 la Nota sobre Contingencias y compromisos de los Estados Financieros Consolidados del Emisor; e /b/ por Deuda
 Financiera, la definición dada a dicho término en el numeral Cuatro letra a/ /i/ de la cláusula Décimo Quinta del Contrato
 de Emisión. Se deja expresa constancia y se establece que, a contar de la fecha de entrada en vigencia obligatoria de
 la IFRS número dieciséis, esto es, el primero de enero de dos mil diecinueve, emitida y aprobada por el Consejo de
 Normas Internacionales de Contabilidad, y respecto del cálculo de Deuda Financiera que deba efectuarse conforme a
 los numerales Cuatro y Cinco de la cláusula Décimo Quinta del Contrato de Emisión con posterioridad a dicha fecha,
 la cuenta -o subcuenta respectiva- referida al monto total del pasivo por obligación por derechos de uso de activos o el
 nombre que defina la Comisión al efecto, que con motivo de la entrada en vigencia de la citada norma deban exponerse
 como un pasivo financiero dentro de los rubros Otros pasivos financieros corrientes y Otros pasivos financieros no
 corrientes, no será considerada, incorporada ni utilizada para el cálculo y determinación de dicha Deuda Financiera.
 111

[pág. 113]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
El cálculo de los índices financieros descritos anteriormente son los siguientes:
 Al 31 de diciembre de 2024
 N° Índices Notas
 M$ Exigido Determinado
 a Mayor valor
 (i) Préstamos bancarios 21 207.904.935
 (ii) Obligaciones con el público 21 1.157.437.074
 (iii) Efectivo y equivalentes al efectivo 8 (707.122.815)
 Deuda financiera neta 658.219.194
 (i) Total Patrimonio 1.672.515.310
 (ii) Dividendos provisionados según política 27 37.055.482
 (iii) Dividendos provisorios 43.416.587
 Total Patrimonio ajustado 1.763.552.739
 Deuda financiera neta / Total Patrimonio ajustado (veces) ≤ 1,50 0,37
 b COBERTURA DE GASTOS FINANCIEROS CONSOLIDADA > 3,00 (ÚLTIMOS DOCE MESES MÓVILES)
 (i) Margen bruto 1.313.608.677
 (ii) Otros ingresos por función 31 40.211.510
 (iii) Costos de distribución 30 (536.420.140)
 (iv) Gastos de administración 30 (214.915.089)
 (v) Otros gastos por función 30 (339.783.068)
 (vi) Depreciación y amortización 30 153.234.224
 ROADA (*) últimos doce meses móviles 415.936.114
 Costos financieros 33 97.165.278
 ROADA/ Costos financieros (veces) (últimos doce meses móviles) > 3,00 4,28
 c PATRIMONIO AJUSTADO A NIVEL CONSOLIDADO > M$ 312.516.750
 (i) Patrimonio atribuible a los propietarios de la controladora 1.525.183.185
 (ii) Dividendos provisionados según política 27 37.055.482
 (iii) Dividendos provisorios 43.416.587
 Patrimonio ajustado > M$ 312.516.750 M$ 1.605.655.254
 d ACTIVOS LIBRES DE GRAVÁMENES CONSOLIDADOS > 1,20
 (i) Total Activos 3.989.716.990
 Activos libres de gravámenes 3.989.716.990
 (i) Préstamos bancarios 21 207.904.935
 (ii) Obligaciones con el público 21 1.157.437.074
 Deuda financiera 1.365.342.009
 Activos libres de gravámenes / Deuda financiera > 1,20 2,92
(*) ROADA, Resultado Operacional Ajustado, se define como el Resultado Operacional Ajustado antes de Depreciación y Amortización.
 e. Mantener, directa o indirectamente, la propiedad de más del cincuenta por ciento de los derechos sociales y de las
 acciones suscritas y pagadas, respectivamente, de: /a/ Cervecera CCU Chile Limitada y /b/ Embotelladoras Chilenas
 Unidas S.A.
 f. Mantener una capacidad instalada nominal para la elaboración indistintamente de Cervezas y/o Bebidas
 Analcohólicas y/o Néctares y/o Aguas Minerales y/o Envasadas, en adelante los “Negocios Esenciales”, igual o no
 inferior, ya sea respecto de una o más de las referidas categorías o todas ellas en conjunto, a 15,9 millones de
 hectolitros anuales.
 g. Mantener, directamente o a través de una subsidiaria, la propiedad de la marca comercial “CRISTAL”, denominativa
 o palabra, para cerveza, en la clase 32 del Clasificador Internacional de Productos y Servicios para el registro de
 marcas comerciales.
 h. No efectuar inversiones en instrumentos emitidos por “partes relacionadas” distintas de sus subsidiarias, ni efectuar
 con ellas otras operaciones ajenas a su giro habitual, en condiciones distintas a las establecidas en el Título XVI de
 la Ley sobre Sociedades Anónimas.
Al 31 de diciembre de 2024, la Compañía estaba en cumplimiento con todos los requerimientos de esta obligación.
 112

[pág. 114]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 22 Arrendamientos
Activos por derecho de uso
El valor libro neto de terrenos, edificios, maquinarias, enseres y accesorios y otras propiedades, planta y equipos corresponde
a contratos de arrendamiento financiero. El movimiento por los activos por derechos de uso es el siguiente:
 Enseres,
 accesorios y
 Terrenos y otras
 Maquinarias Total
 edificios propiedades,
 plantas y
 equipos
 M$ M$ M$ M$
 Al 1 de enero de 2023
 Costo histórico 44.902.809 8.686.624 5.697.398 59.286.831
 Depreciación acumulada (16.224.686) (5.913.230) (2.282.944) (24.420.860)
 Valor libro 28.678.123 2.773.394 3.414.454 34.865.971
 Adiciones 9.761.428 2.049.490 285.144 12.096.062
 Adiciones por combinaciones de negocios (costo histórico) (2) - - 26.726 26.726
 Efecto conversión (costo histórico) (3.605.945) (5.279.722) 14.083 (8.871.584)
 Depreciación del ejercicio (*) (7.720.353) (1.576.613) (1.684.616) (10.981.582)
 Efecto conversión (depreciación) 1.998.626 2.694.334 (7.316) 4.685.644
 Otros incrementos (disminuciones) (1) 1.844.506 1.888.499 296.829 4.029.834
 Bajas del ejercicio (costo) (144.097) - - (144.097)
 Bajas del ejercicio (depreciación) 38.247 - - 38.247
 Subtotales 2.172.412 (224.012) (1.069.150) 879.250
 Valor libro 30.850.535 2.549.382 2.345.304 35.745.221
 Al 31 de diciembre de 2023
 Costo histórico 51.646.199 8.632.533 6.204.646 66.483.378
 Depreciación acumulada (20.795.664) (6.083.151) (3.859.342) (30.738.157)
 Valor libro 30.850.535 2.549.382 2.345.304 35.745.221
 Al 31 de diciembre de 2024
 Adiciones 14.742.255 710.231 3.875.974 19.328.460
 Adiciones por combinaciones de negocios (costo histórico) (2) 119.480 - - 119.480
 Efecto conversión (costo histórico) (394.723) (493.868) (16.876) (905.467)
 Depreciación del ejercicio (*) (8.414.007) (2.156.709) (1.403.956) (11.974.672)
 Efecto conversión (depreciación) 254.338 345.043 (6.199) 593.182
 Otros incrementos (disminuciones) (1) 716.535 1.656.746 61.076 2.434.357
 Bajas del ejercicio (costo) (293.531) (264.372) (250.557) (808.460)
 Bajas del ejercicio (depreciación) 183.848 181.719 119.504 485.071
 Subtotales 6.914.195 (21.210) 2.378.966 9.271.951
 Valor libro 37.764.730 2.528.172 4.724.270 45.017.172
 Al 31 de diciembre de 2024
 Costo histórico 67.640.867 12.451.324 9.861.206 89.953.397
 Depreciación acumulada (29.876.137) (9.923.152) (5.136.936) (44.936.225)
 Valor libro 37.764.730 2.528.172 4.724.270 45.017.172
(1) Corresponde principalmente al efecto financiero de la aplicación de la IAS 29 “Información Financiera en Economías Hiperinflacionarias”.
(2) Ver Nota 1 - Información general, letra C), numerales (4) para 2024 y (5) para 2023.
(*) Este monto incluye M$ 331.402 (M$ 849.277 en 2023) de depreciación activada por activos agrícolas, asociado al costo de venta de vino.
 113

[pág. 115]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Pasivos por arrendamientos
Los pasivos por arrendamientos que devengan intereses, clasificados por tipo de obligación y por su clasificación en el
Estado Consolidado de Situación Financiera son los siguientes:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Corriente No corriente Corriente No corriente
 M$ M$ M$ M$
 Obligaciones por arrendamientos (1) 9.451.551 39.782.317 7.142.360 34.061.739
 Total 9.451.551 39.782.317 7.142.360 34.061.739
(1) Ver Nota 5 - Administración de riesgos.
El acuerdo de arrendamiento más significativo es el siguiente:
CCU S.A.
En diciembre de 2004, la Compañía vendió un terreno previamente clasificado como propiedad de inversión. Como parte de
la transacción se contempló que la Compañía debería arrendar once pisos en un edificio que se iba a construir sobre el
terreno antes mencionado.
El edificio se terminó de construir el año 2007, firmando CCU con fecha 28 de junio de 2007 un contrato de arrendamiento
por 25 años con la Compañía de Seguros de Vida Consorcio Nacional de Seguros S.A. por un monto total de
UF 688.635,63 y con un interés anual del 7,07%. El valor del contrato ascendió a M$ 10.403.632 al 31 de diciembre de 2007.
El contrato otorgó además a CCU el derecho u opción de adquirir los bienes objeto de contrato (inmuebles, muebles e
instalaciones) a partir del mes 68 de vigencia. Las rentas de arriendo comprometidas obedecen a condiciones de mercado.
Al momento de la venta la Compañía reconoció una ganancia de M$ 3.108.950 por la porción del edificio que la Compañía
no arrendó y un pasivo M$ 2.276.677 que se difirió hasta el término de la construcción del Edificio, momento en que la
Compañía registró la operación como leasing financiero.
Con fecha 28 de febrero de 2018, la Compañía realiza una modificación al contrato de arrendamiento celebrado con la
Compañía de Seguros de Vida Consorcio Nacional de Seguros S.A., quedando un saldo de la deuda en UF 608.375, con
interés anual del 2,59% y con vencimiento el 5 de febrero de 2048.
Los vencimientos a valor libro, a valor nominal y tasas de interés de estas obligaciones son los siguientes:
Pasivos por arrendamientos corrientes
Al 31 de diciembre de 2024
Pasivos por arrendamientos a valor libro:
 Vencimientos (*)
 Moneda
 País Tasa
 Rut empresa Rut País o unidad Más de 90 días Tipo de
 Nombre empresa deudora empresa Nombre acreedor Hasta 90 días Total de
 deudora acreedor acreedor de hasta 1 año amortización
 deudora interés
 reajuste
 M$ M$ M$ (%)
 Arrendamientos financieros
 79.862.750-3 Transportes CCU Limitada Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 16.426 50.596 67.022 Mensual 4,49
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 99.012.000-5 Consorcio Nacional de Seguros S.A. Chile UF 150.334 459.014 609.348 Mensual 4,77
 Subtotal 166.760 509.610 676.370
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile CLP 266.922 126.904 393.826 Mensual 4,45
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile UF 1.687.789 4.611.407 6.299.196 Mensual 4,09
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile USD 165.634 381.028 546.662 Mensual 4,00
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina ARS 111.701 290.702 402.403 Mensual 0,66
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina USD 196.759 590.279 787.038 Mensual 0,08
 0-E CCU y subsidiarias Uruguay - Proveedores de PPE Uruguay UYU 45.183 135.550 180.733 Mensual 3,18
 0-E CCU y subsidiarias Paraguay - Proveedores de PPE Paraguay PYG 41.095 124.228 165.323 Mensual 0,10
 Subtotal (arrendamientos IFRS) 2.515.083 6.260.098 8.775.181
 Total 2.681.843 6.769.708 9.451.551
(*) El monto basado en los flujos contractuales no descontados se encuentra en Nota 5 - Administración de riesgos.
 114

[pág. 116]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Pasivos por arrendamientos a valor nominal:
 Vencimientos
 Moneda
 País
 Rut empresa País o unidad Más de 90 días Tipo de
 Nombre empresa deudora empresa Rut acreedor Nombre acreedor Hasta 90 días Total
 deudora acreedor de hasta 1 año amortización
 deudora
 reajuste
 M$ M$ M$
 Arrendamientos financieros
 79.862.750-3 Transportes CCU Limitada Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 17.933 53.801 71.734 Mensual
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 99.012.000-5 Consorcio Nacional de Seguros S.A. Chile UF 332.723 998.169 1.330.892 Mensual
 Subtotal 350.656 1.051.970 1.402.626
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile CLP 325.604 274.379 599.983 Mensual
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile UF 1.432.326 3.336.686 4.769.012 Mensual
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile USD 527.860 1.517.399 2.045.259 Mensual
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina ARS 230.259 633.511 863.770 Mensual
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina USD 245.335 736.004 981.339 Mensual
 0-E CCU y subsidiarias Uruguay - Proveedores de PPE Uruguay UYU 54.132 162.396 216.528 Mensual
 0-E CCU y subsidiarias Paraguay - Proveedores de PPE Paraguay PYG 51.708 150.184 201.892 Mensual
 Subtotal (arrendamientos IFRS) 2.867.224 6.810.559 9.677.783
 Total 3.217.880 7.862.529 11.080.409
Al 31 de diciembre de 2023
Pasivos por arrendamientos a valor libro:
 Vencimientos (*)
 Moneda
 País Tasa
 Rut empresa Rut País o unidad Más de 90 días Tipo de
 Nombre empresa deudora empresa Nombre acreedor Hasta 90 días Total de
 deudora acreedor acreedor de hasta 1 año amortización
 deudora interés
 reajuste
 M$ M$ M$ (%)
 Arrendamientos financieros
 79.862.750-3 Transportes CCU Limitada Chile 97.030.000-7 Banco del Estado de Chile Chile UF 46.742 58.352 105.094 Mensual 2,14
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 99.012.000-5 Consorcio Nacional de Seguros S.A. Chile UF 138.201 421.929 560.130 Mensual 3,95
 Subtotal 184.943 480.281 665.224
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile CLP 81.801 96.742 178.543 Mensual 2,61
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile Euros 10.764 32.291 43.055 Mensual 1,80
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile UF 1.508.830 3.748.411 5.257.241 Mensual 2,96
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile USD 94.946 284.840 379.786 Mensual 3,17
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina ARS 103.598 181.762 285.360 Mensual 33,61
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina USD 64.814 160.461 225.275 Mensual 16,33
 0-E CCU y subsidiarias Uruguay - Proveedores de PPE Uruguay UYU 34.985 72.891 107.876 Mensual 0,84
 Subtotal (arrendamientos IFRS) 1.899.738 4.577.398 6.477.136
 Total 2.084.681 5.057.679 7.142.360
(*) El monto basado en los flujos contractuales no descontados se encuentra en Nota 5 - Administración de riesgos.
Pasivos por arrendamientos a valor nominal:
 Vencimientos
 Moneda
 País
 Rut empresa País o unidad Más de 90 días Tipo de
 Nombre empresa deudora empresa Rut acreedor Nombre acreedor Hasta 90 días Total
 deudora acreedor de hasta 1 año amortización
 deudora
 reajuste
 M$ M$ M$
 Arrendamientos financieros
 79.862.750-3 Transportes CCU Limitada Chile 97.030.000-7 Banco del Estado de Chile Chile UF 49.257 64.180 113.437 Mensual
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 99.012.000-5 Consorcio Nacional de Seguros S.A. Chile UF 318.629 955.887 1.274.516 Mensual
 Subtotal 367.886 1.020.067 1.387.953
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile CLP 86.780 111.905 198.685 Mensual
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile Euros 10.767 32.301 43.068 Mensual
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile UF 1.585.174 4.222.379 5.807.553 Mensual
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile USD 31.917 95.753 127.670 Mensual
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina ARS 209.906 481.331 691.237 Mensual
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina USD 83.515 206.356 289.871 Mensual
 0-E CCU y subsidiarias Uruguay - Proveedores de PPE Uruguay UYU 41.835 88.294 130.129 Mensual
 Subtotal (arrendamientos IFRS) 2.049.894 5.238.319 7.288.213
 Total 2.417.780 6.258.386 8.676.166
 115

[pág. 117]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Pasivos por arrendamientos no corrientes
Al 31 de diciembre de 2024
Pasivos por arrendamientos a valor libro:
 Vencimientos (*)
 Moneda
 Rut País o Más de 3 Tasa
 Rut País Más de 1 año Tipo de
 empresa Nombre empresa deudora empresa Nombre acreedor unidad años hasta 5 Más de 5 años Total de
 acreedor acreedor hasta 3 años amortización
 deudora deudora de años interés
 reajuste
 M$ M$ M$ M$ (%)
 Arrendamientos financieros
 79.862.750-3 Transportes CCU Limitada Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 52.636 - - 52.636 Mensual 2,14
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 99.012.000-5 Consorcio Nacional de Seguros S.A. Chile UF 1.285.168 1.379.838 18.428.958 21.093.964 Mensual 3,95
 Subtotal 1.337.804 1.379.838 18.428.958 21.146.600
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile CLP 19.321 - - 19.321 Mensual 4,16
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile UF 7.623.227 4.241.420 1.422.083 13.286.730 Mensual 4,09
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile USD 366.173 349.822 1.017.761 1.733.756 Mensual 4,00
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina ARS 326.100 107.311 - 433.411 Mensual 0,66
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina USD 1.545.505 1.082.238 - 2.627.743 Mensual 0,08
 0-E CCU y subsidiarias Uruguay - Proveedores de PPE Uruguay UYU 284.040 - - 284.040 Mensual 3,18
 0-E CCU y subsidiarias Paraguay - Proveedores de PPE Paraguay PYG 157.168 93.548 - 250.716 Mensual 0,10
 Subtotal (arrendamientos IFRS) 10.321.534 5.874.339 2.439.844 18.635.717
 Total 11.659.338 7.254.177 20.868.802 39.782.317
(*) El monto basado en los flujos contractuales no descontados se encuentra en Nota 5 - Administración de riesgos.
Pasivos por arrendamientos a valor nominal:
 Vencimientos
 Moneda
 País o
 Rut empresa Rut País Más de 1 año Más de 3 años Tipo de
 Nombre empresa deudora empresa Nombre acreedor unidad Más de 5 años Total
 deudora acreedor acreedor hasta 3 años hasta 5 años amortización
 deudora de
 reajuste
 M$ M$ M$ M$
 Arrendamientos financieros
 79.862.750-3 Transportes CCU Limitada Chile 97.030.000-7 Banco del Estado de Chile Chile CLP 53.800 - - 53.800 Mensual
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 99.012.000-5 Consorcio Nacional de Seguros S.A. Chile UF 2.661.784 2.661.784 24.177.873 29.501.441 Mensual
 Subtotal 2.715.584 2.661.784 24.177.873 29.555.241
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile CLP 504.286 140.151 - 644.437 Mensual
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile UF 5.372.599 2.661.773 626.856 8.661.228 Mensual
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile USD 2.138.893 1.188.049 1.357.385 4.684.327 Mensual
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina ARS 918.048 524.460 - 1.442.508 Mensual
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina USD 1.780.137 1.249.933 - 3.030.070 Mensual
 0-E CCU y subsidiarias Uruguay - Proveedores de PPE Uruguay UYU 333.391 - - 333.391 Mensual
 0-E CCU y subsidiarias Paraguay - Proveedores de PPE Paraguay PYG 193.267 104.757 - 298.024 Mensual
 Subtotal (arrendamientos IFRS) 11.240.621 5.869.123 1.984.241 19.093.985
 Total 13.956.205 8.530.907 26.162.114 48.649.226
Al 31 de diciembre de 2023
Pasivos por arrendamientos a valor libro:
 Vencimientos (*)
 Moneda
 Rut País o Más de 3 Tasa
 Rut País Más de 1 año Tipo de
 empresa Nombre empresa deudora empresa Nombre acreedor unidad años hasta 5 Más de 5 años Total de
 acreedor acreedor hasta 3 años amortización
 deudora deudora de años interés
 reajuste
 M$ M$ M$ M$ (%)
 Arrendamientos financieros
 79.862.750-3 Transportes CCU Limitada Chile 97.030.000-7 Banco del Estado de Chile Chile UF 119.659 - - 119.659 Mensual 2,14
 90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 99.012.000-5 Consorcio Nacional de Seguros S.A. Chile UF 1.224.345 1.224.345 18.420.051 20.868.741 Mensual 3,95
 Subtotal 1.344.004 1.224.345 18.420.051 20.988.400
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile UF 6.824.508 2.701.396 943.701 10.469.605 Mensual 2,96
 0-E CCU y subsidiarias Chile - Proveedores de PPE Chile USD 449.743 322.646 1.011.076 1.783.465 Mensual 3,17
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina ARS 260.266 89.050 43.906 393.222 Mensual 33,61
 0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina USD 347.908 2.668 - 350.576 Mensual 16,33
 0-E CCU y subsidiarias Uruguay - Proveedores de PPE Uruguay UYU 76.471 - - 76.471 Mensual 0,84
 Subtotal (arrendamientos IFRS) 7.958.896 3.115.760 1.998.683 13.073.339
 Total 9.302.900 4.340.105 20.418.734 34.061.739
(*) El monto basado en los flujos contractuales no descontados se encuentra en Nota 5 - Administración de riesgos.
 116

[pág. 118]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Pasivos por arrendamientos a valor nominal:
 Vencimientos (*)
 Moneda
 País o
 Rut empresa Rut País Más de 1 año Más de 3 años Tipo de
 Nombre empresa deudora empresa Nombre acreedor unidad Más de 5 años Total
 deudora acreedor acreedor hasta 3 años hasta 5 años amortización
 deudora de
 reajuste
 M$ M$ M$ M$
Arrendamientos financieros
79.862.750-3 Transportes CCU Limitada Chile 97.030.000-7 Banco del Estado de Chile Chile UF 125.536 - - 125.536 Mensual
90.413.000-1 Compañía Cervecerías Unidas S.A. Chile 99.012.000-5 Consorcio Nacional de Seguros S.A. Chile UF 2.549.031 2.549.030 24.640.634 29.738.695 Mensual
Subtotal 2.674.567 2.549.030 24.640.634 29.864.231
0-E CCU y subsidiarias Chile - Proveedores de PPE Chile Euros 12.108 - - 12.108 Mensual
0-E CCU y subsidiarias Chile - Proveedores de PPE Chile UF 8.394.381 2.996.536 1.170.637 12.561.554 Mensual
0-E CCU y subsidiarias Chile - Proveedores de PPE Chile USD 129.859 78.664 446.295 654.818 Mensual
0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina ARS 946.597 520.514 260.980 1.728.091 Mensual
0-E CCU y subsidiarias Argentina - Proveedores de PPE Argentina USD 402.941 5.028 - 407.969 Mensual
0-E CCU y subsidiarias Uruguay - Proveedores de PPE Uruguay UYU 97.377 - - 97.377 Mensual
Subtotal (arrendamientos IFRS) 9.983.263 3.600.742 1.877.912 15.461.917
Total 12.657.830 6.149.772 26.518.546 45.326.148
A continuación se presenta el detalle de los pagos futuros y el valor de los compromisos por arrendamientos:
 Al 31 de diciembre de 2024
 Monto bruto
 Interés Valor
 interés
 M$ M$ M$
Hasta 90 días 3.217.880 536.037 2.681.843
Más de 90 días hasta 1 año 7.862.529 1.092.821 6.769.708
Más de 1 año hasta 3 años 13.956.205 2.296.867 11.659.338
Más de 3 años hasta 5 años 8.530.907 1.276.730 7.254.177
Más de 5 años 26.162.114 5.293.312 20.868.802
Total 59.729.635 10.495.767 49.233.868
 Al 31 de diciembre de 2023
 Monto bruto
 Interés Valor
 interés
 M$ M$ M$
Hasta 90 días 2.417.780 333.099 2.084.681
Más de 90 días hasta 1 año 6.258.386 1.200.707 5.057.679
Más de 1 año hasta 3 años 12.657.830 3.354.930 9.302.900
Más de 3 años hasta 5 años 6.149.772 1.809.667 4.340.105
Más de 5 años 26.518.546 6.099.812 20.418.734
Total 54.002.314 12.798.215 41.204.099
 117

[pág. 119]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Conciliación de pasivos que surgen de actividades de financiación:
 Flujos Variación por
 Incremento a
 moneda Adiciones por
 Al 31 de Pagos Devengo de través de Al 31 de
 extranjera o combinaciones Otros
 diciembre de 2023 Adquisiciones intereses nuevos diciembre de 2024
 unidad de de negocios (1)
 Capital Intereses arrendamientos
 reajustes
 M$ M$ M$ M$ M$ M$ M$ M$ M$ M$
Otros pasivos financieros
Corriente
 Préstamos bancarios 24.494.870 (43.967.653) (15.109.004) 52.903.303 13.662.655 1.304.411 - - 7.969.029 41.257.611
 Obligaciones con el público 38.650.859 - (31.266.863) - 31.803.416 1.755.653 - - 57.490.089 98.433.154
 Obligaciones por arrendamientos 7.142.360 (16.274.873) (1.902.393) - 1.598.887 2.204.844 119.480 3.626.892 12.936.354 9.451.551
Total otros pasivos financieros corrientes 70.288.089 (60.242.526) (48.278.260) 52.903.303 47.064.958 5.264.908 119.480 3.626.892 78.395.472 149.142.316
No corriente
 Préstamos bancarios 174.074.170 (1.939.484) - - - 8.762 - - (5.496.124) 166.647.324
 Obligaciones con el público 1.050.838.488 (28.398.859) - - - 94.054.380 - - (57.490.089) 1.059.003.920
 Obligaciones por arrendamientos 34.061.739 - - - - 3.803.328 - 15.701.568 (13.784.318) 39.782.317
Total otros pasivos financieros no corrientes 1.258.974.397 (30.338.343) - - - 97.866.470 - 15.701.568 (76.770.531) 1.265.433.561
Total Otros pasivos financieros 1.329.262.486 (90.580.869) (48.278.260) 52.903.303 47.064.958 103.131.378 119.480 19.328.460 1.624.941 1.414.575.877
(1) Ver Nota 1 - Información general, letra C), numeral (12).
 Flujos Variación por
 Adiciones por Incremento a
 Al 31 de moneda Al 31 de
 Pagos Devengo de combinaciones través de
 diciembre de extranjera o Otros diciembre de
 Adquisiciones intereses de negocios nuevos
 2022 unidad de 2023
 Capital Intereses (1) arrendamientos
 reajustes
 M$ M$ M$ M$ M$ M$ M$ M$ M$ M$
 Otros pasivos financieros
 Corriente
 Préstamos bancarios 134.737.116 (86.424.860) (18.541.141) 68.928.016 13.887.323 2.258.552 - - (90.350.136) 24.494.870
 Obligaciones con el público 30.871.086 (26.621.937) (32.003.201) - 32.044.502 660.734 - - 33.699.675 38.650.859
 Obligaciones por arrendamientos 9.120.616 (10.704.270) (1.647.488) - 1.808.779 (1.289.212) 26.726 3.224.024 6.603.185 7.142.360
 Total otros pasivos financieros corrientes 174.728.818 (123.751.067) (52.191.830) 68.928.016 47.740.604 1.630.074 26.726 3.224.024 (50.047.276) 70.288.089
 No corriente
 Préstamos bancarios 84.839.970 (10.000.000) - 8.219.455 - 6.775 - - 91.007.970 174.074.170
 Obligaciones con el público 1.081.682.928 (36.373.728) - - - 39.228.963 - - (33.699.675) 1.050.838.488
 Obligaciones por arrendamientos 31.306.552 - - - - 2.824.911 - 8.872.038 (8.941.762) 34.061.739
 Total otros pasivos financieros no corrientes 1.197.829.450 (46.373.728) - 8.219.455 - 42.060.649 - 8.872.038 48.366.533 1.258.974.397
 Total Otros pasivos financieros 1.372.558.268 (170.124.795) (52.191.830) 77.147.471 47.740.604 43.690.723 26.726 12.096.062 (1.680.743) 1.329.262.486
(1) Ver Nota 1 - Información general, letra C), numeral (5).
 118

[pág. 120]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
 Flujos Variación
 Al 31 de por moneda Adiciones por Incremento a Al 31 de
 Pagos Devengo de
 diciembre de extranjera o combinaciones través de nuevos Otros diciembre de
 Adquisiciones intereses
 2021 unidad de de negocios arrendamientos 2022
 Capital Intereses
 reajustes
 M$ M$ M$ M$ M$ M$ M$ M$
Otros pasivos financieros
Corriente
 Préstamos bancarios 76.169.204 (73.375.368) (7.972.184) 46.843.478 14.857.608 28.076 - - 78.186.302 134.737.116
 Obligaciones con el público 8.087.630 (5.975.742) (18.250.558) - 26.872.771 1.559.386 - - 18.577.599 30.871.086
 Obligaciones por arrendamientos 6.152.361 (9.663.757) (1.792.084) - 1.721.895 1.093.203 - 4.796.273 6.812.725 9.120.616
Total otros pasivos financieros corrientes 90.409.195 (89.014.867) (28.014.826) 46.843.478 43.452.274 2.680.665 - 4.796.273 103.576.626 174.728.818
No corriente
 Préstamos bancarios 114.492.596 - - 49.445.891 - 19.585 - - (79.118.102) 84.839.970
 Obligaciones con el público 339.740.414 - - 686.832.951 - 73.687.162 - - (18.577.599) 1.081.682.928
 Obligaciones por arrendamientos 29.009.023 - - - - 3.823.816 - 7.296.971 (8.823.258) 31.306.552
Total otros pasivos financieros no corrientes 483.242.033 - - 736.278.842 - 77.530.563 - 7.296.971 (106.518.959) 1.197.829.450
Total Otros pasivos financieros 573.651.228 (89.014.867) (28.014.826) 783.122.320 43.452.274 80.211.228 - 12.093.244 (2.942.333) 1.372.558.268
 119

[pág. 121]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 23 Cuentas por pagar comerciales y otras cuentas por pagar
El total de Cuentas por pagar comerciales y otras cuentas por pagar es el siguiente:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Corriente No corriente Corriente No corriente
 M$ M$ M$ M$
 Proveedores 423.583.701 45.275 361.637.804 88.596
 Cuentas por pagar comerciales y otras cuentas por pagar a proveedores 423.583.701 45.275 361.637.804 88.596
 Retenciones por pagar 91.303.484 - 73.336.359 -
 Cuentas por pagar corrientes por retenciones 91.303.484 - 73.336.359 -
 Total 514.887.185 45.275 434.974.163 88.596
Adicionalmente, en Anexo II se presenta Información Adicional Requerida sobre Proveedores con pagos al día y con plazos
vencidos.
Nota 24 Otras provisiones
El total de provisiones registradas son las siguientes:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Corriente No corriente Corriente No corriente
 M$ M$ M$ M$
 Litigios 217.491 2.535.825 256.669 68.662
 Otros 2.244.058 255.255 2.244.058 148.910
 Total 2.461.549 2.791.080 2.500.727 217.572
A continuación se presenta el movimiento de las provisiones:
 Litigios (*) Otros Total
 M$ M$ M$
 Al 1 de enero de 2023 496.302 2.539.796 3.036.098
 Constituidas 272.044 281.812 553.856
 Utilizadas (162.221) - (162.221)
 Liberadas (52.542) (440.137) (492.679)
 Efecto de conversión (228.252) 11.497 (216.755)
 Subtotales (170.971) (146.828) (317.799)
 Al 31 de diciembre de 2023 325.331 2.392.968 2.718.299
 Al 31 de diciembre de 2024
 Adiciones por combinaciones de negocios (1) 1.691.168 - 1.691.168
 Constituidas 1.171.424 8.055 1.179.479
 Utilizadas (359.986) - (359.986)
 Liberadas (70.013) - (70.013)
 Efecto de conversión (4.608) 98.290 93.682
 Subtotales 2.427.985 106.345 2.534.330
 Al 31 de diciembre de 2024 2.753.316 2.499.313 5.252.629
(1) Ver Nota 1 - Información general, letra C), numeral (12).
(*) Ver Nota 35 - Contingencias y compromisos.
 120

[pág. 122]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
El vencimiento de las provisiones al 31 de diciembre de 2024, es el siguiente:
 Litigios Otros Total
 M$ M$ M$
A menos de 1 año 217.491 2.244.058 2.461.549
Entre 1 y 5 años 576.140 255.255 831.395
Más de 5 años 1.959.685 - 1.959.685
Total 2.753.316 2.499.313 5.252.629
El vencimiento de las provisiones al 31 de diciembre de 2023, es el siguiente:
 Litigios Otros Total
 M$ M$ M$
A menos de 1 año 256.669 2.244.058 2.500.727
Entre 1 y 5 años 44.991 148.910 193.901
Más de 5 años 23.671 - 23.671
Total 325.331 2.392.968 2.718.299
Las provisiones por Litigios y Otros (corrientes y no corrientes) corresponden a estimaciones realizadas por la Administración,
destinadas a cubrir eventuales efectos que pudieren derivar de la resolución de juicios/reclamaciones o incertidumbres a que
se encuentra expuesta la Compañía. Dichos juicios/reclamaciones o incertidumbres derivan de transacciones que forman
parte del curso normal de los negocios de CCU y de los países donde opera y cuyos detalles y alcances no son de pleno
conocimiento público, por lo que su exposición detallada podría afectar los intereses de la Compañía y el avance de la
resolución de éstos, según las reservas legales de cada procedimiento administrativo y judicial. Por lo tanto, en base a lo
dispuesto en la NIC 37 “Provisiones, pasivos contingentes y activos contingentes”, párrafo 92, si bien se indican los montos
provisionados en relación a estos juicios/reclamaciones o incertidumbres, no se expone mayor detalle de los mismos al cierre
de estos Estados Financieros.
El detalle de los principales litigios a los cuales se encuentra expuesta la Compañía a nivel consolidado se describen en
Nota 35 - Contingencias y compromisos.
La administración de la Compañía considera que, de acuerdo con el desarrollo de estos litigios a la fecha, las provisiones
constituidas sobre los antecedentes de cada caso, cubren adecuadamente los eventuales efectos adversos que puedan
derivarse de dichos litigios.
Nota 25 Impuestos corrientes, a las ganancias y diferidos
Activos por impuestos corrientes
El detalle de los activos por impuestos corrientes es el siguiente:
 Al 31 de Al 31 de
 diciembre de diciembre de
 2024 2023
 M$ M$
Impuesto por recuperar años anteriores 5.069.480 7.124.688
Pagos provisionales para impuesto de primera categoría 13.614.626 20.322.040
Pago provisional utilidades absorbidas 47.921 764.712
Otros créditos 936.169 574.807
Total 19.668.196 28.786.247
 121

[pág. 123]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Pasivos por impuestos corrientes
El detalle de los pasivos por impuestos corrientes es el siguiente:
 Al 31 de Al 31 de
 diciembre de diciembre de
 2024 2023
 M$ M$
Impuesto de primera categoría 35.372.112 5.968.227
Pago provisional por pagar 3.784.513 3.056.567
Impuesto único artículo N° 21 345.248 214.732
Otros 1.608.298 699.138
Total 41.110.171 9.938.664
Gasto por impuesto
El detalle del gasto por impuesto a la renta e impuestos diferidos es el siguiente:
 Por los ejercicios terminados al 31 de diciembre de
 2024 2023 2022
 M$ M$ M$
(Gasto) ingreso por impuestos diferidos 58.777.006 35.969.675 24.029.239
Ajustes respecto al ejercicio anterior (601.553) 418.002 (1.106.853)
Beneficio por pérdidas tributarias 15.677.770 17.131.132 15.425.726
Total de (pérdida) utilidad por impuesto diferido 73.853.223 53.518.809 38.348.112
Gasto tributario corriente (62.837.194) (37.775.488) (38.717.929)
Ajustes respecto al ejercicio anterior (955) (476.066) 105.874
Total (gastos) ingresos por impuestos corrientes (62.838.149) (38.251.554) (38.612.055)
Total (gastos)/ingresos por impuestos a las ganancias 11.015.074 15.267.255 (263.943)
Los impuestos a la renta e impuestos diferidos relacionados con partidas cargadas o abonadas directamente a la cuenta
Resultados Integrales del Patrimonio son los siguientes:
 Por los ejercicios terminados al 31 de diciembre de
 2024 2023 2022
 M$ M$ M$
Resultado por cobertura de flujos de efectivo (1.281.621) 1.182.375 3.352.151
Resultados actuariales por planes definidos 377.337 (360.233) 1.981.923
Total de impuesto a las ganancias y diferidos relacionado con componentes de resultados
 (904.284) 822.142 5.334.074
integrales
 122

[pág. 124]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Tasa efectiva
El (gasto)/utilidad por los impuestos a las ganancias de la Compañía al 31 de diciembre de 2024, 2023 y 2022 representa
un 5,30%, 14,80% y 0,20%, respectivamente, del resultado antes de impuesto. A continuación se presenta una conciliación
entre dicha tasa efectiva de impuesto y la tasa estatutaria de impuesto vigente en Chile:
 Por los ejercicios terminados al 31 de diciembre de
 2024 2023 2022
 M$ Tasa % M$ Tasa % M$ Tasa %
Utilidad antes de impuesto 165.529.723 103.158.188 135.748.395
Impuesto a la renta a la tasa estatutaria (44.693.025) 27,00 (27.852.711) 27,00 (36.652.067) 27,00
Ajustes para llegar a la tasa efectiva
Efecto impositivo de diferencias permanentes, netos 37.787.116 (21,75) 38.422.245 (37,25) 37.221.335 (27,42)
(Provisión) reverso de provisión por impuestos diferidos 16.375.910 (9,71) 592.008 (0,57) 1.361.100 (1,00)
Efectos de tasas de impuestos extranjeros 2.147.581 (1,20) 4.163.777 (4,04) (1.193.332) 0,88
Déficit (exceso) impuestos ejercicio anterior (602.508) 0,36 (58.064) 0,06 (1.000.979) 0,74
Impuesto a las ganancias 11.015.074 (5,30) 15.267.255 (14,80) (263.943) 0,20
Impuestos diferidos
El impuesto diferido incluido en el Estado Consolidado de Situación Financiera es el siguiente:
 Al 31 de Al 31 de
 diciembre de diciembre de
 2024 2023
 M$ M$
Activos por impuestos diferidos
Provisión por deterioro de cuentas por cobrar 2.244.752 2.062.740
Otros gastos no tributarios 38.242.480 32.959.493
Beneficios al personal 17.657.925 14.917.361
Valorización de inventarios 2.480.489 3.340.389
Intangibles 307.587 248.173
Propiedades, Plantas y Equipos 2.782.089 799.320
Impuestos diferidos relacionados con activos que surgen de una sola transacción 14.804.824 11.603.601
Otros activos 3.642.101 4.638.443
Pérdidas tributarias 54.728.018 31.814.137
Subtotal activos por impuestos diferidos 136.890.265 102.383.657
Compensación por pasivos por impuestos diferidos (95.341.186) (73.931.999)
Total activos por impuestos diferidos 41.549.079 28.451.658
Pasivos por impuestos diferidos
Propiedades, Plantas y Equipos 133.958.756 107.027.820
Gastos de operación agrícola 11.980.659 12.287.741
Activación costos indirectos fabricación 2.191.705 1.167.234
Intangibles 48.661.856 20.166.939
Impuestos diferidos relacionados con pasivos que surgen de una sola transacción 13.879.287 10.290.501
Otros pasivos 12.625.602 9.348.659
Subtotal pasivos por impuestos diferidos 223.297.865 160.288.894
Compensación por activos por impuestos diferidos (95.341.186) (73.931.999)
Total pasivos por impuestos diferidos 127.956.679 86.356.895
Total (86.407.600) (57.905.237)
 123

[pág. 125]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
No se han registrado impuestos diferidos por las diferencias temporarias entre el valor tributario y contable que generan las
inversiones en subsidiarias, por lo tanto, tampoco se reconoce impuesto diferido por los Ajustes de Conversión y Ajustes de
Negocios Conjuntos y Asociadas.
De acuerdo con la normativa tributaria vigente en Chile, las pérdidas tributarias son de aplicación indefinida, no existiendo
un plazo de expiración para las mismas. Respecto de Argentina, Uruguay y Paraguay, las pérdidas tributarias tienen una
duración de 5 años y en Bolivia de 3 años.
A continuación se presenta el análisis del movimiento de impuestos diferidos:
 Análisis del movimiento del impuesto diferido del ejercicio M$
 Al 1 de enero de 2023 (85.502.621)
 Otros incrementos (disminuciones) (1) (48.197.458)
 Impuestos diferidos absorción pérdidas tributarias (559.054)
 Abono a resultados por impuestos diferidos 53.518.809
 Efecto por diferencia de conversión 23.731.521
 Cargo a resultados integrales por impuestos diferidos (360.233)
 Impuesto diferido por combinación de negocios (2) (536.201)
 Subtotales 27.597.384
 Al 31 de diciembre de 2023 (57.905.237)
 Al 1 de enero de 2024
 Abono a resultados por impuestos diferidos 73.853.223
 Efecto por diferencia de conversión (12.341.702)
 Abono a resultados integrales por impuestos diferidos 377.337
 Impuesto diferido por combinación de negocios (3) 320.196
 Otros incrementos (disminuciones) (1) (90.711.417)
 Subtotales (28.502.363)
 Al 31 de diciembre de 2024 (86.407.600)
(1) Corresponde principalmente al efecto financiero de la aplicación de la IAS 29 “Información Financiera en Economías Hiperinflacionarias”.
(2) Ver Nota 1 - Información general, letra C), numeral (5).
(3) Ver Nota 1 - Información general, letra C), numerales (4) y (12).
Reforma Tributaria Internacional – Reglas Modelo Pilar Dos.
La Sociedad ha evaluado la aplicación de NIC 12 “Impuestos a las ganancias” sobre la Reforma Fiscal Internacional (Reglas
del Modelo del Segundo Pilar) mediante la cual se busca que los grupos multinacionales paguen una tasa impositiva efectiva
mínima del 15%. Con base en el análisis realizado, no se han determinado efectos en Compañía Cervecerías Unidas S.A.
ni en los países que participa.
La Sociedad continuará monitoreando el impacto del Pilar II y ajustará sus políticas y estimaciones según sea necesario para
cumplir con las nuevas reglas fiscales.
 124

[pág. 126]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 26 Provisión por beneficios a los empleados
La Compañía otorga beneficios de corto plazo y por terminación de empleo como parte de sus políticas de compensación.
La Compañía mantiene contratos colectivos con sus trabajadores, en los cuales se establecen retribuciones y/o beneficios
de corto y largo plazo a su personal, cuyas principales características se describen a continuación:
 • Los beneficios de corto plazo en general están basados en planes o convenios de modalidad mixta destinados a
 retribuir las prestaciones recibidas, tales como: períodos de vacaciones remunerados, aguinaldos, bonos anuales
 por rendimiento y gratificaciones.
 • Los beneficios de largo plazo son planes o convenios destinados a cubrir principalmente los beneficios de post-
 empleo generado por el término de la relación laboral, sea este por renuncia voluntaria o fallecimiento del personal
 contratado.
El costo de estos beneficios es cargado a resultados en las cuentas relacionadas a Gastos de personal.
El total de beneficios al personal registrados en el Estado Consolidado de Situación Financiera son los siguientes:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Beneficios al personal Corriente No corriente Corriente No corriente
 M$ M$ M$ M$
Beneficios de corto plazo 47.861.302 - 38.317.445 -
Beneficios por terminación de empleos 606.645 48.032.415 395.848 39.586.368
Total 48.467.947 48.032.415 38.713.293 39.586.368
Beneficio de corto plazo
Los beneficios de corto plazo comprenden principalmente remuneraciones, vacaciones y compensaciones a través de bonos.
Estos beneficios son registrados al momento que se devenga la obligación y usualmente son pagados antes de 12 meses,
por lo tanto, no son descontados.
El total de beneficios al personal registrados en el Estado Consolidado de Situación Financiera son los siguientes:
 Al 31 de Al 31 de
 diciembre de diciembre de
 Beneficios al personal corto plazo 2024 2023
 M$ M$
Vacaciones 20.729.130 16.987.082
Bonos y compensaciones 27.132.172 21.330.363
Total 47.861.302 38.317.445
La Compañía registra el costo de las vacaciones del personal sobre base devengada.
Beneficios por terminación de empleo
La Compañía registra un pasivo por el pago a todo evento de indemnizaciones por años de servicio, derivado de los acuerdos
colectivos e individuales suscritos con ciertos grupos de trabajadores. Esta obligación se determina mediante el valor
actuarial del costo devengado del beneficio, método que considera diversos factores en el cálculo, tales como estimaciones
de permanencia futura, tasas de mortalidad, incrementos salariales futuros y tasa de descuento. La Compañía
periódicamente evalúa los factores antes mencionados basados en información histórica y proyecciones futuras, efectuando
los ajustes que correspondan cuando se verifican cambios sostenidos de tendencias. Este valor así determinado se presenta
a valor actual utilizando el método de beneficios devengados por años de servicio. La tasa de descuento se determina por
referencia a curvas de tasas de interés de mercado para bonos empresariales de alta calidad. La tasa de descuento utilizada
en Chile es de un 6,52% y en Argentina de un 35,79% para el ejercicio terminado al 31 de diciembre de 2024 (en Chile
7,35% y en Argentina de un 214,08% 31 de diciembre de 2023).
 125

[pág. 127]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Los beneficios por terminación de empleos registrados son los siguientes:
 Al 31 de Al 31 de
 diciembre de diciembre de
 Indemnización por años de servicio 2024 2023
 M$ M$
Corriente 606.645 395.848
No Corriente 48.032.415 39.586.368
Total 48.639.060 39.982.216
El movimiento de las obligaciones por terminación de empleos, es el siguiente:
 Indemnización por años de servicio M$
Saldo al 1 de enero de 2023 42.772.862
Costo del servicio corriente 4.191.738
Costo por intereses 4.438.416
(Ganancias) pérdidas actuariales (1.454.372)
Beneficios pagados (7.099.274)
Costo servicio pasado 453.213
Efecto de conversión (3.320.367)
Subtotales (2.790.646)
Al 31 de diciembre de 2023 39.982.216
Costo del servicio corriente 4.274.039
Costo por intereses 5.899.859
(Ganancias) pérdidas actuariales 1.581.040
Beneficios pagados (3.835.681)
Costo servicio pasado 640.033
Efecto de conversión (130.122)
Otros 227.676
Subtotales 8.656.844
Al 31 de diciembre de 2024 48.639.060
Los montos registrados en el Estado Consolidado de Resultados por Función, son los siguientes:
 Por los ejercicios terminados al 31 de diciembre de
 Gasto reconocido por beneficios por terminación de empleos
 2024 2023 2022
 M$ M$ M$
Costo del servicio corriente 4.274.039 4.191.738 3.672.626
Costo servicio pasado 640.033 453.213 605.174
Beneficios pagados no provisionados 17.847.114 13.582.343 7.277.848
Otros 580.072 895.162 909.255
Total gasto reconocido Estado Consolidado de Resultados por Función 23.341.258 19.122.456 12.464.903
 126

[pág. 128]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Hipótesis actuariales
Como es mencionado en Nota 2 - Resumen de las principales políticas contables, 2.20, la obligación por indemnización
por años de servicios es registrada a su valor actuarial. Las principales hipótesis actuariales utilizadas para el cálculo de la
obligación por indemnización por años de servicios, son las siguientes:
 Chile Argentina
 Hipótesis Actuariales Al 31 de diciembre Al 31 de diciembre Al 31 de diciembre de Al 31 de diciembre de
 de 2024 de 2023 2024 2023
 Tabla de mortalidad RV-2020 RV-2020 Gam '83 Gam '83
 Tasa de interés anual 6,52% 7,35% 35,79% 214,08%
 Tasa de rotación retiro voluntario 4,3% 4,3% "ESA 77 Ajustada" - 50% "ESA 77 Ajustada" - 50%
 Tasa de rotación necesidades de la empresa 6,1% 6,1% "ESA 77 Ajustada" - 50% "ESA 77 Ajustada" - 50%
 Incremento salarial (*) 3,7% 3,7% 28,10% 196.33%
 Gerente 60 60 60 60
 Edad de Jubilación (*) Hombres 65 65 65 65
 Otros
 Mujeres 60 60 60 60
(*) Promedio ponderado de la Compañía.
Análisis de sensibilidad
A continuación se presenta una sensibilidad basada en aumento y disminución del 1% en la tasa de descuento:
 Al 31 de Al 31 de
 diciembre de diciembre de
 Análisis de sensibilidad 2024 2023
 M$ M$
 Aumento del 1% en la tasa de descuento (ganancia) 2.776.350 2.389.048
 Disminución del 1% en la tasa de descuento (pérdida) (3.175.614) (2.725.833)
Gastos del personal
Los montos registrados en el Estado Consolidado de Resultados por Función, son los siguientes:
 Por los ejercicios terminados al 31 de diciembre de
 Gastos del personal
 2024 2023 2022
 M$ M$ M$
 Sueldos y salarios 284.190.315 242.900.374 243.047.677
 Beneficios a corto plazo a los empleados 48.942.390 36.662.817 39.461.401
 Total gastos por beneficios a los empleados a corto plazo 333.132.705 279.563.191 282.509.078
 Beneficio por terminación de contrato 23.341.258 19.122.456 12.464.903
 Otros gastos de personal 65.620.357 46.858.251 53.747.292
 Total (1) 422.094.320 345.543.898 348.721.273
(1) Ver Nota 30 - Costos y gastos por naturaleza.
 127

[pág. 129]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 27 Otros pasivos no financieros
El total de Otros pasivos no financieros registrados es el siguiente:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Corriente No corriente Corriente No corriente
 M$ M$ M$ M$
 Dividendo de la Matriz provisionado según política 37.055.482 - 20.864.709 -
 Dividendos de la Matriz acordados pendientes de pago (1) 1.256.119 - 1.332.403 -
 Dividendos de las subsidiarias según política 10.606.978 - 8.027.028 -
 Total dividendos por pagar 48.918.579 - 30.224.140 -
 Ingresos percibidos por adelantado 1.215.681 4.355.981 1.438.831 3.987.705
 Otros 874.028 - 258.226 -
 Total 51.008.288 4.355.981 31.921.197 3.987.705
(1) Ver Nota 28 - Patrimonio atribuible a los propietarios de la controladora, Dividendos.
Nota 28 Patrimonio atribuible a los propietarios de la controladora
Capital suscrito y pagado
Al 31 de diciembre de 2024, 2023 y 2022 el capital social de la Compañía presenta un saldo de
M$ 562.693.346 compuesto por un total de 369.502.872 acciones sin valor nominal que se encuentran totalmente suscritas
y pagadas. La Compañía ha emitido solamente una serie única de acciones ordinarias, las cuales gozan de los mismos
derechos de votos sin preferencia alguna. Estas acciones ordinarias se encuentran admitidas para ser transadas en la Bolsa
de Comercio de Santiago de Chile, Bolsa Electrónica de Chile y en la forma de ADS (American Depositary Shares), en la
Bolsa de Comercio de Nueva York (NYSE), con una equivalencia de 2 acciones por cada ADS (Ver Nota 1 - Información
general, letra A)).
La Compañía no ha realizado emisiones de acciones o de instrumentos convertibles durante el período que hagan variar el
número de acciones vigentes al 31 de diciembre de 2024, 2023 y 2022.
Administración del capital
El principal objetivo al momento de administrar el capital de los accionistas es mantener un adecuado perfil de riesgo de
crédito y ratios de capital saludables que permitan a la Compañía el acceso a los mercados de capitales para el desarrollo
de sus objetivos de mediano y largo plazo y, al mismo tiempo, maximizar el retorno de los accionistas.
Utilidad por acción
La utilidad por acción básica se calcula como el cociente entre la utilidad (pérdida) neta del ejercicio atribuible a los
propietarios de la controladora y el número promedio ponderado de acciones vigentes en circulación durante dicho ejercicio.
La utilidad por acción diluida se calcula como el cociente entre la utilidad (pérdida) neta del ejercicio atribuible a los
propietarios de la controladora y el número promedio ponderado de acciones ordinarias adicionales que habrían estado en
circulación si se hubieran convertido todas las acciones ordinarias potenciales con efectos dilusivos.
 128

[pág. 130]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
La información utilizada para el cálculo de la utilidad por acción básica y diluida es la siguiente:
 Por los ejercicios terminados al 31 de diciembre de
 Utilidad por acción
 2024 2023 2022
 Utilidad atribuible a los propietarios de la controladora (M$) 160.944.138 105.652.728 118.168.351
 Número promedio ponderado de acciones 369.502.872 369.502.872 369.502.872
 Utilidad por acción básica (en pesos) 435,57 285,93 319,80
 Utilidad atribuible a los propietarios de la controladora (M$) 160.944.138 105.652.728 118.168.351
 Número promedio ponderado de acciones 369.502.872 369.502.872 369.502.872
 Utilidad por acción diluida (en pesos) 435,57 285,93 319,80
Al 31 de diciembre de 2024, 2023 y 2022, la Compañía no ha emitido instrumentos convertibles o de otra índole que crean
efectos dilutivos.
Utilidad líquida distribuible
En relación a la Circular de la CMF N° 1945, el Directorio de la Compañía acordó con fecha 4 de noviembre de 2009, que la
utilidad líquida distribuible para el ejercicio 2009 y siguientes, será lo que se refleja en los Estados Financieros Consolidados
como Utilidad del ejercicio atribuible a los propietarios de la controladora, sin efectuar ajustes sobre la misma. El acuerdo
mencionado se mantiene vigente para el ejercicio terminado al 31 de diciembre de 2024.
Dividendos
La política de dividendos de la Compañía consiste en distribuir anualmente como dividendo al menos el 50% de las utilidades
líquidas distribuibles del ejercicio.
Durante los períodos terminados al 31 de diciembre de 2024, 2023 y 2022 se han distribuido y/o acordado los siguientes
dividendos:
 N° dividendo Fecha de pago Tipo dividendo Dividendo por acción ($) Relacionado con ejercicio
 264 28-04-2022 Definitivo 200,0000 2021
 265 29-12-2022 Provisorio 135,1000 2022
 266 27-04-2023 Definitivo 24,80181 2022
 267 29-11-2023 Provisorio 86,49907 2023
 268 30-04-2024 Definitivo 85,06042 2023
 269 28-11-2024 Provisorio 117,5000 2024
En Junta Ordinaria de Accionistas de Compañía Cervecerías Unidas S.A., de fecha 13 de abril de 2022 se aprobó, con cargo
a las utilidades del ejercicio 2021, el reparto de un Dividendo Definitivo N° 264 de $ 200 por acción, ascendiendo el monto
total a repartir a M$ 73.900.574. Este dividendo se pagó a contar del día 28 de abril de 2022.
En Sesión Ordinaria de Directorio de Compañía Cervecerías Unidas S.A., de fecha 7 de diciembre de 2022 se aprobó, con
cargo a las utilidades del ejercicio 2022, el reparto de un Dividendo Provisorio N° 265 de $ 135,1 por acción, ascendiendo el
monto total a repartir a M$ 49.919.838. Este dividendo se pagó a contar del día 29 de diciembre de 2022.
En Junta Ordinaria de Accionistas de Compañía Cervecerías Unidas S.A., de fecha 12 de abril de 2023 se aprobó, con cargo
a las utilidades del ejercicio 2022, el reparto de un Dividendo Definitivo N° 266 de $ 24,80181 por acción, ascendiendo el
monto total a repartir a M$ 9.164.340. Este dividendo se pagó a contar del día 27 de abril de 2023.
En Sesión Ordinaria de Directorio de Compañía Cervecerías Unidas S.A., de fecha 8 de noviembre de 2023 se aprobó, con
cargo a las utilidades del ejercicio 2023, el reparto de un Dividendo Provisorio N° 267 de $ 86,49907 por acción, ascendiendo
el monto total a repartir a M$ 31.961.655. Este dividendo se pagó a contar del día 29 de noviembre de 2023.
 129

[pág. 131]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
En Junta Ordinaria de Accionistas de Compañía Cervecerías Unidas S.A., de fecha 17 de abril de 2024 se aprobó, con cargo
a las utilidades del ejercicio 2023, el reparto de un Dividendo Definitivo N° 268 de $ 85,06042 por acción, ascendiendo el
monto total a repartir a M$ 31.430.069. Este dividendo se pagó a contar del día 30 de abril de 2024.
En Sesión Ordinaria de Directorio de Compañía Cervecerías Unidas S.A., de fecha 6 de noviembre de 2024 se aprobó, con
cargo a las utilidades del ejercicio 2024, el reparto de un Dividendo Provisorio N° 269 de $ 117,5 por acción, ascendiendo el
monto total a repartir a M$ 43.416.587. Este dividendo se pagó a contar del día 28 de noviembre de 2024.
Estado de Resultados Integrales
El detalle de ingresos y gastos integrales del ejercicio es el siguiente:
 Saldo bruto Impuesto Saldo neto
 Otros ingresos y gastos con cargo o abono en el patrimonio
 M$ M$ M$
 Ganancias (pérdidas) por coberturas de flujos de efectivo (1) 4.746.744 (1.281.621) 3.465.123
 Ganancias (pérdidas) por diferencias de conversión de subsidiarias en el exterior (1) 214.519.767 - 214.519.767
 Ganancias (pérdidas) actuariales por planes de beneficios definidos (1.581.040) 377.337 (1.203.703)
 Saldo Otros ingresos y gastos integrales al 31 de diciembre de 2024 217.685.471 (904.284) 216.781.187
 Saldo bruto Impuesto Saldo neto
 Otros ingresos y gastos con cargo o abono en el patrimonio
 M$ M$ M$
 Ganancias (pérdidas) por coberturas de flujos de efectivo (1) (4.379.170) 1.182.375 (3.196.795)
 Ganancias (pérdidas) por diferencias de conversión de subsidiarias en el exterior (1) (120.293.386) - (120.293.386)
 Ganancias (pérdidas) actuariales por planes de beneficios definidos 1.454.372 (360.233) 1.094.139
 Saldo Otros ingresos y gastos integrales al 31 de diciembre de 2023 (123.218.184) 822.142 (122.396.042)
 Saldo bruto Impuesto Saldo neto
 Otros ingresos y gastos con cargo o abono en el patrimonio
 M$ M$ M$
 Ganancias (pérdidas) por coberturas de flujos de efectivo (1) (12.415.374) 3.352.151 (9.063.223)
 Ganancias (pérdidas) por diferencias de conversión de subsidiarias en el exterior (1) 9.945.778 - 9.945.778
 Ganancias (pérdidas) actuariales por planes de beneficios definidos (7.103.125) 1.981.923 (5.121.202)
 Saldo Otros ingresos y gastos integrales al 31 de diciembre de 2022 (9.572.721) 5.334.074 (4.238.647)
(1) Estos conceptos se reclasificarán al resultado del ejercicio una vez que se liquiden.
Reservas con efecto en otros resultados integrales (ORI)
El movimiento de las reservas con efecto en otros resultados integrales de cada período es el siguiente:
a) Al 31 de diciembre de 2024:
 Ganancias
 Reservas de (pérdidas)
 Reservas de cobertura de actuariales Otras Total otras
 Movimiento de las Reservas con efecto en otros resultados integrales conversión flujo de por planes de reservas reservas
 efectivo beneficios
 definidos
 M$ M$ M$ M$ M$
 Saldo al 1 de enero de 2024 (158.095.385) (7.331.368) (9.317.562) (1.686.666) (176.430.981)
 Cambios
 Reclasificación de ORI al valor del activo cubierto - 4.657.447 - - 4.657.447
 Ganancias (pérdidas) actuariales por planes de beneficios definidos - - (1.447.717) - (1.447.717)
 Conversión de negocios conjuntos y subsidiarias extranjeras (59.151.707) - - (1.568) (59.153.275)
 Inflación de subsidiarias en Argentina 267.829.919 - - - 267.829.919
 Impuesto a las ganancias - (1.257.511) 335.215 - (922.296)
 Propietarios de la controladora 208.678.212 3.399.936 (1.112.502) (1.568) 210.964.078
 Saldos al 31 de diciembre de 2024 50.582.827 (3.931.432) (10.430.064) (1.688.234) 34.533.097
 Participaciones no controladoras 5.841.556 65.187 (91.201) 1.568 5.817.110
 Subtotales 214.519.767 3.465.123 (1.203.703) - 216.781.188
 130

[pág. 132]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
b) Al 31 de diciembre de 2023:
 Ganancias
 Reservas de (pérdidas)
 Reservas de cobertura de actuariales Otras Total otras
 Movimiento de las Reservas con efecto en otros resultados integrales conversión flujo de por planes de reservas reservas
 efectivo beneficios
 definidos
 M$ M$ M$ M$ M$
Saldo al 1 de enero de 2023 (40.039.090) (4.180.961) (10.351.094) (1.686.855) (56.258.000)
Cambios
Cambio en el valor razonable del instrumento de cobertura reconocido en ORI - (9.189.724) - - (9.189.724)
Reclasificación de ORI al resultado por función - 4.874.098 - - 4.874.098
Ganancias (pérdidas) actuariales por planes de beneficios definidos - - 1.371.350 - 1.371.350
Conversión de negocios conjuntos y subsidiarias extranjeras (484.980.912) - - 189 (484.980.723)
Inflación de subsidiarias en Argentina 366.924.617 - - - 366.924.617
Impuesto a las ganancias - 1.165.219 (337.818) - 827.401
Propietarios de la controladora (118.056.295) (3.150.407) 1.033.532 189 (120.172.981)
Saldos al 31 de diciembre de 2023 (158.095.385) (7.331.368) (9.317.562) (1.686.666) (176.430.981)
Participaciones no controladoras (2.237.091) (46.388) 60.607 (189) (2.223.061)
Subtotales (120.293.386) (3.196.795) 1.094.139 - (122.396.042)
c) Al 31 de diciembre de 2022:
 Ganancias
 Reservas de (pérdidas)
 Reservas de cobertura de actuariales Total otras
 Otras reservas
Movimiento de las Reservas con efecto en otros resultados integrales conversión flujo de por planes de reservas
 efectivo beneficios
 definidos
 M$ M$ M$ M$ M$
Saldo al 1 de enero de 2022 (51.745.399) 5.110.606 (5.446.022) (618.001) (52.698.816)
Cambios
Reclasificación de ORI al valor del activo cubierto - (12.728.174) - - (12.728.174)
Ganancias (pérdidas) actuariales por planes de beneficios definidos - - (6.807.053) - (6.807.053)
Conversión de negocios conjuntos y subsidiarias extranjeras (217.911.312) - - (1.068.854) (218.980.166)
Inflación de subsidiarias en Argentina 229.617.621 - - - 229.617.621
Impuesto a las ganancias - 3.436.607 1.901.981 - 5.338.588
Propietarios de la controladora 11.706.309 (9.291.567) (4.905.072) (1.068.854) (3.559.184)
Saldos al 31 de diciembre de 2022 (40.039.090) (4.180.961) (10.351.094) (1.686.855) (56.258.000)
Participaciones no controladoras (1.760.531) 228.344 (216.130) 1.068.854 (679.463)
Subtotales 9.945.778 (9.063.223) (5.121.202) (4.238.647)
Otras Reservas
Las reservas que forman parte del patrimonio de la Compañía son las siguientes:
Reservas de conversión: Esta reserva nace de la traducción de los Estados Financieros de negocios conjuntos y subsidiarias
cuya moneda funcional es distinta a la moneda de presentación de los Estados Financieros Consolidados y al ajuste por
inflación de las subsidiarias en Argentina. Al 31 de diciembre de 2024, 31 de diciembre de 2023 y 31 de diciembre de 2022
asciende a una reserva positiva de M$ 50.582.827, negativa de M$ 158.095.385 y negativa de M$ 40.039.090,
respectivamente.
Reservas de cobertura: Esta reserva nace de la aplicación de contabilidad de cobertura de los instrumentos financieros
utilizados como tal. Esta reserva se reversa al término de la vigencia de los contratos o bien cuando la operación deje de
calificar como contabilidad de cobertura, lo que ocurra primero. Los efectos de la reserva son traspasados a resultados. El
saldo al 31 de diciembre de 2024, 31 de diciembre de 2023 y 31 de diciembre de 2022 asciende a una reserva negativa de
M$ 3.931.432, M$ 7.331.368 y M$ 4.180.961, neto de sus impuestos a las ganancias.
 131

[pág. 133]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Reservas de ganancias y pérdidas por planes de beneficios definidos: Esta reserva se origina a contar del 1 de enero de
2013, producto de la aplicación de la Enmienda IAS 19 y cuyo efecto al 31 de diciembre de 2024, 31 de diciembre de 2023
y 31 de diciembre de 2022 asciende a una reserva negativa de M$ 10.430.064, M$ 9.317.562 y M$ 10.351.094
respectivamente, neto de sus impuestos diferidos.
Otras reservas varias: Al 31 de diciembre de 2024, 31 de diciembre de 2023 y 31 de diciembre de 2022 el saldo asciende a
una reserva negativa de M$ 39.509.753, M$ 65.455.801 y M$ 36.141.326, respectivamente. Estas reservas corresponden
principalmente a los siguientes conceptos:
− Ajuste por retasación del activo fijo efectuado en el año 1979 (aumento por M$ 4.087.396).
− Corrección monetaria del capital pagado registrado al 31 de diciembre de 2008, según lo señalado en Oficio Circular
 N° 456 de la CMF (disminución por M$ 17.615.333).
− Diferencia en compra de acciones de Viña San Pedro Tarapacá S.A. realizada en los años 2012 y 2013 (aumento por
 M$ 9.779.475).
− Diferencia en compra de acciones de Manantial S.A. realizada el 29 de enero de 2016 (disminución por M$ 7.801.153).
− Diferencia en compra de acciones de Alimentos Nutrabien S.A. realizada por Foods en diciembre de 2016 (disminución
 por M$ 5.426.209). Con fecha 17 de diciembre de 2018, la sociedad coligada Foods y la subsidiaria CCU Inversiones S.A.
 realizan la venta de la propiedad de Alimentos Nutrabien S.A. llevando el efecto anteriormente mencionado a resultado
 del ejercicio.
− Diferencia en compra de acciones de Viña San Pedro Tarapacá S.A. realizada el año 2018 y 2017 (disminución por
 M$ 13.054.114 y M$ 2.075.441 respectivamente).
− Con fecha 30 de agosto de 2019, la sociedad Cervecería Kustmann S.A. adquirío el 5,0001% adicional de Cervecería Szot
 SpA. Como consecuencia de esta combinación de negocios, CK quedó con una participación total de un 50,0004% sobre
 dicha subsidiaria (aumento por M$ 60.887).
− Diferencia en compra de acciones de Sáenz Briones y Cía. S.A.I.C. realizada el 16 de abril, 13 de julio y 9 agosto de 2021
 (disminución por M$ 7.199.525).
− Diferencia en compra de acciones de Viña San Pedro Tarapacá S.A. realizada el 10 de septiembre y 4 de octubre de 2021
 (aumento por M$ 245.244).
− Diferencia en compra de acciones de Viña San Pedro Tarapacá S.A. realizada el 7 de septiembre de 2022 (aumento por
 M$ 102.625) (Ver Nota 1 - Información general, letra C), numeral (13)).
− Diferencia en compra de acciones de Bebidas del Paraguay S.A. y Distribuidora del Paraguay S.A. realizada el 10 de
 marzo de 2023 (disminución por M$ 908.438) (Ver Nota 1 - Información general, letra C), numeral (4)).
− Registro del Acuerdo de Opciones Put para ejercer adquisición de la totalidad de la participación accionaria sobre las
 subsidiarias Bebidas del Paraguay S.A. y Distribuidora del Paraguay S.A. realizada el 16 de marzo de 2023 (disminución
 por M$ 28.554.664 al 31 de diciembre de 2023), la cual fue reversada el 20 de febrero de 2024 contra el pasivo financiero
 registrado (Ver Nota 1 - Información general, letra C), numeral (4)).
− Diferencia por emisión de prima de acciones de Aguas de Origen S.A. realizada el 30 de marzo de 2023 (aumento por
 M$ 148.438) (Ver Nota 16 - Inversiones contabilizadas por el método de la participación, numeral (3))
− Diferencia en compra de acciones de Bebidas del Paraguay S.A. y Distribuidora del Paraguay S.A. realizada el 20 de
 febrero de 2024 (disminución por M$ 10.425.156) (Ver Nota 1 - Información general, letra C), numeral (4)).
− Registro de cambio accionario de la subsidiaria Cervecería Kunstmann S.A., de un 10% sobre Cervecera Guayacán SpA.
 realizado el 26 de abril de 2024 (aumento de M$ 31.300), (Ver Nota 1 - Información general, letra C, numeral (9)).
− Venta de acciones de Cervecería Szot SpA. realizada el 29 de abril de 2024 (disminución de M$ 60.881) (Ver Nota 1 -
 Información general, letra C), numeral (10)).
− Diferencia en compra de acciones de Viña San Pedro Tarapacá S.A. realizada el 21 de noviembre de 2024 (aumento por
 M$ 681.186) (Ver Nota 1 - Información general, letra C), numeral (13)).
− Venta de acciones de Bebidas del Paraguay S.A. de fecha 11 de diciembre de 2024, que generó un efecto patrimonial de
 M$ 7.166.503 (Ver Nota 1 - Información general, letra C), numeral (4)).
 132

[pág. 134]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 29 Participaciones no controladoras
El detalle de las participaciones no controladoras es el siguiente:
a) Patrimonio
 Al 31 de Al 31 de
 diciembre de diciembre de
 Patrimonio 2024 2023
 M$ M$
 Viña San Pedro Tarapacá S.A. 43.663.968 41.631.934
 Bebidas del Paraguay S.A. (1) 17.282.983 17.482.168
 Aguas CCU-Nestlé Chile S.A. 28.814.742 27.624.099
 Cervecería Kunstmann S.A. 11.083.795 10.832.080
 Compañía Pisquera de Chile S.A. 11.887.306 10.055.062
 Distribuidora del Paraguay S.A. (1) 2.950.600 1.954.734
 D&D SpA. (2) 1.424.723 1.415.053
 Aguas de Origen S.A. (3) 12.262.838 -
 AV S.A. (1) 9.274.217 -
 Bebidas Bolivianas BBO S.A. 7.054.461 6.211.874
 Otros 1.632.492 1.810.795
 Total 147.332.125 119.017.799
(1) Ver Nota 1 - Información general, letra C), numeral (4).
(2) Ver Nota 1 - Información general, letra C), numeral (5).
(3) Ver Nota 1 - Información general, letra C), numeral (12).
b) Resultado
 Por los ejercicios terminados al 31 de diciembre de
 Resultado
 2024 2023 2022
 M$ M$ M$
 Aguas CCU-Nestlé Chile S.A. 11.939.712 9.428.103 6.876.759
 Viña San Pedro Tarapacá S.A. 2.914.056 2.181.421 4.620.251
 Cervecería Kunstmann S.A. 1.158.956 1.190.978 4.047.024
 Compañía Pisquera de Chile S.A. 3.338.739 3.256.403 3.594.166
 Sáenz Briones & Cía. S.A.I.C. - - 877
 Distribuidora del Paraguay S.A. 1.101.369 (674.671) (116.677)
 Bebidas del Paraguay S.A. (604.980) 547.873 682.236
 D&D SpA. 90.647 324.466 -
 Aguas de Origen S.A. (1.444.250) - -
 AV S.A. 53.082 - -
 Bebidas Bolivianas BBO S.A. (2.956.395) (3.462.444) (2.342.555)
 Otros 9.723 (19.414) (45.980)
 Total 15.600.659 12.772.715 17.316.101
 133

[pág. 135]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
c) A continuación se presentan en forma resumida, las partidas significativas de los Estados Financieros Consolidados
 correspondiente a las participaciones no controladoras:
 Al 31 de Al 31 de
 diciembre de diciembre de
 Activos y Pasivos 2024 2023
 M$ M$
Activos y Pasivos
Activos corrientes 813.042.655 725.627.672
Activos no corrientes 892.225.098 733.472.890
Pasivos corrientes 549.971.229 409.331.274
Pasivos no corrientes 145.249.838 187.674.051
Dividendos pagados a participaciones no controladoras 12.792.104 15.288.255
La Participación no controladora más significativa se encuentra representada por Viña San Pedro Tarapacá S.A. con las
siguientes cifras:
 Al 31 de Al 31 de
 diciembre de diciembre de
 Activos y Pasivos 2024 2023
 M$ M$
Activos y Pasivos
Activos corrientes 216.421.999 207.102.975
Activos no corrientes 243.013.446 226.340.932
Pasivos corrientes 132.903.418 83.692.552
Pasivos no corrientes 32.108.567 77.620.530
 Por los ejercicios terminados al 31 de diciembre de
 Resultado 2024 2023 2022
 M$ M$ M$
Ingresos por ventas 282.637.923 252.825.495 296.349.893
Utilidad (pérdida) del período 19.201.312 14.259.053 29.949.719
Los dividendos pagados por Viña San Pedro Tarapacá S.A. fueron por M$ 7.137.366, M$ 14.948.153 y M$ 17.906.526, al
31 de diciembre de 2024, 2023 y 2022, respectivamente.
 134

[pág. 136]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 30 Costos y gastos por naturaleza
Los costos y gastos operacionales agrupados de acuerdo a su naturaleza son los siguientes:
 Por los ejercicios terminados al 31 de diciembre de
 Costos y gastos por naturaleza
 2024 2023 2022
 M$ M$ M$
 Costos directos 1.232.870.856 1.090.286.882 1.188.930.623
 Remuneraciones (1) 422.094.320 345.543.898 348.721.273
 Transporte y distribución 377.004.558 332.820.614 379.499.418
 Publicidad y promociones 152.571.607 139.205.727 141.408.476
 Depreciaciones y amortizaciones 153.234.224 126.119.198 126.497.493
 Materiales y mantenciones 95.149.680 75.253.468 75.247.644
 Energía 43.893.542 36.071.907 56.131.568
 Arriendos (2) 26.686.406 23.725.453 23.280.218
 Otros gastos (3) 178.570.881 147.665.534 145.571.745
 Total 2.682.076.074 2.316.692.681 2.485.288.458
(1) Ver Nota 26 - Provisión por beneficios a los empleados.
(2) Se compone principalmente de arriendos de bienes raíces, maquinarias y equipos, que no cumplen con lo indicado en Nota 2 - Resumen de las
 principales políticas contables, (2.13).
(3) En este concepto se incluyen principalmente, asesorías técnicas, servicios de auditoría, gastos jurídicos y de representación, entre otros.
Nota 31 Otros ingresos, por función
El detalle de los Otros ingresos por función es el siguiente:
 Por los ejercicios terminados al 31 de diciembre de
 Otros ingresos por función
 2024 2023 2022
 M$ M$ M$
 Venta de activo fijo (1) 29.796.171 853.594 923.035
 Arriendos 397.922 357.838 693.976
 Venta de vidrio y desechos 1.542.280 1.126.636 1.400.115
 Recuperación de siniestros e indemnizaciones 1.241.536 165.979 183.505
 Otros (2) 7.233.601 1.915.742 2.084.035
 Total 40.211.510 4.419.789 5.284.666
(1) Dentro de las Ventas de activo fijo se incluye entre otros, el efecto de venta de porción de Terreno Quilicura, ver Nota 14 - Activos no corrientes
 mantenidos para la venta, letra a).
(2) Dentro de este concepto se incluye principalmente descuento por pronto pago de proveedores, servicios de tours y eventos.
 135

[pág. 137]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 32 Otras ganancias (pérdidas)
El detalle de la cuenta Otras ganancias (pérdidas) es el siguiente:
 Por los ejercicios terminados al 31 de diciembre de
 Otras ganancias (pérdidas)
 2024 2023 2022
 M$ M$ M$
 Resultados contratos derivados (1) 6.437.666 (9.064.032) (10.059.147)
 Valor bursátil valores negociables 164.604 96.444 (111.708)
 Pérdidas por deterioro de valor (2) - - (2.190.491)
 Pérdida por liquidación de bonos del gobierno argentino (3) (6.316.771) - -
 Otros (380.436) (4.348.620) (308.194)
 Total (94.937) (13.316.208) (12.669.540)
(1) Dentro de este concepto se encuentran M$ 7.607.440 percibidos (netos), M$ 7.335.638 pagados (netos) y M$ 2.577.652 percibidos (netos) al
 31 de diciembre de 2024, 2023 y 2022, respectivamente y que se presentan en el Estado Consolidado de Flujos de Efectivo, en Actividades de
 operación, bajo el rubro “Otras entradas (salidas) efectivo”.
(2) Corresponde principalmente al deterioro del valor de los activos reclasificados a Activos no corrientes mantenidos para la venta, de la Subsidiaria
 Finca La Celia S.A., por un valor de M$ 641.682, más los gastos incurridos para llevar a cabo esta operación por M$ 581.711. Ver Nota 14 –
 Activos no corrientes mantenidos para la venta, letra C).
(3) Corresponde a la liquidación de instrumento financiero (Bono BOPREAL), para ser utilizado en la cancelación de deudas impositivas e
 importaciones de bienes y servicios, según lo establecido en la Com. A 7925 y del Decreto N°72, de la República de Argentina.
Nota 33 Resultados financieros
El detalle de los resultados financieros es el siguiente:
 Por los ejercicios terminados al 31 de diciembre de
 Resultados financieros
 2024 2023 2022
 M$ M$ M$
 Ingresos financieros 38.102.053 39.402.492 22.870.538
 Costos financieros (97.165.278) (77.023.048) (75.930.875)
 Ganancias (pérdidas) de cambio en moneda extranjera (17.797.269) (65.944.570) (20.173.381)
 Resultados por unidades de reajuste (10.722.033) (14.025.895) 1.198.565
 136

[pág. 138]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 34 Efectos de las variaciones en las tasas de cambio de la moneda
Los Activos corrientes se componen en las siguientes monedas y unidades de reajuste:
 Al 31 de diciembre de Al 31 de diciembre de
 ACTIVOS CORRIENTES 2024 2023
 M$ M$
Activos corrientes
Efectivo y equivalente al efectivo 707.122.815 618.154.016
CLP 131.104.956 90.360.822
USD 532.776.367 499.873.696
Euros 2.520.585 1.516.762
ARS 30.548.903 19.758.284
UYU 2.136.790 2.635.618
PYG 5.241.028 2.147.017
BOB 1.206.368 1.069.435
Otras monedas 1.587.818 792.382
Otros activos financieros 11.899.281 7.440.650
CLP 822.288 467.851
UF 7.232.587 3.844.154
USD 3.783.635 442.366
Euros 26.092 3.553
PYG - 2.656.724
Otras monedas 34.679 26.002
Otros activos no financieros 31.143.442 29.674.705
CLP 4.844.074 13.939.522
UF - 1.362.467
USD 2.850.593 2.041.504
Euros 9.513.589 3.206.787
ARS 11.896.592 8.344.924
UYU 383.305 144.716
PYG 803.828 445.094
BOB 773.051 164.498
Otras monedas 78.410 25.193
Deudores comerciales y otras cuentas por cobrar 506.711.173 446.486.753
CLP 299.181.390 291.883.346
UF 360.586 54.212
USD 52.213.269 43.734.334
Euros 7.817.297 8.114.465
ARS 117.920.573 77.006.575
UYU 8.684.460 6.514.410
PYG 15.086.724 13.996.752
BOB 3.385.594 2.856.786
Otras monedas 2.061.280 2.325.873
Cuentas por cobrar entidades relacionadas 15.501.990 9.040.528
CLP 8.362.100 7.827.338
USD 2.207.523 13.136
Euros 29.204 115.166
ARS 11.689 1.084.888
PYG 4.790.036 -
Otras monedas 101.438 -
Inventarios 459.384.555 425.728.432
CLP 356.354.005 376.468.075
ARS 81.521.039 30.448.514
UYU 3.990.906 3.734.911
PYG 12.644.453 11.498.310
BOB 3.790.095 3.156.669
Otras monedas 1.084.057 421.953
Activos biológicos corrientes 16.883.106 14.764.284
CLP 13.579.901 13.191.601
ARS 3.303.205 1.572.683
Activos por impuestos corrientes 19.668.196 28.786.247
CLP 6.792.673 22.123.418
USD 2.199 23.022
ARS 12.450.511 6.151.570
UYU 422.813 383.149
PYG - 105.088
Activos mantenidos para la venta 2.952.282 21.607.472
CLP 506.853 20.207.776
ARS 2.445.429 1.399.696
Total activos corrientes 1.771.266.840 1.601.683.087
CLP 821.548.240 836.469.749
UF 7.593.173 5.260.833
USD 593.833.586 546.128.058
Euros 19.906.767 12.956.733
ARS 260.097.941 145.767.134
UYU 15.618.274 13.412.804
PYG 38.566.069 30.848.985
BOB 9.155.108 7.247.388
Otras monedas 4.947.682 3.591.403
Total activos corrientes por tipo de moneda 1.771.266.840 1.601.683.087
 137

[pág. 139]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Los Activos no corrientes se componen en las siguientes monedas y unidades de reajuste:
 Al 31 de diciembre de Al 31 de diciembre de
 ACTIVOS NO CORRIENTES 2024 2023
 M$ M$
Activos no corrientes
Otros activos financieros 30.060.601 29.981.745
UF 30.060.601 29.981.745
Cuentas por cobrar no corrientes 5.966.414 3.313.742
CLP 59.475 93.543
UF 2.245.560 2.207.319
ARS 3.661.379 1.012.880
Otros activos no financieros 13.674.236 12.311.027
CLP 5.931.535 7.502.550
ARS 7.682.140 4.773.697
UYU 11.248 16.087
PYG 49.313 18.693
Cuentas por cobrar a entidades relacionadas 844.344 42.506
CLP 844.344 42.506
Inversiones contabilizadas por método de la participación 139.746.921 149.593.180
CLP 14.446.708 12.473.973
USD 896.458 863.171
ARS 1.380.017 9.694.302
Otras monedas 123.023.738 126.561.734
Activos intangibles distintos de plusvalía 244.632.721 153.123.207
CLP 102.103.411 93.780.810
ARS 111.983.717 43.067.681
UYU 4.941.055 4.959.318
PYG 17.791.810 4.423.253
BOB 7.812.728 6.892.145
Plusvalía 161.583.233 127.592.056
CLP 78.918.309 79.120.778
ARS 60.204.613 27.728.301
UYU 5.186.877 5.155.840
PYG 5.702.154 5.401.679
BOB 11.571.280 10.185.458
Propiedades, plantas y equipos (neto) 1.522.708.449 1.273.987.695
CLP 1.014.562.371 990.106.233
ARS 430.015.212 219.700.188
UYU 15.961.195 14.989.123
PYG 31.224.130 22.799.672
BOB 30.933.801 26.379.198
Otras monedas 11.740 13.281
Propiedades de inversión 12.666.980 8.121.156
CLP 3.272.632 3.300.887
ARS 9.394.348 4.820.269
Activos por derecho de uso 45.017.172 35.745.221
CLP 2.288.216 2.365.647
UF 41.832.914 30.661.437
ARS 9.305 2.543.786
UYU 461.687 174.351
PYG 425.050 -
Activos por impuestos diferidos 41.549.079 28.451.658
CLP 32.066.798 24.961.135
USD 1.913.015 1.349.518
ARS 6.375.839 1.474.155
UYU 652.186 571.790
PYG 541.241 68.224
Otras monedas - 26.836
Total activos no corrientes 2.218.450.150 1.822.263.193
CLP 1.254.493.799 1.213.748.062
UF 74.139.075 62.850.501
USD 2.809.473 2.212.689
ARS 630.706.570 314.815.259
UYU 27.214.248 25.866.509
PYG 55.733.698 32.711.521
BOB 50.317.809 43.456.801
Otras monedas 123.035.478 126.601.851
Total activos no corrientes por tipo de moneda 2.218.450.150 1.822.263.193
 138

[pág. 140]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Los Pasivos corrientes se componen en las siguientes monedas y unidades de reajuste:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Más de 91 días hasta 1 Más de 91 días hasta 1
 PASIVOS CORRIENTES Hasta 90 días Hasta 90 días
 año año
 M$ M$ M$ M$
Pasivos corrientes
Otros pasivos financieros 35.475.633 120.726.369 58.731.009 48.420.591
CLP 21.109.878 18.046.884 2.367.748 17.037.708
UF 3.428.771 87.012.122 3.242.883 28.374.241
USD 531.474 9.442.661 52.714.405 362.118
Euros 103.888 - 212.407 49.840
ARS 10.059.999 - 54.804 -
PYG 36.457 - - -
BOB 188.449 6.224.702 113.368 2.596.684
Otras monedas 16.717 - 25.394 -
Pasivos por arrendamientos corrientes 2.681.843 6.769.708 2.084.679 5.057.681
CLP 283.348 177.500 81.801 96.742
UF 1.838.123 5.070.421 1.693.771 4.228.695
USD 362.393 971.307 159.760 445.300
Euros - - 10.764 32.291
ARS 111.701 290.702 103.598 181.762
UYU 45.183 135.550 34.985 72.891
PYG 41.095 124.228 - -
Cuentas por pagar comerciales y otras cuentas por pagar 510.626.190 4.260.995 432.447.718 2.526.445
CLP 254.769.653 3.901.022 272.728.937 1.700.735
USD 80.195.669 180.830 48.552.262 307.940
Euros 9.814.496 584 10.018.064 88.592
ARS 144.463.472 - 84.199.465 -
UYU 3.778.079 - 3.941.952 -
PYG 10.349.752 21.289 8.050.252 21.859
BOB 5.882.964 157.270 4.833.519 407.319
Otras monedas 1.372.105 - 123.267 -
Cuentas por pagar a entidades relacionadas 36.417.518 - 55.140.630 -
CLP 10.046.312 - 7.638.951 -
USD 2.794.220 - 4.045.747 -
Euros 21.010.350 - 34.075.498 -
ARS 242.682 - 9.229.527 -
PYG 2.310.004 - 1.131 -
BOB 13.950 - 91.998 -
Otras monedas - - 57.778 -
Otras provisiones a corto plazo 217.491 2.244.058 256.669 2.244.058
CLP 164.622 2.244.058 233.330 2.244.058
ARS 22.110 - 17.059 -
PYG 30.759 - 6.280 -
Pasivos por impuestos corrientes 8.407.598 32.702.573 4.486.182 5.452.482
CLP 4.113.177 32.676.212 4.114.496 2.819.345
USD 604.091 - - -
ARS 3.007.964 3.834 - 2.618.385
UYU 469.118 - 371.686 -
PYG 213.248 - - -
Otras monedas - 22.527 - 14.752
Provisiones corrientes por beneficios a los empleados 31.203.297 17.264.650 22.293.579 16.419.714
CLP 14.428.956 17.252.755 14.279.763 16.419.714
ARS 14.615.567 - 6.569.427 -
UYU 695.096 - 649.101 -
PYG 970.939 - 560.016 -
BOB 205.328 - 235.272 -
Otras monedas 287.411 11.895 - -
Otros pasivos no financieros 3.594.656 47.413.632 906 31.920.291
CLP 1.385.360 47.413.632 - 30.980.829
USD 1.215.681 - - -
ARS - - 906 939.462
PYG 993.615 - - -
Total pasivos corrientes 628.624.226 231.381.985 575.441.372 112.041.262
CLP 306.301.306 121.712.063 301.445.026 71.299.131
UF 5.266.894 92.082.543 4.936.654 32.602.936
USD 85.703.528 10.594.798 105.472.174 1.115.358
Euros 30.928.734 584 44.316.733 170.723
ARS 172.523.495 294.536 100.174.786 3.739.609
UYU 4.987.476 135.550 4.997.724 72.891
PYG 14.945.869 145.517 8.617.679 21.859
BOB 6.290.691 6.381.972 5.274.157 3.004.003
Otras monedas 1.676.233 34.422 206.439 14.752
Total Pasivos corrientes por tipo de moneda 628.624.226 231.381.985 575.441.372 112.041.262
 139

[pág. 141]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Los Pasivos no corrientes se componen en las siguientes monedas y unidades de reajuste:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Más de 1 año hasta 3 Más de 3 años a 5 Más de 1 año hasta 3 Más de 3 años a 5
 PASIVOS NO CORRIENTES Más de 5 años Más de 5 años
 años años años años
 M$ M$ M$ M$ M$ M$
Pasivos no corrientes
Otros pasivos financieros 109.566.601 105.420.081 1.019.245.040 130.645.698 172.465.574 931.134.835
CLP 60.404.790 99.885.625 - 14.665.317 153.022.502 -
UF 44.107.075 663.871 422.216.054 111.452.973 14.513.423 404.617.370
USD - - 592.159.908 - - 520.409.088
BOB 5.054.736 4.870.585 4.869.078 4.527.408 4.929.649 6.108.377
Pasivos por arrendamientos no corrientes 11.659.338 7.254.177 20.868.802 9.302.901 4.340.104 20.418.734
CLP 71.957 - - - - -
UF 8.908.395 5.621.258 19.851.041 8.168.512 3.925.739 19.363.752
USD 1.911.678 1.432.060 1.017.761 797.652 325.315 1.011.076
ARS 326.100 107.311 - 260.266 89.050 43.906
UYU 284.040 - - 76.471 - -
PYG 157.168 93.548 - - - -
Otras cuentas por pagar 45.275 - - 88.596 - -
CLP 41.041 - - 79.135 - -
UF 4.234 - - 9.461 - -
Cuentas por pagar a entidades relacionadas - - - 536.083 - -
CLP - - - 536.083 - -
Otras provisiones a largo plazo 117.839 713.556 1.959.685 - 193.900 23.672
CLP 100.942 - - - - -
ARS 16.897 540.337 1.959.685 - 26.226 23.672
UYU - 173.219 - - 167.674 -
Pasivos por impuestos diferidos 40.864.865 17.064.504 70.027.310 31.622.865 10.650.020 44.084.010
CLP 26.302.201 9.240.534 28.787.902 28.922.360 8.077.467 28.562.262
ARS 14.520.341 7.800.990 36.584.730 2.692.555 2.567.253 12.338.003
UYU - - 875.489 - - 946.054
PYG 42.323 22.980 1.768.718 7.950 5.300 478.042
BOB - - 2.010.471 - - 1.759.649
Provisiones no corrientes por beneficios a los
 633.408 - 47.399.007 738.964 - 38.847.404
empleados
CLP - - 42.647.137 - - 36.897.268
ARS - - 4.751.870 - - 1.950.136
BOB 633.408 - - 738.964 - -
Otros pasivos no financieros 1.863.665 996.926 1.495.390 996.926 996.926 1.993.853
CLP 996.926 996.926 1.495.390 996.926 996.926 1.993.853
PYG 866.739 - - - - -
Total pasivos no corrientes 164.750.991 131.449.244 1.160.995.234 173.932.033 188.646.524 1.036.502.508
CLP 87.917.857 110.123.085 72.930.429 45.199.821 162.096.895 67.453.383
UF 53.019.704 6.285.129 442.067.095 119.630.946 18.439.162 423.981.122
USD 1.911.678 1.432.060 593.177.669 797.652 325.315 521.420.164
ARS 14.863.338 8.448.638 43.296.285 2.952.821 2.682.529 14.355.717
UYU 284.040 173.219 875.489 76.471 167.674 946.054
PYG 1.066.230 116.528 1.768.718 7.950 5.300 478.042
BOB 5.688.144 4.870.585 6.879.549 5.266.372 4.929.649 7.868.026
Total Pasivos no corrientes por tipo de moneda 164.750.991 131.449.244 1.160.995.234 173.932.033 188.646.524 1.036.502.508
 140

[pág. 142]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 35 Contingencias y compromisos
Contratos de servicios
El monto total contratado por la Compañía por concepto de servicios es el siguiente:
 Al 31 de Al 31 de
 diciembre de diciembre de
 Contratos de servicios no cancelables 2024 2023
 M$ M$
Dentro de un año 50.820.240 79.375.436
Entre 1 y 5 años 60.096.921 97.947.446
Más de 5 años 33.177.327 -
Total 144.094.488 177.322.882
Contratos de compra y convenios de suministros
El monto total contratado por la Compañía por concepto de compra y convenios de suministros al 31 de diciembre de 2024
es el siguiente:
 Acuerdo de compra y Contratos de compra de
 Contratos de compra y convenios de suministros convenios de suministros uva y vino
 M$ M$
Dentro de un año 429.613.645 11.241.775
Entre 1 y 5 años 1.786.939.620 2.083.941
Más de 5 años 1.204.234.923 -
Total 3.420.788.188 13.325.716
Compromisos de inversiones de capital
Al 31 de diciembre de 2024, la Compañía y sus subsidiarias mantienen compromisos de inversión de capital relacionados
con Propiedades, planta y equipo e Intangibles (software) por un monto de M$ 23.587.044.
Litigios
A continuación se detallan los juicios más significativos que enfrenta la Compañía y sus subsidiarias en Chile y negocio
conjunto en el extranjero, y que presentan un riesgo posible de ocurrencia desfavorable y cuyos montos comprometidos, de
manera individual, son superiores a M$ 25.000 para casos de las sociedades chilenas y USD 15.000 para casos de las
sociedades extranjeras.
 141

[pág. 143]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
 Monto
 Sociedad Tribunal Materia Etapa procesal
 comprometido
 Transportes CCU Ltda. Corte Suprema. Indemnización de perjuicios. Recurso de unificación de jurisprudencia. M$ 72.000
 Cobro de prestaciones
 Comercial CCU S.A. Corte de Apelaciones. Apelación de sentencia. M$ 46.338
 laborales.
 Cobro de prestaciones
 Comercial CCU S.A. Corte de Apelaciones. Apelación de sentencia. M$ 30.779
 laborales.
 Aguas de Origen S.A. Tribunal Laboral. Juicios laborales por despido. Demanda contestada. USD 19.380
 Aguas de Origen S.A. (1) Tribunal Laboral. Juicios laborales por despido. Sentencia. USD 608.876
 Aguas de Origen S.A. (2) Tribunal Laboral. Juicios laborales por despido. Etapa de prueba. USD 570.846
 Compañía Industrial Cervecera
 Tribunal Laboral. Juicios laborales por despido. Etapa de prueba. USD 48.925
 S.A. (3)
 Reclamos administrativos de
 Compañía Industrial Cervecera Procesos en etapa administrativa o
 Tribunales Administrativos. diversos municipios por tasas USD 22.000
 S.A. judicial.
 de publicidad y propaganda.
 Demanda por beneficios
 Bebidas Bolivianas S.A. Tribunal Laboral. Sentencia. USD 28.160
 sociales.
 Requerimiento Departamento
 de Cundinamarca, relativo a
 determinación de la base para
 Zona Franca Central A la espera de sentencia de segunda
 Consejo de Estado. cálculo del Impuesto al USD 852.041
 Cervecera S.A.S. instancia.
 Consumo (ICO), período
 noviembre y diciembre de
 2019.
 Requerimiento Departamento
 de Cundinamarca, relativo a
 determinación de la base para
 Zona Franca Central Solicitud de Adición y Aclaración de la
 Consejo de Estado. cálculo del Impuesto al USD 6.045.000
 Cervecera S.A.S. sentencia.
 Consumo (ICO), período
 enero a octubre (sin agosto)
 de 2020.
(1) Incluye la cantidad de 9 juicios.
(2) Incluye la cantidad de 20 juicios.
(3) Incluye la cantidad de 3 juicios.
La Compañía y sus subsidiarias mantienen provisiones para cubrir los eventuales efectos adversos provenientes de estas
contingencias y otras menores por un total de M$ 2.753.316 al 31 de diciembre de 2024 (M$ 325.331 al 31 de diciembre de
2023) (Ver Nota 24 - Otras provisiones).
Procesos tributarios
A la fecha de emisión de estos Estados Financieros Consolidados no existen procesos tributarios que impliquen pasivos o
impuestos en reclamo significativos para la Sociedad.
Garantías
Al 31 de diciembre de 2024, CCU y sus subsidiarias no han otorgado garantías directas como parte de sus operaciones
habituales de financiamiento. Sin embargo, han constituido garantías indirectas en forma de stand by, comfort letters y
fianzas generales producto de operaciones de financiamiento. Los principales términos de las garantías indirectas
constituidas se detallan a continuación:
- La asociada indirecta Bodega San Isidro S.R.L. mantiene deuda financiera con banco local en Perú, la cual es avalada
 por la subsidiaria Compañía Pisquera de Chile S.A. a través de carta stand by emitida por el Banco del Estado de Chile,
 esta se encuentra dentro de la política de financiación aprobada por el Directorio de la Sociedad, y que se detalla a
 continuación:
 Institución Monto Fecha de vencimiento
 Banco Crédito de Perú USD 2.600.000 22 de diciembre de 2025
 142

[pág. 144]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
- Adicionalmente la Compañía presenta las siguientes garantías:
 a) La Compañía, mediante instrumento privado de fecha 27 de julio de 2022 se obliga a mantener una participación
 accionaria directa o indirecta de al menos el 50,1%, que le permita el control de su subsidiaria Compañía Pisquera
 de Chile S.A. durante el periodo de vigencia del préstamo bancario con el Banco del Estado de Chile por un total
 de M$ 16.000.000, con vencimiento al 27 de julio de 2027.
 b) La Compañía, mediante instrumento privado de fecha 24 de mayo de 2024, se obliga a mantener una participación
 accionaria directa o indirecta igual o superior al 99,9% en CCU Inversiones II SpA. durante el periodo de vigencia
 del préstamo bancario entre Central Cervecera de Colombia S.A.S. e Itaú Colombia S.A. por un total de MCOP
 178.000.000 con vencimiento al 30 de mayo de 2025, o bien hasta la fecha en que se efectúe el pago íntegro de
 dicho préstamo.
 c) CCU Inversiones II SpA., mediante instrumento privado de fecha 24 de mayo de 2024, se obliga a mantener una
 participación accionaria directa o indirecta de al menos el 50% del capital con derecho a voto del negocio conjunto
 Central Cervecera de Colombia S.A.S. durante el periodo de vigencia del préstamo bancario otorgado por Itaú
 Colombia S.A., por un total de MCOP 178.000.000, con vencimiento al 30 de mayo de 2025, o mientras exista algún
 monto adeudado del préstamo. Adicionalmente, en caso que el deudor experimente dificultades para cumplir en
 tiempo y forma con cualquier compromiso financiero derivado del crédito (capital, intereses, comisiones, impuestos
 o gastos de cualquier tipo), CCU Inversiones II SpA. pagará directamente al banco y/o se le proporcionará al deudor
 los recursos suficientes para proceder al pago.
 d) La Compañía, mediante instrumento privado de fecha 28 de junio de 2024, se obliga a mantener una participación
 accionaria directa o indirecta de al menos el 51% del capital social autorizado de la subsidiaria Bebidas Bolivianas
 S.A., además de mantener directa y/o indirectamente el control efectivo sobre los órganos de la administración y
 dar asistencia técnica necesaria, durante el periodo de vigencia de las obligaciones financieras que mantenga
 Bebidas Bolivianas S.A. con el Banco Mercantil Santa Cruz S.A.
Nota 36 Medio ambiente
Los principales gastos medioambientales acumulados al 31 de diciembre de 2024, en las Unidades Industriales de la
Compañía, se distribuyen de la siguiente forma:
 - Gastos RILES 37,5%
 Principalmente debido al mantenimiento y control de las plantas de tratamiento de Residuos Industriales Líquidos
 (RILES).
 - Gastos RISES 40,5%
 Relacionados con el manejo y disposición de residuos sólidos (RISES), incluyendo los residuos peligrosos (ResPel)
 y residuos industriales reciclables cuya disposición final no corresponde a un relleno sanitario.
 - Gastos Emisiones Gaseosas 0,8%
 Calibraciones y verificaciones de los instrumentos de control y operación de fuentes fijas de emisiones gaseosas
 industriales (principalmente calderas industriales y generadores de energía eléctrica), para dar cumplimento a
 normativas y reglamentos en la materia.
 - Otros Gastos Ambientales 21,2%
 Gastos asociados al Sistema Integral de Gestión de residuos asociados a envases y embalajes, ReSimple, a la
 verificación y cumplimiento de los sistemas de gestión ISO 22000 Inocuidad de Alimentos, ISO 14000 Gestión
 Ambiental y OHSAS 18001 Salud y Seguridad Laboral, que se encuentran en diferentes estados de implementación
 y/o de renovación de la certificación, en las diferentes plantas industriales y/o centros de distribución. La
 implementación y certificación de estas tres normas constituye un objetivo Corporativo de CCU.
 143

[pág. 145]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Al 31 de diciembre de 2024 y 2023, los gastos relacionados con el medio ambiente son los siguientes:
 Por los ejercicios terminados al 31 de
 diciembre de
 Cía. que efectúa el desembolso Proyecto Gastos 2024 2023
 M$ M$
Cervecera CCU Chile Ltda. RILES Mantenimiento y control de plantas de tratamientos de residuos industriales líquidos
 2.103.100 1.986.832
 (RILES).
 RISES Gestión de residuos sólidos (RISES) y residuos peligrosos (ResPel). 1.855.229 1.375.069
 Gases Gestión emisiones atmosféricas. 58.348 52.510
 Otros Gestión de cumplimientos normativos internos y externos. 1.332.986 1.129.161
Compañía Industrial Cervecera S.A. RILES Mantenimiento y control de plantas de tratamientos de residuos industriales líquidos
 2.115.123 1.967.023
 (RILES).
 RISES Gestión de residuos sólidos (RISES) y residuos peligrosos (ResPel). 1.067.081 742.820
 Gases Gestión emisiones atmosféricas. 19.357 22.512
 Otros Gestión de cumplimientos normativos internos y externos. 248.831 128.068
Cervecería Kunstmann S.A. RILES Mantenimiento y control de plantas de tratamientos de residuos industriales líquidos
 730.789 230.247
 (RILES).
 RISES Gestión de residuos sólidos (RISES) y residuos peligrosos (ResPel). 482.191 394.128
 Otros Gestión de cumplimientos normativos internos y externos. 129.572 106.071
Compañía Pisquera de Chile S.A. RILES Mantenimiento y control de plantas de tratamientos de residuos industriales líquidos
 412.839 385.042
 (RILES).
 RISES Gestión de residuos sólidos (RISES) y residuos peligrosos (ResPel). 78.724 97.057
 Gases Gestión emisiones atmosféricas 450 -
 Otros Gestión de cumplimientos normativos internos y externos. 231.400 179.553
Transportes CCU Ltda. RILES Mantenimiento y control de plantas de tratamientos de residuos industriales líquidos
 5.737 10.055
 (RILES).
 RISES Gestión de residuos sólidos (RISES) y residuos peligrosos (ResPel). 1.885.058 2.105.543
 Gases Gestión emisiones atmosféricas. 312 547
 Otros Gestión de cumplimientos normativos internos y externos. 37.161 65.131
Viña San Pedro Tarapacá S.A. RILES Mantenimiento y control de plantas de tratamientos de residuos industriales líquidos
 604.323 569.183
 (RILES).
 RISES Gestión de residuos sólidos (RISES) y residuos peligrosos (ResPel). 148.418 154.356
 Otros Gestión de cumplimientos normativos internos y externos. 261.315 197.588
Embotelladoras Chilenas Unidas S.A. RILES Mantenimiento y control de plantas de tratamientos de residuos industriales líquidos
 714.126 1.134.198
 (RILES).
 RISES Gestión de residuos sólidos (RISES) y residuos peligrosos (ResPel). 1.725.130 1.384.836
 Gases Gestión emisiones atmosféricas. 71.289 81.387
 Otros Gestión de cumplimientos normativos internos y externos. 1.156.161 968.430
Aguas CCU-Nestlé Chile S.A. RILES Mantenimiento y control de plantas de tratamientos de residuos industriales líquidos
 84.252 61.890
 (RILES).
 RISES Gestión de residuos sólidos (RISES) y residuos peligrosos (ResPel). 125.413 92.533
 Gases Gestión emisiones atmosféricas. 3.300 1.362
 Otros Gestión de cumplimientos normativos internos y externos. 439.997 420.017
Fábrica de Envases Plásticos S.A. RISES Gestión de residuos sólidos (RISES) y residuos peligrosos (ResPel). 290.569 180.834
 Otros Gestión de cumplimientos normativos internos y externos. 51.136 47.530
 RILES Mantenimiento y control de plantas de tratamientos de residuos industriales líquidos
 396.502 67.862
 (RILES).
Manantial S.A. RISES Gestión de residuos sólidos (RISES) y residuos peligrosos (ResPel). 73.266 51.401
 Gases Gestión emisiones atmosféricas. 5.592 4.844
 Otros Gestión de cumplimientos normativos internos y externos. 40.224 24.300
 RILES Mantenimiento y control de plantas de tratamientos de residuos industriales líquidos
Milotur S.A. 7.227 11.729
 (RILES).
 RISES Gestión de residuos sólidos (RISES) y residuos peligrosos (ResPel). 7.412 5.506
 Otros Gestión de cumplimientos normativos internos y externos. 115.242 97.470
 144

[pág. 146]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Al 31 de diciembre de 2024 y 2023, los desembolsos efectuados (inversión) y montos comprometidos relacionados con el
medio ambiente son los siguientes:
 Al 31 de diciembre de 2024
 Monto Fecha
 Estado
Cía. que efectúa el Desembolsos comprometido estimada de
 Proyecto Concepto [Terminado,
desembolso efectuados períodos finalización
 En proceso]
 futuros desembolsos
 M$ M$
Cervecera CCU Chile Ltda. RILES Proyecto pozos AA y RIL et 2 En proceso 2.347 - 31-12-2025
 RILES Upgrade Flujómetros Pta.Agua y Riles En proceso 1.469 - 31-12-2025
 RILES Normalización estructura Pta.WTL En proceso 15.168 - 31-12-2025
 RILES Recuperación Módulo B Pta.Riles Ibtech En proceso 311.677 - 31-12-2025
 RILES Reemplazo tubería descarga Riles En proceso 44.762 - 31-12-2025
 RILES Reactor Waterleau - Reactor Ib En proceso 1.055.279 151.632 31-12-2025
 RILES Upgrade PTR etapa III En proceso 13.580 - 31-12-2025
 RILES Optimización Funcionamiento PT En proceso 122.076 51.084 30-05-2025
 Gases Cambio de caldera N° 3 En proceso 111.542 - 31-12-2025
 Otros Nuevo Etiquetado Alcoholes Qui En proceso 281.143 - 30-01-2026
 Otros Etiquetado Alcoholes Temuco En proceso 125.300 - 30-01-2026
 Otros Silenciador Manifold En proceso 81.284 - 30-05-2025
 Otros Upgrade torre enfriamiento CO2 En proceso 310.274 - 31-01-2025
 Otros Nueva norma de NH3 etapa 4 En proceso 67.907 - 31-12-2025
 Otros Saneado Aguas Sup. Terreno Quilicura En proceso 36.809 - 31-12-2025
 Otros Detección y extinción de incen En proceso 240.522 - 31-12-2025
 Otros Implementacion Sistemas de Seg En proceso 8.565 - 31-12-2025
 Otros Plan Seguridad planta Temuco En proceso 61.600 - 31-12-2025
 Otros Proyecto red incendio etapa 2 En proceso 324.086 - 31-12-2025
 Otros Reemplazo Piping NH3 Suministr En proceso 1.500 - 31-12-2025
 Otros Renovación equipos NH3 En proceso 439.084 - 31-12-2025
 Otros Extracción de CO2 (Etapa II) En proceso 58.752 - 31-12-2025
 Otros Mejora sistema de extic y dete En proceso 71.720 - 31-12-2025
 Otros Master Plan Quilicura (EISTU-DIA) En proceso 40.937 - 31-12-2025
 Otros Brechas Estándar NH3 En proceso 51.817 - 31-12-2025
 Otros Renov.equipos NH3 et 2 + Están En proceso 306.952 52.971 31-12-2025
 Otros Set Point Variable Pta.NH3 En proceso 60.805 - 31-12-2025
 Otros Alcantarillados y pozos (aguas En proceso 26.062 103 31-12-2025
 Otros DIA Aumento capacidad Temuco En proceso 3.780 2 30-01-2026
 Otros Red de agua potable En proceso 21.773 103 30-03-2025
 Otros Nueva norma NH3 et 3 En proceso 136.028 - 31-12-2025
 Otros Mitigación de Ruido según Prot En proceso 10.934 9.844 31-12-2025
 Otros Brechas Estándar CO2 En proceso 60.866 6.700 31-12-2025
 Otros Extracción CO2 etapa 2 En proceso 149.655 12.143 01-03-2025
 Otros Seguridad máquinas etapa III En proceso 109.783 44.589 01-03-2025
CCU Argentina S.A. RILES Planta de Efluentes Et.2 En proceso 1.817 - 31-12-2025
 RILES Planta de Efluentes Et.3 En proceso 256.738 21.387 31-12-2025
 RILES Planta Efluentes ET2 CDL En proceso 139.148 - 31-12-2025
 Otros Adecuación Sist. red Incendio ET1 LJ En proceso 42.613 - 31-12-2025
 Otros Mntto de playas (juntas) En proceso 878 - 31-12-2025
 Otros Depósito de químicos LJ En proceso 203.294 - 31-12-2025
 Otros Paredones Perimetrales SV En proceso 84.011 - 31-12-2025
 Otros ADO IT Argentina En proceso 67.555 - 31-12-2025
 Otros Adec. Sistema NH3-CO2 ET2 CDD En proceso 73.063 7.123 31-12-2025
 Otros Cambio de Balanza Camiones En proceso 36.128 - 31-12-2025
 Otros MP Red de Incendios LJ En proceso 353.789 - 31-12-2025
 Otros Apex Molino ET 3/3 SL En proceso 3.784 - 31-12-2025
 Otros Camb cabezales pale despasensores SL En proceso 87.983 - 31-12-2025
 Otros Muros ignífugos entre trafos LJ En proceso 38.928 98 31-12-2025
 Otros Interruptores BT /CAMMESA LJ En proceso 20.814 - 31-12-2025
 Otros Camb cabezales pale despasensores SL En proceso 87.983 - 31-12-2025
 Otros Adecuación Sistema NH3- CO2 CDL En proceso 667 - 31-12-2025
 Otros Potabilización de Agua de Proceso ALL En proceso 49.575 - 31-12-2025
 Otros SySO y 5S - CDL/ALL En proceso 1.851 - 31-12-2025
Cervecería Kunstmann S.A. Gases STD NH3 Extractor de Vahos En proceso 48.376 - 31-12-2025
 Gases RCB Sala de Caldera En proceso 51.816 - 31-12-2025
 RISES Implementación Tks Segmentación PTRS En proceso 72.775 1.114 31-12-2025
 Otros DIA En proceso 13.410 - 31-12-2025
 Otros Cumplimiento Normativo Red de En proceso 70.870 1.087 31-12-2025
 Otros Humedal Depurador En proceso 61.310 - 31-12-2025
 Otros DIA y MasterPlan 2024 En proceso 79.135 22.043 31-12-2025
 Otros Buenas prácticas consumo energ En proceso 13.383 - 31-12-2025
 Otros Buenas practicas consumos de a En proceso 42.459 881 31-12-2025
 Otros FEI Complejo Cervecero En proceso 134.458 - 31-12-2025
 145

[pág. 147]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
 Al 31 de diciembre de 2024
 Monto
 Desembolsos comprometido Fecha
 Estado
Cía. que efectúa el efectuados períodos estimada de
 Proyecto Concepto [Terminado,
desembolso futuros finalización
 En proceso]
 desembolsos
 M$ M$
Compañía Pisquera de Chile RILES Geomembrana Piscina 1 PTR En proceso 5.566 - 31-12-2025
S.A. Otros DIA y PTR 15 Ton Salamanca En proceso 158.603 122.329 31-12-2025
 Otros Planta Osmosis 13-15 m3/h OV En proceso 17.116 - 31-12-2025
 Otros Casino sello verde MP En proceso 1.564 - 31-12-2025
 Otros Circuito Cerrado Refrig. SA En proceso 523.840 29.834 31-12-2025
 Otros Cump. DS43 Bodega SUSPEL OV En proceso 52.500 - 31-12-2025
 Otros Estándar pozos agua OV En proceso 4.535 24.362 31-03-2025
 Otros Pasarelas y Plataformas SO En proceso 31.451 - 31-12-2025
VSPT S.A. RILES DAF PTR Terminado 647 - Finalizado
 RILES Siniestro PTR IDM Terminado 39.838 - Finalizado
 RILES Siniestro PTR Molina En proceso 200.220 - 31-12-2025
 RILES Bombas Refr. Calef. Riles Terminado 19.708 - Finalizado
 RILES Bombas suministros, riles y AS En proceso 13.653 - 31-12-2025
 Gases Sistema para caldera eléctrica Terminado 69.469 - Finalizado
 Gases Caldera de vapor Terminado 23.535 - Finalizado
 Otros Detección CO2 Molina En proceso 12.365 - 31-12-2025
 Otros Detección CO2 Isla de Maipo En proceso 14.888 - 31-12-2025
 Otros (R) Sist. contención incendios Terminado 1.080 - Finalizado
 Otros Obras de Riego Pencahue En proceso 36.447 - 31-12-2025
 Otros Biodiversidad Tarapacá Fase V En proceso 4.686 - 31-12-2025
 Otros Red de Incendio 1/3 IDM Terminado 98.870 - Finalizado
 Otros Detección incendios Molina En proceso 67.438 - 31-12-2025
 Otros Mitigación Sequía (2024) En proceso 87.750 - 31-12-2025
 Otros Caudalímetros moviles En proceso 10.543 - 31-12-2025
 Otros Red de Incendios IdM (2/3) En proceso 72.428 - 31-12-2025
 Otros Autom. Mediciones KPI En proceso 14.016 3 31-12-2025
 Otros Temp. Sistema aseo cubas En proceso 5.519 6.097 31-12-2025
Embotelladoras Chilenas Unidas RILES Canalización y contención de descargas En proceso 40.451 - 31-12-2025
S.A. RILES Normalización descarga efluent En proceso 11.950 - 31-12-2025
 RILES Planta de Riles NPR En proceso 60.588 - 31-12-2025
 RILES Instalación de Estanque PTR En proceso 94.132 - 31-12-2025
 RILES Mejoras PTR: Medidor DQO En proceso 160.308 28.975 31-12-2025
 RILES Instal Generador Planta Agua En proceso 79.167 3.790 31-12-2025
 Gases Cumpl. Legal RS 2425/ Decreto 31 SMA En proceso 36.590 - 31-12-2025
 Gases Mejoras eficiencia energía térmica En proceso 7.838 - 31-12-2025
 Gases Mejoras instalaciones suministro vapor En proceso 134.722 1.919 31-12-2025
 RISES Adecuación de Sist Alma Suspel modelo En proceso 6.813 - 31-12-2025
 RISES Aumento capacidad bodega Suspel NPR En proceso 2.366 - 31-12-2025
 RISES Planta RPET Equipos En proceso 18.994.355 - 31-12-2025
 RISES Planta RPET OOCC En proceso 9.472.387 - 31-12-2025
 RISES Planta RPET Suministros En proceso 2.203.702 - 31-12-2025
 Otros Cambio Inspectores nivel (F1) En proceso 125.265 - 31-12-2025
 Otros Estandarizacion Red Amoniaco En proceso 36.994 - 31-12-2025
 Otros Romana NPR En proceso 54.686 - 31-12-2025
 Otros Sistema de Monitoreo A&E En proceso 1.070 - 31-12-2025
 Otros Upgrade Pozo 3 En proceso 6.552 - 31-12-2025
 Otros Medidores de Caudal En proceso 17.867 - 31-12-2025
 Otros Mejoras Eficiencia ET (Et 2/3) En proceso 49.321 - 31-12-2025
 Otros Recup Energía Venteo Degas En proceso 65.950 427 31-12-2025
 Otros Recuperación de Agua En proceso 201.726 22.610 31-12-2025
 Otros Mejoras Infra. seguridad alimentaria En proceso 125.265 - 31-12-2025
 Otros Renovación cámara de frío Calle Modelo En proceso 54.675 - 31-12-2025
 Otros Cierre Perimetral En proceso 81.140 - 31-12-2025
 Otros Upgrade Sistema Control Osmosis Inversa En proceso 17.547 - 31-12-2025
 Otros Estandariz red NH3 (Et 3/3) En proceso 210.011 - 31-12-2025
 Otros Estandar Riesgos Críticos CO2 En proceso 106.760 4.416 31-12-2025
 Otros Medidas de Seguridad CO2 En proceso 44.676 1.717 31-12-2025
 Otros Actualización Sist. Emerg FEI En proceso 36.464 3.163 31-12-2025
 Otros Eliminación Ftes. Contamin En proceso 29.234 150 31-12-2025
 Otros Optimización sistema de ataque contra in En proceso 77.054 - 31-12-2025
 Otros Mejora sist captación y filtrado agua P3 En proceso 59.758 - 31-12-2025
 146

[pág. 148]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
 Al 31 de diciembre de 2024
 Monto Fecha
 Estado Desembolsos
Cía. que efectúa el comprometido estimada de
 Proyecto Concepto [Terminado, efectuados
desembolso períodos futuros finalización
 En proceso]
 M$ M$ desembolsos
Aguas CCU-Nestlé Chile S.A. RILES Monitoreo y Control de Variables PTR En proceso 193.663 4.959 31-12-2025
 RILES Cambio Estanques PTAS Servidas En proceso 3.286 29.473 31-12-2025
 RILES VDF y Bombas. En proceso 18.637 31-12-2025
 RILES Mejoras PTR; Medidor DQO+ Est. En proceso 161.887 15.841 31-12-2025
 RISES Modificación de bodegas RESPEL En proceso 300 31-12-2025
 Otros Red de Incendios Fase III En proceso 256.475 31-12-2025
 Otros Calidad Energética y monitoreo SGE En proceso 4.282 31-12-2025
 Otros Fase II Red de Agua Coinco En proceso 99.592 399 31-12-2025
 Otros Detección y alarma de riesgo crítico CO2 En proceso 3.147 31-12-2025
 Otros Renovación de sistemas de emer En proceso 17.836 31-12-2025
 Otros Acondicionamiento y reutilizac En proceso 20.265 2.517 31-12-2025
 Otros Habilitación Obras Fuentes de En proceso 32.331 31-12-2025
Fábrica de Envases Plásticos RISES Ante proyecto planta de reciclaje PET En proceso 79.535 31-12-2025
S.A.
 RISES Planta RPET Inyección En proceso 1.948.012 31-03-2025
 Otros Cumplimiento Normativo En proceso 45.127 31-12-2025
 Otros Linerless Plasco En proceso 286.864 31-12-2025
 Otros Mitigación de Ruido Protocolo En proceso 31.200 31-12-2025
 Otros Segunda Parte Normalización de Amoníaco En proceso 46.426 31-12-2025
 Otros Erradicación de Fuentes de con En proceso 15.251 31-12-2025
 Otros Mejoras de Seguridad/Medioambiente En proceso 17.999 31-12-2025
 Otros Normalización de Sistema de Am En proceso 15.296 31-12-2025
 Otros Puntos Grúa Cargas Eléctricas En proceso 29.932 1 31-12-2025
Transportes CCU Ltda. Otros DIA CD Talcahuano En proceso 41.617 31-12-2025
 Otros Normativo En proceso 152.444 1 31-12-2025
 Otros Sustentabilidad, MA y ER En proceso 271.668 9.696 31-12-2025
 Otros Estudios TCCU En proceso 70.276 71.030 31-12-2025
 Otros Normativo En proceso 200.701 738.842 31-12-2025
 Otros Optimización de bodegas/racks En proceso 5.856 31-12-2025
Milotur S.A. RILES Reactores anaeróbicos pta trat efluentes En proceso 548.719 31-12-2025
 RILES Remod planta tratamien efluentes-etapa 2 En proceso 34.653 31-12-2025
 Otros Adec. Instal. filtros trap agua nativa En proceso 3.395 31-12-2025
 Otros Cumplimiento legal En proceso 126 31-12-2025
 Otros Cumplimiento Legal Año 2023 En proceso 3.344 31-12-2025
 Otros HACCP 3° Instancia En proceso 9.557 31-12-2025
 Otros HACCP 4°instancia En proceso 31.174 31-12-2025
 Otros Reducción consumo específico de agua En proceso 174.274 31-12-2025
 Otros Remodelación en baños y comedor fase 2 En proceso 72.540 1.021 31-12-2025
 Otros Seguridad y 5S 2024 En proceso 68.074 4.954 31-12-2025
 Otros Cumplimiento Legal Agua MSP En proceso 70.887 31-12-2025
 147

[pág. 149]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
 Al 31 de diciembre de 2023
 Monto
 Desembolsos comprometido Fecha
 Estado
Cía. que efectúa el efectuados períodos estimada de
 Proyecto Concepto [Terminado,
desembolso futuros finalización
 En proceso]
 desembolsos
 M$ M$
Cervecera CCU Chile Ltda. RILES Upgrade PTR etapa III En proceso 222.670 - 31-12-2024
 RILES Proyecto pozos AA y RIL et 2 En proceso 28.908 2.428 31-12-2024
 RILES Upgrade Flujómetros Pta.Agua y Riles En proceso 45.772 1.465 31-12-2024
 RILES Cambio desagüe línea envasado En proceso 390.257 67.994 31-12-2024
 RILES Monitoreo Pozos Profundos En proceso 12.181 - 31-12-2024
 RILES Proyecto Alcantarillado En proceso 20.150 - 31-12-2024
 RILES Automatización Pta. Agua En proceso 8.940 - 31-12-2024
 RILES Normalización estructura Pta.WTL En proceso 412.379 - 31-12-2024
 Gases Cambio caldera etapa 2. En proceso 59.375 - 31-12-2024
 Gases Cambio de caldera N° 3 En proceso 930.829 - 31-12-2024
 Otros Master Plan Quilicura (EISTU-DIA) En proceso 24.908 - 31-12-2024
 Otros Nueva norma NH3 etapa 3 En proceso 384.648 - 31-12-2024
 Otros Regularización Biogás En proceso 8.365 - 31-12-2024
 Otros Proyecto red incendio etapa 2 En proceso 388.458 - 31-12-2024
 Otros Nueva norma de NH3 etapa 4 En proceso 181.968 11.225 31-12-2024
 Otros FSCC etapa 2 En proceso 7.092 - 31-12-2024
 Otros Upgrade Medidores de Energía parte 2 En proceso 5.100 - 31-12-2024
 Otros FSSC Etapa 3 En proceso 133.995 - 31-12-2024
 Otros Remplazo duchas de emergencia En proceso 41.036 - 31-12-2024
 Otros Detección y extinción de incen En proceso 253.045 99.990 31-12-2024
Compañía Industrial Cervecera RILES Planta de Efluentes Et.2 En proceso 794.035 974 31-12-2024
S.A. RILES Tratamiento de efluentes SV En proceso 147.897 2.011 31-12-2024
 RILES Reemplazo bombas efluentes SF Terminado 84 - Finalizado
 RILES Adec. Planta Efluentes CDD En proceso 769 - 31-12-2024
 RILES Potabilización de Agua de Proceso ALL En proceso 133.659 - 31-12-2024
 RILES Planta Efluentes ET2 CDL En proceso 994.582 16.873 31-12-2024
 Gases Upgrade desaireador caldera SF En proceso 424 - 31-12-2024
 Otros Adecuación Sist. red Incendio ET1 LJ En proceso 12.433 11.513 31-12-2024
 Otros UP-Grade cuadros NH3 OD LJ En proceso 89.627 310 31-12-2024
 Otros UP-Grade cuadros NH3 OD En proceso 45.912 - 31-12-2024
 Otros Adecuación Sistema NH3 SL En proceso 25.588 - 31-12-2024
 Otros Adecuación Sistema NH3 SF En proceso 13.608 - 31-12-2024
 Otros Equipos de Lab + FSSC 22.000 S En proceso 11.797 31 31-12-2024
 Otros Adec Eléctrica E1 ALL En proceso 40.380 355 31-12-2024
 Otros Adecuación Sistema NH3- CO2 CDL En proceso 87.708 1.121 31-12-2024
Cervecería Kunstmann S.A. RILES Monitoreo de Aguas En proceso 29.087 - 31-12-2024
 RILES Filtro para tratamiento primario de agua En proceso 15.504 - 31-12-2024
 Otros DIA (Primera Etapa) En proceso 15.716 - 31-12-2024
 Otros DIA En proceso 70.690 23.122 31-12-2024
Compañía Pisquera de Chile RILES Tableros eléctricos Riles Terminado 5.372 - Finalizado
S.A. RILES Geomembrana Piscina 1 PTR En proceso 42.856 - 31-12-2024
 RISES Restauración Patio Salvataje Sotaquí Terminado 2.653 - Finalizado
 Otros Normalización tableros Elect2 En proceso 6.720 - 31-12-2024
 Otros Red Húmeda SA En proceso 263.910 - 31-12-2024
 Otros Regularización Sist. Eléct. Planta OV En proceso 1.811 - 31-12-2024
 Otros Medidores Ee Planta Sotaquí En proceso 8.438 - 31-12-2024
 Otros Medidores Ee Planta Salamanca En proceso 1.920 - 31-12-2024
Viña San Pedro Tarapacá S.A. RILES Separador de sólidos riles En proceso 14.639 - 31-12-2024
 RILES Up-Grade Disposición Riles En proceso 400 - 31-12-2024
 RILES Tk Soda Granel PTR Terminado 6.970 - Finalizado
 RILES DAF PTR En proceso 157.599 1.926 31-12-2024
 RILES Aireadores de riles En proceso 28.263 - 31-12-2024
 RILES Bombas riles En proceso 15.498 - 31-12-2024
 RILES Epóxido estanques de agua En proceso 9.779 1.499 31-12-2024
 RILES Upgrade de riles y AS En proceso 10.522 - 31-12-2024
 RILES Medición Caudal Pozos (DGA) En proceso 450 - 31-12-2024
 RILES Encamisado pozo profundo En proceso 1.528 - 31-12-2024
 RILES Medición Caudal Superficial IdM En proceso 17.468 - 31-12-2024
 RILES Aseguramiento agua En proceso 200.000 - 31-12-2024
 RILES Caudalímetros - Control Riego En proceso 300 - 31-12-2024
 RILES Epóxido estanques de agua En proceso 8.564 1.499 31-12-2024
 Gases Caldera de vapor En proceso 135.919 2.773 31-12-2024
 Gases Detección de gases En proceso 4.465 - 31-12-2024
 Otros Red de Incendio Molina 2/3 Terminado 4.209 - Finalizado
 Otros Red de Incendio Molina 3/3 Terminado 9.216 - Finalizado
 Otros Red de Incendios 1/3 IDM En proceso 4.625 109.337 31-12-2024
 Otros Biodiversidad Tarapacá Fase V En proceso 13.000 - 31-12-2024
 Otros Reducción de ruido En proceso 9.463 - 31-12-2024
 148

[pág. 150]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
 Al 31 de diciembre de 2023
 Monto
 Desembolsos comprometido Fecha
 Estado
Cía. que efectúa el efectuados períodos estimada de
 Proyecto Concepto [Terminado,
desembolso futuros finalización
 En proceso]
 desembolsos
 M$ M$
Embotelladoras Chilenas Unidas RILES Normalización descarga efluent En proceso 160.473 - 31-12-2024
S.A. RILES Planta de Riles NPR En proceso 104.176 - 31-12-2024
 RILES Medidores de caudal En proceso 42.012 8.597 31-12-2024
 RILES Mejora sistema de regadío En proceso 109 29.871 31-12-2024
 RILES Upgrade Pozo 3 En proceso 53.036 - 31-12-2024
 RISES Aumento capacidad bodega Suspel NPR En proceso 96.619 - 31-12-2023
 RISES Edificio Sustancias Peligrosas En proceso 1.523 - 31-12-2024
 RISES Adecuación bodega sustancias peligrosas En proceso 84.968 - 31-12-2024
 RISES Adecuación de Sist Alma SUSPEL Modelo En proceso 241.852 1.676 31-12-2024
 Otros Linerless Antofagasta En proceso 38.153 - 31-12-2024
 Otros Linerless Temuco En proceso 14.594 - 31-12-2024
 Otros Linerless Modelo En proceso 174.676 - 31-12-2024
 Otros Planta RPET Equipos En proceso 4.116.728 11.970.113 31-12-2024
 Otros Mitigación-Urbanización (NPR). En proceso 28.193 - 31-12-2024
 Otros Mejoras Infra. seguridad alimentaria En proceso 124.468 56.359 31-12-2024
 Otros Control Polución NPR En proceso 186.703 - 31-12-2024
 Otros Planta RPET OOCC En proceso 6.821.093 - 31-12-2024
 Otros Estandarización Red Amoniaco En proceso 88.194 - 31-12-2024
 Otros Cumpl. Legal RS 2425/ Decreto 31 SMA En proceso 50.160 33.440 31-12-2024
 Otros Estandarización Red Amoniaco Et. 2 En proceso 258.929 1 31-12-2024
 Otros Planta RPET Suministros En proceso 702.382 416.658 31-12-2024
 Otros Erradicación Fuentes de Contaminación En proceso 25.000 - 31-12-2024
 Otros Sistema de Monitoreo A&E En proceso 58.925 - 31-12-2024
 Otros Norm. instalaciones eléctricas Et 1. En proceso 99.913 41.200 31-12-2024
 Otros Accesos sanitarios En proceso 56.372 - 31-12-2024
Aguas CCU-Nestlé Chile S.A. RISES Modificación de bodegas RESPEL En proceso 700 - 31-12-2024
 Otros Mejoramiento red de incendio E En proceso 40.282 - 31-12-2024
 Otros Red de Incendios Fase III En proceso 60.542 124.255 31-12-2024
 Otros Red de incendios Fase 2 En proceso 124.724 - 31-12-2024
 Otros Linerless Coinco En proceso 37.911 - 31-12-2024
 Otros Sistema de Gestión Energética En proceso 53 - 31-12-2024
 Otros Calidad Energética y monitoreo SGE En proceso 25.012 4.282 31-12-2024
 Otros Luminarias LED Coinco En proceso 3.437 - 31-12-2024
 Otros Cambio de transformador En proceso 510 - 31-12-2024
 Otros Mejora línea baja tensión En proceso 4.100 - 31-12-2024
Fábrica de Envases Plásticos Gases Cambios motores con eficiencia energética En proceso 25.040 - 31-12-2024
S.A. Otros Ante proyecto planta de reciclaje PET En proceso 159.052 - 31-12-2024
 Otros Linerless Plasco En proceso 232.326 - 31-12-2024
 Otros Mejoras de Seguridad/Medioambiente En proceso 46.624 - 31-12-2024
 Otros Erradicación de Fuentes de con En proceso 11.117 - 31-12-2024
 Otros Luminarias LED Plasco En proceso 18.275 - 31-12-2024
 Otros Cumplimiento Normativo En proceso 4.286 4.990 31-12-2024
 Otros Planta RPET Inyección En proceso 48.751 124.497 31-12-2024
 Otros Mejoras Casino y Camarines PLASCO En proceso 12.119 - 31-12-2024
 Otros Mitigación de Ruido Protocolo En proceso 23.768 - 31-12-2024
 Otros Normalización de Sistema de Am En proceso 71.702 - 31-12-2024
 Otros Normalización tablero eléctric En proceso 31.371 534 31-12-2024
 Otros Segunda Parte Normalización de Amoníaco En proceso 33.466 - 31-12-2024
Transportes CCU Ltda. Otros DIA CD Talcahuano En proceso 70.137 - 31-12-2024
 Otros Normativo y Sustentabilidad En proceso 8.800 - 31-12-2024
 Otros Normativo En proceso 94.440 - 31-12-2024
Milotur S.A. RILES Remodelación Planta Tratamiento En proceso 3.984 - 31-12-2024
 RILES Reactores anaeróbicos pta trat efluentes En proceso 53.730 9.074 31-12-2024
 RILES Remod planta tratamien efluentes-etapa 2 En proceso 291.411 1.844 31-12-2024
 Otros Cumplimiento legal En proceso 33.077 114 31-12-2024
 Otros Cumplimiento Legal año 2023 En proceso 29.525 300 31-12-2024
 149

[pág. 151]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Nota 37 Eventos posteriores
a) Los Estados Financieros Consolidados de CCU S.A. y subsidiarias al 31 de diciembre de 2024 han sido aprobados por
 el Directorio con fecha 25 de febrero de 2025.
b) Con posterioridad al 31 de diciembre de 2024 y hasta la fecha de emisión de estos Estados Financieros Consolidados
 no se tiene conocimiento de otros hechos de carácter financiero o de otra índole, que pudiesen afectar
 significativamente la interpretación de los mismos.
 150

[pág. 152]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Anexo I
Información Adicional requerida por Oficio Circular N° 715 emitido por CMF de fecha 3 de febrero de 2012 para el
rubro Deudores comerciales y otras cuentas por cobrar.
Este Anexo forma parte integral de los Estados Financieros Consolidados de CCU S.A. y subsidiarias.
Al cierre del 31 de diciembre de 2024 y 31 de diciembre de 2023 la Compañía no mantiene saldos que se relacionen a una cartera securitizada.
a) Estratificación de la cartera no securitizada.
 Al 31 de diciembre de 2024
 Cartera al día Morosidad Morosidad Morosidad Morosidad Morosidad Morosidad Morosidad Morosidad Morosidad Total corriente Total no
 Deudores comerciales y otras
 1-30 días 31-60 días 61-90 días 91-120 días 121-150 días 151-180 días 181-210 días 211-250 días superior a 251 corriente
 cuentas por cobrar
 días
 M$ M$ M$ M$ M$ M$ M$ M$ M$ M$ M$ M$
Deudores comerciales bruto 414.767.007 18.246.597 3.652.284 2.027.880 358.991 447.699 755.202 424.480 411.267 3.556.907 444.648.314 -
Provisión de deterioro (2.433.055) (267.381) (297.180) (251.880) (194.646) (175.107) (338.437) (424.480) (411.267) (2.992.262) (7.785.695) -
Otras cuentas por cobrar bruto 69.335.509 36.494 94.664 58.545 164.757 - - 97 - 158.488 69.848.554 5.966.414
Total 481.669.461 18.015.710 3.449.768 1.834.545 329.102 272.592 416.765 97 - 723.133 506.711.173 5.966.414
 Al 31 de diciembre de 2023
 Cartera al día Morosidad Morosidad Morosidad Morosidad Morosidad Morosidad Morosidad Morosidad Morosidad Total corriente Total no
 Deudores comerciales y otras
 1-30 días 31-60 días 61-90 días 91-120 días 121-150 días 151-180 días 181-210 días 211-250 días superior a 251 corriente
 cuentas por cobrar
 días
 M$ M$ M$ M$ M$ M$ M$ M$ M$ M$ M$ M$
Deudores comerciales bruto 369.010.568 8.542.590 3.223.517 1.665.887 793.340 353.960 308.580 356.925 528.617 2.885.032 387.669.016 -
Provisión de deterioro (2.393.058) (385.276) (452.231) (548.089) (283.477) (139.586) (177.277) (332.970) (500.972) (2.538.369) (7.751.305) -
Otras cuentas por cobrar bruto 66.302.808 29.478 34.853 64.880 14.408 66.088 28.985 - - 27.542 66.569.042 3.313.742
Total 432.920.318 8.186.792 2.806.139 1.182.678 524.271 280.462 160.288 23.955 27.645 374.205 446.486.753 3.313.742
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Cartera no repactada Cartera repactada Total cartera bruta Cartera no repactada Cartera repactada Total cartera bruta
 Número de Monto Bruto M$ Número de Monto bruto M$ Número de Monto bruto M$ Número de Monto Bruto M$ Número de Monto bruto M$ Número de Monto bruto M$
 clientes clientes clientes clientes clientes clientes
Cartera al día 60.738 414.756.742 3 10.265 60.741 414.767.007 60.212 368.986.120 10 24.448 60.222 369.010.568
Entre 1 y 30 días 29.000 18.246.597 - - 29.000 18.246.597 15.087 8.542.590 - - 15.087 8.542.590
Entre 31 y 60 días 11.888 3.647.184 2 5.100 11.890 3.652.284 6.002 3.223.517 - - 6.002 3.223.517
Entre 61 y 90 días 4.236 2.027.880 - - 4.236 2.027.880 2.714 1.654.305 1 11.582 2.715 1.665.887
Entre 91 y 120 días 2.949 358.991 - - 2.949 358.991 2.354 793.340 - - 2.354 793.340
Entre 121 y 150 días 1.748 442.399 2 5.300 1.750 447.699 1.835 341.620 1 12.340 1.836 353.960
Entre 151 y 180 días 1.426 755.202 - - 1.426 755.202 1.307 308.580 - - 1.307 308.580
Entre 181 y 210 días 1.996 421.718 1 2.762 1.997 424.480 1.259 356.925 - - 1.259 356.925
Entre 211 y 250 días 1.364 411.267 - - 1.364 411.267 3.060 528.617 - - 3.060 528.617
Superior a 251 días 7.478 2.908.875 5 648.032 7.483 3.556.907 6.469 2.252.991 6 632.041 6.475 2.885.032
Total 122.823 443.976.855 13 671.459 122.836 444.648.314 100.299 386.988.605 18 680.411 100.317 387.669.016
 151

[pág. 153]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
b) Cartera protestada y en cobranza judicial:
 Al 31 de diciembre de 2024 Al 31 de diciembre de 2023
 Cartera protestada y en cobranza judicial Número de Monto Número de Monto
 clientes M$ clientes M$
 Documentos por cobrar protestados 315 649.632 372 688.535
 Documentos por cobrar en cobranza judicial 254 2.008.646 212 1.270.735
 Total 569 2.658.278 584 1.959.270
c) Provisiones y castigos:
 Al 31 de Al 31 de
 diciembre de diciembre de
 Provisiones y castigos 2024 2023
 M$ M$
 Provisión cartera no repactada 7.132.418 7.080.649
 Provisión cartera repactada 653.277 670.656
 Castigos del ejercicio (987.556) (1.025.786)
 Recuperos del ejercicio (1.833.716) (1.122.472)
 152

[pág. 154]
Compañía Cervecerías Unidas S.A. y subsidiarias
Notas a los Estados Financieros Consolidados
31 de diciembre de 2024
Anexo II
Información Adicional Requerida sobre Proveedores y Otras Cuentas por Pagar.
Este Anexo forma parte integral de los Estados Financieros Consolidados de CCU S.A. y subsidiarias.
a) Proveedores con pagos al día:
 Al 31 de diciembre de 2024
 Montos según plazos de pago
 Tipo de proveedor Período
 Entre 31 y 60 Entre 61 y 90 Entre 91 y 120 Entre 121 y Más de 365
 Hasta 30 días promedio de
 días días días 365 días días Total pago (días)
 M$ M$ M$ M$ M$ M$ M$
Productos 206.831.192 27.168.272 15.132.524 1.001.914 4.676 - 250.138.578 54,58
Servicios 120.303.458 7.116.096 5.296.364 6.035 955.170 41.382 133.718.505 35,75
Otros 105.722.617 986.645 14.125.453 600.518 1.676.232 3.893 123.115.358 32,46
Total 432.857.267 35.271.013 34.554.341 1.608.467 2.636.078 45.275 506.972.441
 Al 31 de diciembre de 2023
 Montos según plazos de pago
 Tipo de proveedor Período
 Entre 31 y 60 Entre 61 y 90 Entre 91 y 120 Entre 121 y Más de 365
 Hasta 30 días promedio de
 días días días 365 días días Total
 pago (días)
 M$ M$ M$ M$ M$ M$ M$
Productos 152.459.031 25.923.233 16.084.902 1.132.733 - - 195.599.899 66,41
Servicios 92.202.099 10.454.163 8.403.625 59.002 363.842 - 111.482.731 26,06
Otros 115.843.984 1.797.470 2.994.716 - 970.868 88.596 121.695.634 24,96
Total 360.505.114 38.174.866 27.483.243 1.191.735 1.334.710 88.596 428.778.264
b) Proveedores con pagos vencidos:
 Al 31 de diciembre de 2024
 Montos según plazos de pago
 Tipo de proveedor Período
 Entre 31 y 60 Entre 61 y 90 Entre 91 y 120 Entre 121 y Más de 180
 Hasta 30 días promedio de
 días días días 180 días días Total
 pago (días)
 M$ M$ M$ M$ M$ M$ M$
Productos 2.634.546 517.767 104.381 398.217 101.264 78.536 3.834.711 20,47
Servicios 2.992.064 235.333 175.558 28.149 8.797 54.779 3.494.680 22,15
Otros 541.819 58.700 1.785 12.466 4.154 11.704 630.628 6,55
Total 6.168.429 811.800 281.724 438.832 114.215 145.019 7.960.019
 Al 31 de diciembre de 2023
 Montos según plazos de pago
 Tipo de proveedor Período
 Entre 31 y 60 Entre 61 y 90 Entre 91 y 120 Entre 121 y Más de 180
 Hasta 30 días promedio de
 días días días 180 días días Total
 pago (días)
 M$ M$ M$ M$ M$ M$ M$
Productos 1.943.351 604.709 76.009 178.474 51.545 332.829 3.186.917 23,49
Servicios 1.605.182 907.431 93.623 9.593 59.773 31.939 2.707.541 18,62
Otros 294.982 13.829 40.093 1.157 8.648 31.328 390.037 17,58
Total 3.843.515 1.525.969 209.725 189.224 119.966 396.096 6.284.495
Los atrasos tienen su origen en diferentes motivos, dentro de los que destacan garantías contractuales asociadas a proyectos
de inversión y discrepancias comerciales con proveedores en proceso de regularización.
 153

# Finanzas II · 20 Clase_20_Administacion de Caja

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 20: Administración de Caja
 Profesor: Augusto Orellana
 Maryo 2026
Prof: Augusto Orellana Clase 20: Administración de Caja 1 / 17

[pág. 2]
Roadmap
1 Adm de Caja
2 Liquidez
3 Modelo de Miller y Orr
4 Graham and Leary (2018)
 Prof: Augusto Orellana Clase 20: Administración de Caja 2 / 17

[pág. 3]
Roadmap
1 Adm de Caja
2 Liquidez
3 Modelo de Miller y Orr
4 Graham and Leary (2018)
 Prof: Augusto Orellana Clase 20: Administración de Caja 3 / 17

[pág. 4]
Administración de Caja (Tesorerı́a)
Motivo: Utilización eficiente de la caja
Consistentemente alineado con los objetivos estratégicos:
 Liquidez
 Conservación de los recursos de caja
 Financiamiento
 Exposición al riesgo
 Coordinación
 Prof: Augusto Orellana Clase 20: Administración de Caja 4 / 17

[pág. 5]
Roadmap
1 Adm de Caja
2 Liquidez
3 Modelo de Miller y Orr
4 Graham and Leary (2018)
 Prof: Augusto Orellana Clase 20: Administración de Caja 5 / 17

[pág. 6]
Liquidez
Motivos de la demanda por liquidez:
 Transacción
 Precaución
 Especulación
Costos de poca liquidez
 Demanda insatisfecha; insolvencia financiera
Costos de excesiva liquidez
 Costo de oportunidad; costo de agencia
 Prof: Augusto Orellana Clase 20: Administración de Caja 6 / 17

[pág. 7]
Roadmap
1 Adm de Caja
2 Liquidez
3 Modelo de Miller y Orr
4 Graham and Leary (2018)
 Prof: Augusto Orellana Clase 20: Administración de Caja 7 / 17

[pág. 8]
Modelo de Miller y Orr
 Caracterı́sticas: sistema de administración de efectivo con entradas y
 salidas que fluctúan aleatoriamente (con cambio promedio cero).
 Prof: Augusto Orellana Clase 20: Administración de Caja 8 / 17

[pág. 9]
Principales supuestos del modelo
 Cambios en los flujos netos de caja son inciertos, y se comportan de
 acuerdo a una distribución normal N(0, σ)
 Costo de oportunidad equivalente a la tasa de mercado
 La empresa puede comprar / vender valores negociables a un costo
 fijo igual a “F” pesos en cada oportunidad
Nivel deseable:
 1/3
 3 σ2
 
 ∗
 C =L+ F
 4 R
Limite superior:
 U ∗ = 3C ∗ − 2L
Saldo promedio efectivo:
 4C ∗ − L
 SPE =
 3
 Prof: Augusto Orellana Clase 20: Administración de Caja 9 / 17

[pág. 10]
Ejemplo:
 Saldo mı́nimo de caja = 100
 Varianza de los flujos de caja diarios = 40.000
 Tasa de interés diaria = 1%
 Costos de transacción por compra / venta de valores negociables = 10
Nivel deseable:
  1/3
 ∗ 3 40000
 C = 100 + ∗ 10 ∗ = 411
 4 0.01
Limite superior:
 U ∗ = 3 ∗ 411 − 2 ∗ 100 = 1.032
Saldo promedio efectivo:
 4 ∗ 411 − 100
 SPE = = 514
 3
 Prof: Augusto Orellana Clase 20: Administración de Caja 10 / 17

[pág. 11]
Ejemplo:
 Saldo mı́nimo de caja = 100
 Varianza de los flujos de caja diarios = 40.000
 Tasa de interés diaria = 1%
 Costos de transacción por compra / venta de valores negociables = 10
Nivel deseable:
  1/3
 ∗ 3 40000
 C = 100 + ∗ 10 ∗ = 411
 4 0.01
Limite superior:
 U ∗ = 3 ∗ 411 − 2 ∗ 100 = 1.032
Saldo promedio efectivo:
 4 ∗ 411 − 100
 SPE = = 514
 3
 Prof: Augusto Orellana Clase 20: Administración de Caja 11 / 17

[pág. 12]
Implicancias
 1 Cuanto mayor es la tasa de interés (R), menor es el saldo óptimo de
 efectivo
 2 Cuanto mayor es el costo fijo por pedido (F), mayor es el óptimo de
 efectivo
 3 Mientras mayor sea la incertidumbre (σ 2 ), mayor será el saldo óptimo
 y el lı́mite superior (U*), y la diferencia entre saldo óptimo y reserva
 de seguridad (L).
 Prof: Augusto Orellana Clase 20: Administración de Caja 12 / 17

[pág. 13]
Roadmap
1 Adm de Caja
2 Liquidez
3 Modelo de Miller y Orr
4 Graham and Leary (2018)
 Prof: Augusto Orellana Clase 20: Administración de Caja 13 / 17

[pág. 14]
The Evolution of Corporate Cash Graham and Leary, JACF
2018
Trends in Cash Holdings
 1920–1945: Cash holdings rose dramatically
 1946–1980: Significant decline in average and aggregate cash
 1981–2000: Sharp increase in average cash (driven by new firms);
 aggregate stable.
 2001–2014: Average cash levels off, aggregate cash increases due to
 foreign cash holdings
 Prof: Augusto Orellana Clase 20: Administración de Caja 14 / 17

[pág. 15]
The Evolution of Corporate Cash
Composition vs. Within-Firm Change
 Pre-1980 cash increases were driven by existing firms rather than
 compositional shifts
 Post-1980 increase in cash is mostly due to new firm entries (e.g.,
 tech/health Nasdaq IPOs).
 Within-firm cash holdings have been flat or declining since 1980
 Prof: Augusto Orellana Clase 20: Administración de Caja 15 / 17

[pág. 16]
The Evolution of Corporate Cash
High cash firms
 High growth, high risk, low profitability, low leverage
Low cash firms
 Stable earnings, low investment risk
Aggregate cash influenced by:
 Corporate profitability (cash accumulation)
 Investment needs (cash depletion)
 Macroeconomic trends (GDP, productivity)
 Tax policy (e.g., foreign cash repatriation costs)
 Prof: Augusto Orellana Clase 20: Administración de Caja 16 / 17

[pág. 17]
Both precautionary and agency motives for cash:
Precautionary
 Avoid costly external financing during uncertainty.
Agency
 Excess cash may enable inefficient spending if governance is weak.
Trends reflect changes in public firm composition
 not general firm behavior
 Prof: Augusto Orellana Clase 20: Administración de Caja 17 / 17

# Finanzas II · 23 Clase_23_ Criterios de Evaluacion de Proyectos

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 23: Criterios de evaluación de proyectos
 Profesor: Augusto Orellana
 Junio 2026
Prof: Augusto Orellana Clase 23: Criterios de evaluación 1 / 18

[pág. 2]
Roadmap
1 Criterios
2 Net Present Value
3 Tasa interna de retorno
4 Payback
5 Indice de Rentabilidad
6 Comentarios Adicionales
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 2 / 18

[pág. 3]
Roadmap
1 Criterios
2 Net Present Value
3 Tasa interna de retorno
4 Payback
5 Indice de Rentabilidad
6 Comentarios Adicionales
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 3 / 18

[pág. 4]
Criterios de evaluación y valoración
 1 Valor presente neto (NPV)
 2 Tasa interna de retorno (TIR)
 3 Payback (perı́odo de recuperación de la inversión inicial)
 4 Índice de rentabilidad (IR)
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 4 / 18

[pág. 5]
Roadmap
1 Criterios
2 Net Present Value
3 Tasa interna de retorno
4 Payback
5 Indice de Rentabilidad
6 Comentarios Adicionales
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 5 / 18

[pág. 6]
Net Present Value (NPV)
El valor actual neto (NPV) de un proyecto es el valor actual de sus flujos
de efectivo, descontados al costo de oportunidad del capital.
NPV =
 Investment mkt value - investment cost
Etapas:
 1 Pronosticar los flujos de efectivo netos (cantidad y plazo de cada
 uno).
 2 Estimar el coste de oportunidad del capital.
 3 Utilizar el coste de oportunidad del capital para descontar los flujos de
 efectivo futuros.
 4 Seguir adelante con el proyecto si el valor actual neto de todos los
 flujos de efectivo es mayor que cero. (Regla del NPV)
 ▶ Si NPV > 0 se crea valor
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 6 / 18

[pág. 7]
Evaluación del Proyecto: VPN y TIR
Si la tasa de costo de oportunidad de la inversión (100% capital propio), es decir, el costo de
capital promedio ponderado (WACC), es de 12%, entonces:
 1.365.000 1.365.000 1.365.000
 VP = + + ··· + = 6.780.828
 (1 + 12%)1 (1 + 12%)2 (1 + 12%)8
 VPN = −4.800.000 + 6.780.828 = 1.980.828
 Año Flujo de Caja VP@12% VP Acumulado
 0 -4.800.000 -4.800.000 -4.800.000
 1 1.365.000 1.218.750 -3.581.250
 2 1.365.000 1.088.170 -2.493.080
 3 1.365.000 971.580 -1.521.500
 4 1.365.000 867.482 -654.018
 5 1.365.000 774.538 120.520
 6 1.365.000 691.551 812.071
 7 1.365.000 617.457 1.429.528
 8 1.365.000 551.301 1.980.828
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 7 / 18

[pág. 8]
Roadmap
1 Criterios
2 Net Present Value
3 Tasa interna de retorno
4 Payback
5 Indice de Rentabilidad
6 Comentarios Adicionales
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 8 / 18

[pág. 9]
Tasa interna de retorno (TIR)
Tasa de descuento que hace NPV=0
TIR Rule:
 TIR > Retorno requerido (wacc) → Acepto el proyecto
 TIR < Retorno requerido (wacc) → Rechazo el proyecto
Ejemplo:
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 9 / 18

[pág. 10]
Tasa interna de retorno (TIR): Limitaciones
Multiples TIRs:
 Ante cashflows no convencionales:
 ▶ Year 0 : -60
 ▶ Year 1 : +155
 ▶ Year 2 : -100
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 10 / 18

[pág. 11]
Tasa interna de retorno (TIR): Limitaciones
Multiples TIRs:
 Proyectos mutuamente excluyentes:
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 11 / 18

[pág. 12]
Roadmap
1 Criterios
2 Net Present Value
3 Tasa interna de retorno
4 Payback
5 Indice de Rentabilidad
6 Comentarios Adicionales
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 12 / 18

[pág. 13]
Payback
Tiempo que toma tener NPV=0
 1.365.000 1.365.000 1.365.000
 VP = 1
 + 2
 + ··· + = 6.780.828
 (1 + 12%) (1 + 12%) (1 + 12%)8
 VPN = −4.800.000 + 6.780.828 = 1.980.828
 Año Flujo de Caja VP@12% VP Acumulado
 0 -4.800.000 -4.800.000 -4.800.000
 1 1.365.000 1.218.750 -3.581.250
 2 1.365.000 1.088.170 -2.493.080
 3 1.365.000 971.580 -1.521.500
 4 1.365.000 867.482 -654.018
 5 1.365.000 774.538 120.520
 6 1.365.000 691.551 812.071
 7 1.365.000 617.457 1.429.528
 8 1.365.000 551.301 1.980.828
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 13 / 18

[pág. 14]
Payback: Limitaciones
No considera los flujos de caja que se generan después de recuperar la
inversión inicial
Ejemplo:
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 14 / 18

[pág. 15]
Roadmap
1 Criterios
2 Net Present Value
3 Tasa interna de retorno
4 Payback
5 Indice de Rentabilidad
6 Comentarios Adicionales
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 15 / 18

[pág. 16]
Índice de Rentabilidad (I.R.)
Ratio entre valor presente de los flujos de caja netos y la inversión inicial
 PV
 IR =
 I0
TIR Rule:
 IR >1 → Crea valor
 IR =1 → Preserva valor
 IR <1 → Destruye valor
Limitaciones: Proyectos mutuamente excluyentes
 Ignora la escala (el tamaño) de los flujos generados por el proyecto
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 16 / 18

[pág. 17]
Roadmap
1 Criterios
2 Net Present Value
3 Tasa interna de retorno
4 Payback
5 Indice de Rentabilidad
6 Comentarios Adicionales
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 17 / 18

[pág. 18]
Comentarios Adicionales
Tasa de Descuento e Inflación
 (1 + i) = (1 + π)(1 + r )
 Prof: Augusto Orellana Clase 23: Criterios de evaluación 18 / 18

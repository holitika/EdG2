# Finanzas II · Clase 27 Multiples

Fuente: clase de Finanzas II

[pág. 1]
EAA220B · Dirección Financiera
Valoración
a través de
Múltiplos
 Prof. Augusto Orellana · Junio 2026 · PUC Chile
 Clase 27

[pág. 2]
Motivación 1
 ¿Cuánto paga el mercado por empresas similares?
 DCF vs. Múltiplos Variable de desempeño
 El DCF no es la única forma de valorar una empresa. La
 Se ajusta por escala usando una variable fundamental: P/E,
 valoración relativa es una alternativa ampliamente usada en la
 EBITDA, Ventas, MtB.
 práctica.
 Empresas comparables Aplicación simple
 Se usa información de firmas comparables — sin necesidad de Se aplica el múltiplo promedio de la industria a la empresa
 estimar riesgo (APV, WACC) directamente. objetivo para obtener su valor estimado.
Fuente: Greenwood & White (2006), HBS 9-206-095

[pág. 3]
¿Qué es un Múltiplo? 2
 Múltiplo = Variable Valor / Variable
 Fundamental
 Múltiplo Variable Valor (rojo) Variable Fundamental (azul)
 P/E Precio de la acción Utilidad por acción (EPS)
 P/B Market Value Equity Book Value Equity
 EV/EBITDA Enterprise Value EBITDA
 Un múltiplo es simplemente el precio de mercado por unidad de desempeño económico.

[pág. 4]
VÍNCULO CON EL DCF
Derivación formal El múltiplo captura r y g implícitamente
Gordon Growth Model: No necesitas estimar el costo de capital ni la tasa de crecimiento: el
 mercado lo hace por ti.
 TEV = FCF₁ / (r − g)
Reordenando:
 Ventaja sobre DCF
 TEV / FCF = 1 / (r − g)
 Requiere muchos menos supuestos. Es rápido y refleja directamente
Eso ES el múltiplo:
 el precio de mercado de activos similares.
 Múltiplo = 1 / (r − g)
Ejemplo (r=15%, g=5%):
 Limitación: asume crecimiento estable
 Múltiplo = 10×
 Solo válido si los flujos futuros crecen a tasa constante g. Con flujos
 irregulares o negativos, el múltiplo puede ser engañoso.

[pág. 5]
Metodología General 3
 Seleccionar comparables
 1
 Elegir empresas con modelo de negocio, industria, crecimiento, riesgo y márgenes similares.
 Elegir la base del múltiplo
 2
 Determinar la variable fundamental a usar (EBITDA, Ventas, Utilidad neta, etc.).
 Calcular múltiplos
 3
 Computar el ratio para cada empresa comparable y promediar (simple o ponderado).
 Normalizar la base
 4
 Ajustar por ítems no recurrentes para obtener una base operacional representativa.
 Aplicar y concluir
 5
 Valor = Múltiplo × Base → Interpretar como rango, no como valor exacto.
Fuente: Luehrman (2009), HBS 9-206-039 · Ivashina & Boe (2020), HBS 9-218-017

[pág. 6]
Múltiplos más Usados 4
 P/E (Price-Earnings) M/B (Market-to-Book) EV/EBITDA
 Precio / EPS Mkt Value Equity / Book Value Equity Enterprise Value / EBITDA
Ventajas Ventajas Ventajas
Simple e intuitivo. Muy usado en renta Mide creación de valor. Refleja intangibles y Independiente de deuda. Comparable entre
variable. goodwill. distintas estructuras de capital.
Limitaciones Limitaciones Limitaciones
Sensible a diferencias de crecimiento, riesgo Depende de calidad del balance y prácticas No captura diferencias en capex, riesgo o
y contabilidad. contables. crecimiento.

[pág. 7]
Trading vs. Transaction Multiples 5
 Trading Multiples Transaction Multiples
 • Basados en precios de mercado de empresas públicas • Basados en precios pagados en fusiones y
 comparables. adquisiciones (M&A).
 • EV = Market Value of Equity + Deuda financiera. • EV = Monto pagado por el acquirer + Deuda asumida.
 • Más fáciles de obtener y actualizar en tiempo real. • Generalmente más altos que los trading multiples.
 • Incluyen prima de control por sinergias esperadas (20–
 • Más conservadores (sin prima de control).
 40% típicamente)
 • Fuentes: Bloomberg, Capital IQ, Compustat. • Fuentes: Mergermarket, bases de datos M&A.
Fuente: Luehrman (2009), HBS 9-206-039

[pág. 8]
PRINCIPALES MÚLTIPLOS DE VALORACIÓN
 Ordenados por cercanía al flujo de caja libre real
Múltiplo Uso típico Precisión Uso PE
 TEV / EBITDA Empresas maduras, buyouts 95%
 TEV / (EBITDA−Capex) Empresas capital-intensivas 86%
 TEV / Valor Libro Activos Empresas financieras, activos líquidos Alta
 TEV / EBIT Alternativa al EBITDA, considera D&A 60%
 TEV / Ventas EBITDA negativo, empresas early-stage 51%
 P/E (Precio/Utilidad) Valoración de equity, bolsa 47%

[pág. 9]
Aplicación Práctica 6
Caso: Banco Internacional Caso: Tiendas Lyon
Dato Valor Método Valor estimado
Patrimonio contable US$ 300 MM P/E y M/B US$ 2.160–2.400 MM (patrimonio)
Utilidad neta US$ 40 MM EV/EBITDA (firma) US$ 2.600 MM
P/E comparable 13x EV/EBITDA (patrimonio) US$ 2.200 MM
B/L comparable 1,8x
 Ajustes importantes
 Antes de aplicar el múltiplo, normalizar la base eliminando ítems no
 P/E B/L recurrentes: daños extraordinarios, activos inactivos, depreciaciones
 US$ 520 MM US$ 540 MM atípicas.
 Ejemplo Lyon: EPS ajustado = 1,58 | EBITDA ajustado = 209

[pág. 10]
Selección de Comparables 7
Proceso de selección jerárquica
 Dimensiones de comparabilidad
 Universo de candidatos • Modelo de negocios e industria
 (SIC codes, keywords)
 • Crecimiento esperado (g)
 Filtros objetivos amplios
 (industria, tamaño) • Riesgo y costo de capital (r)
 • Márgenes y rentabilidad (CC)
 Filtros objetivos finos
 (márgenes, geografía)
 • Estructura de capital
 Filtros subjetivos • Tamaño y mercado geográfico
 (ciclo de vida, modelo)
 Comparables
 seleccionados
 Trade-off: tamaño de muestra vs. comparabilidad
 Fuente: Luehrman (2009), HBS 9-206-039

[pág. 11]
Errores Comunes en la Práctica (PE) 8
 ! Usar el mismo histórico de la empresa ! Estacionalidad no ajustada
 En buyouts, el PE cambia las operaciones. El múltiplo propio En industrias estacionales, el EBITDA anual puede estar
 pre-adquisición no es comparable válido. distorsionado según la fecha de corte.
 ! Ignorar cambios macroeconómicos ! Ignorar leases operativos
 Tasas de interés bajas implican múltiplos más altos. Los datos Deben capitalizarse para comparar empresas en igualdad de
 históricos deben ajustarse por ciclo. condiciones (EBITDAR en retail).
 ! Aplicar a base no normalizada ! Olvidar activos no operativos
 El múltiplo debe aplicarse sobre una base que represente el El exceso de caja debe extraerse del EV; los stock options
 negocio normal (sin one-offs). deben incluirse como pasivo.
Fuente: Ivashina & Boe (2020), HBS 9-218-017

[pág. 12]
¿CUÁNDO USAR CADA MÚLTIPLO?
El tipo de empresa y su etapa determinan el múltiplo adecuado
 Startup / VC Crecimiento Expansión Madurez / PE
 Métricas operativas TEV / EBITDA TEV / EBITDA
 TEV / Ventas
 (usuarios, descargas) TEV / EBIT TEV / FCF
 Regla PE: buyout firms casi siempre usan EBITDA como métrica primaria — las empresas target son maduras y el EBITDA aproxima
 bien el cash flow.

[pág. 13]
Ventajas y Limitaciones 9
 ✓ Ventajas ✗ Limitaciones
 • Simples e intuitivos, rápidos de aplicar. • Dependen de la calidad de los comparables.
 • Usan información observable del mercado. • Basados en info contable e histórica.
 • Muy utilizados en la práctica (PE, M&A, equity • No capturan diferencias en crecimiento, riesgo o
 research). capex.
 • Benchmark rápido para contrastar con DCF. • Pueden propagar errores de mercado.
 • Capturan implícitamente r − g del mercado. • Difíciles cuando no hay comparables claros.
 Los múltiplos no reemplazan al DCF — lo complementan.

[pág. 14]
CONCLUSIONES CLAVE
 El múltiplo no es magia: es DCF comprimido Siempre triangular con DCF
1 4
 Cuando divergen, hay algo que aprender. La convergencia da
 Múltiplo = 1/(r−g). El mercado valida implícitamente r y g.
 confianza.
 TEV/Activos es el más preciso en general El proceso importa tanto como el resultado
2 5
 Especialmente para empresas financieras y con bajas Selección objetiva de comparables, normalización, y
 utilidades (Lie & Lie, 2002). documentación previenen sesgos.
 EBITDA supera a EBIT — y a ventas
3
 Depreciación y amortización distorsionan. 95% de fondos PE
 usan TEV/EBITDA.

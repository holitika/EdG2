# Finanzas II · 4 Clase_4 Riesgo-retorno

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 4: Riesgo - Retorno
 Profesor: Augusto Orellana
 Marzo 2026
Prof: Augusto Orellana Clase 4: Riesgo-Retorno 1 / 20

[pág. 2]
Roadmap
1 ROA vs. OROA
2 ROA v.ROE
3 ROE vs. OROA
4 Riesgo Financiero
5 Total Risk
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 2 / 20

[pág. 3]
Roadmap
1 ROA vs. OROA
2 ROA v.ROE
3 ROE vs. OROA
4 Riesgo Financiero
5 Total Risk
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 3 / 20

[pág. 4]
ROA = Net Income Margin × Total Asset Turnover
 Net Income Revenues(Sales)
 ROA = x
 Revenues(Sales) Assets
 (EBIT − iD) ∗ (1 − t) Revenues(Sales)
 ROA = x
 Revenues(Sales) Assets
 Margen de Utilidad Neta (Net Income/Sales)
 ▶ Pago de Intereses (iD)
 ▶ Pago de Impuesto (t)
 Turnover (Rotación) de Activos (Sales/Assets)
Relación ROA Y OROA
  
 D
 ROA = OROA − i (1 − t)
 A
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 4 / 20

[pág. 5]
Roadmap
1 ROA vs. OROA
2 ROA v.ROE
3 ROE vs. OROA
4 Riesgo Financiero
5 Total Risk
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 5 / 20

[pág. 6]
ROA v.ROE
ROA:
 Rentabilidad del resultado neto en relación al total de activos
 Si ∆ Activos → ∆ ROA ⇒ muy volátil a veces
 ROA puede cambiar mecánicamente (e.g. M & A) → No informativo
ROE:
 Rentabilidad del resultado neto en relación al capital invertido
 Importante para los accionistas
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 6 / 20

[pág. 7]
ROE: DuPont Decomposition
 Net Income Assets
 ROE = x = ROA x Equity Multiplier (1)
 Assets Equity
 Net Income Revenues(Sales) Assets
 ROE = x x (2)
 Revenues(Sales) Assets Equity
 ROE = ProfitMargin x AssetTurnover x Equity Multiplier (3)
ROE es afectado por tres cosas:
 1 Operating efficiency
 2 Asset use efficiency
 3 Financial Leverage
  
 Debt
 ROE = ROA x 1 + (4)
 Equity
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 7 / 20

[pág. 8]
ROE: DuPont Decomposition
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 8 / 20

[pág. 9]
Roadmap
1 ROA vs. OROA
2 ROA v.ROE
3 ROE vs. OROA
4 Riesgo Financiero
5 Total Risk
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 9 / 20

[pág. 10]
ROE vs. OROA
 Net Income (EBIT − iD)(1 − t)
 ROE = = (5)
 Equity E
  
 EBIT A iD
 ROE = ∗ − (1 − t) (6)
 A E E
  
 (D + E ) iD
 ROE = OROA ∗ − (1 − t) (7)
 E E
  
 D
 ROE = OROA + (OROA − i) ∗ (1 − t) (8)
 E
Nota importante:
 OROA no depende de la estructura de capital
 ROA Y ROE si dependen de la estructura de capital
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 10 / 20

[pág. 11]
Roadmap
1 ROA vs. OROA
2 ROA v.ROE
3 ROE vs. OROA
4 Riesgo Financiero
5 Total Risk
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 11 / 20

[pág. 12]
Leverage Financiero
Conceptualmente:
 Financial Risk ̸= Business Risk
Financial Risk measure:
 Degree of Financial Leverage (DFL, GFL in Spanish)
 Sensibilidad del Net Income a cambios en EBIT:
 %∆Net Income
 Leverage Financiero =
 %∆EBIT
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 12 / 20

[pág. 13]
Derivación Leverage Financiero
 Sensibilidad del Net Income a cambios en EBIT:
 %∆Net Income
 Leverage Financiero =
 %∆EBIT
Derivación:
 NI = (EBIT − iD)(1 − t) (9)
Como %∆ ≈ dX
 X , entonces:
 dNI dNI dEBIT
 = ∗ (10)
 NI dEBIT NI
 dNI (1 − T ) ∗ dEBIT dEBIT EBIT
 = = ∗ (11)
 NI (EBIT − iD)(1 − t) (EBIT − iD) EBIT
 dNI /NI EBIT
 Leverage Financiero = = (12)
 dEBIT /EBIT (EBIT − iD)
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 13 / 20

[pág. 14]
Close-up al Leverage Financiero
Cambios en EBIT y iD:
 dLF dLF
 <0; >0 (13)
 dEBIT diD
 Un mayor EBIT → Menor Financial Risk
 Un mayor iD → Mayor Financial Risk
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 14 / 20

[pág. 15]
Importancia del Capital Structure
Si D = 0:
 Financial Leverage = 1 (Low financial risk!)
 ROE = ROA ¿Cuál es la intuición?
 ¿Algún efecto en el riesgo operacional?
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 15 / 20

[pág. 16]
Roadmap
1 ROA vs. OROA
2 ROA v.ROE
3 ROE vs. OROA
4 Riesgo Financiero
5 Total Risk
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 16 / 20

[pág. 17]
Leverage Combinado
Conceptualmente:
 Total Risk = Financial Risk + Business Risk
Sensibilidad del Net Income a cambios en ventas:
 %∆Net Income
 Leverage Combinado =
 %∆Q
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 17 / 20

[pág. 18]
Derivación Leverage Combinado
 %∆Net Income
 Leverage Combinado =
 %∆Q
Derivación:
 %∆Net Income %∆EBIT
 Leverage Combinado = ∗ (14)
 %∆EBIT %∆Q
 EBIT EBIT + CF
 Leverage Combinado = ∗ (15)
 EBIT − iD EBIT
 EBIT + CF
 Leverage Combinado = (16)
 EBIT − iD
Factores que afectan el riesgo total de la firma:
 Mayores costos operacionales
 Mayor nivel de deuda
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 18 / 20

[pág. 19]
Leverage Combinado
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 19 / 20

[pág. 20]
Riesgo-Retorno
 Prof: Augusto Orellana Clase 4: Riesgo-Retorno 20 / 20

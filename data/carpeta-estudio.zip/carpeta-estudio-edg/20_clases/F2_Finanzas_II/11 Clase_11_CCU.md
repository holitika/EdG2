# Finanzas II · 11 Clase_11_CCU

Fuente: clase de Finanzas II

[pág. 1]
I A INTEG
 O R RA
 E M D
 A
M
 2024

[pág. 2]
1
 Capítulos / Capítulos
 1 2 Perfil de
 / 1 la entidad
 2 3 4 5 6 7 8 9 10 11 12
 Introducción 1 Gobierno corporativo 32 Estrategia 77 Personas 81
1.1 Carta del Presidente......................................... 3 3.1 Marco de gobernanza.................................................. 33 4.1 Horizontes de tiempo............................................... 78 5.1 Dotación de personal 2024.................................. 84
1.2 Acerca de esta Memoria Integrada......6 3.2 Directorio........................................................................................ 37 4.2 Objetivos estratégicos 2025 - 2027...... 79 5.1.1 Por género.......................................................................84
 Gestión del Directorio...................................................37 4.3 Planes de inversión...................................................... 80 5.1.2 Por nacionalidad.................................................... 85
 Matriz de conocimiento y experiencia 5.1.3 Por rango de edad.............................................. 86
 del Directorio..............................................................................41 5.1.4 Por antigüedad laboral................................ 86
 Declaración de responsabilidad................... 45 5.1.5 Personas con discapacidad.................... 87
 Remuneración al Directorio................................ 46 5.2 Formalidad laboral........................................................... 87
 Perfil de la entidad 7 Visitas a terreno..................................................................... 49 5.3 Adaptabilidad laboral................................................... 88
 3.3 Comités del Directorio................................................ 50 5.4 Equidad salarial por género................................ 88
 3.4 Ejecutivos Principales.................................................... 55 5.4.1 Política de equidad............................................ 88
2.1 Propósito y valores............................................................. 8
 3.5 Adherencia a códigos nacionales o 5.4.2 Brecha salarial......................................................... 89
 Quiénes somos.......................................................................8
2 3 45
 internacionales...................................................................... 58 5.5 Acoso laboral, sexual y violencia en el
 Modelo de Creación de Valor........................... 11
 3.6 Gestión de riesgos y control interno........ 59 trabajo................................................................................................ 89
2.2 Información histórica ................................................ 12
 3.6.1 Gestión de riesgos............................................... 59 5.6 Seguridad laboral............................................................... 90
 Historia............................................................................................... 12
 3.6.2 Control interno........................................................ 68 5.7 Permiso postnatal............................................................. 92
 Hitos 2024.....................................................................................17
 3.7 Relación con los grupos de interés y 5.8 Capacitación y beneficios....................................... 93
 Desempeño 2024............................................................ 20
 público en general................................................... 70 5.9 Política de subcontratación............................... 101
2.3 Propiedad .................................................................................. 28
 3.7.i Grupos de interés...................................70 5.10 Ambiente laboral, identificación de
 2.3.1 Situación de control...................................... 28
 3.7.ii Estudio de Doble Materialidad.. 75 capacidades y conocimientos........................ 101
 2.3.2 Cambios importantes en la
 3.7.iiiProcedimiento de Elección de 5.10.1 Gestión de desempeño............................ 101
 propiedad o control..................................................... 29
 Directores.................................................... 76 5.10.2 Evaluación ascendente.......................... 102
 2.3.3 Identificación de socios o
 3.7.iv Participación en Juntas de 5.10.3 Reclutamiento y selección................ 102
 accionistas mayoritarios....................................... 29
 Accionistas................................................ 76 5.10.4 Movilidad y promoción interna.. 102
 2.3.4 Acciones, sus características y
 derechos........................................................................................ 30 5.10.5 Gestión de talento......................................... 103
 2.3.5 Otros Valores............................................................. 31 5.10.6 Bienestar emocional en el
 trabajo................................................................................ 103
Memoria Integrada 2024 1

[pág. 3]
Capítulos / Capítulos
 1 2 Perfil de
 / 1 la entidad
 2 3 4 5 6 7 8 9 10 11 12
 7 9 11
 Comentarios de accionistas y
 Modelo de negocios 104 Gestión de proveedores 140 Sustentabilidad 147
 del Comité de Directores 178
6.1 Sector industrial............................................................. 105 7.1 Pago a proveedores.................................................... 141 9.1 Estrategia de Sustentabilidad.................. 148 Comentarios de accionistas y del
 Competencia....................................................................... 106 7.2 Evaluación de proveedores........................... 142 Gobernanza de Sustentabilidad........... 149 Comité de Directores............................................................ 178
 Marco normativo........................................................... 107 20 metas al año 2030............................................. 150
 Entidades reguladoras nacionales Equilibrio Hídrico...................................152
 o extranjeras........................................................................... 112 Vocación Circular.................................. 154
 Asociaciones y membresías.......................... 118 Desafío Climático................................. 156
6.2 Negocios.....................................................................................124 Abastecimiento Responsable.... 159
 Segmentos de operación................................. 125 Experiencia SER CCU................................ 160
 Principales asociadas y negocios Pasión por el Consumidor................... 161
 conjunto...................................................................................... 130 Disfrute Consciente............................ 163
 Comercialización, distribución Progreso País........................................... 166
 y venta.............................................................................................. 131 9.2 Métricas SASB...................................................................... 171
 Licencias y contratos .............................................. 132 9.3 Verificación independiente........................... 174
6 8 10 12
6.3 Grupos de interés.......................................................... 135
6.4 Propiedades e instalaciones........................ 135
 Cumplimiento legal Hechos relevantes
 Principales plantas productivas y Anexos 179
 y normativo 144 o esenciales 176
 centros de distribución........................................ 136
6.5 Subsidiarias, asociadas e 8.1 En relación con sus clientes......................... 145 Hechos relevantes o esenciales............................ 176 Informe financiero.................................................................... 179
 inversiones en otras sociedades............ 138 8.2 En relación con sus trabajadores............. 145 Datos generales........................................................................... 180
 Estructura 2024................................................................ 139 8.3 Medioambiental............................................................ 146 Índice GRI................................................................................................. 181
 8.4 Libre competencia..................................................... 146 Filiales (subsidiarias) y Coligadas
 (Asociadas y Negocios
 conjuntos) de Compañía
 Cervecerías Unidas S.A...................................................... 185
Memoria Integrada 2024 2

[pág. 4]
Capítulos / 
 / 1 Introducción 
 1 2 Perfil de la entidad
 2 3 4 5 6 7 8 9 10 11 12
1.1 Carta del Presidente
Estimados Accionistas:
Es para mí un agrado compartir con ustedes la Memoria Anual Integrada y los Estados Financieros
Consolidados de Compañía Cervecerías Unidas S.A. y de sus subsidiarias (CCU) correspondientes
al ejercicio 2024.
Este documento, la primera memoria integrada de CCU, es en sí mismo un hito del período. Si bien desde
2022 fusionamos los reportes financieros y de sustentabilidad de la Compañía, ahora incorporamos
cambios que nos permiten abarcar todos los aspectos que comprende un informe integrado. Francisco Pérez
 Mackenna
Con respecto a la gestión 2024, CCU superó al término del ejercicio el resultado obtenido en 2023,
 Presidente del
demostrando una vez más su gran capacidad para navegar con éxito en un entorno complejo. Directorio
Por una parte, enfrentamos una fuerte caída de las industrias de bebestibles en Argentina, lo
que afectó considerablemente la escala de nuestra operación en ese país. Por otra, en Chile
afrontamos un débil crecimiento económico y una fuerte devaluación del peso.
Lamentablemente, nuestro país ha sufrido al menos desde fines de 2012 un bajo dinamismo,
reflejado en que el Banco Central haya estimado recientemente que el PIB tendencial se mantendrá
por debajo del 2% entre 2025 y 2034. Estrechamente relacionado con ello, la productividad se
ha deteriorado desde 2006 y hoy se ubica apenas un 26,5% por encima de la que teníamos en
1960. De esta forma, se ve cada vez más lejano el anhelo de convertirnos en un país desarrollado,
objetivo sustentado en el libre mercado, la apertura al comercio global y la fortaleza de las
instituciones, claves para competir a nivel global. Si queremos retomar esa senda, Chile debería
asumir el crecimiento como una política de Estado, lo que implica, entre otras medidas, priorizar
el incremento del capital humano y establecer los incentivos correctos para recuperar la inversión.
Memoria Integrada 2024 / 1.1 Carta del Presidente 3

[pág. 5]
Capítulos / 
 / 1 Introducción 
 1 2 Perfil de la entidad
 2 3 4 5 6 7 8 9 10 11 12
En CCU, tenemos la firme convicción de que contamos con un gran equipo de personas, que la distribución de snacks. Con esta asociación, Paraguay pasó a ser el segundo país donde CCU
trabaja con dedicación y excelencia, y que ha sido capaz de sortear estas y otras dificultades integra la licencia de PepsiCo a su portafolio de marcas. Ambos negocios, fortalecen nuestra
para construir una empresa fuerte y vigorosa, que se alista a cumplir 175 años encarando con posición como un operador regional multicategoría de bebestibles.
energía y rigor su futuro. Una compañía que se proyecta gracias a una visión de largo plazo,
cimentada en una estrategia de negocios que cuenta con tres Pilares Estratégicos: Rentabilidad, De esta manera, los volúmenes consolidados de CCU aumentaron un 1,9% durante el período. Sin
Crecimiento y Sustentabilidad. embargo, al excluir el efecto de la incorporación inorgánica de los volúmenes de las operaciones
 mencionadas anteriormente, los volúmenes consolidados disminuyeron un 5,2%, principalmente
En cuanto al pilar Rentabilidad, en 2024 alcanzamos un EBITDA consolidado de CLP 415.936 millones, por la contracción experimentada en Argentina. En el Segmento de operación Chile, logramos
con un aumento del 9,6%, y una Utilidad Neta consolidada que llegó a los CLP 160.944 millones, preservar la escala de negocios, gracias a altos niveles de preferencia de marca y una robusta
expandiéndose un 52,3%. Estas cifras incluyen una ganancia no recurrente por la venta de una porción ejecución en los puntos venta, en tanto que el Segmento de operación Vinos expandió sus
de terreno en Chile, sin cuyo efecto el EBITDA habría crecido un 2,1% y la Utilidad Neta consolidada volúmenes un 1,0%, impulsado por exportaciones.
un 32,5%. Este desempeño se sustenta en el alza del EBITDA de 2,4% experimentada en el Segmento
de operación Chile, y el aumento de 30,0% en el Segmento de operación Vinos, los que compensaron En cuanto a nuestros negocios conjuntos, en Colombia, donde comercializamos cerveza y malta
con creces la contracción de 8,3% en el Segmento de operación Negocios Internacionales, explicada junto con Postobón, alcanzamos un alza anual de 7,8% en volumen, retomando el crecimiento
principalmente por lo sucedido con la industria en Argentina. en dicho país, y consiguiendo un EBITDA positivo.
Cabe destacar que durante el ejercicio 2024, nuestro desempeño tuvo una tendencia ascendente, Con respecto al pilar Sustentabilidad, esta memoria integrada muestra los avances bajo nuestra
con una recuperación importante en el segundo semestre y especialmente en el último trimestre. Estrategia “Juntos por un Mejor Vivir”, presentada en 2023. Esta cuenta con dos ejes, Nuestro
Esto fue impulsado por iniciativas de gestión de ingresos y eficiencias en todos nuestros segmentos Planeta y Nuestras Personas; además de ocho agendas de trabajo y 20 metas al año 2030. Más
de operación, enmarcadas en el Plan regional “HérCCUles”, que iniciamos en 2022 y culminamos adelante en este documento podrán encontrar el detalle de los resultados en esta materia, por
en 2024. El objetivo de dicho plan fue precisamente recuperar resultados financieros reales, lo lo que mencionaré aquí sólo los avances más relevantes.
que permitió positivos crecimientos en EBITDA y en Utilidad neta, resultando la expansión de
esta última muy por sobre la inflación de ese periodo, en un contexto externo desfavorable por Dentro del eje Nuestro Planeta, CCU inauguró en mayo de 2024 la primera planta de reciclaje
devaluación de las monedas y bajo crecimiento económico en la región. de botellas PET de Chile, la que llamamos “CirCCUlar”. Con una inversión de USD 42 millones,
 esta moderna instalación tiene la capacidad de procesar anualmente 18.000 toneladas de PET,
En cuanto al pilar Crecimiento, en 2024 fortalecimos la presencia regional de CCU al consolidar equivalentes a 870 millones de botellas. A fines de 2024, ya elaboramos las primeras botellas que
Aguas de Origen S.A., un negocio conjunto de aguas y bebidas no alcohólicas con Danone en contienen plástico reciclado recolectado en el país, contribuyendo a la disminución de este tipo
Argentina, que seguirá generando sinergias a nuestra operación en dicho país. Adicionalmente, de desechos, un primer paso hacia las desafiantes metas de incorporación a nuestros envases
potenciamos nuestra presencia en Paraguay a través de una asociación con Grupo Vierci, que de resina reciclada en Chile.
abarca la licencia de PepsiCo para la producción y distribución de bebidas, así como también
Memoria Integrada 2024 / 1.1 Carta del Presidente 4

[pág. 6]
Capítulos / 
 / 1 Introducción 
 1 2 Perfil de la entidad
 2 3 4 5 6 7 8 9 10 11 12
Respecto del eje Nuestras Personas, me enorgullece comunicar la primera certificación de CCU Estimados accionistas, agradezco la confianza depositada por ustedes en el Directorio que
como “Top Employer” por parte del Top Employers Institute, un logro que refuerza el compromiso me corresponde presidir, el que tendrá el honor de conducir la empresa este 2025, cuando
de CCU con sus trabajadores. En línea con lo anterior, alcanzamos altos niveles en nuestra celebremos los 175 años de CCU. Nuestra historia ha sido también la de nuestro país, pues
encuesta anual de clima organizacional, logrando un 86% de satisfacción laboral, superando comenzó solo 32 años después de la firma de la Independencia, en 1850. Desde entonces, hemos
los resultados del 2023, y CCU obtuvo nuevamente el primer lugar en el sector de bebidas en acompañado a millones de personas en cada etapa de sus vidas, reuniendo a sus familias en
atracción de talento en Chile en el ranking Merco Talento. sus mejores momentos. Nuestra trayectoria ha estado marcada por el dinamismo, la innovación
 y la capacidad de adaptarnos a las transformaciones de Chile y de los países donde hemos
Todos los avances que conocemos hoy han sido complementados por el desarrollo de nuestro plan ido extendiendo nuestra presencia. Siempre con una mirada al futuro, comprometidos con el
de inversiones por un monto total de CLP 160.086 millones, que nos permite seguir avanzando progreso y contribuyendo con pasión a un mejor vivir.
armónicamente.
 Agradezco especialmente a todos los trabajadores de CCU, a los de hoy y a los del ayer, por el
Seguiremos enfrentando un ambiente de negocios desafiante y volátil, con importantes presiones esfuerzo y la dedicación que han puesto en la construcción de esta gran compañía, cimentada
de costos y gastos con origen en los mercados y en la regulación, un escenario que encaramos con en los principios de Excelencia, Integridad, Entrega y Empoderamiento.
la confianza de contar con un equipo de excelencia y con un sólido Plan Estratégico 2025 - 2027,
que reafirma nuestros pilares. En Rentabilidad, contamos con una serie de iniciativas para mejorar Los invito a disfrutar este año de celebración, a compartir juntos nuestra más que centenaria
nuestros márgenes, tanto en gestión de ingresos como en eficiencias de costos y gastos, apoyadas historia y a seguir trabajando unidos por el desarrollo de Chile.
en la implementación de nuevas herramientas tecnológicas; en Crecimiento, nuestro foco estará
en expandir la escala de negocios y seguir fortaleciendo nuestra presencia regional y preferencia de
marca; y en Sustentabilidad, seguiremos trabajando en nuestra Estrategia “Juntos por un Mejor
Vivir” y sus dos ejes.
 Francisco Pérez
 Mackenna
 Presidente del Directorio
 Compañía Cervecerías Unidas S.A.
 Marzo 2025
Memoria Integrada 2024 / 1.1 Carta del Presidente 5

[pág. 7]
Capítulos / 
 / 1 Introducción 
 1 2 Perfil de la entidad
 2 3 4 5 6 7 8 9 10 11 12
1.2 Acerca de esta Memoria Integrada
El presente documento es la primera Memoria Integrada de CCU. Si bien a partir del año 2022 ya
reportamos en un solo documento los aspectos financieros y de sustentabilidad de la Compañía, en
el año 2024 incorporamos nuestro Modelo de Creación de Valor, de acuerdo con los lineamientos
internacionales de un reporte integrado. A su vez, este documento es el primero en contar con un
proceso de verificación de los contenidos e indicadores incluidos, realizado por entidades externas
independientes (Ver sección “9.3 Verificación independiente”). Su contenido está elaborado en
conformidad a los requerimientos de la Norma de Carácter General (NCG) N° 461 de la Comisión para
el Mercado Financiero (CMF), y siguiendo las directrices y recomendaciones del Integrated Reporting
Framework <IR>. A su vez, considera los indicadores del Sustainability Accounting Standards Board
(SASB) del sector bebidas alcohólicas y no alcohólicas, de acuerdo con la clasificación de industria
de la Sustainable Industry Classification System (SICS), estándares de Global Reporting Initiative (GRI), e
indicadores propios de la Compañía.
Esta Memoria Integrada considera la información del período comprendido entre el 1 de enero de
2024 y el 31 de diciembre de 2024 correspondiente a la gestión de Compañía Cervecerías Unidas S.A.
y sus subsidiarias (“CCU” o la “Compañía”).
Memoria Integrada 2024 / 1.2 Acerca de esta Memoria Integrada 6

[pág. 8]
2
 Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
 2.1 Propósito y valores 8
 Quiénes somos 8
 Modelo de Creación de Valor 11
 2.2 Información histórica 12
 Historia 12
 Hitos 2024 14
 Desempeño 2024 17
 2.3 Propiedad 25
 2.3.1 Situación de control 25
 2.3.2 Cambios importantes en la
 propiedad o control 25
 Perfil de
 2.3.3 Identificación de socios o
 accionistas mayoritarios 26
 2.3.4 Acciones, sus características
 la entidad
 y derechos 27
 2.3.5 Otros Valores 27
Memoria Integrada 2024 7

[pág. 9]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
2.1 Propósito y valores
Quiénes somos
CCU es una empresa multicategoría de bebestibles, con operaciones en Chile, Argentina, Bolivia, En Colombia, operamos en la categoría de cervezas y bebidas a base de malta, a través del
Colombia, Paraguay y Uruguay. negocio conjunto entre CCU y Postobón S.A. y sus relacionadas (Grupo Postobón).
En Chile, CCU es uno de los principales actores en cada una de las categorías en las que participa, Nuestras operaciones se dividen en los siguientes tres Segmentos de operación: (i) Segmento de
incluyendo cervezas, bebidas gaseosas, aguas minerales y envasadas, néctares, vino y pisco, operación Chile, que incluye cervezas, bebidas no alcohólicas, licores, sidra y las Unidades Estratégicas
entre otros. de Servicio (UES) en el mercado chileno; (ii) Segmento de operación Negocios Internacionales, que
 incluye cervezas, sidra, bebidas no alcohólicas y licores, entre otras categorías, en Argentina, Uruguay,
A nivel regional, es la segunda mayor cervecera en Argentina, donde también opera en las Paraguay y Bolivia; y (iii) Segmento de operación Vinos, que incluye vinos y espumantes en el mercado
industrias de sidra, licores y vinos. Adicionalmente, operamos en asociación con Danone en la doméstico, en Chile y Argentina, y exportaciones a más de 90 países. Los ingresos y gastos de las
categoría de aguas minerales y aguas saborizadas. En Bolivia, estamos presentes en las categorías Unidades de Apoyo Corporativo (UAC) se presentan por separado en Otros. Las UAC, al igual que las
de cervezas, aguas y bebidas gaseosas, no alcohólicas y a base de malta. En Uruguay y Paraguay, UES, proporcionan servicios compartidos dentro de la Compañía a fin de captar sinergias operacionales.
operamos en las categorías de cervezas, aguas minerales y embotelladas, bebidas gaseosas,
vinos y néctares. A nivel de gestión operacional, CCU reporta sus resultados en conformidad a los referidos Segmentos
 de operación, esencialmente definidos con respecto a sus ingresos por áreas geográficas de
 actividad comercial.
Memoria Integrada 2024 / 2.1 Propósito y valores 8

[pág. 10]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
En línea con el Propósito de la Compañía, tenemos el compromiso de fomentar el respeto Qué nos inspira
por los Derechos Humanos de las personas, a quienes reconocemos como uno de los ejes de
nuestra identidad corporativa, SER CCU. Conforme con nuestros Principios corporativos estamos SER CCU nos inspira a trascender los legítimos intereses de quienes aquí trabajamos, con un
convencidos que el desempeño de nuestra Compañía y el logro de nuestros objetivos estratégicos propósito y una promesa concretos, que buscan construir un mejor vivir para todos aquellos
se enriquece con la pluralidad de enfoques. Somos una Compañía con tradición histórica desde con quienes nos relacionamos.
1850 y, a lo largo de esta trayectoria, procuramos contribuir a la generación de experiencias
valiosas y un mejor vivir para todos aquellos con quienes nos relacionamos a diario: trabajadores, P1 Nuestro Propósito P2 Nuestra Promesa
consumidores, clientes, proveedores, accionistas, comunidades locales y sociedad en general.
En nuestros esfuerzos por cautelar los Derechos Humanos en las prácticas laborales, somos Nos apasiona crear experiencias para Con una amplia gama de marcas de bebestibles
conscientes de que todas las personas deben ser tratadas con dignidad, igualdad y respeto. compartir juntos un mejor vivir. y experiencias, mejoramos y acompañamos
 distintos momentos de la vida, guiados por
SER
 nuestros principios, en beneficio de las personas
 con las que nos relacionamos y el cuidado del
 medio ambiente.
 Cómo Somos
 QUÉ NOS
 INSPIRA P1 P2 SER CCU es vivir de acuerdo con nuestros principios y proyectar nuestra personalidad en todo
 momento.
 Nuestro Nuestra
 Propósito Promesa Nuestros Nuestra
 P3 Principios
 P4 Personalidad
 CÓMO CÓMO LO PARA
 SOMOS P3 HACEMOS P5 P6 QUIÉN LO P8 Excelencia: Somos apasionados por la calidad Orgullo: Sentimos legítimo orgullo de lo que
 HACEMOS
 y el trabajo bien hecho. somos y de nuestra historia.
 Entrega: Procuramos el bien de los demás y Empatía: Nos relacionamos y colaboramos con
 Nuestros
 Nuestros Pilares Nuestros Nuestras de nuestro entorno, en armonía con nuestros nuestras personas desde el afecto y la confianza.
 Principios estratégicos Procesos Personas legítimos intereses. Superación: Nos gusta plantearnos objetivos
 Integridad: Cumplimos las normas que ambiciosos, superarlos y adaptarnos al mercado.
 P4 P7 P9 nos regulan, siempre inspirados en actuar Pasión: Somos entusiastas y nos gusta
 correctamente. transmitirlo.
 Nuestra Nuestra Nuestro Empoderamiento: Nos mueve una actitud
 Personalidad Plataforma de negocios Planeta emprendedora, innovadora y proactiva.
Memoria Integrada 2024 / 2.1 Propósito y valores 9

[pág. 11]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
Cómo lo Hacemos Para Quién lo Hacemos
SER CCU es hacer las cosas basados en Pilares Estratégicos sólidos, desde una plataforma de negocios SER CCU es ser conscientes del impacto que producimos con quienes nos relacionamos a través de
robusta y una ejecución de excelencia, a través de procesos a lo largo de toda la organización. las experiencias que viven con nosotros, poniendo el bien de las Personas y el de Nuestro Planeta
 como eje central de nuestras decisiones.
 P5 Nuestros P6 Nuestros
 Pilares Estratégicos Procesos P8 Nuestras Personas
 Rentabilidad: Maximizar el valor económico La organización de CCU, desde sus procesos, Vivimos en un mundo plenamente integrado, en donde la acción de cada uno impacta directa e individualmente
 de los negocios que operamos. Esto se logra al mantiene el equilibrio necesario entre una a todas las personas con las que nos relacionamos. En CCU nos inspira esa interacción, por lo que buscamos
 optimizar el retorno final sobre la inversión, lo que es organización formal y una organización informal. constantemente el mejor vivir de cada una de esas personas y lo hacemos a través de compromisos y acciones
 consecuencia de mejores márgenes y el uso eficiente Mientras la primera nos permite tener claridad de concretas que realizamos cada día.
 de los recursos. que lo que hacemos garantiza una gestión ordenada,
 estructurada y replicable, la segunda incorpora la Trabajadores l Inversionistas l Proveedores l Clientes l Consumidores l Comunidades l
 Crecimiento: Incrementar el tamaño y el alcance necesaria espontaneidad que surge de los liderazgos Sociedad en general
 de nuestra operación. Esto se logra mediante una y las relaciones interpersonales dentro de la
 mayor participación de mercado, atendiendo nuevas Compañía. El vínculo con “Nuestras Personas” se gestiona mediante nuestra Estrategia de Sustentabilidad “Juntos por un
 necesidades, nuevos canales, nuevas ocasiones de Mejor Vivir 2030”, a través de las siguientes cuatro agendas de trabajo:
 consumo y entrando a nuevas regiones, negocios y
 categorías. Experiencia SER CCU Disfrute Consciente
 Procesos
 Directivos Pasión por el Consumidor Progreso País
 Sustentabilidad: Asegurar el valor de la Compañía
 a largo plazo. Esto se logra teniendo en consideración
 Organización Organización
 el bienestar actual y futuro de todas las personas Informal Formal
 con las que interactuamos, el desarrollo de nuestras
 marcas y el cuidado del medio ambiente.
 P9 Nuestro Planeta
 Procesos
 Operacionales
 Reconocemos la importancia de hacer negocios con una Visión Medioambiental de largo plazo, que implica
 acciones de corto plazo para así lograr las metas, y promovemos una cultura interna orientada al cuidado del
 medio ambiente.
 Nuestra El vínculo con “Nuestro Planeta” se gestiona mediante nuestra Estrategia de Sustentabilidad “Juntos por un Mejor
 P7 Plataforma de Negocios
 Vivir 2030”, la cual integra nuestra “Visión Medioambiental 2030”, a través de las siguientes cuatro agendas de trabajo:
 Equilibrio Hídrico Desafío Climático
 Nuestro negocio se sustenta en operar, con foco y sinergia, una multicategoría de marcas de bebestibles de
 valor, con un marketing responsable, tanto a nivel regional como de exportación. Vocación Circular Abastecimiento Responsable
Memoria Integrada 2024 / 2.1 Propósito y valores 10

[pág. 12]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
Modelo de Creación de Valor en 9P
 Gobierno Corporativo
 RECURSOS RESULTADOS
 ¿QUÉ NOS INSPIRA? ¿CÓMO SOMOS?
 Financieros Financieros
 • CLP 3.989.717 millones en Activos totales P1 Propósito P3 Principios P4 Personalidad • CLP 160.944 millones de Utilidad Neta
 • CLP 2.317.202 millones en Pasivos totales • CLP 74.847 millones de dividendos pagados
 Nos apasiona crear experiencias para compartir juntos un mejor Excelencia Orgullo
 • CLP 1.672.515 millones de Patrimonio neto vivir. • USD 2.1 mil millones de Capitalización bursátil
 Físicos P2 Promesa Integridad Empatía Físicos
 • 36 plantas productivas(1) • 37,9 millones de HL vendidos(1)
 Con una amplia gama de marcas de bebestibles y experiencias,
 • 54 centros de distribución Entrega Superación • 29,1% de participación de mercado total
 mejoramos y acompañamos distintos momentos de la vida,
 • 1 Planta de Reciclaje (CirCCUlar) • 30,7% material reciclado utilizado en envases y embalajes(2)
 guiados por nuestros principios, en beneficio de las personas
 Empoderamiento Pasión
 Intelectuales con las que nos relacionamos y el cuidado del medio ambiente. Intelectuales
 • 71,9% del volumen consolidado corresponde a marcas • Valor de marca consistente con nuestra participación
 ¿CÓMO LO HACEMOS?
 propietarias de mercado
 • 28,1% del volumen consolidado corresponde a P5 Pilares Estratégicos P6 Procesos P7 Plataforma de negocios • 22 iniciativas anuales aceleradoras de nuestras
 marcas de licencias y contratos para la producción, marcas para la estrategia de sustentabilidad
 comercialización y/o distribución Rentabilidad Procesos Directivos Escala regional y exportación • 4 Plataformas de inteligencia artificial (Delfos, Olympia,
 • 3 Centros de Excelencia (Comercial, Industrial, Zeus y Atenea)
 Crecimiento Procesos Operacionales Foco y sinergia
 Planificación y Logística)
 Humanos Sustentabilidad Informal Organización Formal Multicategoría en bebestibles con Humanos
 • 10.705 Trabajadores marcas de valor • 86% Indicador Global de Clima (IGC) y 79% Indicador Global
 • 18% mujeres del total de trabajadores de Liderazgo (IGL)
 CADENA DE VALOR
 • Trabajadores de 22 nacionalidades • 86% de los trabajadores fueron capacitados
 RECICLAJE Y
 ABASTECIMIENTO PRODUCCIÓN LOGÍSTICA MARKETING VENTAS DISTRIBUCIÓN CONSUMO VALORIZACIÓN
 • 0,76% Tasa de accidentabilidad
 DE RESIDUOS
 Sociales y Relacionales Sociales y Relacionales
 • 6.457 proveedores nacionales y 3.467 internacionales ¿PARA QUIÉN LO HACEMOS? • Encuesta de Satisfacción proveedores 87%
 • 395.293 puntos de venta (Clientes) • Encuesta de Satisfacción clientes 81,6% en Chile y
 P8 Personas(4) P9 Planeta
 • 52 asociaciones y membresías 78,7% en Argentina
 • Planes comunitarios en territorios estratégicos
 Experiencia SER CCU Equilibrio Hídrico
 Naturales Naturales
 Principales materias primas naturales: Pasión por el Consumidor Vocación Circular
 • 48,6% Reducción consumo de agua industrial(3)
 • Cebada, lúpulo y azúcar, entre otras Desafío Climático • 99,4% Valorización de residuos industriales sólidos
 Disfrute Consciente
 • Agua • 64,1% Reducción de emisiones GEI en alcances 1 y 2(3)
 • Energía (eléctrica y térmica) Progreso País Abastecimiento Responsable
Todas las cifras se refieren a CCU Consolidado al 31 de diciembre 2024, a menos que se indique lo contrario.
(1) Considera Asociadas y Negocios conjuntos; (2) Considera solo Chile; (3) En base a valores 2010; (4) Relacionadas a nuestros grupos de interés (Trabajadores, Inversionistas, Proveedores, Clientes, Consumidores, Comunidades y Sociedad en general).
Memoria Integrada 2024 / 2.1 Propósito y valores 11

[pág. 13]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
2.2 Información histórica 1959 CCU empieza a producir bajo licencia Pepsi-Cola.
 1960 La Compañía adquiere la marca de aguas Cachantun y sus instalaciones en Coinco.
Historia
 1979 Se modifica la razón social de la Compañía por la de “Compañía Cervecerías Unidas S.A.”
1850 Nace en Valparaíso la primera fábrica de cervezas en Chile, fundada por don Joaquín Plagemann.
 1986 El grupo Luksic, a través de Quiñenco S.A., y el grupo alemán Schörghuber, a través de Paulaner-
1851 El inmigrante alemán don Carlos Anwandter establece Compañía de Cerveza de Valdivia. Salvator A.G., forman en partes iguales la empresa Inversiones y Rentas S.A., la cual adquiere el 64,3%
 de Compañía Cervecerías Unidas S.A. (CCU S.A.).
1889 La primera cervecera de Valparaíso se fusiona con Fábrica de Cerveza de Limache, dando
origen a Fábrica Nacional de Cerveza. 1990 Mediante un convenio con Paulaner Brauerei A.G., CCU comienza a producir y distribuir la
 cervezas alemana Paulaner en Chile. // CCU expande su negocio de aguas minerales con la adquisición
1901 Fábrica Nacional de Cerveza adquiere Fábrica de Cerveza y Hielo de Gubler y Cousiño. de Agua Mineral Porvenir S.A.I.
1902 Fábrica Nacional de Cerveza se constituye en sociedad anónima con el nombre de Compañía 1992 CCU es la segunda empresa chilena y tercera latinoamericana en colocar American Depositary
Cervecerías Unidas. Receipts (ADRs) en el mercado estadounidense.
1916 CCU se convierte en el principal productor de cervezas en Chile luego de la incorporación 1994 CCU ingresa al negocio del vino a través de la adquisición de Viña San Pedro S.A., hoy Viña San
de las fábricas Ebner de Santiago, Anwandter de Valdivia y Compañía Cervecera La Calera. // CCU Pedro Tarapacá S.A. (“VSPT” o “VSPT Wine Group”). // CCU entra al negocio cervecero en Croacia, al
ingresa al negocio de las bebidas gaseosas con Bilz, luego de la incorporación de Ebner, empresa adquirir el 26,9% y, más tarde, el control de Karlovacka Pivovara d.d., que vende a Heineken el año 2003.
que introdujo Bilz al mercado nacional en 1905.
 1995 CCU ingresa al mercado cervecero argentino a través de la adquisición de dos cervecerías
 1924 CCU adquiere las cerveceras de Concepción y Talca. regionales: Compañía Industrial Cervecera S.A. de Salta y Cervecería Santa Fe S.A. // CCU firma
 acuerdos con Anheuser-Busch para producir, vender y distribuir la marca Budweiser en Argentina.
 1927 CCU adquiere la cervecera de Mitrovich Hermanos en Antofagasta.
 1997 CCU completa exitosamente su segunda colocación de acciones en el exterior a través de ADRs, en
 1933 CCU adquiere la cervecera de la sucesión de Jorge Aubel en Osorno. conjunto con una oferta para los accionistas locales, por un total de aproximadamente USD 155 millones.
 1942 Se lanza al mercado la cerveza Escudo. 1998 Compañía Industrial Cervecera S.A. adquiere las marcas y activos de Cervecería Córdoba S.A.
 1950 CCU adquiere la cervecera de la sociedad Floto 1999 CCU adquiere de Buenos Aires Embotelladoras S.A. e Inversiones Punch Limitada, el 45%
 y Cía. en La Serena. restante de las acciones de Embotelladoras Chilenas Unidas S.A., su filial productora de bebidas no
 alcohólicas, pasando CCU S.A. a ser titular, directa e indirectamente, del 100% del capital accionario
 de aquella.
Memoria Integrada 2024 / 2.2 Información histórica 12

[pág. 14]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
2000 CCU adquiere el 50% de Cervecería Austral S.A. // Viña San Pedro S.A. adquiere Finca La 2009 Nestlé Waters Chile S.A. compra un 29,9% de las acciones de Aguas CCU-Nestlé Chile S.A. //
Celia S.A. en Mendoza, Argentina. CCU coloca en el mercado chileno bonos de la serie H por 2 millones de Unidades de Fomento (UF),
 a 21 años y a una tasa de colocación final de 4,3% anual.
2001 Anheuser-Busch alcanza el 20% de participación en CCU S.A. y vende su posición el año 2004.
 2010 CCU ingresa al negocio de la sidra en Argentina al adquirir el control de las empresas Sáenz
2002 CCU adquiere el 50% de Compañía Cervecera Kunstmann S.A. (hoy Cervecería Kunstmann S.A.). Briones y Cía. S.A.I.C. y Sidra La Victoria S.A. // La filial Inversiones Invex CCU Ltda. adquiere el 4,04%
 de Compañía Cervecerías Unidas Argentina S.A. de propiedad de Anheuser-Busch Investment S.L.
2003 Heineken N.V. ingresa a la propiedad de CCU S.A. a través de la adquisición de Finance Holding Con ello, CCU alcanzó el 100% de la propiedad de Compañía Cervecerías Unidas Argentina S.A.
International, dueña del 50% de Inversiones y Rentas S.A., accionista controlador de CCU S.A. // CCU
comienza a producir y comercializar cervezas Heineken en Chile y Argentina. // CCU ingresa al negocio 2011 Compañía Pisquera de Chile S.A. inicia la distribución de los productos Pernod Ricard en Chile.
del pisco en Chile con la marca Ruta Norte.
 2012 CCU adquiere las sociedades uruguayas Milotur S.A., Marzurel S.A. y Coralina S.A., entrando a
2004 CCU ingresa al negocio de los alimentos listos para su consumo con la adquisición de las Uruguay con la producción y comercialización de aguas minerales y bebidas gaseosas bajo las marcas
marcas y activos de Calaf S.A.I.C. y Francisca Calaf S.A. Esta transacción la realiza la filial Embotelladoras Nativa y Nix, respectivamente. // CCU, a través de Aguas CCU-Nestlé Chile S.A., adquiere el 51% de
Chilenas Unidas S.A. en conjunto con Industria Nacional de Alimentos S.A., filial de Quiñenco S.A. Manantial S.A., negocio de entrega a domicilio de aguas purificadas en botellones mediante el uso de
 dispensadores (Home & Office Delivery, HOD).
2005 CCU se asocia con Cooperativa Agrícola Control Pisquero de Elqui y Limarí Ltda. (Control) para
formar Compañía Pisquera de Chile S.A. 2013 El 3 de abril asume Andrónico Luksic Craig como nuevo Presidente del Directorio, tras la
 muerte de su hermano, Guillermo Luksic Craig. // CCU S.A. hace un aumento de capital, mediante la
2006 Embotelladoras Chilenas Unidas S.A., a través de su coligada Promarca S.A., pasa a ser dueña emisión de 51.000.000 nuevas acciones ordinarias, colocadas tanto en el mercado nacional como a
del 50% de las marcas Watt’s, incluyendo Watt’s Ice Frut, Yogu Yogu y Shake a Shake. través de ADRs en EE.UU. y otros mercados fuera de Chile. // CCU ingresa a Paraguay en el negocio de
 la producción, comercialización y distribución de bebidas tanto alcohólicas como no alcohólicas, bajo
2007 CCU y Nestlé Chile S.A. suscriben un acuerdo de asociación para el desarrollo del negocio de diversas marcas, propias, licenciadas e importadas, mediante la adquisición del 50,005% de Bebidas
aguas minerales y envasadas en Chile, a través de la sociedad Aguas CCU-Nestlé Chile S.A., la cual del Paraguay S.A. y el 49,96% de Distribuidora del Paraguay S.A., ambas sociedades paraguayas. // A
también es titular de una licencia exclusiva para la marca Nestlé Pure Life en Chile. // Foods Compañía través de su filial CCU Inversiones S.A., en conjunto con Inversiones PFI Chile Limitada, se constituye
de Alimentos CCU S.A. compra la marca de cereales Natur. Bebidas CCU-PepsiCo SpA., profundizando CCU su asociación con PepsiCo Inc., y extendiendo la
 duración del contrato de licencia otorgado a su filial Embotelladoras Chilenas Unidas S.A. a largo plazo.
2008 La filial argentina Compañía Industrial Cervecera S.A. adquiere una planta en Luján y las marcas
Bieckert, Palermo e Imperial. // CCU, junto con Viña San Pedro S.A. suscriben con Compañía Chilena 2014 CCU ingresa al mercado boliviano con la producción y comercialización multicategoría de bebidas
de Fósforos S.A. y sus filiales Terciados y Elaboración de Maderas S.A. y Viña Tarapacá EX Zavala S.A. alcohólicas y no alcohólicas a través de una asociación con el Grupo Monasterio, adquiriendo el 34%
un acuerdo de fusión mediante la absorción de Viña Tarapacá EX Zavala S.A. por Viña San Pedro S.A., de Bebidas Bolivianas BBO S.A., con la opción de adquirir una participación adicional que le permita
pasando esta última a denominarse Viña San Pedro Tarapacá S.A. // Foods Compañía de Alimentos ser propietaria del 51% de las acciones de dicha sociedad. // A través de su filial Compañía Industrial
CCU S.A. adquiere el 50% de la sociedad Alimentos Nutrabien S.A. Cervecera S.A., CCU alcanza acuerdos con Cervecería Modelo S. de R.L. de C.V. y Anheuser-Busch LLC
Memoria Integrada 2024 / 2.2 Información histórica 13

[pág. 15]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
para el término del contrato de exclusividad de importación y distribución de las cervezas Corona y Argentina de la marca Budweiser, suscrito entre Compañía Cervecerías Unidas Argentina S.A. y Anheuser-
Negra Modelo en Argentina, y también el término de la licencia para la fabricación y distribución de Busch, Incorporated (hoy Anheuser-Busch LLC, subsidiaria de Anheuser-Busch InBev S.A./N.V.), sujeto
la cerveza Budweiser en Uruguay. // CCU, junto con su filial chilena CCU Inversiones II Ltda., suscribe a la aprobación previa de la Comisión Nacional de Defensa de la Competencia (CNDC) y del Secretario
con Grupo Postobón una serie de contratos a través de los cuales se constituye Central Cervecera de de Comercio del Ministerio de Producción de la Argentina (SECOM), autoridad de aplicación de la ley de
Colombia S.A.S., negocio conjunto en partes iguales para la elaboración, comercialización y distribución defensa de la competencia argentina (la “Transacción”). // Compañía Pisquera de Chile S.A. incorpora a
de cervezas y bebidas no alcohólicas en base a malta en Colombia. su portfolio la marca peruana BarSol mediante la adquisición del 40% de Americas Distilling Investments
 LLC, basada en EE.UU., propietaria de la marca y activos productivos en Perú. // CCU, a través de su filial
2015 CCU, a través de su filial Embotelladoras Chilenas Unidas S.A., entra al negocio de bebidas CCU Inversiones ll Ltda., adquiere el 50% de las acciones de una sociedad por acciones constituida en
instantáneas en polvo en asociación con Empresas Carozzi S.A., creando Bebidas Carozzi-CCU SpA, una Colombia denominada Zona Franca Central Cervecera S.A.S., en la cual CCU y Grupo Postobón participan
operación conjunta en partes iguales. A su vez, Foods Compañía de Alimentos CCU S.A. vende a Empresas como únicos accionistas en partes iguales, y cuyo objeto principal es actuar como usuario industrial de
Carozzi S.A. los activos y equipos relacionados al negocio de elaboración de productos de las marcas Calaf una o varias zonas francas, y operar la planta cervecera que se encontraba en etapa de construcción.
y Natur. // Gracias a una alianza con Molson Coors Brewing Company, CCU incorpora las marcas Coors
Light, Coors 1873 y Blue Moon al mercado chileno. 2018 CCU, a través de su filial CCU Inversiones S.A., aumenta su participación en Viña San Pedro Tarapacá S.A. de
 67,22% a 83,01% a través de una oferta pública de adquisición de acciones que concluyó a fines de enero de 2018.
2016 CCU y Grupo Postobón, a través de su negocio conjunto Central Cervecera de Colombia S.A.S., // El 2 de mayo de 2018, en virtud de la aprobación de la autoridad de aplicación de la ley de defensa de
comienzan la construcción de una planta de producción de cervezas y maltas, con una capacidad anual la competencia argentina (CNDC y SECOM), se produce el cierre de la Transacción entre Anheuser-Busch
de 3 millones de hectolitros. Asimismo, adquieren Artesana Beer Company S.A., relacionada a la marca InBev S.A./N.V. y Compañía Cervecerías Unidas Argentina S.A. que, entre otras materias, comprende: (i) el
de cerveza artesanal 3 Cordilleras. // CCU, a través de su filial Compañía Pisquera de Chile S.A., vende término anticipado al contrato de licencia en Argentina de la marca “Budweiser”, celebrado entre Compañía
su participación del 49% en Compañía Pisquera Bauzá S.A. // CCU adquiere el 100% de las acciones de Cervecerías Unidas Argentina S.A. y Anheuser-Busch, Incorporated (hoy Anheuser-Busch LLC, subsidiaria de
Manantial S.A., a través de sus filiales Aguas CCU-Nestlé Chile S.A. y Embotelladoras Chilenas Unidas S.A. Anheuser-Busch InBev S.A./N.V.), y (ii) la transferencia a favor de Compañía Cervecerías Unidas Argentina S.A.
// CCU en Paraguay, a través de su filial Bebidas del Paraguay S.A., adquiere el 51% de la empresa Sajonia de la propiedad de las marcas Isenbeck, Diosa, Norte, Iguana y Báltica así como las licencias de las marcas
Brewing Company SRL (antes Artisan SRL), relacionada a la marca de cerveza artesanal Sajonia. // internacionales Warsteiner y Grolsch en el territorio argentino. // En virtud del ejercicio de la opción de
CCU, a través de su coligada Foods Compañía de Alimentos CCU S.A. y la filial CCU Inversiones S.A., compra estipulado en el Acuerdo de Accionistas, CCU S.A. adquiere de Grupo Monasterio, titular del
adquieren el 49,9999% y el 0,0001%, respectivamente, de las acciones de Alimentos Nutrabien S.A., 66% de las acciones de Bebidas Bolivianas BBO S.A., un 17% del total del capital de dicha sociedad,
quedando en consecuencia como únicos accionistas directos de ésta. // CCU y Watt’s, entre otras, pasando CCU S.A. a ser titular del 51% de las acciones de Bebidas Bolivianas BBO S.A., conservando
firmaron un “Acuerdo de Asociación Internacional” a fin de expandir la marca Watt’s a algunos países de Grupo Monasterio el 49% restante. Posteriormente, CCU S.A. aportó en dominio el total de las acciones
América del Sur a través de Promarca Internacional SpA, una filial de propiedad total de Promarca S.A. // de que era propietaria en Bebidas Bolivianas BBO S.A. a su filial CCU Inversiones II Ltda., actual accionista
CCU inició la distribución de Red Bull en Chile. y controlador de dicha sociedad. // Foods Compañía de Alimentos CCU S.A. y CCU Inversiones S.A., previa
 aprobación de las autoridades de libre competencia en Chile, vendieron el 100% de las acciones de su filial
2017 Compañía Cervecerías Unidas Argentina S.A. comenzó la producción y comercialización de cerveza Alimentos Nutrabien S.A. a Ideal S.A., filial de Grupo Bimbo. // CCU coloca en el mercado chileno bonos de
Miller Genuine Draft (MGD) en Argentina. // CCU S.A. y Compañía Cervecerías Unidas Argentina S.A. la serie J por UF 3 millones, a 25 años bullet. // A fines de 2018, CCU concluyó la construcción del nuevo
acuerdan con Anheuser-Busch InBev S.A./N.V. (ABI) la terminación anticipada del contrato de licencia en centro de distribución para bebidas no alcohólicas que forma parte del Proyecto CCU Renca.
Memoria Integrada 2024 / 2.2 Información histórica 14

[pág. 16]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
2019 CCU lanza en Chile un moderno sitio de ventas en línea del portfolio de productos de la
Compañía, La Barra, con entrega a domicilio. // Con fecha el 31 de mayo de 2019, CCU, a través de
su filial Viña San Pedro Tarapacá S.A., materializa la compra de los activos vitivinícolas de Pernod
Ricard Argentina SRL, considerando las marcas Graffigna (negocio internacional), Colón y Santa Silvia,
dentro del mercado doméstico argentino. La transacción incluyó asimismo la compra de la bodega
Graffigna ubicada en San Juan y los viñedos de Pocito y Cañada Honda, ubicados asimismo en San
Juan y el viñedo La Consulta ubicado en el Valle de Uco, Mendoza. // En mayo de 2019 se inaugura
oficialmente en Colombia la nueva planta productiva, con capacidad para más de tres millones de
hectolitros. Al mismo tiempo, comenzó la producción y se realizó el lanzamiento de cerveza Andina
y Andina Light, así como Natumalta, una bebida no alcohólica en base a malta.
2020 Emisión de bonos corporativos por un monto total de UF 6,5 millones de los cuales CCU S.A.
coloca una serie L por UF 3 millones a 7 años y una serie M por UF 2 millones a 10 años, mientras que
nuestra filial VSPT emite una serie D por UF 1,5 millones a 5 años. // Luego de su exitoso lanzamiento en
2019, durante el 2020 nuestra plataforma de ventas en línea La Barra consolidó su rol estratégico en la
Compañía, empezando además su expansión en la región, con su lanzamiento en Argentina y Paraguay.
2021 En línea con nuestras metas medioambientales, en 2021 inauguramos y pusimos en marcha
nuestra nueva planta de bebestibles no alcohólicos Embotelladora CCU Renca, la que cuenta con
altos estándares de cuidado al medio ambiente.
En abril, julio y agosto de 2021, aumentamos nuestra participación en el negocio de la sidra en Argentina
a través de nuestra filial Compañía Industrial Cervecera S.A., que adquirió 1.124.111 acciones de la filial
argentina Sáenz Briones y Cía. S.A.I.C., quedando consecuentemente con una participación del 99,9419%
en dicha sociedad. Asimismo, en septiembre y octubre de 2021, aumentamos nuestra participación en
Viña San Pedro Tarapacá S.A., a través de nuestra filial CCU Inversiones S.A., que adquirió 603.639.429
acciones, alcanzando una participación de 84,5159% en Viña San Pedro Tarapacá S.A. al cierre de
diciembre de 2021.
CCU S.A. emitió por primera vez un bono internacional por USD 600 millones a 10 años, con sujeción
a la Regla 144A (Rule 144A) y Regulación S (Regulation S) de la Ley de Valores de los Estados Unidos
 Planta No Alcohólicas
de 1933 (U.S. Securities Act of 1933), para fines corporativos generales. Embotelladora CCU Renca
 Santiago, Chile.
Memoria Integrada 2024 / 2.2 Información histórica 15

[pág. 17]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
2022 En abril de 2022, CCU a través de su subsidiaria Compañía Cervecerías Unidas Argentina S.A. adquirió Se anunció la construcción de una planta de producción de Resina Reciclada rPET (polietileno
el 49% de la propiedad de Aguas Danone de Argentina S.A., que incluye el negocio de aguas minerales y tereftalato reciclado), bajo el nombre “Planta de Reciclaje CirCCUlar”, dentro del terreno de la actual
aguas saborizadas con sus marcas Villavicencio, Villa del Sur, Levité, Ser y Brío, y de Aguas de Origen S.A., Planta Embotelladora CCU Renca.
sociedad esta última que pasó a ser la continuadora del negocio de Aguas Danone de Argentina S.A. a
partir de diciembre de 2022. En noviembre del mismo año, Compañía Cervecerías Unidas Argentina S.A. En octubre celebramos el 5° Encuentro de Sustentabilidad, donde dimos a conocer, a nivel regional,
adquirió de Holding Internationale De Boissons S.A.S. un 1% adicional de las acciones de Aguas de la nueva estrategia de la Compañía en esta materia. Durante la jornada, en la que participaron
Origen S.A., con lo cual CCU alcanzó el 50% de participación en ésta. trabajadores de Chile, Argentina, Bolivia, Paraguay y Uruguay, se dio a conocer el plan para enfrentar
 y gestionar los desafíos Ambientales, Sociales y de Gobernanza (ASG). Esta estrategia cuenta con
En abril CCU S.A. realizó una colocación de bonos a 10 años, serie P, por un total de UF 2 millones una visión, “Juntos por un Mejor Vivir”; dos ejes, Nuestro Planeta y Nuestras Personas; 8 agendas de
con vencimiento al 15 de marzo de 2032 y en diciembre colocó bonos a 20 años, serie R, por un total trabajo y 20 metas al año 2030.
de UF 4 millones con vencimiento al 15 de septiembre de 2042.
 Con fecha 29 de diciembre de 2023, asume la presidencia del Directorio de CCU S.A. el señor Francisco
A través de nuestra filial CCU Inversiones S.A. aumentamos nuestra participación en Viña San Pedro Pérez Mackenna, luego de la renuncia presentada por el señor Andrónico Luksic Craig, quien formó
Tarapacá S.A. en un 0,18%, alcanzando un 84,70%. parte del Directorio de CCU S.A. por más de 36 años.
2023 En marzo de 2023, CCU llegó a acuerdos irrevocables y definitivos respecto de Bebidas del
Paraguay S.A. y Distribuidora del Paraguay S.A., que establecieron la salida del Grupo Cartes de dichas
sociedades, y la incorporación de un nuevo socio Sudameris Bank S.A.E.C.A. En virtud de lo anterior,
CCU a través de su filial CCU Inversiones II SpA, aumentó su participación en Bebidas del Paraguay
 ST R O PLAN
S.A. del 50,005% al 55,007%, y en Distribuidora del Paraguay S.A. del 49,959% al 54,964%, detentando UE ET
 N A
Sudameris Bank S.A.E.C.A. la propiedad de las restantes acciones de ambas sociedades, las que fueron I M ÁTIC
 O
 AB
 AS
 C L
adquiridas por CCU, a través de sus filiales CCU Inversiones II SpA y CCU Inversiones S.A., en febrero FÍ
 O
 ICO
 VOCAC
 I ÓN
 TE
 C
 A
 DR
de 2024, pasando en consecuencia a ser titular de la totalidad de las acciones de dichas sociedades. HÍ
 IM
 CI
 S
 DE
 R
 IE
 O
 NT
 I
 CU
 BR
 OR
 LA
 ILI
Para continuar avanzando con nuestra estrategia de internacionalización, que busca el crecimiento y
 R
 ES P
 E QU
la premiumización del portafolio, VSPT Wine Group inauguró una oficina comercial en Shanghái, China.
 ONSA B L E
 UMIDOR
 EXPER
 DISFR
En Argentina, implementamos la integración del joint venture de Aguas de Origen S.A. a la red de
 NS
 2030
 UT
 IEN
venta y distribución de nuestras filiales en dicho país. Este hito nos permitirá en el futuro desarrollar Patricio Jottar
 CO
 EC
 CI
 Gerente General CCU S.A. SE E
 L
 A
las sinergias propias de nuestra estrategia multicategoría en la región.
 O
 R OR
 N
 ÍS
 CC N P
 SC
 IE U P
 A
 N PA S I Ó
 5° Encuentro de TE SO
 G RE
 Sustentabilidad N PRO
 UE S
 STR O NA
 AS PERS
Memoria Integrada 2024 / 2.2 Información histórica 16

[pág. 18]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
Hitos 2024
 1 Los volúmenes consolidados aumentaron un 1,9% respecto del período anterior, 3 En el año 2024 elaboramos y aprobamos el Plan Estratégico 2025 - 2027, en el que
 considerando el crecimiento orgánico e inorgánico durante el año 2024. Sin embargo, al reafirmamos nuestros tres Pilares Estratégicos: Rentabilidad, Crecimiento y Sustentabilidad.
 excluir el aporte de volúmenes inorgánicos, los volúmenes consolidados se contrajeron En Rentabilidad, contamos con una serie de iniciativas para mejorar nuestros márgenes,
 un 5,2%, explicado prácticamente en su totalidad por la contracción de los volúmenes del tanto en gestión de ingresos como en eficiencias de costos y gastos, apoyadas en la
 Segmento de operación Negocios Internacionales, principalmente por Argentina. implementación de nuevas herramientas tecnológicas. En cuanto a Crecimiento, nuestro
 foco estará en expandir la escala de negocios y seguir fortaleciendo nuestra presencia
 Fortalecimos la presencia regional de CCU al consolidar Aguas de Origen S.A., un negocio conjunto regional y nuestra preferencia de marca. En Sustentabilidad, seguiremos trabajando en
 2 de aguas y bebidas no alcohólicas con Danone en Argentina, el que seguirá generando sinergias nuestra Estrategia “Juntos por un Mejor Vivir” y sus dos ejes Planeta y Personas.
 a nuestra operación en dicho país. Esta consolidación se llevó a cabo en julio 2024, fecha en la
 cual nuestra subsidiaria Compañía Cervecerías Unidas Argentina S.A. (CCU Argentina) ejerció la 4 En el ámbito de nuestros trabajadores, obtuvimos el primer sello internacional de CCU
 opción de compra de acciones, contenida en el acuerdo de accionistas, que le permitía, adquirir la como “Top Employer 2024” por parte del Top Employers Institute, un logro que refuerza el
 cantidad de 8.471.349 acciones correspondientes al 0,1% de participación del negocio conjunto compromiso de CCU con los trabajadores, el desarrollo continuo de buenas prácticas, la
 Aguas de Origen S.A. De esta manera CCU Argentina posee al cierre del año 2024 un 50,1% atracción y retención de talento, el bienestar, la diversidad y la inclusión. Además, alcanzamos
 de dicha sociedad. // Adicionalmente, potenciamos nuestra presencia en Paraguay a través de un 86% en nuestro Indicador Global de Clima, superando los resultados del 2023. Por
 una asociación con el Grupo Vierci, que comprende la licencia de PepsiCo para la producción otro lado, CCU obtuvo nuevamente el 1° lugar en el sector de bebidas en atracción de
 y distribución de bebidas, así como también la distribución de snacks. Con esta asociación, talento en Chile en la 11ª edición del ranking Merco Talento Chile, uno de los rankings
 Paraguay pasó a ser el segundo país en donde la licencia de PepsiCo es parte del portafolio más reconocidos en el país. Por último, CCU fue reconocida por segundo año consecutivo
 de marcas de CCU, además de Chile. En virtud de los acuerdos alcanzados con como una de las 10 empresas más atractivas para trabajar en Chile, según el ranking Merco
 Grupo Vierci, CCU pasó a detentar el 51% de las acciones de AV S.A. y Talento Universitario Chile 2024.
 de Distribuidora del Paraguay S.A. y, una vez cumplidas todas las
 condiciones pactadas, permanecerá con igual porcentaje CCU continuó demostrando su compromiso con Chile a través de donaciones de productos
 de acciones de Bebidas del Paraguay S.A., quedando el 5 de hidratación y energía a familias, bomberos e instituciones afectadas por emergencias y
 49% restante de las acciones de tales compañías en catástrofes naturales. En Chile, en la región de Valparaíso se entregaron más de 50.000 litros,
 manos del Grupo Vierci. Ambos negocios, fortalecen y en las regiones de la Araucanía y O’Higgins más de 6.000 litros a bomberos. Adicionalmente,
 nuestra posición como un operador regional debido al compromiso de los trabajadores de CCU con las familias afectadas por los
 multicategoría de bebestibles. incendios, además de la Campaña 1+1 con Desafío Levantemos Chile, se llevaron a cabo
 jornadas de voluntariado en tareas como la entrega de alimentos, limpieza de escombros
 y reconstrucción de viviendas.
Memoria Integrada 2024 / 2.2 Información histórica 17

[pág. 19]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
 6 En el año 2024, a través de nuestra filial CCU Inversiones S.A. aumentamos nuestra
 participación en Viña San Pedro Tarapacá S.A. en un 0,47%, alcanzando un 85,17%.
 7 CCU obtuvo el lugar 20° en la edición XV del estudio Marcas Ciudadanas, desarrollado por
 Cadem junto a Deloitte y Diario Financiero, destacándose por su conexión con las necesidades
 y preocupaciones de los consumidores. Por su parte, Cachantun y Kunstmann obtuvieron
 los primeros lugares en las categorías Bebidas y Bebidas Alcohólicas, respectivamente.
 Adicionalmente, CCU fue reconocida con el 1° lugar en la categoría Aporte Social, por su
 Proyecto Emprendedor, en el Premio Nacional de Logística 2024.
 8 CCU fue reconocida como una de las 100 empresas más responsables de Chile en el ranking
 Merco Responsabilidad ESG 2023, obteniendo el 1° lugar en el sector Bebidas por quinto
 año consecutivo y el 16° en el ranking general. Asimismo, CCU fue reconocida por sexto
 año consecutivo por el programa Huella Chile y por quinto año por reducción y excelencia 9 Junto a nuestra filial Compañía Pisquera de Chile S.A., anunciamos a los 15 ganadores del
 en la medición y gestión de las emisiones de Gases Efecto Invernadero (GEI). Primer Fondo Hídrico CCU, una iniciativa que busca apoyar la implementación de medidas
 para aumentar la eficiencia del uso del agua en los predios de pequeños agricultores de
 la región de Coquimbo, Chile. Mediante ayuda económica y técnica, los ganadores podrán
 impulsar la sustentabilidad de sus cultivos, introduciendo técnicas como el riego por goteo, la
 impermeabilización de tranques y la instalación de filtros de arena de cuarzo y tuberías, entre
 otras. El fondo es parte de la Estrategia de Sustentabilidad de CCU y busca reducir en un 60%
 el consumo de agua industrial de cara al año 2030, e implementar iniciativas de reposición de
 agua en sus comunidades.
 10 Continuamos progresando en el ámbito de la electromovilidad introduciendo los primeros
 vehículos eléctricos a la flota de distribución en la ciudad de Santiago de Chile, dando
 continuidad a nuestro compromiso con la sustentabilidad y la reducción de emisiones. Así,
 al cierre del año 2024, la flota eléctrica que utiliza CCU alcanzó 31 vehículos, incluyendo
 camiones de diferentes capacidades y características, pudiendo alcanzar hasta 250 kilómetros
 de autonomía en un ciclo de carga. Además, CCU electrificó su centro de distribución
 en Coquimbo con ocho grúas eléctricas, reduciendo 96 toneladas de CO2 anuales. Estas
 iniciativas contribuyen a los objetivos de reducción de emisiones GEI de la Compañía.
Memoria Integrada 2024 / 2.2 Información histórica 18

[pág. 20]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
 11 Logramos tres importantes hitos en economía circular:
 Planta de Reciclaje CirCCUlar: CCU inauguró la primera Planta de Reciclaje de botellas
 a botella plásticas en Chile. Esta planta utiliza tecnología de punta, consume energía 100%
 renovable y reutiliza el agua de sus procesos, reduciendo el impacto ambiental. Además,
 se proyecta que para el año 2025 la planta genere el 15% de su consumo energético a
 través de paneles solares.
 Desafío CirCCUlar: CCU, en conjunto con Desafío Levantemos Chile, lanzó “Desafío
 CirCCUlar”, un fondo concursable que apoya a cooperativas y emprendimientos formales
 de recicladores de base. El fondo busca fomentar modelos de trabajo colaborativo,
 potenciar las labores de los recicladores y empoderarlos como microempresarios y
 agentes de cambio a través del reciclaje de botellas PET. Los ganadores reciben capital
 semilla, mentorías y capacitaciones.
 Primera producción de botellas recicladas: En colaboración con Cachantun y utilizando
 la Planta de Reciclaje CirCCUlar, CCU lanzó al mercado la primera producción de botellas
 elaboradas con material reciclado. Esta iniciativa marca un hito en la Estrategia de
 Sustentabilidad de CCU “Juntos por un Mejor Vivir”, consolidando a la empresa como líder
 en economía circular en Chile.
 Estas iniciativas de CCU promueven la cultura del reciclaje, generan nuevos puestos de
 trabajo, apoyan a recicladores de base y reducen significativamente la cantidad de residuos
 plásticos, contribuyendo a un futuro más sostenible.
 Planta de Reciclaje
 CirCCUlar
 Santiago, Chile
Memoria Integrada 2024 / 2.2 Información histórica 19

[pág. 21]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
Desempeño 2024
 Consolidado
El Ingreso por ventas aumentó un 13,2%, alcanzando CLP 2.904.566 millones de pesos chilenos (CLP), Variación 2024-2023
como resultado de un aumento del 11,1% en los precios promedio en CLP y un alza de 1,9% en los
volúmenes consolidados. El aumento de los precios promedio en CLP se desglosa de la siguiente manera:
(i) un aumento del 4,3% en el Segmento de operación Chile, relacionado con iniciativas de gestión de
ingresos, parcialmente compensado por un efecto mix negativo en el portafolio; (ii) un aumento del
34,8% en el Segmento de operación Negocios Internacionales, impulsado por iniciativas de gestión de
ingresos, que más que compensaron la devaluación del peso argentino (ARS) frente al dólar de Estados
Unidos de América (USD), y un efecto mix positivo, y (iii) un crecimiento del 10,6% en el Segmento de
operación Vinos, impulsado principalmente por un CLP más débil y sus efectos favorables sobre los
ingresos de exportación y un efecto mix positivo. T EBIT
 EBI DA
El aumento de los volúmenes se debió en gran medida al Segmento de operación Negocios Internacionales,
que aumentó sus volúmenes en un 7,5%, principalmente por crecimiento inorgánico, proveniente de la +1,9% +9,6% +13,2% +3,7% +52,3%
 ING
 TA
consolidación a partir de julio 2024 de Aguas de Origen S.A., un negocio de aguas y bebidas no alcohólicas
 TI
 EN
 ES T
 A
 U
 VO
 R
en Argentina, y a partir de octubre 2024, de la asociación con Grupo Vierci, en Paraguay, que incluye la V LID E
 LUMEN OS
 POR AD N
licencia de PepsiCo para la producción y distribución de bebidas, así como la distribución de snacks.
Orgánicamente, es decir, aislando el efecto en volúmenes de la consolidación de dichos negocios, este
segmento contrajo sus volúmenes en un 18,2%, casi en su totalidad explicado por la compleja situación
económica en Argentina, que derivó en una caída levemente sobre el 20% en la industria de la cerveza en
dicho país, mientras que Paraguay y Bolivia expandieron volúmenes, y Uruguay los disminuyó debido a una
alta base de comparación, explicada por una situación de escasez hídrica en el año 2023 que impulsó el
consumo de agua envasada. Por su parte, el Segmento de operación Chile mantuvo la escala disminuyendo
un 0,3%. El Segmento de operación Vinos expandió el volumen en un 1,0%, casi en su totalidad impulsado
por las exportaciones desde Chile, que se expandieron un 3,9%, mientras que los volúmenes en el mercado
doméstico en Chile se mantuvieron planos y los volúmenes en el mercado doméstico argentino disminuyeron.
El Costo de venta creció un 15,4%, como consecuencia del aumento del 13,2% en el Costo de venta
por hectolitro. El mayor Costo de venta por hectolitro se debió a: (i) un aumento del 7,1% en el
Segmento de operación Chile, explicado por la depreciación promedio de 12,5% del CLP frente al USD
y su impacto en los costos denominados en USD, siendo parcialmente compensado por menores
Memoria Integrada 2024 / 2.2 Información histórica 20

[pág. 22]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
precios en malta y PET, parcialmente contrarrestado por mayores precios en azúcar, pulpa de fruta y Consolidado (Millones de CLP) 2024 2023
aluminio; (ii) una expansión del 43,5% en CLP en el Segmento de operación Negocios Internacionales, Volumen (Miles de Hectolitros) 33.773 33.137
impulsada principalmente por Argentina debido a presiones de costos provenientes de la depreciación
 Ingresos por Ventas 2.904.566 2.565.556
del ARS frente al USD; y (iii) un aumento del 7,7% en el Segmento de operación Vinos, impulsado por
mayores costos vinculados al USD, parcialmente compensado por un menor costo de vino. EBIT(1) 262.702 253.283
 Margen EBIT (%) 9,0 9,9
Como consecuencia de lo anterior, el Margen bruto alcanzó los CLP 1.313.609 millones, una expansión del
 EBITDA(1) 415.936 379.402
10,7%. El margen bruto, como porcentaje de los Ingresos por ventas, disminuyó en 104 puntos básicos.
 Margen EBITDA (%) 14,3 14,8
Los gastos de administración, comercialización y distribución (MSD&A, por sus siglas en inglés) aumentaron un Utilidad Neta 160.944 105.653
16,0% en CLP, y como porcentaje de los Ingresos por venta, se deterioraron 91 pb, principalmente explicado
 (1) Resultado Operacional Ajustado (o EBIT por su sigla en inglés), es definido por la Compañía como la Utilidad (pérdida) antes de
por el Segmento de operación Negocios Internacionales, debido a Argentina. El desglose por Segmento de Otras ganancias (pérdidas), Gastos financieros netos, Utilidad de negocios conjuntos y asociadas contabilizados por el método
operación fue el siguiente: (i) en el Segmento de operación Chile, los gastos de MSD&A se expandieron un de la participación, Diferencias de cambio, Resultados por unidades de reajuste e Impuestos a las ganancias. EBIT es equivalente
 al Adjusted Operating Result usado en el Formulario 20-F. 
1,2%, y como porcentaje de los Ingresos por ventas mejoraron 93 pb, principalmente debido a eficiencias (2) ROADA (o EBITDA por sus siglas en inglés), es definido por la Compañía como Resultado Operacional Ajustado antes de Depreciación
que compensaron mayores gastos vinculados al USD, y presiones inflacionarias; (ii) en el Segmento de y Amortización. EBITDA es equivalente al ORBDA (Adjusted Operating Result before Depreciation and Amortization), usado en el
 Formulario 20-F. 
operación Negocios Internacionales, los gastos de MSD&A aumentaron un 56,7%, y como porcentaje de los
Ingresos por ventas aumentaron 336 puntos básicos, esto último debido principalmente por una menor causado principalmente por contratos de derivados, específicamente, contratos forward celebrados para
escala de negocios en Argentina que impactó negativamente en la dilución de los gastos fijos; (iii) en el mitigar el impacto de las fluctuaciones del tipo de cambio en nuestras posiciones en moneda extranjera en
Segmento de operación Vinos, los gastos de MSD&A aumentaron un 9,1%, aunque como porcentaje de el balance; (iii) una menor pérdida en Utilidad de negocios conjuntos y asociadas por CLP 9.723 millones,
los Ingresos por ventas disminuyeron 74 puntos básicos, debido a eficiencias que ayudaron a compensar impulsada por gastos no recurrentes en 2023 relacionados con la integración de Aguas de Origen S.A. en
mayores gastos de marketing relacionados con las exportaciones que están denominados en USD. nuestra operación, y un mejor resultado financiero en Colombia; y (iv) un mejor resultado en Resultados por
 unidades de ajuste por CLP 3.304 millones, principalmente en Argentina. Esto último se vio parcialmente
Con lo anterior, El Resultado Operacional Ajustado (EBIT, por sus siglas en inglés) alcanzó los compensado por una mayor pérdida por CLP 21.443 millones en Gastos financieros netos, principalmente
CLP 262.702 millones, expandiéndose un 3,7% y el Resultado Operacional Ajustado antes de debido a una mayor deuda y mayores tasas de interés en Argentina.
Depreciación y Amortización (EBITDA, por sus siglas en inglés) alcanzó los CLP 415.936 millones,
equivalente a un alza de 9,6%. Excluyendo una ganancia no recurrente por la venta de una porción El Impuesto a las ganancias alcanzó un resultado positivo de CLP 11.015 millones versus un resultado
de terreno en Chile en el segundo trimestre de 2024, que tuvo un impacto de CLP 28.669 millones positivo de CLP 15.267 millones el año anterior. Esto se explica principalmente por una mayor utilidad
antes de impuestos, el EBIT totalizó CLP 234.033 millones, una disminución del 7,6% en comparación antes de impuestos, parcialmente compensados por efectos positivos en Argentina por la aplicación
con el año pasado, y el EBITDA, totalizó CLP 387.267 millones aumentando en un 2,1%. de la inflación para fines tributarios.
El Resultado no operacional totalizó una pérdida de CLP 97.172 millones frente a un resultado negativo de Finalmente, como resultado de todo lo expuesto anteriormente, la Utilidad neta alcanzó una ganancia
CLP 150.125 millones. El mejor resultado se explicó principalmente por: (i) una menor pérdida en Diferencias de CLP 160.944 millones, una expansión de 52,3%. Así también, excluyendo la ganancia no recurrente
de cambio por CLP 48.147 millones, debido a una menor exposición en pasivos en moneda extranjera por la venta de una porción de terreno en Chile en 2T24, la que tuvo un impacto de CLP 20.928 millones
en el balance de Argentina; (ii) un mejor resultado en Otras ganancias/(pérdidas) por CLP 13.221 millones, después de impuestos, la Utilidad neta alcanzó CLP 140.016 millones, aumentando un 32,5%.
Memoria Integrada 2024 / 2.2 Información histórica / Desempeño 2024 21

[pág. 23]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
Desempeño 2024
 Segmento de operación Chile
En el Segmento de operación Chile los Ingresos por ventas registraron un alza de 4,0%, totalizando
CLP 1.829.244 millones, impulsado por un aumento en los precios promedio de 4,3%, mientras
que los volúmenes decrecieron un 0,3%. Los mayores precios promedio se explican por iniciativas
de gestión de ingresos, parcialmente compensadas por un efecto mix negativo, mientras que los
menores volúmenes fueron consecuencia de un crecimiento moderado de la economía. El Costo
de venta por hectolitro aumentó 7,1%, explicado por la depreciación anual promedio de 12,5%
del CLP frente al USD y su impacto en los costos denominados en USD, y por mayores precios en
azúcar, pulpa de fruta y aluminio, siendo parcialmente compensado por menores precios en malta
y PET.
Como resultado, el Margen Bruto se expandió un 0,7% y como porcentaje de los Ingresos por ventas
disminuyó de 45,8% a 44,3%. Por su parte, los gastos de MSD&A aumentaron 1,2% con respecto
al año anterior y, como porcentaje de los Ingresos por ventas, disminuyeron de 34,2% a 33,3%. De
esta manera, el EBIT aumentó 0,4% alcanzando CLP 205.406 millones, y el margen EBIT disminuyó
de 11,6% a 11,2%. Por otro lado, el EBITDA se expandió 2,4% alcanzando CLP 290.080 millones, y el
margen EBITDA disminuyó de 16,1% a 15,9%.
En cervezas, se destacaron los lanzamientos de Royal Guard Apa, que se suma a las propuestas
de segmento de variedades de Royal Guard y de Escudo, quien lanzó la edición limitada Escudo
Maki con sabor a Maqui de la Araucanía. En Austral continuaron con las innovaciones en Patagonia,
lanzando el nuevo formato de botella long neck Hoppy Lager y Red Lager, junto a Patagonia Epic
Mixes en sabor Gin Tonic y Whisky Honey. Sol lanzó dos extensiones de línea Sol Mixes, sabor Mango
Margarita y Spritz frutos rojos. Kunstmann continuó sumando variedades a sus Experimentales de
Edición Limitada. Por último, Stones realizó el lanzamiento de su nueva variedad Stones Berries.
Memoria Integrada 2024 / 2.2 Información histórica / Desempeño 2024 22

[pág. 24]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
El año 2024 estuvo marcado por la inauguración de nuestra Planta de Reciclaje CirCCUlar, la primera
planta de plástico reciclado PET en Chile. Esta planta nos permitirá darle una nueva vida a millones
de botellas cada año. Adicionalmente fuimos pioneros en lanzar la primera botella hecha con plástico
reciclado en Chile de la mano de nuestra marca Cachantun. En la categoría de gaseosas, bajo la
licencia de PepsiCo lanzamos H2OH!, una bebida suavemente gasificada y sin azúcar ideal para
acompañar las comidas junto a sus sabores. En bebidas funcionales continuamos innovando con T EBIT
 EBI DA
el lanzamiento de Gatorlit, nuestra nueva bebida que permite una rápida hidratación y seguimos
expandiendo el portafolio de bebidas energéticas con Rockstar Mango.
 (0,3)% +2,4% +4,0% +0,4%
 ING
 TA
En licores, en el año 2024 en pisco, lanzamos Mistral Nobel Cristalino, un pisco que luego de su reposo
 EN
en barricas de roble, es filtrado en cristales de carbón, lo que realza el sabor de las uvas, mantiene las VO ES
 R
 V
 LUMEN OS
 POR
notas justas a madera y le otorga un color cristalino único. Con este producto logramos por primera
vez competir en la creciente subcategoría de piscos transparentes. En cócteles, Campanario lanzó
una nueva variedad de Colada, Café Latte, que se integra a los Sabores de la Amistad. Además, se
hizo el relanzamiento de Ruta Cocktail con una nueva imagen. Finalmente, Mistral Ice lanzó su nueva
variedad Mango y se incorporó al portafolio la nueva marca Tres Erres Ice.
 Segmento de operación Chile (Millones de CLP) 2024 2023
 Volumen (Miles de Hectolitros) 22.707 22.781
 Ingresos por Ventas 1.829.244 1.758.971
 EBIT(1) 205.406 204.586
 Margen EBIT (%) 11,2 11,6
 EBITDA(2) 290.080 283.409
 Margen EBITDA (%) 15,9 16,1
(1)(2) Refiérase a la página 21.
Memoria Integrada 2024 / 2.2 Información histórica / Desempeño 2024 23

[pág. 25]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
Desempeño 2024
 Segmento de operación Negocios Internacionales
En el Segmento de operación Negocios Internacionales, compuesto por Argentina, Bolivia, Paraguay
y Uruguay, los Ingresos por ventas aumentaron 45,0%, llegando a CLP 850.118 millones. Lo anterior
se explicó por un alza de 34,8% en los precios promedios en CLP, asociado a iniciativas de gestión
de ingresos que más que compensaron la devaluación del ARS con respecto al USD y al CLP. Por su
parte, los volúmenes aumentaron un 7,5%, principalmente por crecimiento inorgánico, proveniente
de la consolidación a partir de julio 2024 de Aguas de Origen S.A., un negocio de aguas y bebidas
no alcohólicas en Argentina, y a partir de octubre 2024, de la asociación con Grupo Vierci, en
Paraguay. Orgánicamente, es decir, aislando el efecto en volúmenes de la consolidación de dichos
negocios, este segmento se contrajo un 18,2%, casi en su totalidad explicado por la compleja
situación económica en Argentina, que derivó en una caída levemente sobre el 20% en la industria
de la cerveza en dicho país, mientras que Paraguay y Bolivia expandieron volúmenes, y Uruguay los
disminuyó debido a una alta base de comparación, explicada por una situación de escasez hídrica
en el año 2023 que impulsó el consumo de agua envasada.
El Costo de venta por hectolitro aumentó 43,5% en CLP, explicado principalmente por el impacto
negativo que generó la devaluación del ARS frente al USD en nuestros costos vinculados al USD.
El Margen Bruto aumentó 36,1% y como porcentaje de los Ingresos por ventas disminuyó de 51,3% a
48,2%. Por otra parte, los gastos MSD&A, se incrementaron en 56,7% y, como porcentaje de los Ingresos
por ventas, aumentaron 336 pb, esto último debido principalmente a una menor escala de negocios
en Argentina que impactó negativamente en la dilución de los gastos fijos. En consecuencia, el EBIT fue
CLP 26.786 millones, siendo 53,5% inferior al año anterior, y el EBITDA se contrajo 8,3% alcanzando
CLP 78.446 millones. Por su parte, el margen EBITDA se redujo de 14,6% a 9,2%.
En Argentina, durante el año 2024, dado el contexto económico nos enfocamos en la racionalización
de calibres y recetas, buscando optimizar el portafolio de CCU. En cervezas, Salta Cautiva amplió su
portfolio con la nueva “Session IPA”, una cerveza fresca, de bajo amargor y alta tomabilidad donde
Memoria Integrada 2024 / 2.2 Información histórica / Desempeño 2024 24

[pág. 26]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
la marca busca seguir desarrollando cervezas inspiradas en la naturaleza. En la categoría sidras, la
marca referente del segmento premium lanzó “1888 Botánica”, un blend patagónico de manzanas
con delicadas notas de enebro. Además, La Celia presentó su nuevo “Élite Pinot Noir”, un vino que
manifiesta el refinamiento y la elegancia de la bodega resaltando la calidad de su terroir ubicado
en Valle de Uco, Mendoza.
 T EBIT
 EBI DA
En la categoría de aguas minerales, Villa del Sur presentó su nuevo formato Kids, consolidando su
posición en el mercado infantil con una propuesta pensada para acompañar a los más pequeños en la
incorporación de hábitos saludables de hidratación. En aguas saborizadas, Levité sumó a su portfolio 7,5% (8,3)% +45,0% (53,5)%
 ING
 TA
la innovadora variedad pomelo rosado, una opción refrescante que responde a las preferencias del
 EN
consumidor actual. Villavicencio, en tanto, celebró su trayectoria con la campaña de sus 120 años, VO ES
 R
 V
 LUMEN OS
 POR
reafirmando su compromiso con la sustentabilidad y la pureza de su origen en los Andes.
En términos de comunicación, Schneider se asoció con la selección nacional durante la Copa
América. Amstel patrocinó la Copa Libertadores y Heineken comunicó su especialidad sin alcohol,
aprovechando la “Fórmula 1” y la música. Miller se centró en la música electrónica e Imperial en
el rugby y su variedad sin alcohol. Sidras lanzó una nueva variedad y patrocinó el tenis y el polo.
En Bolivia, en la categoría de cervezas, lanzamos el nuevo formato lata 269cc de Amstel a través de la
campaña “Vive la pasión de la final en Baires”, adaptándose a las tendencias del mercado boliviano, producida localmente en Bebidas Bolivianas BBO S.A. En la categoría gaseosas, continuamos con
con el mismo sabor refrescante y calidad de siempre. Por otro lado, en diciembre, incorporamos la estrategia de expansión del portafolio, lanzamos el sabor pomelo Mendocina en el formato 1
a nuestro portafolio la cerveza Schneider en el formato lata 473cc, segunda marca internacional litro. Adicionalmente, durante el último trimestre de 2024, la marca Mendocina renovó su imagen
 en todos sus formatos y sabores con el fin de destacar su esencia y modernizar su presentación.
 Segmento de operación Negocios
 2024 2023
 Internacionales (Millones de CLP) En Uruguay, continuamos consolidando el portafolio de bebestibles. En cervezas se consolidó el
 Volumen (Miles de Hectolitros) 9.780 9.095 segmento sin alcohol con el lanzamiento de la Heineken cero lata 350cc. A su vez, incorporamos
 Ingresos por Ventas 850.118 586.484 la categoría de sidras con las marcas 1888 y Real producidas en Argentina. En la categoría néctar
 se agregó el calibre 400cc en el sabor naranja zanahoria.
 EBIT(1) 26.786 57.553
 Margen EBIT (%) 3,2 9,8 En Paraguay, se realizó el lanzamiento de agua tónica La Fuente, el relanzamiento de Amstel
 EBITDA(2) 78.446 85.564 y la incorporación de un amplio portafolio de marcas no alcohólicas y alimentos producto de la
 integración con AV S.A. Las marcas incorporadas son en gaseosas Pepsi, Paso de los Toros,
 Margen EBITDA (%) 9,2 14,6
 Mirinda, 7up y Split; en isotónicas la marca Gatorade; en energéticas, las marcas Rockstar y Red
(1)(2) Refiérase a la página 21. Bull. En alimentos las marcas Lays, Doritos, Cheetos, Fandango y Quaker, entre otras.
Memoria Integrada 2024 / 2.2 Información histórica / Desempeño 2024 25

[pág. 27]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
Desempeño 2024
 Segmento de operación Vinos
En el Segmento de operación Vinos, los Ingresos por ventas aumentaron 11,8%, alcanzando
CLP 282.638 millones, principalmente como consecuencia de mayores precios promedios,
que se incrementaron en 10,6%, acompañado de un alza de 1,0% en volúmenes. Los precios
promedios se incrementaron principalmente por un CLP más débil frente al USD y sus efectos
favorables sobre los ingresos de exportación y un efecto mix positivo. Por su parte los mayores
volúmenes casi en su totalidad estuvieron impulsados por las exportaciones desde Chile, que
se expandieron un 3,9%, mientras que los volúmenes en el mercado doméstico en Chile se
mantuvieron planos y los volúmenes en el mercado doméstico argentino disminuyeron, esto
último asociado al complejo escenario económico en dicho país.
El Costo de venta por hectolitro aumentó un 7,7%, asociado a mayores costos vinculados al USD,
parcialmente contrarrestado por un menor costo de vino. Dado lo anterior, el Margen Bruto se
expandió y como porcentaje de los Ingresos por ventas aumentó 166 pb. Los gastos de MSD&A
aumentaron 9,1% y como porcentaje de los Ingresos por ventas disminuyeron de 30,6% a 29,9%.
Como consecuencia, el EBIT se incrementó en 45,6%, alcanzando CLP 29.155 millones, y el margen
EBIT aumentó de 7,9% a 10,3%. En esta misma línea, el EBITDA registró un alza de 30,0%, alcanzando
CLP 41.829 millones, y el margen EBITDA se incrementó de 12,7% a 14,8%.
En cuanto a innovaciones, en el mercado doméstico de Chile, ampliamos el portafolio de nuestra
línea Gato Selección dulce, con el lanzamiento de sus nuevas variedades Frutilla Borgoña y Chirimoya.
Asimismo, Santa Helena lanzó su nueva variedad Rosé, complementando su portafolio histórico.
Finalmente, VSPT amplió su portafolio de marcas al lanzar al mercado Donnaluna, una propuesta
de cóctel de vino premium con delicadas burbujas, refrescante, suave y listo para disfrutar, en sus
3 variedades: Tinto Rosso, Rossatto y Bianco. Asimismo, en el mercado de exportación, VSPT volvió
a lanzar en el mercado de Reino Unido la marca 35 South, consolidando su posición en el mercado
con sus variedades Cabernet Sauvignon y Sauvignon Blanc. Por otro lado, la marca R&O lanzó en
Memoria Integrada 2024 / 2.2 Información histórica / Desempeño 2024 26

[pág. 28]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
Suecia su espumante Brut, que destaca por sus características notas frescas y frutales. Asimismo,
la marca Ritmo incluyó sus variedades Brut, Rosé y Extra Brut en Corea del Sur, además de Brut
y Rosé en Tailandia, marcando la presencia de VSPT en la categoría de espumantes en el mundo.
Adicionalmente, VSPT conmemoró los 150 años de Viña Tarapacá con el lanzamiento de su edición
limitada Tarapacá Gran Reserva: Aniversario 150 Años. Este vino conmemora la tradición y calidad T EBIT
 EBI DA
de una viña con larga trayectoria y prestigio en el rubro vitivinícola.
En temas de sustentabilidad, VSPT continúa avanzando en su objetivo de carbono neutralidad, +1,0% +30,0% +11,8% +45,6%
 ING
 TA
siendo ratificados nuevamente en el año 2024 como Gold Members del International Wineries for
 EN
Climate Action (IWCA), gracias a las reducciones sostenidas en sus emisiones de gases de efecto VO ES
 R
 V
 LUMEN OS
 POR
invernadero (14% en términos absolutos en el año 2023). Cabe destacar que solo siete viñas en
el mundo cuentan con membresía Gold, siendo VSPT la única en Sudamérica.
Así mismo, VSPT obtuvo por sexto año consecutivo el reconocimiento como la empresa vitivinícola
más innovadora de Chile, según el ranking “Most Innovative Company” del ESE Business School.
 Segmento de operación Vinos (Millones de CLP) 2024 2023
 Volumen (Miles de Hectolitros) 1.361 1.347
 Ingresos por Ventas 282.638 252.825
 EBIT(1) 29.155 20.019
 Margen EBIT (%) 10,3 7,9
 EBITDA(2) 41.829 32.184
 Margen EBITDA (%) 14,8 12,7
(1)(2) Refiérase a la página 21.
Memoria Integrada 2024 / 2.2 Información histórica / Desempeño 2024 27

[pág. 29]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
2.3 Propiedad y control
2.3.1 Situación de control
Inversiones y Rentas S.A. (IRSA), accionista controlador de Compañía Cervecerías Unidas S.A. (CCU S.A.), es
una sociedad anónima cuyos accionistas son las sociedades Quiñenco S.A. y Heineken Chile SpA, las cuales
poseen cada una de ellas el 50% del capital accionario de IRSA. IRSA, directa e indirectamente, a través de
su filial Inversiones IRSA Limitada, posee 65,87% del capital accionario de CCU S.A.
Las acciones emitidas y pagadas de Quiñenco S.A. son de propiedad en un 82,9% de las sociedades Andsberg
Inversiones SpA, Ruana Copper A.G. Agencia Chile, Inversiones Consolidadas Ltda., Inversiones Salta SpA,
Inversiones Alaska Ltda., Inmobiliaria e Inversiones Río Claro S.A. e Inversiones Río Claro Ltda. La fundación
Luksburg Foundation tiene indirectamente el 100% de las acciones de Andsberg Inversiones SpA y el 100% de
las acciones de Ruana Copper A.G. Agencia Chile.
Andrónico Luksic Craig (RUT 6.062.786-K) tiene el 100% del control de Inversiones Consolidadas Ltda. y de
Inversiones Alaska Ltda. La familia de don Andrónico Luksic Craig tiene el 100% del control de Inversiones
Salta SpA. Inmobiliaria e Inversiones Río Claro S.A. e Inversiones Río Claro Ltda. son indirectamente
controladas por la fundación Emian Foundation, en la que la descendencia de don Guillermo Luksic Craig†
(RUT 6.578.597-8) tiene intereses. No existe un acuerdo de actuación conjunta entre los controladores
de Quiñenco S.A.
Heineken Chile SpA es una sociedad por acciones chilena cuyo controlador actual es Heineken International B.V.,
sociedad de responsabilidad limitada holandesa, filial de Heineken N.V. El socio mayoritario de Heineken N.V. es
la sociedad holandesa Heineken Holding N.V., sociedad holandesa filial de L’Arche Green N.V., la cual es filial de
L’Arche Holdings B.V., esta última controlada al final por la señora C.L. de Carvalho-Heineken.
Los miembros del controlador IRSA y únicos accionistas de esta última, Quiñenco S.A. y Heineken Chile SpA,
suscribieron un Pacto de Accionistas, depositado en el Registro de Accionistas de CCU S.A., que considera
restricciones para que éstos puedan adquirir acciones de CCU S.A. en forma independiente, debiendo, salvo
excepciones, ser adquiridas por IRSA. Dicho Pacto de Accionistas contempla, asimismo, restricciones a la libre
enajenación de acciones de IRSA por parte de los referidos accionistas, considerando derechos preferentes,
entre otros.
Memoria Integrada 2024 / 2.3 Propiedad y control 28

[pág. 30]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
2.3.2 Cambios importantes en la propiedad o control A continuación, se presenta una tabla con las participaciones accionarias de los 12 principales
 accionistas.
Durante el año 2024 no hubo cambios relevantes en la propiedad o control de CCU S.A. Sin perjuicio
de lo anterior, si bien nuestro accionista controlador IRSA, no cambió su participación en 2024 en Número de % de
 RUT
CCU, la que al 31 de diciembre de 2024 alcanza directa e indirectamente un 65,87%, la tenencia de acciones propiedad
ADRs, representada por la participación que detenta JP Morgan Chase Bank, N.A. disminuyó a 14,57% Inv. y Rentas S.A.(1) 96.427.000-7 218.109.273 59,03%
al 31 de diciembre de 2024 versus un 18,79% al 31 de diciembre de 2023.
 JP Morgan Chase Bank Segun Circular 40.000.535-4 53.847.923 14,57%
2.3.3 Identificación de socios o accionistas mayoritarios Inv. IRSA Ltda. 76.313.970-0 25.279.991 6,84%
 Banco Santander por Cuenta de Inv. Extranjeros 97.036.000-K 6.927.052 1,87%
 Banco Santander Chile 97.036.000-K 5.892.344 1,59%
 INVERSIONES
 Banco de Chile por Cuenta de State Street 97.004.000-5 5.785.189 1,57%
 Y RENTAS S.A.
 IRSA (1)
 Otros(3)
 ADRs(2) Banco de Chile por Cuenta de Citi Na New York Client 97.004.000-5 4.562.539 1,23%
 Cia de Seguros de Vida Consorcio Nacional de Seguros S.A. 99.012.000-5 3.785.161 1,02%
 AFP Habitat S.A. para Fdo. Pension C 98.000.100-8 2.899.150 0,78%
 65,87% 19,56% 14,57%
 AFP Provida S.A. para Fdo. Pension C 76.265.736-8 2.661.385 0,72%
 50% 50% Banchile Corredores de Bolsa S.A. 96.571.220-8 2.204.387 0,60%
 AFP Provida S.A. para Fdo. Pension B 76.265.736-8 1.460.843 0,40%
 Principales accionistas al 31 de diciembre de 2024 333.415.237 90,23%
 Fuente: DCV Registros.
 (1) Inversiones y Rentas S.A. ejerce el control sobre Inversiones IRSA Limitada. Inversiones y Rentas S.A. posee, directa e
 indirectamente a través de Inversiones IRSA Limitada, el 65,87%de las acciones de CCU S.A.
(1) Al 31 de diciembre 2024, IRSA poseía directamente el 59,028% del capital de CCU S.A. y el 6,842% a través de Inversiones IRSA
 Ltda., un vehículo en el que detenta el 99,9% de propiedad.
(2) En Estados Unidos, las acciones de CCU S.A. que se cotizan en ADRs en el New York Stock Exchange (NYSE). No tenemos conocimiento que existan personas naturales que posean menos de un 10% del
(3) Acciones de CCU S.A. que cotizan en el mercado local, en la Bolsa de Comercio de Santiago, Bolsa de Valores y en la Bolsa
 Electrónica de Chile, Bolsa de Valores. Al 31 de diciembre 2024, los bancos custodios locales por cuenta de inversionistas capital y que, en conjunto con su cónyuge y/o parientes, posean más de dicho porcentaje, ya sea
 extranjeros poseían un 5,577% de participación directa en la propiedad de CCU S.A. con un total de 20.607.328 acciones y los directamente o a través de personas jurídicas.
 Fondos de Pensiones (AFP) chilenos en conjunto el 4,189% de participación directa en la propiedad de CCU S.A. con 15.477.042
 acciones.
Memoria Integrada 2024 / 2.3 Propiedad y control 29

[pág. 31]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
2.3.4 Acciones, sus características y derechos
Al 31 de diciembre de 2024, el total de acciones suscritas y pagadas asciende a 369.502.872. El número Dividendos
de acciones de serie única no experimentó cambios en el ejercicio y el número total de accionistas Monto CLP por
registrados es de 3.704. Fecha Tipo/N° Utilidad año
 (M CLP) acción
 28 noviembre 2024 Provisorio 269 43.416.587 117,5 2024
Política de dividendos
 30 abril 2024 Definitivo 268 31.430.069 85,06042 2023
La política de dividendos que espera cumplir CCU S.A. en ejercicios futuros informada por el Directorio
 29 noviembre 2023 Provisorio 267 31.961.655 86,49907 2023
en la última Junta Ordinaria de Accionistas, celebrada el día 17 de abril de 2024, consiste en un reparto
en dinero de al menos el equivalente al 50% de la utilidad líquida de cada ejercicio social, a pagarse 27 abril 2023 Definitivo 266 9.164.340 24,80181 2022
anualmente, una vez aprobado los Estados Financieros Consolidados del ejercicio correspondiente
por la Junta Ordinaria de Accionistas, haciendo presente que de conformidad con lo dispuesto 29 diciembre 2022 Provisorio 265 49.919.838 135,1 2022
en el artículo 78 de la Ley N° 18.046 sobre Sociedades Anónimas, las utilidades deben destinarse
primeramente a absorber las pérdidas acumuladas, por lo cual el reparto queda condicionado a la 28 abril 2022 Definitivo 264 73.900.574 200 2021
utilidad líquida que efectivamente se obtenga. De esta manera, si una vez absorbidas las pérdidas
acumuladas existiere un remanente, sobre dicho saldo se aplicará la política recién expuesta. Esta 3 de diciembre 2021 Eventual 263 165.167.784 447 Acumuladas
política de dividendos corresponde a la intención del Directorio, por lo cual su cumplimiento queda
condicionado a las utilidades que realmente se obtuvieren. 29 de octubre 2021 Provisorio 262 73.900.574 200 2021
La Utilidad líquida distribuible del ejercicio finalizado al 31 de diciembre de 2024 alcanzó a 23 de abril 2021 Definitivo 261 51.422.045 139,16548 2020
CLP 160.944.137.431, por consiguiente, el reparto del Dividendo Provisorio N° 269 de CLP 117,5
por acción (CLP 235,00000 por ADR), totalizando un monto de CLP 43.416.587.460, pagado el 28 de 30 de diciembre 2020 Provisorio 260 20.692.161 56 2020
noviembre de 2024, equivale a 26,98% de dicha utilidad.
Memoria Integrada 2024 / 2.3 Propiedad y control 30

[pág. 32]
Capítulos / 1 2 Perfil de la entidad 3 4 5 6 7 8 9 10 11 12
Información bursátil 2.3.5 Otros Valores
Las acciones de CCU S.A. se transan en la Bolsa de Comercio de Santiago, Bolsa de Valores desde el
año 1920. El código nemotécnico para dicha bolsa es “CCU”. Los títulos accionarios de CCU S.A. se CCU S.A., es un emisor de ADRs, que actualmente se transan en el NYSE (CCU S.A. estuvo listado en
transan, así mismo, en la Bolsa Electrónica de Chile, Bolsa de Valores. NASDAQ entre 1992 y 1999). Un ADR es equivalente a 2 acciones ordinarias de CCU S.A. El código
 nemotécnico para el NYSE es “CCU” y el banco depositario de los ADRs es JPMorgan Chase Bank N.A.
Adicionalmente, como se describe a continuación, CCU S.A. transa ADRs en el New York Stock Exchange Al cierre de diciembre de 2024, la capitalización bursátil del programa de ADRs de CCU S.A. ascendió
(NYSE) desde el año 1999. a aproximadamente USD 310 millones y representó el 14,57% de la propiedad de la misma.
 Total Transacciones 2024 La Compañía a su vez, para financiar sus operaciones y mantener una adecuada estructura de capital,
 emite deuda en forma de bonos tanto en mercados locales como internacionales(1).
 Precio
 Bolsa Cantidad Monto (1) Para información de estos instrumentos ver la Nota 21 “Otros Pasivos Financieros” de nuestros Estados Financieros Consolidados
 Cierre (1)
 Mayor Medio Menor correspondientes al ejercicio terminado al 31 de diciembre de 2024.
 De Santiago Cifras en CLP
 1° Trimestre 20.365.704 115.539.058.484 5.817,00 5.900,10 5.682,29 5.363,20
 2° Trimestre 18.465.960 106.765.782.994 5.385,00 6.139,40 5.748,56 5.280,00
 3° Trimestre 26.214.176 135.486.899.021 5.300,00 5.753,00 5.205,95 4.769,00
 4° Trimestre 22.730.429 126.543.306.347 5.739,90 5.925,00 5.511,57 5.065,60
 Electrónica Cifras en CLP
 1° Trimestre 2.182.514 12.329.565.472 5.799,20 5.860,00 5.635,04 5.418,00
 2° Trimestre 2.859.270 16.551.284.356 5.840,80 6.067,20 5.774,08 5.290,00
 3° Trimestre 3.091.898 15.817.810.948 5.353,30 5.740,00 5.158,99 4.824,40
 4° Trimestre 4.271.310 23.820.489.746 5.610,00 5.853,40 5.556,97 5.115,10
 NYSE Cifras en USD(2)
 1° Trimestre 10.347.611 123.440.319 11,99 13,05 11,93 11,15
 2° Trimestre 6.451.935 79.276.602 11,38 13,74 12,29 11,20
 3° Trimestre 12.784.466 139.459.694 11,63 12,52 10,91 10,00
 4° Trimestre 10.442.756 118.592.518 11,33 11,97 11,36 10,65
(1) Día de cierre del trimestre.
(2) La cantidad se refiere al número de ADR transados. Los precios están expresados en USD y corresponde al valor de un ADR.
Memoria Integrada 2024 / 2.3 Propiedad y control 31

[pág. 33]
3
 Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 3.1 Marco de gobernanza 33
 3.2 Directorio 37
 Gestión del Directorio 37
 Matriz de conocimiento y experiencia
 del Directorio 41
 Declaración de responsabilidad 45
 Remuneración al Directorio 46
 Visitas a terreno 49
 3.3 Comités del Directorio 50
 3.4 Ejecutivos Principales 55
 3.5 Adherencia a códigos nacionales o
 internacionales 58
 3.6 Gestión de riesgos y control interno 59
 3.6.1 Gestión de riesgos 59
 3.6.2 Control interno 68
 3.7 Relación con los grupos de interés y
 Gobierno
 el público en general 70
 3.7.i Grupos de interés 70
 3.7.ii Estudio de Doble Materialidad 75
 3.7.iii Procedimiento de Elección de Directores 76
 corporativo
 3.7.iv Participación en Juntas de Accionistas 76
Memoria Integrada 2024 32

[pág. 34]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
3.1 Marco de gobernanza SER
 Marco de gobernanza
El Gobierno Corporativo de CCU constituye una de las mayores fortalezas de la Compañía, pues cuenta
con un Directorio de vasta experiencia y diversas instancias de control y gestión interno, tales como Código de Conducta del Directorio
el Comité de Directores, el Comité de Auditoría y el Comité de Dirección, donde participan todos los
Ejecutivos Principales, entre otros. Junto con ello, contamos con códigos, políticas y procedimientos
robustos que permiten la implementación de nuestra estrategia, la identificación y mitigación de los
 Directorio
 Modelo de Prevención
 Auditoría Externa
principales riesgos del negocio y la creación de valor sostenible para nuestros grupos de interés. Comité de Directores de Delitos
 Comité de Auditoría
Asimismo, todas las actividades que realizamos, y que dan forma a nuestro gobierno corporativo,
se enmarcan dentro del SER CCU y las “9Ps” que lo componen, que como detallamos en la sección
 Comité de Conducta en
“2.1 Propósito y valores” , define la identidad de nuestra Compañía. los Negocios Estrategia de Sustentabilidad
 Comité
La máxima instancia administrativa de toma de decisiones de CCU S.A. es el Directorio, que la Gestión de Riesgos de Auditoría Interna
representa judicial y extrajudicialmente, para lo cual está investido de todas las facultades de Dirección
administración y disposición que la ley o los estatutos no establezcan como privativas de la Junta de Comité de Crisis Relación con Inversionistas
Accionistas. Dicho órgano, de acuerdo a sus estatutos, está constituido por nueve miembros elegidos
en Junta de Accionistas, quienes durarán tres años en sus funciones, pudiendo ser reelegidos Trabajadores
indefinidamente. Las reuniones del Directorio se constituyen con la asistencia de seis directores
y los acuerdos se adoptan por mayoría absoluta de los directores asistentes con derecho a voto,
salvo los casos en que la normativa aplicable establezca un quorum superior. Quien preside la Conforme a lo establecido por la Ley N° 18.046 sobre Sociedades Anónimas, existe un Comité
sesión no tendrá voto dirimente en caso de empate. de Directores formado por tres miembros, uno de ellos independiente, entre cuyas principales
 funciones se encuentra examinar los informes de los auditores externos, el balance y los Estados
El actuar de los directores en el ejercicio de sus funciones debe guiarse por el Código de Conducta Financieros Consolidados y examinar los antecedentes de operaciones entre partes relacionadas.
del Directorio, el cual establece, además de principios, ciertos procedimientos, políticas y buenas (Ver sección “3.3 Comités del Directorio”).
prácticas de gobierno corporativo aplicables transversalmente a la Compañía. Este Código
de Conducta del Directorio contiene un capítulo sobre conflicto de interés. Dicho Código se Adicionalmente, y en cumplimiento a las regulaciones de la Securities Exchange Act de 1934, la
complementa y debe interpretarse en conformidad a la legislación vigente, en particular la Ley Sarbanes Oxley Act de 2002 (Ley SOX) y de la normativa dictada al respecto por la Securities and
N° 18.046 sobre Sociedades Anónimas y su Reglamento, la Ley N° 18.045 de Mercado de Valores Exchange Commission (SEC) y del NYSE, que es aplicable a CCU S.A. en tanto emisor de ADRs que se
y la Ley N° 20.393 sobre Responsabilidad Penal de las Personas Jurídicas, así como la regulación transan en el NYSE, existe un Comité de Auditoría. Este Comité está integrado por dos directores
impartida por las entidades públicas correspondientes, en especial de la CMF, y la normativa, independientes, de acuerdo al criterio establecido en la citada normativa. Sus funciones dicen
políticas y procedimientos internos de la Compañía, incluyendo los Estatutos sociales vigentes y relación con la supervisión de los procesos de informes financieros y contables de CCU S.A. y de
el Manual de Manejo de Información de Interés para el Mercado (MMIIM). las auditorías de los Estados Financieros Consolidados.
Memoria Integrada 2024 / 3.1 Marco de gobernanza 33

[pág. 35]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
A continuación, comentamos los principales componentes del Gobierno Corporativo:
 Modelo de Prevención de Delitos Comité de Dirección
CCU cuenta con un Modelo de Prevención de Delitos cuya gestión es reportada semestralmente al El máximo órgano ejecutivo en CCU S.A. es el Comité de Dirección, conformado por los Ejecutivos
Directorio por el Encargado de Prevención de Delitos. (Política de Prevención de Delitos CCU S.A. y Principales (Alta gerencia), quienes son todos los reportes directos del Gerente General, siendo
sus filiales). presidido por éste. Dicho Comité sesiona mensualmente para, entre otras funciones, elaborar y
 luego implementar el Plan Estratégico de CCU, una vez que éste es aprobado por el Directorio.
Para resguardar la libre competencia, CCU cuenta con un Programa de Cumplimiento de la (Ver sección “3.3 Comités del Directorio” y Capítulo “4 Estrategia”).
Libre Competencia que considera actividades de prevención, detección, respuesta y monitoreo.
Este Programa está a cargo de la Gerencia de Cumplimiento, la que depende de la Gerencia de
Asuntos Legales. Código de Conducta en los Negocios
 CCU cuenta con un Código de Conducta en los Negocios, que establece los principios éticos
 que orientan la actitud y conducta de cada uno de los integrantes de la Compañía. Este Código
 establece un conjunto de criterios, normas, pautas y reglas que deben ser observados por todos los
 trabajadores de CCU, es aplicable para CCU S.A. y todas sus filiales y es aprobado por el Directorio.
 Entre estos, se establecen los lineamientos de la Compañía para detectar y gestionar los conflictos
 de interés, el cual se complementa con el procedimiento de “Declaración Conflicto de Intereses”, que
 debe ser completada por todos los trabajadores al ingresar a CCU y ser actualizada cada vez que
 esta situación cambie o al menos una vez al año. Las normas de este Código complementan, pero
 no reemplazan, las disposiciones contenidas en los respectivos Reglamentos Internos y Políticas
 y Procedimientos de la Compañía, los que son igualmente aplicables a todos los trabajadores. El
 Código de Conducta en los Negocios se encuentra disponible en www.ccu.cl (Ver sección “3.6.2
 Control interno”).
 Gestión de Riesgos Estratégicos
 El Proceso de Gestión de Riesgos Estratégicos (Proceso GRE), es gestionado por el Contralor
 General de CCU S.A. e involucra a toda la Alta gerencia de CCU. Para esta revisión, se consideran los
 Objetivos Estratégicos de CCU 2025 – 2027 y riesgos globales de diferentes fuentes. (Ver sección
 “3.6.1 Gestión de riesgos”).
Memoria Integrada 2024 / 3.1 Marco de gobernanza 34

[pág. 36]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 Sustentabilidad
CCU tiene tres Pilares Estratégicos, Rentabilidad, Crecimiento y Sustentabilidad. De este modo, problemas complejos del negocio. Así, bajo este alero de innovación hemos desarrollado herramientas
integramos los desafíos de un desempeño económico, ambiental y social, los cuales están al centro con foco en la optimización y eficiencia en el proceso de venta a nuestros clientes, y la ampliación de
de su actividad. Esto está alineado con la búsqueda continua de un balance adecuado de generación nuestras plataformas de comercio electrónico, con el fin de mejorar la experiencia de nuestros clientes
de valor a corto, mediano y largo plazo, teniendo en consideración la búsqueda constante de un y consumidores, destacando en esto último la plataforma B2B “Mi Carro”, orientada a nuestros clientes
mejor vivir de las personas y el planeta. En esta línea, contamos con un Comité de Sustentabilidad, minoristas, y “La Barra” nuestro canal de venta e-commerce, con un creciente foco regional.
órgano de gobernanza que dirige y articula transversalmente todas las agendas de la Estrategia de
Sustentabilidad “Juntos por un Mejor Vivir”, el cual es presidido por la Gerencia de Asuntos Corporativos Adicionalmente, la Compañía desarrolla algunas iniciativas como “Innpacta”, programa regional de
y Sustentabilidad y cuyo vicepresidente es el Contralor General, además de contar con la participación innovación abierta, que busca identificar startups del mundo que estén desarrollando soluciones
del Gerente General y el Gerente Corporativo de Administración y Finanzas, entre otros miembros. tecnológicas e innovadoras a desafíos relevantes para CCU; y “Despega”, programa que busca
Este Comité cumple un rol clave en la Compañía, en donde se revisan los avances, se explican las fomentar la creatividad y colaboración en la Compañía, implementar herramientas para detectar
brechas y se comunican los planes de acción, velando por apoyar la gestión y cumplimiento de la necesidades, impulsar proyectos innovadores y potenciar la productividad en CCU.
Estrategia de Sustentabilidad. (Ver sección “9.1 Estrategia de Sustentabilidad”).
 Investigación y desarrollo
La innovación es un motor fundamental para desarrollar exitosamente nuestra estrategia en un entorno
altamente competitivo. Si bien la innovación es parte de nuestro quehacer diario y está presente en
todas las áreas de la Compañía, identificamos 4 tipos de innovación que son cruciales para nuestra
estrategia: innovación de productos, innovación disruptiva, innovación incremental e innovación social.
El concepto de innovación disruptiva enmarca nuestra inversión en investigación y desarrollo, ya que
a través de la tecnología y el uso de datos buscamos generar resultados de alto impacto ya sea para
ingresar a nuevos mercados o para satisfacer nuevas necesidades de clientes y consumidores. Para
estos fines contamos con un fondo de innovación que nos permite asegurar el financiamiento de las
iniciativas más prometedoras. La Compañía cuenta también con un equipo dedicado a desarrollar
algoritmos de inteligencia artificial y minería de datos, aplicando tecnologías de frontera para resolver
Memoria Integrada 2024 / 3.1 Marco de gobernanza 35

[pág. 37]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 Grupos de interés
Para la Compañía es de suma importancia poder identificar nuestros grupos de interés y abordar
sus principales intereses, así como el impacto directo de las actividades de la Compañía en dichos
grupos. CCU identifica los temas de interés de sus distintas audiencias mediante estudios de
materialidad y mapeos y análisis de actores. Esta información nos permite entender de manera más
robusta nuestras temáticas de mayor impacto hacia nuestra operación y fuera de ella, impulsándonos
a establecer agendas concretas de acción. (Ver sección “3.7.i Grupos de interés”).
 Trabajadores
Como señalamos al comienzo de esta sección, nuestro Gobierno Corporativo se basa en la identidad
SER CCU, que guía la gestión de nuestros tres Pilares Estratégicos: Rentabilidad, Crecimiento y
Sustentabilidad. Esta identidad impulsa una operación que balancea el foco y las sinergias en una
multicategoría de marcas de bebestibles de valor, buscando la excelencia a través de procesos en
toda la organización. Seis procesos directivos estructuran especialmente la labor de las funciones
directivas: Plan Estratégico (incluyendo la Gestión de Riesgos Estratégicos), Modelo de Preferencia,
Recursos Humanos, Excelencia Operacional, Presupuesto Operativo y Presupuesto de Inversiones. La
identidad SER CCU, en conjunto con estos procesos y mecanismos de gestión de personas, fomenta
el desarrollo de la diversidad de nuestros trabajadores.
Memoria Integrada 2024 / 3.1 Marco de gobernanza 36

[pág. 38]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
3.2 Directorio
Gestión del Directorio
 Procedimiento de inducción
La Compañía cuenta con un procedimiento para la inducción de cada nuevo integrante del Directorio
de CCU S.A. y filiales que sean sociedades anónimas abiertas, que comprende reuniones con el
Gerente General, Gerente Corporativo de Administración y Finanzas, Gerente de Asuntos Legales,
Gerente de Asuntos Corporativos y Sustentabilidad y Contralor General. Sin perjuicio de lo anterior,
el director podrá solicitar y coordinar con el Gerente de Asuntos Legales reuniones con algún otro
gerente o ejecutivo principal.
Asimismo, como parte del proceso de inducción, se entrega a cada director un set de documentos
que comprenden las siguientes materias:
 • El propósito, promesa, principios organizacionales (SER CCU), los Objetivos Estratégicos que
 deben guiar el actuar de la Compañía, sus directores y trabajadores, los que se contienen en
 los siguientes documentos: Memoria Anual, Formulario 20-F presentado a la SEC, Código de
 Conducta del Directorio, Reglamento del Comité de Directores y de Auditoría, de ser aplicable,
 Código de Conducta en los Negocios, Plan Estratégico vigente y los Términos y Condiciones
 Generales de las Políticas Comerciales de CCU.
 • La identificación de los grupos de interés relevantes. (Ver sección “3.7.i Grupos de interés”).
 El marco jurídico vigente más relevante aplicable a la entidad, al Directorio y sus Ejecutivos Principales,
 en especial la Ley N° 18.046 sobre Sociedades Anónimas y su Reglamento, la Ley N° 18.045 de
 Mercado de Valores, y la Ley N° 20.393 sobre Responsabilidad Penal de las Personas Jurídicas,
 que contienen los deberes de cuidado, reserva, lealtad, diligencia e información que conforme a
 la legislación vigente recaen en cada integrante del Directorio.
 • Los Estados Financieros Consolidados trimestrales y anuales de CCU S.A. presentados a la CMF,
 con sus respectivas notas explicativas.
Memoria Integrada 2024 / 3.2 Directorio 37

[pág. 39]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 Asesorías del Directorio Asimismo, una vez aprobadas las actas por el Directorio y/o Comité respectivo, éstas son puestas a disposición
 de los directores en Diligent Boards para la suscripción de las mismas mediante firma electrónica, todo ello
El Directorio de CCU S.A. no cuenta con una política específica para la contratación de expertos conforme a lo dispuesto por la NCG N° 434 de la CMF. La referida plataforma tecnológica cuenta con un
que lo asesoren en materias contables, tributarias, financieras, legales u otras. La contratación de mecanismo de ordenamiento que facilita su indexación y búsqueda de información, manteniéndose el
asesores especialistas en las materias indicadas se analiza caso a caso por el Directorio de acuerdo registro histórico de tales actas y documentos desde su implementación el año 2018.
con la materia específica de que se trate, lo que permite actuar con mayor flexibilidad y dinamismo.
 A través de Diligent Boards no se permite el acceso directo al Canal de Denuncias con que cuenta la
En virtud de lo anterior, el Directorio podrá en todo momento requerir al Gerente General la Compañía, sin perjuicio de lo cual el Contralor General presenta un informe de las denuncias recibidas
contratación de una asesoría externa con la finalidad que el Directorio cuente con la opinión de y las acciones adoptadas al efecto al Comité de Auditoría de manera semestral, el cual es puesto a
uno o más terceros expertos en una denominada materia. Para estos efectos, el mismo Directorio disposición de los directores en Diligent Board en los plazos establecidos.
deberá en cada caso aprobar un presupuesto especial y elegir la empresa o persona natural que
prestará la citada asesoría.
 Diversidad del Directorio
Durante el año 2024, el Directorio no incurrió en gastos por concepto de asesorías. En consecuencia,
no existieron servicios de asesoría adicionales de la empresa de auditoría externa o de otras No hay Directores suplentes, todos los miembros del Directorio son titulares y ninguno está en
entidades contratadas con cargo al presupuesto anual del Directorio. situación de discapacidad.
 Periodicidad del Directorio y Diligent Boards Rango de edad Nacionalidad Antigüedad
 (país de origen)
En conformidad al artículo 81 del Reglamento de la Ley N° 18.046 sobre Sociedades Anónimas,
en las sociedades anónimas abiertas el Directorio debe celebrar sesiones ordinarias a lo menos
una vez al mes, cuyo calendario es acordado por el Directorio anualmente, procediéndose a su
 menos de 30 años - - Chile - 5 menos de 3 años 1 1
citación a través de la plataforma tecnológica Diligent Boards. Asimismo, se podrán celebrar sesiones
 entre 30 y 40 años - - entre 3 y 6 años
extraordinarias, las que deben ser citadas de conformidad a la Ley. El Directorio no ha determinado México - 1 - 1
un número mínimo de reuniones ordinarias, en forma adicional a lo establecido en la referida entre 41 y 50 años 1 - Italia 1 - más de 6 y menos de 9 años - 1
normativa, ni un tiempo promedio mínimo de dedicación presencial y remota de los directores a entre 51 y 60 años - 2 Francia - 1 entre 9 y 12 años - 2
las mismas, permitiendo de esta forma tener mayor flexibilidad y dinamismo en estas materias. entre 61 y 70 años - 5 Reino Unido - 1 más de 12 años - 3
 más de 70 años - 1
En relación a la plataforma tecnológica Diligent Boards, a través de la cual todos los directores tienen
acceso de manera segura, remota y permanente, con una antelación de a lo menos tres días, a las
actas y documentos tenidos a la vista para cada sesión de Directorio, y los miembros respectivos La remuneración de los miembros del Directorio es fijada por la Junta Ordinaria de Accionistas
a las actas y documentos del Comité de Directores, Comité de Auditoría y Comité Internacional. independiente del sexo, según lo indicado más adelante en la sección 3.2 Directorio - Remuneración
 al Directorio.
Memoria Integrada 2024 / 3.2 Directorio 38

[pág. 40]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
Reunión del Directorio de CCU S.A. con las unidades de gestión de riesgos,
auditoría interna y responsabilidad social, y empresa de auditoría externa • El Directorio se reúne dos veces al año con la Gerencia de Asuntos Corporativos y
 Sustentabilidad. La primera reunión se lleva a cabo a comienzos del año para aprobar el plan
 de donaciones del año en curso e informar sobre las donaciones realizadas el año anterior.
 El Directorio se reúne una vez al año con el Contralor General, responsable de la Gestión La segunda reunión tiene como objetivo revisar los asuntos relacionados con la Estrategia de
 de riesgos para analizar el Mapa de Riesgos Estratégicos de CCU y los Planes de Mitigación Sustentabilidad “Juntos por un Mejor Vivir”, incluyendo el eje Planeta y Personas, abordando
 para los riesgos más relevantes. temas ambientales y sociales, respectivamente.
 • El Directorio, a través del Comité de Auditoría, se reúne trimestralmente con el Gerente de • El Gerente Corporativo de Administración y Finanzas detalla al Directorio el cumplimiento
 Auditoría Interna, siendo las principales temáticas abordadas las siguientes: presentación del Balanced Scorecard en forma mensual, considerando las dimensiones de Rentabilidad,
 del Plan de Auditoría interna, auditorías con resultados deficientes, avances del Plan de Crecimiento y Sustentabilidad para cada mes y acumulado, comparado con el año anterior
 Auditoría interna y el resumen de las denuncias recibidas y finalizadas. y presupuesto.
 • El Comité de Directores y el Comité de Auditoría se reúnen a lo menos dos veces al año con la
 empresa de Auditoría Externa a cargo, entre otras materias, de la auditoría de los Estados
 Financieros Consolidados de CCU S.A. Las principales temáticas abordadas en tales sesiones
 son las siguientes: (i) examinar eventuales diferencias detectadas en la auditoría respecto
 de prácticas contables, sistemas administrativos y auditoría interna, (ii) evaluar eventuales
 deficiencias graves que se hubieran detectado y aquellas situaciones irregulares que por
 su naturaleza deban ser comunicadas a los organismos fiscalizadores competentes, y (iii)
 examinar los resultados del Plan Anual de Auditoría y los posibles conflictos de interés que
 puedan existir en la relación con la empresa de auditoría externa o su personal, tanto por
 la prestación de otros servicios a la Compañía o a las empresas de su grupo empresarial, u
 otras situaciones.
 Participan en dichas reuniones el Gerente General, el Contralor General, el Gerente Corporativo
 de Administración y Finanzas y el Gerente de Asuntos Legales; y tratándose de Gestión de riesgos,
 también los gerentes de las respectivas UACs.
Memoria Integrada 2024 / 3.2 Directorio 39

[pág. 41]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 Mejoramiento continuo Plan de continuidad operacional
En CCU no contamos con una autoevaluación regular del desempeño o un procedimiento formal La Compañía cuenta con un Manual de Crisis para CCU S.A. y sus filiales, el cual proporciona un
de detección de mejoras en el funcionamiento del Directorio y de sus Comités. En caso de resumen de los protocolos generales a seguir antes, durante y después de un incidente catalogado
requerirse, éstos son determinados por los mismos, de acuerdo a las necesidades que surjan y se como “Crisis” por la Compañía (un evento inesperado y no rutinario relacionado con las actividades
identifiquen, otorgando con ello mayor flexibilidad. Del mismo modo, el Directorio y sus Comités de CCU y/o su reputación, que crea un alto nivel de incertidumbre y de atención interna y/o externa).
determinan y definen las materias respecto de las cuales requieran capacitar a sus integrantes. El Asimismo, se describen los procedimientos específicos que deben ser ejecutados para cada tipo
Directorio también podrá determinar la necesidad de contar con una evaluación de su desempeño de Crisis.
y funcionamiento y el de sus Comités, así como la detección e implementación de mejoras o áreas
de fortalecimiento, por un experto ajeno a la Compañía. De acuerdo al Manual de Crisis, CCU cuenta con un equipo de trabajo denominado Comité de
 Crisis con funciones claramente definidas, incluyendo reemplazo para cada una de estas funciones.
En relación a la detección de eventuales barreras organizacionales, sociales o culturales, no se han Es responsabilidad del Gerente General conformar este Comité y designar un coordinador.
detectado barreras que pudieren estar inhibiendo la diversidad de capacidades, características Adicionalmente, se ha establecido el rol de Gestionador de Crisis, quien actuará como coordinador
y condiciones en la composición del Directorio y sus Comités. El Directorio adopta las prácticas y del Comité de Crisis en cada unidad. El plan de contingencia no incluye la continuidad del Directorio
efectúa la detección de mejoras para su funcionamiento, de acuerdo a las necesidades que surjan. en situaciones de Crisis, circunstancia en la cual se deberá aplicar la normativa vigente respecto
 a esta materia.
Con fecha 13 de abril de 2021 se publicó en el Diario Oficial la Ley Nº 21.314, que introduce modificaciones
a diversos cuerpos legales, incluyendo, entre otros la Ley N° 18.046 sobre Sociedades Anónimas,
estableciendo la obligación del Directorio de la matriz de una sociedad fiscalizada por la CMF de
establecer y difundir una política general de elección de directores en sus filiales que cumpla con
las menciones mínimas establecidas por la CMF, las que se contienen en la NCG N° 533 emitida
con fecha 11 de marzo de 2025. Dicha política deberá ser publicada a más tardar el 11 de diciembre
de 2025.
Memoria Integrada 2024 / 3.2 Directorio 40

[pág. 42]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
Matriz de conocimientos y experiencia del Directorio
Quisiéramos destacar que nuestro Directorio cuenta con una experiencia común en materia de seguimiento e impulso de nuestras iniciativas de la Estrategia de Sustentabilidad CCU, en especial las
metas de reducción de emisiones y de consumo de agua, valorización de residuos, como también materias relacionadas con los desafíos del relacionamiento comunitario, entre otras.
 Francisco Pablo Rodrigo Óscar Vittorio Carlos María
 Rory Marc
 Pérez Granifo Hinzpeter Hasbún Corbo Molina
 Cullinan Gross
 Gabriela Descripción
 Mackenna Lavín Kirberg Martínez Lioi Solís Cadenas
 Estrategia: experiencia y habilidades en materias de definición de misión, visión,
 Estrategia planificación y estructura para el cumplimiento del propósito y los objetivos de la
 organización.
 Relaciones de Relaciones de negocios: experiencia a nivel nacional e internacional, en la búsqueda
 negocios e identificación de oportunidades de negocios y socios estratégicos.
 Liderazgo: experiencia en armar, formar, influir, motivar y organizar equipos para la
 Liderazgo consecución de los objetivos corporativos estratégicos y alinear a los trabajadores
Experiencia, habilidades y conocimientos
 con la cultura y propósito de la Compañía.
 Finanzas, Finanzas, contabilidad y auditorías: conocimiento y experiencia en materia de
 contabilidad finanzas corporativas, contabilidad, tributaria, control interno, reportes financieros
 y auditorías y auditorías.
 Gobierno corporativo: conocimiento y experiencia en dirección, supervisión y
 Gobierno control de personas jurídicas, en el funcionamiento del gobierno corporativo, en
 corporativo libre competencia, en el modelo de prevención del delito y en la gestión de riesgos.
 Comunicaciones: experiencia en comunicación estratégica y en relacionamiento y
 Comunicaciones vinculación con diferentes stakeholders.
 Administración de riesgos: experiencia en identificación, prevención, control y
 Administración de mitigación de riesgos en diferentes ámbitos (financieros, operacionales, legales,
 riesgos reputacionales), a nivel global, país y de sectores de la economía.
 Ambiental: conocimiento y/o experiencia en normativas, gestión de proyectos, buenas
 Ambiental prácticas y tendencias en materias de protección y cuidado del medioambiente.
 Fusiones y Fusiones y adquisiciones: conocimiento y/o experiencia en fusiones y adquisiciones
 adquisiciones de empresas y en alianzas estratégicas.
 Ciberseguridad y Ciberseguridad y transformación digital: conocimiento y/o experiencia en dirección
 transformación y supervisión de la gestión de técnicas y sistemas de mitigación de riesgos que
 digital atenten contra la seguridad digital.
 Recursos humanos: experiencia en definición de directrices y políticas en materia
 Recursos humanos de gestión de recursos humanos y relaciones laborales.
 Industria de Industria de bebestibles: conocimiento y/o experiencia en empresas del rubro.
 bebestibles
Memoria Integrada 2024 / 3.2 Directorio 41

[pág. 43]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 Francisco Pérez Mackenna Carlos Molina Solís María Gabriela Cadenas
 Presidente Vicepresidente Director
 Director Titular Director Titular Director Titular
 Fecha de Fecha de Fecha de
 designación: 3 de julio 1998 (Director) designación: 11 abril 2012 (Director) designación: 5 de octubre 2022 (Director)
 29 de diciembre 2023 (Presidente) mayo 2018 (Vicepresidente)
 En CCU desde: febrero 1991 En CCU desde: abril 2012 En CCU desde: octubre 2022
Ingeniero Comercial de la Pontificia Universidad Católica de Chile Licenciado en Administración de Empresas, BBA de la Universidad Ingeniero de Sistemas de la Universidad Metropolitana de Caracas,
y MBA de la Universidad de Chicago, Estados Unidos. de Houston y MBA de la Universidad de Texas, Estados Unidos. Venezuela y MBA de la Universidad Politécnica de Madrid, España.
Fue designado Presidente del Directorio de Compañía Cervecerías Es miembro del Directorio de diversas filiales de Compañía Actualmente se desempeña como Senior Vice President Digital
Unidas S.A., luego de la renuncia del señor Andrónico Luksic Craig al Cervecerías Unidas S.A., incluyendo Cervecera CCU Chile Limitada, and Technology, Americas – The Heineken Company. También
cargo de director y Presidente de la misma. También es Presidente Embotelladoras Chilenas Unidas S.A., Compañía Cervecerías es miembro del Directorio de Cervecera CCU Chile Limitada y
del Directorio de Cervecera CCU Chile Limitada, Embotelladoras Unidas Argentina S.A., Viña San Pedro Tarapacá S.A. y Compañía Embotelladoras Chilenas Unidas S.A.
Chilenas Unidas S.A. y Compañía Cervecerías Unidas Argentina Pisquera de Chile S.A.
S.A. Adicionalmente, es miembro del Directorio de Viña San Pedro Más de 20 años de experiencia liderando la transformación de
Tarapacá S.A. y Compañía Pisquera de Chile S.A. Tiene más de 30 años de experiencia en administración y negocios en industrias como consultoría, telecomunicaciones,
 consultoría estratégica en múltiples industrias, especialmente servicios financieros, farmacéutica y consumo masivo. Cuenta con
Entre los años 1991 y 1998, fue el Gerente General de Compañía en bebestibles y productos para el consumo en América. En los un sólido historial de aceleración del crecimiento de las empresas
Cervecerías Unidas S.A. Actualmente, es Gerente General bebestibles sus roles han incluido Desarrollo de Negocios para mediante la combinación de tecnologías emergentes, optimización
de Quiñenco S.A., cargo que detenta desde el año 1998, y Heineken Americas B.V., Planificación y Estrategia para Femsa de procesos empresariales y servicios compartidos.
es miembro del Directorio de varias compañías, incluyendo Cerveza S.A. de C.V. y miembro del Directorio de Kaiser en Brasil.
Inversiones y Rentas S.A., Banco de Chile, Banchile Corredores de Ha sido reconocida en dos oportunidades por HITEC Top 50, como
Seguros Limitada, LQ Inversiones Financieras S.A., Sociedad Matriz Anteriormente fue socio de Booz, Allen & Hamilton, una compañía líderes de Tecnología y Transformación Digital Hispana.
SAAM S.A., Nexans S.A., Hapag Lloyd e Invexans Limited y ocupa global de consultoría comercial. Como tal, lideró esfuerzos de
el cargo de Presidente del Directorio de Compañía Sud Americana de estrategia y cadena de suministro en supermercados, empresas
Vapores S.A., Empresa Nacional de Energía Enex S.A., Invexans S.A. y de alimentos, bebidas de alta graduación y otras empresas de
de Tech Pack S.A. bienes de consumo.
Memoria Integrada 2024 / 3.2 Directorio 42

[pág. 44]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 Pablo Granifo Lavín Vittorio Corbo Lioi Marc Gross
 Director Director Director
 Director Titular Director Independiente Director Titular
 Fecha de Fecha de Fecha de
 designación: 3 de abril 2013 (Director) designación: 11 de abril 2012 (Director) designación: 6 de mayo 2020 (Director)
 En CCU desde: abril 2013 En CCU desde: abril 2012 En CCU desde: mayo 2020
Ingeniero comercial de la Pontificia Universidad Católica de Chile. Licenciado en Economía e Ingeniería Comercial de la Universidad de Chile Ingeniero de la Ecole Nationale Supérieure des Arts et Métiers de
 y Doctor en Economía del Instituto Tecnológico de Massachusetts (MIT). París, Francia y por la Universidad Técnica de Aachen, Alemania.
Es Presidente del Directorio de Viña San Pedro Tarapacá S.A.
desde el año 2013. Es miembro del Directorio de Cervecera CCU Es miembro del Comité de Directores de Compañía Cervecerías Unidas Es miembro del Directorio de Cervecera CCU Chile Limitada,
Chile Limitada, Embotelladoras Chilenas Unidas S.A. y Compañía S.A., en su calidad de director independiente, desde que fue elegido Embotelladoras Chilenas Unidas S.A. y Compañía Cervecerías
Cervecerías Unidas Argentina S.A. director en abril de 2012, del cual es actualmente Presidente. Es también Unidas Argentina S.A.
 miembro y Presidente del Comité de Auditoría desde abril de 2012.
Es Presidente del Directorio de Banco de Chile, Quiñenco S.A., Anteriormente se desempeñó en el Grupo Danone y Sara Lee. En
Banchile Asesorías Financieras S.A., Banchile Administradora General Fue Presidente del Banco Central de Chile entre los años 2003 y 2007, el año 1995, se incorporó a Heineken y ejerció en Grecia el cargo
de Fondos S.A. y Socofin S.A. También es miembro del Directorio y miembro del Consejo de Banco Santander S.A. (España) entre los de Gerente de Planta, para luego en el año 1999 convertirse en el
de Empresa Nacional de Energía Enex S.A. y Vicepresidente de años 2011 y 2014, Presidente del Directorio de Banco Santander Gerente Regional de Operaciones y Abastecimiento para Europa.
Compañía Sud Americana de Vapores S.A. Chile entre los años 2014 y 2018, y director del Grupo Santander- En el año 2002 asumió el cargo de Gerente General de Heineken
 México, del Banco Santander Chile, de ENDESA-Chile y de Seguros en los Países Bajos. En junio de 2005, fue nombrado Gerente
 Sura. Es también asesor económico de grandes empresas chilenas de Abastecimiento y miembro del Equipo Ejecutivo Global de
 y extranjeras y de family offices chilenas. Heineken. Durante los años 2010 a 2015 también fue Presidente
 de Empaque México.
 Fue alto ejecutivo del Banco Mundial en Washington, DC y director
 de su división de ajuste macroeconómico y crecimiento. Fue profesor Desde el año 2012 hasta el año 2017 se desempeñó también
 de Economía en Canadá, Estados Unidos y Chile. Ha llevado a cabo como director, no ejecutivo, de la empresa de alta tecnología
 numerosas consultorías al Banco Mundial, BID, US-AID, la agencia Keonys en Francia. Desde junio de 2020 es asesor principal del
 canadiense de desarrollo (CIDA), la agencia sueca de desarrollo (SIDA), Directorio Ejecutivo de SHV para sus operaciones globales.
 la fundación de estudios avanzados de desarrollo de Japón (FASID) y
 la OCDE. Fue también visiting scholar en Stanford University y en el
 Fondo Monetario Internacional (FMI).
Memoria Integrada 2024 / 3.2 Directorio 43

[pág. 45]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 Rodrigo Hinzpeter Kirberg Rory Cullinan Óscar Hasbún Martínez
 Director Director Director
 Director Titular Director Titular Director Titular
 Fecha de Fecha de Fecha de
 designación: 7 de julio 2015 (Director) designación: 9 de mayo 2018 (Director) designación: 29 de diciembre 2023 (Director)
 En CCU desde: julio 2015 En CCU desde: mayo 2018 En CCU desde: diciembre 2023
Abogado de la Pontificia Universidad Católica de Chile. Es miembro del Directorio de Cervecera CCU Chile Limitada y Ingeniero comercial de la Pontificia Universidad Católica de Chile.
 Embotelladoras Chilenas Unidas S.A.
Es miembro del Directorio de Cervecera CCU Chile Limitada, Es miembro del Directorio de Cervecera CCU Chile Limitada y
Embotelladoras Chilenas Unidas S.A. y Compañía Cervecerías Director de empresas con amplia experiencia en diversos países e Embotelladoras Chilenas Unidas S.A.
Unidas Argentina S.A. industrias, habiendo trabajado en Europa, África y América. Ocupó
 diversos cargos ejecutivos en el Royal Bank of Scotland (RBS), Es Gerente General de Compañía Sudamericana de Vapores S.A.
Se desempeña como director de Inversiones y Rentas S.A., Empresa incluyendo el de Presidente Ejecutivo de la Banca Corporativa desde el año 2012, director de Hapag-Lloyd AG desde el año 2014 y
Nacional de Energía Enex S.A., Enex Corp Ltd. (UK), Enex CL Ltd. (UK), y del Non Core Bank. En el RBS, ayudó a diseñar y ejecutar la presidente de su Comité de Auditoría. Es director de Sociedad Matriz
Invexans S.A., Invexans Limited (UK), Tech Pack S.A. y LQ Inversiones reestructuración de dicho banco durante la crisis financiera del SAAM S.A. desde el año 2015, y Presidente de su Directorio desde
Financieras S.A. año 2008, trabajando con el Ministerio de Economía y Finanzas agosto de 2017. También es director de Invexans S.A., Presidente del
 del Reino Unido y el Banco Central de Inglaterra. Con anterioridad, Comité Estratégico y de Sustentabilidad de Nexans S.A. (Francia) y
Desde el año 2014 es el Gerente Legal de Quiñenco S.A., Consejero como ejecutivo, se desempeñó en la industria de capital de consejero de SOFOFA desde el año 2017, asociación de la cual es su
de SOFOFA desde el año 2017, asociación de la cual es Presidente inversión en Europa y Rusia, y en la industria química y bancaria primer Vicepresidente desde el año 2023. En el año 2002 se integró al
del Capítulo Chile - Argentina, Presidente del Capítulo Chile - en África y Estados Unidos. En cargos no ejecutivos, ha trabajado Grupo Quiñenco, donde hasta el año 2011 administró las inversiones
Paraguay, y Presidente de la Comisión de Seguridad, todas de como miembro de Directorios o como Presidente de empresas de la familia Luksic en Croacia, principalmente en el rubro turístico e
dicha entidad gremial. Anteriormente fue Ministro del Interior de servicios de agua, productos químicos, comercio minorista, inmobiliario. Anteriormente fue parte del área ejecutiva de Michelin
(2010-2013) y luego Ministro de Defensa del Gobierno de Chile agricultura, inversión privada y servicios de arrendamiento de en Francia y Chile.
(2013-2014). aviones. Actualmente es el principal director independiente de
 Acuren Corporation, que cotiza en la bolsa de Nueva York (NYSE).
Memoria Integrada 2024 / 3.2 Directorio 44

[pág. 46]
Capítulos / 
 / 1
 1 2
 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 Corporativo 4 5 6 7 8 9 10 11 12
Declaración de responsabilidad
Los Directores y el Gerente General que suscriben esta Memoria por el ejercicio terminado al 31 de diciembre de 2024, declaran bajo juramento que el contenido de ella es veraz conforme a la
información que han tenido en su poder.
 Francisco Pérez Mackenna Carlos Molina Solís Óscar Hasbún Martínez Marc Gross María Gabriela Cadenas
 Presidente Vice Presidente Director Director Directora
 RUT: 6.525.286-4 RUT: 48.159.144-9 RUT: 11.632.255-2 Pasaporte Francés: Pasaporte Italiano:
 N°17FV23187 N° YB2020485
 Pablo Granifo Lavín Rodrigo Hinzpeter Kirberg Rory Cullinan Vittorio Corbo Lioi Patricio Jottar Nasrallah
 Director Director Director Director Gerente General
 RUT: 6.972.382-9 RUT: 7.016.591-0 RUT: 48.207.653-K RUT: 4.965.604-1 RUT: 7.005.063-3
La presente Declaración de Responsabilidad ha sido suscrita electrónicamente por los Directores y por el Gerente General mediante el uso de la plataforma tecnológica Diligent Boards que mantiene
CCU S.A.
 Santiago, marzo 2025.
Memoria Integrada 2024 / 3.2 Directorio 45

[pág. 47]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
Remuneración al Directorio
Conforme a lo acordado en la Junta Ordinaria de Accionistas de fecha 17 de abril de 2024, la los accionistas el o los dividendos según sea el caso. En el evento que los dividendos distribuidos
remuneración anual de los directores consiste en una dieta mensual de UF 100 brutas para cada exceda el 50% de la referida utilidad líquida distribuible, el porcentaje se calculará sobre un máximo
director y de UF 200 brutas para el Presidente, por asistencia al Directorio independiente del del 50% de dicha utilidad.
número de sesiones que se celebren en el período, más una cantidad equivalente al 3% de los
dividendos que se distribuyeren, para el Directorio en su conjunto, calculados sobre un monto Durante el año 2024, el Directorio incurrió en gastos por CLP 134.165 mil.
máximo equivalente al 50% de la utilidad líquida distribuible del ejercicio, a repartirse a razón de una
novena parte para cada director y en proporción al tiempo que cada uno hubiere servido el cargo De acuerdo a lo anterior, los directores percibieron durante los años 2024 y 2023 por concepto
durante el año 2024, que se pagará en la misma oportunidad en que se pusiere a disposición de de dieta y participación, respectivamente, las siguientes remuneraciones:
 2024 2023
 Director Participación por el ejercicio Participación por el ejercicio
 Dieta Dieta
 (Miles de CLP) Total 2024 2023 Total 2023 2022
 Andrónico Luksic Craig(1) - 68.102 - 68.102 50.378 184.627 106.539 78.088
 Francisco Pérez Mackenna 89.930 214.201 144.652 69.549 43.143 184.627 106.539 78.088
 Carlos Molina Solís 44.965 214.201 144.652 69.549 43.143 184.627 106.539 78.088
 Pablo Granifo Lavín 44.965 214.201 144.652 69.549 39.547 184.627 106.539 78.088
 José Miguel Barros van Hövell tot Westerflier(2) - - - - - 58.566 - 58.566
 Marc Gross 44.965 214.201 144.652 69.549 43.143 184.627 106.539 78.088
 Rodrigo Hinzpeter Kirberg 44.965 214.201 144.652 69.549 43.143 184.627 106.539 78.088
 Rory Cullinan 44.965 214.201 144.652 69.549 43.143 184.627 106.539 78.088
 Vittorio Corbo Lioi 44.965 214.201 144.652 69.549 43.143 184.627 106.539 78.088
 María Gabriela Cadenas(3) 26.235 214.201 144.652 69.549 25.215 126.061 106.539 19.522
 Óscar Hasbún Martínez 44.965 146.100 144.652 1.447 - - - -
 Total(4) 430.920 1.927.810 1.301.868 625.941 373.998 1.661.643 958.851 702.792
(1) El director Andrónico Luksic Craig presentó su renuncia al cargo de Presidente y director de CCU S.A., con efecto el 29 de diciembre de 2023.
(2) El director José Miguel Barros van Hövell tot Westerflier presentó su renuncia al cargo de director de CCU S.A. con efecto el 1 de octubre de 2022. La suma del año 2023 corresponde a la participación en las utilidades distribuidas del ejercicio 2022, pagadas en el año 2023.
(3) Las dietas y participaciones de la directora María Gabriela Cadenas son devengadas y no pagadas al 31 de diciembre de 2024 (pago efectuado con fecha 10 de enero de 2025).
(4) Los totales pueden no sumar por efecto de redondeo en los decimales.
Memoria Integrada 2024 / 3.2 Directorio 46

[pág. 48]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
Asimismo, los directores y Ejecutivos Principales de la matriz que más adelante se indican percibieron Embotelladoras Chilenas Unidas S.A.
durante los años 2024 y 2023, por el desempeño de su cargo de director en las empresas filiales 2024 2023
que se individualizan, las remuneraciones brutas, por concepto de dieta y participación, que se Director (Miles de CLP)
 Dieta Dieta
señalan a continuación: Andrónico Luksic Craig(1) - 7.263
 Francisco Pérez Mackenna 44.962 43.139
Compañía Cervecerías Unidas Argentina S.A.
 Carlos Molina Solís 44.962 43.139
 2024 2023 Pablo Granifo Lavín 44.962 43.139
 Director (Miles de CLP)
 Dieta Dieta
 Patricio Jottar Nasrallah 44.962 43.139
 Andrónico Luksic Craig (1)
 - 2.267
 Marc Gross 44.962 43.139
 Francisco Pérez Mackenna 42.136 20.114
 Rodrigo Hinzpeter Kirberg 44.962 43.139
 Carlos Molina Solís 42.136 20.114
 Rory Cullinan 44.962 43.139
 Patricio Jottar Nasrallah 42.136 20.114
 Rodrigo Hinzpeter Kirberg 42.136 20.114 María Gabriela Cadenas(2) 29.918 28.810
 Marc Gross 42.136 20.114 Óscar Hasbún Martínez 44.962 -
 Pablo Granifo Lavín 42.136 - Total 389.614 338.046
 Total 252.816 102.837 (1) El director Andrónico Luksic Craig presentó su renuncia al cargo de Presidente y director de Embotelladoras Chilenas Unidas
 S.A., con efecto el 29 de diciembre de 2023.
(1) El director Andrónico Luksic Craig presentó su renuncia al cargo de Presidente y director de Compañía Cervecerías Unidas (2) Las dietas y participaciones de la directora María Gabriela Cadenas son devengadas y no pagadas al 31 de diciembre de 2024
 Argentina S.A., con efecto el 29 de diciembre de 2023. (pago efectuado con fecha 10 de enero de 2025).
Compañía Pisquera de Chile S.A.
 Viña San Pedro Tarapacá S.A.
 2024 2023
 Director (Miles de CLP)
 Dieta Dieta 2024 2023
 Director (Miles de CLP)
 Francisco Pérez Mackenna 22.480 21.568 Dieta Participación Dieta Participación
 Carlos Molina Solís 22.480 21.568 Pablo Granifo Lavín 35.963 35.648 34.507 74.874
 Patricio Jottar Nasrallah 22.480 21.568 Carlos Molina Solís 17.983 17.824 15.791 37.437
 Total 67.440 64.704 Francisco Pérez Mackenna 17.983 17.824 17.254 37.437
 José Miguel Barros van Hövell tot Westerflier(1) - - - 37.437
Cervecería Kunstmann S.A.
 Patricio Jottar Nasrallah 17.983 17.824 17.254 37.437
 2024 2023 Total 89.912 89.120 84.806 224.622
Director (Miles de CLP)
 Dieta Dieta
 Patricio Jottar Nasrallah 5.223 5.028 (1) El director José Miguel Barros van Hövell tot Westerflier presentó su renuncia al cargo de director de CCU S.A. con efecto el
 1 de octubre de 2022. La suma del año 2023 corresponde a la participación en las utilidades distribuidas del ejercicio 2022,
 Matias Bebin Subercaseaux 3.376 - pagadas en el año 2023.
 Total 8.599 5.028
Memoria Integrada 2024 / 3.2 Directorio 47

[pág. 49]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
Cervecera CCU Chile Limitada
 2024 2023 2024 2023
 Director (Miles de CLP) Director (Miles de CLP)
 Dieta Dieta Dieta Participación Dieta Participación
 Andrónico Luksic Craig(1) - 14.508 Francisco Pérez Mackenna (1) - 58.696 21.568 65.649
 Francisco Pérez Mackenna 89.923 86.279 Vittorio Corbo Lioi 18.728 58.696 21.568 65.649
 Carlos Molina Solís 89.923 86.279 Carlos Molina Solís 18.728 58.696 21.568 65.649
 Pablo Granifo Lavín 89.923 86.279 Rodrigo Hinzpeter Kirberg 18.728 - - -
 Patricio Jottar Nasrallah 89.923 86.279 Total 56.184 176.088 64.704 196.947
 Rodrigo Hinzpeter Kirberg 89.923 86.279
 (1) El director Francisco Pérez Mackenna presentó su renuncia a la calidad de miembro del Comité de Directores con fecha 4 de
 Rory Cullinan 89.923 86.279 diciembre de 2023, en consideración a que a partir del 29 de diciembre de 2023 asumía la Presidencia del Directorio.
 Marc Gross 89.923 86.279
 María Gabriela Cadenas(2) 59.835 57.620 Remuneración por Comité Auditoría de CCU S.A.
 Óscar Hasbún Martínez 89.923 -
 Total 779.219 676.081 Conforme a lo acordado en la referida Junta Ordinaria de Accionistas de fecha 17 de abril de 2024,
 aquellos directores que forman parte del Comité de Auditoría, así como los designados en calidad
(1) El director Andrónico Luksic Craig presentó su renuncia al cargo de Presidente y director de Cervecera CCU Chile Limitada, de observadores del mismo, perciben una dieta mensual por asistencia, independiente del número
 con efecto el 29 de diciembre de 2023.
(2) Las dietas y participaciones de la directora María Gabriela Cadenas son devengadas y no pagadas al 31 de diciembre de 2024 de sesiones que se celebren en el período, ascendente a UF 50 brutas.
 (pago efectuado con fecha 10 de enero de 2025).
 2024 2023
 Director (Miles de CLP)
 Dieta Dieta
Asimismo, los directores de Compañía Cervecerías Unidas S.A. que más adelante se indican Vittorio Corbo Lioi 20.607 21.568
percibieron durante los años 2024 y 2023, por su participación en los Comités que se individualizan, Carlos Molina Solís 20.607 21.568
las remuneraciones brutas, por concepto de dieta y participación, que se señalan a continuación: Francisco Pérez Mackenna(1) - 21.568
 Rodrigo Hinzpeter Kirberg(1) 20.607 -
Remuneración por Comité de Directores de CCU S.A. Total 61.821 64.704
Conforme a lo acordado en la Junta Ordinaria de Accionistas de fecha 17 de abril de 2024, los (1) El director Francisco Pérez Mackenna presentó su renuncia a la calidad de observador del Comité de Auditoría con fecha 4 de
 diciembre de 2023, designándose en su reemplazo, en igual calidad, al director Rodrigo Hinzpeter Kirberg.
directores que integran el Comité de Directores perciben una dieta por asistencia, independiente del
número de sesiones que se celebren en el período, de UF 50 brutas, más lo que corresponda como
 Remuneración por Comité de Directores de VSPT
porcentaje de los dividendos en su calidad de director de CCU S.A., según se indica precedentemente,
hasta completar el tercio adicional que establece el artículo 50 bis de la Ley N° 18.046 y Circular 2024 2023
N° 1.956 de la CMF. Director (Miles de CLP)
 Dieta Dieta
 Francisco Pérez Mackenna 12.869 17.675
 Total 12.869 17.675
Memoria Integrada 2024 / 3.2 Directorio 48

[pág. 50]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
Visitas a terreno
Las visitas en terreno a las distintas dependencias e instalaciones de la Compañía para conocer el estado,
funcionamiento, principales funciones, preocupaciones, recomendaciones y mejoras, que en opinión de los
responsables de esas dependencias e instalaciones sería pertinente realizar para mejorar el funcionamiento
de las mismas, se determinan por el Directorio, de acuerdo a las necesidades que surjan.
Durante el año 2024, los miembros del Directorio de CCU S.A. realizaron las siguientes visitas a terreno:
 Ejecutivos Principales
 Director Operación visitada
 participantes en la visita(1)
 Planta No alcohólicas, Buenos Aires (Argentina):
 Marc Gross y Visita a las instalaciones industriales de Aguas de Origen S.A. y Juan Martin Vannicola y Julio
 Rory Cullinan reunión con el equipo directivo de CCU Argentina. Freyre.
 Fecha de visita: marzo 2024
 Patricio Jottar, Felipe Benavides,
 Plantas No alcohólicas y Planta Reciclaje, Renca Modelo
 Felipe Dubernet, Eduardo
 Pablo Granifo y y CirCCUlar, respectivamente (Santiago, Chile):
 Ffrench-Davis, Barbara Wolff, Juan
 Vittorio Corbo Visita de directores durante el evento de inauguración de la planta.
 Martin Vannicola, Antonio Cruz,
 Fecha de visita: mayo 2024
 Domingo Jiménez y Juan Boned.
 Planta No alcohólicas, San Antonio I y II (Paraguay):
 Carlos Molina y Sebastián Landi, Antonio Cruz y
 Visita a operaciones industriales y visita a mercado.
 Marc Gross Juan Martin Vannicola.
 Fecha de visita: mayo 2024
 Planta Cerveza, Sajonia y Planta No alcohólicos, San
 Rodrigo Antonio I (Paraguay): No participaron Ejecutivos
 Hinzpeter Visita a la operación de cerveza artesanal. Principales en esta visita.
 Fecha de visita: junio 2024
 Planta No alcohólicas, Pan de Azúcar (Uruguay):
 Francisco Pérez Visita a las instalaciones industriales. No participaron Ejecutivos
 Mackenna Principales en esta visita.
 Fecha de visita: julio 2024
 Plantas No alcohólicas, Embotelladora CCU Renca, Renca
 Modelo y Planta de Reciclaje, CirCCUlar (Santiago, Chile):
 Marc Gross Juan Martin Vannicola.
 Visita a las instalaciones industriales.
 Fecha de visita: octubre 2024
(1) Para mayor información sobre los cargos específicos de los Ejecutivos Principales nombrados, ver sección “3.4 Ejecutivos Principales”.
Memoria Integrada 2024 / 3.2 Directorio 49

[pág. 51]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
3.3 Comités del Directorio a los accionistas, y pronunciarse respecto de éstos en forma previa a su presentación a los
 accionistas para su aprobación;
 Proponer al Directorio nombres para los auditores externos y clasificadores privados de
Comité de Directores riesgo que serán sugeridos a la Junta de Accionistas respectiva. En caso de desacuerdo, el
 Directorio formulará una sugerencia propia, sometiéndose ambas a consideración de la
CCU S.A. cuenta con un Comité de Directores dando cumplimiento a lo previsto en el artículo 50 Junta de Accionistas;
bis de la Ley N° 18.046 sobre Sociedades Anónimas. Examinar los antecedentes relativos a las operaciones a que se refiere el Título XVI de
 la Ley N° 18.046 sobre Sociedades Anónimas y evacuar un informe respecto a esas
 Integrantes y funcionamiento operaciones. Una copia del informe será enviada al Directorio, en el cual se deberá dar
 lectura a éste en la sesión citada para la aprobación o rechazo de la operación respectiva;
En Sesión Extraordinaria de Directorio N° 2.198 de fecha 17 de abril de 2024, luego de la elección del Proponer al Directorio una política general de manejo de conflictos de interés, y pronunciarse
Directorio de Compañía Cervecerías Unidas S.A. efectuada en la 121ª Junta Ordinaria de Accionistas acerca de las políticas generales de habitualidad establecidas de conformidad a lo dispuesto
celebrada con igual fecha, el director independiente señor Vittorio Corbo Lioi designó a los directores en el inciso segundo del artículo 147 de la Ley N° 18.046 sobre Sociedades Anónimas;
señores Carlos Molina Solís y Rodrigo Hinzpeter Kirberg (no independientes) para integrar el Comité de Examinar los sistemas de remuneraciones y planes de compensación de los gerentes,
Directores conforme a lo establecido en el artículo 50 bis de la Ley N° 18.046 y Circular N° 1.956 de la Ejecutivos Principales y trabajadores de Compañía Cervecerías Unidas S.A.;
CMF. En Sesión del Comité de Directores N° 277 celebrada el día 6 de mayo de 2024, los miembros del Preparar un informe anual de su gestión, en que se incluyan sus principales recomendaciones
referido Comité resolvieron designar a don Vittorio Corbo Lioi como Presidente del Comité de Directores. a los accionistas;
 Informar al Directorio respecto de la conveniencia de contratar o no a la empresa de auditoría
Durante el año 2023, el Comité de Directores estuvo compuesto por los señores Vittorio Corbo externa para la prestación de servicios que no formen parte de la auditoría externa, cuando
Lioi (independiente) y los directores señores Francisco Pérez Mackenna y Carlos Molina Solís (no ellos no se encuentren prohibidos de conformidad a lo establecido en el artículo 242 de la
independientes), hasta la renuncia presentada por el director señor Pérez a su calidad de miembro Ley N° 18.045 de Mercado de Valores, en atención a si la naturaleza de tales servicios pueda
del Comité de Directores en Sesión Ordinaria de Directorio N° 2.193 de fecha 4 de diciembre de 2023, generar un riesgo de pérdida de independencia; y
designándose en su reemplazo al director señor Rodrigo Hinzpeter Kirberg (no independiente). Las demás materias que señale el estatuto social, o que le encomiende una Junta de
 Accionistas o el Directorio, en su caso.
El Comité de Directores sesiona en la medida que requiera conocer alguna materia propia de sus
funciones y reporta al Directorio en la siguiente sesión, según corresponda, las materias específicas Actividades Realizadas
que haya conocido.
 El Comité de Directores sesionó en 13 oportunidades entre enero de 2024 y marzo de 2025,
 Funciones levantándose actas de cada reunión y reportando al Directorio, en la siguiente sesión según
 corresponda, las materias específicas que haya conocido. En el ejercicio de sus funciones, el Comité
Las funciones del Comité de Directores están establecidas en el artículo 50 bis de la Ley N° 18.046 de Directores se reunió regularmente con los gerentes de Compañía Cervecerías Unidas S.A. y
sobre Sociedades Anónimas, y son las siguientes: con la empresa de auditoría externa, a fin de tratar los temas relevantes de su competencia.
 Examinar los informes de los auditores externos, el balance y demás estados financieros En este ámbito, y dando cumplimiento a las obligaciones dispuestas en el artículo 50 bis de
 presentados por los administradores o liquidadores de Compañía Cervecerías Unidas S.A. la Ley N° 18.046 sobre Sociedades Anónimas, las materias analizadas y principales actividades
Memoria Integrada 2024 / 3.3 Comités del Directorio 50

[pág. 52]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
efectuadas por el Comité de Directores durante el ejercicio 2024 y hasta marzo 2025, fueron las Revisión del informe de los pagos efectuados a la empresa de auditoría externa durante los años
siguientes: 2023 y 2024;
 Revisión y análisis de los Estados Financieros Consolidados trimestrales y anuales previo a su Propuesta al Directorio, para ser sometida a consideración de la Junta Ordinaria de Accionistas a
 examen por el Directorio; celebrarse el año 2025, respecto de las empresas de auditoría externa y clasificadoras de riesgo;
 Revisión de la cuenta de las fiscalizaciones efectuadas por el Servicio de Impuestos Internos y de Aprobación de la contratación de servicios fuera de auditoría a ser prestados por la empresa de
 las reorganizaciones de activos de que fue objeto Compañía Cervecerías Unidas S.A. durante el auditoría externa; y
 año 2023 y 2024; Examen de los términos y condiciones de las siguientes operaciones con partes relacionadas de
 Revisión y análisis de la adecuación de la Política de Operaciones Habituales entre Partes Compañía Cervecerías Unidas S.A. y sus filiales o modificación de las existentes, para ser sometidas
 Relacionadas de Compañía Cervecerías Unidas S.A. a la Norma de Carácter General N° 501 de la a consideración del Directorio, conforme al Título XVI de la Ley N° 18.046:
 CMF que establece las menciones mínimas que deberá contener dicha política;
 Revisión y examen del otorgamiento de una garantía personal por parte de Compañía Cervecerías AA Examinó los antecedentes de las siguientes operaciones con partes relacionadas no
 Unidas S.A. a su filial CCU Inversiones II SpA para que esta garantice a banco Itaú Colombia o comprendidas en el párrafo B siguiente, previo a su examen y aprobación por el Directorio:
 Scotiabank Colombia, a través de la emisión de cartas de crédito stand-by por banco Itaú Chile o a) Servicios publicitarios adicionales con la plataforma de Canal 13, para el periodo junio 2023
 Scotiabank Chile, el refinanciamiento de los créditos bancarios otorgados por Scotiabank Colombia – mayo 2024, respecto de las sociedades Cervecera CCU Chile Limitada y Embotelladoras
 a Central Cervecera de Colombia S.A.S.; Chilenas Unidas S.A.;
 Se reunió con la empresa de auditoría externa, socio a cargo y equipo de auditoría, para interiorizarse b) Cesión de créditos de Heineken Brouwerijen B.V. a Compañía Cervecerías Unidas S.A.
 de las actividades que éstos realizan, particularmente la revisión del informe de la empresa de por concepto de royalties adeudados al 12 de diciembre de 2023 por la filial argentina
 auditoría externa respecto de los resultados de la auditoría del año 2023, el Plan de Auditoría Compañía Industrial Cervecera S.A.;
 integrada para los procesos de revisión de Estados Financieros Consolidados al 31 de diciembre c) Servicios publicitarios con la plataforma de Canal 13, para los servicios correspondientes
 2024, composición del equipo de trabajo de auditoría externa y el respectivo cronograma anual al periodo junio 2024 - mayo 2025, respecto de las sociedades Cervecera CCU Chile
 de trabajo a ejecutarse durante el año 2024, declaración de independencia, plan de comunicación Limitada, Embotelladoras Chilenas Unidas S.A., Aguas CCU-Nestlé Chile S.A., Compañía
 con el Comité y la revisión y seguimiento a la Carta de Control Interno para el año 2023; Pisquera de Chile S.A., Viña San Pedro Tarapacá S.A., Compañía Cervecerías Unidas S.A.,
 Revisión y análisis de las adecuaciones implementadas en el Modelo de Prevención de Delitos Manantial S.A. y La Barra S.A.;
 de Compañía Cervecerías Unidas S.A. y filiales a propósito de la entrada en vigencia de la d) Modificación del Supply Agreement entre Heineken Brouwerijen B.V. y Cervecera CCU Chile
 Ley N° 21.595 que modifica la ley de responsabilidad jurídica de las empresas; Limitada y de los Trade Mark License Agreement de las marcas Amstel y Sol vigentes entre
 Tomó conocimiento de la no existencia de cambios en los criterios y políticas contables utilizados Heineken Brouwerijen B.V. y Bebidas del Paraguay S.A. para efectos de permitir la exportación
 en la confección de los Estados Financieros Consolidados de Compañía Cervecerías Unidas S.A. y de tales productos de Cervecera CCU Chile Limitada a Bebidas del Paraguay S.A.;
 filiales y de la no existencia de cambios en la política de provisiones en la confección de los mismos; e) Suscripción de contratos de auspicio con Fundación Teletón para las marcas Cristal, Cachantun,
 Revisión del informe de provisiones de grandes clientes; Watt’s y Bilz y Pap. Se incluye campaña Bilz y Pap de reciclaje y la “Campaña 1+1”;
 Revisión y acuerdo de mantener durante al año 2024 la política de cobertura de tipo de cambio f) Servicios publicitarios con plataforma de Canal 13 para el periodo enero 2025 – diciembre
 vigente; 2025, respecto de las sociedades Cervecera CCU Chile Limitada, Embotelladoras Chilenas
 Análisis y revisión del sistema de remuneraciones y compensaciones a gerentes, Ejecutivos Unidas S.A., Aguas CCU-Nestlé Chile S.A., Compañía Pisquera de Chile S.A., Viña San Pedro
 Principales y trabajadores; Tarapacá S.A., Compañía Cervecerías Unidas S.A., Manantial S.A. y La Barra S.A.; y
 g) Donación a la Fundación Guillermo Luksic, ligada a la familia Luksic.
Memoria Integrada 2024 / 3.3 Comités del Directorio 51

[pág. 53]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 B Tomó conocimiento trimestralmente de las operaciones efectuadas por Compañía
 Cervecerías Unidas S.A. que, conforme a la Política de Operaciones Habituales entre
 Comité de Auditoría
 Partes Relacionadas, sean ordinarias en consideración al giro social, previo a su
 modificación de conformidad a lo dispuesto en la Norma de Carácter General N° 501 Integrantes y funcionamiento
 de la CMF, aprobada por el Directorio de Compañía Cervecerías Unidas S.A. con fecha 7
 de agosto de 2024, pasando dicho reporte a ser de carácter semestral a contar del 1 de En Sesión Extraordinaria de Directorio N° 2.198 de fecha 17 de abril de 2024, y luego de la elección del
 septiembre de 2024, fecha de entrada en vigencia de la misma. Directorio de Compañía Cervecerías Unidas S.A. efectuada en la 121ª Junta Ordinaria de Accionistas
 celebrada con igual fecha, el Directorio acordó que el Comité de Auditoría estuviera integrado por
Durante el año 2024 no hubo propuestas efectuadas por el Comité de Directores al Directorio de los directores señores Vittorio Corbo Lioi y Carlos Molina Solís, quienes cumplen con los criterios de
Compañía Cervecerías Unidas S.A. que no hubiesen sido recogidas por este último. independencia establecidos en la Securities and Exchange Act de 1934, Sarbanes-Oxley Act de 2022
 (Ley SOX) y las normas de gobierno corporativo del NYSE, participando en calidad de observador el
 Honorarios y Gastos director señor Rodrigo Hinzpeter Kirberg. En Sesión del Comité de Auditoría N° 185 celebrada el día
 6 de mayo de 2024, los miembros del referido Comité resolvieron designar al director señor Vittorio
Los directores integrantes del Comité percibieron la dieta determinada por la 121ª Junta Ordinaria de Corbo Lioi como Presidente del Comité de Auditoría.
Accionistas celebrada el 17 de abril de 2024, esto es, una dieta mensual por asistencia, independiente
del número de sesiones que se celebren en el periodo, de UF 50 brutas, más lo que le corresponda Durante el año 2023, el Comité de Auditoría estuvo integrado por los directores señores Vittorio
como porcentaje de los dividendos en su calidad de director de Compañía Cervecerías Unidas S.A., Corbo Lioi y Carlos Molina Solís, quienes cumplen con los referidos criterios de independencia,
hasta completar el tercio adicional que establece el artículo 50 bis de la Ley Nº 18.046 sobre Sociedades participando en calidad de observador el director señor Francisco Pérez Mackena, hasta su renuncia
Anónimas y la Circular Nº 1.956 de la CMF. a ésta presentada en Sesión Ordinaria de Directorio N° 2.193 de fecha 4 de diciembre de 2023, en
 la que se designó en su reemplazo, en igual calidad, al director señor Rodrigo Hinzpeter Kirberg.
El Comité no requirió contratar asesores para desarrollar sus funciones, por lo cual no incurrió en
gastos con cargo al presupuesto aprobado por la referida Junta Ordinaria de Accionistas. El Comité de Auditoría sesiona en la medida que requiere conocer alguna materia propia de sus
 funciones y reporta al Directorio en la siguiente sesión, según corresponda, las materias específicas
El Comité de Directores se reunió dos veces el año 2024 con la empresa de auditoría externa. que haya conocido.
En la página 48 de esta memoria se muestra de manera comparativa la remuneración percibida por Funciones
cada integrante de este Comité en los ejercicios 2023 y 2024.
 Las funciones de este Comité de Auditoría son:
 Responsable de la contratación, remuneración y supervisión del trabajo de firmas de contabilidad
 pública contratadas para preparar o emitir un informe de auditoría, revisar o certificar dichos
 informes, debiendo los auditores externos reportarle directamente en estas materias al Comité
 de Auditoría;
 Resolver los desacuerdos entre la administración y los auditores respecto de los informes financieros;
Memoria Integrada 2024 / 3.3 Comités del Directorio 52

[pág. 54]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 Aprobar en forma previa la contratación de servicios, distintos a los de auditoría, que vaya a prestar Se reunió con la empresa de auditoría externa, socio a cargo y equipo de auditoría, para interiorizarse
 la firma de auditores externos; de las actividades que éstos realizan, particularmente el plan de auditoría externa para los
 Establecer un procedimiento para conocer y tratar quejas recibidas por Compañía Cervecerías procesos de confección de Estados Financieros Consolidados y Formulario 20-F, certificación SOX,
 Unidas S.A. respecto de la contabilidad, controles contables u otras materias de auditoría y para el declaración de independencia, fraude y plan de comunicación con el Comité de Auditoría, y revisó
 envío anónimo y confidencial por parte de empleados de preocupaciones relacionadas con estas la implementación de la Carta de Control Interno;
 materias; y Tomó conocimiento de la no existencia de cambios en los criterios y políticas contables utilizados
 Fijar su presupuesto anual de gastos y contratar asesores externos. en la confección de los Estados Financieros Consolidados de Compañía Cervecerías Unidas S.A. y
 filiales y de la no existencia de cambios en la política de provisiones en la confección de los mismos;
 Actividades realizadas Revisó el informe de provisiones de grandes clientes;
 Revisó y acordó mantener durante al año 2024 la política de cobertura tipo de cambio vigente;
El Comité de Auditoría sesionó en 13 oportunidades entre enero de 2024 y marzo de 2025, Revisó el informe de los pagos efectuados a la empresa de auditoría externa durante el año 2024; y
levantándose actas de cada reunión, reportando al Directorio en la siguiente sesión las materias Revisó la propuesta al Directorio, para ser sometida a consideración de la Junta Ordinaria de
específicas que haya conocido. En el ejercicio de sus funciones el Comité de Auditoría se reunió Accionistas a celebrarse el año 2025, respecto de las empresas de auditoría externa.
regularmente con los gerentes de Compañía Cervecerías Unidas S.A., con el Contralor General, el
Gerente de Auditoría Interna y auditores externos, a fin de tratar diversos temas vinculados con sus Honorarios y gastos
funciones. Las materias analizadas y principales actividades efectuadas por el Comité de Auditoría
durante el ejercicio 2024 y hasta marzo 2025, fueron las siguientes: Los directores integrantes de este Comité de Auditoría, así como los designados en calidad de
 Tomó conocimiento del Informe Anual de Resultados de Auditoría Interna correspondiente a los observadores del mismo, percibieron la remuneración aprobada por la 121ª Junta Ordinaria de
 años 2023 y 2024, y se sometió a su aprobación el Plan de Auditoría Interna para los años 2024 Accionistas celebrada el 17 de abril de 2024, consistente en una dieta mensual por asistencia,
 y 2025; independiente del número de sesiones que se celebren en el período, ascendente a UF 50 brutas.
 Tomó conocimiento semestralmente de las denuncias recibidas dentro del procedimiento de El Comité de Auditoría no efectuó gastos con cargo al presupuesto de UF 2.000 acordado por la
 quejas (Whistle Blowing) establecido en cumplimiento de las normas contenidas en la Ley SOX; señalada Junta Ordinaria de Accionistas.
 Se sometió a su aprobación la contratación de la firma de auditores externos PricewaterhouseCoopers
 Consultores, Auditores y Compañía Limitada para la prestación de servicios distintos a los de auditoría El Comité de Auditoría se reunió dos veces el año 2024 con la empresa de auditoría externa y
 y conoció el monto y detalle de los honorarios pagados a dicha empresa de auditoría externa por trimestralmente con el área de auditoría interna.
 todos los servicios prestados a la Compañía;
 Examinó los Estados Financieros Consolidados trimestrales y anuales emitidos por Compañía En la página 48 de esta memoria se muestra de manera comparativa la remuneración percibida por
 Cervecerías Unidas S.A. previo a su examen por el Directorio; cada integrante de este Comité en los ejercicios 2023 y 2024.
 Tomó conocimiento de los resultados del proceso de autoevaluación y de certificación para efectos
 de la aplicación de la sección 404 de la Ley SOX;
 Revisó el documento Formulario 20-F preparado por Compañía Cervecerías Unidas S.A. para ser
 enviado a la SEC;
 Revisó trimestralmente el Informe de Resultados de Auditoría Interna correspondiente al año
 2024;
Memoria Integrada 2024 / 3.3 Comités del Directorio 53

[pág. 55]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
Políticas de contratación asesorías de los Comités
Los Comités no cuentan con una política específica para la contratación de expertos que los asesoren
en materias contables, tributarias, financieras, legales u otras. La contratación de asesores especialistas
en las materias indicadas se analiza caso a caso por el respectivo Comité de acuerdo con la materia
específica de que se trate, lo que permite actuar con mayor flexibilidad y dinamismo. Sin perjuicio de
lo anterior, el Comité de Directores, de conformidad a lo dispuesto en la Ley N° 18.046, y el Comité
de Auditoría, cuentan con presupuestos para estos efectos, los que son aprobados anualmente por
la Junta Ordinaria de Accionistas.
En virtud de lo anterior, cada Comité podrá en todo momento requerir al Gerente General la
contratación de una asesoría externa con la finalidad que éste cuente con la opinión de uno o más
terceros expertos en una denominada materia. Para estos efectos, el Comité deberá en cada caso
aprobar un presupuesto especial y elegir la empresa o persona natural que prestará la citada asesoría.
Ni el Comité de Directores ni el Comité de Auditoría requirieron contratar asesores para desarrollar
sus funciones durante el año 2024, por lo cual no incurrieron en gastos con cargo a sus respectivos
presupuestos aprobados en la Junta Ordinaria de Accionistas celebrada el 17 de abril de 2024.
Memoria Integrada 2024 / 3.3 Comités del Directorio 54

[pág. 56]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
3.4 Ejecutivos Principales
 6 7 9 10
 8 12
 4
 13 14
 5 2 1 3 11
1. Patricio Jottar 3. Bárbara Wolff 5. Julio Freyre 7. Pedro Herane 9. Eduardo Ffrench-Davis 11. Felipe Benavides 13. Juan Martín Vannicola
 Gerente General Gerente de Asuntos Gerente General de Gerente General de Viña Gerente General de Gerente de Asuntos Legales Gerente Corporativo de
 Corporativos y Sustentabilidad Compañía Cervecerías Unidas San Pedro Tarapacá S.A. Embotelladoras Chilenas Procesos Industriales
 Argentina S.A. Unidas S.A.
2. Gabriela Ugalde 4. Domingo Jiménez 6. Matías Bebin 8. Felipe Dubernet 10. Antonio Cruz 12. Juan Boned 14. Sebastián Landi
 Gerente Corporativo Gerente General de Compañía Gerente General de Gerente Corporativo Gerente de Planificación Contralor General Gerente de Negocios
 de Recursos Humanos Pisquera de Chile S.A Cervecera CCU Chile Limitada de Administración y Finanzas Estratégica y Nuevos Negocios Internacionales
Memoria Integrada 2024 / 3.4 Ejecutivos Principales 55

[pág. 57]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
Organigrama Comité de
 Directorio
 Comité de
 Auditoría Directores
 Patricio Jottar
 Gerente General
 Comité de Dirección
 La Gerencia Corporativa de Administración y Finanzas tiene a
 su cargo las Relaciones con Accionistas e Inversionistas, a
 Matías Bebin Pedro Herane Felipe Dubernet través de la Gerencia de Planificación Financiera y Relación con
 Gerente General Gerente General Gerente Corporativo Inversionistas, entre otras funciones.
 Cervecera CCU Chile Viña San Pedro de Administración
 Limitada Tarapacá S.A. y Finanzas
 Eduardo Ffrench-Davis Julio Freyre Felipe Benavides Gabriela Ugalde Juan Martín Vannicola
 Gerente General Gerente General
 Gerente de Gerente Corporativo Gerente Corporativo de
 Embotelladoras Compañía Cervecerías
 Asuntos Legales de Recursos Humanos Procesos Industriales
 Chilenas Unidas S.A. Unidas Argentina S.A.
 Domingo Jiménez Sebastián Landi Juan Boned Bárbara Wolff Antonio Cruz
 Gerente General Gerente de Asuntos Gerente de Planificación
 Gerente de Negocios Contralor
 Compañía Pisquera Corporativos y Estratégica y Nuevos
 Internacionales General
 de Chile S.A. Sustentabilidad Negocios
 Comité de
 Sustentabilidad
 La Gerencia de Contraloría es responsable de las unidades de Control Interno y La Gerencia de Asuntos Corporativos y Sustentabilidad es responsable del Desarrollo
 Gestión de Riesgos, a través de la Subgerencia de Administración de Riesgo y la Sostenible y Comunicación con los medios, a través de las Subgerencias de Sustentabilidad
 Gerencia de Auditoría, entre otras funciones. y Comunicaciones, entre otras funciones.
Memoria Integrada 2024 / 3.4 Ejecutivos Principales 56

[pág. 58]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
Los Ejecutivos Principales de CCU S.A. registrados durante los años 2023 y 2024 en la CMF son los siguientes:
 Fecha Fecha
 Nombre RUT Profesión Cargo
 nombramiento término
Patricio Jottar Nasrallah 7.005.063-3 Ingeniero Comercial Gerente General de Compañía Cervecerías Unidas S.A. 01/07/1998
Pedro Herane Aguado 11.677.304-K Ingeniero Comercial Gerente General Viña San Pedro Tarapacá S.A. 01/04/2013
Felipe Dubernet Azócar 8.550.400-2 Ingeniero Civil Gerente Corporativo de Administración y Finanzas 31/01/2014
Felipe Benavides Almarza 13.025.939-1 Abogado Gerente de Asuntos Legales 16/03/2015
Antonio Cruz Stuven 15.320.602-3 Ingeniero Comercial Gerente de Planificación Estratégica y Nuevos Negocios 05/06/2017
María Gabriela Ugalde Romagnoli 6.554.359-1 Psicóloga Gerente Corporativo de Recursos Humanos 02/04/2018
Domingo Jiménez Manterola 13.882.226-5 Ingeniero Comercial Gerente General de Compañía Pisquera de Chile S.A. 16/08/2018
Sebastián Landi 27.206.106-8 Ingeniero Químico Gerente de Negocios Internacionales 04/11/2019
Juan Martín Vannicola 27.370.350-0 Ingeniero Industrial Gerente Corporativo de Procesos Industriales 01/04/2020
Juan Boned 27.610.083-1 Contador Público Nacional Contralor General 01/08/2021
Julio Agustín Freyre 93.603.117(1) Licenciado en Dirección de Empresas Gerente General Compañía Cervecerías Unidas Argentina S.A. 01/08/2021
Bárbara Wolff Gopfert 14.376.180-0 Ingeniero Comercial Gerente de Asuntos Corporativos y Sustentabilidad 01/10/2022
Eduardo Ffrench-Davis Rodríguez 10.738.037-K Ingeniero Civil Industrial Gerente General Embotelladoras Chilenas Unidas S.A. 01/06/2023
Matías Bebin Subercaseaux 15.365.587-1 Ingeniero Comercial Gerente General Cervecera CCU Chile Limitada 01/06/2023
Francisco Diharasarri Domínguez 7.034.045-3 Ingeniero Civil Gerente General de CCU Chile 01/10/2003 31/07/2023
Martín Rodríguez Guiraldes 8.547.811-7 Ingeniero Comercial Gerente de Transformación 01/03/2015 31/03/2023
(1) DNI Argentino.
Memoria Integrada 2024 / 3.4 Ejecutivos Principales 57

[pág. 59]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
Remuneración Ejecutivos Principales Participación en la propiedad de CCU S.A. al 31 de diciembre de 2024 de:
En el ejercicio del año 2024, los Ejecutivos Principales percibieron CLP 9.128 millones (CLP 8.931 millones Ejecutivos Principales: El señor Juan Boned poseía 300 ADRs, representativo de 600 acciones
en el año 2023) por concepto de remuneraciones y bonos de desempeño en términos brutos. Respecto de CCU S.A., equivalente a 0,0002% de participación accionaria, los que fueron vendidos en su
al concepto de indemnizaciones pagadas a Ejecutivos Principales en el ejercicio del año 2024, no se totalidad con fecha 11 de marzo de 2025. Los demás Ejecutivos Principales no tienen participación
realizaron pagos por este concepto (CLP 2.187 millones en el año 2023). directa o indirecta en la propiedad de CCU S.A.; y
 Directores: (i) el Presidente señor Francisco Pérez Mackenna tiene el 0,004% de participación
Compensaciones directa en la propiedad de CCU S.A. con 14.897 acciones; y (ii) el director señor Vittorio Corbo
 Lioi es indirectamente titular de 4.343 acciones de CCU S.A., equivalente a 0,001%, a través de
CCU ha implementado una Política de Compensaciones diseñada para alinear los intereses la propiedad de la sociedad Vittorio Corbo y Asociados Limitada, de la cual detenta el 80%.
de los ejecutivos con los objetivos estratégicos de la Compañía. Esta Política, compuesta por
una remuneración fija y un componente variable sujeto a revisión anual, busca recompensar
el desempeño individual y el logro de metas colectivas. El incentivo variable, aprobado por el
 3.5 Adherencia a códigos nacionales o
Comité de Directores, se otorga en función de indicadores de desempeño y vinculado al éxito de internacionales
la organización. La Política de Compensaciones garantiza el cumplimiento de las normas legales y
regulaciones vigentes, así como la equidad interna y la competitividad externa. El Directorio de CCU S.A. no ha adherido formalmente a ningún código nacional o internacional de
 gobierno corporativo. No obstante, como se mencionó en la sección “3.1 Marco de gobernanza”,
La Política de Compensaciones no incorpora planes que incluyan pagos basados en opciones sobre el actuar de los directores en el ejercicio de sus funciones se guía por el Código de Conducta del
acciones de la Compañía, como tampoco incentivos de largo plazo de cualquier especie. Directorio, el cual establece, además de principios, ciertos procedimientos, políticas y buenas
 prácticas de gobierno corporativo aplicables transversalmente a la Compañía.
Otros Benef icios
Conforme a lo antes indicado, la compensación total que percibe un ejecutivo principal está
compuesta por la remuneración fija garantizada, pagos variables, así como pagos mandatorios
por ley.
La Compañía otorga a los Ejecutivos Principales los siguientes beneficios:
 Seguro complementario de Salud, Seguro de Vida y Seguro de Accidentes Personales cubierto
 100% por la Compañía.
 Exámenes de Salud Preventivos con una periodicidad bi-anual cubierto 100% por la Compañía.
 Política de retiro que garantiza el pago de indemnización por años de servicio a partir de los 60
 años, sin límites de antigüedad ni remuneración.
Memoria Integrada 2024 / 3.5 Adherencia a códigos nacionales o internacionales 58

[pág. 60]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
3.6 Gestión de riesgos y control interno
3.6.1 Gestión de riesgos Elementos centrales del Proceso GRE
CCU cuenta con un marco de gestión de riesgos y control interno, que se formaliza en políticas, Este Proceso GRE está basado en el estándar del Committee of Sponsoring Organizations of the Treadway
procesos y procedimientos. El Proceso de Gestión de Riesgos Estratégicos (Proceso GRE) permite Commission (COSO), del cual se aplican la metodología y las mejores prácticas. La autoevaluación de
que los riesgos materiales y estratégicos para la gestión de la Compañía sean adecuadamente cada filial de la Compañía es considerada en el Proceso GRE, el cual se estructura en cinco etapas:
identificados, evaluados, y mitigados a través de instrumentos y metodologías basadas en establecer un contexto, identificar, analizar, evaluar y tratar los riesgos. Además, incluye dos etapas
estándares internacionales. (Ver sección “3.1 Marco de gobernanza”). transversales y periódicas: monitorear/revisar y comunicar/consultar. Estas etapas están diseñadas
 para abordar riesgos estratégicos, operacionales, económicos, sociales y de cumplimiento, incluyendo
El Proceso GRE es gestionado por el Contralor General y la Alta Gerencia de la Compañía e involucra riesgos relacionados con el cambio climático.
al Directorio y a la Alta Gerencia de la Compañía. Los roles y actividades del Proceso GRE son
definidos, liderados y ejecutados principalmente por la Alta Gerencia. El Contralor General y la El Proceso GRE considera la identificación y evaluación de los riesgos en base a dos dimensiones,
Alta Gerencia fijan las directrices generales de los riesgos y su gestión, revisando y aprobando el impacto potencial que tendría la materialización de los riesgos a los que estamos expuestos y la
anualmente los Riesgos Estratégicos y los Planes de Mitigación, los que son presentados anualmente vulnerabilidad. Habiendo identificado y priorizado los principales riesgos, el proceso considera los
al Directorio. riesgos operacionales, laborales, financieros, así como otros riesgos relacionados con la sustentabilidad,
 como por ejemplo riesgos asociados a derechos humanos, trabajo forzoso, trabajo infantil, prácticas
La Gerencia de Contraloría es responsable de la administración, consolidación, monitoreo y comunicación antisindicales, discriminación; la seguridad y salud de los clientes; las relaciones con sus colaboradores;
de los riesgos estratégicos, así como de la verificación de la efectividad y cumplimiento de las políticas, y, crecientemente, riesgos relacionados con el cambio climático. Todos estos elementos y evaluaciones
procedimientos y controles implementados para la gestión de riesgos. son consideradas en la priorización de los riesgos, para lo cual se consideran también cambios en
 la regulación existente. CCU cuenta con políticas, procedimientos y canales de denuncia, mediante
 las cuales aborda y fortalece la gestión de los derechos humanos en la Compañía, los cuales son
 considerados al momento de evaluar y priorizar riesgos relacionados con los derechos humanos. Sin
 perjuicio de ello, CCU está evaluando la realización de un análisis completo de la debida diligencia
 en derechos humanos.
 Comunicación y capacitación
 CCU no aborda de manera específica en sus programas de divulgación de información y capacitación
 permanente las políticas, procedimientos, controles y códigos implementados para la gestión de
 riesgos, sin perjuicio de lo cual cuenta con programas de divulgación de información y capacitación
 permanente para el personal.
Memoria Integrada 2024 / 3.6 Gestión de riesgos y control interno 59

[pág. 61]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
Identif icación de riesgos
Como parte del Proceso GRE, CCU identifica, evalúa y revisa anualmente los riesgos que podría esperarse En la categoría de bebidas no alcohólicas, competimos principalmente con embotelladores
afecten las perspectivas económicas y financieras de la Compañía. Producto de este proceso, se ha de productos de The Coca-Cola Company: Embotelladora Andina S.A. y Embonor S.A. en Chile,
identificado un grupo de riesgos que actualmente se gestionan en carácter de materiales y estratégicos. Paraguay Refrescos S.A. en Paraguay, Montevideo Refrescos S.R.L. en Uruguay y Embotelladoras
 Bolivianas Unidas (EMBOL S.A.) en Bolivia.
Es importante destacar que los riesgos comentados a continuación no son los únicos que enfrenta la
Compañía y que los riesgos adicionales que actualmente no conocemos o que consideramos inmateriales El aumento en la agresividad competitiva, respaldado por la capacidad financiera de nuestros
también pueden afectar adversamente la operación y resultados de la organización. La Compañía no ha competidores, podría afectar potencialmente nuestra venta y nuestra participación de mercado,
identificado otros riesgos y oportunidades derivados de los impactos que la entidad y sus operaciones redundando, en definitiva, en impactos negativos en la rentabilidad.
generen directa o indirectamente en el medioambiente o la sociedad.
 Para enfrentar este entorno competitivo, CCU mantiene estrategias de innovación para fortalecer
Para efectos de gestión y orden, se agruparon los riesgos en las siguientes categorías: sus ventas y participación de mercado, las cuales son soportadas con campañas de marketing, al
 tiempo en que desarrolla proyectos de optimización de las cadenas de producción y distribución
 A.
 A Riesgos relacionados con los procesos de negocio para la reducción de costos y mejora del margen operacional.
 B.
 B Riesgos relacionados con cambios e incumplimientos legales y normativos
 C.
 C Riesgos relacionados con la tecnología e innovación A pesar de estos esfuerzos, CCU no puede garantizar que sus competidores no intensifiquen la
 D.
 D Riesgos relacionados con la sustentabilidad agresividad de su estrategia en el futuro, por lo que continúa evaluando estrategias para proteger
 su participación de mercado y rentabilidad.
A
A. Riesgos relacionados con los procesos de negocio
 En relación al crecimiento y consolidación de la industria de supermercados en Chile, esta se
 encuentra altamente consolidada, lo que otorga un mayor poder adquisitivo a pocas cadenas.
 CAMBIOS EN LA INDUSTRIA A NIVEL MUNDIAL, REGIONAL O LOCAL, ASÍ COMO
 A.1 TAMBIÉN EL CRECIMIENTO DEL CANAL SUPERMERCADOS PODRÍA AFECTAR NUESTRA Esta consolidación podría limitar la capacidad de la Compañía para negociar precios favorables,
 RENTABILIDAD, RESULTADOS Y PARTICIPACIÓN DE MERCADO afectando negativamente sus ventas y rentabilidad. Además, aumenta la exposición al riesgo de
 crédito, en caso que alguno de estos grandes clientes deje de cumplir con sus obligaciones de
 pago hacia nosotros.
En todos los países donde opera la Compañía, compite con marcas locales y globales,
especialmente en las categorías de cervezas y bebidas no alcohólicas. En el mercado de cervezas, Las consecuencias podrían ser una reducción en la rentabilidad, un menor flujo de caja, disminución
su principal competencia proviene de las filiales de Anheuser-Busch InBev SA/NV (ABI), la mayor de la participación de mercado y aumento del riesgo de crédito si un cliente significativo no cumple
cervecera del mundo, que cuenta con economías de escala significativas en producción y con sus obligaciones de pago.
distribución. En Chile, competimos principalmente con Cervecería Chile S.A., una filial de ABI,
que cuenta con un acuerdo de distribución con Embotelladora Andina S.A. y Embonor S.A., los CCU mitiga este riesgo mediante esfuerzos para mantener la diversificación de sus canales de ventas
principales embotelladores de productos de The Coca-Cola Company. y cuenta con cobertura de seguros de crédito.
Memoria Integrada 2024 / 3.6 Gestión de riesgos y control interno 60

[pág. 62]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 NUESTROS RESULTADOS PODRÍAN VERSE AFECTADOS SI NO SOMOS CAPACES Las fluctuaciones en los costos de estas materias primas e insumos podrían impactar negativamente la
 A.2 DE MANTENER LA IMAGEN, CALIDAD DE NUESTROS PRODUCTOS Y UNA BUENA rentabilidad de la Compañía. Para mitigar este riesgo, la Compañía cuenta con acuerdos de suministro a
 RELACIÓN CON NUESTROS CLIENTES, CONSUMIDORES Y LICENCIATARIOS largo plazo con ciertos proveedores que incorporan polinomios de reajustes para reflejar el costo real de
 los insumos. Ante variaciones que podrían impactar negativamente nuestra rentabilidad, permanentemente
La imagen y calidad de los productos de la Compañía son esenciales para su éxito y desarrollo. Un a nivel interno gestionamos proyectos de eficiencias que ayuden a compensar dicho efecto.
eventual problema de calidad podría empañar la reputación de los productos y afectar negativamente
los ingresos. Es crucial asegurar una buena atención al cliente por parte de la fuerza de ventas y
adaptar nuevos lanzamientos e innovaciones a las necesidades y gustos de los consumidores. Además, A.4
 LA ESCASEZ Y DISPONIBILIDAD DE MATERIAS PRIMAS E INSUMOS CRÍTICOS NOS
información negativa o imprecisa en redes sociales podría afectar la reputación de la Compañía. PODRÍA IMPACTAR NEGATIVAMENTE
La Compañía sostiene la postura de mantención y mejoramiento continuo en ámbitos de calidad e La escasez de materias primas e insumos críticos, debido a cambios en los patrones de consumo,
inocuidad de las materias primas, insumos y materiales, velando siempre por la seguridad de quienes producción agrícola, calidad y disponibilidad del suministro, o problemas logísticos, podría afectar
trabajan en la empresa, así como la seguridad de los consumidores y del medio ambiente durante la cadena de suministro y los niveles de producción de la Compañía, impactando negativamente
los procesos de elaboración, envasado y distribución de los productos. Los productos elaborados y sus resultados.
distribuidos por la Compañía, se rigen con la normativa vigente en cada país. La Compañía cuenta
con certificaciones destacadas como Hazard Analysis and Critical Control Points (HACCP), ISO 22000, Para mitigar estos riesgos, la Compañía realiza una revisión anual con el objeto de identificar y
FSSC 22000 y British Retail Consortium (BRC). actualizar planes de acción que aseguren la continuidad operacional, que incluyen contratos a
 largo plazo con ciertos proveedores, planes de contingencia, búsqueda de nuevos proveedores
CCU opera bajo licencias que incluyen condiciones específicas para su renovación. El vencimiento y mayores niveles de inventarios de insumos críticos, planes que se monitorean periódicamente
o la terminación de estos acuerdos podría impactar negativamente determinados segmentos de pero que eventualmente podrían no ser suficientes para mitigar un impacto material en nuestros
operación. En el año 2024, aproximadamente el 72% del volumen de ventas corresponde a marcas resultados y posición financiera.
propias, lo que mitiga el riesgo del potencial impacto de la pérdida de los contratos de licencias.
 CRISIS SANITARIAS, PANDEMIAS O BROTES DE ENFERMEDADES CONTAGIOSAS
 A.3 LAS FLUCTUACIONES EN EL COSTO DE NUESTRAS MATERIAS PRIMAS E INSUMOS A.5 A NIVEL GLOBAL O REGIONAL PODRÍAN TENER UN IMPACTO NEGATIVO EN
 PODRÍAN IMPACTAR NEGATIVAMENTE NUESTRA RENTABILIDAD NUESTRAS OPERACIONES Y POSICIÓN FINANCIERA
La Compañía, para la elaboración de los productos que comercializa, compra materias primas e Una crisis sanitaria, pandemias o brotes de enfermedades a nivel global o regional podrían
insumos tales como malta, azúcar, pulpa de fruta, arroz, jarabe de maíz, uva, vino, concentrados impactar negativamente las operaciones y la posición financiera de la Compañía. Estos eventos
de gaseosas por licencias, lúpulo, esencias y alcohol (pisquero, neutro y otros), así como material pueden interrumpir el funcionamiento normal, limitar la capacidad de abastecimiento, producción
de embalaje, a productores locales o en el mercado internacional. Los precios de estos productos y distribución, y/o reducir la demanda de productos. Un período prolongado de incertidumbre
están expuestos a la volatilidad del mercado, determinadas por la oferta y demanda global, económica podría afectar materialmente el negocio, los resultados operativos, el acceso a
variaciones en los tipos de cambio, eventos climáticos, sociales y conflictos geopolíticos, sobre financiamiento y la situación financiera general.
los que la Compañía no tiene control.
Memoria Integrada 2024 / 3.6 Gestión de riesgos y control interno 61

[pág. 63]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
Medidas restrictivas prolongadas para controlar un brote de enfermedad o cualquier desarrollo adverso Las Políticas Monetarias restrictivas del Banco Central de Chile, como el alza de tasas de interés
de salud pública en los mercados objetivos pueden tener un efecto material y adverso en las operaciones para controlar la inflación, también pueden restringir el acceso al crédito y ralentizar el crecimiento
comerciales. El impacto de una pandemia dependerá de su evolución, incluida su duración, el impacto económico, afectando el consumo de los productos de la Compañía. Además, la exposición de Chile,
en los mercados financieros y la confianza de los consumidores, lo cual es incierto. La Compañía cuenta como economía emergente, a crisis internacionales de liquidez y fluctuaciones en los mercados
con planes de contingencia para el cuidado de las personas y la continuidad operacional, aunque no de capitales puede impactar negativamente la demanda de productos y la capacidad de acceder a
se puede asegurar que estos planes sean suficientes para mitigar un impacto en los resultados y la financiamiento en condiciones favorables.
posición financiera, debido a la naturaleza, duración y alcance de un evento de estas características.
 ARGENTINA
 DEPENDEMOS EN GRAN MEDIDA DE LAS CONDICIONES POLÍTICAS, SOCIALES Las operaciones de CCU en Argentina están expuestas a un entorno legal y económico volátil.
 A.6 Argentina ha sufrido recesiones, altos niveles de inflación, devaluaciones de su moneda y altas tasas
 Y ECONÓMICAS EN LOS PAÍSES QUE OPERAMOS, LO QUE PUEDE IMPACTAR
 NUESTROS RESULTADOS OPERACIONALES Y POSICIÓN FINANCIERA de interés en diversos periodos de su historia, y fue declarada economía hiperinflacionaria en 2018,
 condición que mantiene hasta la fecha. Así también, desde el año 2019, existen controles cambiarios
Los resultados operacionales y la posición financiera de CCU dependen en gran medida de las que limitan la importación de bienes y la repatriación de utilidades, afectando la flexibilidad financiera
condiciones macroeconómicas de los mercados donde opera, siendo los más relevantes Chile y de nuestras filiales. Asimismo, entre 2020 y 2023, se instauraron mecanismos de control de precios
Argentina. En efecto, el Segmento de operación Chile representó el 61,0% de los ingresos totales sobre bienes de consumo, incluida la cerveza, los que redujeron la rentabilidad de nuestra operación.
en el año 2024, incluyendo el segmento Otros/Eliminaciones, el que considera los gastos e ingresos Estos controles fueron eliminados tras el cambio de administración, al final de 2023.
corporativos y las eliminaciones de las transacciones realizadas entre los distintos segmentos de
operación. Por su parte, el Segmento de operación Negocios Internacionales, dentro del cual Argentina En diciembre de 2023, el nuevo gobierno emitió el Decreto de Necesidad y Urgencia N° 70/2023,
representa una fracción relevante de sus operaciones, e incluye además Bolivia, Paraguay y Uruguay, que derogó regulaciones restrictivas y amplió la autonomía contractual, aunque su vigencia depende
contribuyó con un 29,3% de los ingresos totales, mientras que el Segmento de operación Vinos, que de la falta de rechazo del DNU por ambas Cámaras del Congreso, lo que a la fecha del presente
abarca los mercados domésticos de Chile y Argentina y el mercado de exportaciones, representó no ha ocurrido.
un 9,7% de los ingresos. Debido a lo anterior, los resultados de la Compañía están estrechamente
ligados al desempeño de la economía chilena y argentina. Estos cambios pueden afectar la planificación financiera y la rentabilidad de CCU en el país. Para
 mitigar estos riesgos, la Compañía realiza un monitoreo continuo del entorno regulatorio, optimiza
CHILE costos y diversifica sus operaciones regionales para reducir su exposición al mercado argentino,
La economía chilena ha registrado un crecimiento promedio del PIB de 2,0% anual entre 2014 y garantizando así la continuidad de sus actividades.
2024, con períodos de desaceleración en momentos de crisis global, como en el año 2009 y 2020.
En Chile, la inflación ha tenido variaciones materiales durante algunos periodos, por ejemplo en el CCU enfrenta riesgos financieros derivados de factores externos, como cambios en las calificaciones
año 2022 alcanzó un 12,8% vs. un promedio anual de 4,6% entre 2014 y 2024, afectando el poder crediticias soberanas y fluctuaciones en los tipos de cambio, que pueden afectar su posición
adquisitivo de los consumidores y generando presiones sobre los costos operacionales. Aunque en financiera y operativa.
los años 2023 y 2024 la inflación se redujo a 3,9% y 4,5%, respectivamente, no se puede garantizar
que se mantenga en niveles controlados, lo que podría influir en los márgenes operativos de la Una rebaja en la calificación crediticia de la deuda soberana de Chile podría tener un impacto
Compañía, especialmente cuando los contratos de suministro están denominados en moneda negativo en las calificaciones de riesgo de la Compañía, incrementando los costos de financiamiento
extranjera o indexados al índice de precios al consumidor.
Memoria Integrada 2024 / 3.6 Gestión de riesgos y control interno 62

[pág. 64]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
y restringiendo el acceso a los mercados de capitales. Este riesgo se ve influenciado por condiciones En relación al talento interno, la Compañía cuenta con procesos definidos para identificar y desarrollar este
macroeconómicas locales y la percepción del entorno financiero internacional. talento, proporcionando formación y oportunidades de desarrollo lo cual permite preparar a los empleados
 para roles clave. La comunicación abierta y el feedback continuo son parte esencial de la cultura de la
Gran parte del precio de las materias primas e insumos utilizados están denominadas en otras Compañía y forman parte del proceso de evaluación de desempeño, y son un insumo para entender y
monedas distintas a las monedas de curso legal en los países donde operamos. Las variaciones en abordar las necesidades y preocupaciones del personal, contribuyendo así a su satisfacción y compromiso.
el tipo de cambio pueden elevar los costos de producción y reducir los márgenes de rentabilidad.
 A.8 EL CAMBIO EN EL ESTILO DE VIDA Y LAS PREFERENCIAS DE CONSUMO DE LAS
Para mitigar los riesgos relacionados con las condiciones políticas, sociales y económicas en los países
 PERSONAS PODRÍA IMPACTAR NUESTRO NEGOCIO Y SUS RESULTADOS
que operamos, CCU mantiene un perfil financiero conservador, con indicadores de liquidez adecuados
y una política de diversificación de fuentes de financiamiento, lo que permite acceder a los mercados de
deuda en condiciones competitivas. Esto además está sustentado por clasificaciones de riesgo favorables La pandemia por COVID-19 y otros eventos han propiciado los cambios en el estilo de vida, las
tanto a nivel local (‘AA+’ por Fitch Chile e ICR) como internacional (‘BBB’ perspectiva negativa, y ‘BBB+’ preferencias de consumo y ha generado una aceleración de la revolución digital. Estos cambios
perspectiva estable, por Standard & Poor’s y Fitch Ratings, respectivamente). Asimismo, la Compañía impactan en las preferencias de los consumidores, lo que requiere que la Compañía se mantenga
implementa estrategias de cobertura cambiaria de balance, principalmente en Chile. en una constante innovación, para responder a las preferencias de consumo.
Adicionalmente, implementa planes de eficiencia y optimización de costos, y ha diversificado sus B Riesgos relacionados con cambios e incumplimientos legales
operaciones geográficamente en el tiempo. Estas acciones permiten a la Compañía fortalecer su y normativos
resiliencia frente a cambios en las condiciones económicas, políticas y sociales, protegiendo así su
estabilidad financiera y operativa.
 RIESGOS RELACIONADOS CON LA LIBRE COMPETENCIA EN TODOS LOS MERCADOS
 B.1 DONDE OPERAMOS Y LOS CAMBIOS EN LA NORMATIVA APLICABLE PODRÍAN
 PUEDE QUE NO SEAMOS CAPACES DE ATRAER, CONTRATAR O RETENER AL AFECTAR NUESTROS RESULTADOS
 A.7
 PERSONAL CLAVE
 Los riesgos de libre competencia que enfrenta CCU están relacionados con su posición en los mercados
La fuga o alta rotación de empleados esenciales puede afectar negativamente la continuidad de las donde opera. En Chile, donde la Compañía ocupa un rol de liderazgo, ha sido demandada por un
operaciones, así como la ejecución de estrategias y la innovación de la Compañía. La pérdida de competidor bajo la acusación de presunto abuso de posición dominante en el mercado de cervezas
talento clave también puede resultar en la pérdida de conocimiento y experiencia, lo que podría en el canal de consumo inmediato (on premise), sin que el Tribunal de Defensa de la Libre Competencia
debilitar la competitividad de la Compañía. (Ver Capítulo “5 Personas”). (TDLC) haya emitido un fallo hasta la fecha. Asimismo, tras un requerimiento de la Fiscalía Nacional
 Económica (FNE) por eventuales prácticas anticompetitivas, el TDLC aprobó un acuerdo conciliatorio
Para mitigar este riesgo, la Compañía cuenta con procesos definidos para una efectiva retención mediante el cual CCU asumió compromisos fundamentalmente para facilitar la participación de micro
y contratación. Esto incluye ofrecer paquetes de compensación competitivos, oportunidades de cerveceros artesanales en puntos de venta como hoteles, restaurantes, bares y discotecas.
desarrollo profesional, un buen clima laboral y programas de reconocimiento. Adicionalmente,
la Compañía cuenta con procesos para fomentar una cultura organizacional que motive a los El incumplimiento de estos compromisos, así como un fallo desfavorable, podría resultar en
empleados, asegurando que se sientan comprometidos y valorados. sanciones económicas significativas y costos asociados al ajuste de condiciones comerciales,
Memoria Integrada 2024 / 3.6 Gestión de riesgos y control interno 63

[pág. 65]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
afectando los márgenes de rentabilidad. Además, el impacto reputacional podría traducirse en Para mitigar este riesgo, CCU mantiene un monitoreo constante de las reformas legislativas y fiscales
una disminución de la preferencia de clientes y socios comerciales. en los mercados donde opera, apoyándose en un equipo especializado en cumplimiento normativo.
 Este equipo se encarga de adaptar de manera oportuna las políticas y procedimientos internos
En los demás países donde la Compañía opera, el principal riesgo está asociado a posibles abusos a los cambios regulatorios. Asimismo, la capacitación continua del personal en temas fiscales y la
de posición dominante por parte de competidores con alta participación de mercado, lo que podría colaboración con asesores legales y tributarios, permiten el cumplimiento de las normativas vigentes,
derivar en barreras de acceso, pérdida de participación de mercado y condiciones comerciales reduciendo así la exposición a sanciones y protegiendo la estabilidad financiera de la Compañía.
menos favorables, afectando los ingresos y la competitividad.
 B.3 RIESGO DE CAMBIOS EN REGULACIONES DE ETIQUETADO Y PUBLICIDAD
Para mitigar estos riesgos, CCU mantiene un Programa de Cumplimiento en Libre Competencia que
incluye un manual detallado y capacitaciones periódicas para colaboradores clave, enfocadas en
promover buenas prácticas y asegurar el cumplimiento de las normativas vigentes. Estas actividades Las regulaciones en materia de etiquetado y publicidad de bebidas alcohólicas y otros productos
son supervisadas por la Gerencia de Cumplimiento, la cual depende de la Gerencia de Asuntos alimenticios en los mercados donde opera CCU están en constante evolución. En Chile, la Ley N° 21.363
Legales, que gestiona los riesgos de libre competencia y monitorea el entorno regulatorio para introduce restricciones en la publicidad y regulaciones al etiquetado de bebidas alcohólicas, con
anticipar y prevenir contingencias que puedan derivar en impactos financieros adversos. obligaciones como advertencias sobre el consumo, restricciones de horario y limitaciones en eventos
 deportivos. Además, se encuentran actualmente en tramitación proyectos de ley que proponen
 incorporar mayor información nutricional y advertencias en los productos.
 POTENCIALES CAMBIOS EN LA LEGISLACIÓN TRIBUTARIA, CAMBIOS EN LOS
 B.2 IMPUESTOS CORPORATIVOS Y ESPECÍFICOS, ASÍ COMO LAS REGULACIONES Estos cambios normativos podrían impactar la estrategia de marketing y reducir el consumo de
 ESPECÍFICAS DE LOS MERCADOS DONDE OPERAMOS PODRÍAN TENER UN IMPACTO bebidas alcohólicas y no alcohólicas. CCU busca mitigar estos riesgos mediante la promoción del
 NEGATIVO EN NUESTROS RESULTADOS
 consumo responsable, el cumplimiento anticipado de nuevas normativas y la implementación de
 campañas alineadas con los marcos regulatorios vigentes.
Los negocios de CCU están sujetos a diversas obligaciones tributarias en los países donde opera,
incluyendo entre otros, impuestos a la renta y gravámenes específicos sobre bebidas alcohólicas
y no alcohólicas. Un incremento en las tasas impositivas, la creación de nuevos tributos o cambios B.4 RIESGOS DE INCUMPLIMIENTOS NORMATIVOS, PODRÍAN AFECTAR LA
 RENTABILIDAD Y LOS RESULTADOS DE NUESTROS NEGOCIOS
en las regulaciones de los mismos, podrían impactar negativamente las ventas y la rentabilidad.
En octubre de 2024, se publicó la Ley N° 21.713 que modificó el Código Tributario y estableció normas El incumplimiento de normativas, leyes y/o reglamentos aplicables podría afectar la rentabilidad
para combatir la informalidad, la evasión, la elusión y el crimen organizado (también conocida como y los resultados de los negocios de la Compañía. La operación en diversas jurisdicciones implica
“Ley de Cumplimiento Tributario”), otorgando mayores atribuciones a los organismos fiscalizadores. el cumplimiento de un amplio espectro de regulaciones, que abarcan desde normativas laborales
Además, se prevé la presentación de un segundo proyecto de ley durante 2025, orientado a modificar y ambientales hasta leyes tributarias y de protección al consumidor. El incumplimiento de estas
el sistema de imposición a la renta. Al cierre de esta memoria, aún no se dispone de los detalles de normativas podría resultar en sanciones, multas, litigios y daños a la reputación, lo que podría
esta propuesta, lo que introduce un componente de incertidumbre en el entorno tributario. tener un impacto negativo en la rentabilidad y los resultados operativos.
Memoria Integrada 2024 / 3.6 Gestión de riesgos y control interno 64

[pág. 66]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
La Compañía ha implementado un sistema de cumplimiento normativo robusto que incluye políticas, 2050 y promueve instrumentos de gestión ambiental más estrictos, entre ellos, planes nacionales,
procedimientos y controles internos que buscan el cumplimiento de las normativas aplicables. regionales y comunales de adaptación y mitigación de cambio climático, así como guías emitidas
 por el Ministerio del Medio Ambiente para la evaluación de sinergias y seguimiento de variables
 climáticas, lo que eleva la complejidad regulatoria para nuevas operaciones.
 B.5
 NUEVAS NORMATIVAS MEDIOAMBIENTALES APLICABLES PODRÍAN AFECTAR
 NUESTROS NEGOCIOS
 En septiembre de 2023 se promulgó en Chile la Ley de Biodiversidad, que crea el Servicio de
 Biodiversidad, encargado de la conservación del patrimonio natural, cuya implementación dependerá
Las operaciones de CCU están sujetas a un marco normativo medioambiental riguroso y en constante de reglamentos que deberán dictarse durante el año 2025.
evolución a nivel nacional e internacional. Este marco regula aspectos clave como emisiones de
distintas fuentes, manejo de residuos, almacenamiento de sustancias peligrosas, normativa sobre Además, la Ley N° 21.595 de 2023, sobre Delitos Económicos, introdujo nuevos tipos penales
biodiversidad, aguas y demás actividades inherentes a nuestra industria. medioambientales, como la liberación ilegal de sustancias contaminantes, la extracción no autorizada
 de agua, la afectación grave al medioambiente y la emisión de reportes incompletos o falsos a
En relación al manejo de residuos, en Chile la Ley N° 20.920 de Responsabilidad Extendida del la autoridad ambiental. CCU ha implementado protocolos y resguardos adicionales para dar
Productor (Ley REP) establece metas progresivas de recolección y valorización de envases, vigentes cumplimiento a estas nuevas exigencias.
desde septiembre de 2023, y nuestras filiales participan activamente en ReSimple, el primer sistema
de gestión colectivo aprobado por las autoridades.
 B.6
 LOS CAMBIOS EN EL MERCADO LABORAL DE LOS PAÍSES EN QUE OPERAMOS
 PODRÍAN IMPACTAR NUESTROS MÁRGENES Y RESULTADOS DE NUESTRO NEGOCIO
Asimismo, la Ley N° 21.368 que regula la entrega de plásticos de un solo uso y las botellas plásticas,
conocida como Ley PUSU, establece que en Chile las botellas plásticas desechables deben
contener al menos un 15% de plástico recolectado y reciclado localmente para 2025, aumentando Los cambios en el mercado laboral de los países en que CCU tiene presencia podrían afectar los
progresivamente este porcentaje hasta llegar a un 70% el año 2060. Para anticiparse a estos márgenes y resultados del negocio. En todos los países donde opera la Compañía, esta se expone
desafíos, la Compañía construyó la Planta de Reciclaje CirCCUlar, la que actualmente produce resina a fluctuaciones en la oferta de mano de obra, aumento de la demanda en ciertas especialidades
reciclada a partir de plástico recolectado en Chile, fortaleciendo nuestra cadena de suministro con y cambios en la legislación laboral. En abril de 2023, se publicó en Chile la ley sobre reducción de
material propio y de terceros, y reafirmando nuestro compromiso con la innovación sostenible y el la jornada de trabajo, cuya implementación es de carácter progresivo en un plazo máximo de 5
cumplimiento normativo. Asimismo, conforme a lo dispuesto en la referida Ley, los comercializadores años, contados desde abril de 2023. En Argentina, los altos niveles de inflación y la presión sindical
de bebestibles deberán ofrecer opciones retornables y debiendo los supermercados destinar un suponen un continuo incremento de los gastos salariales, factores que eventualmente pueden
30% de sus vitrinas a estos formatos desde febrero de 2026. aumentar los costos operativos y afectar la rentabilidad.
Respecto a los derechos de aguas, la reforma al Código de Aguas de 2022 introdujo un régimen de Para mitigar estos riesgos, la Compañía monitorea continuamente las condiciones del mercado
derechos de aprovechamiento de aguas temporales, sanciones de caducidad por no uso (obra), laboral, a fin de ajustar sus políticas de recursos humanos y buscar eficiencias operativas para
introdujo mayores atribuciones a la Dirección General de Aguas en contexto de escasez hídrica adaptarse a los cambios legislativos y económicos.
y estableció criterios más exigentes en la evaluación ambiental de proyectos con componentes
hídricos, considerando los efectos del cambio climático. Asimismo, la Ley Marco de Cambio Climático
de 2022 establece el objetivo de neutralidad de emisiones de gases de efecto invernadero para
Memoria Integrada 2024 / 3.6 Gestión de riesgos y control interno 65

[pág. 67]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
C Riesgos relacionados con la tecnología e innovación De conformidad a lo informado al mercado mediante Hechos Esenciales de fechas 26 y 27 de
 septiembre de 2024, la Compañía experimentó un incidente de ciberseguridad que afectó algunos de
 DEFICIENTE TRANSFORMACIÓN DIGITAL Y DE PROCESOS PODRÍAN IMPACTAR sus sistemas de TI relacionados con las áreas de ventas y distribución. Desde entonces, la Compañía
 C.1 NUESTRA RENTABILIDAD, LOS RESULTADOS Y NUESTRA HABILIDAD PARA OPERAR ha resuelto dicho incidente a través de medidas de contención, erradicación y recuperación,
 EN EL FUTURO incluyendo un análisis forense digital exhaustivo.
Una transformación digital y de procesos tardía o ineficaz podría impactar negativamente la Para mitigar este riesgo, CCU cuenta con un plan integral de ciberseguridad enfocado en fortalecer
rentabilidad, los resultados operativos y la capacidad de CCU para mantener su competitividad las capacidades de identificación, protección, detección, respuesta y recuperación. Este plan incluye
a largo plazo. La transformación digital es clave para mejorar la eficiencia operativa y optimizar tecnología avanzada para monitorear y proteger tanto los entornos industriales como tecnológicos,
los procesos, pero la falta de inversión en tecnología, la resistencia al cambio por parte de los y permitir la continuidad del negocio en caso de futuros incidentes.
colaboradores o la implementación deficiente de nuevas herramientas y sistemas podría generar
ineficiencias, mayores costos operacionales y pérdida de oportunidades de negocio. Estos desafíos Además, la Compañía ha establecido un Gobierno Corporativo en materia de ciberseguridad, que
pueden traducirse en demoras en la ejecución de proyectos estratégicos, interrupciones operativas incluye políticas y protocolos, planes de educación y formación continua para los empleados, y
y limitaciones para responder de manera ágil a las demandas del mercado. soluciones de seguridad cibernética diseñadas para responder a amenazas emergentes. Estas
 acciones permiten reducir la vulnerabilidad ante ciberataques y proteger los activos críticos de
Para mitigar este riesgo, CCU ha implementado un plan de transformación digital que incluye la Compañía, resguardando así su operatividad y reputación en un entorno digital cada vez más
inversiones en tecnologías avanzadas, capacitaciones periódicas para familiarizar a los colaboradores desafiante.
con nuevas herramientas y procesos, y una revisión constante de los sistemas y procedimientos
para su alineación con los Objetivos Estratégicos (Ver Capítulo “4 Estrategia”). Además, la Compañía
fomenta una cultura de innovación y cambio, promoviendo la adopción de soluciones tecnológicas C.3 RIESGO DE SEGURIDAD DE DATOS DE LOS CLIENTES
que mejoren la colaboración y la eficiencia.
 ESTAMOS EXPUESTOS AL RIESGO DE UN CIBERATAQUE QUE AFECTE NUESTRAS El riesgo de seguridad de datos de los clientes implica la posibilidad de acceso no autorizado,
 C.2 PLATAFORMAS DE INFORMACIÓN, LO QUE PODRÍA GENERAR UNA INTERRUPCIÓN pérdida o robo de información sensible, lo que puede resultar en sanciones regulatorias, pérdida de
 A NUESTRO NEGOCIO confianza de los clientes, daño a la reputación de la Compañía y costos significativos en respuesta
 a incidentes y medidas correctivas. La posibilidad de ocurrencia depende de la efectividad de las
La creciente digitalización de las operaciones ha aumentado la dependencia de las redes de datos y medidas de seguridad actuales, la sofisticación de las amenazas y la capacitación del personal.
los sistemas de tecnología de la información (TI), lo que expone a CCU al riesgo de ciberataques. Estos
incidentes pueden generar interrupciones en los procesos de producción, distribución y ventas, así como Para mitigar este riesgo, la Compañía aplica protocolos de seguridad robustos, realiza auditorías
pérdidas financieras, exposición de datos sensibles y daños a la reputación y la confianza de los clientes. de seguridad periódicas, capacita a sus colaboradores en prácticas de ciberseguridad, utiliza
 tecnologías de encriptación y autenticación, y establece planes de respuesta a incidentes. Estas
Un ciberataque exitoso puede resultar en la pérdida de ingresos debido a la interrupción de las acciones ayudan a proteger los datos de los clientes, mantener la confianza y cumplir con las
operaciones, así como en un aumento de los costos asociados a la restauración de sistemas y la regulaciones de privacidad.
implementación de medidas de recuperación.
Memoria Integrada 2024 / 3.6 Gestión de riesgos y control interno 66

[pág. 68]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
D Riesgos relacionados con la Sustentabilidad
 LA COMPAÑÍA OPERA EN GEOGRAFÍAS EXPUESTAS A DESASTRES NATURALES, su compromiso con el desarrollo sostenible y el bienestar de las personas. La comunicación
 D.1 DONDE ANTE UN EVENTO EXTRAORDINARIO PODRÍA TENER UN EFECTO NEGATIVO transparente y continua con las comunidades es fundamental para construir y mantener la confianza
 SOBRE NUESTRAS OPERACIONES Y POSICIÓN FINANCIERA y el apoyo necesarios para operar de manera efectiva.
La Compañía opera en geografías expuestas a desastres naturales, donde ante un evento extraordinario
 D.3
 LA DISPONIBILIDAD Y CALIDAD DEL AGUA PODRÍA IMPACTAR NEGATIVAMENTE
podría haber un impacto negativo significativo sobre las operaciones y la posición financiera. Aunque
 NUESTROS NEGOCIOS
la cobertura de seguros se ajusta a las políticas internas y a los estándares del mercado, en caso de
eventos extraordinarios los seguros pueden ser insuficientes para cubrir ciertas pérdidas.
 La disponibilidad y calidad del agua podría impactar negativamente los negocios de la Compañía. El
Actualmente, se mantiene una cobertura de seguro a todo riesgo, incluyendo averías de maquinaria agua es un componente esencial para la elaboración de nuestros productos y el riego de nuestros
y daños por interrupciones en las operaciones, terremotos e incendios para todos los activos en campos. Una falla en el suministro de agua, cambios normativos que limiten el uso de este recurso,
todos los países en que operamos. Sin embargo, las pólizas están sujetas a deducibles y límites de problemas de escasez hídrica producto del cambio climático, o una contaminación de las fuentes,
cobertura que, a pesar de estar alineados con los estándares del mercado, pueden ser insuficientes podría afectar negativamente las ventas e incrementar los costos, impactando la rentabilidad.
para dar cobertura a determinadas indemnizaciones. Además, el mercado de seguros es cíclico y
los eventos catastróficos podrían cambiar las condiciones del mercado, provocando incrementos La Compañía cuenta con procesos, políticas y procedimientos para optimizar el consumo de agua
en el costo de las primas y deducibles o, en casos excepcionales, la falta de disponibilidad de industrial y reducir el impacto de las operaciones en el medio ambiente. Desde el año 2010, se ha
cobertura por factores no relacionados con el negocio. implementado una Visión Medioambiental que establece metas de reducción de consumo de agua
 en las operaciones. Asimismo, la Compañía ha renovado su compromiso en la nueva Estrategia
 de Sustentabilidad que integra la Visión Medioambiental 2030. En particular, en lo que se refiere a
 D.2 NUESTRA CAPACIDAD DE OPERAR PODRÍA VERSE AFECTADA SI NO MANTENEMOS
 equilibrio hídrico, se compromete a seguir optimizando el consumo de agua por hectolitro producido.
 UNA BUENA RELACIÓN CON LAS COMUNIDADES DONDE OPERAMOS
 (Ver sección “9.1 Estrategia de Sustentabilidad”).
La capacidad de la Compañía para operar podría verse afectada si no se mantiene una buena
relación con las comunidades donde opera. Las operaciones dependen del apoyo y la aceptación
de las comunidades locales. Si no se logran relaciones positivas, podría haber oposición, protestas
o acciones legales que interrumpan las operaciones y dañen la reputación de la Compañía.
Para mitigar este riesgo, consideramos esencial involucrarse activamente con las comunidades
locales, escuchar sus preocupaciones y trabajar en colaboración para abordar cualquier problema. En
particular, la Compañía ha enfocado sus esfuerzos en trabajar estrechamente con las comunidades,
implementando planes de Relacionamiento Comunitario que beneficien a estas áreas y demuestren
Memoria Integrada 2024 / 3.6 Gestión de riesgos y control interno 67

[pág. 69]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 Código de Conducta en los Negocios y Código de Conducta del Directorio
3.6.2 Control interno
 En abril de 2004 se adoptó un Código de Conducta en los Negocios, el cual contiene un conjunto de
 Revisión de estructuras salariales principios, criterios, normas, pautas y reglas que deben orientar la conducta de cada uno de los integrantes
 de CCU, incluyendo Ejecutivos Principales y trabajadores. Este Código se actualiza periódicamente según
La revisión de la estructura salarial, de las políticas de compensación e indemnización para los la Administración lo considera necesario, siendo la última actualización en junio de 2022.
Ejecutivos Principales, se realiza a través de un procedimiento del que participa el Directorio,
mientras que, para la revisión del Gerente General, dicho rol es desempeñado por el Presidente CCU cuenta con un Comité de Conducta en los Negocios, integrado por el Gerente Corporativo
del Directorio. Este procedimiento no incluye la asesoría de terceros. de Recursos Humanos, quien lo preside, el Gerente General, el Contralor General, el Gerente
 Corporativo de Administración y Finanzas y el Gerente de Asuntos Legales, el cual tiene por función
Actualmente el plan de compensación del Gerente General y Ejecutivos Principales, no considera mantener actualizado dicho Código, así como velar por su cumplimiento, absolver las consultas
aprobación ni la divulgación de la estructura por parte de los accionistas. que de acuerdo a este Código se le formulen, en particular las relacionadas con el cumplimiento
 de la ley y normas reglamentarias vigentes, y recibir, conocer y analizar las denuncias recibidas,
 pudiendo también recomendar o imponer la aplicación de las medidas que correspondan.
 Plan de sucesión
 El Comité de Conducta en los Negocios celebrará sesiones ordinarias a lo menos ochos veces por
CCU cuenta con un procedimiento que contiene parámetros establecidos asociados a la sucesión de año calendario, en las fechas, horas y lugares que el propio Comité de Conducta en los Negocios
los Ejecutivos Principales y el Gerente General. El riesgo asociado a la sucesión de los ejecutivos es fije y sesiones extraordinarias cuando las cite especialmente el Presidente del Comité de Conducta
gestionado por la Gerencia Corporativa de Recursos Humanos quien identifica y recoge antecedentes en los Negocios, por sí o por indicación de uno o más miembros. Es obligación del Comité de
de las capacidades, conocimientos, condiciones, experiencias y visiones de sus Ejecutivos Principales Conducta en los Negocios informar al Comité de Auditoría de CCU S.A. semestralmente de las
y Gerente General. Lo anterior se realiza mediante procesos de Evaluación Desempeño, Evaluación denuncias recibidas e inmediatamente en el caso que se trate de materias relevantes.
Ascendente, Comité de Desarrollo Ejecutivo, entre otras. (Ver Capítulo “5 Personas”).
 Auditoría interna
De la Gerencia de Contraloría depende la Gerencia Corporativa de Auditoría Interna, cuyo alcance es
regional (Chile, Argentina, Paraguay, Uruguay, Bolivia y Colombia), reporta trimestralmente al Comité
de Directores, en cumplimiento de la Ley N° 18.046, y al Comité de Auditoría en cumplimiento de
la Ley SOX.
De las materias tratadas, acuerdos y propuestas de las reuniones de estos Comités se da cuenta
en la sesión del Directorio más próxima, que adopta los acuerdos pertinentes. El Contralor General
asiste como invitado a las sesiones del Directorio.
Memoria Integrada 2024 / 3.6 Gestión de riesgos y control interno 68

[pág. 70]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
Adicionalmente, en el año 2013 se adoptó un Código de Conducta del Directorio, actualizado Canal de Denuncias
en el año 2015 y en el año 2021, el cual cubre materias de confidencialidad, acceso a asesorías
externas, inducción de directores electos y revisión de la información relativa a candidatos a director, CCU cuenta con un Canal de Denuncias para atender cualquier reclamo o denuncia, sobre
y establece reglas y procedimientos respecto de conflictos de interés. Ambos Códigos se encuentran actuaciones o comportamientos que puedan ser contrarios a la normativa legal o los principios
disponibles en nuestro sitio web www.ccu.cl y www.ccuinvestor.com. establecidos en el Código de Conducta en los Negocios, al que tienen acceso no solo los
 trabajadores, sino también accionistas, clientes, proveedores y terceros ajenos a la Compañía.
 Modelo de Prevención de Delitos Dicho Canal de Denuncias es administrado por un servicio externo e independiente, permite recibir
 y gestionar las denuncias, garantizando la confidencialidad y seguridad de la información entregada,
Nuestro Modelo de Prevención de Delitos (MPD), el cual contiene todos los elementos para así como el anonimato del denunciante, quien a su vez puede consultar y conocer el estado del
prevenir el riesgo de comisión de conductas típicas en el marco de la gestión empresarial, según proceso. Nuestro Canal de Denuncias mantiene un vínculo bidireccional con el denunciante, con
lo dispuesto en la Ley N° 20.393 que establece la Responsabilidad Penal de las Personas Jurídicas el objetivo de atender cualquier reclamo o denuncia que se realice. En ese sentido, y de acuerdo
en Chile. con los más altos estándares éticos que siempre hemos adoptado, la persona que denuncia tiene
 la absoluta certeza que la denuncia es anónima y está exenta de cualquier tipo de represalias.
El 1 de septiembre de 2024 entró en vigencia la Ley N° 21.595 de Delitos Económicos, cuyo
propósito central es prevenir la perpetración de delitos económicos a través de imposición de Se puede acceder al Canal de Denuncias de las siguientes maneras:
mayores exigencias a las personas jurídicas y sus sistemas de cumplimiento interno, por lo que
CCU ha realizado las adecuaciones necesarias a su modelo. El MPD aplica para CCU S.A. y sus Ingresando al link del sistema de denuncias (https://ccu.ines.cl/ccu/formulario/) a través de
filiales y fue aprobado por el Directorio. cualquier plataforma web oficial de las operaciones CCU en Chile, Argentina, Bolivia, Uruguay y
 Paraguay, incluyendo el sitio web www.ccu.cl, la intranet corporativa, el portal de proveedores
En la implementación del MPD se identificaron todos los procesos que, por su naturaleza, estaban y de clientes. Las denuncias pueden ser anónimas, confidenciales y seguras.
expuestos a riesgos de realización de las conductas sancionadas en la ley, estableciendo controles Directamente a través del área o unidad de trabajo del denunciante, o a través del mismo enlace
con el objeto de mitigar los mismos. del sistema de denuncias, si no se requiere confidencialidad.
 A través del correo electrónico denunciaccu@ccu.cl.
El Encargado de Prevención de Delitos, reporta al Directorio una vez al año el plan de trabajo anual
y semestralmente la gestión del MPD en cumplimiento de lo dispuesto en la Ley N° 20.393, sin Recibida la denuncia a través de alguna de las vías antes indicadas, se realiza una investigación y
perjuicio de estar facultado para concurrir al Directorio a reportar cualquier situación que requiera es informada al Comité de Conducta en los Negocios más próximo. Sin perjuicio de lo anterior, el
su conocimiento o decisión. Hasta la fecha, no se han registrado sanciones en este ámbito. Comité de Conducta en los Negocios o el Gerente Corporativo de Auditoría interna puede siempre
 recibir directamente una denuncia o decretar de oficio una investigación en relación con las materias
 de su competencia. Semestralmente, se presenta en el Comité de Auditoría de CCU S.A. un resumen
 de todas las denuncias recibidas, su análisis y planes de acción a implementar, y en cada una de las
 sesiones del Comité de Conducta en los Negocios.
Memoria Integrada 2024 / 3.6 Gestión de riesgos y control interno 69

[pág. 71]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
3.7 Relación con los grupos de interés y el público en general
3.7.i Grupos de interés
CCU mantiene una relación transparente y abierta con sus grupos de interés, contando con canales de comunicación permanentes y adecuados con cada uno de ellos, que permitan entregar información
relevante, oportuna y clara sobre el desarrollo de las actividades de la Compañía.
 Trabajadores ¿Qué temas tratamos?
 Cuidado y seguridad de las personas, continuidad operacional, desempeño económico, social y
 Compuesto por todos los trabajadores de CCU S.A y sus filiales. ambiental de la Compañía, remuneración y beneficios, relaciones laborales, planes de carrera,
 nuevas formas de trabajo e integración regional junto a noticias de interés común de la Compañía
 a nivel general.
 ¿Qué canales usamos?
¿Por qué nos relacionamos?
 Página web www.ccuinvestor.com / www.ccu.cl Evaluación de desempeño y ascendente
Para CCU, las personas son el principal motor de la Compañía ya que constituyen un eje central y Intranet corporativa Líderes y jefaturas
estratégico. Buscamos promover el desarrollo y crecimiento de nuestras personas, potenciar sus Mailings y newsletters Reuniones con sindicatos
talentos y su compromiso con el propósito y los valores de CCU a través de un clima laboral positivo, Sistemas informativos como pantallas o Procesos de planificación estratégica
que permita a los trabajadores identificarse y sentir orgullo de formar parte de la Compañía. carteles en lugares de tránsito de personas Memoria Anual
 Encuesta de clima organizacional; bajada de Canal de Denuncias
¿Cómo nos comunicamos? resultados y generación de planes de acción
Mantenemos una comunicación permanente con nuestras personas, tanto de forma directa como
indirecta, utilizando medios internos y externos de la Compañía. Reuniones, actividades laborales
o de recreación, envío de mailings y publicación en pantallas, son instancias de comunicación que
van creando nuestra cultura interna basada en el SER CCU y permiten ir fortaleciendo los Principios
de la Compañía.
La Gerencia Corporativa de Recursos Humanos es la encargada de establecer las directrices y
gestionar las relaciones con este grupo de interés.
Memoria Integrada 2024 / 3.7 Relación con los grupos de interés y el público en general 70

[pág. 72]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 Proveedores Clientes
 En este grupo consideramos todos aquellos proveedores que nos suministran Referido a quienes venden y comercializan nuestros productos, como
 de forma directa materias primas e insumos, materiales de fabricación, bienes almacenes, botillerías, tiendas de conveniencia, autoservicios, supermercados,
 y servicios. mayoristas, restaurantes, hoteles, entre otros.
¿Por qué nos relacionamos? ¿Por qué nos relacionamos?
Los proveedores son un aliado estratégico en nuestra gestión y son una parte fundamental de Gracias a una extensa red de clientes, nuestros productos llegan a millones de personas en los
nuestra cadena de valor, con quienes buscamos establecer relaciones colaborativas y de largo países donde operamos y que nos permiten estar cerca de los consumidores. A ellos les entregamos
plazo que nos permitan alcanzar las metas establecidas a nivel estratégico en nuestros tres pilares: productos de calidad, con el mejor servicio y máxima ejecución.
crecimiento, rentabilidad y sustentabilidad. El compromiso de largo plazo con nuestros proveedores
es central para la estrategia de la Compañía, aportando a su desarrollo alineados con nuestra ¿Cómo nos comunicamos?
Estrategia de Sustentabilidad.
 Generamos oportunidades de crecimiento conjunto en el largo plazo. Para ello medimos su satisfacción,
¿Cómo nos comunicamos? monitoreamos sus expectativas y detectamos oportunidades de mejora que nos permiten seguir avanzando
 en la relación con ellos a través de una fuerza de venta comprometida y con pasión por el servicio.
La Gerencia Corporativa de Abastecimiento, que depende de la Gerencia Corporativa de Administración
y Finanzas, es la encargada de establecer las directrices y gestionar las relaciones con este grupo de Las gerencias de ventas son las encargadas de establecer las directrices y gestionar las relaciones
interés. con este grupo de interés.
¿Qué temas tratamos? ¿Qué temas tratamos?
Resolución de inquietudes, proyectos conjuntos, plazos de pago, canales de comunicación, Consultas y reclamos, desempeño económico, social y ambiental, innovaciones de productos,
homologación de requisitos de productos y servicios, auditorías de proveedores. publicidad, educación y capacitación, apoyo financiero.
¿Qué canales usamos? ¿Qué canales usamos?
 Servicios de atención a clientes
 Página web www.ccuinvestor.com / www.ccu.cl Encuesta de Proveedores Página web www.ccuinvestor.com / www.ccu.cl Contacto con fuerza de ventas
 Portal de proveedores Procesos de licitación CRECCU Mailings
 Mailings Memoria Anual Mi Carro Memoria Anual
 Reuniones técnicas de planificación Canal de Denuncias Portal web de clientes créditos Canal de Denuncias
Memoria Integrada 2024 / 3.7 Relación con los grupos de interés y el público en general 71

[pág. 73]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 Consumidores Comunidades
 Ad portas de cumplir 175 años de tradición, los productos de CCU llegan a Se consideran las personas, juntas de vecinos, organizaciones funcionales,
 millones de personas en Chile y en los países donde operamos que prefieren organizaciones de base, y todas las instituciones y empresas que se
 nuestras marcas. Este grupo abarca a todas las personas que consumen encuentren en el radio de influencia de nuestras operaciones, en los países
 nuestros productos. donde operamos.
¿Por qué nos relacionamos? ¿Por qué nos relacionamos?
Queremos conocer cada día más a nuestros consumidores, de manera de poder ofrecerles SER CCU es situar el bien de las personas en el centro de nuestro quehacer y de nuestras decisiones.
productos que se transformen en sus preferidos. Con un amplio portafolio multicategoría, los Por esta razón, nuestra relación con la comunidad es fundamental, basada en el diálogo, la confianza
acompañamos en distintos momentos de la vida, llevándoles productos de alta calidad, que buscan y el trabajo conjunto para generar vínculos de largo plazo.
satisfacer todas las ocasiones de consumo.
 ¿Cómo nos comunicamos?
¿Cómo nos comunicamos?
 En cada una de las interacciones que tenemos con la comunidad hay una oportunidad de
A través de atractivas campañas y publicidad, pensadas en cada uno de nuestros consumidores, comunicación y de aportar a un mejor vivir. Buscamos influir positivamente en la vida de las
donde buscamos acercarnos y darnos a conocer. comunidades cercanas a nuestras zonas de operación, manteniendo reuniones periódicas y
 desarrollando proyectos en conjunto, potenciando el desarrollo local.
La Gerencia de Desarrollo Comercial, que depende de la Gerencia de Planificación Estratégica y
Nuevos Negocios, es la encargada de liderar y entregar las directrices respecto a esta temática. La Subgerencia de Asuntos Públicos y Gestión Territorial, perteneciente a la Gerencia de Asuntos
 Corporativos y Sustentabilidad, es la encargada de establecer las directrices y gestionar las relaciones
¿Qué temas tratamos? con este grupo de interés. Además, contamos con un equipo de Relacionadores Comunitarios,
 quienes están encargados de la ejecución del plan de Relacionamiento Comunitario Local, debiendo
Ocasiones de consumo, nuevas tendencias, campañas de consumo responsable de alcohol, ejercer la vocería, monitoreo y reporte de contingencias locales.
lanzamiento de productos y atributos de productos.
 ¿Qué temas tratamos?
¿Qué canales usamos?
 Temas específicos de cada localidad, informamos sobre el desempeño económico, social y ambiental
 Página web www.ccuinvestor.com / www.ccu.cl Servicio de atención al consumidor de la Compañía cuando es relevante para la comunidad, consumo responsable de alcohol, seguridad
 Publicidad en redes sociales, televisión y radio, Portal La Barra vial, contribución medioambiental, aporte cultural y social.
 vía pública y otros medios de comunicación Canal de Denuncias
 Estudio de tendencias del consumidor
Memoria Integrada 2024 / 3.7 Relación con los grupos de interés y el público en general 72

[pág. 74]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
¿Qué canales usamos? La Subgerencia de Asuntos Públicos y Gestión Territorial, perteneciente a la Gerencia de Asuntos
 Corporativos y Sustentabilidad, es la encargada de establecer las directrices y gestionar las relaciones
 Página web www.ccuinvestor.com / www.ccu.cl Plan anual de relacionamiento comunitario con este grupo de interés.
 Reuniones y mesas de trabajo Memorial Anual
 Programas específicos por área de influencia Canal de Denuncias ¿Qué temas tratamos?
 Desempeño económico, social y ambiental, relación con los grupos de interés, denuncias, proyectos
 Sociedad en general en conjunto, cambios regulatorios, tendencias de consumo, información relevante para la sociedad
 en general.
 En este grupo se consideran reguladores(2), fundaciones, organizaciones
 gubernamentales y no gubernamentales (ONG’s), líderes de opinión, ¿Qué canales usamos?
 organizaciones sociales, organizaciones de servicio y orden público,
 medios de comunicación y sociedad en general. Página web www.ccuinvestor.com / www.ccu.cl Memoria Anual
 Redes sociales Formulario 20-F
 Seminarios y eventos Press release de resultados financieros
¿Por qué nos relacionamos? Mesas de trabajo Reuniones formales (Ley del Lobby)
 Reuniones Canal de Denuncias
Como compañía la transparencia en la entrega de información es fundamental para la operación Comunicados de prensa
de nuestra Compañía, donde el contar con la disponibilidad para responder a cualquier entidad
sus consultas y requerimientos, nos permite conocer inquietudes y desarrollar conocimiento.
Además, dentro de la sociedad, nos enorgullece ser parte de la historia de los ciudadanos ad portas
de cumplir 175 años en 2025, donde además de aportar al crecimiento económico de los países
donde operamos, buscamos fomentar el desarrollo y bienestar de la sociedad, poniendo el bien
de las personas y del planeta como eje central de nuestras decisiones.
Dentro de la identidad de SER CCU, buscamos estar presentes en ocasiones que la ciudadanía nos
necesite, involucrándonos en forma ágil y tangible en situaciones de emergencia.
¿Cómo nos comunicamos?
Mantenemos canales permanentes con la ciudadanía, dentro y fuera de la zona de influencia directa
de nuestras operaciones.
(2) Para mayor información diríjase a la sección “6.1 Sector industrial – Entidades reguladoras nacionales o extranjeras”.
Memoria Integrada 2024 / 3.7 Relación con los grupos de interés y el público en general 73

[pág. 75]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
 Inversionistas y analistas Asimismo, la sección de Relación con Inversionistas cuenta con su propio sitio web www.ccuinvestor.com,
 donde se encuentran reportes trimestrales de resultados, estados financieros, memorias anuales y Formulario
 Representados por actuales accionistas y potenciales inversionistas basados 20-F. Además, se encuentran los hechos esenciales e información de interés para el mercado
 tanto en Chile como en el extranjero, y analistas financieros, de diversos tales como dividendos, ofertas públicas, colocaciones de bonos, y nuestras prácticas de gobierno
 bancos e instituciones financieras nacionales e internacionales. corporativo, entre otros. Este sitio se encuentra disponible tanto en inglés como en español, dando
 cumplimiento a la normativa chilena y extranjera.
 Trimestralmente se publica un detallado análisis de sus resultados por cada Segmento de operación,
¿Por qué nos relacionamos? luego de los cuales el Gerente General junto con el Gerente Corporativo de Administración y
 Finanzas y el equipo del área de Relación con Inversionistas, realizan una conferencia telefónica
Los accionistas e inversionistas, son actores claves para el crecimiento y posicionamiento de donde se explican los lineamientos estratégicos de CCU y se responden las consultas de analistas
nuestra Compañía, donde su compromiso y confianza es de suma relevancia para potenciar nuestra e inversionistas.
propuesta de valor y estrategia en el largo plazo. Por su parte, los analistas financieros son una
fuente de información relevante acerca de la visión del mercado en nuestra Compañía, y a la vez, Asimismo, CCU S.A. participa en diversas conferencias de bancos locales e internacionales y realiza
contribuyen a difundir nuestro desempeño al mercado en general. anualmente roadshows locales y en el extranjero. Adicionalmente, atiende a un gran número de
 inversionistas y analistas durante el año. La Compañía busca permanentemente nuevas herramientas
¿Cómo nos comunicamos? tecnológicas para desarrollar su estrategia de Relación con Inversionistas.
La Compañía cuenta con una subgerencia de Relación con Inversionistas que depende de la ¿Qué temas tratamos?
Gerencia Corporativa de Administración y Finanzas. Al mismo tiempo, cuenta con la Gerencia de
Asuntos Corporativos y Sustentabilidad encargada de la relación con los medios de comunicación. Desempeño económico, social y ambiental, avances del Plan Estratégico, marco normativo,
Asimismo, los portavoces oficiales de CCU ante los inversionistas son el Gerente de Planificación adaptación a nuevas regulaciones, proyectos e inversiones.
Financiera y Relación con Inversionistas y el Gerente Corporativo de Administración y Finanzas. El
portavoz oficial de CCU con los medios de comunicación es el Gerente de Asuntos Corporativos y ¿Qué canales usamos?
Sustentabilidad. Lo señalado anteriormente es sin perjuicio de la representación que le corresponde
al Presidente del Directorio y al Gerente General.
 Página web www.ccuinvestor.com / www.ccu.cl Mailings
CCU mantiene una relación transparente y abierta con sus accionistas, inversionistas, analistas, y Reuniones, conferencias y roadshows Memoria Anual
la comunidad en general. En nuestro sitio web corporativo (www.ccu.cl) se encuentra disponible Junta de Accionistas Hechos esenciales
tanto para el público en general, como también para inversionistas y analistas, información de Formulario 20-F Información de interés para el mercado
la Compañía en relación a nuestros proveedores, nuestras marcas, presencia regional, canal de Press release de resultados financieros Canal de Denuncias
denuncias, nuestras iniciativas de consumo responsable, noticias, publicaciones e información de
contacto, entre otros aspectos relevantes de la Compañía.
Memoria Integrada 2024 / 3.7 Relación con los grupos de interés y el público en general 74

[pág. 76]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
3.7.ii Estudio de Doble Materialidad
La Compañía ha adoptado como práctica la realización de análisis de materialidad cada dos años Si bien la Compañía no cuenta con un procedimiento formal de mejora continua para sus
desde 2018, evolucionando hacia un enfoque de doble materialidad en los últimos ciclos. Este enfoque comunicaciones al mercado, el Estudio de Doble Materialidad, le permite identificar áreas de mejora
reconoce la interconexión entre los impactos financieros internos y los impactos en los diversos y garantizar que sus comunicaciones sean oportunas y comprensibles.
grupos de interés. Por lo tanto, para asegurar una identificación y priorización efectiva de los temas
más relevantes, junto a una empresa de asesoría externa experta en la materia, se lleva a cabo el De la quinta etapa, se obtiene como resultado la siguiente matriz de doble entrada con 16 temas
Estudio de Doble Materialidad. materiales:
Este estudio identifica y prioriza temas que pueden afectar positiva o negativamente a los grupos de
 + 1 Gestión del agua
interés, el entorno y la gestión empresarial. Así, la Compañía puede anticiparse a los desafíos futuros y
tomar decisiones estratégicas informadas, garantizando su sustentabilidad y resiliencia. Además este 2 Calidad y seguridad de productos
estudio, que sigue los lineamientos del GRI y la NCG N°461 de la CMF, considera los indicadores SASB del 3 Gestión de residuos y economía circular
sector bebidas alcohólicas y no alcohólicas brindando transparencia y comparabilidad en los resultados. 1
 4 Ética y transparencia
 3 2
El desarrollo de este estudio estuvo compuesto por cinco etapas: 4 5 Relación con las comunidades
 Materialidad de impacto
 5
 6 6 Marketing y consumo responsable
 1 3 4
 Identificación de impactos Evaluación Priorización de ejecutivos 7 7 Seguridad y bienestar de trabajadores
 Taller de priorización de temas 8
 Revisión de documentos internos 30 8 Privacidad de datos
 Consulta interna
 Análisis de prensa y redes materiales, para la elaboración de 13 9
 sociales Entrevistas a directores matriz de doble materialidad. 10 9 Satisfacción de clientes y consumidores
 12
 y Ejecutivos Principales
 Revisión de tendencias y 10 Cadena de suministro
 11
 estándares
 801 11 Ciberseguridad
 Benchmark y tendencias 14
 15
 Encuestas a trabajadores 12 Transformación digital e innovación
 2 5 13 Cambio climático y emisiones GEI
 Definición de temas materiales 9 Validación
 14 Atracción y desarrollo de talento
 Consulta externa
 Análisis de documentos Encuestas a Inversionistas Aprobación de la matriz de doble
 internos materialidad resultante por la 15 Diversidad, equidad e inclusión
 1.451 - Materialidad financiera +
 6 entrevistas a expertos y Gerencia de Asuntos Corporativos
 autoridades Clientes y Sustentabilidad y Gerencia de
 Análisis preliminar de Contraloría de CCU.
 215 Para ver más información y detalle hacer click en el
 impactos y riesgos
 número del tema material
 Proveedores
Memoria Integrada 2024 / 3.7 Relación con los grupos de interés y el público en general 75

[pág. 77]
Capítulos / 1 2 3 Gobierno Corporativo 4 5 6 7 8 9 10 11 12
3.7.iii Procedimiento de Elección de Directores 3.7.iv Participación en Juntas de Accionistas
La Compañía cuenta con un “Procedimiento de Elección de Directores en Juntas de Accionistas”, que La Compañía no estima necesario contar con un sistema o procedimiento que permita a los accionistas
forma parte del Código de Conducta del Directorio, cuyo objetivo es permitir la adecuada difusión de participar y ejercer su derecho a voto por medios remotos, debiendo analizarse caso a caso, ya que se
los antecedentes de quienes postulen al cargo de director, contribuyendo a la decisión que adopten prefiere la participación presencial de accionistas, sea personalmente o debidamente representados
los accionistas en las elecciones respectivas. por sus apoderados. El Directorio de CCU S.A., de conformidad a la normativa legal aplicable, es
 quién define la forma de participación en la Junta de Accionistas. En virtud de lo anterior, en su sesión
Conforme a dicho procedimiento, corresponde al Gerente de Asuntos Legales o, en su defecto, quién celebrada el día 6 de marzo de 2024, aprobó el mecanismo de participación a distancia en la Junta
haga las veces de Secretario del Directorio de CCU S.A., recibir los currículum que presenten quienes Ordinaria de Accionistas del año 2024.
postulen al cargo de director, debiendo difundir dicha información en el sitio web de la Compañía,
recibir la declaración jurada que deben presentar los candidatos a directores independientes de Los acuerdos adoptados por las Juntas podrán ser conocidos por el público general de acuerdo a la
acuerdo a lo dispuesto en el artículo 50 bis de la Ley N° 18.046 sobre Sociedades Anónimas, e informar normativa vigente, no estimándose necesario contar con un mecanismo, sistema o procedimiento
a los accionistas en el referido sitio web la lista de candidatos a directores que hubieren aceptado que permita a dicho público informarse en tiempo real de tales acuerdos.
su nominación y declarado no tener inhabilidades para desempeñar el cargo.
En el referido procedimiento, no obstante, no se contempla expresamente (i) la obligación de informar
acerca de la diversidad de capacidades, condiciones, experiencias y visiones que en opinión del
Directorio resulta aconsejable tengan quienes formen parte del mismo; (ii) una instancia que tenga
como objetivo ayudar a los accionistas en la búsqueda y elección de candidatos al Directorio; ni
(iii) políticas para guiar la conformación de las nóminas que se provea a los accionistas de manera
que exista diversidad en sus integrantes o que los integrantes de esa nómina de un mismo sexo no
superen 60% del total. Lo anterior, debido a que esta es una materia de exclusiva competencia de
los accionistas reunidos en Junta de Accionistas.
Lo indicado precedentemente es sin perjuicio de lo establecido en la Ley N° 18.046 sobre Sociedades
Anónimas, relativa a la obligación del Directorio de la matriz de una sociedad fiscalizada por la CMF de
establecer y difundir una política general de elección de directores en sus filiales que cumpla con las
menciones mínimas establecidas por la CMF, las que se contienen en la NCG N° 533 emitida con fecha
11 de marzo de 2025. Dicha política deberá ser publicada a más tardar el 11 de diciembre de 2025.
Memoria Integrada 2024 / 3.7 Relación con los grupos de interés y el público en general 76

[pág. 78]
4
 Capítulos / 1 2 3 4 Estrategia 5 6 7 8 9 10 11 12
 4.1 Horizontes de tiempo 78
 4.2 Objetivos estratégicos 2025 - 2027 79
 4.3 Planes de inversión 80
 2.3.1 Situación de control 25
 2.3.2 Cambios importantes en la
 propiedad o control 2
 Estrategia
Memoria Integrada 2024 77

[pág. 79]
Capítulos / 1 2 3 4 Estrategia 5 6 7 8 9 10 11 12
4.1 Horizontes de tiempo
El desarrollo de nuestra actividad se estructura en torno a tres pilares que dan forma a nuestra
estrategia y que mantenemos balanceados permanentemente, estos son: Rentabilidad, Crecimiento y
Sustentabilidad. Bajo el pilar de Rentabilidad, nos enfocamos en maximizar el valor económico de los
negocios donde operamos, optimizando el retorno final de nuestras inversiones, como consecuencia de
mejores márgenes operacionales y el uso eficiente de los recursos. Con respecto al pilar Crecimiento,
buscamos incrementar el tamaño y alcance de nuestra operación, lo que se logra, atendiendo nuevas
necesidades, canales, nuevas ocasiones de consumo y entrando en nuevas regiones, negocios y
categorías. Finalmente, bajo el pilar de Sustentabilidad, aseguramos el valor de la Compañía a largo
plazo, considerando el bienestar actual y futuro de todas las personas con las que nos relacionamos,
el desarrollo de nuestras marcas, el cuidado del medio ambiente y los derechos humanos.
Así, para desarrollar y dar seguimiento a la estrategia de la Compañía, contamos con un proceso
formal de planificación estratégica, que involucra la creación de objetivos estratégicos de largo plazo,
a través de planes trianuales, aprobados y monitoreados periódicamente por el Directorio. En la
elaboración de estos objetivos participa activamente el Comité de Dirección, liderado por la Gerencia
Corporativa de Desarrollo, la que constantemente evalúa y monitorea nuestro entorno, de modo de
adaptar en tiempo y forma nuestra estrategia a los nuevos desafíos de la Compañía.
En el año 2024 finalizamos la ejecución del plan regional “HérCCUles”, que iniciamos en el año
2022 con el objetivo de recuperar nuestros resultados financieros. Asimismo, durante el año 2024
elaboramos el Plan Estratégico 2025 - 2027, el que cuenta con cuatro Objetivos Estratégicos en
torno a nuestros tres Pilares Estratégicos: Rentabilidad, Crecimiento y Sustentabilidad. El primer
Objetivo Estratégico es Mejorar márgenes operacionales, el segundo es Capitalizar oportunidades
de crecimiento, expandiendo la escala de negocios y fortaleciendo nuestra presencia regional; el
tercero es Ejecutar “Juntos por un Mejor Vivir”, en sus dos ejes Planeta y Personas. Finalmente, todo
lo anterior se refleja en los Segmentos de operación, donde el cuarto Objetivo Estratégico define
con claridad los focos, desafíos y acciones específicas para cada uno, para alcanzar así las metas
establecidas en el Plan Estratégico 2025 - 2027.
Memoria Integrada 2024 / 4.1 Horizontes de tiempo 78

[pág. 80]
Capítulos / 1 2 3 4 Estrategia 5 6 7 8 9 10 11 12
4.2 Objetivos estratégicos 2025 - 2027
 SU
 AD
 E RE TE
 R
 D
 NT
 DA NT N TA B I L I
 C
 O
 S
 D
 ABILI CIMIE
 1 2 3
 Mejorar márgenes operacionales Capitalizar oportunidades de crecimiento Ejecutar Juntos por un Mejor Vivir
 Gestión de Eficiencias (GEF) bajo 2 ejes y 7 frentes, Negocios con escala: Mantener y/o aumentar valor Concretar avances en nuestra Estrategia de Sustentabilidad
 buscando optimizar procesos e incorporar tecnología: marcario y participación de mercado 2030 en sus dos ejes Personas y Planeta y 8 agendas
 de trabajo:
 GEF Márgenes: Negocios con baja escala: Crecer en valor marcario y
 Gestión de Ingresos participaciones de mercado Equilibrio hídrico, Vocación Circular, Desafío climático
 Abastecimiento / Costos y Abastecimiento responsable en el eje Planeta
 Fortalecer posición competitiva en la región
 GEF Gastos: Experiencia SER CCU, Pasión por el consumidor,
 Foco en innovación de alto margen
 Industrial Disfrute consciente y Progreso país en el eje Personas
 Marketing
 Administración
 Ventas
 Planificación y Logística
 4
 Focos específicos para cada Segmento de Operación
Memoria Integrada 2024 / 4.2 Objetivos estratégicos 2025 - 2027 79

[pág. 81]
Capítulos / 1 2 3 4 Estrategia 5 6 7 8 9 10 11 12
4.3 Planes de inversión
El crecimiento en cada uno de los Segmentos de operación requiere de permanentes inversiones, La Compañía revisa periódicamente su programa de inversiones y lo adecua a las necesidades del
lo que significó en el año 2024 un flujo de efectivo relativo a compras de propiedades, plantas y negocio, por lo tanto, no se puede asegurar que los montos mencionados se ejecuten en los términos
equipos, por CLP 160.086 millones. Las inversiones fueron principalmente destinadas a aumentar y plazos indicados.
capacidad, mejorar la calidad de los procesos productivos, apoyar la innovación, introducir mejoras
medioambientales e inversiones relacionadas con cumplimiento normativo y dar soporte a los Adicionalmente dentro de nuestro Plan Estratégico para los próximos años evaluamos permanentemente
procesos de ejecución en el mercado. De este total, el flujo de efectivo en Chile relativo a compras posibles adquisiciones totales o parciales en los países que operamos.
de propiedades, plantas y equipos alcanzó a CLP 128.793 millones.
El plan de inversiones para apoyar el crecimiento orgánico a nivel consolidado contempla invertir
CLP 193.459 millones en 2025, compuesto principalmente por CLP 87.192 millones en activos de Políticas de Inversión y Financiamiento
producción, que incluye la implementación de nueva línea de envasado en Renca, Santiago de Chile
y otras inversiones relacionadas a cumplimiento normativo, actualización de nuestras plataformas Las inversiones que realiza la Compañía están orientadas tanto a la reposición normal de activos
tecnológicas y mejoras en las operaciones en nuestros negocios en Chile y Argentina, CLP 18.844 millones operacionales, modernizaciones y nuevas instalaciones para ampliar y mejorar la capacidad
en activos de distribución a fin de optimizar nuestras operaciones logísticas, CLP 28.680 millones en productiva, así como a la adquisición –con fines de crecimiento– de participaciones en empresas
envases y embalajes retornables y CLP 25.048 millones en activos de marketing. La inversión en Chile afines a sus actividades en Chile y en el exterior.
corresponde a CLP 145.793 millones, lo cual incluye la inversión de los segmentos de operación Chile,
Vinos (correspondiente a Chile), entre otros. Estas cifras pueden sufrir ajustes dependiendo de las El financiamiento de las inversiones proviene principalmente del flujo operacional generado por
condiciones de mercado y de las necesidades de la Compañía. la Compañía, complementado con deuda del mercado financiero, velando siempre por mantener
 un perfil financiero saludable.
El programa de inversiones proyectado para el período 2025 - 2028 en cada uno de los Segmentos
de operación se indican a continuación: La Compañía invierte sus excedentes de caja en depósitos a plazo, depósitos overnight y pactos.
 Asimismo, realiza operaciones de seguro de cambio para calzar sus saldos de balance en monedas
 Segmentos de operación extranjeras.
 2025 2026 2027 2028
 (Millones de CLP)
Chile 113.437 115.034 107.416 106.657
Negocios Internacionales 47.666 44.824 42.060 45.982
Vinos 16.117 18.338 20.338 16.037
Otros 16.239 6.121 1.939 1.106
Total 193.459 184.317 171.752 169.782
Memoria Integrada 2024 / 4.3 Planes de inversión 80

[pág. 82]
5
 Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
 5.1 Dotación de personal 2024 84
 5.1.1 Por género 84
 5.1.2 Por nacionalidad 85
 5.1.3 Por rango de edad 86
 5.1.4 Por antigüedad laboral 86
 5.1.5 Personas con discapacidad 87
 5.2 Formalidad laboral 87
 5.3 Adaptabilidad laboral 88
 5.4 Equidad salarial por género 88
 5.4.1 Política de equidad 88
 5.4.2 Brecha salarial 89
 5.5 Acoso laboral, sexual y violencia en
 el trabajo 89
 5.6 Seguridad laboral 90
 5.7 Permiso postnatal 92
 5.8 Capacitación y beneficios 93
 5.9 Política de subcontratación 101
 5.10 Ambiente laboral, identificación de 101
 Personas capacidades y conocimentos
 5.10.1 Gestión de desempeño 101
 5.10.2 Evaluación ascendente 102
 5.10.3 Reclutamiento y selección 102
 5.10.4 Movilidad y promoción interna 102
 5.10.5 Gestión de talento 103
 5.10.6 Bienestar emocional en el trabajo 103
Memoria Integrada 2024 81

[pág. 83]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
Personas
La visión corporativa nos inspira a reconocer el valor y compromiso de nuestras personas,
impulsando experiencias laborales para que alcancen su máximo potencial y construyamos juntos
un mejor vivir.
En este sentido, nuestras personas son el principal motor de la Compañía, por lo que buscamos su
desarrollo integral y promovemos que vivan los principios corporativos en un ambiente de buen
clima organizacional y seguridad.
De esta manera el desarrollo del negocio está guiado por principios basados en convicciones sólidas
y profundas que son el reflejo de la forma en que trabajamos y la impronta con el que hacemos
nuestra labor.
Quienes trabajamos en CCU estamos muy orgullosos de nuestra identidad SER CCU, que a través
de los principios de Excelencia, Entrega, Integridad y Empoderamiento, marca un sello distintivo
de las personas, articula nuestro quehacer y guía la toma de decisiones.
 Excelencia Entrega Integridad Empoderamiento
 Somos apasionados Procuramos el bien de Cumplimos las normas Nos mueve una
 por la calidad y el los demás y de nuestro que nos regulan, actitud emprendedora,
 trabajo bien hecho. entorno, en armonía siempre inspirados en innovadora y proactiva.
 con nuestros legítimos actuar correctamente.
 intereses.
Memoria Integrada 2024 / Personas 82

[pág. 84]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
Basándonos en nuestra estrategia de gestión de personas, en CCU nos comprometemos a crear CCU cuenta con un total de 56 sindicatos de los cuales 45 se encuentran en Chile, 9 en Argentina,
experiencias laborales positivas, priorizar la seguridad y fomentar oportunidades para todos los 1 en Uruguay y 1 en Bolivia, mientras que en Paraguay no hay sindicatos. En términos de afiliación,
trabajadores. Para ello, damos especial importancia a incrementar la participación de las mujeres 4.244 trabajadores se encuentran sindicalizados en Chile, 1.655 en Argentina, 58 en Uruguay y 115
en el ámbito laboral e impulsar la inclusión en el trabajo. “Juntos por un Mejor Vivir” reconoce en Bolivia alcanzando un 56,7% de trabajadores sindicalizados a nivel regional. Adicionalmente,
el aporte y contribución de cada trabajador, así como construimos relaciones de confianza a tanto en Chile como en Bolivia los sindicatos cuentan con adherentes que perciben extensión de
través de experiencias significativas durante su trayectoria laboral. (Ver sección “9.1 Estrategia de beneficios, sumando 773 trabajadores en Chile y 8 en Bolivia. No se registraron huelgas durante
Sustentabilidad”). el año 2024 en ningún país donde operamos.
Impulsamos un entorno de trabajo seguro y saludable en un marco de respeto por los Derechos
Humanos en el desempeño laboral de todas las personas. La Política de Diversidad e Inclusión de
CCU valora el sello propio de cada trabajador, con visiones, experiencias y orígenes o condiciones
distintas. Adicionalmente, contamos con una Política Corporativa de Derechos Humanos CCU(3),
que tiene por objetivo entregar un marco de acción y relevar el valor de quienes integran la
Compañía, considerando su origen, experiencia, intereses y condiciones distintas. De esta manera,
renovamos el compromiso con la valoración de equipos diversos, favoreciendo el desarrollo personal
y laboral de sus trabajadores. Esta directriz está desarrollada en el marco de la Política Corporativa
de Derechos Humanos, a nivel regional.
En concreto el Comité de Conducta en los Negocios y el Canal de Denuncias, nos permite actuar
con debida diligencia para enfrentar situaciones que afecten a nuestros trabajadores en materias
de derechos humanos. También se adoptaron otras políticas y procedimientos operacionales en
concordancia con estos compromisos. En gestión de riesgos, realizamos evaluaciones de derechos
humanos en las prácticas laborales, correspondientes al cumplimiento legal en cuanto al trabajo
infantil, comprobándose que no ha habido casos de menores de edad contratados por CCU.
(3) Los compromisos declarados en la Política Diversidad e Inclusión y la Política Corporativa de Derechos Humanos están
 públicamente disponibles en la web corporativa, sección Políticas y Códigos (https://www.ccu.cl/publicaciones-ccu/). Al igual
 que en períodos anteriores, durante 2024 no se recibieron denuncias por casos de discriminación en la Compañía.
Memoria Integrada 2024 / Personas 83

[pág. 85]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
 5.1 Dotación de personal 2024
La dotación de personal de CCU S.A. y sus filiales es de 10.705 trabajadores.
 10.705 Trabajadores 5.1.1 Por género
 Mu Ho
 jeres mbres
 Tipos de cargo Mujeres Hombres Total
 Alta gerencia 2 14% 12 86% 14
 Gerencia 146 29% 357 71% 503
 U S.A. TERNA Jefatura 342 24% 1.079 76% 1.421
 CC
 IN CI
 OS O
 CI to d e Op
 en er Operarios 184 5% 3.757 95% 3.941
 N
 GO
 m a
 AL
 g
 ci
 NE
 Se
 4% 47% 33% 16%
 ES
 ón
 Fuerza de ventas 178 12% 1.365 88% 1.543
 Administrativos 218 36% 381 64% 599
 n
 n
 Se
 Se
 m
 ió
 m
 ió
 ac c
 ra
 g
 g
 en en
 to de Oper to de Ope Auxiliares 50 9% 530 91% 580
 CHILE VINOS
 Otros profesionales 699 46% 826 54% 1.525
 Otros técnicos 144 25% 435 75% 579
 Total 1.963 18% 8.742 82% 10.705
 La Compañía fomenta la participación de mujeres en sus equipos, por lo que cuenta con un objetivo
 de tener un 20% de mujeres en su dotación total. Además, de la totalidad de los cargos asociados
 a STEM (por su sigla en inglés, Science, Technology, Engineering and Mathematics) que representa la
 integración interdisciplinaria de la ciencia en un contexto asociado a la ingeniería y la tecnología,
 la Compañía registró un 37% de mujeres en esta clasificación en el año 2024.
Memoria Integrada 2024 / 5.1 Dotación de personal 2024 84

[pág. 86]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
5.1.2 Por nacionalidad
 Alta Gerencia Gerencia Jefatura Operario Fuerza de venta Administrativo Auxiliar Otros Profesionales Otros Técnicos Total general
País de Origen
 Mujeres Hombres Mujeres Hombres Mujeres Hombres Mujeres Hombres Mujeres Hombres Mujeres Hombres Mujeres Hombres Mujeres Hombres Mujeres Hombres Mujeres Hombres
Argentina - 2 32 77 67 188 19 1.495 8 185 19 11 8 9 119 148 34 95 306 2.210
Australia - - - 1 - - - - - - - - - - - - - - - 1
Bolivia - - 4 4 17 38 1 104 8 101 7 15 - 9 13 31 2 12 52 314
Brasil - - - 1 1 2 1 2 - 1 - - - - 1 - - - 3 6
Chile 2 8 100 248 212 731 151 1.784 121 782 165 308 34 455 477 552 87 249 1.349 5.117
China - - - 1 - - - - - - - - - - 6 4 - - 6 5
Colombia - - 1 - 3 - - 15 - 2 1 2 - 9 1 - - - 6 28
Cuba - - - - - - - 1 - - - - - - - - - - - 1
Ecuador - - - - - - - 1 - - - - - 1 - - - - - 2
Estados Unidos - - - 1 - - - - - - - - - - 4 4 - - 4 5
Francia - - 1 - - - - - - - - - - - 1 - - - 2 -
Guatemala - - - - - 1 - - - - - - - - - - - - - 1
Haití - - - - - - - 13 - - - - 1 4 - - - - 1 17
Holanda - - - 2 - - - - - - - - - - - - - - - 2
Italia - 1 - - - - - - - - - - - - - - - - - 1
Panamá - - - - - - - 1 - - - - - - - - - - - 1
Paraguay - - 2 12 33 85 6 161 30 239 20 24 5 8 55 56 7 53 158 638
Perú - - - 2 - 1 2 22 - 2 1 2 - 8 4 - 1 1 8 38
República Dominicana - - - - - - - 2 - - - - - - 1 - - - 1 2
Taiwán - - 1 - - - - - - - - - - - - 1 - - 1 1
Uruguay - 1 2 6 2 9 1 60 - 6 2 2 2 5 7 9 - 1 16 99
Venezuela - - 3 2 7 24 3 96 11 47 3 17 - 22 10 21 13 24 50 253
Total 2 12 146 357 342 1.079 184 3.757 178 1.365 218 381 50 530 699 826 144 435 1.963 8.742
Memoria Integrada 2024 / 5.1 Dotación de personal 2024 85

[pág. 87]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
5.1.3 Por rango de edad
 Mu Ho
 jeres mbres
 Menos de Entre 30 y Entre 41 y Entre 51 y Entre 61 y Más de 70 Menos de Entre 30 y Entre 41 y Entre 51 y Entre 61 y Más de 70
Tipos de cargos Total
 30 años 40 años 50 años 60 años 70 años años 30 años 40 años 50 años 60 años 70 años años
Alta gerencia - - 1 1 - - - - 6 4 2 - 14
Gerencia 4 62 61 19 - - 3 122 144 72 16 - 503
Jefatura 29 192 87 32 2 - 83 399 327 213 56 1 1.421
Operarios 47 53 38 35 11 - 619 1.102 984 710 315 27 3.941
Fuerza de ventas 37 76 49 15 - 1 233 445 386 248 53 - 1.543
Administrativos 52 77 48 31 10 - 44 127 103 80 26 1 599
Auxiliares 18 15 8 6 3 - 166 184 102 57 21 - 580
Otros profesionales 265 302 97 30 5 - 241 326 154 82 21 2 1.525
Otros técnicos 43 68 23 10 - - 81 157 99 70 28 - 579
Total 495 845 412 179 31 1 1.470 2.862 2.305 1.536 538 31 10.705
5.1.4 Por antigüedad laboral
 Mu Ho
 jeres mbres
 Menos de 3 Entre 3 y 6 Más de 6 y Entre 9 y 12 Más de 12 Menos de 3 Entre 3 y 6 Más de 6 y Entre 9 y 12 Más de 12
Tipos de cargos Total
 años años menos de 9 años años años años años menos de 9 años años años
Alta gerencia - - 1 - 1 - 3 - 2 7 14
Gerencia 40 19 25 18 44 44 36 57 48 172 503
Jefatura 84 73 65 45 75 209 141 130 157 442 1.421
Operarios 130 26 7 10 11 1.303 537 389 399 1.129 3.941
Fuerza de ventas 101 40 16 9 12 520 202 190 166 287 1.543
Administrativos 83 43 32 22 38 87 59 50 60 125 599
Auxiliares 28 16 2 2 2 224 148 70 44 44 580
Otros profesionales 410 139 48 34 68 416 128 91 57 134 1.525
Otros técnicos 83 21 15 11 14 141 63 55 46 130 579
Total 959 377 211 151 265 2.944 1.317 1.032 979 2.470 10.705
Memoria Integrada 2024 / 5.1 Dotación de personal 2024 86

[pág. 88]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
5.1.5 Personas con discapacidad 5.2 Formalidad laboral
Tipos de cargos Mujeres Hombres Total Tipo de contrato Mujeres Hombres Total
Alta gerencia - - - Indefinido 1.810 7.828 9.638
Gerencia - 3 3 % del Total Consolidado 16,91% 73,12% 90,03%
Jefatura 1 8 9 Plazo fijo 96 698 794
Operarios 3 28 31 % del Total Consolidado 0,90% 6,52% 7,42%
Fuerza de ventas 1 7 8 Obra o faena 57 216 273
Administrativos 6 5 11 % del Total Consolidado 0,53% 2,02% 2,55%
Auxiliares 2 2 4 Honorarios - - -
Otros profesionales 6 5 11 % del Total Consolidado - - -
Otros técnicos 2 3 5 Total Consolidado 1.963 8.742 10.705
Total 21 61 82 % del Total Consolidado 18,34% 81,66% 100,00%
% del Total 25,6% 74,4% 100,0%
Memoria Integrada 2024 / 5.2 Formalidad laboral 87

[pág. 89]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
5.3 Adaptabilidad laboral 5.4 Equidad salarial por género
CCU cuenta con la Política de Modalidad de Trabajo denominada 5-F que compatibiliza la preferencia 5.4.1 Política de equidad
por la presencialidad con la flexibilidad del teletrabajo, permitiendo a nuestros trabajadores realizar
sus labores de forma remota cuando sus funciones lo permitan. En CCU, promovemos una compensación justa y equitativa, independientemente del género, a través
 de nuestra Política de Derechos Humanos, que formaliza nuestro compromiso con la igualdad de
 oportunidades y la equidad de género. Seleccionamos y evaluamos a nuestro personal objetivamente,
 basándonos en sus capacidades, en todos los niveles de la Compañía y en un entorno laboral libre
 de discriminación.
 Mujeres Hombres Total Complementariamente, nuestra Política de Compensaciones establece los lineamientos para
Jornada Ordinaria 1.821 8.655 10.476 asegurar la equidad y la competitividad salarial, realizando un seguimiento continuo de indicadores
 % del Total Consolidado 17,01% 80,85% 97,86% en cada segmento de operación. Esta política busca atraer, retener y desarrollar a los trabajadores,
 considerando la equidad interna, la competitividad externa, el marco normativo y los aspectos
Jornada Parcial 6 3 9
 presupuestarios. Nuestros procesos de gestión de compensaciones se basan en estos mismos
 % del Total Consolidado 0,06% 0,03% 0,09% principios, y para mantenernos actualizados con los rangos salariales del mercado, participamos
Teletrabajo Parcial 70 69 139 periódicamente en encuestas de compensaciones realizadas por una consultora externa.
 % del Total Consolidado 0,65% 0,64% 1,29%
Teletrabajo Completo - - - Las remuneraciones del personal ejecutivo y profesional se definen mediante una evaluación de cargos
 que determina su contribución y valor para la organización, asignando un nivel a cada puesto. Con base
 % del Total Consolidado - - -
 en estos niveles y la información del mercado, se establece una escala salarial con bandas internas
Pactos de adaptabilidad responsabilidades familiares 66 15 81 que garantizan una compensación similar para cargos con niveles equivalentes de complejidad y
 % del Total Consolidado 0,62% 0,14% 0,76% responsabilidad. Respecto a las indemnizaciones del Gerente General y demás Ejecutivos Principales,
Bandas de horas para cuidado de niños y niñas < 12 años - - - estas se rigen por la Política de Retiro de Gerentes la cual ha sido aprobada por el directorio.
 % del Total Consolidado - - -
 Para los trabajadores que no participan en negociaciones colectivas, se realiza una revisión salarial
Total Consolidado 1.963 8.742 10.705
 anual individual, considerando su desempeño, posición en la banda salarial y presupuesto disponible,
 % del Total Consolidado 18,34% 81,66% 100,00%
 determinando un incremento por mérito. En esta instancia, los trabajadores pueden expresar
 cualquier inquietud o consulta sobre sus compensaciones.
 En el caso de las negociaciones colectivas, las estructuras de remuneraciones, beneficios y reajustes
 salariales se definen a partir de las propias negociaciones y los valores de mercado.
Memoria Integrada 2024 / 5.4 Equidad salarial por género 88

[pág. 90]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
Si bien no contamos con un procedimiento formal para que los accionistas aprueben las estructuras
salariales ni las indemnizaciones del Gerente General y los Ejecutivos Principales, anualmente se
 5.5 Acoso laboral, sexual y violencia en el trabajo
presenta al Comité de Directores una revisión de estas estructuras y la política de compensación,
incluyendo un análisis de la competitividad externa y la equidad interna por categorías laborales, En nuestra Política Corporativa de Derechos Humanos declaramos nuestro rechazo a cualquier
en concordancia con nuestra Política de Compensaciones. práctica de acoso, así como cualquier otra conducta que pretenda menoscabar o afectar la dignidad
 de las personas.
 Durante el 2024, en atención a la Ley N° 21.643 que establece un marco legal para la prevención y
5.4.2 Brecha salarial sanción del acoso y violencia en el entorno laboral (Ley Karin), se recibieron las siguientes denuncias:
 (i) por acoso laboral: 19 denuncias ante CCU en Chile, a través del Canal de Denuncias, (8 mujeres y 11
Como parte de su compromiso con la equidad salarial, CCU lleva a cabo una medición anual de hombres), 7 presentadas ante la Dirección del Trabajo en Chile (2 mujeres y 5 hombres), y 7 denuncias
la brecha salarial entre hombres y mujeres que ocupan cargos de igual contribución al negocio. en el extranjero bajo el equivalente a dicha normativa (3 mujeres y 4 hombres); (ii) por acoso sexual: 6
Los resultados de 2024 muestran un 97% de equidad en la media y un 98% en la mediana, lo denuncias presentadas ante CCU en Chile, 1 presentada ante la Dirección del Trabajo en Chile y 2 en el
que evidencia la efectividad de la política de compensación de CCU para garantizar la igualdad de extranjero, bajo normativa equivalente (todas las denuncias por acoso sexual fueron presentadas por
remuneración en todos los niveles de la empresa. mujeres); (iii) no hubo denuncias por violencia en el trabajo en Chile bajo esta Ley, ni en el extranjero
 bajo normativa equivalente.
 Brecha Salarial Media Brecha Salarial Mediana En el marco de la promoción de la Ley Karin, se realizaron talleres y charlas presenciales dirigidos a Alta
 gerencia, Gerencia, Jefatura y dirigentes sindicales, se enviaron comunicados por correo electrónico
 Tipos de cargos
 con una apertura promedio de un 86%. En este contexto, se informó sobre los alcances de la Ley,
 Mujeres Hombres Mujeres Hombres
 las conductas a fomentar bajo el alero de SER CCU y las disposiciones legales que ha implementado
 la Compañía para dar cumplimiento a esta Ley. Paralelamente se habilitó una sección denominada
 Alta gerencia 98% 100% 101% 100%
 “Ley Karin” en nuestra Intranet en Chile, que contiene definiciones y material de capacitación con
 Gerencia 94% 100% 95% 100% foco en la prevención y difusión de canales de denuncias.
 Jefatura 100% 100% 100% 100%
 Operarios 94% 100% 97% 100% A su vez, se actualizaron los Reglamentos Internos de cada unidad de negocio incorporando el
 protocolo de prevención y procedimiento de sanción e investigación para denuncias de acoso sexual,
 Fuerza de ventas 97% 100% 99% 100%
 laboral y violencia en el trabajo. Al mismo tiempo, permanecen disponibles los cursos e-learning
 Administrativos 98% 100% 99% 100% que refuerzan el bienestar individual y dentro de los equipos de trabajo, tales como salud mental,
 Auxiliares 96% 100% 91% 100% inclusión y derechos humanos.
 Otros profesionales 95% 100% 97% 100%
 Por otro lado, el 28,82% de nuestros trabajadores recibió una capacitación formal respecto del
 Otros técnicos 96% 100% 97% 100%
 protocolo de prevención del acoso sexual, laboral y la violencia en el trabajo y del procedimiento de
 Total 97% 100% 98% 100% investigación y sanción al que quedan sometidas dichas conductas.
Memoria Integrada 2024 / 5.5 Acoso laboral, sexual y violencia en el trabajo 89

[pág. 91]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
Nuestro Canal de Denuncias, que es administrado por un servicio externo e independiente, nos Con este propósito, nuestras prioridades son:
permite recibir y gestionar las denuncias de ésta y otra índole con la debida diligencia, garantizando
la confidencialidad de la información entregada. Este constituye un medio formal de comunicación 1 Aplicar una metodología de identificación de peligros y evaluación de riesgos junto con los
de reclamos para ésta y otras materias. operadores de proceso, utilizando herramientas como tarjetas de seguridad, inspecciones
 planificadas, auditorías de seguridad, permisos de trabajo y el Análisis Seguro de Trabajo
El Canal de Denuncias entrega anonimato y confidencialidad a toda persona que conozca o sospeche (AST) para tareas críticas y planificadas. Asimismo, implementamos la metodología ORR
de alguna actuación que pueda implicar una infracción a las leyes vigentes, a los Principios de CCU (Reducción de Riesgos Operacionales) para riesgos críticos, asegurando la aplicación de
o a su Código de Conducta en los Negocios. Este mecanismo se encuentra a disposición de todos medidas de control efectivas.
nuestros grupos de interés.
 2 Control de energías peligrosas, mediante la implementación de procedimientos de bloqueo
 y etiquetado de energías peligrosas (LOTO, por sus siglas en inglés, Log Out - Tag Out) para
5.6 Seguridad laboral evitar encendidos accidentales de equipos, protegiendo a los trabajadores frente a energías
 activas y residuales.
En CCU fomentamos prácticas laborales seguras y saludables, priorizando la prevención de incidentes
que puedan impactar a nuestros trabajadores. Para ello, hemos implementado un Sistema de 3 Fortalecer la seguridad a través del liderazgo, promoviendo la observación y retroalimentación
Gestión de Seguridad y Salud en el Trabajo basado en la metodología de Mantenimiento Productivo continua, el uso de herramientas de autocuidado (Tarjeta Pare, Piense y Actúe), la capacitación
Total (TPM, por sus siglas en inglés). Este sistema se desarrolla conforme a la normativa chilena de líderes, la comunicación de cuasi accidentes y la implementación de acciones correctivas
y los estándares internacionales de seguridad de clase mundial (ver sección “6.4 Propiedades e frente a desviaciones detectadas. Además, cada centro de trabajo cuenta con un equipo
instalaciones”). interdisciplinario encargado de investigar incidentes, revisar la Matriz de Identificación de
 Peligros y Evaluación de Riesgos, y actualizar los controles según las causas identificadas.
Nuestro sistema asegura el cumplimiento de estándares internacionales, como la norma
ISO 45001:2018, y está estructurado en torno a sus principales pilares: enfoque, equipos 4 Mejorar nuestro sistema de gestión constantemente mediante la adopción de buenas
interdisciplinarios, gestión de procesos, estandarización y expansión, empoderamiento, y la activa prácticas, auditorías mensuales de seguridad, salud y medio ambiente, y auditorías periódicas
participación de los trabajadores. del sistema TPM. La investigación de incidentes se realiza con metodologías de análisis de
 causa raíz, como la técnica de los “5 porqués”, lo que permite establecer acciones correctivas
Además, contamos con un Reglamento Especial de Empresas Contratistas y Subcontratistas, y preventivas para reducir la probabilidad de recurrencia.
disponible en nuestro repositorio de estándares de seguridad, que regula el desempeño de las
empresas externas que colaboran con nosotros. Toda nuestra gestión sigue el ciclo de mejora continua PDCA (Planificar, Hacer, Verificar, Actuar),
 asegurando la eficacia de nuestras acciones.
Nuestro objetivo principal es alcanzar cero accidentes, promoviendo una cultura de seguridad y
eliminando conductas de riesgo para crear un entorno de trabajo seguro.
Memoria Integrada 2024 / 5.6 Seguridad laboral 90

[pág. 92]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
 Seguridad laboral en CCU 2024 Meta 3 Investigar cuáles son las causas de los accidentes del trabajo y las enfermedades profesionales
 que se produzcan.
 Tasa de enfermedades profesionales por cada 100 trabajadores contratados 0,08% 0,00%
 Tasa de accidentabilidad(1) por cada 100 trabajadores contratados 0,76% <1%
 4 Decidir si los accidentes o enfermedades se deben a negligencias inexcusables.
 Tasa de fatalidad por cada 100.000 trabajadores contratados 0 0 5 Indicar la adopción de todas las medidas de seguridad que faciliten la prevención de riesgos
 Promedio mensual de días perdidos(2) por accidente 26,76 9 profesionales.
 6 Cumplir con todas las funciones que le encomiende el organismo administrador del seguro
(1) (Nº de accidentes / dotación) *100. La dotación informada en este cuadro corresponde a la dotación promedio de cada año.
(2) N° días perdidos por accidentes / N° de accidentes de trabajo. social.
 7 Promover la participación en cursos destinados a la capacitación de los trabajadores, en
Comité Paritario organismos públicos o privados que se encuentren autorizados para cumplir esa finalidad.
En CCU la consulta y participación activa de nuestros trabajadores es uno de los pilares fundamentales
de nuestra gestión de seguridad. Esto se logra mediante herramientas y mecanismos que fomentan
la comunicación abierta y el compromiso con la prevención de riesgos. Algunas de estas herramientas
incluyen: tarjetas de seguridad, reportes de cuasi accidentes, encuestas de seguridad y auditorías
específicas en seguridad y salud en el trabajo.
Diariamente, los indicadores de seguridad, como accidentes, incidentes y cuasi accidentes, se
revisan en pizarras de gestión ubicadas en las áreas operativas, lo que facilita una retroalimentación
constante y la implementación de acciones correctivas inmediatas. Estas reuniones también permiten
identificar oportunidades de mejora y reconocer comportamientos seguros entre los trabajadores.
El Comité Paritario de Higiene y Seguridad, conformado por representantes de los trabajadores
y de la empresa, desempeña un rol crucial en nuestra estrategia de seguridad. Además de las
funciones establecidas por la legislación vigente, su labor incluye:
 1 Asesorar e instruir a los trabajadores en la correcta utilización de los elementos de protección
 personal.
 2 Vigilar el cumplimiento, tanto por parte de los trabajadores como de la organización, de todas
 las medidas de prevención, higiene y seguridad.
Memoria Integrada 2024 / 5.6 Seguridad laboral 91

[pág. 93]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
5.7 Permiso postnatal Días promedio de uso del permiso postnatal en Chile
Si bien la Compañía no cuenta con una política formal de permiso postnatal que exceda la normativa
legal vigente en cada país donde opera, en Chile se complementa la remuneración de las trabajadoras
con permiso maternal. Este beneficio asegura que reciban su remuneración íntegra durante el
 Hombres
período postnatal, complementando el subsidio legal del sistema de salud.
 5 días 6 semanas o menos
 Cargo Mujeres
 (Paternal) (Parental)
A continuación, se presenta el porcentaje de personas que tuvieron derecho y ejercieron el uso
 Alta Gerencia - - -
del permiso postnatal por género, considerando Chile, Argentina, Bolivia, Paraguay y Uruguay:
 Gerencia 168,0 5 -
% Personas que hicieron uso de permisos de postnatal Jefatura 168,0 5 -
 Operario 84,0 5 -
 Fuerza de venta 168,0 5 -
 Administrativo 163,2 5 -
 Auxiliar - 5 -
País Mujeres Hombres
 Otros profesionales 170,5 5 -
 Chile 100,0% 100,0%
 Otros técnicos 168,0 5 -
 Argentina 100,0% 100,0%
 Total 155,7 5 -
 Bolivia 100,0% 100,0%
 Paraguay 100,0% 100,0%
 Uruguay 100,0% 100,0% En Chile, por normativa legal la Compañía cumple con los siguientes requerimientos:
 Total 100,0% 100,0%
 Guarderías o contribuciones: CCU y sus filiales ofrecen este beneficio de acuerdo a
 la legislación vigente en cada país. Además, en el caso de Chile, si la salud del niño no
 permite su asistencia al colegio, se entrega una asignación directa en dinero en vez de
 pagar una sala cuna.
Memoria Integrada 2024 / 5.7 Permiso postnatal 92

[pág. 94]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
 Con la finalidad de generar un ambiente de aprendizaje y desarrollo, durante el año 2024
 Facilidades o prestaciones para la lactancia materna: En Chile, Argentina, Uruguay, diversificamos los canales formativos, a través de formatos presenciales, virtuales e híbridos,
 Paraguay y Bolivia, las trabajadoras tienen derecho a una hora diaria de permiso de ampliando así las oportunidades de mayor alcance en el aprendizaje a nivel regional. Asimismo,
 lactancia hasta que el niño cumpla cierta edad (un año en Chile y Paraguay, seis meses en el diseño de los planes de capacitación conectó en forma directa la formación con las metas y
 Uruguay y Bolivia). Durante el permiso de trabajo, pueden ausentarse para amamantar desafíos funcionales.
 o extraerse leche, y los empresarios deben proporcionar espacios adecuados. Esto
 fomenta la lactancia materna y permite a las madres cumplir con sus responsabilidades La plataforma de formación CCU (www.formacionccu.cl) constituye el espacio virtual a través
 laborales. Es una medida que promueve la conciliación entre trabajo y maternidad, del cual se habilitan los recursos asociados a formación e-learning para los equipos de trabajo.
 salvaguardando el bienestar de madres e hijos en los primeros meses de vida. También Atendiendo a la actualización de las normativas legales del año 2024, el foco formativo se centró
 se puede acordar el aplazamiento o adelanto en media hora, o en una hora, del inicio en el desarrollo de cursos en temáticas de libre competencia y modelo de prevención de delitos
 o fin de la jornada laboral. y continuamos con la formación en materias de ciberseguridad, los cuales impactan de forma
 transversal a toda la Compañía. En la misma línea, la plataforma de formación opera como el
 Permiso parental retribuido para el cuidador principal/no principal: En Chile repositorio de cursos asincrónicos, que tienen un alcance regional.
 existe el permiso parental remunerado, también conocido como “postnatal parental”.
 Este permiso se concede a la madre o al padre designado como cuidador principal del A partir del proceso de detección de necesidades de capacitación del 2024, se diseñaron e
 recién nacido o adoptado. La prestación permite a este cuidador ausentarse del trabajo y implementaron planes de formación para las distintas funciones organizacionales. En la función
 percibir una compensación igual a sus ingresos imponibles durante un periodo de hasta comercial, se reforzaron competencias comerciales para el segmento de vendedores, por medio
 24 semanas. De estas 24 semanas, al menos 12 debe utilizarlas la madre, y el resto puede de procesos de capacitación e-learning de forma permanente. Asimismo, se desarrollaron
 transferirse al padre si éste lo solicita. competencias de liderazgo para equipos de alto desempeño, con énfasis en robustecer la gestión
 de los indicadores comerciales en los equipos. En logística, el foco de desarrollo se centró en líderes
 de la operación, fortaleciendo competencias de comunicación efectiva y manejo de equipos. En
5.8 Capacitación y beneficios la función industrial, la malla formativa abordó temáticas vinculadas a seguridad, calidad, medio
 ambiente y mantenimiento.
Formación y capacitación En relación a los equipos de administración general, la capacitación estuvo orientada al desarrollo
 de competencias de análisis de datos y gestión, presentaciones efectivas, innovación, normativas
Para CCU el desarrollo de las personas es fundamental, ya que permite a la Compañía ser más financieras, laborales y medio ambientales, definiendo una malla adecuada a la especialidad de
competitiva en un entorno empresarial en constante evolución y cambio, con independencia del cada área, con contenidos transversales y específicos.
sector en el que opere.
 El año 2024 se continuó desarrollando el rol del Líder CCU, potenciando el principio de “Desarrollar
A través de una formación de excelencia, se busca fortalecer una cultura organizacional basada con Entrega” en los líderes con equipo a cargo, profundizando en el modelo de liderazgo situacional
en los principios del SER CCU, y al mismo tiempo, desarrollar las competencias necesarias para el cual entregan herramientas para una efectiva gestión de equipos, de acuerdo a su grado de
impulsar el logro de los objetivos estratégicos. desarrollo. Se logró una participación de un 90% de líderes, con un 95% de satisfacción.
Memoria Integrada 2024 / 5.8 Capacitación y beneficios 93

[pág. 95]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
En Chile, en relación al beneficio tributario SENCE (Servicio Nacional de Capacitación y Empleo), la
Compañía alcanzó un uso de un 85% de dicho beneficio, el cual impactó principalmente a equipos
de operación productiva industrial, ventas y logística. También, permitió impulsar la empleabilidad
en integrantes de las comunidades en donde la Compañía opera a nivel nacional, por medio del
entrenamiento de competencias técnicas vinculadas con la Estrategia de Sustentabilidad, tales
como, recicladores de base, operación de equipos logísticos, ventas, y marketing.
 Ramas Ámbitos N° total de Cobertura
 capacitados
 Desarrollo Diplomados, Pregrado, Magíster, Técnica
 101 1,1%
 Profesional superior.
 Capacitación Cursos de desarrollo interno en plataforma de
 5.012 54,0%
 interna Formación.
 Cursos ejecutados por proveedores externos,
 Capacitación
 como instituciones de educación superior o 5.412 58,0%
 externa
 especializadas en capacitación.
 Capacitación y desarrollo 2024
 Monto total en millones de CLP destinado a capacitación y
 1.928
 desarrollo profesional a trabajadores
 % del gasto de capacitación y desarrollo profesional de
 0,0664%
 trabajadores sobre el total de ingresos anuales
Memoria Integrada 2024 / 5.8 Capacitación y beneficios 94

[pág. 96]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
Formación por categoría y género
 Número de capacitados % de capacitados(1) Total de horas Horas promedio
 Tipos de cargos
 Mujeres Hombres Total Mujeres Hombres Total Mujeres Hombres Mujeres Hombres
 Alta gerencia 1 6 7 50,00% 50,00% 50,00% 38 63 38 11
 Gerencia 122 343 465 83,56% 96,08% 92,45% 2.569 7.198 21 21
 Jefaturas 335 1.039 1.374 97,95% 96,29% 96,69% 8.526 19.650 25 19
 Operarios 120 3.198 3.318 65,22% 85,12% 84,19% 938 26.843 8 7
 Fuerza de ventas 80 1.174 1.254 44,94% 86,01% 81,27% 897 10.463 11 9
 Administrativos 151 347 498 69,27% 91,08% 83,14% 2.207 3.863 15 11
 Auxiliares 17 431 448 34,00% 81,32% 77,24% 132 842 8 2
 Otros profesionales 532 753 1.285 76,11% 91,16% 84,26% 14.426 14.446 27 19
 Otros técnicos 129 421 550 89,58% 96,78% 94,99% 2.340 5.636 18 13
 Total(2) 1.487 7.712 9.199 75,75% 88,22% 85,93% 32.073 89.004 22 11
(1) El porcentaje del total capacitado está calculado sobre el total consolidado tanto de mujeres como de hombres respectivamente.
(2) Considera todos los trabajadores contratados por CCU, que tengan un contrato a plazo indefinido, fijo u obra y faena.
La formación y desarrollo en el año 2024, en términos de horas promedio por trabajador fue de 22 horas para mujeres y 11 horas para hombres, alcanzando un 75,75% para mujeres, 88,22% para
hombres y 85,93% a nivel del total consolidado de cobertura para los trabajadores vigentes de la Compañía.
Memoria Integrada 2024 / 5.8 Capacitación y beneficios 95

[pág. 97]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
 Escuela de Grueras y Grueros Capacitaciones en Seguridad
 La Escuela de Grueras y Grueros, es un proyecto que busca dar continuidad operacional Para CCU, la seguridad es un pilar fundamental, y en este sentido, la capacitación
 a la operación logística en contexto de temporadas de mayor demanda productiva, por continua ha sido clave para fortalecer las competencias en excelencia operativa,
 medio de la incorporación de mujeres y hombres en la operación logística, impulsando permitiendo a los trabajadores desempeñar sus labores de manera más eficiente y
 de forma directa la empleabilidad en comunas estratégicas para la Compañía. Durante protegida.
 el año 2024, se realizaron instancias simultáneas en conjunto con las municipalidades
 de Renca y Quilicura, mediante capacitaciones teóricas y prácticas en Operación Segura Dentro del programa de formación 2024 que se impulsó a nivel Compañía, se destacan
 de Grúa Horquilla, en las instalaciones de CCU. El programa cuenta con un total de 226 los siguientes entrenamientos:
 egresados desde su implementación en el año 2021, de los cuales un 47% son mujeres.
 Operadores de Excelencia.
 Escuela de Ventas
 Manejo de residuos y sustancias peligrosas.
 Con el propósito de asegurar una mejor integración de los vendedores que se MIPER (Identificación de Peligro y Evaluación de Riesgos).
 incorporaron a la Temporada de verano, se desarrolló e implementó la “Escuela de Manejo seguro alza hombre y hombre a bordo.
 Ventas”, en la cual se formaron a los participantes durante su período de inducción, Directiva ATEX (Manejo de equipamientos en ambientes explosivos).
 abordando competencias en técnicas de ventas y profundizando en el Modelo Comercial
 Aislación, bloqueo y verificación de energía cero.
 CCU, con temáticas como Portafolio, Ejecución Comercial, entre otros. Así también, por
 medio de experiencias prácticas en terreno, se vincularon con la gestión de ventas en Manejo de emergencias con amoniacos.
 el canal tradicional. Manejo Seguro de Grúa Horquilla.
 Manejo de traumas: inmovilización y traslado de lesionados.
 En esta versión del programa, participaron 29 personas de Santiago, las cuales formaron
 parte de la temporada, distribuidos entre las oficinas comerciales de Renca, Maipú, La Material de extinción y formas de control de fuegos.
 Florida, Pedro Aguirre Cerda y Conchalí. Protección radiológica.
 Protocolo de prevención de riesgos ergonómicos en el puesto de trabajo.
 Técnicas avanzadas en emergencias con CO2.
 Técnicas de control de incendios incipientes.
 Técnicas de Instrucción y control de riesgos en ambiente eléctrico aplicando la NFPA 70E.
 Técnicas de prevención de riesgos y accidentes laborales.
 Trabajo seguro en espacios confinados.
Memoria Integrada 2024 / 5.8 Capacitación y beneficios 96

[pág. 98]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
Programas de desarrollo de trabajadores
 Líderes CCU Desarrollo Profesional Impulsa CCU
 Programa corporativo orientado a líderes CCU con equipo a cargo, para Programa corporativo de cofinanciamiento de estudios de posgrado a nivel
 promover los roles de SER CCU. El objetivo de este programa en el año nacional. Considera a profesionales con buen desempeño sostenido e interés
 2024 fue enseñar buenas prácticas de Liderazgo Situacional. La habilidad de en desarrollarse profesionalmente dentro de la Compañía. Contempla estudios
 liderar equipos efectivamente se ha convertido en un pilar fundamental para como Diplomados, Magíster y MBA Nacional.
 garantizar el éxito organizacional. En este contexto, el Liderazgo Situacional
emerge como una herramienta esencial para los líderes de CCU, entregándoles la flexibilidad El programa Impulsa busca promover el desarrollo profesional de trabajadores con buen desempeño,
necesaria para enfrentar los desafíos y las exigencias del mercado. lo que redunde en un impacto positivo en los objetivos de la Compañía. Adicionalmente, busca
 retener a trabajadores por medio de la gestión de acciones dirigidas para su aceleramiento
Desde los resultados obtenidos en la encuesta de satisfacción, los líderes consideran que el dinamismo profesional a través de estudios de postgrado. Por último, el Programa Impulsa apoya la formación
y la practicidad del taller les permitió aplicar inmediatamente lo aprendido en sus equipos. Los líderes de postgrados para los talentos, lo que facilita ampliar su experiencia profesional y asumir desafíos
CCU valoran el proceso formativo implementado con un 98% de satisfacción. En Chile el programa de mayor complejidad. Dentro de las acciones de gestión de talento esta actividad robustece y
contó con la participación de 748 líderes, equivalente a un 90% del universo elegible. actualiza los conocimientos para que los profesionales los puedan ocupar en la Compañía.
 Jóvenes Profesionales Inglés Let’s Talk
 Programa corporativo dirigido a los jóvenes profesionales a nivel regional, Programa dirigido a trabajadores con interés en desarrollar el idioma inglés, a
 durante sus primeros tres años de experiencia laboral. Su propósito es generar través de clases personalizadas durante 6 meses. El Programa Let’s Talk busca
 competencias clave para impulsar el desarrollo acelerado de los jóvenes desarrollar de manera efectiva las habilidades y competencias lingüísticas
 profesionales, considerando su grado de madurez profesional. Esto, a través de de los trabajadores, enfocándose en el conocimiento y la práctica del idioma
 la implementación de acciones formativas que permitan desde una experiencia inglés como una herramienta del desarrollo profesional.
inmersiva, aprender sobre un área estratégica del negocio y a través del entrenamiento, generar
competencias en temáticas como presentaciones efectivas, gestión de proyectos y empoderamiento, El desarrollo del inglés fortalece el repertorio de competencias de los trabajadores permitiendo
los que cursan anualmente de acuerdo a su etapa en el programa. autogestionar desafíos actuales y futuros, siendo este idioma un canal permanente de proyección,
 desarrollo de carrera y un habilitador ante experiencias de contexto global. Se realiza un diagnóstico
Utilizando la diversificación de aprendizaje, se espera que el desarrollo de competencias mejoren y seguimiento de los avances de los participantes respecto a los niveles de inglés lo cual tiene un
la capacidad de respuesta a sus desafíos y adaptación. A través de experiencias inmersivas tienen impacto en su desarrollo profesional.
espacios para internalizar los procesos operacionales y de soporte que sustentan nuestro negocio.
El programa contó con la participación del 88% de los jóvenes profesionales a nivel regional.
Memoria Integrada 2024 / 5.8 Capacitación y beneficios 97

[pág. 99]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
 Cursos Abiertos CCU Durante el año 2024 el Programa de Calidad de Vida denominado “Vivamos Bien” se implementó
 en todos los países donde operamos alineado a la agenda Disfrute Consciente del eje Personas de
 Programa corporativo dirigido a todos los trabajadores de las distintas unidades la Estrategia de Sustentabilidad. Este programa reúne los beneficios y actividades que contribuyen
 de la Compañía, que cuenta con una oferta formativa en competencias claves a mejorar la calidad de vida en tres ámbitos:
 para las necesidades del presente y futuro. El objetivo del programa es robustecer
 competencias clave para el desempeño y amplificar el alcance de conocimientos
 y habilidades específicas en roles y contextos diversos. Estos entrenamientos
impulsan experiencias formativas complementarias a las mallas funcionales de capacitación anual
y permiten una experiencia de vinculación de los participantes, generando una visión global de los Bienestar laboral: Instancias de integración,
desafíos organizacionales que ocurren en cada función. beneficios de protección y servicios que se entregan
 en el día a día laboral. Implementamos una encuesta
Mediante la estandarización de necesidades formativas para todas las unidades de negocio, se logra de bienestar emocional en el trabajo que arrojó el
escalar la capacitación, generando instancias formativas rentables para la Compañía al considerar resultado de 70% de favorabilidad.
espacios de eficiencia en los costos por volumen de participantes.
Calidad de vida
Nuestras políticas y beneficios están dirigidos a fomentar un equilibrio saludable entre la vida laboral y Tiempo libre y familia: Actividades y beneficios que
personal de nuestros trabajadores, promoviendo un estilo de vida saludable y el consumo responsable buscan la conciliación de trabajo y familia, orientadas
de alcohol, alineado con el programa CRÁ (Consumidor Responsable de Alcohol) de la agenda disfrute a compartir y disfrutar fuera del horario laboral.
consciente del eje de personas.
Contamos con el apoyo de una corporación privada sin fines de lucro que brinda cobertura completa
en caso de accidentes laborales y desarrolla programas de prevención de riesgos para toda la
organización. Esta institución pone a disposición de los trabajadores una amplia gama de recursos,
incluyendo material de capacitación, fichas de seguridad, cursos en línea sobre temas específicos, Vida sana: Iniciativas que promueven el autocuidado,
normativas, protocolos de salud ocupacional, señalética y formularios de inspección, entre otros. alimentación saludable y actividad física. Destacamos
Garantizamos la confidencialidad de la información proporcionada por los trabajadores, respaldada los chequeos preventivos de salud en toda la región.
por nuestros reglamentos internos, y cumplimos rigurosamente con las políticas y normativas de Además en Chile en nuestras plantas contamos con
confidencialidad que protegen la información compartida con el servicio de salud. atención médica periódica para todos los trabajadores
 que allí trabajan.
Memoria Integrada 2024 / 5.8 Capacitación y beneficios 98

[pág. 100]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
Principales benef icios CCU
 Alcance
Tipo de Contrato Nombre de Beneficios Descripción de los Beneficios
 Regional
 Seguro de Vida, Catastrófico y
 Disponible para todos los trabajadores, pagado en un 100% por la Compañía, con cobertura catastrófica y oncológica. CHL, PRY
 Oncológico
 Seguro complementario de salud, Seguro complementario de salud cofinanciado entre el trabajador y la Compañía, que cubre un % de lo no cubierto
 CHL, ARG, BOL
 dental y Catastrófico por el plan de Isapre o Fonasa.
 Bienestar Social Su objetivo es apoyar a todos los socios y sus cargas en sus necesidades médicas, sociales o económicas. CHL, ARG, PRY
 Plan de Ahorro Previsional Aporte de la empresa equivalente al ahorro voluntario que el trabajador realice al fondo de pensiones. CHL
 Programa de Becas y Excelencia Destaca el rendimiento de los alumnos con nota superior a 6,5 al finalizar el ciclo de enseñanza básica y media,
 CHL
 Académica CCU Te Apoya además de brindar apoyo económico para quienes ingresan por primera vez a las universidades.
 Reconocimiento a la Trayectoria Ceremonia y regalo de reconocimiento a trabajadores con 5, 10, 15, 20, 25, 30 ó 35 años de antigüedad en la Compañía. CHL, ARG
 CHL, ARG, URY,
 Premio Espíritu SER CCU Entrega de premios y reconocimientos a trabajadores que reflejan constantemente los principios SER CCU.
 PRY, BOL
 Regalo por cumpleaños Productos de la Compañía como regalo corporativo en el mes del cumpleaños del trabajador. CHL, ARG, BOL
 CHL, ARG, URY,
 Día libre por cumpleaños Día libre en el mes del cumpleaños del trabajador.
Plazo PRY, BOL
Indefinido Precios preferenciales en distintos comercios del mercado. (Despensa Nestlé, Buen Vecino Watt’s, Catadores VSPT,
 Portal de descuentos CHL, ARG
 Manantial Contigo).
 Cooperativa de ahorro, crédito y
 Su objetivo es apoyar en sus necesidades económicas a todos los socios. CHL, PRY
 servicios financieros
 Beca “Vamos por más” Apoyo económico para especialización educacional. CHL
 Obsequio Mensual Productos Cerveza al personal. ARG, URY
 Obsequio Productos por
 Cerveza para consumo fiesta de casamiento. ARG
 Casamiento
 Obsequio por Nacimiento Boucher por nacimiento. ARG
 Préstamos personales Con beneficio en la tasa de interés. CHL, ARG
 Día Libre por paternidad Tres días libre para el progenitor por nacimiento de hijos. ARG
 Día Libre por fallecimiento Tres días libre para el trabajador en caso de fallecimiento de un familiar con 1er grado de consanguinidad. BOL
 Bono Nacido Vivo Pago de un bono equivalente a un salario mínimo nacional otorgado al trabajador con la presentación del Certificado Nacido Vivo. BOL
 Bono Sepelio Pago único a los trabajadores equivalente a un salario mínimo nacional, por el fallecimiento de cada hija(o) menor de 19 años. BOL
Memoria Integrada 2024 / 5.8 Capacitación y beneficios 99

[pág. 101]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
 Alcance
Tipo de Contrato Nombre de Beneficios Descripción de los Beneficios
 Regional
 Consiste en la entrega a la madre gestante (asegurada o beneficiaria) y al lactante, de una asignación mensual en
 Subsidio Prenatal y Postnatal BOL
 especie equivalente a un salario mínimo nacional.
 Reconocimiento Educación Superior Obsequio otorgado a los trabajadores que concluyen su carrera universitaria. PRY
 Apoyo económico para gastos no cubiertos por seguros de salud debido a enfermedades asociadas a discapacidades.
 Reembolso Especial Gastos por
 VSPT Wine Group complementa con un Programa de beneficios que apoya y promueve la tramitación de credencial de CHL
 Inclusión
Plazo discapacidad para trabajadores y beneficios tales como reembolso de gastos médicos y otros.
Indefinido CHL, ARG, PRY,
 La Barra Precio preferencial en la compra de productos de la Compañía a través del portal de Ventas CCU.
 BOL
 Fiesta de Navidad Jornada de celebración de Navidad para trabajadores y grupo familiar. CHL
 CHL, ARG, URY,
 Caja de Navidad Caja navideña con productos de la empresa y otros.
 BOL
 Regalo de Navidad para hijos Entrega de regalo/giftcard a los hijos de los trabajadores hasta los 12 años de edad. CHL
 Jornadas y/o regalos de celebración para Fiestas Patrias, Día de la Secretaría, Día de la Madre, Día del Padre, Día del
 Celebraciones Días Especiales CHL
 Niño, Día de la Mascota (VSPT), Día del Trabajador.
 Evaluaciones preventivas de salud
 Vacunación Influenza y exámenes preventivos. CHL, ARG, PRY
 una vez al año
Todos los tipos Accesos a eventos auspiciados por
de contrato Sorteos de entradas o acceso gratuito a eventos auspiciados por las marcas. CHL, ARG , URY
 las marcas
 Atención Médica (general, psicológica y/o psiquiátrica en línea, donde el trabajador puede realizar consultas médicas
 Telemedicina / Red Salud CHL, ARG, BOL
 vía teléfono o video llamada.
 Comedor Empresa aporta entre el 70% y 100% del costo del consumo en comedor. ARG
 Fiesta de Fin de Año Jornada de celebración de fin de año para trabajadores. CHL, ARG
 Jornada reducida los viernes Jornada reducida los viernes del año. CHL, ARG
Todos los tipos
de contrato para Flexibilidad de horario el primer día Trabajadores que tengan hijos en preescolar o primer ciclo de enseñanza básica. (No aplica para trabajadores con turno). CHL, PRY
los trabajadores Ser Flex (VSPT) Programa de beneficios flexibles que entrega días de vacaciones adicionales a los legales a partir de un sistema de puntos. CHL
elegibles según Programa “Comamos Sano” Fruta o colación saludable en horario de trabajo (no aplica regiones). CHL,ARG, PRY
labores que Beneficios de ámbito Recreacional, Social, Educativo y otros de integridad para el trabajador que surgen CHL, ARG, PRY,
desempeñan o Otros Beneficios por sindicalización
 exclusivamente de las negociaciones sindicales. BOL
sindicalización SoftLanding Reincorporación parcial al trabajo con aseguramiento del 100% del salario. ARG
 WellHub Acceso a nivel nacional a centros de entrenamiento y plataforma virtual para actividades de bienestar integral. ARG
Memoria Integrada 2024 / 5.8 Capacitación y beneficios 100

[pág. 102]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
5.9 Política de subcontratación
En CCU, los servicios externos efectuados por empresas Contratistas o Subcontratistas se La evaluación de desempeño considera los siguientes puntos de medición:
rigen por un procedimiento formal que regula la administración de estos servicios y el acceso a
nuestras dependencias. Este procedimiento, que abarca la ejecución de contratos y órdenes de Principios SER CCU
compra, prioriza la seguridad y salud ocupacional, exigiendo la acreditación de la documentación
correspondiente para autorizar el ingreso y la ejecución de trabajos. Además, se verifica el
cumplimiento de las obligaciones laborales y previsionales de los trabajadores contratistas.
5.10 Ambiente laboral, identificación de Excelencia Entrega Integridad Empoderamiento
capacidades y conocimientos Son el reflejo de la forma en que hacemos nuestro trabajo y tomamos decisiones y, son transversales
 a todos los trabajadores de la Compañía. Cada principio posee dos competencias que describen
5.10.1 Gestión de desempeño comportamientos observables para cada nivel de contribución: Mi persona, Líder de Equipos y
 Ejecutivos.
CCU fomenta el desarrollo personal y profesional de los trabajadores, y para ello se apoya en el
proceso de Gestión del Desempeño, ciclo anual que busca alinear los principios del SER CCU, los Objetivos o funciones del cargo
objetivos de los trabajadores y la Compañía. Este proceso contribuye a la mejora permanente de
los resultados y el fortalecimiento de la cultura SER CCU. Se evalúan los objetivos de la persona en relación con el cargo, alineados a la estrategia
 organizacional y del área correspondiente. Además, dentro de los objetivos de los gerentes y
En concreto, es una instancia formal de diálogo entre el líder y el trabajador respecto de las subgerentes se encuentra el cumplimiento del balanced scorecard.
expectativas, los resultados y desafíos que se busca desarrollar; permite medir el rendimiento de
los trabajadores en relación con los objetivos y principios, e identificar fortalezas y oportunidades
de mejora para gestionar acciones de desarrollo futuras. Cumplimiento global
El proceso, que se gestiona en línea, garantiza el resguardo de la confidencialidad y transparencia Cada trabajador recibe una evaluación global en una escala de cinco niveles; “No Cumple”, “Cumple
de la información, donde además el trabajador tiene acceso a una copia de su evaluación como Parcialmente”, “Logra lo Esperado”, “Excede lo Esperado” y “Supera Excepcionalmente”. Es una
respaldo. El trabajador debe cumplir con el requisito de tener una antigüedad mínima de seis calificación del desempeño global del trabajador realizado por su jefatura, ponderando la sección
meses en la Compañía, con contrato de plazo indefinido. de Principios y de Objetivos.
Memoria Integrada 2024 / 5.10 Ambiente laboral, identificación de capacidades y conocimientos 101

[pág. 103]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
5.10.2 Evaluación ascendente Los procesos de selección son gestionados en plataformas en línea que dan soporte a las distintas
 etapas del proceso, desde la publicación, el reclutamiento hasta la selección de los candidatos. Todas
 las vacantes disponibles están alojadas en el portal Trabaja en CCU, que se encuentra disponible en:
La Compañía cuenta con una herramienta de medición de liderazgo, denominada evaluación www.trabajaenccu.cl
ascendente, donde los trabajadores evalúan la actitud de su jefatura directa en relación al cumplimiento
del rol del líder SER CCU. Este instrumento es una encuesta confidencial y anónima y cada jefe con CCU procura el desarrollo y la empleabilidad de los profesionales en etapa temprana, a través del
tres o más respuestas recibe un informe con las fortalezas y oportunidades de mejora. Programa de Prácticas, donde en el año 2024 se incorporaron a más de 400 estudiantes para
 realizar su práctica técnica o profesional en las distintas áreas de negocio como Ventas, Marketing,
En el año 2024, este proceso tuvo una tasa de participación consolidada de un 89% considerando las Finanzas, Logística, Industrial, Recursos Humanos, entre otras. De estos, un 16% fue contratado para
respuestas de 5.888 trabajadores en la región. El Indicador Global de Liderazgo (IGL) a nivel Compañía las vacantes disponibles.
fue de un 79%, dos puntos porcentuales superior a lo obtenido el año anterior, donde 1.021 jefes
recibieron un reporte individual con su IGL, que les permitió identificar fortalezas, oportunidades de La experiencia laboral es un aspecto reconocido y valorado por los trabajadores, ya que permite
mejora y generar planes para su desarrollo alineados a los principios del SER CCU. generar un desarrollo de carrera en el largo plazo, con oportunidades dentro y fuera de Chile, junto
 con un amplio portafolio multicategoría de bebestibles, diversas unidades de negocio y marcas que
 ofrecen una plataforma diversa para el crecimiento de cada profesional.
5.10.3 Reclutamiento y selección La tasa de contratación en el total de la Compañía en el año 2024 corresponde a un 5%, respecto del
 total de trabajadores con contrato indefinidos. De este porcentaje, un 45% corresponde a mujeres.
El proceso de reclutamiento y selección tiene por objetivo identificar, atraer al mejor talento disponible,
y de esta forma, contribuir al logro de los objetivos de la organización y asegurar su continuidad
operacional. CCU procura que la atracción del talento esté alineado a los principios del SER CCU, 5.10.4 Movilidad y promoción interna
buscándolos a través de su propuesta de marca empleadora. Asimismo, la Política Corporativa de
Derechos Humanos declara que CCU está en contra del trabajo infantil y junto con la Política de Nuestros procesos de movilidad y promoción interna reflejan el compromiso de CCU con el desarrollo
Diversidad e Inclusión, aseguran que los candidatos sean tratados con dignidad y respeto durante de nuestros trabajadores. Gracias a la implementación de concursos internos, fomentamos el
todo el proceso, de manera de garantizar la igualdad de oportunidades. crecimiento profesional y la movilidad entre diferentes áreas de la Compañía. Para postular,
 nuestros trabajadores deben demostrar un buen nivel de desempeño y contar con al menos
Para activar el reclutamiento CCU cuenta con fuentes externas e internas. Externamente la Compañía un año de experiencia en su puesto actual. Las promociones son una oportunidad para asumir
trabaja de forma activa con universidades, institutos, liceos técnicos, municipalidades, portales de nuevas responsabilidades, desarrollar nuevas habilidades y representan un reconocimiento a los
trabajo, Bolsa Nacional de Empleo y redes sociales. Internamente, los trabajadores vigentes postulan trabajadores que aportan valor a nuestra Compañía.
a concursos internos lo que permite movimientos internos y promociones.
Memoria Integrada 2024 / 5.10 Ambiente laboral, identificación de capacidades y conocimientos 102

[pág. 104]
Capítulos / 1 2 3 4 5 Personas 6 7 8 9 10 11 12
En el año 2024, un 11% de la dotación consolidada fue promovida a cargos de mayor responsabilidad.
La tasa de rotación a nivel consolidado fue de un 13%, en el que 5% corresponden a renuncias
voluntarias. Además, se generaron 1.464 vacantes de las cuales un 70% fueron cubiertas por
candidatos internos. Adicionalmente, la Compañía tiene como objetivo el desarrollo de sus propios
trabajadores, en el que el 80% de los nombramientos de Alta gerencia y Gerencia sea cubierto
internamente. De las vacantes para Alta gerencia y Gerencia, un 91% se realizó por movilidad interna.
5.10.5 Gestión de talento
La Gerencia Corporativa de Recursos Humanos realiza un seguimiento integral de las capacidades,
conocimientos, condiciones, experiencias y visiones de sus trabajadores mediante procesos de
Evaluación de Desempeño, Potencial y Ascendente para las jefaturas. Para los Ejecutivos Principales,
se realiza anualmente un Comité de Desarrollo Ejecutivo que, en sesiones de trabajo conjuntas con
el Comité de Dirección, analiza los planes de desarrollo y sucesión de la Alta gerencia y Gerencia. Este
mecanismo permite la identificación de posibles sucesores de los Ejecutivos Principales, facilitando
un reemplazo oportuno y la consiguiente transferencia de funciones e información crítica ante
eventuales contingencias, con el objetivo de mitigar cualquier impacto adverso en la organización.
La designación del sucesor del Gerente General recae en el Directorio, el cual fundamenta su
decisión en un análisis exhaustivo de la trayectoria profesional, evaluaciones de desempeño y
ascendentes, planes de retiro y sucesión, y demás información pertinente de los candidatos.
5.10.6 Bienestar emocional en el trabajo
En un esfuerzo por fomentar un entorno laboral positivo, CCU diseñó e implementó la encuesta
de bienestar emocional en el trabajo. Este instrumento, con sus 46 afirmaciones, exploró los
sentimientos de felicidad, motivación, inspiración y entusiasmo, y revelando los factores de riesgo
que impactan en el cargo, el grupo y la organización.
La participación fue de 77% a nivel regional, lo que subraya el compromiso colectivo de CCU hacia
un ambiente laboral más saludable y equilibrado. Se complementa con el resultado de la encuesta
de Clima del 86% explicado en la sección “9.1 Estrategia de Sustentabilidad”.
Memoria Integrada 2024 / 5.10 Ambiente laboral, identificación de capacidades y conocimientos 103

[pág. 105]
6
 Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
 6.1 Sector industrial 105
 Competencia 106
 Marco normativo 107
 Entidades reguladoras nacionales o extranjeras 112
 Asociaciones y membresías 118
 6.2 Negocios 124
 Segmentos de operación 125
 Principales asociadas y negocios conjunto 130
 Comercialización, distribución y venta 131
 Licencias y contratos 132
 6.3 Grupos de interés 135
 6.4 Propiedades e instalaciones 135
 Principales plantas productivas y centros de distribución 136
 6.5 Subsidiarias, asociadas e inversiones en
 Modelo
 otras sociedades 138
 Estructura 2024 139
 de negocios
Memoria Integrada 2024 104

[pág. 106]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
6.1 Sector industrial
Como se detalló al comienzo de esta Memoria, en la sección Perfil de la Entidad, CCU es una
empresa multicategoría regional de bebestibles, con operaciones en Chile, Argentina, Bolivia,
Colombia, Paraguay y Uruguay. En consecuencia, participamos en numerosas categorías dentro
de la industria de bebestibles, tanto en bebidas alcohólicas como no alcohólicas, siendo las más
relevantes dentro de las primeras las categorías de cervezas, vino, pisco y sidra. Por su parte, las
categorías más relevantes en las que participamos dentro del universo de bebidas no alcohólicas
se encuentran bebidas gaseosas, aguas minerales y envasadas, néctares, bebidas energéticas,
deportivas y bebidas en base a malta, entre otras.
A continuación, presentamos las participaciones de mercado por segmentos de operación:
 Participación de Mercado 2024
 Chile(1) 44,9%
 Negocios Internacionales(2) 18,7%
 Vinos(3) 18,4%
 Total(4) 29,1%
(1) Excluye HOD, jugos en polvo y energéticas.
(2) Incluye cervezas y aguas puras y saborizadas en Argentina; cervezas, gaseosas, jugos líquidos y aguas sin sabor en Uruguay;
 cervezas, gaseosas, jugos líquidos y aguas sin sabor en Paraguay; cervezas, malta y gaseosas en Bolivia.
(3) Incluye vinos domésticos y exportación desde Chile. Vinos domésticos fuente Nielsen, vinos exportación según mercado
 reportado por la Asociación de Vinos de Chile. Excluye vino granel.
(4) Promedio ponderado de todas las categorías en donde CCU participa basados en las participaciones de mercado de cada
 categoría y ponderados por las estimaciones internas de los tamaños de las industrias de dichas categorías al cierre 2024.
 Fuentes de Market share: Nielsen para Chile y vinos domésticos; Ernest&Young (EY) para cervezas, y Nielsen para aguas puras
 y saborizadas en Argentina; ID Retail para Uruguay; CCR para Paraguay; CIESMORI para gaseosas, y Nielsen para cervezas y
 malta en Bolivia; Asociación de Viñas de Chile para vinos de exportación. Cifras actualizadas anualmente.
Memoria Integrada 2024 / 6.1 Sector industrial 105

[pág. 107]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
Competencia mediados de 2019, Embotelladora Andina y Embonor comenzaron a distribuir los productos de Capel. Otro
 competidor relevante es Diageo Chile Limitada, que importa licores premium como whisky Johnnie Walker
A continuación, identificamos a nuestros competidores por segmento de operación, en línea con y vodka Smirnoff, entre otros. A mediados de 2018, los productos de Diageo Chile Limitada comenzaron a
lo señalado previamente en la sección “3.6.1 Gestión de riesgos”. ser distribuidos por Embotelladora Andina y Embonor. Por último, competimos con otros importadores de
 menor tamaño de productos internacionales, así como productores locales de pisco y otros licores.
Competencia en el Segmento de operación Chile
 Competencia en el Segmento de operación Negocios Internacionales
El mercado de las cervezas en Chile se caracteriza por la presencia de una amplia gama de marcas de
cervezas locales e internacionales. Nuestro principal competidor en el negocio de las cervezas es Cervecería En cervezas, competimos principalmente en Argentina con Cervecería y Maltería Quilmes S.A.I.C.A. y G,
Chile S.A., filial de ABI. Sus principales marcas de cervezas en el mercado chileno son Becker, Corona, en Paraguay con Cervecería Paraguaya S.A., en Uruguay con Fábricas Nacionales de Cerveza S.A., en
Báltica, Stella Artois y Budweiser. Tras la ejecución de un acuerdo de distribución en noviembre de 2020, Bolivia con Cervecería Boliviana Nacional S.A. y en Colombia con Bavaria & Cia S.C.A., todas ellas filiales
Cervecería Chile S.A. distribuye sus productos a través de la red de distribución de Embotelladora Andina de ABI. Como resultado de su posición dominante y gran tamaño en estos países, estás compañías se
S.A. (Embotelladora Andina) y Coca-Cola Embonor S.A. (Embonor), ambas empresas son las licenciatarias benefician de economías de escala en la producción y la distribución de cervezas.
y embotelladoras de los productos de The Coca-Cola Company en Chile. Antes de noviembre de 2020,
Cervecería Chile S.A. distribuía sus productos a través de la distribución directa y de mayoristas. En bebidas no alcohólicas competimos principalmente con Paraguay Refrescos S.A., en Paraguay,
 con Montevideo Refrescos S.R.L. en Uruguay, y en Bolivia con Embotelladoras Bolivianas Unidas,
Otro actor relevante en el mercado de las cervezas en Chile es Viña Concha y Toro S.A. (Concha y EMBOL S.A., todas ellas, embotelladoras de los productos de The Coca-Cola Company.
Toro), que importa Miller Genuine Draft y Estrella Damm desde el año 2018. Concha y Toro también
posee una participación mayoritaria en Southern Brewing Company, fabricante de la cerveza En Argentina, en aguas minerales, Cervecería y Maltería Quilmes S.A.I.C.A. y G, comercializa las aguas
Kross. Finalmente, en el mercado de las cervezas competimos también con un amplio número de Nestlé con sus marcas Eco de los Andes y Glaciar, Nestlé Pureza Vital. Por su parte, Manaos participa
cervecerías artesanales y distribuidores e importadores de cervezas internacionales. en el mercado con la marca Villamanaos. Asimismo, en aguas minerales, The Coca-Cola Company en
 Argentina participa a través de sus marcas Smart Water, Bonaqua y Benedictino; en aguas saborizadas,
En las categorías de bebidas no alcohólicas, nuestros principales competidores son las compañías comercializa la marca Aquarius. En tanto, Manaos participa con sus marcas Placer, Baggio y Baggio Fresh.
que producen, embotellan y distribuyen bebidas no alcohólicas en Chile bajo las licencias de The
Coca-Cola Company y sus coligadas. Así, los dos principales actores en el negocio de bebidas Competencia en el Segmento de operación Vinos
carbonatadas en Chile son Embotelladora Andina y Embonor. Nuestro principal competidor en el
negocio de aguas minerales, purificada y saborizada es Vital Aguas S.A., propiedad de Embotelladora La industria vitivinícola, tanto en el mercado doméstico como en el de exportación, se caracteriza
Andina y Embonor. Nuestro principal competidor en el negocio de néctares, jugos, té helado y por tener un amplio número de participantes de diversas escalas de negocios. Así, los principales
bebidas deportivas es Vital Jugos S.A., perteneciente a Embotelladora Andina y Embonor S.A. competidores de VSPT Wine Group en el mercado doméstico chileno son Viña Concha y Toro S.A. y Viña
 Santa Rita S.A. (Santa Rita). Tras la ejecución de un acuerdo de distribución en noviembre de 2021, Santa
El mercado de licores en Chile se caracteriza por una amplia gama de productos de producción local Rita distribuye sus productos a través de la red de distribución de Embotelladora Andina y Embonor.
e importados. Nuestro mayor competidor es Cooperativa Agrícola Pisquera Elqui Limitada (Capel), que Otras viñas relevantes en el mercado doméstico chileno son, Bodegas y Viñedos Santa Carolina S.A.,
produce pisco localmente e importa otros licores. Capel cuenta con plantas de producción ubicadas en las Viña Undurraga S.A., Viña Cousiño Macul S.A. y Viña Montes. A nivel internacional, VSPT Wine Group
regiones de Atacama y Coquimbo, en el norte de Chile, y distribuye sus productos en todo el país. Desde compite con los productores chilenos y con los productores de vino de otros países en el mundo.
Memoria Integrada 2024 / 6.1 Sector industrial 106

[pág. 108]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
Marco normativo energía de los productos, restricciones horarias de publicidad, y la prohibición de participación en
 eventos deportivos y culturales, las que entran en vigencia en forma inmediata o diferida según se
 establece en la referida norma.
CCU S.A., en su carácter de sociedad anónima abierta, se encuentra regulada por la Ley N° 18.045
sobre Mercado de Valores, la Ley N° 18.046 sobre Sociedades Anónimas y su Reglamento contenido Bebidas No Alcohólicas
en el Decreto Supremo N° 702 del Ministerio de Hacienda de 2011 y la normativa dictada al efecto
por la CMF. Asimismo, CCU S.A., en su calidad de emisor ADRs que actualmente se transan en el NYSE, Se deben observar las normas del Reglamento Sanitario de los Alimentos contenido en el Decreto
se encuentra sujeta, en lo que fuere aplicable, al Securities Exchange Act de 1934, Sarbanes-Oxley Act N° 977 del Ministerio de Salud de 1997 y en el Código Sanitario, relativas a las condiciones
de 2002 y a la normativa dictada al efecto por la Securities and Exchange Commission y el NYSE. sanitarias a las que debe ceñirse la producción, importación, elaboración, envase, almacenamiento,
 distribución y venta de alimentos para uso humano.
Adicionalmente, CCU S.A., sus filiales y coligadas, deben observar las normas aplicables de manera
específica a las actividades y negocios que cada una realiza, siendo las principales las que se indican En lo que respecta a aguas minerales, se aplican adicionalmente las disposiciones del Reglamento
a continuación para cada segmento: de Aguas Minerales contenidas en Decreto N° 106 del Ministerio de Salud de 1997, que establece,
 además de la obligación de obtener la autorización de establecimiento y funcionamiento otorgado
 por el servicio de salud respectivo, la obligación de contar en forma previa a su explotación comercial
SEGMENTO DE OPERACIÓN CHILE con la respectiva declaración de fuente curativa, pudiendo el agua mineral solo ser envasada en su
 fuente de origen conforme a los procedimientos y manipulaciones establecidos en el mencionado
 Cervezas Reglamento, debiendo las marcas destinadas a distinguir aguas minerales y sus subproductos
 envasados tener igual denominación al de la o las fuentes de que proceden y que se hallen
(i) Ley N° 18.455 que contiene normas sobre Producción, Elaboración y Comercialización de registradas en el Ministerio de Salud. Se establecen, asimismo, disposiciones relativas al envasado,
Alcoholes Etílicos, Bebidas Alcohólicas y Vinagres, reglamentada en el Decreto N° 78 del Ministerio rotulación y publicidad de aguas minerales y sus subproductos.
de Agricultura de 1986, que establece, entre otras, la obligación de inscribir las bebidas alcohólicas
que se comercialicen en Chile en el registro que al efecto lleva el Servicio Agrícola y Ganadero Finalmente, a esta categoría le son aplicables las siguientes disposiciones: (i) Ley N° 20.606 de 2012
(SAG) y los requisitos de rotulación, (ii) Ley N° 19.925 sobre Expendio y Consumo de Bebidas sobre Composición Nutricional de los Alimentos y su Publicidad, (ii) Decreto N° 13 del Ministerio de
Alcohólicas, que establece la obligación de contar con patente de alcoholes para el expendio de Salud de 26 de junio de 2015, que modifica el Decreto N° 977 antes referido, (iii) Ley N° 20.869 de
bebidas alcohólicas, fija el horario de funcionamiento para dichos establecimientos, dispone la 13 de noviembre de 2015 sobre Publicidad de Alimentos y Decreto Supremo N° 1 del Ministerio de
prohibición de venta y suministro a menores de 18 años de edad en establecimientos autorizados Salud de 11 diciembre de 2017, que entró en vigencia el 11 de junio de 2018, normas que establecen
para el expendio de bebidas alcohólicas así como la venta, suministro o consumo en lugares ciertas restricciones y exigencias en materia de publicidad, rotulación y comercialización a aquellos
determinados, y demás requisitos y condiciones para la comercialización de bebidas alcohólicas, alimentos que sean calificados “altos en” alguno de los nutrientes críticos definidos y energía; y (iv)
y (iii) Ley N° 21.363 que establece normas en materia de Comercialización y Publicidad de Bebidas Ley N° 21.368 de 2021, que regula la entrega de plásticos de un solo uso y las botellas plásticas,
Alcohólicas y su Reglamento contenido en el Decreto N° 98 del Ministerio del Interior y Seguridad denominada Ley PUSU, dispone, entre otras obligaciones, que los productores de bebestibles
Pública de 7 de julio de 2023, disponiendo, entre otros, la incorporación de advertencias sobre el deben incorporar en sus botellas plásticas desechables un determinado porcentaje de plástico
consumo de alcohol en el etiquetado y la publicidad, la obligación de informar en las etiquetas la recolectado y reciclado en Chile, iniciando a partir de enero de 2025 con un 15%.
Memoria Integrada 2024 / 6.1 Sector industrial 107

[pág. 109]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
 Licores SEGMENTO DE OPERACIÓN NEGOCIOS INTERNACIONALES
Se aplica a los destilados, cócteles y licores las siguientes disposiciones: (i) Ley N° 18.455 sobre Argentina
Producción, Elaboración y Comercialización de Alcoholes Etílicos, Bebidas Alcohólicas y Vinagres,
su Reglamento contenido en el Decreto N° 78 del Ministerio de Agricultura de 1986 antes referido Compañía Industrial Cervecera S.A. y Aguas de Origen S.A. deben observar las normas aplicables
que establece, entre otras, la obligación de inscribir las bebidas alcohólicas que se comercialicen en de manera específica a las actividades y negocios que realizan, entre ellas, fundamentalmente
Chile en el registro que al efecto lleva el SAG y los requisitos de rotulación, (ii) Ley N° 19.925 sobre la Ley Nacional N° 18.284, Código Alimentario argentino que regula todo lo relacionado con la
Expendio y Consumo de Bebidas Alcohólicas, que establece la obligación de contar con patente de elaboración, importación, exportación, comercialización, rotulado, etc. de alimentos, condimentos,
alcoholes para el expendio de bebidas alcohólicas, fija el horario de funcionamiento para dichos bebidas o primeras materias en todo el país. A su vez, Compañía Industrial Cervecera S.A. debe dar
establecimientos, dispone la prohibición de venta y suministro a menores de 18 años de edad en cumplimiento a: (i) Ley Nacional N° 24.788 y sus decretos reglamentarios sobre “Lucha contra el
establecimientos autorizados para el expendio de bebidas alcohólicas así como la venta, suministro o Alcoholismo”, que regula la venta y consumo de bebidas alcohólicas y su publicidad, determinando
consumo en lugares determinados, y demás requisitos y condiciones para la comercialización de bebidas el horario autorizado para la comercialización y la prohibición de venta a menores de 18 años
alcohólicas, (iii) Decreto Supremo N° 521 del Ministerio de Agricultura de 1999 que reglamenta el uso de de edad, y (ii) Decreto Reglamentario N° 688/2009 y sus complementarios que regula todo lo
la denominación de origen “pisco”, las características y modalidades que se deben cumplir respecto de la relacionado a la publicidad de bebidas con alcohol, siendo aplicable las disposiciones de la Ley
materia prima a utilizar, y la elaboración y envasado de este producto, y (iv) Ley N° 21.363 que establece N° 5.708 en el ámbito de la ciudad de Buenos Aires. Por su parte, Aguas de Origen S.A. debe
normas en materia de Comercialización y Publicidad de Bebidas Alcohólicas y su Reglamento contenido en cumplir con la Ley de Etiqueta Frontal N° 27.642 que regula la información que debe figurar en
el Decreto N° 98 del Ministerio del Interior y Seguridad Pública de 7 de julio de 2023, disponiendo, entre los envases de bebidas sin alcohol que contienen exceso de azúcares, sodio, grasas saturadas,
otros, la incorporación de advertencias sobre el consumo de alcohol en el etiquetado y la publicidad, la grasas totales y calorías como también su publicidad.
obligación de informar en las etiquetas la energía de los productos, restricciones horarias de publicidad
y la prohibición de participación en eventos deportivos y culturales, las que entran en vigencia en forma
inmediata o diferida según se establece en la referida norma. Uruguay
 Las sociedades Milotur S.A., Marzurel S.A., y Andrimar S.A., en cuanto a su actividad, esto es, la
 elaboración y comercialización de bebidas no alcohólicas así como la distribución y comercialización
 de bebidas alcohólicas, las principales normas que las regulan son: (i) Decreto N° 315/94 que
 contiene el Reglamento Bromatológico Nacional, (ii) Código de la Niñez y la Adolescencia que regula
 aspectos relativos al expendio y publicidad de bebidas alcohólicas, (iii) Ley N° 17.849 y su Decreto
 Reglamentario N° 260/07 que regulan el Sistema Integrado de Gestión de Envases, (iv) Reglamento
 Técnico Mercosur para rotulación de alimentos envasados, (v) Ley N° 18.159 que regula la promoción
 y defensa de la competencia, (vi) Ley N° 19.855 que regula el consumo problemático de bebidas
 alcohólicas y su Decreto Reglamentario N° 63/2020, (vii) Decreto N° 272/18, con vigencia desde
 el 1 de marzo de 2020, sobre rotulado de los alimentos, (viii) Ley N° 19.829 de Gestión Integral
 de Residuos Sólidos, y (ix) Resoluciones N° 271/021 y N° 1391/024 sobre objetivos mínimos de
 recuperación y valorización de envases.
Memoria Integrada 2024 / 6.1 Sector industrial 108

[pág. 110]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
 Paraguay
En virtud del carácter específico del objeto social de Bebidas del Paraguay S.A., relacionado con
la producción, importación, comercialización y publicidad de bebidas con y sin alcohol, de Sajonia
Brewing Company S.A. en lo que respecta a la producción, comercialización y publicidad de bebidas
con alcohol, y de Distribuidora del Paraguay S.A. y AV S.A. para la comercialización y publicidad de
bebidas con o sin alcohol, son aplicables las siguientes normativas: (i) Ley N° 1.333/98 sobre Publicidad
y Promoción de Tabaco y Bebidas Alcohólicas, (ii) Ley N° 1.642/00 que prohíbe la venta de bebidas
alcohólicas a menores de edad y prohíbe su consumo en la vía pública, y (iii) Decreto del Poder
Ejecutivo N° 1.635/99 y Resolución del Ministerio de Salud Pública y Bienestar Social N° 643/12 que
regulan aspectos relativos al registro de productos alimenticios y sus modificaciones, entre otras.
 Bolivia
En atención al objeto social de Bebidas Bolivianas BBO S.A. relacionadas a la producción,
importación, exportación y comercialización de bebidas alcohólicas y no alcohólicas, son
aplicables las siguientes normas: (i) Ley N° 1.990 o Ley General de Aduanas y los Decretos
Supremos N° 27.947 y N° 572 que incorporan modificaciones al Decreto Supremo N° 25.870 que
contiene el Reglamento de la Ley General de Aduanas, que regulan el régimen de importaciones
y exportaciones, (ii) Ley N° 2.061 del Servicio Nacional de Sanidad Agropecuaria e Inocuidad
Alimentaria (SENASAG), entidad encargada de administrar el régimen de sanidad agropecuaria e
inocuidad alimentaria en el país, (iii) Resolución N° 42/2023/2018 que contiene el Reglamento para
la clasificación y registro de alimentos emitida por el Servicio Nacional de Sanidad Agropecuaria
(SENASAG), y (iv) Ley N° 259 sobre control al expendio y consumo de bebidas alcohólicas.
Memoria Integrada 2024 / 6.1 Sector industrial 109

[pág. 111]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
SEGMENTO DE OPERACIÓN VINOS
 Chile Argentina
A Viña San Pedro Tarapacá S.A. y sus filiales les son aplicables las normas específicas relativas Finca La Celia S.A., filial de Viña San Pedro Tarapacá S.A. en Argentina, debe observar las normas
a las actividades y negocios que cada una realiza, siendo las principales: (i) Ley N° 18.455 que aplicables de manera específica a las actividades y negocios que realiza, fundamentalmente: (i) Ley
contiene normas sobre Producción, Elaboración y Comercialización de Alcoholes Etílicos, Bebidas Nacional N° 18.284, Código Alimentario argentino que regula todo lo relacionado con la elaboración,
Alcohólicas y Vinagres, reglamentada en el Decreto N° 78 del Ministerio de Agricultura de 1986, importación, exportación, comercialización, rotulado, entre otros, de alimentos, condimentos, bebidas
que establece, entre otras, la obligación de inscribir las bebidas alcohólicas que se comercialicen o primeras materias en todo el país, (ii) Ley Nacional N° 24.788 y sus decretos reglamentarios sobre
en Chile en el registro que al efecto lleva el SAG y los requisitos de rotulación, (ii) Ley N° 19.925 “Lucha contra el Alcoholismo”, que regula la venta y consumo de bebidas alcohólicas y su publicidad,
sobre Expendio y Consumo de Bebidas Alcohólicas, que establece la obligación de contar con determinando el horario autorizado para la comercialización y la prohibición de venta a menores de
patente de alcoholes para el expendio de bebidas alcohólicas, fija el horario de funcionamiento 18 años de edad, (iii) Decreto Reglamentario N° 688/09 y sus complementarios que regula todo lo
para dichos establecimientos, dispone la prohibición de venta y suministro a menores de 18 años relacionado a la publicidad de bebidas con alcohol, siendo aplicable las disposiciones de la Ley N° 5.708 en
de edad en establecimientos autorizados para el expendio de bebidas alcohólicas así como la el ámbito de la ciudad de Buenos Aires, (iv) Resoluciones dictadas por el Instituto Nacional de Vitivinicultura
venta, suministro o consumo en lugares determinados, y demás requisitos y condiciones para la respecto al vino, (v) Resoluciones dictadas por el Departamento General de Irrigación de Mendoza, y (vi)
comercialización de bebidas alcohólicas, (iii) Decreto N° 464 del Ministerio de Agricultura de 1995, Ley de Aguas N° 430 y N° 322 que regulan la administración y gestión del agua en Mendoza.
sobre zonificación vitivinícola o denominación de origen para vinos que se produzcan en el país y fija
normas para su utilización, estableciéndose las zonas geográficas de las cuales se deben obtener las
uvas para contar con la respectiva denominación de origen, (iv) Ley N° 20.089, que crea el Sistema Reino Unido
Nacional de Certificación de Productos Orgánicos Agrícolas, la cual establece las condiciones para
la comercialización de productos bajo la denominación de origen de orgánico o sus equivalentes, Finalmente, VSPT UK Ltd., en su calidad de sociedad anónima constituida en el Reino Unido, le es
y (v) Ley N° 21.363 que establece normas en materia de Comercialización y Publicidad de Bebidas aplicable la Food Safety Act 1990 (Ley de Seguridad Alimentaria).
Alcohólicas y su Reglamento contenido en el Decreto N° 98 del Ministerio del Interior y Seguridad
Pública de 7 de julio de 2023, disponiendo, entre otros, la incorporación de advertencias sobre el
consumo de alcohol en el etiquetado y la publicidad, la obligación de informar en las etiquetas la
energía de los productos, restricciones horarias de publicidad y la prohibición de participación en
eventos deportivos y culturales, las que entran en vigencia en forma inmediata o diferida según
se establece en la referida norma.
Memoria Integrada 2024 / 6.1 Sector industrial 110

[pág. 112]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
PRINCIPALES ASOCIADAS Y NEGOCIOS CONJUNTOS Asimismo, a Central Cervecera de Colombia S.A.S., Zona Franca Central Cervecera S.A.S. y Artesanos
 de Cervezas S.A.S. les son aplicables, en materia de bebidas alcohólicas, las normas específicas
 Argentina relativas a las actividades y negocios que cada una realiza, siendo las principales: (i) Ley N° 9 de
 1979 que establece las condiciones que deben cumplir las materias primas para la elaboración de
Aguas Danone de Argentina S.A., en su calidad de sociedad anónima cerrada, se encuentra regulada por bebidas alcohólicas, (ii) Ley N° 124 de 1994 que regula la venta y consumo de bebidas alcohólicas y
la Ley General de Sociedades N° 19.550 y lo dispuesto por el Código Civil y Comercial de la Nación. su publicidad y establece los requisitos de edad mínima a nivel nacional para la compra de bebidas
 alcohólicas, prohibiendo el expendio de bebidas embriagantes a menores de 18 años, (iii) Decreto
 Chile N° 1.686 de 2012, Reglamento Técnico que establece los requisitos sanitarios que deben cumplir las
 bebidas alcohólicas para consumo humano, (iv) Decreto N° 780 de 2016 que establece, en materia de
Cervecería Austral S.A., debe observar las normas aplicables de manera específica a las actividades bebidas alcohólicas, la obligación de resaltar en la publicidad y leyendas relacionadas la prohibición
y negocios que realiza, principalmente aquellas descritas en el Segmento de operación Chile, del expendio de bebidas alcohólicas a menores de edad, así como las especificaciones que deben
sección cervezas. cumplir sus envases y etiquetas, (v) Circular N° 486 de 2016, que establece los requisitos sanitarios
 asociados a la fabricación, elaboración, envasado, almacenamiento, distribución, comercialización,
 Colombia expendio, importación o exportación de bebidas alcohólicas, (vi) Ley N° 223 de 1995 y Ley N° 1.816
 de 2016 que regulan los impuestos locales aplicables a la producción y distribución de bebidas
Zona Franca Central Cervecera S.A.S. debe cumplir con el régimen de zonas francas establecido alcohólicas, incluidas las cervezas, en territorio colombiano, (vii) artículo 475 del Estatuto Tributario
en la Ley N° 1.004 de 2005, el Decreto N° 2.147 de 2016 modificado por el Decreto N° 278 de que determina la base gravable del Impuesto sobre las Ventas (IVA), (viii) Decreto N° 1.366 de 2020,
2021, el Decreto N° 1.165 de 2019 modificado por el Decreto 659 de 2024 y, reglamentado por que establece disposiciones para otorgar el registro sanitario de bebidas alcohólicas fabricadas
la Resolución N° 46 de 2019, esta última, modificada a su vez por la Resolución 97 de 2024, el y comercializadas por microempresarios y la certificación en buenas prácticas de manufactura,
Decreto N° 920 de 2023, y las demás normas que lo modifiquen, adicionen o reglamenten, así (ix) Decreto N° 162 de 2021, mediante el cual se modifica Decreto N° 1.686 de 2012, (x) Circular
como su respectiva resolución de declaratoria de existencia de la zona franca, y su plan maestro conjunta N° 11 de 2017, que aborda los certificados en buenas prácticas de manufactura para
de desarrollo general aprobado por el Ministerio de Comercio, Industria y Turismo. bebidas alcohólicas, y (xi) Decreto N° 120 de 2010, por el cual se adoptan medidas en relación con
 el etiquetado y la publicidad.
En materia tributaria, a Zona Franca Central Cervecera S.A.S. le aplica el artículo 240-1 del Estatuto
Tributario, modificado por la Ley N° 1.819 de 2016, siempre que hayan sido calificadas como Igualmente, respecto de bebidas no alcohólicas, son aplicables principalmente las siguientes
Usuarios Industriales antes del 13 de diciembre de 2022; en caso contrario, se deberá dar normas: (i) Resolución N° 2.674 de 2013 que establece los requisitos sanitarios de fabricación,
cumplimiento a lo señalado en el artículo 11 de la Ley Nº 2.277 de 2022, y demás normas que procesamiento, preparación, envase, almacenamiento, transporte, distribución y comercialización,
lo reglamenten. En todo caso, se aplica el artículo 240-1 del Estatuto Tributario, modificado por (ii) Resolución N° 719 de 2015, que establece la clasificación de alimentos y bebidas para consumo
la Ley N° 2.277 de 2022 en lo relacionado con las tarifas del impuesto sobre la renta aplicable humano de acuerdo con el riesgo en salud pública, (iii) Resolución N° 5.109 de 2005, que establece
a los usuarios comerciales de zona franca. Adicionalmente, se deberá aplicar el parágrafo 6 del el reglamento técnico sobre los requisitos de rotulado o etiquetado, (iv) Resolución N° 810 de 2021,
artículo 240 del Estatuto Tributario en relación con el Impuesto Mínimo. que se establece el reglamento técnico sobre los requisitos de etiquetado nutricional y frontal, y
 (v) Resolución N° 2.492 de 2022, que modifica la Resolución N° 810 de 2021 antes indicada.
Memoria Integrada 2024 / 6.1 Sector industrial 111

[pág. 113]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
Entidades reguladoras nacionales o extranjeras
País Entidades Fiscalizadoras(1) Descripción
Segmento de operación Chile
 Comisión para el Mercado Financiero (CMF) Servicio público de carácter técnico encargado de la fiscalización y regulación, entre otras entidades, de sociedades anónimas abiertas.
 Entidad regulatoria que tiene entre sus principales funciones controlar y fiscalizar el cumplimiento de las disposiciones legales y reglamentarias que
 Servicio Agrícola y Ganadero (SAG)
 regulan la producción, elaboración, comercio, exportación e importación de bebidas alcohólicas.
 Secretarías Regionales del Ministerio de Salud (SEREMI Autoridad sanitaria encargada de fiscalizar y sancionar las disposiciones del Código Sanitario y otras normativas, en materia de higiene y seguridad del
 DE SALUD) ambiente, plantas productivas y lugares de trabajo, alimentos, normativas respecto etiquetado y publicidad de bebidas con alcohol, entre otros.
 Entidad encargada de proteger el medio ambiente y la salud de las personas, asegurando el cumplimiento de la normativa ambiental vigente, fiscalizando
 Superintendencia de Medio Ambiente (SMA)
 aquellos proyectos o actividades que se encuentren dentro de su competencia.
 Servicio público, dependiente del Ministerio de Economía, Fomento y Turismo, encargado de fiscalizar el cumplimiento de las disposiciones de la Ley
 Servicio Nacional del Consumidor (SERNAC)
 N° 19.496 y de toda otra normativa de protección a los derechos de los consumidores.
 Servicio público descentralizado, dependiente del Ministerio de Economía, Fomento y Turismo, encargado de fiscalizar, defender y promover la libre
 Fiscalía Nacional Económica (FNE)
 competencia actuando en representación del interés público como organismo especializado.
 Organismo del Estado de Chile, encargado de cautelar el uso de las aguas terrestres y su gobernanza, resguardando su preservación y disponibilidad
 Dirección General de Aguas (DGA)
 en calidad y cantidad para un desarrollo sostenible, de acuerdo a las atribuciones establecidas en el Código de Aguas.
 Servicio público descentralizado dependiente del Ministerio de Hacienda, encargado de aplicar y fiscalizar los impuestos internos cuyo control no
 Chile esté especialmente encomendado por ley a una autoridad diferente, encontrándose facultado, entre otros, para interpretar administrativamente las
 Servicio de Impuestos Internos (SII)
 disposiciones tributarias, fijar normas, impartir instrucciones y dictar órdenes para la aplicación y fiscalización de los impuestos, así como conocer y
 fallar como tribunal de primera instancia los reclamos tributarios que presenten los contribuyentes.
 Dirección del Trabajo (DT) Servicio público descentralizado dependiente del Ministerio del Trabajo, encargado de velar por el cumplimiento de la legislación laboral vigente.
 Servicio funcionalmente descentralizado, con personalidad jurídica y patrimonio propio, sujeto a la supervigilancia del Presidente de la República, cuya
 Superintendencia de Servicios Sanitarios (SISS) misión es la fiscalización de los prestadores de servicios sanitarios, del cumplimiento de las normas relativas a servicios sanitarios y el control de los
 residuos líquidos industriales que se encuentren vinculados a las prestaciones o servicios de las empresas sanitarias.
 Organismo dependiente del Ministerio de las Culturas, las Artes y el Patrimonio encargado de la protección y tuición del patrimonio cultural y natural
 Consejo de Monumentos Nacionales (CMN) de Chile, gestionando el reconocimiento, resguardo y acceso al patrimonio y la memoria, de forma participativa y en su diversidad, para generar
 conocimiento y contribuir a mejorar la calidad de vida de las personas.
 Corporación autónoma de derecho público, a la cual le corresponde la administración de una comuna, que cuenta a través de su Dirección de Rentas,
 Municipalidades con facultades para fiscalizar que las personas que realicen actividades comerciales y aquellas relativas al expendio, producción, almacenamiento y
 distribución de bebidas alcohólicas cuenten con las correspondientes patentes comerciales y/o de alcoholes.
 Entidad extranjera (Estados Unidos de América) encargada, entre otros, de la supervigilancia de emisores de ADRs y, por ende, aplicable a CCU S.A.
 Securities and Exchange Commission (SEC)
 en su calidad de emisor de ADRs que actualmente se transan en el NYSE.
(1) Las entidades reguladoras que tienen facultades de fiscalización incluidas en esta sección corresponden a aquellas que tienen dichas atribuciones respecto de los distintos sectores productivos reflejados en cada Segmento de operación, así como en las principales
 Asociadas y Negocios Conjuntos.
Memoria Integrada 2024 / 6.1 Sector industrial 112

[pág. 114]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
País Entidades Fiscalizadoras(1) Descripción
Segmento de operación Negocios Internacionales
 Registro Público de Comercio Entidad encargada del registro, fiscalización y regulación de sociedades para su oponibilidad a terceros.
 Entidad que posee, entre sus principales funciones, la aplicación del Código Alimentario Argentino (CAA) y la fiscalización de la sanidad y calidad de los alimentos
 Instituto Nacional de Alimentos (INAL)
 acondicionados, bebidas alcohólicas y no alcohólicas, sus materias primas, aditivos alimentarios, colorantes y coadyuvantes de tecnología, entre otras.
 Organismo que tiene entre sus finalidades la coordinación de las políticas del gobierno nacional en materia ambiental, estableciendo la planificación
 Ministerio de Medio Ambiente y Desarrollo Sostenible
 estratégica de políticas y programas en tal sentido.
 Argentina Entidad responsable del control y fiscalización del cumplimiento de las disposiciones de la Ley de Defensa del Consumidor N° 24.240 y de toda otra
 Dirección Nacional de Defensa del Consumidor
 normativa de protección a los derechos de los consumidores.
 Comisión Nacional de Defensa de la Competencia (CNDC) Organismo encargado de fiscalizar, defender y promover la libre competencia en todos los mercados o sectores productivos de la economía argentina.
 Agencia de Recaudación y Control Aduanero (ARCA) Organismo encargado de la aplicación, percepción, recaudación y fiscalización de las rentas e impuestos nacionales y del control del comercio exterior.
 Organismo que tiene, entre otras funciones, el diseño, elaboración, administración y fiscalización de las políticas en todo lo inherente a las relaciones
 Ministerio del Trabajo, Empleo y Seguridad Social
 y condiciones individuales y colectivas de trabajo, al empleo, la capacitación laboral y a la seguridad social.
 Órgano estatal a cargo de la definición, diseño, coordinación y evaluación de las políticas públicas referidas a las bebidas alcohólicas. Asimismo, la
 referida entidad, por medio de su Presidente, preside la Mesa Coordinadora de Fiscalización del Mercado de Bebidas Alcohólicas, cuya principal función
 Junta Nacional de Drogas
 es el desarrollo de un plan estratégico para la fiscalización del cumplimiento de las disposiciones referidas al mercado de bebidas alcohólicas y de la
 Ley de Creación de Marco Regulatorio para el Consumo Problemático de Bebidas Alcohólicas.
 En la órbita del Ministerio de Salud Pública funciona el Registro Obligatorio de Vendedores de Bebidas Alcohólicas, alcoholes para el consumo humano y
 Ministerio de Salud Pública
 actividades conexas. Este es el registro habilitante para las actividades de distribución, comercialización, venta, ofrecimiento y suministro de bebidas alcohólicas.
 Entidad encargada de administrar un registro de fabricantes e importadores que comercialicen bebidas alcohólicas destiladas y sus productos y de
 Laboratorio Tecnológico del Uruguay (LATU)
 emitir certificados para la comercialización de productos alimenticios y bebidas (no alcohólicas).
 Entidad encargada de fiscalizar toda la actividad del sector vitivinícola, del registro de empresas y la dictación de normas técnicas, incluyendo normas
 Instituto Nacional Vitivinícola (INAVI)
 sobre comercialización de productos vitivinícolas, realizando el control de estos productos en sustitución del LATU.
 Entidades encargadas de fiscalizar, dentro del territorio de cada Departamento, el cumplimiento de normas bromatológicas, realizando la habilitación
 Uruguay Intendencias Departamentales
 de locales, depósitos y vehículos para la comercialización, producción y transporte de alimentos.
 Comisión Nacional de Promoción y Defensa de la Competencia Autoridad dependiente del Ministerio de Economía y Finanzas encargada de controlar y sancionar las prácticas anticompetitivas.
 Autoridad nacional, integrante del Poder Ejecutivo, que tiene por competencia el diseño y la ejecución de toda la política nacional en materia de
 relaciones laborales tanto a nivel individual como colectiva. En el ámbito del Ministerio de Trabajo y Seguridad Social se realizan las audiencias de
 Ministerio de Trabajo y Seguridad Social
 conciliación obligatorias previas al inicio de cualquier reclamo laboral individual, así como las mediaciones en caso de conflictos colectivos de trabajo.
 También le compete a este Ministerio la Inspección Nacional de Trabajo.
 Ministerio de Industria Energía y Minería Autoridad nacional, integrante del Poder Ejecutivo, que tiene por competencia diseñar e instrumentar las políticas del Gobierno referidas al sector industrial.
 Ministerio de Ambiente. Dirección Nacional de Aguas Autoridad nacional, integrante del Poder Ejecutivo, responsable de la dirección de la política nacional de aguas. La DINAGUA es la que otorga los
 (DINAGUA) permisos de extracción de aguas subterráneas.
 Ministerio de Ambiente. Dirección Nacional de Calidad y Autoridad nacional, integrante del Poder Ejecutivo, responsable de la planificación, diseño y ejecución de la política ambiental en el país. En el ámbito
 Evaluación Ambiental (DINACEA) de la DINACEA se realiza el control ambiental de las actividades que se desarrollan en el país.
(1) Las entidades reguladoras que tienen facultades de fiscalización incluidas en esta sección corresponden a aquellas que tienen dichas atribuciones respecto de los distintos sectores productivos reflejados en cada Segmento de operación, así como en las principales
 Asociadas y Negocios Conjuntos.
Memoria Integrada 2024 / 6.1 Sector industrial 113

[pág. 115]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
País Entidades Fiscalizadoras(1) Descripción
 Dirección General de Personas y Estructuras Jurídicas y
 Entidad dependiente del Ministerio de Hacienda, encargada de la regulación y fiscalización de las sociedades anónimas.
 Beneficiarios Finales, y la Abogacía del Tesoro
 Autoridad sanitaria que, a través del Instituto Nacional de Alimentación y Nutrición (INAN), fiscaliza y sanciona las disposiciones del Código Sanitario
 Ministerio de Salud Pública y Bienestar Social y otras normativas. El INAN otorga el Registro Sanitario obligatorio para todos los productos alimenticios y bebidas de importadores, fabricantes,
 representantes y otros, y otorga el Registro de Establecimiento, necesario para habilitar las instalaciones respecto a requisitos higiénico-sanitarios.
 Autoridad responsable de regular, controlar y fiscalizar los productos para la salud como medicamentos de uso humano, drogas, productos químicos,
 Dirección Nacional de Vigilancia Sanitaria (DINAVISA) y productos como cosméticos, perfumes, domisanitarios y afines. La DINAVISA se encarga del Registro Nacional de Sustancias Estupefacientes y Drogas
 Peligrosas.
 Entidad encargada de la protección, mantenimiento e incremento de la condición fitosanitaria y la calidad de productos de origen vegetal y controlar los
 Servicio Nacional de Calidad y Sanidad Vegetal y de
 insumos de uso agrícola sujetos a regulación conforme a normas legales y reglamentarias. El SENAVE otorga el Certificado del Registro de Importador
 Semillas (SENAVE)
 y Subproductos de Origen Vegetal.
 Entidad encargada de regular y promover el incremento del comercio interno e internacional, además de recibir y procesar la inscripción de alimentos
 Ministerio de Industria y Comercio (MIC)
 elaborados o bebidas para el consumo.
 Entidad encargada de supervisar, fiscalizar y evaluar la Política Ambiental Nacional y de otorgar la Declaración de Impacto Ambiental, la cual es obligatoria
 Ministerio del Ambiente y Desarrollo Sostenible (MADES)
 para prever y estimar impactos ambientales en toda obra o actividad que tenga como consecuencia afectar la vida en general o recursos, entre otros.
 Órgano de aplicación de la Ley N° 422/78 “Forestal”, encargado de promover y fomentar el desarrollo forestal, monitorear y fiscalizar la extracción,
 Instituto Forestal Nacional (INFONA) industrialización y comercialización de productos maderables y no maderables provenientes del aprovechamiento del bosque hasta la primera
 Paraguay transformación de estos. Asimismo, se encarga del Registro de Importación Forestal.
 Autoridad fiscalizadora encargada de administrar los impuestos y de supervisar, elaborar y aplicar las disposiciones legales en materia impositiva, así
 como de regular y cobrar los impuestos, de aplicar sanciones y dar trámite a los recursos que sean aplicables. Asimismo, es la autoridad encargada de
 Dirección Nacional de Ingresos Tributarios (DNIT)
 dar trámite a los despachos de importación, recauda los tributos, aplica la legislación aduanera y realiza un control de mercaderías, personas, medios
 de transporte y las unidades de carga.
 Autoridad encargada de fiscalizar el cumplimiento de la normativa laboral vigente, promover la equidad y garantizar el trabajo decente y empleo digno,
 Ministerio de Trabajo, Empleo y Seguridad Social
 inserción y protección social. Interviene en el tratamiento de los conflictos individuales y colectivos extrajudiciales de trabajo, ejerciendo facultades de
 (MTESS)
 mediación y conciliación.
 Secretaría de la Defensa al Consumidor (SEDECO) Autoridad encargada de velar por la protección y defensa de los consumidores y usuarios.
 Órganos de gobierno local con personería jurídica que, dentro de su competencia, tienen autonomía política, administrativa y normativa. Conforme
 Autoridades Municipales a la Ley Orgánica Municipal, tienen competencia para la zonificación de los territorios, así como para la habilitación e inspección de establecimientos
 industriales dentro de su jurisdicción.
 Autoridad encargada de la aplicación de la Ley de Defensa de la Competencia, tiene el fin de promover y defender la libre competencia en los mercados,
 Comisión Nacional de la Competencia (CONACOM)
 mediante mecanismos de promoción, abogacía, investigación y sanción.
 Autoridad encargada de la prevención, recuperación y control del lavado de dinero proveniente del tráfico ilícito de estupefacientes, la drogadicción;
 Secretaría Nacional Antidrogas (SENAD) el control de drogas peligrosas y su prevención. En ese sentido, se encarga del registro y fiscalización de los operadores que comercializan sustancias
 químicas.
(1) Las entidades reguladoras que tienen facultades de fiscalización incluidas en esta sección corresponden a aquellas que tienen dichas atribuciones respecto de los distintos sectores productivos reflejados en cada Segmento de operación, así como en las principales
 Asociadas y Negocios Conjuntos.
Memoria Integrada 2024 / 6.1 Sector industrial 114

[pág. 116]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
País Entidades Fiscalizadoras(1) Descripción
 Entidad encargada de fiscalizar, controlar, supervisar y regular las actividades de las empresas en lo concerniente al cumplimiento de obligaciones comerciales,
 Autoridad de Empresas (AEMP)
 gobierno corporativo, defensa de la competencia y las recaudaciones establecidas por ley con el objeto de contribuir al crecimiento económico.
 Entidad regulatoria de bebidas, encargada del control y garantía de la inocuidad de los alimentos, en los tramos productivos y de procesamientos que
 Servicio Nacional de Sanidad Agropecuaria e Inocuidad
 correspondan al sector agropecuario, el control de insumos utilizados para la producción agropecuaria, agroindustrial y forestal, y la certificación de
 Alimentaria (SENASAG)
 la sanidad agropecuaria e inocuidad alimentaria de productos de consumo.
 Autoridad sanitaria a nivel Departamental, encargada de establecer, controlar y evaluar permanentemente la situación de salud en el departamento,
 Servicios Departamentales de Salud (SEDES)
 efectuar en forma desconcentrada el registro y control sanitario de alimentos.
 Secretarías de Medio Ambiente a nivel Departamental, así como las Secretarías Municipales, tienen como finalidad la protección y conservación del
 Secretarías de Medio Ambiente a Nivel Departamental medio ambiente y los recursos naturales, regulando las acciones del hombre con relación a la naturaleza y promoviendo el desarrollo sostenible con
 la finalidad de mejorar la calidad de vida de la población.
 Entidad dependiente del Ministerio de Justicia, encargada de hacer cumplir los derechos y garantías de los usuarios y consumidores y toda normativa
 Viceministro de Defensa del Consumidor de protección a los derechos de los consumidores, así como prevenir y promover tales derechos, pudiendo asimismo interpretar administrativamente
 dicha normativa.
 Entidad encargada de administrar el sistema de impuestos, además de optimizar las recaudaciones, mediante la administración, aplicación, recaudación
 Servicios de Impuestos Nacionales (SIN)
 Bolivia y fiscalización eficiente y eficaz de los impuestos.
 Entidad encargada de controlar y prevenir ilícitos aduaneros a través de inspección, vigilancia y control aduanero de mercancías que circulen por vías
 Aduana Nacional de Bolivia
 terrestres, fluviales, lacustres o aéreas.
 Entidad que tiene como objeto regular, controlar y fiscalizar las actividades de juego de lotería, azar, sorteos y promociones empresariales realizadas
 Autoridad del Juego (AJ)
 dentro del territorio boliviano de manera justa, legal y transparente con responsabilidad social.
 Entidad encargada de regular la prestación del servicio de agua potable y saneamiento básico, incluyendo la fiscalización, control, supervisión, regulación
 Autoridad de Fiscalización y Control Social de Agua
 de los recursos hídricos, priorizando el derecho de uso para consumo humano y el acceso al saneamiento en equilibrio con el medio ambiente, además
 Potable Saneamiento Básico (AAPS)
 de otorgar concesiones, licencias y registros para la prestación de los servicios.
 Entidad encargada de proteger y garantizar los derechos socio laborales en el marco del trabajo digno y el cumplimiento digno, además de velar por el
 Ministerio del Trabajo, Empleo y Previsión Social cumplimiento de la legislación laboral, interpretando, orientando la correcta aplicación de la normativa y promoviendo la capacidad de autorregulación
 de las partes, a través de las Inspecciones Laborales.
 Entidad encargada del registro de comercio, bajo la tuición del Ministerio de Desarrollo Productivo y Economía Plural, todo ello conforme la Ley N° 1.398
 Servicio Plurinacional de Registro de Comercio (SEPREC)
 (Ley de Registro de Comercio).
 Autoridad de Fiscalización y Control de Pensiones y Entidad creada para supervisar, fiscalizar, controlar y regular a las personas naturales y jurídicas que desempeñan sus actividades en el ámbito de la
 Seguro (APS) Seguridad Social de Largo Plazo y Mercado de Seguro, todo ello conforme la Ley N° 1.883 (Ley de Seguros).
(1) Las entidades reguladoras que tienen facultades de fiscalización incluidas en esta sección corresponden a aquellas que tienen dichas atribuciones respecto de los distintos sectores productivos reflejados en cada Segmento de operación, así como en las principales
 Asociadas y Negocios Conjuntos.
Memoria Integrada 2024 / 6.1 Sector industrial 115

[pág. 117]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
 País Entidades Fiscalizadoras(1) Descripción
 Segmento de Operación Vinos(2)
 Entidad que tiene como objetivo fundamental la fiscalización de la genuinidad de los productos vitivinícolas; contralor de la producción, circulación,
 Instituto Nacional de Viticultura (INV) fraccionamiento y comercialización de los alcoholes etílico y metanol y Autoridad de Aplicación del Sistema de Designación del Origen de los Vinos y
 Argentina de las Bebidas Espirituosas de Origen Vínico.
 Es la entidad responsable de recaudar, pagar, administrar y hacer cumplir los impuestos, IVA, aduanas e impuestos especiales del Registro de Mayoristas
 HM Revenue & Customs (HMRC)
 de Alcohol (“AWRS”) y los impuestos en general de las sociedades.
 Companies House Es la entidad que regula y fiscaliza a las sociedades.
 Information Commissioner’s Office Es la entidad encargada de la fiscalización y cumplimiento del Reglamento General de Protección de Datos del Reino Unido.
 Es la entidad encargada de establecer y revisar los estándares de publicidad ante cualquier reclamo publicitario que se haga sobre productos que se
 Reino Advertising Standards Authority
 comercialicen en el Reino Unido.
 Unido
 UK Border Force Entidad dependiente del Ministerio del Interior responsable de los controles fronterizos de inmigración y aduanas.
 Es el principal ente regulador que supervisa las normas y la seguridad de los alimentos en dicho país. El Equipo de Estándares de Vino es un equipo
 Food Standards Agency (FSA) - Wine Standards Branch
 dentro de la FSA y hace cumplir las regulaciones específicas del vino en el Reino Unido.
 Asociadas y Negocios Conjuntos(3)
 Entidad encargada de velar por el correcto funcionamiento y cumplimiento normativo de las sociedades comerciales y analizar de forma ocasional la
 Superintendencia de Sociedades situación jurídica, contable, económica y administrativa de éstas, incluyendo el cumplimiento de las obligaciones legales relativas al registro de inversión
 extranjera en Colombia.
 Ministerio de Comercio, Industria y Turismo (MINCIT) Entidad encargada de apoyar la actividad empresarial, productora de bienes, servicios y tecnología, así como la gestión turística de las regiones del país.
 Autoridad principal en materia sanitaria con competencia especial de inspección, vigilancia, control y sanción sobre la producción y venta de bebidas
 Instituto Nacional de Vigilancia de Medicamentos y
 alcohólicas, incluyendo el cumplimiento de todas las medidas sanitarias y de salubridad durante la producción y los requerimientos especiales frente
 Alimentos (INVIMA)
 al embotellamiento, etiquetado, publicidad y distribución de las bebidas alcohólicas.
 Entidad encargada, junto a las Secretarías de Hacienda Distritales y Municipales, de la administración y cumplimiento de las obligaciones en materia
 Dirección de Impuestos y Aduanas Nacionales (DIAN) fiscal y tributaria a nivel nacional y local, respectivamente. A su vez, la DIAN tiene competencia especial en materia tributaria y aduanera frente a las
 Colombia sociedades comerciales y mercancías que se encuentren dentro del régimen de Zonas Francas.
 Entidad encargada de la vigilancia y sanción en materia de protección al consumidor, régimen de protección a la libre competencia y régimen de
 Superintendencia de Industria y Comercio (SIC)
 protección al uso y tratamiento de datos personales.
 Entidad encargada de ejercer la prevención, inspección, control y vigilancia del cumplimiento de las obligaciones en materia laboral, así como la
 Ministerio del Trabajo
 investigación e imposición de sanciones derivadas de su incumplimiento.
 Entidad que tiene por objeto la ejecución de las políticas, planes, programas y proyectos sobre medio ambiente y recursos naturales renovables, así
 Corporación Autónoma Regional de Cundinamarca
 como el cumplimiento y oportuna aplicación de las disposiciones legales vigentes sobre su disposición, administración, manejo y aprovechamiento,
 (CAR)
 conforme a las regulaciones, pautas y directrices expedidas por el Ministerio de Medio Ambiente.
(1) Las entidades reguladoras que tienen facultades de fiscalización incluidas en esta sección corresponden a aquellas que tienen dichas atribuciones respecto de los distintos sectores productivos reflejados en cada Segmento de operación, así como en las principales
 Asociadas y Negocios Conjuntos.
(2) El Segmento de operación Vinos comprende además las entidades indicadas en el Segmento de operación Chile, salvo lo referido respecto de la SEC, y las entidades argentinas contenidas en el Segmento de operación Negocios Internacionales, salvo el INAL.
(3) Asociadas y Negocios Conjuntos comprende además las entidades indicadas en el Segmento de operación Chile, salvo lo referido respecto de la SEC, y las entidades argentinas contenidas en el Segmento de operación Negocios Internacionales.
Memoria Integrada 2024 / 6.1 Sector industrial 116

[pág. 118]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
 País Entidades Fiscalizadoras(1) Descripción
 Asociadas y Negocios Conjuntos(3)
 Autoridad Nacional de Licencias Ambientales (ANLA) Entidad encargada de aprobar y verificar el cumplimiento del Plan de Gestión Ambiental de Residuos de Envases y Empaques.
 El Ministerio de Salud y Protección Social de Colombia es la entidad gubernamental encargada de formular, adoptar, dirigir y coordinar las políticas,
 planes, programas y proyectos en materia de salud en el país. Algunas de las responsabilidades y funciones principales incluyen: la regulación de
 Ministerio de Salud y Protección Social
 bebidas alcohólicas, control de publicidad y etiquetado de productos, promoción de hábitos saludables, así como la prevención de enfermedades
 producidas por el consumo excesivo de bebidas alcohólicas y azucaradas.
 Cámaras de Comercio Las Cámaras de Comercio a nivel local y regional tienen funciones de registro y control de las empresas, así como de promoción del comercio y la inversión.
 Colombia
 Organización para la Cooperación y el Desarrollo La OCDE puede tener influencia en la regulación empresarial, especialmente en áreas relacionadas con buenas prácticas corporativas y estándares
 Económicos (OCDE) internacionales.
 Entidad gubernamental encargada de la gestión y supervisión de las finanzas públicas a nivel local, ya sea a nivel municipal, departamental o distrital.
 Secretaría de Hacienda Su influencia en las empresas privadas del país es indirecta pero significativa, ya que las políticas fiscales y financieras que implementan pueden afectar
 el entorno empresarial de diversas maneras
 La Unidad de Gestión Pensional y Parafiscales (UGPP) Entidad encargada de fiscalizar y verificar que las sociedades realicen de forma correcta y oportuna el pago de seguridad social y parafiscales a sus empleados.
(1) Las entidades reguladoras que tienen facultades de fiscalización incluidas en esta sección corresponden a aquellas que tienen dichas atribuciones respecto de los distintos sectores productivos
 reflejados en cada Segmento de operación, así como en las principales Asociadas y Negocios Conjuntos.
(3) Asociadas y Negocios Conjuntos comprende además las entidades indicadas en el Segmento de operación Chile, salvo lo referido respecto de la SEC, y las entidades argentinas contenidas en el
 Segmento de operación Negocios Internacionales.
Memoria Integrada 2024 / 6.1 Sector industrial 117

[pág. 119]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
Asociaciones y membresías
En CCU participamos activamente en diversas instancias externas que nos permiten contribuir al desarrollo sostenible, en línea con nuestra adhesión a Pacto Global y los avances que nos hemos
propuesto de acuerdo a los Objetivos de Desarrollo Sostenible (ODS).
Segmento de operación Chile
 N° Gremios, Asociaciones u Organizaciones Descripción Participación
 Organización sin fines de lucro que agrupa a empresas socias y entidades colaboradoras
1 ACCIÓN Empresas
 comprometidas con mejorar la vida de las personas y del planeta a través de la sostenibilidad en Chile.
 Organización sin fines de lucro que promueve el acceso a la justicia de personas o grupos vulnerables
2 Fundación Pro Bono y de organizaciones sociales, a través del trabajo voluntario o probono de abogados/as, estudios
 jurídicos y empresas.
3 Generación Empresarial Organización sin fines de lucro, que promueve la ética y las mejores prácticas en las empresas.
 Instituto Chileno de Administración Racional de Empresas Corporación privada sin fines de lucro e independiente de intereses gremiales y políticos, con el CCU S.A.
4
 (ICARE) propósito de promover la excelencia empresarial en el país.
 Iniciativa de las Naciones Unidas, que tiene por objetivo acelerar y ampliar el impacto global de los
5 Pacto Global negocios, contribuyendo al cumplimiento de los Objetivos de Desarrollo Sostenible (ODS) a través
 de empresas responsables y ecosistemas que fomenten el cambio.
 Federación gremial, sin fines de lucro, que reúne a empresas, asociaciones y gremios vinculados al
6 Sociedad de Fomento Fabril (SOFOFA) sector industrial chileno, la cual se ha constituido como la más importante, representativa y diversa
 insititución empresarial del país.
7 Asociación de Productores de Cerveza de Chile (ACECHI) Gremio que reúne y representa a las principales empresas de la industria cervecera nacional. CCU S.A. y Cervecera CCU Chile Limitada
 Asociación gremial que busca ser un punto de encuentro que permita colaborar en el desarrollo
8 Asociación Gremial de Industriales del Plástico (ASIPLA) CCU S.A. y Fábrica de Envases Plásticos S.A.
 sustentable de la industria del plástico.
 Entidad de derecho privado, sin fines de lucro, integrada por los principales gremios empresariales,
 Corporación para el Desarrollo Productivo de la Araucanía
9 universidades, sindicatos de trabajadores, empresas privadas e instituciones públicas relacionadas
 (CorpAraucanía)
 con la actividad productiva y el fomento de los negocios e inversiones en la IX Región. Cervecera CCU Chile Limitada
 Asociación gremial sin fines de lucro, que tiene por misión la racionalización, el desarrollo y la protección
10 Multigremial de la Araucanía (ASIMCA)
 de las actividades de los industriales de las provincias de Malleco y Cautín.
Memoria Integrada 2024 / 6.1 Sector industrial 118

[pág. 120]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
N° Gremios, Asociaciones u Organizaciones Descripción Participación
 Cervecera CCU Chile Limitada,
 Asociación gremial que buscar representar a toda la Industria Proveedora y sus marcas, velando
11 Asociación Gremial de Industrias Proveedoras (AGIP) Embotelladoras Chilenas Unidas S.A. y
 siempre por la libre competencia y las buenas prácticas.
 Compañía Pisquera de Chile S.A.
 Asociación gremial sin fines de lucro, que representa las inquietudes de sus asociados a las autoridades
12 Cámara de Comercio de Santiago del país, participando en la actividad legislativa que considera de interés de sus asociados y de las Cervecería Kunstmann S.A., La Barra S.A.
 empresas a nivel nacional.
 Cámara Chileno - Alemana de Comercio e Industria Asociación gremial sin fines de lucro, la cual constituye una poderosa plataforma comercial de
13
 (CAMCHAL) transferencia tecnológica y de know-how.
14 Cámara de Comercio e Industrias de Valdivia (CCIV) Organización dedicada a promover el desarrollo económico y empresarial en la ciudad de Valdivia.
 Cervecería Kunstmann S.A.
 Es una corporación privada, pluralista, sin fines de lucro y que busca potenciar el desarrollo de la
 Corporación para el Desarrollo de la Región de los Ríos
15 Región de Los Ríos, promoviendo la participación ciudadana en el quehacer local y regional junto a
 (CODEPROVAL)
 gremios, universidades y sector empresarial.
 Asociación gremial Pro Consumo Responsable de Bebidas Espirituosas de Chile, institución conformada
 Asociación Chilena de Empresas de Bebidas Espirituosas
16 por los principales representantes, importadores y productores de bebidas alcohólicas que operan
 Pro Consumo Responsable (APROCOR)
 en Chile.
 Asociación chilena, que reúne a viticultores, vinificadores, destiladores y envasadores de la industria Compañía Pisquera de Chile S.A.
17 Asociación de Productores de Pisco (APP)
 del pisco chileno, abarcando con sus miembros casi la totalidad de dichas áreas productivas.
 Asociación Gremial de Fabricantes y Distribuidores de Asociación gremial que vela por el bien de la industria de manera sostenible y en sintonía con los
18
 Licores y Bebidas Espirituosas de Chile (AFLECHI) consumidores.
19 AB Chile Asociación que representa a la industria de alimentos y bebestibles no alcohólicos del país.
20 Asociación de Industriales de Antofagasta (AIA) Gremio empresarial enfocado en ser líderes en desarrollo sustentable. Embotelladoras Chilenas Unidas S.A.
21 Asociación Nacional de Avisadores (ANDA) Asociación gremial compuesta por las empresas del país que realizan inversión publicitaria.
Memoria Integrada 2024 / 6.1 Sector industrial 119

[pág. 121]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
Segmento de operación Negocios Internacionales
N° Gremios, Asociaciones u Organizaciones Descripción Participación País
 Cámara Argentina de la Industria de Bebidas sin Cámara gremial empresarial que agrupa y representa a las principales compañías productoras de Aguas de
1
 Alcohol (CADIBSA) gaseosas, aguas con y sin gas, aguas saborizadas, jugos, isotónicas y energizantes en Argentina. Origen S.A.
 Asociación civil que agrupa a las principales compañías cerveceras, malteras, y comercializadoras
2 Cámara de la Industria Cervecera Argentina
 de cebada de Argentina.
 Entidad empresarial que agrupa más de 30 cámaras de la industria de alimentos y bebidas,
3 COPAL
 teniendo una representación sectorial y federal que alcanza a más de 2000 empresas.
 Cámara que proporciona servicios de búsqueda para agentes o representantes para la venta de Argentina
4 Cámara de Comercio Argentino-Holandesa Compañía
 sus productos en Argentina o los Países Bajos.
 Industrial
 Cámara que promueve los lazos comerciales entre Argentina y Chile, cumpliendo un rol Cervecera S.A.
5 Cámara de Comercio Argentino Chilena (CCACH) fundamental en la orientación y guía de empresas argentinas y chilenas en la concreción de
 negocios bilaterales.
 Organización que promueve el crecimiento y la competitividad de las empresas de Argentina. Su
6 IDEA objetivo es contribuir con el progreso económico y social, incidiendo directamente a través del
 debate y la ejecución de propuestas.
 Cámara de Industria, Comercio, Servicios y Turismo de Organización gremial que aglutina a las empresas industriales, comerciales, de servicios y turismo
7
 Santa Cruz - Cainco de Santa Cruz, Bolivia.
 Asociación gremial boliviana que aglutina a las empresas industriales, comerciales, de servicios
8 Cámara Nacional de Industrias (CNI) Bebidas Bolivianas
 y turismo, legalmente establecidas en el territorio boliviano. Bolivia
 BBO S.A.
 Es una institución empresarial privada, sin fines de lucro, con independencia económica y política.
9 Cámara Nacional de Comercio Creada para proteger los derechos del empresariado nacional y fortalecer la cohesión entre
 todas las regiones del país.
Memoria Integrada 2024 / 6.1 Sector industrial 120

[pág. 122]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
N° Gremios, Asociaciones u Organizaciones Descripción Participación País
 Cámara que promueve el desarrollo de la industria de alimentos y bebidas en el país, la economía
10 Cámara de Alimentos y Bebidas (CABE) de mercado, garantizando la seguridad alimentaria, la información al consumidor y el bienestar
 de las personas.
 Gremio del sector privado que se encarga de representar a las empresas y marcas anunciantes
11 Cámara de Anunciantes del Paraguay (CAP)
 ante la sociedad.
 Entidad sin fines de lucro que agrupa más de 500 empresas importadoras tradicionales, así como
12 Centro de Importadores del Paraguay (CIP)
 a otros prestadores de servicios a la importación.
13 Cámara Paraguaya de Bebidas Alcohólicas (CAPABA) Entidad que provee una plataforma y acción coordinada para la industria.
 Institución independiente, sin fines de lucro, la cual cuenta con una membresía actual de más
14 Cámara de Comercio Paraguayo Americana de 300 empresas y profesionales que representan a grandes, medianas y pequeñas firmas de
 diferentes rubros.
 Bebidas del
 Paraguay
 Asociación inscripta, sin fines de lucro, que tiene como objetivo la colaboración en la difusión, Paraguay S.A.
 Centro de Regulación, Normas y Estudios de la estudio, optimización y correcta aplicación de las normas jurídicas en materia de comunicación,
15
 Comunicación (CERNECO) publicidad, libertad de expresión y en especial la de expresión comercial, libertad de competencia,
 así como las relacionadas con la defensa de los derechos del consumidor.
 Entidad sin fines de lucro, que se configura como un interlocutor institucional de gran trayectoria,
16 Cámara de Comercio Paraguayo - Argentina
 en la articulación y generación de vínculos comerciales entre ambos países.
 Asociación sin fines de lucro que brinda servicios de asesoramiento e información para facilitar
17 Cámara de Comercio e Industria Paraguayo - Alemana los negocios de sus asociados, y busca fortalecer las relaciones económicas entre Paraguay y
 Alemania.
 Organización gremial cuya misión es satisfacer por medio de sus servicios las necesidades y
18 Unión Industrial Paraguaya (UIP) expectativas de los asociados y a través de ellos al país, promocionando el mejoramiento de la
 calidad de vida.
 Institución que representa al sector industrial del país buscando una articulación público-privada
19 Cámara de Industria del Uruguay (CIU) que permita el diseño y ejecución de políticas e instrumentos que favorezcan el desarrollo
 industrial. Milotur S.A. Uruguay
 Asociación de Importadores y Mayoristas de Almacén Institución que busca consolidar la unión de los asociados con el fin de dar la mayor eficiencia
20
 (AIMA) posible a los actos y las gestiones que la Asociación realice.
Memoria Integrada 2024 / 6.1 Sector industrial 121

[pág. 123]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
Segmento de operación Vinos
N° Gremios, Asociaciones u Organizaciones Descripción Participación País
 Organización que agrupa a más de 200 bodegas de todas las regiones vitivinícolas argentinas,
1 Bodegas de Argentina y Wines of Argentina (WofA) Finca La Celia S.A. Argentina
 cuyas exportaciones representan casi el 95% de las exportaciones totales de vino del país.
 Organización internacional cuyos miembros contribuyen al menos con el uno por ciento de
 sus ingresos anuales a causas medioambientales para proteger el medio ambiente. A través de
2 1% For the Planet Viña Tarapacá, VSPT firmó un acuerdo de colaboración con 1% For the Planet, para lo cual se
 comprometió a donar el 1% de las ventas de sus vinos Gran Reserva Tarapacá para ir en apoyo
 y difusión de proyectos de conservación, el que se canaliza a través de la ONG, Tierra Austral.
 Organización sin fines de lucro que agrupa a empresas socias y entidades colaboradoras
3 Acción Empresas comprometidas con mejorar la vida de las personas y del planeta a través de la sostenibilidad
 en Chile.
 Corresponden a tipos de Organizaciones de Usuarios de Agua (OUA), las cuales son entidades con
 personalidad jurídica, reglamentadas en el Código de Aguas, formadas por dos o más personas
 con derechos de aprovechamiento sobre las aguas en un mismo río, acuífero, canal, embalse u
 otra obra hidráulica de toma y distribución común. Representados por la Subgerencia Agrícola de
 VSPT Wine Group, se participa en las distintas instancias de reunión y colaboración de los socios.
 Durante el 2024, se consideran las siguientes OUA: Viña San Pedro
 Chile
 • Asociación De Canalistas Canal Pencahue Tarapacá S.A.
4 Asociaciones de canalistas y comunidades de agua
 • Comunidad de aguas Canal Cerrillano
 • Junta de vigilancia Río Seco de Lontué
 • Canal Comunidad y canal Pocillano
 • Asociación Canal El Huique y Las Trancas
 • Comunidad de aguas Toma La Encierra
 • Asociación de canales de la Ribera Sur del Cachapoal
 • Asociación Canal Huidobro
 Asociaciones de rutas del vino y asociaciones de viñateros en los principales valles donde VSPT
5 Asociaciones y Rutas del Vino de Casablanca y Curicó
 está presente, con el objetivo de promover el origen y potenciar el enoturismo local.
 Asociación gremial que buscar representar a toda la Industria Proveedora y sus marcas, velando
6 Asociación Gremial de Industrias Proveedoras (AGIP)
 siempre por la libre competencia y las buenas prácticas.
7 Asociación Nacional de Avisadores (ANDA) Asociación gremial compuesta por las empresas del país que realizan inversión publicitaria.
Memoria Integrada 2024 / 6.1 Sector industrial 122

[pág. 124]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
N° Gremios, Asociaciones u Organizaciones Descripción Participación País
 Asociación gremial sin fines de lucro, que representa las inquietudes de sus asociados a las
8 Cámara de Comercio de Santiago autoridades del país, participando en la actividad legislativa que considera de interés de sus
 asociados y de las empresas a nivel nacional.
 Conformado por 79 viñas, que en su conjunto representan más del 80% de la producción y
 exportación de vino embotellado. Su objetivo es desarrollar líneas de I+D de largo plazo, excelencia,
9 Consorcio I+D Vinos de Chile eficientes y centradas en las necesidades del sector vitivinícola nacional de manera transversal y
 que mejoren su competitividad, contribuyendo a posicionar a la industria chilena como productor
 de vinos premium, sustentables y diversos.
 Grupo de trabajo colaborativo sin fines de lucro de viñas comprometidas con el medio ambiente,
10 International Wineries for Climate Action (IWCA) que adoptan un enfoque basado en la ciencia para reducir las emisiones de carbono en toda la
 industria vitivinícola. Viña San Pedro
 Chile
 Tarapacá S.A.
 Red de empresas que busca promover espacios de trabajo inclusivos para la diversidad y generar
11 Pride Connection
 lazos para la atracción de talento a las distintas organizaciones que la componen.
 Agrupación, perteneciente a la SOFOFA, con más de 100 empresas que buscan fomentar procesos
12 Red de Empresas Inclusivas (REIN) responsables de inclusión laboral de personas con discapacidad, confirmando su beneficio social
 y económico para el país.
 Organización británica formada por organizaciones y profesionales de todo el mundo, que buscan
13 Sustainable Wine Roundtable (SWR)
 activamente un mundo más sostenible para la industria vitivinícola.
 Entidad gremial sin fines de lucro y de carácter privado que representa a los productores
14 Vinos de Chile vitivinícolas de Chile, el cual tiene como misión posicionar al vino chileno como un producto
 premium y sustenble, en nuestro país y el mundo.
Memoria Integrada 2024 / 6.1 Sector industrial 123

[pág. 125]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
6.2 Negocios
La Compañía ha definido tres Segmentos de operación, los cuales se determinaron en base a los Por su parte, las actividades de negocio realizadas por las UES, esto es: Comercial CCU S.A. (Comercial
ingresos de las actividades de negocios provenientes de las zonas geográficas donde comercializa CCU), Transportes CCU Limitada (Transportes CCU), CRECCU S.A. (CRECCU) y La Barra S.A. (La Barra),
sus productos: comprenden la comercialización, distribución, venta y en algunos casos financiamiento, de los productos
 de la Compañía en el territorio chileno, y a través de Fábrica de Envases Plásticos S.A. (PLASCO), la
 producción de prácticamente la totalidad de las preformas y tapas de las botellas plásticas retornables
 y no retornables utilizadas en el Segmento de operación Chile.
 La relación entre los Segmentos de operación y las UAC es regulada mediante contratos de servicios
 Chile Negocios Internacionales Vinos compartidos (Acuerdos de Nivel de Servicios), esto es, contratos anuales que especifican tanto los
 servicios prestados, así como las variables de medición del nivel de servicio y precio de los mismos.
 Cervezas, bebidas no Cervezas, sidra, bebidas Vinos y espumantes en el
 alcohólicas, licores, sidra y las no alcohólicas y licores, mercado doméstico, en Chile El nivel de servicio es evaluado dos veces al año cualitativamente, directamente por los usuarios,
 UESs en el mercado chileno entre otras categorías, en y Argentina, y exportación a y además existe un proceso de autoevaluación cuantitativo.
 los mercados de Argentina, más de 90 países
 Bolivia, Paraguay y Uruguay
Los tres Segmentos de operación señalados anteriormente son consistentes con la forma en que
se gestiona la Compañía. Estos Segmentos de operación reflejan información financiera separada,
que es revisada periódicamente por la máxima autoridad en la toma de decisiones de operación de
cada Segmento, con el objeto de definir la asignación de recursos y evaluación de su rendimiento.
Finalmente, los gastos e ingresos de las UAC son presentados en el Segmento Otros, en el que
figura la eliminación de las transacciones realizadas entre los Segmentos de operación.
Las UAC y UES proporcionan servicios compartidos a toda la organización, de forma centralizada,
a fin de captar las sinergias entre las diferentes unidades. Las UAC contemplan servicios, a nivel
regional, de tecnologías de información, administración y finanzas y abastecimiento, entre otros.
Memoria Integrada 2024 / 6.2 Negocios 124

[pág. 126]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
Segmentos de operación
 Chile
CCU, a través de su filial Cervecera CCU Chile Limitada (Cervecería CCU), cuenta con dos plantas
productivas, ubicadas en las ciudades de Santiago y Temuco, esta última es una planta mixta de
cervezas y bebidas no alcohólicas. Asimismo, la Compañía cuenta con otras plantas productivas
para cervezas, siendo las principales ubicadas en Valdivia (a través de Cervecería Kunstmann S.A.)
y Punta Arenas (a través de Cervecería Austral S.A.) y elabora un diverso portafolio de productos a
través de marcas propias y sus respectivas extensiones de marca. En cervezas, cuenta con las marcas
Cristal, Cristal CER0,0°, Escudo, Royal Guard, Royal Guard 0,0°, Morenita, Dorada, Andes, Stones y
Bavaria. Junto con ello, CCU produce y comercializa bajo licencia exclusiva las cervezas premium
Heineken, Heineken 0.0°, Sol, Coors, Polar Imperial y Patagonia. Adicionalmente, a través de sus filiales
y coligadas, produce y distribuye Kunstmann, Kunstmann Sin Alcohol, Austral, D’Olbek, Guayacán,
Mahina y Volcanes del Sur. La comercialización de cervezas se realiza en botellas de vidrio retornable
y no retornable, latas de aluminio, barriles de acero inoxidable y un volumen menor en botellas de
plástico, específicamente las variedades de la marca Stones.
A través de la filial Embotelladoras Chilenas Unidas S.A. (ECCUSA), la Compañía cuenta con tres plantas
productivas, una ubicada en la ciudad de Antofagasta y dos ubicadas en la ciudad de Santiago. La mayoría
de las marcas, ya sean propias o bajo licencia, tienen extensiones, incorporando sus versiones light y/o
zero, según corresponda. Compañía Cervecerías Unidas S.A. (CCU S.A.) es dueña de las marcas Bilz,
Pap, Pop Candy, Kem, Kem Xtreme y Nobis. Asimismo, la Compañía explota, bajo licencia de PepsiCo,
Inc. o sus empresas relacionadas, las marcas Pepsi, 7Up, H2OH!, Mirinda, Gatorade, Gatorlit, Rockstar
y Lipton Ice Tea. El contrato de licencia suscrito con Schweppes Holdings Limited le permite explotar las
marcas Crush, Canada Dry Limón Soda, Canada Dry Ginger Ale y Canada Dry Agua Tónica. La Compañía
participa con Watt’s S.A., como únicas accionistas en partes iguales, en la propiedad de Promarca S.A.,
sociedad titular de las marcas Watt’s, Yogu Yogu, Shake a Shake y Frugo, y adicionalmente cuenta con
licencias sobre dichas marcas para la producción, comercialización y distribución, en determinados
envases, de néctares de fruta bajo la marca Watt’s, incluyendo sus versiones Light y Selección, y bebidas
de fantasía con jugo de fruta a través de la marca Frugo. La Compañía distribuye Red Bull en el país y,
a través de la sociedad Bebidas Carozzi-CCU SpA, comercializa y distribuye bebidas instantáneas en
polvo bajo las marcas Sprim y Vivo.
Memoria Integrada 2024 / 6.2 Negocios 125

[pág. 127]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
A través de la filial Aguas CCU-Nestlé Chile S.A. (Aguas CCU) en sus plantas de Coinco y Casablanca, se
embotellan aguas purificadas, saborizadas y minerales: bajo la marca Nestlé Pura Vida se embotella
agua purificada; bajo las marcas Cachantun y Porvenir se embotellan aguas minerales; bajo las
marcas MAS y Woman se embotellan aguas saborizadas. Esta sociedad también importa la marca
de aguas minerales Perrier. Aguas CCU, a través de su filial Manantial S.A., produce, comercializa y
distribuye aguas purificadas bajo la marca Manantial, principalmente en botellones que funcionan
con dispensadores HOD (home and office delivery por su sigla en inglés), que se entregan en
hogares y oficinas. Manantial se embotella en Antofagasta, Santiago, Coronel y Puerto Montt.
 La Compañía, a través de su filial Compañía Pisquera de Chile S.A. (CPCh), cuenta con cinco plantas
 productivas en la IV Región, ubicadas en Ovalle, Pisco Elqui, Salamanca, Monte Patria y Sotaquí.
 Cada una de estas plantas cumple un rol, en términos de vinificación, destilación y envasado, para
 cada una de las marcas de nuestro portfolio. En las categorías pisco y cócteles, CPCh posee las
 marcas Mistral, Campanario, Horcón Quemado, Control Valle del Encanto, Tres Erres, Espíritu de
 Los Andes, La Serena, Hard Fresh, Iceberg, Ruta Cocktail, Sabor Andino Sour y La Pizka, junto con
 sus respectivas extensiones de línea. En la categoría ron, la Compañía cuenta con las marcas Sierra
 Morena y Cabo Viejo. En la categoría licores, cuenta con las marcas Fehrenberg, Kantal, Barsol,
 Puklaro y es distribuidor exclusivo en Chile de las marcas Pernod Ricard en el canal tradicional,
 entre las cuales se encuentran ron Havana Club y licores Jameson, Ballantine’s, Absolut, Chivas
 Regal, Beefeater y Ramazotti, entre otros, y distribuidor exclusivo de Fratelli Branca, con las marcas
 Fernet Branca, Branca Menta, Carpano, Punt e Mes y Borghetti. Finalmente, en la categoría sidras,
 la Compañía importa y distribuye desde CCU Argentina la marca Sidra 1888.
Memoria Integrada 2024 / 6.2 Negocios 126

[pág. 128]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
 Negocios Internacionales
El Segmento de operación Negocios Internacionales está compuesto por las operaciones de
Argentina, Bolivia, Paraguay y Uruguay.
En Argentina, CCU produce cervezas en sus plantas ubicadas en las ciudades de Salta, Santa Fe y
Luján. Sus principales marcas son Schneider, Imperial, Santa Fe, Salta, Córdoba, Norte, Palermo,
Isenbeck, Iguana y Bieckert. Adicionalmente, es titular de contratos de licencia exclusiva para la
producción y comercialización de Heineken, Amstel, Sol, Miller Genuine Draft, Warsteiner, Grolsch
y Blue Moon. Asimismo, CCU importa la marca Kunstmann. Del mismo modo, exporta cervezas
a diversos países, principalmente bajo las marcas Schneider, Heineken e Imperial. CCU también
participa en el negocio de la sidra, donde fabrica y comercializa las marcas líderes del mercado
Sidra Real, La Victoria, 1888 y Pehuenia. Participa asimismo en el negocio de licores, los que
se comercializan bajo la marca El Abuelo, además de importar pisco desde Chile. Dentro de su
portafolio, también vende y distribuye las marcas de vinos Eugenio Bustos y La Celia. Desde junio
de 2019, ha incorporado a su portafolio de vinos las marcas Colón y Graffigna pertenecientes a la
bodega Finca La Celia S.A. (filial en Argentina de VSPT Wine Group). En abril de 2022, CCU a través de su subsidiaria, Compañía Cervecerías Unidas Argentina S.A. adquirió
 el 49% de la propiedad de Aguas Danone de Argentina S.A., lo que incluye el negocio de aguas
 minerales y aguas saborizadas con sus marcas Villavicencio, Villa del Sur, Levité, Ser y Brío. Asimismo,
 la subsidiaria Compañía Cervecerías Unidas Argentina S.A., adquirió 49.000 acciones ordinarias,
 nominativas no endosables de la sociedad Aguas de Origen S.A., a un valor de un peso argentino
 cada una, quedando con una participación de un 49% de esta sociedad. Cabe señalar que Aguas de
 Origen S.A., es la continuadora del negocio de Aguas Danone de Argentina S.A. lo que fue efectivo a
 partir del 1 de diciembre de 2022 como consecuencia de la escisión-fusión aprobada por asambleas
 de Aguas Danone de Argentina S.A. y Aguas de Origen S.A. el 30 de junio de 2022. Con fecha 30
 de noviembre de 2022, se realizó una compra de 634.061 acciones a Holding Internationale De
 Boissons S.A.S. lo que corresponde al 1% de las acciones de Aguas de Origen S.A., con lo cual CCU
 alcanzó el 50% de participación sobre ésta. Con la adquisición de las participaciones en Aguas de
 Origen S.A. y Aguas Danone de Argentina S.A., durante el año 2022, CCU se incorporó al negocio de
 aguas minerales y saborizada, participando con sus marcas Villavicencio, Villa del Sur, Levité, Ser y
 Brío. En julio de 2024 CCU adquirió el 0,1% de las acciones de Aguas de Origen S.A. alcanzando la
 participación mayoritaria y consolidando los resultados de la Compañía.
Memoria Integrada 2024 / 6.2 Negocios 127

[pág. 129]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
CCU en Bolivia participa en el negocio de bebidas no alcohólicas y cervezas a través de Bebidas CCU en Paraguay desarrolla el negocio de producción, comercialización y venta de bebidas no
Bolivianas BBO S.A., sociedad que cuenta con dos plantas, ubicadas en Santa Cruz de la Sierra alcohólicas, cervezas, vinos, pisco y alimentos. En gaseosas, cuenta con la marca Pulp, y la licencia
y Warnes. En bebidas no alcohólicas, está presente en la categoría de gaseosas con las marcas para producir y distribuir Pepsi, Paso de los Toros, Mirinda, 7up y Split. En jugos, Puro Sol y la
Mendocina y Sinalco. También participa en la categoría de productos en base a malta sin alcohol licencia para producir y distribuir néctares bajo la marca Watt’s. En Aguas, cuenta con la marca La
con la marca Malta Real y en la categoría de aguas con las marcas Mendocina y De La Sierra. En Fuente y la licencia para producir y distribuir Aquafina. En isotónicas, tiene la licencia para importar
cervezas, cuenta con marcas propias y licenciadas, tales como Uyuni, Real, Capital, Cordillera, y distribuir la marca FullSport, bebida isotónica proveniente de Uruguay y la licencia para importar,
Amstel y Schneider. Adicionalmente, Bebidas Bolivianas BBO S.A. comercializa la marca importada producir y distribuir Gatorade. En energéticas, cuenta con la licencia para importar Red Bull, y la
de cerveza Heineken. licencia para producir y distribuir Rockstar. En cervezas, cuenta con licencia para distribuir cervezas
 bajo las marcas Heineken, Amstel, Sol, Blue Moon, Schin, Paulaner y Kunstamann. En cervezas
CCU en Uruguay participa en el negocio de aguas minerales con las marcas Nativa y Nix, en gaseosas artesanales cuenta con la marca Sajonia y sus variedades, las que son producidas localmente. En
con la marca Nix, en néctares con la marca Watt’s y en bebidas isotónicas con la marca FullSport. pisco, importa y distribuye pisco Mistral. Adicionalmente, CCU en Paraguay distribuye alimentos
Adicionalmente, comercializa marcas importadas de nuestras filiales en Chile y Argentina, en cervezas en las categorías de snacks y cereales. En snacks, distribuye las marcas Lays, Doritos, Cheetos y
cuenta con Heineken, Schneider, Imperial, Kunstmann, Amstel, Miller Genuine Draft y Escudo Silver, Fandango; y Quaker en cereales.
y en vinos con Misiones de Rengo, La Celia y Eugenio Bustos, y en sidras con las marcas 1888 y Real.
Memoria Integrada 2024 / 6.2 Negocios 128

[pág. 130]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
 Vinos
CCU, a través de su filial VSPT Wine Group, elabora vinos y espumantes, los cuales se comercializan
en el mercado nacional y extranjero exportando a más de 90 países. VSPT Wine Group está formado
por las viñas San Pedro, Tarapacá, Santa Helena, Misiones de Rengo, Leyda y Viña Mar en Chile,
además de Finca La Celia y Bodega Graffigna en Argentina; contando con plantas productivas en
las ciudades de Molina, Isla de Maipo y Totihue. En Argentina cuenta con las bodegas Finca La Celia
y San Juan, ubicadas en las provincias de Mendoza y San Juan, respectivamente.
Sus principales marcas son Altair, Cabo de Hornos, Sideral, 1865, Castillo de Molina, Épica, Gato
(en mercado doméstico) y GatoNegro (en exportaciones) de Viña San Pedro; las líneas Varietal,
Reserva y Gran Reserva de la Viña Tarapacá y sus etiquetas Azul, Negra y Roja; Viña Leyda en
sus series Reserva, Coastal Vineyard y Lot; Misiones de Rengo en sus series Gran Reserva Black,
Cuvée, Reserva, Varietal, y su línea Sparkling y la extensión de marca “Misión”. Además de Alpaca,
la línea Reserva y Gran Reserva de Viña Santa Helena; y en la categoría espumantes, Viñamar en
sus expresiones Método Tradicional, Extra Brut, Brut, Brut Nature, Brut Unique, Rosé, Moscato,
ICE y Viñamar Zero Desalcoholizado; además, destaca Donnaluna en la categoría de cóctel de vino
y, finalmente, Manquehuito en la categoría coolers y sangrías. En Argentina, a su vez, destacan las
marcas La Celia, Graffigna, Colón y Colón Selecto.
Memoria Integrada 2024 / 6.2 Negocios 129

[pág. 131]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
Principales asociadas y negocios conjuntos
CCU participa en partes iguales con Maltexco S.A. en la propiedad de Cervecería Austral S.A. (Austral),
sociedad que produce, vende y distribuye cerveza Austral en Chile. Adicionalmente, Cervecería
CCU cuenta con un contrato de licencia indefinida, sujeto al cumplimiento de las condiciones
establecidas en dicho contrato, para la producción de cervezas Patagonia y Polar Imperial en Chile y
un contrato de distribución para la venta y comercialización de la totalidad de los productos Austral
en Chile, con excepción de la Región de Magallanes, donde la venta y distribución es efectuada por
Comercial Patagona Ltda., filial de Austral y en la que Austral cuenta con un centro de distribución
con tecnologías no contaminantes, inaugurado en el año 2019.
En Colombia, CCU participa en partes iguales con Grupo Postobón en la propiedad de Central
Cervecera de Colombia S.A.S. (CCC) y en Zona Franca Central Cervecera S.A.S. (ZFCC) para la
elaboración, comercialización y distribución en ese país de cervezas y bebidas no alcohólicas en
base a malta. CCC cuenta con contratos exclusivos para la importación, distribución y producción
en Colombia de cervezas bajo las marcas Heineken, Tecate y Sol, así como Coors light, y para la
producción, comercialización y distribución de las marcas Miller Lite y Miller Genuine Draft. Cuenta
además con las marcas propias de cerveza local Andina y Andina Light, Natumalta para bebidas
no alcohólicas en base a malta, y Andina “Refajo”, una mezcla de cerveza y gaseosa. Bajo el actual
modelo de gestión, ZFCC produce nuestros productos en la planta inaugurada en mayo del año
2019, los que vende a CCC para su comercialización y distribución. Bajo un modelo análogo,
Artesanos de Cervezas S.A.S., filial de CCC, produce la marca 3 Cordilleras que es comercializada
y distribuida por CCC.
Memoria Integrada 2024 / 6.2 Negocios 130

[pág. 132]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
Comercialización, distribución y venta Proveedores
CCU abarca directamente las actividades productivas y comerciales en Chile a través de sus filiales y En relación a nuestros proveedores, en el Segmento de operación Chile ningún proveedor concentra
coligadas Cervecería CCU, ECUSA, VSPT Wine Group, CPCh, Aguas CCU, Cervecería Kunstmann S.A. más del 10% de las compras efectuadas en dicho Segmento de operación. En el Segmento de
(CK) y Austral, entre otras. A su vez, Comercial CCU es responsable de la venta, tanto para clientes operación Negocios Internacionales, ningún proveedor que representa más del 10% de las compras
a través de nuestra fuerza de venta, en aquellas zonas en que esta modalidad de venta resulta más efectuadas en este Segmento de operación. En el Segmento de operación Vinos ningún proveedor
eficiente, y La Barra S.A. (La Barra) es responsable de la venta a consumidores desde Arica a Puerto concentra más del 10% de las compras efectuadas en este Segmento de operación.
Montt a través del portal de venta online (www.labarra.cl), de todos los productos de la Compañía en
Chile y Transportes CCU está a cargo de la distribución de los productos. Ambas filiales forman parte Para satisfacer sus diversos requerimientos, CCU celebra contratos de abastecimientos respecto
del Segmento de operación Chile. En la zona extremo sur del país, la venta y la distribución se realiza de sus principales materias primas entre ellos malta, azúcar, pulpa de fruta, arroz, jarabe de maíz,
a través de Comercial Patagona Limitada. En el caso específico de nuestro negocio de aguas HOD, uva, vino, concentrados de gaseosas por licencias, lúpulo, esencias y alcohol (pisquero, neutro y
Manantial S.A., desde sus inicios, cuenta con su propia red de venta con 14 sucursales. La distribución otros), y material de embalaje, principalmente latas de aluminio, botellas de vidrio y PET, entre otros.
también se maneja directamente pues, dada la naturaleza del producto, se requiere de un tipo de
transporte distinto al resto del portafolio de CCU. En Argentina, Uruguay, Paraguay, Colombia y Bolivia, La Compañía no cuenta con patentes de su propiedad y de importancia utilizados en procesos
estas operaciones son desarrolladas mediante fuerza de venta propia, así como por distribuidores. productivos.
La Compañía se relaciona con múltiples clientes y proveedores, llegando a 111.134 puntos de venta
relacionado al Segmento de operación Chile. Por su parte, La Barra distribuyó nuestros productos a
66.455 hogares en Chile. Adicionalmente, el negocio de aguas HOD en Chile, a través de Manantial S.A.,
filial de Aguas CCU, abarca aproximadamente 48.637 clientes directamente abastecidos en sus hogares
y llega a oficinas de 12.768 empresas. En el Segmento de operación Vinos, el negocio de vino doméstico
en Chile llegó a 29.677 puntos de venta. En el Segmento de operación Negocios Internacionales,
estimamos que el total de puntos de venta alcanzados en Argentina son 215.750, en Bolivia 15.282,
en Paraguay 35.527 y en Uruguay 17.600.
Clientes
En el Segmento de operación Chile, no tenemos ningún cliente que represente más del 10% de
los Ingresos por ventas de dicho Segmento de operación. En el Segmento de operación Negocios
Internacionales no tenemos ningún cliente que represente más del 10% de los Ingresos por ventas,
de dicho Segmento de operación. En el caso del Segmento de operación Vinos no tenemos ningún
cliente que represente más del 10% de los Ingresos por ventas en dicho Segmento de operación.
Memoria Integrada 2024 / 6.2 Negocios 131

[pág. 133]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
Licencias y contratos
La Compañía cuenta con numerosas licencias y contratos para la producción, comercialización y/o distribución de sus marcas y productos en sus respectivos mercados, siendo los principales presentados
en la tabla a continuación:
 Licencia Fecha de Expiración Licenciante Territorio Derechos
Aberlour, Absolut, Ballantine's, Beefeater, Blender’s Pride, Borzoi,
Chivas Regal, Cuvee MUMM, Dubonnet, Elyx, G.H. MUMM, Havana Club,
Jameson, Kahlúa, Level, Long John, Longmorn, Malibu, Martell, Olmeca, Junio 2027 Pernod Ricard Chile S.A. Chile Comercializar los productos en el Territorio
Orloff, Passport, Pernod, Perrier Jouet, Ricard, Royale Salute, Sandeman,
Scapa, Strathisla, The Glenlivet, Wyborowa, 100 Pipers, para Chile(1)
Amstel para Argentina(2) 10 años renovables Amstel Brouwerij B.V. Argentina Elaborar y comercializar los productos en el Territorio
Amstel para Bolivia(9) Agosto 2033 Heineken Brouwerijen B.V. Bolivia Elaborar y comercializar los productos en el Territorio
Amstel para Uruguay(16) En proceso Amstel Brouwerij B.V. Uruguay Comercializar los productos en el Territorio
Amstel para Paraguay(1) Septiembre 2027 Amstel Brouwerij B.V. Paraguay Comercializar los productos en el Territorio
Austral para Chile(4) Julio 2026 Cervecería Austral S.A. Chile Comercializar los productos en el Territorio
Avena Quaker Extra Fino, Avena Tradicional Fortificada Ca-Fe-Zn, Barra
Display Chispa Chocolate, Barra Display Frutilla, Barra Display Vainilla
Toffe, Barra Display Vainilla Toffe, Cheetos, Doritos Queso, Fandangos
Presunto, Fandangos Queijo, Honey Graham, Honey Nut, Lays Clásicas,
Harina de Avena Integral Py, Lays stax SCO, Lays stax Original, Tostitos,
Stax Sal, Lay’s Ketchup, Stax Sco Casa, Lays Stax Cheddar, Lays Queso 14 de octubre del 2034 PepsiCo del Paraguay S.R.L. Paraguay Comercializar los productos en el Territorio
y Pimienta, Lays Ceb Car Lto, Cheetos Pali, Aveia Quaker Fr, Granola
Quaker Miel y Pasas, Granola Quaker Miel y Almendras, Avena
Multisemilla II, Avena Multisemillas IV, Quaker Avena Instant, Avena
Multisemillas I, Barra Display Manzana, Tostitos, Doritos DInamita FH y
Lays TA FH para Paraguay
 Coors Brewing Company d/b/a Molson Coors
Blue Moon para Argentina(19) Diciembre 2028 renovables Argentina Elaborar y comercializar los productos en el Territorio
 International y MCI Investments LLC
Blue Moon para Paraguay Abril 2028 Coors Brewing Company Paraguay Comercializar los productos en el Territorio
Coors para Chile(5) Diciembre 2025 Coors Brewing Company Chile Elaborar y comercializar los productos en el Territorio
Crush, Canada Dry (Ginger Ale, Agua Tónica y Limón Soda) para Chile(6) Diciembre 2028 Schweppes Holding Limited Chile Elaborar y comercializar los productos en el Territorio
Fernet Branca, Brancamenta, Punt E Mes, Borghetti, Carpano Rosso y
 Diciembre 2029 Fratelli Branca Destilerías S.A. Chile Comercializar los productos en el Territorio
Carpano Bianco para Chile
Frugo para Chile Indefinida Promarca S.A. Chile Elaborar y comercializar los productos en el Territorio
Gatorade para Chile(7) Diciembre 2043 Stokely Van Camp Inc. Chile Elaborar y comercializar los productos en el Territorio
Gatorade para Paraguay(21) 1 de abril de 2033 PepsiCo del Paraguay S.R.L. Paraguay Elaborar y comercializar los productos en el Territorio
Memoria Integrada 2024 / 6.2 Negocios 132

[pág. 134]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
Licencia Fecha de Expiración Licenciante Territorio Derechos
Grolsch para Argentina Mayo 2028 Asahi Premium Brands Argentina Elaborar y comercializar los productos en el Territorio
Heineken para Bolivia(8) Diciembre 2029 Heineken Brouwerijen B.V. Bolivia Comercializar los productos en el Territorio
 Chile y
Heineken para Chile y Argentina(9) 10 años renovables Heineken Brouwerijen B.V. Elaborar y comercializar los productos en el Territorio
 Argentina
Heineken para Colombia(10) Marzo 2028 Heineken Brouwerijen B.V. Colombia Elaborar y comercializar los productos en el Territorio
Heineken para Paraguay(1) Mayo 2026 Heineken Brouwerijen B.V. Paraguay Comercializar los productos en el Territorio
Heineken para Uruguay(9) 10 años renovables Heineken Brouwerijen B.V. Uruguay Comercializar los productos en el Territorio
Mas para Uruguay(15) Diciembre 2028 Aguas CCU-Nestlé Chile S.A. Uruguay Elaborar y comercializar los productos en el Territorio
Kunstmann para Colombia(1) Julio 2025 Cervecería Kunstmann S.A. Colombia Comercializar los productos en el Territorio
Miller para Argentina(10) Diciembre 2026 Coors Brewing Company Argentina Elaborar y comercializar los productos en el Territorio
Miller Lite y Miller Genuine Draft para Colombia(13) Diciembre 2026 Coors Brewing Company Colombia Elaborar y comercializar los productos en el Territorio
Miller para Uruguay(6) Julio 2026 Coors Brewing Company Uruguay Comercializar los productos en el Territorio
Nestlé Pura Vida para Chile(6) Diciembre 2027 Nestlé S.A., Societé de Produits Nestlé S.A. y Nestec S.A. Chile Elaborar y comercializar los productos en el Territorio
Paulaner para Paraguay Abril 2025 Paulaner Brauerei GmbH & Co KG Paraguay Comercializar los productos en el Territorio
Patagonia para Chile Indefinida Cervecería Austral S.A. Chile Elaborar y comercializar los productos en el Territorio
 PepsiCo, Inc., Seven-Up International, a través de
Pepsi, Seven Up, Mirinda y H2OH! para Chile Diciembre 2043 Chile Elaborar y comercializar los productos en el Territorio
 Bebidas CCU-PepsiCo SpA
Pepsi, Pepsi Light, Pepsi Max, Pepsi Blue, Pepsi Black, 7up, 7up Free,
Mirinda (Guaraná), Mirinda Free (Guaraná), Paso de los Toros, Paso de 1 de abril de 2033 PepsiCo del Paraguay S.R.L. Paraguay Elaborar y comercializar los productos en el Territorio
los Toros Free y Aquafina para Paraguay(21)
Polar Imperial para Chile Indefinida Cervecería Austral S.A. Chile Elaborar y comercializar los productos en el Territorio
Red Bull para Chile(11) Indefinida Red Bull Panamá S.A. Chile Comercializar los productos en el Territorio
Redbull para Paraguay(16) En proceso Red Bull Panamá S.A. y AJ S.A. Calidad Ante Todo Paraguay Comercializar los productos en el Territorio
Rockstar para Chile(17) Diciembre 2043 Pepsi Cola Manufacturing Company of Uruguay S.R.L. Chile Elaborar y comercializar los productos en el Territorio
Schneider para Bolivia(16) En proceso Compañía Industrial Cervecera S.A. Bolivia Elaborar y comercializar los productos en el Territorio
Split para Paraguay(16) En proceso PepsiCo del Paraguay S.R.L. Paraguay Comercializar los productos en el Territorio
Sol para Argentina(9) 10 años renovables Heineken Brouwerijen B.V. Argentina Elaborar y comercializar los productos en el Territorio
Sol para Chile(9) 10 años renovables Heineken Brouwerijen B.V. Chile Elaborar y comercializar los productos en el Territorio
Sol para Colombia(3) Marzo 2028 Heineken Brouwerijen B.V. Colombia Elaborar y comercializar los productos en el Territorio
Sol para Paraguay(1) Enero 2026 Heineken Brouwerijen B.V. Paraguay Comercializar los productos en el Territorio
Té Lipton para Chile Diciembre 2030 Pepsi Lipton International Limited Chile Elaborar y comercializar los productos en el Territorio
Tecate para Colombia(3) Marzo 2028 Heineken Brouwerijen B.V. Colombia Elaborar y comercializar los productos en el Territorio
Villavicencio, Villa del Sur, Levite, Brio, Ser, We, Mate Power, Evian y Ser
 Indefinida Aguas de Origen S.A. Argentina Comercializar los productos en el Territorio
(en polvo)(18)
Memoria Integrada 2024 / 6.2 Negocios 133

[pág. 135]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
 Licencia Fecha de Expiración Licenciante Territorio Derechos
Warsteiner para Argentina(14) Mayo 2028 Warsteiner Brauerei Haus Cramer KG Argentina Elaborar y comercializar los productos en el Territorio
Watt’s para Uruguay 99 años renovables Promarca Internacional SpA Uruguay Elaborar y comercializar los productos en el Territorio
Watt's (néctares, bebidas en base a fruta y otros) en envases rígidos,
 Indefinida Promarca S.A. Chile Elaborar y comercializar los productos en el Territorio
excepto cartón para Chile
Watt's (jugos) en envases rígidos, excepto cartón para Chile(20) Diciembre 2028 Promarca S.A. Chile Elaborar y comercializar los productos en el Territorio
Watt's para Paraguay(12) Julio 2026 Promarca Internacional Paraguay S.R.L. Paraguay Elaborar y comercializar los productos en el Territorio
(1) Renovable por periodos sucesivos de 3 años.
(2) Luego del vencimiento inicial, licencia se renueva automáticamente en idénticas condiciones (Rolling Contract), cada año por un período
 de 10 años, salvo aviso de no renovación.
(3) El contrato se mantendrá vigente mientras se mantenga vigente el contrato de licencia de Heineken para Colombia.
(4) Licencia renovable por períodos de 2 años, sujeto al cumplimiento de las condiciones establecidas en el contrato.
(5) Luego del vencimiento inicial, licencia se renueva automáticamente en idénticas condiciones (Rolling Contract), cada año por un período
 de 5 años, sujeto al cumplimiento de las condiciones establecidas en el contrato.
(6) Licencia se renueva por periodos de 5 años, sujeto al cumplimiento de las condiciones establecidas en el contrato.
(7) Licencia se renovó por un período igual a la duración del Pacto de Accionistas de Bebidas CCU-PepsiCo Spa.
(8) Licencia por 10 años, renovables automáticamente, por períodos de 5 años, salvo aviso de no renovación.
(9) Licencia por 10 años, renovables automáticamente en idénticas condiciones (Rolling Contract), cada año por un período de 10 años,
 salvo aviso de no renovación.
(10) Luego del vencimiento inicial, la licencia se renueva automáticamente cada año por un período de 5 años (Rolling Contract), salvo aviso
 de no renovación.
(11) Contrato indefinido, aviso de término con 6 meses de anticipación. 
(12) Sub-licencia se renueva automática y sucesivamente por dos periodos de 5 años cada uno, sujeto a los términos y condiciones estipulados en el
 contrato de Sub-licencia Internacional de 28 de diciembre de 2018 entre Promarca Internacional Paraguay S.R.L. y Bebidas del Paraguay S.A.
(13) Licencia se renueva por un periodo de 5 años, sujeto al cumplimiento de las condiciones establecidas en el contrato.
(14) Previo a la expiración del plazo, las partes negociarán su renovación por otros 5 años.
(15) Contrato renovable por periodos sucesivos de 10 años.
(16) Se inició la comercialización de los productos, contrato en proceso de negociación.
(17) Mientras se encuentre vigente el pacto de accionistas de Bebidas CCU-PepsiCo SpA.
(18) Vigencia indefinida hasta tanto se configure alguna de las causales de terminación. Incumplimiento esencial, que CCU deje de ser
 accionista de Aguas de Origen S.A. o que alguna sea declarada en quiebra.
(19) Luego del vencimiento inicial, licencia se renueva automáticamente en idénticas condiciones (Rolling Contract), por dos períodos de 5
 años, sujeto al cumplimiento de las condiciones establecidas en el contrato.
(20) Plazo se renovará automáticamente por períodos iguales y sucesivos de 5 años cada uno, salvo aviso con a lo menos 1 año de anticipación
 al vencimiento del plazo original o de cualquiera de sus prórrogas.
(21) Luego del vencimiento inicial, opera una renovación 4 años, salvo notificación por escrito de no renovar por al menos 1 año antes de
 la finalización del vencimiento inicial.
Memoria Integrada 2024 / 6.2 Negocios 134

[pág. 136]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
6.3 Grupos de interés
Para mayor información ver sección “3.7 Relación con los grupos de interés y el público en general”.
6.4 Propiedades e instalaciones
A continuación, se presenta la información correspondiente a nuestras principales plantas de
producción al 31 de diciembre de 2024, todas ellas son de nuestra propiedad o de nuestras
subsidiarias.
Para el Segmento de operación Chile, tenemos una capacidad de producción instalada agregada
mensual de 337,8 millones de litros, incluyendo Manantial, con una capacidad de utilización(4) durante
los meses de mayor producción de 73,7%. La capacidad total anual nominal instalada para este
Segmento de operación es 3.715,9 millones de litros. El tamaño total de nuestras instalaciones en
el Segmento de operación Chile es de 1.141.703 metros cuadrados.
Para el Segmento de operación Negocios Internacionales, tenemos una capacidad de producción
instalada agregada mensual de 218,2 millones de litros, con una capacidad de utilización(4) durante
los meses de mayor producción de 70,7%. La capacidad total anual nominal instalada para este
segmento es 2.392,0 millones de litros. El tamaño total de nuestras instalaciones en el Segmento
de operación Negocios Internacionales es de 500.437 metros cuadrados.
Para nuestro Segmento de operación Vinos, tenemos una capacidad nominal de llenado agregada de
88.445 litros por hora y una capacidad de almacenamiento en tanques y barriles de 126,6 millones
de litros. El tamaño total de nuestras instalaciones en el Segmento de operación Vinos es de 153.706
metros cuadrados.
(4) La capacidad utilizada durante el mes de mayor producción es igual al resultado de la producción como porcentaje de la
 capacidad de producción nominal instalada durante nuestro mes de mayor producción para cada planta correspondiente.
 La capacidad de producción nominal mensual instalada se define como la capacidad de producción para el mix vigente de
 producción/envasado durante un período de 25 días al mes y 3 turnos al día. La holgura (de refuerzo) implícita no mide
 necesariamente la holgura real. Creemos que la capacidad de producción real es inferior a la capacidad de producción nominal
 instalada, ya que se requieren ajustes para el desempeño real de la maquinaria, mix de envasado, disponibilidad de materias
 primas y botellas, estacionalidad entre los meses y otros factores. Como resultado de lo anterior, creemos que las tasas de
 utilización de la capacidad mensual de los meses de mayor producción mostradas subestiman la capacidad real de utilización
 y que la holgura se sobreestima.
Memoria Integrada 2024 / 6.4 Propiedades e instalaciones 135

[pág. 137]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
Principales plantas productivas y centros de distribución
 Centros de distribución propios
 Arica Chillán
Segmento de operación Segmento de operación
 Iquique Talcahuano
Chile Negocios Internacionales
 Antofagasta Los Ángeles
Plantas Cerveza Plantas Cerveza Calama Valdivia
 Buenos Aires
 Colombia
 Santiago - Quilicura Copiapó Osorno
 Valdivia Argentina Santa Fe Coquimbo Puerto Montt
Plantas Mixtas Salta Chile Ovalle Cervecera
 Temuco (Cervezas y No Alcohólicas) Paraguay Sajonia Llay Llay Temuco
Plantas No Alcohólicas Plantas Mixtas Curauma Modelo
 Antofagasta Bolivia Warnes (cerveza y malta) Santiago Sur Villarica
 Casablanca Plantas No Alcohólicas Renca Coyhaique
 Bolivia Rancagua Punta Arenas
 Coinco Uruguay Pan de Azúcar
 Talca
 Coronel (Manantial) San Antonio I
 Paraguay Santa Fe Ciudadela
 Santiago - Embotelladora CCU Renca San Antonio II
 Argentina Salta Pilar
 Santiago - Renca Modelo Bolivia Santa Cruz de la Sierra
 Chile Luján
 Santiago - Quilicura (Manantial) Mendoza(3) Paraguay Encarnación Cuidad del Este
 Argentina Paraguay
 Puerto Montt (Manantial) Buenos Aires (4)
 San Antonio
Plantas Licores Plantas Sidra Uruguay Pan de Azúcar
 Elqui Allen Bolivia Santa Cruz de la Sierra La Paz
 Argentina
 Monte Patria Ciudadela
 Salamanca Centros de distribución arrendados
 Sotaquí Segmento de operación Uruguay Illapel Castro
 Ovalle Vinos Chile
 La Vara San Antonio
 Plantas Vinos
 Rosario Mendoza
Principales asociadas y Molina
 Argentina Córdoba Alianza
negocios conjunto Chile Isla de Maipo 36 54 San Juan Sauce Viejo
 Totihue Argentina
Plantas Cerveza Liberación Ciudad del Este
Chile Punta Arenas(1) Finca La Celia Plantas Centros de San Ignacio Misiones Katueté
 Argentina productivas Paraguay
Colombia Sesquille(2) Bodega San Juan distribución Coronel Oviedo I Encarnación
 Coronel Oviedo II
(1) Propiedad de Cervecería Austral S.A.; (2) Propiedad de Zona Franca Central Cervecera S.A.S.; (3) Compañía Cervecerías Unidas Argentina S.A. tiene un 49% de propiedad en Aguas Bolivia Cochabamba
Danone de Argentina S.A.; (4) Compañía Cervecerías Unidas Argentina S.A. tiene un 50% de propiedad en Aguas de Origen S.A.
Memoria Integrada 2024 / 6.4 Propiedades e instalaciones 136

[pág. 138]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
Excelencia operacional
Estándares de operación Los pilares TPM son los siguientes:
Trabajamos en base al criterio de eficiencia operacional, implementando la metodología de Pilar DPO
Mantenimiento Productivo Total (TPM, por sus siglas en inglés), que instala una modalidad orientada Desarrollo de personas y organizaciones.
 CERO BRECHAS EN COMPETENCIAS
a la excelencia en los procesos, cuyos objetivos materializan nuestro Plan Estratégico y la Estrategia Cero personal desmotivado, cero talento sin uso, cero
 Pilar ME
de Sustentabilidad “Juntos por un Mejor Vivir”. fugas de talento y cero logros sin reconocimiento.
 Mejora enfocada.
 CERO DESPERDICIOS
TPM es un sistema de gestión integrado, que contiene un conjunto de herramientas estructuradas Cero pérdidas de tiempo, agua Pilar Seguridad
 y energía, cero faltantes, cero
en pilares, que se ejecutan siguiendo pasos ordenados y coordinados. Su objetivo es resolver cambios en plan de producción CERO ACCIDENTES
 Cero riesgos, accidentes y
problemas en la operación, atacando brechas entre los objetivos y la situación real, priorizándolos y cero desperdicios de recursos.
 conductas inseguras, cero días
de acuerdo con las necesidades y planificación estratégica de nuestra Compañía. pérdidas, cero daño a propiedad y
 cero impacto ambiental.
Como primer fundamento de estos pilares de TPM, el Sistema Conductor soporta los pilares Pilar CA/MA
 Control de activos y Pilar Medioambiente
mediante priorizar, enfocar, planificar y seguir a los equipos de mejora e inversiones necesarias
 Mantenimiento autónomo. CERO IMPACTOS
para llegar a un buen resultado. Este fundamento tiene un indicador principal llamado ICEO (Índice CERO FALLAS DE MÁQUINAS AMBIENTALES
Compuesto de Excelencia Operacional), integrado por los 20 indicadores de Productividad, Eficiencia, Cero pérdidas de eficiencia, cero Cero pérdidas de agua y energía y
 paros externos, cero pérdidas cero emisiones de CO2.
Calidad y medio ambiente. de velocidad, cero repuestos
 obsoletos, cero ajustes y aseos
 fuera de plan y cero anomalías. Pilar Calidad
El segundo fundamento es el desarrollo de Liderazgo y Gestión del cambio cultural que busca TPM, a
 CERO DEFECTOS
través de comunicación, involucramiento y empoderamiento de todas las personas en la Compañía. Cero reclamos, cero pérdidas de productos
 y materiales y cero reprocesos.
Este es un proceso de cambio organizacional y aprendizaje transversal, que genera valor a base de
una cultura de excelencia operacional, lo que conlleva una forma de operar integral y sustentable Adopción de mejores prácticas y/o normas internacionales de operación
en el largo plazo.
 A nivel operativo, un 34% de las plantas productivas y centros de distribución de la Compañía
En este escenario, asociamos objetivos pertinentes a cada uno de los seis pilares, con una evaluación poseen un Sistema de Gestión Ambiental ISO 14001, con certificación vigente.
anual (mediante auditoría) de los elementos clave para una mejora continua.
 Además, la planta en Temuco (cervezas y no alcohólicas) y las plantas en Santiago de Quilicura
 (cervezas), Renca Modelo, Embotelladora CCU Renca (no alcohólicas) y la operación de PLASCO,
 cuentan con una certificación vigente en el Sistema de Gestión de Energía ISO 50001.
Memoria Integrada 2024 / 6.4 Propiedades e instalaciones 137

[pág. 139]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
La gestión ambiental requiere inversiones y gastos para la Compañía necesarios para su operación, Cif ras de certif icación de inocuidad en la región
en particular en la categoría de bebidas no alcohólicas. Destacamos durante el año 2024 el inicio de
la operación de planta CirCCUlar, la primera planta de reciclaje de botella a botella (PET) en Chile, Categorías 2024 2023 2022
la cual se convierte en un importante hito dentro de la infraestructura y capacidades de reciclaje Certificados 30 28 25
de plástico en nuestro país. Sitios(1) totales 34 32 32
 Porcentajes
Otros procesos medioambientales relevantes se asocian a la gestión de residuos industriales Certificación por sitio 88,2% 87,5% 78,1%
líquidos y sólidos, emisiones gaseosas (calibraciones y verificaciones de los instrumentos de control y Certificación/volumen producto 96,0% 95,5% 81,4%
operación de fuentes fijas) y otros recursos vinculados al desempeño normativo, como la verificación
y cumplimiento de los sistemas de gestión ISO 22000, inocuidad de alimentos, ISO 14000, gestión (1) Corresponden a plantas productivas y almacenes de producto terminado.
 (2) No se considera el volumen de plantas Allen (sidra) y Finca La Celia (vinos), en Argentina.
ambiental y OHSAS 18001, de seguridad y salud ocupacional. (3) Durante el año 2024 se incorporó al CCU las operaciones de Aguas de Origen S.A., de los sitios de Villa del Sur y Villavicencio,
 los cuales cuentan y han renovado sus certificaciones de inocuidad alimentaria.
Calidad de productos
La calidad e inocuidad en los procesos, productos y materias constituyen un aspecto fundamental 6.5 Subsidiarias, asociadas e inversiones en
 otras sociedades
para nuestra gestión. En esta materia, contamos con procesos robustos, protocolos de trabajo y
certificaciones internacionales que nos permiten cumplir con los altos estándares de la industria.
En esta línea desarrollamos nuestros productos bajo el Reglamento Sanitario de los Alimentos en
Chile, y cada país se rige bajo la normativa existente y, en casos especiales, se acude a la Universidad
Católica y al Instituto de Nutrición y Tecnología de los Alimentos (INTA).
 6.5.1 Subsidiarias y asociadas
Dentro de las certificaciones con las que contamos destacan:
 Toda esta información se encuentra disponible en el anexo “Filiales y Coligadas 2024”.
 Hazard Analysis and Critical Control Points (HACCP): Análisis de riesgo y puntos críticos de control.
 ISO 22000, FSSC 22000 y BRC (British Retail Consortium): estas se orientan a un debido control de
 procesos para la protección del consumidor, garantizando la inocuidad y seguridad alimentaria 6.5.2 Inversión en otras sociedades
 de los productos elaborados.
 No existen entidades en que se posean inversiones que representen más del 20% del activo total
 de CCU S.A. que no revistan el carácter de subsidiarias o asociadas.
Memoria Integrada 2024 / 6.5 Subsidiarias, asociadas e inversiones en otras sociedades 138

[pág. 140]
Capítulos / 1 2 3 4 5 6 Modelo de negocios 7 8 9 10 11 12
 Participación Total = (Directa + Indirecta)
Estructura 2024 Compañía
 Participación Directa
 Participación Indirecta = (Total - Directa)
 Cervecerías Unidas S.A.
 4,1096% 100,0000%
 Fábrica de Envases
 Plásticos S.A. Millahue S.A. Marzurel S.A.
 95,8904% 99,9991% 99,9773% 99,9773% 0,0000% 100,0000%
 0,1936% 0,1484% 0,9537% 0,0398% 100,0000% 100,0000%
 Cervecera CCU Inversiones Invex CCU Inversiones Viña Altaïr SpA
 Chile Ltda. CCU Dos Ltda. S.A. CRECCU S.A. Milotur S.A.
 99,8064% 100,0000% 99,8516% 100,0000% 99,0242% 99,9776% 99,9602% 100,0000% 0,0000% 85,1506% 0,0000% 100,0000%
 34,0000% 19,3510% 80,6490% 33,3481% 100,0000% 50,0000% 99,8816% 0,1184% 100,0000%
 Compañía
 Compañía Pisquera Cervecerías Unidas Inversiones Invex CirCCUlar SpA Comercial CCU S.A. Finca La Celia S.A. Andrimar S.A.
 de Chile S.A. Argentina S.A. CCU Ltda.
 46,0000% 80,0000% 0,0000% 99,9940% 66,6519% 99,9925% 0,0000% 99,9773% 50,0000% 99,9888% 0,0000% 85,1506% 0,0000% 100,0000%
 2,0000% 21,5033% 78,4967% 1,6274% 0,7028% 0,4756% 50,0000% 100,0000% 51,0166%
 Transportes CCU Compañía Industrial Cervecería 0,0054% Embotelladoras Bebidas
 Ltda. Cervecera S.A. Austral S.A. Chilenas Unidas S.A. CCU-PepsiCo SpA VSPT UK Ltda. AV S.A.
 98,0000% 100,0000% 0,0000% 99,9953% 48,3726% 49,9999% 98,8000% 99,9835% 0,0000% 49,9888% 0,0000% 85,1506% 0,0000% 51,0166%
 49,0000% 1,0000% 98,0000% 1,0000% 85,1697% 100,0000% 57,2158%
 Cervecería Aguas Danone de Comercial La Barra S.A. Viña San Pedro Bebidas del
 Kunstmann S.A. Argentina S.A. Patagona Ltda. Tarapacá S.A. VSPT US LLC Paraguay S.A.
 50,0007% 50,0007% 0,0000% 48,9971% 0,0000% 49,9999% 99,0000% 100,0000% 0,0000% 85,1506% 0,0000% 85,1506% 0,0000% 57,2157%
 49,9999% 50,0001% 50,1000% 50,1000% 100,0000% 100,0000% 1,0000% 99,0000%
 Los Huemules Aguas de Origen Aguas CCU-Nestlé Promarca VSPT Winegroup Sajonia Brewing
 S.R.L. S.A. Chile S.A. Internacional SpA (Shanghai) Limited Company S.A.
 0,0000% 74,9981% 0,0000% 50,0970% 0,0000% 50,0917% 0,0000% 49,9917% 0,0000% 85,1506% 0,0000% 57,1536%
 60,0002% 100,0000% 99,0775% 0,9225% 0,0100% 99,9900% 51,0024%
 Promarca
 Cervecera Inversiones Manantial S.A. Internacional Distribuidora del
 Guayacán SpA Internacionales SpA Paraguay S.R.L. Paraguay S.A.
 0,0000% 30,0005% 0,0000% 80,0000% 0,0000% 50,5520% 0,0000% 49,9917% 0,0000% 51,0024%
 51,0061% 100,0000% 100,0000% 50,0000%
 Cervecería Belga International Spirits Central Cervecera
 Investments USA Bebidas Ecusa SpA
 de la Patagonia S.A. de Colombia S.A.S.
 LLC
 0,0000% 25,5034% 0,0000% 80,0000% 0,0000% 99,9835% 0,0000% 50,0000%
 50,0909% 40,0000% 50,0000% 0,0398% 100,0000%
 Americas Distilling Bebidas CCU Inversiones Artesanos de
 Mahina SpA Investments LLC Carozzi CCU SpA II SpA Cervezas S.A.S.
 0,0000% 25,0458% 0,0000% 32,0000% 0,0000% 49,9917% 99,9602% 100,0000% 0,0000% 50,0000%
 50,1000% 49,9000% 51,0132% 50,0000% 51,0000% 50,0000%
 Volcanes del Sur Promarca S.A. Bebidas Bolivianas Zona Franca Central
 D&D SpA Cervecera S.A.S.
 S.A. BBO S.A.
 0,0000% 74,9503% 0,0000% 40,8106% 0,0000% 49,9917% 0,0000% 51,0000% 0,0000% 50,0000%
 Sociedades subsidiarias nacionales Sociedades subsidiarias extranjeras Sociedades negocios conjuntos extranjeras Sociedades negocios conjuntos nacionales Sociedades operaciones conjuntas Sociedades asociadas extranjeras
Memoria Integrada 2024 / 6.5 Subsidiarias, asociadas e inversiones en otras sociedades 139

[pág. 141]
7
 Capítulos / 1 2 3 4 5 6 7 Gestión de proveedores 8 9 10 11 12
 7.1 Pago a proveedores 141
 7.2 Evaluación de proveedores 142
 propiedad o control 2
 Gestión
 de proveedores
Memoria Integrada 2024 140

[pág. 142]
Capítulos / 1 2 3 4 5 6 7 Gestión de proveedores 8 9 10 11 12
Gestión de proveedores
Los proveedores en CCU son considerados socios estratégicos, siendo fundamentales en el desarrollo
de la operación de la Compañía. Buscamos con ellos establecer relaciones colaborativas y de largo plazo
que nos permitan alcanzar las metas establecidas a nivel estratégico en nuestros tres pilares, crecimiento,
rentabilidad y sustentabilidad. La Gerencia Corporativa de Abastecimiento, que depende de la Gerencia
Corporativa de Administración y Finanzas, es la encargada de establecer las directrices y gestionar las
relaciones con dichos proveedores, buscando a partir de esto aportar al desarrollo de la estrategia de
la Compañía en las dimensiones previamente descritas. En la dimensión de sustentabilidad, buscamos
proveedores con una visión alineada con nuestra Estrategia de Sustentabilidad, permitiéndonos así lograr
las metas relacionadas a las agendas de Vocación Circular, Desafío Climático, Abastecimiento Responsable
y Progreso País.
El compromiso de largo plazo con nuestros proveedores es central para la estrategia de la Compañía.
Vivimos en un mundo integrado, en donde la acción de cada uno impacta directa e individualmente a
todas las personas con las que nos relacionamos.
7.1 Pago a proveedores
Todas las compras de CCU se generan a través de órdenes de compra, las cuáles llegan al proveedor
vía electrónica, las que tienen una serie de términos y condiciones acordadas.
Cabe destacar que, en Chile la Ley N° 21.131 vela por un pago máximo de 30 días a todos los
proveedores, en la cual se establece que, en casos excepcionales, las partes puedan acordar un
plazo que exceda el referido, dejándolo por escrito. Esta excepción no se lleva a cabo por decisión
propia de CCU para proveedores PYME’s. Todo lo anterior aplica para proveedores nacionales, no
distinguiendo entre críticos y no críticos, en tanto proveedores internacionales tendrán los plazos
de pago acordados en la negociación entre las partes.
Memoria Integrada 2024 / 7.1 Pago a proveedores 141

[pág. 143]
Capítulos / 1 2 3 4 5 6 7 Gestión de proveedores 8 9 10 11 12
En virtud de una comunicación transparente con nuestro proveedores, haciendo más eficientes los procesos
e integrando las operaciones que CCU tiene a nivel internacional, cuenta con el Portal de Proveedores
 7.2 Evaluación de proveedores
que permite a nuestros proveedores tener una gestión más eficiente de sus pagos, ya que, además
de encontrar la habitual información referente a sus facturas, también pueden ver si su factura fue Los compromisos con nuestros proveedores abordan la gestión del riesgo en la cadena de
ingresada, fecha de pago programada, información sobre sus pedidos en curso y otras herramientas abastecimiento, a través de este enfoque en el que podemos identificar y evaluar el impacto
pensadas en mejorar la experiencia como proveedor de CCU. El portal ya fue implementado en CCU en nuestro negocio. En CCU contamos con un amplio portafolio de proveedores con los que
en Chile, Argentina, Uruguay y Paraguay. interactuamos regularmente, donde de forma anual, se trabaja con un número relevante de éstos
 para hacer una gestión directa a través de una evaluación de proveedores y de una encuesta de
Por criterio de materialidad, la tabla siguiente resume la información de los proveedores de nuestras satisfacción de proveedores.
operaciones en Chile y Argentina. Se consideran proveedores nacionales, todos aquellos domiciliados
en Chile. Al 31 de diciembre de 2024 no se registraron intereses por mora en los pagos de facturas Respecto a los criterios económico y social, se monitorea su cumplimiento, en base a 4 aspectos:
a proveedores. evaluación tributaria, comercial, financiera y laboral de los proveedores, alertando sobre situaciones
 de riesgo, y permitiendo así gestionar los respectivos planes de mitigación en caso de ser requerido.
 Hasta 30 Entre 31 y 60 Más de 60
 Categorías Total
 días días días En el ámbito de gobernanza, con el objetivo de ir mejorando continuamente la relación con nuestros
Proveedores nacionales proveedores, realizamos anualmente desde el año 2018, una encuesta para conocer su nivel de satisfacción
 como proveedor CCU, verificar el grado de difusión de la Guía de Buenas Prácticas – Proveedor CCU
N° de facturas pagadas(1) 210.096 22.919 11.950 244.965
 (GBP) y consultar sobre su alcance en materia de sustentabilidad. Desde el año 2020 implementamos esta
Total (Millones de CLP)(2) 1.551.780 179.375 101.638 1.832.793 encuesta también para Argentina y a partir del año 2022 se extendió también en Uruguay, Bolivia y Paraguay.
 Esta encuesta, abarca los siguientes temas: transparencia en los procesos de cotización y adjudicación;
N° Proveedores(3) 6.307 1.308 477 6.457
 claridad en las especificaciones técnicas o requisitos de nuestras solicitudes de compra; comunicación
Proveedores internacionales con CCU; cumplimiento de las fechas de pago; y preguntas relacionadas con sustentabilidad. En la
 última medición obtuvimos un 87% de satisfacción de los proveedores encuestados en las distintas
N° de facturas pagadas(1) 29.724 32.486 17.184 79.394
 geografías donde operamos, donde se mantuvo la calificación del año anterior.
Total (Millones de CLP)(2) 278.225 322.406 201.973 802.604
N° Proveedores(3) 2.006 2.409 1.501 3.467
(1) Número de facturas pagadas: el número de facturas pagadas durante el año a proveedores por cada uno de los rangos ya
 señalados.
(2) Monto total: la suma del valor de las facturas pagadas durante el año por cada uno de los rangos ya señalados.
(3) Columna Total no suma el total de proveedores de los rangos indicados ya que un mismo proveedor puede estar en más de
 un rango.
Memoria Integrada 2024 / 7.2 Evaluación de proveedores 142

[pág. 144]
Capítulos / 1 2 3 4 5 6 7 Gestión de proveedores 8 9 10 11 12
Como parte de la evaluación que realiza la Compañía hacia sus proveedores, se realizan auditorías % de proveedores % de compras
 Tipo de proveedores Evaluados totales que totales que
y monitoreos de cumplimento, en función del objetivo de gestionar riesgos específicos de la cadena
 representan representan
de suministro:
 Proveedores internacionales 73 1% 10%
 Auditoría de licencias: realizadas por nuestros socios estratégicos a los proveedores con Proveedores nacionales 1.317 12% 85%
 el fin de certificar el proceso técnico de producción de materias primas y material de empaque.
 Total(1) 1.390 13% 95%
 (1) Se consideran solo segmentos Chile, Vinos y Argentina. 
 Auditorías de desarrollo de nuevos proveedores: aplicadas a potenciales
 proveedores, en el caso que sea un proveedor nacional, o a través de una empresa certificadora,
 en el caso de un proveedor extranjero, con el objetivo de auditar distintos aspectos tales como
 la existencia de la fábrica o empresa, calidad de las instalaciones y condiciones laborales de sus
 trabajadores.
 Vendor Rating System (VRS): indicador de medición cuantitativa del desempeño de los
 productos entregados por parte de los proveedores y considera variables de calidad (número
 de defectos en un periodo esperado, criticidad del defecto y condición de entrega en las
 instalaciones) y el nivel de compromiso del proveedor (gestión de reclamos).
 Control de Contratistas: Este control se aplica a las empresas proveedoras de servicios
 que ingresan a las operaciones de la Compañía. En el caso de Chile, se realiza con el apoyo
 de una empresa externa, encargada de verificar que los proveedores cumplan con las leyes
 sociales/ laborales respecto de sus trabajadores (entre ellas, la Ley de Subcontratación) y que
 éstos estén correctamente habilitados para cumplir sus funciones.
En el año 2024, evaluamos a un total de 1.390 proveedores en nuestros tres segmentos de
operación, lo que representa a un 13% del total de proveedores totales y un 95% de la facturación
del año.
Memoria Integrada 2024 / 7.2 Evaluación de proveedores 143

[pág. 145]
8
 Capítulos / 1 2 3 4 5 6 7 8 Cumplimiento legal y normativo 9 10 11 12
 8.1 En relación con sus clientes 145
 8.2 En relación con sus trabajadores 145
 8.3 Medioambiental 146
 propiedad o control 2
 8.4 Libre competencia 146
 propiedad o control 2
 Cumplimiento
 legal y normativo
Memoria Integrada 2024 144

[pág. 146]
Capítulos / 1 2 3 4 5 6 7 8 Cumplimiento legal y normativo 9 10 11 12
8.1 En relación con sus clientes
En orden de velar por los derechos de los consumidores, en CCU contamos con políticas de control
en materia de publicidad, rotulación e inocuidad alimentaria de nuestros productos, respaldadas
en procedimiento de Manejo de Reclamos Producto Servicio de Atención al Consumidor.
CCU cuenta con una serie de procedimientos en orden a velar adecuada y oportunamente por
los derechos de los consumidores, incluyendo controles en la rotulación, publicidad e inocuidad
alimentaria de sus productos, así como de atención de eventuales reclamos. Durante el año 2024,
la Compañía no registró sanciones por infracción a la Ley N° 19.496, de protección de los derechos
del consumidor. Al mismo tiempo, estamos desarrollando procesos internos para cumplir oportuna
y adecuadamente la ley de protección de datos personales, que entrará en vigencia en diciembre
del año 2026.
8.2 En relación con sus trabajadores
Los trabajadores en CCU son el motor que guía nuestro negocio. Nos enfocamos en su desarrollo
integral durante todo el ciclo laboral, velando por su salud y seguridad, promoviendo su desarrollo
y que vivan los principios corporativos en un ambiente de buen clima organizacional. Tal como
declaramos en nuestra Política Corporativa de Derechos Humanos CCU, para prevenir y detectar
incumplimientos regulatorios referidos a nuestros trabajadores, cumplimos estrictamente con las
leyes y regulaciones aplicables en el ámbito laboral, extendiendo este compromiso hacia nuestros
proveedores, contratistas, socios y aliados estratégicos.
Memoria Integrada 2024 / 8.2 En relación con sus trabajadores 145

[pág. 147]
Capítulos / 1 2 3 4 5 6 7 8 Cumplimiento legal y normativo 9 10 11 12
Además, disponemos un Canal de Denuncias que permite a nuestros trabajadores, así como y actualización de cada matriz por país, con los requisitos normativos y regulatorios aplicables
también a terceros que interactúan con CCU, informar o denunciar: a sus procesos e instalaciones, la realiza una empresa externa especializada en la materia, y
 posteriormente validada por la Subgerencia de Medio Ambiente en Chile.
 Conductas o prácticas cuestionables sobre los principios y valores contenidos en el Código de
 Conducta en los Negocios y en el SER CCU. La Gerencia de Medioambiente Industrial realiza un seguimiento mensual del cumplimiento para
 Actividades no acordes a lo establecido en las normas, políticas contables, control interno y a las definir planes de acción. La Subgerencia de Medio Ambiente (Contraloría) valida el cumplimiento
 materias de auditoría que dicen relación con el examen de los Estados Financieros Consolidados, del área industrial de manera trimestral, actuando como un control adicional.
 conforme con las obligaciones que impone la Ley SOX.
 Incumplimientos a lo establecido en el MPD. Durante el año 2024 no se presentaron multas ni sanciones ambientales en Chile, Bolivia, Paraguay
 Incumplimiento a cualquier legislación vigente en los países donde CCU esté presente. y Uruguay. En Argentina, particularmente en Planta Salta, presentó una multa por la autoridad
 medioambiental. La sanción es debido a los parámetros de vuelco de efluentes. El monto total
Las sanciones ejecutoriadas por multas laborales en este ámbito durante el año 2024 son 17 y anual de la multa aplicada fue de USD 5.416.
ascienden a CLP 24 millones, de acuerdo a lo informado por la Dirección del Trabajo al cierre del año
2024. No existen sentencias ejecutoriadas en el año 2024 que apliquen sanciones que correspondan En relación a programas de cumplimiento ante la Superintendencia de Medio Ambiente (SMA) en
a acciones de tutela. Chile se aprobó el Plan de Cumplimiento de Cervecera CCU Chile Limitada, aprobado con fecha el
 7 de noviembre del 2024 y en periodo de ejecución a agosto del año 2025, donde se debe entregar
 el informe final. El referido plan es referente a no reportar remuestreos en ciertos periodos de
8.3 Medioambiental 2020 -2021 -2022 y superación de dos parámetros según programa de monitoreo.
 Adicionalmente el Plan de Cumplimiento de Cervecería Kunstmann S.A. se encuentra en ejecución
El modelo de cumplimiento medioambiental en CCU está constituido por una matriz de cumplimiento para desde el año 2023. El referido plan se debió a no reportar los monitoreos, frecuencia, y parámetros
cada una de las diferentes unidades de negocio, denominada Índice de Radicación, que contiene los permisos, de sus autocontroles según de su programa de monitoreo.
exigencias ambientales y buenas prácticas de acuerdo con la normativa de cada país en que operamos.
La modalidad de cumplimiento es respaldada a través de la presentación del certificado o resolución
 8.4 Libre competencia
de la autoridad competente en la materia. Dicha documentación debe ser presentada a la Subgerencia
de Medio Ambiente de Contraloría de CCU. CCU cuenta con el Programa de Cumplimiento de Libre Competencia que incluye entre otras,
 capacitaciones tanto por e-learning como de manera presencial, así como la gestión de distintas
Este modelo de cumplimiento se aplica a todas las instalaciones industriales y centros de distribución. políticas y procedimientos, a través de la Gerencia de Cumplimiento. No hemos sido sancionados
En Chile, la responsabilidad directa de elaborar y actualizar la matriz recae en la Subgerencia por conductas atentatorias contra la libre competencia.
de Medio Ambiente. Sin embargo, cada unidad de negocio es responsable de su cumplimiento
medioambiental, supervisados por la Gerencia de Medioambiente Industrial (2024) quienes diseñan, En lo que respecta a los riesgos de libre competencia éstos están asociados principalmente a la
mejoran y monitorean estándares y controles que aseguran internamente el cumplimiento. En el posibilidad del ejercicio de conductas exclusorias en mercados en que existe un actor que detenta
caso de los demás países donde operamos, Argentina, Bolivia, Paraguay y Uruguay, la elaboración posición dominante.
Memoria Integrada 2024 / 8.4 Libre competencia 146

[pág. 148]
9
 Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 9.1 Estrategia de Sustentabilidad 148
 Gobernanza de Sustentabilidad 149
 20 metas al año 2030 150
 Equilibrio Hídrico 152
 Vocación Circular 154
 Desafío Climático 156
 Abastecimiento Responsable 159
 Experiencia SER CCU 160
 Pasión por el Consumidor 161
 Disfrute Consciente 163
 Progreso País 166
 9.2 Métricas SASB 171
 Sustentabilidad 9.3 Verificación independiente 174
Memoria Integrada 2024 147

[pág. 149]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
9.1 Estrategia de Sustentabilidad
La Sustentabilidad está definida como uno de los tres pilares estratégicos de la Compañía, junto
con Rentabilidad y Crecimiento. Estos pilares reconocen la importancia de desarrollar nuestro
 S T R O PLAN
negocio y trabajo con una mirada sostenible y balanceada entre el corto y largo plazo, teniendo E E
siempre en consideración el bienestar actual y futuro de todas las personas con las que la NU TA
Compañía interactúa, el cuidado del medioambiente y el desarrollo de sus marcas. ÁTICO AB
 IM AS
 CL TE
A fines del año 2023 anunciamos una actualización de nuestro Modelo de Sustentabilidad volcando F ÍO O VOCAC C
 A RIC I ÓN
nuestra visión hacia una Estrategia de Sustentabilidad que llamamos, “Juntos por un Mejor Vivir”, ÍD
 IM
 CI
 S
 H
 DE
 R
 IE
la cual, durante el año 2024, tuvo su primer año de puesta en marcha e implementación en línea O
 NT
 I
 CU
 BR
con el camino iniciado el año 2010 a través de nuestra Visión Medioambiental y determinados
 OR
 LA
 ILI
Objetivos de Desarrollo Sostenible (ODS). Nuestra estrategia fue diseñada atendiendo todos los
 R
 ES P
 E QU
desafíos, impactos y oportunidades relativos a nuestro negocio y cadena de valor, lo que nos
ha permitido continuar avanzando en las temáticas esenciales asociadas a nuestra industria en
 ONSA B L E
 UMIDOR
profunda conexión con nuestro entorno y contexto.
 EXPER
 DISFR
Los avances de las 20 metas al año 2030 de la Estrategia de Sustentabilidad han sido verificados
de manera independiente, permitiéndonos contar con valores confiables y trazables.
 NS
 2030
 UT
 IEN
 CO
 EC
 CI
 SE E
 L
 A
 O
 R O R
 N
 ÍS
 CC P
 SC
 IE U N P
 A
 N PA S I Ó O
 TE S
 R E
 O G
 N P R S
 UE A
 STR O N
 Los ODS son un conjunto de 17 objetivos globales adoptados por AS PE R S
 la Asamblea General de las Naciones Unidas en 2015, nuestra
 Estrategia de Sustentabilidad “Juntos por un Mejor Vivir”
 trabaja en 7 de ellos.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad 148

[pág. 150]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 Gobernanza de Sustentabilidad
 O PLAN
 EST R ET
 NU A
 TICO AB
 I MÁ AS
 CL TE
 O
 1
 FÍ ICO
 VOCAC
 I ÓN
 C
 A
 DR
 HÍ
 IM
 CI
 S
 DE
 R
 IE
 O
 NT
 I
 CU
 BR
 OR
 LA
 ILI
 CCU cuenta con un Comité de Sustentabilidad, órgano de gobernanza que dirige y articula
 R
 ES P
 E QU
 ONSA B L E
 Visión
 UMIDOR
 transversalmente todas las agendas de la Estrategia de Sustentabilidad, el cual es presidido por la
 EXPER
 DISFR
 NS
 2030
 UT
 IEN
 Gerente de Asuntos Corporativos y Sustentabilidad y cuyo vicepresidente es el Contralor General,
 CO
 EC
 CI
 SE E
 L
 A
 O
 R O R
 N
 ÍS
 CC N P
 SC
 IE
 además de contar con la participación del Gerente General y el Gerente Corporativo de Administración
 U P
 A
 N PA S I Ó O
 TE
 ES
 2
 R
 OG
 N PR S
 UE A
 N
 STR
 AS PE RSO y Finanzas, entre otros miembros. El Comité de Sustentabilidad sesiona en forma trimestral y es, en esta
 instancia, donde se revisan los avances, se explican las brechas y se comunican los planes de acción,
 Ejes
 Planeta Personas velando por apoyar la gestión y cumplimiento de la Estrategia de Sustentabilidad.
 Equilibrio Hídrico Experiencia SER CCU
 8 Cada una de las ocho agendas de trabajo está liderada por un Gerente del Comité de Dirección, quien
 participa en el Comité de Sustentabilidad y que da cuenta de los avances de cada agenda. Además, el
 Agendas
 Vocación Circular Pasión por el consumidor de trabajo Comité cuenta con un panel de apoyo en diferentes temáticas que enriquecen la discusión y permite
 anticiparnos a situaciones futuras.
 Desaf ío Climático Disfrute Consciente
 Abastecimiento Responsable Progreso País Lideran el Comité de Sustentabilidad junto con
 20
 Directores Comité Sustentabilidad
 apoyar y supervisar el cumplimiento de metas
 10 10
 Metas
 Metas Metas 2030
 Planeta Personas Facilitadores UEN
 Velan por la asignación y control de recursos
 alineados a las metas de su unidad de negocio
 Iniciativas anuales Sponsors Lideran y reportan las agendas de trabajo
 Expertos técnicos Asesoran el desarrollo técnico y cumplimiento
 Nuestro Planeta regulatorio de nuestras agendas de trabajo y metas
Dicha Estrategia se compone de dos ejes, Planeta y Personas, estando cada eje compuesto
por cuatro agendas de trabajo. Estas agendas conforman las 20 Metas al año 2030, las cuales Dentro de este foro y contexto, el Comité de Sustentabilidad ha definido como parte del proceso de
cuentan con el apoyo de múltiples y significativas iniciativas anuales que nos permiten avanzar en gestión de la Estrategia de Sustentabilidad “Juntos por un Mejor Vivir”, realizar una revisión de nuestros
nuestros compromisos declarados. Durante el año 2024, implementamos más de 160 iniciativas avances y prioridades en el punto medio de esta década, esto es en el año 2025, incorporando rangos
conducidas a través de nuestras ocho agendas de trabajo. desafiantes a las cifras a las que aspiramos en nuestras 20 Metas al año 2030, lo que se publicará en
 la próxima Memoria Integrada 2025.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad 149

[pág. 151]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
20 metas al año 2030
Eje Planeta Eje Personas
 Equilibrio Hídrico Vocación Circular Experiencia SER CCU Pasión por el Consumidor
 CERO
 Residuos industriales a relleno
 60% sanitario Certificar a CCU como un Crecimiento sostenido de la preferencia
 Reducción consumo de agua industrial .
 empleador de excelencia de nuestras marcas
 (2,08 hl/hl)(*)
 100%
 Materiales de envases y embalajes
 reciclables, reutilizables o
 1 compostables Mantener un clima laboral 25
 Iniciativa anual de reposición
 hídrica en zonas prioritarias de CCU
 50% saludable (IGC: >=85%) Iniciativas aceleradoras anuales para
 “Juntos por un Mejor Vivir”
 Contenido promedio de material
 reciclado en envases y embalajes
 +400 ton
 PET recuperado (**) anualmente a través
 de CCU y sus marcas comerciales
 Desafío Climático Abastecimiento Responsable Disfrute Consciente Progreso País
 50% 50% 100%
 Reducción de emisiones en Materias primas estratégicas (***)
 100% Planes Comunitarios en territorios
 estratégicos
 Alcances 1 y 2 (4,4 kg. CO2e/hl)(*) provenientes de agricultura certificada Implementación de Programa CRÁ
 (Consumidor Responsable de Alcohol)
 30.000
 75% Clientes impactados por medio de
 Utilización de energía eléctrica 100% programas de capacitaciones y/o
 financiamiento
 renovable Implementación Programa
 Vivamos Bien-Vida Sana
 Apertura nacional Museo Cervecero
 20% Limache
 Disminución de emisiones en logística
 90%
(*) En base a valores 2010. Proveedores significativos adheridos a
(**) Cifra adicional a la exigencia Ley REP/PUSU. Guía de Buenas Prácticas (GBP)
(***) Cebada, lúpulo y azúcar.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad 150

[pág. 152]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 Eje Planeta
 La gestión de cumplimiento ambiental se basa en identificar y monitorear los indicadores claves con
 metas específicas, donde contamos con un plan que establece nuestra hoja de ruta a corto, medio
 y largo plazo, por medio de la supervisión de los procesos para validar los resultados en relación
 con los estándares, sistemas de gestión, objetivos y metas establecidos. Adicionalmente, buscamos
 O PLAN constantemente la implementación de los estándares y sistemas de gestión que contribuyan a la
 E ST R ET
 N U A eficiencia y efectividad en el desempeño medioambiental, conforme a las mejores prácticas. Ejemplo
 ÁTICO AB de esto son las normas ISO y Metodología TPM, por sus siglas en inglés “Total Productive Maintenance”.
 IM AS
 CL TE ( Ver sección “6.4 Propiedades e Instalaciones”).
 O
 FÍ O VOCAC C
 A
 D RIC I ÓN
 HÍ
 IM
 CI
 S
 DE R
 IE
 O La Compañía destinó durante el año 2024 un total de CLP 65.402 millones, CLP 46.287 millones para
 NT
 I
 CU
 BR proyectos de inversión y CLP 19.115 millones en gastos ambientales. Esto significó un aumento de un
 OR
 LA
 ILI
 R
 ES P
 48% y un 16% adicionales respecto al periodo anterior, respectivamente.
 E QU
 ONSA B L E
 UMIDOR
 Dentro de este contexto, es importante mencionar que las operaciones, para el año 2025 proyecta
 EXPER
 DISFR
 un gasto en torno a CLP 13 mil millones, por la entrada en operación de CirCCUlar y se mantiene el
 gasto asociado al sistema de recolección de envases y embalajes, ReSimple, por un monto cercano
 NS
 2030
 UT
 IEN
 CO
 a CLP 5 mil millones.
 EC
 CI
 SE E
 L
 A
 O
 R OR
 N
 ÍS
 CC N P
 SC
 IE U P
 A
 N PA S I Ó Mediante el eje Nuestro Planeta, priorizamos y gestionamos con excelencia nuestros principales desafíos
 TE
 E SO
 OG
 R ambientales a través de cuatro agendas de trabajo definidas como: Equilibrio Hídrico, Vocación Circular,
 N PR S
 UE
 STR O NA Desafío Climático y Abastecimiento Responsable.
 AS PERS
 Política de Medio Los lineamientos que se presentan son:
 Ambiente CCU
 Cumplimiento normativo
En CCU entendemos la relevancia de operar nuestro negocio con responsabilidad ambiental y por Cumplimiento ambiental
 Nos entrega lineamientos, a nivel Gestión de riesgos
lo mismo, estamos comprometidos con el cuidado del medioambiente, alineados a los desafíos
 regional, para desarrollar y promover, Educación y sensibilización
y prioridades de nuestro entorno y sostenibilidad organizacional. Velamos por el uso eficiente y entre nuestros grupos de interés Colaboración y compromiso
responsable de los recursos naturales, buscando constantemente de la mano de la innovación, internos y externos, una cultura Transparencia y reportabilidad
tecnología, aplicación de altos estándares de gestión y desarrollo de nuevas capacidades, nuevas orientada a minimizar los impactos
alternativas que nos permitan reducir nuestros impactos y adaptarnos de manera ágil y eficiente a medioambientales en el ciclo de vida De esta manera, gestionamos el conjunto de indicadores establecidos
 para cumplir con las exigencias regulatorias, contamos con una
nuevas exigencias regulatorias y del entorno. de nuestros procesos y productos. identificación temprana de riesgos, trabajamos en fortalecer nuestra
 cultura ambiental, colaboramos con nuestros grupos de interés y
 aseguramos la veracidad de nuestra información reportada.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad 151

[pág. 153]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
Avances de nuestro desempeño A continuación, se muestra un esquema que explica la extracción, uso y reposición del agua durante
 el año 2024:
 Fuentes de obtención de agua
 Equilibrio Hídrico 8.519.827 m3
El agua es un componente esencial para la vida humana y los ecosistemas. Es por esto que nuestra
preocupación por el recurso hídrico no sólo radica en la necesidad de este elemento para nuestras
 Red de agua Pozos Aguas
operaciones, sino también en su disponibilidad para el consumo humano y ecosistemas que conviven 14% potable
 79% profundos
 7% superficiales
en los territorios donde estamos presentes.
 Canales y
 manantiales
Frente a este contexto, por medio de esta agenda de trabajo, CCU impulsa una gestión basada en la
 60,72% Agua extraída en regiones con un estrés hídrico(1)
excelencia y responsabilidad hídrica a través de dos metas:
 ¿En qué usamos el agua?
 Reducir un 60% nuestro consumo de agua industrial (Base 2010).
 Implementar al menos una iniciativa anual de reposición hídrica en zonas prioritarias de CCU.
 Reducir un 60% nuestro Descarga de
 7% 93% 37%
 META 1 consumo de agua industrial
 Avance
 2024
 48,6% (2,67 hl/hl) aguas servidas
 0,58 millones m3
 Servicios Elaboración
 (2,08 hl/hl)
 Producto
 terminado(2)
Este indicador relaciona la cantidad de agua utilizada en el proceso productivo con la producción.
 Descarga de RILes
Al cierre de año se alcanzó un valor de 2,67 hectolitros de agua utilizada por cada hectolitro
producido, lo que se traduce en un 48,6% de reducción en base al indicador del 2010, año donde 4,01 millones m3
comenzó este desafío.
 Redes de Cursos Uso interno
 40% alcantarillado 57% superficiales 3% calidad de
 Política Hídrica CCU Los lineamientos que se presentan son: de empresas de agua riego
 sanitarias
 Cumplimiento normativo
 Nos entrega los lineamientos en torno Cumplimiento ambiental Total de agua consumida
 a la gestión de este recurso, buscando Gestión de riesgos
 Educación y sensibilización 4.436.373 m3
 velar por el consumo responsable y
 eficiente del agua, todo ello en línea con Colaboración y compromiso 50,27% Agua consumida en regiones con un estrés hídrico(1)
 el estricto cumplimiento normativo. Transparencia y reportabilidad
 (1) Regiones con un estrés hídrico alto o extremadamente alto, de acuerdo a la herramienta Aqueduct.
 (2) Producto terminado elaborado con el 37% del total del agua obtenida.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Equilibrio Hídrico 152

[pág. 154]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
El porcentaje de reducción señalado se logró mediante un continuo plan de eficiencias, en todas nuestras 1 Primer fondo hídrico CCU
operaciones. En esta tarea, aplicamos sistemas de optimización continua y las mejores tecnologías y
prácticas disponibles, donde durante el año 2024 se llevaron a cabo proyectos específicos y se continuó Iniciativa
 A través de una alianza con Compañía Pisquera de
implementando la herramienta UBM (Utilities Benchmark Model) que permite identificar con mayor META 2 Chile y Cooperativa de Control Pisquero, realizamos el
precisión brechas y oportunidades de reducciones hídricas, en base a experiencias internacionales, Primer Fondo Concursable para impulsar la ejecución
alcanzables con ajustes operacionales. de proyectos eficientes en el uso de agua de cooperados
 de la región de Coquimbo en sus predios. Mediante
El agua residual de las plantas industriales es descargada al alcantarillado, a cursos de aguas superficiales ayuda económica y técnica, 15 ganadores implementaron
o se utiliza en algunos casos para riego interno, según resolución o permiso de cada instalación. Las proyectos que les permiten utilizar de forma más eficiente
instalaciones que cuentan con un sistema de tratamiento propio poseen monitoreos y controles el recurso hídrico, dando continuidad a sus cultivos de uva
periódicos que permiten descargar el residuo líquido tratado según normativa ambiental vigente. pisquera, introduciendo técnicas como el riego por goteo,
 la impermeabilización de tranques, instalación de filtros de
 arena de cuarzo y renovación de tuberías, entre otras.
 Implementar al menos una iniciativa
 META 2 anual de reposición hídrica en zonas
 Avance
 2024
 2 Iniciativas Puntos de agua purificada en Monte Patria
 prioritarias 2
 Iniciativa
 Iniciativa desarrollada por CCU y ejecutada por FreshWater,
Esta meta tiene por objetivo contribuir a la seguridad hídrica a través de proyectos que fortalezcan META 2 para facilitar el acceso a agua a 200 niños en las salas cuna
el acceso y calidad del agua de las personas, en sintonía con nuestros entornos inmediatos, además y jardines infantiles San Martín de Porres y Pampanito, de
de impulsar el cuidado de los acuíferos, crear conciencia, valoración y eficiencia en la utilización del la Fundación Integra en Monte Patria, región de Coquimbo,
recurso hídrico. por medio de la instalación de puntos de agua purificada.
 Estos dispositivos tienen la capacidad de entregar hasta 12
Con la puesta en marcha de “Juntos por un Mejor Vivir” nos comprometimos a implementar anualmente litros de agua al día, la cual se obtiene del aire mediante
al menos una iniciativa hídrica con impacto ambiental y/o social en nuestras zonas prioritarias. Estas un sistema que captura por condensación de partículas
zonas son actualizadas anualmente, tomando en consideración el contexto actual en equilibrio con de agua, con un sistema de purificación incorporado,
una mirada de largo plazo. Además, anualmente se monitorea la disponibilidad hídrica en todas las entregando agua lista para ser consumida.
instalaciones de la Compañía, con especial foco en aquellas ubicadas en zonas de escasez hídrica
declaradas por la autoridad local. En el caso de Chile, estas zonas son establecidas por la Dirección Porcentaje de estrés hídrico(1)
General de Aguas (DGA) del Ministerio de Obras Públicas.
 Extremadamente alto (>80%) Medio alto (20 - 40%)
En el mapa a continuación, se presenta el porcentaje de estrés hídrico de las zonas donde se encuentran Alto (40 - 80%) Medio bajo (10 - 20%)
ubicadas las plantas productivas de CCU.
 Bajo (<10%)
 (1) Fuente: WRI - Aqueduct Water Risk Atlas.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Equilibrio Hídrico 153

[pág. 155]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 Vocación Circular
Esta agenda de trabajo nos permite gestionar los temas asociados a la economía circular, un reto global La valorización de residuos ha permitido también generar cultura medioambiental en los trabajadores,
que se considera una herramienta imprescindible para lograr un uso responsable de los recursos quienes aportan ideas y han sido parte crucial del proceso de optimización continua.
materiales, maximizando la valorización y disminución en la generación de residuos. CCU define la
gestión responsable de residuos como una tarea clave en la que deben participar y colaborar todas El total de residuos de la Compañía, entre residuos peligrosos y no peligrosos, fue de 304.978
las personas involucradas y así generar una visión conjunta, de manera de contribuir a la educación en toneladas (ton) en el año 2024. Los residuos sólidos industriales generados cada año en las
toda la cadena de valor. CCU se enfoca en ser líder en economía circular, por medio de cuatro metas: operaciones corresponden, principalmente, a residuos no peligrosos (99,90%).
 Cero residuos industriales a relleno sanitario
 Contar con un 100% de envases y embalajes reutilizables, reciclables o compostables
 Contar con un 50% contenido promedio de material reciclado en envases y embalajes
 Recuperar 400 toneladas de PET anualmente a través de CCU y sus marcas comerciales Ingreso de
 materias Procesos Residuos
 Productos Comercialización Envases y
 primas y productivos
 materiales de Embalajes
 CERO residuos industriales a relleno posconsumo
META 3 sanitario
 Avance
 2024
 0,6% fabricación
 100% Valorización de Residuos Industriales a relleno sanitario
Dentro de los compromisos y grandes desafíos de “Juntos por un Mejor Vivir”, está evitar el envío
 Residuos Residuos
de residuos a relleno sanitario, y lograr valorizar el 100% de los residuos industriales. No Peligrosos(1) Peligrosos(2)
 (304.658 ton) (312 ton)
 Residuos Residuos No
 Valorizados
 99,4% Valorizados 0,6%
 Residuos
 Residuos Residuos Residuos Residuos no
 Asimilables a
 compostables reciclables reutilizables Segregables
 302.892 ton 2.086 ton Domésticos
 (31.780 ton) (41.809 ton) (218.243 ton) (10.802 ton)
 (2.023 ton)
Para lograr este alto porcentaje de valorización, los residuos como vidrios, papeles, cartones, aluminio,
entre otros materiales son entregados clasificadamente a terceros para su reciclaje. Además, con
 (1) Son aquellos que no presentan características que los hagan peligrosos para la salud humana o el medio ambiente. En esta
la puesta en marcha de la Planta de Reciclaje CirCCUlar, los residuos y mermas de PET de nuestras categoría tenemos residuos orgánicos, reciclables, reutilizables, no reciclables/no segregables y asimilables a domésticos.
operaciones, son enviados para ser clasificados y producir resina reciclada, que será utilizada (2) Se refiere a un desecho considerado peligroso por tener propiedades intrínsecas que presentan riesgos en la salud. Estos
 residuos suelen contener sustancias tóxicas, corrosivas, inflamables, entre otras, que pueden causar daños si no se gestionan
posteriormente en nuestros envases, haciendo realidad la economía circular del PET. adecuadamente.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Vocación Circular 154

[pág. 156]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 Dentro de los materiales de envases más utilizados, el volumen y contenido porcentual de material
 META 4
 Contar con un 100% de envases y embalajes
 reutilizables, reciclables o compostables
 Avance
 2024
 99,95% reciclado utilizado en el año 2024, se presenta a continuación:
 en Chile
 64% 55% 32% 0,1%
Para CCU, y como base de la economía circular, es fundamental contar con envases y embalajes con
materiales que se puedan mantener más tiempo en ciclos productivos, es decir, maximizar su uso y
minimizar la generación de residuos.
 Madera/Fibra Metal Vidrio Plástico (1)
 de papel (aluminio o acero) 140.539 ton 38.265 ton
Para el cumplimiento de esta meta, se evalúa la materialidad de los componentes de cada SKU y la 15.046 ton 23.343 ton
factibilidad que el mercado local pueda reutilizar, reciclar o compostar, acompañado de la documentación
entregada por los proveedores de cada material que respaldan la composición de los mismos.
 Sello Elijo Reciclar
 Inicio de operación de la Planta de reciclaje CirCCUlar dio comienzo a la
 Con el objetivo de entregar información clara a los consumidores y fomentar incorporación de material reciclado en nuestros envases plásticos.
 la cultura del reciclaje, CCU es parte del Acuerdo de Producción Limpia de Eco-
 Etiquetado, liderado por la Sociedad de Fomento Fabril, el Ministerio del Medio
 Ambiente y la Agencia de Sustentabilidad y Cambio Climático. Actualmente,
 345 productos de la Compañía cuentan con el sello #ElijoReciclar, el cual
 certifica que al menos un 80% del peso del envase está confeccionado con
 materiales reciclables; que los materiales pueden ser separados del resto del Desafío CirCCUlar, fondo concursable impulsado por CCU y Desafío
 envase para su reciclaje y que existe una demanda de la industria del reciclaje Levantemos Chile. En la primera etapa, se seleccionaron a emprendimientos
 por esos materiales. de más 60 recicladores de la Región Metropolitana y de Valparaíso.
 META 5
 Incorporar un 50% de material reciclado
 promedio en envases y embalajes
 Avance
 2024
 30,7%
 en Chile Primera botella con plástico reciclado en Chile, Cachantun a través de la
 campaña comercial #RevoluciónNatural busca ampliar y fomentar la cultura
Parte del compromiso de la agenda es la incorporación paulatina de material reciclado en nuestros de reciclaje de los consumidores.
envases y embalajes. Desarrollamos un trabajo en conjunto con nuestros proveedores para contar
con materias primas con un mayor porcentaje de material no virgen y su adecuada acreditación.
 (1) Corresponde a la fracción de botellones de Manantial y al inicio de operación de Planta de Reciclaje CirCCUlar.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Vocación Circular 155

[pág. 157]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 Recuperar 400 toneladas de PET
 META 6 anualmente a través de CCU y sus
 Avance
 2024
 386 toneladas Desaf ío Climático
 marcas comerciales recuperadas
 En línea con los desafíos globales de la mitigación del cambio climático, la Compañía publicó el año
 2010 su primer compromiso de reducción de emisiones en Alcances 1 y 2, teniendo grandes avances
Para contribuir a la cultura de reciclaje de la ciudadanía, nos hemos propuesto recuperar plástico PET a la fecha. CCU continúa trabajando en la descarbonización de toda su cadena de valor, por medio de
a través de campañas o acciones desarrolladas por CCU y/o sus marcas comerciales. Esta meta refleja tres metas:
el compromiso de CCU con la economía circular y la reducción del impacto ambiental mediante el
reciclaje y la reutilización de plásticos. Reducir un 50% las emisiones GEI en Alcances 1 y 2 (Base 2010)
 Utilizar un 75% de energía eléctrica renovable
 ReCCUpero, programa de CCU Argentina enfocado en el rescate, valorización y Disminuir un 20% las emisiones GEI en logística
 256 reinserción de materiales post-consumo, que reúne los esfuerzos de organizaciones
 no gubernamentales (ONGs), municipios, cooperativas, emprendedores gastronómicos,
 Reducir un 50% las emisiones
 grandes eventos, empresas de impacto y consumidores para que todos los empaques
 toneladas
 vuelvan al ciclo productivo.
 META 7 GEI en Alcances 1 y 2
 Avance
 2024
 64,1% (3,17 kg CO e/hl)
 2
recuperadas (4,41 kg CO2e/hl)
 Familias Reciclando en #ModoBilzYPap, donde miles de familias se sumaron a la
 130 novena edición de la cruzada de reciclaje más grande de Chile, recolectando y llevando CCU cuenta con un indicador de reducción de emisiones en Alcances 1 y 2, el cual obtuvo un valor de
 botellas PET a los más de 500 puntos limpios habilitados de Arica a Magallanes. Esta 64% de reducción en base al indicador del año 2010, lo que corresponde a 3,17 kg CO2 equivalente
 iniciativa fue impulsada por Bilz y Pap, Teletón y el Ministerio del Medio Ambiente, junto (CO2e) por hectolitro producido, superando en un 28% la actual meta de la Compañía.
 toneladas
recuperadas al apoyo de 130 municipalidades a lo largo de todo Chile, logrando incentivar la cultura
 de reciclaje y compromiso durante la Teletón. Las emisiones de CCU son gestionadas por medio de la Huella de Carbono CCU, la cual considera un
 inventario de las emisiones en Alcances 1 y 2. Para el año 2024, los resultados fueron los siguientes:
 ALCANCE 1 ALCANCE 2
 Emisiones directas Emisiones indirectas
 (instalaciones de la Compañía) (energía eléctrica adquirida)
 79.853 21.765
 toneladas CO2e toneladas CO2e
 Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Desafío Climático 156

[pág. 158]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
Cada una de las plantas productivas y centros de distribución reportan la información necesaria para
calcular sus emisiones directas e indirectas de forma mensual a través de esta herramienta corporativa.
Para esto, las instalaciones gestionan sus emisiones de Alcances 1 y 2 por medio de la eficiencia de Emisiones de sustancias que agotan el ozono
procesos productivos, sistemas de medición más rigurosos, renovación de tecnología, materialización de Las emisiones de la Compañía de sustancias que tienen el potencial de agotar la
proyectos específicos e implementación de sistemas de gestión de energía, como ISO 50.001. capa de ozono no son significativas. En el año 2024 alcanzaron un valor de 0,02
 toneladas, métrica de CFC-11 (clorofluorocarbono) equivalente, correspondiendo
Para calcular la reducción de emisiones, se tomó el 2010 como año base debido a que fue el primero a emisiones fugitivas de gases de tipo HCFC (Hidroclorofluorocarbonos) y HFC
con una contabilización formal de las emisiones GEI por medio de una herramienta desarrollada (Hidrofluorocarbonos), que son compuestos utilizados en los equipos de refrigeración
para CCU, basada en el estándar del GHG Protocol (Tool for Stationary Combustion) y validada por y climatización de las plantas productivas y oficinas de CCU a nivel regional.
una tercera parte. Este proceso de validación de indicadores ambientales se realiza de forma anual
con verificadores externos. Gestión eficiente de la energía
 El consumo de energía térmica directa de la Compañía proveniente de fuentes no
Los factores de emisión provienen principalmente de fuentes tales como IPCC (Guidelines for National renovables fue 1.158.440 gigajulios (GJ) en el año 2024, lo que corresponde a un
Greenhouse Gas Inventories, 2006), GHG Protocol y Guidelines to Defra (DECC’s GHG Conversion Factors 3,4% menor al consumo del año anterior. La matriz de consumo de combustibles
for Company Reporting), entre otras. La consolidación de los indicadores ambientales expresados fósiles (no renovables) se compone principalmente de gas natural, considerada
como intensidad, incluidos los gases de efecto invernadero, se efectúa por control operacional en la mejor opción por sus menores emisiones locales en comparación con otras
función de los volúmenes de producción. alternativas de combustibles como gas licuado, gasolina, petróleo y diésel.
Comparado en base al año 2010, en el año 2024 la Compañía evitó emitir 114.572 toneladas de CO2e El consumo de energía térmica de fuentes renovables en el año 2024 fue de 60.920
de acuerdo a la metodología Business As Usual (BAU), considerando los Alcances 1 y 2. GJ, provenientes de la generación de biogás de las plantas Santiago - Quilicura y
 Temuco, en Chile, y Santa Fe en Argentina.
 Emisiones derivadas de combustibles fósiles
 A través la cuantificación volumétrica de todos los combustibles fósiles utilizados por
 la Compañía y considerando los factores estipulados en el manual de estimación de
 emisiones atmosféricas del sistema RUEA (Registro Único de Emisiones Atmosféricas
 del Ministerio de Medio Ambiente de Chile) tenemos que, las emisiones derivadas
 de la combustión de los combustibles fósiles, respecto al año 2023, de dióxido de
 azufre (SOx), óxido de nitrógeno (NOx), material particulado (MP) y compuestos
 orgánicos volátiles (COV), disminuyeron en 24%, 20%, 22% y 19%, respectivamente.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Desafío Climático 157

[pág. 159]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
Consumo energético dentro de la organización Incorporación de grúas eléctricas
Distribución de consumo de energía térmica en el año 2024: En el centro de distribución de Coquimbo y en la Planta Santiago - Quilicura,
 disminuyendo no solo las emisiones GEI, sino también ruido en la operación,
 mejorando las condiciones de trabajo en nuestras instalaciones.
 82,7% 9,2% 2,3% 0,7% 0,1% 2,8% 2,2%
Gas Natural Gas Licuado Diésel Petróleo Gasolina Biogás Leña
 Domotización en el centro de distribución de Renca
 Fuentes No Renovables Fuentes Renovables
 Iniciativa piloto de eficiencia lumínica, que continúa impulsando el ahorro
La Compañía también genera electricidad renovable propia a partir de biogás y paneles fotovoltaicos, energético de nuestras instalaciones.
durante el año 2024 produjo 34.390 GJ. Así, el consumo total de energía directa e indirecta (de
fuentes no renovables y renovables) para el año 2024 fue de 2.152.381 GJ, siendo un 0,3% menor
que el año anterior.
Reducción de consumo de energía
 Utilizar un 75% de Energía Eléctrica
En el año 2024, CCU evitó consumir 144.169 GJ, comparado con el año 2010, según la metodología META 8
 Renovable (EER)
 Avance
 2024
 84%
BAU. La disminución se explica por una mayor eficiencia en los procesos productivos, renovación
tecnológica y proyectos específicos. Las principales iniciativas relacionadas con la reducción de
consumo de energía son: Las instalaciones de CCU en Chile se abastecen de energía eléctrica proveniente de los distribuidores
 del Sistema Eléctrico Nacional (SEN), Sistema Eléctrico de Aysén (SEA) y Sistema Eléctrico de
 Fortalecimiento de la gestión energética mediante la metodología TPM. Magallanes (SEM). Para el caso de las operaciones regionales, Argentina, Bolivia, Paraguay y Uruguay,
 • Revisión y expansión de buenas prácticas específicas para reducir el consumo de energía a nivel la energía proviene de sus respectivas matrices energéticas.
 regional.
 • Aumento en la recuperación de condensado durante los procesos de elaboración y envasado, y Desde el año 2023, en Chile contamos con un contrato de abastecimiento de energía eléctrica
 en la eficiencia del uso de equipos de aireación en plantas de tratamiento de residuos industriales renovable con la empresa Colbún, el cual nos permite abastecer con energía eléctrica renovable
 líquidos. durante ocho años a nuestras plantas productivas y centros de distribución. Este contrato de
 suministro de energía permitió a CCU evitar la emisión de cerca de 32.179 toneladas de CO2 al año.
 Esta gestión nos permitió avanzar en el indicador de uso de energía eléctrica renovable, alcanzando
 un 84% en el año 2024, superando en un 12% la meta actual de la Compañía.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Desafío Climático 158

[pág. 160]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 META 9
 Disminuir un 20% las emisiones GEI
 en logística (Alcance 3)
 Abastecimiento responsable
 La Compañía vela por un abastecimiento responsable de toda su cadena de suministro, con énfasis
Durante el año 2024, hemos continuado con la gestión de emisiones en la operación logística de en impulsar prácticas agrícolas sostenibles, por medio de una meta, la cual corresponde a alcanzar un
CCU, donde el objetivo es contar con la línea base de emisiones logísticas verificada el año 2025. 50% de materias primas estratégicas provenientes de agricultura certificada.
Transportes CCU cuenta con un plan para el cumplimiento de esta meta que considera la disminución
de emisiones en distribución primaria (Acarreo) y secundaria (Porteo), a través de:
 Alcanzar un 50% de materias primas
Focalizar Excelencia Operacional en procesos de Porteo y Acarreo: se encuentran en marcha META 10 estratégicas provenientes de agricultura
 Avance
 2024
 29,3%
distintas iniciativas que buscan aumentar la productividad y la eficiencia mediante sistemas de rutas certificada
inteligentes para asegurar rutas más eficientes que optimicen la capacidad de carga de nuestros
camiones en cada viaje.
 La elaboración de nuestros productos se realiza con materias primas de calidad, donde, además, para
Medir y hacer gestión de conducción a las tripulaciones: se implementarán sistemas de telemetría agregar valor compartido para las personas y el planeta, hemos incorporado la meta de contar con
que nos permitirán monitorear, gestionar y controlar los kilómetros de cada ruta, logrando planificar materias primas estratégicas provenientes de agricultura certificada. Este tipo de certificación fomenta
mejores rutas y vincular los incentivos a las decisiones de conducción (velocidad, aceleración, frenado, la producción responsable, considerando criterios ambientales, sociales y económicos, fortaleciendo un
ralentí y uso de neumáticos). abastecimiento responsable en toda la cadena de suministro, impulsando prácticas agrícolas sostenibles.
Incorporar nuevas tecnologías e inteligencia artificial: se continuará aumentando la A través de la gestión realizada con nuestros proveedores estratégicos, el año 2024, CCU alcanzó un
electromovilidad y las tecnologías más avanzadas en consumo eficiente de combustibles en camiones, 29,3% de materias primas estratégicas provenientes de agricultura certificada, lo que corresponde a
explorando y evaluando la big data y capacidad de IA Machine Learning. un total de 64.590 toneladas.
 80 Camiones Euro VI en operación de acarreo, los cuales disminuyen las emisiones
 de NOx y material particulado fino.
 36,9% 100% 9,7%
 Malta (Cebada) Lúpulo Azúcar
 31 Incorporación de 31 camiones eléctricos a la flota de distribución. 58.408 ton 182 ton 6.000 ton de azúcar
 de remolacha
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Abastecimiento responsable 159

[pág. 161]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 Eje Personas Avances de nuestro desempeño
 Experiencia SER CCU
 ST R O PLAN
 U E ET Esta agenda de trabajo está dedicada exclusivamente a los trabajadores de la Compañía, quienes
 N A
 ÁTICO AB constituyen un eje central y estratégico en todas las unidades de negocio. En este contexto y de la
 LI M AS
 O
 C
 O
 TE mano de una serie de iniciativas y robusta agenda, trabajamos por la solidez de una organización y
 FÍ RIC
 VOCAC
 I ÓN
 C
 A
 HÍ
 D marca empleadora referente regional, reconociendo el valor del talento y del compromiso de nuestros
 IM
 CI
 S
 DE O R
 IE
 trabajadores. Nuestra agenda de trabajo se ancla sobre dos grandes metas:
 NT
 I
 BR
 CU
 OR
 ILI
 LA
 E QU
 R
 Certificar a CCU como un empleador de excelencia
 ES P
 Mantener un clima laboral saludable
 ONSA B L E
 UMIDOR
 EXPER
 DISFR
 NS
 2030 Certificar a CCU como un Avance
 UT
 IEN
 META 11
 CO
 2024
 EC
 empleador de excelencia
 CI
 SE E
 L
 A
 O
 R OR
 N
 ÍS
 CC P
 SC
 IE U N P
 A
 N PA S I Ó
 TE
 E SO
 R Inspirados por nuestro SER CCU, nos enorgullece el trabajo robusto que hacemos con nuestros
 OG
 N PR S
 UE A trabajadores, por lo que hacerlo visible y comparable a través de una certificación internacional
 STR O N
 AS PERS no permite no solo validar las buenas prácticas desarrolladas en Recursos Humanos, sino también
 desafiarnos a seguir mejorando manteniendo el estándar en todos los países donde operamos. Es
 así, que el año 2024 fuimos certificados como Top Employer Chile.
Para CCU, las personas son el principal motor de la Compañía, estableciendo continuamente La certificación Top Employer reconoce a las compañías con mejores prácticas de empleo y condiciones
relaciones de confianza con sus trabajadores, clientes, proveedores y comunidades donde opera. laborales de estándar global, promoviendo el desarrollo y bienestar de sus empleados. Este proceso,
 basado en una encuesta de seis dimensiones, analiza y evalúa la estrategia de personas, entorno
Es así como a través del eje Nuestras Personas, buscamos continuar generando oportunidades de laboral, adquisición de talento, aprendizaje, bienestar y diversidad e inclusión.
desarrollo mediante experiencias significativas a través de cuatro agendas de trabajo: Experiencia
SER CCU, Pasión por el Consumidor, Disfrute Consciente y Progreso País.
 Atraer Modelar Desarrollar Unir Comprometer Dirigir
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Experiencia SER CCU 160

[pág. 162]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
Este sello, permite atraer y retener el talento en la organización, compartir buenas prácticas Con los resultados obtenidos cada unidad de negocio genera planes de acción para mantener o
con empresas participantes e identificar oportunidades transversales en las distintas áreas de mejorar en el año siguiente. Los resultados de esta encuesta se encuentran disponibles en una
la Compañía. El proceso iniciado el año 2024, permitió fortalecer diversas prácticas laborales, plataforma que permite observar la evolución histórica de los resultados, así como hacer seguimiento
reforzando y validando nuestras métricas y procesos de gestión de Recursos Humanos. a los planes de acción establecidos.
 META 12 Mantener un clima laboral saludable
 Avance
 2024 86% Pasión por el Consumidor
 En CCU, nos preocupamos de crear nuevas experiencias, manteniendo una estrecha sintonía y
La medición del clima organizacional refleja la percepción que los trabajadores tienen acerca de su entendimiento de nuestros consumidores, por medio de dos metas:
ambiente laboral. En CCU medimos el clima anualmente a través de una encuesta dirigida a todos los
trabajadores con un mínimo de seis meses de antigüedad y con contrato indefinido. La participación Crecimiento sostenido de la preferencia de nuestras marcas
es voluntaria y los datos entregados por los trabajadores son tratados de forma confidencial. Implementar anualmente 25 iniciativas aceleradoras de “Juntos por un Mejor Vivir”
La encuesta es un cuestionario de autorreporte en que el trabajador señala su nivel de acuerdo con
una serie de afirmaciones acerca de su ambiente de trabajo. Crecimiento sostenido de la Avance Crecimiento
 META 13
 preferencia de nuestras marcas 2024 sostenido
Desde el año 2018 se utiliza el mismo modelo de Clima Organizacional, que recoge el Indicador Global de
Clima (IGC) y 12 dimensiones del trabajo. El IGC engloba las actitudes del trabajador hacia la organización
y da cuenta de un estado de bienestar y la intención de permanecer en ella. Incluyendo los siguientes Con el objetivo de impulsar el continuo crecimiento de nuestras marcas, hemos desarrollado nuestro Modelo
elementos: de Preferencia. Este modelo identifica las causas y variables que impactan tanto en el valor de nuestras marcas
 como en los resultados del negocio. Reconociendo que las marcas son el activo clave de nuestra empresa,
 adoptamos una estrategia de portafolio en la que cada marca define un posicionamiento deseado dentro
 de su categoría. Esta estrategia orienta la gestión de cuatro factores clave: publicidad, producto, punto de
 venta y precio, con el propósito de lograr mayor preferencia y, en consecuencia, mayores participaciones
 Satisfacción con Identificación con Engagement / Intención de de mercado, incrementos en ingresos y un desarrollo sostenido de las categorías donde participamos.
 la organización la organización Compromiso permanencia
 Para monitorear el impacto de nuestras acciones comerciales en los consumidores y garantizar un
 crecimiento sostenido, llevamos a cabo estudios periódicos como tracking de marca, medición de
En el año 2024, el indicador IGC alcanzó un 86% de satisfacción laboral a nivel consolidado, con una desempeño en puntos de venta, paneles de consumo en hogares, entre otros. Para responder a preguntas
participación de 8.408 trabajadores que representan un 95% de los trabajadores elegibles de participar. específicas del negocio también realizamos constantemente distintos estudios ad-hoc en consumidores,
 tales como, estudios de innovaciones, evaluaciones publicitarias, pruebas a ciegas, barridos de tendencias,
Adicionalmente este año consultamos a los trabajadores por su grado de conocimiento, identificación entre otros. Los resultados de estas iniciativas son analizados regularmente en reuniones con el Gerente
y el aporte al propósito de CCU resultando un 88% de respuestas positivas. General de CCU S.A., el equipo ejecutivo y las unidades de negocio de los seis países donde operamos.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Pasión por el Consumidor 161

[pág. 163]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
META 14
 Implementar anualmente 25 iniciativas Avance 22 Con el objetivo de fortalecer y acelerar nuestro compromiso en temáticas de sustentabilidad
 generando un contacto con nuestros consumidores, contamos con iniciativas o acciones que nuestras
 aceleradoras de “Juntos por un Mejor Vivir” 2024 Iniciativas
 marcas comerciales realizan en un año calendario para apoyar el cumplimiento de la Estrategia de
 Sustentabilidad “Juntos por un Mejor Vivir”. Durante el año 2024, realizamos 22 iniciativas a través
 de 14 marcas comerciales, contribuyendo a generar un mejor vivir de las personas y/o el planeta.
 “1% for the Planet”, destinando el 1% de las ventas de la línea
 Gran Reserva a la Fundación Tierra Austral para promover la Resalta la identidad de lo “Típico Chileno”.
 conservación de los ecosistemas terrestres de Chile Central.
 Con su programa Ciclo del Agua, para el ST R O PLAN 10% del presupuesto de Marketing destinado
 U E ET a Campaña de Consumo Responsable (Chile,
 cuidado de humedales y ríos locales. N A
 ÁTICO AB Argentina, Uruguay, Paraguay).
 LI M AS
 C TE
 O
 FÍ O VOCAC C
 A RIC I ÓN
 #Revolución Natural, primera botella HÍ
 D
 IM
 CI
 S
 Fomento al deporte a través de “Recicancha” y
 DE
 R
 IE
 con plástico reciclado en Chile. O
 NT
 organización de 5v5.
 I
 CU
 BR
 OR
 LA
 ILI
 R
 ES P
 E QU
 ONSA B LE
 UMIDOR
 “Familias reciclando en Modo Bilz y Pap”, Programa “Refresca tu barrio”.
 EXPER
 DISFR
 campaña de reciclaje más grande de Chile.
 NS
 2030
 UT
 IEN
 La campaña el “Conductor Valdiviano”
 CO
 EC
 CI
 SE E Apoyo al desarrollo cultural, institucional y
 L
 A
 O
 R OR turístico local en la ciudad de Valdivia, Chile.
 N
 ÍS
 CC P
 SC
 IE U N P
 A
 Colaboración con el programa “Genias”. N PA S I Ó
 TE SO
 G RE
 N PRO S
 UE
 STR O NA
 AS PERS
 Fortalecimiento de identidad de barrios.
 Campañas de Teletón.
 Apoyo a artistas locales emergentes.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Pasión por el Consumidor 162

[pág. 164]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 El programa CRÁ, hoy es un pilar fundamental de nuestra estrategia en Chile, y está enfocado en 4
 Disfrute Consciente grupos de interés: trabajadores, clientes, comunidades y consumidores.
La Compañía fomenta el disfrute consciente, ofreciendo un portafolio amplio que promueva, junto a Trabajadores
sus marcas, un consumo informado, moderado y responsable, por medio de dos metas: Durante el año 2024, se realizó la campaña interna “InfluenSER CRÁ” que invitó a todos los
 trabajadores a fomentar los momentos de disfrute con moderación, tanto dentro como fuera del
 Implementar un 100% de Programa CRÁ - Consumo Responsable de Alcohol trabajo, inspirando a otros a ser unos consumidores responsables de alcohol.
 Implementar un 100% de Programa Vivamos Bien – Vida Saludable
 Clientes
 Se desarrollaron diversas acciones según el canal de venta, donde se busca aumentar el volumen de
 META 15 Implementar un 100% Programa CRÁ
 Avance 100% venta de productos sin alcohol y así hacer crecer esta categoría. Destacamos la campaña “Disfrutemos
 2024 Implementación desde cero” que se realizó en el canal supermercado y en cadenas de alimentos de comida rápida.
 Chile
 Comunidades y consumidores
 Dentro de las distintas iniciativas que componen el programa, trabajamos desde el año 2019 con
Alineadas a nuestro propósito, desde el año 1994, CCU ha implementado una serie de iniciativas que Fundación Emilia, expertos en seguridad vial, donde visibilizamos a la ciudadanía, de manera conjunta,
promueven y concientizan sobre la importancia del consumo responsable de alcohol. Estas acciones el mensaje “Si vas a manejar pasa las llaves”. Durante el año 2024, junto a la fundación se desarrollaron
reflejan nuestro compromiso con la educación y la prevención de los riesgos asociados al consumo cinco talleres presenciales en las regiones de Antofagasta y la Araucanía, alcanzando a más de 800
excesivo e irresponsable, buscando fomentar conductas responsables en toda la ciudadanía, lo estudiantes. Las charlas estuvieron orientadas a promover la prevención, educación y moderación
cual se encuentra plasmado además en nuestro Código de Autorregulación sobre Comunicaciones en el consumo de alcohol, abordando temáticas clave como los riesgos del consumo excesivo y la
Comerciales Responsables. importancia de tomar decisiones informadas.
 Además, por primera vez, lanzamos una campaña digital dirigida a un público más joven llamada
 Código sobre Comunicaciones Los productos CCU y la comunicación que de ellos se realice, “CRÁ Awards”, cuyo objetivo fue reconocer y premiar a aquellos consumidores que consistentemente
 siempre deberán cumplir con la normativa vigente en cada país
 Comerciales Responsables donde se elaboren, distribuyan o exhiban. demuestran conductas responsables en relación al consumo de alcohol.
 En este documento se declara que las Para esto, se declaran tres tipos de principios:
 comunicaciones de la Compañía deben Principios generales, aplicables a todos los
 mantenerse dentro de los límites de lo productos de CCU.
 responsable y correcto, pero al mismo Principios aplicables a productos con alcohol.
 tiempo, mantener su vigor y atracción a los Principios aplicables a productos sin alcohol.
 consumidores, buscando crear un vínculo
 emocional y directo con cada uno de ellos.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Disfrute Consciente 163

[pág. 165]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 Comunidades
 META 16
 Implementar un 100% Programa Vivamos
 Bien – Vida Saludable
 Avance
 2024
 100% Chile Como parte del desarrollo de los planes de relacionamiento comunitario en nuestros territorios
 estratégicos, continuamos avanzando en establecer alianzas con organizaciones y fundaciones que
 promuevan la práctica deportiva, entregando espacios de esparcimiento y recreación en las comunas
Este programa tiene por objetivo promover hábitos de vida saludable entre los consumidores, los de Renca, Quilicura, Coinco y Vilcún.
trabajadores y las comunidades, mediante iniciativas que fomentan la prevención y autocuidado,
una alimentación saludable y equilibrada, y la actividad física. Durante el año 2024, destacamos los En Renca, se realizaron talleres deportivos para niños y adultos, además de la Corrida Familiar de
siguientes avances: Renca junto a CCU, la cual se ha transformado en un hito anual para la comuna con más de 1.500
 participantes cada año.
Trabajadores
Conscientes de la importancia de fomentar el cuidado y bienestar de nuestros trabajadores nace En Quilicura, durante todo el año estuvimos junto a la Fundación “Ganémosle a la calle”, realizando
el programa “Vivamos Bien – Vida Saludable”, el cual promueve la implementación de iniciativas de jornadas deportivas de diversas disciplinas para 250 niños de las villas Santa Teresita y El Amanecer.
autocuidado, alimentación saludable y actividad física. Se impulsó la homologación del programa a nivel
regional, traspasando las mejores prácticas a todos los trabajadores a nivel regional, como contar con En Coinco y Vilcún, trabajamos con 330 niños y sus familias de la mano de “Fútbol +”, organización
operativos de salud en todas las instalaciones donde la Compañía opera. que se enfoca en colegios, barrios y clubes deportivos para desarrollar talleres socio deportivos, en
 los que se involucra a toda la comunidad para aprender el trabajo en equipo y cohesión comunitaria.
En Chile, se destacan las siguientes iniciativas:
Exámenes preventivos Charlas de bienestar Operativos de
 de salud vacunación
 Realización de charlas
Implementación de operativos Realización de operativos de
 online sobre distintos temas
 gratuitos en cada centro inoculación gratuitos contra
 relacionados a la salud física,
 de trabajo, que incluye un el virus de la influenza en los
 emocional y financiera, además
 chequeo preventivo centros de trabajo
 de actividades relacionadas al
 tiempo libre
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Disfrute Consciente 164

[pág. 166]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 Consumidores Cachantun
 A través de su oferta de productos de la multicategoría, CCU ofrece un portafolio equilibrado que
 se ajusta a cada ocasión de consumo. Continuamos fortaleciendo nuestro portafolio de productos A través de la creación de espacios que promueven la vida en comunidad y
 reducidos o sin azúcar, además de contar con marcas que fomentan el deporte y el bienestar, como el bienestar social, Cachantun junto a Fundación Mi Parque llevan adelante
 Gatorade y Cachantun. el programa “Refresca tu Barrio”, una iniciativa que mejora la calidad de
 vida en los barrios mediante la recuperación de plazas. En el año 2024, el
 Productos reducidos en azúcar programa benefició a la “Plaza de los Colores” en La Serena, la Plaza “María
 Luisa Bombal” en la comuna de El Bosque y la “Plaza El Rulo” en Coinco,
 52,8% 41,7% 4,3% renovando e inaugurando espacios verdes accesibles para todos. Con esta
 iniciativa, Cachantun reafirma su compromiso con el bienestar de las personas,
 de productos reducidos en de ingresos por del volumen total de ventas sumando 15 plazas reconstruidas en comunidad desde Arica hasta Puerto
 azúcares vendidos sobre el bebidas sin calorías y de productos que contengan Montt, con más de 14.150 m² de áreas renovadas y un impacto positivo en la
 total de ventas analcohólicos bajas en calorías más ingredientes nutritivos o
 funcionales(1) vida de más de 200.000 vecinos.
 Gatorade
 Campeonato 5v5
 Es la plataforma de Gatorade a nivel mundial, pensada para conectar y generar
 compromiso con jóvenes entre 14 a 16 años. En marzo 2024, y bajo su formato
 original, el evento se desarrolló en San Carlos de Apoquindo, donde 50 equipos,
 formados por más de 300 de hombres y mujeres, disputaron el campeonato
 con el objetivo de ganar un cupo para representar a Chile en Londres donde se
 disputó la fase final del torneo, cuyo premio era la obtención de tickets a la final
 de la UEFA Champions League 2024 en el estadio de Wembley.
 Recicancha Quilicura
 En su segunda versión, se realizó el proyecto Recicancha, que consideró el
 mejoramiento de dos multicanchas construidas con 8.5 toneladas de plástico
 reciclado. Este proyecto se desarrolló en conjunto con Villa El Amanecer y Santa
 Teresita de la comuna de Quilicura, beneficiando a más de 6.000 vecinos, y se
 suma a la Recicancha construida en el año 2023 en Renca.
(1) Incluye fibra, vitaminas, minerales, fitoquímicos o aditivos minerales funcionales
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Disfrute Consciente 165

[pág. 167]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 El eje central de esta relación corresponde a la implementación de los Planes de Relacionamiento
 Progreso País Comunitario de CCU, los cuales consideran las necesidades identificadas en cada territorio e iniciativas
 diseñadas para generar un impacto positivo en territorios estratégicos. Estas iniciativas buscan promover
CCU colabora al desarrollo económico y cultural en los países donde opera, alineados a su escala y el desarrollo sostenible, mejorar las condiciones de vida de las comunidades y fomentar relaciones
realidad local, procurando generar una huella positiva a través de cuatro metas: estrechas y responsables entre CCU y los actores locales.
 Implementar planes comunitarios en el 100% de territorios estratégicos La implementación consta de cuatro pasos:
 Apertura nacional del Museo Cervecero Limache
 Impactar a 30.000 clientes por medio de programas de capacitaciones y/o financiamiento
 Alcanzar un 90% de proveedores significativos adheridos a la Guía de Buenas Prácticas (GBP)
 META 17
 Implementar planes comunitarios en
 100% territorios estratégicos
 Avance
 2024
 100% Reconocimiento Mapeo del Identificación Desarrollo del
 de áreas de retorno de necesidades plan comunitario
 influencia
Nuestro compromiso es promover y asegurar relaciones estrechas entre la Compañía y actores locales, Es importante destacar que los Planes de Relacionamiento Comunitario se fundamentan en los
considerando el bienestar actual y futuro de todas las personas con las que interactuamos. Este principios del SER CCU, garantizando el bienestar presente y futuro de las personas, el cuidado del
compromiso se ve reflejado en nuestra Política de Relacionamiento Territorial. medioambiente, el acceso al agua, el consumo responsable y el fortalecimiento cultural y social en
 los territorios donde operamos.
 Política de Relacionamiento Dentro de las plantas de CCU, se han identificado 15 territorios estratégicos.
 Territorial Nuestros 5 principios corresponden a:
 En esta Política declaramos que la construcción
 Quilicura Coinco Santa Fe Las Heras
 Somos un buen vecino Renca Valles Pisqueros Salta Chascomús
 de un relacionamiento sólido y permanente
 El territorio prospera con CCU Vilcún Austral Luján
 con la comunidad está directamente ligada
 Cumplimos nuestros compromisos Antofagasta
 con nuestra preocupación por el bienestar de
 Puertas abiertas
 las personas como un elemento estratégico en
 Vinculación territorial continua
 nuestro modelo de negocios, permitiéndonos San Antonio
 Pan de Azúcar
 generar valor mutuo junto con fortalecer nuestra Asunción
 continuidad operacional y organizacional.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Progreso País 166

[pág. 168]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
Al cierre del año 2024, contamos con un 100% de implementación de estos planes en Chile y el Además, la Compañía continuó aportando a Red de Alimentos, institución a la cual se entregan
desarrollo de los mapeos en Argentina. Además, se definió por primera vez un plan de vínculo productos para ser consumidos por personas en situación de vulnerabilidad a más de 200
territorial para Paraguay en sus dos zonas de influencia y, en Uruguay, se desarrollaron las primeras organizaciones sociales, donando más de 1,6 millones de litros de productos CCU.
tres etapas de su plan. Bolivia aún no es una zona considerada prioritaria, pero se encuentra en
permanente monitoreo. Plan de relacionamiento comunitario en Coinco
Apoyo Solidario En la comuna de Coinco se encuentra la instalación donde se envasa agua mineral Cachantun desde
Nuestro compromiso con la hidratación se extiende no solo a nuestros territorios estratégicos, hace más de 100 años en Chile. CCU ha realizado diversos aportes a la comunidad desde la adquisición
sino que abarca todo el territorio regional, aportando con nuestros productos en momentos de este negocio, de los cuales se destacan el apoyo al acceso agua a través de la ejecución de dos
de emergencia y necesidad de la ciudadanía, apalancado por nuestra Política de Aportes a la pozos de agua potable rural, beneficiado a más de 600 familias; el incentivo al deporte, mediante
Comunidad: Donaciones y Auspicios Solidarios. el apoyo al Club Cachantun con una escuela de fútbol para 50 niños y niñas, y el mejoramiento de
 áreas verdes, como la renovación de la Plaza El Rulo, mediante el programa Refresca Tu Barrio.
 Política de Aportes a la CCU en el Arte
 Comunidad: Donaciones y
 Auspicios Solidarios Llevamos más de 30 años apoyando la cultura nacional a través de este programa enmarcados en
 Los lineamientos que se presentan y describen
 el propósito de “Acercar el Arte a las personas”, impulsando mayor accesibilidad y descentralización
 Tiene como propósito robustecer nuestro son:
 de la cultura. Aportamos a la ampliación de la oferta artística y a la difusión del arte chileno mediante
 proceso de aportes a la comunidad de
 Áreas de reporte una agenda de actividades relacionadas al arte visual chileno contemporáneo.
 manera coherente con el propósito,
 principios y valores de la Compañía, Beneficiarios
 cumpliendo a su vez, con la normativa Cumplimiento normativo Durante el año 2024, se realizaron nueve exposiciones en la Sala de Arte CCU, y se desarrolló
 vigente en cada país y con lo establecido en una iniciativa pionera de convocatoria a artistas de las zonas norte y sur de Chile, brindándoles la
 el Código de Conducta en los Negocios de oportunidad de exponer sus obras. En el sur, se trabajó con la Escuela de Arte de la Universidad
 la Compañía y el Modelo de Prevención de Católica de Temuco y en la zona norte, con el Museo Ruinas de Huanchaca de Antofagasta. El
 Delitos de CCU S.A. y filiales. resultado fueron cientos de artistas que postularon y 4 exposiciones con una excelente recepción
 del público local, con un alcance de más de 10.000 personas en todas sus actividades, duplicando
 el público del año 2023.
En el año 2024, la Compañía colaboró con más de 350 instituciones. Dentro de los distintos
ejes de acción, destacan el mejoramiento de áreas verdes, incentivo al deporte, apoyo a familias
damnificadas de incendios o emergencias climáticas, apoyo en tutorías y becas para estudiantes
de 4º medio y campañas 1+1, entre ellas para Teletón y Desafío Levantemos Chile. Adicionalmente,
donamos 56.000 litros en productos de hidratación en situaciones de emergencias, a bomberos,
juntas de vecinos y organizaciones sociales de Chile, principalmente en la Región de Valparaíso.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Progreso País 167

[pág. 169]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 Las iniciativas destacadas durante el año 2024 corresponden a las siguientes:
 META 18
 Apertura nacional del Museo Cervecero
 Limache
 Programa Master Class: Con 1.587 alumnos participantes, este programa está centrado en
 potenciar habilidades clave para el desarrollo del negocio, por medio del desarrollo talleres
 online, abarcando temáticas tales como, “Contabilidad para mi negocio”, “Alfabetización digital
La construcción y apertura del Museo Cervecero Limache es un proyecto impulsado por CCU con Excel básico” y “Rol del Administrador del negocio”.
el fin de restaurar y preservar el patrimonio histórico de la cervecera nacional, bajo el alero de esta Programa CRECER Juntos: Corresponde a un programa de capacitación y asesoría dirigido
fábrica, fundada en 1883, como parte de su historia. Al cierre del año, se ha completado su etapa a los clientes de CRECCU, almaceneros y botilleros que deseen conocer o mejorar la gestión
de desarrollo técnico mediante distintas especialidades, principalmente arquitectura, paisajismo, dentro de su negocio. Los talleres abarcaron temáticas de desarrollo de negocios y consumo
museografía y estructura. responsable de alcohol, contando con un total de 363 alumnos inscritos.
 Levantamiento Net Promoter Score (NPS): Se realizó un nuevo estudio para determinar el
Como parte de la vocación de este proyecto, por segundo año consecutivo la ex fábrica abrió sus nivel de lealtad que tienen los clientes respecto de los servicios entregados por el programa, por
puertas en el Día de los Patrimonios, recibiendo más de 1.800 visitantes. medio de la aplicación de la herramienta NPS, la cual arrojó que existe un 77,8% de probabilidad
 de que las personas recomienden CRECCU. Este resultado es muy positivo, y está asentado en
 el crédito y el apoyo a los almacenes y botilleros a nivel nacional.
 Impactar a 30.000 clientes por medio
 META 19 de programas de capacitaciones y/o
 Avance
 2024
 18.604
 financiamiento clientes
La Compañía desarrolla la relación con sus clientes con un enfoque colaborativo, procurando generar
oportunidades de crecimiento mutuo en el largo plazo. En este contexto, cuenta con programas
de apoyo a través de capacitaciones y/o financiamiento orientados a pequeños almaceneros y
botilleros en Chile y Argentina.
 CRECCU
 14.523 Filial de CCU que entrega acceso a financiamiento a emprendedores del segmento
 minorista, apoyando el crecimiento de sus negocios, facilitando capital de trabajo
 que se utiliza en la compra de productos. Además, realiza asesorías técnicas y
 Clientes
impactados capacitaciones que potencian sus habilidades y conocimientos, colaborando a
 rentabilizar su negocio.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Progreso País 168

[pág. 170]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 Academia CCU Mi Carro CCU
 4.081 En el año 2024, nuestro programa de capacitación online, enfocado en fortalecer Plataforma online que permite mantener un canal de comunicación adicional con clientes del
 las capacidades de pequeños y medianos comercios, alcanzó un récord de más de canal tradicional, y que estos puedan generar pedidos 24/7 a partir del catálogo completo de
 4.000 clientes inscritos al cierre del año. Como parte de nuestros esfuerzos para productos. Durante el año 2024, desplegamos y/o actualizamos dos herramientas digitales, las
 Clientes
impactados mejorar la experiencia del usuario, lanzamos la aplicación “Academia CCU”. cuales corresponden a:
Continuamos expandiendo nuestra oferta educativa, finalizando el año 2024 con 19 cursos gratuitos Actualización de página web y aplicación, contando con nuevas tecnologías, herramientas y
y on demand, junto con la masterclass “Digitalizá tu Negocio”, que se impartió de forma presencial funcionalidades. De esta manera, se busca poder darles nuevas modalidades de compra a nuestros
en las localidades de Luján y Santa Fe. clientes, las cuales incluyen el acceso al catálogo, información de sus compras, promociones y
 notificaciones. A lo largo del año, esta herramienta se desplegó en todos los distritos de Chile.
Programa de Excelencia Comercial en Uruguay
En Uruguay, desde el año 2019 se efectúa el Programa de Excelencia Comercial (PEC), dirigido a sus Sofía CCU, asistente digital a través de la aplicación WhatsApp, que permite a nuestros clientes
18 distribuidores a lo largo del país, realizando capacitaciones anuales con el fin de profesionalizar tener una comunicación más rápida, eficiente y cercana. Al igual que Mi Carro, se puede acceder
y potenciar su trabajo. a los catálogos de venta, promociones y ofertas especiales. Durante el año 2024 se desplegó en
 cinco distritos de Chile.
En el año 2024, se realizaron dos Talleres PEC con los distribuidores de todo el país, uno de ellos
denominado “Crecer para rentabilizar”, con el objetivo de potenciar la venta en escala (volumen); Formación Fuerza de Ventas
y el otro llamado “Procesos e innovaciones, claves para el crecimiento”, apuntando al desarrollo En CCU continuamos reforzando nuestro compromiso con la formación y desarrollo de nuestra
y profesionalización del distribuidor en base al cumplimiento de los procesos y lineamientos fuerza de ventas. Durante el año 2024 reforzamos contenido clave para la Seguridad y Salud
establecidos en CCU Uruguay. Ocupacional, profundizando temáticas claves del negocio que nos permiten seguir construyendo
 relaciones de confianza con nuestros clientes.
 De manera complementaria, este año implementamos mensualmente cápsulas de formación, que
 se presentan a los equipos de ventas en cada oficina comercial, diseñadas para entregar contenido
 relevante sobre gestión de clientes, estrategias comerciales y de ejecución en los puntos de venta.
 Adicionalmente, reforzamos nuestro compromiso con la libre competencia, a través de instancias de
 capacitación, donde compartimos contenidos enfocados en los fundamentos de la libre competencia
 y la identificación de conductas riesgosas.
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Progreso País 169

[pág. 171]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
Encuesta de satisfacción de clientes Impulsamos relaciones colaborativas con nuestros proveedores, las cuales se basan en el compromiso
Adicional al apoyo de nuestros clientes mediante programas, la Compañía mide el grado de de contribuir al bienestar actual y futuro del entorno con el que interactuamos. Parte fundamental
satisfacción de sus clientes de canal tradicional, por medio de un estudio anual en los mercados de de este compromiso corresponde al cumplimiento de la Guía de Buenas Prácticas – Proveedor CCU
Chile y Argentina. Este estudio nos permite comprender su percepción en términos de satisfacción, (GBP), la cual ha sido incorporada como una herramienta para velar por un ambiente abierto, leal y
a través del análisis de 10 dimensiones que abarcan toda la cadena de valor y los puntos de competitivo, basándose en tres lineamientos generales:
contacto. De este modo, identificamos oportunidades de mejora que fortalecen continuamente
nuestra relación con los clientes. Conducta en los negocios
 Respeto por Nuestras Personas
En el año 2024, los resultados corresponden a los siguientes: Respeto por Nuestro Planeta
Resultados encuesta de satisfacción de clientes Esta guía aplica para CCU y todos sus proveedores, por lo que todo proveedor debe aceptar y
 cumplir con ella, lo cual queda acordado en todos los contratos y órdenes de compra. Dentro de
 85,3
 este contexto, se espera que todos los proveedores de CCU hagan propios estos compromisos y
 las buenas prácticas, respetándolas y exigiéndolas dentro de su propia cadena de valor y con la
 82,5
 82,2 comunidad en que se relacionan.
 81,4 81,6
 79,6 79 78,7
 Como parte del proceso de mejora continua, instamos a nuestros proveedores a desarrollar medios
 para alcanzar y mejorar el cumplimiento de los lineamientos establecidos y de las buenas prácticas
 asociadas. Estos lineamientos se basan en el cumplimiento de la ley, normas y regulaciones en Chile,
 2021 2022 2023 2024
 Argentina, Paraguay, Uruguay y Bolivia, así como el respeto a los derechos humanos conforme a
 los 10 principios del Pacto Global de las Naciones Unidas, la generación de condiciones laborales
 Chile Argentina seguras, y el cuidado del medioambiente en sus distintas dimensiones.
Los resultados de 2024 contemplan una muestra del 2,3% de clientes en Chile, y un 3% en Argentina. Adhesión a Guía de Buenas Prácticas a Proveedores 2024
 1.545 proveedores significativos
 Total 92,1%
 Alcanzar un 90% de proveedores
META 20 significativos adheridos a la Guía de
 Avance
 2024 92,1%
 Buenas Prácticas a Proveedores (GBP)
 97,4% 81,7% 100% 84% 68,4%
Memoria Integrada 2024 / 9.1 Estrategia de Sustentabilidad / Progreso País 170

[pág. 172]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
9.2 Métricas SASB
Tema Parámetro de contabilidad Código Respuesta
Gestión del combustible de Combustible de la flota propia consumido FB-NB-110a.1a No contamos con flota propia de vehículos.
la flota Porcentaje de energías renovables en la flota propia FB-NB-110a.1b No aplica.
 FB-AB-130a.1a
 Total de energía consumida 2.152.381 GJ
 FB-NB-130a.1a
 FB-AB-130a.1b
Gestión de la energía Porcentaje de electricidad de la red 43,3%
 FB-NB-130a.1b
 FB-AB-130a.1c
 Porcentaje de energías renovables 39,4%
 FB-NB-130a.1c
 FB-AB-140a.1a
 Total de agua extraída 8.519.827 m3
 FB-NB-140a.1a
 FB-AB-140a.1b
 Total de agua consumida 4.436.373 m3
 FB-NB-140a.1b
 FB-AB-140a.1c
Gestión del agua Porcentaje de agua extraída en regiones con un estrés hídrico inicial alto o extremadamente alto 60,72%
 FB-NB-140a.1c
 FB-AB-140a.1d
 Porcentaje de agua consumida en regiones con un estrés hídrico inicial alto o extremadamente alto 50,27%
 FB-NB-140a.1d
 Descripción de los riesgos de la gestión del agua y análisis de las estrategias y las prácticas para FB-AB-140a.2a Ver sección 9.1 Estrategia de Sustentabilidad - Equilibrio Hídrico y la sección
 mitigarlos FB-NB-140a.2a 3.6.1 Gestión de riesgos.
 Ingresos por bebidas sin calorías y bajas en calorías FB-NB-260a.1a CLP 372.954 millones de pesos.
 De acuerdo a la definición del indicador SASB, no contamos con productos sin
 Ingresos por bebidas sin azúcar añadida FB-NB-260a.1b
 azúcar añadida.
Salud y nutrición
 Ingresos por bebidas endulzadas artificialmente FB-NB-260a.1c CLP 415.803 millones de pesos.
 Análisis del proceso de identificación y gestión de los productos e ingredientes relacionados
 FB-NB-260a.2 Ver sección 9.1 Estrategia de Sustentabilidad - Disfrute Consciente.
 con las preocupaciones nutricionales y de salud de los consumidores
 Estamos adheridos a las mejores prácticas de la industria en materia de
 información al consumidor, como la Guía Diaria de Alimentación. Además,
 contamos con una serie de herramientas internas de autorregulación en
 materia de etiquetado y comunicación de todos sus productos: Sistema de
Etiquetado y marketing de Porcentaje de anuncios publicitarios (1) realizados para niños y (2) realizados para niños que
 FB-NB-270a.1 Mensajes CCU (SMCCU), Política de Alcohol CCU y el Código de Comunicaciones
productos promueven productos que cumplen con las recomendaciones alimentarias
 Comerciales Responsables CCU, dirigido a nuestros trabajadores, agencias
 de marketing, publicidad y productoras para que respeten e incorporen los
 conceptos del Consumo Responsable de Alcohol. En el año 2024, menos del
 0,5% de nuestro gasto publicitario estuvo dirigido a niños.
Memoria Integrada 2024 / 9.2 Métricas SASB 171

[pág. 173]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
Tema Parámetro de contabilidad Código Respuesta
 Ingresos de los productos etiquetados como (1) que contienen organismos modificados
 FB-NB-270a.2a No tenemos productos no alcohólicos (bebidas gaseosas, en base a malta,
 genéticamente (OMG)
 jugos, néctares, isotónicas, funcionales, aguas minerales, aguas purificadas y
 Ingresos de los productos etiquetados como (2) que no contienen OMG FB-NB-270a.2b aguas saborizadas) que contengan ingredientes etiquetados como OMG.
Etiquetado y marketing de Número de incidentes de no conformidad de los códigos reglamentarios o del sector para el
 FB-NB-270a.3 No hubo.
productos etiquetado o el marketing
 Importe total de las pérdidas monetarias como resultado de los procedimientos judiciales
 FB-NB-270a.4 No hubo.
 relacionados con las prácticas de etiquetado o de marketing
 La entidad describirá brevemente la naturaleza, el contexto y las acciones correctivas
 FB-NB-270a.4b
 adoptadas como resultado de las pérdidas monetarias
 FB-AB-410a.1a
 Peso total de los envases utilizados 218.039 toneladas.
 FB-NB-410a.1a
 FB-AB-410a.1b
 Porcentaje del peso total de envases fabricados con materiales reciclados o renovables 79,72%
Gestión del ciclo de vida de FB-NB-410a.1b
los envases FB-AB-410a.1c
 Porcentaje del peso total de envases que son reciclables o compostables 99,95%
 FB-NB-410a.1c
 Descripción de las estrategias para reducir el efecto ambiental de los embalajes a lo largo de su FB-AB-410a.2a
 Ver sección 9.1 Estrategia de Sustentabilidad - Vocación Circular.
 ciclo de vida FB-NB-410a.2a
 Tasa de no conformidad de la auditoría de la responsabilidad social y ambiental de los
 proveedores FB-AB-430a.1
 Conformidad de la auditoría de responsabilidad social y ambiental de los proveedores: tasa de FB-NB-430a.1a
 casos de no conformidad importantes
 Conformidad de la auditoría de responsabilidad social y ambiental de los proveedores: tasas de
 FB-NB-430a.1b
 acciones correctivas correspondientes a casos de no conformidad importantes
Impactos ambientales y
 Conformidad de la auditoría de responsabilidad social y ambiental de los proveedores: tasa de
sociales de la cadena de FB-NB-430a.1c No hacemos auditorías, sí una encuesta de autoevaluación.
 casos de no conformidad leves
suministro de ingredientes
 Conformidad de la auditoría de responsabilidad social y ambiental de los proveedores: tasas de
 FB-NB-430a.1d
 acciones correctivas correspondientes a casos de no conformidad leves
 Tasa de no conformidades graves de la auditoría de responsabilidad social y medioambiental
 FB-AB-430a.1a
 de los proveedores
 Tasa de no conformidades leves de la auditoría de responsabilidad social y medioambiental de
 FB-AB-430a.1b
 los proveedores
Memoria Integrada 2024 / 9.2 Métricas SASB 172

[pág. 174]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
Tema Parámetro de contabilidad Código Respuesta
 Tasa de acciones correctivas para no conformidades graves en relación con la responsabilidad
Impactos ambientales y FB-AB-430a.1c
 social y medioambiental de los proveedores
sociales de la cadena de No hacemos auditorías, sí una encuesta de autoevaluación.
suministro de ingredientes Tasa de acciones correctivas para no conformidades leves en relación con la responsabilidad
 FB-AB-430a.1d
 social y medioambiental de los proveedores
 Para identificar los ingredientes que proceden de regiones con un estrés
 Porcentaje de los ingredientes de las bebidas que proceden de regiones con un estrés hídrico FB-AB-440a.1 hídrico inicial alto o extremadamente alto, se analizaron los proveedores
 inicial alto o extremadamente alto FB-NB-440a.1 de materias primas de mayor impacto. Es así que determinamos que un
 16,99% de nuestros ingredientes provienen de zonas de riesgo hídrico.
Suministro de ingredientes Los ingredientes prioritarios para la fabricación de nuestros productos son
 malta, azúcar, pulpa de fruta, arroz, jarabe de maíz, uva, vino, concentrados
 Lista de ingredientes prioritarios de las bebidas y descripción de los riesgos de abastecimiento FB-AB-440a.2 de gaseosas por licencias, lúpulo, esencias y alcohol (pisquero, neutro y
 debido a consideraciones ambientales y sociales FB-NB-440a.2 otros). Identificamos los riesgos asociados a su abastecimiento, los cuales se
 relacionan principalmente con la disponibilidad de agua y factores logísticos
 del suministro.
 Nuestras comunicaciones se ajustan a las normativas y comportamiento
 ético, promoviendo el disfrute consciente y el mejor vivir de las personas
 y el planeta. Contamos con un Código de Comunicaciones Comerciales
 Responsables CCU, que es una guía de autorregulación de uso interno y
 Porcentaje del total de impresiones publicitarias realizados en individuos en o por encima de la externo. Entrega información para que la comunicación de nuestras marcas
 FB-AB-270a.1
 edad legal para consumir alcohol se diseñen y dirijan explícitamente a personas autorizadas para consumir
 alcohol de acuerdo a la legislación de cada país. Manteniéndose los límites
Consumo de alcohol y de lo responsable y correcto, pero al mismo tiempo, con su vigor y atracción
marketing responsables a los consumidores, buscando crear un vínculo emocional y directo con
 cada uno de ellos.
 Número de incidentes de no conformidad de los códigos regulatorios o del sector para el
 FB-AB-270a.2a No hubo.
 etiquetado o el marketing
 Importe total de las pérdidas monetarias como resultado de los procedimientos judiciales FB-AB-270a.3a
 No hubo.
 relacionados con las prácticas de etiquetado o de marketing FB-NB-270a.4a
 Descripción de los esfuerzos para promover el consumo responsable de alcohol FB-AB-270a.4a Ver sección 9.1 Estrategia de Sustentabilidad - Disfrute Consciente.
 FB-AB-000.Aa
 Volumen de productos vendidos 33.773 millones de hectolitros.
 FB-NB-000.Aa
Parámetros FB-AB-000.Ba
 Número de instalaciones de producción 36 plantas productivas.
de actividad FB-NB-000.Ba
 FB-AB-000.Ca
 Total de millas recorridas por carretera por la flota 48.458.090 millas
 FB-NB-000.Ca
Memoria Integrada 2024 / 9.2 Métricas SASB 173

[pág. 175]
Sres. Compañia Cervecerias Unidas S.A.
 Página 3
 Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
 Conclusiones
 El proceso de verificación se realizó en base a los indicadores incluidos en la Memoria Integrada
 2024, una vez definidos por la Administración en su proceso de materialidad. El detalle de los
9.3 Verificación independiente indicadores que forman parte del proceso de verificación se señalan a continuación:
 Indicadores CMF NCG N°461:
 Marzo 31, 2025
Deloitte Sres. Compañia Cervecerias Unidas S.A. 1 2.1 2.2 2.3 3.1 3.2 3.3 3.4 3.5 3.6 3.7
 Deloitte
 Página 2 4.1 4.2 4.3 5.1 5.2 5.3 5.4 5.5 5.6 5.7 5.8
 Auditores y Consultores Limitada
 Rosario Norte 407 5.9 6.1 6.2 6.3 6.4 6.5 7.1 7.2 8.1 8.2 8.3
 Rut: 80.276.200-3
 Nuestra revisión incluyó los siguientes procedimientos: 8.4 8.5 9.1 9.2 10 11 12
 Las Condes, Santiago
 Chile
 Fono: (56) 227 297 000
 Deloitte
 Fax: (56) 223 749 177
 • Reunión con el equipo que lideró el proceso de elaboración de la Memoria Integrada 2024. Indicadores Sustainability Accounting Standards Board SASB:
 Auditores y Consultores Limitada
 deloittechile@deloitte.com
 Rosario Norte 407
 Marzo 31, 2025 www.deloitte.cl
 Rut: 80.276.200-3 • Revisión de evidencias para los indicadores detallados en esta carta, así como el resultado del FB-AB-000.A FB-AB-000.B FB-AB-000.C FB-AB-130a.1 FB-AB-140a.1
 Las Condes, Santiago
 Chile proceso de materialidad, con las áreas participantes de la elaboración de la Memoria Integrada FB-AB-140a.2 FB-AB-270a.1 FB-AB-270a.2 FB-AB-270a.3 FB-AB-270a.4
Señores Fono: (56) 227 297 000 2024.
 Fax: (56) 223 749 177 FB-AB-410a.1 FB-AB-410a.2 FB-AB-430a.1 FB-AB-440a.1 FB-AB-440a.2
Compañia Cervecerias Unidas S.A. deloittechile@deloitte.com
Presente FB-NB-000.A FB-NB-000.B FB-NB-000.C FB-NB-110a.1 FB-NB-130a.1
Marzo 31, 2025 www.deloitte.cl
 • Análisis de la trazabilidad de los contenidos de la Memoria Integrada 2024, comprobación de
 FB-NB-140a.1 FB-NB-140a.2 FB-NB-260a.1 FB-NB-260a.2 FB-NB-270a.1
 los indicadores detallados en esta carta, de acuerdo con los requerimientos establecidos en el
 Hemos realizado una revisión de seguridad limitada de los contenidos e indicadores de la
Señores Estándar GRI, SASB y NCG 461 FB-NB-270a.2 FB-NB-270a.3 FB-NB-270a.4 FB-NB-410a.1 FB-NB-410a.2
 Memoria Integrada
Compañia Cervecerias 2024 de Compañia
 Unidas S.A. Cervecerias Unidas S.A., (en adelante "la Sociedad")., FB-NB-430a.1 FB-NB-440a.1 FB-NB-440a.2
 de acuerdo con lo establecido con los Estándares del Global Reporting Initiative, (en adelante
Presente • Revisión de la información incluida en la Memoria Integrada 2024 a partir de la documentación
 "GRI"), Sustainability Accounting Standards Board (en adelante "SASB") y la Norma de de respaldo proporcionada por la Administración, sin embargo, nuestros procedimientos no Indicadores Gobal Reporting Intiative (GRI):
 Carácter
Hemos Generaluna
 realizado N° 461 (en adelante
 revisión "NCG
 de seguridad 461”) )de
 limitada y su
 losmodificación
 contenidos e la a Norma de
 indicadores deCarácter
 la incluyeron el testeo de los datos en los que se basan las estimaciones o en desarrollar por
 General N°519 (NCG 519) emitida por la Comisión para el Mercado Financiero
Memoria Integrada 2024 de Compañia Cervecerias Unidas S.A., (en adelante "la Sociedad")., (en adelante separado nuestras propias estimaciones con las cuales evaluar las de la Sociedad. 2-1 2-4 2-5 2-6 2-7 2-9 2-11 2-12
 "CMF”)
de acuerdoporcon
 el lo
 periodo comprendido
 establecido con los entre el 01 de
 Estándares delenero
 GlobaldeReporting
 2024 y el 31 de diciembre
 Initiative, de
 (en adelante 2-13 2-14 2-15 2-16 2-17 2-19 2-20 2-22
 2024.
"GRI"), Sustainability Accounting Standards Board (en adelante "SASB") y la Norma de Los procedimientos realizados en un encargo de seguridad limitada varían en naturaleza y 2-23 2-24 2-25 2-26 2-27 2-29 3-1 3-2
Carácter General N° 461 (en adelante "NCG 461”) ) y su modificación la a Norma de Carácter oportunidad y son menos extensos que para un encargo de seguridad razonable. En consecuencia, el
 NuestraN°519
General responsabilidad
 (NCG 519) emitida por la Comisión para el Mercado Financiero (en adelante 201-2 206-1 301-2 301-3 302-1 302-4 303-1 303-3
 nivel de seguridad obtenido en un encargo de seguridad limitada es sustancialmente menor que la
"CMF”) por el periodo comprendido entre el 01 de enero de 2024 y el 31 de diciembre de seguridad que se habría obtenido si hubiéramos realizado un encargo de aseguramiento razonable. 303-4 305-1 305-2 306-1 306-3 306-4 401-2 403-2
 Nuestra responsabilidad es expresar una conclusión de seguridad limitada de los contenidos e
2024. 403-4 403-5 403-6 404-1 404-2 408-1 417-1
 indicadores incluidos en la Memoria Integrada para el período finalizado en diciembre de Nuestra Independencia y controles de calidad
 2024, que
Nuestra han sido presentados de acuerdo con los Estándares GRI, SASB y NCG 461, en
 responsabilidad Respecto de los indicadores antes señalados, podemos afirmar que no se ha puesto de manifiesto
 base a los procedimientos que hemos realizado y la evidencia obtenida. Hemos realizado Hemos cumplido con las normas pertinentes de conducta profesional y el código de ética aplicables ningún aspecto que nos haga creer que los indicadores incluidos en la Memoria Integrada para el
 nuestra responsabilidad
Nuestra revisión de seguridad limitada
 es expresar unadeconclusión
 acuerdo con de la Norma Internacional
 seguridad limitada de los sobre
 contenidos e a la práctica contable y aquellas relacionadas con las revisiones de seguridad limitada, emitidos por periodo finalizado en diciembre 2024 de Compañia Cervecerias Unidas S.A., no han sido
 International Standard on Assurance Engagements Other than Audits
indicadores incluidos en la Memoria Integrada para el período finalizado en diciembre or Reviews of Historical
 de diversos organismos profesionales de contabilidad, que se basan en los principios fundamentales de Marzo 31, 2025
 elaborados, en todos sus aspectos materiales, de acuerdo con Estándares del Global Reporting
 Financial Information (ISAE 3000), emitida por el International Auditing
2024, que han sido presentados de acuerdo con los Estándares GRI, SASB y NCG 461, en and Assurance integridad, objetividad, competencia profesional y debido cuidado, confidencialidad y Sres. Compañia Cervecerias
 Initiative, Sustainability Unidas S.A.
 Accounting Standards Board y la Norma de Carácter General N° 461.
 Standard
base a los Board (IAASB).que
 procedimientos Estahemos
 normarealizado
 requiere yque planifiquemos
 la evidencia y realicemos
 obtenida. este trabajo
 Hemos realizado comportamiento profesional. Página 4
 para obtener una seguridad limitada, respecto de los indicadores incluidos
nuestra revisión de seguridad limitada de acuerdo con la Norma Internacional sobre en la Memoria
 Integrada 2024,
International estén exentos
 Standard de errores
 on Assurance materiales.Other than Audits or Reviews of Historical
 Engagements Otras responsabilidades
 La firma aplica la Norma Internacional de Control de Calidad 1, Control de Calidad para Firmas que
Financial Information (ISAE 3000), emitida por el International Auditing and Assurance Realizan Auditorías y Revisiones de Estados Financieros, y Otras Revisiones de Seguridad y
 Una revisión
Standard Board de(IAASB).
 seguridadEstalimitada
 normaimplica
 requierela realización de procedimientos
 que planifiquemos y realicemos(queesteconsisten
 trabajo Servicios Relacionados, y en consecuencia mantiene un sistema integral de control de calidad que • La preparación de la Memoria Integrada 2024, así como el contenido de esta, es responsabilidad
 principalmente en realizar consultas a la gerencia y a otros dentro de la
para obtener una seguridad limitada, respecto de los indicadores incluidos en la Memoriaentidad y aplicar Marzo 31,
 incluye 2025 y procedimientos documentados con respecto al cumplimiento de los requisitos
 políticas de la Sociedad, que además es responsable de definir, adaptar y mantener los sistemas de
 procedimientos
Integrada analíticos
 2024, estén y dedeotro
 exentos tipo,materiales.
 errores según corresponda) y evaluar la evidencia obtenida. éticos, las normasCervecerias
 Sres. Compañia Unidas
 profesionales, S.A.
 los requisitos legales y reglamentarios aplicables. gestión y control interno de los que se obtiene la información.
 Los procedimientos también incluyen la evaluación de la consistencia de los indicadores Página 3
 incluidos
Una en la
 revisión deMemoria
 seguridadIntegrada
 limitada para
 implicael período finalizado
 la realización en diciembre de(que
 de procedimientos 2024 de acuerdo
 consisten • Nuestra responsabilidad es emitir una carta de verificación independiente, basada en los
 con el Estándaren GRI, SASB y NCG a461. Conclusiones procedimientos aplicados en nuestra revisión.
principalmente realizar consultas la gerencia y a otros dentro de la entidad y aplicar
procedimientos analíticos y de otro tipo, según corresponda) y evaluar la evidencia obtenida.
 El proceso de verificación se realizó en base a los indicadores incluidos en la Memoria Integrada • Este informe ha sido preparado exclusivamente en interés de la Sociedad, de acuerdo con los
Los procedimientos también incluyen la evaluación de la consistencia de los indicadores
 2024, una vez definidos por la Administración en su proceso de materialidad. El detalle de los términos establecidos en las condiciones comerciales de la propuesta de servicios.
incluidos en la Memoria Integrada para el período finalizado en diciembre de 2024 de acuerdo
 indicadores que forman parte del proceso de verificación se señalan a continuación:
con el Estándar GRI, SASB y NCG 461.
 • Hemos realizado nuestro trabajo de acuerdo con las normas de independencia requeridas por el
 Indicadores CMF NCG N°461: Código de Ética de la IFAC.
 1 2.1 2.2 2.3 3.1 3.2 3.3 3.4 3.5 3.6 3.7
 • Las conclusiones de la revisión son válidas para la última versión de la Memoria Integrada
 Deloitte® se refiere a Deloitte Touche Tohmatsu Limited una compañía privada limitada por garantía, de Reino Unido, y a su red de firmas miembro, cada una de las cuales es una
 entidad legal separada e independiente. Por favor, vea en www.deloitte.com/cl/acercade la descripción detallada de la estructura legal de Deloitte Touche Tohmatsu Limited y sus
 4.1 4.2 4.3 5.1 5.2 5.3 5.4 5.5 5.6 5.7 5.8 2024, recibido el 27 de marzo de 2025.
 firmas miembro.
 5.9 6.1 6.2 6.3 6.4 6.5 7.1 7.2 8.1 8.2 8.3
 Deloitte Touche Tohmatsu Limited es una compañía privada limitada por garantía constituida en Inglaterra & Gales bajo el número 07271800, y su domicilio registrado: Hill House,
 1 Little New Street, London, EC4A 3TR, Reino Unido. 8.4 8.5 9.1 9.2 10 11 12 Saluda atentamente a Ustedes,
Deloitte® se refiere a Deloitte Touche Tohmatsu Limited una compañía privada limitada por garantía, de Reino Unido, y a su red de firmas miembro, cada una de las cuales es una
entidad legal separada e independiente. Por favor, vea en www.deloitte.com/cl/acercade la descripción detallada de la estructura legal de Deloitte Touche Tohmatsu Limited y sus
 Indicadores Sustainability Accounting Standards Board SASB:
firmas miembro.
 FB-AB-000.A
Deloitte Touche Tohmatsu Limited es una compañía privada limitada por garantía constituida en Inglaterra & Gales bajo el número 07271800, y su domicilio registrado: Hill House,
1 Little New Street, London, EC4A 3TR, Reino Unido. FB-AB-000.B FB-AB-000.C FB-AB-130a.1 FB-AB-140a.1
 FB-AB-140a.2 FB-AB-270a.1 FB-AB-270a.2 FB-AB-270a.3 FB-AB-270a.4 Roberto Espinoza
 FB-AB-410a.1 FB-AB-410a.2 FB-AB-430a.1 FB-AB-440a.1 FB-AB-440a.2 Socio
 FB-NB-000.A FB-NB-000.B FB-NB-000.C FB-NB-110a.1 FB-NB-130a.1
 FB-NB-140a.1 FB-NB-140a.2 FB-NB-260a.1 FB-NB-260a.2 FB-NB-270a.1
Memoria Integrada 2024 / 9.3 Verificación independiente FB-NB-270a.2 FB-NB-270a.3 FB-NB-270a.4 FB-NB-410a.1 FB-NB-410a.2 174

[pág. 176]
Capítulos / 1 2 3 4 5 6 7 8 9 Sustentabilidad 10 11 12
Sustentalia
 Carta De Conformidad Resultados: Resumen
 Sustentalia ha sido contratado por Compañía Cervecerías Unidad S.A. y sus filiales (CCU)
 TABLA 1: Resumen de Resultados de Indicadores ICES
 Verificación Independiente de Avances para la revisión independiente de los avances del Indicador Compuesto de Estrategia de
 Sustentabilidad definidos en las metas corporativas al año 2030, con el fin de asegurar la calidad de
 Indicador Compuesto de Estrategia de Sustentabilidad Temática Código Indicador Meta 2030
 Resumen
 los datos a reportar en su memoria anual integrada. Los datos reportados para CCU son precisos,
 2024
 completos, coherentes, transparentes y libres de errores u omisiones materiales.
 De nuestra consideración: 1.1 Consumo de agua industrial 2,08 HL/HL 2,67 Hl / HL
 1 Equilibrio Hídrico
 1.2 Iniciativas de reposición hídrica 1/año 2 Nivel de aseguramiento: Razonable
 Sustentalia ha realizado el servicio de revisión independiente de los avances del Indicador Compuesto
 de Estrategia de Sustentabilidad (ICES) de CCU S.A. de acuerdo con lo siguiente: Valorización de residuos sólidos Alcance
 2.1 100% 99,4%
 industriales TABLA 2: Unidades incluidas en la evaluación, en forma adicional a CCU.
 Periodo: 01/01/2024 – 31/12/2024 Envases y embalajes reutilizables, Unidad Instalación
 2.2 100% 99,95% (1) Coinco (Chile)
 2 Vocación Circular reciclables y/o compostables Aguas CCU-Nestlé Chile S.A.
 Empresa: CCU S.A. Porvenir (Casablanca, Chile)
 Contenido de material reciclado en envases Cervecería Austral S.A. Austral (Punta Arenas, Chile)
 2.3 50% 30,7% (1)
 y embalajes Cervecería Kunstmann S.A. Kunstmann (Valdivia, Chile)
 Indicadores ICES:
 2.4 Toneladas recuperadas de plástico PET 400 ton/año 386,6 ton Luján (Buenos Aires, Argentina)
 Compañía Industrial Cervecera S.A. Salta (Argentina)
 Código Indicador 3.1 Huella de Carbono kg CO2e/hl
 4,41 3,17 Santa Fe (Argentina)
 1.1 Reducción de consumo de agua industrial kg CO2 / hl kg CO2 / hl Quilicura (Santiago, Chile)
 Cervecera CCU Chile Limitada
 Temuco (Chile)
 1.2 Iniciativas de reposición hídrica 3 Desafío Climático 3.2 Uso de Energía Eléctrica Renovable 75% 84%
 Ovalle (Chile)
 2.1 Valorización de residuos sólidos industriales Porcentaje de reducción de emisiones en Compañía Pisquera de Chile S.A.
 Monte Patria (Chile)
 3.3 20% No aplica Salamanca (Chile)
 2.2 Envases y embalajes reutilizables, reciclables y/o compostables Logística
 Sotaquí (Chile)
 2.3 Contenido de material reciclado en envases y embalajes Abastecimiento Porcentaje de Materias primas estratégicas Embotelladora CCU Renca (Santiago, Chile)
 4 4.1 50% 29,3% Embotelladoras Chilenas Unidas S.A. Renca Modelo (Santiago, Chile)
 2.4 Toneladas recuperadas de plástico PET Responsable certificadas
 Antofagasta (Chile)
 3.1 Huella de carbono en Alcances 1 y 2 5.1
 Ser reconocidos como empleador de
 1 Certificado 1 Certificado Fábrica de Envases Plásticos S.A. Renca (Santiago, Chile)
 Experiencia Ser excelencia (Certificación RRHH) Transportes CCU Limitada 26 centros de distribución en Chile
 3.2 Utilización de Energía Eléctrica Renovable 5
 CCU Cachapoal Andes (Totihue, Chile)
 3.3 Porcentaje de reducción de emisiones en Logística 5.2 Clima laboral 85% 86%
 Isla Maipo (Chile)
 Viña San Pedro Tarapacá S.A.
 4.1 Porcentaje de Materias primas estratégicas certificadas 6.1
 Crecimiento sostenido de Primera
 * *
 Lontue (Chile)
 Pasión por Preferencia Molina (Chile)
 5.1 Ser reconocidos como empleador de excelencia (Certificación RRHH) 6
 el consumidor Milotur S.A. Pan de Azúcar (Montevideo, Uruguay)
 5.2 Clima laboral 6.2 N° de Iniciativas aceleradoras de JPMV 25 22
 Quilicura (Santiago, Chile)
 Manantial S.A. Coronel (Chile)
 6.1 Crecimiento sostenido de Primera Preferencia 7.1 Implementación Programa CRÁ(1) 100% 100%
 Disfrute Puerto Montt (Chile)
 6.2 N° de Iniciativas aceleradoras de "Juntos por un Mejor Vivir" 7
 Consciente Implementación de Programa Vivamos Ciudadela (Argentina)
 Compañía Industrial Cervecera S.A.
 7.1 Implementación Programa CRÁ 7.2 100% 100% Allen (Argentina)
 Bien - Vida Sana(1)
 Warnes (Bolivia)
 7.2 Implementación de Programa Vivamos Bien - Vida Sana Bebidas Bolivianas BBO S.A.
 8.1 Implementación de Planes comunitarios (1) 100% 100% Santa Cruz (Bolivia)
 8.1 Implementación de Planes de relacionamiento comunitarios Bebidas del Paraguay S.A. San Antonio I (Paraguay)
 Apertura nacional de Museo Limache- Finca La Celia (Argentina)
 8.2 Apertura nacional de Museo Limache 8.2 100% 100% Finca La Celia S.A.
 Según Presupuesto 2024 Bodega San Juan (Argentina)
 8.3 N° de Clientes impactados en programas de capacitaciones y/ o financiamiento 8 Progreso País N° de Clientes impactados en programas de Compañía Industrial Cervecera S.A. 11 Centros de distribución y 2 Centros de almacenamiento
 8.3 30.000 18.604 Comercial Patagona Limitada Centro Distribución (Punta Arenas, Chile)
 capacitaciones y/o financiamiento
 8.4 Proveedores significativos adheridos a Guía de Buenas Prácticas - Proveedor CCU - El límite organizacional se estableció siguiendo el enfoque de control operacional.
 Proveedores significativos adheridos a Guía
 8.4 90% 92% - Destinatario: uso interno y publicación externa.
 de Buenas Prácticas
 *Información de naturaleza confidencial (1) Resultados Chile
 La verificación independiente de los indicadores, ha sido realizada a través de una revisión crítica, Conclusión
 usando como referencia:
 CCU proporcionó la Declaración de Indicador Compuesto de Estrategia de Sustentabilidad
  Procedimiento de Indicador Compuesto de Estrategia de Sustentabilidad (ICES), (ICES) e Indicadores Compuestos Medio Ambientales (ICMA) para el periodo 01/01/2024 –
  Procedimiento de Indicador Compuesto Medioambiental (ICMA), 31/12/2024. Los resultados se encuentran en Tabla 1.
  Procedimiento Directivo de Excelencia Operacional (PDEO) vigentes,
  ISO 14064-1:2018 (para Alcances 1 y 2) Marianne Oelker Javiera Labbé Sustentalia concluye hay evidencia suficiente que los Indicadores reportados son materialmente
 Revisión Técnica Dirección Técnica correctos y es una representación fiel de la información y datos disponibles y que ha sido elaborada de
 Fecha de Carta de Conformidad: 27 de Marzo de 2025
 acuerdo a los procedimientos de la Compañía y la ISO 14064-1 vigente.
 Sustentalia-CCU 03-2025v2
 Mateo de Toro y Zambrano 1491 of 206 , La Reina, Santiago-Chile. www.sustentalia.cl Mateo de Toro y Zambrano 1491 of 206 , La Reina, Santiago-Chile. www.sustentalia.cl Mateo de Toro y Zambrano 1491 of 206 , La Reina, Santiago-Chile. www.sustentalia.cl
 1 2 3
Memoria Integrada 2024 / 9.3 Verificación independiente 175

[pág. 177]
10
 Capítulos / 1 2 3 4 5 6 7 8 9 10 Hechos relevantes o esenciales 11 12
 Durante el período enero – diciembre 2024, Compañía Cervecerías Unidas S.A. informó a la
 CMF, Bolsas de Valores y al mercado, en el carácter de esencial o relevante, lo siguiente:
 6 de marzo de 2024
 Informa propuesta de dividendo: En cumplimiento de lo dispuesto en los artículos 9 y 10 inciso
 segundo de la Ley N° 18.045, en la Norma de Carácter General N° 30 y en la Circular N° 660 de la
 CMF, se informa en carácter de Hecho Esencial que el Directorio de CCU, en sesión celebrada el 6
 de marzo de 2024, acordó proponer a la próxima Junta Ordinaria de Accionistas el reparto de un
 dividendo definitivo bajo el N° 268 de $31.430.069.484 correspondiente al 29,75% de la utilidad líquida
 distribuible del ejercicio terminado el 31 de diciembre de 2023, ascendente a $105.652.728.197, que
 implica un reparto por acción de $85,06042. Este dividendo definitivo es de carácter adicional, el que
 sumado al dividendo provisorio N° 267 pagado en noviembre de 2023, ascendente a $31.961.654.790
 y equivalente al 30,25% de la referida utilidad líquida, del cual $31.695.819.644 es dividendo mínimo
 obligatorio y $265.835.146 dividendo definitivo adicional, ascienden al total de $63.391.724.274
 equivalente al 60,00% de la utilidad líquida distribuible del ejercicio terminado el 31 de diciembre
 Hechos relevantes
 de 2023. Este dividendo definitivo se propondrá pagar a contar del día 30 de abril de 2024 a los
 accionistas que se encuentren inscritos en el registro respectivo a la medianoche del quinto día hábil
 anterior a dicha fecha, esto es, a la medianoche del día 24 de abril de 2024.
 o esenciales
Memoria Integrada 2024 176

[pág. 178]
Capítulos / 1 2 3 4 5 6 7 8 9 10 Hechos relevantes o esenciales 11 12
17 de abril 2024 operaciones, manteniendo en todo momento su continuidad operacional. (iii) En concreto, con la asesoría de
En cumplimiento de lo dispuesto en el artículo 9° e inciso segundo del artículo 10° de la Ley N° 18.045 y de la técnicos expertos, el día 25 de septiembre se trabajó en las etapas de contención, erradicación y recuperación.
Sección II N° 1 literal 2.2.A de la Norma de Carácter General N° 30 de la CMF, en relación a lo dispuesto en el Lo anterior ha permitido la reposición gradual de los sistemas informáticos afectados, los que se espera se
artículo 68 de la Ley N° 18.045, se informa en el carácter de Hecho Esencial que en Junta Ordinaria de Accionistas normalicen totalmente a la brevedad posible. 2. Relevante. De acuerdo a lo establecido en el artículo 9° y en
de la sociedad, celebrada el día 17 de abril de 2024, resultaron elegidos como directores, por un período de el inciso segundo del artículo 10° de la Ley N° 18.045, y a lo dispuesto en la Norma de Carácter General N°
tres años, Francisco Pérez Mackenna, Pablo Granifo Lavín, Rodrigo Hinzpeter Kirberg, María Gabriela Cadenas, 30, CCU reporta como Hecho Esencial lo siguiente: (i) CCU ha tomado conocimiento el día 26 de septiembre
Carlos Molina Solís, Marc Gross, Rory Cullinan, Oscar Hasbún Martínez y Vittorio Corbo Lioi, siendo éste último que el Incidente de Ciberseguridad tuvo como consecuencia la fuga de información, cuyo contenido y alcance
designado en calidad de director independiente de conformidad con lo dispuesto en el artículo 50 bis de la Ley está en evaluación. (ii) Una vez que concluyan los trabajos de análisis forense digital respecto al Incidente de
N° 18.046. Asimismo, en sesión extraordinaria de Directorio celebrada con igual fecha, el Directorio designó a Ciberseguridad, de resultar aplicable, CCU actualizará el contenido de esta comunicación. (iii) Al 26 de septiembre
Francisco Pérez Mackenna como Presidente del Directorio y a Carlos Molina Solís como Vicepresidente. En la de 2024, no se cuenta con información que permita proyectar los efectos financieros sobre los activos, pasivos
misma sesión, el director independiente Vittorio Corbo Lioi designó como miembros del Comité de Directores o resultados de CCU producto de la materia informada como Hecho Esencial, los que de existir serán oportuna
a los directores Carlos Molina Solís y Rodrigo Hinzpeter Kirberg, quedando de esta manera conformado dicho y debidamente informados a la CMF y al mercado en general.
Comité por los directores Corbo, Molina e Hinzpeter. Finalmente, se informa que en la referida sesión de
Directorio, y en cumplimiento de lo dispuesto en la Ley Sarbanes-Oxley, el Directorio designó como miembros 27 septiembre 2024
del Comité de Auditoría a los directores Vittorio Corbo Lioi y Carlos Molina Solís, y al director Rodrigo Hinzpeter A fin de mantener al mercado y público en general debidamente informado, se complementa la comunicación
Kirberg en calidad de observador. que se hiciera con fecha 26 de septiembre de 2024 como Hecho Esencial en los siguientes términos: (i) En
 relación a las etapas de contención, erradicación y recuperación respecto al Incidente de Ciberseguridad, CCU
 7 agosto 2024 puede confirmar que no existe ni ha existido propagación de la amenaza a terceros, incluyendo sus clientes y
En virtud de lo establecido en el artículo 9° e inciso segundo del artículo 10° de la Ley N° 18.045, en los proveedores. (ii) En relación a la fuga de información, CCU puede confirmar que cuenta con respaldos inmutables
artículos 146 y 147 de la Ley N° 18.046 sobre Sociedades Anónimas y en las Normas de Carácter General de todos sus archivos digitales. Se informa, asimismo, que con la asesoría de técnicos expertos, CCU sigue
N° 30 y N° 501 de la CMF, se comunica con carácter de Hecho Esencial de CCU que, en sesión de Directorio realizando los trabajos de análisis forense digital respecto al Incidente de Ciberseguridad y, de resultar aplicable,
celebrada con fecha 7 de agosto de 2024, se aprobó el nuevo texto de su Política de Operaciones Habituales actualizará el contenido de esta comunicación. Como fuera indicado, se señala que CCU ha mantenido en todo
con Partes Relacionadas, el que se acompaña a dicha comunicación como anexo. Se informa, asimismo, momento su continuidad operacional.
que la referida política se encontrará a disposición de los accionistas de CCU en las oficinas sociales y en
el sitio web www.ccuinvestor.com, sección Gobierno Corporativo, subsección Lineamientos de Gobierno 6 noviembre 2024
Corporativo, de conformidad con lo preceptuado por el literal b) del artículo 147 de la Ley N° 18.046 sobre Informa dividendo provisorio N° 269: De conformidad con lo dispuesto en la Circular N° 660 de la CMF, se
Sociedades Anónimas. comunica, en el carácter de información relevante, que el Directorio de Compañía Cervecerías Unidas S.A., en
 sesión ordinaria celebrada con igual fecha, acordó con cargo a las utilidades del ejercicio 2024, el reparto de un
 26 septiembre 2024 dividendo provisorio N° 269 de $ 117,5 por acción, ascendiendo el monto total a repartir a $ 43.416.587.460.
Se comunica: 1. Antecedentes. En relación a lo que se informa como Hecho Esencial en el numeral 2. siguiente: Se informó, asimismo, que el pago de este dividendo se efectuará a contar del día 28 de noviembre de 2024,
(i) El día 25 de septiembre CCU tomó conocimiento que algunos de sus sistemas informáticos – en las áreas a los accionistas que se encuentren inscritos en el Registro de Accionistas a la medianoche del quinto día hábil
de venta y distribución – se vieron afectados por un incidente causado por un agente externo (el “Incidente de anterior a la fecha de pago, esto es, el día 22 de noviembre de 2024. Adicionalmente, se indica que tienen
Ciberseguridad”). (ii) CCU cuenta con planes y protocolos de prevención, detección y respuesta frente a casos derecho a este dividendo todas las acciones de la Compañía, ya que todas son de una misma serie. Se adjuntó
como el Incidente de Ciberseguridad, los que permitieron contener el impacto del mismo en sus servicios y formulario N° 1 requerido por la Circular N° 660 de la CMF.
Memoria Integrada 2024 177

[pág. 179]
11
 Capítulos / 1 2 3 4 5 6 7 8 9 10 11 Comentarios de accionistas y del Comité de Directores 12
 Durante el año 2024 no hubo propuestas efectuadas por el Comité de Directores al Directorio
 de Compañía Cervecerías Unidas S.A. que no hubiesen sido recogidas por este último, ni se
 formularon comentarios o proposiciones por accionistas relativas a la marcha de los negocios
 sociales, a ser incluidos en un anexo de la memoria.
Comentarios de accionistas
 y del Comité de Directores
Memoria Integrada 2024 178

[pág. 180]
12
 Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
 Informes financieros
 Los Estados Financieros Consolidados de CCU S.A. y sus filiales correspondiente al ejercicio
 terminado al 31 de diciembre 2024, se encuentran disponibles en nuestra página web de relación
 con inversionistas en la sección Reportes Financieros, y en el sitio web de la Comisión para el
 Mercado Financiero. Ambos links se muestran a continuación:
 Ver en www.ccuinvestor.com Ver en www.cmfchile.cl
 Anexos
Memoria Integrada 2024 179

[pág. 181]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Datos generales
Razón Social
Compañía Cervecerías Unidas S.A. Adicionalmente, en la 46a Junta Extraordinaria de Accionistas celebrada el día 18 de junio de 2013,
Sociedad anónima abierta se acordó, entre otros, aumentar el capital de la sociedad, modificando al efecto los estatutos de la
Nombres de fantasía: “C.C.U.” y “CCU”. misma, según consta de escritura pública a que se redujo el acta de dicha Junta, otorgada con igual
RUT: 90.413.000-1
 fecha en la Notaría de Santiago de don Eduardo Javier Diez Morello, cuyo extracto se inscribió a fojas
 48.216 bajo el N° 32.190 del Registro de Comercio de Santiago del año 2013 y se publicó en el Diario
Domicilio legal Oficial de fecha 25 de junio del mismo año.
Ciudad de Santiago. Dirección Casa Matriz: Avda. Vitacura N° 2670, Piso 23, Las Condes, Región Metropolitana. Casilla
Postal: 33. Código Postal: 7650054. Teléfono: (56-2) 2427-3000
www.ccu.cl / www.ccuinvestor.com Objeto social
 a) La fabricación, elaboración y comercialización de cervezas, bebidas alcohólicas, aguas gaseosas
Equipo de Relación con Inversionistas y bebidas en general; b) La producción, elaboración y comercialización de alimentos de cualquier
Joaquín Trejo Darraidou / Claudio Las Heras Olivares / Carolina Burgos Méndez clase u origen, y en especial la pesca o caza; c) La administración, manejo y explotación de predios
investor@ccuinvestor.com - Teléfono: (56-2) 2427-3195
 agrícolas, forestales o de aptitud forestal, como la transformación, industrialización y comercialización
 de productos agrícolas, ganaderos y forestales; d) La fabricación y comercio de envases de todo
Empresa de auditoría externa
PricewaterhouseCoopers Consultores, Auditores y Compañía Limitada. tipo y para cualquier uso; e) El transporte terrestre, aéreo, marítimo y fluvial, por cuenta propia o
 ajena; f) La producción y comercialización de maquinarias, vehículos, elementos y equipos para fines
 agrícolas, mineros, pesqueros, industriales, de construcción, comerciales y de uso doméstico, sus
Constitución accesorios y repuestos; g) La industria de la construcción, el desarrollo de negocios inmobiliarios y
Compañía Cervecerías Unidas S.A. se constituyó por escritura pública de 8 de enero de 1902, otorgada la promoción de las actividades turísticas; h) La realización de actividades y negocios relacionados
ante el entonces Notario de Valparaíso don Pedro Flores Zamudio, autorizándose su existencia mediante con la minería y la explotación, producción y comercialización de cualquier fuente de energía
Decreto Supremo N° 889 de 19 de marzo de 1902, inscritos a fojas 49 vta. N° 45 del Registro de Comercio susceptible de aprovechamiento industrial o doméstico; i) La computación electrónica, la asesoría en
de Valparaíso del año 1902 y publicados en el Diario Oficial de fecha 24 de marzo del mismo año. la administración, organización y desarrollo de empresas; j) La ejecución de mandatos, comisiones
 y corretajes y la participación, en conformidad a la ley, en empresas de objeto bancario, de servicios
Por acuerdo adoptado en la 44a Junta General Extraordinaria de Accionistas celebrada el día 4 de financieros, de seguros, de warrants, de almacenamiento y depósitos de mercaderías, y en la
junio de 2001, se reformó el estatuto de la sociedad, trasladando el domicilio social de la ciudad de administración de fondos mutuos y previsionales; y k) Comprar y en general adquirir, vender y en
Valparaíso a la ciudad de Santiago, entre otras modificaciones, y fijando un texto refundido de dicho general enajenar, y permutar toda clase de valores, entendiéndose por tales cualesquiera títulos
estatuto, todo lo cual consta de escritura pública a que se redujo el acta de dicha Junta, otorgada con transferibles, incluyendo acciones, opciones a la compra y venta de acciones, bonos, debentures,
igual fecha ante la Notario de Valparaíso doña María Ester Astorga Lagos, cuyo extracto se inscribió a cuotas de fondos mutuos, planes de ahorro, efectos de comercio, y en general todo título de
fojas 18.149, bajo el N° 14.600 del Registro de Comercio de Santiago del año 2001 y se publicó en el crédito o inversión; así como también, los valores emitidos o garantizados por el Estado, por las
Diario Oficial de fecha 13 de junio del mismo año. instituciones públicas centralizadas o descentralizadas y por el Banco Central de Chile.
Memoria Integrada 2024 180

[pág. 182]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Índice GRI
Nombre Código Solicitud específica Página
GRI 1: Fundamentos 1 Declaración de uso e Índice GRI 6
 2-1 Detalles organizacionales 180
 2-2 Entidades incluidas en la presentación de informes de sostenibilidad No reportado.
 2-3 Período de objeto del informe, frecuencia y punto de contacto 6, 180
 2-4 Actualización de la información 6
 2-5 Verificación externa 174, 175
 2-6 Actividades, cadena de valor y otras relaciones comerciales 105
 2-7 Empleados 84, 85, 87
 2-8 Trabajadores que no son empleados No reportado.
 2-9 Estructura y composición de la gobernanza 37, 50, 52, 56
 2-10 Designación y selección del máximo órgano de gobierno No reportado.
 2-11 Presidente del máximo órgano de gobierno 42
 2-12 Función del máximo órgano de gobierno en la supervisión de la gestión de impactos 39, 149
 2-13 Delegación de la responsabilidad para manejo de impactos 59
 2-14 Función del máximo órgano de gobierno en la presentación de informes de sostenibilidad 45
 2-15 Conflictos de interés 34
GRI 2:
 2-16 Comunicación de inquietudes críticas 50
Contenidos Generales
 2-17 Conocimientos colectivos del máximo órgano de gobierno 37, 40, 41
 2-18 Evaluación del desempeño del máximo órgano de gobierno No reportado.
 2-19 Políticas de remuneración 46, 58
 2-20 Proceso para determinar la remuneración 46
 Este indicador es considerado
 2-21 Ratio de compensación total anual
 estratégico y confidencial para CCU.
 2-22 Declaración sobre la estrategia de desarrollo sostenible 33, 35, 80
 2-23 Compromisos y políticas 33, 79
 2-24 Incorporación de los compromisos y políticas 33
 2-25 Procesos para remediar los impactos negativos 69, 145
 2-26 Mecanismos para solicitar asesoramiento y plantear inquietudes 69
 2-27 Cumplimiento de la legislación y las normativas 145, 146
 2-28 Afiliación y asociaciones 118
 2-29 Enfoque para la participación de los grupos de interés 70
 2-30 Convenios de negociación colectiva No reportado.
 3-1 Proceso de determinación de los temas materiales 75
GRI 3:
 3-2 Lista de temas materiales 75
Temas Materiales
 3-3 Gestión de los temas materiales No reportado.
Memoria Integrada 2024 181

[pág. 183]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Nombre Código Solicitud específica Página
 201-1 Valor económico directo generado y distribuido No reportado.
GRI 201: 201-2 Implicaciones financieras y otros riesgos y oportunidades derivados del cambio climático 67
Desempeño económico 201-3 Obligaciones del plan de beneficios definidos y otros planes de jubilación No reportado.
 201-4 Asistencia financiera recibida del gobierno No reportado.
GRI 202: 202-1 Ratios entre el salario de categoría inicial estándar por género y el salario mínimo local No reportado.
Presencia en el mercado 202-2 Proporción de altos ejecutivos contratados en la comunidad local No reportado.
GRI 203: Impactos económicos 203-1 Inversiones en infraestructura y servicios apoyados No reportado.
indirectos 203-2 Impactos económicos indirectos significativos No reportado.
GRI 204: Prácticas de adquisición 204-1 Proporción de gasto en proveedores locales No reportado.
 205-1 Operaciones evaluadas en función de los riesgos relacionados con la corrupción No reportado.
GRI 205:
 205-2 Comunicación y formación sobre políticas y procedimientos anticorrupción No reportado.
Anticorrupción
 205-3 Incidentes de corrupción confirmados y medidas tomadas No reportado.
GRI 206: Competencia desleal 206-1 Acciones jurídicas relacionadas con la competencia desleal y las prácticas monopólicas y contra la libre competencia 63, 69, 146
 207-1 Enfoque fiscal No reportado.
 207-2 Gobernanza fiscal, control y gestión de riesgos No reportado.
GRI 207: Fiscalidad
 207-3 Participación de los grupos de interés y gestión de sus inquietudes en manera fiscal No reportado.
 207-4 Presentación de informes país por país No reportado.
 301-1 Materiales utilizados por peso o volumen No reportado.
GRI 301: Materiales 301-2 Insumos reciclados utilizados 155
 301-3 Productos y materiales de envasado recuperados 155
 302-1 Consumo de energía dentro de la organización 158
 302-2 Consumo de energía fuera de la organización No reportado.
GRI 302: Energía 302-3 Intensidad energética No reportado.
 302-4 Reducción del consumo energético 158
 302-5 Reducción de los requerimientos energéticos de productos y servicios No reportado.
 303-1 Interacción con el agua como recurso compartido 152, 153
 303-2 Gestión de los impactos relacionados con los vertidos de agua No reportado.
GRI 303: Agua y efluentes 303-3 Extracción de agua 152
 303-4 Vertidos de agua 152
 303-5 Consumo de agua 152
 305-1 Emisiones directas de GEI (Alcance 1) 156
 305-2 Emisiones indirectas de GEI asociadas a la energía (Alcance 2) 156
 305-3 Otras emisiones indirectas de GEI (Alcance 3) No reportado.
GRI 305: Emisiones 305-4 Intensidad de las emisiones de GEI 156
 305-5 Reducción de las emisiones de GEI 157
 305-6 Emisiones de sustancias que agotan la capa de ozono (ODS) No reportado.
 305-7 Óxidos de nitrógeno (NOx), óxidos de azufre (SOx) y otras emisiones significativas al aire No reportado.
Memoria Integrada 2024 182

[pág. 184]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Nombre Código Solicitud específica Página
 306-1 Generación de residuos e impactos significativos relacionados con los residuos 154
 306-2 Gestión de impactos significativos relacionados con los residuos No reportado.
GRI 306: Residuos 306-3 Residuos generados 154
 306-4 Residuos no destinados a eliminación 154
 306-5 Residuos destinados a eliminación No reportado.
GRI 308: Evaluación ambiental 308-1 Nuevos proveedores que han pasado filtros de evaluación y selección de acuerdo con los criterios ambientales No reportado.
de proveedores 308-2 Impactos ambientales negativos en la cadena de suministro y medidas tomadas No reportado.
 401-1 Contrataciones de nuevos empleados y rotación de personal No reportado.
GRI 401: Empleo 401-2 Prestaciones para los empleados a tiempo completo que no se dan a los empleados a tiempo parcial o temporales 98
 401-3 Permiso parental No reportado.
GRI 402: Relaciones
 402-1 Plazos de aviso mínimo sobre cambios operacionales No reportado.
trabajador-empresa
 403-1 Sistema de gestión de la salud y la seguridad en el trabajo. No reportado.
 403-2 Identificación de peligros, evaluación de riesgos e investigación de incidentes 90
 403-3 Servicios de salud en el trabajo No reportado.
 403-4 Participación de los trabajadores, consultas y comunicación sobre salud y seguridad en el trabajo 91
 403-5 Formación de trabajadores sobre salud y seguridad en el trabajo. 96
GRI 403:
 403-6 Promoción de la salud de los trabajadores 98
Salud y seguridad
 Prevención y mitigación de los impactos para la salud y la seguridad en el trabajo directamente vinculados a través
 403-7 137
 de las relaciones comerciales
 403-8 Cobertura del sistema de gestión de la salud y la seguridad en el trabajo No reportado.
 403-9 Lesiones por accidente laboral. No reportado.
 403-10 Dolencias y enfermedades laborales No reportado.
 404-1 Promedio de horas de formación al año por empleado 95
GRI 404: Formación y
 404-2 Programas para desarrollar las competencias de los empleados y programas de ayuda a la transición 93
enseñanza
 404-3 Porcentaje de empleados que reciben evaluaciones periódicas del desempeño y desarrollo profesional No reportado.
GRI 405: Diversidad e igualdad 405-1 Diversidad en órganos de gobierno y empleados No reportado.
de oportunidades 405-2 Ratio entre salario básico y la remuneración de mujeres y de hombres No reportado.
GRI 406: No discrimincación 406-1 Casos de discriminación y acciones correctivas emprendidas No reportado.
GRI 407: Libertad de asociación 407-1 Operaciones y proveedores en los que el derecho a la libertad de asociación y la negociación colectiva podría estar No reportado.
y negociación colectiva en riesgo
GRI 408: Trabajo infantil 408-1 Operaciones y proveedores con riesgo significativo de casos de trabajo infantil 59
GRI 409: Trabajo forzoso u
 409-1 Operaciones y proveedores con riesgo significativo de casos de trabajo forzoso u obligatorio No reportado.
obligatorio
GRI 410: Prácticas en materia
 410-1 Personal de seguridad capacitado en políticas o procedimientos de derechos humanos No reportado.
de seguridad
Memoria Integrada 2024 183

[pág. 185]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Nombre Código Solicitud específica Página
GRI 411: Derechos de los
 411-1 Casos de violaciones de los derechos de los pueblos indígenas No reportado.
pueblos indígenas
 413-1 Operaciones con programas de participación de la comunidad local, evaluaciones de impacto y programas de desarrollo No reportado.
GRI 413: Comunidades locales
 413-2 Operaciones con impactos negativos significativos -reales o potenciales- en las comunidades locales No reportado.
GRI 414: Evaluación social de 414-1 Nuevos proveedores que han pasado filtros de selección de acuerdo con criterios sociales. No reportado.
los proveedores 414-2 Impactos sociales negativos en la cadena de suministro y medidas tomadas. No reportado.
GRI 415: Política pública 415-1 Contribuciones a partidos y/o representantes políticos. No reportado.
GRI 416 Salud y seguridad de 416-1 Evaluación de los impactos de las categorías de productos y servicios en la salud y la seguridad No reportado.
los clientes 416-2 Casos de incumplimiento relativos a los impactos de las categorías de productos y servicios en la salud y la seguridad No reportado.
 417-1 Requerimientos para la información y el etiquetado de productos y servicios 138
GRI 417:
 417-2 Casos de incumplimiento relacionados con la información y el etiquetado de productos y servicios No reportado.
Marketing y etiquetado
 417-3 Casos de incumplimiento relacionado con comunicaciones de marketing No existieron durante el 2024.
GRI 418: Privacidad del cliente 418-1 Reclamaciones fundamentadas relativas a violaciones de la privacidad del clientes y pérdida de datos del cliente No reportado.
(*) GRI 304 - Biodiversidad no aplica.
Memoria Integrada 2024 184

[pág. 186]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Filiales (subsidiarias) y Coligadas AGUAS CCU-NESTLÉ CHILE S.A.
(Asociadas y Negocios conjuntos) de Razón Social
 Naturaleza jurídica
 AGUAS CCU-NESTLÉ CHILE S.A.
 Sociedad anónima cerrada
Compañía Cervecerías Unidas S.A. Domicilio
 Avda. Presidente Eduardo Frei Montalva N° 1.500, comuna de Renca, Región
 Metropolitana
 Capital suscrito y pagado M$ 49.799.375
 % participación total en 2024 50,1000% (50,1000% en 2023)
 % de la inversión sobre el 0,9423%
 activo total de la matriz
 Directores Titulares(*) Eduardo Ffrench-Davis Rodríguez (Presidente)
Al 31 de diciembre de 2024(1)(2) Felipe Benavides Almarza
 Rodrigo Camacho
 Felipe Dubernet Azócar
 Andrés Eyzaguirre Larraín
 Patricio Jottar Nasrallah
 Rachel Muller Galvao
 Gerente General Rubén Marrero Guerrero
 Objeto Social/ Actividades
 El objeto de la sociedad es la producción, envasado, distribución, comercialización y venta en todo el territorio
 de la República de Chile de aguas minerales y de aguas envasadas purificadas o no, ambas con o sin sabor y/o
 con o sin gas, transparentes y sin color, envasadas para su consumo directo, tanto nacionales como importadas.
 Esta sociedad desarrolla actividades de elaboración, envasado, distribución y comercialización de aguas
 minerales, purificadas y saborizadas bajo marcas propias, contratos de licencia o de distribución.
 Principales contratos con la matriz
 Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos).
 Vinculación futura proyectada
 Se proyecta que esta sociedad continúe desarrollando sus actividades de producción, envasado, distribución,
 comercialización y venta de aguas minerales y de aguas envasadas purificadas o no, con o sin sabor y/o con o
 sin gas, transparentes y sin color, envasadas para su consumo directo, entre otros, vinculándose con la matriz a
 través de contratos de servicios compartidos.
(1) El porcentaje actual de participación sobre las filiales y coligadas que se informa, es aquel porcentaje que mantiene la empresa
 matriz directa o entidad inversora sobre sus filiales o coligadas, respectivamente. (*) Los directores señores Felipe Benavides Almarza, Felipe Dubernet Azócar y Eduardo Ffrench-Davis Rodríguez son Ejecutivos
(2) El capital suscrito y pagado de aquellas filiales y coligadas denominadas en su origen a una moneda distinta del peso chileno Principales de la matriz y el director señor Patricio Jottar Nasrallah es Gerente General de la misma.
 (M$ o miles de CLP) se convierten a miles de pesos chilenos de acuerdo al tipo de cambio de cierre del ejercicio 2024. La señora Rachel Muller Galvao renunció a su cargo de director con efecto al 1 de febrero de 2025.
Memoria Integrada 2024 185

[pág. 187]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
 La sociedad es administrada por Embotelladoras Chilenas Unidas S.A., quien podrá actuar por intermedio de sus propios
 BEBIDAS ECUSA SpA apoderados o de uno o más mandatarios que designe especialmente para este efecto mediante escritura pública.
 (**) Con fecha 2 de septiembre de 2024, la sociedad celebró un contrato de compraventa de activos vinculados a la operación de
Razón Social BEBIDAS ECUSA SpA Red Bull en Chile, traspasando dichos activos a Red Bull Chile SpA.
Naturaleza jurídica Sociedad por acciones
 Avda. Presidente Eduardo Frei Montalva N° 1.500, comuna de Renca, Región
Domicilio Metropolitana CCU INVERSIONES II SpA1
Capital suscrito y pagado M$ 1.000
% participación total en 2024 100,0000% (100,0000% en 2023) Razón Social CCU INVERSIONES II SpA (CCU Inversiones II)
 Naturaleza jurídica Sociedad por acciones
% de la inversión sobre el 0,2520%
activo total de la matriz Domicilio Avda. Vitacura N° 2.670, piso 23, comuna de Las Condes, Región Metropolitana
Administración(*) Carlos Anwandter Gibson Capital suscrito y pagado M$ 344.884.634
 Felipe Benavides Almarza % participación total en 2024 99,9602% (99,9547% en 2023)
 Juan Boned % de la inversión sobre el
 Antonio Cruz Stuven 7,7263%
 activo total de la matriz
 Stephanie de la Mare Martínez Administración(*) Felipe Benavides Almarza
 Felipe Dubernet Azócar Antonio Cruz Stuven
 Eduardo Ffrench-Davis Rodríguez Felipe Dubernet Azócar
 Patricio Jottar Nasrallah Patricio Jottar Nasrallah
 Sebastián Landi Sebastián Landi
 Daniel López Medina Gabriela Ugalde Romagnoli
 Josefina Prussing Millar
 Objeto Social/ Actividades
 Gabriela Ugalde Romagnoli
 El objeto de la sociedad es: (i) efectuar toda clase de inversiones en el exterior, en cualquier tipo de bienes,
Gerente General Eduardo Ffrench-Davis Rodríguez instrumentos financieros y efectos de comercio y, en particular, en acciones o derechos sociales de compañías
Objeto Social/ Actividades constituidas en el exterior, así como otorgar préstamos o cualquier otro tipo de financiamiento a entidades en el
El objeto de la sociedad es: (i) distribución, transporte, importación, exportación, compra, venta y comercialización exterior; (ii) Comprar y vender toda clase de valores y efectos de comercio emitidos en el extranjero, entendiendo
en general, en cualquier forma y a cualquier título, de todo tipo de bebidas analcohólicas ya sea por cuenta propia por tales, entre otros, acciones de entidades extranjeras transadas en bolsas de valores en el exterior, bonos
o ajena; (ii) arrendamiento, subarrendamiento y explotación de espacios publicitarios y prestación de servicios de emitidos y transados en el extranjero y cualquier otra clase de valores transados en bolsas de valores extranjeras;
comercialización y publicidad en general que diga relación con los bienes, productos, negocios y actividades referidos y (iii) realizar cualquier otra actividad acordada por las socias y que conduzca a los fines anteriormente señalados.
en el número (i) anterior; (iii) compra, venta, arrendamiento, importación, exportación y comercialización, en general, en Esta sociedad desarrolla actividades de inversión en el exterior, en particular, en acciones y/o derechos sociales
cualquier forma y a cualquier título, de todo tipo de bienes muebles; (iv) prestación de servicios de asistencia técnica, de compañías constituidas en el extranjero.
elaboración de políticas de marketing, publicidad y similares relacionadas con los fines sociales; (v) inversión de los Principales contratos con la matriz
frutos que produzca el desarrollo de su giro en todo tipo de bienes corporales e incorporales muebles e inmuebles; Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos).
y (vi) la realización de todos los actos y contratos necesarios y/o conducentes para el cumplimiento del objeto social.
 Vinculación futura proyectada
Esta sociedad desarrolla actividades de marketing y publicidad de bebidas analcohólicas.
 Se proyecta que esta sociedad continúe desarrollando actividades de inversión en el exterior, en particular, en
Principales contratos con la matriz acciones y/o derechos sociales de compañías constituidas en el extranjero, vinculándose con la matriz a través de
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos). contratos de servicios compartidos.
Vinculación futura proyectada(**)
Se proyecta que esta sociedad continúe vinculándose con la matriz a través de contratos de servicios compartidos (*) Los administradores señores Felipe Benavides Almarza, Antonio Cruz Stuven, Felipe Dubernet Azócar, Sebastián Landi y Gabriela
en el marco del desarrollo de actividades propias de su giro. Ugalde Rogmanoli son Ejecutivos Principales de la matriz y el administrador señor Patricio Jottar Nasrallah es Gerente General
 de la misma.
(*) El administrador y Gerente General señor Eduardo Ffrench-Davis Rodríguez, y los administradores señores Felipe Benavides La sociedad es administrada por Compañía Cervecerías Unidas S.A., quien podrá actuar por intermedio de sus propios
 Almarza, Juan Boned, Antonio Cruz Stuven, Felipe Dubernet Azócar, Sebastián Landi y Gabriela Ugalde Romagnoli son Ejecutivos apoderados o de uno o más mandatarios que designe especialmente para este efecto mediante escritura pública de la que
 Principales de la matriz y el administrador señor Patricio Jottar Nasrallah es Gerente General de la misma. deberá tomarse nota al margen de la inscripción de la sociedad en el Registro de Comercio respectivo.
Memoria Integrada 2024 186

[pág. 188]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
 CCU INVERSIONES S.A. CERVECERA CCU CHILE LIMITADA
Razón Social CCU INVERSIONES S.A. (CCU Inversiones) CERVECERA CCU CHILE LIMITADA (Cervecera CCU Chile Ltda.,
Naturaleza jurídica Sociedad anónima cerrada Razón Social Cervecería CCU Ltda., Cervecería CCU, Cervecera CCU y Cervecera
 Avda. Presidente Eduardo Frei Montalva N° 1.500, comuna de Renca, Región CCU Chile)
Domicilio Metropolitana Naturaleza jurídica Sociedad de responsabilidad limitada
Capital suscrito y pagado M$ 270.761.066 Avda. Presidente Eduardo Frei Montalva N° 8.000, comuna de Quilicura, Región
 Domicilio Metropolitana
% participación total en 2024 99,0242% (99,0242% en 2023)
 Capital suscrito y pagado M$ 30.003.741
% de la inversión sobre el 11,9900%
activo total de la matriz % participación total en 2024 99,8064% (99,8064% en 2023)
Directores Titulares(*) Felipe Benavides Almarza (Presidente) % de la inversión sobre el 6,6658%
 Antonio Cruz Stuven (Vicepresidente) activo total de la matriz
 Felipe Dubernet Azócar Directores Titulares(*) Francisco Pérez Mackenna (Presidente)
Gerente General Felipe Dubernet Azócar María Gabriela Cadenas
Objeto Social/ Actividades Rory Cullinan
El objeto de la sociedad es: (i) inversión en sociedades dedicadas a: la elaboración, envase, compra, venta, distribución, Pablo Granifo Lavín
importación, exportación y comercialización de toda clase de bebidas alcohólicas, analcohólicas, aguas minerales, Marc Gross
jugos, néctares, concentrados, así como toda clase alimentos, de las materias primas necesarias para su elaboración, Rodrigo Hinzpeter Kirberg
de envases de todo tipo y de otros bienes corporales muebles que digan relación con la industria de las bebidas Patricio Jottar Nasrallah
y alimentos; la prestación de servicios de venta, comercialización, distribución, transporte y bodegaje; servicios de Carlos Molina Solís
asesoría y administración en materia de otorgamiento de créditos, recaudación, pago, cobranza y demás funciones Óscar Hasbún Martínez
de tesorería y caja; servicios de instalación, retiro, mantención y reparación de máquinas conservadoras, enfriadoras Gerente General Matías Bebin Subercaseaux
y/o expendedoras de bebidas alcohólicas, analcohólicas y alimentos en general, y de los elementos y accesorios de Objeto Social/ Actividades
aquéllas; y el arrendamiento, subarrendamiento y explotación de espacios publicitarios y prestación de servicios El objeto social es: (i) la elaboración, envasado, compra, venta, importación y exportación de todo tipo de bebidas
de publicidad en general; (ii) inversión, compra, venta, arrendamiento y en general la adquisición y enajenación alcohólicas y analcohólicas en general, aguas minerales, néctares, jugos, concentrados, artículos de plástico y
de bienes raíces corporales e incorporales así como la realización de toda clase de negocios inmobiliarios; (iii) sus derivados, materias primas, productos elaborados, partes, piezas, envases de todo tipo y de otros bienes
inversión, compra, venta, arrendamiento, y en general la adquisición y enajenación de bienes muebles, tanto corporales muebles que digan relación con la industria de las bebidas en general y del plástico; (ii) la elaboración,
corporales como incorporales, incluyendo acciones, opciones de compra y venta de acciones, bonos, debentures, comercialización, importación y exportación de alimentos de cualquier clase u origen; (iii) la producción, elaboración,
cuotas o derechos en sociedades y otros valores mobiliarios, instrumentos financieros y efectos de comercio en envasado, importación, exportación y comercialización de toda clase de alimentos; (iv) la explotación de negocios y/o
general, como asimismo de marcas comerciales y demás privilegios y/o derechos de propiedad industrial; y (iv) establecimientos destinados al expendio y comercialización de las bebidas y alimentos antes referidos y de bienes
celebración de cualquier otro acto o contrato concerniente a las actividades y negocios antes enunciados, así como corporales muebles en general, como supermercados, restaurantes, cafeterías y pubs, ya sea por sí o a través de
cualquier otro negocio similar o análogo, y todas las operaciones accesorias que fueren necesarias, conducentes terceros; (v) el transporte y distribución de esos productos o bienes, ya sea en el mismo estado o transformados;
o convenientes para la complementación del objeto social arriba expresado. (vi) la realización de publicidad y propaganda comercial, por cuenta propia o ajena, por sí o a través de terceros,
Esta sociedad desarrolla actividades de inversión, especialmente en acciones y derechos sociales. de los productos, bienes y establecimientos referidos precedentemente; (vii) la compra, venta, arrendamiento y
Principales contratos con la matriz explotación en general, por cuenta propia o ajena, de toda clase de espacios publicitarios en cualesquiera medios
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos). de comunicación y/o difusión, incluidos los medios de transmisión electrónica, internet, redes computacionales y de
Vinculación futura proyectada bases de datos en general, así como el desarrollo, implementación, creación y diseño en páginas web; (viii) la compra,
Se proyecta que esta sociedad continúe desarrollando actividades de inversión, especialmente en acciones y venta, importación, exportación, arrendamiento y en general la explotación de toda clase de elementos, artículos
derechos sociales, vinculándose con la matriz a través de contratos de servicios compartidos. y bienes o activos publicitarios, promocionales, de propaganda y/o marketing; (ix) la producción y realización, por
 cuenta propia o ajena de toda clase de publicaciones científicas, artísticas, culturales o de publicidad, directamente
(*) El director y Gerente General señor Felipe Dubernet Azócar y los directores señores Felipe Benavides Almarza y Antonio Cruz o a través de terceros; (x) el estudio y ejecución de todo tipo de obras y proyectos de ingeniería y construcción,
 Stuven son Ejecutivos Principales de la matriz. por cuenta propia o ajena, incluyendo la realización de loteos, subdivisiones y obras de urbanización en general;
Memoria Integrada 2024 187

[pág. 189]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
(xi) la compra, venta, arrendamiento, y en general la adquisición y enajenación de bienes raíces y la realización de Objeto social / Actividades
toda clase de negocios inmobiliarios; (xii) la compra, venta, arrendamiento, y en general la adquisición y enajenación El objeto de la sociedad es: (i) la producción, elaboración, compraventa, exportación, importación, representación,
de bienes muebles, tanto corporales como incorporales, incluyendo acciones, bonos, debentures y otros valores intermediación de cepas, cervezas y otros relacionados a éstas, al igual que aguas saborizadas, infusiones, bebidas
mobiliarios, instrumentos financieros y efectos de comercio en general, como asimismo de marcas comerciales analcohólicas de todo tipo y, en general, todo tipo de líquidos bebestibles; (ii) el almacenamiento y envase de cervezas
y demás privilegios y/o derechos de propiedad industrial; (xiii) la celebración de cualquier otro acto o contrato y licores en general y todo lo que en la actualidad o en el futuro o de cualquier manera se relacione con la industria
concerniente a las actividades industriales y de negocios antes enunciadas, así como cualquier otro negocio similar cervecera, sus derivados y líquidos bebestibles en general; (iii) la operación y prestación de servicios de restaurantes,
o análogo, incluyendo la realización de inversiones en sociedades dedicadas directa o indirectamente a cualquiera fuentes de soda, cafeterías y similares; y (iv) servicios de comida preparada en forma artesanal y, en general, la
de esas actividades, y todas las operaciones accesorias que fueren necesarias, conducentes o convenientes para la operación y la prestación de servicios propios de establecimientos que en general expenden bebidas y alimentos.
complementación del objeto social arriba expresado; y (xiv) la realización de cualquier otro negocio civil o de comercio Esta sociedad desarrolla actividades de elaboración, envasado y comercialización de cervezas bajo la marca Guayacán.
permisible que acuerden las socias. Vinculación futura proyectada
Esta sociedad desarrolla el negocio de elaboración, envasado y comercialización de cervezas en Chile, bajo marcas
 Se proyecta que esta sociedad continúe con el desarrollo y explotación de marcas comerciales a través del
propias y licenciadas.
 otorgamiento de licencias a sus accionistas.
Principales contratos con la matriz
Contrato de arrendamiento de marcas comerciales; contrato de prestación de servicios, asesoría y asistencia
técnica (contrato de servicios compartidos); contrato de arrendamiento de envases; contrato de arrendamiento
de planta industrial; y contrato de arrendamiento de depósitos y bodegas. CERVECERÍA BELGA DE LA PATAGONIA S.A.
Vinculación futura proyectada
Se proyecta que esta sociedad continúe desarrollando actividades de elaboración, envasado y comercialización de CERVECERÍA BELGA DE LA PATAGONIA S.A. (Cervecería Belga de
 Razón Social
cervezas, vinculándose con la matriz a través de contratos de servicios compartidos y contratos de arrendamiento la Patagonia)
de planta industrial, depósitos, bodegas y envases. Naturaleza jurídica Sociedad anónima cerrada
 Baquedano N° 1.899 interior, Coyhaique, Región de Aysén del General Carlos
(*) Los directores señores María Gabriela Cadenas, Rory Cullinan, Pablo Granífo Lavín, Marc Gross, Óscar Hasbún Martínez, Rodrigo Domicilio Ibáñez del Campo
 Hinzpeter Kirberg, Carlos Molina Solís y Francisco Pérez Mackenna son directores de la matriz, el Gerente General señor Matías
 Capital suscrito y pagado M$ 246.582
 Bebin Subercaseaux es ejecutivo principal y el director señor Patricio Jottar Nasrallah es Gerente General de la misma.
 % participación total en 2024 51,0061% (51,0061% en 2023)
 % de la inversión sobre el
 CERVECERA GUAYACÁN SpA2 activo total de la matriz
 0,0101%
 Directores Titulares Alejandro Kunstmann Ramos (Presidente)
Razón Social CERVECERA GUAYACÁN SpA
 Xavier Lombardo
Naturaleza jurídica Sociedad por acciones Daniel Rowlands Berger
Domicilio Calle Principal N° 33, Diaguitas, Vicuña, Región de Coquimbo Directores Suplentes Armin Kunstmann Telge
Capital suscrito y pagado M$ 982.762 Tomás Mosella Vial
% participación total en 2024 60,0002% (50,0004% en 2023) Mathias de Smet D’Olbecke
% de la inversión sobre el Gerente General José Luis Urrejola Sarmiento
 0,0093%
activo total de la matriz Objeto social / Actividades
Directores Titulares Alejandro Kunstmann Ramos (Presidente) El objeto social es la producción, compra, venta, distribución, importación, exportación y comercialización en cualquier
 Juan Esteban Fernández Ortuzar forma, por cuenta propia o de terceros, de toda clase de cervezas y de los insumos, máquinas, materias primas y
 Xavier Lombardo productos destinados a fabricarlas, producirlas, conservarlas y transportarlas, como también todas las actividades
 Tomás Mosella Vial relacionadas directa o indirectamente con las indicadas.
 Víctor Szecowka Latrach Esta sociedad desarrolla actividades de elaboración, envasado y comercialización de cerveza artesanal bajo la marca D’Olbek.
 Juan Esteban Toro Durán Vinculación futura proyectada
Gerente General Andrés Toro Olivos Se proyecta que esta sociedad continúe con el desarrollo y explotación de marcas comerciales a través del
 otorgamiento de licencias a sus accionistas.
Memoria Integrada 2024 188

[pág. 190]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
 CERVECERÍA KUNSTMANN S.A. 3 CIRCCULAR SpA4
 CERVECERÍA KUNSTMANN S.A. (Compañía Cervecera Kunstmann Razón Social CIRCCULAR SpA
Razón Social
 S.A., Cervecería Kunstmann, Kunstmann y CK) Naturaleza jurídica Sociedad por Acciones
Naturaleza jurídica Sociedad anónima cerrada Domicilio Caletera Américo Vespucio N°999, Comuna de Renca, Región Metropolitana
Domicilio Ruta T-350, N° 950, ciudad de Valdivia, Región de Los Ríos Capital suscrito y pagado M$ 10.000.000
Capital suscrito y pagado M$ 1.796.995 % participación total en 2024 100,0000%
% participación total en 2024 50,0007% (50,0007% en 2023) % de la inversión sobre el 0,3101%
% de la inversión sobre el 0,3610% activo total de la matriz
activo total de la matriz Administración(*) Carlos Anwandter Gibson
Directores Titulares(*) Armin Kunstmann Telge (Presidente) Felipe Benavides Almarza
 Fernando Barros Tocornal Juan Boned
 Matías Bebin Subercaseaux Antonio Cruz Stuven
 Patricio Jottar Nasrallah Felipe Dubernet Azócar
Directores Suplentes Michael Keutmann Kirchgaesser Patricio Jottar Nasrallah
 Cristóbal Kunstmann Ramos Sebastián Landi
 Xavier Lombardo Daniel Panelati
 Tomás Mosella Vial Evelyn Peña Barrera
Gerente General Alejandro Kunstmann Ramos Gabriela Ugalde Romagnoli
Objeto social / Actividades Gerente General Evelyn Peña Barrera
El objeto de la sociedad es: (i) la producción, compra, venta, distribución, importación, exportación, comercialización Objeto social / Actividades
en cualquier forma, por cuenta propia o de terceros, de toda clase de bienes y productos, en especial cervezas y El objeto de la sociedad es i) la fabricación, elaboración, transformación, reciclaje, valorización, producción,
cervezas sin alcohol, y de los insumos, máquinas, materias primas, productos destinados a fabricarlas, producirlas, importación, compra, venta, exportación, distribución y comercialización de todo tipo de productos e insumos de
conservarlas y transportarlas; como también todas las actividades relacionadas con las indicadas, así como sus plástico y sus derivados, materias primas, artículos, mercaderías, productos, implementos, partes, piezas, envases,
subproductos o derivados; y la elaboración, venta y distribución de alimento y suplemento para animales. y otros bienes corporales muebles que digan relación con la industria del plástico, su valorización y reciclaje; la
Esta sociedad desarrolla actividades de elaboración, venta y comercialización de cerveza Kunstmann y otras. distribución, comercialización, exportación, venta y en general la enajenación de estos bienes, ya sea en el mismo
Principales contratos con la matriz estado, reciclados o transformados; ii) la compra, venta, arrendamiento, importación, exportación y comercialización
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos); y contrato en general, en cualquier forma y a cualquier título, de todo tipo de bienes muebles; iii) prestación de servicios
de arrendamiento de bodega. de asistencia técnica y similares relacionadas con los fines sociales; iv) la inversión de los frutos que produzca el
 desarrollo de su giro en todo tipo de bienes corporales e incorporales, muebles e inmuebles; y v) la realización de
Vinculación futura proyectada
 todos los actos y contratos necesarios y/o conducentes para el cumplimiento del objeto social.
Se proyecta que esta sociedad continúe desarrollando actividades de elaboración, venta y comercialización de
 Esta sociedad desarrolla actividades de valorización, transformación y reciclaje de insumos plásticos y sus derivados.
cerveza, vinculándose con la matriz a través de contratos de servicios compartidos y contratos de arrendamiento
de bodega. Vinculación futura proyectada
 Se proyecta que esta sociedad continúe realizando actividades de valorización, transformación y reciclaje de insumos
(*) El director titular señor Matías Bebin Subercaseaux es ejecutivo principal de la matriz y el director titular señor Patricio Jottar plásticos y sus derivados para empresas relacionadas de Compañía Cervecerías Unidas S.A.
 Nasrallah es Gerente General de la misma.
 (*) Los administradores señores Felipe Benavides Almarza, Juan Boned, Antonio Cruz Stuven, Felipe Dubernet Azócar, Sebastián
 Landi y Gabriela Ugalde Romagnoli son Ejecutivos Principales de la matriz y el administrador señor Patricio Jottar Nasrallah es
 Gerente General de la misma.
 La sociedad es administrada por Millahue S.A., quién podrá actuar por intermedio de sus propios apoderados o de uno o más
 mandatarios que designe especialmente para este efecto mediante escritura pública.
Memoria Integrada 2024 189

[pág. 191]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
 COMERCIAL CCU S.A. COMPAÑÍA PISQUERA DE CHILE S.A.
Razón Social COMERCIAL CCU S.A. (Comercial CCU) Razón Social COMPAÑÍA PISQUERA DE CHILE S.A. (CPCH S.A.)
Naturaleza jurídica Sociedad anónima cerrada Naturaleza jurídica Sociedad anónima cerrada
 Avda. Presidente Eduardo Frei Montalva N° 1.500, comuna de Renca, Región Domicilio Avda. Vitacura N° 2.670, piso 25, comuna de Las Condes, Región Metropolitana
Domicilio Metropolitana Capital suscrito y pagado M$ 17.130.085
Capital suscrito y pagado M$1.268 46,0000% (46,0000% en 2023)
 % participación total en2024
% participación total en 2024 50,0000% (50,0000% en 2023) % de la inversión sobre el
% de la inversión sobre el 1,5487%
 0,0000% activo total de la matriz
activo total de la matriz Directores Titulares(*) Patricio Jottar Nasrallah (Presidente)
Directores Titulares(*) Antonio Cruz Stuven (Presidente) José Miguel Barros van Hövell tot Westerflier
 Matías Bebin Subercaseaux Mauricio Estay Urqueta
 Felipe Dubernet Azócar José Manuel Henríquez García Huidobro
Gerente General Matías Bebin Subercaseaux Nicolás Luksic Puga
Objeto social / Actividades Carlos Molina Solís
El objeto de la sociedad es: (i) producción, compra, venta, distribución, importación, exportación y comercialización Francisco Pérez Mackenna
de bebidas alcohólicas y analcohólicas en general y de toda clase de alimentos, de las materias primas necesarias Gerente General Domingo Jiménez Manterola
para su elaboración, de envases de todo tipo y de otros bienes corporales muebles que digan relación con la Objeto social / Actividades
industria de las bebidas y alimentos; así como la realización de inversiones en sociedades dedicadas al objeto El objeto de la sociedad es: (i) la producción, compra, venta, distribución, importación, exportación y comercialización
antes señalado; (ii) asesoría y prestación de servicios de venta y comercialización, por cuenta propia o ajena, de de bebidas alcohólicas y analcohólicas, especialmente pisco, y las materias primas necesarias para su elaboración,
bebidas alcohólicas y analcohólicas en general y de toda clase de alimentos, de sus materias primas, de envases de envases de todo tipo y de otros bienes muebles, materiales e inmateriales, que digan relación con la industria
de todo tipo y de otros bienes corporales muebles que digan relación con la industria de las bebidas y alimentos; de bebidas alcohólicas y analcohólicas, así como la realización de inversiones en sociedades dedicadas al objeto
(iii) realización de publicidad y propaganda comercial, por cuenta propia o ajena, por sí o a través de terceros, de antes señalado, siempre que tales inversiones no se efectúen en sociedades o personas jurídicas de otra naturaleza
los bienes referidos precedentemente; (iv) representación de empresas nacionales o extranjeras, en todo tipo relacionadas a alguno de los accionistas; y, (ii) en general, la sociedad podrá realizar todos los actos y celebrar
de negocios relacionados con el giro social; (v) otorgamiento de financiamiento a terceros, con recursos propios, todos los contratos que sean necesarios o conducentes a la realización del objeto social previsto.
mediante la celebración de toda clase de operaciones de crédito de dinero; y (vi) en general, realizar todos los Esta sociedad desarrolla actividades de elaboración, envasado y comercialización de pisco y licores bajo marcas
actos y celebrar todos los contratos que sean necesarios o conducentes al objeto social. propias, contratos de licencia o de distribución.
Esta sociedad desarrolla actividades de comercialización multicategoría de productos elaborados y/o comercializados
 Principales contratos con la matriz
por empresas relacionadas de Compañía Cervecerías Unidas S.A.
 Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos); y contrato
Principales contratos con la matriz de arrendamiento de oficinas.
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos).
 Vinculación futura proyectada
Vinculación futura proyectada Se proyecta que esta sociedad continúe desarrollando actividades de elaboración, envasado y comercialización
Se proyecta que esta sociedad continúe desarrollando actividades de comercialización multicategoría de productos de pisco y licores bajo marcas propias, contratos de licencia o de distribución, vinculándose con la matriz a través
elaborados y/o comercializados por empresas relacionadas de Compañía Cervecerías Unidas S.A., vinculándose de contratos de servicios compartidos y arrendamiento de oficinas.
con la matriz a través de contratos de servicios compartidos.
 (*) Los directores señores Carlos Molina Solís y Francisco Pérez Mackenna son directores de la matriz. El Gerente General señor
(*) El director y Gerente General señor Matías Bebin Subercaseaux y los directores señores Antonio Cruz Stuven y Felipe Dubernet Domingo Jiménez Manterola es ejecutivo principal y el director señor Patricio Jottar Nasrallah es Gerente General de la misma.
 Azócar son Ejecutivos Principales de la matriz.
Memoria Integrada 2024 190

[pág. 192]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
 CRECCU S.A. Principales contratos con la matriz
 Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos); y contrato
 de arrendamiento de oficinas.
Razón Social CRECCU S.A. (CRECCU)
 Sociedad anónima cerrada Vinculación futura proyectada
Naturaleza jurídica
 Se proyecta que esta sociedad continúe desarrollando actividades de desarrollo e implementación de sistemas de
 Avda. Presidente Eduardo Frei Montalva N°8.000, comuna de Quilicura, Región
Domicilio financiamiento y crédito a clientes, con recursos propios, utilizables en la adquisición de bienes comercializados por
 Metropolitana
 entidades relacionadas de la sociedad y/o de su matriz Compañía Cervecerías Unidas S.A., la prestación de servicios
Capital suscrito y pagado M$ 3.009.095 de administración de crédito y cobranza, el diseño e implementación de diversos programas de capacitación a
% participación total en 2024 99,9602% (99,9602% en 2023) sus clientes y la prestación de servicios y asesoría en materia de gestión de crédito y cobranza a distintas UENs,
% de la inversión sobre el vinculándose con la matriz a través de contratos de servicios compartidos y de arrendamiento de oficinas.
 0,1635%
activo total de la matriz
 Felipe Dubernet Azócar (Presidente) (*) Los directores señores Matías Bebin Subercaseaux, Felipe Dubernet Azócar y Bárbara Wolff Gopfert son Ejecutivos Principales
Directores Titulares(*)
 de la matriz.
 Matías Bebin Subercaseaux
 Jaime Binder Ross
 Tomás Mosella Vial D&D SpA
 Bárbara Wolff Gopfert
Gerente General Rodrigo Borgoño Undurraga Razón Social D&D SpA (D y D SpA)
Objeto social / Actividades Naturaleza jurídica Sociedad por acciones
La sociedad tiene por objeto: (i) desarrollo e implementación de sistemas de financiamiento y crédito bajo cualquier Avda. Presidente Eduardo Frei Montalva N° 7.050, Bodega 1, comuna de
modalidad autorizada por la ley; (ii) otorgamiento de financiamiento a terceros, con recursos propios, mediante la Domicilio Quilicura, Región Metropolitana
celebración de toda clase de operaciones de crédito de dinero; (iii) emisión de tarjetas de crédito utilizables en la Capital suscrito y pagado M$ 221.000
adquisición de bienes y en el pago de servicios vendidos o prestados por entidades relacionadas de la sociedad y/o
de su matriz Compañía Cervecerías Unidas S.A.; (iv) administración y operación, por sí o a través de terceros, de toda % participación total en 2024 51,0132% (51,0132% en 2023)
clase de sistemas de financiamiento permitidos por la ley, incluidas las tarjetas de crédito, con el propósito de poner % de la inversión sobre el 0,0387%
a disposición de terceros un medio de financiar la adquisición de bienes y contratación de servicios de empresas activo total de la matriz
relacionadas de la sociedad y/o de su matriz Compañía Cervecerías Unidas S.A.; (v) prestación de servicios y asesorías Directores Titulares(*) Domingo Jiménez Manterola (Presidente)
en materias de evaluación de riesgo, control de créditos y constitución de garantías de cualquier clase, sea que ello se Diego García Silva
verifique directamente por la sociedad o mediante la subcontratación de dichos servicios o asesorías; (vi) gestión de Rodrigo Jadue Roa
cobranza a terceros sea ésta de carácter judicial o extrajudicial, su administración y control, sea que ello se verifique Cristian Nordenflycht Bordeu
directamente por la sociedad o mediante la subcontratación de personas o empresas especializadas; (vii) prestación Diego Taggart Méndez
de toda clase de servicios financieros a terceros en conformidad a la ley; (viii) inversión en acciones, derechos sociales, Objeto social / Actividades
bonos, debentures, certificados de depósitos, toda clase de valores mobiliarios, efectos de comercio e instrumentos La sociedad tiene por objeto: (i) preparación, fabricación, compra, venta comercialización, importación y exportación
financieros de cualquiera especie; (ix) desarrollo e implementación, ya sea directamente o a través de terceros, así de toda clase de productos alimenticios de consumo humano; (ii) por cuenta propia o ajena, administrar y explotar
como apoyo al desarrollo e implementación, de proyectos y/o programas que fomenten, propendan o faciliten el establecimientos de comercio dedicados al expendio o venta de alimentos o bebidas directamente al público consumidor,
emprendimiento y crecimiento sustentable de terceros, incluyendo el otorgamiento de toda clase de créditos y la tanto en Chile como en el extranjero (dentro de este giro la sociedad podrá celebrar contratos de representación,
prestación de toda clase de servicios profesionales y técnicos, ya sea a través de consultorías, asesorías, estudios distribución, franchising, sociedad o cualquier otra forma de asociación, con empresas nacionales o extranjeras, dedicadas
y/o capacitaciones, entre otros; y, en general, cualquier otra actividad civil o comercial que se relacione directa o al rubro del expendio o venta de alimentos o bebidas); y (iii) en general, realizar todos los giros que estime conveniente
indirectamente con el objeto señalado precedentemente y que acuerden los accionistas. cuando así lo manifieste a lo menos dos tercios de las acciones suscritas y pagadas con derecho a voto.
Esta sociedad desarrolla actividades de financiamiento y crédito a clientes, con recursos propios, utilizables en la Esta sociedad desarrolla actividades de elaboración de variedades de sour y coctelería alcohólica y analcohólica.
adquisición de bienes comercializados por entidades relacionadas de la sociedad y/o de su matriz Compañía Cervecerías
 Vinculación futura proyectada
Unidas S.A., la prestación de servicios de administración de crédito y cobranza a distintas Unidades Estratégicas de
Negocios (UEN), y el diseño y la implementación de diversos programas de capacitación a sus clientes. Se proyecta que esta sociedad continúe desarrollando actividades de elaboración de variedades de sour y coctelería
 alcohólica y analcohólica.
 (*) El director señor Domingo Jiménez Manterola es ejecutivo principal de la matriz.
Memoria Integrada 2024 191

[pág. 193]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
 (vii) la prestación de servicios de asesoría, administración, coordinación y/o gestión en materia de otorgamiento
 EMBOTELLADORAS CHILENAS UNIDAS S.A.5 de créditos, recaudación, pago, cobranza y demás funciones de tesorería y caja; (viii) la prestación de servicios de
 asesoría, administración y control de inventarios de materiales de empaque, insumos, concentrados, productos
 EMBOTELLADORAS CHILENAS UNIDAS S.A. (CCU, CCU CHILE, terminados y demás activos de terceros, sean éstos sociedades relacionadas o no; (ix) la prestación de servicios de
Razón Social
 ECUSA, ECCU, ECCUSA, Embotelladora CCU y Embotelladora CCU S.A.) instalación, retiro, mantención y reparación de máquinas conservadoras, enfriadoras y/o expendedoras de bebidas
Naturaleza jurídica Sociedad anónima cerrada alcohólicas y analcohólicas en general así como toda clase de mercaderías, y de los elementos y accesorios de
 Avda. Presidente Eduardo Frei Montalva N° 1.500, comuna de Renca, Región aquéllas; (x) el arrendamiento, subarrendamiento y explotación de espacios publicitarios y prestación de servicios de
Domicilio Metropolitana publicidad en general; y (xi) la celebración de cualquier otro acto o contrato concerniente a las actividades industriales
Capital suscrito y pagado M$ 172.298.227 y de negocios antes enunciadas, así como cualquier otro negocio similar o análogo, y todas las operaciones accesorias
% participación total en 2024 98,8000% (98,8000% en 2023) que fueren necesarias, conducentes o convenientes para la complementación del objeto social arriba expresado.
 Esta sociedad desarrolla actividades de elaboración, envasado y comercialización de bebidas no alcohólicas y aguas
% de la inversión sobre el 12,7433% envasadas bajo marcas propias, contratos de licencia o de distribución.
activo total de la matriz
 Francisco Pérez Mackenna (Presidente) Principales contratos con la matriz
Directores Titulares(*)
 Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos); y contrato
 Carlos Molina Solís (Vicepresidente) de arrendamiento de planta industrial.
 María Gabriela Cadenas
 Vinculación futura proyectada
 Rory Cullinan
 Se proyecta que esta sociedad continúe desarrollando actividades de elaboración, envasado y comercialización de
 Pablo Granifo Lavín bebidas no alcohólicas y aguas envasadas bajo marcas propias, contratos de licencia o de distribución, vinculándose
 Marc Gross con la matriz a través de contratos de servicios compartidos y de arrendamiento de planta industrial.
 Óscar Hasbún Martínez
 Rodrigo Hinzpeter Kirberg (*) Los directores señores María Gabriela Cadenas, Rory Cullinan, Pablo Granifo Lavín, Marc Gross, Óscar Hasbún Martínez,
 Patricio Jottar Nasrallah Rodrigo Hinzpeter Kirberg, Carlos Molina Solís y Francisco Pérez Mackenna son directores de la matriz. El Gerente General
 Eduardo Ffrench-Davis Rodríguez señor Eduardo Ffrench-Davis Rodríguez es ejecutivo principal y el director señor Patricio Jottar Nasrallah es Gerente General
Gerente General
 de la misma.
Objeto social / Actividades
El objeto de la sociedad será: (i) la elaboración, envase, compra, venta, comercialización, distribución, importación y exportación
de toda clase de bebidas alcohólicas, analcohólicas, aguas minerales, jugos, néctares, concentrados, mermeladas, así como FÁBRICA DE ENVASES PLÁSTICOS S.A.
toda clase de productos y artículos alimenticios, ya sea por cuenta propia y/o ajena, y tomar representaciones nacionales y/o
extranjeras; (ii) la comercialización al por menor de bebidas analcohólicas en general y de mercaderías, entre otras formas, a Razón Social FÁBRICA DE ENVASES PLÁSTICOS S.A. (PLASCO S.A. y PLASCO)
través de la utilización de máquinas automáticas de expendio directo al público; (iii) la fabricación, elaboración, transformación,
gestión, reciclaje, valorización, producción, importación, compra, venta, exportación, distribución y comercialización de todo tipo Naturaleza jurídica Sociedad anónima cerrada
de productos e insumos de plástico y sus derivados, materias primas, artículos, mercaderías, productos, implementos, partes,
 Domicilio Calle Alberto Pepper N°1.551, comuna de Renca, Región Metropolitana.
piezas, envases y otros bienes corporales muebles que digan relación con la industria del plástico y su reciclaje; la distribución,
comercialización, exportación, venta y en general la enajenación de estos bienes, ya sea en el mismo estado, reciclados o Capital suscrito y pagado M$ 18.744.767
transformados; (iv) la compra, venta, arrendamiento y en general la adquisición y enajenación de bienes raíces corporales % participación total en 2024 95,8904% (95,8904% en 2023)
e incorporales y la realización de toda clase de negocios inmobiliarios; (v) la inversión, compra, venta, arrendamiento, % de la inversión sobre el 0,7788%
comodato y en general la adquisición y enajenación de bienes muebles, tanto corporales como incorporales, incluyendo activo total de la matriz
toda clase de equipos y máquinas expendedoras a industrias, oficinas y a personas naturales y jurídicas, opciones de Directores Titulares(*) Juan Boned (Presidente)
compra y venta de acciones, acciones, bonos, debentures, planes de ahorro, cuotas de fondos mutuos, cuotas o derechos Felipe Benavides Almarza
en sociedades, y otros valores mobiliarios, instrumentos financieros y efectos de comercio en general, como asimismo María Ángela Crestuzzo Bianchetti
de marcas comerciales y demás privilegios y/o derechos de propiedad industrial; (vi) la prestación de servicios de transporte Felipe Dubernet Azócar
aéreo y terrestre, de carga y pasajeros; arrendamiento, subarrendamiento, mantención y reparación de toda clase de vehículos;
 Juan Martín Vannicola
importación, distribución, compra y venta de partes, piezas y repuestos de los mismos y de accesorios e insumos
 Gerente General Daniel Panelati
para ellos; servicios de asesoría en materia de tráfico y transporte en general; y servicios de bodegaje y distribución
de materias primas, insumos, concentrados y/o productos terminados, sean éstos elaborados y/o comercializados
por Compañía Cervecerías Unidas S.A., cualesquiera de sus filiales, sociedades coligadas y/o por terceros;
Memoria Integrada 2024 192

[pág. 194]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Objeto social / Actividades Objeto social / Actividades
El objeto de la sociedad es: (i) la fabricación, elaboración, producción, importación, compra, exportación, venta, El objeto de la sociedad es la inversión en toda clase de bienes corporales e incorporales, incluyendo derechos
distribución y comercialización de todo tipo de productos de plástico y sus derivados, materias primas, artículos, en sociedades, acciones, valores mobiliarios, marcas comerciales, nombres de dominio, licencias o sub-licencias,
mercaderías, productos, implementos, partes, piezas, envases, y otros bienes corporales muebles que digan relación títulos de crédito y efectos de comercio, tanto en Chile como en el extranjero.
con la industria del plástico; (ii) la distribución, comercialización, exportación, venta, y en general la enajenación Esta sociedad desarrolla actividades de inversión en el exterior, en particular, en acciones y/o derechos sociales
de esos bienes, ya sea en el mismo estado o transformados; (iii) la realización de toda clase de actividades y la de compañías constituidas en el extranjero.
celebración de cualquier otro acto o contrato concerniente a la industria del plástico, y toda otra especie de insumos Principales contratos con la matriz
y elementos relacionados con los fines antedichos, así como cualquier otro negocio similar, análogo; y (iv) todas Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos).
las demás operaciones accesorias que fueren necesarias, conducentes o convenientes para la complementación
 Vinculación futura proyectada
del objeto social arriba expresado.
 Se proyecta que esta sociedad continúe desarrollando actividades de inversión en el exterior, en particular, en acciones
Esta sociedad desarrolla actividades de elaboración de envases y tapas plásticas.
 y/o derechos sociales de compañías constituidas en el extranjero, vinculándose con la matriz a través de contratos
Principales contratos con la matriz de servicios compartidos.
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos); contrato
de arrendamiento de planta industrial; contrato de arrendamiento de bodegas; y contrato de arrendamiento de (*) Los administradores señores Felipe Benavides Almarza, Antonio Cruz Stuven, Felipe Dubernet Azócar y Domingo Jiménez Manterola son
equipos y otros activos. Ejecutivos Principales de la matriz y el administrador señor Patricio Jottar Nasrallah es Gerente General de la misma.
Vinculación futura proyectada La sociedad es administrada por su matriz Compañía Pisquera de Chile S.A., que la ejercerá por intermedio de sus representantes o a
 través de mandatarios o delegados designados en la escritura pública de constitución o designados especialmente al efecto por escritura
Se proyecta que esta sociedad continúe desarrollando actividades de elaboración de envases y tapas plásticas,
 pública, de la cual se deberá tomar nota al margen de la inscripción social.
vinculándose con la matriz a través de contratos de servicios compartidos y contratos de arrendamiento de planta
industrial, bodegas, equipos y otros activos.
(*) Los directores señores Felipe Benavides Almarza, Juan Boned, Felipe Dubernet Azócar y Juan Martín Vannicola son Ejecutivos INVERSIONES INVEX CCU DOS LIMITADA
 Principales de la matriz.
 INVERSIONES INVEX CCU DOS LIMITADA (Inversiones Invex CCU
 Razón Social
 Dos Ltda., Invex CCU Dos Ltda., Invex CCU Dos e Invex Dos)
 INVERSIONES INTERNACIONALES SpA Naturaleza jurídica Sociedad de responsabilidad limitada
 Domicilio Avda. Vitacura N° 2.670, piso 23, comuna de Las Condes, Región Metropolitana
Razón Social INVERSIONES INTERNACIONALES SpA
 Capital suscrito y pagado M$ 38.865.235
Naturaleza jurídica Sociedad por acciones
 % participación total en 2024 99,8516% (99,8516% en 2023)
Domicilio Avda. Vitacura N° 2.670, piso 25, comuna de Las Condes, Región Metropolitana
 % de la inversión sobre el 5,4215%
Capital suscrito y pagado M$ 1.827.959
 activo total de la matriz
% participación total en 2024 100,0000% (100,0000% en 2023) Felipe Benavides Almarza (Presidente)
 Directores Titulares(*)
% de la inversión sobre el 0,0271% Antonio Cruz Stuven
activo total de la matriz Felipe Dubernet Azócar
Administración(*) Felipe Benavides Almarza Gerente General Felipe Dubernet Azócar
 Antonio Cruz Stuven
 Objeto social / Actividades
 Felipe Dubernet Azócar
 El objeto de la sociedad es: (i) efectuar toda clase de inversiones en el exterior, en cualquier tipo de bienes, instrumentos financieros
 Rodrigo Jadue Roa
 y efectos de comercio y, en particular, en acciones o derechos sociales de compañías constituidas en el exterior, así como otorgar
 Domingo Jiménez Manterola préstamos o cualquier otro tipo de financiamiento a entidades en el exterior; (ii) comprar y vender toda clase de valores y efectos de
 Patricio Jottar Nasrallah comercio emitidos en el extranjero, entendiendo por tales, entre otros, acciones de entidades extranjeras transadas en bolsas de
 valores en el exterior, bonos emitidos y transados en el extranjero y cualquier otra clase de valores transados en bolsas de valores
 extranjeras; y (iii) realizar cualquier otra actividad acordada por las socias y que conduzca a los fines anteriormente señalados.
 Esta sociedad realiza inversiones en el exterior, en particular, en acciones o derechos sociales de compañías constituidas en
 el extranjero.
Memoria Integrada 2024 193

[pág. 195]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Principales contratos con la matriz Vinculación futura proyectada
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos). Se proyecta que esta sociedad continúe desarrollando actividades de inversión en el exterior, en particular, en
Vinculación futura proyectada acciones y/o derechos sociales de compañías constituidas en el extranjero, vinculándose con la matriz a través de
Se proyecta que esta sociedad continúe desarrollando actividades de inversión en el exterior, en particular, en contratos de servicios compartidos.
acciones y/o derechos sociales de compañías constituidas en el extranjero, vinculándose con la matriz a través de
 (*) Los administradores señores Felipe Benavides Almarza, Antonio Cruz Stuven, Felipe Dubernet Azócar, Sebastián Landi y Gabriela
contratos de servicios compartidos.
 Ugalde Romagnoli son Ejecutivos Principales de la matriz y el administrador señor Patricio Jottar Nasrallah es Gerente General
 de la misma.
(*) El director y Gerente General señor Felipe Dubernet Azócar y los directores señores Felipe Benavides Almarza y Antonio Cruz La sociedad es administrada por Compañía Cervecerías Unidas S.A., quien podrá actuar por intermedio de sus propios
 Stuven son Ejecutivos Principales de la matriz. apoderados o de uno o más mandatarios que designe especialmente para este efecto mediante escritura pública de la que
 deberá tomarse nota al margen de la inscripción de la sociedad en el Registro de Comercio respectivo.
 INVERSIONES INVEX CCU LIMITADA
 LA BARRA S.A.
 INVERSIONES INVEX CCU LIMITADA (Inversiones Invex CCU Ltda.,
Razón Social
 Invex CCU Ltda., Invex CCU e Invex) Razón Social LA BARRA S.A. (LA BARRA)
Naturaleza jurídica Sociedad de responsabilidad limitada Naturaleza jurídica Sociedad anónima cerrada
 Avda. Presidente Eduardo Frei Montalva N° 1.500, comuna de Renca, Región Avda. Vitacura N° 2.670, piso 19, comuna de Las Condes, Región Metropolitana
Domicilio: Domicilio
 Metropolitana.
 Capital suscrito y pagado M$ 6.000.000
Capital suscrito y pagado M$ 192.787.916
 % participación total en 2024 99,0000% (99,0000% en 2023)
% participación total en 2024 66,6519% (66,6519% en 2023)
 % de la inversión sobre el 0,0655%
% de la inversión sobre el 9,4145% activo total de la matriz
activo total de la matriz
 Directores Titulares(*) Matías Bebin Subercaseaux (Presidente)
Administración(*) Felipe Benavides Almarza
 Eduardo Ffrench-Davis Rodríguez
 Antonio Cruz Stuven
 Pedro Herane Aguado
 Felipe Dubernet Azócar
 Domingo Jiménez Manterola
 Patricio Jottar Nasrallah
 Matías Rojas Reyes
 Sebastián Landi
 Álvaro Román Marambio
 Gabriela Ugalde Romagnoli
 Gerente General Juan Ignacio Junco Sotomayor
Objeto social / Actividades
El objeto de la sociedad es: (i) efectuar toda clase de inversiones en el exterior, en cualquier tipo de bienes, Objeto social / Actividades
instrumentos financieros y efectos de comercio y, en particular, en acciones o derechos sociales de compañías La sociedad tiene por objeto: (i) compra, venta, distribución, importación, exportación y comercialización de bebidas
constituidas en el exterior, así como otorgar préstamos o cualquier otro tipo de financiamiento a entidades en el alcohólicas y analcohólicas en general y de toda clase de alimentos; así como de toda clase de bienes muebles que
exterior; (ii) comprar y vender toda clase de valores y efectos de comercio emitidos en el extranjero, entendiendo digan relación con la industria de bebidas y alimentos, incluyendo su publicidad, promoción, venta y distribución,
por tales, entre otros, acciones de entidades extranjeras transadas en bolsas de valores en el exterior, bonos importación, exportación y comercialización; (ii) asesoría y prestación de servicios de venta, distribución, importación,
emitidos y transados en el extranjero y cualquier otra clase de valores transados en bolsas de valores extranjeras; exportación y comercialización, por cuenta propia o ajena, por sí o a través de terceros, de los productos y bienes
y (iii) realizar cualquier otra actividad acordada por las socias y que conduzca a los fines anteriormente señalados. referidos en el número (i) precedente; (iii) realización de actividades y/o prestación de servicios de planificación,
Esta sociedad realiza inversiones en el exterior, en particular, en acciones o derechos sociales de compañías publicidad y promoción, por cuenta propia o ajena, por sí o a través de terceros, que sean complementarios o
constituidas en el extranjero. estén relacionados con los productos y bienes antes enunciados; (iv) representación de empresas nacionales o
 extranjeras, en todo tipo de negocios relacionados con el objeto social; así como la realización de inversiones en
Principales contratos con la matriz
 sociedades dedicadas a dicho objeto; y (v) en general, cualquier otra actividad civil o comercial que se relacione
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos).
 directa o indirectamente con el objeto social y que acuerden los accionistas.
 Esta sociedad desarrolla actividades de venta y comercialización de bebidas alcohólicas y analcohólicas a través
 de plataformas digitales.
Memoria Integrada 2024 194

[pág. 196]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Principales contratos con la matriz MANANTIAL S.A.
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos).
Vinculación futura proyectada Razón Social MANANTIAL S.A.
Se proyecta que esta sociedad continúe desarrollando actividades de venta y comercialización de bebidas alcohólicas Sociedad anónima cerrada
 Naturaleza jurídica
y analcohólicas a través de plataformas digitales, vinculándose con la matriz a través de contratos de servicios
 Domicilio Los Robles N° 540, comuna de Quilicura, Región Metropolitana
compartidos.
 Capital suscrito y pagado M$ 3.647.737
(*) Los directores señores Matías Bebin Subercaseaux, Eduardo Ffrench-Davis Rodríguez, Pedro Herane Aguado y Domingo Jiménez % participación total en 2024 99,0775% (99,0775% en 2023)
 Manterola son Ejecutivos Principales de la matriz.
 Con fecha 5 de diciembre de 2024 la señora Cristina Birrell Berazadi renunció a su calidad de directora en la sociedad.
 % de la inversión sobre el 0,3025%
 activo total de la matriz
 Directores Titulares(*) Eduardo Ffrench-Davis Rodríguez (Presidente)
 Carlos Anwandter Gibson
 MAHINA SpA
 Christian Bravo Sauturel
 Gerente General Cristián Fajre Wipe
Razón Social MAHINA SpA
 Sociedad por acciones Objeto social / Actividades
Naturaleza jurídica
 El objeto de la sociedad es: (i) desarrollar, por cuenta propia o de terceros o asociada a terceros, toda clase de
Domicilio Caleta Hanga Roa O´Tai, S/N, Rapa Nui, Región de Valparaíso
 actividades relacionadas con el tratamiento y purificación de agua para el consumo, y producción y venta de agua
Capital suscrito y pagado M$ 1.150.000 con formulaciones especiales para fines específicos; su distribución, venta, y comercialización; así como el arriendo
% participación total en 2024 50,0909% (50,0909% en 2023) o venta de aparatos distribuidores automáticos y prestación de servicios complementarios que sean necesarios o
% de la inversión sobre el conducentes a la consecución de los fines anteriores; (ii) efectuar inversiones en toda clase de bienes inmuebles
 0,0164% o muebles, corporales e incorporales, y formar parte de sociedades de cualquier especie; y (iii) asimismo, la
activo total de la matriz
 Miguel Angel Rapu Pate (Presidente) sociedad podrá dedicarse a la fabricación, elaboración, preparación y producción de productos industriales y su
Directores Titulares
 comercialización.
 Armin Kunstmann Telge
 Esta sociedad desarrolla el negocio de producción, venta y distribución a clientes de aguas purificadas principalmente
 Xavier Lombardo
 en botellones sobre dispensadores, así como el arriendo o venta de aparatos dispensadores de agua, en el segmento
 Ana Rapu Edmunds
 home and office delivery.
Gerente General Ana Rapu Edmunds
 Principales contratos con la matriz
Objeto social / Actividades Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos).
El objeto de la sociedad es: (i) la elaboración, fabricación, producción, compra, venta, importación, exportación y,
 Vinculación futura proyectada
en general, la comercialización en todas sus formas, ya sea al por mayor o menor, por cuenta propia o ajena, de
 Se proyecta que esta sociedad continúe desarrollando sus actividades de producción, venta y distribución de aguas,
toda clase de productos alimenticios, comestibles y bebestibles incluyendo bebidas alcohólicas; (ii) la explotación
 así como también el arriendo o venta de aparatos dispensadores de agua, entre otros, vinculándose con la matriz
de bares, restaurantes, confiterías, parrillas, salón de fiestas, servicios de desayunos, almuerzos, cenas, venta de
 a través de contratos de servicios compartidos.
toda clase de comidas y bebidas y toda actividad relacionada con la gastronomía y la elaboración de comidas; (iii)
el otorgamiento, gestión y administración de franquicias, agencias, representaciones comerciales, distribución, (*) El director señor Eduardo Ffrench-Davis Rodríguez es ejecutivo principal de la matriz.
logística, compraventa por mayor o menor, importación, exportación, locación y sublocación de inmuebles; y (iv) la
compra, venta, permuta, comodato, explotación, arrendamiento y/o administración de bienes inmuebles y realizar
toda clase de mejoras de inmuebles propios o de terceros. A tales fines la sociedad tiene plena capacidad jurídica MILLAHUE S.A.6
para adquirir derechos, contraer obligaciones y ejercer todos los actos que no sean prohibidos por las leyes o por
su estatuto.
 Razón Social MILLAHUE S.A. (Inversiones Millahue y Millahue)
Esta sociedad desarrolla actividades de elaboración, envasado y comercialización de cervezas bajo la marca Mahina.
 Naturaleza jurídica Sociedad anónima cerrada
Vinculación futura proyectada
 Domicilio Avda. Vitacura N° 2.670, piso 23, comuna de Las Condes, Región Metropolitana
Se proyecta que esta sociedad continúe con el desarrollo y explotación de marcas comerciales a través del
otorgamiento de licencias a sus accionistas. Capital suscrito y pagado M$ 10.124.668
Memoria Integrada 2024 195

[pág. 197]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
% participación total en 2024 99,9773% (99,9621% en 2023) Objeto social / Actividades
% de la inversión sobre el El objeto de la sociedad es: (i) prestar servicios de transporte de carga; (ii) arrendamiento, subarrendamiento,
 0,5898% mantención y reparación de toda clase de vehículos; (iii) importación, distribución, compra y venta de partes,
activo total de la matriz
Directores Titulares(*) Felipe Benavides Almarza (Presidente) piezas y repuestos de los mismos y de accesorios e insumos para ellos; (iv) servicios de asesoría en materia de
 Antonio Cruz Stuven tráfico y transporte en general; (v) servicios de bodegaje y distribución de materias primas, insumos, concentrados
 y/o productos terminados, sean éstos elaborados y/o comercializados por Compañía Cervecerías Unidas S.A.,
 Felipe Dubernet Azócar
 cualesquiera de sus filiales y/o por terceros; (vi) servicios de asesoría, administración, coordinación y/o gestión
Gerente General Felipe Dubernet Azócar
 en materia de otorgamiento de créditos, recaudación, pago, cobranza y demás funciones de tesorería y caja; (vii)
Objeto social / Actividades servicios de asesoría, administración y control de inventarios de materiales de empaque, insumos, concentrados,
El objeto de la sociedad es: (i) la explotación de fuentes de agua mineral; (ii) la fabricación, distribución y productos terminados y demás activos de terceros, sean éstos sociedades relacionadas o no; y (viii) instalación,
comercialización de toda clase de productos naturales, bebidas analcohólicas y demás productos similares, como retiro, mantención y reparación de máquinas conservadoras, enfriadoras y/o expendedoras de bebidas alcohólicas
asimismo, de vinos, cervezas, productos lácteos y alimentos de cualquier origen, y de los insumos industriales tales y analcohólicas en general, y de los elementos y accesorios de aquellas.
como tapas tipo corona, envases de plástico y/o vidrio, cajas plásticas y etiquetas; y (iii) la realización de inversiones Esta sociedad presta servicios de logística, transporte y distribución a las diversas UEN.
en toda clase de bienes muebles e inmuebles, corporales o incorporales, tales como acciones, bonos, debentures, Principales contratos con la matriz
efectos de comercio, valores mobiliarios, y la venta y comercialización de los mismos. Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos); y contratos
Esta sociedad desarrolla actividades de inversión en toda clase de bienes muebles e inmuebles, corporales o de arrendamiento y subarrendamiento de oficinas y bodegas.
incorporales.
 Vinculación futura proyectada
Principales contratos con la matriz Se proyecta que esta sociedad continúe prestando servicios de logística, transporte y distribución a las diversas
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos). UEN, vinculándose con la matriz a través de contratos de servicios compartidos y contratos de arrendamiento y
Vinculación futura proyectada subarrendamiento de oficinas y bodegas.
Se proyecta que esta sociedad continúe desarrollando actividades de inversión en toda clase de bienes muebles e
inmuebles, corporales o incorporales, vinculándose con la matriz a través de contratos de servicios compartidos. (*) Los directores señores Felipe Benavides Almarza, Felipe Dubernet Azócar y Eduardo Ffrench-Davis Rodríguez son Ejecutivos
 Principales de la matriz.
(*) El director y Gerente General señor Felipe Dubernet Azócar y los directores señores Felipe Benavides Almarza y Antonio Cruz
 Stuven son Ejecutivos Principales de la matriz.
 VIÑA ALTAÏR SpA
 TRANSPORTES CCU LIMITADA
 VIÑA ALTAÏR SpA (Viñamar, Altaïr Vineyards & Winery, Viña Totihüe,
 Razón Social
Razón Social TRANSPORTES CCU LIMITADA (Transportes CCU Ltda.) Viña Altaïr – San Pedro y VA)
Naturaleza jurídica Sociedad de responsabilidad limitada Naturaleza jurídica Sociedad por Acciones
 Avda. Presidente Eduardo Frei Montalva N° 8.000, comuna de Quilicura, Región Dirección: Avda. Vitacura N° 2.670, piso 16, comuna de Las Condes, Región Metropolitana
Domicilio M$ 8.558.664
 Metropolitana Capital suscrito y pagado
Capital suscrito y pagado M$ 26.998 % participación total en 2024 100,0000% (100,0000% en 2023)
% participación total en 2024 98,0000% (98,0000% en 2023) % de la inversión sobre el 0,3023%
% de la inversión sobre el activo total de la matriz
 0,5704%
activo total de la matriz Administración(*) Germán Del Río López
Directores Titulares(*) Eduardo Ffrench-Davis Rodríguez (Presidente) Pedro Herane Aguado
 Felipe Benavides Almarza Vicente Rosselot Soini
 Felipe Dubernet Azócar Marcela Ruiz Hadad
Gerente General Álvaro Román Marambio
Memoria Integrada 2024 196

[pág. 198]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Objeto social / Actividades Gerente General Pedro Herane Aguado
La sociedad tiene por objeto: (i) producción, industrialización, comercialización, distribución, importación y Objeto social / Actividades
exportación, por cuenta propia o ajena, de toda clase de productos vitivinícolas; (ii) producción, industrialización, La sociedad tiene por objeto: (i) la producción, industrialización, comercialización, distribución, importación y
comercialización, distribución, importación, y exportación, por cuenta propia o ajena de vinos y licores y de las exportación por cuenta propia o ajena, de toda clase de productos agrícolas, en especial de los vitivinícolas; (ii) la
materias primas de los mismos; (iii) el aprovechamiento industrial y comercial de los subproductos y derivados de producción, industrialización, comercialización, distribución, importación y exportación, por cuenta propia o ajena,
vinos y licores, y de las materias primas de los mismos; iv) explotación de marcas comerciales; (v) prestación de de toda clase de bebidas, sean éstas vinos, licores, cervezas, o de cualquier naturaleza, alcohólicas o analcohólicas y
servicios relacionados con los rubros señalados en los numerales i) a iv) anteriores, así como servicios de asesoría, de las materias primas de las mismas, el aprovechamiento industrial y comercial de los subproductos y derivados de
marketing, ventas, enología, administración, organización, desarrollo de empresas y turismo; (vi) arrendamiento de los artículos que anteceden; (iii) la prestación de servicios relacionados con los mismos rubros así como servicios de
toda clase de bienes muebles e inmuebles; vii) representación de empresas nacionales y extranjeras en relación asesoría, marketing, ventas, enología, administración, organización y desarrollo de empresa; y (iv) la representación
con los rubros y actividades señalados en los numerales (i) a (vi) anteriores; y (viii) en general, la celebración de de empresas nacionales y extranjeras, la distribución y comercialización de los productos nacionales o importados
cualquier acto o contrato y el desarrollo de cualquier actividad relacionada directa o indirectamente con los rubros de los bienes anteriormente mencionados y de productos alimenticios en general.
y actividades señalados en los numerales (i) a (vi) anteriores. Esta sociedad desarrolla actividades de elaboración, envasado, venta, distribución, promoción y comercialización de
Esta sociedad desarrolla actividades de adquisición y desarrollo de marcas comerciales y la explotación de las vinos, espumantes y coolers, entre otros productos, bajo marcas propias o licenciadas para el mercado doméstico
mismas a través del otorgamiento de licencias a su matriz Viña San Pedro Tarapacá S.A. y exportaciones.
Vinculación futura proyectada Principales contratos con la matriz
Se proyecta que esta sociedad mantenga vigente las licencias de uso, elaboración, fabricación, envasado, venta, Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos); y contrato
promoción, distribución y comercialización de sus productos en todo el territorio extranjero y en Chile con su de subarriendo de oficinas.
matriz Viña San Pedro Tarapacá S.A. Vinculación futura proyectada
(*) El administrador señor Pedro Herane Aguado es ejecutivo principal de la matriz. Se proyecta que esta sociedad continúe desarrollando actividades de elaboración, envasado, venta, distribución
 La sociedad es administrada por Viña San Pedro Tarapacá S.A., que la ejercerá a través de mandatarios o delegados designados y comercialización de vinos, espumantes y coolers, entre otros productos, vinculándose con la matriz a través de
 especialmente al efecto por escritura pública de la cual se deberá tomar nota al margen de la inscripción social. contratos de servicios compartidos y de subarrendamiento de oficinas.
 (*) Los directores señores Pablo Granifo Lavín, Carlos Molina Solís y Francisco Pérez Mackenna son directores de la matriz, el
 Gerente General señor Pedro Herane Aguado es ejecutivo principal y el director señor Patricio Jottar Nasrallah es Gerente
 VIÑA SAN PEDRO TARAPACÁ S.A. General de la misma.
 VIÑA SAN PEDRO TARAPACÁ S.A. (VSPT, VSPT S.A., San Pedro
 S.A., San Pedro Wine Group, VSPT Wine Group, Grupo VSPT, SPWG,
Razón Social VOLCANES DEL SUR S.A.
 Southern Sun Wine Group, SSWG, San Pedro Tarapacá S.A., Viña
 Tarapacá S.A., Viña Tarapacá Ex Zavala S.A. y Viña San Pedro S.A.)
Naturaleza jurídica Sociedad anónima abierta Razón Social VOLCANES DEL SUR S.A.
Domicilio Avda. Vitacura N° 2.670, piso 16, comuna de Las Condes, Región Metropolitana
 Naturaleza jurídica Sociedad anónima cerrada
Capital suscrito y pagado M$ 123.808.521
 Domicilio Ruta T-350, N° 950, Valdivia, Región de Los Ríos
% participación total en 2024 85,1697% (84,7015% en 2023)
 Capital suscrito y pagado M$ 3.065.536
% de la inversión sobre el 8,1672%
activo total de la matriz % participación total en 2024 50,1000% (50,1000% en 2023)
Directores Titulares(*) Pablo Granifo Lavín (Presidente) % de la inversión sobre el 0,2960%
 Carlos Molina Solís (Vicepresidente) activo total de la matriz
 José Miguel Barros van Hövell tot Westerflier Directores Titulares Alejandro Kunstmann Barros (Presidente)
 Patricio Jottar Nasrallah Xavier Lombardo
 Carlos Mackenna Iñíguez Marcel Siburo Valenzuela
 Francisco Pérez Mackenna Gerente General Marcel Siburo Valenzuela
 Zhihao Yang
Memoria Integrada 2024 197

[pág. 199]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Objeto social / Actividades Gerente General Agustín González Avalis
El objeto de la sociedad es: (i) la adquisición y desarrollo de marcas comerciales y licencias de marcas, y la explotación Objeto social / Actividades
de las mismas sea directamente o a través de licencias o sublicencias otorgadas a terceros; (ii) la realización de La sociedad tiene por objeto realizar por cuenta propia, de terceros o asociada a terceros: (i) extracción, recolección,
actividades de planificación, publicitarias, y financieras que sean complementarias o digan relación con potenciar industrialización, producción, embotellado, distribución y comercialización en todas sus formas posibles de aguas
el desarrollo y valor de sus marcas comerciales o licencias de marcas; y (iii) la inversión en toda clase de bienes minerales, carbonatadas o no, saborizadas o no, con o sin agregado de jugo, y jugos en polvo, alimentos líquidos,
corporales e incorporales, incluyendo derecho en sociedades, acciones, valores mobiliarios, marcas comerciales, productos y subproductos derivados de aguas minerales, alimentos líquidos y aguas en general e insumos necesarios
títulos de crédito y efectos de comercio. Podrá además participar directa o indirectamente en la elaboración, para dichos productos y subproductos; (ii) compra, venta, distribución, importación y exportación y el ejercicio de
fabricación, embotellamiento, distribución, venta y comercialización de bebidas alcohólicas y no alcohólicas, ya comisiones, representaciones y consignaciones de los productos, subproductos derivados de su elaboración, y
sea por cuenta propia o de terceros, pudiendo, además participar en la industria alimenticia ya sea produciendo, mercaderías y materias primas vinculadas con los mismos.
distribuyendo, comercializando, importando o exportando. Esta sociedad se dedica a la extracción, envasado, distribución y comercialización en todas sus formas posibles de
Esta sociedad se dedica a la adquisición y desarrollo de marcas comerciales y la explotación de las mismas a través aguas minerales, ya sea por cuenta propia, de terceros o asociada a terceros.
del otorgamiento de licencias a sus accionistas. Vinculación futura proyectada
Vinculación futura proyectada Se proyecta que esta sociedad continúe desarrollando por cuenta propia, de terceros o asociada a terceros, la
Se proyecta que esta sociedad continúe desarrollando actividades de adquisición y desarrollo de marcas comerciales extracción, envasado, distribución y comercialización en todas sus formas posibles de aguas minerales.
y la explotación de las mismas a través del otorgamiento de licencias a sus accionistas.
 (*) El director titular señor Julio Freyre Aznárez y el director suplente señor Antonio Cruz Stuven son Ejecutivos Principales de la
 matriz, y el director titular señor Patricio Jottar Nasrallah es Gerente General de la misma.
2. FILIALES EN EL EXTRANJERO
 AGUAS DE ORIGEN S.A.7 ANDRIMAR S.A.
Razón Social AGUAS DE ORIGEN S.A. Razón Social ANDRIMAR S.A.
Naturaleza jurídica Sociedad anónima cerrada Naturaleza jurídica Sociedad anónima cerrada
Domicilio Suipacha N°1111, piso 18, Ciudad Autónoma de Buenos Aires, Argentina Tiburcio Gómez N° 1.330, Piso 3 Unidad A, 11300 Montevideo, Departamento
 Domicilio de Montevideo Uruguay.
Capital suscrito y pagado M$ 8.179.555
 50,1000% (50,0000% en 2023) Capital suscrito y pagado M$ 8.480
Participación total en 2024
% de la inversión sobre el % participación total en 2024 100,0000% (100,0000% en 2023)
 0,4010% % de la inversión sobre el
activo total de la matriz 0,0525%
Directores Titulares(*) Fernando Sanchis Sacchi (Presidente) activo total de la matriz
 Julio Freyre Aznárez (Vicepresidente) Directores Titulares(*) Sebastián Landi (Presidente)
 Henri Bruxelles Felipe Benavides Almarza
 Juan Carlos Garibaldi Antonio Cruz Stuven
 Andrés Pablo Glerean Francisco Díaz Fadic
 Philippe-Loic Jacob Gerente General Nicolás Novoa Cruz
 Patricio Jottar Nasrallah
Directores Suplentes Emmanuelle Marianne Bely
 Javier Caspani Zurbriggen
 Antonio Cruz Stuven
 María Cecilia Ghezzi
 Ezequiel Gussoni
 Matías Ledesma
 Ricardo Olivares Elorrieta
Memoria Integrada 2024 198

[pág. 200]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Objeto social / Actividades Objeto social / Actividades
El objeto de la sociedad es: (i) industrializar y comercializar en todas sus formas mercaderías, arrendamientos de La sociedad tiene por objeto dedicarse, por cuenta propia o asociada a terceros, en el país o en el extranjero,
bienes, obras y servicios, en los ramos y anexos: de alimentación, artículos del hogar y oficina, automotriz, bar, a operaciones industriales, comerciales, agropecuarias, forestales, inmobiliarias, de importación, exportación y
bazar, caucho, combustible, comunicaciones, construcción, cosmética, cueros, deportes, editorial, electrónica, servicios permitidos por la ley. Podrá comprar, vender, distribuir, arrendar y negociar productos, materias primas,
electrotécnica, enseñanza, espectáculos, extractivas, ferretería, fotografías, fibras, frutos del país, hotel, imprenta, bienes muebles e inmuebles, derechos y acciones; constituir derechos reales; importar, exportar y transformar
informática, joyería, juguetería, lana, lavadero, librería, madera, máquinas, marítimo, mecánica, medicina, metalúrgica, productos; aceptar mandatos, comisiones y representaciones; tomar préstamos; administrar bienes; registrar,
música, obras de ingeniería, óptica, papel, perfumería, pesca, plástico, prensa, publicidad, química, radio, servicios adquirir y ceder invenciones; participar en sociedades, joint ventures o consorcios; y concursar en licitaciones
profesionales, técnicos y administrativos, tabaco, televisión, textil, transporte, turismo, valores inmobiliarios, públicas o privadas. La sociedad tiene plena capacidad para adquirir derechos, contraer obligaciones y realizar
vestimenta, veterinaria, vidrio; (ii) importaciones, exportaciones, representaciones, comisiones y consignaciones; (iii) todos los actos no prohibidos por las leyes o sus estatutos.
compraventa, arrendamiento, administración, construcción y toda clase de operaciones con bienes inmuebles; (iv) Esta sociedad desarrolla actividades de distribución de bebidas gaseosas, cervezas, energizantes y aguas.
explotación agropecuaria, forestación, fruticultura, citricultura y sus derivados, cumpliendo con las disposiciones Vinculación futura proyectada
legales; y (v) participación, constitución o adquisición de empresas que operen en los ramos preindicados. Se proyecta que esta sociedad continúe desarrollando actividades de distribución de bebidas gaseosas, cervezas,
Esta sociedad desarrolla actividades de inversión en bienes inmuebles en los cuales se asienta la actividad de energizantes y aguas.
Milotur S.A.
Vinculación futura proyectada (*) Los directores titulares señores Antonio Cruz Stuven, Eduardo Ffrench-Davis Rodríguez, Sebastián Landi y el director suplente
Se proyecta que esta sociedad continúe desarrollando actividades de inversión en bienes inmuebles en los cuales señor Felipe Benavides Almarza son Ejecutivos Principales de la matriz.
se asiente la actividad de Milotur S.A.
(*) Los directores señores Felipe Benavides Almarza, Antonio Cruz Stuven y Sebastián Landi son Ejecutivos Principales de la matriz.
 BEBIDAS BOLIVIANAS BBO S.A. 9
 Razón Social BEBIDAS BOLIVIANAS BBO S.A.
 Naturaleza jurídica Sociedad anónima cerrada
 AV S.A. 8 Carretera al Norte, Km. 25, Municipio de Warnes, Departamento de Santa
 Domicilio Cruz, Bolivia
Razón Social AV S.A. M$ 18.631.783
 Capital suscrito y pagado
Naturaleza jurídica Sociedad anónima cerrada
 % participación total en 2024 51,0000% (51,0000% en 2023)
Domicilio Cruz del Chaco N°1563, Asunción, Paraguay
 % de la inversión sobre el 0,2391%
Capital suscrito y pagado M$ 7.513.084 activo total de la matriz
% participación total en 2024 51,0166% Directores Titulares(*) Carlos Pinto Meyer (Presidente)
% de la inversión sobre el 0,3146% Sebastián Landi (Vicepresidente)
activo total de la matriz Felipe Benavides Almarza
Directores Titulares(*) Sebastián Landi (Presidente) Antonio Cruz Stuven
 Antonio Cruz Stuven Rafael Deheza Cronembold
 Eduardo Ffrench-Davis Rodríguez Carlos Krutzfeld Monasterio
 Víctor Rodríguez Yakisich Carlos Melchor Díaz Villavicencio
 Ignacio Luis Vierci Bravard Directores Suplentes Paola Camhi Jacard
Directores Suplentes Felipe Benavides Almarza Jaime Ronald Gutiérrez López
 Nestor Fabián Abraham Arce Joaquín Eduardo Trejo Darraidou
Gerente General Rafael Fontecilla Cornejo Gerente General(**) Albert Charles Masri Bascuñán
Memoria Integrada 2024 199

[pág. 201]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Objeto social / Actividades Directores Suplentes Felipe Benavides Almarza
La sociedad tiene por objeto principal realizar por cuenta propia, ajena o asociada con terceros, las siguientes Nestor Fabián Abraham Arce
actividades enumeradas de manera indicativa pero no limitativa: (i) dedicarse a la producción, embotellamiento y Gerente General Rafael Fontecilla Cornejo
comercialización de cerveza, bicervecina, maltas, bebidas fermentadas, bebidas alcohólicas para el consumo general; Objeto social / Actividades
(ii) dedicarse a la producción, embotellamiento y comercialización de bebidas no alcohólicas para el consumo
 La sociedad tiene por objeto dedicarse por cuenta propia o asociada a terceros, a la producción, industrialización,
general; (iii) representar en Bolivia a empresas y/o marcas nacionales y/o extranjeras a efectos de distribuir y/o
 importación, exportación, representación, distribución y comercialización de todo tipo de bebidas y en general a cualquier
comercializar en Bolivia productos de empresas, ya sean éstas fabricantes, comercializadoras o representantes de
 otro acto lícito de comercio. Para el cumplimiento de sus fines, la sociedad podrá: (i) adquirir y transferir el dominio
toda clase de bebidas alcohólicas y analcohólicas; (iv) asociarse para determinados negocios en forma accidental
 de bienes muebles, inmuebles y vehículos, construir y fabricar toda clase de bienes, efectuar operaciones con bancos
o del joint venture, conformar consorcios, dentro de las actividades del objeto social de la sociedad; (v) registrar
 oficiales y privados del país o del extranjero; (ii) solicitar y obtener créditos; (iii) tomar dinero prestado; (iv) dar o aceptar
y comercializar marcas, rótulos comerciales y patentes en general, vinculadas al desarrollo de las actividades
 garantías reales o personales; (v) participar en licitaciones públicas o privadas; (vi) solicitar la explotación de concesiones
señaladas en sus estatutos; (vi) invertir los fondos excedentes provenientes del giro habitual de sus actividades en
 del Gobierno Nacional y/o Municipal, de entidades autárquicas y/o privadas; (vii) recibir o dar representaciones; (viii)
cualquier tipo de inversión como ser bonos, plazos fijos, títulos públicos o privados o cualquier instrumento; y (vii)
 recibir o dar comisiones, consignaciones; (ix) designar distribuidores de sus productos; (x) desarrollar cualquier actividad
prestar servicios que sean consecuencia de las actividades específicas de la sociedad, necesarios al cumplimiento
 relacionada directa o indirectamente al objeto social; y (xi) conferir poderes generales y especiales, sustituirlos y revocarlos
de cualquiera de las finalidades del giro social sin ninguna limitación y al desarrollo de las actividades señaladas
 y practicar cualquier acto y celebrar cualquier contrato que la buena marcha de la sociedad aconseje, sin limitación
en los estatutos, excepto las que por ley se encuentren prohibidas.
 alguna, estén o no comprendidos en esta enumeración.
Esta sociedad desarrolla actividades de producción, envasado, comercialización y distribución de bebidas alcohólicas
 Esta sociedad desarrolla principalmente actividades de elaboración, envasado y distribución de bebidas con y sin alcohol.
y analcohólicas en Bolivia.
 Principales contratos con la matriz
Principales contratos con la matriz
 Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos).
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos).
 Vinculación futura proyectada
Vinculación futura proyectada
 Se proyecta que esta sociedad continúe desarrollando actividades de elaboración, envasado y venta de bebidas
Se proyecta que esta sociedad continúe desarrollando actividades de producción, envasado, comercialización y
 con y sin alcohol, vinculándose con la matriz a través de contratos de servicios compartidos.
distribución de bebidas alcohólicas y analcohólicas (gaseosas, aguas, maltas y cervezas) en Bolivia, vinculándose
con la matriz a través de contratos de servicios compartidos. (*) Los directores titulares señores Antonio Cruz Stuven, Eduardo Ffrench-Davis Rodríguez, Sebastián Landi y el director suplente
 señor Felipe Benavides Almarza son Ejecutivos Principales de la matriz.
(*) Los directores titulares señores Felipe Benavides Almarza, Antonio Cruz Stuven y Sebastián Landi son Ejecutivos Principales
 de la matriz.
(**) El Gerente General señor Albert Charles Masri Bascuñán renunció a su cargo con efecto al 26 de febrero de 2025, designándose
 en su reemplazo al señor Nicolás Agustín Rubino, quien asumió el cargo a contar del 10 de marzo del mismo año. COMPAÑÍA CERVECERÍAS UNIDAS ARGENTINA S.A.
 Razón Social COMPAÑÍA CERVECERÍAS UNIDAS ARGENTINA S.A. (CCU Argentina)
 BEBIDAS DEL PARAGUAY S.A.10
 Naturaleza jurídica Sociedad anónima cerrada
Razón Social BEBIDAS DEL PARAGUAY S.A. Domicilio Suipacha N° 1.111, piso 18, Ciudad Autónoma de Buenos Aires, Argentina
Naturaleza jurídica Sociedad anónima cerrada Capital suscrito y pagado M$ 644.293
Domicilio Acceso Sur Km 32, San Antonio, Paraguay % participación total en 2024 80,6490% (80,6490% en 2023)
Capital suscrito y pagado M$ 28.191.250 % de la inversión sobre el 11,5288%
 activo total de la matriz
% participación total en 2024 57,2158% (55,0070% en 2023)
 Directores Titulares(*) Francisco Pérez Mackenna (Presidente)
% de la inversión sobre el 0,7528% Carlos Molina Solís (Vicepresidente)
activo total de la matriz
 Javier Caspani Zurbriggen
Directores Titulares(*) Sebastián Landi (Presidente)
 Julio Freyre Aznárez
 Antonio Cruz Stuven
 Agustín González Avalis
 Eduardo Ffrench-Davis Rodríguez
 Pablo Granifo Lavín
 Víctor Rodríguez Yakisich
 Marc Gross
 Ignacio Luis Vierci Bravard
 Ezequiel Gussoni Cattaneo
Memoria Integrada 2024 200

[pág. 202]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
 Rodrigo Hinzpeter Kirberg Directores Suplentes Andrés Pablo Glerean
 Patricio Jottar Nasrallah Horacio Daniel Morelli
 Carlos López Sanabria
 Gerente General Julio Freyre Aznárez
 Ricardo Olivares Elorrieta
 Fernando Sanchis Sacchi Objeto social / Actividades
 El objeto de la sociedad es realizar, por cuenta propia de terceros y/o asociada a terceros, en Argentina o en el exterior,
Directores Suplentes Andrés Pablo Glerean
 las siguientes actividades: (i) Industriales: elaboración, fraccionamiento y comercialización de cerveza y malta, sus
 Horacio Daniel Morelli
 productos derivados, anexos y afines; explotación directa o indirecta de cebada cervecera, lúpulo y su cultivo; elaboración,
Gerente General Julio Freyre Aznárez fraccionamiento y comercialización de bebidas gaseosas y aguas minerales; conservación de carnes, frutas, verduras
Objeto social / Actividades y demás productos perecederos en sus cámaras frigoríficas; utilización de los subproductos para la elaboración de
El objeto de la sociedad es realizar, por cuenta propia o de terceros o asociada a terceros, las siguientes actividades: levadura, forrajes, abono y otros productos químicos; (ii) Comerciales: adquisición y enajenación de bienes muebles,
(i) el aporte y la inversión de capitales en empresas o sociedades constituidas o a constituirse, la participación - materias primas, elaboradas o a elaborarse, patentes de invención, marcas, diseños y modelos industriales; importación
en dinero o en especie - en otras sociedades por acciones y la adquisición, enajenación o transferencia de títulos, y exportación de cerveza, malta, agua mineral, sus derivados, elaboraciones y otros productos en general; ejercer
acciones, debentures, facturas, remitos y valores mobiliarios en general, nacionales o extranjeros, títulos, bonos y representaciones, comisiones y consignaciones, en los rubros: cerveza, malta, agua mineral, bebidas, helados, bocaditos,
papeles de crédito de cualquier tipo o modalidad, creados o a crearse; y (ii) toma y otorgamiento de toda clase de galletitas y derivados referidos a tales artículos; (iii) Financieras: adquisición y enajenación de participaciones en otras
créditos, con o sin garantía real, emisión de debentures, obligaciones negociables, papeles de comercio y bonos, sociedades y empresas del país o del exterior; aportar y vender capitales propios y ajenos, con o sin garantía, a sociedades
otorgamiento de avales y garantías, todo ello, con exclusión de las actividades comprendidas en la ley de entidades o a particulares; tomar y vender valores mobiliarios con o sin cotización. Quedan excluidas las operaciones a que se
financieras o que requieran el concurso del público. refiere la Ley N° 21.526 de Entidades Financieras u otras que requieran el concurso del ahorro público; (iv) Inmobiliarias:
Esta sociedad desarrolla actividades de inversión en acciones y derechos sociales. adquisición, enajenación, explotación, arrendamiento, construcción, permuta y/o administración y/o disposición bajo
Vinculación futura proyectada cualquier forma de toda clase de inmuebles, urbanos o rurales; subdivisión de tierras y su urbanización, construcción
Se proyecta que esta sociedad continúe desarrollando actividades de inversión en acciones y derechos sociales. de edificios para renta o comercio; constitución de toda clase de derechos reales sobre inmuebles; y realización de
 operaciones comprendidas dentro de las leyes y reglamentos de la propiedad horizontal; y (v) Agropecuarias: explotación
(*) Los directores señores Pablo Granifo Lavín, Marc Gross, Rodrigo Hinzpeter Kirberg, Carlos Molina Solís y Francisco Pérez –en todas sus formas– de establecimientos agrícola-ganaderos, frutícolas, forestales y granjas.
 Mackenna son directores de la matriz, el director y Gerente General señor Julio Freyre Aznárez es ejecutivo principal y el director Esta sociedad desarrolla actividades de elaboración, envasado, venta, distribución y comercialización de cervezas,
 señor Patricio Jottar Nasrallah es Gerente General de la misma. bebidas malteadas y malta.
 Principales contratos con la matriz
 Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos).
 COMPAÑÍA INDUSTRIAL CERVECERA S.A.11 Vinculación futura proyectada
 Se proyecta que esta sociedad continúe desarrollando actividades de elaboración, envasado, venta, distribución
Razón Social COMPAÑÍA INDUSTRIAL CERVECERA S.A. y comercialización de cervezas, bebidas malteadas y malta, vinculándose con la matriz a través de contratos de
Naturaleza jurídica Sociedad anónima cerrada servicios compartidos.
Domicilio Adolfo Güemes N° 1.253, ciudad de Salta, Argentina
 (*) El director titular y Gerente General señor Julio Freyre Aznárez es ejecutivo principal de la matriz.
Capital suscrito y pagado M$ 2.851.938
% participación total en 2024 78,4967% (78,4967% en 2023)
% de la inversión sobre el DISTRIBUIDORA DEL PARAGUAY S.A.12
 14,3598%
activo total de la matriz
Directores Titulares(*) Carlos López Sanabria (Presidente) Razón Social DISTRIBUIDORA DEL PARAGUAY S.A.
 Julio Freyre Aznárez (Vicepresidente) Naturaleza jurídica Sociedad anónima cerrada (Paraguay)
 Javier Caspani Zurbriggen Domicilio Acceso Sur Km 32, San Antonio, Paraguay
 Agustín González Avalis Capital suscrito y pagado M$ 5.134.380
 Ezequiel Gussoni Cattaneo % participación total en 2024 51,0024% (54,9640% en 2023)
 Ricardo Olivares Elorrieta
 % de la inversión sobre el 0,1000%
 activo total de la matriz
Memoria Integrada 2024 201

[pág. 203]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Directores Titulares(*) Sebastián Landi (Presidente) Director Suplente Vicente Rosselot Soini
 Antonio Cruz Stuven Objeto social / Actividades
 Eduardo Ffrench-Davis Rodríguez La sociedad tiene por objeto: (i) producción, industrialización, comercialización, distribución, importación y exportación
 Víctor Rodríguez Yakisich por cuenta propia o ajena, de toda clase de productos agrícolas, en especial de los vitivinícolas; (ii) explotación,
 Ignacio Luis Vierci Bravard administración y arriendo, por cuenta propia o ajena, de predios agrícolas, bodegas, viñedos y establecimientos
Directores Suplentes Nestor Fabián Abraham Arce comerciales del rubro vitivinícola; (iii) producción, industrialización, comercialización, distribución, importación y
 Felipe Benavides Almarza exportación, por cuenta propia o ajena de toda clase de bebidas, sean estas vinos, licores, cervezas o de cualquier
Gerente General Rafael Fontecilla Cornejo naturaleza, alcohólicas y de las materias primas de las mismas; (iv) aprovechamiento industrial y comercial de los
 subproductos y derivados de los artículos que anteceden; (v) prestación de servicios relacionados con los mismos
Objeto social / Actividades
 rubros; y (vi) representación de empresas nacionales y extranjeras, la distribución y comercialización de los productos
La sociedad tendrá por objeto dedicarse por cuenta propia o asociada a terceros a la producción, industrialización,
 nacionales o importados de los bienes anteriormente mencionados y de productos alimenticios en general.
importación, exportación, representación, distribución y comercialización de todo tipo de bebidas, y en general, a
 Esta sociedad desarrolla actividades de producción, elaboración, envasado, venta, promoción y comercialización
cualquier otro acto lícito de comercio. Para el cumplimiento de sus fines, la sociedad podrá: (i) adquirir y transferir
 de vinos argentinos, bajo marcas propias “La Celia”, “Bodega Tamarí”, “Colón” y “Graffigna”, destinados al mercado
el dominio de bienes muebles, inmuebles y auto-vehículos, construir y fabricar toda clase de bienes, efectuar
 doméstico argentino y de exportación.
operaciones con bancos oficiales y privados del país o del extranjero; (ii) solicitar y obtener créditos; (iii) tomar
dinero prestado; (iv) dar o aceptar garantías reales o personales; (v) participar en licitaciones públicas o privadas; (vi) Vinculación Futura
solicitar la explotación de concesiones del Gobierno Nacional y/o Municipal, de entidades autárquicas y/o privadas; Se proyecta que esta sociedad continúe desarrollando actividades de producción, elaboración, envasado, venta,
(vii) recibir o dar representaciones; (viii) recibir o dar comisiones, consignaciones; (ix) designar distribuidores de sus promoción y comercialización de vinos argentinos, bajo marcas propias, o por medio de contratos de licencia o
productos; (x) desarrollar cualquier actividad relacionada directa o indirectamente al objeto social; y (xi) conferir distribución, destinados al mercado doméstico y de exportación argentino.
poderes generales y especiales, sustituirlos y revocarlos y practicar cualquier acto y celebrar cualquier contrato que
 (*) El director señor Pedro Herane Aguado es ejecutivo principal de la matriz.
la buena marcha de la sociedad aconseje, sin limitación alguna, estén o no comprendidos en esta enumeración.
Esta sociedad desarrolla el negocio de distribución de bebidas gaseosas, cervezas, energizantes y aguas.
Vinculación futura proyectada
Se proyecta que esta sociedad continúe desarrollando actividades de distribución de bebidas gaseosas, cervezas, INTERNATIONAL SPIRITS INVESTMENTS USA LLC
energizantes y aguas.
 Razón Social INTERNATIONAL SPIRITS INVESTMENTS USA LLC
(*) Los directores titulares señores Antonio Cruz Stuven, Eduardo Ffrench Davis Rodríguez, Sebastián Landi y el director suplente Naturaleza jurídica Sociedad de responsabilidad limitada
 señor Felipe Benavides Almarza son Ejecutivos Principales de la matriz.
 2.711 Centerville Road, Suite 400, Wilmington, New Castle County, Delaware
 Domicilio 19808, Estados Unidos de América
 FINCA LA CELIA S.A. Capital suscrito y pagado M$ 306.272
 % participación total en 2024 100,0000% (100,0000% en 2023)
Razón Social FINCA LA CELIA S.A. % de la inversión sobre el 0,0079%
Naturaleza jurídica Sociedad anónima cerrada activo total de la matriz
Domicilio Avda. San Martín N° 972, 3er piso, (5.500), ciudad de Mendoza, Argentina Administración(*) Felipe Benavides Almarza
Capital suscrito y pagado M$ 1.024.354 Antonio Cruz Stuven
% participación total en 2024 99,8816% (99,8816% en 2023) Felipe Dubernet Azócar
 Rodrigo Jadue Roa
% de la inversión sobre el 0,7657% Domingo Jiménez Manterola
activo total de la matriz
 Patricio Jottar Nasrallah
Directores Titulares(*) Pedro Herane Aguado (Presidente)
 Federico Busso (Vicepresidente)
 Fernando Sanchis Sacchi
Memoria Integrada 2024 202

[pág. 204]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Objeto social / Actividades MARZUREL S.A.
La sociedad tiene por objeto participar en cualquier acto o actividad legal para la cual las sociedades de
responsabilidad limitada puedan formarse bajo las leyes del Estado de Delaware.
 Razón Social MARZUREL S.A.
Esta sociedad desarrolla actividades de inversión de carácter financiero y, en especial, en acciones y derechos
sociales. Naturaleza jurídica Sociedad anónima cerrada
 Tiburcio Gómez N° 1.330, Piso 3 Unidad A, 11.300 Montevideo, Departamento
Vinculación futura proyectada Domicilio de Montevideo, Uruguay
Se proyecta que esta sociedad continúe desarrollando actividades de inversión de carácter financiero en el exterior,
en particular, en acciones y/o derechos sociales. Capital suscrito y pagado M$ 63.664
 % participación total en2024 100,0000% (100,0000% en 2023)
(*) Los administradores señores Felipe Benavides Almarza, Antonio Cruz Stuven, Felipe Dubernet Azócar y Domingo Jiménez % de la inversión sobre el
 Manterola son Ejecutivos Principales de la matriz, y el administrador señor Patricio Jottar Nasrallah es Gerente General de la 0,0680%
 activo total de la matriz
 misma.
 Directores Titulares(*) Sebastián Landi (Presidente)
 Felipe Benavides Almarza
 LOS HUEMULES S.R.L. Antonio Cruz Stuven
 Francisco Díaz Fadic
Razón Social LOS HUEMULES S.R.L. Gerente General Nicolás Novoa Cruz
Naturaleza jurídica Sociedad de responsabilidad limitada Objeto social / Actividades
Domicilio Suipacha N° 1.111, piso 18, Ciudad Autónoma de Buenos Aires, Argentina El objeto de la sociedad es: (i) industrializar y comercializar en todas sus formas mercaderías, arrendamientos de
Capital suscrito y pagado M$ 111.015 bienes, obras y servicios, en los ramos y anexos de agencias de viajes, alimentación, artículos del hogar y oficina,
 automotriz, bazar, bebidas, carnes, caucho, comestibles, comunicaciones, construcción, subsidiarios, cosmética,
% participación total en 2024 49,9999% (50,0001% en 2023)
 cueros, deportes, editorial, electrónica, electrotécnica, enseñanza, espectáculos, extractivas, ferretería, fotografías,
% de la inversión sobre el 0,0376% fibras sintéticas, frutos del país, hotel, imprenta, informática, joyería, juguetería, lana, lavadero, librería, madera,
activo total de la matriz máquinas, marítimo, mecánica, medicina, metalúrgica, minería, música, obras de ingeniería e instalaciones sanitarias,
Gerentes Ricardo Olivares Elorrieta (Gerente Titular) públicas o privadas, óptica, papel, perfumería, pesca, plásticas, prensa, propaganda, química, radio, servicios
 Andrés Pablo Glerean (Gerente Suplente) profesionales, técnicos y administrativos, tabaco, televisión, textil, transporte nacional e internacional de personas,
Objeto social / Actividades cosas, semovientes y noticias, turismo, valores inmobiliarios, vestimenta, veterinaria, vidrio; (ii) importaciones,
La sociedad tiene por objeto dedicarse por cuenta propia o ajena, o asociada a terceros, dentro o fuera del país, exportaciones, representaciones, comisiones y consignaciones; (iii) compraventa, arrendamiento, administración,
a: (i) la explotación de restaurantes, bares, cafeterías y venta de toda clase de alimentos y bebidas elaborados construcción y toda clase de operaciones con bienes inmuebles, respetando las prohibiciones legales que se hallen
en dichos establecimientos; (ii) la importación y exportación de bienes relacionados con la gastronomía; y (iii) la en vigencia; y (iv) forestación, fruticultura, citricultura y sus derivados, cumpliendo con las disposiciones legales.
realización de cualquier actividad conexa, derivada o análoga que directamente se vincule a ese objeto, incluyendo Esta sociedad es titular de las marcas registradas para la comercialización de los productos de Milotur S.A.
el arrendamiento de restaurantes, bares, cafeterías. Para la realización del objeto social, la sociedad tiene plena Vinculación futura proyectada
capacidad jurídica para realizar toda clase de actos, contratos y operaciones autorizadas por las leyes, sin restricción Se proyecta que esta sociedad continúe siendo titular de las marcas registradas para la comercialización de los
alguna, ya sean de naturaleza civil, comercial, administrativa, judicial o de cualquier otra, que se relacionen directa productos de Milotur S.A.
o indirectamente con el objeto social.
Esta sociedad desarrolla como actividad la administración de los inmuebles de que es titular. (*) Los directores señores Felipe Benavides Almarza, Antonio Cruz Stuven y Sebastián Landi son Ejecutivos Principales de la matriz.
Vinculación futura proyectada
Se proyecta que esta sociedad continúe administrando los inmuebles de que es titular.
Memoria Integrada 2024 203

[pág. 205]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
 MILOTUR S.A. SAJONIA BREWING COMPANY S.A.
Razón Social MILOTUR S.A. Razón Social SAJONIA BREWING COMPANY S.A.
Naturaleza jurídica Sociedad anónima cerrada Naturaleza jurídica Sociedad anónima (Paraguay)
 Tiburcio Gómez N° 1.330, Piso 3 Unidad A, 11.300 Montevideo, Departamento Domicilio Alejo García N° 2.589, Asunción, Paraguay
Domicilio de Montevideo, Uruguay Capital suscrito y pagado M$ 1.782.162
Capital suscrito y pagado M$ 32.633.466
 % participación total en 2024 99,0000% (99,0000% en 2023)
% participación total en 2024 100,0000% (100,0000% en 2023) % de la inversión sobre el
% de la inversión sobre el 0,0038%
 0,9107% activo total de la matriz
activo total de la matriz Directores Titulares Rodrigo Aguilera Díaz (Presidente)
Directores Titulares(*) Sebastián Landi (Presidente) Francisco Raúl Morales Herrera
 Felipe Benavides Almarza Gerente General Rafael Fontecilla Cornejo
 Antonio Cruz Stuven
 Objeto social / Actividades
 Francisco Díaz Fadic
 La sociedad tiene por objeto la importación, fabricación y distribución de bebidas alcohólicas (cervezas) e insumos
Gerente General Nicolás Novoa Cruz
 para la fabricación de la misma, exportación, comercio en general; la importación, exportación o re-exportación,
Objeto social / Actividades distribución, compraventa de mercaderías o efectos de comercio, sin limitación de cantidad, especie o calidad,
El objeto de la sociedad es: (i) industrializar y comercializar en todas sus formas mercaderías, arrendamientos de por cuenta propia o asociada a terceros; y consignación, representación, mandatos. Podrá también dedicarse a la
bienes, obras y servicios, en los ramos y anexos: de alimentación, artículos del hogar y oficina, automotriz, bar, bazar, prestación de todo tipo de servicios y, en general, a las actividades que directa o indirectamente se relacionen con
caucho, construcción, cosmética, cueros, editorial, electrónica, electrotécnica, enseñanza, espectáculos, extractivas, su objeto, que los accionistas consideren de interés para el giro social, y sean de lícito comercio, en el país o en el
ferretería, fotografías, fibras, frutos del país, hotel, imprenta, informática, joyería, juguetería, lana, lavadero, librería, extranjero, sirvan para su complementación, expansión o consolidación empresarial, para lo cual tendrá capacidad
limpieza, madera, máquinas, marítimo, mecánica, medicina, metalúrgica, música, obras de ingeniería, óptica, papel, jurídica para celebrar toda clase de contratos o actos, sin más limitaciones que las expresamente establecidas en
perfumería, pesca, plástico, prensa, publicidad, química, radio, servicios profesionales, técnicos y administrativos, las leyes y los estatutos sociales.
tabaco, televisión, textil, transporte, turismo, valores inmobiliarios, vestimenta, veterinaria, vidrio; (ii) importaciones, Esta sociedad desarrolla principalmente actividades de elaboración y distribución de cervezas artesanales bajo la
exportaciones, representaciones, comisiones y consignaciones; (iii) compraventa, arrendamiento, administración, marca Sajonia.
construcción y toda clase de operaciones con bienes inmuebles respetando las prohibiciones legales; (iv) forestación, Vinculación futura proyectada
fruticultura, citricultura y sus derivados, cumpliendo con las disposiciones legales; y (v) participación, constitución Se proyecta que esta sociedad continúe desarrollando actividades de elaboración y distribución de cervezas
o adquisición de empresas que operen en los ramos preindicados. artesanales.
Esta sociedad desarrolla actividades de extracción, envasado y comercialización de agua mineral y otras bebidas
no alcohólicas elaboradas a partir del agua extraída. Asimismo, importa y comercializa cerveza y vinos.
Principales contratos con la matriz
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos). VSPT UK LTD.
Vinculación futura proyectada
Se proyecta que esta sociedad continúe desarrollando actividades de extracción, envasado y comercialización de Razón Social VSPT UK LTD.
agua mineral y otras bebidas no alcohólicas e importando cervezas y vinos, vinculándose con la matriz a través de Domicilio 83 Baker Street, Londres, W1U 6AG, Reino Unido
contratos de servicios compartidos. Naturaleza jurídica Sociedad de responsabilidad limitada
 Capital suscrito y pagado M$ 521.337
(*) Los directores señores Felipe Benavides Almarza, Antonio Cruz Stuven y Sebastián Landi son Ejecutivos Principales de la matriz.
 % participación total en 2024 100,0000% (100,0000% en 2023)
 % de la inversión sobre el 0,0039%
 activo total de la matriz
 Director Titular Germán del Río López
Memoria Integrada 2024 204

[pág. 206]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Objeto/Actividades VSPT WINEGROUP (SHANGHAI) LIMITED
Su objeto social no tiene restricción conforme a la Companies Act de 2006 de Reino Unido, por tanto, puede realizar
cualquier actividad lícita conforme a dicha normativa.
 Razón Social VSPT WINEGROUP (SHANGHAI) LIMITED
Esta sociedad desarrolla actividades de importación de vino a granel chilenos y argentinos que adquiere de su matriz
Viña San Pedro Tarapacá S.A. y de su filial argentina Finca la Celia S.A. para su envasado, promoción, distribución Naturaleza jurídica Sociedad de Inversiones China
y comercialización en Reino Unido. No. 875, Qiuxing Road, Lingang New Area, China (Shanghai) Pilot Free Trade
 Domicilio Zone, China
Vinculación Futura proyectada
Se proyecta que esta sociedad continúe adquiriendo vinos a su matriz Viña San Pedro Tarapacá S.A. y a Finca La Capital suscrito(*) M$ 498.230
Celia S.A. para envasarlos, promocionarlos, distribuirlos y comercializarlos en Reino Unido. % participación total en 2024 100,0000% (100,0000% en 2023)
 % de la inversión sobre el 0,0138%
 activo total de la matriz
 Director Titular Germán del Río López
 VSPT US LLC Supervisor Único del Directorio Vicente Rosselot Soini
 Gerente General Craig Aldous
Razón Social VSPT US LLC
 Sociedad de responsabilidad limitada Objeto Social/ Actividades
Naturaleza jurídica
 La sociedad se constituyó con el objeto y propósito de dedicarse al negocio de vinos y prestación de servicios
Domicilio 2010 NW 150th Ave, suite 211, Pembroke Pines, 33028, Florida, Estados Unidos.
 de promoción y planificación de marketing, entre otros, debiendo para ello, cuando sea procedente, contar con
Capital suscrito y pagado M$ 398.584 licencias de las autoridades chinas pertinentes.
% participación total en 2024 100,0000% (100,0000% en 2023) Esta sociedad desarrolla actividades de gestión de ventas, promoción, marketing y trademarketing de vinos, vinos
% de la inversión sobre el espumantes y otros productos elaborados en base a vino, chilenos y argentinos en China.
 0,0110%
activo total de la matriz Vinculación futura proyectada:
Administración(*) Germán del Río López Se proyecta que esta nueva sociedad desarrolle actividades de gestión de ventas, promoción, marketing y
 Pedro Herane Aguado trademarketing de vinos principalmente chilenos y argentinos en China.
 Vicente Rosselot Soini
 (*) Se proyecta que el capital suscrito se pague a partir del año 2025.
Gerente General Andrés Tauber Domínguez
Objeto social / Actividades
La sociedad se constituyó con el objeto y propósito de dedicarse a la naturaleza del negocio que será conducido
y desarrollado por la sociedad y a dedicarse a cualquier acto o actividad legal y ejercer cualquier facultad que 3. COLIGADAS EN CHILE
esté autorizada a las sociedades de responsabilidad limitada constituidas bajo las leyes del Estado de Florida,
relacionadas o que sean consecuencia de y necesarias, convenientes o aconsejables para la realización de los fines
antes mencionados. BEBIDAS CAROZZI CCU SpA
Esta sociedad desarrolla actividades de promoción, marketing y trademarketing de vinos, vinos espumantes y otros
productos elaborados en base a vino, chilenos y argentinos, en Estados Unidos de América. Razón Social BEBIDAS CAROZZI CCU SpA (BEBIDAS CAROZZI CCU)
Vinculación Futura Naturaleza jurídica Sociedad por acciones
Se proyecta que esta sociedad continúe desarrollando actividades de promoción, marketing y trademarketing de vinos, Avda. Presidente Eduardo Frei Montalva N° 1.500, comuna de Renca, Región
vinos espumantes y otros productos elaborados a base de vino, chilenos y argentinos, en Estados Unidos América. Domicilio Metropolitana
 Capital suscrito y pagado M$ 7.162
(*) El administrador señor Pedro Herane Aguado es ejecutivo principal de la matriz.
 % participación total en 2024 50,0000% (50,0000% en 2023)
 % de la inversión sobre el 0,1842%
 activo total de la coligante
Memoria Integrada 2024 205

[pág. 207]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Directores Titulares(*) Eduardo Ffrench-Davis Rodríguez (Presidente) Objeto social / Actividades
 Matías Bebin Subercaseaux El objeto de la sociedad es: (i) fabricación, producción, elaboración, transformación, distribución, transporte,
 Luz María Rojas Sepúlveda importación, exportación, compra, venta, y comercialización en general, en cualquier forma y a cualquier título,
 Santiago Valdés Birrel de todo tipo de concentrados y jarabes utilizados para la elaboración de bebidas de fantasía a base de agua
Gerente General María José Osorio Alfaro carbonatada, y de materias primas o semielaboradas relacionadas con los productos recién descritos; (ii) tomar de
 y/o dar a sociedades, instituciones, personas naturales, o cualquier otro tipo de entidad que goce de personalidad
Objeto social / Actividades
 jurídica, ya sea de derecho público o privado, nacional o extranjera, representaciones de marcas, productos y/o
El objeto de la sociedad será la producción, comercialización y distribución de bebidas instantáneas en polvo.
 licencias relacionadas con dichos negocios, actividades y productos, todo dentro del territorio de la República de
Para la consecución de dicho fin, la sociedad podrá ejecutar todos los actos y celebrar todos los contratos que
 Chile; (iii) administración de licencias y sub-licencias relacionadas con los negocios, actividades y productos a que se
sean necesarios o convenientes, pudiendo incluso constituir o formar parte de otras sociedades, comunidades,
 refieren los literales anteriores; (iv) prestar toda clase de servicios de asistencia técnica, en cualquier forma, que diga
personas jurídicas de cualquier clase y otras entidades.
 relación con los bienes, productos, negocios y actividades referidos en las letras anteriores y su comercialización,
Esta sociedad desarrolla el negocio de elaboración, comercialización y distribución de bebidas instantáneas en
 elaboración de políticas de marketing, publicidad y similares relacionadas con los fines sociales; (v) inversión de los
polvo bajo las marcas Vivo y Sprim.
 frutos que produzca el desarrollo de su giro en todo tipo de bienes corporales e incorporales, muebles e inmuebles;
Principales contratos con Compañía Cervecerías Unidas S.A. y (vi) realización de todos los actos y contratos necesarios y/o conducentes para el cumplimiento del objeto social.
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos). Esta sociedad desarrolla actividades de elaboración y comercialización de concentrados y jarabes para preparar
Vinculación futura proyectada bebidas analcohólicas, administración de licencias y sublicencias y prestación de servicios asistencia técnica y de
Se proyecta que esta sociedad continúe desarrollando el negocio de elaboración, comercialización y distribución publicidad, entre otros.
de bebidas instantáneas en polvo bajo las marcas Vivo y Sprim, vinculándose con Compañía Cervecerías Unidas Principales contratos con Compañía Cervecerías Unidas S.A.
S.A. a través de contratos de servicios compartidos. Contrato de licencia de las marcas Bilz, Pap, Pop de Bilz y Pap, Kem y Nobis; y contrato de prestación de servicios,
 asesoría y asistencia técnica (contrato de servicios compartidos).
(*) Los directores señores Matías Bebin Subercaseaux y Eduardo Ffrench-Davis Rodríguez son Ejecutivos Principales de Compañía
 Cervecerías Unidas S.A. Vinculación futura proyectada
 Se proyecta que esta sociedad continúe desarrollando actividades de elaboración y comercialización de concentrados
 y jarabes para preparar bebidas analcohólicas, administración de licencias y sublicencias y prestación de servicios
 de asistencia técnica y de publicidad, entre otros, vinculándose con Compañía Cervecerías Unidas S.A. a través de
 BEBIDAS CCU-PEPSICO SpA contratos de licencia de las marcas Bilz, Pap, Pop de Bilz y Pap, Kem y Nobis y contratos de servicios compartidos.
Razón Social BEBIDAS CCU-PEPSICO SpA (*) El director titular señor Eduardo Ffrench-Davis Rodríguez es ejecutivo principal de Compañía Cervecerías Unidas S.A. y el
Naturaleza jurídica Sociedad por acciones director señor Patricio Jottar Nasrallah es Gerente General de la misma.
 Avda. Presidente Eduardo Frei Montalva N° 1.500, comuna de Renca, Región
Domicilio Metropolitana
Capital suscrito y pagado M$ 1.000 CERVECERÍA AUSTRAL S.A.
% participación total en 2024 50,0000% (50,0000% en 2023)
% de la inversión sobre el Razón Social CERVECERÍA AUSTRAL S.A. (AUSTRAL S.A.)
 0,0351%
activo total de la coligante Naturaleza jurídica Sociedad anónima cerrada
Directores Titulares(*) Eduardo Ffrench-Davis Rodríguez (Presidente) Domicilio Calle Patagona N° 508, ciudad y comuna de Punta Arenas, Región de Magallanes
 Patricio Jottar Nasrallah Capital suscrito y pagado M$ 5.640.204
 Roberto Olea % participación total en 2024 48,3726% (48,3726% en 2023)
 Erick Scheel
 % de la inversión sobre el 0,4679%
Gerente General Andrés Gardella Storm activo total de la coligante
Memoria Integrada 2024 206

[pág. 208]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Directores Titulares(*) Matías Bebin Subercaseaux (Presidente) % de la inversión sobre el 0,1121%
 Juan Pablo Edwards Guzmán activo total de la matriz
 Cristián Herrera Fernández Administración(*) Matías Bebin Subercaseaux
 Xavier Lombardo Felipe Covarrubias Ochagavía
 Cristián Mandiola Parot Juan Pablo Edwards Guzmán
 Tomás Mosella Vial Cristián Herrera Fernández
Gerente General Felipe Covarrubias Ochagavía Pablo Iturriaga Wilder
Objeto social / Actividades Xavier Lombardo
El objeto de la sociedad es la ejecución y desarrollo por cuenta propia o de terceros, o asociada con terceros, de Cristián Mandiola Parot
las siguientes actividades: (i) inversión en todas sus formas y en todo tipo de bienes, corporales o incorporales, Tomás Mosella Vial
muebles o inmuebles, vinculados al negocio de la malta, cebada, derivados de malta, cerveza y comercialización y Felipe Sandoval González
distribución de bebidas y licores en general; (ii) prestación de toda clase de servicios y asesorías vinculados al rubro Objeto social / Actividades
cervecero, maltero y sus derivados, y de bebidas y licores en general, a toda clase de personas o empresas, y ya sea El objeto de la sociedad es: (i) compra, venta, adquisición, enajenación, importación, exportación, comercialización
directamente o por intermedio de sociedades que cree o en las que participe al efecto; (iii) desarrollo y la inversión y distribución en cualquier forma de bebidas alcohólicas, analcohólicas y productos afines; (ii) prestación de
en productos relacionados con lo anterior; (iv) compra, venta, exportación, importación, fabricación, elaboración, servicios de transporte de carga en general, ya sea con vehículos propios o de terceros, dentro y fuera del país; (iii)
producción, transporte o distribución de toda clase de productos, mercaderías y de toda clase de bienes en general arrendamiento, subarrendamiento, mantención y reparación de toda clase de vehículos; (iv) servicios de asesoría
vinculados al rubro de la malta, cebada, derivados de malta, cerveza, bebidas y licores en general; (v) constituir toda en materia de tráfico y transporte en general; (v) servicios de bodegaje y distribución de materias primas, insumos,
clase de sociedades pudiendo desarrollar las actividades propias de su giro social por sí misma o a través de las concentrados, productos terminados y cualquier otra clase de bienes corporales muebles, incluyendo todas
sociedades que constituya o en las que se incorpore como socia o accionista; (vi) representar personas naturales aquellas operaciones comerciales, industriales o financieras que directa o indirectamente se relacionen con dicha
o jurídicas, nacionales o extranjeras, en todo tipo de negocios relacionados con el giro social; (vii) la ejecución de actividad; (vi) prestación de todo tipo de servicios y asesorías técnicas, profesionales, administrativas, contables, de
todos los actos y contratos civiles y comerciales conducentes a la realización del giro, incluyendo la compra, venta, coordinación y gestión en materia de otorgamiento de créditos, recaudación, pago, cobranzas y demás funciones
adquisición, enajenación, a cualquier título de toda clase de bienes y participar como socia o accionista de otras de tesorería y caja y otras complementarias de lo anterior; (vii) instalación, retiro, mantención y reparación de
sociedades o empresas cuyo objeto se relacione con el giro social; y (viii) todas las demás que acuerden los socios máquinas conservadoras, enfriadoras y/o expendedoras de bebidas alcohólicas y analcohólicas en general, y de
relacionadas con el giro social, tanto en el país como el exterior. los elementos y accesorios de aquéllas; (viii) prestación de servicios de publicidad, propaganda y marketing; y (ix)
Esta sociedad desarrolla actividades de elaboración, envasado y comercialización de cervezas bajo las marcas en general, la realización de cualquier acto o la celebración de cualquier contrato que los socios acuerden.
Austral e Imperial. Esta sociedad desarrolla actividades de comercialización de bebidas alcohólicas y analcohólicas elaboradas y/o
Principales contratos con Compañía Cervecerías Unidas S.A. comercializadas por empresas relacionadas de Compañía Cervecerías Unidas S.A. o terceros.
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato servicios compartidos). Vinculación futura proyectada
Vinculación futura proyectada Se proyecta que esta sociedad continúe desarrollando actividades de comercialización de bebidas alcohólicas y
Se proyecta que esta sociedad continúe desarrollando actividades de elaboración, envasado y comercialización analcohólicas elaboradas y/o comercializadas por empresas relacionadas de Compañía Cervecerías Unidas S.A. o
de cervezas, vinculándose con Compañía Cervecerías Unidas S.A. a través de contratos de servicios compartidos. terceros.
(*) El director titular señor Matías Bebin Subercaseaux es ejecutivo principal de Compañía Cervecerías Unidas S.A. (*) El administrador señor Matías Bebin Subercaseaux es ejecutivo principal de Compañía Cervecerías Unidas S.A.
 La administración, uso de la razón social y representación judicial y extrajudicial de Comercial Patagona Limitada corresponde a
 Cervecería Austral S.A., que la ejerce a través de una o más personas naturales designadas mediante escritura pública anotada
 COMERCIAL PATAGONA LIMITADA13 al margen de la inscripción social.
Razón Social COMERCIAL PATAGONA LIMITADA (PATAGONA LIMITADA)
 PROMARCA INTERNACIONAL SpA
Naturaleza jurídica Sociedad de responsabilidad limitada
 Los Flamencos N° 700, ciudad y comuna de Punta Arenas, Región de Magallanes
Domicilio Razón Social PROMARCA INTERNACIONAL SpA
 y de la Antártica Chilena
 Naturaleza jurídica Sociedad por acciones
Capital suscrito y pagado M$ 1.000
 Avda. Presidente Eduardo Frei Montalva N° 1.500, comuna de Renca, Región
% participación total en 2024 98,0000% (98,0000% en 2023) Domicilio Metropolitana
Memoria Integrada 2024 207

[pág. 209]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Capital suscrito y pagado M$ 10.961 % de la inversión sobre el 0,6003%
% participación total en 2024 100,0000% (100,0000% en 2023) activo total de la coligante
% de la inversión sobre el Directores Titulares Pablo Tagle Quiroz (Presidente)
 0,2064% Daniella Coll Cortés (Vicepresidente)
activo total de la coligante
Administración(*) Daniela Coll Cortés Daniel López Medina
 José Luis Cruzat Valdéz Nicolás Spitzer Ascui
 Daniel López Medina Gerente José Luis Cruzat Valdés
 Nicolás Spitzer Ascui Objeto social / Actividades
 Pablo Tagle Quiroz El objeto de la sociedad es: (i) la adquisición y desarrollo de marcas comerciales y licencias de marcas, y la explotación
Objeto social / Actividades de las mismas sea directamente o a través de licencias o sublicencias otorgadas a terceros; (ii) la realización de
El objeto de la sociedad es: (i) la explotación y desarrollo en la República Argentina, la República del Paraguay, el actividades de planificación, publicitarias y financieras que sean complementarias o digan relación con potenciar el
Estado Plurinacional de Bolivia, la República Oriental de Uruguay y otros países distintos de Chile que pudieren desarrollo y valor en Chile o en el extranjero de sus marcas comerciales y licencias de marcas o las de sus filiales;
acordar sus accionistas en el futuro, de las marcas comerciales Watt´s, así como de otras marcas que pueda adquirir y (iii) la inversión en toda clase de bienes corporales e incorporales, incluyendo derechos en sociedades, acciones,
o crear en el futuro en dichas jurisdicciones, en adelante las “Marcas Comerciales”, sea directamente o a través valores mobiliarios, marcas comerciales, títulos de crédito y efectos de comercio.
de licencias o sub-licencias otorgadas a terceros; (ii) la realización de actividades de planificación, publicitarias, y Esta sociedad se dedica a la adquisición y desarrollo de marcas comerciales y la explotación de las mismas a través
financieras que sean complementarias o digan relación con potenciar el desarrollo y valor de sus Marcas Comerciales del otorgamiento de licencias a sus accionistas (marcas Watt’s) en Chile y en determinados mercados internacionales
en los referidos países; y (iii) la inversión en toda clase de bienes corporales e incorporales, incluyendo derechos a través de su filial Promarca Internacional SpA.
en sociedades, acciones, valores mobiliarios, marcas comerciales, nombres de dominio, licencias o sub-licencias, Principales contratos con Compañía Cervecerías Unidas S.A.
títulos de crédito y efectos de comercio. Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos).
Esta sociedad se dedica actualmente a la explotación y desarrollo de la marca comercial Watt´s en la República del Vinculación futura proyectada
Paraguay y en la República Oriental del Uruguay, a través del otorgamiento de licencias o sub-licencias a empresas Se proyecta que esta sociedad continúe con el desarrollo de marcas comerciales y explotación de las mismas a través
relacionadas. del otorgamiento de licencias a sus accionistas (marcas Watt’s) Chile y en determinados mercados internacionales
Principales contratos con Compañía Cervecerías Unidas S.A. a través de su filial Promarca Internacional SpA, vinculándose con Compañía Cervecerías Unidas S.A. a través de
Contrato de prestación de servicios, asesoría y asistencia técnica (contrato de servicios compartidos). contratos de servicios compartidos.
Vinculación futura proyectada
Se proyecta que esta sociedad continúe explotando y desarrollando la marca comercial Watt´s en la República del
Paraguay y en la República Oriental del Uruguay, a través del otorgamiento de licencias o sub-licencias a empresas
relacionadas, vinculándose con Compañía Cervecerías Unidas S.A. a través de contratos de servicios compartidos. 4.- COLIGADAS EN EL EXTRANJERO
(*) La sociedad es administrada por Promarca S.A., que la ejercerá por medio de sus representantes o a través de mandatarios o
 delegados designados especialmente al efecto por escritura pública de la cual se deberá tomar nota al margen a la inscripción AGUAS DANONE DE ARGENTINA S.A.
 social.
 Razón Social AGUAS DANONE DE ARGENTINA S.A.
 Naturaleza jurídica Sociedad anónima cerrada
 PROMARCA S.A.14
 Domicilio Moreno N° 877, piso 4° Ciudad Autónoma de Buenos Aires, Argentina
 Capital suscrito y pagado M$ 2.141.284
Razón Social PROMARCA S.A. (Promarca)
Naturaleza jurídica Sociedad anónima cerrada % participación total en 2024 49,0000% (49,0000% en 2023)
 Avda. Presidente Eduardo Frei Montalva N° 1.500, comuna de Renca, Región % de la inversión sobre el 0,0240%
Domicilio Metropolitana activo total de la coligante
Capital suscrito y pagado M$ 25.808.443
% participación total en 2024 50,0000% (50,0000% en 2023)
Memoria Integrada 2024 208

[pág. 210]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Directores Titulares(*) Henry Bruxelles (Presidente) Directores Suplentes Antonio Cruz Stuven
 Philippe-Loic Jacob (Vicepresidente) Manuel Gastañeta Carrillo de Albornoz
 Julio Freyre Aznárez Rodrigo Jadue Roa
 Juan Garibaldi Michael Berkoff
 Fernando Sanchis Sacchi Objeto social / Actividades
Directores Suplentes Emmanuelle Marianne Bely La sociedad tiene por objeto participar en cualquier acto o actividad legal para la cual las sociedades de responsabilidad
 María Cecilia Ghezzi limitada puedan formarse bajo las leyes del Estado de Delaware.
 Andrés Pablo Glerean Esta sociedad se dedica a la producción, distribución y comercialización de pisco o destilados a base de uva en
 Ezequiel Gussoni Cattaneo Estados Unidos de América y en el extranjero.
 Gonzalo Velazco Vinculación futura proyectada
Objeto social / Actividades Se proyecta que esta sociedad continúe desarrollando actividades de producción, distribución y comercialización
La sociedad tiene por objeto realizar por cuenta propia, de terceros o asociada a terceros: (i) extracción, recolección, de pisco o destilados a base de uva en Estados Unidos de América y en el extranjero.
industrialización, producción, embotellado, distribución y comercialización en todas sus formas posibles de aguas
minerales, carbonatadas o no, saborizadas o no, con o sin agregado de jugo, y jugos en polvo, alimentos líquidos, (*) Los directores titulares señores Felipe Benavides Almarza y Domingo Jiménez Manterola y el director suplente señor Antonio
productos y subproductos derivados de aguas minerales, alimentos líquidos y aguas en general e insumos necesarios Cruz Stuven son Ejecutivos Principales de Compañía Cervecerías Unidas S.A.
para dichos productos y subproductos; y (ii) compra, venta, distribución, importación y exportación y el ejercicio
de comisiones, representaciones y consignaciones de los productos, subproductos derivados de su elaboración, ARTESANOS DE CERVEZAS S.A.S.15
y mercaderías y materias primas vinculadas con los mismos.
Esta sociedad es dueña del inmueble ubicado en la Provincia de Mendoza en el que Aguas de Origen S.A. realiza Razón Social ARTESANOS DE CERVEZAS S.A.S.
su actividad de extracción, envasado y comercialización de aguas minerales.
 Naturaleza jurídica Sociedad por acciones simplificada
Vinculación futura proyectada
 Domicilio Calle 30 N° 44 -176, Medellín, Antioquia, Colombia
Se proyecta que esta sociedad siga siendo dueña del inmueble ubicado en la Provincia de Mendoza a objeto que
Aguas de Origen S.A. continúe realizando la extracción, envasado y comercialización en todas sus formas posibles Capital suscrito y pagado M$ 451.996
de aguas minerales. % participación total en2024 100,0000% (100,0000% en 2023)
 % de la inversión sobre el 0,1309%
(*) El director titular señor Julio Freyre Aznárez es ejecutivo principal de Compañía Cervecerías Unidas S.A. activo total de la coligante
 Gerente General(*) Juan David Vélez Abad
 Suplentes Agustín Eduardo Mendizábal (Primer Suplente)
 AMERICAS DISTILLING INVESTMENTS LLC Felipe Mejía Posada (Segundo Suplente)
 Federico José Llano Molina (Tercer Suplente)
Razón Social AMERICAS DISTILLING INVESTMENTS LLC Objeto social / Actividades
Naturaleza jurídica Sociedad responsabilidad limitada La sociedad tendrá por objeto principal: (i) la fabricación de cervezas y bebidas no alcohólicas a base de malta; adquisición,
 Delaware Statutory Services, LLC, 3500 S. Dupont Highway, Dover, DE 19901, enajenación, comercialización, distribución, exportación, almacenamiento y expendio de sus propios productos y de otros
Domicilio Estados Unidos de América fabricantes relacionados con estos ramos industriales, así como la importación y nacionalización de cervezas, bebidas no-alcohólicas
Capital suscrito y pagado M$ 3.985.840 a base de malta; (ii) la adquisición, enajenación, fabricación, procesamiento, transformación, almacenamiento, distribución,
 importación, exportación, comercialización y beneficio de materias primas, productos semi-elaborados, subproductos y demás
% participación total en 2024 40,0000% (40,0000% en 2023)
 elementos propios para la industria de cervezas y de bebidas no alcohólicas a base de malta; y (iii) la ejecución de cualquier otra
% de la inversión sobre el 0,0575% actividad lícita permitida por la Ley colombiana, necesaria para la ejecución y desarrollo del objeto social.
activo total de la coligante Esta sociedad desarrolla el negocio de producción y comercialización de bebidas alcohólicas y no alcohólicas en Colombia.
Directores Titulares(*) Felipe Benavides Almarza Vinculación futura proyectada
 Carlos Ferreyros S. Se proyecta que esta sociedad continúe desarrollando el negocio de producción y comercialización de bebidas
 Domingo Jiménez Manterola alcohólicas y no alcohólicas en Colombia.
 Diego Loret de Mola
 (*) La sociedad es administrada y representada por un Gerente, quién tendrá tres suplentes con iguales facultades.
Memoria Integrada 2024 209

[pág. 211]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
 CENTRAL CERVECERA DE COLOMBIA S.A.S.16 PROMARCA INTERNACIONAL PARAGUAY SOCIEDAD DE RESPONSABILIDAD LIMITADA
Razón Social CENTRAL CERVECERA DE COLOMBIA S.A.S. (CCC y CCC S.A.S.) PROMARCA INTERNACIONAL PARAGUAY SOCIEDAD DE
 Razón Social
Naturaleza jurídica Sociedad por acciones simplificada RESPONSABILIDAD LIMITADA
Domicilio Avda. Carrera 45 N° 108-27. Torre 3, piso 21, Bogotá, Colombia Naturaleza jurídica Sociedad de responsabilidad limitada
Capital suscrito y pagado M$ 21.952.592 Domicilio Benjamín Constant N° 624, Asunción, Paraguay.
% participación total en 2024 50,0000% (50,0000% en 2023) Capital suscrito y pagado M$ 6.365
% de la inversión sobre el % participación total en 2024 99,9900% (100,0000% en 2023)
 0,4503%
activo total de la coligante % de la inversión sobre el 0,0010%
Directores Titulares(*) Francisco Pérez Mackenna (Presidente) activo total de la coligante
 Carlos Julio Ardila Gaviria Administración(*) Sigfrido Luis Gross Brown Abreu
 Vicente Borrero Calero Objeto social / Actividades
 Marc Busain La sociedad tendrá por objeto principal realizar por cuenta propia o ajena, o asociada a terceros, dentro o fuera del
 Miguel Fernando Escobar Penagos país, el licenciamiento de marcas y actividades afines. Tendrá, además, por objeto realizar por cuenta propia o ajena,
 Patricio Jottar Nasrallah o asociada a terceros, la compra, venta, intermediación, permuta, locación, administración y explotación de toda clase
Directores Suplentes Óscar Hasbún Martínez de inmuebles urbanos y/o rurales, inclusive de zonas francas en el país o en el extranjero, así como la realización de
 Miguel Ignacio Gutiérrez Navarro loteamientos, urbanizaciones, fraccionamientos y asentamientos de colonizaciones privadas, y todos aquellos actos
 Juan Fernando Maya Restrepo que autorizan las leyes y reglamentos que rigen la materia. También podrá realizar las siguientes actividades: (i)
 Ronald Lucassen Comerciales: Compra, venta, permuta, consignación, importación, exportación, reexportación, tránsito, intermediación y
 Federico José Llano Molina distribución de toda clase y para todo destino, en cualquier etapa de su industrialización, incluso en la de subproductos
 Fernando Sanchis Sacchi y desechos de todo tipo de bienes de cambio. Prestar servicios y mandatos mediante el desarrollo de toda clase
 de representaciones, distribuciones, comisiones, consignaciones y asesoramiento en administración de negocios y
Gerente General Felipe Mejía Posada
 empresas; inversiones, compraventa de toda clase de valores mobiliarios y papeles de créditos bajo cualquiera de
Suplentes Gerente General Agustín Eduardo Mendizábal (Primer Suplente - Director de Finanzas) los sistemas o modalidades creados o a crearse. Podrá también constituir sociedades y tomar participación en ellas o
 Federico José Llano Molina (Segundo Suplente - Gerente de Operaciones) en negociaciones de cualquier clase. Comprar y vender, explotar y transferir concesiones, contratar y concertar todo
 Fabián Rodríguez Gómez (Representante Legal, Judicial y Administrativo) tipo de negocios u operaciones lícitas con el Gobierno, las Municipalidades y otras Autoridades, Empresas públicas,
 María Margarita Cuellar Pineda (Representante Legal, Judicial y Administrativo) binacionales o mixtas nacionales o extranjeras y concurrir a toda clase de licitaciones o concursos públicos o privados,
Objeto social / Actividades sea en el país o en el extranjero por cuenta propia o de terceros o asociada a terceros; (ii) Industriales: Fabricación, y
La sociedad tendrá por objeto principal: (i) la fabricación de cervezas y bebidas no alcohólicas a base de malta; (ii) elaboración en todas sus etapas y formas de toda clase de productos y materias primas y todo otro tipo de actividad
la adquisición, enajenación, comercialización, distribución, exportación, almacenamiento y expendio de sus propios industrial y/o de transformación bajo cualquier tipo de régimen incluido el de maquila, zona franca u otro similar;
productos; (iii) la adquisición, enajenación, fabricación, procesamiento, transformación, almacenamiento, distribución, (iii) Construcción: Realización de todo tipo de proyectos arquitectónicos y construcciones urbanas y/o rurales; (iv)
importación, exportación, comercialización y beneficio de materias primas, productos semi-elaborados, subproductos y Franchising: Toda clase de operación de franchising nacional y/o internacional; (v) Representación: Toda forma de
demás elementos propios para la industria de cervezas y de bebidas no alcohólicas a base de malta; y (iv) la ejecución de representación de personas físicas o jurídicas, tanto nacionales como extranjeras y todo tipo de mandatos y de gestión
cualquier otra actividad lícita permitida por la ley colombiana, necesaria para la ejecución y desarrollo del objeto social. de negocios ajenos. Representación, negociación y/o gestión de marcas, patentes, licencias, franquicias y toda clase
Esta sociedad desarrolla el negocio de producción y comercialización de bebidas alcohólicas y no alcohólicas en Colombia. de concesión de empresas del país y/o del exterior; (vi) Productivas y Extractivas: Emprendimientos agropecuarios
Vinculación futura proyectada y rurales en general, explotaciones forestales, de reforestación, y acuáticas, y toda forma de extracción mineral y/o
Se proyecta que esta sociedad continúe desarrollando el negocio de producción y comercialización de bebidas química; y (vii) Transporte: Explotación de toda clase de transporte terrestre, fluvial, marítimo, aéreo o combinado,
alcohólicas y no alcohólicas en Colombia. de personas o cosas en general. Ejecutar en general, por cuenta propia, de terceros o asociada a terceros, del país
 o del extranjero, todos los actos jurídicos y operaciones que tengan relación directa o indirecta, como antecedente
(*) El director titular señor Francisco Pérez Mackenna y el director suplente señor Óscar Hasbún Martínez son directores de o consecuencia de la explotación de sus negocios, en cuyo caso tendrá capacidad jurídica para toda clase de actos
 Compañía Cervecerías Unidas S.A y el director titular señor Patricio Jottar Nasrallah es Gerente General de la misma. y contratos y para el ejercicio de todas las acciones a que hubiere lugar, sin más limitaciones que las expresamente
 establecidas en las leyes, y en sus estatutos, debiendo considerarse esta enumeración como simplemente enunciativa
 y no taxativa ni limitativa, pudiendo en consecuencia realizar todo acto de comercio lícito.
Memoria Integrada 2024 210

[pág. 212]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Esta sociedad desarrolla actividades de explotación, a través de terceros, de licencias de marcas comerciales Objeto social / Actividades
otorgadas por su matriz Promarca Internacional SpA. La sociedad tendrá como objeto social principal, actuar exclusivamente como usuario industrial de bienes y servicios
Vinculación futura proyectada de una o varias zonas francas, para la realización de las siguientes actividades: (i) maquila y/o producción y fabricación
Se proyecta que esta sociedad continúe desarrollando actividades de explotación, a través de terceros, de licencias de cervezas y bebidas no alcohólicas a base de malta, y maquila o arrendamiento de equipos o de una porción de la
de marcas comerciales otorgadas por su matriz Promarca Internacional SpA en Paraguay. planta para la fabricación de bebidas no alcohólicas a los accionistas de la sociedad o a sus compañías controlantes,
 controladas y/o bajo control común, sea directa o indirectamente; (ii) adquisición, enajenación, fabricación, procesamiento,
(*) La administración y dirección está a cargo de un Gerente designado por los socios. En la escritura de constitución de fecha 17 transformación, almacenamiento, importación, exportación y beneficio de materias primas, productos semi-elaborados,
 de abril 2017, otorgada en la Notaría de la cuidad de Asunción, República del Paraguay de don Luis Enrique Peroni Giralt, los sub productos y demás elementos propios para la industria de cervezas y bebidas no alcohólicas a base de malta,
 socios designaron como primer Gerente a don Sigfrido Luis Gross Brown Abreu. y para la maquila y/o producción y fabricación de bebidas no alcohólicas a los accionistas de la sociedad o a sus
 compañías controlantes, controladas y/o bajo control común, sea directa o indirectamente; (iii) construcción de obras
 civiles directamente o a través de sub contratistas, para la construcción de obras civiles su propia planta y bodega, y
 ZONA FRANCA CENTRAL CERVECERA S.A.S. realización de reparaciones locativas, obras de ingeniería civil, operaciones logísticas, negociar, comprar y vender toda
 clase de implementos del ramo de la construcción; (iv) adquisición, importación y exportación de equipos, maquinarias
 ZONA FRANCA CENTRAL CERVECERA S.A.S. (ZF Central Cervecera y repuestos; (v) actividad de servicios de logística, transporte, almacenamiento, manipulación de carga, control de
Razón Social inventarios, etiquetados, toma de muestras y distribución para la prestación de servicios logísticos en desarrollo de su
 S.A.S., ZF CC y ZF CC S.A.S.)
Naturaleza jurídica Sociedad por acciones simplificada objeto social, donde se realicen los procesos de logística, transporte, manipulación, distribución, empaque, reempaque,
 envase, etiquetado o clasificación a Central Cervecera de Colombia S.A.S, así como a los accionistas de la sociedad o
Domicilio Km 36 Troncal Central del Norte (Autopista Bogotá Tunja), Colombia
 a sus compañías controlantes, controladas y/o bajo control común, sea directa o indirectamente; y (vi) la ejecución de
Capital suscrito y pagado M$ 20.353.399 cualquier otra actividad lícita permitida por la ley colombiana, necesaria para la ejecución y desarrollo del objeto social.
% participación total en2024 50,0000% (50,0000% en 2023) Se entenderán incluidos en el objeto social los actos directamente relacionados con el mismo y los que tengan como
% de la inversión sobre el finalidad ejercer los derechos o cumplir las obligaciones, legal o convencionalmente derivados de la existencia y actividad
 3,4311% de la sociedad.
activo total de la coligante
Directores Titulares(*) Francisco Pérez Mackenna (Presidente) Esta sociedad desarrolla el negocio de producción y comercialización de bebidas alcohólicas y no alcohólicas en Colombia.
 Carlos Julio Ardila Gaviria Vinculación futura proyectada
 Vicente Borrero Calero Se proyecta que esta sociedad continúe desarrollando el negocio de producción y comercialización de bebidas
 Marc Busain alcohólicas y no alcohólicas en Colombia.
 Miguel Fernando Escobar Penagos
 (*) El director titular señor Francisco Pérez Mackenna y el director suplente señor Óscar Hasbún Martínez son directores de
 Patricio Jottar Nasrallah
 Compañía Cervecerías Unidas S.A., y el director titular señor Patricio Jottar Nasrallah es Gerente General de la misma.
Directores Suplentes Óscar Hasbún Martínez
 Miguel Ignacio Gutiérrez Navarro
 Juan Fernando Maya Restrepo
 Federico José Llano Molina
 Ronald Lucassen
 Fernando Sanchis Sacchi
Gerente General Felipe Mejía Posada
Suplentes Gerente General Agustín Eduardo Mendizábal (Primer Suplente del Representante Legal)
 Federico José Llano Molina (Segundo Suplente del Representante Legal)
 Juan Alejandro Vásquez Arango (Tercer Suplente del Representante Legal)
 Fabián Rodríguez Gómez (Representante Legal, Judicial y Administrativo)
 María Margarita Cuellar Pineda (Representante Legal, Judicial y Administrativo)
Memoria Integrada 2024 211

[pág. 213]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
Notas Filiales y Coligadas 3. CERVECERÍA KUNSTMANN S.A. y CERVECERÍA SZOT SpA
 En Junta Extraordinaria de Accionistas de fecha 23 de mayo de 2024, según consta en escritura pública de fecha 24
1. CCU INVERSIONES II SpA de mayo de 2024 otorgada en la Notaría de Santiago de don Juan Ricardo San Martín Urrejola, se acordó modificar el
 objeto social a fin de incluir la comercialización de cualquier forma de cervezas sin alcohol, así como la elaboración,
Mediante Acuerdo de Accionistas sin forma de Junta, según consta de escritura pública de fecha 26 de enero de venta y distribución de alimento y suplemento para animales. Un extracto de dicha escritura se inscribió a fojas 182
2024 otorgada en la Notaría de Santiago de don Juan Ricardo San Martín Urrejola, Compañía Cervecerías Unidas vuelta bajo el N° 101 en el Registro de Comercio a cargo del Conservador de Bienes Raíces de Valdivia correspondiente
S.A. y CCU Inversiones S.A., en su calidad de únicos accionistas de CCU Inversiones II SpA, acordaron aumentar el al año 2024 y se publicó en el Diario Oficial de fecha 8 de junio del mismo año.
capital de la sociedad en la cantidad de USD 41.775.000, esto es, desde la cantidad de USD 304.334.863 dividido
en 237.008.523 acciones nominativas, de una sola serie y sin valor nominal, íntegramente suscrito y pagado, a la Mediante instrumento privado de fecha 29 de abril de 2024 Cervecería Kunstmann S.A. vendió a Cervecería Szot SpA
cantidad de USD 346.109.863 dividido en 269.541.863 acciones nominativas, de una sola serie y sin valor nominal, la totalidad de las acciones que detentaba en la referida sociedad. El pago de dichas acciones se efectuó mediante
mediante la emisión de 32.533.340 nuevas acciones de iguales características, íntegramente suscritas y pagadas en la transferencia del dominio de las marcas “Szot”, “Szot Cerveza Artesanal Chilena” y “Soñada en California Criada en
el mismo acto por Compañía Cervecerías Unidas S.A. Un extracto de dicha escritura se inscribió a fojas 10.209, bajo Chile Szot”. En consecuencia, en dicha fecha, Cervecería Kunstmann S.A., dejó de ser accionista en Cervecería Szot
el N° 4.454 del Registro de Comercio a cargo del Conservador de Bienes Raíces de Santiago de 2024 y se publicó SpA y pasó a ser titular de las marcas antes indicadas.
en el Diario Oficial de 3 de febrero del mismo año.
 4. CIRCCULAR SpA
Mediante instrumento privado de fecha 12 de diciembre de 2024, CCU Inversiones II SpA vendió y cedió al señor
Friedrich Pershak la totalidad de las acciones de que era titular en su filial uruguaya Coralina S.A., ascendente al cien Mediante escritura pública de fecha 1 de febrero de 2024 otorgada en la Notaría de Santiago de don Juan Ricardo
por ciento de las acciones suscritas y pagadas de la referida sociedad, procediéndose con igual fecha al cumplimiento San Martín Urrejola, Millahue S.A., en calidad de único accionista, constituyó la sociedad CirCCUlar SpA. El capital de
de todos los actos y comunicaciones a las autoridades uruguayas correspondientes. En consecuencia, a contar del la sociedad de $ 10.000.000.000 dividido en 10.000.000 acciones ordinarias, nominativas, de una sola serie y sin valor
12 de diciembre de 2024, Coralina S.A. dejó de ser filial de CCU Inversiones II SpA. nominal, se suscribió íntegramente por Millahue S.A., quien pagó 2.000.000 de acciones, con la suma de $ 2.000.000.000,
 en dinero efectivo y se obligó a pagar el saldo de 8.000.000 de acciones, ascendente a la suma de $ 8.000.000.000, en
2. CERVECERA GUAYACÁN SpA el plazo de 5 años contados desde la fecha de la escritura de constitución. Un extracto de dicha escritura fue inscrito
 a fojas 11.207, bajo el N° 4.908 del Registro de Comercio a cargo del Conservador de Bienes Raíces de Santiago
Mediante escritura pública de fecha 26 de abril de 2024 otorgada en la Notaría de Santiago de don Juan Ricardo San correspondiente al año 2024 y se publicó en el Diario Oficial de fecha 8 de febrero del mismo año.
Martín Urrejola, los accionistas Inversiones Diaguitas #33 SpA y Cervecería Kunstmann S.A. en su calidad de únicos
accionistas de Cervecera Guayacán SpA, acordaron aumentar el capital social de $ 898.630.795 dividido en 261.538 5. EMBOTELLADORAS CHILENAS UNIDAS S.A.
acciones ordinarias, nominativas de una sola serie y sin valor nominal, con iguales derechos económicos y políticos,
a la suma de $ 982.762.180 dividido en 326.922 acciones de iguales características, íntegramente suscritas a ser En Junta Extraordinaria de Accionistas celebrada con fecha 25 de noviembre de 2023, según consta de escritura
pagadas en el plazo de 30 días por el accionista Cervecería Kunstmann S.A. Un extracto de dicha escritura se inscribió pública de fecha 26 de marzo de 2024, otorgada en la Notaría de Santiago de don Juan Ricardo San Martín Urrejola,
en el registro de Comercio a cargo del Conservador de Bienes Raíces de Santiago a fojas 37.323 bajo el N° 15.475 se acordó ampliar el objeto social a fin de incluir la fabricación, elaboración, transformación, gestión, reciclaje,
correspondiente al año 2024 y se publicó en el Diario Oficial de fecha 9 de mayo del mismo año. valorización, producción, importación, compra, venta, exportación, distribución y comercialización de todo tipo de
 productos e insumos de plástico y sus derivados, materias primas, artículos, mercaderías, productos, implementos,
 partes, piezas, envases, y otros bienes corporales muebles que digan relación con la industria del plástico, su
Memoria Integrada 2024 212

[pág. 214]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
valorización y reciclaje, así como la distribución, comercialización, exportación, venta y en general la enajenación de Con fecha 31 de julio de 2024 Compañía Cervecerías Unidas Argentina S.A. adquirió de Holding Internationale de
estos bienes, ya sea en el mismo estado, reciclados o transformados. Un extracto de dicha escritura se inscribió a Boissons S.A.S. el 0,1% de las acciones de Aguas de Origen S.A., quedando en consecuencia con el 50,1% de las
fojas 27.778 bajo el N° 11.776 del Registro de Comercio a cargo del Conservador de Bienes Raíces del año 2024 y acciones de dicha sociedad y Holding Internationale de Boissons S.A.S. con el 49,9% restante. A contar de dicha
se publicó en el Diario Oficial de fecha 10 de abril del mismo año. fecha Aguas de Origen S.A. pasó a ser filial de Compañía Cervecerías Unidas Argentina S.A.
6. MILLAHUE S.A. 8. AV S.A.
En Junta Extraordinaria de Accionistas celebrada con fecha 29 de agosto de 2024, según consta de escritura pública Mediante escritura pública N° 27 de fecha 22 de mayo de 2008, otorgada en la Notaría del Escribano Público César
de fecha 13 de septiembre de 2023, otorgada en la Notaría de Santiago de don Juan Ricardo San Martín Urrejola, se Augusto Sanabria Vierci, inscrita ante los Registros Públicos el 11 de mayo de 2008, se constituyó la sociedad anónima
acordó aumentar el capital de la sociedad en $ 7.002.654.006, esto es, desde la cantidad de $ 3.124.668.612 dividido denominada AV S.A.
en 25.600.000 acciones nominativas de una misma y única serie y sin valor nominal, íntegramente suscrito y pagado,
a la suma de $ 10.127.322.618 dividido en 42.742.310 acciones nominativas de una misma y única serie y sin valor Mediante instrumento privado de fecha 14 de octubre del 2024, los accionistas Antonio Juan Bautista Vierci Mendoza
nominal, mediante la emisión de 17.142.310 acciones de pago, de idénticas características, a ser suscritas por los y Ana María Yakisich de Vierci cedieron y transfirieron un total de 3.011 acciones de dicha sociedad a favor de CCU
accionistas a prorrata de sus participaciones y pagadas dentro del plazo de 2 meses desde la fecha de la referida Inversiones II SpA, ascendente al 51% de las acciones suscritas e integradas de la misma, procediéndose dentro
Junta Extraordinaria de Accionistas. Un Extracto de dicha escritura se inscribió a fojas 95.761 bajo el N° 38.274 del de los plazos legales previstos en la legislación paraguaya al cumplimiento de todos los actos y comunicaciones a
Registro de Comercio a cargo del Conservador de Bienes Raíces de Santiago del año 2024. El referido extracto fue las autoridades paraguayas correspondientes. En consecuencia, a contar de dicha fecha, AV S.A. paso a ser filial de
rectificado e inscrito a fojas 96.136 bajo el N° 38.426 del Conservador de Bienes Raíces de Santiago del año 2024 CCU Inversiones II SpA.
y ambos fueron publicados en el Diario Oficial de fecha 13 de noviembre del mismo año. Únicamente el accionista
Compañía Cervecerías Unidas S.A. pagó dentro del plazo el aumento de capital antes indicado reduciéndose éste En Asamblea Extraordinaria de Accionistas de fecha 1 de noviembre del 2024, se resolvió modificar los estatutos
de pleno derecho a la suma de $ 7.000.000 dividido en 17.135.813 acciones ordinarias, nominativas de una sola sociales, entre otras materias, en lo que respecta al derecho de preferencia para la adquisición de acciones, dirección
serie y sin valor nominal. En consecuencia, el capital de la sociedad asciende a la suma de $ 10.124.668.612 divido y administración de la sociedad, representación legal, quórums y mayorías en reuniones de Directorio y asambleas.
en 42.735.813 acciones nominativas de una sola serie y sin valor nominal. Esta modificación de estatutos se encuentra en proceso de protocolización e inscripción ante los Registros Públicos.
7. AGUAS DE ORIGEN S.A. 9. BEBIDAS BOLIVIANAS BBO S.A.
Con fecha 27 de abril de 2022, Compañía Cervecerías Unidas Argentina S.A. adquirió el 49% de las acciones de En Junta General Extraordinaria de Accionistas de fecha 23 de enero de 2024, según consta en Escritura Pública
Aguas Danone de Argentina S.A. y de Aguas de Origen S.A. En Asamblea Extraordinaria de Accionistas de fecha 30 N° 216/2024 de fecha 12 de marzo de 2024, otorgada en la Notaría de Fe Pública N° 13 del Distrito Judicial de
de junio del 2022, se resolvió la fusión - escisión entre Aguas Danone de Argentina S.A. y Aguas de Origen S.A., la Santa Cruz, a cargo de la Dra. Sarita Cuellar Roca, se acordó un aumento de capital social suscrito y pagado de
cual tuvo fecha efectiva de reorganización el 1 de diciembre del año 2022. La fusión se inscribió con fecha 19 de Bs. 111.446.000 a Bs. 125.366.000.
enero de 2024 ante la Inspección General de Justicia de la Ciudad de Buenos Aires, Argentina.
 En Junta General Extraordinaria de Accionistas de fecha 19 de marzo de 2024, según consta en Escritura Púbica
Asimismo, con fecha 1 de diciembre de 2022 Compañía Cervecerías Unidas Argentina S.A. adquirió el 1% de las N° 248/2024 de fecha 26 de marzo de 2024, otorgada en la Notaría de Fe Pública N° 13 del Distrito Judicial
acciones de Aguas de Origen S.A. quedando en consecuencia con el 50% de las acciones de dicha sociedad. de Santa Cruz, a cargo de la Dra. Sarita Cuellar Roca, se acordó una reducción de capital suscrito y pagado
 de Bs. 125.366.000 a Bs. 95.366.000.
Memoria Integrada 2024 213

[pág. 215]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
En Junta General Extraordinaria de Accionistas de fecha 3 de abril de 2024, según consta en Escritura Pública En Asamblea Extraordinaria de Accionistas de fecha 14 de noviembre del 2024, se resolvió modificar los estatutos
N° 425/2024 de fecha 27 de mayo de 2024, otorgada por en la Notaría de Fe Pública N° 13 del Distrito Judicial sociales, entre otras materias, en lo que respecta al derecho de preferencia para la adquisición de acciones, dirección
de Santa Cruz, a cargo de la Dra. Sarita Cuellar Roca, se acordó un aumento de capital suscrito y pagado de y administración de la sociedad, quórums respecto reuniones de directorio y asambleas, y distribución de dividendos.
Bs. 95.366.000 a Bs. 102.326.000. Esta modificación de estatutos se encuentra en proceso de protocolización e inscripción ante los Registros Públicos.
En Junta General Extraordinaria de Accionistas de fecha 28 de junio de 2024, según consta en Escritura Pública N° 699/2024 Mediante instrumento privado de fecha 11 de diciembre de 2024, los accionistas de Bebidas del Paraguay S.A.,
de fecha 27 de agosto de 2024, otorgada por en la Notaría de Fe Pública N° 13 del Distrito Judicial de Santa Cruz a cargo CCU Inversiones II SpA y CCU Inversiones S.A., cedieron y transfirieron un total de 9.475 acciones de Bebidas
de la Dra. Sarita Cuellar Roca, se acordó aumentar el capital suscrito y pagado de Bs. 102.326.000 a Bs. 116.246.000. del Paraguay S.A. al señor Antonio Juan Bautista Vierci Mendoza y a la señora Ana María Yakisich de Vierci,
 procediéndose dentro de los plazos legales previstos en la legislación paraguaya al cumplimiento de todos los actos
En Junta General Extraordinaria de Accionistas de fecha 9 de diciembre de 2024, según consta en Escritura Pública y comunicaciones a las autoridades paraguayas correspondientes. En consecuencia, a contar de dicha fecha, los
N° 67/2025 de fecha 17 de febrero de 2025, otorgada en la Notaría de Fe Pública N° 88 del Distrito Judicial de Santa señores Antonio Bautista Vierci Mendoza y Ana María Yakisich de Vierci pasaron a ser accionistas de Bebidas del
Cruz, se acordó un aumento de capital suscrito y pagado de Bs. 116.246.000 a Bs. 122.510.000. Paraguay S.A. con un 42,7842% del capital social, el cual, una vez cumplidas todas las condiciones de los acuerdos
 alcanzados con Grupo Vierci, ascenderá al 49%, permaneciendo CCU Inversiones II SpA con el 51% restante.
En Junta General Extraordinaria de Accionistas de fecha 24 de febrero de 2025, se resolvió una reducción de capital
suscrito y pagado de Bs. 122.510.000 a Bs. 105.000.000. Adicionalmente, en una segunda Junta General Extraordinaria 11. COMPAÑÍA INDUSTRIAL CERVECERA S.A.
de Accionistas celebrada en la misma fecha, se resolvió un aumento de capital suscrito y pagado de Bs. 105.000.000
a Bs. 108.480.000. Las referidas modificaciones estatutarias se encuentran en proceso de inscripción. En Asamblea Extraordinaria de Accionistas de fecha 28 de julio de 2023 se aprobó la fusión por absorción de Saénz
 Briones y CÍA S.A.I.C. en Compañía Industrial Cervecera S.A. con efecto a partir del 1 de mayo de 2023, y la reforma
10. BEBIDAS DEL PARAGUAY S.A. al estatuto social de la sociedad absorbente a fin de incorporar a su objeto social las actividades que desarrollaba
 Sáenz Briones y Cía. S.A.I.C. Para la materialización de la fusión se dio cumplimiento a todos los requisitos formales
Con fecha 20 de febrero de 2024, en virtud del acuerdo de Opciones Put y Call celebrado con fecha 16 de marzo de y etapas establecidas en la normativa argentina aplicable. La fusión se inscribió y aprobó por la Inspección General
2023 entre CCU Inversiones II SpA y Sudameris Bank S.A.E.C.A. (Sudameris), y como consecuencia del ejercicio por de Justicia de la Ciudad de Buenos Aires con fecha 11 de noviembre de 2024 y ante la Inspección de Personas
parte de esta última de la Opción Put, CCU Inversiones II SpA y CCU Inversiones S.A. adquirieron de Sudameris la Jurídicas de la Provincia de Salta con fecha 25 de septiembre del mismo año.
totalidad de las acciones de Bebidas del Paraguay S.A. y Distribuidora del Paraguay S.A. de propiedad de este último. En
consecuencia, a partir de dicha fecha, los únicos accionistas de Bebidas del Paraguay S.A. y Distribuidora del Paraguay Conforme a la normativa aplicable, desde la fecha efectiva de fusión acordada, esto es, desde el 1 de mayo de 2023
S.A. eran CCU Inversiones II SpA y CCU Inversiones S.A. y hasta el día 11 de noviembre de 2024, fecha en que se produce la disolución sin liquidación de Sáenz Briones y
 Cía. S.A.I.C., la administración, desarrollo del negocio y representación de Sáenz Briones y Cía. S.A.I.C. se llevó a cabo
En Asamblea Extraordinaria de Accionistas de fecha 11 de septiembre de 2024, se acordó aumentar el capital social a la por el Directorio de Compañía Industrial Cervecera S.A.
suma de Gs. 221.460.000.000 a efectos de capitalizar la prima de emisión de acciones ascendente a Gs. 118.430.000.000.
Asimismo, en Asamblea Ordinaria de Accionistas celebrada en la misma fecha, se acordó aprobar la capitalización 12. DISTRIBUIDORA DEL PARAGUAY S.A.
de dicha prima de emisión y la consecuente integración de las acciones e impresión de los títulos representativos de
las mismas. La modificación de estatutos por aumento de capital social se encuentra protocolizada por instrumento Con fecha 20 de febrero de 2024, en virtud del acuerdo de Opciones Put y Call celebrado con fecha 16 de marzo
público N° 299 de fecha 8 de octubre de 2024, otorgado en la Notaría del Escribano Público Oscar Doldán Livieres, e de 2023 entre CCU Inversiones II SpA y Sudameris Bank S.A.E.C.A. (Sudameris), y como consecuencia del ejercicio
inscrito ante los Registros Públicos con fecha 16 de octubre del mismo año. por parte de esta última de la Opción Put, CCU Inversiones II SpA y CCU Inversiones S.A. adquirieron de Sudameris
Memoria Integrada 2024 214

[pág. 216]
Capítulos / 1 2 3 4 5 6 7 8 9 10 11 12 Anexos
la totalidad de las acciones de Bebidas del Paraguay S.A. y Distribuidora del Paraguay S.A. de propiedad de este Nicolas Spitzer Ascui, Daniel López Medina y la señora Daniell Coll Cortés. Se acordó, asimismo, que la reforma de
último. En consecuencia, a partir de dicha fecha, los únicos accionistas de Bebidas del Paraguay S.A. y Distribuidora estatutos antes indicada, así como la revocación y elección del nuevo Directorio, produjeran sus efectos una vez
del Paraguay S.A. eran CCU Inversiones II SpA y CCU Inversiones S.A. legalizada la referida reforma de estatutos. Un extracto de la referida escritura pública se inscribió a fojas 9.235,
 bajo el N° 4.047 del Registro de Comercio a cargo del Conservador de Bienes Raíces de Santiago correspondiente
Mediante instrumento privado de fecha 14 de octubre del 2024, los accionistas de Distribuidora del Paraguay S.A., al año 2024 y se publicó en Diario Oficial de fecha 3 de febrero del mismo año.
CCU Inversiones II SpA y CCU Inversiones S.A., cedieron y transfirieron un total de 611 acciones que detentaban de
Distribuidora del Paraguay S.A., ascendente a un 49% de las acciones suscritas e integradas de ésta última, a los 15. ARTESANOS DE CERVEZAS S.A.S.
señores Antonio Juan Bautista Vierci Mendoza y Ana María Yakisich de Vierci, procediéndose dentro de los plazos
legales previstos en la legislación paraguaya al cumplimiento de todos los actos y comunicaciones a las autoridades De conformidad al Acta N° 16 del 12 de octubre de 2023, y considerando que el capital autorizado de la sociedad
paraguayas correspondientes. En consecuencia, a contar de dicha fecha, los señores Antonio Juan Bautista Vierci ascendía a COP 2.000.000.000 dividido en 2.000.000 acciones y el capital suscrito y pagado a COP 1.962.000.000
Mendoza y Ana María Yakisich de Vierci pasaron a ser accionistas de Distribuidora del Paraguay S.A. dividido en 1.962.000 acciones, se acordó: i) emitir, colocar y ofrecer al accionista un total de 36.000 acciones, por un
 monto total de COP 36.000.000, a un precio de suscripción por acción de COP 1.000. Conforme a la referida Acta, no
En Asamblea Extraordinaria de Accionistas de fecha 31 de octubre de 2024 se resolvió modificar los estatutos sociales, hubo lugar a expedir un reglamento de emisión y colocación de acciones, toda vez que se trata de una capitalización
entre otras materias, en lo que respecta al derecho de preferencia para la adquisición de acciones, dirección y de créditos; y ii) Una vez aprobada la capitalización de pasivos, emitir, colocar y ofrecer 2.000 acciones ordinarias
administración de la sociedad, quórums respecto de reuniones de Directorio y asambleas, y distribución de dividendos. a favor del accionista único, pasando el capital suscrito y pagado de COP 1.998.000.000 dividido en 1.998.0000
Esta modificación de estatutos se encuentra en proceso de protocolización e inscripción ante los Registros Públicos. acciones a COP 2.000.000.000, equivalente a 2.000.000 acciones de valor nominal de COP 1.000 por acción.
13. COMERCIAL PATAGONA LIMITADA 16. CENTRAL CERVECERA DE COLOMBIA S.A.S.
Mediante escritura pública de fecha 9 de mayo de 2024 otorgada en la Notaría de Santiago don Juan Ricardo San De conformidad con el reglamento de emisión y colocación de acciones aprobado por la Junta Directiva de la
Martín Urrejola, los socios de Comercial Patagona Limitada acordaron modificar los estatutos de dicha sociedad sociedad, según consta en el Acta N° 38 del 23 de enero de 2024, y considerando que el capital autorizado de
estableciendo que la administración y uso de la razón social corresponderá al socio Cervecería Austral S.A., que la la sociedad ascendía a COP 500.000.000.000 dividido en 500.000.000 acciones y el capital suscrito y pagado
ejercerá por intermedio de uno o más mandatarios que designe especialmente para este efecto mediante escritura a COP 96.276.132.000 dividido en 96.276.132 acciones, se acordó emitir, colocar y ofrecer a los accionistas
pública que deberá inscribirse en el Registro de Comercio respectivo. Un extracto de dicha escritura fue inscrito a un total de 860.000 acciones, por un monto total de COP 86.000.000.000, a un precio de suscripción por acción
fojas 227 vta., bajo el N° 117 del Registro de Comercio a cargo del Conservador de Bienes Raíces de Punta Arenas de COP 1.000, de los cuales se imputa la suma de COP 85.140.000.000 a la cuenta de prima en colocación de
correspondiente al año 2024 y se publicó en el Diario Oficial de fecha 24 de mayo del mismo año. acciones. Conforme al referido reglamento, el pago de las acciones suscritas se efectuó en dinero en efectivo según
 el cronograma que en el mismo se establece.
14. PROMARCA S.A.
En Junta Extraordinaria de Accionistas celebrada con fecha 24 de enero de 2024, cuya acta se redujo a escritura
pública con fecha 25 de enero de 2024 en la Notaría de Santiago de don Iván Torrealba Acevedo, se acordó,
entre otras materias, la disminución del número de directores de 6 a 4 y, consecuentemente, la modificación de
los quórums de constitución y adopción de acuerdos en el Directorio. En virtud de lo anterior, en dicha Junta se
procedió a revocar al Directorio y a designar nuevos directores, siendo electos los señores Pablo Tagle Quiroz,
Memoria Integrada 2024 215

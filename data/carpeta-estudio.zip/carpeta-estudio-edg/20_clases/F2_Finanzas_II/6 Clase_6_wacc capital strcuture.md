# Finanzas II · 6 Clase_6_wacc capital strcuture

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 6: Costo de Capital & Capital Structure
 Profesor: Augusto Orellana
 Marzo 2026
Prof: Augusto Orellana Clase 6: WACC & Capital Structure 1 / 32

[pág. 2]
Roadmap
1 Modigliani & Miller
2 Riesgo
3 EPS & Leverage
4 Impuestos
5 Recapitalization
6 WACC & Taxes
7 Medición del riesgo financiero
8 Recap & WACC
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 2 / 32

[pág. 3]
Estructura de Capital y Cost of Capital
¿Cómo varı́a el costo de capital cuando cambia el capital structure?
¿Es relevante la estructura de capital? ¿Por qué?
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 3 / 32

[pág. 4]
Roadmap
1 Modigliani & Miller
2 Riesgo
3 EPS & Leverage
4 Impuestos
5 Recapitalization
6 WACC & Taxes
7 Medición del riesgo financiero
8 Recap & WACC
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 4 / 32

[pág. 5]
Modigliani & Miller: Proposición I
En un mercado de capitales perfecto, el valor total de una empresa es igual
al valor de mercado del total de flujos de efectivo generados por sus
activos, y no lo afecta la selección de su estructura de capital.
 E +D =U =A (1)
El valor total de la empresa es igual al de sus activos, esté
apalancada o no.
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 5 / 32

[pág. 6]
Modigliani & Miller: Proposición I
Ley de precio único:
 En un mercado de capitales perfecto, el flujo de caja pagado a los
 aportadores de recursos es igual al flujo de caja generado por los
 activos.
 Demuestre que Vu = Va
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 6 / 32

[pág. 7]
Modigliani & Miller: Proposición II
El costo del capital propio apalancado (con riesgo) es igual al costo de
capital propio no apalancado (sin riesgo) más una prima por riesgo que es
proporcional a la razón a valor de mercado de deuda a capital.
 D
 re = ru + ∗ (ru − rd )
 E
Recordar que por MMI:
 E + D = U = A ⇒ ru = rA (2)
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 7 / 32

[pág. 8]
Modigliani & Miller: Proposición II
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 8 / 32

[pág. 9]
Roadmap
1 Modigliani & Miller
2 Riesgo
3 EPS & Leverage
4 Impuestos
5 Recapitalization
6 WACC & Taxes
7 Medición del riesgo financiero
8 Recap & WACC
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 9 / 32

[pág. 10]
Betas apalancadas y no apalancadas
Si el re cambia cuando ↑ D, ¿Qué pasa con el riesgo del Equity de la
firma (βe )?
 Equity systematic risk:
 1 Business risk → βu
 2 Financial risk → D
 E ∗ (βu − βd )
 D
 βe = βu + (βu − βd )
 E
Si la estructura de capital cambia (↑ D):
 βu no cambia. ¿Por qué?
 ▶ Riesgo de mercado de los proyectos (operaciones) similares
 βe cambia. ¿Sube o baja?
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 10 / 32

[pág. 11]
Riesgo y Estructura de Capital: Airline Industry
 D
 βe = βu + (βu − βd )
 E
 βu muy similares (casi iguales) ¿Por qué?
 βe muy distintas ¿Por qué?
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 11 / 32

[pág. 12]
Roadmap
1 Modigliani & Miller
2 Riesgo
3 EPS & Leverage
4 Impuestos
5 Recapitalization
6 WACC & Taxes
7 Medición del riesgo financiero
8 Recap & WACC
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 12 / 32

[pág. 13]
EPS y Estructura de Capital
Recordemos:EPS = Net Income / Total shares
 La sensibilidad del EPS ante cambios en EBIT es mayor para una
 empresa apalancada → DFL!
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 13 / 32

[pág. 14]
Modigliani & Miller: Supuestos
Supuestos:
 1 No impuestos
 2 No hay costos directos de financial distress (ej: costo de bancarrota)
 3 No hay costos indirectos de financial distress
 4 No hay costos directos de transacción (ej: comisiones)
 5 Managers no manejan información privada
 6 No hay problemas de agencia
 7 Inversionistas pueden prestar y pedir prestado a la misma tasa que la
 firma
 8 Mercado completamente competitivo y eficiente
¿Realistas?
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 14 / 32

[pág. 15]
Roadmap
1 Modigliani & Miller
2 Riesgo
3 EPS & Leverage
4 Impuestos
5 Recapitalization
6 WACC & Taxes
7 Medición del riesgo financiero
8 Recap & WACC
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 15 / 32

[pág. 16]
Impuestos
Algunas consideraciones:
 Las empresas pagan impuestos sobre las utilidades que generan.
 Interest expense is tax-deductible.
 Ejemplo:
 ▶ ¿Cuánto llega a debt-holders?
 ▶ ¿Cuánto llega a equity-holders?
 ▶ ¿En qué escenario es mayor el beneficio?
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 16 / 32

[pág. 17]
Impuestos: Interest Expense Tax Shield
Interest Expense Tax Shield:
 rd ∗ D ∗ tc (80*0.21=16.80)
Valor presente de los Interest Expense Tax Shield :
 rd ∗ D ∗ tc
 PV IETS = = D ∗ tc (3)
 rd
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 17 / 32

[pág. 18]
IETS y el valor de la firma
Valor de una Firma Apalancada:
 VL = VU + D ∗ tc (4)
La estructura de capital es relevante!
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 18 / 32

[pág. 19]
Valor de una Firma Apalancada:
 El valor total de los activos (valor de la firma) es igual al valor
 presente de los flujos de los activos operacionales y de los tax shield
 ¡La identidad contable se mantiene! A=D+E
 Pero tambien es cierto que: A=Vu + Tc D
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 19 / 32

[pág. 20]
Roadmap
1 Modigliani & Miller
2 Riesgo
3 EPS & Leverage
4 Impuestos
5 Recapitalization
6 WACC & Taxes
7 Medición del riesgo financiero
8 Recap & WACC
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 20 / 32

[pág. 21]
Recapitalizar para capturar el escudo fiscal
 ¿Qué ocurre con el valor de la firma?
 El valor del Equity cae después de la recapitalización
 ▶ ¿Por qué un Recap es beneficioso para los accionistas?
 ¿Qué pasa con el efectivo de la recompra de acciones? ¿Quién lo
 recibe?
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 21 / 32

[pág. 22]
Roadmap
1 Modigliani & Miller
2 Riesgo
3 EPS & Leverage
4 Impuestos
5 Recapitalization
6 WACC & Taxes
7 Medición del riesgo financiero
8 Recap & WACC
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 22 / 32

[pág. 23]
WACC & Impuestos
Verdadero cost of debt:
 (1 − t) ∗ rd
Si el rendimiento requerido por los prestamistas es rd , el costo después de
impuestos para la empresa es (1 − t) ∗ rd
WACC (Weighted Average Cost of Capital)
 D E
 WACC = ∗ (1 − t) ∗ rd + ∗ re
 A A
Cost of equity
 D
 re = ru + (ru − rd ) ∗ ∗ (1 − t)
 E
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 23 / 32

[pág. 24]
Roadmap
1 Modigliani & Miller
2 Riesgo
3 EPS & Leverage
4 Impuestos
5 Recapitalization
6 WACC & Taxes
7 Medición del riesgo financiero
8 Recap & WACC
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 24 / 32

[pág. 25]
Fuentes de riesgo en la rentabilidad patrimonial
    
 D D
 re = ROE = OROA(PGU) ∗ 1 + − rd ∗ (1 − tc )
 E E
Suponiendo estructura tributaria dada y relación D/E constante, y
recordando que:
 Var (A + B) = σ 2 = σA2 + σB2 ± 2 ∗ σA ∗ σB
 Var (kA) = k 2 σA2
 h 2 i
 D 2 2
 1+ D 1+ D D
   
σre = (1 − tc )2 E
 2
 σPGU + E σrd − 2 E E σPGU σrd ρPGU,rd
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 25 / 32

[pág. 26]
Medición del riesgo financiero: Ejercicio
Una empresa tiene ventas que siguen una distribución normal. Como
resultado, la utilidad neta también se distribuye normalmente.
Se sabe que:
 Si la empresa no tiene deuda (D/E = 0), la utilidad neta tiene:
 ▶ Media: $144,000
 ▶ Desviación estándar: $80,000
 Si la empresa tiene una relación deuda/patrimonio igual a 1 (D/E =
 1), la utilidad neta tiene:
 ▶ Media: $108,000
 ▶ Desviación estándar: $80,000
Se pide calcular la probabilidad de que la utilidad neta sea negativa en
ambos casos.
Supuesto: La utilidad neta sigue una distribución normal y la única fuente
de incertidumbre proviene de las ventas.
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 26 / 32

[pág. 27]
Medición del riesgo financiero
Caso 1: Sin deuda (D/E = 0)
  
 Ut. Neta − 144,000 0 − 144,000
P(Ut. Neta ≤ 0) = P ≤ = P(Z ≤ −1.80) ≈ 0.0359
 80,000 80,000
Caso 2: Con deuda (D/E = 1)
  
 Ut. Neta − 108,000 0 − 108,000
P(Ut. Neta ≤ 0) = P ≤ = P(Z ≤ −1.35) ≈ 0.0885
 80,000 80,000
Conclusión:
El uso de deuda aumenta la probabilidad de pérdidas:
 3.59% → 8.85%
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 27 / 32

[pág. 28]
Roadmap
1 Modigliani & Miller
2 Riesgo
3 EPS & Leverage
4 Impuestos
5 Recapitalization
6 WACC & Taxes
7 Medición del riesgo financiero
8 Recap & WACC
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 28 / 32

[pág. 29]
¿Cómo la recapitalización affecta el WACC?
¿Cómo sabemos “cuanto” cambia el wacc?
 “de-levering” and “re-levering” formulas 1
¿Para qué tipo de firmas es válida
esta aproximación?
 Firmas Maduras: No growth
 1
 Los profesionales utilizan fórmulas derivadas para casos especiales que son
extremadamente fáciles de analizar. Nosotros también utilizaremos estas fórmulas
derivadas para casos especiales, con la esperanza de que los cálculos sean muy similares
a los cálculos “correctos”.
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 29 / 32

[pág. 30]
¿De qué se trata el de-levering y el re-levering?
 1 Relevering: Calcular ru , asumiendo D actual
 2 Delevering: Calcular el nuevo rˆe , considerando la nueva deuda D ′
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 30 / 32

[pág. 31]
Relevering y De-levering para firmas Maduras
 De-levering:
 1 Usando re = ru + (ru − rd ) ∗ D
 E ∗ (1 − t), despejamos ru :
 rd (1 − t)D + re E
 ru =
 (1 − t)D + E
 Re-levering:
 2 Usando la nueva información de D’ y E’, calculamos el nuevo rˆe :
 D′
 rˆe = ru + (ru − rd ) ∗ ∗ (1 − t)
 E′
 3 Recalculamos WACC con la nueva información:
 ′ ′ ′
  
 ˆ = D E tD
 WACC ∗ (1 − t) ∗ rd + ′ ∗ rˆe = ru 1 − ′
 A′ A A
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 31 / 32

[pág. 32]
A mayor leverage, menor WACC:
 tD ′
  
 ˆ
 WACC = ru 1 − ′
 A
 Prof: Augusto Orellana Clase 6: WACC & Capital Structure 32 / 32

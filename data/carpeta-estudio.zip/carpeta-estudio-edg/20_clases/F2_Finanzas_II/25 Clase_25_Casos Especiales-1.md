# Finanzas II · 25 Clase_25_Casos Especiales-1

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
Clase 25: Casos especiales de evaluación de proyectos
 Profesor: Augusto Orellana
 Junio 2026
Prof: Augusto Orellana Clase 25: Casos especiales 1 / 40

[pág. 2]
Roadmap
1 Distinta vida útil
2 Reemplazo Maquinaria
3 Projectos de Inversion
4 Racionamiento de Capital
5 Inversiones Interrelacionadas
6 Arrastre de Pérdidas
7 Deuda Subsidiada
 Prof: Augusto Orellana Clase 25: Casos especiales 2 / 40

[pág. 3]
Roadmap
1 Distinta vida útil
2 Reemplazo Maquinaria
3 Projectos de Inversion
4 Racionamiento de Capital
5 Inversiones Interrelacionadas
6 Arrastre de Pérdidas
7 Deuda Subsidiada
 Prof: Augusto Orellana Clase 25: Casos especiales 3 / 40

[pág. 4]
Proyectos excluyentes con distinta vida útil
Ejemplo. Una empresa debe escoger entre dos máquinas A y B para aumentar la
capacidad de su proceso productivo. Ambas máquinas tienen el mismo
rendimiento por hora de producción, pero se diferencian entre ellas por la
inversión inicial, el costo de operación y la vida útil.
 ■ Máquina A: tiene un costo de $15.000, dura 3 años, y tiene un costo de
 operación anual de $4.000.
 ■ Máquina B: sólo cuesta $10.000, dura 2 años y tiene un costo de operación
 anual de $6.000.
¿Cuál máquina debe elegirse si el costo de capital de la empresa es de 10% anual?
 Para simplificar su análisis suponga que no hay impuestos.
 Prof: Augusto Orellana Clase 25: Casos especiales 4 / 40

[pág. 5]
Proyectos excluyentes con distinta vida útil
Calculamos el Valor Presente de los Costos
 Máquina F0 F1 F2 F3 VPN
 A 15 4 4 4 24,95
 B 10 6 6 – 20,41
 ■ ¿Algún problema con esta evaluación? No queda claro qué ocurre
 una vez que madure el proyecto de menor duración.
 ■ Supongamos que la actividad que desarrollamos con el proyecto debe
 seguir y, por lo tanto, habrá que reinvertir en el mismo proyecto o
 invertir en uno nuevo.
 Prof: Augusto Orellana Clase 25: Casos especiales 5 / 40

[pág. 6]
Solución 1: Fijar un Horizonte Común
 Máquina F0 F1 F2 F3 F4 F5 F6 VPN
 A 15 4 4 19 4 4 4 43,69
 B 10 6 16 6 16 6 6 51,22
 4 4 4 + 15 4 4 4
 VPN(Máquina A) = 15 + + 2
 + 3
 + 4
 + 5
 +
 1, 1 (1, 1) (1, 1) (1, 1) (1, 1) (1, 1)6
 6 6 + 10 6 6 + 10 6 6
 VPN(Máquina B) = 10 + + + + + +
 1, 1 (1, 1)2 (1, 1)3 (1, 1)4 (1, 1)5 (1, 1)6
Decisión: Máquina A.
Supuesto clave:
 ■ El proyecto puede repetirse indefinidamente a escala constante.
 Prof: Augusto Orellana Clase 25: Casos especiales 6 / 40

[pág. 7]
Solución 2: Anualidad Equivalente
■ Situación original máquina A:
 F0 F1 F2 F3 F4 F5 F6 F7 F8 F9
 15 4 4 4
 15 4 4 4
 15 4 4 4
■ Transformación de los flujos de la máquina A:
 F0 F1 F2 F3 F4 F5 F6 F7 F8 F9
 Original 15 4 4 4
 Anualidad A A A
  
 1 1 1
 VPN(Máquina A) = A × + +
 1, 1 (1, 1)2 (1, 1)3
  
 1 1 1
 24, 95 = A × + +
 1, 1 (1, 1)2 (1, 1)3
 Prof: Augusto Orellana Clase 25: Casos especiales 7 / 40

[pág. 8]
Método de costo anual equivalente (CAE)
 n
 X ANN 1
 VPN = t
 ⇒ ANN = n × VPN
 (1 + r ) X 1
 t=1
 (1 + r )t
 t=1
Determinación de la anualidad equivalente de la Máquina A (CAE):
 3
 A A A X 1
CAE (Máquina A) = + + = A = A×2, 487
 (1, 1)1 (1, 1)2 (1, 1)3 (1, 1)t
 t=1
 A ≈ 24,95
 2,487 ≈ 10, 03
 ■ Interpretación: la Máquina A equivale a un costo anual constante de
 aproximadamente $10,03 durante sus 3 años de vida útil.
 Prof: Augusto Orellana Clase 25: Casos especiales 8 / 40

[pág. 9]
Método de costo anual equivalente (CAE)
 ■ Situación original máquina B:
 F0 F1 F2 F3 F4 F5 F6 F7 F8
 10 6 6
 10 6 6 ...
 10 6 6
 10 6 6
 ■ Transformación de los flujos de la máquina A:
 F0 F1 F2 F3 F4 F5 F6 F7 F8
 Original 10 6 6
 Anualidad B B
  
 1 1
 VPN(Máquina B) = B × +
 1, 1 (1, 1)2
  
 1 1
 20, 415 = B × +
 1, 1 (1, 1)2
 Prof: Augusto Orellana Clase 25: Casos especiales 9 / 40

[pág. 10]
Método de costo anual equivalente (CAE)
Determinación de la anualidad equivalente de la Máquina B (CAE):
 3
 A A X 1
 CAE (Máquina B) = + = B = B × 1, 736
 (1, 1)1 (1, 1)2 (1, 1)t
 t=1
 B ≈ 20,41
 1,736 ≈ 11, 76
Regla de decisión
 CAEA = 10, 03 < CAEB = 11, 76
 ⇒ Elegir Máquina A
 Prof: Augusto Orellana Clase 25: Casos especiales 10 / 40

[pág. 11]
Roadmap
1 Distinta vida útil
2 Reemplazo Maquinaria
3 Projectos de Inversion
4 Racionamiento de Capital
5 Inversiones Interrelacionadas
6 Arrastre de Pérdidas
7 Deuda Subsidiada
 Prof: Augusto Orellana Clase 25: Casos especiales 11 / 40

[pág. 12]
CAE – Reemplazo de Máquinas
Suponga ahora que usted está operando con una máquina C que:
 ■ Costó $18.000 hace 2 años.
 ■ Genera un flujo de costos de $9.000 anuales.
 ■ Se espera que dure otros 3 años.
 ■ No tiene valor residual.
 Si usted pudiera cambiar la máquina C por la máquina A,
 ¿harı́a el reemplazo ahora o esperarı́a tres años más?
 (Suponga una tasa de descuento de 10%)
 Prof: Augusto Orellana Clase 25: Casos especiales 12 / 40

[pág. 13]
CAE – Reemplazo de Máquinas
Determinación de la anualidad equivalente de la Máquina C (CAE):
 5 5
 X 9 X 1
 VP(Costos) = 18 + = 18 + 9 ≈ 52, 12
 (1, 1)t (1, 1)t
 t=1 t=1
 5
 X 1
 CAE (Máquina C) = C = C × 3, 791
 (1, 1)t
 t=1
 52, 12
 C≈ ≈ 13, 75
 3, 791
Sin embargo, la inversión en C ya se realizó, por lo que para la
decisión actual sólo importan los costos futuros:
 3
 X 9
 VP(Costos futuros) = = 22, 38
 (1, 1)t
 t=1
 Prof: Augusto Orellana Clase 25: Casos especiales 13 / 40

[pág. 14]
CAE – Reemplazo de Máquinas
 ¿harı́a el reemplazo ahora o esperarı́a tres años más?
 Prox Prox Desde
 3 años (PV) 3 años (CAE) 5 año (CAE)
 Máq. C 22,38 9,00 13,75
 Máq. A 24,95 10,03 10,03
Una vez que la máquina C llegue al final de su vida útil
 CAEC = 13, 75 > CAEA = 10, 03
 Conviene reemplazar C por A en ese momento
 La inversión histórica de $18.000 es un costo hundido para la decisión actual,
 pero sı́ forma parte del CAE de largo plazo de la máquina C.
 Prof: Augusto Orellana Clase 25: Casos especiales 14 / 40

[pág. 15]
Momento Óptimo para el Reemplazo de una Inversión
 ■ La máquina actual tiene 3 años de vida útil remanente, no tiene valor
 de liquidación y sus costos operativos esperados son:
 ▶ Año 1: $50
 ▶ Año 2: $55
 ▶ Año 3: $70
 ■ La máquina nueva requiere una inversión inicial de $100 y genera
 costos operativos anuales de $30 durante sus 5 años de vida útil.
 ■ Supuestos:
 ▶ La empresa continuará operando indefinidamente.
 ▶ La máquina nueva puede reinvertirse a escala constante.
 ▶ El costo de capital es de 10%.
 ■ Objetivo:
 ▶ Determinar si conviene reemplazar la máquina actual: 1, 2, o al final de
 su vida útil
 Prof: Augusto Orellana Clase 25: Casos especiales 15 / 40

[pág. 16]
CAE – Reemplazo de Máquinas
El CAE de la máquina nueva es:
 5 5
 ! !
 X 30 X 1
 CAEnueva = 100 + / = 56, 38
 (1, 1)t (1, 1)t
 t=1 t=1
 10% 0 1 2 3 4 5
 Flujos 100 30 30 30 30 30
 CAE 56,38 56,38 56,38 56,38 56,38
 VP(Flujos) 213,72 27,27 24,79 22,54 20,49 18,63
 VP(CAE) 213,72 51,25 46,59 42,36 38,51 35,01
 Prof: Augusto Orellana Clase 25: Casos especiales 16 / 40

[pág. 17]
CAE – Reemplazo de Máquinas
 10% 1 2 3 4
 Reemplazo Año 4 50,0 55,0 70,0 56,4
 VPN (4y) 182,01 45,45 45,45 52,59 38,51
 Reemplazo Año 3 50,0 55,0 56,4 56,4
 VPN (4y) 171,78 45,45 45,45 42,36 38,51
 Reemplazo Año 2 50,0 56,4 56,4 56,4
 VPN (4y) 172,92 45,45 46,59 42,36 38,51
 Reemplazo Año 1 56,4 56,4 56,4 56,4
 VPN (4y) 178,72 51,25 46,59 42,36 38,51
Interpretación
La estrategia óptima consiste en mantener la máquina actual durante dos
años más y efectuar el reemplazo al inicio del tercer año, ya que esa
alternativa minimiza el valor presente total de los costos.
 Prof: Augusto Orellana Clase 25: Casos especiales 17 / 40

[pág. 18]
Roadmap
1 Distinta vida útil
2 Reemplazo Maquinaria
3 Projectos de Inversion
4 Racionamiento de Capital
5 Inversiones Interrelacionadas
6 Arrastre de Pérdidas
7 Deuda Subsidiada
 Prof: Augusto Orellana Clase 25: Casos especiales 18 / 40

[pág. 19]
Proyectos de Inversión - VPN
Suponga que la empresa para la que usted trabaja está considerando los
siguientes proyectos de inversión mutuamente excluyentes:
 ■ El proyecto A tiene una inversión inicial de $8 MM y retornará $6
 MM el año próximo y el siguiente.
 ■ El proyecto B también tiene una inversión inicial de $8 MM, pero
 retornará $4 MM, $4,5 MM y $5 MM durante los siguientes 3 años.
 0 1 2 3
 Proyecto A -8 6 6 0 VPN 2,41
 Proyecto B -8 4 4,5 5 VPN 3,11
 Prof: Augusto Orellana Clase 25: Casos especiales 19 / 40

[pág. 20]
Solución 1: Fijar un Horizonte Común
 ■ Definimos una vida útil uniforme:
 6 6−8 6 6−8 6 6
Proyecto A = −8+ + + + + + = 6, 06
 1, 1 (1, 1) (1, 1) (1, 1) (1, 1) (1, 1)6
 2 3 4 5
 4 4, 5 5−8 4 4, 5 5
Proyecto B = −8+ + + + + + = 5, 45
 1, 1 (1, 1) (1, 1) (1, 1) (1, 1) (1, 1)6
 2 3 4 5
 Prof: Augusto Orellana Clase 25: Casos especiales 20 / 40

[pág. 21]
Valor Anual Equivalente (VAE)
 n
 X 1
 VAE = VPN/
 (1 + r )t
 t=1
 0 1 2 3
 Proyecto A -8 6 6
 VPN 2,41 -8,00 5,45 4,96
 VAE 1,39
 Proyecto B -8 4 4,5 5
 VPN 3,11 -8,00 3,64 3,72
 VAE 1,25
Decisión: El proyecto A es el de mayor VAE.
 Prof: Augusto Orellana Clase 25: Casos especiales 21 / 40

[pág. 22]
Roadmap
1 Distinta vida útil
2 Reemplazo Maquinaria
3 Projectos de Inversion
4 Racionamiento de Capital
5 Inversiones Interrelacionadas
6 Arrastre de Pérdidas
7 Deuda Subsidiada
 Prof: Augusto Orellana Clase 25: Casos especiales 22 / 40

[pág. 23]
Racionamiento de Capital
 Situación común en empresas pequeñas y medianas.
 Clave: asignar recursos limitados lo más eficiente posible.
Idea central
No necesariamente se seleccionan los proyectos con mayor VPN individual,
sino la combinación de proyectos que genere el mayor VPN total dado el
capital disponible.
 Prof: Augusto Orellana Clase 25: Casos especiales 23 / 40

[pág. 24]
Racionamiento de Capital (Proyectos Independientes)
Una compañı́a dispone de un presupuesto de $100.000 para realizar nuevas
inversiones.
 Proyecto I.I. (M$) VPN (M$)
 A 10 5
 B 5 5
 C 90 10
 D 60 12
 E 75 15
 F 15 2
 ¿Qué proyectos deberı́a seleccionar la compañı́a?
 Prof: Augusto Orellana Clase 25: Casos especiales 24 / 40

[pág. 25]
Racionamiento de Capital (Proyectos Independientes)
Si todas las alternativas de inversión son independientes entre sı́,
usamos el Índice de Rentabilidad (I.R.).
 Proyecto I.I. (M$) VPN (M$) IR Ranking
 A 10 5 1,50 2
 B 5 5 2,00 1
 C 90 10 1,11 6
 D 60 12 1,20 3
 E 75 15 1,20 4
 F 15 2 1,13 5
Decisión: B + A + D + E + F
 ■ Los recursos se asignan siguiendo ese orden hasta agotar el
 presupuesto disponible.
 ■ Esta regla funciona cuando los proyectos son divisibles o
 independientes y no existen interacciones entre ellos.
 Prof: Augusto Orellana Clase 25: Casos especiales 25 / 40

[pág. 26]
Racionamiento de Capital: Algunos comentarios
 1 ¿Qué pasa si me sobran recursos?
 ▶ Se pueden usar para: aumentar capital de trabajo, disminuir deuda,
 dividendos, etc
 2 Evaluar en el margen: VPN(A+B+C+D+G) >
 VPN(A+B+C+D+E+F)
 3 El método de ranking a través del IR NO sirve cuando hay cualquier
 otra restricción aparte de la de recursos de capital
 ▶ Racionamiento de capital en dos perı́odos
 Prof: Augusto Orellana Clase 25: Casos especiales 26 / 40

[pág. 27]
Racionamiento de Capital (Proyectos Dependientes)
 Entre todas las combinaciones factibles con VPN positivo, ¿cuál
 maximiza el valor sujeto a la restricción presupuestaria?
 Proyecto I.I. (M$) VP (M$) VPN (M$) Exclusión
 A 50 90 40 Sı́
 B 40 50 10 Sı́
 C 50 70 20 No
 D 60 65 5 No
 ■ Los proyectos A y B son mutuamente excluyentes.
 ■ Las combinaciones (A + D) y (C + D) no son factibles porque
 exceden el presupuesto (100).
 Prof: Augusto Orellana Clase 25: Casos especiales 27 / 40

[pág. 28]
Racionamiento de Capital (Proyectos Dependientes)
 Combinación Inversión VPN Total
 A+C 100 60
 B+C 90 30
 B+D 100 15
Decisión: A + C
 VPNA+C = 40 + 20 = 60
 Prof: Augusto Orellana Clase 25: Casos especiales 28 / 40

[pág. 29]
Roadmap
1 Distinta vida útil
2 Reemplazo Maquinaria
3 Projectos de Inversion
4 Racionamiento de Capital
5 Inversiones Interrelacionadas
6 Arrastre de Pérdidas
7 Deuda Subsidiada
 Prof: Augusto Orellana Clase 25: Casos especiales 29 / 40

[pág. 30]
Inversiones Interrelacionadas
 Dos inversiones pueden estar interrelacionadas por distintas razones (
 externalidades)
 Suele reflejarse en los flujos de caja y puede ser:
 ▶ Positivo (sinergias)
 ▶ Negativo (canibalización)
 Por ello, los proyectos no siempre deben evaluarse de manera aislada.
 Prof: Augusto Orellana Clase 25: Casos especiales 30 / 40

[pág. 31]
Inversiones Interrelacionadas
 □ Determinar todas las combinaciones factibles de proyectos.
 ▶ Algunas combinaciones pueden no ser viables.
 ▶ Puede existir exclusión mutua o complementariedad.
 □ Calcular el VPN de cada combinación.
 ▶ Las externalidades deben incorporarse explı́citamente.
 □ Seleccionar la combinación de mayor VPN, siempre que éste sea
 positivo.
 Caso VPN individuales VPN conjunto
 a) VPNA = 100, VPNB = 50 ⇒ VPNA+B = 160
 b) VPNA = 100, VPNB = 50 ⇒ VPNA+B = 150
 c) VPNA = 100, VPNB = 50 ⇒ VPNA+B = 140
 d) VPNA = 100, VPNB = 50 ⇒ VPNA+B = 90
 e) VPNA = −10, VPNB = −5 ⇒ VPNA+B = 8
 Prof: Augusto Orellana Clase 25: Casos especiales 31 / 40

[pág. 32]
Roadmap
1 Distinta vida útil
2 Reemplazo Maquinaria
3 Projectos de Inversion
4 Racionamiento de Capital
5 Inversiones Interrelacionadas
6 Arrastre de Pérdidas
7 Deuda Subsidiada
 Prof: Augusto Orellana Clase 25: Casos especiales 32 / 40

[pág. 33]
Arrastre de Pérdidas
Ejemplo. Una empresa terminó el presente año con una pérdida tributaria
de $100.000 que no pudo utilizar para reducir impuestos. Si arrastra la
pérdida:
 Año 1 Año 2 Año 3
 Resultado antes de impuestos 30.000 50.000 70.000
 Pérdida utilizada (30.000) (50.000) (20.000)
 Utilidad tributable 0 0 50.000
 Impuestos (20%) 0 0 10.000
 Prof: Augusto Orellana Clase 25: Casos especiales 33 / 40

[pág. 34]
Arrastre de Pérdidas
Valor de las pérdidas de arrastre
Sin pérdida de arrastre, la empresa habrı́a pagado:
 6.000 10.000 14.000
Con pérdida de arrastre, paga:
 0 0 10.000
Por lo tanto, el ahorro tributario es:
 6.000 10.000 4.000
 6.000 10.000 4.000
 VP(Ahorro tributario) = + 2
 + = 16.724
 1, 1 (1, 1) (1, 1)3
 VP(Pérdida de arrastre) = 16.724
 Prof: Augusto Orellana Clase 25: Casos especiales 34 / 40

[pág. 35]
Roadmap
1 Distinta vida útil
2 Reemplazo Maquinaria
3 Projectos de Inversion
4 Racionamiento de Capital
5 Inversiones Interrelacionadas
6 Arrastre de Pérdidas
7 Deuda Subsidiada
 Prof: Augusto Orellana Clase 25: Casos especiales 35 / 40

[pág. 36]
¿Qué es una deuda subsidiada?
Idea central
Una deuda está subsidiada cuando la empresa puede endeudarse en condiciones más
favorables que las disponibles en el mercado.
Deuda a mercado Deuda subsidiada
 Recibo hoy = 900 Recibo hoy = 900
 VP(Pagos) = 900 VP(Pagos) = 843, 78
 VPN = 0 VPN = 56, 22
 Subsidio = Monto recibido − VP(Pagos futuros)
Interpretación
La empresa recibe hoy más valor del que devuelve en términos presentes. La diferencia
es una transferencia de riqueza otorgada por quien financia el proyecto.
 Prof: Augusto Orellana Clase 25: Casos especiales 36 / 40

[pág. 37]
Deuda Subsidiada
Una empresa está evaluando un proyecto de 4 años de duración que se estima
generará flujos de caja netos de $ 675 constantes, en cada uno de estos 4 años.
El proyecto demandará una inversión inicial total de $ 1.800, la mitad de la cual
se financiará con deuda que devengará un interés de 9% anual y que se devolverá
en cuatro cuotas anuales, iguales y sucesivas a partir del primer año.
Suponiendo que el costo de capital (promedio ponderado) relevante para evaluar
este proyecto es de 20% anual:
 a) ¿Le conviene a esta empresa llevar a cabo el proyecto si la deuda estuviera
 pactada en condiciones de mercado?
 b) ¿Cambiarı́a su respuesta en (a) si la tasa de interés de 9% para la deuda
 fuera subsidiada ya que en condiciones de mercado sólo serı́a posible
 endeudarse al 12%?
 Prof: Augusto Orellana Clase 25: Casos especiales 37 / 40

[pág. 38]
Parte a):Tratamiento de la deuda a valor de mercado
Paso 1: Determinar el pago anual equivalente de la deuda
La deuda tiene un valor de mercado de $900 y se descuenta a una tasa de 9%.
 " #
 1 1
 900 = F −
 0, 09 0, 09(1, 09)4
 900 = F × 3, 240
 900
 F = = 277, 80
 3, 240
Paso 2: Verificar que la deuda está correctamente valorizada
 !
 277, 80 277, 80 277, 80 277, 80
 VPNDeuda = 900 − + + +
 1, 09 (1, 09)2 (1, 09)3 (1, 09)4
 VPNDeuda = 0
Conclusion
 675 675 675 675
 VPN = −1.800 + + + +
 1, 2 (1, 2)2 (1, 2)3 (1, 2)4
Utilizando la fórmula de anualidad:
 " #
 1 1
 VPN = −1.800 + 675 −
 0, 20 0, 20(1, 2)4
 VPN = −52, 60
 ⇒ El proyecto debe rechazarse
 Prof: Augusto Orellana Clase 25: Casos especiales 38 / 40

[pág. 39]
Parte b):Deuda Subsidiada
Paso 1: Determinar el pago anual a tasa de mercado
Si una deuda de $900 se financiara a la tasa de mercado de 12%, el pago anual serı́a:
 " #
 1 1
 900 = F −
 0, 12 0, 12(1, 12)4
 F = 296, 31
Paso 2: Valor de mercado de los pagos efectivamente pactados
La empresa sólo paga cuotas anuales de:
 277, 80
Por lo tanto, el valor presente de esos pagos descontados a la tasa de mercado es:
 277, 80 277, 80 277, 80 277, 80
 VP(Pagos) = + + +
 1, 12 (1, 12)2 (1, 12)3 (1, 12)4
 VP(Pagos) = 843, 78
Paso 3: Determinar el subsidio
 Subsidio = Monto recibido − VP(Pagos)
 = 900 − 843, 78 = 56, 22
 Subsidio = 56, 22
 Prof: Augusto Orellana Clase 25: Casos especiales 39 / 40

[pág. 40]
Parte b): Valor del Proyecto
Cuando el financiamiento está subsidiado y sólo puede obtenerse si se realiza el proyecto,
el subsidio constituye un beneficio adicional.
 VPN(Proyecto) = VPN(Proyecto puro) + VPN(Subsidio)
 = −52, 60 + 56, 22
 = 3, 62
Decisión
 VPN = 3, 62 > 0
 ⇒ Aceptar el proyecto
El proyecto destruye valor por sı́ solo, pero el subsidio asociado al financiamiento
 más que compensa esa pérdida.
 Prof: Augusto Orellana Clase 25: Casos especiales 40 / 40

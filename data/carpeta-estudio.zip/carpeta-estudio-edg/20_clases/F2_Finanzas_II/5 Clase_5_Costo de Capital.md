# Finanzas II · 5 Clase_5_Costo de Capital

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 5: Costo de Capital
 Profesor: Augusto Orellana
 Marzo 2026
Prof: Augusto Orellana Clase 5: Costo de Capital 1 / 18

[pág. 2]
Roadmap
1 Introducción
2 Cost of Equity
3 Cost of Debt
4 WACC
5 Capital Structure & WACC
 Prof: Augusto Orellana Clase 5: Costo de Capital 2 / 18

[pág. 3]
Roadmap
1 Introducción
2 Cost of Equity
3 Cost of Debt
4 WACC
5 Capital Structure & WACC
 Prof: Augusto Orellana Clase 5: Costo de Capital 3 / 18

[pág. 4]
Introducción al Costo de Capital
¿Qué es el Costo de capital?
 Tasa de retorno exigida por los inversionistas (acreedores/acciones)
 para compensar el uso de capital.
Riesgo - Retorno:
 A mayor riesgo → Mayor la tasa exigida
Dos Escenearios:
 100% Equity
 Mix Debt & Equity
 Prof: Augusto Orellana Clase 5: Costo de Capital 4 / 18

[pág. 5]
Financiamiento 100% Equity
 “Unlevered” Equity
 ra : Retorno exigido a los activos
 ru : Retorno exigido al equity
¿Cuál es el costo de financiar esta empresa?
 Cost of Equity (ru )
 Prof: Augusto Orellana Clase 5: Costo de Capital 5 / 18

[pág. 6]
Roadmap
1 Introducción
2 Cost of Equity
3 Cost of Debt
4 WACC
5 Capital Structure & WACC
 Prof: Augusto Orellana Clase 5: Costo de Capital 6 / 18

[pág. 7]
Cost of Equity
Modelo de Dividendos
 D0 ∗ (1 + g )
 P0 =
 ru − g
Donde:
 P0 : Precio actual
 D0 : Dividendos actuales
 g : Tasa de crecimiento de dividendos
 D1
 ru = +g
 P0
¿Qué pasa si la empresa no paga dividendos?
 Amazon!
 Prof: Augusto Orellana Clase 5: Costo de Capital 7 / 18

[pág. 8]
Cost of Equity
Modelo de CAPM
 E (ru ) = rf + βu ∗ (E (rm − rf ))
Donde:
 rf : Tasa libre de riesgo
 rm − rf : Market risk premium
 βu : Riesgo relativo al mercado
¿Qué pasa si la empresa no cotiza en bolsa?
 Prof: Augusto Orellana Clase 5: Costo de Capital 8 / 18

[pág. 9]
Financiamiento Deuda & Equity
 Debt & ”Levered” Equity
 ra : Retorno exigido a los activos
 rd : Retorno exigido a la deuda
 re : Retorno exigido al equity
¿Cuál es el costo de financiar esta empresa?
 Cost of Equity (re )
 ▶ Ya sabemos cómo calcularlo
 Cost of Debt (rd )
 ▶ Observable (tasa de interés)
 Prof: Augusto Orellana Clase 5: Costo de Capital 9 / 18

[pág. 10]
Roadmap
1 Introducción
2 Cost of Equity
3 Cost of Debt
4 WACC
5 Capital Structure & WACC
 Prof: Augusto Orellana Clase 5: Costo de Capital 10 / 18

[pág. 11]
Cost of Debt
¿Qué es rd ?
 YTM: Tasa de interés requerida por el mercado
 Prof: Augusto Orellana Clase 5: Costo de Capital 11 / 18

[pág. 12]
Roadmap
1 Introducción
2 Cost of Equity
3 Cost of Debt
4 WACC
5 Capital Structure & WACC
 Prof: Augusto Orellana Clase 5: Costo de Capital 12 / 18

[pág. 13]
WACC
WACC (Weighted Average Cost of Capital)
 Promedio ponderado de la tasa exigida por los inversionistas
 D E
 WACC = ∗ rd + ∗ r e
 A A
3 etapas para calcular WACC:
 1 Calculamos el retorno exigido por cada tipo de inversionista (rd , re )
 2 Calculamos el valor de cada parte del valor de la firma (D, E )
 3 Calculamos WACC
 Prof: Augusto Orellana Clase 5: Costo de Capital 13 / 18

[pág. 14]
WACC
 ¿Qué pasa cuando hay más de un tipo de deuda?
 D1 D2 E
 WACC = ∗ r d1 + ∗ rd2 + ∗ re
 A A A
 ¿Qué pasa cuando hay preferred stocks?
 D P E
 WACC = ∗ r d + ∗ rp + ∗ re
 A A A
WACC es super flexible!
 Prof: Augusto Orellana Clase 5: Costo de Capital 14 / 18

[pág. 15]
Roadmap
1 Introducción
2 Cost of Equity
3 Cost of Debt
4 WACC
5 Capital Structure & WACC
 Prof: Augusto Orellana Clase 5: Costo de Capital 15 / 18

[pág. 16]
Estructura de Capital y Cost of Equity
¿Cómo varı́a el costo de capital cuando cambia el capital structure?
 Costo del Equity (re ):
 ▶ re = ROE . Demuestrelo
 ROE es afectado por tres cosas:
 1 Operating efficiency
 2 Asset use efficiency
 3 Financial Leverage
  
 Debt
 ROE = ROA x 1+ (1)
 Equity
 “A mayor deuda, mayor costo de equity”
 Prof: Augusto Orellana Clase 5: Costo de Capital 16 / 18

[pág. 17]
Estructura de Capital y Cost of Debt
¿Cómo varı́a el costo de capital cuando cambia el capital structure?
 Costo de la Deuda (rd ):
 ▶ YTM está directamente relacionado con el “default”
 ⋆ Mayor default está relacionado con mayor deuda
 “A mayor probabilidad de default, mayor costo de deuda”
 Prof: Augusto Orellana Clase 5: Costo de Capital 17 / 18

[pág. 18]
Estructura de Capital y Cost of Capital
¿Cómo varı́a el costo de capital cuando cambia el capital structure?
¿Es relevante la estructura de capital? ¿Por qué?
 Prof: Augusto Orellana Clase 5: Costo de Capital 18 / 18

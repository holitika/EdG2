# Finanzas II · 11 Clase_11_CCUc

Fuente: clase de Finanzas II

[pág. 1]
ANÁLISIS RAZONADO
 Al 31 de diciembre de 2024
A. RESUMEN DEL PERIODO1
En 2024, CCU superó los resultados financieros del 2023 tras una sólida mejora durante la segunda mitad del
año. Además, continuamos avanzando en nuestra estrategia en un entorno de negocios particularmente
desafiante y volátil. Durante 2024, enfrentamos una contracción levemente sobre el 20% en las industrias de
cerveza y agua en Argentina, y un crecimiento económico modesto en Chile, lo que llevó a volúmenes planos
en el Segmento de operación Chile. Adicionalmente, experimentamos presiones en costos y gastos
provenientes de la depreciación de nuestras monedas locales frente al USD.
En este escenario, el EBITDA acumulado consolidado alcanzó los CLP 387.267 millones, un aumento del
2,1% (CLP 415.936 millones; un 9,6% de aumento cuando se incluye la ganancia no recurrente de la venta
de una porción de terreno en Chile el 2T24), y la Utilidad neta acumulada consolidada alcanzó los
CLP 140.016 millones, expandiéndose un 32,5% (CLP 160.944 millones; un 52,3% de aumento cuando se
incluye la mencionada ganancia no recurrente). El fuerte repunte en la segunda mitad del año, donde el
EBITDA consolidado se expandió un 27,7%, se explicó principalmente por un sólido desempeño en el cuarto
trimestre de 2024 en todos nuestros Segmentos de operación, más que compensando una primera mitad
desafiante donde registramos una disminución del 26,5% en el EBITDA a junio de 2024. Esta tendencia al
alza fue impulsada por iniciativas de gestión de ingresos y eficiencias en todos nuestros Segmentos de
operación, lo que nos permitió más que compensar los impactos negativos en nuestros resultados del
escenario descrito anteriormente.
Las iniciativas mencionadas se ejecutaron bajo el plan regional "HérCCUles", que iniciamos en 2022 y
finalizamos en 2024, siendo clave para alinear a la Compañía bajo 6 pilares con el objetivo de recuperar los
resultados financieros, lo que permitió positivos crecimientos en EBITDA y en Utilidad neta, resultando la
expansión de esta última muy por sobre la inflación de ese periodo, a pesar de un contexto externo
desfavorable con devaluación de las monedas y bajo crecimiento económico en la región.
En cuanto a nuestra estrategia de negocio, durante el año, CCU continuó fortaleciendo su presencia regional.
En julio de 2024, comenzamos a consolidar "Aguas de Origen" (ADO), nuestro negocio de aguas con Danone
en Argentina, lo que seguirá aportando sinergias a nuestras operaciones en ese país. En octubre de 2024,
aumentamos nuestra escala en Paraguay a través de una asociación con el Grupo Vierci (AV), que incluye la
licencia de PepsiCo para la producción y distribución de bebidas, así como la distribución de snacks. Con esta
asociación, Paraguay se convirtió en el segundo país donde la licencia de PepsiCo forma parte del portafolio
de marcas de CCU, además de Chile. Al mismo tiempo, continuamos invirtiendo en nuestras marcas logrando
una sólida preferencia de marca, especialmente en cerveza en Chile, y seguimos reforzando nuestra
transformación digital para apoyar la ejecución de ventas e impulsar eficiencias operacionales en el futuro.
Finalmente, fuimos los primeros en inaugurar una moderna planta de reciclaje de PET, “botella a botella”,
denominada "CirCCUlar" en Chile.
Desde una mirada trimestral, en el cuarto trimestre de 2024, CCU alcanzó sólidos resultados. El EBITDA
consolidado alcanzó los CLP 182.6212 millones, un aumento del 65,2%. Este resultado fue impulsado por
todos nuestros Segmentos de operación. Es importante mencionar que en el 4T23 la aplicación de la NIC 29
de las NIIF en Argentina generó una pérdida de CLP 24.018 millones en el EBITDA consolidado, frente a una
ganancia de CLP 1.095 millones en el 4T24. Aislando estos efectos, el EBITDA consolidado se expandió en
un 34,9%. Excluyendo los volúmenes inorgánicos de la consolidación de ADO y AV en Argentina y Paraguay,
respectivamente, los volúmenes disminuyeron un 0,1% en el 4T24, explicado en su totalidad por el Segmento
de operación Negocios Internacionales, que continuó contrayéndose frente al año pasado, debido a Argentina,
1 Los resultados hacen referencia a cifras del cuarto trimestre del 2024 y se comparan con cifras del cuarto trimestre del 2023, a no ser que se indique lo contrario.
2 Excluyendo la consolidación de ADO en Argentina y de AV en Paraguay, el EBITDA consolidado habría alcanzado los CLP 179.727 millones y se expande un 62,6%. Para mayor
detalle del impacto de la consolidación de ADO y AV ver el Reporte Trimestral de resultados del 4T24 disponible en el sitio www.ccuinvestor.com sección Información financiera.

[pág. 2]
ANÁLISIS RAZONADO
siendo casi totalmente compensado por una expansión en el Segmento de operación Chile, mientras que los
volúmenes de vino se mantuvieron planos. La Utilidad neta consolidada alcanzó una ganancia de CLP 74.153
millones, aumentando un 77,7%, impulsado tanto por el mejor resultado operacional mencionado
anteriormente como por un mejor resultado no operacional, particularmente en Argentina.
El análisis a continuación considera cifras orgánicas, es decir, excluyendo la consolidación de ADO y
AV, a menos que se indique lo contrario.
El Ingreso por ventas aumentó un 56,7% orgánicamente, impulsado en su totalidad por un aumento de 56,9%
en los precios promedio orgánicos en CLP, ya que los volúmenes consolidados disminuyeron un 0,1%
orgánicamente. El aumento de los precios promedio orgánicos en CLP se debió a: (i) un alza del 4,9% en el
Segmento de operación Chile, relacionado con iniciativas de gestión de ingresos, parcialmente compensado
por un efecto mix negativo, (ii) un gran aumento en el Segmento de operación Negocios Internacionales,
impulsado principalmente por una base de comparación favorable en Argentina3, e iniciativas de gestión de
ingresos, y (iii) un crecimiento del 21,7% en el Segmento de operación Vinos, principalmente como resultado
de una baja base de comparación3, un CLP más débil y su impacto favorable en los ingresos de exportación,
y un efecto mix positivo. En términos de volúmenes orgánicos, el desempeño fue el siguiente: (i) un aumento
del 4,7% en el Segmento de operación Chile, en parte debido a una baja base de comparación en el 4T23,
(ii) una contracción orgánica del 11,5 % en el Segmento de operación Negocios Internacionales, concentrada
principalmente en Argentina, mientras que todas las demás geografías experimentaron un crecimiento del
volumen, y (iii) una contracción del 0,3% en el Segmento de operación Vinos, donde las exportaciones se
expandieron, siendo casi totalmente compensadas por un mercado doméstico argentino más débil, ya que
los volúmenes domésticos en Chile se mantuvieron planos.
El Costo de venta aumentó un 52,6% orgánicamente, explicado por un mayor costo de ventas por hectolitro,
que se expandió un 52,8% orgánicamente en CLP. El mayor costo de ventas por hectolitro se debió a: (i) un
aumento del 7,8% en el Segmento de operación Chile, explicado por la depreciación del 7,3% 4 del CLP frente
al USD y su impacto en los costos denominados en USD, y mayores precios en PET, aluminio y pulpa de
fruta, compensado parcialmente por menores precios en malta y azúcar, (ii) un aumento en el Segmento de
operación Negocios Internacionales, impulsado principalmente por una baja base de comparación en
Argentina3, junto con presiones de costos provenientes de la depreciación del ARS frente al USD y su impacto
negativo en los costos denominados en USD, y (iii) un aumento del 28,8% en el Segmento de operación
Vinos, también principalmente debido a una baja base de comparación en Argentina3, mayores costos
vinculados al USD y un mayor costo del vino.
El Margen bruto orgánico alcanzó CLP 426.783 millones, un aumento del 61,5%, y el margen bruto, como
porcentaje de los Ingresos por ventas, aumentó en 141 pb.
Los gastos de MSD&A aumentaron un 62,8% orgánicamente en CLP, y como porcentaje de los Ingresos por
ventas, aumentaron 124 pb. Los mayores gastos MSD&A se debieron en gran medida a:
(i) un fuerte aumento en el Segmento de operación Negocios Internacionales, impulsado por una baja base
de comparación en Argentina3, parcialmente compensado con eficiencias, y (ii) un aumento del 10,2% en el
Segmento de operación Vinos, también impulsado por una baja base de comparación en Argentina3, y
mayores gastos de marketing denominados en USD. Como porcentaje de los Ingresos por ventas, los gastos
de MSD&A mejoraron 298 pb debido a las eficiencias en este segmento. Las alzas anteriores, se vieron
parcialmente compensadas por una disminución del 1,5% en los gastos MSD&A del Segmento de operación
Chile, debido a eficiencias que ayudaron a compensar los mayores gastos vinculados al USD y presiones
inflacionarias. Como porcentaje de los Ingresos por ventas, los gastos de MSD&A mejoraron en 344 pb en
este segmento.
El EBIT alcanzó los CLP 137.715 millones, y el EBIT orgánico a CLP 135.733 millones, una expansión de
61,9% y 59,6%, respectivamente.
El EBITDA alcanzó los CLP 182.621 millones, y el EBITDA orgánico fue de CLP 179.727 millones,
aumentando un 65,2% y 62,6%, respectivamente, impulsado por todos los Segmentos de operación de la
3 La aplicación de la NIC 29 de las NIIF en Argentina generó un impacto significativo en los resultados del cuarto trimestre de 2023, dada la fuerte depreciación del ARS frente al
USD en ese trimestre. Esto generó una base de comparación particularmente baja para el Segmento de operación Negocios Internacionales y el Segmento de operación Vinos al
comparar Ingresos por ventas, el Costo de ventas, los gastos MSD&A, el EBIT y el EBITDA, con las cifras del cuarto trimestre de 2024.
4 La variación del CLP con respecto a otras monedas considera el promedio del periodo 2024 (aop por sus siglas en inglés) versus el promedio del periodo 2023. Fuente: Banco
Central de Chile.
 2

[pág. 3]
ANÁLISIS RAZONADO
siguiente manera: el Segmento de operación Chile expandió el EBITDA en un 23,0%; el Segmento de
operación Negocios Internacionales se expandió un 216,2% orgánicamente, y el Segmento de operación
Vinos aumento en un 16,0%. El margen EBITDA por su parte, alcanzó 18,9% y 20,0% de manera orgánica,
este último aumentando 72 pb con respecto al año anterior.
Dado que el impacto de la consolidación de ADO y AV en el Resultado no operacional y en la Utilidad
neta no es material, el análisis a continuación considera cifras consolidadas, es decir, incluyendo la
consolidación de ambos negocios.
El Resultado no operacional totalizó una pérdida de CLP 34.324 millones frente a un resultado negativo de
CLP 54.928 millones el año pasado. La menor pérdida se explicó por: (i) un mejor resultado en Otras
ganancias/(pérdidas) por CLP 16.462 millones, causada principalmente por contratos de derivados5,
específicamente, contratos forward celebrados para mitigar el impacto de las fluctuaciones del tipo de cambio
en nuestras posiciones en moneda extranjera en el balance, (ii) un mejor resultado en Diferencia de cambio
por CLP 16.111 millones, debido a una menor exposición en pasivos en moneda extranjera en el balance de
Argentina, y (iii) una menor pérdida en Resultado por unidades de reajuste por CLP 2.643 millones,
principalmente en Argentina. Esto se vio parcialmente compensado por: (i) una mayor pérdida por CLP 9.053
millones en Gastos financieros netos, principalmente debido a una mayor deuda y mayores tasas de interés,
en Argentina, y (ii) una mayor pérdida en Utilidad de negocios conjuntos y asociadas por CLP 5.559 millones,
generado en su mayoría por un resultado positivo en Argentina en ADO en el 4T23, negocio el cual desde
julio 2024 se consolida, y una mayor pérdida en Colombia, debido a provisiones relacionadas con
reclamaciones sobre la determinación de la base del Impuesto al Consumo (ICO).
El Impuesto a las ganancias alcanzó los CLP 21.259 millones frente a un resultado positivo de CLP 17.693
millones el año pasado. Los mayores impuestos se explicaron principalmente por una mayor Utilidad antes
de impuestos, como resultado de un mejor desempeño financiero en Chile y Argentina.
La Utilidad neta alcanzó una ganancia de CLP 74.153 millones, frente a una ganancia de CLP 41.729 millones
el año pasado, expandiéndose un 77,7% explicado por los efectos mencionados anteriormente.
B. ANÁLISIS DE LOS ESTADOS FINANCIEROS
1. LIQUIDEZ
La Razón de Liquidez al 31 de diciembre de 2024 disminuyó con respecto al 31 de diciembre de 2023, al pasar
desde 2,33 a 2,06 veces, explicado por un alza en los Activos Corrientes proporcionalmente menor al aumento
de los Pasivos corrientes. Los mayores Activos Corrientes se explicaron principalmente por un mayor Efectivo
y equivalentes al efectivo, y mayores Deudores comerciales y otras cuentas por cobrar. Por su parte, los
mayores Pasivos corrientes se explican principalmente por mayores Otras cuentas por pagar comerciales y
Otros pasivos financieros corrientes, esto último por mayor deuda de corto plazo.
Por su parte, al igual que la Razón de liquidez, la Razón Ácida se contrajo con respecto al 31 de diciembre de
2023, desde 1,67 a 1,49 veces. Dicha caída se explica por un alza en los Activos Corrientes, estos últimos
descontados los Inventarios y los Gastos pagados por anticipado, proporcionalmente menor al alza de los
Pasivos corrientes, como se indicó en el párrafo anterior. Las variaciones tanto en Activos corrientes y Pasivos
corrientes, se explican por las mismas razones descritas en La Razón de Liquidez.
2. ENDEUDAMIENTO
La Razón de endeudamiento al 31 de diciembre de 2024 disminuyó con respecto al 31 de diciembre de 2023,
al pasar desde 1,71 a 1,52 veces, principalmente asociado a que los Pasivos totales aumentan proporcionalmente
menos que el Patrimonio neto atribuible a los propietarios de la controladora. Los mayores Pasivos totales se
explican principalmente por un alza en Pasivos corrientes, principalmente por mayores Otras cuentas por pagar
comerciales y Otros pasivos financieros corrientes, esto último por mayor deuda.
5 Ver Nota 32, Otras Ganancias/(pérdidas), de nuestros Estados Financieros al 31 de diciembre 2024
 3

[pág. 4]
ANÁLISIS RAZONADO
La composición de pasivos, expresada como porcentaje sobre el total de los pasivos, al 31 de diciembre de 2024
se compone de un 37,1% en corriente y 62,9% en no corriente. Esta composición aumenta la composición
corriente desde un 32,9% y disminuye la porción no corriente desde un 67,1% al compararlo con el 31 de
diciembre de 2023. Esto se explica por mayores Cuentas por pagar comerciales y una mayor deuda de corto
plazo.
La Cobertura de Gastos Financieros, disminuyó levemente con respecto al 31 de diciembre del 2023, al pasar
desde 4,9 veces a 4,3 veces al 31 de diciembre 2024, explicado por un aumento proporcionalmente mayor en
los gastos financieros, que el alza registrada en el EBITDA. Los mayores gastos financieros se explican
principalmente por una mayor deuda y mayores tasas de interés en Argentina.
3. ACTIVIDAD
El total de activos de la Compañía al 31 de diciembre de 2024 muestra un aumento en relación al 31 de
diciembre de 2023, al pasar desde CLP 3.423.946 millones a CLP 3.989.717 millones. Esta alza se debe tanto
a mayores Activos no corrientes, estos últimos asociado mayormente a mayores Propiedades, plantas y
equipos, como también a Activos corrientes, estos últimos por mayores Efectivo y equivalentes al efectivo y
mayores Deudores comerciales y otras cuentas por cobrar.
El Índice de Rotación de inventarios se ubicó en 3,6 veces, aumentando con respecto al 3,0 registrado al 31
de diciembre del 2023, esto último por una caída en el inventario promedio y un alza en los costos por ventas.
Consistentemente con lo anterior, la permanencia de inventarios disminuyó con respecto al 31 de diciembre de
2023, desde 118,4 días a 100,1 días.
4. RESULTADOS ACUMULADOS6
Ventas Físicas Consolidadas
Las ventas físicas acumuladas al 31 de diciembre de 2024 alcanzaron 33.773 Mhl (excluyendo ventas de vino
granel), equivalente a un alza de 1,9% o 636 Mhl respecto al mismo período del año anterior (caída orgánica
de 5,2% o 1.708 Mhl). Esta alza se explica por:
 • El Segmento de operación Chile cayó 0,3% o 74 Mhl.
 • El Segmento de operación Negocios Internacionales aumentó 7,5% o 684 Mhl. (Caída orgánica de
 18,2%, o 1.659 Mhl)
 • El Segmento de operación Vinos creció 1,0% o 14 Mhl.
Resultados Consolidados
El análisis a continuación considera cifras orgánicas, es decir, excluyendo la consolidación de ADO y
AV, a menos que se indique lo contrario.
 El Ingreso por ventas aumentó un 9,4% orgánicamente, como resultado de un aumento del 15,4% en los
 precios promedio orgánicos en CLP, parcialmente compensado por una contracción del 5,2% en los
 volúmenes consolidados orgánicos. El aumento de los precios promedio orgánicos en CLP se desglosa de
 la siguiente manera: (i) un aumento del 4,3% en el Segmento de operación Chile, relacionado con iniciativas
 de gestión de ingresos, parcialmente compensado por un efectos mix negativo en el portafolio; (ii) un
 aumento del 57,1% en el Segmento de operación Negocios Internacionales, impulsado por iniciativas de
 gestión de ingresos, que más que compensaron la devaluación del ARS frente al USD, y un efecto mix
 positivo, y (iii) un crecimiento del 10,6% en el Segmento de operación Vinos, impulsado principalmente por
 un CLP más débil y sus efectos favorables sobre los ingresos de exportación y un efecto mix positivo. La
 disminución de los volúmenes orgánicos se debió en gran medida a la contracción orgánica del 18,2% en el
 Segmento de operación Negocios Internacionales, casi en su totalidad explicada por Argentina, debido a
6
 Los resultados hacen referencia a cifras acumuladas a diciembre 2024 comparadas con cifras acumuladas a diciembre 2023, a
menos que se indique lo contrario.
 4

[pág. 5]
ANÁLISIS RAZONADO
 una caída levemente por sobre el 20% en la industria de la cerveza en dicho país, mientras que Paraguay
 y Bolivia expandieron volúmenes, y Uruguay los disminuyó debido a una alta base de comparación,
 explicada por una situación de escasez hídrica en 2023 que impulsó el consumo de agua envasada. El
 Segmento de operación Chile mantuvo la escala disminuyendo un 0,3%. El Segmento de operación Vinos
 expandió el volumen en un 1,0%, casi en su totalidad impulsado por las exportaciones desde Chile, que se
 expandieron un 3,9%, mientras que los volúmenes en el mercado doméstico en Chile se mantuvieron planos
 y los volúmenes en el mercado doméstico argentino disminuyeron.
 El Costo de venta creció un 12,0% orgánicamente, como consecuencia del aumento orgánico del 18,1% en
 el costo de ventas por hectolitro. El mayor costo de ventas por hectolitro se debió a: (i) un aumento del 7,1%
 en el Segmento de operación Chile, explicado por la depreciación del 12,5%4 del CLP frente al USD y su
 impacto en los costos denominados en USD, y por mayores precios en azúcar, pulpa de fruta y aluminio,
 parcialmente compensado por menores precios en malta y PET, (ii) una expansión orgánica del 68,6% en
 CLP en el Segmento de operación Negocios Internacionales, impulsada principalmente por Argentina debido
 a presiones de costos provenientes de la depreciación del ARS frente al USD; y (iii) un aumento del 7,7%
 en el Segmento de operación Vinos, impulsado principalmente por mayores costos vinculado al USD,
 parcialmente compensado por un menor costo de vino.
 El Margen bruto alcanzó los CLP 1.263.652 millones orgánicos, una expansión orgánica del 6,5%. El margen
 bruto orgánico, como porcentaje de los Ingresos por ventas, disminuyó en 126 puntos básicos.
 Los gastos de MSD&A aumentaron un 11,2% orgánicamente en CLP, y como porcentaje de los Ingresos
 por venta, se deterioraron 57 pb, principalmente explicado por el Segmento de operación Negocios
 Internacionales, debido a Argentina. El desglose por Segmento de operación fue el siguiente: (i) en el
 Segmento de operación Chile, los gastos de MSD&A se expandieron un 1,2%, y como porcentaje de los
 Ingresos por ventas mejoraron 93 pb, principalmente debido a eficiencias que compensaron mayores gastos
 vinculados al USD, y presiones inflacionarias, (ii) en el Segmento de operación Negocios Internacionales,
 los gastos de MSD&A aumentaron un 37,9% orgánicamente, y como porcentaje de los Ingresos por ventas
 aumentaron 306 puntos básicos orgánicamente, esto último debido principalmente a una menor escala de
 negocios en Argentina que impactó negativamente en la dilución de los gastos fijos; (iii) en el Segmento de
 operación Vinos, los gastos de MSD&A aumentaron un 9,1%, aunque como porcentaje de los Ingresos por
 ventas disminuyeron 74 pb, debido a eficiencias que ayudaron a compensar mayores gastos de marketing
 relacionados con las exportaciones que están denominados en USD.
 El EBIT alcanzó los CLP 262.702 millones, y orgánicamente alcanzó los CLP 262.146 millones. Excluyendo
 la ganancia no recurrente por la venta de una porción de terreno en Chile en el segundo trimestre de 2024,
 el EBIT orgánico totalizó CLP 233.477 millones, una disminución orgánica del 7,8% en comparación con el
 año pasado.
 El EBITDA alcanzó los CLP 415.936 millones, y orgánicamente alcanzó los CLP 414.095 millones.
 Excluyendo la ganancia no recurrente por la venta de una porción de terreno en Chile en el segundo trimestre
 de 2024, el EBITDA orgánico totalizó CLP 385.426 millones, un aumento orgánico del 1,6% en comparación
 con el año pasado, registrando un fuerte repunte en la segunda mitad del año. Por Segmento de operación,
 el mayor EBITDA orgánico se explicó por una expansión del 2,4% en el Segmento de operación Chile y un
 aumento del 30,0% en el Segmento de operación Vinos, siendo parcialmente compensado por una
 contracción orgánica del 10,5% en el Segmento de operación Negocios Internacionales, principalmente
 concentrada en Argentina, mientras que Paraguay y Bolivia reportaron una mejora en el EBITDA. El margen
 EBITDA alcanzó 14,3%, y orgánicamente alcanzó 14,7%, este último plano versus el año pasado.
Dado que el impacto de la consolidación de ADO y AV en el Resultado no operacional y en la Utilidad
neta no es material, el análisis a continuación considera cifras consolidadas, es decir, incluyendo la
consolidación de ambos negocios.
 El Resultado no operacional totalizó una pérdida de CLP 97.172 millones frente a un resultado negativo de
 CLP 150.125 millones en 2023. El mejor resultado se explicó principalmente por: (i) una menor pérdida en
 Diferencias de cambio por CLP 48.147 millones, debido a una menor exposición en pasivos en moneda
 extranjera en el balance de Argentina, (ii) un mejor resultado en Otras ganancias/(pérdidas) por
 CLP 13.221 millones, causado principalmente por contratos de derivados 5, específicamente, contratos
 forward celebrados para mitigar el impacto de las fluctuaciones del tipo de cambio en nuestras posiciones
 5

[pág. 6]
ANÁLISIS RAZONADO
 en moneda extranjera en el balance, (iii) una menor pérdida en Utilidad de negocios conjuntos y asociadas
 por CLP 9.723 millones, impulsada por gastos no recurrentes en 2023 relacionados con la integración de
 ADO en nuestra operación, y un mejor resultado financiero en Colombia, y (iv) un mejor resultado en
 Resultados por unidades de ajuste por CLP 3.304 millones, principalmente en Argentina. Esto último se vio
 parcialmente compensado por una mayor pérdida por CLP 21.443 millones en Gastos financieros netos,
 principalmente debido a una mayor deuda y mayores tasas de interés en Argentina.
 El Impuesto a las ganancias alcanzó un resultado positivo de CLP 11.015 millones versus un resultado
 positivo de CLP 15.267 millones el año anterior. Esto se explica principalmente por una mayor utilidad antes
 de impuestos, parcialmente compensados por efectos positivos en Argentina por la aplicación de la inflación
 para fines tributarios.
 La Utilidad neta alcanzó una ganancia de CLP 160.944 millones, una expansión de 52,3%. Excluyendo la
 ganancia no recurrente por la venta de una porción de terreno en Chile en 2T24, la Utilidad neta alcanzó
 CLP 140.016 millones, aumentando un 32,5%, explicado por los efectos mencionados anteriormente.
Resultados Cuarto Trimestre por Segmento de operación7:
 1. Segmento de operación Chile
En el Segmento de operación Chile los Ingresos por ventas aumentaron en un 9,9%, como resultado de un
aumento del 4,9% en los precios promedio y un 4,7% de mayores volúmenes. Los precios promedio se vieron
impulsados por iniciativas de gestión de ingresos, parcialmente compensados por un efecto mix negativo,
mientras que los volúmenes se expandieron principalmente debido a una baja base de comparación en el
4T23. El EBITDA totalizó CLP 106.879 millones, un aumento del 23,0% y el margen EBITDA creció 208 puntos
base hasta 19,6%.
Progresamos en términos de nuestra Estrategia de Sustentabilidad “Juntos por un Mejor Vivir”. Nuestra planta
de reciclaje de PET "CirCCUlar" alcanzó un nuevo hito importante al lanzar las primeras botellas de PET
producidas con material reciclado en Chile. La marca elegida fue Cachantun, nuestra marca líder de agua
mineral. También lideramos la novena versión de la campaña de reciclaje más extensa de Chile, denominada
"Familias reciclando en modo #BilzYPap", una iniciativa que invita a todas las familias chilenas a reciclar
botellas de PET con más de 700 puntos de reciclaje en todo Chile. En el marco de nuestra agenda de
"Equilibrio Hídrico", CCU, en asociación con FreshWater, instaló dispositivos innovadores de purificación de
agua en dos entidades educativas, proporcionando agua diaria a los niños en una zona donde la escasez de
agua ha sido un desafío persistente.
En cuanto a nuestras marcas, CCU fue reconocida como una marca ciudadana líder en Chile, ocupando el
puesto 20, en la decimoquinta edición del estudio "Marcas Ciudadanas" realizado por Cadem, Deloitte y Diario
Financiero durante el segundo semestre de 2024. Este estudio evalúa 310 marcas, de las cuales 40 fueron
consideradas marcas ciudadanas por su contribución e impacto en la vida de los chilenos. Además, las
marcas de CCU, Cachantun y Kunstmann alcanzaron el primer lugar en las categorías de bebidas y bebidas
alcohólicas, respectivamente.
En cuanto a innovaciones, presentamos nuevas marcas y nuevas variedades de marcas ya existentes durante
el trimestre, entre ellas: el lanzamiento de H2Oh!, una nueva bebida no alcohólica ligeramente gasificada,
refrescante y sin azúcar, presentada en dos sabores, Lima Limón y Naranchelo. Esta marca responde a la
creciente demanda de los consumidores por mayor variedad y opciones más saludables en el mercado. En
la categoría de cerveza, lanzamos Sol Mix, con dos nuevas variedades con sabor diseñadas para ampliar las
ocasiones de consumo y ampliar el mercado de la cerveza al dirigirse a consumidores de otras categorías.
 2. Segmento de operación Negocios Internacionales
En el Segmento de operación Negocios Internacionales, excluyendo los volúmenes inorgánicos de la
consolidación de ADO y AV, en Argentina y Paraguay, respectivamente, las ventas netas orgánicas
registraron un fuerte aumento, impulsado por mayores precios promedio orgánicos, que más que
compensaron una contracción del 11,5% en los volúmenes orgánicos. Los precios promedio orgánicos más
7
 Los resultados hacen referencia a cifras del cuarto trimestre 2024 comparadas con el cuarto trimestre del 2023, a menos que se
indique lo contrario.
 6

[pág. 7]
ANÁLISIS RAZONADO
altos se vieron impulsados principalmente por una baja base de comparación debido a un impacto negativo
en los Ingresos por ventas producto de la fuerte devaluación del ARS frente al USD en nuestros resultados
del 4T233, y en menor medida por esfuerzos de gestión de ingresos. El EBITDA orgánico alcanzó los
CLP 69.873 millones, más que triplicando lo alcanzado el año pasado, impulsado por todas las geografías de
este segmento.
 3. Segmento de operación Vinos
El Segmento de operación Vinos registró una expansión de 21,4% en los Ingresos por ventas, impulsada por
un aumento del 21,7% en los precios promedio, mientras que los volúmenes se mantuvieron planos. Las
exportaciones se expandieron durante el trimestre, siendo casi totalmente compensado por una caída del
mercado doméstico argentino, ya que los volúmenes domésticos chilenos se mantuvieron planos. Los mejores
precios promedio se explicaron principalmente por una base de comparación favorable 3, un CLP más débil y
su impacto favorable en los ingresos de exportación, y efectos mix positivos. El EBITDA alcanzó los
CLP 12.222 millones, un crecimiento del 16,0% y el margen EBITDA se redujo en 74 pb.
Además, durante el trimestre lanzamos Donnaluna, un nuevo y refrescante cóctel de vino, diseñado para
refrescarse durante los meses más cálidos, hecho con esencias naturales, ligeramente gasificado y bajo en
alcohol y calorías. Las variedades de Donnaluna tienen 5,5 grados de alcohol y se presentan en tres
variedades: tinto rosso, rossatto y bianco.
5. RENTABILIDAD
La Rentabilidad del Patrimonio al 31 de diciembre de 2024 respecto al 31 de diciembre de 2023 aumentó, al
pasar de 8,3% a 11,7% ya que la Utilidad neta aumentó por sobre el Patrimonio promedio. Por su parte, la
Rentabilidad del Activo aumentó desde un 3,0% a un 4,3% en el mismo periodo, ya que la Utilidad neta
aumentó más que el Total de activos promedio. Por el contrario, el Rendimiento de los Activos Operacionales
experimentó una caída desde 9,2% a 8,2% durante el mismo periodo, ya que este se calcula como el EBIT
sobre los Activos productivos promedio. El EBIT aumentó proporcionalmente menos que los Activos
productivos.
La Utilidad por Acción al 31 de diciembre de 2024 aumentó con respecto al 31 de diciembre de 2023, pasando
desde CLP 285,9 a CLP 435,6. Esto debido a que la Utilidad atribuible a los propietarios de la controladora
aumentó en un 52,3%, esto último principalmente asociado a la venta de una porción de un terreno en Chile
que generó una ganancia después de impuestos de CLP 20.928 millones en el segundo trimestre de 2024.
Aislando dicho efecto, la Utilidad neta se expandió un 32,5%.
Por su parte, el Retorno de Dividendos al 31 de diciembre de 2024, aumentó con respecto al 31 de diciembre
de 2023, al pasar desde 2,0% a 3,5%, principalmente asociado a mayores dividendos repartidos en los últimos
12 meses.
6. ESTADO DE FLUJOS DE EFECTIVO
Al 31 de diciembre de 2024, se generó un alza del saldo de Efectivo y equivalentes al efectivo respecto del 31
de diciembre de 2023 de CLP 88.969 millones, explicado principalmente porque los flujos positivos de efectivo
procedentes de actividades de operación por CLP 287.517 millones, superaron los desembolsos de
actividades de inversión y financiación por CLP 118.294 millones y CLP 125.036 millones, respectivamente.
Adicionalmente, se registró un efecto positivo en el Efectivo y equivalentes al efectivo por movimientos de tipos
de cambio por CLP 44.187 millones.
Los flujos netos negativos provenientes de las actividades de inversión son explicados principalmente por la
incorporación de propiedades, plantas y equipos, contrarrestado por importes procedentes de la venta de
propiedades, planta y equipo, esto último por la venta de una porción de terreno en Chile en el 2T24. Por su
parte, los flujos negativos de las actividades de financiación se generan principalmente por pagos de
préstamos y bonos y dividendos pagados, parcialmente contrarrestado por importes procedentes de
préstamos de corto plazo y bonos.
 7

[pág. 8]
ANÁLISIS RAZONADO
Todo lo anterior, se tradujo en un saldo final de efectivo y equivalentes al efectivo de CLP 707.123 millones al
31 de diciembre de 2024.
7. FACTORES DE RIESGO
Los riesgos a continuación no son los únicos que enfrenta la Compañía. Los riesgos adicionales que
actualmente no conocemos o que consideramos inmateriales también pueden afectar adversamente nuestra
operación. Los siguientes factores de riesgo se han agrupado de la siguiente manera:
 • Riesgos asociados a nuestro negocio
 • Riesgos asociados al cambio climático
 • Riesgos relativos a Chile
 • Riesgos relativos a Argentina
Riesgos relativos a nuestro negocio
POSIBLES CAMBIOS EN LA LEGISLACIÓN TRIBUTARIA EN LOS PAÍSES DONDE OPERAMOS PODRÍAN
AFECTAR NUESTRO NEGOCIO Y, EN PARTICULAR, LOS CAMBIOS EN LOS IMPUESTOS
CORPORATIVOS Y ESPECÍFICOS PODRÍAN AFECTAR A NUESTROS RESULTADOS E INVERSIONES.
Nuestros negocios están afectos a distintos impuestos en los países donde operamos, incluyendo entre otros,
impuestos a la renta e impuestos específicos sobre bebidas alcohólicas y no alcohólicas. Un aumento en las
tasas de dichos impuestos, o de cualquier otro, o cambios en las regulaciones de los mismos, podrían afectar
en forma negativa nuestras ventas y rentabilidad.
LOS CAMBIOS EN EL MERCADO LABORAL DE LOS PAÍSES EN QUE OPERAMOS PODRÍAN AFECTAR
NUESTROS MÁRGENES DEL NEGOCIO.
En todos los países donde operamos estamos expuestos a cambios en el mercado laboral que podrían afectar
nuestra rentabilidad y crecimiento futuro. Estos cambios podrían incluir fluctuaciones en la oferta de mano de
obra, aumento de la demanda en ciertas especialidades y cambios en la legislación laboral, entre otros.
En abril de 2023 se publicó en Chile, la ley sobre reducción de la jornada de trabajo, de 45 a 40 horas,
señalando que su implementación se hará de manera progresiva a contar del mes de abril de 2024, en un
plazo máximo de 5 años.
En Argentina, los altos niveles de inflación y presión sindical suponen un continuo incremento de nuestros
gastos salariales.
LA COMPAÑÍA ENFRENTA RIESGOS RELACIONADOS CON LA LIBRE COMPETENCIA EN TODOS LOS
MERCADOS DONDE OPERA.
Los principales riesgos de libre competencia que enfrenta CCU están asociados a su posición en cada uno
de los mercados en que participa. En Chile, donde la Compañía tiene una posición de liderazgo, ha sido
demandada por su principal competidor por supuestas conductas de abuso de posición dominante, sin que
hasta la fecha el tribunal haya resuelto. Por otro lado, con ocasión de un requerimiento de la Fiscalía Nacional
Económica ("FNE") por eventuales abusos, el Tribunal de Defensa de la Libre Competencia aprobó una
conciliación entre CCU S.A. y la FNE, en virtud de la cual CCU S.A. asumió una serie de compromisos en
orden a facilitar el ingreso de micro-cerveceros artesanales a locales que venden cerveza para ser consumida
en los mismos, tales como hoteles, restaurantes, pubs, bares y discotecas. Adicionalmente, en los demás
países en que la Compañía está presente, está expuesta mayormente a ser víctima de abusos de posición
dominante por parte de algunos de sus competidores. La Compañía cuenta con un programa y un manual de
libre competencia, el cual considera entre otras iniciativas, capacitaciones a los colaboradores en estas
materias realizadas por la Gerencia de Cumplimiento, quién es responsable de la gestión de riesgos de libre
 8

[pág. 9]
ANÁLISIS RAZONADO
competencia.
LA CONSOLIDACIÓN DE LA INDUSTRIA A NIVEL MUNDIAL PODRÍA IMPACTAR NUESTRA
PARTICIPACIÓN DE MERCADO.
En todos los países donde operamos, competimos con marcas locales y globales, especialmente en las
categorías de cervezas y bebidas analcohólicas. En cervezas competimos con las filiales de Anheuser-Busch
InBev SA/NV (“ABI”), la compañía de cervezas más grande del mundo y en bebidas no alcohólicas,
competimos principalmente con empresas embotelladoras de los productos de The Coca-Cola Company.
Nuestra principal competencia en el mercado chileno de cervezas es Cervecería Chile S.A., filial de ABI, que
cuenta con un acuerdo de distribución de sus productos con Embotelladora Andina S.A. y Embonor S.A., los
principales embotelladores de los productos de The Coca-Cola Company en Chile. En el pasado, Cervecería
Chile S.A. ha implementado agresivas prácticas comerciales. En Argentina competimos con Cervecería y
Maltería Quilmes S.A.I.C.A. y G, en Paraguay competimos con Cervecería Paraguaya S.A., en Uruguay con
Fábricas Nacionales de Cerveza S.A., en Bolivia con Cervecería Boliviana Nacional S.A. y en Colombia con
Bavaria & Cia S.C.A., todas ellas filiales de ABI. Como resultado de su posición dominante y gran tamaño en
estos países, estas compañías se benefician de economías de escala en la producción y la distribución de
cervezas.
En bebidas analcohólicas competimos principalmente con Embotelladora Andina S.A. y Embonor S.A., en
Chile, en Paraguay con Paraguay Refrescos S.A., en Uruguay con Montevideo Refrescos S.R.L. y en Bolivia
con Embotelladoras Bolivianas Unidas, EMBOL S.A., todas ellas, embotelladoras de los productos de The
Coca-Cola Company.
Dado lo anterior, no podemos asegurar que a futuro la agresividad de la competencia no se incremente dada
la capacidad financiera de nuestros competidores, pudiendo afectar nuestra participación de mercado y
rentabilidad.
DEPENDEMOS DE LA RENOVACIÓN DE DETERMINADOS ACUERDOS DE LICENCIA PARA MANTENER
NUESTRAS ACTUALES OPERACIONES.
La mayoría de nuestros acuerdos de licencia incluyen determinadas condiciones que deben ser cumplidas
durante su vigencia para su renovación. El término de algunos de nuestros acuerdos de licencias podría tener
un impacto negativo sobre nuestras operaciones. Aproximadamente un 70% de nuestro volumen de ventas
son de marcas propias, lo que mitiga en parte el efecto que podría tener el término de alguna licencia
específica.
EL CRECIMIENTO DEL CANAL DE SUPERMERCADOS PODRÍA AFECTAR NUESTRA RENTABILIDAD.
La industria de supermercados en Chile se encuentra consolidada, lo que aumenta la importancia y poder de
negociación de las cadenas de supermercados. Como resultado de ello, podríamos no ser capaces de obtener
precios favorables, lo que podría afectar nuestras ventas y rentabilidad en forma negativa. Como resultado
de las fortalezas y la estrategia de la Compañía, junto con las tendencias de consumo, la Compañía ha logrado
mantener el canal tradicional como su principal canal de ventas.
Además, la consolidación de las cadenas de supermercados tiene el efecto de aumentar nuestra exposición
al riesgo de crédito, ya que estamos más expuestos en caso que alguno de estos grandes clientes deje de
cumplir con sus obligaciones de pago hacia nosotros. Para estos casos, la Compañía cuenta con cobertura
de seguros de crédito.
LAS FLUCTUACIONES EN EL COSTO DE NUESTRAS MATERIAS PRIMAS PODRÍAN IMPACTAR
NEGATIVAMENTE NUESTRA RENTABILIDAD.
Compramos malta, arroz y lúpulo para la cerveza, azúcar para gaseosas, uva para el vino, pisco y cócteles y
material de embalaje a productores locales o a través de compras en el mercado internacional. Los precios
de dichos productos están expuestos a la volatilidad de las condiciones de mercado, han experimentado
importantes fluctuaciones a través del tiempo, están determinados por su oferta y demanda global, junto con
otros factores como las variaciones en los tipos de cambio, sucesos climáticos, sociales y conflictos
 9

[pág. 10]
ANÁLISIS RAZONADO
geopolíticos, sobre los que no tenemos control.
La Compañía cuenta con acuerdos de suministro a largo plazo de ciertas materias primas con proveedores
que incorporan polinomios de reajustes que aseguren reflejar el costo real de los insumos. Ante variaciones
que podrían afectar negativamente nuestra rentabilidad buscamos coordinadamente a nivel interno proyectos
de eficiencias que ayuden a compensar dicho efecto.
LA ESCASEZ DE MATERIAS PRIMAS Y MATERIALES DE EMPAQUE CRÍTICOS JUNTO CON LAS
INTERRUPCIONES EN LA LOGÍSTICA DEL COMERCIO INTERNACIONAL PODRÍAN IMPACTAR
NEGATIVAMENTE A NUESTRA CADENA DE SUMINISTROS.
La escasez de materias primas y materiales de empaque críticos, ya sea por cambios en los patrones de
consumo, el nivel de producción de los cultivos agrícolas en el mundo, la calidad y disponibilidad del
suministro, y/o problemas asociados a la logística del comercio internacional, podría afectar nuestra cadena
de suministro e impactar negativamente nuestros niveles de producción y, en consecuencia, nuestros
resultados.
En Chile, la Ley N° 21.368 del año 2021, que regula la entrega de plástico de un solo uso y las botellas de
plástico, y que refuerza la retornabilidad, denominada Ley PUSU, requiere que los productores de bebestibles
incorporen en sus botellas plásticas desechables un determinado porcentaje de plástico recolectado y
reciclado en Chile. La Compañía ha implementado planes que permitan reducir el riesgo de no disponibilidad
de dicho plástico a ser utilizado como materia prima en el mercado local.
Nuestra cadena de suministro, producción y logística es fundamental para la entrega de nuestros productos
a los centros de consumo. Falta de capacidad para atender la demanda o una interrupción o una falla
significativa en esta cadena podría afectar en forma negativa los resultados de la Compañía, en caso que
dicha falla no sea resuelta a la brevedad. Una interrupción podría ser causada por diversos factores, como
huelgas, paralizaciones de servicios públicos tales como aduanas y puertos, fallas en la planificación con
nuestros proveedores, terrorismo, fallas de seguridad, delincuencia, crisis sanitarias, reclamaciones de las
comunidades, cortes de energía eléctrica u otros eventos de la naturaleza como terremotos o incendios, que
escapan a nuestro control.
Para mitigar este escenario, la Compañía cuenta con un proceso de revisión anual que identifica riesgos
asociados a este tema para generar o actualizar planes de acción que ayuden a mitigar el riesgo. En dicho
proceso se toman acciones que van desde la firma de contratos de largo plazo, que permiten mejorar el
relacionamiento estratégico con los proveedores, elaboración de planes de contingencia que incluya
materiales sustitutos, búsqueda de nuevos proveedores, o contar con mayores niveles de inventarios de
ciertos insumos identificados como críticos.
CRISIS SANITARIAS, PANDEMIAS O EL BROTE DE ENFERMEDADES CONTAGIOSAS A NIVEL GLOBAL
O REGIONAL PODRÍAN TENER UN IMPACTO NEGATIVO EN NUESTRAS OPERACIONES Y POSICIÓN
FINANCIERA.
Una crisis sanitaria, pandemias o el brote de enfermedades a nivel global o regional podrían tener un impacto
negativo en nuestras operaciones y posición financiera. Esto debido a que estas podrían impedir el normal
funcionamiento de la operación de la Compañía, limitar nuestra capacidad de abastecimiento, producción y
distribución, y/o generar una contracción de la demanda de nuestros productos. Un período prolongado de
incertidumbre económica podría tener un impacto material desfavorable en nuestro negocio, en los resultados
de las operaciones, en el acceso a financiamiento y en la situación financiera general.
Cualquier medida restrictiva prolongada establecida para controlar un brote de una enfermedad contagiosa u
otro desarrollo adverso de salud pública en cualquiera de los mercados objetivos puede tener un efecto
material y adverso en las operaciones comerciales. El alcance del impacto de una pandemia en nuestro
negocio y situación financiera dependerá en gran medida de la evolución futura, incluida la duración de la
pandemia, el impacto en los mercados financieros y de capitales y el impacto relacionado en la confianza de
los consumidores y las industrias, todo lo cual es muy incierto y no podrían predecirse con exactitud.
La Compañía cuenta con planes de contingencia para el cuidado de las personas y la continuidad operacional
para enfrentar eventos de este tipo, pero no podemos asegurar que dichos planes sean suficientes para
mitigar un impacto material en nuestros resultados y posición financiera.
 10

[pág. 11]
ANÁLISIS RAZONADO
EL CAMBIO EN EL ESTILO DE VIDA Y LAS PREFERENCIAS DE CONSUMO DE LAS PERSONAS, PODRÍA
TENER UN IMPACTO EN NUESTRO NEGOCIO, SITUACIÓN FINANCIERA Y RESULTADOS.
La pandemia por COVID-19 y otros eventos han propiciado los cambios en el estilo de vida, las preferencias
de consumo y ha generado una aceleración de la revolución digital. Estos cambios impactan en las
preferencias de los consumidores, lo que requiere innovación que nos permita mantenernos competitivos en
línea con las preferencias de consumo.
ESTAMOS EXPUESTOS AL RIESGO DE UN CIBERATAQUE QUE AFECTE NUESTRAS PLATAFORMAS
DE INFORMACIÓN, LO QUE PODRIA GENERAR UNA INTERRUPCIÓN EN NUESTRO NEGOCIO.
La aceleración digital, ha generado en gran medida una dependencia de las empresas por digitalizar el
negocio, desde las redes de datos hasta los sistemas de TI (Tecnología de la Información), lo cual genera
una brecha en la seguridad, en donde estos componentes son cada vez más vulnerables, pudiendo causar
interrupciones de las operaciones, pérdidas financieras, pérdida de datos y daños a la reputación.
Los ciberataques pueden tener un impacto significativo en las operaciones, la reputación y los resultados, ya
que pueden provocar interrupciones en las actividades de producción, distribución y ventas, con un riesgo de
pérdida de ingresos y/o mayores costos para retomar operaciones y dañar la reputación y la confianza de
nuestros clientes.
En CCU hemos implementado un plan de ciberseguridad, cuyo objetivo es definir, incorporar y robustecer
capacidades y procesos críticos, para prevenir ciberataques y proteger la continuidad del negocio. Este plan
contempla, la incorporación de tecnología de última generación que nos apoya en la identificación, protección
y detección, así como en la respuesta y recuperación de las operaciones en sus ambientes industriales como
tecnológicos en caso de un evento.
Además, CCU, ha definido un Gobierno Corporativo, el cual entre otros aspectos define políticas de
ciberseguridad, planes de educación y formación a los empleados en materia de ciberseguridad, y soluciones
de seguridad cibernética.
CAMBIOS EN LAS REGULACIONES EN MATERIAS DE ETIQUETADO Y PUBLICIDAD DE BEBIDAS
ALCOHÓLICAS Y OTROS PRODUCTOS ALIMENTICIOS EN LOS PAÍSES DONDE OPERAMOS PODRÍAN
AFECTARNOS.
En agosto de 2021 se publicó en Chile la Ley N° 21.363 que establece normas en materia de comercialización
y publicidad de bebidas alcohólicas, modificando las Leyes N° 18.455 y N° 19.925. Esta modificación introduce
restricciones en materia de publicidad, etiquetado y comercialización de bebidas alcohólicas incorporando
advertencias sobre el consumo de alcohol en etiquetado y publicidad, la obligación de informar en las
etiquetas la energía de los productos, restricciones horarias de publicidad, prohibición en participación en
eventos deportivos y culturales, entre otros, las que entran en vigencia en forma inmediata o diferida según
se establece en la referida norma. Este cambio normativo podría afectar nuestro portafolio de bebidas
alcohólicas y ciertas actividades de marketing. La Compañía continúa con su compromiso de largo plazo en
ser un activo agente de la promoción de un consumo responsable de alcohol en la sociedad.
Actualmente, se encuentra en tramitación en Chile proyectos de ley que modifican la Ley N° 18.455 que fija
normas sobre producción, elaboración y comercialización de alcoholes etílicos, bebidas alcohólicas y
vinagres, en materias relativas a información de ingredientes e información nutricional obligatoria, así como
la incorporación de rotulación de advertencias establecidas para alimentos calificados como “altos en” cuando
corresponda.
Si estos u otros proyectos similares son aprobados, así como futuras regulaciones que pudieran restringir la
venta de bebidas alcohólicas o no alcohólicas, en cualquiera de los países donde operamos, se podría ver
afectado el consumo de nuestros productos y, como consecuencia de ello, impactar nuestro negocio en forma
negativa.
 11

[pág. 12]
ANÁLISIS RAZONADO
NUESTROS RESULTADOS PODRÍAN VERSE AFECTADOS SI NO SOMOS CAPACES DE MANTENER LA
IMAGEN, CALIDAD DE NUESTROS PRODUCTOS, Y UNA BUENA RELACIÓN CON NUESTROS
CLIENTES Y CONSUMIDORES.
La imagen y calidad de nuestros productos es esencial para el éxito y el desarrollo de la Compañía. Un
eventual problema de calidad podría empañar la reputación de nuestros productos y podría afectar en forma
negativa nuestros ingresos. Asimismo, es importante asegurar una buena atención al cliente por nuestra
fuerza de ventas y adecuar nuevos lanzamientos e innovaciones a las necesidades y gustos de nuestros
consumidores. Así mismo, información negativa o imprecisa en redes sociales, podría afectar nuestra
reputación.
Como Compañía sostenemos la postura de mantención y mejoramiento continuo en ámbitos de calidad e
inocuidad de las materias primas y materiales, velando siempre, por la seguridad de quienes trabajamos en
CCU, al igual que la seguridad de nuestros consumidores y del medio ambiente durante los procesos de
elaboración, envasado y distribución de nuestros productos.
Todas nuestras categorías de bebidas sin alcohol están desarrolladas bajo el Reglamento Sanitario de los
Alimentos en Chile, y cada país se rige bajo la normativa existente y, en casos especiales, se acude a la
Universidad Católica y al INTA.
Dentro de las certificaciones con las que contamos destacan: (i) Hazard Analysis and Critical Control Points
("HACCP”) y (ii) ISO 22000, FSSC 22000 y British Retail Consortium (“BRC”).
 LA COMPAÑÍA OPERA EN GEOGRAFIAS EXPUESTAS A DESASTRES NATURALES, DONDE ANTE
UN EVENTO EXTRAORDINARIO NUESTRA COBERTURA DE SEGUROS PODRÍA SER INSUFICIENTE
PARA CUBRIR CIERTAS PÉRDIDAS EN LAS QUE PODEMOS INCURRIR.
Nuestra cobertura de seguros se ajusta a nuestras políticas internas y a los estándares del mercado. En caso
de eventos extraordinarios, nuestros seguros pueden ser insuficientes para cubrir ciertas pérdidas. A la fecha
de este documento, mantenemos una cobertura de seguro a todo riesgo, incluyendo averías de maquinaria y
daños debido a interrupciones en nuestras operaciones, terremotos e incendios para todos nuestros activos.
Nuestras pólizas de seguro están sujetas a deducibles y límites de cobertura y, a pesar de estar en línea con
los estándares del mercado, pueden ser insuficientes para dar cobertura a determinadas indemnizaciones.
Además, el mercado de seguros sigue siendo cíclico y los eventos catastróficos podrían cambiar las
condiciones en el mercado de seguros, provocando incrementos en el costo de las primas y de los deducibles
o, en caso excepcional, la falta de disponibilidad de la cobertura por factores no relacionadas con nuestro
negocio.
El hecho de que se produzcan eventos adversos significativos, pérdidas u otros daños que no estén parcial o
totalmente cubiertos por nuestro programa de seguros o que superen los límites de cobertura, podría dar lugar
a costos adicionales inesperados y, a su vez, tener un efecto material adverso en nuestro negocio, su situación
financiera y los resultados de las operaciones.
Riesgos relativos al cambio climático
EL SUMINISTRO DE AGUA ES ESENCIAL PARA EL DESARROLLO DE NUESTROS NEGOCIOS.
El agua es un componente esencial para la elaboración de nuestros productos y riego de nuestros campos.
Una falla en nuestro suministro de agua, cambios normativos que limiten el uso de este recurso, problemas
de escasez hídrica producto del cambio climático, o una contaminación de nuestras fuentes, podría afectar
en forma negativa nuestras ventas e incrementar los costos, afectando como consecuencia la rentabilidad.
La Compañía cuenta con procesos, políticas y procedimientos para optimizar el consumo de agua industrial
y reducir el impacto de nuestras operaciones en el medio ambiente.
Desde 2010, contamos con una Visión Medioambiental que establece metas de reducción de consumo de
agua en nuestras operaciones. Entre el año 2010 y 2023, la Compañía redujo aproximadamente en un 48%
el consumo de este recurso por hectolitro producido. Asimismo, CCU ha renovado su compromiso en la nueva
Estrategia de Sustentabilidad a través de su Visión Medioambiental 2030. En particular, en lo que se refiere
a equilibrio hídrico, se compromete a seguir optimizando el consumo de agua por hectolitro producido.
 12

[pág. 13]
ANÁLISIS RAZONADO
DESASTRES NATURALES EN LAS GEOGRAFÍAS EN QUE OPERAMOS PODRÍAN TENER UN EFECTO
NEGATIVO SIGNIFICATIVO SOBRE NUESTRAS OPERACIONES Y POSICIÓN FINANCIERA.
Los desastres de la naturaleza en los territorios donde operamos podrían impedir o afectar nuestra capacidad
de fabricar, distribuir o vender nuestros productos. El no tomar las medidas adecuadas para mitigar el posible
impacto de dichos eventos, o no manejarlos en forma efectiva si se producen, podría afectar en forma negativa
los resultados operacionales y la posición financiera de la Compañía.
Chile se ha visto afectado en el pasado por desastres naturales, tales como terremotos, aluviones e incendios
forestales de gran magnitud. Para mitigar los impactos de estos eventos u otros, la Compañía cuenta con
planes de contingencia especialmente diseñados, medidas de seguridad que contribuyen a la mitigación y
seguros asociados. Los efectos de los desastres naturales podrían verse aumentados producto del cambio
climático.
NUEVAS NORMATIVAS MEDIO AMBIENTALES APLICABLES PODRÍAN AFECTAR NUESTRO NEGOCIO.
Las operaciones de la Compañía están sujetas a normativa medioambiental a nivel local, nacional e
internacional. Dicha normativa cubre, entre otras cosas, emisiones provenientes de distintas fuentes, ruidos,
la eliminación de residuos sólidos y líquidos, el almacenamiento temporal de residuos y sustancias peligrosas
y no peligrosas, olores y otras actividades inherentes a nuestra industria. En Chile el 1 de junio de 2016 se
dictó la Ley N° 20.920 que estableció el marco para la Gestión de Residuos y Responsabilidad Extendida del
Productor y Fomento al Reciclaje, definida anteriormente como Ley REP, cuya finalidad es disminuir la
generación de residuos de productos prioritarios determinados en dicha normativa y fomentar su reutilización.
El 16 de marzo de 2021, se publicó el Reglamento que establece metas de recolección, valorización y otras
obligaciones asociadas a envases y embalajes las que se irán haciendo efectivas a partir de septiembre de
2023 y de forma progresiva durante los próximos años, según los porcentajes de cada producto prioritario.
Adicionalmente las filiales de CCU, que son productores para efectos de la Ley REP, adhirieron como socias
al primer Sistema de Gestión Colectivo llamado ReSimple, que a su vez cuenta con las aprobaciones
ambientales y del Tribunal de Defensa de la Libre Competencia (“TDLC”).
Adicionalmente, la Ley Nº 21.368 de 2021, denominada Ley PUSU, requiere: (i) que las botellas de plástico
desechables que se comercialicen deben ser fabricadas conteniendo un porcentaje de plástico recolectado y
reciclado dentro del país de acuerdo a lo que establezca el reglamento que al efecto se dictará, con un mínimo
de un 15% el año 2025 y con un crecimiento progresivo hasta el 2060, y (ii) los comercializadores de
bebestibles (incluyendo el comercio electrónico y las aplicaciones de delivery) deberán ofrecer bebestibles en
botellas retornables y en el caso de supermercados disponer un 30% de sus vitrinas para dichos formatos
retornables. Esta última obligación es exigible a partir del 13 agosto de 2024. Al respecto, está pendiente la
dictación del reglamento de la Ley PUSU que permitirá resolver las referencias técnicas que se requieren para
la operación y cumplimiento de la referida Ley.
De manera de anticipar el cumplimiento integral de esta normativa, CCU se encuentra en proceso de
construcción de la Planta de Resina Reciclada denominada “CirCCUlar” que se encargará de transformar el
plástico recolectado y reciclado en el país, en resina reciclada para ser usada en nuestras botellas. Dadas las
restricciones establecidas en la Ley y en el futuro reglamento, en relación a la obtención del referido plástico,
se deberán establecer cadenas de abastecimiento a partir de material propio (mermas) y de la obtención de
terceros.
En Chile, la reforma del Código de Aguas de 2022 establece un nuevo régimen de constitución de derechos
de aprovechamiento de aguas de carácter temporal, aplicable a aquellos derechos que se otorguen en el
futuro, e introduce un sistema de caducidad por no uso cuando no se realicen las obras constructivas para el
ejercicio de los mismos y tales derechos figuren publicados en el listado de pago de patente de no uso durante
un plazo determinado, ello sumado a la introducción, dentro del proceso de evaluación ambiental, de criterios
relativos al cambio climático estableciendo un régimen más exigente respecto al recurso hídrico, tanto para
la constitución de nuevos derechos como para la evaluación ambiental de nuevos proyectos con variables
ambientales hídricas.
A su vez, Ley N° 21.455 de 2022, Ley Marco de Cambio Climático en Chile, establece un marco jurídico para
hacer frente a los desafíos que presenta para el país el cambio climático, con la finalidad de alcanzar y
 13

[pág. 14]
ANÁLISIS RAZONADO
mantener la neutralidad de emisiones de Gases de Efecto Invernadero (“GEI”) al año 2050. En relación a lo
anterior, y dados los instrumentos de gestión que se emitirán como las guías que establecen los efectos
sinérgicos y seguimiento de variables ambientales con mirada de cambio climático estimamos que la
regulación y tramitación ambiental serán más exigentes y complejidad regulatoria.
El 6 de septiembre de 2023 se promulgó la Ley de Biodiversidad, que crea el Servicio de Biodiversidad,
institucionalidad orientada a conservar la diversidad biológica y protección del patrimonio natural del país,
encontrándose pendiente la dictación del respectivo reglamento, por lo que será necesario revisar la
implementación del mismo y su grado de afectación en nuestras operaciones.
En relación a la normativa ambiental, la Ley N° 21.595 de agosto de 2023, “Ley de Delitos Económicos”,
incorporó un capítulo nuevo al Código Penal chileno denominado “Atentados Contra Medio Ambiente”, el cual
establece tipos penales específicos en materia medioambiental enmarcados, entre otros, en la liberación de
sustancias contaminantes al aire, agua, suelo, la extracción ilegal de agua y la afectación grave al
medioambiente, la reportabilidad falsa e incompleta que oculte o morigere consecuencias ambientales, así
como delitos asociados a temas sectoriales fuera de la competencia de la Superintendencia de Medio
Ambiente. Al respecto, la Compañía se encuentra tomando los resguardos y adoptando los protocolos
pertinentes para abordar las nuevas exigencias a fin de dar cumplimiento a dicha normativa.
Riesgos relativos a Chile
DEPENDEMOS EN GRAN MEDIDA DE LAS CONDICIONES ECONÓMICAS, POLÍTICAS Y SOCIALES EN
CHILE, LO QUE PUEDE IMPACTAR NUESTROS RESULTADOS OPERACIONALES Y POSICIÓN
FINANCIERA.
Nuestra actividad comercial se desarrolla principalmente en Chile. Así un 68,6% de nuestros ingresos del año
2023 provienen del Segmento de operación Chile, un 22,9% proviene del Segmento de operación Negocios
Internacionales, que incluye Argentina, Bolivia, Paraguay y Uruguay, y un 9,9% proviene del Segmento de
operación Vinos, que incluye el mercado doméstico en Chile y Argentina y el mercado de exportaciones. De
ahí que los resultados operacionales y posición financiera son dependientes, en gran medida, del nivel general
de la actividad económica en Chile. La economía chilena ha experimentado un crecimiento del PIB anual
promedio de un 2,0% entre los años 2013 y 2023. En el pasado, un crecimiento económico desacelerado en
Chile ha significado una tasa de crecimiento de consumo de nuestros productos o rentabilidades más bajas.
El desempeño económico de Chile se ha visto afectado por trastornos de los mercados financieros y
recesiones globales como fue el caso de los años 2009 y 2020.
Si bien la inflación chilena ha sido limitada en los últimos diez años, en línea con la tendencia internacional,
Chile experimentó un aumento de la presión inflacionaria en 2022, alcanzando una inflación de 12,8%, en
comparación con un promedio anual de 4,5% entre 2013 y 2023. En 2023 la inflación retornó a cifras más
bajas, al cerrar en un 3,9%. Los altos niveles de inflación y devaluación de la moneda en Chile podrían afectar
adversamente la economía chilena y tener un efecto adverso en nuestros resultados. Si bien las últimas
estimaciones del Banco Central proyectan una desaceleración de la inflación en 2024, no podemos asegurar
que la inflación en Chile se mantenga en los niveles actuales.
Las medidas tomadas en el pasado y, durante el 2022, por el Banco Central de Chile para controlar la inflación
han incluido una política monetaria más estricta con altas tasas de interés, lo que restringe la disponibilidad
de crédito y el crecimiento económico. Políticas monetarias más restrictivas también contribuyen a reducir la
tasa de crecimiento de la economía chilena, como ocurrió en 2022. También es probable que una mayor
inflación aumente algunos de nuestros costos y gastos, dado que nuestros contratos de suministro pueden
estar denominados en moneda extranjera o indexados al índice de precios al consumidor de Chile. Esto podría
afectar adversamente nuestros márgenes operacionales y resultados financieros.
En su calidad de economía de mercado emergente y abierta, Chile está más expuesto a las condiciones
desfavorables de los mercados internacionales, las que podrían tener un impacto negativo sobre la demanda
de nuestros productos y de terceros con los que efectuamos negocios.
Cualquier combinación entre una baja confianza de parte de los consumidores, mercados de capitales
desestabilizados a nivel mundial y/o condiciones económicas internacionales menos favorables podrían
 14

[pág. 15]
ANÁLISIS RAZONADO
afectar en forma negativa la economía chilena y, como consecuencia, nuestros negocios. Por otro lado, una
crisis global de liquidez o un aumento en las tasas de interés podría limitar nuestra capacidad para obtener la
liquidez necesaria para cumplir con nuestros compromisos y/o aumentar nuestros gastos financieros.
Para mitigar los impactos financieros de lo mencionado anteriormente, la Compañía ha mantenido adecuados
niveles de liquidez, tomando medidas para asegurar la cadena de abastecimiento y, al mismo tiempo, ha
implementado planes de eficiencias, mejoras en gestión de ingresos, costos y gastos. Por otro lado, ha
diversificado sus operaciones geográficamente y mantiene una sólida salud financiera que se refleja en su
clasificación de riesgo local e internacional.
CUALQUIER REBAJA DE LA CALIFICACIÓN SOBERANA DE LA DEUDA DE CHILE POR PARTE DE LAS
AGENCIAS INTERNACIONALES DE CALIFICACIÓN CREDITICIA PUEDE AUMENTAR NUESTROS
COSTOS FINANCIEROS O LIMITAR NUESTRO ACCESO A LOS MERCADOS DE CAPITALES.
Cualquier revisión futura adversa de las calificaciones crediticias de la deuda soberana de Chile por parte de
las agencias de calificación crediticia internacionales puede afectar negativamente nuestras calificaciones de
riesgo, nuestro negocio, los resultados financieros futuros y el patrimonio de los accionistas. Además, las
calificaciones crediticias afectan el costo y otras condiciones en las que podemos obtener financiamiento. Las
agencias de calificación nos evalúan periódicamente y las calificaciones de nuestra deuda se basan en una
serie de factores, como nuestra solidez financiera y las condiciones que afectan al sector de los servicios
financieros en general. No se puede asegurar que las agencias de calificación mantengan las calificaciones
o perspectivas actuales, y cualquier rebaja en la calificación crediticia de nuestra deuda probablemente
limitaría nuestro acceso a los mercados de capitales y afectaría negativamente a nuestros resultados y
situación financiera.
LAS FLUCTUACIONES DE TIPO DE CAMBIO PUEDEN AFECTAR NEGATIVAMENTE NUESTRA
RENTABILIDAD
Dado que la mayoría de nuestras materias primas están indexadas al USD y exportamos vino en diferentes
monedas (USD, Dólares canadienses, Euros y Libras), estamos expuestos a los riesgos por tipo de cambio
que podrían afectar en forma negativa nuestra posición financiera y resultados operacionales. El efecto de
dicha variación en el tipo de cambio sobre los ingresos por exportaciones compensa parcialmente el efecto
del costo de materias primas en términos de pesos chilenos.
Riesgos relativos a Argentina
DEPENDEMOS DE LAS CONDICIONES ECONÓMICAS, POLÍTICAS Y SOCIALES EN ARGENTINA, LO
QUE PUEDE IMPACTAR DE MANERA NEGATIVA NUESTROS RESULTADOS OPERACIONALES Y
POSICIÓN FINANCIERA.
Mantenemos importantes activos en Argentina, los que constituyen una fuente relevante de nuestros ingresos
de operación.
Las condiciones macroeconómicas del país, la posición financiera y los resultados de nuestras operaciones
en Argentina dependen, en gran medida, de las condiciones económicas, políticas y sociales imperantes en
ese país, ya que la demanda de productos bebestibles por lo general depende de las condiciones económicas
que prevalecen en el mercado local. Argentina ha sufrido recesiones, altos niveles de inflación, devaluaciones
de su moneda, altas tasas de interés e importantes desaceleraciones de su economía en diversos periodos
de su historia. A continuación, un resumen de la evolución de los principales indicadores de Argentina:
Durante 2016 el PIB en Argentina experimentó una contracción de 2,1% y un nivel de inflación cercana al
40%. El 2017 mostró un crecimiento del PIB de 2,8% y un nivel de inflación en torno a 25%, mostrando una
leve recuperación de la economía. En 2018 nuevamente el PIB de Argentina entró en un ciclo recesivo,
experimentando una contracción de 2,6% y un nivel de inflación de 47,6%. En consecuencia, dado que la tasa
de inflación acumulada superó el 100% entre el 2016 y el 2018 (3 años), y conforme a lo que prescribe la IAS
29, Argentina fue declarada como una economía hiperinflacionaria a contar del 1 de julio de 2018. En el 2020,
el PIB se contrajo un 9,9%, mientras que la inflación acumulada se ubicó en un 36,1%. En 2021, el PIB se
expandió un 10,7% y la inflación se ubicó en 50,9% mientras que en 2022 el PIB creció un 5,0% y la inflación
alcanzó un 94,8%. En 2023, el PIB se contrajo un 1,6% y la inflación alcanzó un 211%. En consecuencia,
 15

[pág. 16]
ANÁLISIS RAZONADO
dado que la inflación entre 2020 y 2022 superó el 100%, Argentina sigue siendo considerada una economía
hiperinflacionaria (ver Nota 2 de los Estados Financieros Consolidados al 31 de diciembre de 2024).
Si las condiciones económicas en Argentina se deterioran aún más, o si la inflación continúa acelerándose, o
si la capacidad del gobierno argentino para acceder a los mercados financieros a largo plazo para financiar el
aumento del gasto es limitada dados los altos niveles de endeudamiento del sector público, el crecimiento
económico de Argentina y la salud financiera y los resultados de nuestras operaciones en Argentina podrían
verse afectados negativamente.
La devaluación del ARS afecta en forma negativa nuestros resultados. Los Estados Financieros para nuestras
filiales argentinas usan el ARS como moneda funcional, y se convierten a CLP para propósitos de
consolidación, teniendo un impacto en el resultado y patrimonio por efecto de conversión. Además, el costo
de la mayoría de nuestras materias primas en Argentina está indexado al precio del USD. En 2023, el ARS
versus USD tuvo una devaluación promedio de aproximadamente 122,1% y una devaluación (al cierre del
período) de 356,2%. Todo lo anterior, generó un efecto de conversión en los ingresos, costos y gastos
reportados, además de presión en los costos indexados al USD.
Dado que no se puede predecir cómo serán las condiciones económicas en Argentina a futuro, ni cuándo
Argentina dejará de considerarse como una economía hiperinflacionaria para efectos contables, tampoco
podemos predecir cómo los negocios de CCU se verán afectados por el futuro contexto económico en
Argentina. Para mitigar los efectos de los actuales desafíos macroeconómicos, CCU Argentina ha
implementado planes de eficiencias, mejoras en gestión de ingresos, costos y gastos.
EL RÉGIMEN LEGAL Y LA ECONOMÍA DE ARGENTINA SON SUSCEPTIBLES A CAMBIOS QUE PODRÍAN
AFECTAR EN FORMA NEGATIVA NUESTRAS OPERACIONES EN DICHO PAÍS.
El 1 de septiembre de 2019, el Banco Central Argentino emitió la Circular “A” 6.770, la cual estableció varios
controles de intercambio para exportaciones e importaciones de bienes y servicios, tenencia de activos
extranjeros, operaciones para no residentes, deuda financiera externa, deudas entre residentes argentinos,
repatriación de utilidades y pago de dividendos, entre otros. La Circular se emitió en respuesta a la publicación
del Decreto 609/2019, por el cual el gobierno argentino implementó regulaciones cambiarias originalmente
hasta el 31 de diciembre de 2019, pero fue posteriormente prorrogado por tiempo indefinido. El Decreto
609/2019 establece la obligación de convertir el valor de las mercancías y servicios exportados a pesos
argentinos en el sistema financiero local, de acuerdo con los términos y condiciones establecidos por el Banco
Central Argentino. Todas estas medidas han impactado negativamente la libre importación de bienes y en la
práctica restringe nuestra capacidad de repatriar ganancias.
Desde 2020 y hasta fines de 2023, en un intento de frenar la creciente inflación, el gobierno argentino aplicó
varios métodos para regular directa e indirectamente los aumentos de precios de varios bienes de consumo,
incluida la cerveza envasada. Durante 2023 fuimos parte de acuerdos con el gobierno argentino que nos
obligaban a vender nuestros productos a un precio previamente acordado. Estos acuerdos y los distintos
mecanismos destinados al control y fijación de precios fueron dejados sin efecto por el nuevo gobierno que
asumió a fines del año 2023.
Al cierre de este reporte, existen varias restricciones a la transferencia de divisas y a la repatriación de
capitales que podrían afectar a la capacidad de nuestras filiales para realizar pagos y, a su vez, podrían
afectar negativamente a nuestra actividad y a nuestros resultados.
Adicionalmente, el nuevo gobierno ha dictado el Decreto de Necesidad y Urgencia 70/2023, el cual introduce
modificaciones relevantes al régimen legal en el que opera CCU Argentina y sus sociedades subsidiarias,
entre ellas, pueden destacarse: (i) la derogación total de la Ley de Abastecimiento N° 20.680; (ii) la derogación
total de la Ley de Góndolas N° 27.454; (iii) la derogación total de la Ley de Observatorio de Precios y
Disponibilidad de Bienes, Insumos y Servicios N° 26.992; (iv) modificaciones al Código Civil y Comercial de
la Nación relativas a la ampliación de la autonomía de la voluntad en la contratación; y (v) modificaciones al
régimen laboral. Al cierre de este documento, el Decreto de Necesidad y Urgencia 70/2023 se encuentra
vigente, pero pendiente de ratificación por parte del Congreso de la Nación, lo que sucederá en caso de que
al menos una de sus cámaras lo ratifique.
 16

[pág. 17]
ANÁLISIS RAZONADO
Administración de riesgos
Para las empresas donde existe una participación controladora, la Gerencia Corporativa de Administración y
Finanzas de la Compañía provee un servicio centralizado a las empresas del grupo para la obtención de
financiamiento y la administración de los riesgos de tipo de cambio, tasa de interés, liquidez, riesgo de
inflación, riesgos de materias primas y riesgo de crédito. Esta función opera de acuerdo con un marco de
políticas y procedimientos que es revisado regularmente para cumplir con el objetivo de administrar el riesgo
proveniente de las necesidades del negocio.
Para aquellas empresas en que existe una participación no controladora (VSPT, CPCh, Aguas CCU-Nestlé
S.A., Cervecería Kunstmann S.A., Bebidas Bolivianas BBO S.A., Bebidas del Paraguay S.A., Distribuidora del
Paraguay S.A. y AV S.A.) esta responsabilidad recae en sus respectivos Directorios y respectivas Gerencias
de Administración y Finanzas. El Directorio y Comité de Directores, cuando procede, es el responsable final
del establecimiento y revisión de la estructura de administración del riesgo, como también de revisar los
cambios significativos realizados a las políticas de administración de riesgos y recibe información relacionada
con dichas actividades.
De acuerdo a las políticas de administración de riesgos, la Compañía utiliza instrumentos derivados solo con
el propósito de cubrir exposiciones a los riesgos de tasas de interés y tipos de cambios provenientes de las
operaciones de la Compañía y sus fuentes de financiamiento, de los cuales, algunos son tratados
contablemente como coberturas. Las transacciones con instrumentos derivados son realizadas
exclusivamente por personal de la Gerencia de Administración y Finanzas y la Gerencia de Auditoría Interna
revisa regularmente el ambiente de control de esta función. La relación con los clasificadores de riesgo y el
monitoreo de restricciones financieras (covenants) son administrados por la Gerencia de Administración y
Finanzas.
La exposición de riesgos financieros de la Compañía está relacionada principalmente con las variaciones de
tipos de cambio, tasas de interés, inflación, precios de materias primas (commodities), impuestos, cuentas
por cobrar a clientes y liquidez. Con la finalidad de administrar el riesgo proveniente de algunas de estas
exposiciones se utilizan diversos instrumentos financieros.
Para cada uno de los puntos siguientes, y donde aplica, los análisis de sensibilidad desarrollados son
solamente para efectos ilustrativos, ya que en la práctica las variables sensibilizadas rara vez cambian sin
afectarse unas a otras y sin afectar otros factores que fueron considerados como constantes y que también
afectan la posición financiera y de resultados de la Compañía.
Riesgo de tipo de cambio
La Compañía se encuentra expuesta a riesgos de tipo de cambio provenientes de: a) su exposición neta de
activos y pasivos en monedas extranjeras, b) los ingresos por ventas de exportación, c) las compras de
materias primas, insumos e inversiones de capital efectuadas en monedas extranjeras o indexadas a dichas
monedas, y d) la inversión neta de subsidiarias mantenidas en el exterior. La mayor exposición a riesgos de
tipo de cambio de la Compañía es la variación del peso chileno respecto del dólar estadounidense, el euro, el
peso argentino, el peso uruguayo, guaraní paraguayo, boliviano y peso colombiano.
Al 31 de diciembre de 2024, la Compañía mantiene pasivos en monedas extranjeras por el equivalente a
M$ 725.459.706 (M$ 673.839.310 al 31 de diciembre de 2023) que en su mayoría están denominadas en
dólares estadounidenses. Las obligaciones con instituciones financieras y obligaciones con el público en
monedas extranjeras por M$ 600.172.708 al 31 de diciembre de 2024 (M$ 544.341.120 al 31 de diciembre de
2023) representan un 44% (42% al 31 de diciembre de 2023) del total de las obligaciones financieras. El 56%
(58% al 31 de diciembre de 2023) restante está denominado principalmente en Unidades de Fomento y pesos
chilenos. Adicionalmente, la Compañía mantiene activos en monedas extranjeras por M$ 621.497.508
(M$ 564.888.883 al 31 de diciembre de 2023) que corresponden principalmente a efectivo y equivalentes al
efectivo y cuentas por cobrar por exportaciones.
 17

[pág. 18]
ANÁLISIS RAZONADO
Para proteger el valor de la posición neta de los activos y pasivos en monedas extranjeras de sus operaciones
en Chile y Argentina, la Compañía adquiere contratos de derivados (forwards de monedas) para mitigar
cualquier variación en el peso chileno y en el peso argentino respecto de otras monedas.
Respecto de las operaciones de las subsidiarias en el extranjero, la exposición neta pasiva en dólares
estadounidenses y otras monedas extranjeras, después del uso de instrumentos derivados, equivale a
M$ 74.315.533 (M$ 42.453.444 al 31 de diciembre de 2023).
Al 31 de diciembre de 2024 la exposición neta en Chile en monedas extranjeras, después del uso de
instrumentos derivados, es pasiva por M$ 4.356.360 (M$ 7.510.628 al 31 de diciembre de 2023).
Del total de ingresos por ventas al 31 de diciembre de 2024 de la Compañía, un 5% (5% en 2023 y 6% en
2022) corresponde a ventas de exportación efectuadas en monedas extranjeras, principalmente dólares
estadounidenses, euro, libra esterlina y otras monedas y del total de costos directos aproximadamente un
65% (62% en 2023 y 63% en 2022) corresponde a compras de materias primas e insumos en monedas
extranjeras o que se encuentran indexados a dichas monedas. La Compañía no cubre las eventuales
variaciones en los flujos de caja esperados por estas transacciones.
Por otra parte, la Compañía se encuentra expuesta a los movimientos en los tipos de cambio relacionados
con la conversión desde pesos argentinos, pesos uruguayos, guaraníes paraguayos, bolivianos, dólar
estadounidense, libra esterlina, yuan, soles y pesos colombianos a pesos chilenos de los resultados, activos
y pasivos de sus subsidiarias en Argentina, Uruguay, Paraguay, Bolivia, Estados Unidos, Reino Unido y China,
negocio conjunto y asociadas en Argentina y Perú y negocio conjunto en Colombia. La Compañía no cubre
los riesgos relacionados con la conversión de las subsidiarias, asociada y negocio conjunto cuyos efectos son
registrados en Patrimonio.
Análisis de sensibilidad al tipo de cambio
El efecto por Ganancias (pérdidas) de cambio en moneda extranjera reconocido en el Estado Consolidado de
Resultados por Función para el ejercicio terminado al 31 de diciembre de 2024, relacionado con los activos y
pasivos denominados en monedas extranjeras asciende a una pérdida de M$ 17.797.269 (M$ 65.944.570 en
2023 y M$ 20.173.381 en 2022).
Considerando la exposición en Chile al 31 de diciembre de 2024, después del uso de instrumentos derivados
es pasiva por M$ 4.356.360 (M$ 7.510.628 al 31 de diciembre de 2023), y asumiendo un aumento/disminución
de un 10% en los tipos de cambio y manteniendo todas las otras variables constantes, tales como tasas de
interés, se estima que el efecto sobre los resultados de la Compañía sería una pérdida/utilidad después de
impuesto de M$ 318.014 (M$ 545.052 en 2023 y M$ 43.941 en 2022) asociado a los propietarios de la
controladora.
Considerando que aproximadamente el 5% de los ingresos por ventas de la Compañía corresponden a ventas
de exportación efectuadas desde Chile (5% en 2023 y 6% en 2022) y que aproximadamente un 65% (62% en
2023 y 63% en 2022) del total de costos directos de la Compañía están en dólares estadounidenses o
indexados a dicha moneda y asumiendo que las monedas funcionales se aprecien/deprecien un 10% respecto
al dólar estadounidense, manteniendo todas las demás variables constantes, el efecto hipotético sobre los
resultados de la Compañía sería aproximadamente una pérdida/utilidad después de impuesto por este efecto
de M$ 48.376.600 (M$ 41.161.484. en 2023 y M$ 43.950.998 en 2022).
La Compañía, también está sujeta al tipo de cambio de los países donde operan las subsidiarias en el
extranjero, ya que el resultado se convierte a pesos chilenos al tipo de cambio promedio de cada mes, excepto
Argentina que utiliza el tipo de cambio de cierre de la fecha de reporte. El resultado de las operaciones de las
subsidiarias en el extranjero acumuladas al 31 de diciembre de 2024 fue una utilidad de M$ 31.554.223,
utilidad de M$ 60.164.242 en 2023 y pérdida de M$ 63.345.544 en 2022). Por lo tanto, una
depreciación/apreciación del tipo de cambio del peso argentino, uruguayo, guaraní paraguayo y boliviano
respecto del peso chileno de un 10%, generaría hipotéticamente una pérdida/utilidad antes de impuesto
 18

[pág. 19]
ANÁLISIS RAZONADO
M$ 3.155.422 (M$ 6.016.424 en 2023 y M$ 6.334.554 en 2022).
La inversión neta mantenida en subsidiarias, negocios conjuntos y asociadas que desarrollan sus actividades
en el extranjero al 31 de diciembre de 2024 asciende a M$ 549.120.456, M$ 123.023.739 y M$ 1.813.525,
respectivamente (M$ 288.873.649, M$ 135.198.194 y M$ 1.743.986 al 31 de diciembre de 2023). Asumiendo
un aumento o disminución de un 10% en el tipo de cambio del peso argentino, peso uruguayo, guaraní
paraguayo, boliviano o peso colombiano respecto del peso chileno y manteniendo todas las otras variables
constantes, el aumento/disminución mencionado anteriormente resultaría hipotéticamente en una
utilidad/pérdida de M$ 67.395.772 (M$ 42.581.583 en 2023 y M$ 54.791.581 en 2022) que se registraría con
abono/cargo a patrimonio.
La Compañía no cubre los riesgos relacionados con la conversión de moneda de los Estados Financieros de
las subsidiarias que tienen otra moneda funcional, cuyos efectos son registrados en Patrimonio.
Riesgo de tasas de interés
El riesgo de tasas de interés proviene principalmente de las fuentes de financiamiento de la Compañía.
Para administrar el riesgo de tasas de interés, la Compañía posee una política de administración de tasas de
interés que busca reducir la volatilidad de su gasto financiero y mantener un porcentaje ideal de su deuda en
instrumentos con tasas fijas. Las obligaciones en instituciones financieras y con el público se encuentran
mayormente fijas por el uso de instrumentos derivados tales como cross currency swaps.
Al 31 de diciembre de 2024 y 31 de diciembre de 2023, luego de considerar el efecto de swaps de tasas de
interés y de monedas, el 100% de las deudas de la Compañía poseen tasas de interés fija.
Los términos y condiciones de las obligaciones con instituciones financieras de la Compañía al 31 de
diciembre de 2024, incluyendo los tipos de cambio, tasa de interés, vencimientos y tasas de interés efectivas,
se encuentran detallados en Nota 21 - Otros pasivos financieros.
Análisis de sensibilidad a las tasas de interés
El Costo financiero total reconocido en el Estado Consolidado de Resultados por Función para el ejercicio
terminado al 31 de diciembre de 2024, relacionado principalmente a deudas de corto y largo plazo, asciende
a M$ 97.165.278 (M$ 77.023.048 en 2023 y M$ 75.930.875 en 2022).
Riesgo de inflación
La Compañía mantiene una serie de contratos con terceros indexados a UF como así mismo la deuda
financiera indexada a UF, lo que significa que quede expuesta a las fluctuaciones de la UF, generándose
incrementos en el valor de dichos contratos y pasivos en caso de que ésta experimente un crecimiento en su
valor producto de la inflación. Este riesgo se ve mitigado en parte debido a que la Compañía tiene como
política a) ajustar sus precios de acuerdo a la inflación, dentro de las condiciones que permite el mercado,
manteniendo de esta manera sus ingresos unitarios en UF relativamente constantes y b) mantener contratos
cross currency swap para cubrir deuda financiera neta en UF si las condiciones del mercado son favorables
para la Compañía.
La inflación en Argentina ha mostrado incrementos importantes desde inicios de 2018. La tasa de inflación
acumulada de tres años, calculada usando diferentes combinaciones de índices de precios de consumo, ha
superado el 100% durante varios meses, y sigue incrementándose. La inflación acumulada de tres años
calculada usando el índice general de precios ya ha sobrepasado el 100%. Por lo tanto, conforme lo prescribe
la IAS 29, se declaró a Argentina como una economía hiperinflacionaria a partir del 1 de julio de 2018 (ver
Nota 2 - Resumen de las principales políticas contables (2.4)).
 19

[pág. 20]
ANÁLISIS RAZONADO
Análisis de sensibilidad a la inflación
El resultado por unidades de reajuste total reconocido en el Estado Consolidado de Resultados por Función
para el ejercicio terminado al 31 de diciembre de 2024, relacionado a ciertos activos, deudas de corto y largo
plazo indexados a la Unidad de Fomento y por la aplicación de la contabilidad hiperinflacionaria en Argentina,
corresponde a una pérdida pérdida de M$ 10.722.033 (pérdida de M$ 14.025.895 en 2023 y utilidad de
M$ 1.198.565 en 2022). Asumiendo un aumento/disminución razonablemente posible de la Unidad de
Fomento en aproximadamente 3% en Chile y una inflación de un 30% en Argentina, y manteniendo todas las
otras variables constantes, tales como tasas de interés, el aumento/disminución mencionado anteriormente
resultaría hipotéticamente en una pérdida/utilidad antes de impuesto de M$ 8.948.677 (M$ 11.592.842 al 31
de diciembre de 2023 y M$ 4.681.098 en 2022) en el Estado Consolidado de Resultados por Función.
Riesgo de precio de materias primas
La principal exposición a la variación de precios de materias primas se encuentra relacionada con el
abastecimiento de cebada, malta y latas utilizados en la producción de cervezas, concentrados, azúcar y
envases plásticos utilizados en la producción de bebidas gaseosas y vinos a granel y uvas para la fabricación
de vinos y licores.
Malta y latas
La Compañía en Chile se abastece de malta proveniente de productores locales y del mercado internacional
(principalmente Argentina). Con los productores locales y argentinos se suscriben compromisos de
abastecimiento a largo plazo, en los cuales el precio de la malta se fija anualmente en función del precio de
mercado de la cebada y de los costos de fabricación establecidos en los contratos.
Las compras y los compromisos tomados exponen a la Compañía al riesgo de fluctuación de precios de estas
materias primas. Por su parte CCU Argentina adquiere toda la demanda de malta de productores locales.
Esta materia prima representa aproximadamente el 8% (8% en 2023 y 6% en 2022) del costo directo del
Segmento de operación Chile.
Al 31 de diciembre de 2024 el costo de las latas representa aproximadamente un 22% del costo directo en el
Segmento de operación Chile (21% en 31 de diciembre de 2023 y 24% en 2022). En el Segmento de operación
Negocios Internacionales, el costo de las latas representa aproximadamente un 35% del costo directo de
materias primas al 31 de diciembre de 2024 (32% en 2023 y 37% en 2022).
Concentrados, azúcar y envases plásticos
Las principales materias primas utilizadas en la producción de bebidas no alcohólicas son los concentrados,
que se adquieren principalmente de los licenciatarios, el azúcar y las resinas plásticas en la fabricación de
envases plásticos y contenedores. La Compañía se encuentra expuesta a riesgo de fluctuación en los precios
de estas materias primas que representan en su conjunto aproximadamente un 28% (28% en 2023 y 26% en
2022) del costo directo del Segmento de operación Chile.
La Compañía no realiza actividades de cobertura sobre estas compras de materias primas.
Uvas y vinos
Las principales materias primas utilizadas por la subsidiaria Viña San Pedro Tarapacá S.A. para la producción
de vinos, son uvas cosechadas de producción propia y uvas y vinos adquiridos de terceros en forma de
contratos de largo plazo y spot. Aproximadamente el 34% (34% al 31 de diciembre de 2023 y 27% en 2022)
del total del abastecimiento de VSPT durante los últimos 12 meses, se realizó desde sus propios viñedos, de
las cuales un 57% (57% al 31 de diciembre de 2023 y 45% en 2022) corresponden a uva para el mercado de
exportación.
 20

[pág. 21]
ANÁLISIS RAZONADO
El 66% (66% al 31 de diciembre de 2023 y 73% en 2022) del abastecimiento restante es comprado a
productores en modalidad de contratos de largo plazo y spot. Durante los últimos 12 meses, VSPT compró el
56% (48% al 31 de diciembre de 2023 y 58% en 2022) de la uva y vino necesario de terceros a través de
contratos spot. Adicionalmente, las transacciones de largo plazo representaron un 10% (17% al 31 de
diciembre de 2023 y 15% en 2022) sobre el total del abastecimiento.
Debemos considerar que el vino al 31 de diciembre de 2024 representa el 53% (56% al 31 de diciembre de
2023 y 59% en 2022) del costo directo total, es decir, el abastecimiento comprado a productores a través de
contrato spot representa el 30% del costo directo (27% al 31 de diciembre de 2023 y 34% en 2022).
Análisis de sensibilidad de precios de materias primas
El total del costo directo en el Estado Consolidado de Resultados por Función para el ejercicio terminado al
31 de diciembre de 2024 asciende a M$ 1.232.870.856 (M$ 1.090.286.882 en 2023 y M$ 1.188.930.623 en
2022). Asumiendo un aumento (disminución) razonablemente posible en el costo directo de cada segmento
de un 8% y manteniendo todas las otras variables constantes, tales como los tipos de cambio, el
aumento/disminución resultaría hipotéticamente en una pérdida/utilidad antes de impuestos de
aproximadamente M$ 65.932.456 (M$ 61.638.324 en 2023 y M$ 62.291.401 en 2022) para el Segmento de
operación Chile, M$ 25.188.226 (M$ 17.294.358 en 2023 y M$23.328.732 en 2022) para el Segmento de
operación Negocios Internacionales y M$ 10.532.781 (M$ 9.926.816 en 2023 y M$ 11.714.298 en 2022) para
el Segmento de operación Vinos.
Riesgo de Crédito
El riesgo de crédito al cual está expuesta la Compañía proviene principalmente de a) las cuentas por cobrar
comerciales mantenidas con clientes minoristas, distribuidores mayoristas y cadenas de supermercados de
mercados domésticos; b) cuentas por cobrar por exportaciones; y c) las inversiones financieras mantenidas
con bancos e instituciones financieras, tales como depósitos a la vista, fondos mutuos, instrumentos
adquiridos con compromiso de retroventa e instrumentos financieros derivados.
Mercado Doméstico
El riesgo de crédito relacionado a cuentas por cobrar comerciales de mercados domésticos es administrado
por la Gerencia de Administración de Crédito y Cobranza y es monitoreado por el Comité de Crédito de cada
unidad de negocio.
El mercado doméstico se refiere principalmente a saldos por cobrar de operaciones realizadas en Chile y
representan un 58% del total de las cuentas por cobrar comerciales (65% al 31 de diciembre de 2023). La
Compañía posee una amplia base de clientes que están sujetos a las políticas, procedimientos y controles
establecidos por la Compañía. Los límites de crédito son establecidos para todos los clientes con base en una
calificación interna y su comportamiento de pago. Las cuentas por cobrar comerciales pendientes de pago
son monitoreadas regularmente. Adicionalmente, la Compañía toma seguros de crédito que cubren el 90%
de los saldos de las cuentas por cobrar individualmente significativas, cobertura que al 31 de diciembre de
2024 alcanza a 83% (83% al 31 de diciembre de 2023) del total de las cuentas por cobrar.
Las cuentas por cobrar comerciales que se encuentran vencidas, corresponden a clientes que presentan
moras en promedio de menos de 24 días (24 días al 31 de diciembre de 2023).
Al 31 de diciembre de 2024, la Compañía tenía aproximadamente 1.800 clientes (1.650 clientes al 31 de
diciembre de 2023) que adeudan más que $ 10 millones cada uno y que en su conjunto representan
aproximadamente el 89% (89% al 31 de diciembre de 2023) del total de cuentas por cobrar comerciales. Hubo
373 clientes (305 clientes al 31 de diciembre de 2023) con saldos superiores a $ 50 millones que representa
aproximadamente un 78% (78% al 31 de diciembre de 2023) del total de cuentas por cobrar. El 88% (88% al
 21

[pág. 22]
ANÁLISIS RAZONADO
31 de diciembre de 2023) de estas cuentas por cobrar se encuentran cubiertas por el seguro de crédito antes
mencionado.
La Compañía comercializa sus productos a través de clientes minoristas, mayoristas y cadenas de
supermercados, siendo la calidad crediticia de estos de un 99% (99% al 31 de diciembre de 2023).
Al 31 de diciembre de 2024 la Compañía no ha recibido garantías significativas por parte de sus clientes.
La Compañía estima que no son necesarias provisiones de riesgo de crédito adicionales a las provisiones
individuales y colectivas para pérdidas por deterioro determinadas al 31 de diciembre de 2024, que ascienden
M$ 7.785.695 (M$ 7.751.305 al 31 de diciembre de 2023), ya que, como se menciona anteriormente un gran
porcentaje de las cuentas por cobrar se encuentran cubiertas por seguros (Nota 10 - Deudores Comerciales
y otras cuentas por cobrar).
Mercado Exportación
El riesgo de crédito relacionado a cuentas por cobrar comerciales de exportación es administrado por la
Jefatura de Crédito y Cobranza y es monitoreado por la Gerencia de Administración y Finanzas. Los saldos
por cobrar del mercado exportación de VSPT representan un 11% del total de las cuentas por cobrar
comerciales (10% al 31 de diciembre de 2023). VSPT posee una amplia base de clientes, en más de ochenta
países, que están sujetos a las políticas, procedimientos y controles establecidos por VSPT. Adicionalmente,
VSPT toma seguros de créditos que cubren el 90% de las cuentas por cobrar individualmente significativas,
cobertura que al 31 de diciembre de 2024 alcanza al 84% (90% al 31 de diciembre de 2023) del total de las
cuentas por cobrar. Las cuentas por cobrar comerciales pendientes de pago son monitoreadas regularmente.
Aparte de los seguros de crédito, al estar diversificado en diversos países aminora el riesgo de crédito.
Al 31 de diciembre de 2024 hay 85 clientes (73 clientes al 31 de diciembre de 2023) que adeudan más de
M$ 65.000 cada uno y que representan el 95% (93% al 31 de diciembre de 2023) del total de las cuentas por
cobrar de VSPT.
Las cuentas por cobrar comerciales de exportación de VSPT que se encuentran vencidas, corresponden a
clientes que presentan mora de menos de 43 días promedio (56 días promedio al 31 de diciembre de 2023).
La Compañía estima que no son necesarias provisiones de riesgo de crédito adicionales a las provisiones
individuales y colectivas determinadas al 31 de diciembre de 2024. Ver análisis de vencimientos de cuentas
por cobrar y provisión para pérdidas por deterioro de cuentas por cobrar (Nota 10 - Deudores Comerciales
y otras cuentas por cobrar).
Inversiones financieras e instrumentos financieros derivados
Las inversiones financieras corresponden a depósitos a plazo, instrumentos financieros adquiridos con
compromiso de retroventa son pactadas a una tasa de interés fija, con vencimientos inferiores a 3 meses y
en instituciones financieras en Chile, por lo que no se encuentran expuestas a riesgos significativos de
mercado. Respecto de los instrumentos financieros derivados, estos se valorizan a su valor razonable y son
contratados solo en el mercado en Chile. A partir del año 2018 se aplican los cambios, exigidos en la enmienda
de IFRS 9, en la valorización de los instrumentos financieros derivados considerando el riesgo de contraparte
(CVA y DVA, por sus siglas en inglés). El efecto de CVA/DVA es calculado a partir de la probabilidad de
default de CCU o de la contraparte, según corresponda, considerando una tasa de recuperación de un 40%
para cada instrumento derivado. Dicha probabilidad se obtiene a partir del spread de bonos corporativos con
igual calificación para el caso de CCU, mientras que, para la contraparte, se considera la suma entre el Credit
Default Swap (CDS) de Chile y el CDS del banco Citibank en Estados Unidos. Al 31 de diciembre de 2024 el
efecto no es significativo.
 22

[pág. 23]
ANÁLISIS RAZONADO
Riesgo de impuestos
Nuestros negocios están afectos a distintos impuestos en los países donde operamos, incluyendo entre otros,
impuestos a la renta e impuestos específicos sobre bebidas alcohólicas y no alcohólicas. Un aumento en las
tasas de dichos impuestos, o de cualquier otro, o cambios en las regulaciones de los mismos, podrían afectar
en forma negativa nuestras ventas y rentabilidad.
Riesgo de liquidez
La Compañía administra el riesgo de liquidez a nivel consolidado, siendo la principal fuente de liquidez los
flujos de efectivo provenientes de sus actividades operacionales. Adicionalmente, la Compañía tiene la
capacidad de emitir instrumentos de deuda y patrimonio en el mercado de capitales de acuerdo a sus
necesidades.
Para administrar la liquidez de corto plazo, la Compañía se basa en los flujos de caja proyectados para un
período móvil de doce meses y mantiene efectivo y equivalentes al efectivo disponible para cumplir sus
obligaciones.
Basado en el actual desempeño operacional y su posición de liquidez, la Compañía estima que los flujos de
efectivo provenientes de las actividades operacionales y el efectivo disponible serán suficientes para financiar
el capital de trabajo, las inversiones de capital, los pagos de intereses, los pagos de dividendos y los
requerimientos de pago de deudas, por los próximos 12 meses y el futuro previsible.
A continuación se resumen los vencimientos de los Otros pasivos financieros de la Compañía, basados en
los flujos contractuales no descontados:
 Vencimiento de flujos contratados
 Valor libro (*) Más de 90 Más de 1 Más de 3
 Al 31 de diciembre de 2024 Más de 5
 Hasta 90 días días hasta 1 año hasta 3 años hasta Total
 años
 año años 5 años
 M$ M$ M$ M$ M$ M$ M$
 Otros pasivos financieros no derivados
 Préstamos bancarios 207.904.935 27.660.050 22.865.553 80.529.312 104.271.082 4.918.795 240.244.792
 Obligaciones con el público 1.157.437.074 15.010.590 103.735.572 106.227.041 62.491.195 1.177.559.067 1.465.023.465
 Obligaciones por arrendamientos 49.233.868 3.217.880 7.862.529 13.956.205 8.530.907 26.162.114 59.729.635
 Depósitos recibidos en garantía de envases y
 11.772.459 - 11.772.459 - - - 11.772.459
 contenedores
 Subtotal 1.426.348.336 45.888.520 146.236.113 200.712.558 175.293.184 1.208.639.976 1.776.770.351
 Pasivos financieros derivados
 Instrumentos financieros derivados 652.079 652.079 - - - - 652.079
 Pasivos de cobertura 12.667.177 1.359.777 2.833.330 5.526.492 5.541.056 - 15.260.655
 Subtotal 13.319.256 2.011.856 2.833.330 5.526.492 5.541.056 - 15.912.734
 Total 1.439.667.592 47.900.376 149.069.443 206.239.050 180.834.240 1.208.639.976 1.792.683.085
(*) Ver clasificación del valor libro en corriente y no corriente en Nota 7 - Instrumentos financieros.
 23

[pág. 24]
ANÁLISIS RAZONADO
 Vencimiento de flujos contratados
 Valor libro (*) Más de 90 Más de 1 Más de 3
 Más de 5
 Al 31 de diciembre de 2023 Hasta 90 días días hasta 1 año hasta 3 años hasta Total
 años
 año años 5 años
 M$ M$ M$ M$ M$ M$ M$
 Otros pasivos financieros no derivados
 Préstamos bancarios 198.569.040 18.446.613 15.884.136 39.244.074 168.351.944 6.773.214 248.699.981
 Obligaciones con el público 1.089.489.347 13.599.586 43.987.484 168.542.146 70.621.982 1.105.895.648 1.402.646.846
 Obligaciones por arrendamientos 41.204.099 2.417.780 6.258.386 12.657.830 6.149.772 26.518.546 54.002.314
 Depósitos recibidos en garantía de envases y
 11.774.922 - 11.774.922 - - - 11.774.922
 contenedores
 Pasivo por contrato de opción (1) 28.554.669 28.636.699 - - - - 28.636.699
 Subtotal 1.369.592.077 63.100.678 77.904.928 220.444.050 245.123.698 1.139.187.408 1.745.760.762
 Pasivos financieros derivados
 Instrumentos financieros derivados 468.541 468.541 - - - - 468.541
 Pasivos de cobertura 12.541.188 1.428.407 1.869.494 5.742.758 5.757.322 - 14.797.981
 Subtotal 13.009.729 1.896.948 1.869.494 5.742.758 5.757.322 - 15.266.522
 Total 1.382.601.806 64.997.626 79.774.422 226.186.808 250.881.020 1.139.187.408 1.761.027.284
(*) Ver clasificación del valor libro en corriente y no corriente en Nota 7 - Instrumentos financieros.
(1) Ver Nota 1 - Información general, letra C), numeral (4).
 24

[pág. 25]
ANÁLISIS RAZONADO
 ANÁLISIS RAZONADO
 31/12/2024 31/12/2023
 INDICADORES FINANCIEROS
 1.- LIQUIDEZ (ver B.1)
 Razón de liquidez 2,06 2,33
 Definida como:
 Total Activos Corrientes
 Total Pasivos Corrientes
 Razón ácida 1,49 1,67
 Definida como:
 Act. Corr. - Invent. - Pagos Anticip.
 Pasivo Corriente
 2.- ENDEUDAMIENTO (ver B.2)
 Razón de endeudamiento 1,52 1,71
 Definida como:
 Pas. Corr. + Pas. No Corr.
 Patrimonio atribuible a los propietarios
 de la controladora
 Proporción de la deuda corriente
 y no corriente en relación a deuda total:
 Pasivo corriente 37,1% 32,9%
 Pasivo no corriente 62,9% 67,1%
 Cobertura de Gastos Financieros 4,3 4,9
 Definida como:
 ROADA (EBITDA)**
 Gastos Financieros
 3.- ACTIVIDAD (ver B.3)
 Total de Activos (MM$) 3.989.717 3.423.946
 Rotación de Inventario 3,6 3,0
 Definida como:
 Costo de ventas del periodo
 Inventario Promedio
 Permanencia de Inventario 100,1 118,4
 Definida como:
 Inventario Promedio x N° de días período (*)
 Costo de Ventas del período
 (*) 90; 180; 270 0 360 según corresponda
 (**) Resultado Operacional Ajustado, se define como el Resultado Operacional Ajustado antes de Depreciación y Amortización.
 25

[pág. 26]
ANÁLISIS RAZONADO
 ANÁLISIS RAZONADO
 31/12/2024 31/12/2023
4.- RESULTADOS (ver B.4)
 Ventas Físicas (Millones de Hectólitros)
 Segmento de operación Chile 22,7 22,8
 Segmento de operación Negocios Internacionales 9,8 9,1
 Segmento de operación Vinos 1,4 1,3
 Volumen Total de Ventas (*) 33,8 33,1
 Resultados Financieros
 Ingresos por Ventas 2.904.566 2.565.556
 (Millones de $)
 Costos de ventas 1.590.958 1.378.612
 (Millones de $)
 Resultado operacional ajustado 262.702 253.283
 (Millones de $)
 R.A.I.I.D.A. 415.929 306.300
 (Resultado antes de Impuestos, Intereses,
 Depreciación y Amortización, en Millones
 de $)
 Gastos Financieros Netos 59.063 37.621
 (Millones de $)
 Utilidad atribuible a los propietarios de
 la controladora 160.944 105.653
 (Millones de $)
 (*) Incluye Eliminaciones entre segmentos de operación
 26

[pág. 27]
ANÁLISIS RAZONADO
 ANÁLISIS RAZONADO
 31/12/2024 31/12/2023
5.- RENTABILIDAD (ver B.5)
 Rentabilidad del patrimonio 11,7% 8,3%
 Definida como:
 Utilidad atribuible a los propietarios de
 la controladora
 Patrimonio atribuible a los propietarios
 de la controladora promedio
 Rentabilidad del Activo 4,3% 3,0%
 Definida como:
 Utilidad atribuible a los propietarios de
 la controladora
 Total activo promedio
 Rendimiento Activos Operacionales 8,2% 9,2%
 Definida como:
 Resultado operacional ajustado
 Total activos operacionales
 Utilidad por acción ($) 435,6 285,9
 Definida como:
 Utilidad atribuible a los propietarios de
 la controladora
 Total acciones suscritas y pagadas al:
 31/12/2024 N° accs. 369.502.872
 31/12/2023 N° accs. 369.502.872
 31/12/2023 N° accs. 369.502.872
 Retorno de dividendos 3,5% 2,0%
 Definida como:
 Dividendos pagados por acción últimos 12 meses
 Precio acción al cierre del periodo
6.- OTROS
 Valor libro acción ($) 4.127,7 3.297,3
 Definida como:
 Patrimonio atribuible a los propietarios
 de la controladora
 N° total de acciones
 Valor bolsa de la acción en $ corrientes 5.739,9 5.610,0
 al cierre de cada período
 27

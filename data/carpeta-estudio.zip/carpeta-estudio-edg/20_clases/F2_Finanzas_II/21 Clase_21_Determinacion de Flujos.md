# Finanzas II · 21 Clase_21_Determinacion de Flujos

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
Clase 21: Capital Budgeting - Determinación de flujos
 Profesor: Augusto Orellana
 Mayo 2026
 Prof: Augusto Orellana Clase 21: Determinación de flujos 1 / 20

[pág. 2]
Roadmap
1 Introducción
2 Métodos de Flujos de Caja
3 Método Indirecto
4 Método Directo
 Prof: Augusto Orellana Clase 21: Determinación de flujos 2 / 20

[pág. 3]
Roadmap
1 Introducción
2 Métodos de Flujos de Caja
3 Método Indirecto
4 Método Directo
 Prof: Augusto Orellana Clase 21: Determinación de flujos 3 / 20

[pág. 4]
Invertir o no invertir, he ahı́ el dilema...
Para evaluar una inversión propuesta, debemos analizar los cambios que
genera en los flujos de caja de la empresa y determinar si crean valor.
¿Cuales son los flujos relevantes a considerar?: Incremental cash
flows
 Todos los cambios en los flujos de caja futuros de la empresa que
 resultan directamente de realizar el proyecto
Free Cash Flows:
 El flujo de caja libre del proyecto es el efecto incremental que el
 proyecto tiene sobre el efectivo disponible
 Prof: Augusto Orellana Clase 21: Determinación de flujos 4 / 20

[pág. 5]
Free Cash Flows: Pitfalls
Aspectos importantes a considerar
 1 Costos hundidos (sunk costs)
 ▶ Costos ya incurridos. Se excluyen del análisis
 2 Costos de oportunidad
 ▶ Beneficios que se sacrifican al usar un recurso en el proyecto (por ejemplo, el
 valor de venta actual de un activo); sı́ se incluyen
 3 Efectos colaterales (spillovers)
 ▶ Impactos del proyecto sobre otros; se incluyen
 4 Capital de trabajo neto
 ▶ Inversiones en inventarios, cuentas por cobrar y efectivo necesarias para
 operar el proyecto; se invierten al inicio y se recuperan al final
 5 Costos de financiamiento
 ▶ Intereses, dividendos o amortizaciones no se incluyen en los flujos del proyecto
 6 Medición correcta
 ▶ Se usan flujos de caja después de impuestos y registrados cuando
 efectivamente ocurren (no utilidades contables)
 Prof: Augusto Orellana Clase 21: Determinación de flujos 5 / 20

[pág. 6]
Roadmap
1 Introducción
2 Métodos de Flujos de Caja
3 Método Indirecto
4 Método Directo
 Prof: Augusto Orellana Clase 21: Determinación de flujos 6 / 20

[pág. 7]
Métodos de Flujos de Caja
Directo
 Listar todas las entradas y salidas de caja.
 Se usa en los Estados Financieros
Indirecto
 Se comienza por Net Income Statement (Estado de Resultados)
 Se deducen y añaden los flujos de efectivo que no estaban
 contemplados
 Este es el que se usa en valoración!
 Prof: Augusto Orellana Clase 21: Determinación de flujos 7 / 20

[pág. 8]
Roadmap
1 Introducción
2 Métodos de Flujos de Caja
3 Método Indirecto
4 Método Directo
 Prof: Augusto Orellana Clase 21: Determinación de flujos 8 / 20

[pág. 9]
Métodos de Flujos de Caja Indirectos
Free Cash flows =
 + Project operating cash flow
 − Project change in net working capital
 − Project capital spending
Hay dos formas de ver los FCF
 Unlevered Free Cash Flows (UFCF)
 ▶ CF producidos por todos los inversionistas (equity & debt-holders)
 ▶ Método de valoración: WACC
 (Levered) Free Cash Flows (FCF)
 ▶ CF producidos solo por todos los equity-holders
 ▶ Método de valoración: FCFE
Por ahora nos enfocaremos en el UFCF!
 Prof: Augusto Orellana Clase 21: Determinación de flujos 9 / 20

[pág. 10]
Project operating cash flow
Operating cash flow = NOPLAT (Net Operating Profit Less
Adjusted Taxes)
 + Earnings before interest and taxes (EBIT)
 + Depreciation
 − Taxes (EBIT*tax%)
 Prof: Augusto Orellana Clase 21: Determinación de flujos 10 / 20

[pág. 11]
Project Net Working Capital (or financing)
Net working capital
 = Current Assets - Cash - Current Liabilities
 = Inventory + Receivables - Payables
 Prof: Augusto Orellana Clase 21: Determinación de flujos 11 / 20

[pág. 12]
Project Capital Spending
Capex
 Prof: Augusto Orellana Clase 21: Determinación de flujos 12 / 20

[pág. 13]
Unlevered Free Cash Flows
 Prof: Augusto Orellana Clase 21: Determinación de flujos 13 / 20

[pág. 14]
Roadmap
1 Introducción
2 Métodos de Flujos de Caja
3 Método Indirecto
4 Método Directo
 Prof: Augusto Orellana Clase 21: Determinación de flujos 14 / 20

[pág. 15]
Métodos de Flujos de Caja Directos
Listamos todas las entradas y salidas de caja:
 Entradas de caja (cash inflows):
 ▶ Cobros a clientes
 ▶ Intereses cobrados
 ▶ Dividendos recibidos
 ▶ Otros ingresos en efectivo
 Salidas de caja (cash outflows):
 ▶ Pagos a proveedores
 ▶ Pagos de sueldos
 ▶ Pago de impuestos
 ▶ Pago de intereses
 ▶ Otros gastos pagados en efectivo
 Prof: Augusto Orellana Clase 21: Determinación de flujos 15 / 20

[pág. 16]
Ejemplo
 Hugo emprende cada verano el negocio de distribuir helados en
 pequeños locales en la playa. El negocio se llevará a cabo de
 noviembre a febrero, y luego se liquidará.
 La mercaderı́a se venderı́a al mes siguiente de adquirida en
 condiciones de 10% contado, 30% a 30 dı́as y el saldo a 60 dı́as:
 ▶ Mes 1: 0 ; Mes 2 = 100 MM, Mes 3 = 120 MM, Mes 4 = 15 MM,
 Mes 5 = 200 MM
 El emprendedor comprarı́a mercaderı́as con un costo igual al 80% del
 valor de venta, pagando 50% al contado y el resto a 30 dı́as
 Para realizar la distribución, deberá arrendar una bodega por
 $5M/mes
 Previo a comenzar, Hugo proyecta sus ventas y que flujos le reportará
 el negocio, en el que pondrá sus ahorros de $233 millones
 Prof: Augusto Orellana Clase 21: Determinación de flujos 16 / 20

[pág. 17]
Ejemplo: Solución
 Prof: Augusto Orellana Clase 21: Determinación de flujos 17 / 20

[pág. 18]
Ejemplo: Solución
 Prof: Augusto Orellana Clase 21: Determinación de flujos 18 / 20

[pág. 19]
Ejemplo: Solución
 Prof: Augusto Orellana Clase 21: Determinación de flujos 19 / 20

[pág. 20]
Ejemplo: Solución
 Prof: Augusto Orellana Clase 21: Determinación de flujos 20 / 20

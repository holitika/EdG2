# Finanzas II · 19 Clase_19_Administacion de Credito-1

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 19: Administración de Crédito
 Profesor: Augusto Orellana
 Mayo 2026
Prof: Augusto Orellana Clase 19: Administración de crédito 1 / 23

[pág. 2]
Roadmap
1 Adm de crédito
2 Terminos de ventas
3 Periodo de Crédito
4 Efectos de la Polı́tica de Crédito
5 Evaluación de la Polı́tica de
 Crédito
6 Análisis de Crédito
 Prof: Augusto Orellana Clase 19: Administración de crédito 2 / 23

[pág. 3]
Roadmap
1 Adm de crédito
2 Terminos de ventas
3 Periodo de Crédito
4 Efectos de la Polı́tica de Crédito
5 Evaluación de la Polı́tica de
 Crédito
6 Análisis de Crédito
 Prof: Augusto Orellana Clase 19: Administración de crédito 3 / 23

[pág. 4]
Administración del Crédito
Otorgar crédito es la forma de estimular las ventas
Trade-off importante:
 Beneficios: Estimular ventas y disfrazar incrementos de precios
 Costos: Exposición al riesgo crediticio del cliente (no pago)
3 aspectos a considerar:
 Términos de ventas
 Analisis de credito
 Politica de cobros
 Prof: Augusto Orellana Clase 19: Administración de crédito 4 / 23

[pág. 5]
Polı́tica de Crédito
 Cuentas por cobrar = Ventas diarias promedio ∗ Perı́odo promedio cobro
 La inversión de una empresa en cuentas por cobrar depende de
 factores que influyen en las ventas a crédito y la cobranza
 Prof: Augusto Orellana Clase 19: Administración de crédito 5 / 23

[pág. 6]
Roadmap
1 Adm de crédito
2 Terminos de ventas
3 Periodo de Crédito
4 Efectos de la Polı́tica de Crédito
5 Evaluación de la Polı́tica de
 Crédito
6 Análisis de Crédito
 Prof: Augusto Orellana Clase 19: Administración de crédito 6 / 23

[pág. 7]
Condiciones de Venta
3 aspectos a considerar:
 1 Plazo y tasa del crédito
 2 Perı́odo y plazo de descuento por pronto pago
 3 Tipo de instrumento de crédito
The basic form:
 Ejemplo: “2/10, neto 60”.
 ▶ Los clientes tienen 60 dı́as a partir de la fecha de la factura para pagar
 el total; sin embargo, si el pago se realiza dentro de los primeros 10
 dı́as, se puede aplicar un descuento del 2% por pronto pago.
 Prof: Augusto Orellana Clase 19: Administración de crédito 7 / 23

[pág. 8]
Roadmap
1 Adm de crédito
2 Terminos de ventas
3 Periodo de Crédito
4 Efectos de la Polı́tica de Crédito
5 Evaluación de la Polı́tica de
 Crédito
6 Análisis de Crédito
 Prof: Augusto Orellana Clase 19: Administración de crédito 8 / 23

[pág. 9]
Periodo de Crédito
Es el plazo del crédito otorgado
 2 componentes:
 ▶ Perı́odo de crédito neto (tiempo que el cliente tiene para pagar)
 ▶ Descuento por pronto pago (el tiempo durante el cual el descuento está
 disponible)
 Ejemplo
 ▶ Con 2/10, neto 30, el plazo de crédito neto es de 30 dı́as y el plazo de
 descuento por pronto pago es de 10 dı́as
 Prof: Augusto Orellana Clase 19: Administración de crédito 9 / 23

[pág. 10]
Perı́odo de crédito neto
Tiempo que el cliente tiene para pagar
 1 Fecha de Facturación: Inicia el periodo de crédito
 ▶ Puede ser: Embarque, Recepción y Fin de mes.
 2 Duración: Ciclo operativo del comprador (tiempo para vender
 inventarios y cobrar)
 ▶ Perecibilidad y valor colateral: bienes perecibles → plazos más cortos
 ▶ Demanda del producto: productos nuevos o de baja rotación → plazos
 más largos.
 ▶ Costo y estandarización: bienes baratos y estandarizados → plazos más
 cortos.
 ▶ Riesgo de crédito: mayor riesgo → plazos más cortos.
 ▶ Tamaño de la cuenta: cuentas pequeñas → plazos más cortos.
 ▶ Competencia: mercados más competitivos → plazos más largos.
 ▶ Tipo de cliente: distintos clientes pueden recibir condiciones de crédito
 diferentes.
 Prof: Augusto Orellana Clase 19: Administración de crédito 10 / 23

[pág. 11]
Descuentos por pronto pago (Cash Discounts)
Objetivos
 Acelerar el cobro de cuentas por cobrar.
 Reducir la inversión en crédito a clientes.
 Cobrar implı́citamente por el crédito a quienes no toman el descuento.
Funcionamiento
 Ejemplo: 2/10, neto 30
 ▶ 2% de descuento si se paga en 10 dı́as.
 ▶ Si no, el total se paga en 30 dı́as.
 ▶ Renunciar al descuento equivale a pagar una tasa implı́cita alta por 20
 dı́as de crédito adicional.
Efectos Financieros
 Incentiva pagos anticipados.
 Reduce el Periodo Promedio de Cobro (PPC).
 Disminuye las necesidades de financiamiento en cuentas por cobrar.
 Prof: Augusto Orellana Clase 19: Administración de crédito 11 / 23

[pág. 12]
Instrumentos de Crédito Comercial
Cuenta abierta (Open Account)
 Forma más común de crédito comercial.
Pagaré (Promissory Note)
 Documento formal de deuda firmado por el cliente.
 Usado en montos grandes o cuando existe mayor riesgo de cobranza.
Letra comercial (Commercial Draft)
 Orden de pago en una fecha especı́fica.
Contrato de venta condicional
 El vendedor mantiene la propiedad legal hasta el pago total.
 Usualmente en pagos en cuotas con interés implı́cito.
 Prof: Augusto Orellana Clase 19: Administración de crédito 12 / 23

[pág. 13]
Roadmap
1 Adm de crédito
2 Terminos de ventas
3 Periodo de Crédito
4 Efectos de la Polı́tica de Crédito
5 Evaluación de la Polı́tica de
 Crédito
6 Análisis de Crédito
 Prof: Augusto Orellana Clase 19: Administración de crédito 13 / 23

[pág. 14]
Efectos de la Polı́tica de Crédito
 1 Efectos en ingresos:
 ▶ Los cobros se retrasan, pero las ventas pueden aumentar.
 ▶ Posibilidad de cobrar precios más altos y vender mayores cantidades.
 2 Efectos en costos:
 ▶ Los costos de producción o compra se incurren de inmediato, incluso si
 el pago se recibe después.
 3 Costo de financiamiento:
 ▶ Las cuentas por cobrar deben financiarse, generando costos de
 endeudamiento.
 4 Riesgo de incobrabilidad:
 ▶ Algunos clientes pueden no pagar cuando se vende a crédito.
 5 Descuentos por pronto pago:
 ▶ Reducen el ingreso por venta cuando los clientes pagan
 anticipadamente.
 Prof: Augusto Orellana Clase 19: Administración de crédito 14 / 23

[pág. 15]
Roadmap
1 Adm de crédito
2 Terminos de ventas
3 Periodo de Crédito
4 Efectos de la Polı́tica de Crédito
5 Evaluación de la Polı́tica de
 Crédito
6 Análisis de Crédito
 Prof: Augusto Orellana Clase 19: Administración de crédito 15 / 23

[pág. 16]
Evaluación de la Polı́tica de Crédito
Idea central: Otorgar crédito es conveniente si el VPN incremental de
cambiar la polı́tica es positivo.
Beneficios
 Aumento de ventas: Q ′ > Q.
 Ganancia adicional mensual:
 (P − v )(Q ′ − Q)
Costos
 Retraso en el cobro de las ventas actuales: PQ.
 Producción de unidades adicionales: v (Q ′ − Q).
Regla de decisión
 (P − v )(Q ′ − Q)
 NPV = −[PQ + v (Q ′ − Q)] +
 R
Aceptar el cambio si NPV > 0.
 Prof: Augusto Orellana Clase 19: Administración de crédito 16 / 23

[pág. 17]
Ejemplo
1. Flujo actual (ventas al contado)
 (P − v )Q = (49 − 20) × 100 = 2,900
2. Flujo bajo nueva polı́tica (Neto 30)
 (P − v )Q ′ = (49 − 20) × 110 = 3,190
3. Beneficio incremental mensual
 (P − v )(Q ′ − Q) = 29 × 10 = 290
4. Costo de cambiar la polı́tica
 PQ + v (Q ′ − Q) = 4,900 + 200 = 5,100
5. VPN del cambio (perpetuidad)
 (P − v )(Q ′ − Q)
 NPV = −[PQ + v (Q ′ − Q)] +
 R
 290
 NPV = −5,100 + = 9,400 > 0
 0.02
 Prof: Augusto Orellana Clase 19: Administración de crédito 17 / 23

[pág. 18]
Roadmap
1 Adm de crédito
2 Terminos de ventas
3 Periodo de Crédito
4 Efectos de la Polı́tica de Crédito
5 Evaluación de la Polı́tica de
 Crédito
6 Análisis de Crédito
 Prof: Augusto Orellana Clase 19: Administración de crédito 18 / 23

[pág. 19]
¿Cuánto deberı́amos prestar?
Parámetros
 P: precio, v : costo variable, π: probabilidad de no pago, R: tasa de
 descuento
1. Cliente de compra única
 (1 − π)P
 NPV = −v
 1+R
Se pierde principalmente el costo del producto si el cliente no paga.
2. Cliente recurrente
 (1 − π)(P − v )
 NPV = −v
 R
El beneficio esperado incluye la relación comercial futura.
Idea clave: Las ventas recurrentes aumentan fuertemente el incentivo a
otorgar crédito, aun cuando exista riesgo de no pago.
 Prof: Augusto Orellana Clase 19: Administración de crédito 19 / 23

[pág. 20]
Modelo de W. Sartoris y N. Hill
Evaluar descuentos por pronto pago y su efecto en flujos de caja,
financiamiento e incobrabilidad.
 Prof: Augusto Orellana Clase 19: Administración de crédito 20 / 23

[pág. 21]
Ejercicio Aplicado
Una empresa comercializa un producto con las siguientes caracterı́sticas:
 Venta diaria: 200 unidades.
 Precio de venta a crédito por unidad: $500.
 El costo representa el 70% del precio de venta.
La polı́tica comercial de la empresa establece lo siguiente:
 El 40% de las ventas se realiza al contado.
 A las ventas al contado se les ofrece un descuento por pronto pago del 5%.
 El 60% restante corresponde a ventas a crédito a 30 dı́as.
 Debido a retrasos en el pago de algunos clientes, el perı́odo efectivo promedio de cobro es de 35 dı́as.
 La tasa de incobrabilidad sobre las ventas a crédito es del 2%.
Respecto de la operación productiva y abastecimiento:
 La empresa mantiene un stock de materias primas suficiente para cubrir 15 dı́as de ventas.
 Las compras de materias primas se pagan, en promedio, 30 dı́as después de recibidas.
 Una orden de compra de materiales demora aproximadamente 30 dı́as en llegar a la empresa.
La tasa anual de descuento relevante para evaluar los flujos es de 18% anual.
 1 Construir la lı́nea de tiempo operacional y financiera del ciclo de ventas.
 2 Calcular el Valor Presente Neto (VPN) de la polı́tica actual utilizando el modelo de Sartoris y Hill.
 Prof: Augusto Orellana Clase 19: Administración de crédito 21 / 23

[pág. 22]
Ejercicio Aplicado: Estimulando pronto pago
Suponga ahora que la empresa evalúa una modificación en su polı́tica comercial y operacional. Los nuevos datos son los
siguientes:
 Venta diaria: 210 unidades.
 Precio de venta a crédito por unidad: $500.
 El costo representa el 70% del precio de venta, es decir, $350 por unidad.
La nueva polı́tica comercial establece:
 El 50% de las ventas se realiza al contado.
 A las ventas al contado se les ofrece un descuento por pronto pago del 8%.
 El 50% restante corresponde a ventas a crédito a 30 dı́as.
 Debido a retrasos en el pago de algunos clientes, el perı́odo efectivo promedio de cobro es de 35 dı́as.
 La tasa de incobrabilidad sobre las ventas a crédito es del 1%.
Respecto de la operación productiva y abastecimiento, se mantienen las siguientes condiciones:
 La empresa mantiene un stock de materias primas suficiente para cubrir 15 dı́as de ventas.
 Las compras de materias primas se pagan, en promedio, 30 dı́as después de recibidas.
 Una orden de compra de materiales demora aproximadamente 30 dı́as en llegar a la empresa.
La tasa anual de descuento relevante para evaluar los flujos se mantiene en 18% anual.
 Prof: Augusto Orellana Clase 19: Administración de crédito 22 / 23

[pág. 23]
Ejercicio Aplicado: Aumentando plazo
Suponga finalmente que la empresa evalúa una tercera polı́tica comercial. Los nuevos datos son los siguientes:
 Venta diaria: 220 unidades.
 Precio de venta a crédito por unidad: $500.
 El costo representa el 70% del precio de venta, es decir, $350 por unidad.
La polı́tica comercial alternativa establece:
 El 20% de las ventas se realiza al contado.
 A las ventas al contado se les ofrece un descuento por pronto pago del 5%.
 El 80% restante corresponde a ventas a crédito a 60 dı́as.
 Debido a retrasos en el pago de algunos clientes, el perı́odo efectivo promedio de cobro es de 70 dı́as adicionales.
 La tasa de incobrabilidad sobre las ventas a crédito es del 3%.
Respecto de la operación productiva y abastecimiento, se mantienen las siguientes condiciones:
 La empresa mantiene un stock de materias primas suficiente para cubrir 15 dı́as de ventas.
 Las compras de materias primas se pagan, en promedio, 30 dı́as después de recibidas.
 Una orden de compra de materiales demora aproximadamente 30 dı́as en llegar a la empresa.
La tasa anual de descuento relevante para evaluar los flujos se mantiene en 18% anual.
 Prof: Augusto Orellana Clase 19: Administración de crédito 23 / 23

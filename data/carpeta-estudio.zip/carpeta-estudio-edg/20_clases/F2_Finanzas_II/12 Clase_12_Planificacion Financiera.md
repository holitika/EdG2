# Finanzas II · 12 Clase_12_Planificacion Financiera

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 12: Planificación estratégica y financiera de
 Largo Plazo
 Profesor: Augusto Orellana
 Abril 2026
Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 1 / 15

[pág. 2]
Roadmap
1 Introducción
2 Crecimiento y financiamiento
3 Financiamiento Externo Requerido
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 2 / 15

[pág. 3]
Roadmap
1 Introducción
2 Crecimiento y financiamiento
3 Financiamiento Externo Requerido
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 3 / 15

[pág. 4]
¿Qué es la Planificación Financiera?
La planificación financiera es parte de un proceso más amplio, denominado
planificación estratégica
Planificación estratégica
 Proyecta a la empresa hacia el futuro
 Considera:
 ▶ Objetivos financieros y no financieros
 ▶ Escenarios esperados
 ▶ Impacto de eventos poco probables
Planificación Financiera
 Creación de un presupuesto financiero con mirada hacia el futuro
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 4 / 15

[pág. 5]
¿Por qué son los presupuestos financieros?
Planes que especifican ingresos, gastos, desembolsos, y en general
cualquier variable monetaria, para un periodo de tiempo futuro
Objetivos de la Planificación estratégica:
 Anticipar la condición futura de la empresa
 Planear:
 ▶ Inversiones
 ▶ Financial leverage
 ▶ Cash / Payouts
 ▶ Liquidez / working capital
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 5 / 15

[pág. 6]
¿Analisis Financiero = Planificación Financiera?
NO!
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 6 / 15

[pág. 7]
Roadmap
1 Introducción
2 Crecimiento y financiamiento
3 Financiamiento Externo Requerido
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 7 / 15

[pág. 8]
Crecimiento y financiamiento
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 8 / 15

[pág. 9]
Vender para crecer
Ejemplo: Ciclo de Efectivo
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 9 / 15

[pág. 10]
Aumento de ventas (∆+ Sales)
∆+ Sales ⇒ ∆+ Assets
 ∆+ Sales ⇒ ∆+ Liabilities
 1 Activos Corrientes:
 1 Pasivos Corrientes:
 ▶ Cuentas por cobrar ▶ Cuentas por pagar
 ▶ Existencias/Inventarios
 ▶ Otros activos de CP
 ▶ Remuneraciones por pagar
 ▶ Otros pasivos de CP
 2 Activos Fijos:
 2 Utilidades Retenidas:
 ▶ PPE
Si hay deficit → Financiamineto Externo Requerido (FER) (en
ingles: Additional Funds Needed (AFN))
 FER = ∆A − ∆P − ∆UtRet
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 10 / 15

[pág. 11]
Roadmap
1 Introducción
2 Crecimiento y financiamiento
3 Financiamiento Externo Requerido
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 11 / 15

[pág. 12]
Financiamiento Externo Requerido
¿Cómo obtenemos el FER?
 Método del % sobre ventas
 ▶ Determinar FER a partir del % sobre ventas a que corresponde cada
 activo y pasivo
Dos caminos para calcular FER:
 Proyección del balance
 Proyección de las entradas y salida de caja
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 12 / 15

[pág. 13]
Financiamiento Externo Requerido: Ejemplo
Las ventas del 2024 fueron de $500.000 , lo cual significó copar completamente la capacidad
productiva de la empresa. El margen de utilidad después de impuestos sobre la ventas fue de 4%
y se espera que se mantenga. Durante el año pasado la empresa ganó $20.000 después de
impuestos y pagó un dividendo equivalente al 60% de la utilidad neta, porcentaje de pago que
espera mantener. ¿Qué financiamiento externo requerirá la empresa el 2025 si se espera que las
ventas lleguen a $800.000 y que se deben realizar inversiones en activo fijo por $100.000?
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 13 / 15

[pág. 14]
FER: Proyección del balance
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 14 / 15

[pág. 15]
FER: Proyección de las entradas y salida de caja
 Prof: Augusto Orellana Clase 12: Planificación Financiera (LP) 15 / 15

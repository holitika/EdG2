# Finanzas II · 10 Clase_10_NVIDIA

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 10: Razones Financieras.
 Caso 1: NVIDIA
 Profesor: Augusto Orellana
 Marzo 2026
Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 1 / 29

[pág. 2]
Roadmap
1 NVIDIA
2 Análisis Cualitativo
3 Análisis Cuantitativo
4 Análisis Financiero
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 2 / 29

[pág. 3]
Roadmap
1 NVIDIA
2 Análisis Cualitativo
3 Análisis Cuantitativo
4 Análisis Financiero
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 3 / 29

[pág. 4]
Presentación de la Empresa: NVIDIA
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 4 / 29

[pág. 5]
NVIDIA
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 5 / 29

[pág. 6]
Analisis Financiero de NVIDIA
 ¿Cómo llegó a ser NVIDIA el gigante que es hoy en dı́a?
Analizemos financieramente a NVIDIA 3 años atrás (2022)
 1 Analisis Cualitativo
 ▶ Porter
 2 Analisis Quantitativo
 ▶ Liquidez
 ▶ Solvencia
 ▶ Rentabilidad
 ▶ Working Capital
 3 Fuente de Info: 10-k
 ▶ Link
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 6 / 29

[pág. 7]
Roadmap
1 NVIDIA
2 Análisis Cualitativo
3 Análisis Cuantitativo
4 Análisis Financiero
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 7 / 29

[pág. 8]
Porter: Rivalidad entre competidores
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 8 / 29

[pág. 9]
Porter: Rivalidad entre competidores (compustat)
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 9 / 29

[pág. 10]
Porter: Rivalidad entre competidores (Alta)
 Industria donde el ritmo de innovación es acelerado
 Alta presión competitiva obliga a sostener niveles altos de I+D
 Competencia no solo en precio
 ▶ Compentencias por ecosistemas y adopción tecnológica
Implicación financiera: alta rivalidad suele presionar márgenes, pero una
diferenciación fuerte permite sostener rentabilidad mediante valor
agregado.
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 10 / 29

[pág. 11]
Porter: Amenaza de nuevos entrantes (Baja)
 Barreras elevadas por complejidad tecnológica, inversión en I+D e
 infraestructura
 Necesidad de acceso a cadenas de suministro (importancia de
 suppliers)
Implicación financiera: barreras altas protegen participación de mercado y
sostienen desempeño en el largo plazo, favoreciendo estabilidad de
ingresos.
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 11 / 29

[pág. 12]
Porter: Poder de negociación de los proveedores (Alto)
 NVIDIA no fabrica sus semiconductores ni posee plantas de
 fabricación
 ▶ Depende de foundries y de terceros para ensamblaje, pruebas y
 empaquetado
 Riesgo estructural por la limitación de proveedores globales
 Necesidad de hacer pedidos con hasta 12 meses de anticipación
 ▶ Eleva costos y riesgos de exceso de inventario si cambia la demanda
Implicación financiera: este factor afecta directamente costos, margen
bruto, e incluso decisiones de capital de trabajo (inventarios y
compromisos de compra).
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 12 / 29

[pág. 13]
Porter: Poder de negociación de los proveedores (Alto)
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 13 / 29

[pág. 14]
Porter: Poder de negociación de los compradores (Alto)
 Parte significativa de ingresos de un número limitado de clientes
 Clientes pueden cancelar o modificar pedidos con poca anticipación
 Necesidad de hacer pedidos con hasta 12 meses de anticipación
 ▶ Eleva costos y riesgos de exceso de inventario si cambia la demanda
Implicación financiera: el poder del comprador aumenta la volatilidad en
ventas y presiona condiciones comerciales (precio, volumen, tiempos),
afectando proyecciones y estabilidad de ingresos.
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 14 / 29

[pág. 15]
Porter: Poder de negociación de los compradores (Alto)
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 15 / 29

[pág. 16]
Porter: Amenaza de productos sustitutos (Media)
 En mercados tecnológicos, existen alternativas funcionales según el
 caso de uso
 Sin embargo, NVIDIA sostiene una propuesta diferenciada basada en:
 ▶ Arquitectura GPU
 ▶ Deep learning
 ▶ Integración de softwares
Implicación financiera: sustitutos moderados implican necesidad de
mantener diferenciación para proteger márgenes y evitar erosión de
participación.
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 16 / 29

[pág. 17]
Roadmap
1 NVIDIA
2 Análisis Cualitativo
3 Análisis Cuantitativo
4 Análisis Financiero
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 17 / 29

[pág. 18]
NVIDIA: Balance Sheet
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 18 / 29

[pág. 19]
NVIDIA: Net Income
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 19 / 29

[pág. 20]
NVIDIA: Análisis de Ratios
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 20 / 29

[pág. 21]
NVIDIA vs. Industria
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 21 / 29

[pág. 22]
Roadmap
1 NVIDIA
2 Análisis Cualitativo
3 Análisis Cuantitativo
4 Análisis Financiero
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 22 / 29

[pág. 23]
Análisis financiero de NVIDIA (2022-2023)
1) Contexto estratégico previo al boom
 NVIDIA operaba en una industria con alta rivalidad tecnológica
 ▶ Clave: Gatos R+D y diferenciación de producto
 Barreras de entrada altas
 ▶ Economics moats
 Alto poder de proveedores y clientes concentrados
El éxito posterior no se explica solo por demanda de IA, sino por una
posición competitiva ya consolidada.
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 23 / 29

[pág. 24]
Análisis financiero de NVIDIA (2022-2023)
2) Evolución de resultados (2022 - 2023)
 Ingresos relativamente estables (27 mil millones USD)
 La utilidad operativa cayó significativamente
 Fase de inversión estratégica intensiva
 ▶ Acquisiciones estratégicas en el ecosistema de data centers y cloud AI
Costos de integración, amortizaciones tecnológicas y mayor gasto en
desarrollo, reduciendo utilidades de corto plazo pero fortaleciendo la
capacidad de crecimiento futuro
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 24 / 29

[pág. 25]
Análisis financiero de NVIDIA (2022-2023)
3) Liquidez y solvencia
 Caı́da en liquidez entre 2022 y 2023
 ▶ Financiamiento de inversión estratégica (acquisiciones)
 Apalancamiento disminuye
 ▶ Acquisición se realizó con una estructura financiera sólida y bajo riesgo
 de solvencia
Consistente con una empresa que financia crecimiento mediante recursos
propios
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 25 / 29

[pág. 26]
Análisis financiero de NVIDIA (2022-2023)
4) Rentabilidad
 Caı́da en 2023 respecto de 2022
A pesar de la caı́da, la empresa mantiene rentabilidad positiva y márgenes
estructuralmente superiores a gran parte de la industria, lo que confirma la
existencia de ventajas competitivas persistentes
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 26 / 29

[pág. 27]
Análisis financiero de NVIDIA (2022-2023)
5) Capital de trabajo y preparación operativa
 Acumulación relevante de capital de trabajo e inventarios
 ▶ NVIDIA anticipó expansión futura de demanda
La acumulación de inventarios permitió que NVIDIA respondiera
rápidamente al aumento explosivo de la demanda de GPUs AI en los años
siguientes.
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 27 / 29

[pág. 28]
Análisis financiero de NVIDIA (2022-2023)
6) Insight financiero central
El crecimiento extraordinario posterior de NVIDIA no fue un evento
inesperado, sino el resultado de una estrategia financiera y tecnológica
deliberada, basada en:
 1 Adquisiciones e inversiones estratégicas
 2 Balance sólido para financiar expansión sin aumentar riesgo financiero
 3 Inversión anticipada en capacidad tecnológica y de infraestructura
 4 Aprovechamiento de barreras tecnológicas y diferenciación del
 producto
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 28 / 29

[pág. 29]
Análisis financiero de NVIDIA (2022-2023)
 Entre 2022 y 2023 NVIDIA atraviesa una fase de transición caracterizada
por menor rentabilidad contable pero fuerte inversión estratégica,
fortalecimiento del ecosistema tecnológico y preparación operativa. Estas
decisiones crearon las condiciones financieras y tecnológicas que
permitieron a la empresa capturar de manera desproporcionada el
crecimiento global del mercado de inteligencia artificial en los años
posteriores
 Prof: Augusto Orellana Clase 10: Razones Financieras (NVIDIA) 29 / 29

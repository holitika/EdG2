# Finanzas II · 3 Clase_3 Liquidez_rentabilidad_riesgo

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 3: Liquidez - Rentabilidad - Riesgo
 Profesor: Augusto Orellana
 Marzo 2026
Prof: Augusto Orellana Clase 3: Dilemas 1 / 18

[pág. 2]
Roadmap
1 Liquidez
2 Rentabilidad
3 OROA: Margen o Turnover
4 Riesgo Operacional
5 Triángulo de la Inversión
 Prof: Augusto Orellana Clase 3: Dilemas 2 / 18

[pág. 3]
Roadmap
1 Liquidez
2 Rentabilidad
3 OROA: Margen o Turnover
4 Riesgo Operacional
5 Triángulo de la Inversión
 Prof: Augusto Orellana Clase 3: Dilemas 3 / 18

[pág. 4]
Liquidez de una Empresa
¿Qué es la liquidez?
 Rapidez y facilidad con la que un activo se transforma en efectivo
¿Cómo se mide?
 1 Current Ratio: Activos Corrientes / Pasivos Corrientes (≤ 12 meses)
 2 Quick (Acid) Ratio: (Activos Corrientes - Inventarios) / Pasivos
 Corrientes
 ▶ Inventarios son poco lı́quidos
 ▶ Mucho inventario también refleja un problema. ¿Por qué?
Ventajas Alta Liquidez Desventajas Alta Liquidez
 Menor insolvencia de CP Menor rentabilidad
 Enfrentar shocks de caja
 Prof: Augusto Orellana Clase 3: Dilemas 4 / 18

[pág. 5]
Roadmap
1 Liquidez
2 Rentabilidad
3 OROA: Margen o Turnover
4 Riesgo Operacional
5 Triángulo de la Inversión
 Prof: Augusto Orellana Clase 3: Dilemas 5 / 18

[pág. 6]
Rentabilidad de una Empresa
¿Qué es la rentabilidad?
 Eficiencia con la que la empresa genera beneficios a partir del capital
 invertido
¿Cómo se mide?
 1 OROA: Operating Return on Assets (EBIT/Assets)
 ▶ ¿Qué tan buenos son los activos para generar resultados operativos?
 ▶ Se distribuye entre acreedores y accionistas
 2 ROA: Return on Assets (Net income/Assets)
 ▶ Dado todo lo que la empresa posee, ¿cuánta utilidad genera?
 ▶ Rentabilidad del activo total después de intereses e impuestos
 3 ROE: Return on Equity (Net income/Equity)
 ▶ ¿Cuánto ganan los accionistas por cada peso invertido?
 ▶ Rentabilidad del capital propio
 Prof: Augusto Orellana Clase 3: Dilemas 6 / 18

[pág. 7]
OROA VS. ROA VS. ROE
 Prof: Augusto Orellana Clase 3: Dilemas 7 / 18

[pág. 8]
Roadmap
1 Liquidez
2 Rentabilidad
3 OROA: Margen o Turnover
4 Riesgo Operacional
5 Triángulo de la Inversión
 Prof: Augusto Orellana Clase 3: Dilemas 8 / 18

[pág. 9]
OROA = Operating Profit Margin × Total Asset Turnover
 EBIT Revenues(Sales)
 OROA = x
 Revenues(Sales) Assets
 Margen de Utilidad Operacional (EBIT/Revenues)
 ▶ Utilidad por cada peso vendido
 Turnover (Rotación) de Activos (Revenues/Assets)
 ▶ Ventas por cada peso invertido en activos
 Prof: Augusto Orellana Clase 3: Dilemas 9 / 18

[pág. 10]
Desagregación de la Rentabilidad Operacional
 Prof: Augusto Orellana Clase 3: Dilemas 10 / 18

[pág. 11]
Rentabilidades Excepcionales
¿Cómo tener rentabilidades excepcionales?
 Altos márgenes y alta rotación
¿Qué hacer para asegurarlas?: Economic Moats
 Switching costs (e.g., software)
 Activos intangibles
 Specific Assets
 Ventajas de Costo
 Economias de escala
 Barreras de entradas
 Regulación
 Prof: Augusto Orellana Clase 3: Dilemas 11 / 18

[pág. 12]
Roadmap
1 Liquidez
2 Rentabilidad
3 OROA: Margen o Turnover
4 Riesgo Operacional
5 Triángulo de la Inversión
 Prof: Augusto Orellana Clase 3: Dilemas 12 / 18

[pág. 13]
Riesgo de Rentabilidad (Profit risk)
¿Qué es el Profit risk?
 Variabilidad de la rentabilidad de los activos (OROA)
⇒ A mayor riesgo, mayor retorno esperado exigido
 Prof: Augusto Orellana Clase 3: Dilemas 13 / 18

[pág. 14]
Close-up of Profit Risk (Business risk)
Conceptualmente:
 Business Risk = Sales Risk + Operating Risk
Operating Risk measure:
 Degree of Operating Leverage (DOL (GLO in Spanish))
 Prof: Augusto Orellana Clase 3: Dilemas 14 / 18

[pág. 15]
Leverage Operacional
 Sensibilidad del EBIT a cambios en ventas:
 %∆EBIT
 Leverage Operacional =
 %∆Ventas(unidades)
Derivación:
 EBIT = (P − c) ∗ Q − CF (1)
Como %∆ ≈ dX
 X , entonces:
 dEBIT dEBIT dQ
 = ∗ (2)
 EBIT dQ EBIT
 dEBIT (P − c) ∗ dQ (P − c) ∗ dQ Q
 = = ∗ (3)
 EBIT (P − c) ∗ Q − CF (P − c) ∗ Q − CF Q
 dEBIT /EBIT (P − c) ∗ Q
 Leverage Operacional = = (4)
 dQ/Q (P − c) ∗ Q − CF
 Prof: Augusto Orellana Clase 3: Dilemas 15 / 18

[pág. 16]
Close-up al Leverage Operacional
Cambios en c y CF :
 dLO dLO
 >0; >0 (5)
 dc dCF
 Un mayor c o CF → Mayor Operating Risk → Mayor Profit Risk
 Prof: Augusto Orellana Clase 3: Dilemas 16 / 18

[pág. 17]
Roadmap
1 Liquidez
2 Rentabilidad
3 OROA: Margen o Turnover
4 Riesgo Operacional
5 Triángulo de la Inversión
 Prof: Augusto Orellana Clase 3: Dilemas 17 / 18

[pág. 18]
Triángulo del Riesgo – Rentabilidad - Liquidez
 Alto retorno + Bajo riesgo → Baja liquidez (ej, PPE)
 Alto retorno + Alta liquidez → Alto riesgo (ej, acciones)
 Bajo riesgo + Alta liquidez → Bajo retorno (ej, cash)
 Prof: Augusto Orellana Clase 3: Dilemas 18 / 18

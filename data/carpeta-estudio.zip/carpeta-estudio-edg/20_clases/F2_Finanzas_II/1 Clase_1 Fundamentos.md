# Finanzas II · 1 Clase_1 Fundamentos

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
Clase 1: Fundamentos de la Administración Financiera
 Profesor: Augusto Orellana
 Marzo 2026
 Prof: Augusto Orellana Clase 1: Fundamentos 1 / 13

[pág. 2]
Roadmap
1 Finanzas: Sus 5 áreas
2 Corporate Finance
3 Decisiones Financieras
4 Formas de Organización
5 Mercado Financiero
 Prof: Augusto Orellana Clase 1: Fundamentos 2 / 13

[pág. 3]
Roadmap
1 Finanzas: Sus 5 áreas
2 Corporate Finance
3 Decisiones Financieras
4 Formas de Organización
5 Mercado Financiero
 Prof: Augusto Orellana Clase 1: Fundamentos 3 / 13

[pág. 4]
Finanzas: Sus 5 áreas
 Prof: Augusto Orellana Clase 1: Fundamentos 4 / 13

[pág. 5]
Roadmap
1 Finanzas: Sus 5 áreas
2 Corporate Finance
3 Decisiones Financieras
4 Formas de Organización
5 Mercado Financiero
 Prof: Augusto Orellana Clase 1: Fundamentos 5 / 13

[pág. 6]
¿Qué son las finanzas corporativas?
 1 Decisiones financieras de una empresa
 ▶ Inversiones
 ▶ Financimiento
 2 Creación de valor
 ▶ Formas de organización
 ▶ Objetivos de la empresa
 3 La corporación, el mercado financiero y su contexto
 Prof: Augusto Orellana Clase 1: Fundamentos 6 / 13

[pág. 7]
Roadmap
1 Finanzas: Sus 5 áreas
2 Corporate Finance
3 Decisiones Financieras
4 Formas de Organización
5 Mercado Financiero
 Prof: Augusto Orellana Clase 1: Fundamentos 7 / 13

[pág. 8]
Decisiones financieras de una empresa
Inversiones
 Buena inversión: Cash Flow > Costo del Activo
 Riesgo
Financiamiento
 Largo plazo: Estructura de Capital
 Corto plazo: Cash management/working capital
 Prof: Augusto Orellana Clase 1: Fundamentos 8 / 13

[pág. 9]
Roadmap
1 Finanzas: Sus 5 áreas
2 Corporate Finance
3 Decisiones Financieras
4 Formas de Organización
5 Mercado Financiero
 Prof: Augusto Orellana Clase 1: Fundamentos 9 / 13

[pág. 10]
Formas de Organización Empresarial
Algunas preguntas:
 1 Ciclo de vida: ¿Cómo es el ciclo de vida de las empresas?
 2 Financiamiento: ¿Cuán fácil es obtener financiamiento?
 3 Utilidades e Impuestos: ¿A quién le corresponden?
 4 Responsabilidad: ¿Quién está a cargo?
 Prof: Augusto Orellana Clase 1: Fundamentos 10 / 13

[pág. 11]
Roadmap
1 Finanzas: Sus 5 áreas
2 Corporate Finance
3 Decisiones Financieras
4 Formas de Organización
5 Mercado Financiero
 Prof: Augusto Orellana Clase 1: Fundamentos 11 / 13

[pág. 12]
La corporación, el mercado financiero y su contexto
 Prof: Augusto Orellana Clase 1: Fundamentos 12 / 13

[pág. 13]
El mercado financiero
Primary Markets vs Secondary Markets
 Public offerings (IPOs, SEOs) vs Transferring ownership
 Prof: Augusto Orellana Clase 1: Fundamentos 13 / 13

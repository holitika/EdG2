# Finanzas II · 24 Clase_24_ Evaluacion de Proyectos y Empresas-1

Fuente: clase de Finanzas II

[pág. 1]
EAA220B – Dirección Financiera
 Clase 24: Evaluación de inversiones y empresas
 Profesor: Augusto Orellana
 Junio 2026
Prof: Augusto Orellana Clase 24: Evaluación 1 / 27

[pág. 2]
Roadmap
1 Introducción
2 Valor de los Activos con WACC
3 Valor Presente Ajustado (APV)
4 Valor del Equity
 Prof: Augusto Orellana Clase 24: Evaluación 2 / 27

[pág. 3]
Roadmap
1 Introducción
2 Valor de los Activos con WACC
3 Valor Presente Ajustado (APV)
4 Valor del Equity
 Prof: Augusto Orellana Clase 24: Evaluación 3 / 27

[pág. 4]
Valoración
 Prof: Augusto Orellana Clase 24: Evaluación 4 / 27

[pág. 5]
Tres Métodos de Valoración
I. Método WACC (CCPP)
 Es el método más simple y utilizado en valorización corporativa.
 Cuándo usarlo: cuando la empresa mantiene una estructura de deuda relativamente
 estable en el tiempo.
II. Valor Presente Ajustado ( APV)
 Separa claramente el valor del proyecto y el efecto del financiamiento.
 Cuándo usarlo: cuando la deuda cambia en el tiempo o el financiamiento es complejo.
III. Flujo al Capital (Flow to Equity)
 Mide directamente el valor generado para los accionistas.
 Cuándo usarlo: cuando el análisis se centra en el patrimonio o retorno para los dueños.
 Prof: Augusto Orellana Clase 24: Evaluación 5 / 27

[pág. 6]
Roadmap
1 Introducción
2 Valor de los Activos con WACC
3 Valor Presente Ajustado (APV)
4 Valor del Equity
 Prof: Augusto Orellana Clase 24: Evaluación 6 / 27

[pág. 7]
Valor de los Activos con WACC
Idea Principal
La técnica WACC es ampliamente utilizada porque es simple e intuitiva. La
valoración considera a todos los inversionistas como un solo grupo, sin separar
accionistas y acreedores.
Supuestos necesarios para usar WACC
 La empresa mantiene una estructura de capital relativamente estable.
 El riesgo operativo del proyecto es similar al de la empresa.
 La deuda tiene un nivel de riesgo relativamente constante.
 Los beneficios tributarios de la deuda pueden incorporarse correctamente en
 el WACC.
 Los flujos del proyecto pueden valorarse como flujos operacionales del activo.
 Prof: Augusto Orellana Clase 24: Evaluación 7 / 27

[pág. 8]
Uso del WACC para Valorar Empresas y Proyectos
Pasos Principales
 1 Proyectar los Flujos de Caja Libres Desapalancados (UFCF) de la empresa o proyecto.
 2 Descontar esos flujos utilizando el WACC.
Interpretación
 El valor presente de los UFCF futuros corresponde al Valor Empresa (Enterprise Value).
 Si se incluyen las inversiones iniciales (flujo en t = 0), se obtiene el Valor Presente Neto
 (VPN).
Consideración Importante
 Muchas empresas utilizan un mismo WACC para todos los proyectos de una división.
 Esto solo es correcto si el proyecto tiene un riesgo y operaciones similares al negocio
 existente.
 Si el proyecto es distinto, se debe estimar un WACC especı́fico para el proyecto.
 Prof: Augusto Orellana Clase 24: Evaluación 8 / 27

[pág. 9]
Ejemplo: Valoración usando WACC
Datos Cálculos
 EBIT = 35 1. Flujo Libre Desapalancado
 Impuestos = 30%
 UFCF = 35(0.7) + 25 − 10 − 0.5 = 39
 Depreciación = 25
 CAPEX = 10
 ∆ NWC = 0.5 2. Costo del Equity
 βE = 1.20 rE = 2.5% + 1.2(4.8%)
 rf = 2.5%
 Prima de mercado = 4.8% rE = 8.26%
 Deuda/Valor = 19.8%
 rD = 8.0% 3. WACC
 E D
 WACC = rE + rD (1 − T )
 D+E D+E
 WACC = 0.802(8.26%) + 0.198(8.0%)(0.7)
 WACC ≈ 7.2%
 4. Enterprise Value
 39
 EV =
 0.072
 EV ≈ 542
 Prof: Augusto Orellana Clase 24: Evaluación 9 / 27

[pág. 10]
Roadmap
1 Introducción
2 Valor de los Activos con WACC
3 Valor Presente Ajustado (APV)
4 Valor del Equity
 Prof: Augusto Orellana Clase 24: Evaluación 10 / 27

[pág. 11]
Valor Presente Ajustado (APV)
 Existen distintos métodos para valorar empresas y proyectos.
 El método más utilizado es WACC, pero no siempre es el más flexible.
 El método APV permite separar:
 ▶ el valor operacional del negocio,
 ▶ y el valor creado por el financiamiento.
 APV es especialmente útil cuando la estructura de deuda cambia en
 el tiempo.
 Prof: Augusto Orellana Clase 24: Evaluación 11 / 27

[pág. 12]
¿Qué es APV?
Adjusted Present Value (APV)
Valora una empresa separando:
 1 El valor del negocio sin deuda.
 2 El valor de los beneficios del financiamiento (Managers’ decisions)
 Prof: Augusto Orellana Clase 24: Evaluación 12 / 27

[pág. 13]
APV vs WACC
Ventajas de APV Ventajas de WACC
 Más flexible. Más simple de aplicar.
 Menos supuestos. Muy usado en empresas
 Separa claramente operación y maduras.
 financiamiento. Buen benchmark para
 Útil cuando la deuda cambia proyectos similares.
 en el tiempo. Fácil de comunicar e
 interpretar.
Importante
APV siempre funciona cuando WACC funciona, pero no necesariamente al
revés.
 Prof: Augusto Orellana Clase 24: Evaluación 13 / 27

[pág. 14]
Etapas del Método APV
 1 Estimar los flujos operacionales desapalancados.
 2 Valorar la empresa como si no tuviera deuda.
 3 Calcular los beneficios del financiamiento:
 ▶ escudo fiscal,
 ▶ subsidios,
 ▶ costos financieros.
 4 Sumar ambos componentes.
 APV = VU + VP(Escudo Fiscal)
 Prof: Augusto Orellana Clase 24: Evaluación 14 / 27

[pág. 15]
Caso de Estudio: IBEX Industries
Contexto
Roy Henry, presidente de IBEX Industries, desea adquirir Acme Filters, una
división de SL Corporation.
 Acme es una empresa madura.
 Ha tenido problemas de desempeño en los últimos años.
 IBEX identifica oportunidades de creación de valor.
 ▶ Reducir lı́neas de productos poco rentables.
 ▶ Outsourcing de componentes para mejorar márgenes.
 ▶ Reducir inventarios y capital de trabajo.
 ▶ Venta de activos ociosos.
 ▶ Mejorar distribución e incentivos de ventas.
 ▶ Aprovechar beneficios tributarios de la deuda.
 Prof: Augusto Orellana Clase 24: Evaluación 15 / 27

[pág. 16]
Supuestos Financieros
 Precio mı́nimo de venta: $307 millones (book value).
 80% financiado con deuda.
 Target debt-to-capital ratio de 50%.
 Pago de intereses no mayor a $20 millones.
 Acme es una empresa privada. (que implica esto?)
 Prof: Augusto Orellana Clase 24: Evaluación 16 / 27

[pág. 17]
Financial Information
 Prof: Augusto Orellana Clase 24: Evaluación 17 / 27

[pág. 18]
Valor Operacional
 Primero valoramos la empresa como si estuviera completamente
 financiada con equity.
 Los UFCF ya fueron estimados.
 ru = 13.5%.
 Terminal Value in yr 5= Yrru6CF 21.3m∗1.05
 −g = 0.135−0.05 = 263.4m
 Prof: Augusto Orellana Clase 24: Evaluación 18 / 27

[pág. 19]
Beneficios del Financiamiento
 Year 1: 7.5% ∗ 13 + 8% ∗ 80 + 9.5% ∗ 150 = 21.6
 Year 1: R ∗ D ∗ Tc = 21.6 ∗ 0.34 = 7.4
 Prof: Augusto Orellana Clase 24: Evaluación 19 / 27

[pág. 20]
Compramos o no compramos?
Pregunta
¿El valor creado supera el costo de adquisición?
Si el APV excede el precio pagado, la adquisición crea valor.
 Prof: Augusto Orellana Clase 24: Evaluación 20 / 27

[pág. 21]
Decisión Final
 Prof: Augusto Orellana Clase 24: Evaluación 21 / 27

[pág. 22]
Roadmap
1 Introducción
2 Valor de los Activos con WACC
3 Valor Presente Ajustado (APV)
4 Valor del Equity
 Prof: Augusto Orellana Clase 24: Evaluación 22 / 27

[pág. 23]
Free Cash Flow to Equity (FCFE)
Idea Principal
El método FCFE valora directamente el patrimonio de los accionistas.
 (Levered) Free Cash Flows (FCF)
 ▶ CF producidos solo por los equity-holders
Free Cash flows =
 + Project cash flows
 − Project change in net working capital
 − Project capital spending
 Prof: Augusto Orellana Clase 24: Evaluación 23 / 27

[pág. 24]
(Levered) Free Cash Flows (FCF)
Project cash flow
 + Net Income
 + Depreciation
 − Taxes (Net Income*tax%)
Net working capital
 = Current Assets - Cash - Current Liabilities
 = Inventory + Receivables - Payables
Capex
Importante
A diferencia del UFCF, el FCFE incorpora explı́citamente las decisiones de
financiamiento.
 Prof: Augusto Orellana Clase 24: Evaluación 24 / 27

[pág. 25]
¿Cómo se Valora con FCFE?
 1 Proyectar FCFE futuros.
 2 Estimar el costo del equity:
 rE = rf + βE (RM − rf )
 3 Descontar los FCFE utilizando rE .
 N
 X FCFEt TV
 Valor Equity = t
 +
 t=1
 (1 + r E ) (1 + rE )N
Resultado
El valor obtenido corresponde directamente al patrimonio de los accionistas.
 Prof: Augusto Orellana Clase 24: Evaluación 25 / 27

[pág. 26]
Resumen de los Tres Métodos
 Método Flujo utilizado Resultado
 WACC UFCF Valor Empresa
 APV UFCF + Escudo Fis- Valor Empresa
 cal
 FCFE Flujo al Equity Valor del Equity
Mensaje Final
Si los supuestos son consistentes, WACC, APV y FCFE deberı́an entregar
esencialmente el mismo valor económico.
 Prof: Augusto Orellana Clase 24: Evaluación 26 / 27

[pág. 27]
Resumen de los Tres Métodos
 Prof: Augusto Orellana Clase 24: Evaluación 27 / 27

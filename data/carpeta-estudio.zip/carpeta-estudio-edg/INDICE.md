# Índice del material

Archivos de texto incluidos en esta carpeta.


## 20_clases/DE_Dirección_de_Empresas

- 20_clases/DE_Dirección_de_Empresas/8A305A-Ventajas Competitivas y Estrategias Genericas 1.md (8A305A-Ventajas Competitivas y Estrategias Genericas (1).pdf)
- 20_clases/DE_Dirección_de_Empresas/9A305A-Logro y Sustentación de Ventajas Competitivas 1.md (9A305A-Logro y Sustentación de Ventajas Competitivas (1).pdf)
- 20_clases/DE_Dirección_de_Empresas/10A305A-Modelos de Negocio 1.md (10A305A-Modelos de Negocio (1).pdf)
- 20_clases/DE_Dirección_de_Empresas/11A305A-Estrategia de Negocio 1.md (11A305A-Estrategia de Negocio (1).pdf)
- 20_clases/DE_Dirección_de_Empresas/12A305A-Mapas Estratégicos 1.md (12A305A-Mapas Estratégicos (1).pdf)
- 20_clases/DE_Dirección_de_Empresas/13A305A-Agenda Estratégica 1.md (13A305A-Agenda Estratégica (1).pdf)
- 20_clases/DE_Dirección_de_Empresas/13A305A-Estrategia Corporativa 1.md (13A305A-Estrategia Corporativa (1).pdf)
- 20_clases/DE_Dirección_de_Empresas/14A305A-Decisiones Diversificación 1.md (14A305A-Decisiones Diversificación (1).pdf)
- 20_clases/DE_Dirección_de_Empresas/15A305A-Concepto de Implementacion 1.md (15A305A-Concepto de Implementacion (1).pdf)
- 20_clases/DE_Dirección_de_Empresas/16A305A-Estructura Organizacional 1.md (16A305A-Estructura Organizacional (1).pdf)
- 20_clases/DE_Dirección_de_Empresas/17A-A305A-Control de Gestión 1.md (17A-A305A-Control de Gestión (1).pdf)
- 20_clases/DE_Dirección_de_Empresas/18A305A-Sistemas de Incentivos 1.md (18A305A-Sistemas de Incentivos (1).pdf)
- 20_clases/DE_Dirección_de_Empresas/19A305A-Sistemas de Evaluación de Desempeño 1.md (19A305A-Sistemas de Evaluación de Desempeño (1).pdf)
- 20_clases/DE_Dirección_de_Empresas/24A305A-Etica y Gestion de Empresas 1.md (24A305A-Etica y Gestion de Empresas (1).pdf)

## 20_clases/DP_Dirección_de_Personas

- 20_clases/DP_Dirección_de_Personas/Tema 1 - introducción.md (Tema 1 - introducción.pdf)
- 20_clases/DP_Dirección_de_Personas/Tema 2 - analisis y diseño de cargos.md (Tema 2 - analisis y diseño de cargos.pdf)
- 20_clases/DP_Dirección_de_Personas/Tema 3 - reclutamiento y selección.md (Tema 3 - reclutamiento y selección.pdf)
- 20_clases/DP_Dirección_de_Personas/Tema 4 - capacitación.md (Tema 4 - capacitación.pdf)
- 20_clases/DP_Dirección_de_Personas/Tema 5 - desempeño.md (Tema 5 - desempeño.pdf)
- 20_clases/DP_Dirección_de_Personas/Tema 6 - compensaciones incentivos beneficios.md (Tema 6 - compensaciones, incentivos, beneficios.pdf)
- 20_clases/DP_Dirección_de_Personas/Tema 7 - talento y desarrollo de carrera.md (Tema 7 - talento y desarrollo de carrera.pdf)
- 20_clases/DP_Dirección_de_Personas/Tema 8 - salidas.md (Tema 8 - salidas.pdf)
- 20_clases/DP_Dirección_de_Personas/Tema 9- Satisfacción Laboral y Cultura.md (Tema 9- Satisfacción Laboral y Cultura.pdf)
- 20_clases/DP_Dirección_de_Personas/Tema 10 - Seguridad e Higiene Disciplina.md (Tema 10 - Seguridad e Higiene, Disciplina.pdf)
- 20_clases/DP_Dirección_de_Personas/Tema 11 - Relaciones Laborales.md (Tema 11 - Relaciones Laborales.pdf)

## 20_clases/TF_Teoría_Financiera

- 20_clases/TF_Teoría_Financiera/L1 Intro.md (L1. Intro.pdf)
- 20_clases/TF_Teoría_Financiera/L2 Arbitraje y Derivados.md (L2. Arbitraje y Derivados.pdf)
- 20_clases/TF_Teoría_Financiera/L3 Decisiones.md (L3. Decisiones.pdf)
- 20_clases/TF_Teoría_Financiera/L4 Análisis MV.md (L4. Análisis MV.pdf)
- 20_clases/TF_Teoría_Financiera/L5 CAPM.md (L5. CAPM.pdf)
- 20_clases/TF_Teoría_Financiera/L6 APT.md (L6. APT.pdf)
- 20_clases/TF_Teoría_Financiera/L7HME y BF SV.md (L7.HME y BF SV.pdf)
- 20_clases/TF_Teoría_Financiera/L9 Estructura de Capital.md (L9 Estructura de Capital.pdf)
- 20_clases/TF_Teoría_Financiera/L10 Payout policy.md (L10 Payout policy.pdf)

## 20_clases/F2_Finanzas_II

- 20_clases/F2_Finanzas_II/1 Clase_1 Fundamentos.md (1. Clase_1 Fundamentos.pdf)
- 20_clases/F2_Finanzas_II/2 Clase_2 Financial Manager.md (2. Clase_2 Financial Manager.pdf)
- 20_clases/F2_Finanzas_II/3 Clase_3 Liquidez_rentabilidad_riesgo.md (3. Clase_3 Liquidez_rentabilidad_riesgo.pdf)
- 20_clases/F2_Finanzas_II/4 Clase_4 Riesgo-retorno.md (4. Clase_4 Riesgo-retorno.pdf)
- 20_clases/F2_Finanzas_II/5 Clase_5_Costo de Capital.md (5. Clase_5_Costo de Capital.pdf)
- 20_clases/F2_Finanzas_II/6 Clase_6_wacc capital strcuture.md (6. Clase_6_wacc & capital strcuture.pdf)
- 20_clases/F2_Finanzas_II/7 Clase_7_wacc Deuda Optima.md (7. Clase_7_wacc & Deuda Optima.pdf)
- 20_clases/F2_Finanzas_II/8 Clase_8_Analisis Financiero.md (8. Clase_8_Analisis Financiero.pdf)
- 20_clases/F2_Finanzas_II/9 Clase_9_Razones Financieras.md (9. Clase_9_Razones Financieras.pdf)
- 20_clases/F2_Finanzas_II/10 Clase_10_NVIDIA.md (10. Clase_10_NVIDIA.pdf)
- 20_clases/F2_Finanzas_II/11 Clase_11_CCU.md (11. Clase_11_CCU.pdf)
- 20_clases/F2_Finanzas_II/11 Clase_11_CCUb.md (11. Clase_11_CCUb.pdf)
- 20_clases/F2_Finanzas_II/11 Clase_11_CCUc.md (11. Clase_11_CCUc.pdf)
- 20_clases/F2_Finanzas_II/12 Clase_12_Planificacion Financiera.md (12. Clase_12_Planificacion Financiera.pdf)
- 20_clases/F2_Finanzas_II/13 Clase_13_Crecimiento y Financiamiento.md (13. Clase_13_Crecimiento y Financiamiento.pdf)
- 20_clases/F2_Finanzas_II/14 Clase_14_Patrones de Financiamiento.md (14. Clase_14_Patrones de Financiamiento.pdf)
- 20_clases/F2_Finanzas_II/15 Clase_15_Patrones de Financiamiento Roher.md (15. Clase_15_Patrones de Financiamiento Roher.pdf)
- 20_clases/F2_Finanzas_II/16 Clase_16_Modelos de Financiamiento.md (16. Clase_16_Modelos de Financiamiento.pdf)
- 20_clases/F2_Finanzas_II/17 Clase_17_Financiamiento de Largo Plazo.md (17. Clase_17_Financiamiento de Largo Plazo.pdf)
- 20_clases/F2_Finanzas_II/18 Clase_18_Administracion del Inventario.md (18. Clase_18_Administracion del Inventario.pdf)
- 20_clases/F2_Finanzas_II/19 Clase_19_Administacion de Credito-1.md (19. Clase_19_Administacion de Credito-1.pdf)
- 20_clases/F2_Finanzas_II/20 Clase_20_Administacion de Caja.md (20. Clase_20_Administacion de Caja.pdf)
- 20_clases/F2_Finanzas_II/21 Clase_21_Determinacion de Flujos.md (21. Clase_21_Determinacion de Flujos.pdf)
- 20_clases/F2_Finanzas_II/23 Clase_23_ Criterios de Evaluacion de Proyectos.md (23. Clase_23_ Criterios de Evaluacion de Proyectos.pdf)
- 20_clases/F2_Finanzas_II/24 Clase_24_ Evaluacion de Proyectos y Empresas-1.md (24. Clase_24_ Evaluacion de Proyectos y Empresas-1.pdf)
- 20_clases/F2_Finanzas_II/25 Clase_25_Casos Especiales-1.md (25. Clase_25_Casos Especiales-1.pdf)
- 20_clases/F2_Finanzas_II/26 Clase_26_Opciones_Reales-1.md (26. Clase_26_Opciones_Reales-1.pdf)
- 20_clases/F2_Finanzas_II/Clase 27 Multiples.md (Clase 27. Multiples.pdf)

## 20_clases/FM_Fundamentos_de_Marketing

- 20_clases/FM_Fundamentos_de_Marketing/Clase Estrategias de Precios V12.md (Clase  Estrategias de Precios V1.2.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase N1 Clase introductoria v2023 IIpptx.md (Clase N°1 Clase introductoria v2023 II.pptx.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase N3 Modelos de negocios.md (Clase N°3 Modelos de negocios.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase N4 Estrat Competitivas y Centralidad en el cliente VA.md (Clase N°4  Estrat Competitivas y Centralidad en el cliente VA.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase N15 marketing digital v2023 2sem.md (Clase N°15 marketing digital v2023 2°sem.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase N18 Etica y Responsabilidad Social Empresarial v2023 2 sem.md (Clase N°18 Etica y Responsabilidad Social Empresarial v2023 2 sem.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase de Comunicaciones v2023 v1-1.md (Clase de Comunicaciones v2023 v1-1.pdf)

## 20_clases/FM

- 20_clases/FM (Clase de Repaso Prueba 1.pptx; no convertido (no es PDF))

## 20_clases/FM_Fundamentos_de_Marketing

- 20_clases/FM_Fundamentos_de_Marketing/Clase de estrategias de marcas v2 2 sem 2023.md (Clase de estrategias de marcas v2 2 sem 2023.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase de repaso examen 2023.md (Clase de repaso examen 2023.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase de repaso prueba 2.md (Clase de repaso prueba 2.pdf)

## 20_clases/FM

- 20_clases/FM (Clase de repaso prueba 2.pptx; no convertido (no es PDF))

## 20_clases/FM_Fundamentos_de_Marketing

- 20_clases/FM_Fundamentos_de_Marketing/Clase introductoria.md (Clase introductoria.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase n5 Conducta del consumidor y shopper V23.md (Clase n°5 Conducta del consumidor y shopper V2.3.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase n6 Segmentación de mercado v2023 2osem.md (Clase n°6 Segmentación de mercado v2023 2osem.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase n7 Investigación de mercado VA.md (Clase n°7 Investigación de mercado VA.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase n8 Posicionamiento v2sem 2023.md (Clase n°8 Posicionamiento v2sem 2023.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase n10 Estrategia de productos v20232.md (Clase n°10 Estrategia de productos v20232.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase n12 Estrategias Servicios 2 sem 2123.md (Clase n°12 Estrategias Servicios 2 sem 2123.pdf)
- 20_clases/FM_Fundamentos_de_Marketing/Clase n13 Canales de Distribución V2023 2sem v2.md (Clase n°13 Canales de Distribución V2023 2sem v2.pdf)

## 20_clases/MA_Marketing_Analytics

- 20_clases/MA_Marketing_Analytics/clase1_Analytics Canvas.md (clase1_Analytics Canvas .pdf)
- 20_clases/MA_Marketing_Analytics/clase2_Analytics Canvas.md (clase2_Analytics Canvas .pdf)
- 20_clases/MA_Marketing_Analytics/clase3_Analytics Canvas.md (clase3_Analytics Canvas .pdf)
- 20_clases/MA_Marketing_Analytics/clase4_Analytics Canvas.md (clase4_Analytics Canvas.pdf)
- 20_clases/MA_Marketing_Analytics/clase5_P1_Analytics 2024.md (clase5_P1_Analytics 2024 .pdf)
- 20_clases/MA_Marketing_Analytics/clase5_P2_Analytics 2024.md (clase5_P2_Analytics 2024.pdf)
- 20_clases/MA_Marketing_Analytics/clase6_Analytics Canvas.md (clase6_Analytics Canvas.pdf)
- 20_clases/MA_Marketing_Analytics/clase7_Analytics Canvas.md (clase7_Analytics Canvas .pdf)
- 20_clases/MA_Marketing_Analytics/clase8_Analytics Canvas.md (clase8_Analytics Canvas.pdf)
- 20_clases/MA_Marketing_Analytics/clase9_Analytics Canvas.md (clase9_Analytics Canvas.pdf)
- 20_clases/MA_Marketing_Analytics/clase10_Analytics Canvas.md (clase10_Analytics Canvas  .pdf)
- 20_clases/MA_Marketing_Analytics/clase11_Analytics Canvas.md (clase11_Analytics Canvas .pdf)
- 20_clases/MA_Marketing_Analytics/clase12_Analytics Canvas.md (clase12_Analytics Canvas.pdf)
- 20_clases/MA_Marketing_Analytics/clase13_Analytics Canvas.md (clase13_Analytics Canvas  .pdf)
- 20_clases/MA_Marketing_Analytics/clase14_Analytics Canvas.md (clase14_Analytics Canvas  .pdf)
- 20_clases/MA_Marketing_Analytics/clase15_Analytics Canvas.md (clase15_Analytics Canvas.pdf)
- 20_clases/MA_Marketing_Analytics/clase16_Analytics Canvas.md (clase16_Analytics Canvas.pdf)
- 20_clases/MA_Marketing_Analytics/clase17_Analytics Canvas.md (clase17_Analytics Canvas.pdf)
- 20_clases/MA_Marketing_Analytics/clase18_Analytics Canvas.md (clase18_Analytics Canvas.pdf)
- 20_clases/MA_Marketing_Analytics/clase19_Analytics Canvas.md (clase19_Analytics Canvas   .pdf)
- 20_clases/MA_Marketing_Analytics/clase20_Analytics Canvas.md (clase20_Analytics Canvas .pdf)
- 20_clases/MA_Marketing_Analytics/clase21_Analytics Canvas.md (clase21_Analytics Canvas.pdf)
- 20_clases/MA_Marketing_Analytics/clase22_Analytics Canvas.md (clase22_Analytics Canvas.pdf)
- 20_clases/MA_Marketing_Analytics/clase23 Analytics Canvas.md (clase23 Analytics Canvas .pdf)
- 20_clases/MA_Marketing_Analytics/clase24 Analytics Canvas.md (clase24 Analytics Canvas.pdf)
- 20_clases/MA_Marketing_Analytics/clase25_Analytics Canvas.md (clase25_Analytics Canvas .pdf)
- 20_clases/MA_Marketing_Analytics/clase26_Analytics Canvas.md (clase26_Analytics Canvas .pdf)
- 20_clases/MA_Marketing_Analytics/clase27_P1_Analytics Canvas.md (clase27_P1_Analytics Canvas.pdf)
- 20_clases/MA_Marketing_Analytics/clase27_P2_Analytics Canvas.md (clase27_P2_Analytics Canvas .pdf)
- 20_clases/MA_Marketing_Analytics/clase28 Analytics Canvas.md (clase28 Analytics Canvas  .pdf)
- 20_clases/MA_Marketing_Analytics/clase29 Analytics Canvas.md (clase29 Analytics Canvas  .pdf)

## 10_manuales/Manual_Direccion

- 10_manuales/Manual_Direccion/parte_01_pags_1-57.md (03_MANUAL_ULTIMATE_DIRECCION_EDG_2027_V2_REORDENADO p.1-57)
- 10_manuales/Manual_Direccion/parte_02_pags_58-108.md (03_MANUAL_ULTIMATE_DIRECCION_EDG_2027_V2_REORDENADO p.58-108)
- 10_manuales/Manual_Direccion/parte_03_pags_109-160.md (03_MANUAL_ULTIMATE_DIRECCION_EDG_2027_V2_REORDENADO p.109-160)
- 10_manuales/Manual_Direccion/parte_04_pags_161-211.md (03_MANUAL_ULTIMATE_DIRECCION_EDG_2027_V2_REORDENADO p.161-211)
- 10_manuales/Manual_Direccion/parte_05_pags_212-261.md (03_MANUAL_ULTIMATE_DIRECCION_EDG_2027_V2_REORDENADO p.212-261)
- 10_manuales/Manual_Direccion/parte_06_pags_262-279.md (03_MANUAL_ULTIMATE_DIRECCION_EDG_2027_V2_REORDENADO p.262-279)

## 10_manuales/Manual_Finanzas

- 10_manuales/Manual_Finanzas/parte_01_pags_1-64.md (02_MANUAL_ULTIMATE_FINANZAS_EDG_2027_V2_FORMULAS_CLARAS p.1-64)
- 10_manuales/Manual_Finanzas/parte_02_pags_65-127.md (02_MANUAL_ULTIMATE_FINANZAS_EDG_2027_V2_FORMULAS_CLARAS p.65-127)
- 10_manuales/Manual_Finanzas/parte_03_pags_128-181.md (02_MANUAL_ULTIMATE_FINANZAS_EDG_2027_V2_FORMULAS_CLARAS p.128-181)
- 10_manuales/Manual_Finanzas/parte_04_pags_182-236.md (02_MANUAL_ULTIMATE_FINANZAS_EDG_2027_V2_FORMULAS_CLARAS p.182-236)
- 10_manuales/Manual_Finanzas/parte_05_pags_237-256.md (02_MANUAL_ULTIMATE_FINANZAS_EDG_2027_V2_FORMULAS_CLARAS p.237-256)

## 10_manuales/Manual_Marketing

- 10_manuales/Manual_Marketing/parte_01_pags_1-67.md (01_MANUAL_ULTIMATE_MARKETING_EDG_2027_V2_FORMULAS_Y_METRICAS_CLARAS p.1-67)
- 10_manuales/Manual_Marketing/parte_02_pags_68-125.md (01_MANUAL_ULTIMATE_MARKETING_EDG_2027_V2_FORMULAS_Y_METRICAS_CLARAS p.68-125)
- 10_manuales/Manual_Marketing/parte_03_pags_126-182.md (01_MANUAL_ULTIMATE_MARKETING_EDG_2027_V2_FORMULAS_Y_METRICAS_CLARAS p.126-182)
- 10_manuales/Manual_Marketing/parte_04_pags_183-245.md (01_MANUAL_ULTIMATE_MARKETING_EDG_2027_V2_FORMULAS_Y_METRICAS_CLARAS p.183-245)
- 10_manuales/Manual_Marketing/parte_05_pags_246-300.md (01_MANUAL_ULTIMATE_MARKETING_EDG_2027_V2_FORMULAS_Y_METRICAS_CLARAS p.246-300)
- 10_manuales/Manual_Marketing/parte_06_pags_301-338.md (01_MANUAL_ULTIMATE_MARKETING_EDG_2027_V2_FORMULAS_Y_METRICAS_CLARAS p.301-338)

## 30_examenes_anteriores/EG-Administracion-Enero-2022.md

- 30_examenes_anteriores/EG-Administracion-Enero-2022.md (EG-Administracion-Enero-2022.pdf)

## 30_examenes_anteriores/Enunciado-Adm-agosto-2025.md

- 30_examenes_anteriores/Enunciado-Adm-agosto-2025.md (Enunciado-Adm-agosto-2025.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/Enunciado-Adm-enero-2025.md

- 30_examenes_anteriores/Enunciado-Adm-enero-2025.md (Enunciado-Adm-enero-2025.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/Enunciado-Adm-enero-2026.md

- 30_examenes_anteriores/Enunciado-Adm-enero-2026.md (Enunciado-Adm-enero-2026.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/Enunciado-Examen-de-grado-agosto-2024.md

- 30_examenes_anteriores/Enunciado-Examen-de-grado-agosto-2024.md (Enunciado-Examen-de-grado-agosto-2024.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/Examen-Grado-Administracion-Enero-2024.md

- 30_examenes_anteriores/Examen-Grado-Administracion-Enero-2024.md (Examen-Grado-Administracion-Enero-2024.pdf)

## 30_examenes_anteriores/Examen-de-Administracion-Agosto-2021-Parte-I-y-II-618a9a6c56319.md

- 30_examenes_anteriores/Examen-de-Administracion-Agosto-2021-Parte-I-y-II-618a9a6c56319.md (Examen-de-Administracion-Agosto-2021-Parte-I-y-II-618a9a6c56319.pdf)

## 30_examenes_anteriores/Examen-de-Administracion-Enero-2023.md

- 30_examenes_anteriores/Examen-de-Administracion-Enero-2023.md (Examen-de-Administracion-Enero-2023.pdf)

## 30_examenes_anteriores/Examen-de-Grado-Administracion-Agosto-2022.md

- 30_examenes_anteriores/Examen-de-Grado-Administracion-Agosto-2022.md (Examen-de-Grado-Administracion-Agosto-2022.pdf)

## 30_examenes_anteriores/Examen-de-Grado-Administracion-Agosto-2023.md

- 30_examenes_anteriores/Examen-de-Grado-Administracion-Agosto-2023.md (Examen-de-Grado-Administracion-Agosto-2023.pdf)

## 30_examenes_anteriores/Examen-de-Grado-Administracion-Agosto-2026.md

- 30_examenes_anteriores/Examen-de-Grado-Administracion-Agosto-2026.md (Examen-de-Grado-Administracion-Agosto-2026.pdf)

## 30_examenes_anteriores/administracin-agosto-2018.md

- 30_examenes_anteriores/administracin-agosto-2018.md (administracin-agosto-2018.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/administracin-enero-2018-5.md

- 30_examenes_anteriores/administracin-enero-2018-5.md (administracin-enero-2018-5.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/administracin-enero-2020.md

- 30_examenes_anteriores/administracin-enero-2020.md (administracin-enero-2020.pdf)

## 30_examenes_anteriores/agosto-2014.md

- 30_examenes_anteriores/agosto-2014.md (agosto-2014.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/agosto-2015.md

- 30_examenes_anteriores/agosto-2015.md (agosto-2015.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/agosto-2016.md

- 30_examenes_anteriores/agosto-2016.md (agosto-2016.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/agosto-2017-administracin.md

- 30_examenes_anteriores/agosto-2017-administracin.md (agosto-2017-administracin.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/agosto-2019.md

- 30_examenes_anteriores/agosto-2019.md (agosto-2019.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/enero-2015.md

- 30_examenes_anteriores/enero-2015.md (enero-2015.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/enero-2016.md

- 30_examenes_anteriores/enero-2016.md (enero-2016.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/enero-2017-2.md

- 30_examenes_anteriores/enero-2017-2.md (enero-2017-2.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/enero-2019.md

- 30_examenes_anteriores/enero-2019.md (enero-2019.pdf; OCR (escaneo): pueden haber errores de lectura)

## 30_examenes_anteriores/enunciado-e-g--1-21-parte-1-y-2.md

- 30_examenes_anteriores/enunciado-e-g--1-21-parte-1-y-2.md (enunciado-e-g--1-21-parte-1-y-2.pdf)

## 30_examenes_anteriores/parte-1-2-3-administracin-agosto-2020.md

- 30_examenes_anteriores/parte-1-2-3-administracin-agosto-2020.md (parte-1-2-3-administracin-agosto-2020.pdf)

## 30_examenes_anteriores/semestre-1-2014.md

- 30_examenes_anteriores/semestre-1-2014.md (semestre-1-2014.pdf; OCR (escaneo): pueden haber errores de lectura)

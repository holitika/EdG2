# Manual de Marketing · parte 4 (páginas 183-245)

Fuente: 01_MANUAL_ULTIMATE_MARKETING_EDG_2027_V2_FORMULAS_Y_METRICAS_CLARAS

[pág. 183]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2025 | pregunta 1
 Convocatoria 2 | página original 440 | Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Actualmente, On tiene una participación global inferior al 1% y aproxima
 damente un 8% en Estados Unidos, lo
 que muestra un amplio margen de crecimiento. Esto ha [levado al Directorio
 a plantearse una nueva estrategia:
 la expansión hacia el segmento de corredores ocasionales, que representan
 el grueso del mercado. Este segmento
 está representado por personas que corren de forma recreativa o simpleme
 nte usan zapatillas deportivas como
 parte de su estilo de vida diario. El desafío que ha puesto el Directorio
 se condiciona a que la marca no pierda
 su esencia premium, su compromiso ambiental y su diferenciación basada en
 la comodidad y el bienestar.
 La competencia en este mercado es muy fuerte. Nike mantiene un posiciona
 miento claro como la marca del
 rendimiento extremo, asociándose con atletas élite y rompiendo límites
 físicos a través de la innovación
 científica. Adidas, por su parte, combina rendimiento con un estilo urbano aspiracion
 al, integrando tecnologías
 como Boost* y colaboraciones con marcas de moda. Ambas marcas tienen presencia
 consolidada en todos los
 segmentos, desde profesionales hasta ocasionales.
 On, en cambio, ha cultivado un nicho claro: corredores serios que valoran su
 salud física y buscan productos
 sostenibles, diferenciándose por priorizar la comodidad, el diseño innovador
 y la tecnología ecológica. El desafío
 es cómo trasladar esta propuesta a un público más ocasional, menos especializ
 ado, sin diluir su esencia.
 Preguntas:
 1. A partir de la información del caso, identifique y explique claramente qué variables
 de segmentación
 psicográficas y conductuales debería considerar On para definir con precisión
 el perfil de estos corredores
 ocasionales. Además, caracterice a estos corredores ocasionales de acuerdo
 a estas variables. Justifique
 claramente su respuesta.
 2. A partir de la información del caso y del nuevo segmento objetivo y
 condiciones planteadas por el
 Directorio, redacte la declaración de posicionamiento de On dirigida a dicho
 segmento de corredores
 ocasionales, considerando sus características y motivaciones. Además, explique
 claramente en qué aspectos
 claves esta declaración se diferencia del posicionamiento actual de On y del
 posicionamiento de Nike y
 Adidas.
 * Boost esuna tecnología de amortiguación desarrollada por Adidas
 en colaboración con la empresa química BASF. Se basa en un material
 llamado TPU expandido (poliuretano termoplástico expandido)
 , que se presenta como pequeñas cápsulas que, al fusionarse,
 suela con alta capacidad de retomo de energía y amortiguación crean una
 duradera
 3
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 183

[pág. 184]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2026 | pregunta 3
 Convocatoria 1 | página original 456 | Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N%3
 La industria mundial del vino atraviesa una transformación estructural marcada por una doble presión simultánea: una
 caída sostenida en el volumen consumido y un aumento persistente de los costos y la volatilidad productiva. De acuerdo
 con la Organización Internacional del Vino (OTV), el consumo global disminuyó desde 248 millones de hectólitros en
 2017 a una proyección de 214 millones en 2025, lo que representa una contracción acumulada del 14%, el declive más
 prolongado registrado en los últimos cincuenta años.
 Más allá del volumen, el cambio es cualitativo y cultural. El vino ya no se consume de la misma manera ni en los
 mismos contextos. Desde comienzos de la década del 2000, se observa una reducción significativa del consumo durante
 las comidas y un aumento del consumo fuera de ellas, en contextos más fragmentados y menos ritualizados. Este
 fenómeno se ve reforzado por tendencias sociodemográficas: disminución del tamaño de los hogares en países OCDE
 (de 3,2 a 2,1 personas entre 2000 y 2024), menor frecuencia de comidas familiares y mayor dispersión de los horarios
 laborales.
 Incluso dentro de los momentos de consumo, el vino enfrenta una competencia creciente por ocasiones. Cerveza
 artesanal y cócteles sofisticados han adoptado códigos históricamente asociados al vino —relato de origen, narrativa
 sensorial, diseño de envases— desplazándolo como opción preferente. Sin embargo, el principal sustituto no alcohólico
 ha sido el agua embotellada premium, categoría que crece a una tasa anual del 6,5% desde 2018.
 Desde una perspectiva generacional, el desafío es aún más profundo. En mercados maduros, los Baby Boomers (nacidos
 1946-1964) concentran el 62% del volumen total consumido. Cada cohorte posterior muestra una caída significativa en
 el consumo de vino respecto de la generación anterior a igual edad: Generación X (nacidos entre 1965-1980, -35%),
 Millennials (nacidos entre 1981-1996, -48%) y se espera algo similar en la Generación Z (nacidos entre 1997-2012, -
 60%). Estudios recientes indican que Millennials y Gen Z prefieren cócteles premezclados, bebidas RTD (ready-to-
 drink), spritzers! y alternativas sin o con bajo contenido alcohólico. Entre las razones destacan la percepción del vino
 como una bebida “demasiado formal”, la complejidad del proceso de selección, la baja transparencia en información
 nutricional y su escasa alineación con tendencias de moderación y bienestar.
 Paradójicamente, este contexto ha dado origen a un segmento emergente que privilegia “beber menos, pero mejor”.
 Estos consumidores reducen la frecuencia, pero están dispuestos a pagar precios premium por vinos con historia,
 autenticidad, atributos de sustentabilidad (orgánico, biodinámico), formatos que favorecen la moderación y experiencias
 diferenciadas, como el enoturismo y los clubes de venta directa (D2C). En paralelo, el mercado de vinos Sin/Poco
 Alcohol (No/Low Alcohol) creció un 13% en volumen durante 2024 en los diez principales mercados del mundo, y el
 e-commerce de vino ya representa el 18% de las ventas en mercados desarrollados, frente al 6% en 2019.
 En este contexto opera Viña Ladera, un productor chileno de tamaño medio con ventas anuales entre USD 35 y 45
 millones. Su estructura de ventas se concentra en exportaciones (70%), principalmente a Estados Unidos (35%), Reino
 Unido (20%) y Brasil (15%), mientras que el mercado doméstico representa el 30% restante.
 El portafolio actual de la viña se distribuye en tres grandes líneas. La línea Base, con precios a público entre USD 7 y
 12 la botella, concentra el 75% del volumen producido (aproximadamente 850 mil cajas de 9 litros) y opera con
 márgenes de 28-32%. Se compone principalmente de variedades tradicionales (Cabernet Sauvignon, Merlot, Sauvignon
 Blanc y Chardonnay) y se distribuye masivamente a través de importadores los que a su vez le distribuyen a
 supermercados y mayoristas, con alta dependencia de promociones. Su posicionamiento es percibido como “confiable,
 pero genérico”.
 * Un Spritzer (0 Spritz) es una bebida refrescante y burbujeante a base de vino (generalmente blanco) y agua con gas, que se sirve fría, con
 hielo, y a menudo se adorna con limón o frutas
 6
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 184

[pág. 185]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2026 | pregunta 3
 Convocatoria 1 | página original 457 | Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 La línea Gran Reserva, con precios a público entre USD 15 y 22 la botella, representa el 20% del volumen producido
 (225 mil cajas) y genera márgenes superiores (3842%). Incluye variedades como Carmenere, Syrah y Pinot Noir, y se
 distribuye de manera directa y selectiva en tiendas especializadas y restaurantes de nivel medio-alto. Su narrativa se
 apoya en la “calidad del vino chileno”, pero carece de una diferenciación clara frente a competidores similares.
 Finalmente, la venta de vino a granel representa el 5% del volumen producido, con márgenes bajos (8—12%) y cumple
 principalmente una función táctica de manejo de inventarios, sin aportar valor de marca.
 Desde el punto de vista de marcas, Viña Ladera presenta debilidades relevantes. El reconocimiento asistido de marca
 (brand awareness) en mercados clave alcanza solo un 18% (frente a 35-45% de competidores principales), mientras que
 el awareness espontáneo es de apenas 4%. Su Net Promoter Score (NPS) es +22, considerado neutral, y las asociaciones
 predominantes se limitan a “vino chileno” y “buena relación precio-calidad”, sin atributos distintivos claros.
 Durante 2025, la viña enfrentó una presión creciente por parte de sus importadores en Estados Unidos y Reino Unido,
 quienes exigieron mayores descuentos para sostener promociones al consumidor final. Estos importadores operan
 portafolios amplios (40-80 marcas), privilegian alta rotación con mínimo soporte de marketing y buscan márgenes
 objetivo entre 35% y 40%.
 Frente a este escenario, el Directorio definió para 2026 un mandato estratégico claro. En el plano financiero, se exige
 un crecimiento mínimo de 8% en valor de ventas ($), mantener un margen EBITDA de 16% y reducir la dependencia
 de los dos principales importadores desde el 55% actual a menos del 45% en un plazo de tres años. Como restricciones,
 se establece que no habrá inversión en nueva capacidad productiva y la viña no le comprará vino a terceros.
 Se pide responder:
 1. Apartir de los cambios estructurales en el consumo de vino descritos en el caso conteste las siguientes preguntas:
 a. Evalúe críticamente el portafolio actual de Viña Ladera.
 b. Proponga una redefinición del foco estratégico de segmentación que permita cumplir simultáneamente los
 objetivos de crecimiento en valor de ventas y margen, considerando las restricciones del Directorio.
 e. Señale y explique además los dos principales riesgos de su propuesta. Justifique claramente su respuesta.
 2. A partir de la información del caso, proponga y justifique dos decisiones concretas de estrategia de canales que
 Viña Ladera podría implementar para lograr el requerimiento del Directorio. Señale y explique además el principal
 riesgo de cada decisión propuesta. Justifique claramente su respuesta.
 2 El Net Promoter Score (NPS) es un indicador de lealtad y recomendación del cliente, muy usado en marketing, experiencia
 de cliente y estrategia. Mide qué tan dispuestos están tus clientes a recomendar tu producto, servicio o empresa a otras
 personas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 185

[pág. 186]
Marketing - versión clara y reordenada
 Marketing Analytics - 35 preguntas
Examen de Grado UC | materia, preguntas y respuestas 186

[pág. 187]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2012 | pregunta 6
 Convocatoria 1 | página original 98 | ANOVA y análisis factorial
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA Nº6
 El Banco X es uno de los principales bancos financieros del país, con una participación de mercado de 18% en colocaciones.
 La estrategia del Banco X, hasta el momento, ha sido dirigir sus esfuerzos a personas de Grupos Socio Económicos (GSE)
 ABC1 y C2. Sin embargo, en el último tiempo el Directorio y la alta gerencia del Banco han planteado la necesidad de
 ampliar el grupo objetivo hacia los GSE C3 y D, para así lograr los objetivos de crecimiento que se han planteado.
 Con el propósito de evaluar esta oportunidad, el Banco X decide realizar un estudio de mercado, consistente en una encuesta
 a personas mayores de 18 años, de los GSE C3 y D. Un objetivo importante del estudio es conocer la imagen que tienen las
 personas de los bancos, en general y también en relación a las casas comerciales que ofrecen productos y servicios
 financieros (por ejemplo, grandes tiendas tales como Falabella, Paris o Ripley). Para capturar esta información, se pidió a los
 encuestados que indicaran, a través de encuestas presenciales en hogares, qué tan de acuerdo o en desacuerdo están con 10
 afirmaciones sobre los bancos y sobre las casas comerciales. Con las respuestas de 400 personas, se realizó un análisis de
 factores (con método de componentes principales, y rotación Varimax a partir de las cargas factoriales o loadings), con los
 siguientes resultados:
 Cuadro Nº1: Resultados del Análisis de Factores
 Variable (Afirmación) Factor 1 Factor 2 Factor 3 Factor 4 Comunalidad*
 1. Los bancos son confiables 0,881 0,048 0,078 -0,162 0,811
 2. Los bancos son seguros 0,870 0,135 0,124 -0,064 0,794
 3. Los productos de casas comerciales son
 0,027 0,730 0,016 0,137 0,552
 más flexibles que los de los bancos
 4. Las casas comerciales son más agiles que
 0,053 0,763 -0,037 0,080 0,593
 los bancos
 5. Las casas comerciales otorgan créditos
 0,007 0,711 0,007 0,040 0,507
 con más facilidad que los bancos
 6. Los bancos tienen horarios convenientes -0,116 -0,081 0,803 -0,131 0,682
 7. Los bancos tienen una buena cobertura de
 0,282 -0,077 0,705 0,060 0,586
 sucursales
 8. Los bancos tienen buenas ubicaciones 0,183 0,143 0,701 -0,073 0,551
 9. Los productos de los bancos son
 -0,090 0,110 -0,124 0,751 0,600
 complicados de entender
 10. Los bancos piden muchos papeles -0,053 0,170 -0,033 0,784 0,647
 Varianza (valor propio o eigenvalue) 1,92 1,79 1,75 1,41 6,87
 % Varianza explicada 17,4% 16,2% 15,9% 12,9% 62,4%
 * Indica qué porcentaje de la varianza de cada variable es explicada por los factores retenidos en el análisis.
 A partir del análisis de factores se calcularon los puntajes de los 4 factores para cada participante que contestó la encuesta, y
 luego se hizo un análisis de varianza (ANOVA) al 95% de confianza, para ver si había diferencia en los puntajes promedio
 de factores entre quienes son clientes de un banco (es decir, poseen cuenta de ahorro, tarjeta vista, depósitos a plazo, cuenta
 corriente, tarjeta bancaria u otro producto de un banco) y quienes no lo son. El siguiente Cuadro Nº2 muestra los resultados
 del test ANOVA para los 4 factores.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 187

[pág. 188]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2012 | pregunta 6
 Convocatoria 1 | página original 99 | ANOVA y análisis factorial
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 Cuadro Nº2: Resultados del Análisis de Varianza (ANOVA)
 Factor 1 Factor 2 Factor 3 Factor 4
 Valor “p” del test ANOVA 0.000 0.861 0.136 0.031
 Puntajes de factores (en promedio):
 Clientes de bancos 0.1757 -0.0080 -0.0700 -0.1011
 No clientes de bancos -0.2001 0.0090 0.0797 0.1151
 A usted se le pide responder:
 1. Suponga que usted es Gerente de la empresa de investigación de mercados, y debe presentar los resultados del estudio al
 Gerente del Banco X. ¿Cuáles son las 3 conclusiones más importantes del Análisis de Factores presentado en el Cuadro
 Nº1, que usted señalaría al Gerente del Banco X?.
 2. El Gerente del Banco X, viendo los resultados de los Cuadros Nº1 y Nº2, comentaba: “Dados estos resultados, lo que
 debemos hacer es asignar nuestros recursos de marketing a la captación de nuevos clientes basándonos en el beneficio de
 “seguridad”, ya que la percepción de un mayor nivel del Factor 1 (que se refiere a “seguridad”) es lo que más influye
 en que clientes potenciales de bancos se conviertan en clientes reales de bancos, dentro de los 4 Factores analizados”
 ¿Está usted de acuerdo con la afirmación del Gerente del Banco X? ¿Por qué? Justifique su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 188

[pág. 189]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2012 | pregunta 6
 Convocatoria 1 | página original 100 | ANOVA y análisis factorial
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 14
 ANEXO
 TABLAS DE MATEMÁTICAS FINANCIERAS
 Tabla Nº 1
 1
 Valor Presente de $1 recibido al final de n períodos: =
 (1 + r) n
 n -n
 PVI r,n = 1/(1+r) = (1 + r)
 Período 1% 2% 3% 4% 5% 6% 7% 8% 9% 10% 12% 14% 15% 16% 18% 20% 24% 28% 32% 36%
 1 .9901 .9804 .9709 .9615 .9524 .9434 .9346 .9259 .9174 .9091 .8929 .8772 .8696 .8621 .8475 .8333 .8065 .7813 .7576 .7353
 2 .9803 .9612 .9426 .9246 .9070 .8900 .8734 .8573 .8417 .8264 .7972 .7695 .7561 .7432 .7182 .6944 .6504 .6104 .5739 .5407
 3 .9706 .9423 .9151 .8890 .8638 .8396 .8163 .7938 .7722 .7513 .7118 .6750 .6575 .6407 .6086 .5787 .5245 .4768 .4348 .3975
 4 .9610 .9238 .8885 .8548 .8227 .7921 .7629 .7350 .7084 .6830 .6355 .5921 .5718 .5523 .5158 .4823 .4230 .3725 .3294 .2923
 5 .9515 .9057 .8626 .8219 .7835 .7473 .7130 .6806 .6499 .6209 .5674 .5194 .4972 .4761 .4371 .4019 .3411 .2910 .2495 .2149
 6 .9420 .8880 .8375 .7903 .7462 .7050 .6663 .6302 .5963 .5645 .5066 .4556 .4323 .4104 .3704 .3349 .2751 .2274 .1890 .1580
 7 .9327 .8706 .8131 .7599 .7107 .6651 .6227 .5835 .5470 .5132 .4523 .3996 .3759 .3538 .3139 .2791 .2218 .1776 .1432 .1162
 8 .9235 .8535 .7894 .7307 .6768 .6274 .5820 .5403 .5019 .4665 .4039 .3506 .3269 .3050 .2660 .2326 .1789 .1388 .1085 .0854
 9 .9143 .8368 .7664 .7026 .6446 .5919 .5439 .5002 .4604 .4241 .3606 .3075 .2843 .2630 .2255 .1938 .1443 .1084 .0822 .0628
 10 .9053 .8203 .7441 .6756 .6139 .5584 .5083 .4632 .4224 .3855 .3220 .2697 .2472 .2267 .1911 .1615 .1164 .0847 .0623 .0462
 11 .8963 .8043 .7224 .6496 .5847 .5268 .4751 .4289 .3875 .3505 .2875 .2366 .2149 .1954 .1619 .1346 .0938 .0662 .0472 .0340
 12 .8874 .7885 .7014 .6246 ..5568 .4970 .4440 .3971 .3555 .3186 .2567 .2076 .1869 .1685 .1372 .1122 .0757 .0517 .0357 .0250
 13 .8787 .7730 .6810 .6006 .5303 .4688 .4150 .3677 .3262 .2897 .2292 .1821 .1625 .1452 .1163 .0935 .0610 .0404 .0271 .0184
 14 .8700 .7579 .6611 .5775 .5051 .4423 .3878 .3405 .2892 .2633 .2046 .1597 .1413 .1252 .0985 .0779 .0492 .0316 .0205 .0135
 15 .8613 .7430 .6419 .5553 .4810 .4173 .3624 .3152 .2745 .2394 .1827 .1401 .1229 .1079 .0835 .0649 .0397 .0247 .0155 .0099
 16 .8528 .7284 .6232 .5339 .4581 .3936 .3387 .2919 .2519 .2176 .1631 .1229 .1069 .0930 .0708 .0541 .0320 .0193 .0118 .0073
 17 .8444 .7142 .6050 .5134 .4363 .3714 .3166 .2703 .2311 .1978 .1456 .1078 .0929 .0802 .0600 .0451 .0258 .0150 .0089 .0054
 18 .8360 .7002 .5874 .4936 .4155 .3503 .2959 .2502 .2120 .1799 .1300 .0946 .0808 .0691 .0508 .0376 .0208 .0118 .0068 .0039
 19 .8277 .6864 .5703 .4746 .3957 .3305 .2765 .2317 .1945 .1635 .1161 .0829 .0703 .0596 .0431 .0313 .0168 .0092 .0051 .0029
 20 .8195 .6730 .5537 .4564 .3769 .3118 .2584 .2145 .1784 .1486 .1037 .0728 .0611 .0514 .0365 .0261 .0135 .0072 .0039 .0021
 25 .7798 .6095 .4776 .3751 .2953 .2330 .1842 .1460 .1160 .0923 .0588 .0378 .0304 .0245 .0160 .0105 .0046 .0021 .0010 .0005
 30 .7419 .5521 .4120 .3083 .2314 .1741 .1314 .0994 .0754 .0573 .0334 .0196 .0151 .0116 .0070 .0042 .0016 .0006 .0002 .0001
 40 .6717 .4529 .3066 .2083 .1420 .0972 .0668 .0460 .0318 .0221 .0107 .0053 .0037 .0026 .0013 .0007 .0002 .0001 * *
 50 .6080 .3715 .2281 .1407 .0872 .0543 .0339 .0213 .0134 .0085 .0035 .0014 .0009 .0006 .0003 .0001 * * * *
 60 .5504 .3048 .1697 .0951 .0535 .0303 .0173 .0099 .0057 .0033 .0011 .0004 .0002 .0001 * * * * * *
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 189

[pág. 190]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2012 | pregunta 6
 Convocatoria 1 | página original 101 | ANOVA y análisis factorial
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 15
 Tabla Nº 2:
 Valor Presente de una Anualidad de $1 por período para n períodos:
 1 1 1 1 1
 1− VP = + + + ...
 (1 + r) (1 + r) 2 (1 + r) 3 (1 + r) n
 n 1 (1 + r) n
 PVIFA r,t = ∑ =
 n
 t =1 (1 + r) t r
 VP = ∑
 1
 t =1 (1 + r) t
 Número
 de pagos 1% 2% 3% 4% 5% 6% 7% 8% 9% 10% 12% 14% 15% 16% 18% 20% 24% 28%
 1 0.9901 0.9804 0.9709 0.9615 0.9524 0.9434 0.9346 0.9259 0.9174 0.9091 0.892.9 0.8772 0.8696 0.8621 0.8475 0.8333 0.8065 0.7813
 2 1.9704 1.9416 1.9135 1.8861 1.8594 1.8334 1.8080 1.7833 1.7591 1.7355 1.6901 1.6467 1.6257 1.6052 1.5656 1.5278 1.4568 1.3916
 3 2.9410 2.8839 2.8286 2.7751 2.7232 2.6730 2.6243 2.5771 2.5313 2.4869 2.4018 2.3216 2.2832 2.2459 2.1743 2.1065 1.9813 1.8684
 4 3.9020 3.8077 3.7171 3.6299 3.5460 3.4651 3.3872 3.3121 3.2397 3.1699 3.0373 2.9137 2.8550 2.7982 2.6901 2.5887 2.4043 2.2410
 5 4.8534 4.7135 4.5797 4.4518 4.3295 4.2124 4.1002 3.9927 3.8897 3.7908 3.6048 3.4331 3.3522 3.2743 3.1272 2.9906 2.7454 2.5320
 6 5.7955 5.6014 5.4172 5.2421 5.0757 4.9173 4.7665 4.6229 4.4859 4.3553 4.1114 3.8887 3.7845 3.6847 3.4976 3.3255 3.0205 2.7594
 7 6.7282 6.4720 6.2303 6.0021 5.7864 5.5824 5.3893 5.2064 5.0330 4.8684 4.5638 4.2883 4.1604 4.0386 3.8115 3.6046 3.2423 2.9370
 8 7.6517 7.3255 7.0197 6.7327 6.4632 6.2098 5.9713 5.7466 5.5348 5.3349 4.9676 4.6389 4.4873 4.3436 4.0776 3.8372 3.4212 3.0758
 9 8.5660 8.1622 7.7861 7.4353 7.1078 6.8017 6.5152 6.2469 5..9962 5.7590 5.3282 4.9464 4.7716 4.6065 4.3030 4.0310 3.5655 3.1842
 10 9.4713 8.9826 8.5302 8.1109 7.7217 7.3601 7.0236 6.7101 6.4177 6.1446 5.6502 5.2161 5.0188 4.8332 4.4941 4.1925 3.6819 3.2689
 11 10.3676 9.7868 9.2526 8.7605 8.3064 7.8869 7.4987 7.1390 6.8052 6.4951 5.9377 5.4527 5.2337 5.0286 4.6560 4.3271 3.7757 3.3351
 12 11.2551 10.5753 9.9540 9.3851 8.8633 8.3838 7.9427 7.5361 7.1607 6.8137 6.1944 5.6603 5.4206 5.1971 4.7932 4.4392 3.8514 3.3868
 13 12.1337 11.3484 10.6350 9.9856 9.3936 8.8527 8.3577 7.9038 7.4869 7.1034 6.4235 5.8424 5.5831 5.3423 4.9095 4.5327 3.9124 3.4272
 14 13.0037 12.1062 11.2961 10.5631 9.8986 9.2950 8.7455 8.2442 7.7862 7.3667 6.6282 6.0021 5.7245 5.4675 5.0081 4.6106 3.9616 3.4587
 15 13.8651 12.8493 11.9379 11.1184 10.3797 9.7122 9.1079 8.5595 8.0607 7.6061 6.8109 6.1422 5.8474 5.5755 5.0916 4.6755 4.0013 3.4834
 16 14.7179 13.5777 12.5611 11.6523 10.8378 10.1059 9.4466 8.8514 8.3126 7.8237 6.9740 6.2651 5.9542 5.6685 5.1624 4.7296 4.0333 3.5026
 17 15.5623 14.2919 13.1661 12.1657 11.2741 10.4773 9.7632 9.1216 8.5436 8.0216 7.1196 6.3729 6.0472 5.7487 5.2223 4.7746 4.0591 3.5177
 18 16.3983 14.9920 13.7535 13.6593 11.6896 10.8276 10.0591 9.3719 8.7556 8.2014 7.2497 6.4674 6.1280 5.8178 5.2732 4.8122 4.0799 3.5294
 19 17.2260 15.6785 14.3238 13.1339 12.0853 11.1581 10.3356 9.6036 8.9501 8.3649 7.3658 6.5504 6.1982 5.8775 5.3162 4.8435 4.0967 3.5386
 20 18.0456 16.3514 14.8775 13.5903 12.4622 11.4699 10.5940 9.8181 9.1285 8.5136 7.4694 6.6231 6.2593 5.9288 5.3527 4.8696 4.1103 3.5458
 25 22.0232 19.5235 17.4131 15.6221 14.0939 12.7834 11.6536 10.6748 9.8226 9.0770 7.8431 6.8729 6.4641 6.0971 5.4669 4.9476 4.1474 3.5640
 30 25.8077 22.3965 19.6004 17.2920 15.3725 13.7648 12.4090 11.2578 10.2737 9.4269 8.0552 7.0027 6.5660 6.1772 5.5168 4.9789 4.1601 3.5693
 40 32.8347 27.3555 23.1148 19.7928 17.1591 15.0463 13.3317 11.9246 10.7574 9.7791 8.2438 7.1050 6.6418 6.2335 5.5482 4.9966 4.1659 3.5712
 50 39.1961 31.4236 25.7298 21.4822 18.2559 15.7619 13.8007 12.2335 10.9617 9.9148 8.3045 7.1327 6.6605 6.2463 5.5541 4.9995 4.1666 3.5714
 60 44.9550 34.7609 27.6756 22.6235 18.9293 16.1614 14.0392 12.3766 11.0480 9.9672 8.3240 7.1401 6.6651 6.2402 5.5553 4.9999 4.1667 3.5714
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 190

[pág. 191]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2013 | pregunta 5
 Convocatoria 1 | página original 123 | ANOVA, clustering y cuestionario
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº 5
 El consumo de medios digitales ha aumentado mucho en los últimos años, y representa una clara amenaza para las
 industrias proveedoras de medios impresos: diarios y revistas, libros, agendas y cuadernos, así como impresos
 publicitarios tales como volantes o dípticos, que han sufrido bajas en sus ventas debido a la fuerte entrada de sus
 respectivos sustitutos digitales. Incluso, algunos medios impresos tradicionales han sido remplazados totalmente por
 sus símiles digitales; es el caso de la revista norteamericana Newsweek, que tras 80 años deja de producir su versión
 impresa, manteniendo sólo el formato digital.
 Puntito es una imprenta que fabrica y comercializa productos de papel tales como memorias de empresas, cuadernos,
 agendas, volantes y afiches publicitarios. Puntito tiene una buena reputación en la industria, y ofrece productos de alta
 calidad y un buen servicio a sus clientes. Sin embargo, las ventas de Puntito han caído en el último año, y sus
 ejecutivos creen que se debe a la fuerte entrada de medios digitales. Por lo tanto, Puntito decide investigar los hábitos y
 percepciones de los consumidores de medios impresos y digitales. Específicamente, a la empresa le interesa conocer el
 nivel de consumo promedio de ambos tipos de medios, y ver si hay diferencias entre distintos grupos de personas según
 características demográficas. Además, Puntito quiere saber qué piensan estos consumidores sobre las posibles
 diferencias entre medios impresos y digitales, de modo de poder segmentar el mercado según esto y desarrollar
 campañas comunicacionales adecuadas para algunos o varios de los segmentos resultantes.
 Con este propósito, Puntito decide hacer una encuesta en hogares a una muestra representativa de la población en
 estudio: hombres y mujeres mayores de 14 años, de todos los grupos socioeconómicos. En el Anexo 1 de la siguiente
 página se presenta una selección de preguntas del cuestionario que será administrado. Se pregunta sobre hábitos de
 consumo de medios (preguntas 1, 2 y 3), sobre percepciones acerca de las posibles diferencias entre medios impresos y
 digitales (preguntas 4 y 5), y sobre variables demográficas (edad, sexo, y grupo socioeconómico) que permitan
 clasificar a los participantes (no incluidas en el Anexo 1).
 Sobre la base de la información presentada, a Ud. se le pide responder de manera precisa y concisa, las preguntas A y
 B que se le formulan a continuación, entregando los fundamentos conceptuales correspondientes:
 Pregunta A: Puntito quiere comparar el nivel promedio de consumo de medios impresos y digitales entre hombres y
 mujeres, utilizando para ello las preguntas 1, 2 y 3 del Anexo 1.
 (A.1) Dado el objetivo planteado por Puntito en la pregunta A indique qué tipo de análisis estadístico debiera usarse y
 por qué, explicando brevemente en qué consiste dicho análisis.
 (A.2) Explique qué tan apropiadas le parecen las preguntas 1, 2 y 3 del Anexo 1 para llevar a cabo el análisis
 estadístico que Ud. sugirió en (A.1) y para lograr el objetivo planteado por Puntito en la pregunta A. Fundamente su
 respuesta.
 Pregunta B: Suponga ahora que Puntito quiere segmentar a los participantes del estudio de acuerdo a sus percepciones
 sobre las posibles diferencias entre los medios impresos y digitales, usando para ello las preguntas 4 y 5 del Anexo 1.
 (B.1) Dado el objetivo planteado por Puntito en la pregunta B señale qué tipo de análisis estadístico debiera usarse y
 por qué, explicando brevemente en qué consiste dicho análisis.
 (B.2) Explique qué tan apropiadas le parecen las preguntas 4 y 5 del Anexo 1 para llevar a cabo el análisis estadístico
 que Ud. sugirió en (B.1) y para lograr el objetivo planteado por Puntito en la pregunta B. Fundamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 191

[pág. 192]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2013 | pregunta 5
 Convocatoria 1 | página original 124 | ANOVA, clustering y cuestionario
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 ANEXO 1
 Principales Preguntas del Cuestionario
 P1. ¿Con qué frecuencia lee usted medios impresos? (por ejemplo, diarios, revistas, o material publicitario)
 Nunca De vez en cuando A veces Bastante seguido Muy seguido
 P2. ¿Con qué frecuencia lee usted medios digitales? (por ejemplo, diarios, revistas, o material publicitario)
 Nunca De vez en cuando A veces Bastante seguido Muy seguido
 P3. En el último mes, ¿qué porcentaje del tiempo que dedicó a leer, lo destinó a medios digitales, y qué
 porcentaje a medios impresos?
 Medios Digitales Medios Impresos
 % %
 P4. ¿Cree usted que con el tiempo va a remplazar su consumo de medios impresos por medios digitales?
 SI NO
 P5. ¿Qué tan de acuerdo o en desacuerdo está con cada una de las siguientes afirmaciones? (Desde 1 = Muy en
 Desacuerdo a 5 = Muy de Acuerdo)
 Afirmación 1 2 3 4 5
 Los contenidos de un texto son más fáciles de
 entender en papel que en digital.
 Leer en digital es más cool y novedoso que leer
 en formato impreso.
 Las personas mayores en general prefieren leer
 en papel que en una pantalla.
 Me manejo muy bien con los medios digitales.
 Los diarios impresos son más para el fin de
 semana, mientras que los diarios digitales son
 más para los días de semana (lunes a viernes).
 A los integrantes de mi familia les gusta mucho
 leer el diario impreso.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 192

[pág. 193]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2011 | pregunta 5
 Convocatoria 2 | página original 81 | Calidad de clustering
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº5
 Fertilizantes TQC es una empresa chilena dedicada a la exportación de fertilizantes y otros productos químicos para la
 agricultura. Su principal mercado es Estados Unidos, ya que empresas de ese país compran aproximadamente el 45% de
 la producción de Fertilizantes de TQC. Sin embargo, la competencia ha aumentado mucho en ese país, no sólo de parte
 de otros productores chilenos, sino que de proveedores de otros países.
 Con el objetivo de entender qué criterios son los que más consideran las empresas compradoras de fertilizantes químicos
 al momento de elegir un proveedor, Fertilizantes TQC realizó una encuesta a clientes actuales y potenciales. Se diseñó un
 cuestionario en formato digital que fue administrado por una plataforma de Internet independiente. A una muestra de
 1.500 gerentes de compra, actuales y potenciales clientes de Fertilizantes TQC, se les envió un correo electrónico
 invitándolos a participar del estudio, con un link hacia la encuesta. Se obtuvieron 1.000 respuestas (suponga que el diseño
 del cuestionario y el procedimiento de muestreo y recolección de datos son adecuados).
 La primera pregunta del cuestionario es la siguiente: A continuación se le presenta una lista de aspectos que usted podría
 considerar al momento de elegir una empresa proveedora de fertilizantes químicos. Le pedimos que asigne un total de
 100 puntos entre los 4 aspectos que usted considera más relevantes, según su grado de importancia. Los aspectos a
 evaluar eran los siguientes:
 • Confiabilidad en la entrega • Justicia en el trato a clientes
 • Calidad de los productos • Calidad de las personas
 • Dar soluciones integrales • Precios de productos y servicios
 • Flexibilidad en el servicio • Calidad de la interacción diaria
 • Efectividad en manejo de reclamos • Reputación de la empresa
 La empresa decide segmentar a sus clientes de acuerdo a estos aspectos, con el objetivo de ser eficiente en la asignación
 de recursos y desarrollar propuestas de valor diferenciadas para cada segmento. Para esto, se realiza un análisis de
 conglomerados usando la metodología de K-Medias1, con la cual se obtienen 2 soluciones alternativas: con 3 segmentos,
 y con 4 segmentos (ver Anexo en página siguiente).
 A usted se le pide responder:
 1. ¿Cuál de las 2 soluciones elegiría, y por qué?
 2. Desde el punto de vista de las características de los segmentos, ¿en qué se diferencian las 2 soluciones, y qué
 implicancia práctica tendría para el Departamento de Marketing de TQC, pasar de la solución de 3 segmentos, a la
 de 4 segmentos?
 1 Se define a priori un número “k” de clusters. Las “k” observaciones más distantes constituyen los centroides de cada uno de
 los “k” clusters, y se asigna el resto de las observaciones a los clusters, según su distancia hacia los centroides. Se recalculan los
 centroides, y se produce una iteración, hasta minimizar las distancias de los elementos a sus centroides.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 193

[pág. 194]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2011 | pregunta 5
 Convocatoria 2 | página original 82 | Calidad de clustering
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 ANEXO: Alternativas de solución del análisis de conglomerados
 Solución con 3 Segmentos
 Tamaño Distancia Distancia Promedio entre Segmentos
 Promedio al Interior del
 Relativo (%) Segmento Seg.1 Seg. 2 Seg. 3
 Segmento 1 46% 21 0
 Segmento 2 15% 14 28 0
 Segmento 3 39% 15 23 33 0
 Centroides de los conglomerados:
 Variable Segmento 1 Segmento 2 Segmento 3 Promedio
 Confiabilidad en la entrega 16.1 11.7 35.0 22.8
 Calidad de los productos 22.8 42.8 27.4 27.6
 Dar soluciones integrales 0.0 0.0 0.7 0.3
 Flexibilidad en el servicio 1.7 1.7 1.7 1.7
 Efectividad en manejo de reclamos 10.3 3.9 2.8 6.4
 Justicia en el trato a clientes 3.3 0.0 4.3 3.2
 Calidad de las personas 9.4 0.6 1.1 4.8
 Precios de productos y servicios 27.6 17.1 24.8 24.9
 Calidad de la interacción diaria 1.7 11.7 0.2 2.6
 Reputación de la empresa 7.0 10.7 2.0 5.6
 Solución con 4 Segmentos
 Tamaño Distancia Distancia Promedio entre Segmentos
 Promedio al Interior del
 Relativo (%) Segmento Seg. 1 Seg. 2 Seg. 3 Seg. 4
 Segmento 1 17% 10 0
 Segmento 2 15% 11 33 0
 Segmento 3 32% 13 34 33 0
 Segmento 4 36% 19 31 29 24 0
 Centroides de los conglomerados:
 Variable Segmento 1 Segmento 2 Segmento 3 Segmento 4 Promedio
 Confiabilidad en la entrega 11.6 11.7 36.3 20.7 22.8
 Calidad de los productos 22.0 41.7 28.2 23.8 27.6
 Dar soluciones integrales 0.0 0.0 0.8 0.0 0.3
 Flexibilidad en el servicio 0.0 0.0 2.1 2.9 1.7
 Efectividad en manejo de reclamos 0.4 2.2 0.8 16.2 6.4
 Justicia en el trato a clientes 0.0 0.0 2.1 7.1 3.2
 Calidad de las personas 18.0 0.6 1.3 3.6 4.8
 Precios de productos y servicios 36.0 19.9 26.3 20.5 24.9
 Calidad de la interacción diaria 0.0 11.1 0.3 2.4 2.6
 Reputación de la empresa 12.0 12.9 1.8 2.9 5.6
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 194

[pág. 195]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2014 | pregunta 5
 Convocatoria 1 | página original 146 | Causalidad publicitaria
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA N” 5
 Faris es una importante cadena de tiendas por departamento del país, que debe definir su inversión en publicidad
 online (ej. banners en páginas web de empresas o buscadores) para los próximos 18 meses. Antes de tomar esta
 decisión, el gerente de marketing de Faris, Richard Thumb, quiere saber cuál es el impacto que la publicidad
 online tiene sobre las ventas online de productos de Faris. Para resolver esta duda, Thumb se reunió con dos
 empresas de investigación de mercados, les explicó el problema que quieren estudiar, y les solicitó una propuesta
 de metodología de investigación para responder a esta pregunta, teniendo como grupo objetivo personas con
 acceso a Internet, que hayan realizado compras en el sitio web de Faris en los últimos 6 meses. A continuación se
 presentan las propuestas de ambas empresas:
 Empresa 1: ComRate
 Ofrece monitorear las conductas de navegación de un panel de consumidores, conformado por personas que han
 aceptado que se instale un software en sus computadores personales, que “observa” y monitorea la actividad
 online que cada miembro del panel realiza. Como recompensa por participar, los panelistas reciben servicios
 informáticos gratis, tales como memoria virtual para respaldar archivos, o softwares anti-virus. Así, ComRate
 registrará durante 1 mes, para todos los miembros del panel, lo siguiente: (a) si vieron avisos de Faris en sitios
 web de otras empresas (por ejemplo, en páginas de medios de prensa online, tales como El Mercurio o La
 Tercera); (b) si vieron avisos de Faris en motores de búsqueda (por ejemplo, la página de Google); y (c) si vieron
 avisos de Faris en los dos medios online mencionados anteriormente!. Durante el mismo mes, ComRate registró
 para cada miembro del panel, las compras online que realizaron en la página web de Faris. Para medir el impacto
 de la publicidad online en las ventas online de Faris, simplemente se compara el nivel de compras online de Faris
 (en dinero) entre quienes vieron publicidad online de Faris (en las 3 modalidades antes descritas), y quienes no lo
 hicieron. Si las compras promedio de quienes sí vieron publicidad, son mayores (con significancia estadística) que
 las compras de quienes no lo hicieron, entonces se concluye que la publicidad online de Faris se traduce en
 mayores ventas online para esta empresa.
 Empresa 2: E-Test
 Propone obtener una muestra estadísticamente representativa de personas que navegan en Internet, e invitarlos a
 participar en una tarea que consiste en que durante 15 minutos deben evaluar la calidad de distintas páginas web
 según ciertos criterios que les fueron entregados con anterioridad. Para medir el impacto de la publicidad online
 de Faris en sus ventas online, a los participantes se les asigna aleatoriamente y en igual número, a los siguientes 5
 grupos experimentales:
 Grupo 1: ve el aviso de Faris en el sitio web de otra empresa (ej. El Mercurio).
 Grupo 2: ve el aviso de Faris en un buscador (ej. Google).
 Grupo 3: ve el aviso de Faris en los dos medios anteriores,
 Grupo 4: No ve avisos de Faris en los medios anteriores,
 Grupo 5: No participa de la tarea encomendada (tarea de evaluar páginas web).
 A continuación de la tarea asignada, se les pide a los participantes que completen una breve encuesta, en que una
 de las preguntas es la siguiente: “En una escala de 1 a 7, ¿Qué tan probable es que usted compre por Internet
 productos de la empresa Faris, durante los próximos 30 días?” Usando los resultados de esta pregunta como
 variable dependiente, se mide el efecto de la publicidad online de Faris (en las tres modalidades descritas), en la
 intención de compra de los participantes.
 PREGUNTAS
 a) Compare ambas propuestas, explicando brevemente las principales ventajas de cada una en relación a la otra y
 a la luz del objetivo de “saber cuál es el impacto que la publicidad online tiene sobre las ventas online de
 productos de Faris,”
 b) Indique cuál de las dos propuestas recomendaría y por qué. Para responder esta pregunta suponga que el costo
 para Faris de ambas propuestas es equivalente y que los resultados de ambos estudios estarían disponibles en el
 mismo momento.
 1 Se supone que quienes entraron al buscador o página web que contiene un aviso, vieron el aviso.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 195

[pág. 196]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2023 | pregunta 5
 Convocatoria 2 | página original 398 | Conjoint por segmento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº 5
 MasterClass es un servicio de streaming online que ofrece clases de diversos temas impartidas por personas
 expertas en sus respectivas áreas. Los y las instructoras van desde escritores ganadores del Premio Nobel hasta
 chefs con estrellas Michelin, directores de cine premiados con el Oscar y más. Las clases cubren una amplia gama
 de temas como escritura, cine, cocina, música, deportes, entre otros. En cada clase, los instructores comparten sus
 experiencias, habilidades y consejos a través de videos de alta calidad y materiales complementarios.
 Actualmente, Masterclass ofrece tres planes: individual, dúo y familiar; y está pensando modificar el plan de
 suscripción individual para lo cual diseñó e implementó un análisis conjunto basado en elecciones (choice-based
 conjoint, CBC). A partir de un estudio preliminar, se determinó que los cinco atributos clave de la suscripción
 individual son:
 1. Precio mensual (US$9, US$11, US$13)
 2. Acceso a todas las clases (Sí, No)
 3. Posibilidad de interactuar con los instructores (Sí, No)
 4. Incluye material extra de aprendizaje (Sí, No)
 5. Posibilidad de descargar las clases para ver offline (Sí, No)
 Un total de 1.000 encuestados evaluaron distintos perfiles utilizando una escala tipo elección múltiple. Una vez
 obtenidas las respuestas, se estimó un modelo logit con dos clases latentes (suponiendo una función lineal para
 las utilidades) obteniéndose los siguientes resultados:
 Tabla 1: Resultados de la estimación de un modelo logit con dos clases latentes
 Segmento 1 Segmento 2
 Atributo Nivel (40%) (60%)
 Precio Mensual $9 0 0
 Precio Mensual $11 -0,3 -0,7
 Precio Mensual $13 -0,5 -0,9
 Acceso a todas las clases No 0 0
 Acceso a todas las clases Si 0,3 0,1
 Interacción con instructores No 0 0
 Interacción con instructores Si 0,6 0,2
 Material extra de aprendizaje No 0 0
 Material extra de aprendizaje Si 0,4 0,2
 Descargas offline No 0 0
 Descargas offline Si 0,4 0,2
 Observaciones:
 a. Los valores en la tercera y cuarta columna de la Tabla N° 1 son los coeficientes del modelo logit para
 cada segmento. Estos representan las utilidades parciales (part-worths).
 b. Los niveles con coeficientes igual a cero corresponden al nivel base (y por lo tanto no fueron estimados).
 c. Todos los coeficientes estimados son estadísticamente significativos al 5% (p < 0,05).
 d. Notar que la probabilidad de pertenecer al segmento 1 es 0,4.
 Basado en los resultados anteriores, responda las preguntas que se le formulan a continuación entregando los
 fundamentos correspondientes:
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 196

[pág. 197]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2023 | pregunta 5
 Convocatoria 2 | página original 399 | Conjoint por segmento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 PREGUNTAS
 1. ¿Existen diferencias entre los dos segmentos en términos de preferencias e importancia de los atributos?
 2. El plan básico actual de la empresa (que cuesta US$9) no ofrece hoy la posibilidad de interactuar con los
 instructores. La gerenta comercial de la empresa evalúa ofrecer este servicio y subir el precio del plan
 básico a US$10. ¿Recomendaría usted mantener el servicio original, ofrecer el nuevo servicio u ofrecer
 ambos? Determine la disposición a pagar por este atributo y utilícelo en su argumentación.
 3. ¿Por qué los ejecutivos utilizan la metodología CBC, que es una de las metodologías indirectas y no se
 pregunta directamente, a los potenciales consumidores, por las utilidades que les reporta cada nivel de
 cada atributo? Explique.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 197

[pág. 198]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2021 | pregunta 5
 Convocatoria 1 | página original 337 | Conjoint versus datos históricos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 PREGUNTA Nº5
 El mercado de galletas en Chile llega a $ 200 mil millones anuales en ventas según datos de la empresa de
 investigación de mercado Nielsen Chile, y viene creciendo a un ritmo de 1% en supermercados y más de 4% en el
 canal tradicional de almacenes. Las empresas que lideran este mercado son Costa (Costa, Vivo) que tiene una
 participación de 36%, Nestlé (McKay) con 32% y Arcor (Dos-en-Uno, Bon-o-Bon) con 13%. El resto del mercado
 se distribuye entre fabricantes pequeños y marcas propias.
 En la categoría de galletas dulces, los dos fabricantes más grandes, Costa y Nestlé, han introducido en el último
 tiempo varias innovaciones de galletas con trocitos de frutos secos y chocolates. Arcor no ha sido tan activo en estas
 innovaciones y los ejecutivos del área de marketing de Arcor consideran que esto puede explicar la disminución en
 su participación de mercado en esta categoría. En respuesta a lo anterior, los ejecutivos del área galletas de Arcor
 preparan un plan que consiste en lanzar nuevas galletas con trocitos de frutos secos para competir de mejor forma
 con Costa y Nestlé. Para esto encargan una propuesta metodológica a una empresa de investigación para realizar un
 estudio de mercado que permita estimar las preferencias de los consumidores en la categoría de galletas dulces. La
 propuesta enviada por la empresa de estudios tiene las siguientes características técnicas:
 Estudio: Análisis Conjunto con método de Perfil Completo (Método Indirecto)
 Muestra: 720 casos con cuestionario aplicado a personas que consumen regularmente galletas dulces
 Atributos y Niveles: Los atributos y niveles considerados en el estudio se presentan en la tabla siguiente.
 Atributo Nivel 1 Nivel 2 Nivel 3 Nivel 4
 Marca Arcor Costa Nestlé
 Formato* Mini Rollo Familiar
 Fruto Seco Avellanas Cranberries Frambuesas Manzanas
 Precio $1.000 $1.500 $2.000 $2.500
 (*) Formato Mini es pequeño, como colación y para escolares. Formato rollo o tubo es el formato tradicional de las galletas para 2 ó 3 personas.
 Formato familiar es un formato más grande orientado a toda la familia.
 Resultados: Los resultados del estudio, en cuanto a preferencias de los consumidores, se entregarán a nivel agregado
 (para la muestra completa) y para segmentos de edad y sexo.
 Cuando la propuesta del estudio se le presenta al directorio de Arcor, tres de sus miembros hacen los siguientes
 comentarios:
 Director 1: No parece necesario hacer un estudio en base a encuestas cuando se tiene disponible la información del
 panel de consumidores de la empresa de investigación de mercado Nielsen Chile (equivalente a Panel de Kantar
 World Panel) con las compras efectivas de cada consumidor y con el precio pagado. Se podría usar un modelo de
 elección de marca con esta información de compras efectivas.
 Director 2: Los resultados a nivel agregado, o con segmentaciones por variables demográficas, son muy poco útiles
 para una empresa relativamente pequeña como Arcor. A nivel agregado, siempre Costa y Nestlé aparecerán con las
 mayores preferencias.
 Director 3: Hay atributos que no están presentes en el estudio, como por ejemplo los logos de Alto en Azúcar,
 Calcio y Grasas. Me parece que la ausencia de estos atributos puede sesgar significativamente los resultados.
 Sobre la base de la información que se le ha presentado, a Ud. se le pide responder las siguientes preguntas,
 entregando los fundamentos correspondientes:
 a) Considerando el comentario del Director 1, ¿existe alguna ganancia con la metodología que propone la
 empresa de investigación de mercado? Justifique su respuesta.
 b) Según el comentario del Director 2, ¿es posible con los resultados de la metodología que se propone, hacer
 segmentaciones más finas (detalladas) según preferencias de los consumidores? Justifique su respuesta.
 c) ¿Está usted de acuerdo con el comentario del Director 3, en el sentido de que la ausencia del atributo Logo
 (Alto en Azúcar, Calcio y Grasa) puede sesgar significativamente los resultados del estudio? Justifique su
 respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 198

[pág. 199]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2017 | pregunta 5
 Convocatoria 2 | página original 248 | Conjoint y DAP
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA N* 5S
 Aunque apenas representan el 1% del total de refrescos que se comercializan en Chile, las bebidas isotónicas
 mantienen un fuerte crecimiento en el país según datos de AB Chile, entidad gremial que reúne a los productores
 e importadores de alimentos y bebidas analcohólicas. Entre enero y septiembre de 2016 se vendieron 19,9
 millones de litros de este tipo de bebidas, mostrando un crecimiento de 33,1% con respecto al año anterior, En
 los últimos 10 años, la penetración de estas bebidas rehidratantes ha subido de 2% a 19,9%. En Chile existen 5
 competidores en la categoría de bebidas isotónicas: Gatorade, Powerade, Vitamin O2, Sprim Sport y Zuko Go.
 La marca Gatorade, elaborada y embotellada por CCUS.A., es líder de la categoría con un 80% de participación
 de mercado,
 Los ejecutivos de Gatorade encargan a una empresa de investigación de mercado un estudio de Amálisis
 Conjunto (conjoint analysis) con el objeto de conocer los cambios que podrían estar teniendo los consumidores
 en relación a las preferencias por bebidas isotónicas.
 El estudio realizado por la empresa de investigación consideró los atributos y niveles que se presentan en el
 Cuadro 1 de la página siguiente: Light / Regular, Precio, Tapa, Marca y Sabor. El estudio se realizó en base a la
 metodología de perfil completo (0 método indirecto) en la cual un determinado número de perfiles es evahuado
 por cada encuestado en una muestra representativa, en este caso de tamaño n = 543, del segmento objetivo.
 Algunos resultados del estudio se exhiben, en la página signiente, en el Cuadro 2 y el Cuadro 3. El Cuadro 2
 presenta la importancía de cada atribu£o calculada en base a la diferencia máxima de utilidades en cada atributo
 y escalada para que sume 100, por lo cual se puede leer como porcentaje de importancia. En la primera columna
 de este Cuadro se presenta la importancia para el total de la muestra mientras que en las columnas siguientes se
 exhiben los resultados desagregados por género, edad, grupo socio económico y si es consumidor de la categoría.
 En la última fila del Cuadro 2 se presenta el tamaño de la muestra correspondiente a cada segmento. Finalmente,
 en el Cuadro 3 se presentan las utilidades (o preferencias) de un consumidor particular.
 PREGUNTAS
 a) Suponga que al momento de la presentación de los resultados del estudio, uno de los ejecutivos de Gatorade
 se da cuenta y hace notar que en el esfudio no está presente el atributo Formato o Contenido (500 cc, 600
 — ce, 750 ce, 1.000 ce, etc...). Si el atributo Formato o Contenido fuese efectivamente relevante en las
 preferencias de los consumidores, ¿podría esto sesgar o influir de manera significativa en los análisis de los
 resultados del estudio? Fundamente su respuesta.
 b) De los resultados que se presentan en el Cuadro 2, se desprende que los consumidores son homogéneos en
 sus preferencias respecto de este tipo de bebidas, con lo cual no se podrían obtener las ganancias que produce
 wna segmentación de los consumidores ¿Está usted de acuerdo con esta afirmación? Justifique su respuesta.
 c) ¿Cuánto vale, en valor monetario (pesos), la marca Gatorade para el consumidor cuyas utilidades se
 presentan en el Cuadro 37 Explique, mostrando los cálculos correspondientes.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 199

[pág. 200]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2017 | pregunta 5
 Convocatoria 2 | página original 249 | Conjoint y DAP
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 Cuadro 1 : Atribntos y Niveles
 Light/Regular Light Regilar
 Precio $800 $900 $1.000
 Tapa Deportiva Plana
 Marca Gatorade Powerade
 Sabor Naranja Manzana Lima/Limón
 Cuadro 2: Importancia de Atributos Según Distinto Tipo de Variables (en porcentaje)
 Light/Regular | 7% 7% 6% 7% 7% 6% 6% 7% 7% 6%
 Precio 10% 10% 10% 10% 10% 10% 10% 10% 10% 14%
 Tapa 17% 16% 18% 16% 19% 18% 19% 17% 17% 11%
 Marca 27% 27% 28% 27% 27% 20% 28% 27% 27% 31%
 Sabor 39% 40% 38% 40% 37% 40% 37% 39% 39% 38%
 Total 100% | 100% 100% | 100% 100% | 100% 100% 100% 100% 100%
 n (Muestra) 343 303 240 277 266 181 182 180 533 10
 Cuadro 3: Utilidades de un Consumidor (*)
 LightRegular Light =20 Regular = 0
 Precio $800 =10 $900 =0 $1.000 =-5
 Tapa Deportiva =8 Plana =0
 Marca Gatorade = 0 Powerade = -10
 Sabor Naranja =3 Manzana = -8 Lima/Limón =0
 () El estadigrafo R? en la estimación es 0,96 y la utilidad del producto (perfil) base es 25.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 200

[pág. 201]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2021 | pregunta 2
 Convocatoria 2 | página original 343 | Conjoint y DAP
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 PREGUNTA Nº2
 La industria de los videojuegos es uno de los pocos sectores de la economía que ha crecido en medio de la
 pandemia. Diversos estudios muestran que, a nivel global, los gamers aumentaron en más de 260 millones en
 lo que va de pandemia. Por su parte, sitios como Linio y Mercado Libre registraron un alza de 200% en la
 compra de consolas y accesorios “gaming”, demostrando ser una de las pocas industrias que va al alza en
 medio de la crisis económica más importante del último tiempo.
 El estudio “ABC del Gaming” realizado por la agencia WILD FI identifica cuatro tipos de “gamers”. Uno de
 estos segmentos es el Ultimate Gamer, que corresponde en un 60% a hombres con promedio de edad de 28
 años. Es aquel que vive y respira videojuegos en todos los espectros del mercado, ya sea jugando, comprando
 o consumiendo streaming. Este segmento es muy importante para la industria de los videojuegos, por lo que
 los fabricantes orientan sus desarrollos tecnológicos de manera de dar respuesta a los constantes cambios y
 requerimientos de estos gamers.
 Para entender mejor al segmento de ultimate gamers, se le encargó un estudio a una empresa de investigación
 de mercado, con el objetivo de obtener sus preferencias respecto a las características más importantes de las
 consolas más populares de videojuegos. En particular, se desarrolló un estudio de análisis conjunto, evaluando
 distintas características de estos productos, incluso con características que no están disponibles actualmente en
 el mercado pero que podrían desarrollarse si los clientes muestran preferencias importantes.
 Los resultados del análisis conjunto para un consumidor promedio de este segmento pueden verse en la
 siguiente tabla.
 Atributo Nivel Part-worth o utilidad
 parcial*
 Microsoft 0
 Marca Nintendo -50
 Sony 100
 8GB 0
 Memoria 16GB 100
 32GB 120
 500GB 0
 Almacenamiento 1TB 80
 2TB 100
 400 0
 Precio(USD) 500 -60
 600 -120
 4K 0
 Resolución HD -40
 8K 10
 Nota: Considere que todos los valores estimados (part-worths) son estadísticamente distintos de cero
 (excepto los niveles base no estimados que se fijaron = 0).
 Sobre la base de la información que se le ha presentado, responda las siguientes preguntas fundamentando su
 respuesta.
 a) Considerando el segmento de los ultimate gamers, nombre los dos principales beneficios de realizar un
 estudio de análisis conjunto versus un estudio que analice datos de compras históricas.
 b) ¿Cuánto estaría dispuesto a pagar un consumidor promedio por aumentar la memoria RAM de su consola
 de 16 GB a 32 GB? ¿Qué decisiones puede tomar un fabricante a partir de un análisis como éste?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 201

[pág. 202]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2021 | pregunta 2
 Convocatoria 2 | página original 344 | Conjoint y DAP
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 c) ¿Cuál de las dos siguientes consolas es más preferida por un cliente promedio? Indique sus supuestos y
 desarrolle su respuesta.
 Consola A Consola B
 Marca Sony Nintendo
 Memoria 8 GB 16 GB
 Almacenamiento 500 GB 1 TB
 Precio USD 500 USD 400
 Resolución 8K 4K
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 202

[pág. 203]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2019 | pregunta 5
 Convocatoria 1 | página original 286 | Conjoint y diseño
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N“5S
 La plataforma Uber, que contacta pasajeros y conductores cumple 5 años en Chile, está presente en 26 ciudades
 con más de 60 mil conductores y tiene más de 2 millones de usuarios. La competencia más directa es Cabify
 que cuenta con 50 mil conductores. Una diferencia importante entre las empresas Uber y Cabify es que la
 primera tiene un procedimiento de selección de sus conductores más simple y que sólo requiere una solicitud a
 través de Internet; mientras que Cabify requiere además una entrevista presencial en el proceso de selección.
 Adicionalmente, Cabify tiene, en promedio, conductores con automóviles más modernos y precios levemente
 superiores. A modo de comparación, los taxis de techo amarillo no llegan a 35 mil en todo el país.
 Las razones por las cuales estas plataformas de transporte han crecido de manera tan dinámica en los últimos
 años son varias. En primer lugar, la alta tasa de bancarización de los chilenos permite pagar los viajes con tarjeta.
 En segundo lugar, la alta penetración de teléfonos inteligentes, hace posible que los usuarios gestionen su viaje
 y se comuniquen con el conductor. Finalmente, la aplicación otorga certeza en el trayecto y la tarifa.
 Adicionalmente, la propuesta de valor para los conductores ha sido exitosa.
 La empresa Uber hizo un estudio de Análisis Conjunto!. Para esto seleccionó una muestra de usuarios de su
 plataforma a quienes se les aplicó una encuesta para medir las utilidades parciales de atributos en base al método
 indirecto (evaluación de perfiles). Los atributos considerados más importantes por estudios previos en clientes
 y las utilidades parciales correspondientes al promedio de la muestra se presentan en el Cuadro N“1. Estos
 atributos son: (1) el tiempo que demora el automóvil en llegar desde el momento en que el usuario lo solicita,
 (1i) la antigiiedad del automóvil, (iii) el desempeño histórico del conductor en base a las encuestas de satisfacción
 que completan los usuarios, (iv) si el sistema de postulación de los conductores se realiza íntegramente por
 Internet o si la selección requiere además una entrevista presencial y (v) la experiencia del conductor en la
 compañía.
 Cuadro N21: Utilidades Parciales de Atributos (Promedio de la Muestra)
 Atributo Niveles
 Tiempo Demora Llegada (min.) 5 min. 7 min, 10 min,
 Utilidad 0 -2 4
 Antigliedad Vehículo (años) 0ól 263 24 ó más
 Utilidad 0 -1 2
 Desempeño Conductor (Escala 1 a5) 5.0 4.5 4.0
 Utilidad 0 - -2
 Sistema Postulación Conductor Internet Presencial
 Utilidad a) 3
 Experiencia Conductor (meses) 1 mes 6 meses 12 meses
 Utilidad 0 2 4
 PREGUNTAS
 a) ¿Cuáles el principal problema de marketing que enfrenta Uber y que los lleva a hacer este estudio?
 ¿Cómo podría utilizar Uber los resultados presentados?
 b) ¿Por qué Uber hace un estudio de mercado basado en encuestas si dispone de una enorme cantidad de
 información detallada de los millones de viajes que realizan los usuarios? Explique.
 c) ¿Cuántos perfiles completos, en el modelo de medición indirecta, habría usado usted para estimar las
 utilidades en el Cuadro 1? Justifique su respuesta
 1 Del inglés “Conjoint Analysis”.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 203

[pág. 204]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2020 | pregunta 6
 Convocatoria 2 | página original 327 | Conjoint y diseño de oferta
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 PREGUNTA N° 6
 Las restricciones que ha implicado la pandemia del coronavirus han profundizado el uso del canal online, tanto
 en Chile como en muchos otros países del mundo. De acuerdo con un estudio de la empresa consultora Bain
 & Company1, realizado en junio recién pasado, un 33% de los consumidores chilenos declaran haber utilizado
 por primera vez el canal online para hacer sus compras de supermercado y alimentos. Los clientes nuevos que
 más crecieron fueron del estrato socio económico alto (44% de crecimiento) aunque los consumidores nuevos
 de estratos medios y bajos también crecieron (26% y 39% respectivamente). Estos aumentos incluyen tanto
 los canales online propios de los supermercados, como las apps de “última milla” como Uber Eats, Pedidos
 Ya y Cornershop. Según el estudio de Bain & Company, un 24% de los consumidores usaron una app de
 “última milla” por primera vez durante la pandemia del coronavirus. También han crecido en este mercado la
 frecuencia de uso y el monto de la compra promedio.
 Definitivamente no hay actor del mercado de delivery de alimentos que no esté desarrollando nuevas y mejores
 formas de llegar al consumidor en el canal online. Los supermercados se potencian para hacer frente a la
 demanda de mejor forma, las tiendas especialistas debutan en este mundo y las aplicaciones tradicionales
 generan mecanismos para adaptarse a un entorno que se expande. Los expertos pronostican que las compras
 online de supermercado probablemente se van a mantener en el futuro porque los consumidores ya han bajado
 las aplicaciones, han realizado compras y han podido apreciar sus conveniencias. Probablemente van a
 participar en esta industria muchos actores. El problema no es tanto la competencia sino el ofrecer una
 propuesta de valor atractiva porque el mercado está creciendo de manera significativa.
 En el mundo de las apps de “última milla”, Cornershop ha sido el líder hasta antes de la pandemia del
 coronavirus. Según uno de sus máximos ejecutivos, los desafíos que enfrentan hoy en día son captar nuevos
 clientes, generar hábitos en los clientes para mantener la demanda después de terminadas las restricciones
 sanitarias, aumentar la penetración en regiones donde no están llegando y ajustar la propuesta de valor a las
 necesidades de los nuevos clientes. Estos cambios en la propuesta de valor podrían considerar la estructura de
 precios, las características de la membresía Pop (cliente premium), los comercios con convenio u otras
 características
 PREGUNTAS:
 a) Describa, a partir de los antecedentes en la pregunta, dos problemas de marketing que enfrenta
 actualmente Cornershop. Sea preciso (a) en su respuesta.
 b) Considerando uno (y sólo uno) de los desafíos que enfrenta Cornershop:
 (i) Mencione un modelo o metodología analítica que ayude a los ejecutivos a tomar las decisiones que
 deben enfrentar con respecto al desafío considerado por usted. Justifique su respuesta.
 (ii) Indique los datos que requiere para aplicar el modelo o metodología mencionado.
 (iii) Indique los resultados que se obtendrían del modelo en directa relación con las decisiones relevantes
 al problema.
 1
 El Mercurio, viernes 17 de Julio 2020
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 204

[pág. 205]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2025 | pregunta 6
 Convocatoria 1 | página original 436 | Conjoint y disposición a pagar
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 PREGUNTA N%
 Lanzamiento de nuevo producto enriquecido con proteínas
 Una empresa chilena de alimentos, que compite en la categoría Helados, desea evaluar la introducción
 de un
 nuevo helado enriquecido con proteínas en la categoría de helados vendidos en supermercados. Actualmente,
 E en Chile no existe ningún producto con dicho atributo en
 esta categoría de helados. Los alimentos con proteínas
 agregadas son una tendencia mundial, y Chile no es la
 excepción. Lácteos en general (leche, yogurt), granola e
 incluso pan, son los productos que destacan en el mercado
 nacional: “Se le puede agregar protemna a cualquier
 producto”, señalan los especialistas. El helado
 convencional contiene entre 2 y 4 gr de proteína por
 porción. Los helados enriquecidos con proteínas pueden
 tener hasta 6-12 gr/porción.
 Actualmente, la empresa cuenta con datos transaccionales históricos de la categoría de helados en Chile, que
 incluyen información, para los últimos dos años, sobre precios semanales, volúmenes vendidos de sus marcas,
 si hubo o no promociones de precio en cada semana y, sabores de helados vendidos en distintos canales de
 venta. El equipo gerencial tenía que presentar al Directorio las predicciones de venta para el nuevo producto y
 tenía dudas de cómo justificar el lanzamiento de la nueva línea de helados enriquecidos con proteínas.
 A continuación, se muestran dos propuestas que usted debe analizar:
 Propuesta 1: Una de las analistas del área comercial proponía construir un modelo predictivo de ventas para la
 nueva línea. Dados los datos transaccionales, disponibles en la base de datos de la empresa, proponía usarlos
 en un modelo predictivo para estimar las ventas de la nueva línea de helados.
 1. Haga un análisis crítico de dicha propuesta metodológica para tener una buena estimación de ventas
 del nuevo producto.
 Propuesta 2: Ante la insistencia del gerente de investigación de mercado, la empresa realizó un análisis
 conjunto para identificar cómo los consumidores valoran diferentes atributos de un producto. Para este estudio,
 se evaluaron cuatro atributos clave para la introducción del nuevo helado:-
 * — Sabor: Manjar, Vainilla de Madagascar y Pistacho de Turquía.
 * — Proteína: proteína Regular y Enriquecido con proteína.
 * — Precio: $12.000, $10.000 y $8.000.
 * Marca: Marca A (la que introduce el producto nuevo), Marca Competidor B, Marca Competidor C.
 Se recolectaron datos de preferencias de dos segmentos de consumidores: El Segmento 1 (70%) corresponde
 al público general de la categoría de helados, mientras que el Segmento 2 (30%) corresponde a clientes de la
 marca A, la que está introduciendo el producto.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 205

[pág. 206]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2025 | pregunta 6
 Convocatoria 1 | página original 437 | Conjoint y disposición a pagar
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 Los part-worths (o utilidades parciales) obtenido(a)s fueron lo(a)s siguientes:
 Atributol — Nivel (ngg…fí$;g h1) (Síí%nfr?£ !12>
 Sabor | Manjar 0,0 0,0
 Vainila 0,5 0,8
 Pistacho -0,3 -0,4
 Proteína Regular 0,0 00
 Enriquecido 08 12
 Precio | $12.000 0,0 0,0
 $10.000 0,5 0,3
 $8.000 10 0,6
 Marca | MarcaA 0,0 0,0
 Marca B -0,4 12
 Marca C -0,6 -1,5
 "
 El nivel base de cada atributo (Manjar, Proteína regular, $ 12.0b0, Marca A) tiene un part-worth de 0. El
 resto
 de coeficientes (part-worths) son todos estadísticamente significativos al 5% (p-value<0.05).
 Recibidos los resultados del estudio, el equipo comercial seguía teniendo dudas sobre el mejor plan comercial
 para la nueva línea. El gerente de investigación de mercado proponía lanzar el nuevo helado bajo la marca
 A,
 con foco en el segmento 1 y con un precio premium respecto del resto de la categoría.
 2. Haga un análisis crítico de dicha propuesta de plan comercial para la nueva línea de helados,
 considerando los resultados obtenidos en el análisis conjunto y las métricas de disposición a pagar
 e
 importancia relativa de los atributos evaluados, para cada uno de los segmentos. Justifique
 cuantitativamente sus argumentos.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 206

[pág. 207]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2019 | pregunta 5
 Convocatoria 2 | página original 298 | Difusión de Bass
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA N's
 En las últimas décadas, Chile ha experimentado una caída drástica en la tasa de fertilidad total (número
 promedio de hijos de una mujer durante su vida fértil). Si en 1960, esta tasa fue de 5,5, para 1980 ya había
 caído a 2,6 y el último Censo, arrojó 1,3 hijos por mujer. La cifra más baja de la historia. En este contexto, el
 mercado de pañales para niños se ha visto fuertemente afectado, experimentando contracción tanto en volumen
 (unidades) como en ventas valoradas ($), a tasas de 7% anual aproximadamente, en los últimos 5 años.
 El mercado de pañales para niños en Chile está liderado por tres marcas, que en conjunto capturan hoy, cerca
 del 85% de la participación en ventas. Sin embargo, la participación de mercado de hace un año de las 3 marcas
 mencionadas, superaba el 95%. La caída de más de diez puntos de estas marcas tradicionales se debe
 fundamentalmente a la proliferación de nuevas marcas propias del retail, que han ganado participación
 rápidamente y contribuyen a la contracción del mercado tradicional debido a la emigración de consumidores
 desde marcas de mayor precio hacia las de menor precio.
 Los fabricantes de las marcas principales han intentado defenderse de la declinación del tamaño del mercado,
 profundizando promociones de precios y bajas permanentes de precios. Adicionalmente, una de las acciones
 que redujo en parte la declinación de la categoría, fue el lanzamiento hace un par de años de nuevos productos
 de mayor valor agregado, como los pañales formato Pants (tipo calzón), que tienen beneficios de practicidad
 a la hora de poner y sacar, además de mejor ajuste al cuerpo del bebé, El segmento Pants en Chile es incipiente.
 La gráfica N*1 muestra la penetración del producto Pants en Chile desde su lanzamiento a mediados de 2017.
 La gráfica N%, por su parte, muestra el precio promedio de Pants relativo al precio efectivo de los pañales
 elásicos, en el mismo perfodo de tiempo.
 Gráfica N"1 Gráfica N2
 Penetración % de Producto Pants Precio Relativo Producto Pants Relativo!
 Según Meses Desde Lanzamiento a Precio Pañal Clásico
 18-
 (
 [
 —
 [
 Precio Relalivo Pants
 Penetración (%)
 3
 13-
 N
 0".
 ea CEO Ia —
 20167-07 210 2018.07 201901 20184
 Wes
 A usted se le pide responder:
 a) ¿De qué manera afecta a la velocidad de crecimiento de las ventas del producto Pants, la caída en la
 tasa de fertilidad? Argumente usando un modelo analítico.
 b) ¿De qué manera afecta a la velocidad de crecimiento de las ventas, los cambios de precios
 implementados en el producto Pants por los líderes del mercado? Argumente usando un modelo
 analítico,
 Continúa en la página siguiente
 ! El precio relativo corresponde al precio de Pants divídido por el precio del pañal clásico
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 207

[pág. 208]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2019 | pregunta 5
 Convocatoria 2 | página original 299 | Difusión de Bass
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 €) Suponga que existen sólo dos marcas para el producto Pants. Una marca clásica de proveedor y una
 marca propia del retail, Se dispone de datos de elección de marca a partir de los cuales se estima un
 modelo de regresión logística, que entrega la siguiente función de utilidad para un consumidor
 promedio.
 U = 0,56 x (Marca) — 1,5 (Precio) + Residuo
 Donde (Marca) es una variable dummy que toma el valor 1 s1 es marca proveedor y valor 0 sí es marca
 propia del retail. El (Precio) se expresa en pesos.
 ¿Cuáles debieran ser las participaciones de mercado de la marca del Proveedor y de la marca Propia
 si los precios de ambas marcas son iguales? Explique.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 208

[pág. 209]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2012 | pregunta 5
 Convocatoria 2 | página original 110 | Diseño muestral
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 PREGUNTA Nº 5
 Costanera Center es uno de los mayores proyectos inmobiliarios de la empresa Cencosud S. A. En él, se encuentra el mall
 (centro comercial) Costanera Center, que es el de mayor altura de Chile. Cuenta con más de 300 locales comerciales: un
 Jumbo, un Easy, un Santa Isabel, tiendas Paris, Ripley y Falabella, un paseo gastronómico con restaurantes y cafés, doce
 salas de cines, juegos Aventura Center con pistas de bowling, centros médicos y de salud, gimnasio, y estacionamientos para
 recibir a 5.500 vehículos en seis niveles.
 La construcción del mall Costanera Center no ha estado exenta de polémica, ya que se ha comentado que cuando esté
 funcionando en su total capacidad, provocaría muchísima congestión vehicular en el sector, debido a la gran cantidad de
 personas que llegarían en su automóvil.
 En una noticia publicada recientemente en la sección Economía y Negocios de El Mercurio, se indica que en los primeros
 fines de semana de funcionamiento del mall, más de 300 mil personas lo visitaron, lo que representa aproximadamente un
 25% de aumento en relación a otros malls de Santiago. Sin embargo, se indica que en todo momento hubo estacionamientos
 disponibles. Adicionalmente, se sabe que en días de semana, menos del 20% de los asistentes al mall fue en vehículo.
 Frente a estos antecedentes, surge la pregunta de si una vez que el mall esté funcionando a plena capacidad, será realmente
 tanta la gente que se desplazará al lugar en su automóvil, en vez de ir caminando o usando las distintas formas de transporte
 1
 público. Se cree que en el período inicial de funcionamiento, una buena cantidad de personas va sólo a mirar y conocer el
 mall, pero no representan la demanda real de consumidores que el mall tendrá una vez que haya pasado la novedad y que
 esté funcionando en su totalidad.
 Suponga que Cencosud decide contratar un estudio de mercado con el siguiente objetivo de investigación: estimar cuánta
 gente va a ir al mall Costanera Center en su automóvil (a partir de quienes indican que sí pretenden ir en automóvil al
 mall) cuando esté en pleno funcionamiento (esto es, pasado el período inicial en que parte importante de la gente va sólo a
 conocerlo).
 Con este objetivo de investigación como foco, Cencosud solicita una propuesta de diseño de investigación a dos empresas de
 investigación de mercado. El estudio debe realizarse dentro de las próximas 4 semanas (sin llegar todavía a la fase de plena
 capacidad del mall).
 El Cuadro 1 de la página siguiente presenta un resumen de los diseños de investigación propuestos por las empresas Alpha
 Research y Beta Intelligence (suponga que ambas propuestas tienen el mismo costo financiero para Cencosud).
 1 El mall está a pasos de la estación de metro Tobalaba, que conecta las líneas 1 y 4; además está muy cerca de avenidas con
 amplio flujo de buses del Transantiago (Ej. Providencia/Apoquindo, Vitacura).
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 209

[pág. 210]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2012 | pregunta 5
 Convocatoria 2 | página original 111 | Diseño muestral
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 CUADRO 1: Resumen diseño de investigación de ambas empresas
 Alpha Research Beta Intelligence
 Grupo objetivo Hombres y mujeres mayores de 18 Hombres y mujeres mayores de 18 años,
 años, que viven en el Gran Santiago. que son jefes de hogar del Gran Santiago.
 Método de obtención de Encuesta presencial (con Encuesta telefónica, usando una base de
 datos encuestadores) en el mismo mall datos con números de teléfono fijo de los
 Costanera Center. hogares de las comunas del Gran
 Santiago, aportados por las respectivas
 municipalidades.
 Tamaño muestral * 580 personas, distribuidas de manera 1.800 personas, distribuidas de manera
 proporcional al flujo de visitantes de proporcional al tamaño (en número de
 cada día de la semana, de lunes a personas) de las comunas del Gran
 domingo. Esto es, 60 personas por día Santiago.
 de lunes a viernes, y 140 personas por
 día de sábado a domingo.
 Forma de obtención de En la entrada principal del mall, Primero se dividirá la muestra en grupos
 la muestra comenzarán encuestando a la persona excluyentes, según los siguientes estratos:
 que entre al mall a la hora de inicio de sexo, rango de edad y grupo
 la recolección de datos, y luego cada socioeconómico. Luego, en cada grupo se
 3 minutos encuestarán a otra, y así seleccionará aleatoriamente la muestra,
 hasta completar la muestra de cada proporcional a la cantidad total de jefes
 día, justo a la hora de término de la de hogar en cada grupo.
 recolección de datos.
 Otros antecedentes del Las encuestas se realizarán durante 1 Las encuestas se realizarán durante 2
 trabajo de campo semana, de lunes a viernes entre las semanas, de lunes a viernes, entre las
 18:00 y las 21:00 horas, y de sábado a 16:00 y las 21:00 horas.
 domingo entre las 11:00 y 18:00
 horas.
 * Suponga que en ambos casos, el tamaño muestral es apropiado dado el diseño propuesto.
 Sobre la base de la información presentada, a Ud. se le pide responder de manera precisa y concisa, las preguntas que se le
 formulan a continuación, entregando los fundamentos conceptuales correspondientes:
 1) Compare las propuestas de las dos empresas de investigación de mercados, explicando los aspectos positivos y
 negativos de cada una de ellas, dado el contexto planteado en el enunciado y el objetivo de investigación definido por
 Cencosud.
 2) Si tuviera que elegir solamente entre las dos propuestas anteriores ¿Cuál elegiría Ud. y por qué? Responda esta pregunta
 en base a la relevancia de los aspectos identificados en la pregunta anterior, más que en la cantidad de aspectos
 positivos o negativos.
 3) ¿De qué forma podría perfeccionar el diseño elegido por usted en la pregunta anterior? Señale las dos principales
 modificaciones que Ud. introduciría para mejorar el diseño de investigación elegido y justifique.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 210

[pág. 211]
Marketing - versión clara y reordenada
 Marketing Analytics | marzo 2011 | pregunta 5
 Convocatoria 1 | página original 66 | Encuesta y muestreo
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº5
 Nestlé S.A. presentó hace unos meses una demanda judicial contra Córpora Tres Montes S.A. por supuestas infracciones
 a las normas de competencia leal y ética comercial contempladas en la Ley No 20.169 que regula la competencia desleal.
 La demanda, que finalmente fue rechazada por la entidad legal correspondiente, se basó en que Tres Montes habría
 imitado “códigos visuales” entendidos estos como: colores, imágenes, logos y otros elementos utilizados en los envases,
 etiquetas de productos y medios gráficos que se utilizan en la publicidad de los productos Nestlé 1.
 La Figura 1 muestra los productos Nescafé de Nestlé y Monterrey de Córpora Tres Montes, en sus envases de 170 grs.
 Figura 1: Envases de Nescafé (Nestlé) y Monterrey (Córpora Tres Montes)
 La empresa demandante sostenía que el producto Monterrey imita las “apariencias distintivas” del producto Nescafé con
 el cual compite, “con el claro propósito de que los mismos sean confundidos por el público consumidor”. Más
 específicamente, las propiedades “visuales” de Nescafé que habrían sido imitadas por Monterrey son:
 • Colores y combinaciones de colores en envase y tapa
 • Figura de tazón rojo y granos de café
 • Tipo y color de las marca comercial
 • Frases como “café instantáneo en polvo”
 • Ubicación de la marca en el envase y espuma en el tazón.
 Para respaldar su demanda, Nestlé contrató un estudio a una prestigiosa empresa de investigación de mercados del país,
 cuyo objetivo era demostrar que, debido a la similitud de los envases, una cantidad significativa de personas estaría
 comprando café Monterrey creyendo que compraba Nescafé. El estudio realizado fue de carácter cuantitativo y aplicado a
 una muestra de 315 personas2, hombres y mujeres mayores de 25 años seleccionados aleatoriamente por sexo y edad de
 acuerdo a la distribución de la población del Censo 2002. Las personas de la muestra fueron encuestadas en 20 lugares
 representativos de Santiago que se caracterizan por tener una alta afluencia de público (salidas de metro, supermercados,
 centros comerciales, salidas de cine, y esquinas de alto tráfico peatonal).
 El Cuadro Nº 1 que se presenta más adelante, muestra el cuestionario aplicado a los encuestados, y el Cuadro Nº 2
 presenta los resultados principales del estudio.
 1 Los datos entregados en esta pregunta no necesariamente son los reales.
 2 Lo cual representaría, con una confianza del 95%, un error muestral o estadístico del 5,5%.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 211

[pág. 212]
Marketing - versión clara y reordenada
 Marketing Analytics | marzo 2011 | pregunta 5
 Convocatoria 1 | página original 67 | Encuesta y muestreo
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 Se Pide:
 Suponga que usted representa a Córpora Tres Montes S.A. y debe entregar un breve informe analizando críticamente el
 estudio de mercado presentado por Nestlé, y explicando por qué los resultados no permiten demostrar que, “debido a
 la similitud de los envases, una cantidad significativa de personas estaría comprando café Monterrey, creyendo que
 compraba Nescafé”.
 Cuadro Nº 1: Cuestionario
 1. (Mostrar imagen del envase de Monterrey por 3 segundos y luego guardar la imagen) ¿De qué marca era el
 producto que le acabo de mostrar? Respuesta espontánea.
 2. (Mostrar imagen del envase de Monterrey nuevamente y sin guardar la imagen) ¿Con qué marca cree usted
 que podría confundir este producto? Respuesta espontánea.
 3. (Mostrar imagen de ambos envases: Monterrey y Nescafé) ¿Con qué frase está usted más de acuerdo?
 • Estos dos envases no se parecen en nada
 • Estos dos envases son similares pero no me confundiría entre ellos al minuto de comprar
 • Estos dos envases son tan similares que podría confundirme entre ellos al momento de comprar
 Cuadro 2: Resultados Estudio
 Pregunta 1: ¿De qué marca era el producto que le acabo de mostrar?
 Marca Respuestas Hombres Mujeres
 Monterrey 90,2% 93,0% 87,6%
 Nescafé 3,1% 2,3% 3,8%
 Otra Marca 2,4% 3,1% 1,8%
 No Sabe 4,3% 1,6% 6,8%
 Total 100,0% 100,0% 100,0%
 Pregunta 2: ¿Con qué marca cree usted que podría confundir este producto?
 Marca Respuestas Hombres Mujeres
 Nescafé 57,6% 60,2% 55,2%
 Dolca 4,5% 2,6% 6,1%
 Otra Marca 3,0% 3,9% 2,4%
 No Sabe 5,5% 5,3% 5,7%
 No se Confundiría 29,4% 28,0% 30,6%
 Total 100,0% 100,0% 100,0%
 Pregunta 3: ¿Con qué frase está usted más de acuerdo?
 Frase Respuestas Hombres Mujeres
 “Estos dos envases no se parecen en nada.” 5,8% 5,4% 6,3%
 “Estos dos envases son similares pero no me confundiría entre
 71,3% 71,2% 71,4%
 ellos al momento de comprar.”
 “Estos dos envases son tan similares que podría confundirme
 22,9% 23,4% 22,3%
 al momento de comprar.”
 Total 100,0% 100,0% 100,0%
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 212

[pág. 213]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2015 | pregunta 5
 Convocatoria 2 | página original 181 | Factores, segmentos y targeting
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA N* 5
 El mercado de automóviles de lujo en EE.UU, en los últimos años ha estado dominado por las marcas BMW,
 Mercedes-Benz, Lexus, Audi, Accura e Infinity. Las marcas del grupo económico TaTa de India, Jaguar y
 Land Rover, apenas llegan al 3% de participación de mercado en este país. Los ejecutivos del grupo Tata
 esperan que esto cambie en los próximos años porque pretenden re-posicionar al modelo Jaguar en el
 mercado de lujo de EE.UU. como un modelo deportivo, de buen diseño y de buena calidad en relación a su
 precio.
 Para evaluar la nueva propuesta de valor de la marca Jaguar, los ejecutivos de Tata India realizan un estudio
 de posicionamiento del mercado de automóviles de lujo en EE.UU. Las Figuras 1 y 2 que se exhiben más
 adelante, muestran un mapa de percepciones del mercado de automóviles actual, en el cual Jaguar es
 prácticamente inexistente. El mapa se construye a partir de un estudio basado en las percepciones de
 atributos relevantes de las marcas más significativas. La Figura 1 presenta las dimensiones o factores 1 y 2
 mientras que la Figura 2 presenta las dimensiones o factores 1 y 3. En el título de los ejes se indica el % de la
 varianza explicado de acuerdo a la solución de análisis de factores. El Cuadro A, que aparece en la siguiente
 página, entrega información adicional de las percepciones de los consumidores al presentar las correlaciones
 entre las dimensiones obtenidas del análisis de factores y algunos de los atributos considerados en el estudio.
 Por último, para incorporar las preferencias de los consumidores en el análisis, el Cuadro B, que se presenta
 en la página siguiente, muestra los coeficientes de regresión que relacionan las preferencias declaradas por
 los consumidores (variable dependiente) con las dimensiones obtenidas del análisis de factores (variables
 independientes). Los coeficientes no significativos estadísticamente en este Cuadro son reemplazados por el
 valor 0. También se reportan en la última fila del Cuadro B los estadígrafos R* correspondientes.
 Figura 1 : Mapa de Posicionamiento de Marcas en Dimensiones 1 y 2
 —…í,0_ . 1'0: : .1
 e Audi
 e Meércedes
 BMW
 «V Infinity
 e Accura
 - =1,0
 O Lexus
 -2,0.
 — factori (43%)
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 213

[pág. 214]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2015 | pregunta 5
 Convocatoria 2 | página original 182 | Factores, segmentos y targeting
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 Figura 2 : Mapa de Posicionamiento de Marcas en Dimensiones 1 y 3
 E Accura
 _ gg :
 -
 Mercedes 9
 |
 _
 =
 - e yw
 be 400
 ¿
 . . ;
 : e lexus — :
 -1;0
 ,
 | 20
 — Factori(8%) —
 Cuadro A: Correlaciones entre Atributos Seleccionados y Factores y Comunalidades
 Atributos Factori Factor2 Factor3 Comunalidad
 Atractivo 0.934 0.104 0.267 0.954
 Mal Construido -0.989 0.111 0.026 0.992
 Deportivo -0.032 0.923 -0.030 0.853
 Buen Diseño -0.102 0.899 0.113 0.832
 Prestigioso 0.903 - —-0.416 -0.047 0,992
 Valor* 0.426 0.054 0.866 0.934
 Varianza 43% 28% 18%
 (*) Desempeño en relación a precio
 Cuadro B: Coeficientes de Regresión entre Preferencias Declaradas y Factores
 Segmento 1 Segmento 2 Segmento 3
 Tamaño % 40% 12% 48%
 Constante 6.00 3.63 6.60
 Factor 1 1.53 0.00 1.10
 Factor 2 0.68 0.95 0.00
 Factor 3 0.68 0.00 2.08
 R* 0.92 0.60 0.85
 PREGUNTAS
 a) Describa las preferencias de los segmentos 2 y 3. ¿A cuál de estos dos segmentos debiera dirigirse
 Jaguar? Fundamente su respuesta.
 b) Suponga que Jaguar es exitosa en su reposicionamiento en este mercado y es percibido como 1n auto
 deportivo, de buen diseño, con alto valor. Suponga además que Jaguar logra ubicarse en la mente de los
 consumidores como un automóvil tan deportivo y de buen diseño como el mejor del mercado actual (en
 las Figuras 1 y 2) y de tanto valor (desempeño en relación a precio) como el mejor del mercado actual
 (en las Figuras 1 y 2). ¿Qué posición ocuparía Jaguar en el mapa de posicionamiento? Grafique en los
 mapas de posicionamiento que se presentan en la Hoja de Respuesta y explique su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 214

[pág. 215]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2013 | pregunta 6
 Convocatoria 2 | página original 135 | Factorial y segmentación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº 6
 Una importante empresa de investigación de mercados realizó recientemente un estudio que busca identificar las
 principales tendencias de los chilenos en cuanto a estilos de vida, percepciones de marcas, y otros aspectos
 relacionados con su rol como consumidores. Una parte de este estudio tiene que ver con el concepto de “Vida Sana,”
 para saber qué tan sanos somos los chilenos en cuanto a hábitos (por ejemplo, comer sano, hacer ejercicio, o dormir lo
 suficiente). Con este fin, se realizó una encuesta presencial en hogares a 300 personas a lo largo de todo Chile, en que
 los encuestadores preguntaron sobre hábitos y costumbres relacionados con llevar una vida saludable. A cada
 participante se le pidió que indicara qué tan de acuerdo o en desacuerdo está con una serie de afirmaciones, en una
 escala de 1 = Muy en Desacuerdo a 5 = Muy de Acuerdo. También se registró información demográfica para clasificar
 a los participantes según sexo, rango de edad y grupo socioeconómico.
 A continuación se presentan los resultados de dos análisis multivariados que se hicieron a partir de los datos obtenidos.
 Primero se realizó un análisis de factores con 10 afirmaciones sobre hábitos y costumbres, utilizando la metodología
 de componentes principales y realizando una rotación Varimax para poder interpretar más fácilmente los factores. Los
 resultados se presentan a continuación en el Cuadro N° 1:
 CUADRO N° 1: Análisis de Factores
 Frases / Variables Factor1 Factor2 Factor3 Comunalidad
 1. Hago ejercicio físico con regularidad.
 -0,01 -0,69 0,10 0,49
 2. Siento que descanso la mayoría de las noches. -0,04 -0,16 0,86 0,77
 3. Me preocupo de dormir las horas suficientes para
 descansar bien. 0,18 -0,04 0,84 0,74
 4. Siempre considero las calorías en las cosas que
 como. 0,70 -0,12 0,17 0,53
 5. Participo frecuentemente en actividades deportivas
 y recreativas 0,19 -0,78 0,04 0,65
 6. Compro productos alimenticios sin aditivos
 artificiales. 0,76 -0,12 0,02 0,59
 7. Me preocupo de las enfermedades que me pueden
 provocar los alimentos que consumo. 0,79 -0,03 0,04 0,63
 8. Me preocupo de mantenerme hidratado tomando al
 menos 2 litros de agua al día. 0,19 -0,75 -0,01 0,60
 9. Evito los alimentos con grasas trans o con
 demasiadas grasas saturadas. 0,56 -0,44 0,04 0,51
 10. Acostumbro a leer la rotulación de los envases de
 los alimentos antes de comprarlos. 0,74 -0,12 -0,01 0,56
 Varianza (valor propio) 2,66 1,79 1,52
 % Varianza 27% 18% 15%
 Posteriormente, se realizó un análisis de conglomerados usando la técnica de k-medias, a partir de los puntajes de los
 factores obtenidos en el análisis anterior (análisis de factores). Se obtuvieron 4 segmentos relevantes, que junto con ser
 analizados en función de los factores mencionados, fueron caracterizados de acuerdo a las variables demográficas sexo,
 rango de edad, y grupo socioeconómico. Los resultados se presentan en la página siguiente en el Cuadro N° 2.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 215

[pág. 216]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2013 | pregunta 6
 Convocatoria 2 | página original 136 | Factorial y segmentación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 CUADRO N° 2: Análisis de Conglomerados o Segmentos y Características de los Segmentos
 Tamaño Relativo de los Segmentos
 SEG1 SEG2 SEG3 SEG4 TOTAL
 # personas 99 69 60 72 300
 % del total 33% 23% 20% 24% 100%
 Medias de Factores Según Segmentos
 SEG1 SEG2 SEG3 SEG4 TOTAL
 Factor1 0,91 -0,40 -0,81 -0,19 0,00
 Factor2 -0,26 1,18 -0,92 0,00 0,00
 Factor3 0,30 0,39 0,66 -1,33 0,00
 Características Demográficas
 (1)
 SEXO (valor p = 0,043)
 SEG1 SEG2 SEG3 SEG4 TOTAL
 Hombres 42% 42% 62% 42% 46%
 Mujeres 58% 58% 38% 58% 54%
 (1)
 EDAD (valor p = 0,030)
 SEG1 SEG2 SEG3 SEG4 TOTAL
 15-24 21% 26% 38% 28% 27%
 25-34 15% 17% 18% 22% 18%
 35-44 17% 22% 18% 19% 19%
 45-54 24% 16% 7% 13% 16%
 55 y más 23% 19% 19% 18% 20%
 (1)
 GRUPO SOCIOECONÓMICO (valor p = 0,170)
 SEG1 SEG2 SEG3 SEG4 TOTAL
 ABC1 16% 10% 10% 13% 13%
 C2 25% 13% 18% 19% 20%
 C3 38% 39% 40% 43% 40%
 D 21% 38% 32% 25% 28%
 (1): Valor p (también llamado p–value): test de significancia.
 PREGUNTAS
 Si usted fuera el gerente de Marketing de una cadena de gimnasios (que desarrolla fundamentalmente actividades
 aeróbicas, baile, pesas, spinning, etc.), y sobre la base de la información que se le ha proporcionado en los análisis
 multivariados, responda las siguientes dos preguntas:
 1) ¿A cuáles dos segmentos enfocaría su estrategia comunicacional? Justifique su respuesta, señalando las principales
 características de los segmentos elegidos.
 2) Suponga ahora que usted y su equipo del gimnasio quieren desarrollar un nuevo servicio llamado: Alimentación
 Sana y Vida Balanceada (programa de nutrición y balance entre alimentación y actividad física). La agencia
 publicitaria con la que Ud. trabaja le propone una estrategia comunicacional dirigida al segmento: hombres jóvenes
 que estudian o trabajan. ¿Le parece a usted adecuado el segmento objetivo elegido por la agencia? Explique por qué.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 216

[pág. 217]
Marketing - versión clara y reordenada
 Marketing Analytics | marzo 2009 | pregunta 5
 Convocatoria 1 | página original 10 | Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº5
 El Museo CAT es una institución sin fines de lucro cuyo objetivo es acercar las ciencias, artes y tecnologías a niños,
 jóvenes y adultos, educando de una manera entretenida e interactiva. Cuenta con una gran variedad de exhibiciones,
 tales como las salas “universo,” “energía,” “robótica,” “electromagnetismo,” y “percepciones,” entre otras. Además
 ofrece diversos talleres para que los niños, guiados por un adulto, aprendan sobre ciertas actividades (por ejemplo,
 construcción) e interactúen entre sí en torno a éstas.
 Una de las principales preocupaciones del equipo directivo es cómo financiar mejor a CAT. Específicamente, se está
 considerando la opción de subir el precio de la entrada para niños, que se ha mantenido en $2.000 (en términos
 nominales) por más de ocho años. Sin embargo, hay cierto temor en cuanto a la posible caída en la venta de entradas,
 y a la reacción general del público (eventualmente la prensa), ante esta alza de precios. Por otro lado, si se decidiera
 subir los precios, tampoco está claro en qué monto sería razonable hacerlo.
 Para tomar una decisión bien informada sobre los precios de las entradas a CAT, el equipo directivo optó por realizar
 los siguientes dos tipos de análisis:
 1. Análisis de la Competencia:
 En primer lugar, se obtuvieron los precios actuales de entrada para niños de los “lugares de entretención familiar”
 (LEF).
 En segundo lugar, se obtuvieron las preferencias de los niños por los distintos LEF. Para ello, se encuestó a 400
 adultos con hijos menores de 18 años (200 de estos adultos fueron entrevistados a la salida del museo CAT y 200 en
 sus hogares, en ambos casos seleccionados aleatoriamente). En la encuesta, a cada adulto se le preguntó cuáles eran
 los 3 LEF preferidos de sus hijos, y luego, para la muestra total, se sumaron las respuestas para cada LEF (segunda
 columna del Cuadro Nº1 que se presenta más adelante).
 Finalmente, se obtuvieron las evaluaciones de atributos de CAT y de los otros LEF, que los directivos de CAT
 consideraban los más relevantes. Para ello, a los mismos 400 encuestados descritos en el párrafo anterior, se les pidió
 que pusieran una nota de 1 a 7 a cada LEF en cada uno de los atributos (donde 1 = muy malo, y 7 = excelente).
 Los principales resultados del estudio de preferencias y evaluación de atributos, se presentan en el siguiente cuadro
 (Cuadro Nº1), cuya última columna corresponde al promedio simple de la evaluación de los tres atributos.
 Cuadro Nº1
 Evaluación de Atributos
 LEF Precio Actual Preferencia Entretenido Educativo Buen Precio Promedio Simple
 Divertilandia $ 3.800 22% 6.7 3.8 4.4 5.0
 Zoológico TAM $ 2.500 14% 6.2 6.0 5.1 5.8
 Multi-Cines $ 2.500 14% 6.5 4.4 4.9 5.3
 CAT $ 2.000 10% 6.0 6.8 5.4 6.1
 Zoológico SIC $ 1.000 10% 5.7 5.8 5.8 5.8
 Casa Educativa $ 1.700 7% 5.9 6.0 5.1 5.7
 Saltarín $ 4.000 5% 5.6 4.1 4.7 4.8
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 217

[pág. 218]
Marketing - versión clara y reordenada
 Marketing Analytics | marzo 2009 | pregunta 5
 Convocatoria 1 | página original 11 | Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 2. Disposición a Pagar de las Personas:
 A la misma muestra de adultos descrita previamente, se le preguntó si estarían dispuestos a pagar un determinado
 precio por una entrada de niños a CAT. Se usó una escala de 5 puntos, en que las opciones eran: definitivamente sí,
 probablemente sí, no sé, probablemente no, y definitivamente no.
 Dado que el precio actual de la entrada de niños de CAT es de $2.000, se quiso evaluar la disposición a pagar precios
 superiores. El siguiente cuadro muestra, para cinco niveles de precios, el porcentaje de personas que contestaron
 “definitivamente sí” y “probablemente sí” (la última columna representa la suma de las dos anteriores).
 Cuadro Nº2
 Precio Definitivamente Sí Probablemente Sí Total "Sí"
 $ 1.500 30% 38% 68%
 $ 2.000 22% 33% 50%
 $ 2.500 15% 30% 45%
 $ 3.000 11% 25% 36%
 $ 3.500 8% 15% 23%
 Se Pide:
 1. Uno de los gerentes de CAT comenta: “A partir de la información que se desprende de los Cuadros Nº1 y Nº2,
 para mí el tema está claro: podemos subir el precio tranquilamente de $2.000 a $3.000. Se ve que hay una buena
 disposición a pagar, y CAT es el LEF mejor evaluado en cuanto a sus atributos.” ¿Está usted de acuerdo con este
 Gerente? ¿Por qué?
 2. Suponga ahora que CAT decide hacer un tercer análisis, esta vez sobre la demanda de entradas de niños. Se hizo
 un análisis econométrico de regresión múltiple, para ver el impacto que tienen el precio, la publicidad y la
 actividad económica del país en las ventas de entradas de niños a CAT. Se tomaron datos de los últimos 60 meses.
 A continuación se presenta la ecuación del modelo (nota: ln = logaritmo natural) y los coeficientes obtenidos:
 ln (Ventas) = 24,5 – 2,2 x ln (Precio) + 0,8 x ln (Publicidad) + 0,1 x ln (IMACEC) + ε
 (Nota: La variable dependiente “Ventas”, corresponde a la cantidad de entradas vendidas en cada período)
 Dado que el precio de la entrada para niños al CAT se ha mantenido en $2.000 por más de ocho años, para
 efectos de la regresión, dicho precio fue debidamente ajustado por la inflación (cambio en el IPC) a lo largo del
 tiempo, de modo de usar precios reales. Por otra parte, la inversión publicitaria mensual, también fue medida en
 términos reales. Finalmente, la actividad económica fue medida a través del IMACEC (Indicador Mensual de
 Actividad Económica).
 Suponga que el modelo econométrico está bien especificado, tiene un buen ajuste, y los coeficientes son
 estadísticamente significativos.
 Considerando únicamente la información que se desprende del Cuadro Nº2 y los resultados del análisis
 econométrico, ¿subiría usted el precio de la entrada al CAT desde los actuales $2.000 a $3.000?.
 Fundamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 218

[pág. 219]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2009 | pregunta 5
 Convocatoria 2 | página original 23 | Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 3. PREGUNTA Nº5
 “Fuerte aumento de locales vacíos en stripcenters… Las comunas más afectadas son Lo Barnechea, Huechuraba y Las
 Condes.” dice el titular de una noticia publicada en el diario El Mercurio hace algunos días.
 Los stripcenters son centros comerciales ubicados en sectores residenciales, que agrupan en general no más de 20
 locales (típicamente mini-markets, farmacias, bancos, centros de belleza y otras tiendas), en una superficie que va
 desde los 1.000 a los 4.000 metros cuadrados. Se ubican en lugares estratégicos de ciertas comunas, generalmente en
 esquinas con buena visibilidad y alto tráfico vehicular, y en barrios con alta densidad poblacional.
 Este modelo de retail se ha desarrollado bastante durante los últimos 4 años. Sólo en Santiago existen 43 stripcenters,
 y hay 11 en construcción. Representantes de la industria atribuyen este desarrollo a la creciente necesidad de los
 consumidores por lugares de venta convenientes en cuanto a cercanía de sus hogares y menor tiempo en realizar las
 compras. Los stripcenters compiten con malls (por ejemplo, Alto Las Condes o Mall Plaza), tiendas de conveniencia,
 tiendas especializadas independientes, etc.
 Sin embargo, como se indica en la noticia de El Mercurio, la tasa de desocupación de los stripcenters ha aumentado
 de 5% a 10.8% en los últimos 6 meses. Para las inmobiliarias que han invertido en estos stripcenters, esta mayor
 desocupación tiene un perjuicio económico. Además, pone en riesgo la imagen de los stripcenters, ya que la gente
 podría asociar esta mayor desocupación con problemas de calidad en las tiendas, mal servicio, o mayor criminalidad
 en el área, entre otras cosas.
 La inmobiliaria AV (por “atención a los vecinos”), especialista en desarrollar y administrar stripcenters (cuenta con 8
 en Santiago), decidió tomar cartas en el asunto e investigar el mercado a través de un estudio de mercado, para
 entender mejor el problema e identificar posibles soluciones.
 El principal objetivo de la investigación era saber qué iniciativas podrían desarrollar los stripcenters para atraer a más
 consumidores. Para responder esta pregunta, se realizaron 12 sesiones de grupo o focus groups (4 en cada una de las 3
 comunas más afectadas). En cada grupo participaron 10 personas, las cuales fueron seleccionadas aleatoriamente entre
 personas mayores de 15 años que vivían en las comunas de Las Condes, Lo Barnechea y Huechuraba. Durante las
 sesiones de grupo, a cada participante se le pidió que sugiriera oralmente, frente al grupo, dos iniciativas que los
 stripcenters podrían desarrollar para atraer a más personas. Terminadas las sesiones, se realizó una distribución de
 frecuencia de las 240 respuestas, para ver qué iniciativa aparecía como la más recomendada. Los siguientes fueron los
 resultados:
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 219

[pág. 220]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2009 | pregunta 5
 Convocatoria 2 | página original 24 | Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 Publicitar los beneficios de los stripcenters en medios masivos 55%
 Crear programas de fidelización o de lealtad1, en cada stripcenter 25%
 Realizar eventos culturales 14%
 Otras ideas 6%
 En base a los resultados de la investigación o estudio de mercado, los ejecutivos de AV concluyeron que lo que se
 debe hacer es publicitar los beneficios de los stripcenters en medios masivos.
 A usted se le pide responder las siguientes preguntas:
 1. ¿Está usted de acuerdo con la conclusión de los ejecutivos de AV, a partir de los resultados de la investigación o
 estudio de mercado?. Fundamente su respuesta.
 2. Ahora AV quiere saber a qué grupo(s) socioeconómico(s) (GSE) convendría más dirigir la campaña publicitaria.
 Esto es importante, ya que en estas tres comunas coexisten sectores residenciales con personas de varios GSE.
 Los ejecutivos de AV piensan que los stripcenters son más atractivos para personas de GSE más altos, pero para
 estar seguros, deciden hacer un nuevo estudio, que consistió en una encuesta a 2.000 personas de tres distintas
 comunas: 1.000 personas de Las Condes, 500 de Lo Barnechea, y 500 de Huechuraba; la muestra se conformó de
 esta forma debido a que la comuna de Las Condes tiene aproximadamente el doble de población que las otras dos
 comunas, de acuerdo al Censo 2002. De la encuesta se obtuvo, para cada participante, el número de visitas
 mensuales a algún stripcenter, y su GSE (bajo las categorías ABC1, C2, C3 y DE2). Se calculó el coeficiente de
 correlación entre estas dos variables (visitas mensuales y GSE), y como resultado se obtuvo un coeficiente de
 correlación ρ = 0,76 (entre visitas a stripcenters ¿y el conjunto de los cuatro grupos socio económicos?) . Dada la
 alta correlación entre estas dos variables, los ejecutivos de AV decidieron que lo conveniente era dirigir la
 campaña publicitaria a personas de GSE “alto” y “medio-alto” (ABC1 y C2, respectivamente).
 Desde un punto de vista conceptual, a usted se le pide comentar la decisión de AV, es decir la conveniencia de
 dirigir la campaña publicitaria a personas de GSE “alto” y “medio-alto”, desde cada una de las siguientes dos
 perspectivas, en forma independiente:
 a. La composición de la muestra (sólo en base a la información entregada en el enunciado), y
 b. El análisis estadístico de los datos usados para tomar la decisión.
 Profesor: Aquí un par de personas preguntó ¿a qué estadística se refería la pregunta?
 1 Por ejemplo, ofrecer una tarjeta a través de la cual van acumulando puntos por compras en el stripcenter, que luego
 pueden canjear por premios.
 2 Se asignó un “4” a ABC1, un “3” a C2, un “2” a C3, y un “1” a DE
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 220

[pág. 221]
Marketing - versión clara y reordenada
 Marketing Analytics | marzo 2010 | pregunta 5
 Convocatoria 1 | página original 39 | Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº5
 “JueguePC” es una empresa dedicada al desarrollo de videojuegos para ser utilizados en el computador personal. El
 Directorio de la empresa ha planteado la importancia de explorar el potencial de crecimiento de la empresa en el
 segmento etáreo o de edad de entre 18 y 29 años (hombres), pues a pesar de orientarse históricamente al mercado
 adolescente masculino, el servicio de soporte on-line de la empresa ha recibido un número significativo de consultas por
 parte de usuarios hombres mayores de 18 años.
 Para responder a la inquietud del Directorio, la Gerencia de Marketing de “JueguePC” realizó un estudio de mercado en
 dos fases. La primera fase consistió en un estudio cualitativo basado en 8 sesiones de grupos o grupos focales (“focus
 groups”) que fueron moderadas por una Psicóloga; la segunda fase consistió en un estudio cuantitativo, específicamente
 consistió en una encuesta a 1.000 hombres de entre 18 y 29 años de edad, en hogares del Gran Santiago1.
 Uno de los objetivos específicos del estudio de mercado era identificar segmentos del mercado potencial en los cuales el
 consumo de videojuegos fuera más intensivo para que, eventualmente, constituyesen el foco de una campaña publicitaria.
 En relación a este objetivo, uno de los hallazgos principales del estudio cualitativo fue que los hombres dejaban de
 utilizar videojuegos en su computador personal cuando se casaban, pues esta práctica no se ajustaría al estilo de vida que
 adquiere un hombre al contraer matrimonio. El estudio cuantitativo, por su parte, frente a la pregunta “¿Cuánto tiempo
 destina usted, diariamente, al consumo de videojuegos en el computador?”, arrojó los siguientes resultados (Ver
 notas explicativas a continuación del cuadro):
 Porcentajes de Usuarios Intensivos por Segmento
 EDAD
 18-24 años 25-29 años Total (18-29 años)
 Casado 38% 16% 21%
 (38 de entre 100 encuestados) (56 de entre 350 encuestados) (94 de entre 450 encuestados)
 Marital
 Estado
 Soltero 39% 14% 32%
 (156 de entre 400 encuestados) (21 de entre 150 encuestados) (177 de entre 550 encuestados)
 Notas:
 i. El porcentaje (%) indicado para cada segmento en cada celda, muestra el porcentaje de individuos de entre los
 encuestados en dicho segmento, que destina más de 1 hora diaria al consumo de videojuegos en el computador.
 ii. Entre paréntesis, bajo el porcentaje de cada segmento, se indica el número de casos en cada segmento que
 respondió que destina más de 1 hora diaria al consumo de videojuegos en el computador y el número de
 encuestados en dicho segmento.
 iii. El estado marital “soltero” incluye divorciados y viudos.
 1 Suponga que la muestra es de tamaño adecuado y representativa de la población en estudio.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 221

[pág. 222]
Marketing - versión clara y reordenada
 Marketing Analytics | marzo 2010 | pregunta 5
 Convocatoria 1 | página original 40 | Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 En vista a estos resultados, el Director A de “JueguePC”, plantea que dada la asociación entre el “estado marital” y el
 “consumo de videojuegos”, la hipótesis del estudio cualitativo ha recibido evidencia a su favor y, por ende, propone
 concentrar la campaña de publicidad en medios orientados al segmento de hombres solteros. El Director B, por su parte,
 argumenta que los resultados del estudio cuantitativo indican que no es el “estado marital”, sino la “edad” la variable
 que permite discriminar la intensidad de consumo de videojuegos y, por lo tanto, propone concentrar la campaña en
 medios orientados al segmento de jóvenes de entre 18 y 24 años, sin considerar su estado marital.
 A usted se le pide responder las siguientes preguntas:
 1. Determine quién tiene la razón: ¿el Director A, el Director B, o ninguno de los dos?. Fundamente su respuesta.
 2. El Director C se suma a la discusión, comentando que tal vez fue un error haber usado sesiones de grupo (“focus
 groups”) en este caso particular. Luego indica: “deberíamos haber realizado entrevistas en profundidad en vez de
 sesiones de grupo”. A usted se le pide que indique, y explique brevemente, la principal razón por la que el Director
 C podría estar en lo correcto.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 222

[pág. 223]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2010 | pregunta 5
 Convocatoria 2 | página original 54 | Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº5
 Una prestigiosa empresa de investigación de mercados decide realizar un estudio en el sector de la salud. En particular, le
 interesa medir el nivel de conocimiento de las clínicas médicas de Santiago, entre personas mayores de 18 años
 pertenecientes a los grupos socioeconómicos C2 y C3.
 Con este objetivo, la empresa decide administrar una encuesta en hogares, usando un muestreo probabilístico de tipo
 sistemático, seleccionando hogares en dos comunas en las que hay una alta concentración de personas de estos dos
 grupos socioeconómicos1 .
 Para medir el conocimiento de marca, se utilizaron las siguientes tres preguntas (P1, P2 y P3):
 P1: “Pensando en clínicas médicas de Santiago, ¿cuál es la primera clínica médica que se le viene a la mente?”
 P2: “¿Qué otras clínicas médicas conoce?”
 P3: (Mostrar tarjeta con todas las marcas de clínicas médicas de Santiago) “¿Y qué otras clínicas médicas de esta
 lista conoce?”
 La primera pregunta mide el “top of mind” (TOM, la marca que está en primer lugar en la mente de la persona
 encuestada), la segunda pregunta mide la recordación espontánea, y la tercera la recordación ayudada. Suponga que en
 Santiago operan, para el segmento C2-C3, fundamentalmente 5 clínicas médicas: las clínicas médicas A, B, C, D y E. El
 Cuadro Nº1 muestra los porcentajes (%) correspondientes a las respuestas de cada una de las preguntas que evalúan las
 distintas formas o niveles de recordación de marca.
 Cuadro Nº1: Niveles de Recordación de Marca
 Recordación Recordación
 Clínica TOM Espontánea Ayudada
 A 7.8% 11.5% 14.8%
 B 24.1% 34.4% 41.5%
 C 32.9% 40.7% 45.6%
 D 24.8% 46.3% 67.8%
 E 10.4% 24.4% 31.1%
 Promedio 20% 31.5% 40.2%
 Nota Explicativa al Cuadro Nº1: Por ejemplo, la primera fila de datos se interpreta como sigue: el 7.8% de los
 encuestados nombra a la Clínica “A” al realizarse la pregunta 1; este porcentaje sube a 11.5% cuando se agrega a
 quienes nombran a Clínica “A” al hacerse la pregunta 2; este último porcentaje sube a 14.8% cuando se agrega a
 quienes nombran a Clínica “A” al realizarse la pregunta 3.
 1 Suponga que el procedimiento de muestreo es el adecuado, y que no hay errores metodológicos en el estudio.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 223

[pág. 224]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2010 | pregunta 5
 Convocatoria 2 | página original 55 | Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 Suponga que ahora la empresa de investigación decide analizar el nivel de recordación espontánea para 4 segmentos de
 personas (los segmentos: S1, S2, S3, y S4), formados luego de realizar un análisis de conglomerados en base a ciertas
 variables de comportamiento de compra (por ejemplo, anticipación con la que pide horas de atención, frecuencia
 promedio de visitas a clínicas, etc.).
 El Cuadro Nº2 muestra el tamaño relativo de cada segmento, la recordación espontánea de cada clínica (tercera columna
 del Cuadro Nº1), pero ahora para cada segmento, y la importancia relativa que cada segmento de personas asigna, en
 promedio, a los dos atributos más relevantes de esta categoría de producto (es decir, de las clínicas médicas), que son la
 “calidad” (del cuerpo médico, del servicio y de la infraestructura) y la “conveniencia” (en términos de precio, de
 ubicación y de acceso).
 Cuadro Nº2: Tamaño, Recordación, e Importancia de Atributos por Segmento
 S1 S2 S3 S4 Total
 % de la
 24% 35% 11% 30% 100%
 población
 1
 Recordación Espontánea
 A 4% 2% 57% 12% 11.5%
 B 40% 2% 1% 80% 34.4%
 C 95% 37% 7% 12% 40.7%
 D 6% 87% 1% 48% 46.3%
 E 11% 21% 81% 17% 24.4%
 Atributos 2
 Calidad 50% 42% 77% 81%
 Conveniencia 50% 58% 23% 19%
 Notas Explicativas al Cuadro Nº2:
 1: El primer número de esta sección de la tabla (4%) se interpreta como que el 4% del Segmento 1 recuerda
 espontáneamente a Clínica Médica “A”.
 2: Los números de esta sección de la tabla muestran la importancia relativa que cada segmento otorga a cada
 uno de los dos atributos principales.
 A Ud. se le pide responder las siguientes preguntas:
 1. Un ejecutivo de la Clínica Médica “C”, al ver el Cuadro Nº1 comenta: “este estudio nos indica que no debemos
 temerle a nuestro archirrival, la Clínica Médica “D”, ya que nuestro TOM es casi 10 puntos porcentuales más alto
 que el de ellos. Por lo tanto es más probable que las personas elijan la Clínica “C”, en lugar de la Clínica ‘D’” ¿Está
 usted de acuerdo con la afirmación del ejecutivo de la Clínica Médica “C”? ¿Por qué?
 2. Si usted fuera el Gerente de Marketing de la Clínica Médica “B”, que se caracteriza por ser muy conveniente aunque
 con una calidad sólo promedio, ¿qué haría en términos de estrategias de Marketing para aumentar la participación de
 mercado de su Clínica?. Responda y justifique de acuerdo a la información entregada por el estudio realizado por la
 empresa de investigación de mercados.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 224

[pág. 225]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2024 | pregunta 5
 Convocatoria 2 | página original 423 | Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA N"5
 La empresa Lipigas lanzó hace un año una aplicación (App) para realizar pedidos de gas residencial directamente desde
 un teléfono celular. A pesar del corto tiempo, un porcentaje importante de los pedidos ya se realizan utilizando este
 canal. Para fortalecer este nuevo canal de comunicación y ventas, la empresa ha realizado fuertes inversiones
 publicitarias en TV y redes sociales por el impacto que creen que tienen en la descarga de la App y luego en las ventas.
 La empresa realizó un estudio para evaluar el impacto de la inversión en distintos medios de contacto (televisión abierta
 y redes sociales) sobre las ventas semanales. Luego de recolectar los datos, se generaron dos modelos de regresión lineal
 múltiple. El primer modelo determina cuántas personas descargaron la App (y crearon una cuenta) como función del
 precio e inversión publicitaria, mientras que el segundo modelo determina las ventas (en unidades de 15kg vendidas)
 como función del precio e inversión publicitaria.
 En particular los modelos son:
 Modelo 1:
 Descargas, = ay + a,Precio, + a-Inversión en TV, + a;Inversión en Redes Sociales, + El
 Modelo 2:
 Ventas; = Po + PiPrecio, + P Inversión en TV, + PiInversión en Redes Sociales, + e2
 Donde Descargas,corresponde a las cuentas creadas en la App en la semana , Ventas;, corresponde a las unidades de
 1S5kg vendidas en la semana , considerando todos los canales de venta (en miles de unidades), Precio; es el precio
 promedio de los cilindros de 15kg en la semana ? (en miles de pesos) que puede considerarse exógeno en ambas
 ecuaciones, y, las variables Inversión en TV, e Inversión en Redes Sociales;,, corresponden a los montos en millones
 de pesos en dichas inversiones en la semana £.
 Para estimar los modelos se utilizaron los datos de las últimas 52 semanas en la Región Metropolitana. Los resultados
 se muestran a continuación
 Variable Independiente Cngchjiilig:t:e C“<n)c;(fiiiligr?t: e
 Intercepto | 2.000|! 300|
 ¡Precio N -20/| -0,16|
 |Inversión en TV Abierta |[ 10| 0,25]
 ]Inversíón en Redes Sociales H 20H 0Á
 R? Ajustado [ 0,85/ 0,90|
 Todos los coeficientes son estadísticamente significativos al 95%. Considere que el precio está en pesos mientras que
 la inversión publicitaria está en millones de pesos.
 Preguntas:
 1. Tomando los modelos econométricos desarrollados para Lipigas y sus resultados, indique si las inversiones en
 publicidad en TV y en publicidad en redes sociales, pueden o no ser consideradas como complementarias o
 sustitutas. Fundamente su respuesta.
 2. El gerente general quiere saber cuál de los dos tipos de inversiones en publicidad le genera mayor retorno
 financiero a la empresa, y si estos modelos (1 y 2), permiten responder su inquietud. Respóndale al Gerente,
 argumentando su respuesta.
 3. Considerando el Modelo 2, ¿Cuál sería la reducción en el precio, equivalente al impacto de la publicidad tanto
 en TV abierta como en redes sociales de $10 millones y $5 millones (simultáneamente), en una semana en
 particular? Considere un precio actual promedio de $30.000.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 225

[pág. 226]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2025 | pregunta 5
 Convocatoria 2 | página original 447 | Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N“5
 Un reciente estudio publicado en la prestigiosa revista académica “Marketin
 g Science”, explora el potencial uso
 de la plataforma GP74.0% de inteligencia artificial para construir mapas
 de posicionamiento, que representen las
 percepciones de los consumidores respecto de las marcas de una categoría
 de productos, y que permitan tomar
 decisiones comerciales.
 El estudio publicado considera 21 marcas de antomóviles que fueron evaluadas en
 distintos atributos usando GPT
 4.0 y un prompt” que pide que actúe como un Joven, de altos ingresos y educación
 universitaria, que llena una
 encuesta de percepciones de marca. Luego, los resultados fueron contrastados
 con la metodología tradicional, es
 decir, un estudio con encuestas a una muestra de consumidores, con el perfil mencionad
 o, para así generar mapas
 perceptuales de las marcas.
 En particular, los 12 atributos considerados en el estudio fueron: popular, potente,
 deportivo, con estilo, con
 tecnología avanzada, eco-friendly, eficiente en el consumo de combustible, confiable,
 seguro, cómodo, durable y
 espacioso. En GPTA.0 se utilizó el prompt: “Evalúe en una escala de puntajes
 de 0 (muy bajo) a 10 (muy alto) el
 atributo ...(atributo)... de la marca de automóvil ...(marca).... “. En el caso
 de la encuesta a consumidores se
 realizaron exactamente las mismas preguntas a 402 personas representativas
 del segmento objetivo de los autos
 considerados, según la metodología tradicional.
 Con los datos obtenidos por cada metodología se obtuvo una matriz de puntajes para cada
 atributo en cada marca.
 A continuación, se aplicó un análisis de factores que entregó las siguientes varianzas
 explicadas, en porcentaje,
 para los primeros seis factores, las cuales se presentan a continuación en el siguiente
 cuadro:
 Metodología | Factor 1 2 3 4 5 6
 GPT4.0 41% 16% 13% 1% 10% 5%
 Encuestas a Consumidores 70% 12% 4% 3% 2% 2%
 Las tablas que se presentan a continuación muestran las correlaciones (o
 Zoadings) más significativas entre los
 atributos originales y los factores obtenidos en cada metodología.
 Tabla de Correlaciones en Tabla de Correlaciones en
 Metodología GPT4.0 Metodología Encuesta
 Atributo Factor 1 | Factor 2 V _ Atributo Factor 1 Factor 2
 Eficiente* 0.60 -0.12 .. Eficiente* 0.59 -0.21
 Deportivo -0.90 0.01 . Deportivo -0.84 -0.09
 Durable 0.05 0.89 " Durable 0,02 0.55
 Eco-friendly 0.70 -0.15 . Eco-friendly 0.64 -0.19
 Confiable 0.42 0.10 | Confiable 0.29 0.05
 La Figura 1, que se presenta a continuación, muestra el mapa de posicionamiento
 construido con análisis de factores
 a partir de las respuestas de GPT4.0. Asimismo, la Figura 2 presenta
 el mapa de posicionamiento construido
 mediante análisis de factores a partir de las encuestas a la muestra de 402 consumido
 res representativos. En los
 ejes de ambas figuras se presenta el porcentaje de la varianza capturado/explicado
 por los factores correspondientes.
 $ GPT4.0 es un sistema de inteligencia artificial entrenado con enormes cantidades
 de contenidos disponibles en Internet, para entender
 y generar lenguaje humano.
 * Un prompt es una instrucción, pregunta o texto que se proporciona
 a un modelo de lenguaje para generar una respuesta o contenido
 específico
 10
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 226

[pág. 227]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2025 | pregunta 5
 Convocatoria 2 | página original 448 | Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Figura 1: Mapa de Posicionamiento Basado en Inteligencia Artificia
 l (GPT4.0)
 1
 Jeep !
 0.4- !
 r Subaru
 i
 i
 . 1
 5 02
 o _ 1
 Ford |
 — 1
 — - -
 [
 e Dodge ; / N¡ssan/ Volvo
 S Chewrolet — Mazda “Toyota
 g Oe Occ Fnda” -
 4 Porshe Lexus í
 1
 Ferrari BMW ,
 Mercedes Benz — ! Volkswagen
 -0.27 Lamborghini Aydi
 , Hyundai
 ,1 - . Renault
 , , , N Tesla ,
 -0.75 -0.50 -0.25 0.00 0.25
 Factor 1 (41%)
 Figura 2: Mapa de Posicionamiento Basado en Encuestas a Consumi
 dores
 F
 0.08 - Jeep N
 t
 Subaru
 1
 0.04 - ! Dodge
 !
 — ¡— Chevrolet Honda
 X 1
 >
 = Ferrari ; _ 1
 Lexus, Toyota
 N—
 000--------—.— - Mercedes Benz ___ a
 !
 £ ;
 E Porshe Lamborghini BMW ; Nissan “Ford
 Audi ; Mazda
 -0.04- Volkswag¡en
 Ú
 r
 : Hyundai
 t
 1. Renault
 Tesla¡
 0.2 0.1 D.0 0.1
 Factor 1 (70%)
 Preguntas:
 1. Independientemente de los resultados que este caso presenta, describa
 dos ventajas significativas y dos
 desventajas significativas, que podría tener el uso de plataformas de inteligenc
 ia artificial para construir mapas
 de posicionamiento, en relación a la metodología tradicional basada en encuestas
 a consumidores.
 2. ¿Diría usted que las dos metodologías presentadas en este caso describen
 de manera similar las percepciones
 que tienen los consumidores sobre las marcas de automóviles? Explique
 su respuesta.
 3. La marca Toyota se declara como la marca líder en la fabricaci
 ón de automóviles eficientes y eco-friendly. ¿Es
 esta declaración creíble para los consumidores de acuerdo al mapa
 presentado en la Figura 2? ¿Qué tres acciones
 de marketing debiera realizar Toyota para comunicar bien su posicion
 amiento deseado?, Explique su respuesta.
 11
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 227

[pág. 228]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2024 | pregunta 5
 Convocatoria 1 | página original 411 | K-means y promociones
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº5
 EcoVida, un destacado fabricante nacional de productos de consumo envasados, ha lanzado recientemente una
 nueva línea de galletas sin gluten y sin lactosa, dentro de la categoría “Galletas”. La acogida de estos productos por
 parte de los consumidores ha sido variada. Con el objetivo de comprender mejor las preferencias de los
 consumidores hacia estos productos, se realizó una segmentación de mercado utilizando el método k-medias, basada
 en variables demográficas y patrones de compra de productos sin gluten y sin lactosa, en otras categorías (por
 ejemplo: leche, pan, pastas).
 Esto resultó en la identificación de dos segmentos distintos: el Segmento 1, que constituye el 75% de los clientes,
 compuesto principalmente por consumidores de mayor edad que previamente no habían comprado productos sin
 gluten o sin lactosa en otras categorías; y el Segmento 2, que representa el 25% restante, incluyendo a clientes más
 jóvenes que ya tenían un historial de compra regular de este tipo de productos.
 Para profundizar en el análisis, se decidió examinar las ventas de las galletas, tanto de productos tradicionales como
 de los nuevos productos sin gluten y sin lactosa. Se aplicó un modelo por segmento para cuantificar cómo las
 variaciones en los precios y las promociones afectan las ventas en toda la categoría de galletas. Las promociones
 analizadas son del tipo 2x1 y se llevaron a cabo durante el último semestre.
 El modelo utilizado es el siguiente, donde la variable dependiente es el logaritmo natural de las ventas totales de
 galletas (unidades vendidas), y las variables independientes incluyen el logaritmo natural del precio regular
 promedio de toda la categoría de galletas (incluye los productos recientemente introducidos), además de una
 variable dummy para las promociones actuales y el efecto retardado de las promociones que hubo la semana anterior.
 Es decir, se indica con 1, si hubo promociones en esta categoría esa semana y 0 en caso contrario.
 𝐿𝑜𝑔(𝑣𝑒𝑛𝑡𝑎𝑠𝑡 ) = 𝛼𝑜 + 𝛼1 log(𝑝𝑟𝑒𝑐𝑖𝑜𝑡 ) + 𝛼2 𝑃𝑟𝑜𝑚𝑜𝑐𝑖ó𝑛𝑡 + 𝛼3 𝑃𝑟𝑜𝑚𝑜𝑐𝑖ó𝑛𝑡−1 + 𝜀𝑡
 Donde:
 - 𝛼1 representa el coeficiente para el logaritmo del precio regular.
 - 𝛼2 es el coeficiente para las promociones actuales.
 - 𝛼3 es el coeficiente para el efecto de las promociones realizadas la semana anterior.
 Los coeficientes obtenidos para cada segmento son los siguientes:
 Variable Coef. Segmento 1 Coef. Segmento 2
 Intercepto (𝛼𝑜 ) 10.000 4.500
 log(Precio regular) (𝛼1 ) -0.8 -0.3
 Promoción (𝛼2 ) 0.4 0.3
 Promoción Lag (𝛼3 ) -0.2 -0.05
 Nota: Todos los coeficientes son estadísticamente significativos
 Preguntas:
 1. Considerando la información proporcionada y comparando ambos segmentos, ¿cuál segmento elegiría para
 dirigir una estrategia promocional y por qué? Argumente.
 2. ¿Cuáles son las principales ventajas y desventajas de usar en este caso, una segmentación con k-medias basada
 en variables demográficas y compras en otras categorías? En particular, ¿Qué otras variables de segmentación
 habría usado usted en la segmentación de k-medias de manera de detectar segmentos con distintos patrones de
 compra de productos sin gluten y sin lactosa en otras categorías?
 3. Basándose en los coeficientes del modelo, ¿cuál es el impacto observado de una promoción en las ventas de la
 categoría de galletas? Si se aumentara la frecuencia de las promociones en el futuro y, con nuevos datos, se
 volviera a estimar una regresión como la planteada, ¿cómo esperaría que esto se viera reflejado en los
 coeficientes del modelo (𝛼1, 𝛼2 , 𝑦 𝛼3 )?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 228

[pág. 229]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2026 | pregunta 6
 Convocatoria 1 | página original 461 | Logit multinomial y rentabilidad de promoción
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N%
 En años recientes el retail media ha adquirido un rol crecientemente importante en el ecosistema del retail y el e-
 commerce. Por retail media se entiende la venta de espacios digitales de publicidad por parte de los retailers (canal de
 = venta al comprador final) a marcas de proveedores, para activar campañas en sus canales digitales
 (sitio web/app) o dentro del local (in-store, ej., pantallas digitales o señalización digital),
 típicamente apoyándose en audiencias seleccionadas con datos históricos de los clientes del retailer
 (first-party data). Por ejemplo, durante una visita al supermercado, el cliente puede ver en una
 pantalla digital ubicada cerca de la góndola de cereales un aviso de la marca Nestlé (“Fitness en
 oferta / nuevo sabor”), pagado por esa marca al retailer. En Chile, todos los grandes retailers han
 incorporado redes de retail media (RMN) a sus operaciones.
 Desde el punto de vista de los proveedores y sus marcas, la promesa del retail media es que permite aprovechar el
 conocimiento basado en datos del retailer para entregar mensajes personalizados y/o contextualmente relevantes,
 combinando la precisión del marketing digital con la inmediatez de los ambientes de retail (online y presenciales). Para
 la toma de decisiones por parte de la empresa avisadora, la pregunta relevante es si una campaña se justifica en términos
 de ventas y margen incremental. Este desafío de medición es particularmente importante en ambientes presenciales (in-
 store), donde la exposición al segmento objetivo, no siempre se observa directamente y las campañas pueden coincidir
 temporalmente con otras acciones comerciales (precio, folleto o catálogo impreso de ofertas, exhibiciones especiales)
 0, con variaciones de demanda que ocurren al mismo tiempo que se implementa una campaña.
 En este contexto, la marca Fitness de Nestlé, una marca de cereales para el desayuno, está interesada en evaluar el
 impacto de campañas de retail media in-store sobre sus resultados de ventas y margen. Para ello, el equipo de analítica
 de la marca ha utilizado datos transaccionales de un panel de consumidores durante un período de 104 semanas. Los
 datos están disponibles a nivel de hogar-visita: cada observación corresponde a una visita de un hogar al supermercado
 y registra si en esa visita el hogar compró cereal y, si compró, qué marca eligió.
 En particular, el equipo de Nestlé ha estimado un modelo logit para describir la elección de marcas en la categoría. Las
 marcas consideradas en el modelo se presentan en la tabla a continuación.
 PL: Marca propia del Supermercado (Private Labei)
 FN: Fitness (Nestlé)
 2: No compra cereal (cutside option; utilidad deterministica = O]
 *Supuesto: no existen otras marcas de cereales que la PL y FN.
 El modelo considera que, en cada visita de un hogar al supermercado, el hogar elige comprar una unidad de cereal de
 una de las marcas disponibles o no comprar cereal (outside option), cuya utilidad determinística se normaliza a 0. Esto
 es, la elección se considera a nivel de marcas.
 La tabla siguiente describe cada una de las variables del modelo:
 Variables explicativas (para cada marca j en la visita t):
 Preciojt: USD por unidad del producto de marca j en la visita t
 Foileto_jt: 1 si un producto de la marca j aparece destacado en folleto durante la visita t, ); 0 en caso contrario
 Exhibición_jt: 1 si un producto de la marca j estuvo en cabecera de góndola durante la visita t, ); 0 en caso contrario
 RMN. jt: 1 si algún producto de la marca j fue publicitada vía retail media network (RMN) del retailer en tienda física
 durante la visita t (p. ej., pantallas digitales/ digital signage); O en caso contrario.
 Los resultados del estudio se presentan en la Tablas 1 y 2 a continuación:
 H
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 229

[pág. 230]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2026 | pregunta 6
 Convocatoria 1 | página original 462 | Logit multinomial y rentabilidad de promoción
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Tabla 1. Estadística descriptiva del Panel (promedios del período)
 % del Panel expuesto a La actividad:
 Precio Retail (por unicdad) .
 Marca . Folleto Exhibición | RMN (in-store)
 [USD, Precio al público]
 PL (Marca Propia) 1.70 18% 5% 11%
 FN (Fitness, Nestié) 245 19% 5% 14%
 Nota: La opción “no-choice” o “no-compra” es considerada la opción base en el modelo con variables Precio, Folleto,
 Exhibición y RMN iguales a cero. La constante de esta opción es igual a la utilidad sistemática y es igual a 0.
 Tabla 2. Parámetros estimados (Logit Multinomial)
 Variable Coeficiente Error
 Estandar
 Constante PL 0.35 0.08
 Constante FN -0.60 0.10
 Precio -0.76 0.05
 Folleto 0.40 0.06
 Exhibición 0.75 0.12
 RMN 0.30 0.07
 Pseudo R? 0.29 —
 Log-
 vefosimílítud 1842
 Se pide responder:
 1. Nestlé está evaluando lanzar una nueva campaña de retail media in-store para su marca Fitness (FN). El retailer
 ofrece una activación de retail media con un costo de US$ 14.000 para un período de campaña en la que se proyectan
 1 millón de visitas. Suponga que la contribución para Nestlé por cada unidad vendida de (FN) es US$ 1. Considere
 como escenario base aquel en que ambas marcas tienen Folleto = Exhibición = RMN = 0, y que los precios de cada
 marca son los precios a público promedio del período estudiado. Como dato adicional, las probabilidades de elección
 predichas por el modelo en este escenario base (RMN = 0) son:
 Po :nocompracereal=0,678 | Compare con un escenario alterativo en que solo Fitness activa retail media
 Pp, : Marca propia = 0,264 (RMN = 1 para FN), manteniendo todo lo demás constante. En base a la
 Pen: Fitness = 0,058
 información presentada en las tablas 1 y 2, evalúe si conviene invertir en la
 activación in-store de RMN para Fitness.
 Para responder debe calcular lo siguiente:
 a. Calcule las probabilidades de elección predichas por el modelo en el escenario con campaña.
 b. Calcule el beneficio neto incremental esperado para Nestlé (en US$) asociado a la campaña.
 e. Con base en (ii), indique si Nestlé debiera invertir en el paquete RMN bajo la regla: invertir solo si el beneficio
 neto incremental esperado es mayor que cero. Explique brevemente.
 2. Considere la misma campaña de retail media in-store para Fitness (FN) que en la pregunta anterior, pero ahora desde
 la perspectiva del retailer. Suponga que el margen unitario del retailer (precio retail menos precio por mayor pagado
 por el supermercado a la marca) por unidad es de USDS0,80 para la marca propia (PL) y de USD$0,30 para Fitness
 de Nestlé (FN). Suponga también que implementar la campaña implica un costo incremental para el retailer de
 USS$ 3.000.
 a. Antes de hacer cualquier cálculo, ¿Esperaría que el margen total del retailer por ventas en la categoría cereales
 (considerando el millón de visitas) aumente o disminuya cuando solo FN activa RMN? Justifique brevemente en
 forma cualitativa. En sujustificación, indique dos posibles fuentes de ese cambio.
 b. Calcule el margen total esperado del retailer por ventas (en US$) en el escenario base (RMN = 0) y en el escenario
 con campaña (RMN = 1 solo para FN), así como el beneficio neto esperado del retailer, producto de la venta de
 la activación in-store RMN a Nestlé.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 230

[pág. 231]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2020 | pregunta 5
 Convocatoria 1 | página original 311 | Logit y heterogeneidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº5
 La Central de Abastecimiento del Sistema Nacional de Servicios de Salud (Cenabast), es una institución
 pública dependiente del Ministerio de Salud, cuya misión es abastecer de medicamentos e insumos médicos a
 la Red de Salud Pública. Cenabast es quien compra los remedios más baratos en Chile y un decreto de ley
 publicado hace pocos días en el Diario Oficial permitirá que las farmacias accedan a los precios Cenabast.
 Aunque no todas las farmacias podrán acceder de manera inmediata. A partir del 6 de abril de 2020, los
 chilenos podrán comprar medicamentos, a precio Cenabast, en aquellas farmacias independientes que
 intermedien con la institución pública. En 12 meses, esta medida se ampliará a las cadenas regionales y en un
 plazo de 24 meses, a las grandes cadenas farmacéuticas.
 Las tres grandes cadenas de farmacias que operan en Chile están preocupadas porque durante dos años no
 podrán acceder a los menores precios de los medicamentos. Los consumidores probablemente, preferirán las
 farmacias independientes y cadenas regionales que accedan a los menores precios, generando condiciones
 menos favorables para las grandes cadenas. Según un estudio de Geo-Research (www.geo-research.com), en
 el año 2019 la participación de mercado de las grandes cadenas fue 17% para Cruz Verde, 11% para Salcobrand
 y 9% para Farmacias Ahumada. Las farmacias independientes alcanzaron una participación del 49%; algunas
 cadenas de menor tamaño tenían la participación restante.
 Una de las cadenas grandes de farmacia, ha realizado en los últimos días un estudio de mercado con el
 propósito de medir el impacto que podrían tener los eventuales cambios de precio en la participación de
 mercado. El estudio seleccionó una muestra de 300 personas mayores de 18 años a quienes se les presentaron
 distintos escenarios de farmacias, con distintos escenarios de precio, y con distintos escenarios de cercanía
 geográfica al hogar o lugar de trabajo. Los encuestados debían elegir la opción preferida.
 Suponga que los resultados del estudio son los que se muestran en la tabla siguiente. La tabla muestra las
 estimaciones de dos modelos de elección, estimados mediante regresiones logísticas. El primero sólo incluye
 las constantes de marca en las cuales las tres cadenas grandes se han asociado a las letras A, B y C, a través de
 variables 0/1 según si la marca está presente en la alternativa. El segundo modelo incluye además las variables
 cuantitativas Precio y Distancia. En ambos modelos, la alternativa de referencia corresponde a la Cadena A.
 La tabla muestra, para cada modelo, el coeficiente estimado y el estadístico z (ó t) correspondiente a cada
 variable.
 Modelo 1 Modelo 2
 Variable Coeficiente Estadístico z Coeficiente Estadístico z
 Precio (Miles de $) -0.20 -7.4
 Distancia (Kms.) -1.00 -6.5
 Cadena B* 1.20 4.2 0.50 2.1
 Cadena C* -0.80 -3.1 -0.50 -2.2
 Farmacia Independiente* 1.80 4.7 1.50 3.1
 n 300 300
 Estadístico R2 0.22 0.36
 (*) Constantes de marca tomando como referencia la Cadena A
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 231

[pág. 232]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2020 | pregunta 5
 Convocatoria 1 | página original 312 | Logit y heterogeneidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 PREGUNTAS
 a) ¿De qué forma se hace cargo el modelo logístico de la heterogeneidad de los consumidores? Explique
 su respuesta.
 b) A partir de los resultados de la estimación detallados en la tabla anterior, ¿Cuál es la variable más
 importante en la preferencia de los consumidores? Explique su respuesta.
 c) Suponga que un consumidor enfrenta un medicamento con precio M$ 10 en las todas las cadenas de
 farmacia y precio M$5 en una farmacia independiente. ¿Bajo qué condiciones, alguna de las cadenas
 de farmacia presentaría una oferta competitiva a la farmacia independiente en este caso particular?
 Justifique numéricamente.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 232

[pág. 233]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2018 | pregunta 5
 Convocatoria 1 | página original 262 | Mapa perceptual
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 PREGUNTA N"5
 El retail ha sido, sin lugar a dudas, el sector de mayor dinamismo de la economía chilena en las últimas tres décadas.
 No sólo se ha incrementado su volumen de ventas de manera muy importante, sino también ha mostrado evidencia
 de una evolución rápida, que ha sabido adaptarse a los cambios del país y de los consumidores. En el sector retail
 participan hipermercados de gran tamaño, supermercados, supermercados mayoristas que venden tanto a almacenes
 como a consumidores finales, almacenes, ferias y otros canales tales como tiendas de conveniencia, farmacias y
 de
 comercio electrónico. Los supermercados son el canal de distribución más grande, con casi un 60% de las ventas
 productos de consumo masivo. Hoy en día el mercado nacional de supermercados es controlado principalmente por
 dos operadores: Walmart y Cencosud, que concentran el 65% de la facturación total; le siguen el grupo SMU y
 Falabella (Tottus).
 De acuerdo a un reporte elaborado el 2017 por Kantar Worldpanel, en los últimos meses se ha observado una
 disminución en la participación del canal hipermercados y un crecimiento de las ventas de supermercados de menor
 tamaño. También, ha crecido la preferencia por ferias y supermercados mayoristas. Según el reporte mencionado, los
 chilenos han mostrado un cambio en sus preferencias hacia la compra rápida, lo que está llevando a las principales
 firmas del sector a potenciar los formatos de menor tamaño, los cuales facilitan justamente este tipo de compras. La
 Tabla N*1 siguiente muestra, según Kantar Worldpanel, la participación en volumen de ventas del sector retail para
 los distintos canales en los años 2013 y 2017. Estos datos revelan el crecimiento de formatos de supermercado de
 menor tamaño, los supermercados mayoristas y las ferias. La contrapartida es la caída de los hipermercados:
 Tabla N* 1: Evolución del Volumen de Ventas por Canal en el Sector Retail de Chile
 Año | Hipermercado | Supermercado | Almacén Su&ermegcado Feria | Otros | Total
 ayorista
 2013 37% 24% 14% 2% 3% 20% | 100%
 2017 30% 28% 13% 5% 8% 16% | 100%
 La Figura N” 1 de Ja página siguiente muestra un mapa de posicionamiento de los distintos canales o tiendas de retail
 donde los consumidores compran productos de consumo masivo. Esta figura se obtiene mediante un análisis de
 factores aplicado a los datos de un estudio de mercado donde se preguntó a una muestra de consumidores por sus
 percepciones respecto de cada uno de los canales en cada uno de 23 ítems o atributos. Los dos factores principales
 capturan de manera conjunta el 75% de la varianza en los ítems originales. Los vectores con flechas en la figura
 representan dimensiones o atributos, y los vectores sin flechas y con línea punteada representan las preferencias de
 distintos segmentos de consumidores, en el modelo de vector ideal. No todos los segmentos son de igual tamaño.
 PREGUNTAS
 1. Uno de los ítems o atributos originales del estudio de mercado que se incluyó en el análisis de factores es el
 atributo “Servicio al Cliente”. En los resultados del análisis de factores este atributo no aparece como significativo
 porque no está correlacionado con ninguno de los dos factores seleccionados. ¿Significa esto que a los
 consumidores no les importa el Servicio al Cliente? Explique su respuesta.
 2. Los supermercados mayoristas no son el canal preferido por ningún segmento según el Mapa de Posicionamiento
 en la Figura N* 1 y por lo tanto debieran tener participación de mercado igual a 0. En la realidad, sin embargo,
 esto no es así, y este canal ha anmentado su participación llegando actualmente a tener un 5% ¿Cóma se entiende
 esta aparente contradicción? Fundamente su respuesta.
 3. La pérdida de participación de mercado de los hipermercados ha generado en estos la necesidad de defenderse
 de los otros canales que han ganado participación en los últimos años. Suponga que la siguiente ecuación
 representa el beneficio que los hipermercados quieren maximizar:
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 233

[pág. 234]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2018 | pregunta 5
 Convocatoria 1 | página original 263 | Mapa perceptual
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 B = (Precio — Costo) x Mercado Total x (PM) — Gasto M arketing (1)
 Donde B representa el beneficio, Mercado Total corresponde a la venta total y PM es la participación de mercado en
 volumen. Suponga que los hipermercados reaccionan a la pérdida de participación mediante una campaña
 comunicacional que muestra: (1) el valor que tiene para el consumidor la variedad de productos para poder comprar
 todo en un solo lugar y Cii) la importancia de la confianza en la tienda donde se compra.
 Explique el cambio que más probablemente se producirá con la reacción de los hipermercados a la pérdida de
 participación:
 a) en el mapa de posicionamiento y
 b) en la ecuación de beneficio (1).
 Fundamente claramente sus respuestas.
 Figura N* 1: Mapa de Posicionamiento Canales Productos Consumo Masivo
 1.0-
 Higermercado
 . »
 0.8- - Fería
 . u D
 u Es
 N Lx /' ”
 Buena Relación Precio/Calidad S v MA
 . . ,¡ A . . Conmable
 —
 —.»..'_._ xx 7 .', '__,¡ .
 3?_
 =. x AA —
 [ . J Ff,a ,
 [
 .
 u E S, ¿º'
 =—— -
 —
 —
 N 0n
 - Almacan Buena Snsización
 £g — Bajos
 Precios — »
 | .
 L
 Supermercado Mayorista
 - .
 - . Supermercado
 -D.5 - - *
 1.0-
 - 1 D
 L '
 1.0 .5 00 U 1.0
 Factor 1 (45%)
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 234

[pág. 235]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2022 | pregunta 5
 Convocatoria 1 | página original 361 | Mapa perceptual dinámico
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 PREGUNTA Nº5
 En los últimos años ha habido una explosión en la cantidad de datos disponibles para la toma de decisiones en
 las áreas de marketing de empresas y organizaciones: redes sociales, datos de navegación y transacciones a
 través de Internet, información de bases de datos de clientes y registros de datos en plataformas. Este escenario
 contrasta marcadamente con el escenario de 20 años atrás en el cual la principal fuente de información en
 marketing eran las encuestas.
 La plataforma Statista (www.statista.com) es una de las plataformas de datos para negocios más importantes
 en Internet que registra datos de 170 industrias en 150 países. En la categoría de automóviles de lujo tipo sedán
 en EE.UU., Statista registra (entre otros datos) el precio de los automóviles en miles de dólares, la participación
 de mercado en esta categoría de automóviles y un rating o puntaje, en la escala 1 a 10, elaborado
 automáticamente por la plataforma a partir de características físicas u observables de las distintas marcas:
 consumo de combustible, características del sistema de seguridad, características del sistema de frenos, espacio
 interior y potencia del motor. Los datos de Statista se actualizan constantemente cada vez que se produce un
 cambio en las condiciones de mercado.
 La figura que se presenta a continuación muestra la posición relativa de 10 marcas de la categoría de
 automóviles de lujo tipo sedán en EE.UU. en base a los registros de Statista. Los modelos de cada marca no
 se han considerado para una mejor visualización. En el eje horizontal de la figura se representa el precio en
 miles de dólares y en el eje vertical se muestra el rating o puntaje elaborado por Statista. El tamaño de los
 textos en la figura es proporcional a la participación de mercado de las marcas en esta categoría. Las líneas
 punteadas vertical y horizontal corresponden a los promedios de precio y puntaje de las marcas
 respectivamente.
 Figura: Mapa de Marcas de Automóviles
 Preguntas:
 a) Describa ventajas y desventajas de la metodología utilizada para representar la posición relativa de las
 distintas marcas, según la figura y los registros de Statista, con respecto a la metodología usual o
 clásica de Mapas de Posicionamiento.
 b) ¿Cómo se puede explicar que, según el mapa de la figura, marcas como Mercedes-Benz, y en cierta
 medida BMW, tengan alta participación de mercado en circunstancias que hay otras marcas con mejor
 rating y un precio más conveniente?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 235

[pág. 236]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2017 | pregunta 5
 Convocatoria 1 | página original 234 | Modelo Assessor/pretest
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA N* 5
 Chile es el país de América Latina con el mayor gasto per cápita en higiene bucal: $ 11,4 (dólares) al año, le
 siguen Colombia, Argentina y Perú. Dentro del gasto en higiene bucal, el ítem que más aporta a este gasto es
 la pasta dental. Las tres marcas que lideran el mercado chileno de pastas dentales, según nn estudio de mercado
 reciente, son Pepsodent (de Unilever) con aproximadamente el 45% del mercado, Colgate (de Colgate) con
 aproximadamente 25% del mercado y Aquafresh y Sensodyne (de Glaxo-Smith-Kline) con el 15%,. El 15%
 restante se reparte entre marcas menores.
 Un descubrimiento reciente de científicos ingleses, sin embargo, podría alterar este mercado de manera
 significativa. Una revolucionaria pasta dental, desarrollada por el departamento de Odontología de la
 Universidad Queen Mary de Londres y el Imperial College, contiene un vidrio bioactivo, llamado BiominF,
 que rellena los huecos existentes entre los dientes y al mismo tiempo libera calcio, fosfato y fluoruro, haciendo
 una reparación de la dentadura mientras estamos durmiendo; sin dolor y sin olor.
 Las pruebas de laboratorio de la nueva pasta dental muestran que el producto es más avanzado que otras pastas
 de dientes remineralizantes actualmente ofrecidas en el mercado, tales como Sensodyne, El uso de la nueva
 pasta hace que los dientes sean mucho más resistentes al ataque de los refrescos ácidos. También es mucho
 más eficaz que los dentífricos convencionales en los que Jos ingredientes activos, tales como fluoruro soluble,
 se lavan y se vuelven ineficaces en menos de dos horas. La principal ventaja de BioMinF respecto a intentos
 anteriores de crear productos similares, es que éste libera las sustancias mucho más lentamente, durante unas
 ocho o nueve horas.
 Los creadores de la nueva pasta han entregado una licencia para que la empresa Dental-MinF comercialice el
 nuevo producto en Chile. Los ejecutivos de Dental-MinF, con el propósito de estimar la participación de
 mercado que podría llegar a tener la nueva pasta, realizaron un pre-test de mercado utilizando el modelo de
 preferencias de la metodología ASSESSOR. Esto es, en la fase de laboratorio: (1) a una muestra representativa
 de 350 consumidores del mercado objetivo se les preguntá por las preferencias de marcas antes de conocer la
 Nueva Marca (y suponiendo precios similares entre marcas), luego (1i) a los consumidores en la muestra se les
 presentó el nuevo producto a través de avisos publicitarios incluidos en un documental y (iii) se les dio la
 opción de comprar alguna de las marcas existentes o la Nueva Marca. El 20% de la muestra en el laboratorio
 decidió probar la Nueva Marca después de conocer el producto a través de los comerciales. Al término de la
 fase de Jaboratorio a todos los encuestados se les regaló la Nueva Marca y en la etapa de seguimiento posterior
 (2a3 semanas después) los consumidores volvieron evaluar las preferencias suponiendo precios similares
 entre marcas. Los resultados de este ejercicio se muestran a continmación en el Cuadro 1.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 236

[pág. 237]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2017 | pregunta 5
 Convocatoria 1 | página original 235 | Modelo Assessor/pretest
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 Cuadro 1: Participación de las Preferencias Antes y Después
 de Conocer la Nueva Marca
 Marca — Preferencia Antes* Preferencia Después**
 Pepsodent 41% 35%
 Colgate 27% - 23%
 Aquafresh 12% 10%
 Sensodyne 4% 4%
 Otras 16% ' 16%
 Nueva Marca - 12%
 (*) Antes de conocer la Nueva Marca, etapa (1) en el laboratorio
 (**) Después de conocer y probar la Nueva Marca
 Los ejecutivos de la empresa Dental-MinF tienen considerado vender el producto en todas las cadenas de
 supermercados pero no en las cadenas de farmacia, las que representan el 30% de la venta de pastas dentales.
 Además, los ejecutivos tienen pensado una campaña de lanzamiento, en medios masivos, que logra dar a
 conocer el nuevo producto al 75% del mercado objetivo.
 PREGUNTAS
 a) ¿Por qué considera usted que los ejecutivos de la empresa Dental-MinF decidieron hacer un pre-test de
 mercado y no un test de mercado? Explique.
 b) ¿Qué porcentaje del mercado objetivo probará la Nueva Marca? y ¿Cuál será la participación de mercado
 de la Nueva Marca? Fundamente su respuesta, mostrando los cálculos correspondientes.
 e) Suponga que los ejecutivos de Dental-MinF consideran que los resultados del estudio de mercado son
 mucho menores a los esperados y deciden rediseñar el lanzamiento del nuevo producto. ¿Qué cambio
 propone usted en el diseño para que el Janzamiento sea exitoso? y ¿De qué manera afectaría este cambio
 a la estimación de la participación de mercado de la Nueva Marca? Fundamente sus repuestas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 237

[pág. 238]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2022 | pregunta 5
 Convocatoria 2 | página original 372 | Modelo de elección de marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº5
 De acuerdo con datos de Euromonitor1 (www.euromonitor.cl), Chile es el líder en el consumo de helados en
 Latinoamérica, con 7,7 litros por persona al año. Las ventas en la región han crecido en los últimos cinco años
 un 52%.
 En este mercado se aprecia una tendencia importante hacia un consumo más premium, sofisticado y artesanal.
 Los consumidores se fijan cada vez más en la calidad, y por lo tanto muchos están dispuestos a pagar más por
 productos con mejores ingredientes, como leche líquida en vez de en polvo, trozos de frutas y frutos secos
 naturales y sin grasas saturadas y trans agregadas.
 El formato cassata o familiar (envase de aproximadamente 1 litro) ocupa el primer lugar en el consumo de
 helado de los chilenos, con un 56%. Tras este formato, los helados premium (20,4%) y los postres y tortas
 (18,9%) son los que presentan la mayor demanda en el mercado local. El mercado actual de helados está liderado
 por Savory, que ocupa el 42% de participación de mercado, seguido por Bresler, con el 24%, y San Francisco
 de Loncomilla con el 15%.
 El fabricante de los helados San Francisco de Loncomilla, quiere estudiar las conductas de compra de los
 consumidores de helados en formato cassata o familiar para implementar acciones orientadas a aumentar su
 participación de mercado. Para esto utiliza un panel de 400 consumidores en el cual se registran mediante un
 scanner las compras de helados tipo cassata en el canal supermercado durante un año. Para cada compra de un
 helado cassata se registra la marca, el precio pagado en miles de pesos, si el producto está en display2 en un
 espacio destacado del supermercado y si se han distribuido en la sala de ventas flyers o folletos promocionando
 el producto. Estas dos últimas variables tienen la forma si/no correspondiente a los valores 1 y 0
 respectivamente. Además, se consideran en el modelo las constantes de marca.
 La tabla siguiente muestra la estimación de un modelo de regresión logístico (logit) para explicar la elección de
 marca en esta categoría, en función de las variables independientes mencionadas. La marca considerada como
 base es San Francisco. El Modelo 1 en la tabla considera sólo las constantes de marca y el Modelo 2 agrega las
 otras variables definidas.
 Estimaciones Modelo Logístico Elección de Marca
 Modelo 1 Modelo 2*
 Error Error
 Variable Coeficiente t** Coeficiente t**
 Estándar Estándar
 Precio (miles $) -1.25 0.18 -6.9
 Display (0/1) 0.88 0.46 1.9
 Flyer/Folleto (0/1) 0.19 0.05 3.8
 Constante Savory 0.84 0.25 3.4 0.83 0.39 2.1
 Constante Bresler 0.73 0.23 3.2 0.44 0.25 1.8
 (*) Pseudo R2 = 68%
 (**) Estadístico t igual a coeficiente dividido por error estándar
 Suponga que en el formato cassata o familiar sólo existen las tres marcas consideradas en el estudio. Responda
 las siguientes preguntas.
 a) ¿Qué información relevante para la toma de decisiones de marketing puede ser obtenida de los modelos
 presentados en la tabla? Sea específico en su respuesta.
 1 Los datos que se presentan en esta pregunta no necesariamente son reales.
 2 Display es un espacio en el local que paga el proveedor para exhibir en forma destacada y temporal un producto adicional
 a su espacio normal en la góndola.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 238

[pág. 239]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2022 | pregunta 5
 Convocatoria 2 | página original 373 | Modelo de elección de marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 b) ¿Qué le recomendaría usted a San Francisco de Loncomilla, si esta marca quiere aumentar su participación
 de mercado: disminuir el precio en $1 mil pesos o poner los helados San Francisco en display? Explique
 su recomendación.
 c) ¿Qué crítica(s) se le podría hacer a los datos utilizados y a la metodología implementada en el estudio
 considerando la categoría helados analizada? Explique su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 239

[pág. 240]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2015 | pregunta 5
 Convocatoria 1 | página original 168 | Mystery shopper y diseño exploratorio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA N" 5
 El concepto de farmers' markets (en español, “mercados de los granjeros”) se ha desarrollado mucho en los
 últimos años, y la cantidad de este tipo de minoristas ha crecido una enormidad en Estados Unidos y Canadá,
 pasando de 1.755 tiendas en 1994 a 8.144 en 2013. En ellas se venden muchos productos frescos, tales como
 frutas y verduras, carnes, comida preparada, yogurts, dulces artesanales, etc., además de alimentos envasados
 que típicamente se consumen en un hogar. El surtido de productos favorece los alimentos frescos, orgánicos,
 integrales y, en general, saludables.
 Junto con ofrecer una gama diferenciada de productos en relación a la que ofrecen los supermercados
 tradicionales, los farmers' markets intentan posicionarse como una tienda de alimentación en que el cliente
 vive una experiencia de compra distinta, en base a atractivas exhibiciones de producto, variadas
 degustaciones de alimentos, lugares especialmente habilitados para consumir productos en la misma tienda,
 y la entrega de información y asesoría nutricional a los compradores.
 Novofresh es una tienda farmers” market en Seattle (Washington, Estados Unidos), que nació en 1907 y que
 se ubica en un sector residencial caracterizado por tener una población bastante diversa en cuanto a edad y
 ciclo de vida familiar, Es muy común en este sector ver personas solteras, parejas sin hijos, familias con
 hijos de distintas edades, y parejas mayores en que los hijos ya no viven con ellos. En los últimos años, la.
 tienda Novofresh se ha transformado en una de las mayores atracciones turísticas de la ciudad. Tiene un alto
 flujo de público, y las encuestas a clientes indican que estos están bastante satisfechos con la tienda y el
 servicio prestado. Sin embargo, la rotación de ciertos productos, la compra promedio, y la rentabilidad de la
 tienda no han sido lo suficientemente buenas, en relación a cifras de desempeño de otros armers* markets de
 Estados Unidos. Por lo tanto, los dueños de. Novofresh deciden contratar a Todd Offresco como asesor
 comercial, para que les ayude a entender mejor el problema y proponer vías de solución,
 El diagnóstico de Todd indica que gran parte del alto flujo de personas en la tienda proviene de turistas,
 quienes no compran surtidos de productos muy rentables para la empresa: “el desafío es ampliar y potenciar
 la base de clientes locales!, y asegurarse que la propuesta de valor de Novofresh responda a sus necesidades,
 y los invite a volver a la tienda con frecuencia y a recomendarla a sus familiares y amigos.” Ante este
 desafío, Offresco explica a los dueños de Novofresh:que es fundamental medir y gestionar la experiencia del
 cliente durante su visita a la tienda. “Es necesario capturar las reacciones, sentimientos, motivaciones y
 comportamientos de los consumidores antes de que estos elementos sean racionalizados y filtrados por la
 memoria. Esto es particularmente relevante en tiendas de este tipo, en que el cliente no sólo viene a comprar
 productos de “su canasta típica”, sino que a buscar soluciones alimenticias, y disfrutar el proceso de compra,”
 argumentaba Offresco.
 Los dueños de Novofresh, convencidos con el planteamiento de Offresco, deciden contratar a la empresa
 RevNext, que ofrece un servicio de medición y gestión de- experiencia de clientes en tienda, a través de los
 propios teléfonos inteligentes (smartphones) de los clientes. ¿Cómo funciona? Primero, usando la base de
 datos de clientes locales de la tienda, se invita a unos 20 clientes a que participen de un estudio de mercado
 durante 2 semanas, y como agradecimiento se les entrega una canasta de productos seleccionados al término
 del estudio. Para que este grupo represente a la clientela de Novofresh, se reclutan personas de distintas
 edades y ciclos de vida familiar. Luego se instala la aplicación RevNext en los teléfonos inteligentes de los
 participantes y se acuerda con cada uno un plan de visitas a la tienda, en días y horarios específicos.
 Una vez en la tienda, la aplicación RevNext conecta en línea al cliente (a través de su teléfono) con un
 investigador, quien desde su oficina monitorea el recorrido del cliente en la tienda, recibe sus comentarios y
 ! Chentes “locales” son aquellos q que viven en Seattle, yy P por lo tanto . no incluye a los turistas q que visitan la tienda.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 240

[pág. 241]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2015 | pregunta 5
 Convocatoria 1 | página original 169 | Mystery shopper y diseño exploratorio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 1»
 le hace preguntas. A continuación se indican algunos ejemplos de los principales usos de la aplicación
 RevNext:
 El cliente informa, al ingresar a la tienda, si viene solo o acompañado (y con quién).
 El investigador le pregunta al cliente, mediante un mensaje de texto “¿qué andas buscando en este
 l
 momento? Opciones: algo de aperitivo, algo para el almuerzo, algo de postre, algo para regalo, otra
 cosa,” (El cliente debe marcar sus opciones en el teléfono).
 El cliente saca una foto de una exhibición de productos que le parece confusa y se la manda al
 investigador con algún comentario al respecto.
 El cliente filma su propia cara haciendo un comentario al investigador, ya sea espontáneamente o a partir
 de alguna pregunta del investigador.
 El investigador pregunta al cliente si vio o no una determinada promoción y qué tan atractiva le parece.
 El cliente le responde a través de su teléfono.
 Si hay una cola muy larga en las cajas, el cliente puede manifestar su incomodidad con tal situación
 simplemente haciendo un c/ick en un ícono que indica “colas muy largas”.
 El cliente registra lo que compra y el investigador le pregunta en ese momento por qué está lievando un
 determinado producto.
 El cliente manifiesta sus emociones, en diversas etapas de la compra, a través de una serie de emoticons
 (caras con distintas expresiones, por ejemplo cansado, enojado, contento, entretenido, etc.).
 Inmediatamente terminada la compra, el investigador le pregunta al cliente qué tan satisfecho quedó con
 la experiencia en Novofresh, si encontró todo lo que buscaba, si espera volver dentro de una semana, si
 recomendaría la tienda.a un amigo, etc.
 PREGUNTAS
 1) ¿Cuáles son los principales beneficios y las principales limitaciones del enfoque de investigación
 utilizado, en relación al problema que enfrenta Novofresh, y al objetivo de medir y gestionar la
 experiencia de los clientes? Refiérase tanto a aspectos relacionados con la implementación de la
 metodología (aplicación RevNext), como a su pertinencia en cuanto a los resultados y conclusiones que !
 !
 A
 se podrían obtener. Sea preciso y conciso en su respuesta.
 2) En la última reunión de Directorio de Novofresh, el Gerente General presentó con mucho orgullo el
 estudio que realizarían con RevNext. A pesar del entusiasmo con que varios directores acogieron laidea,
 hubo uno que se mostró escéptico, planteando lo siguiente: “sinceramente no creo que tengamos que
 reinventar la rueda; yo sugiero hacer un estudio de cliente incógnito, de la siguiente forma:
 investigadores preparados se hacen pasar por clientes y reportan una serie de aspectos objetivos del
 servicio entregado en la tienda, tales como la disponibilidad de productos, los precios de ciertos
 productos, la cantidad de minutos que dura la cola, si estaba o no visible el material publicitario, si la
 cajera sonrió o no al interactuar con el cliente, etc. Si logramos completar 300 informes de este tipo,
 tendremos resultados muy contundentes sobre la experiencia de los clientes, que nos permitirían mejorar
 la rotación de productos, compra promedio y rentabilidad de la tienda.” ¿Está usted de acuerdo con el
 comentario de este director? ¿Por qué sí o por qué no? Justifique su respuesta. Suponga que el costo de la
 propuesta planteada por este director es equivalente al costo del estudio RevNext.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 241

[pág. 242]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2014 | pregunta 5
 Convocatoria 2 | página original 156 | Necesidad y diseño de investigación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA
 N* 5
 Balmaceda es una compañía chilena de danza moderna que crea montajes para hacer presentaciones en salas
 de teatro y espectáculos en las pr1n01pales ciudades del país. Según Enrique Balmaceda, su fundador y
 director ejecutivo, “...nuestra misión es llevar la danza moderna a muchos espectadores, a través de
 espectáculos n0vedosos que logren una conexión emocional con la audiencia”. La compañía Balmaceda ha
 sido exitosa en Chile, por lo que ahora se plantean un nuevo desafío: crecer a través de una expansión al
 resto de los países de Latinoamérica, es decir, llevar espectáculos de danza moderna nuevos y de alta calidad
 a audiencias de otros países de la región.
 Con el fin de llevar a cabo éste desafío, la compañía ha contratado recientemente como Gerente de
 Marketing a Natalia, una ex bailarina de la compañía, que hasta hace poco se desempeñaba de manera
 exitosa como gerente de negocios de una tienda de ropa deportiva. Enrique Balmaceda le ha encargado a
 Natalia que diseñe e 1mplemente la estrategia de expansión internacional de la empresa.
 El primer desafío de Natalia es desarrollar los nuevos “productos” que se ofrecerán, es decir, crear los
 espectáculos específicos de danza moderna que se presentarán en el resto de Latinoamérica. Con este
 objetivo en mente, y aprovechando la experiencia adquirida en su trabajo anterior, Natalia le plantea a
 Enrique Balmaceda la necesidad de realizar estudios de mercado de consumidores (audiencia potencial) en
 esos otros países. Sin embargo, y para su sorpresa, Natalia se encontró con la siguiente respuesta de Enrique:
 “No necesitamos hacer estudios de mercado de consumidores. ¿Por qué tenemos que preguntarle a la
 audiencia lo que quiere? Cuando las personas vienen a nuestro show, esperan una experiencia única y
 Jantástica, una que nunca podrán olvidar. ¿Cómo pueden las personas decir lo que quieren si nunca lo han
 visto? Si les preguntáramos, terminaríamos haciendo el tradicional ballet “El Lago de los Cisnes' todos los
 años. ” '
 En favor de la posición de Enrique Balmaceda, no son pocas las empresas que operan de acuerdo a esta
 filosofía de no involucrar a los consumidores en estudios de mercados conducentes a desarrollar nuevos
 productos. Por ejemplo: (i) la joyería Tiffany no le pregunta a las mujeres por el tipo de joyas que necesitan;
 (ii) Steve Jobs, de Apple señaló en una oportunidad: “. . muchas veces las personas no saben lo que quieren
 - hasta que lo ven” y (iii) Mario D” Amico, V1cepresrdente de Marketing de Cirque du Soleil, declaró hace
 algún tiempo“... cualquier empresa innovadora se cuestiona cuánto se debe preguntar a los co_nsumzdores,
 la misión central de nuestra compañía es hacer lo que ningún consumidor espera que hagamos”.
 PREGUNTAS
 1) ¿Está Ud. de acuerdo con la posición de Enrique Balmaceda, en cuanto a que la compañía no debería
 hacer estudios de mercado con los potenciales consumidores (audiencia) de los espectáculos de danza
 moderna, y con los argumentos que él plantea? Justifique su respuesta.
 2) Suponga que Enrique Balmaceda, para no frustrar a Natalia y darle la oportunidad de demostrar el valor
 de su propuesta, acepta que se realice un solo estudio de mercado con la audiencia potencial, definida
 como personas de grupos socioeconómicos medios y altos, que asisten al menos 4 veces al año a
 espectáculos artísticos en los ámbitos de teatro, danza, o música. Natália debe decidir cuál de las
 siguientes metodologías de investigación (recolección de datos) utilizar: (a) encuestas presenciales en
 hogares, utilizando un cuestionario estructurado (preguntas cerradas) de unos 20 minutos de duración;
 (b) entrevistas en profundidad de 45 a 60 minutos de duración, en un lugar especialmente habilitado para
 ello; o (c) etnografía, en que durante e inmediatamente después de la realización de espectáculos de
 teatro, danza o música, se observa a la audiencia y se interactúa con ella a través de breves entrevistas (3
 a 5 minutos). ¿Cuál de estas tres opciones elegiría y por qué? Fundamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 242

[pág. 243]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2018 | pregunta 5
 Convocatoria 2 | página original 274 | Panel, frecuencia y Assessor
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA N* 5
 el cuidado
 Siguiendo los pasos del mercado de productos para el cuidado de la piel, la industria de productos para
 del mundo, importantes cambios, Motivado por la
 del cabello está enfrentando, en la mayoría de los mercados
 s prestan al cabello, en muchos países se observa una tendencia hacia el
 creciente atención que los consumidore
 se ajusten mejor a las necesidades individuales y a los deseos de lograr una
 consumo de productos que
 fortalecen,
 determinada apariencia. Las personas ya no sólo se lavan el cabello, también lo hidratan, protegen,
 etc.
 De acuerdo a la empresa de investigación de mercado IRI, en el mercado en EE.UU., las categorías de productos
 muy en línea con el
 relacionadas con el cuidado del cabello han tenido un crecimiento leve en Jos últimos años,
 crecimiento de la población. La composición de este ligero crecimiento, sin embargo, ha sido muy heterogénea.
 Los productos orgánicos y naturales son los que más han crecido. Los consumidores se han vuelto más conscientes
 de los ingredientes de los productos. Productos con sulfatos, accites minerales y alcohol, que alguna vez fueron
 ampliamente usados, se han transformado en tabú en las nuevas formulaciones.
 En Chile, según el panel de consumidores Kantar
 WorldPanei que mide las conductas de compra de un panel
 de 2.000 hogares en las principales ciudades de Chile, los
 productos de belleza y cuidado de la piel tuvieron un
 crecimiento importante el 2017. En particular, las
 categorías de cuidado del cabello, que incluye
 fundamentalmente los shampoo y los acondicionadores,
 tuvieron un crecimiento cercano al 2,5%.
 La Tabla siguiente muestra indicadores de desempeño de
 categoría y de marca para las categorías Shampoo y
 la
 Acondicionador en Chile, según el panel de Kantar WorldPanel. Para los años 2016 y 2017, la tabla muestra
 penetración de mercado (% de hogares que compran el producto), la frecuencia de compra o número de visitas
 en las cuales se compra la categoría (0 marca) y el ticket (o valor) promedio por visita. Todos los indicadores
 corresponden a un perfodo de un año. Las dos últimas filas de la tabla muestran los indicadores correspondientes
 a la empresa líder en ambas categorías.
 Tabla: Indicadores de Desempeño de Shampoo y Acondicionador de Pelo
 Categoría y Marca Lider de las Categorías (datos anuales)*
 170 Frecuencia Gasto por
 . Penetración (%) Compras Compra ($)
 Categoría 2016 12017 2016 2017 2016 2017
 Shampoo 996 992 98 10,0 2354 2314
 944 940 6,7 6,7 2.025 2.030
 Acondicionador
 Shampoo Líder Categoría 56,3 55,9 2,9 3,3 3473 3169
 Acondicionador Marca Líder 35,5 345 22 23 2 991 3.044
 Categoría
 y las otras marcas.
 (*) Los datos corresponden a hogares. Suponga formatos iguales entre la marca líder de la categoría
 refieren al total del
 Suponga que en un año el consumo y la compra coinciden. Los datos de penetración de marca se
 mercado y no a los que compran la categoría.
 PREGUNTAS
 panel de
 a) Describa las ventajas que tiene para el análisis de los datos de desempeño de categoría y marca un
 consumidore s, en relación a muestras independient es en cada período. Sea preciso en su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 243

[pág. 244]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2018 | pregunta 5
 Convocatoria 2 | página original 275 | Panel, frecuencia y Assessor
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 de
 b) Suponga que los ejecutivos de la marca líder de las categorías analizan la tabla con los indicadores
 el cuidado del cabello debieran enfatizar una estrategía de
 desempeño y discuten si en productos para
 para
 crecimiento basada en (i) la penetración o en (ii) la frecuencia. Suponga costos de inversión semejantes
 Proponga una (y sólo una) de estas estrategias, a la luz de los datos presentados en la
 estas dos estrategias.
 Tabla y considerando los patrones usuales de indicadores de desempeño en productos de consumo masivo.
 Justifique s respuesta.
 orgánicos
 Suponga que el líder del mercado desarrolla un nuevo acondicionador en base a ingredientes
 y naturales y que después de 3 meses dispone de los datos de penetración y frecuencia para ese trimestre.
 alcanzar el muevo producto después de 12
 Proponga un modelo para estimar la penetración que podría
 meses. Explique sin usar fórmulas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 244

[pág. 245]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2016 | pregunta 5
 Convocatoria 1 | página original 193 | Participación y conjoint
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA N*5
 En Junio de 2016 entrará en vigencia la nueva Ley de Etiquetado Nutricional de Alimentos en Chile que afecta
 a alimentos con altas cantidades de calorías, grasa total, azúcares o sodio. El objetivo de la Ley es informar a
 la población de aquellos alimentos que pueden resultar perjudiciales para la salud cuando se consumen en
 exceso, La nueva Ley establece que, los alimentos que no cumplan los estándares fijados por el Ministerio de
 Salud, deberán colocar en sus envases advertencias en sellos de color negro con frases de la forma ”alto en”
 calorías, grasas saturadas, azúicares o sodio, según corresponda. Para la industria alimentaria, esta norma
 representa un desafío en términos de desarrollar tecnologías que permitan modificar la composición de los
 alimentos a fin de mejorar su calidad nutricional.
 Se estima que, en algunas categorías de productos, la mayoría de las marcas deberán colocar el sello negro
 (como se muestra en la figura de más abajo) y sólo unas pocas marcas estarán liberadas del sello mencionado
 al cumplir los estándares que ha determinado la autoridad. La pregunta que muchas empresas que fabrican y
 comercializan productos alimenticios se están haciendo en Chile es cómo va a reaccionar el consumidor ante
 este nuevo escenario en el mercado.
 ALTO EN ALTO EN
 SoDIO CALORÍAS
 Minaerio fristario
 de Baluó b S Tn Saa
 Una de las categorías que se podría ver afectada de manera muy significativa con la nueva normativa es la de
 “mantequillas”. En ésta categoría existen tres líneas de producto: las de buen sabor (como atributo distintivo),
 las supuestamente saludables ( que tienen un atributo funcional como “light”, “bajo en sodio”, etc, y que no
 necesariamente cumplen la nueva norma) y las económicas (de bajo precio relativo). El Cuadro 1 muestra
 estadísticas de ventas del año 2015 para toda la categoría de “mantequillas” 1 y para el fabricante H Foods que
 tiene una extensión de marca diferente en cada una de las líneas mencionadas. En los últimos años, las
 preferencias del consumidor por las distintas líneas en esta categoría no han variado de manera importante.
 Cuadro 1: Ventas Categoría Mantequillas
 Ventas Volumen 2015 Ventas Valor 2015
 (miles de kilos) (millones de $)
 Total Categoría . 18.522 42.281
 Sabor 11.570 26.775
 Saludable 3.228 9.679
 Económico 3.724 5.827
 Total H Foods 7.147 14.808
 Sabor 4.647 10.271
 Saludable 803 2.184
 Económico 1.697 2353
 H Foods ha estado trabajando en los últimos meses en el desarrollo de una mantequilla que cumple las nuevas
 normas y por tanto no requeriría del sello negro “alto en ...” Los ejecutivos de H. Foods creen que esta nueva
 mantequilla podría ser la única en el mercado en cumplir la norma. Si bien este producto está listo para salir al
 mercado, el principal inconveniente que se ha detectado, en estudios de sabor, es que tiene un desempeño en
 este atributo significativamente más bajo que las otras mantequillas que se comercializan actualmente.
 1 La información contenida en este caso es real, aunque algunos datos han sido modificados para resguardar la
 confidencialidad.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 245

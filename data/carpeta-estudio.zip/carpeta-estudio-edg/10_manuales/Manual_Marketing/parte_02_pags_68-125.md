# Manual de Marketing · parte 2 (páginas 68-125)

Fuente: 01_MANUAL_ULTIMATE_MARKETING_EDG_2027_V2_FORMULAS_Y_METRICAS_CLARAS

[pág. 68]
Marketing - versión clara y reordenada
 transformacional relaciona la experiencia con un significado. Pueden coexistir. Ninguna justifica
 promesas no verificadas: la fuerza persuasiva debe apoyarse en evidencia pertinente cuando hace
 afirmaciones sobre desempeño.
 Diseñar un brief y una campaña
 El apunte organiza decisiones con misión, mercado, mensaje, medios, dinero y medición, junto con
 la ejecución creativa. La misión define conducta y objetivo; el mercado especifica público y
 situación; el mensaje propone beneficio y evidencia; los medios determinan contacto; el dinero
 asigna recursos; la medición establece cómo se evaluará. Un brief útil añade restricciones,
 entregables y responsabilidades.
 Ejemplo didáctico: una aplicación de planificación médica no necesita simplemente «más
 notoriedad». La investigación podría mostrar que las personas no reservan porque no entienden si
 la hora queda confirmada. La tarea es comunicar confirmación y facilitar el primer agendamiento. La
 pieza debe demostrar el proceso; el canal debe alcanzar a quienes buscan atención; el producto
 debe cumplir la promesa. Se mide comprensión, reservas completadas y cumplimiento, y se
 compara con una referencia adecuada.
 Los recursos creativos -personajes, historias, demostraciones, testimonios- se eligen por el
 mecanismo. Una historia memorable puede fallar si el público no recuerda qué marca la ofreció. Un
 testimonio puede generar confianza o parecer poco creíble. La ejecución debe permitir atribuir la
 propuesta a la marca y respetar las condiciones del beneficio. No basta describir una pieza
 «emocional» o «viral» sin conexión con objetivo.
 Alcance, frecuencia y embudos
 Alcance cuenta personas u hogares distintos expuestos. Frecuencia es el promedio de
 exposiciones entre los alcanzados. Los GRP se obtienen multiplicando alcance expresado como
 porcentaje por frecuencia media. Un alcance de 40% y frecuencia 3 produce 120 GRP. Eso no
 significa que se haya alcanzado al 120% de la población: hay exposiciones repetidas.
 CPM expresa costo por mil impresiones bajo una definición explícita. Si una campaña cuesta
 500.000 y entrega 200.000 impresiones, el CPM es 500.000/200.000×1.000=2.500. Si se cambia el
 denominador a personas únicas, se mide otra relación. Ni CPM bajo ni GRP alto demuestran
 rentabilidad o efecto causal sobre ventas.
 El árbol de respuesta de p.100 usa probabilidades condicionales. Con 63% de conciencia,54% de
 comprensión entre quienes tienen conciencia,77% de interés entre quienes comprenden,68% de
 intención entre interesados y 90% de compra entre quienes declaran intención, la proporción final
 es 0,63×0,54×0,77×0,68×0,90≈0,1603:16,03% de la población inicial. No se multiplica por quienes
 no están interesados. No se deben multiplicar porcentajes marginales medidos en toda la población
 como si fueran condicionales.
 Las pérdidas del árbol permiten localizar una hipótesis de intervención. Mejorar comprensión puede
 ser prioritario si ahí se pierde una parte grande y existe una pieza confusa; también hay que
 considerar costo y capacidad de modificar cada transición. La identidad del embudo no prueba que
 un anuncio cause toda compra final. Para estimar incremento hay que comparar con lo que habría
 ocurrido sin la intervención, como se explica en Analytics.
Examen de Grado UC | materia, preguntas y respuestas 68

[pág. 69]
Marketing - versión clara y reordenada
 Presupuesto y presencia temporal
 Presupuestar por ventas, historia o competencia puede ser simple, pero no demuestra que el monto
 sea suficiente ni óptimo. El enfoque por objetivos y tareas parte del cambio buscado, acciones
 necesarias, costo y evaluación. Debe reconocer incertidumbre y permitir ajustar si la respuesta no
 coincide con la esperada.
 Una presencia continua mantiene exposición; flighting alterna períodos de actividad y pausa; una
 estrategia pulsante combina base con intensificación. Se eligen por ciclos de demanda,
 recordación, desgaste creativo, disponibilidad y recursos. No hay una pauta universal para toda
 marca. Aumentar presión mientras no existe stock puede desperdiciar recursos y decepcionar
 clientes.
 13. Marketing digital y automatización
 Digital, automatización y ética como decisiones de marketing
 Ecosistema, RACE y comportamientos digitales
 Medios propios (sitio, aplicación, base de contactos autorizados), pagados (anuncios y patrocinios)
 y ganados (recomendaciones, reseñas y cobertura) cumplen funciones distintas. Los propios
 ofrecen control pero necesitan contenido, servicio y tráfico; los pagados compran acceso y
 requieren economía de adquisición; los ganados pueden aportar credibilidad, pero su mensaje y
 permanencia tienen menos control. Una reseña incentivada no debe tratarse como recomendación
 espontánea sin reconocer el incentivo.
 RACE ordena Reach, Act, Convert, Engage: llegar, facilitar interacciones pertinentes, convertir
 una conducta definida y sostener una relación. Cada etapa necesita un resultado y un denominador.
 «Convertir» puede ser compra, solicitud, reserva o inscripción; hay que especificarlo. Engagement
 no demuestra por sí solo lealtad rentable. No se debe sumar personas únicas de varios canales sin
 eliminar duplicaciones.
 Los apuntes manuscritos de Maida Palacios desarrollan cinco comportamientos digitales: acceso,
 personalización, conexión, engagement y colaboración (APCEC). Úsalos como preguntas
 sobre la experiencia. Acceso: ¿la persona obtiene información o servicio fácil y oportunamente?
 Personalización: ¿puede adaptar una oferta relevante con un costo y uso de datos aceptables?
 Conexión: ¿puede interactuar con otras personas y recibir respuesta? Engagement: ¿el contenido
 merece su atención por utilidad o experiencia? Colaboración: ¿puede contribuir a una solución o
 proyecto colectivo? Facilitar comentarios no equivale a cocrear un producto; una actividad debe
 ofrecer influencia y retroalimentación reales para llamarse colaboración.
 SEO mejora acceso y pertinencia del contenido en búsqueda orgánica; la publicidad de búsqueda
 paga por exposición o interacción según su modalidad. En estos materiales, SEM se usa para
 búsqueda pagada. Una posición orgánica requiere trabajo de contenido y experiencia, por lo que no
 es económicamente gratuita; tampoco se compra una posición orgánica por pagar un anuncio. Para
 decidir, diferencia búsqueda de marca, que puede capturar demanda existente, de búsquedas
 genéricas donde compites por nuevos clientes.
 Ejercicio de embudo. Una campaña genera 100.000 impresiones, 2.000 clics y 80 compras;
 cuesta $600.000. CTR=2.000/100.000=2%; conversión clic→compra=80/2.000=4%; CPC= $300;
Examen de Grado UC | materia, preguntas y respuestas 69

[pág. 70]
Marketing - versión clara y reordenada
 costo por compra atribuida= $7.500. Con margen de $10.000 por compra, margen atribuido=
 $800.000. Si un control indica que solo 30 compras fueron incrementales, margen incremental=
 $300.000 y resultado neto incremental=-$300.000. La campaña puede tener un costo por compra
 aparentemente bueno y perder dinero causalmente. Usa CAC solo si las compras corresponden
 efectivamente a nuevos clientes adquiridos; compra, conversión y cliente no son la misma unidad.
 Storytelling organiza mensaje, personajes, conflicto y trama para hacer comprensible y memorable
 una promesa. Parte de audiencia, problema y conducta deseada; define qué evidencia sostiene el
 relato y cómo distribuirlo. Un relato emocionante no justifica inventar resultados, exagerar
 beneficios o reemplazar información esencial. Se verifica con comprensión, asociaciones y
 conducta pertinente, además de métricas de atención.
 Qué automatizar y cómo verificar la inteligencia artificial
 Automatización ejecuta reglas o procesos; machine learning estima patrones a partir de datos;
 modelos generativos producen contenido según un modelo aprendido. No todos los procesos
 automáticos son IA. Tampoco tener IA equivale a capacidades humanas generales, elimina errores
 o garantiza mayor retorno. La evaluación depende de la tarea: recomendación de producto,
 clasificación de mensajes, priorización comercial o previsión de demanda.
 Un sistema necesita tres funciones conectadas: registro confiable de clientes/interacciones;
 ejecución de acciones coherentes; y análisis para medir resultados y corregir. Si el registro duplica
 clientes, el motor puede enviar mensajes contradictorios; si la variable objetivo premia clics, la
 optimización puede elevar clics irrelevantes; si se entrena con ventas históricas que nunca
 ofrecieron cierto producto a un grupo, puede perpetuar esa ausencia sin descubrir su demanda.
 Procedimiento de evaluación. Define decisión, población y costo del error; documenta datos y
 permisos; separa entrenamiento de evaluación temporal; compara una regla simple; revisa
 calibración y desempeño por grupos; prueba el efecto de la acción con una evaluación adecuada;
 establece revisión humana, límites y monitoreo de deriva. Para un chatbot, incluye exactitud,
 comprensión, resolución, derivación a una persona y daño de una respuesta falsa. Para campañas,
 evalúa contribución incremental y fatiga, no solamente precisión predictiva. Para contenido, verifica
 hechos y coherencia de marca antes de difundir.
 Ética y responsabilidad: argumentar sin eslóganes
 Cuatro lentes ayudan a discutir una decisión. El utilitarismo considera beneficios y daños de todos
 los afectados; no se reduce a maximizar utilidad de la empresa. Los derechos preguntan si se
 respetan autonomía, información y privacidad. La justicia examina criterios de distribución y
 procedimiento; tratar situaciones distintas exactamente igual no siempre es justo. Los contratos
 sociales consideran compromisos y expectativas legítimas, sin usar «es la costumbre» como
 excusa para un daño.
 Caso. Una empresa desea personalizar precios usando datos que revelan urgencia o
 vulnerabilidad. Analiza valor entregado, acceso y costos, pero también si el cliente comprende el
 uso de datos, puede elegir y recibe información adecuada. Compara una segmentación por servicio
 con explotación de una restricción personal. Define revisión de variables, transparencia,
 reclamaciones y controles de efectos por grupo. Los apuntes no sirven como dictamen jurídico:
 clasificar toda diferencia de precio como ilícita es una simplificación incorrecta; el análisis normativo
 concreto requiere revisar la regla y contexto aplicables.
Examen de Grado UC | materia, preguntas y respuestas 70

[pág. 71]
Marketing - versión clara y reordenada
 Una política responsable integra integridad de producto, veracidad de comunicación, condiciones
 de venta, privacidad, abastecimiento y efectos ambientales/sociales. Tiene responsables,
 indicadores y canales para corregir. Una declaración de valores no compensa incentivos que
 premian ocultar reclamos. Reconoce racionalizaciones de daño: negar responsabilidad, negar
 perjuicio, culpar a la víctima, descalificar a quien critica o invocar una lealtad superior. Una
 respuesta de caso explica quién soporta el daño, qué práctica lo produce y qué cambio concreto lo
 reduce.
 Digital e inteligencia artificial con criterio
 Owned, paid y earned distinguen medios propios, pagados y exposición obtenida mediante
 terceros. SEO trabaja visibilidad orgánica; no significa ausencia de costos. El uso de SEM en el
 curso suele referirse a búsqueda pagada, aunque los términos deben definirse. RACE organiza
 alcance, interacción, conversión y relación posterior. Se debe especificar qué conducta cuenta en
 cada fase y evitar sumar personas duplicadas entre canales.
 La inteligencia artificial puede apoyar clasificación, predicción, personalización y generación. El
 aprendizaje automático forma parte del campo de IA; no se invierte esa relación ni se asume que
 toda automatización aprende. Predecir quién comprará no equivale a identificar a quién persuadirá
 una campaña: personas con alta probabilidad de compra podrían comprar sin contacto. La
 intervención exige evaluar resultado incremental, costos y consecuencias.
 Una aplicación necesita datos pertinentes, calidad, controles y seguimiento. Se puede comparar
 con una regla simple, evaluar fuera de la muestra o en períodos posteriores y comprobar errores
 por grupos. El contenido generado necesita revisión de exactitud y promesas. Las afirmaciones del
 apunte sobre conversiones garantizadas, eliminación de errores o cifras tecnológicas de años
 pasados no se presentan como evidencia vigente.
 14. Ética y responsabilidad comercial
 Ética, incentivos y responsabilidad social
 La ética comercial analiza qué se hace y cómo afecta a personas y grupos. Una mirada de
 consecuencias evalúa beneficios y daños; una de deberes o derechos considera restricciones que
 no se resuelven solo sumando resultados; la virtud pregunta por hábitos y carácter; la justicia
 examina distribución y trato. Estos enfoques pueden conducir a tensiones reales. Reconocer una
 tensión no permite justificar engaño mediante una conveniencia económica.
 La conducta depende de personas y de sistemas. Objetivos imposibles, premios mal diseñados,
 presión y controles débiles pueden favorecer malas prácticas. Las neutralizaciones descritas en el
 apunte -negar responsabilidad, daño o víctima, descalificar críticos o apelar a una lealtad superior-
 ayudan a reconocer excusas. El diagnóstico debe llevar a acciones: revisar métricas, promesas,
 permisos, supervisión y canales para corregir problemas.
 La responsabilidad social incorpora relaciones con empleados, entorno, comunidad y
 consumidores. Una donación no compensa automáticamente una oferta engañosa o un daño
 central del negocio. Una evaluación necesita considerar impactos, evidencia y trade-offs, además
 de reputación. Mejorar prácticas puede fortalecer confianza y reducir ciertos riesgos, pero no
 garantiza por sí solo mayor rentabilidad, crédito más barato o supervivencia.
Examen de Grado UC | materia, preguntas y respuestas 71

[pág. 72]
Marketing - versión clara y reordenada
 El resumen afirma que la publicidad comparativa está prohibida en Chile. Esa generalización se
 corrige: la Ley 20.169 identifica como desleales las comparaciones que no se apoyan en
 antecedentes veraces y demostrables o que contravienen esa ley. La exigencia para estudiar es
 verificar las afirmaciones comparativas y el contexto; no concluir que toda comparación es ilícita.
 Verificación externa puntual,11 de octubre de 2026: Biblioteca del Congreso Nacional, Ley
 20.169, artículo 4.
 Cómo cerrar una respuesta
 Una respuesta académica completa plantea objetivo y público, explica el mecanismo de
 comunicación, propone ejecución coherente con la entrega, define presupuesto o criterios de
 asignación y establece medidas. También considera riesgo de interpretación, veracidad y efectos
 no deseados. Si existe un problema ético, identifica afectados y alternativas, fundamenta la elección
 y diseña controles. La recomendación debe poder ejecutarse y evaluarse.
 Base local: resumen completo, pp.95-119, con revisión del modelo integrado p.97 y el árbol de
 respuesta y pauta temporal p.100. Se excluyen como hechos actuales los porcentajes históricos de
 inversión publicitaria y afirmaciones sin respaldo de causalidad o legalidad.
 15. Lecturas y comprensión profunda del cliente
 Lecturas de Fundamentos: mecanismos y aplicación
 Jobs to Be Done: explicar el progreso en una circunstancia
 Christensen, Hall, Dillon y Duncan proponen investigar el progreso que una persona intenta lograr
 en una circunstancia y cómo una oferta ayuda a hacerlo. Un «trabajo» no equivale a una
 característica del producto ni a un cargo del comprador. Incluye dimensiones funcionales,
 emocionales y sociales, alternativas, ansiedad y barreras de cambio. La demografía describe quién;
 la circunstancia y el trabajo ayudan a explicar por qué una solución es contratada o abandonada. El
 enfoque complementa segmentación, investigación y pruebas; una entrevista narrativa no identifica
 por sí sola un efecto causal estadístico.
 Procedimiento. Entrevista a quienes compraron recientemente, abandonaron o cambiaron de
 solución; reconstruye el detonante, la búsqueda, alternativas, dudas, decisión y experiencia
 posterior. Pregunta qué intentaban lograr, qué hacían antes, qué solución improvisaban y qué los
 frenaba. Busca no consumo, tareas que quieren evitar y usos inesperados. Separa una petición de
 atributo («quiero una función más») del progreso que haría útil esa función. Contrasta relatos con
 observación o transacciones y casos que contradigan tu hipótesis. Después traduce el trabajo en
 experiencia, procesos, canal, precio y criterio de éxito.
 Caso de aplicación. Una persona adulta que trabaja no solo busca comprar cursos: puede intentar
 mejorar credenciales sin perder ingreso ni abandonar responsabilidades familiares. El programa
 debe resolver horario, reconocimiento de antecedentes, información de costos, apoyo y ritmo;
 cambiar publicidad sin cambiar procesos no entrega el trabajo. Compara ese progreso con el de un
 estudiante que busca experiencia universitaria presencial. Las dos ofertas pueden compartir
 contenido académico y necesitar experiencias, soporte y modelos económicos diferentes. Evalúa
 permanencia, aprendizaje, finalización y costo de servir, además de inscripción inicial.
Examen de Grado UC | materia, preguntas y respuestas 72

[pág. 73]
Marketing - versión clara y reordenada
 Investigación tradicional y conocimiento profundo
 Straker, Bucolo y Wrigley comparan investigación de mercado y métodos de conocimiento profundo
 del cliente. La lectura local informa entrevistas a representantes de once empresas, por lo que sus
 conclusiones deben entenderse dentro de ese diseño; no es un experimento que demuestre que
 todo focus group fracasa o que toda narrativa produce innovación. El aporte es decidir qué
 conocimiento hace falta y combinar métodos.
 Durante ideación, observación, narrativas, personajes y escenarios pueden revelar contradicciones
 entre lo que las personas dicen y hacen, necesidades latentes y oportunidades. En desarrollo,
 prototipos y escenarios comprueban comprensión y experiencia. Cuando la alternativa madura,
 investigación estructurada dimensiona preferencias, restricciones y población; un piloto conductual
 verifica resultados. No conviertas esa secuencia en una ley: una decisión pequeña puede iterar
 rápidamente, y un riesgo alto puede exigir evidencia robusta desde el inicio.
 La cercanía de empleados al cliente puede mejorar interpretación y acción, pero también introducir
 afinidad, confirmación o proyección. Un proveedor externo puede aportar independencia y
 especialización, y aun así perder contexto. Define cómo registrar evidencia, discutir interpretaciones
 y transferir aprendizaje al responsable de decidir. Una persona ficticia es una herramienta para
 explorar, no evidencia de que un segmento existe. La utilidad de un insight se demuestra cuando
 modifica una hipótesis y permite diseñar una prueba o una oferta mejor.
 Neuromarketing: señal, constructo y decisión
 La lectura resumida de Harrell trata señales neuronales y fisiológicas como fuentes
 complementarias de información. Diferencia la medición observada del concepto inferido y de la
 conducta que interesa. Seguimiento ocular localiza mirada; no prueba agrado o compra. Una
 respuesta de activación fisiológica no distingue por sí sola emoción positiva de negativa. La
 actividad medida en una región o una señal eléctrica requiere diseño e interpretación
 especializados: no equivale a «leer la mente» ni a una disposición a pagar observable.
 El EEG permite observar cambios eléctricos con resolución temporal útil; la resonancia funcional
 observa un correlato hemodinámico de actividad, con otras restricciones de costo y situación de
 medición. Ninguno sustituye automáticamente una prueba comercial. En evaluación creativa, una
 medida puede localizar momentos que atraen atención y ayudar a reformular una pieza; después se
 comprueba comprensión del mensaje, asociación a la marca y conducta pertinente. Un anuncio
 sorprendente puede elevar atención y no producir la respuesta deseada.
 Decisión resuelta. Una firma debe elegir entre dos empaques. Si la duda es visibilidad en góndola,
 una prueba de mirada puede servir; si es interpretación de beneficios, usa comprensión y
 entrevistas; si es compra rentable, incorpora precio, disponibilidad y prueba conductual. Compara el
 valor incremental de información con el costo y tiempo. Exige un criterio de validación fuera de la
 muestra, una comparación con un método simple, controles del diseño y claridad sobre qué puede
 concluirse. Considera consentimiento, privacidad y riesgo de manipulación. Las posibilidades
 especulativas de influencia mencionadas en una lectura histórica no se presentan como tácticas
 recomendadas ni como capacidades comerciales establecidas.
 Fuentes locales. Resumen «Know Your Customers’ Jobs to Be Done», Resumen «Comparing and
 Complementing Methods» y Resumen «Neuromarketing: What You Need to Know», atribuidos a
 Deyanira Molina. Se leyeron sus textos completos (8, 8 y 5 páginas, respectivamente). La atribución
Examen de Grado UC | materia, preguntas y respuestas 73

[pág. 74]
Marketing - versión clara y reordenada
 de autores originales procede del programa local de Fundamentos; estos resúmenes no se
 confunden con los artículos originales ni con una pauta oficial.
 16. Aplicación integral de Fundamentos
 A. Fundamentos de Marketing
 Del problema del cliente a una economía de valor
 Una empresa no crea valor porque tenga un producto técnicamente novedoso. Lo crea cuando una
 persona reconoce que la solución mejora una situación que le importa, puede acceder a ella y está
 dispuesta a entregar dinero, tiempo, datos o esfuerzo. La propuesta debe superar la alternativa real
 del cliente: otra marca, una solución improvisada, postergar la compra o no hacer nada. Por eso
 “competidor” significa cualquier opción que resuelve la misma necesidad, aunque pertenezca a otra
 categoría.
 Para analizar un caso, reconstruye cinco eslabones. (1) Situación y necesidad: quién enfrenta qué
 tarea, en qué contexto y con qué urgencia. (2) Beneficio percibido: funcional, económico, social,
 emocional o de riesgo reducido. (3) Sacrificio total: precio, búsqueda, aprendizaje, traslado,
 incertidumbre y costo de cambio. (4) Entrega: producto, servicio, canal, disponibilidad y experiencia.
 (5) Captura de valor: ingreso menos costos variables y costos de servir, más efectos de retención o
 de portafolio. Una promesa atractiva puede destruir valor si requiere subsidios permanentes,
 logística costosa o una frecuencia de recompra que el cliente no tendrá.
 Ejemplo. Una empresa vende un filtro de agua por $60.000 y cartuchos de $12.000 cada tres
 meses. El cliente compara costo inicial, instalación, sabor, confianza, reposición y costo de agua
 embotellada. La empresa compara margen del equipo con margen recurrente, tasa de reposición,
 devoluciones, servicio y costo de adquisición. Si cuesta $18.000 adquirir a un cliente y el margen
 del equipo es $10.000, la venta inicial pierde $8.000; la propuesta puede ser viable si la contribución
 descontada de reposiciones supera esa brecha y el cliente permanece. No basta afirmar “alto valor
 de vida”: se necesitan frecuencia, retención, margen, costo de servir y horizonte.
 El valor de vida de cliente no es simplemente ventas acumuladas. En forma simplificada, si cada
 periodo genera margen de contribución m, la probabilidad de retención es r y el descuento es d, el
 valor presente de margen de una relación de horizonte largo puede aproximarse como (CLV ≈ m
 r/(1+d-r)), bajo supuestos de margen y retención constantes y con el primer margen futuro recibido
 en el siguiente periodo. La fórmula sirve para sensibilidad, no como verdad: cambiar frecuencia,
 cohortes, costos de adquisición o riesgo puede alterar la decisión. Una recomendación distinguida
 explica qué dato domina el CLV y qué acción puede cambiarlo.
 Segmentación como hipótesis explicativa
 Segmentar es buscar grupos con diferencias relevantes en necesidades, respuesta o economía. No
 es dividir clientes por edad porque esos datos estén disponibles. Un segmento debe permitir
 responder por qué la propuesta, precio, canal o comunicación debería variar. Las variables pueden
 ser geográficas, demográficas, psicográficas, conductuales, por ocasión, necesidad o beneficio
 buscado. La variable describe; el mecanismo explica.
 Una secuencia defendible es: fijar mercado y unidad de análisis; formular necesidad o respuesta
 que puede variar; elegir variables anteriores a la decisión; formar grupos; describirlos con variables
Examen de Grado UC | materia, preguntas y respuestas 74

[pág. 75]
Marketing - versión clara y reordenada
 independientes; comprobar tamaño, crecimiento, margen, acceso y estabilidad; y decidir si la firma
 puede servirlos de forma diferenciada. Evita usar resultados de compra para formar los segmentos
 y luego afirmar que estos “explican” la compra sin validación. Tampoco confundas segmento
 atractivo con segmento servible: el tamaño debe descontar competencia, costo de adquisición,
 capacidad, regulación y poder del canal.
 Ejemplo. En cuidado dental se observan tres grupos: personas preocupadas por sensibilidad,
 hogares que priorizan precio y consumidores que compran productos premium por estética. Edad
 puede ayudar a describirlos, pero el plan se construye desde la tarea: sensibilidad requiere
 credibilidad y continuidad; precio requiere disponibilidad y un escalón de entrada; estética puede
 valorar resultados demostrables y marca. Para cada segmento prueba si la necesidad predice
 elección o disposición a pagar, y si la empresa puede entregar el beneficio. Si la comunicación usa
 “segmento joven” como explicación, pero no identifica ocasión, barrera o beneficio, el diagnóstico
 todavía es superficial.
 El targeting compara atractivo externo y ajuste interno. Una matriz útil incluye tamaño y crecimiento,
 intensidad competitiva, margen, sensibilidad al precio, accesibilidad, costo de servir, encaje con
 capacidades y riesgo de reacción. La empresa puede optar por cobertura amplia, marketing
 diferenciado, foco concentrado o personalización; cada una cambia escala, complejidad,
 consistencia de marca y exposición a shocks. En un examen, justifica la elección con capacidad
 real y compara una alternativa descartada.
 El posicionamiento es la asociación que se busca ocupar frente a alternativas en una situación de
 compra. Una declaración de posicionamiento puede ordenar: para quién, en qué marco de
 referencia, qué beneficio diferencial y qué razones para creer. No es un eslogan. Si se promete “el
 más conveniente” pero la reserva, el despacho y la atención fallan, la experiencia contradice la
 posición. Una marca puede medir conocimiento, asociaciones, consideración, elección y lealtad;
 ninguna métrica aislada representa todo el posicionamiento.
 Marca, producto e innovación: coherencia y riesgo
 La marca es un activo de memoria, significado y expectativa que reduce búsqueda e incertidumbre
 y facilita preferencia o prima de precio. La prueba empírica de marca debe distinguir notoriedad,
 asociaciones, calidad percibida, lealtad y conducta. Un alto recuerdo no garantiza elección; una
 prima pagada puede deberse a distribución o falta de alternativas. Arquitectura de marca organiza
 marcas corporativas, familiares, submarcas y extensiones. Una extensión aprovecha asociaciones
 existentes, pero solo si hay ajuste de categoría, beneficio y credibilidad. Si el nuevo producto
 incumple desempeño, el daño puede regresar a la marca madre.
 La innovación se juzga en dos mercados: el cliente debe adoptar y la empresa debe entregar. Para
 evaluar concepto, producto mínimo y lanzamiento, separa novedad, beneficio, sustitución y
 adicionalidad. Un nuevo SKU puede generar prueba pero canibalizar la línea más rentable; la
 canibalización no es siempre mala si retiene clientes que de otro modo migrarían a un competidor,
 pero debe medirse. Calcula contribución incremental del portafolio: margen del nuevo producto
 menos margen perdido de productos propios, promociones, costos de lanzamiento y capacidad
 adicional, más efectos plausibles en adquisición o retención.
 Puerta de inversión. Define antes de probar un umbral de avance: intención con precio,
 comprensión del concepto, prueba sensorial, conversión de piloto, recompra, contribución y tasa de
Examen de Grado UC | materia, preguntas y respuestas 75

[pág. 76]
Marketing - versión clara y reordenada
 reclamo. No uses una única cifra de “interés”. Las pruebas monádicas evitan comparación explícita;
 las comparativas facilitan trade-offs pero pueden inflar discriminación. Una degustación ciega
 estima producto; una prueba con marca mide el sistema producto-marca. El tamaño de muestra
 debe corresponder a la decisión: una prueba pequeña detecta problemas obvios, no
 necesariamente diferencias pequeñas entre subgrupos.
 Precio: disposición a pagar, elasticidad y contribución
 El precio cumple tres funciones a la vez: determina ingresos, selecciona clientes y comunica
 posicionamiento. La demanda responde al precio junto con ingreso, referencia, competencia,
 disponibilidad, costo de cambio y promociones. La elasticidad-precio puntual es (ε=(dQ/dP)(P/Q)).
 Si ε=-1,5, un alza pequeña de 1% se asocia aproximadamente con una baja de 1,5% en unidades,
 manteniendo lo demás constante. Para cambios grandes, no extrapoles esa aproximación lineal;
 usa la forma funcional estimada o prueba escenarios.
 Cálculo de contribución. Si precio neto es $10.000 y costo variable unitario $6.000, la contribución
 es $4.000. Con costos fijos de $8 millones, equilibrio inicial es 2.000 unidades. Si se reduce precio
 10% a $9.000 y costo variable permanece $6.000, la contribución cae a $3.000 y el nuevo equilibrio
 sube a 2.667 unidades (8.000.000/3.000). La baja requiere vender 33,3% más unidades solo para
 cubrir los mismos costos fijos. Esta cuenta omite reacciones competitivas, costo de capacidad,
 descuentos, mezcla y valor de vida; es un primer filtro, no una recomendación final.
 Los métodos de precio responden preguntas distintas. Cost-plus verifica cobertura de costos, no
 valor ni demanda. Competencia ubica referencias, pero no determina lo que el cliente pagaría.
 Gabor-Granger prueba compra ante precios sucesivos para una oferta concreta; puede sufrir
 anclaje y sesgo hipotético. Van Westendorp pregunta umbrales subjetivos de demasiado
 barato/caro; ayuda a explorar rango aceptable, no encuentra por sí solo precio que maximiza
 utilidad. Conjoint estima trade-offs bajo atributos y precios experimentales. Datos transaccionales
 estiman respuesta revelada, aunque precio y promoción pueden ser endógenos. Recomienda
 triangulación y una prueba de mercado controlada cuando el riesgo lo justifique.
 Discriminación de precios requiere diferencias observables en disposición a pagar, posibilidad de
 separar grupos, reglas legales/éticas y control de reventa o arbitraje. Versioning, paquetes, tarifas
 por uso y precios de plataforma no son idénticos. En plataformas de dos lados, puede ser eficiente
 subsidiar un lado para atraer el otro; debe identificarse elasticidad y efectos de red en ambos. Un
 descuento general puede aumentar ventas y destruir margen; la métrica correcta es contribución
 incremental neta, incluyendo compras adelantadas y canibalización.
 Canales y estrategia de llegada al mercado
 El canal resuelve disponibilidad, búsqueda, información, financiamiento, servicio, entrega y
 devolución. Cada intermediario agrega cobertura o capacidad y cobra margen; además puede
 controlar datos, experiencia, precio en vitrina y acceso al cliente. La pregunta gerencial no es
 “¿online o tienda?” en abstracto, sino qué tareas necesita resolver cada segmento y qué actor
 puede realizarlas con menor costo total y suficiente calidad.
 Mapea el canal desde descubrimiento hasta posventa: cómo conoce, compara, compra, recibe,
 usa, devuelve y repone el producto. Mide conversión por etapa, quiebres, costo logístico por orden,
 devoluciones, margen después de comisión, recompra, datos accesibles y conflicto entre canales.
 Omnicanalidad significa continuidad del proceso y la información, no presencia simultánea en todos
Examen de Grado UC | materia, preguntas y respuestas 76

[pág. 77]
Marketing - versión clara y reordenada
 los medios. Si la tienda física permite prueba y asesoría y el ecommerce permite reposición, pueden
 complementarse; si el canal online captura clientes ya existentes con comisión y descuento, la
 venta digital puede ser mayoritaria y la contribución incremental baja.
 Una decisión de distribución distingue cobertura intensiva, selectiva y exclusiva según búsqueda,
 posicionamiento, soporte y control. La exclusividad puede mejorar servicio o proteger inversión,
 pero reduce alcance. La cobertura intensiva facilita conveniencia, aunque puede generar conflicto y
 menor control. La estrategia debe incluir incentivos, inventario, territorio, información, estándares de
 servicio y resolución de disputas. Un intermediario no es solo un “costo”: puede aportar demanda y
 reducir costos de transacción.
 De la estrategia al plan y a la medición
 Un plan de marketing vincula diagnóstico, objetivo, segmento, propuesta, palancas, presupuesto,
 calendario, responsables y medición. Los objetivos deben separar resultados finales (contribución,
 retención, participación) de indicadores adelantados (consideración, disponibilidad, prueba,
 conversión). Un indicador de actividad -impresiones, publicaciones, visitas- solo describe ejecución.
 La cadena causal debe declarar qué intervención se espera que cambie qué conducta y por qué
 esa conducta genera el resultado económico.
 Ejemplo de recomendación. “No se recomienda abrir todos los canales todavía. En dos comunas
 con alta densidad del segmento, probaría un punto de retiro y una campaña geográfica frente a
 comunas de control. El éxito exige aumento de órdenes entregadas y contribución neta después de
 logística; suspendería si mejora descarga pero no compra, o si el costo de servicio supera margen.
 Si el efecto es positivo, ampliaría gradualmente y revisaría capacidad.” Esta recomendación
 contiene acción, segmento, mecanismo, medición, comparación, riesgo y regla de decisión; supera
 una lista de las cuatro P.
 Profundización adicional de Marketing Analytics
 17. Decisiones de investigación y diseño
 De la pregunta de negocio al diseño de investigación
 Formular el problema correcto
 Un síntoma («bajó la participación») no es una pregunta de investigación. Primero identifica
 decisión y alternativas: ¿cambiar precio, producto, canal o promoción? Luego define qué
 incertidumbre podría cambiar la elección. Especifica unidad de análisis, población, período, variable
 resultado, factores explicativos, comparadores y restricciones.
 Tipos de investigación: exploratoria para descubrir lenguaje/mecanismos; descriptiva para
 dimensionar o perfilar; predictiva para anticipar resultados; causal para estimar qué cambiaría bajo
 una intervención. Una investigación exploratoria no estima prevalencia; un modelo predictivo no
 prueba causalidad; una encuesta declarativa puede no anticipar compra real.
Examen de Grado UC | materia, preguntas y respuestas 77

[pág. 78]
Marketing - versión clara y reordenada
 Datos, medición y calidad
 Datos activos se obtienen preguntando o interviniendo (encuestas, entrevistas, experimentos);
 datos pasivos se generan en transacciones, navegación o uso. Los activos observan
 actitudes/intenciones pero sufren recuerdo y deseabilidad social. Los pasivos registran conducta,
 pero no siempre motivación, pueden excluir personas sin huella y exigen gobernanza.
 Define constructo (idea teórica), indicador (medición observable), escala, período y unidad.
 Confiabilidad es consistencia; validez es representar el concepto correcto. Pretest detecta
 ambigüedad, fatiga y orden. Preguntas dobles, negativas confusas, respuestas no exhaustivas y
 escalas asimétricas generan error de medición.
 En cualitativo entrevista para comprender procesos y lenguaje. Usa guía flexible, muestra
 intencional, codificación explícita, casos que contradicen la hipótesis y citas trazables. No
 interpretes frecuencia de menciones como tamaño poblacional. Para texto, valida reglas o modelos
 con ejemplos reales; ironía, idioma y contexto son fuentes de error.
 Diseño de investigación: de una pregunta a datos defendibles
 Matriz de diseño
 Pregunta Diseño que suele ayudar Evidencia que produce Límite principal
 ¿Qué lenguaje/razones Entrevistas, grupos, Hipótesis y mecanismos No prevalencia poblacional
 usan? observación
 ¿Qué proporción Encuesta con muestra y Estimación de Selección, recuerdo y
 conoce/considera? medición adecuada proporciones declaración
 ¿Qué grupos difieren en Panel o transacciones Conducta observada por Cobertura, selección y
 compras? período ausencia de motivos
 ¿Qué oferta prefieren en Conjoint Trade-offs dentro del Sesgo hipotético y validez
 perfiles hipotéticos? diseño externa
 ¿Qué efecto causó el Experimento aleatorio Contraste causal bajo Integridad, costo,
 tratamiento? diseño interferencia
 ¿Qué ocurrirá después? Modelo predictivo validado Pronóstico fuera de Predicción no causal
 muestra
 Los métodos pueden combinarse. Entrevistas pueden mejorar un cuestionario; encuesta
 dimensiona una hipótesis; experimento prueba intervención; transacciones monitorean efecto real.
 La secuencia se decide según costo del error: una decisión grande requiere evidencia más robusta
 que una prueba pequeña y reversible.
 Construcción de instrumentos
 Empieza con constructos y usos, no con preguntas atractivas. Cada ítem debe medir una cosa, usar
 lenguaje que la población entiende y especificar período. Define orden aleatorio cuando el orden
 pueda sesgar; incluye «no sabe/no aplica» cuando corresponda; evita inducir una respuesta. Para
 escalas, revisa anclas, simetría y si las distancias numéricas se interpretan de manera válida.
 Pretest cognitivo: pide a personas del público objetivo que expliquen cómo entendieron cada
 pregunta y cómo eligieron respuesta. Piloto operativo: mide duración, abandono, fallas de flujo,
 variabilidad, faltantes y lógica de saltos. Cambios posteriores al piloto deben documentarse y
Examen de Grado UC | materia, preguntas y respuestas 78

[pág. 79]
Marketing - versión clara y reordenada
 pueden invalidar comparaciones si instrumento cambió entre grupos.
 Error total de encuesta
 Error total incluye cobertura, selección, no respuesta, medición, recuerdo, procesamiento y
 variabilidad muestral. El margen de error convencional cubre solo parte del cuadro, bajo un diseño
 probabilístico. Aumentar n reduce varianza de muestreo aproximadamente con raíz de n, pero
 puede hacer más precisa una estimación sesgada. En respuesta distinguida, explicita qué error se
 controla y cuál queda.
 Marketing Analytics como sistema de decisión
 La analítica puede ser descriptiva (qué ocurrió), diagnóstica/exploratoria (qué patrón o mecanismo
 investigar), predictiva (qué podría ocurrir) o prescriptiva (qué acción conviene bajo restricciones).
 Cada etapa depende de la anterior: prescribir usando predicción sesgada solo automatiza error.
 Define población y decisión, costo de error, datos disponibles, supuestos, validación y monitoreo. El
 indicador más sofisticado no sirve si el responsable no puede actuar o la acción no cambia el
 resultado.
 Un ciclo defendible es: medir brecha, estudiar cliente/competencia/entorno, diseñar alternativa,
 probar impacto, escalar o corregir y monitorear efectos secundarios. El tablero debe separar
 métricas de cliente, mercado, operación y finanzas. Para cada instrumento especifica quién decide,
 cuándo y qué resultado cambia la acción.
 18. Valor de información y elección bajo incertidumbre
 La información tiene valor económico cuando permite tomar una mejor decisión bajo incertidumbre.
 Cambiar una creencia sin cambiar una acción ni su resultado puede no generar valor para esa
 decisión. No se compra un estudio solo porque produce más datos o reduce un error estadístico; se
 pregunta qué decisión puede cambiar y cuánto vale ese cambio.
 Ejercicio completo. Lanzar una oferta genera $10 millones si tiene éxito y pierde $8 millones si
 falla. Antes del estudio, la probabilidad de éxito es 0,40. No lanzar produce cero. El valor esperado
 de lanzar es 0,40×10-0,60×8=-$0,8 millones, por lo que se elige no lanzar, con valor cero. Con
 información perfecta se lanzaría solo si va a tener éxito: valor esperado=0,40×10=$4 millones. El
 valor esperado de información perfecta es $4 millones; es un límite superior para lo que conviene
 pagar por información sobre esta decisión, bajo estos supuestos.
 Ahora un estudio imperfecto produce una señal favorable con probabilidad 0,40. Después de esa
 señal, la probabilidad de éxito es 0,70; después de una señal desfavorable, es 0,20. Estas
 creencias son coherentes con la probabilidad previa: 0,40×0,70+0,60×0,20=0,40. Con señal
 favorable, lanzar vale 0,70×10-0,30×8=$4,6 millones. Con señal desfavorable, vale
 0,20×10-0,80×8=-$4,4 millones y se elige no lanzar. El valor esperado con estudio, antes de su
 costo, es 0,40×4,6+0,60×0=$1,84 millones. Su valor incremental es $1,84 millones. Un precio de $2
 millones vuelve negativa la ganancia esperada neta, aunque el estudio sea informativo.
 El cálculo requiere probabilidades previas, calidad de la señal, acciones disponibles y resultados.
 Puede incluir costo de retrasar lanzamiento o valor de reutilizar conocimiento en varias decisiones.
 La información perfecta es una referencia teórica, no una promesa que pueda cumplir una
 encuesta. Un estudio cualitativo puede ser valioso al descubrir una alternativa no considerada,
Examen de Grado UC | materia, preguntas y respuestas 79

[pág. 80]
Marketing - versión clara y reordenada
 incluso cuando no entrega una probabilidad poblacional; el valor depende del cambio en la decisión.
 19. Medición, muestreo e inferencia
 Muestreo e inferencia
 La población define a quién queremos describir; la unidad muestral es quien puede ser
 seleccionado; el marco es la lista o mecanismo de acceso. El muestreo probabilístico asigna
 probabilidades conocidas, facilitando inferencia si cobertura y respuesta son adecuadas.
 Conveniencia y panel opt-in pueden ser útiles, pero sus errores no desaparecen con una muestra
 grande.
 Para una proporción bajo muestreo aleatorio simple y población grande, tamaño aproximado:
 n = z² p(1-p) / e²
 z corresponde al nivel de confianza (1,96 para 95%); p es proporción anticipada; e es margen de
 error absoluto. Si no hay valor previo usa p=0,5 para un tamaño conservador. Ajusta por efecto de
 diseño, población finita y no respuesta.
 Ejemplo resuelto. Para 95% de confianza, ±5 puntos porcentuales y p=0,5:
 n=1,96²×0,25/0,05²≈384,2; se requieren 385 respuestas completas bajo los supuestos simples. Si el
 70% contactado completa, se necesitan aproximadamente 385/0,70=550 contactos. Esto no
 resuelve sesgo de cobertura ni de no respuesta.
 Un intervalo de confianza de 95% se refiere al procedimiento de muestreo repetido, bajo los
 supuestos adoptados. No significa que, dado el intervalo calculado, exista 95% de probabilidad de
 que el parámetro fijo esté dentro. Reporta incertidumbre junto a tamaño de efecto, base, período y
 sesgos potenciales.
 Estadística aplicada: lectura de resultados con criterio
 Variabilidad y tamaños de efecto
 La media describe centro, la desviación estándar dispersión, la mediana es robusta a extremos, y
 cuantiles describen distribución. Compara grupos con medidas consistentes y muestra
 tamaños/intervalos. Una diferencia estadísticamente detectable puede ser irrelevante
 económicamente; una diferencia importante puede ser imprecisa si la muestra es pequeña. Reporta
 ambas dimensiones.
 Pruebas, hipótesis y p-valor
 El p-valor es probabilidad, bajo la hipótesis nula y el modelo, de observar datos al menos tan
 incompatibles como los obtenidos. No es probabilidad de que la hipótesis nula sea cierta, ni tamaño
 del efecto, ni prueba de importancia. El umbral no corrige diseño malo, múltiples comparaciones,
 selección de resultados o medición inválida. Define hipótesis y resultado antes del análisis cuando
 sea posible.
Examen de Grado UC | materia, preguntas y respuestas 80

[pág. 81]
Marketing - versión clara y reordenada
 ANOVA en diseño factorial
 ANOVA de un factor compara una variable categórica con una respuesta numérica. En factorial,
 efectos principales y de interacción responden preguntas diferentes: una interacción implica que el
 efecto de un factor depende del otro. No interpretes efecto principal como universal si la interacción
 es fuerte. El diseño, balance, tamaño muestral y codificación determinan precisión. En experimento,
 interacción puede ser efecto causal de tratamientos; en encuesta observacional, permanece
 exposición asociativa.
 Estadística que faltaba entre la pregunta y la decisión
 Escalas y elección de procedimiento
 Una variable nominal identifica categorías sin orden; una ordinal ordena sin garantizar distancias
 iguales; una de intervalo permite comparar diferencias; una de razón agrega un cero significativo y
 permite proporciones. El número asignado a una etiqueta no crea distancia: codificar marcas como
 1, 2 y 3 no hace que la tercera sea tres veces la primera. Ratings tipo Likert requieren justificar el
 tratamiento agregado y revisar sensibilidad cuando se usan como métricos.
 Si comparas categorías, usa frecuencias y proporciones; si comparas una respuesta numérica entre
 grupos, medias/distribuciones y procedimientos adecuados; si estudias covariación de dos
 métricas, correlación/regresión. La pregunta y el diseño preceden a la prueba. Un panel con
 muchas compras por hogar contiene observaciones relacionadas: el número de tickets no equivale
 al número de unidades independientes para todos los análisis.
 Tabla de contingencia y chi-cuadrado
 Una tabla cruza dos variables categóricas. Para contrastar independencia, calcula la frecuencia
 esperada de cada celda bajo H₀ como Eᵢⱼ=(total filaᵢ × total columnaⱼ)/N. El estadístico es
 χ²=Σ(Oᵢⱼ-Eᵢⱼ)²/Eᵢⱼ, con grados de libertad (filas-1)(columnas-1). Es una comparación de conteos, no
 una suma de porcentajes. Revisa independencia y frecuencias esperadas; celdas escasas pueden
 requerir un procedimiento exacto o un diseño distinto. No combines categorías solo para obtener
 significación.
 Ejercicio completo. En 200 clientes, entre 100 que vieron una oferta 60 compran y 40 no; entre
 100 que no la vieron 40 compran y 60 no. Totales: 100 compras y 100 no compras. Bajo
 independencia se esperan 50 en cada celda. χ²=4×(10²/50)=8, con un grado de libertad. La
 diferencia de compra es 60%-40%=20 puntos porcentuales. El contraste es evidencia de
 asociación; será evidencia causal de la asignación si los grupos surgieron de un experimento válido,
 no si la exposición seleccionó clientes con mayor intención. El tamaño de asociación V de Cramér
 en una tabla 2×2 es √(8/200)=0,20; ayuda a no confundir tamaño con p-valor.
 Correlación, regresión y valor de información
 La correlación de Pearson estandariza covarianza: r=Cov(X,Y)/(sₓsᵧ). Describe asociación lineal,
 no cualquier relación ni un efecto causal. Para datos ordinales o relaciones monótonas puede ser
 pertinente una correlación de rangos. Gráfica antes de interpretar: valores extremos, mezcla de
 segmentos o una curva pueden cambiar el significado de r. Una relación global puede revertirse al
 separar grupos por un confusor.
Examen de Grado UC | materia, preguntas y respuestas 81

[pág. 82]
Marketing - versión clara y reordenada
 La regresión lineal Y=β₀+β₁X₁+…+βₖXₖ+ε distingue respuesta y predictores. βⱼ mide diferencia
 esperada de Y por una unidad adicional de Xⱼ manteniendo los otros predictores del modelo. La
 unidad importa. Una pendiente de -20 puede representar unidades por peso o por mil pesos; no
 compares su magnitud con un coeficiente de otra escala. Revisa forma funcional, errores,
 dependencia, extrapolación y multicolinealidad. R² alto no valida causalidad ni garantiza buena
 predicción futura.
 Antes de investigar, pregunta cuánto podría cambiar la decisión. Si una prueba cuesta $3 millones y
 solo puede evitar una pérdida de $500.000, su valor económico es limitado salvo que informe otras
 decisiones importantes. En cambio, una incertidumbre pequeña sobre un lanzamiento irreversible
 puede justificar más evidencia. El valor de información deriva de mejorar decisiones bajo
 incertidumbre, no de tener más tablas.
 20. ANOVA y comparación de grupos
 ANOVA y comparación de grupos
 ANOVA pregunta si las medias de tres o más grupos son compatibles con una media común.
 Separa variabilidad entre grupos de variabilidad residual dentro de grupos:
 F = MS entre / MS dentro, donde cada cuadrado medio es suma de cuadrados dividida por sus
 grados de libertad.
 La hipótesis nula es igualdad de todas las medias. Un F significativo indica evidencia de que no
 todas son iguales; no identifica qué pares difieren ni cuán importante es la diferencia. Después
 aplica comparaciones planificadas o post hoc con control del error, muestra intervalos y tamaño de
 efecto.
 Supuestos: independencia de observaciones, residuos razonablemente compatibles con el modelo
 y varianzas comparables en ANOVA clásico. El diseño de asignación determina si cabe
 interpretación causal. Si son ratings observacionales de conceptos, diferencias no prueban que el
 concepto causó preferencia: puede haber orden, composición o selección.
 Ejemplo. Tres conceptos reciben puntuaciones medias 5,1; 5,4; y 6,0. El F global es significativo.
 No concluyas automáticamente «concepto C gana»: revisa comparaciones de pares, intervalo,
 relevancia práctica, perfil de quienes respondieron y realismo de la tarea. Para decidir lanzamiento,
 complementa con precio, disponibilidad y prueba conductual.
 21. Segmentación analítica y representación de mercado
 Segmentación analítica: k-medias
 K-medias asigna cada observación al centroide más cercano y actualiza centroides para minimizar
 la suma de distancias cuadráticas dentro de los K grupos. Sus entradas determinan el resultado:
 una variable en escala de miles puede dominar edad en decenas; estandarizar suele ser necesario
 para variables comparables, pero no corrige una selección equivocada ni convierte categorías
 nominales en magnitudes.
 Procedimiento: (1) definir unidad y objetivo de segmentación; (2) seleccionar variables relacionadas
 con necesidad o respuesta, excluyendo IDs; (3) revisar faltantes, valores extremos y codificación;
Examen de Grado UC | materia, preguntas y respuestas 82

[pág. 83]
Marketing - versión clara y reordenada
 (4) escalar cuando proceda; (5) probar varios K e inicializaciones; (6) comparar codo, silhouette,
 tamaños y separación; (7) perfilar con variables no usadas; (8) comprobar estabilidad y respuesta;
 (9) evaluar si cada grupo recibe una acción rentable.
 No elijas K solo por un índice o p-valor. Un cluster no es automáticamente un segmento: puede
 reflejar ruido, escala o artefacto de muestra. Valida fuera de muestra o en período distinto y
 compara valor incremental frente a una regla simple.
 Mini-ejemplo. Dos clientes tienen (visitas, gasto)=(2, 100) y (8, 500), mientras otro grupo mide
 variables en miles. Sin estandarizar, gasto domina distancias. Tras estandarizar puedes detectar
 perfiles relativos; luego confirma si las diferencias predicen una respuesta distinta a oferta/precio.
 La acción requiere costos de contacto, tamaño de grupo y riesgo de estereotipar a individuos.
 Segmentación y representación de mercado en profundidad
 Decidir entre a priori y posteriori
 Segmentación a priori define grupos antes de analizar (por ejemplo, canal, ocasión o perfil
 demográfico) porque la empresa necesita una regla ejecutable. Segmentación posteriori descubre
 agrupaciones según patrones de respuesta o variables. La segunda puede revelar heterogeneidad,
 pero exige validar estabilidad, perfil y accesibilidad; su costo de implementación puede superar el
 beneficio. Compara ambas contra política no segmentada y criterios simples.
 Preparación y selección de variables para k-medias
 Variables deben representar diferencias de necesidad o comportamiento relevantes, no solo estar
 disponibles. Evita duplicar conceptos correlacionados porque multiplican peso. Estandarizar
 (z=(x-x̄)/s) deja variables comparables en escala, pero hace que ruido de una variable de varianza
 pequeña tenga peso sustantivo; por eso se revisa confiabilidad. Variables categóricas no se
 introducen como etiquetas numéricas sin justificar distancia. Outliers pueden mover centroides:
 revisa causas y sensibilidad, no los elimines automáticamente.
 La suma de cuadrados interna nunca aumenta cuando K aumenta, así que el codo es una
 compensación entre ajuste y simplicidad, no una prueba formal de K correcto. Silhouette compara
 cohesión y separación para cada observación; valores altos favorecen separación, pero geometrías
 no esféricas pueden penalizar una estructura útil. Réplicas con semillas distintas y muestras
 bootstrap revelan fragilidad.
 Diferenciar factorial de componentes principales
 Análisis factorial común modela variables observadas como combinación de factores comunes más
 error específico. Componentes principales resumen varianza total mediante combinaciones
 matemáticas y no postulan la misma estructura de factores latentes. Si el objetivo es construir
 dimensiones subyacentes, aclara qué método se aplicó, qué rotación y por qué. En el examen no
 basta decir «aplico factorial»: explica dato, adecuación, criterio de número, lectura de cargas y uso
 posterior.
Examen de Grado UC | materia, preguntas y respuestas 83

[pág. 84]
Marketing - versión clara y reordenada
 MDS métrico y no métrico
 MDS métrico intenta reproducir magnitudes de disimilitud; no métrico preserva ordenamiento.
 Ambos buscan representación de baja dimensión; stress indica discrepancia entre distancias del
 mapa y disimilitudes originales. Menor stress suele indicar mejor ajuste, pero agregar dimensiones
 siempre ayuda. Escoge dimensión por compromiso entre ajuste, interpretabilidad y estabilidad. Ejes
 pueden tener escala/orientación arbitraria. Para proponer reposicionamiento necesitas atributos
 importantes, dirección deseada, factibilidad y respuesta competitiva.
 RFM, clustering jerárquico y Assessor
 RFM resume clientes por recencia (tiempo desde última compra), frecuencia (número en ventana) y
 monto (valor en ventana). Define escala, ventana y umbrales; luego perfila grupos. Es una
 herramienta operacional de priorización, no un modelo de necesidad. Puede premiar clientes
 grandes por ingresos aunque tengan bajo margen y no mide respuesta incremental. Una campaña
 debe evaluar retención o contribución adicional frente a grupo comparable.
 Clustering jerárquico parte de cada observación como grupo y fusiona grupos según distancia y
 regla de enlace hasta una jerarquía. El dendrograma muestra fusiones; cortar a cierta altura
 determina K. Resultado depende de estandarización, distancia, linkage y outliers. A diferencia de
 k-medias, no requiere fijar K al inicio y no reasigna grupos partidos en el proceso aglomerativo; su
 costo crece con N y puede ser sensible a primeras fusiones. Usa ambos como análisis
 complementarios, no como árbitros de una verdad única.
 Assessor y otros pretests de producto buscan relacionar medidas de prueba/aceptación con compra
 esperada, a veces combinando prueba y recompra en un período. Son útiles para priorizar
 conceptos, pero pronóstico depende de calibración, muestra, distribución, disponibilidad, precio y
 competencia. Una medida de intención no debe presentarse como venta asegurada. Compara
 pronóstico y ventas reales de lanzamientos previos; documenta error de calibración.
 22. Factorial, MDS y medición de percepción
 Análisis factorial, MDS y preferencias
 Factorial exploratorio
 Busca representar correlaciones entre indicadores mediante pocas dimensiones latentes. Revisa
 que existan correlaciones aprovechables, adecuación muestral, comunalidades, número de factores
 y solución rotada. Las cargas describen asociación de cada indicador con factores; se nombra cada
 dimensión según el patrón conjunto, no según un solo ítem conveniente. Cargas cruzadas o
 comunalidades bajas advierten interpretación frágil.
 Factorial no es regresión: resume covariación y no estima automáticamente un efecto sobre ventas.
 La escala, selección de indicadores y muestra condicionan la solución. Si se emplean scores para
 segmentar o predecir, el paso posterior necesita validación.
Examen de Grado UC | materia, preguntas y respuestas 84

[pág. 85]
Marketing - versión clara y reordenada
 Escalamiento multidimensional
 MDS ubica objetos de modo que distancias en un mapa representen disimilitudes observadas.
 Revisa stress/ajuste, dimensionalidad y estabilidad. Ejes pueden rotarse o reflejarse sin cambiar
 distancias; no les asignes significado sin atributos externos o evidencia adicional. Proximidad indica
 percepción similar bajo la medición, no causalidad, preferencia ni participación.
 Lectura aplicada. Si dos marcas quedan próximas, pregunta si compiten por la misma
 ocasión/segmento y si la cercanía es estable. Si el mapa ubica un espacio vacío, no concluyas que
 existe demanda: comprueba qué atributo representaría ese espacio, si es importante, si se puede
 entregar y si la muestra lo entiende.
 Medición de marca y mapas perceptuales
 Medición de marca debe especificar constructo y población: reconocimiento asistido, recuerdo
 espontáneo, top of mind, asociaciones, calidad percibida, consideración, preferencia, recompra y
 precio relativo son métricas distintas. BAV separa diferenciación, relevancia, estima y conocimiento;
 puede ayudar a diagnosticar fortaleza/estatura, pero no convierte puntuaciones en valor financiero
 automáticamente. Evita umbrales arbitrarios universales (por ejemplo, una brecha fija de puntos
 para declarar líder mental) salvo respaldo específico de una pauta o programa.
 Para un mapa basado en atributos, recoge percepciones de marcas y atributos y comprueba
 escalas/consistencia; análisis factorial puede resumir dimensiones correlacionadas antes de
 representarlas. Para mapa de similitud global, MDS trabaja con disimilitudes por pares y ejes
 interpretados después. En ambos, añade punto ideal/preferencias y evidencia de elección. Un
 espacio perceptual vacío puede estar vacío porque nadie lo desea o porque no hay alternativa; se
 necesita investigación de demanda antes de recomendar entrada.
 23. Métricas de compra, heterogeneidad y repetición
 Compra repetida y modelos de heterogeneidad
 Poisson-Gamma
 Poisson modela conteos por intervalo dado una tasa individual λ: (P(X=x|λ)=e^-λλ^x/x!). La mezcla
 Gamma permite que clientes tengan tasas distintas. Si λ sigue Gamma de forma y tasa (k,α), la
 media marginal de conteos es (k/α) y la varianza marginal es (k/α + k/α²) bajo esa parametrización.
 La sobredispersión surge porque la población mezcla frecuencias diferentes; no asumas que todo
 exceso de variación es una falla de captura.
 Usa intervalos comparables y define universo, exposición y compra. Ceros pueden incluir no
 compradores estructurales; una ventana corta puede confundir poca frecuencia con abandono.
 Compara ajuste, estabilidad temporal y predicción. Un benchmark estacionario pierde sentido con
 lanzamientos, quiebres de stock o promociones intensas.
 Beta-Binomial
 Si la probabilidad individual de comprar una marca es θ y θ varía según Beta(a,b), el número de
 éxitos en n ocasiones sigue una Beta-Binomial. El posterior con x compras observadas es
 Beta(a+x,b+n-x) bajo observaciones intercambiables. La heterogeneidad implica que dos clientes
 con igual promedio de categoría pueden diferir en propensión a elegir marca.
Examen de Grado UC | materia, preguntas y respuestas 85

[pág. 86]
Marketing - versión clara y reordenada
 Dirichlet como benchmark
 El modelo Dirichlet de compra de marcas extiende estas ideas para estimar regularidades de
 penetración, frecuencia, duplicación entre marcas y lealtad conductual en categorías relativamente
 estables. Se usa como benchmark: compara valores observados y esperados para investigar
 diferencias. Desviación puede indicar diferenciación, disponibilidad, precio, promoción, cambio de
 régimen o datos/modelo inadecuados; no es un veredicto automático de éxito o fracaso.
 Modelos probabilísticos de compra y elección: conexiones
 De Poisson a mezcla Gamma
 El modelo Poisson parte de eventos independientes a tasa constante dentro de la ventana: media y
 varianza del conteo condicional son λ. En mercados reales hay heterogeneidad: algunos clientes
 compran con mayor tasa. Si la tasa individual varía según Gamma(k, α), la distribución observada
 es mezcla negativa binomial. La media aumenta con tasa promedio y la varianza excede media por
 heterogeneidad. Se puede estimar parámetros por máxima verosimilitud o momentos según método
 del curso; después se validan conteos observados y predichos.
 No combines tasa de compra con exposición desigual sin ajuste: clientes observados más meses
 tendrán más conteos aunque tengan igual propensión. Define oportunidad, ventana, repetición y no
 comprador. Una tasa promedio puede subestimar cola de clientes intensivos y sobreestimar cliente
 típico.
 Beta-Binomial con ejemplo numérico
 Supón prior Beta(2,8), media previa 0,20. Tras 10 oportunidades, la persona compra 4 veces.
 Posterior Beta(6,14), media posterior 6/(6+14)=0,30. El prior regulariza muestras cortas; con más
 observaciones, los datos pesan más. La predicción depende del prior y supuesto de probabilidad
 estable. Si oportunidades no son comparables o hay exposición selectiva, el modelo simple puede
 engañar.
 Logit: coeficientes, odds y probabilidades
 Odds de evento es (P/(1-P)). Un coeficiente β se interpreta en log-odds, y (e^β) como razón de odds
 por unidad. Para pasar a probabilidad, calcula el índice lineal para un perfil y aplica función
 logística. Efectos marginales se evalúan en perfiles o se promedian sobre población. Un coeficiente
 puede ser estadísticamente preciso y producir efecto pequeño si la probabilidad base está cerca de
 cero o uno.
 En multinomial, probabilidades comparten denominador y suman uno; por eso un cambio de
 atributo en una alternativa redistribuye probabilidades entre las demás. Explica efecto comparado
 con alternativa de referencia y verifica sensibilidad al conjunto de opciones. Si dos productos son
 casi idénticos, IIA puede repartir sustitución de modo poco realista.
Examen de Grado UC | materia, preguntas y respuestas 86

[pág. 87]
Marketing - versión clara y reordenada
 Del ajuste al uso gerencial
 Antes de usar un modelo, define decisión, costo de falsos positivos/negativos, población, ventana y
 variable objetivo. Ajuste dentro de muestra solo muestra capacidad de describir datos conocidos.
 Validación fuera de muestra prueba generalización temporal o poblacional. Calibración pregunta si
 eventos que el modelo predice a 20% ocurren cerca de 20%; discriminación pregunta si ordena
 clientes de alto a bajo riesgo. Para asignar promociones, evalúa uplift incremental, no solo
 propensión: clientes que comprarían sin descuento pueden ser los más propensos y los menos
 incrementales.
 Métricas de mercado y compra repetida
 Una cifra de participación no explica por qué una marca cambia. Descompón tamaño y lealtad:
 participación por unidades o valor; penetración de categoría y marca; frecuencia entre
 compradores; unidades por ocasión; gasto; tasa de conversión; recencia; duplicación y switching.
 Define siempre el denominador. La penetración de marca es hogares que compran marca / hogares
 potenciales; penetración de categoría usa compradores de categoría. «Lealtad» puede ser
 proporción de compras de categoría asignada a una marca (share of category requirements),
 proporción de clientes exclusivos o retención: no son intercambiables.
 Ejemplo. En un panel de 1.000 hogares, 400 compran categoría; 160 compran Marca A.
 Penetración de categoría=40%; penetración de A sobre toda la muestra=16%; penetración de A
 entre compradores de categoría=40%. Si esos 160 hogares compran 320 unidades de A y 800
 unidades totales de categoría, SCR aproximado de A entre sus compradores =320/800=40% (si el
 denominador usa todas sus compras de categoría). No confundas este indicador condicionado con
 el share de mercado de todos los hogares.
 Panel permite observar transiciones de los mismos hogares y separar cambio conductual de cambio
 de composición muestral. También puede sufrir desgaste, envejecimiento, cambio de medición y
 reactividad. Muestras transversales independientes sirven para estimar cortes poblacionales, pero
 las diferencias entre períodos pueden reflejar quién respondió. Un panel no vuelve causal una
 asociación temporal.
 Gamma-Poisson: derivación y ejercicio completo
 Sea (X|λ∼Poisson(λT)) el número de compras del hogar durante ventana T. Los hogares difieren en
 λ. Supón (λ∼Gamma(r,s)), con forma r y tasa s; entonces (E(λ)=r/s), (Var(λ)=r/s²). Al integrar la
 heterogeneidad, el conteo marginal es sobredisperso:
 E(X)=rT/s; Var(X)=rT/s·(1+T/s); P(X=0)=[s/(s+T)]^r.
 Penetración esperada en ventana T es (1-P(X=0)). La media entre compradores es (E(X)/P(X>0)).
 La heterogeneidad genera más hogares con cero compras y una cola de hogares intensivos que el
 Poisson homogéneo.
 Ejercicio. El promedio trimestral es 2,4 compras y varianza 5,1. Para T=1 trimestre, (r/s=2,4) y
 (2,4(1+1/s)=5,1). Así, (1/s=5,1/2,4-1=1,125), s≈0,889 y r≈2,133. Penetración trimestral:
 (1-(0,889/1,889)^2,133≈0,80). Compras medias de hogares compradores: 2,4/0,80≈3,0. Para un
 año (T=4 trimestres), media marginal=2,133×4/0,889≈9,6; penetración
 (1-(0,889/4,889)^2,133≈0,973). La media anual entre compradores ≈9,6/0,973≈9,87. Redondeos
Examen de Grado UC | materia, preguntas y respuestas 87

[pág. 88]
Marketing - versión clara y reordenada
 pueden diferir por parámetros redondeados. Este cálculo exige que la tasa latente sea estable
 durante el período.
 Si un hogar realizó n compras durante período previo T₀, conjugación actualiza la tasa Gamma a
 forma (r+n) y tasa (s+T₀). La compra pasada eleva la tasa posterior esperada; mayor tiempo
 observado sin compra también informa y evita tratar clientes con ventanas distintas como
 equivalentes. No confundas compras pasadas con efecto causal de campaña.
 Dirichlet como modelo de compra de categoría y marcas
 El modelo Dirichlet clásico combina dos procesos. Primero, modela cuántas compras de categoría
 realiza cada hogar durante una ventana; una mezcla Gamma-Poisson (NBD) captura
 heterogeneidad de intensidad. Segundo, condicionado al total de compras de categoría, modela
 qué marcas elige el hogar mediante probabilidades heterogéneas con distribución Dirichlet. La
 mezcla de elecciones produce una distribución Dirichlet-multinomial. Así conecta penetración y
 frecuencia de categoría con penetración y lealtad de marcas.
 Si las propensiones de un hogar a elegir J marcas son θ=(θ₁,…,θⱼ), con θ∼Dirichlet(α₁,…,αⱼ), su
 preferencia media por marca j es αⱼ/α₀, donde α₀=Σαⱼ. La suma α₀ regula dispersión entre hogares:
 con mayor concentración, propensiones individuales se agrupan más cerca de la media; con menor
 concentración hay mayor heterogeneidad. Estos parámetros no son cuotas fijas de mercado por
 definición: predicen patrón de elección bajo supuestos de categoría, ventana y estaciones
 comparables.
 Ejemplo ilustrativo. Si α=(4,3,3), preferencias medias son 40%, 30% y 30%. Un hogar con diez
 compras no tiene que elegir A cuatro veces: la variabilidad de elecciones y la heterogeneidad entre
 hogares generan múltiples combinaciones. En la categoría, agrega sobre hogares y compras para
 calcular participaciones esperadas. Compara contra datos observados por penetración, frecuencia,
 duplicación, exclusividad y switching.
 Un benchmark razonable suele implicar que marcas grandes tengan mayor penetración y una
 ventaja más pequeña en frecuencia; muchas categorías exhiben «doble riesgo» (marcas pequeñas
 tienen menos compradores y algo menor frecuencia) y poca lealtad exclusiva. Si datos se alejan,
 investiga promoción, distribución, diferenciación, calidad de datos, cambio de período,
 estacionalidad o violación de supuestos. No concluyas automáticamente que la marca con mayor
 lealtad es más fuerte: puede tener baja penetración y compradores muy intensivos.
 24. Logit, elección y datos de panel
 Logit y modelos de elección
 Logit binario
 Para una elección Y∈0,1, la probabilidad es:
 P(Y=1|x)=1/[1+exp(-(β₀+β₁x₁+…+βₖxₖ))].
 El modelo estima log-odds: (log[P/(1-P)]=β₀+β'x). Un aumento de una unidad en x_j multiplica los
 odds por (e^β_j), manteniendo lo demás constante. No significa que la probabilidad cambie β_j
 puntos porcentuales. El efecto marginal en probabilidad depende del punto de partida: en extremos,
 puede ser pequeño.
Examen de Grado UC | materia, preguntas y respuestas 88

[pág. 89]
Marketing - versión clara y reordenada
 Cálculo ilustrativo. Si β_precio=-0,4, un aumento unitario de precio multiplica los odds por
 exp(-0,4)=0,6703, cerca de 33% menos odds, no 33 puntos menos de probabilidad. Si la
 probabilidad inicial es 0,50, odds=1; odds nuevos=0,6703 y probabilidad
 nueva=0,6703/(1+0,6703)≈0,4013. La caída es cerca de 9,9 puntos porcentuales. La unidad de
 precio y rango de observación son esenciales.
 Elección multinomial
 Para alternativas j, utilidad sistemática (Vᵢⱼ=β'xᵢⱼ) y logit condicional da (Pᵢⱼ=exp(Vᵢⱼ)/sum_k exp(Vᵢₖ)).
 Define alternativa base, variables por persona y por alternativa, precio, atributos y opción de no
 compra cuando corresponda. La propiedad IIA implica que razón de probabilidades de dos
 alternativas no cambia al agregar otra; puede ser poco realista cuando las opciones son sustitutos
 cercanos. Considera especificaciones más flexibles cuando los datos y curso lo permitan.
 Comprueba codificación, escala, multicolinealidad, separación, ajuste, calibración y desempeño
 fuera de muestra. El modelo predice elección condicionada a muestra y atributos incluidos; no
 demuestra que una promoción cause cambio si el precio no varió exógenamente.
 Panel y logit: ejecutar cálculos y reconocer restricciones
 Switching y proyección de participaciones
 Una matriz de transición T contiene Tᵢⱼ=P(marca próxima=j | marca actual=i); cada fila suma 1. La
 diagonal describe persistencia a la siguiente ocasión; el resto, destinos de cambio. No es
 necesariamente retención anual ni lealtad actitudinal. Si sₜ es un vector fila de participaciones por
 ocasiones comparables, sₜ₊₁=sₜT. Define si la tabla usa consumidores, ocasiones o volumen: un
 hogar pesado puede tener más peso en share de unidades que en share de personas.
 Ejercicio. Con s=(0,60;0,40) y T con filas A=(0,80;0,20), B=(0,30;0,70), share siguiente de
 A=0,60×0,80+0,40×0,30=0,60; el de B=0,40. La estabilidad del share es compatible con cambios: A
 pierde 12% de ocasiones totales haciaB y gana 12% desdeB. Si T fuera estable indefinidamente, la
 participación estacionaria cumple s=sT, de donde s_A=0,30/(0,20+0,30)=0,60. No proyectes
 automáticamente después de un lanzamiento o stockout: cambian la matriz, exposición y conjunto
 de alternativas. La matriz describe transición observada; no demuestra que una campaña produjo el
 cambio.
 Constantes de marca, pruebas y efecto económico
 En elección logit, se identifica una constante por marca respecto de una base cuya constante se fija
 0. Esa normalización resuelve que sumar una misma cifra a todas las utilidades no cambia
 probabilidades. La constante recoge diferencias sistemáticas no incluidas en los atributos; no es
 una estimación financiera pura de brand equity. Si omitiste disponibilidad o calidad, puede recoger
 parte de esos factores.
 Un estadístico z o t aproxima coeficiente/error estándar y evalúa evidencia contra un valor nulo bajo
 el modelo. No mide cuál variable tiene «más impacto»: precisión y magnitud son preguntas
 diferentes. Para comparar impacto, simula cambios realistas de cada variable, muestra
 probabilidades y efecto económico. Una dummy de display varía 0→1; precio puede variar un peso
 o mil. En algunas pautas se usa significación para identificar factores relevantes: responde a ese
 criterio y añade que no ordena magnitudes económicas.
Examen de Grado UC | materia, preguntas y respuestas 89

[pág. 90]
Marketing - versión clara y reordenada
 Ejercicio resuelto. Dos marcas tienen V_A=0,8-0,2 p_A y V_B=-0,2 p_B. Con p_A=5,p_B=4,
 V_A=-0,2 y V_B=-0,8. P_A=exp(-0,2)/[exp(-0,2)+exp(-0,8)]=0,6457. Si A aumenta precio a 6,
 V_A=-0,4 y P_A=0,5987. La diferencia es -4,70 puntos; no es -20 puntos por tener β=-0,2. El valor
 económico requiere margen, tamaño de categoría, respuesta del competidor y costos.
 Elasticidades y IIA
 Si la utilidad de cada alternativa incluye un precio propio con coeficiente común β_p, la derivada
 propia es ∂Pⱼ/∂pⱼ=β_pPⱼ(1-Pⱼ). La elasticidad propia es εⱼⱼ=β_ppⱼ(1-Pⱼ). Para k≠j, ∂Pⱼ/∂pₖ=-β_pPⱼPₖ, y
 la elasticidad cruzada de Pⱼ respecto del precio de k es εⱼₖ=-β_ppₖPₖ. Estas fórmulas suponen la
 especificación indicada; no son universales para cualquier logit multinomial con variables
 individuales y parámetros distintos.
 En el ejemplo anterior, elasticidad propia de A=-0,2×5×(1-0,6457)=-0,3543. Es local: no reemplaza
 el recálculo exacto cuando el precio cambia mucho. La elasticidad cruzada respecto de
 p_B=-(-0,2)×4×0,3543=0,2834. Al encarecerB, aumenta P_A. Coeficiente negativo de precio no
 basta para llamar elástica a la demanda; hay que calcular la magnitud con precio y probabilidad.
 IIA implica P_A/P_B=exp(V_A-V_B): al añadir otra alternativa sin modificar A yB, su razón
 permanece igual. Si inicialmente A yB tienen 50% cada una y se agrega una copia casi idéntica
 deB, un logit simple de utilidades iguales asignaría un tercio a cada opción. Puede ser implausible
 porque la nuevaB debería competir principalmente con la viejaB. Estimar por segmentos capta
 diferencias entre segmentos, pero no elimina automáticamente IIA dentro de cada uno. Modelos
 más flexibles, como logit anidado o de coeficientes aleatorios, requieren justificar datos y estructura;
 reconocer la restricción es parte central del uso gerencial del modelo.
 25. Difusión, Bass y dinámica del mercado
 Difusión de Bass
 El modelo Bass representa adopción acumulada N(t) en un mercado potencial m. Los innovadores
 adoptan por influencias externas con coeficiente p; los imitadores responden a la proporción ya
 adoptante con coeficiente q. Adopción nueva:
 n(t) = [p + q·N(t)/m] · [m - N(t)].
 El primer término es propensión de adopción; el segundo, potencial restante. Al inicio domina p y
 después puede crecer el efecto de imitación; al agotarse el mercado potencial, la adopción cae.
 Una solución continua estándar es (N(t)=m[1-e^-(p+q)t]/[1+(q/p)e^-(p+q)t]), con tiempo y unidades
 consistentes.
 Estima m, p y q con datos temporales que cubran una parte informativa de la curva; mercados
 cortos no identifican bien saturación. Interpreta escenarios, no certeza. Bass básico no modela
 automáticamente precio, competencia, reposición, generaciones de producto, stockouts ni
 diferencias entre adopción y ventas repetidas. Una campaña puede coincidir con una curva
 creciente sin ser su causa.
Examen de Grado UC | materia, preguntas y respuestas 90

[pág. 91]
Marketing - versión clara y reordenada
 Bass: derivación y decisiones de adopción
 Sea F(t) proporción acumulada de mercado potencial m que adoptó hasta t. Entre los que aún no
 adoptan, probabilidad instantánea de hacerlo es p+qF(t): p representa exposición
 externa/innovación y qF(t) la influencia de adopción previa/imitación. La fracción susceptible que
 queda es 1-F(t). Entonces:
 dF/dt = [p+qF(t)][1-F(t)].
 Es una ecuación logística modificada. Separando variables e integrando con F(0)=0 se obtiene:
 F(t) = [1-e^-(p+q)t] / [1+(q/p)e^-(p+q)t].
 Adoptadores acumulados (N(t)=mF(t)); nuevos adoptadores por unidad temporal (n(t)=m·dF/dt). Si
 p,q están «por año», t debe expresarse en años. El tiempo del pico de adopciones cuando q>p es
 (t*=ln(q/p)/(p+q)). El máximo volumen de nuevos adoptadores no es máximo de ventas repetidas,
 ingreso o utilidad; estos requieren modelos adicionales.
 Decisión. Una muestra temprana ayuda a calibrar p pero suele contener poca información de q o
 m. Analogías con innovaciones comparables pueden apoyar escenarios, no sustituir datos. Define
 mercado potencial por capacidad, necesidad, acceso, elegibilidad y economía; calcula escenarios
 de p, q, m y precio. Capacidad, stock, compatibilidad, efecto red y actualización del producto
 pueden alterar difusión. Separar «acelerar adopción» (aumentar p/q o exposición) de «ampliar
 mercado potencial» (elevar m) ayuda a diseñar acciones distintas.
 26. Conjoint, atributos, DAP y simulación
 Conjoint, DAP y simulación de ofertas
 Conjoint estima cómo atributos y niveles contribuyen a utilidad declarada o elección en perfiles de
 oferta. Diseña atributos controlables y comprensibles, niveles realistas, tareas tolerables y perfiles
 que representen compensaciones plausibles. Incluye precio cuando se quiere estimar intercambio
 entre atributos y dinero. Demasiados atributos elevan fatiga; perfiles imposibles dañan validez.
 En un modelo aditivo, utilidad del perfil j para persona i es (U_ij=Σ_k β_ikx_jk+ε_ij). La codificación
 determina interpretación de parámetros. Importancia de atributo suele calcularse como rango de
 utilidades parciales dividido por suma de rangos; depende del rango de niveles incluido y no es una
 verdad universal sobre la categoría.
 Si utilidad del precio es lineal y su coeficiente β_p<0, disposición a pagar por un cambio de atributo
 con utilidad ΔU es DAP=ΔU/(-β_p). Ejemplo: ΔU=0,8 y β_p=-0,02 por peso ⇒ DAP declarada=$40.
 La cifra solo es válida dentro del modelo, diseño, muestra, forma funcional y moneda/unidad.
 Presenta intervalos o sensibilidad cuando sea posible.
 Simula competencia y comparte una regla: máxima utilidad, share of preference logit o regla con
 no-compra. Explicita qué competidores están incluidos, disponibilidad, distribución, restricciones y
 heterogeneidad. Contrasta la oferta recomendada en escenarios de precio y competidor. Conjoint
 no predice necesariamente compra real: la declaración puede sufrir sesgo hipotético y los perfiles
 pueden no reflejar mercado.
Examen de Grado UC | materia, preguntas y respuestas 91

[pág. 92]
Marketing - versión clara y reordenada
 Conjoint: diseño, estimación y límites en profundidad
 Atributos y niveles
 Selecciona atributos que la empresa puede cambiar y el consumidor entiende. Niveles deben ser
 mutuamente distinguibles, realistas y cubrir el rango de decisión. Precio incluido permite trade-off
 monetario; si todos los perfiles son dominados, la tarea no revela compensaciones. Evita atributos
 redundantes (marca y calidad percibida pueden reflejarse parcialmente) y demasiados niveles que
 sobrecargan.
 Diseño experimental y estimación
 El diseño combina niveles en perfiles procurando variación identificable. Un diseño eficiente
 balancea estimación con restricciones realistas. La codificación dummy o effects-coded cambia
 referencia e interpretación de utilidades; el ranking de perfiles depende de suma cero o nivel base.
 Si respuesta es elección entre tareas, estimación suele usar logit; si ratings, puede usar regresión
 con supuestos de escala. Declara unidad de respuesta y método.
 Simulación con escenarios
 Define competidores, precios, disponibilidad, conjunto de elección, no-compra y regla de conversión
 a share. First-choice asigna cada persona a su mayor utilidad y puede ser sensible a pequeñas
 diferencias; logit distribuye probabilísticamente. Ninguna regla es neutral. Evalúa perfil actual, perfil
 propuesto, respuesta competitiva y cambios de costo. Si la simulación pronostica share, verifica con
 datos reales y límites de extrapolación.
 Conjoint y difusión: cálculos adicionales de evaluaciones del curso
 Cuántos perfiles y qué identifica un diseño
 Con J atributos y Lⱼ niveles por atributo, hay ΠLⱼ perfiles de un diseño factorial completo. Para un
 modelo aditivo con intercepto y dummies, el número de parámetros libres es 1+Σ(Lⱼ-1). Esa cifra es
 un mínimo algebraico de perfiles independientes para un rating lineal individual, no una
 recomendación de tamaño muestral ni garantía de precisión. Se necesita rango completo de la
 matriz de diseño; repetir perfiles o confundir niveles entre atributos impide identificar efectos aunque
 haya suficientes filas. Con ese mínimo no quedan grados de libertad residuales para evaluar ruido;
 más tareas o un diseño poblacional adecuado suelen ser necesarios.
 Ejemplo. Servicio con marca 3 niveles, plazo 2 y precio 3 tiene 3×2×3=18 perfiles. El modelo aditivo
 requiere 1+(3-1)+(2-1)+(3-1)=6 parámetros. Un subconjunto de seis perfiles solo identifica esos
 efectos si sus combinaciones producen rango 6. Para estimar interacciones marca×plazo se
 agregan(3-1)(2-1)=2 parámetros y el mínimo algebraico pasa 8. La ortogonalidad ayuda a separar
 efectos en un diseño apropiado, pero no crea información sobre interacciones ausentes.
 Restricciones realistas pueden impedir un diseño perfectamente balanceado: documenta qué
 efectos pueden estimarse.
 Una utilidad parcial es relativa al nivel base o a la restricción de suma cero. Para comparar perfiles,
 suma utilidades bajo una misma codificación; no combines interceptos de una codificación con
 efectos de otra. Importancia=(rango del atributo)/(suma de rangos) depende de niveles incluidos. El
 atributo precio parecerá más importante si se amplía mucho su rango: no significa que los clientes
 hayan cambiado de preferencias.
Examen de Grado UC | materia, preguntas y respuestas 92

[pág. 93]
Marketing - versión clara y reordenada
 Si falta un atributo, no concluyas que nunca sesga. Si todos imaginan un nivel constante y el efecto
 es aditivo, puede quedar absorbido en el intercepto; si lo imaginan en función de marca/precio, o
 interactúa con atributos, puede contaminar efectos y simulaciones. Una tarea hipotética de mejor
 producto tampoco garantiza disponibilidad, comprensión ni compra real.
 Del conjoint al lanzamiento
 En el caso bancario de descuento con 3 niveles y 8 empresas, el factorial tiene 24 combinaciones.
 El modelo aditivo de rating requiere 1+2+7=10 parámetros, antes de interacciones. Si se desea
 evaluar cómo cambia el valor del descuento según la empresa, una interacción completa agrega
 2×7=14 parámetros: el modelo saturado requiere 24. Un diseño reducido que solo estima efectos
 principales no responde esa pregunta por arte de magia. Además, «empresa» puede confundir
 sector, frecuencia de uso, cobertura y acceso; perfila segmentos y verifica elegibilidad real para
 usar el beneficio.
 La recomendación compara preferencia simulada y costo del beneficio, probabilidad de redención,
 frecuencia, canibalización y retención incremental. Un descuento muy valorado puede transferir
 margen a clientes que ya comprarían. Incluye competidores y alternativa sin beneficio cuando
 corresponda, limita fatiga y prueba el programa con una evaluación que permita atribuir su efecto.
 Tiempo de adopción y extensiones de Bass
 Del Bass básico, para alcanzar una fracción objetivo a entre 0 y 1, despeja su solución acumulada:
 t(a)=ln[(1+a·q/p)/(1-a)]/(p+q).
 Con p=0,03,q=0,38 por año y a=0,50, t=ln[(1+0,50×0,38/0,03)/0,50]/0,41≈6,55 años. Se refiere al
 50% del mercado potencial m, no al 50% de toda la población. Si m equivale a 50% de la población,
 alcanzar a=0,50 equivale a 25% de esa población. Diferenciar ambos denominadores evita
 interpretar mal proyecciones de penetración.
 Cuando se quiere modelar precio o publicidad, los apuntes distinguen ampliar mercado potencial de
 acelerar adopción. Un menor precio puede volver elegibles a personas antes excluidas y elevar m;
 también puede acelerar a compradores ya elegibles. Un Bass generalizado puede incorporar
 esfuerzo de marketing en la velocidad del proceso, pero se debe especificar la ecuación, unidades y
 estimación. No se puede afirmar cuánto sube penetración a partir de Bass básico si precio no está
 en su ecuación. Con crecimiento del mercado potencial también cambia la interpretación de «no
 adoptantes»; no basta reemplazar m por una serie arbitraria y mantener todos los supuestos sin
 revisar.
 Norton-Bass extiende la lógica a generaciones sucesivas de un producto. Una generación nueva
 puede atraer nuevos usuarios y captar demanda de una anterior, por lo que ventas por generación
 dependen de lanzamiento, adopción, sustitución y compatibilidad. Sirve para reconocer la diferencia
 entre expansión de categoría y canibalización tecnológica. Una proyección debe distinguir primera
 adopción de categoría, actualización de equipo, reposición y ventas totales. No sumes dos curvas
 independientes para generaciones sustitutas sin contabilizar clientes compartidos: puedes contar
 dos veces el mismo mercado.
 Respuesta aplicada. Si un sistema de pago tiene baja adopción, revisa acceso, confianza,
 comercios compatibles, facilidad y ventaja frente a tarjetas antes de concluir que falta publicidad. Un
 servicio adicional de cuotas puede cambiar propuesta y mercado potencial; usa investigación de
Examen de Grado UC | materia, preguntas y respuestas 93

[pág. 94]
Marketing - versión clara y reordenada
 necesidades y conjoint con precio para medir trade-offs, y luego un piloto de uso para validar
 adopción y costo. La curva histórica y el modelo orientan escenarios; la causalidad de una
 intervención requiere evidencia adicional.
 Qué no debe aprenderse literalmente de un resumen
 Los resúmenes son mapas de estudio y pueden contener simplificaciones o errores. K-medias es
 sensible a extremos porque usa distancias al cuadrado; un mayor F de clustering no demuestra por
 sí solo una solución comercial óptima. Un p-valor pequeño no mide importancia económica.
 Atributos muy correlacionados pueden formar factores, pero factorial no convierte percepciones
 declaradas en preferencias reveladas. Una matriz de switching no prueba causalidad. Van
 Westendorp señala aceptabilidad percibida; un cruce llamado «óptimo» por una pauta no
 demuestra máximo de beneficio. Y un buen programa digital no garantiza más lealtad, menores
 costos ni ausencia de error de IA: esas son hipótesis que se verifican.
 Fuentes locales utilizadas en estas ampliaciones. Programa de Fundamentos de Marketing de
 Daniel Molina(2021-2); Programa de Mercados II de Daniela Zúñiga(2022); Apuntes de Clases
 Mercados II(Zúñiga); Claves Examen; Repaso Mercados I; Preparación para Examen de Grado
 Administración de Vicente García Casassus, sección Marketing; Resumen Mercados Parte 3 de
 Maida Palacios, leído visualmente; Examen Mercados II 01-2021 y Pauta Prueba 1 Mercados II
 01-2022. Las explicaciones y ejercicios adicionales son desarrollos de estudio; no se presentan
 como una pauta oficial del Examen de Grado 2027.
 27. Investigación de precios y lanzamiento
 Investigación de precios: Gabor-Granger y Van Westendorp
 Gabor-Granger ofrece precios y pregunta intención de compra, siguiendo una secuencia definida.
 Con proporción de aceptación por precio, estima demanda declarada y calcula ingreso (p×Q(p));
 para decisión financiera se usa contribución ((p-v)×Q(p)) y se incorporan costos. El orden puede
 anclar respuestas, la intención no es compra y la curva depende del competidor y contexto
 presentados.
 Van Westendorp pregunta precios que parecen demasiado baratos, baratos, caros y demasiado
 caros. Las curvas acumuladas e intersecciones delimitan un rango de aceptabilidad percibida bajo
 el instrumento. No identifican el precio que maximiza utilidad o margen, ni una DAP individual
 observada. Reporta método de acumulación y población. Valida con transacciones, piloto o
 experimento cuando el costo lo permita.
 Distinción importante: rango aceptable, precio de reserva, precio que maximiza ingreso y precio
 que maximiza contribución son preguntas diferentes. La mejor decisión puede cambiar al incluir
 costo, capacidad, segmento, frecuencia, referencia, reacción competitiva y efecto sobre marca.
Examen de Grado UC | materia, preguntas y respuestas 94

[pág. 95]
Marketing - versión clara y reordenada
 Medir intención, adopción y comportamiento real
 Una escala de intención sirve para comparar conceptos o describir predisposición, pero la
 correlación con compra individual puede ser moderada. Para mejorar inferencia, presenta precio,
 competencia, categoría y disponibilidad realistas; define horizonte corto y conducta binaria;
 distingue prueba de repetición. Aun así, no conviertas «probablemente compraría» en unidades
 observadas sin calibración. Para lanzamiento de durable, separa adopción inicial de reposición;
 para consumo frecuente, modela uso, frecuencia y penetración.
 Una buena evaluación combina evidencia de concepto, prueba ciega/de producto cuando aplica,
 precio, canal, capacidad operativa y piloto. Si la prueba conductual no es viable, declara el rango de
 escenarios y qué dato actualiza la recomendación. El grado suele valorar que reconozcas el límite
 sin dejar de decidir con la mejor evidencia disponible.
 28. Causalidad y experimentación
 Causalidad y experimentación
 Resultados potenciales
 El efecto causal compara resultado potencial de la misma unidad bajo tratamiento y control. Solo se
 observa uno; el otro es contrafactual. La aleatorización balancea en expectativa causas observadas
 y no observadas. El efecto promedio de asignar tratamiento puede estimarse comparando grupos si
 se mantiene integridad de asignación, medición, seguimiento y análisis.
 Diseña: hipótesis y mecanismo, población/unidad, tratamiento, control, resultado primario,
 guardarraíl, duración, tamaño de muestra, asignación, contaminación, cumplimiento y plan analítico.
 ITT analiza según asignación original; evita seleccionar solo quienes cumplieron. Reporta
 estimación, intervalo y relevancia práctica, no solo p-valor.
 Riesgos y diseños observacionales
 Confusor es causa común de tratamiento y resultado; mediador está en la ruta posterior al
 tratamiento; colisionador recibe efectos de dos variables. Ajustar por mediador puede ocultar parte
 del efecto total; condicionar en colisionador puede crear asociación espuria. La secuencia temporal
 sola no identifica causalidad.
 Diferencias en diferencias compara cambios y requiere tendencias paralelas plausibles,
 composición estable y ausencia de shocks diferenciales. Matching y controles requieren que no
 quede confusión no observada importante y que exista soporte/solapamiento. En series temporales,
 controla tendencias y estacionalidad; en experimentos geográficos, evita contaminación entre
 zonas. Nombra el supuesto que sostiene la inferencia y propone una prueba de sensibilidad.
Examen de Grado UC | materia, preguntas y respuestas 95

[pág. 96]
Marketing - versión clara y reordenada
 29. Texto y análisis cualitativo digital
 Texto y analítica cualitativa de datos digitales
 TF-IDF da más peso a un término que aparece con frecuencia en un documento y menos si
 aparece en casi todos los documentos. Una forma común es (TF[i,j]=n[i,j]/Nⱼ), (IDFᵢ=log(N/dfᵢ)),
 (TFIDF=TF×IDF); algunas implementaciones suavizan logaritmos y conteos, por lo que debe
 declararse la convención. El resultado ordena términos distintivos, no revela automáticamente
 significado o intención.
 Topic modeling agrupa coocurrencias para proponer temas latentes. Cada tema necesita lectura
 humana, ejemplos y validación; el algoritmo puede agrupar por estilo, entidad o palabra común en
 vez de un constructo útil. Análisis de sentimiento clasifica polaridad o emoción; negación, ironía,
 modismos, contexto e idioma producen errores. Evalúa con conjunto etiquetado por personas,
 matriz de confusión, precisión/recall y sesgos por grupo. En decisiones relevantes incluye revisión
 humana.
 Ejemplo. Las reseñas repiten «lento». Puede describir despacho, aplicación, atención o carga de
 página. Frecuencia bruta no identifica mecanismo. Codifica contexto (objeto de evaluación, etapa
 de viaje, severidad), compara con pedidos y tiempos operativos, y valida manualmente una
 muestra. Una palabra frecuente puede ser indicador de fricción real o artefacto de una
 campaña/tema puntual.
 30. Extensiones cuantitativas y correcciones de resúmenes
 Panel, repetición y denominadores
 Para estudiar un cambio individual, Var(Y₁-Y₀)=Var(Y₁)+Var(Y₀)-2Cov(Y₁,Y₀). Un panel con
 correlación positiva puede estimar cambios con mayor precisión que dos muestras independientes
 comparables. Ejemplo: si ambas varianzas son 100 y la covarianza es 60, la varianza del cambio
 es 200-120=80; con muestras independientes sería 200. Para la media del cambio de n individuos
 independientes entre sí, la varianza es 80/n. Esta ventaja requiere comparabilidad; abandono
 selectivo, errores y reactividad del panel pueden introducir sesgo. La frase «un panel siempre tiene
 menor varianza» necesita esos supuestos.
 En Gamma-Poisson, conserva la parametrización forma r, tasa s y duración T. La media de la tasa
 es r/s y la varianza r/s²; la media del conteo es rT/s y su varianza rT/s+rT²/s². Para estimar por
 momentos con T conocido, media del conteo μ y varianza v>μ:
 r=μ²/(v-μ), s=rT/μ=μT/(v-μ).
 Si μ=4 compras por trimestre y v=12, con T=1 trimestre, r=16/8=2 y s=4/8=0,5 trimestres. La tasa
 media es 4 por trimestre y su varianza 8. La penetración trimestral es 1-(0,5/1,5)²=8/9≈88,89%; la
 compra media entre compradores es 4/(8/9)=4,5. Si v≤μ, esta estimación no entrega una mezcla
 Gamma válida con heterogeneidad positiva; revisa muestra, dispersión y modelo, en lugar de
 inventar parámetros negativos.
 Para dos ventanas adyacentes de igual duración T con una tasa individual constante, la proporción
 que compra en ambas ventanas es 2·Pen(T)-Pen(2T). Sale de inclusión y exclusión:
 P(A∩B)=P(A)+P(B)-P(A∪B). En el ejemplo, Pen(2T)=1-(0,5/2,5)²=0,96; ambas
Examen de Grado UC | materia, preguntas y respuestas 96

[pág. 97]
Marketing - versión clara y reordenada
 ventanas=2×0,8889-0,96=0,8178. Entre compradores de la primera ventana, la repetición es
 0,8178/0,8889≈92%. La fórmula no es la probabilidad de hacer dos o más compras dentro de una
 sola ventana: esa otra pregunta requiere P(X≥2)=1-P(X=0)-P(X=1). Tampoco sustituyas 2T por T+1
 cuando T usa una unidad diferente o no vale uno.
 La Gamma no mantiene su media constante si haces s→∞ dejando r fijo: tanto media como
 varianza tienden a cero. Para estudiar hogares progresivamente homogéneos con la misma media
 λ̄, aumenta r y s manteniendo r/s=λ̄; entonces la varianza λ̄/s tiende a cero. Esta distinción aclara
 una simplificación de los apuntes y muestra por qué las unidades y lo que se mantiene fijo importan.
 El «monopolio natural» de los resúmenes de compra repetida se refiere a la mayor presencia
 relativa de compradores livianos en marcas grandes. No significa que una marca grande sea un
 monopolio económico ni que cada comprador nuevo la elija. Se trata de una regularidad empírica
 de determinadas categorías estables, complementaria al doble riesgo. Se usa como benchmark
 para cuestionar si un resultado de lealtad era esperable dado el tamaño de marca; no sustituye la
 medición de disponibilidad, preferencia o causalidad.
 Bass generalizado: ecuación, mecanismo y cálculo
 El resumen de Carolina Saavedra distingue dos extensiones. En la primera, cambia el mercado
 potencial. Una aproximación del material es mₜ=mₜ₋₁[1+g+c·ΔP%], donde g es crecimiento natural
 en la unidad de tiempo indicada y c representa la respuesta del potencial al cambio porcentual del
 precio. Si m₀=10.000, g=0,02, c=-0,5 y el precio baja 10% expresado como -0,10,
 m₁=10.000[1+0,02+(-0,5)(-0,10)]=10.700. El aumento potencial es 7%; no es una adopción
 inmediata de 700 personas. Explicita si porcentajes se ingresan como fracciones: mezclar 10 con
 0,10 multiplica por cien el efecto. Es una aproximación local, no un resultado universal; hay que
 modelar cómo entran nuevos elegibles y revisar el balance entre potencial y adoptantes.
 La segunda extensión modifica la velocidad: dF/dt=x(t)[p+qF(t)][1-F(t)], con x(t)≥0 como
 multiplicador de esfuerzo. Define tiempo efectivo τ(t)=∫₀ᵗx(u)du. Mediante la regla de la cadena,
 dF/dτ=(p+qF)(1-F), por lo que la solución del Bass básico se aplica al tiempo efectivo:
 F(t)=[1-exp(-(p+q)τ(t))]/[1+(q/p)exp(-(p+q)τ(t))].
 Si x(t)=1, τ=t y recuperas Bass básico. Si durante el primer año x=1,5 y después vuelve a uno, al
 terminar ese año el proceso ha recorrido 1,5 unidades de tiempo efectivo. Este modelo expresa una
 hipótesis de aceleración; no estima automáticamente x por observar más publicidad. Los apuntes
 proponen una relación con cambios de precio y publicidad, cuyos coeficientes deben estimarse y
 cuya validez se limita al rango observado. Si una fórmula predice x<0, viola la interpretación de
 adopción creciente: no se usa sin revisar especificación y límites.
 La política de precios requiere además contribución, descuento de flujos, reacción de competidores
 y costo del esfuerzo. Acelerar adopción puede elevar volumen temprano y disminuir margen. Las
 afirmaciones del resumen sobre cuándo debe comenzar a caer el precio corresponden a un modelo
 de optimización con supuestos particulares; no son una regla para todos los productos o mercados.
Examen de Grado UC | materia, preguntas y respuestas 97

[pág. 98]
Marketing - versión clara y reordenada
 Norton-Bass: evitar doble conteo entre generaciones
 En la versión de dos generaciones del resumen, m₁ es el potencial inicial y m₂ el potencial adicional
 de la segunda generación, lanzada en t₂. Define F₁(t) como difusión inicial y F₂(t-t₂)=0 antes del
 lanzamiento. Una representación pedagógica es:
 Usuarios en generación 1: A₁(t)=m₁F₁(t)[1-F₂(t-t₂)].
 Usuarios en generación 2: A₂(t)=F₂(t-t₂)[m₂+m₁F₁(t)].
 El término m₁F₁F₂ es migración: se resta de la primera generación y se suma a la segunda.
 Ejemplo: m₁=100.000, m₂=20.000, F₁=0,80 y F₂=0,25. Sin migración, la primera tendría 80.000
 usuarios; migran 20.000. A₁=60.000 y A₂=0,25×(20.000+80.000)=25.000. El total es 85.000: 80.000
 de la base inicial y 5.000 de la expansión, contando una vez a quienes migraron. Al restar y sumar
 exactamente la migración, A₁+A₂=m₁F₁+m₂F₂.
 Estas cantidades son usuarios asignados a generaciones bajo el modelo; no son ventas nuevas por
 periodo ni el acumulado histórico de todas las personas que alguna vez compraron la generación 1.
 Ese acumulado histórico no podría disminuir al migrar clientes. Para calcular ventas de reposición o
 actualización necesitas además modelar el momento de cambio y unidades por usuario. Define si
 los potenciales se entregan como 100.000 y 20.000 adicionales o como 100.000 y 120.000 totales;
 confundirlos duplica la expansión. La igualdad de curvas de difusión entre generaciones es un
 supuesto de la versión del curso, no una característica necesaria de todo modelo multigeneración.
 Tres funciones de demanda y una regla de simulación que exige escala
 Una función lineal Q=a+bp, b<0, tiene elasticidad ε=bp/(a+bp) donde la demanda es positiva. Una
 función exponencial Q=c·exp(a+bp) tiene ε=bp. Una función logística acotada
 Q=c·exp(a+bp)/[1+exp(a+bp)] tiene ε=bp(1-Q/c). El material de Carolina Saavedra etiqueta una
 fórmula logística bajo el rótulo «exponencial»: reconoce la ecuación, no solo el título. La logística
 mantiene Q entre cero y c; la lineal puede dar demanda negativa si extrapolas, y la exponencial no
 tiene la misma cota superior.
 Ejemplo logístico. c=1.000 compradores potenciales, a=2, b=-0,1 por unidad monetaria y p=20. La
 utilidad es cero, Q=500 y ε=-0,1×20×(1-0,5)=-1. Si el costo marginal es 8, el margen proporcional es
 (20-8)/20=0,60. La condición de Lerner exige 1/|ε|=0,60 para un óptimo interior, pero aquí 1/|ε|=1:
 este precio no cumple la condición. Eso no autoriza a sustituir p=8/(1-1) y concluir «infinito»: la
 elasticidad cambia con p. Deriva beneficio con la función completa o resuelve numéricamente,
 comprueba restricciones y luego interpreta.
 Los resúmenes también incluyen una regla Bradley-Terry-Luce de preferencias positivas,
 Pⱼ=uⱼᵇ/Σuₖᵇ, b>0. Exige utilidades positivas y una escala apropiada; no acepta utilidades negativas
 elevadas a un exponente arbitrario. Con u=(2;1), b=1 produce probabilidades (2/3;1/3). Si sumas
 uno a ambos valores, pasa a (3/5;2/5): cambia la predicción. En cambio, el logit exp(Vⱼ)/Σexp(Vₖ) es
 invariante a sumar la misma constante a todos los V. No intercambies reglas de simulación sin
 justificar la escala. First-choice, BTL y logit producen resultados distintos; una preferencia simulada
 sigue requiriendo validación comercial y opción externa cuando corresponda.
 Fuentes locales cotejadas: Resumen Mercados II de Carolina Saavedra, 37 páginas (texto
 completo y revisión visual de fórmulas en páginas 21-22, 29-32 y 34, 36-37); VÍCTOR-Mercados II,
 12 páginas; resúmenes de Fundamentos de Maca Azolas; Marketing de Domingo Anrique; y los
Examen de Grado UC | materia, preguntas y respuestas 98

[pág. 99]
Marketing - versión clara y reordenada
 resúmenes HTML de Fundamentos y de Pruebas 1 y 2 de Analytics. La enseñanza corrige los
 errores identificados; la auditoría de cada archivo informa por separado las imágenes o porciones
 que aún requieren verificación.
 31. Laboratorios y auditoría de pautas
 Laboratorio cuantitativo integrado
 Laboratorio A: ANOVA, incertidumbre y elección
 Supón que una empresa prueba tres envases con cinco personas por envase y obtiene ratings de
 intención de compra:
 Envase A Envase B Envase C
 4 5 7
 5 5 6
 4 6 7
 5 4 8
 4 5 7
 Medias: A=4,4; B=5,0; C=7,0; media global=5,467. La suma de cuadrados entre grupos es
 (SS_B=5Σ(ȳⱼ-ȳ)²≈18,53). La suma de cuadrados dentro es (SS_W=ΣΣ(yᵢⱼ-ȳⱼ)²=5,2). Grados de
 libertad: entre=2 y dentro=12. Por tanto (MS_B≈9,27), (MS_W≈0,433), (F≈21,39). Un F así de
 grande sería evidencia contra igualdad de todas las medias bajo los supuestos del modelo. El
 resultado no dice automáticamente que C sea superior en el mercado: se requieren comparaciones
 de pares, incertidumbre, muestra representativa y prueba de conducta real. Aquí además son cinco
 respuestas por grupo, por lo que una conclusión gerencial definitiva sería prematura.
 Laboratorio B: elegir K y no sobreinterpretar k-medias
 Considera clientes ya estandarizados en dos variables (sensibilidad a conveniencia, sensibilidad a
 precio): A=(-1;-1), B=(-0,8;-1,2), C=(1;1), D=(1,2;0,8). Con K=2, una asignación intuitiva es A,B y
 C,D. Centroides: μ1=(-0,9;-1,1) y μ2=(1,1;0,9). Distancia cuadrática de A a
 μ1=(-1+0,9)²+(-1+1,1)²=0,01+0,01=0,02; de A a μ2=(-1-1,1)²+(-1-0,9)²=4,41+3,61=8,02. A queda
 claramente en grupo 1. Sin embargo, esta separación solo acredita estructura en estas dos
 variables y observaciones. Para llamarlos segmentos, hay que perfilar con datos no usados en el
 algoritmo, comprobar estabilidad y probar si responden distinto a una oferta. Un cluster que no lleva
 a una acción mejor que targeting simple no tiene valor comercial.
 Laboratorio C: interpretar odds correctamente
 Un logit de compra estima intercepto -1,2 y coeficiente de exposición 0,5. Sin exposición, el índice
 lineal es -1,2; la probabilidad es (1/(1+e^1,2)≈0,231). Con exposición, el índice es -0,7 y la
 probabilidad ≈0,332. La diferencia predicha es 10,1 puntos porcentuales en este perfil. Los odds se
 multiplican por (e^0,5≈1,65), es decir, aumentan 65%; la probabilidad no sube 65 puntos. Aunque la
 salida sugiera asociación, si las personas expuestas ya tenían más intención, el coeficiente no
 identifica el efecto causal de la campaña.
Examen de Grado UC | materia, preguntas y respuestas 99

[pág. 100]
Marketing - versión clara y reordenada
 Laboratorio D: Bass y momento máximo de adopción
 En el Bass básico, para (q>p), el máximo flujo de adopción ocurre en (t=ln(q/p)/(p+q)), bajo tiempo
 continuo y parámetros constantes. Si p=0,03 y q=0,38 por año, (t=ln(12,67)/0,41≈6,19) años desde
 el origen temporal del modelo. Este es un resultado del ajuste, no una fecha garantizada. Cambios
 de precio, acceso, competencia, restricciones de stock o un mercado potencial mal especificado
 desplazan o invalidan la proyección. Explica siempre el origen de t y la periodicidad usada.
 Laboratorio E: conjoint, DAP y simulación
 Un perfil «entrega al día siguiente» aumenta utilidad estimada en 0,6 unidades; un aumento de
 precio de $1.000 reduce utilidad en 0,25. La DAP por entrega rápida es (0,6/(0,25/1.000)=$2.400).
 La empresa no debería cobrar automáticamente $2.400 más: debe revisar error de estimación,
 costos, margen, heterogeneidad, disponibilidad y si el escenario estaba representado en el diseño.
 Para simular participación, agrega alternativas de competidores y una opción de no compra; calcula
 utilidad para cada perfil y aplica una regla común. Presenta sensibilidad al precio y competencia:
 una simulación puntual sin escenario alternativo oculta la incertidumbre.
 Laboratorio F: uplift causal de una campaña
 Supón asignación aleatoria de 10.000 clientes por grupo. Compra: 8,0% en tratamiento y 7,2% en
 control. Efecto ITT en tasa = 0,8 puntos porcentuales. Compradores incrementales esperados por
 cada 10.000 asignados ≈80. Si margen por compra es $18.000, margen incremental esperado =
 $1.440.000 por cada 10.000 clientes; resta costo de campaña y cualquier costo variable adicional.
 Un intervalo de confianza debe acompañar el estimador. Verifica asignación, contaminación,
 compras fuera de ventana y que el resultado primario no se haya elegido después de ver los datos.
 Si la diferencia es estadísticamente significativa pero margen incremental neto es negativo, no
 escales la campaña en su forma actual.
 Laboratorio G: precio declarado y contribución
 Una prueba Gabor-Granger a $10.000 obtiene aceptación declarada de 40% y a $9.000 de 48%, en
 una muestra de 1.000 personas del segmento. Proyección simplificada sobre 20.000 prospectos:
 8.000 y 9.600 intenciones, respectivamente. Con costo variable $6.000, contribuciones declaradas:
 a $10.000 → $4.000×8.000=$32 millones; a $9.000 → $3.000×9.600=$28,8 millones. Aunque el
 precio bajo atrae más intención y puede maximizar ingreso, no maximiza contribución en esta
 proyección. La conclusión sigue siendo hipotética: aplica un piloto y mide compra real, mezcla,
 repetición y respuesta competitiva.
 Taller de verificación: resolver y auditar una pauta cuantitativa
 Una pauta local aporta métodos y criterios de corrección, pero puede contener errores de
 transcripción, redondeo o supuestos tácitos. Separa tres preguntas: ¿puedo reproducir el cálculo?,
 ¿qué supuesto permite interpretar el resultado?, ¿qué decisión realmente sostiene? Estos ejercicios
 proceden de los compilados locales de conjoint y elección de marca, cuyo texto se revisó completo;
 las correcciones se señalan en lugar de copiar el resultado sin comprobarlo.
Examen de Grado UC | materia, preguntas y respuestas 100

[pág. 101]
Marketing - versión clara y reordenada
 Interpolación, disposición a pagar y codificación
 En StarCard se estiman efectos de descuento 10%=7,5 y 15%=10,5;30 tiendas=2; precio 20= $-5
 respecto de precio 10; intercepto 5. Bajo interpolación lineal adicional, precio 15 aporta-2,5;
 precio 18 aporta-4; descuento 12% aporta 7,5+(2/5)(10,5-7,5)=8,7. Por tanto, con 30 tiendas,
 U(10%,15)=5+7,5+2-2,5=12; U(12%,18)=5+8,7+2-4=11,7. Se prefiere el primer perfil dentro del
 modelo, aunque ofrezca menor descuento.
 El aumento de utilidad de 10% a 12% es 1,2. La pendiente de utilidad-precio entre 10 y 20
 es-5/10=-0,5 por unidad monetaria. DAP incremental=1,2/0,5=2,4; precio de
 indiferencia=15+2,4=17,4. Este cálculo no se obtiene de las dummies por sí solas: supone
 interpolación. Si el precio tiene un umbral o la valoración de descuento es no lineal, se necesitan
 otros niveles o una especificación diferente. Conjoint de rankings tratados como métricos aproxima
 utilidad bajo supuestos de escala; conviene contrastar con elección y sensibilidad.
 En el ejemplo de smartphones, los tamaños de segmentos 35%,30%,40% suman 105%. No se
 pueden usar directamente como pesos poblacionales; solicita corrección o presenta una
 normalización solo como escenario provisional explícito. El nuevo teléfono tiene cámara 64 MP,
 nivel no incluido en la tabla(32,48,108 MP): se debe justificar interpolación o recoger información
 adicional. La utilidad del perfilC según los niveles impresos suma 3,3+2,4+2,4+1,4=9,5, mientras la
 pauta consigna 9,6. Estas discrepancias importan para trazabilidad aunque no cambien el
 diagnóstico principal.
 La simulación de una oferta que casi domina todos los atributos puede entregar share cercano a
 100%. No se redondea eso a certeza comercial: marca omitida, muestra, precio irrealista,
 disponibilidad, opción de no compra y escala de utilidad afectan validez. También se distingue
 promedio de probabilidades individuales de probabilidad calculada con utilidades promedio:
 la función logit es no lineal, así que ambas operaciones generalmente difieren. Segmenta o agrega
 sobre individuos con pesos válidos antes de inferir un mercado.
 Cómo se estima un logit y cómo se evalúa
 Si cada persona u ocasión elige una alternativa, la verosimilitud del modelo es L=ΠᵢPᵢ,elección
 observada. Su logaritmo es ℓ=Σᵢln(Pᵢ,elección observada). Máxima verosimilitud busca
 parámetros que maximicen esa suma dentro del modelo y conjunto de datos. Dar una probabilidad
 alta a una opción que no fue elegida no ayuda a la verosimilitud de esa fila. Para datos de panel, la
 evaluación estadística debe reconocer dependencia y estructura del modelo; no todos los tickets
 equivalen a hogares independientes.
 Ejercicio del compilado de aerolíneas. Las probabilidades de las opciones efectivamente
 elegidas en la estimación 1 son 0,45;0,40;0,10;0,50: producto 0,009 y log-verosimilitud≈-4,7105. En
 la estimación 2 son 0,50;0,50;0,10;0,60: producto 0,015 y log-verosimilitud≈-4,1997. La segunda se
 ajusta mejor según este criterio entre las dos ofrecidas. Clasificando por alternativa de mayor
 probabilidad, acierta 3 de 4=75%; la tercera persona eligeB aunque el modelo asigna mayor
 probabilidad aA. Ajuste de verosimilitud y tasa de acierto son criterios distintos y ninguno garantiza
 generalización.
 Una comparación adicional enfrenta log-verosimilitud del modelo con una referencia de solo
 constantes. Un pseudo-R² usual es 1-ℓ_modelo/ℓ_referencia; no es la proporción de varianza
 explicada de una regresión lineal. Evalúa además probabilidades/calibración, log-loss fuera de
Examen de Grado UC | materia, preguntas y respuestas 101

[pág. 102]
Marketing - versión clara y reordenada
 muestra, errores relevantes para la decisión y estabilidad temporal. La opción de no compra forma
 parte del denominador cuando está incluida: omitirla cambia todas las probabilidades.
 IIA individual y agregación: una diferencia que cambia cálculos
 IIA se aplica a probabilidades condicionadas al mismo perfil. Si desapareceA y utilidades deB,C
 permanecen, PᵢB,nueva=PᵢB/(1-PᵢA) y análogamente paraC. Si los perfiles tienen probabilidades
 diferentes, se recalcula para cada perfil y después se promedia. En general, promedio[PᵢB/(1-PᵢA)]
 ≠ promedio(PᵢB)/[1-promedio(PᵢA)]. Renormalizar cuotas agregadas requiere un supuesto
 adicional de homogeneidad o una aproximación explícita.
 Usando la estimación 2 del ejercicio de aerolíneas, los perfiles
 tienen(A,B,C)=(0,5;0,2;0,3),(0,2;0,3;0,5),(0,6;0,1;0,3),(0,3;0,6;0,1). Al salirA, las probabilidades deB
 son 0,2/0,5=0,4;0,3/0,8=0,375;0,1/0,4=0,25;0,6/0,7≈0,8571. Su promedio es 47,05%; C queda
 52,95%. Renormalizar las cuotas promedio iniciales(A 40%,B 30%,C 30%) daría 50% paraB y 50%
 paraC, un resultado diferente. La pauta del compilado mezcla tablas y emplea una renormalización
 agregada; para estudiar conserva la restricción IIA y el cálculo por perfil, y declara si se adopta la
 aproximación de la pauta.
 IIA sigue siendo una restricción sobre sustitución dentro de cada perfil: una alternativa aérea
 cercana puede captar mucho más que el bus en la realidad. Heterogeneidad de precios o perfiles
 produce distintos porcentajes agregados, pero no prueba que el logit simple capte una sustitución
 flexible dentro de cada individuo.
 Recalcular no compra y promociones con interacciones
 Con utilidades(A,B,C,no compra)=(3;-2;0;-4), la probabilidad de no compra es
 exp(-4)/[exp(3)+exp(-2)+exp(0)+exp(-4)]≈0,0008623=0,0862%. Compra total≈99,9138%. La pauta
 impresa cambia por error exp(-2) a exp(2) en el denominador y obtiene otra cifra; conserva el signo
 del dato al sustituir. Para cálculo numérico, restar el máximo de utilidades a todas antes de
 exponenciar evita desbordamiento y no cambia probabilidades.
 En café, los coeficientes son precio regular-29,94, descuento 29,21, dummy promoción 2,11 e
 interacción promoción×lealtad-0,68. Si se aumenta precio regular enδ y se reduce por igual
 mediante promoción, el cambio de utilidad no es exactamente 2,11: ΔV=(-29,94+29,21)δ+2,11-0,68
 L=-0,73 δ+2,11-0,68 L, si antes no había promoción y L es la lealtad definida en el modelo.
 Paraδ=0,10 yL=0,80, ΔV=-0,073+2,11-0,544=1,493. La pauta aproxima los dos coeficientes de
 precio como iguales y no incorpora la interacción en ese paso. Declara esa aproximación si se usa;
 para ejecutar el modelo completo utiliza todos sus términos.
 Una asociación positiva con promoción no autoriza engañar ni demuestra el efecto causal de una
 falsa rebaja. Las promociones pueden seleccionarse según demanda y contexto; además, las
 condiciones reales comunicadas deben ser veraces. La respuesta de Distinción interpreta el
 mecanismo de percepción y compara resultados rentables, sin convertir una descripción estadística
 en una recomendación perjudicial.
 Fuentes locales. Compilado Ejercicios Análisis Conjoint-Pauta(13 páginas) y Compilado Ejercicios
 Elección de Marca-Pauta(12 páginas), encontrados fuera del catálogo inicial de Marketing. No se
 altera la pauta original; este taller deja visibles las discrepancias y los supuestos al aprender de ella.
Examen de Grado UC | materia, preguntas y respuestas 102

[pág. 103]
Marketing - versión clara y reordenada
 32. Integración y redacción de una respuesta completa
 Cómo redactar una respuesta de Analytics de Distinción
 1. Define la decisión y la unidad de análisis. 2. Traduce la decisión en pregunta analítica y
 población. 3. Justifica datos, muestra e instrumento. 4. Especifica modelo, variable resultado y
 parámetros. 5. Muestra cálculo o procedimiento reproducible. 6. Interpreta magnitud, dirección,
 unidad e incertidumbre. 7. Evalúa supuestos, selección, calidad y validez externa. 8. Convierte el
 resultado en acción y define una prueba/monitoreo.
 Un coeficiente significativo, cluster limpio, mapa atractivo o R² alto no basta. La Distinción viene de
 vincular evidencia con decisión y explicar qué cambiaría la recomendación.
 Examen de grado: construcción de la respuesta
 Desarrollo de estrategia
 Una respuesta de estrategia debería empezar con una tesis condicional y específica: «Recomiendo
 proteger el segmento X con una variante y mantener precio en Y, porque evidencia A indica
 mecanismo B; lo probaría en canal C antes de escalar». Luego demuestra el diagnóstico, aplica
 modelos y conecta plan con economía. Evita frameworks en secuencia sin decisión.
 Preguntas cuantitativas
 Escribe datos, unidades y supuestos; elige fórmula; muestra operación; comprueba que resultado
 tenga sentido; traduce a decisión; declara incertidumbre. En logit no llames elasticidad a coeficiente;
 en ANOVA no concluyas par sin post hoc; en conjoint no llames compra a preferencia declarada; en
 Bass no confundas adopción con ventas; en PSM no digas óptimo sin objetivo económico.
 Qué eleva una respuesta de aprobada a Distinción
 Una respuesta aprobada puede definir y aplicar el marco correcto. Una respuesta de Distinción
 además selecciona qué parte del marco es pertinente, identifica mecanismo, calcula implicancia
 económica, compara alternativa, declara supuesto crítico, reconoce evidencia incompleta, propone
 prueba y especifica cómo decidir según el resultado. No agrega jerga: agrega razonamiento
 verificable.
 B. Marketing Analytics
 Investigación de mercados: del síntoma al diseño
 Un problema gerencial expresa una decisión (por ejemplo, qué precio fijar); un problema de
 investigación define incertidumbre que los datos pueden reducir (qué atributos explican elección y
 cómo varía sensibilidad al precio). Antes de recolectar datos, escribe la decisión, alternativas,
 resultado de interés, población, unidad de análisis, horizonte y costo del error. “Conocer al cliente”
 es demasiado amplio para un estudio defendible.
 La investigación exploratoria descubre conceptos y mecanismos; descriptiva estima incidencia,
 perfiles o tendencias; causal estima el cambio atribuible a una intervención. Métodos cualitativos no
 estiman prevalencia poblacional; encuestas transversales no demuestran causalidad; experimentos
 pueden tener validez externa limitada. Entrevistas individuales sirven cuando hay sensibilidad o
 experiencia compleja; grupos focales generan interacción y lenguaje compartido, pero conformidad
Examen de Grado UC | materia, preguntas y respuestas 103

[pág. 104]
Marketing - versión clara y reordenada
 y dominancia pueden sesgar la discusión. Observación registra conducta en contexto, no siempre
 motivos.
 Diseña el cuestionario desde constructos y decisiones. Usa lenguaje comprensible y neutral,
 pregunta una cosa a la vez, fija periodo de recuerdo, ofrece alternativas exhaustivas y mutuamente
 excluyentes cuando corresponda, separa “no sabe” de “ninguna”, y ordena preguntas desde
 espontáneas a asistidas. Pretest cognitivo: pide a personas del público objetivo que expliquen qué
 entendieron y cómo eligieron respuesta. Revisa duración, saltos, escala, faltantes, orden y modo de
 aplicación. Un cuestionario preciso puede producir una muestra sesgada; ambas dimensiones se
 controlan por separado.
 Muestreo, incertidumbre y lectura de proporciones
 La población objetivo debe corresponder a la decisión. Un marco muestral incompleto excluye
 personas; la no respuesta puede sesgar si responde sistemáticamente quien tiene mayor interés.
 Muestreo aleatorio simple da probabilidad igual conocida; estratificado divide la población en grupos
 y selecciona dentro de ellos, útil para asegurar subgrupos; conglomerados selecciona unidades
 agrupadas y reduce costo, pero suele aumentar error; sistemático selecciona cada k unidades
 después de un inicio aleatorio y requiere que el orden no tenga periodicidad problemática. Muestreo
 por conveniencia no permite inferencia probabilística general.
 Para estimar proporción con muestreo aleatorio simple, (n_0=z²p(1-p)/e²). Con 95% de confianza
 (z≈1,96), p=0,5 y error e=0,05: n₀≈1,96²×0,25/0,0025≈384,2, por lo que se requieren
 aproximadamente 385 respuestas completas bajo esos supuestos. Si la tasa esperada de
 respuesta es 60%, invitar a unas 642 personas; esto no corrige sesgo de no respuesta. Con
 población finita N se usa (n=n_0/[1+(n_0-1)/N]); con conglomerados se multiplica por el efecto de
 diseño antes de ajustar. Para estimar medias se usa desviación estándar y margen de error
 correspondiente.
 Ponderar restituye composición conocida si la selección diferencial puede corregirse con
 información adecuada, pero pesos extremos elevan varianza. Reporta base no ponderada,
 ponderación, tasas de respuesta, error o intervalo y restricciones del marco. Una precisión numérica
 estrecha no elimina sesgo sistemático. Diferencias entre subgrupos requieren errores estándar de
 la diferencia, no comparar dos porcentajes visualmente. El intervalo de confianza describe
 incertidumbre del procedimiento, no probabilidad de que un parámetro fijo esté en un intervalo
 observado.
 ANOVA: qué prueba y cómo interpretar
 ANOVA compara medias de una variable continua entre dos o más grupos. Descompone variación
 total en variación entre grupos y dentro de grupos: (SS_T=SS_B+SS_W). Con k grupos y N
 observaciones, (MS_B=SS_B/(k-1)), (MS_W=SS_W/(N-k)) y (F=MS_B/MS_W). Si F es grande
 frente a su distribución bajo H₀: μ₁=…=μₖ, hay evidencia de que alguna media difiere. No identifica
 qué pares difieren; aplica contrastes planificados o post hoc controlando multiplicidad.
 Ejemplo. Tres campañas generan satisfacción media 6,1; 6,8; 7,0 en escala 1-10. Un ANOVA
 significativo indica al menos una diferencia bajo supuestos, pero no prueba que la campaña 3 sea
 superior a todas. Revisa independencia, residuos aproximadamente normales dentro de grupo y
 varianzas comparables; con heterocedasticidad considera Welch. Reporta tamaños por grupo,
 medias e intervalos, η² o medida de efecto, comparaciones y relevancia práctica. Si la asignación a
Examen de Grado UC | materia, preguntas y respuestas 104

[pág. 105]
Marketing - versión clara y reordenada
 campaña no fue aleatoria, ANOVA describe diferencias ajustadas al diseño; no convierte una
 comparación observacional en causal.
 Factorial ANOVA estudia efectos principales e interacción. Si el efecto de campaña depende del
 segmento, una interacción significativa indica que la diferencia cambia por segmento; promediar
 puede ocultar esa heterogeneidad. Representa medias por celda y analiza efectos simples. Antes
 de declarar que una campaña “funciona mejor”, define resultado, grupo y exposición, y distingue
 significancia estadística de la utilidad de despliegue.
 K-means: construir, validar y usar grupos
 K-means asigna cada observación al centroide más cercano y actualiza centroides para minimizar
 la suma de distancias cuadradas dentro de los grupos. El procedimiento requiere elegir k, escalar
 variables, inicializar centros, iterar asignación/actualización y revisar convergencia. Funciona mejor
 con variables numéricas y grupos aproximadamente compactos; variables categóricas, outliers,
 distribuciones muy asimétricas o formas no esféricas pueden distorsionarlo.
 Mini-ejemplo. Clientes tienen frecuencia mensual y gasto por visita. Un cliente con gasto 500.000
 domina a otro con frecuencia 3 si las escalas no se normalizan. Estandarizar convierte unidades
 comparables, pero puede amplificar ruido de variables con baja varianza. Define variables según
 necesidad comercial y decide tratamiento de extremos con fundamento. Ejecuta múltiples inicios
 aleatorios, compara inercia (que siempre cae al subir k), silhouette, estabilidad ante remuestreo y
 facilidad de acción. El “codo” es una guía, no prueba objetiva de k correcto.
 Después perfila grupos usando variables no usadas para crear el cluster: compra, margen,
 retención, canal o respuesta a intervención. Evalúa estabilidad temporal, tamaño, identificabilidad y
 capacidad de asignar nuevos clientes. Etiquetar cluster como “premium” requiere mostrar
 evidencias. Si los grupos no responden diferente a una acción, quizá no convenga personalizar. No
 uses un p-valor universal como criterio de calidad de clustering: la validez depende de estructura,
 estabilidad y utilidad fuera de muestra.
 Factorial y MDS: representar percepciones sin inventar ejes
 Análisis factorial busca variables latentes que explican covariación entre indicadores observados.
 Factor común representa varianza compartida; componente principal resume varianza total para
 reducir dimensión y no equivale conceptualmente a un factor latente. Verifica correlaciones,
 adecuación muestral, comunalidades, cargas y estabilidad. Número de factores puede apoyarse en
 eigenvalores, gráfico scree y análisis paralelo, junto con interpretación. La rotación cambia
 orientación para facilitar lectura, no mejora mágicamente la validez.
 Una carga indica asociación entre ítem y dimensión bajo el modelo; el signo puede invertirse si se
 invierte eje. Nombrar una dimensión exige observar varios ítems con cargas coherentes y validar
 significado con teoría y consumidores. Un ítem ambiguo o con cargas cruzadas no se resuelve
 forzando una etiqueta conveniente.
 MDS busca una configuración de puntos cuyas distancias representen disimilitudes observadas.
 Puede partir de juicios de similitud entre pares o distancias derivadas de atributos. Evalúa stress y
 estabilidad; representación bidimensional simplifica, ejes son arbitrarios en orientación y escala. “A
 y B están cerca” significa que son percibidas como similares en los datos y métrica usados; no
 implica que compartan todos los atributos ni que una marca deba moverse a un espacio vacío.
 Superpone atributos, preferencias y elección para discutir oportunidad. Un mapa describe
Examen de Grado UC | materia, preguntas y respuestas 105

[pág. 106]
Marketing - versión clara y reordenada
 estructura relativa, no participación, causalidad ni tamaño de mercado.
 Modelos de compra repetida: Gamma-Poisson, Beta-Binomial y Dirichlet
 Cuando clientes difieren en tasa de compra, el promedio agregado puede ocultar que muchos
 compran poco y pocos compran mucho. Poisson modela conteos n en una ventana de duración t,
 dado una tasa individual λ: (P(N=n|λ)=exp(-λt)(λt)ⁿ/n!). La tasa es heterogénea; una Gamma previa
 sobre λ produce distribución marginal Gamma-Poisson (binomial negativa), con sobredispersión
 respecto de Poisson. En parametrización forma α y tasa β, (E[λ]=α/β) y (Var(λ)=α/β²).
 Condicionalmente a n compras observadas durante t, la posterior es Gamma(α+n,β+t), por
 conjugación.
 Cálculo. Supón prior λ~Gamma(2,1) (tasa por mes, con parámetro de tasa), y se observan 3
 compras en 2 meses. La posterior es Gamma(5,3), con media 5/3≈1,67 compras por mes. Para
 pronosticar cuatro meses, la media posterior es 4×5/3≈6,67 compras. La incertidumbre predictiva
 sigue siendo importante; no pronostiques que ocurrirán exactamente 6,67 compras. Declara
 parametrización porque Gamma también se expresa con escala; confundir tasa y escala invierte
 resultados.
 Beta-Binomial sirve para una tasa de éxito individual (por ejemplo, probabilidad de compra por
 oportunidad) heterogénea: si p~Beta(a,b) y x de m oportunidades fueron exitosas, posterior
 Beta(a+x,b+m-x), media (a+x)/(a+b+m). No es intercambiable con Gamma-Poisson: uno trata
 proporción de éxitos en oportunidades, el otro tasa de eventos por exposición.
 El modelo Dirichlet de compra repetida combina heterogeneidad en frecuencia y en elección de
 marca bajo supuestos de compra relativamente estacionaria, independencia/mezcla especificada y
 marcas de penetración continua. Ayuda a generar benchmarks para penetración, frecuencia y
 duplicación entre marcas. No predice automáticamente cambios de precio, campañas o innovación
 estructural: primero evalúa si el patrón observado se desvía del benchmark y después investiga
 causas. “Lealtad” aparente puede ser consecuencia de frecuencia, tamaño de marca y
 disponibilidad, no preferencia exclusiva.
 Logit multinomial: de utilidad a probabilidades y trade-offs
 El logit supone que cada alternativa j tiene utilidad sistemática (Vᵢⱼ=β'xᵢⱼ) más un término aleatorio. Si
 errores son independientes Gumbel, (Pᵢⱼ=exp(Vᵢⱼ)/Σₖ exp(Vᵢₖ)). Un coeficiente positivo aumenta
 utilidad y probabilidad, manteniendo otras variables; magnitud depende de unidad y no es
 porcentaje directo. Para atributo binario, el odds ratio condicional es exp(β), pero la variación de
 probabilidad depende de la situación inicial y competidores.
 Cálculo simple. Dos alternativas tienen utilidades V_A=0, V_B=ln(2). Entonces exp(V_A)=1,
 exp(V_B)=2; P_A=1/3 y P_B=2/3. Si un atributo de A sube utilidad en ln(2), su peso exponencial se
 duplica y las probabilidades se recalculan sobre todas las opciones. Este cociente de odds
 mantiene independencia de otras opciones según IIA, supuesto que puede fallar cuando hay
 sustitutos muy similares. Agrega alternativa externa si la opción de no compra existe.
 Si utilidad incluye precio con coeficiente negativo β_p, la DAP marginal por atributo x es β_x/-β_p,
 con unidades monetarias compatibles y supuestos constantes. La elasticidad requiere derivar la
 probabilidad con respecto al precio; no es igual al coeficiente. Heterogeneidad puede estimarse con
 interacciones o logit mixto/clases latentes, pero aumenta complejidad y exige validación. Para
 decidir, simula alternativas plausibles, aplica disponibilidad y costos, verifica predicción fuera de
Examen de Grado UC | materia, preguntas y respuestas 106

[pág. 107]
Marketing - versión clara y reordenada
 muestra y calcula contribución, no solo cuota.
 Bass: adopción acumulada y momento de crecimiento
 Bass representa la probabilidad de adopción en t entre quienes aún no adoptaron, con
 (f(t)/(1-F(t))=p+qF(t)): p es innovación/exposición externa y q imitación/social; F(t) es proporción
 acumulada del mercado potencial m. La cantidad acumulada satisface
 (N(t)=m[1-e^-(p+q)t]/[1+(q/p)e^-(p+q)t]) en la forma continua usual. Adopciones del periodo son
 derivada o diferencia de N(t). El pico de adopción ocurre cuando (F(t*)=(q-p)/(2q)) si q>p; si p≥q, no
 hay pico interior bajo esa expresión.
 Cómo aplicarlo. Identifica mercado potencial y fecha de inicio, ajusta datos de adopción
 acumulada, examina calidad de ajuste y estabilidad, y construye escenarios. p alto implica adopción
 temprana aun con poca base social; q alto implica crecimiento acelerado cuando la base aumenta.
 Un buen ajuste retrospectivo no valida pronóstico si cambian precio, distribución, capacidad, norma
 o categoría. Producto industrial, discontinuidad de medición y difusión por múltiples segmentos
 pueden romper supuestos.
 La gerencia puede usar el modelo para planificar capacidad, distribución, caja y comunicación, no
 solo anunciar una fecha de “despegue”. Sensibiliza m, p y q; contrasta ventas nuevas con
 reemplazo; compara adopción real con disponibilidad y prueba. Difusión describe una trayectoria
 agregada, no prueba que la publicidad causó adopción ni que cada cliente sea innovador o imitador
 en sentido psicológico.
 Conjoint, disposición a pagar y diseño de oferta
 Conjoint presenta perfiles que combinan niveles de atributos y solicita elecciones, rankings o
 ratings. El diseño debe cubrir trade-offs sin combinaciones absurdas, incluir precio y opción externa,
 controlar carga de tarea y muestrear usuarios elegibles. El modelo convierte respuestas en
 utilidades parciales; importancias dependen del rango de niveles mostrado. La DAP de un cambio
 de atributo es la utilidad adicional dividida por el valor absoluto del coeficiente de precio bajo utilidad
 lineal, pero no es constante si existen no linealidades o preferencias heterogéneas.
 Procedimiento de respuesta. (1) Define decisión y competencia. (2) Selecciona atributos
 manipulables, evitando duplicidad. (3) Elige niveles creíbles, incluidos precios reales. (4) Construye
 perfiles con diseño eficiente y tareas manejables. (5) Estima utilidades y heterogeneidad. (6) Simula
 elección para ofertas y escenarios competitivos. (7) Traduce cuota prevista a volumen usando
 mercado disponible/distribución y luego a margen neto. (8) Valida con piloto o datos observados.
 Una simulación de share-of-preference distribuye preferencias entre opciones probadas; una regla
 de primera elección asigna cada persona a su perfil máximo y puede exagerar cambios discretos.
 Ninguna representa demanda total sin calibración. Incluye “no comprar” o un benchmark existente;
 si se elimina la opción externa, el modelo obliga a comprar alguna alternativa y sobreestima
 aceptación. Presenta rango de resultados y sensibilidad a competidores, precio y disponibilidad.
Examen de Grado UC | materia, preguntas y respuestas 107

[pág. 108]
Marketing - versión clara y reordenada
 Gabor-Granger, Van Westendorp y experimentos de precio
 Gabor-Granger pregunta probabilidad de compra a distintos precios para un producto especificado;
 de una curva estimada de proporción de compradores y tamaño de mercado se deriva ingreso o
 contribución esperada. El orden de precios puede anclar respuestas y la intención puede
 sobrestimar compra. Van Westendorp pregunta precios demasiado baratos, baratos, caros y
 demasiado caros; curvas acumuladas ayudan a identificar rango percibido, pero intersecciones no
 equivalen a máximo beneficio. Ambos sirven para explorar, no reemplazan elasticidad observada.
 Experimento de precio asigna precios/ofertas aleatoriamente a grupos comparables en tiendas,
 usuarios o zonas y registra compra real. El efecto promedio es diferencia de resultados entre
 tratamiento y control bajo asignación, cumplimiento y medición comparables. Determina
 previamente duración, unidad de aleatorización, contaminación, costo de grupo control y reglas de
 seguridad. Mide margen total y efectos de referencia, no solo unidades del producto. En retail,
 cambios simultáneos de exhibición, promoción o stock confunden interpretación.
 Causalidad, atribución y pruebas incrementales
 La pregunta causal compara (Y(1)), resultado con intervención, y (Y(0)), resultado sin ella para las
 mismas unidades; solo uno se observa por unidad. Aleatorización hace comparables grupos en
 expectativa y permite estimar efecto promedio, si no hay interferencia relevante, pérdida diferencial
 ni cambios de medición. En experimento A/B asigna usuario, hogar, tienda o zona; define
 exposición y resultado antes de mirar datos, calcula potencia según efecto mínimo relevante y evita
 detener la prueba cuando aparece significancia.
 Si no se puede aleatorizar, diferencias en diferencias compara cambio del tratado con cambio del
 control, bajo tendencias paralelas y ausencia de shocks diferenciales; regresión discontinua explota
 un umbral, bajo continuidad y ausencia de manipulación; variables instrumentales requieren
 instrumento que afecte tratamiento y no resultado por otra ruta. Estas estrategias dependen de
 supuestos y no son etiquetas automáticas de causalidad.
 En marketing, atribución asigna crédito de conversión a canales; incrementalidad estima ventas que
 no habrían ocurrido sin inversión. Último clic es regla contable, no causal. Un holdout puede estimar
 lift de campaña; el valor económico usa margen incremental, costo de medios, descuentos,
 devoluciones, canibalización y valor futuro. Si la campaña aumenta descargas sin incrementar
 compras o retención, el mecanismo de negocio no queda demostrado. Una respuesta distinguida
 declara identificación, incertidumbre, escala temporal y acción siguiente.
 Integrar modelos sin tratar un output como decisión
 Los modelos responden preguntas complementarias. Investigación cualitativa ayuda a descubrir por
 qué; encuesta cuantifica cuánto y a quién; factorial/MDS representa estructura de percepción;
 clustering organiza heterogeneidad; conjoint estima trade-offs declarados; logit modela elecciones;
 experimentos miden impacto causal; Gamma-Poisson/Dirichlet modelan compra repetida; Bass
 organiza difusión. Ningún método resuelve por sí solo estrategia, factibilidad o rentabilidad.
 Antes de recomendar, identifica unidad, horizonte, variable de resultado, contrafactual,
 incertidumbre, supuesto dominante y consecuencia económica. Revisa consistencia de
 moneda/periodo/unidades y no traduzcas automáticamente porcentaje a puntos porcentuales,
 coeficiente a elasticidad o significancia a importancia práctica. Si resultados discrepan, busca
 diferencias de población, medida, periodo, método o constructo. La decisión distingue evidencia,
Examen de Grado UC | materia, preguntas y respuestas 108

[pág. 109]
Marketing - versión clara y reordenada
 interpretación y juicio gerencial. Una recomendación de Distinción hace explícito qué evidencia
 cambiaría la decisión.
Examen de Grado UC | materia, preguntas y respuestas 109

[pág. 110]
Marketing - versión clara y reordenada
 MATERIA RECUPERADA · MARKETING
 ANALYTICS
 Integración de las cuatro clases grabadas y los resúmenes asociados
 1. Del problema de gestión al análisis que realmente permite
 decidir
 Una técnica estadística no es el punto de partida. El orden correcto es: decisión gerencial,
 información faltante, unidad de análisis, población, datos disponibles, método, criterio de validación,
 resultado y acción. Si la empresa quiere decidir a qué clientes ofrecer una promoción, “hacer
 clustering” todavía no define el problema. Primero debe precisar si busca describir heterogeneidad,
 predecir respuesta, estimar causalidad o maximizar contribución. Cada propósito exige evidencia
 distinta.
 La investigación exploratoria ayuda a descubrir variables y mecanismos; la descriptiva estima
 tamaños o asociaciones; la causal exige una comparación capaz de aislar el efecto de una
 intervención. Un mapa perceptual puede revelar proximidades; no demuestra por sí solo que mover
 comunicación causará ventas. Un logit puede predecir elección; no convierte una correlación en
 efecto causal. Un conjoint estima trade-offs bajo su diseño; no garantiza demanda observada si la
 tarea es poco realista, la muestra no representa al mercado o faltan atributos.
 Respuesta de Distinción: antes de calcular, declara qué decisión cambia con el resultado, qué
 identifica el método, qué supuesto sostiene la interpretación y qué dato adicional verificaría
 rentabilidad o causalidad.
 2. Segmentación: construir grupos útiles, no solo grupos
 separados
 Las clases grabadas muestran investigación de mercado, criterios de segmentación, distancia
 euclidiana, k-means y ejemplos con clientes de retail. Una segmentación útil debe ser identificable,
 sustancial, accesible, estable en el horizonte de decisión, diferenciable y accionable. Una alta
 separación matemática no compensa que el segmento sea imposible de reconocer en la operación
 o que no responda de modo distinto.
 Jerárquico y k-means
 El clustering jerárquico aglomerativo parte con cada observación como grupo y fusiona según una
 regla de distancia y enlace. Sirve para explorar estructura y proponer valores de k. K-means parte
 con k centroides, asigna cada observación al centro más cercano, recalcula centros y repite hasta
 estabilizar la suma de cuadrados dentro de los grupos. Su solución depende de escala, valores
 atípicos, inicialización y k. Por eso se estandarizan variables cuando sus unidades no son
 comparables, se prueban varias semillas y se revisa estabilidad.
Examen de Grado UC | materia, preguntas y respuestas 110

[pág. 111]
Marketing - versión clara y reordenada
 La distancia euclidiana d(i,j)=√Σ(xik-xjk)² puede quedar dominada por una variable con rango
 amplio. Estandarizar cambia la pregunta: cada variable pasa a contribuir en unidades de desviación
 estándar. Eso es razonable cuando las dimensiones merecen peso comparable; no debe hacerse
 mecánicamente si el peso económico de una variable es parte del problema.
 Elegir k y validar
 • Codo o reducción de variación interna: busca el punto donde agregar grupos aporta poco.
 • Silhouette u otras medidas internas: comparan cohesión y separación, sin probar utilidad
 comercial.
 • Estabilidad: repite con otras muestras, períodos e inicializaciones.
 • Validez externa: comprueba diferencias en conducta futura, respuesta o valor, evitando usar la
 misma variable para construir y “validar” el segmento sin reconocer circularidad.
 • Accionabilidad: define regla de asignación, propuesta, canal, costo y métrica por segmento.
 3. Factores y mapas perceptuales
 El análisis factorial resume covariación entre atributos mediante dimensiones latentes. Se revisan
 adecuación de la matriz, número de factores, cargas, comunalidades y rotación. Kaiser -retener
 autovalores mayores que uno- es solo una señal; se combina con gráfico de sedimentación, análisis
 paralelo, interpretabilidad y estabilidad. La rotación facilita interpretar, pero no transforma una
 solución débil en una estructura verdadera.
 En un mapa perceptual, las marcas son puntos y los atributos pueden representarse como vectores.
 La dirección de un vector indica dónde aumenta el atributo y su longitud refleja cuán bien queda
 representado en el plano. Cercanía visual sugiere similitud bajo las dimensiones retenidas. Hay que
 mirar porcentaje de varianza explicada y no leer distancias pequeñas como diferencias sustantivas
 si el mapa pierde información.
 4. Preferencias, conjoint y disposición a pagar
 Conjoint descompone la evaluación de perfiles en utilidades parciales. La importancia de un atributo
 depende del rango de niveles incluido; no es una propiedad universal. La disposición a pagar por
 pasar del nivel a al nivel b puede aproximarse como -(Ub-Ua)/βprecio cuando la utilidad del precio
 es lineal y βprecio está expresado por unidad monetaria. El signo, las unidades y el rango son
 esenciales. Luego se simulan alternativas y participaciones de preferencia; para hablar de ventas o
 beneficio se incorporan tamaño, disponibilidad, competencia, costos y canibalización.
 Las imágenes de las clases también conectan k-means, posicionamiento, factores y conjoint. El hilo
 común es separar descripción, predicción, preferencia y efecto causal. Esa separación evita
 recomendar una campaña rentable solo porque aumenta utilidad estimada o confundir un segmento
 estadístico con un mercado atractivo.
Examen de Grado UC | materia, preguntas y respuestas 111

[pág. 112]
Marketing - versión clara y reordenada
 5. Integración con Fundamentos: Zoom y WOM
 El complemento ya incorporado al manual usa la prueba de curso sobre Zoom y WOM para
 practicar investigación, segmentación, adopción, freemium y las cinco dimensiones ciencia,
 sustancia, historia, velocidad y simplicidad. La ampliación presente agrega el puente analítico: una
 hipótesis sobre usuarios o narrativa debe convertirse en variables, diseño, comparación y métrica
 económica. Usuarios registrados no equivalen a clientes pagados; exposición no equivale a
 adopción; crecimiento agregado no identifica causalidad.
Examen de Grado UC | materia, preguntas y respuestas 112

[pág. 113]
Marketing - versión clara y reordenada
 PARTE DE PRÁCTICA - 70 preguntas
 históricas
 Fundamentos de Marketing - 35 preguntas
Examen de Grado UC | materia, preguntas y respuestas 113

[pág. 114]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2018 | pregunta 1
 Convocatoria 1 | página original 253 | Amenaza low-cost y submarca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 1
 por la entrada
 Homero Cisternas, gerente general de Envases del Atlántico (EDELTA), se encontraba preocupado
 de Envasin, un nuevo competidor en la industria de los envases. Envasin había lanzado al mercado una nueva línea
 a precios más bajos que los de EDELTA.
 de envases que se caracterizaban por tener una menor calidad, pero
 un equipo de tres vendedores, había logrado ventas por 1 millón de USD (dólares
 - Envasin, con sólo
 que él
 estadounidenses) durante el último trimestre del año anterior. Homero Cisternas pensaba que la empresa
 debía tomar una decisión de crecimiento: mantenerse en la misma línea de siempre con la tecnología
 dirigía
 avanzada y productos de alta calidad, o entrar en la categoría de productos más económicos.
 la
 EDELTA desarrolla envases flexibles combinando materiales, estructuras y diseños que permiten extender
 final. En la industria
 duración de los productos, proteger su calidad y presentarlos de manera atractiva al consumidor
 productos
 de los envases, EDELTA es reconocida como líder en calidad e innovación tecnológica. Sus líneas de
 (lácteos, mayonesas, ketchup, etc.) y otros de especialidad para
 incluyen envases para la industria de los alimentos
 (detergentes, lavavajillas, etc.). La participación de mercado de EDELTA alcanza el 80%
 la industria de la limpieza
 En
 del mercado total de los envases. Hasta ahora EDELTA no tenía competidores en la industria de los alimentos.
 la industria de la limpieza EDELTA tiene dos competidores con una propuesta de valor similar a la suya.
 durante el
 En la siguiente tabla se indican las ventas y los márgenes brutos del portfolio de productos de EDELTA
 año 2017:
 _ Año 2017
 Ventas [en MM de USD)| Margen Bruto
 Industria Alimentos 75 67%
 Industria Limpieza 25 20%
 de los
 Homero Cisternas tenía dudas de si entrar o no en la categoría de envases económicos para la industria
 el discurso del Presidente del Directorio de la
 alimentos y así competir directamente con Envasin, y recordó
 empresa, justo el mes pasado:
 “Las ventas de EDELTA han crecido a un ritmo de 30% anual durante los últimos cinco años. Un resultado
 en la
 sin precedentes. En los últimos diez años hemos innovado constantemente en el sector de los envases
 industria de los alimentos. Estos éxitos son consecuencia de nuestra liderazgo tecnológico y nuestra
 seguir
 continua inversión en Investigación y Desarrollo. Nuestro futuro depende de continuar en esta línea y
 La misión de EDELTA se
 proporcionando a nuestros clientes envases más sólidos, seguros y eficaces.
 focaliza en ofrecer a nuestros clientes la más alta calidad y los productos más innovadores del mercado.”
 o,
 Para algunos clientes de EDELTA el proceso de compra de envases era muy relevante y de alto involucramient
 a sus necesidades. Según sus datos, Cisternas
 por lo que analizaban las propiedades de cada uno de ellos con respecto
 las decidían
 señalaba que alrededor del 30% de las ventas de envases de sus clientes, en la industria de los alimentos,
 de
 los ingenieros de empaque, los cuales eran bien conscientes de los beneficios que les aportaban los productos
 calidad que suponía utilizar los envases de EDELTA. Cisternas sabía que para el resto de sus clientes era el
 mayor
 jefe de compra quien tomaba la decisión, el cual privilegiaba el precio dado ciertos estándares mínimos,
 de ventas
 La fuerza de ventas de EDELTA era la más formada y especializada de la industria. Si bien esta fuerza
 distribuidores de la empresa.
 no vendía directamente, su rol era estimular la demanda que luego era satisfecha por los
 finales, intentando encontrar soluciones a
 El equipo de ventas pasaba la mayoría de su tiempo con los clientes
 in si y preparando estudios para demostrar lo efectivo que eran los
 problemas complejos, analizando aplicaciones
 bien los
 productos de la empresa en materia técnica. De acuerdo a Cisternas, si la fuerza de ventas entendía
 de sus clientes y lograba demostrarles las ventajas de los envases de mayor calidad que la empresa
 problemas
 producía, entonces serían capaces de hacerles una propuesta de valor más convincente.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 114

[pág. 115]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2018 | pregunta 1
 Convocatoria 1 | página original 254 | Amenaza low-cost y submarca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 año
 EDELTA vende todas sus líneas de envases a través de una red de distribuidores industriales no exclusiva. El
 pasado, su red incluía a 60 distribuidores de los cuales 15 representaban más del 80% de las ventas de la compañía.
 Los distribuidores solían tener en stock una amplia gama de productos y muchos de ellos hacían de punto de venta
 único para todas las necesidades de envasado. Algunos distribuidores de EDELTA comercializaban también los
 productos de Envasin ya que tenían una buena aceptación en el mercado, mientras otros que no lo hacían le habían
 pedida a EDELTA que desarrollara una línea de productos más económica para poder competir.
 En la siguiente tabla se muestran los actuales precios unitarios en USD tanto a los distribuidores como el sugerido
 de reventa, a los clientes finales de ambas empresas, para la industria de alimentos:
 De PRECIO UNITARIO POR ENVASE
 EDELTA ENVASIN
 Costo producción unitario 0,5 , 0,3
 Precio al distibuidor — — 09
 Precio sugerido de reventa al cliente final 2,0 1,7
 a la
 Con la llegada de Envasin y considerando que la industria de los envases para alimentos no presentaba barreras
 entrada, Homero Cisternas se preguntaba cómo hacerlo en caso de ingresar al mercado con una línea de envases
 que
 más económica. Dado que la nueva línea de envases económicos tenía el mismo costo de producción unitario
 Envasin, su propuesta general de precios era mantener el precio a los distribuidores de sus envases premium y para
 el caso de la línea de envases económicos fijar un precio de venta al distribuidor que le permitiera a EDELTA
 del
 mantener el margen de contribución unitario. Además, le sugeriría a los distribuidores un precio de reventa
 cliente final que les permitiera a ellos mantener el actual margen de contribución que tenían
 envase económico al
 con la línea premium de EDELTA.
 PREGUNTAS
 a) De acuerdo con la información entregada, ¿debiera EDELTA responder a la entrada de Envasin con una línea
 de envases más económica y similar a la de esta? Justifique claramente su respuesta desde el punto de vista
 comercial.
 b) De acuerdo con la información proporcionada, ¿cómo puede impactar la decisión de precios propuesta por
 Homero Cisternas a la generación de valor de EDELTA? Fundamente claramente su respuesta desde el punto
 de vista comercial.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 115

[pág. 116]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2021 | pregunta 1
 Convocatoria 1 | página original 329 | Brand equity y arquitectura
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 1
 PREGUNTA Nº1
 Para bien o para mal, Starbucks ha logrado acaparar el mercado mundial de las cafeterías, ofreciendo una
 experiencia que va más allá del producto o la bebida como tal. Nestlé lo sabe, y por ello decidieron desembolsar
 $500 millones de dólares el año 2017 para adquirir la parte mayoritaria de la marca Blue Bottle.
 Blue Bottle es una marca que pertenecía hasta el año 2017 a Bottle Coffee Company. W. James Freeman fundó está
 compañía en los 2000 en Oakland, California, con la idea de tostar el café en pequeñas cantidades y así vender el
 café recién tostado directamente a las casas haciendo home-delivery.
 El café de Blue Bottle se caracteriza por la calidad de sus granos, las técnicas de tostado y las preparaciones refinadas
 que han ido variando la cultura del café en la actualidad. De esta forma, el café pasó de ser visto como un commodity
 a convertirse en un producto de lujo, como pueden ser actualmente el vino o la cerveza artesanal.
 A partir de lo anterior, Blue Bottle Coffee se convirtió en un referente en el mundo del café premium enfocada a
 los fanáticos del café ya sea en sus locales físicos como a su creciente base de clientes que mantienen una suscripción
 online mensual, de la cual reciben tanto las últimas novedades de los productos de la marca como las compras que
 llevan a cabo.
 Blue Bottle Coffee nació para aquellas personas que buscan un tostador artesanal que ofrezca café de mayor calidad,
 de “origen responsable” y con un buen servicio al cliente. La propuesta de valor de la marca busca diferenciarse por
 la calidad del producto, solo se sirve café tostado en las últimas 48 horas para que sea degustado en el punto álgido
 de sabor. Estos valores y posicionamiento le ayudan a diferenciarse de otras grandes cadenas que compiten en su
 mercado.
 La marca ha desarrollado guías, vídeos y cursos sobre cómo comprar, almacenar y preparar un buen café. De esta
 manera se alinean con su propuesta de valor y muestran su amor por el producto y les ayuda a justificar el precio
 más alto a pagar por su producto.
 En el año 2006, W.James Freeman se dio cuenta de la importancia de las tiendas físicas para que el consumidor
 pudiera vivir la experiencia completa del café además de construir un concepto único en el diseño de las tiendas. El
 primer local fue abierto en San Francisco y se diferencian de otras cadenas de café no sólo por la calidad de éste
 sino que también por el diseño de éstos. En lugar de adoptar un modelo estandarizado, sus cafeterías son elegantes,
 modernas y reflejan las características únicas del barrio en el que se encuentran. Esto crea una atmósfera en la que
 uno no solo disfruta de la taza de café, sino que se siente muy bien al mismo tiempo. Asimismo, caminando por la
 calle y a decenas de metros de distancia, los consumidores pueden apreciar claramente como destaca la imagen de
 la Botella Azul haciéndose fácilmente reconocible por todos.
 Las tiendas eran visitadas por consumidores jóvenes exploradores y con estilo que buscaban atributos más allá del
 café. El concepto del café era de calidad superlativa y experiencial debido a la forma en la que se preparaba y servía
 lo que le permitía cobrar entre 2 a 3 veces el valor de un café en Starbucks. Los consumidores buscaban ser parte
 de un grupo especial que tenían en común la inquietud por tener experiencias sensoriales únicas. Se podían apreciar
 en Manhattan y en California filas de consumidores millennials y hípsters esperando por un café especial no
 industrial. Poco a poco diversos inversionistas relacionados con la industria tecnológica como Garrett Camp (Uber),
 Evan Williams (Twitter) y Kevin Systrom (Instagram) comenzaron a invertir en esta empresa para mejorar la
 calidad de los productos, hacerlos más sustentables y expandir los locales en Estados Unidos y Japón.
 El Gerente de Marketing a nivel global del Negocio de Café en Nestlé, Cliff Mc Gregor, miraba con mucha
 detención la evolución de esta marca y veía como las ventas en Estados Unidos de Blue Bottle crecían 5 a 6 veces
 más rápido que las marcas de café de Nestlé: Nescafé y Nespresso. La primera de ellas está orientada a un mercado
 más masivo, el cual consume café instántaneo en polvo y que se caracteriza por tener una producción del tipo más
 industrial. Para estos segmentos de mercado Nestlé tiene las siguientes marcas: Nescafé Fina Selección, Nescafé
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 116

[pág. 117]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2021 | pregunta 1
 Convocatoria 1 | página original 330 | Brand equity y arquitectura
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 Clásico, Nescafé Dolca, Nescafé Decaf y Nescafé Expresso. Por su parte, Nespresso es una marca que está orientada
 al segmento premium, la cual cuenta con locales propios donde se vende un café en granos envasado en cápsulas
 de alta calidad.
 Dado que el nuevo CEO de Nestlé, Mark Schneider, le pidió a todos los Gerentes Globales de Marketing ideas de
 nuevas marcas para ser adquiridas, Cliff presentó Blue Bottle como una tremenda oportunidad de largo plazo dado
 el aporte de capital de marca que Blue Bottle podía hacer al portafolio de marcas de cafés de Nestlé. Finalmente en
 2017, Nestlé adquiere el 68% de la propiedad de la marca Blue Bottle y sus 50 tiendas en U$500 millones. Decide
 que la administración se siga manteniendo totalmente independiente a Nestlé.
 De acuerdo al Gerente de Marketing de Nestlé, Blue Bottle le da una porción más grande del mercado de Estados
 Unidos, el más grande del mundo. Además, ofrece oportunidades para que Nestlé crezca en el café listo para beber
 y café tostado y molido, especialmente a través de suscripciones en línea.
 Se pide responder:
 a) El Gerente de Finanzas aprobó con muchas dificultades la compra de Blue Bottle ya que su evaluación del valor
 de las tiendas físicas y la fábrica no era más de U$50 millones. De acuerdo a sus conocimientos del concepto
 de valor de marca, ¿cuáles serían a su juicio los tres principales argumentos que habría entregado Cliff
 McGregor para que Nestlé invirtiera 10 veces ese valor? Justifique claramente su respuesta.
 b) El mes pasado, el CEO de Nestlé le pide a Cliff Mc Gregor una presentación de cómo ha andado el negocio.
 Cliff con mucho orgullo le muestra los excelentes resultados en ventas, utilidades e indicadores de marca por
 sobre los presupuestados. El CEO le pide a Cliff analizar la opción de que Blue Bottle se transforme en una
 marca del portfolio de Nescafé de manera de capitalizar mejor esos buenos resultados. Considerando alguno de
 los modelos de arquitectura de marca que usted conoce, ¿debería Cliff McGregor apoyar o no la idea del CEO
 de incorporar la marca Blue Bottle al portafolio de la marca Nescafé? Justifique su elección utilizando el modelo
 de arquitectura de marca seleccionado.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 117

[pág. 118]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2023 | pregunta 1
 Convocatoria 1 | página original 377 | Campañas y customer journey
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº1
 Contact Vision (CV) es una empresa fabricante de lentes de contacto que vende a través de un sistema de suscripción
 mensual y un modelo de distribución virtual D2C o Directo al Consumidor. Es una marca que, utilizando
 principalmente el marketing digital, su página web y las redes sociales, y evitando los canales tradicionales (ej.
 Cadenas de ópticas), vende lentes de contactos directamente a los consumidores a un precio más bajo que los
 competidores. A través de esta estrategia, se podía, por ejemplo, comprar su producto directamente vía los anuncios
 de Facebook, que le daban acceso a la página web de CV. De esta manera, a los prospectos que se les hubiera
 prescrito lentes de contacto por parte del oftalmólogo (médico oculista) de su preferencia y que terminaran
 suscribiéndose, recibirían en su casa cada mes las lentes de uso diario y desechables, a un precio de USD 1 (50
 centavos por cada lente). El precio de suscripción mensual era de US30.
 A diferencia de otras marcas de consumo D2C que ofrecían a los consumidores productos de cuidado personal no
 regulados (ej: Dollar Shave Club que vendía hojas de afeitar), CV vende lentes de contacto que están clasificados
 como productos sanitarios por la Food Drug Administration (FDA) estadounidense y, por lo tanto, se rigen por
 estrictas normas de fabricación y prácticas de venta. Toda persona que requiriera anteojos ópticos o lentes de
 contacto para corregir un problema de visión necesitaba una orden médica para poder adquirir estos productos. La
 ruta de compra del consumidor promedio se iniciaba al darse cuenta de que ya no veía bien, lo que gatillaba una
 visita al oftalmólogo, el cuál sugería usar anteojos ópticos o lentes de contacto desechables y emitía una receta.
 Luego, la persona buscaba información, tanto en medios como en sus conocidos, sobre qué opción era la más
 adecuada, así como la marca de óptica más confiable. Eventualmente, visitaba locales y páginas web de ópticas.
 Finalmente elegía dónde registrar la receta y mandaba a fabricar los lentes ópticos o lentes de contacto. En este
 último caso, debía volver a comprar cada 30 días o elegir una suscripción como la que ofrecía CV, dado que era una
 deficiencia visual permanente. La empresa CV contaba con la ventaja de ser la primera que entraba al mercado
 óptico con el modelo D2C, y de haber creado una relación estrecha con clientes finales y oftalmólogos, lo que
 generaba una buena reputación y tráfico a su sitio web.
 CV había sido capaz de construir una marca moderna, diferenciadora y atractiva para distintos segmentos, con una
 alta tasa de fidelización y satisfacción entre sus clientes, gracias a la satisfacción con el producto y el servicio de
 entrega oportuno.
 La publicidad de CV debía llegar a los clientes potenciales de forma efectiva y eficiente, y lograr destacarse en la
 gran cantidad de avisos de ópticas, que utilizaban redes sociales, buscadores y sitios web, además de publicidad
 tradicional, para atraer prospectos. El plan de “medios ganados”1 de CV le significaba una gran cobertura en varias
 redes sociales, blogs y páginas web de medios de comunicación. Por ejemplo, algunos clientes subían sus fotos,
 usando las lentes CV a Facebook, Instagram y Pinterest. CV publicaba anuncios digitales en otras redes sociales
 además de las ya mencionadas, como Snapchat, e invertía en medios offline tradicionales como radio y TV. Además,
 compraba anuncios en Google Adwords y Google Display.
 Cada medio comunicacional ofrecía opciones de cómo comprar y luego monitorear la inversión para la toma de
 decisiones. La métrica más tradicional utilizada en la mayoría de los medios era el costo por mil (CPM), referida al
 costo que el anunciante paga por hacer llegar su anuncio a 1.000 personas del segmento objetivo, y se empleaba
 para medir el alcance o el número de impresiones de un anuncio. El porcentaje de clics (CTR), medía cuantas
 personas hacían clic en un anuncio para visitar el sitio web de la empresa respecto del total de visualizaciones, lo
 que ofrecía una referencia sobre el nivel de atracción generado por el anuncio. Por su parte, el costo de adquisición
 (CPA) medía el costo promedio asociado a la captación de un cliente a través de un medio específico.
 1 Medio Ganado: se refiere a todo medio en que la marca aparezca y se exponga al segmento objetivo, sin que se pague
 por ello. Es una exposición “orgánica” en base a la calidad de sus contenidos asociados a la marca.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 118

[pág. 119]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2023 | pregunta 1
 Convocatoria 1 | página original 378 | Campañas y customer journey
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 Preguntas:
 1. El Gerente de Marketing de CV se encontraba evaluando cómo seguir con las campañas que estaba realizando
 en la plataforma Facebook para lograr aumentar las ventas de suscripciones durante el 2023. Tenía dos opciones:
 (1) destinar $100.000 mensuales a conversión de prospectos1, ó (2) invertir $100.000 mensuales en realizar
 acciones de retargeting2.
 Para tomar la decisión, el gerente de marketing cuenta con la siguiente información sobre campañas recientes:
 Campaña de Prospección en Buscadores vs Campaña de Retargeting
 Campaña de Prospección Campaña de Retargeting
 Inversión $100.000 $100.000
 Impresiones 6.425.703 417.084
 Clics 98.313 21.986
 Consumidores que inician el proceso de suscripción 5.141 3.153
 Consumidores que completan la suscripción 1.285 2.628
 CPM - costo por mil $15,56 $239,76
 CPC - costo por clic $1,02 $4,55
 CPA - costo por adquisición $77,8 $38,05
 CTR - Tasa de clics 1,53% 5,27%
 Tasa de conversión a compra 0,02% 0,63%
 Desde el punto de vista de marketing, y de acuerdo a la información entregada en el enunciado, recomiende qué
 campaña, la de prospección de clientes, la de retargeting o una combinación de ambas, debiera seguir el gerente
 de marketing, si este contara con $100.000 mensuales y su objetivo fuera el de aumentar el número de
 suscripciones en el tiempo.
 2. Por otro lado, uno de los gerentes de CV, proponía asignar más recursos a comprar listas de personas con alta
 probabilidad de necesitar una corrección visual dada su edad, y generar campañas de emails con promociones
 de precios para la suscripción. El Gerente General, en cambio, proponía una campaña masiva de marca en medios
 tradicionales y redes sociales, para así empujar las ventas mensuales de nuevas suscripciones. Desde el punto de
 vista de marketing, evalúe cada una de las propuestas presentadas, de manera de tomar la decisión correcta de
 asignación presupuestaria.
 1 Campaña de Prospección: técnica de marketing cuyo objetivo es impactar a potenciales usuarios que pertenecen a los
 segmentos objetivo y que no han tenido contacto previo con la marca.
 2 Retargeting: es una técnica de marketing digital cuyo objetivo es impactar a los usuarios que previamente han
 interactuado (visitado la web, visto videos, bajado info, etc.) con la marca. La finalidad del retargeting es recordar a los
 usuarios interesados en nuestros productos y marca, que estamos ahí y que tenemos una oferta interesante que ofrecerles.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 119

[pág. 120]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2021 | pregunta 4
 Convocatoria 2 | página original 348 | Canal online y omnicanalidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 1
 PREGUNTA Nº4
 Desde inicios del 2020, diversas empresas han tenido que adaptarse rápidamente a la nueva realidad de
 negocios impuesta por las consecuencias del Covid19. La Pandemia provocó cambios importantes por
 restricciones de circulación y aforo y, por otro lado, el uso más intensivo de medios digitales. Previo a estos
 cambios, la gran mayoría de las empresas tradicionales dependía exclusivamente de canales de venta físicos
 (distribuidores) o su propia cadena de tiendas. En pocos meses, las empresas más ágiles optaron por
 complementar su canal de distribución físico tradicional, incorporándose a un “marketplace” (plataforma
 virtual de comercio de otras empresas; ej. Mercado Libre), delegando su comercio online a una plataforma de
 compras (ej. Cornershop) o desarrollando su propio canal virtual D2C (Directo al consumidor) el que les
 permite conocer más profundamente a sus clientes.
 Si una empresa decide crear su propia unidad de ecommerce, tiene que tener el talento profesional adecuado y
 realizar entre otras tareas, el crear su página web, una app para el móvil, desarrollar campañas de generación
 de tráfico y conversión, así como organizar el proceso logístico de gestión de inventarios en un centro de
 distribución o sus propias tiendas (“Black Stores”, sin atención de público y “Grey Stores”, en caso que sí),
 del despacho a los clientes y, muchas veces, el retorno de los productos por parte del cliente final (logística
 reversa). Estas últimas dos actividades se delegan por lo general, a un operador logístico (ej. Chilexpress, DHL,
 Boosmap).
 Suponga que a mediados de 2021, usted es consultor de la empresa HomeTips, reconocida marca diseñadora
 e importadora de productos con su marca propia de menaje y cocina, ropa de cama, muebles, adornos para el
 hogar y juguetes, ya establecida en el mercado nacional con una cadena de 50 tiendas físicas, distinguidas por
 su buen servicio. En las tiendas de grandes dimensiones, ofrece una gran gama de productos con diseño
 exclusivo, vendedores capacitados para asesorar en decoración o en qué regalar y diversos servicios tales como
 despacho a domicilio, instalación, empaque de regalos y otros. El ticket promedio de compra en sus tiendas se
 ha incrementado a $18.000 durante la pandemia, desde aproximadamente $14.000 en el período previo. Si bien
 las personas llegan a la tienda con una idea, los productos son muy atractivos y generan ventas impulsivas. El
 margen promedio de HomeTips en sus tiendas es aproximadamente un 40% de la venta.
 La pandemia está reduciéndose y gran parte de sus tiendas están en comunas que avanzan en las “Fases” del
 Plan Paso a Paso y el tráfico a las tiendas empieza a aumentar. Un reciente estudio de mercado cuantitativo
 entre clientes de HomeTips, indicaba que más de un 65% quería volver a las tiendas a comprar
 presencialmente, mientras que un 10% quería seguir exclusivamente comprando online las categorías de
 productos de la tienda. El resto, valoraba el poder usar herramientas digitales, pero también extrañaba las
 tiendas y tener la experiencia sensorial total.
 HomeTips no tiene actualmente una operación propia de comercio electrónico. Desde el inicio de la pandemia
 ha logrado aminorar en parte el impacto negativo en las ventas, por la vía de operar con CornerTop, una
 plataforma de compra online y despacho de “última milla”. El comprador final entra a la plataforma/app de
 CornerTop y ahí selecciona la alternativa HomeTips y los productos que desea de ésta, y paga con su tarjeta
 de crédito. Luego, el “comprador” (Shopper) de CornerTop va a la tienda HomeTips, compra lo pedido con
 tarjeta de crédito provista por CornerTop y luego lleva el producto a la casa del comprador final. CornerTop
 le cobra a HomeTips un monto fijo de $5.000 por compra, lo que ha reducido significativamente los márgenes
 de esta última. Los datos de clientes quedan en las bases de CornerTop.
 La empresa ha estado considerando entrar a Mercado Libre, el principal marketplace de América Latina con
 cobertura en varios países, dónde HomeTips tiene también tiendas físicas. Los marketplaces o plataformas de
 comercio se han desarrollado rápidamente en Chile y el mundo (Ej. Mercado Libre, Linio.cl, Barrio Meiggs.cl,
 etc.). Estas plataformas captan por un lado oferentes, incluso competidores entre sí, de diversos productos y
 servicios, exigiéndoles compromiso de inventarios y servicios de postventa. A cambio de un pago por servicios
 y una comisión porcentual sobre la venta, la plataforma ofrece un espacio virtual estándar en su web, apoya
 en el uso de fotos de productos, gestiona el carro de compra y medios de pago, así como los servicios logísticos
 de despacho. A los compradores finales, un marketplace le ofrece en un solo lugar una gran variedad de
 productos, marcas y servicios, confianza en el medio de pago y el despacho a su casa o empresa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 120

[pág. 121]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2021 | pregunta 4
 Convocatoria 2 | página original 349 | Canal online y omnicanalidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 Uno de los Directores de HomeTips, el Sr. A, cree que la pandemia durará pocos meses más y que los recursos
 deben invertirse en fortalecer la cadena de tiendas, refrescar su interior e invertir en publicidad para promover
 el retorno a las tiendas. “Nuestros clientes valoran la experiencia de la tienda y para nosotros es más rentable”,
 planteaba el Sr.A, que además pedía se terminara el contrato con CornerTop.
 En cambio, otra Directora, Sra. Z, planteaba que era el momento para invertir en la propia unidad de
 ecommerce y logística de despacho, terminar el contrato con CornerTop, organizar el retiro en tiendas y
 potenciar la omnicanalidad. “Opino que nuestros clientes han cambiado para siempre. Más que nunca debemos
 conocer profundamente sus preferencias y conductas”, enfatizaba.
 Se pide:
 a) Ante las alternativas posibles planteadas y excluyentes por presupuesto, se le pide a usted identificar
 y desarrollar los dos argumentos principales, que sustentan lo propuesto por cada uno de los
 Directores.
 b) Suponga que HomeTips, fortalece su red de tiendas, desarrolla su operación propia de ecommerce,
 mantiene el vínculo comercial con CornerTop y además, incorpora a Mercado Libre como
 marketplace. ¿Cuáles son los tres principales factores para el éxito de esta estrategia de distribución?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 121

[pág. 122]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | marzo 2011 | pregunta 1
 Convocatoria 1 | página original 58 | Canales y cadena de valor
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº 1
 En un reciente artículo aparecido en la Revista Business Week, se relata un cambio en la política de distribución y
 logística de la cadena de súpermercados Walmart en Estados Unidos, dirigido a sus proveedores “grandes” (ej. Nestlé,
 Procter & Gamble, Unilever, Kraft, etc.), los cuales, sumados, representan el 80% de las compras totales de Walmart.
 Para este tipo de proveedores, la cadena Walmart es el principal cliente y representa aproximadamente entre 25-30% de
 sus ventas totales; los otros clientes son otras cadenas regionales de Estados Unidos tales como Safeway, Kroger, Publix,
 etc. Para los proveedores pequeños y medianos no habría cambios en la política de distribución y logística de Walmart.
 Walmart es la compañía minorista más grande del mundo, con ingresos anuales de aproximadamente US$416 mil
 millones y más de 8.576 tiendas repartidas en EEUU, América Latina, Asia y Europa. Walmart opera a través de los
 formatos de tiendas de descuento, supercentros y súpermercados vecinales. La estrategia comercial que caracteriza a
 Walmart es la de “precios bajos todos los días”, mediante la cual busca tener los precios al consumidor más bajos en
 relación a sus competidores. Hasta ahora, Walmart emplea un sistema logístico1 de transporte de productos similar al de
 sus competidores supermercadistas en Estados Unidos.
 El sistema actual (ver diagrama Nº1) opera a través de la entrega física de los productos en los centros de distribución de
 Walmart, por parte de los proveedores y sus sistemas logísticos de transporte. Desde ahí, es el propio Walmart quien a
 través de su sistema logístico, que incluye más de 6.500 camiones propios y subcontratados, distribuye los productos a
 los locales de su cadena. Por este servicio, Walmart cobra al proveedor un 3% del valor ($) de las compras que Walmart
 le haya hecho a ellos.
 Diagrama Nº1
 L
 O
 P C
 R A
 O L
 V E
 Centro de
 E Distribución S
 E
 D W
 O A
 R L
 E M
 S A
 R
 T
 1 Sistema Logístico de Transporte: comprende la gestión de stocks y transporte físico de los productos terminados mediante flotas de
 transporte propio o contratados a terceros (“transportistas”).
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 122

[pág. 123]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | marzo 2011 | pregunta 1
 Convocatoria 1 | página original 59 | Canales y cadena de valor
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 El nuevo sistema definido por Walmart sustituiría el sistema logístico del proveedor por su propio sistema. Es decir,
 Walmart se preocuparía de retirar los productos desde las bodegas/fábricas de los proveedores, los llevaría a sus centros
 de distribución, y luego los despacharía como siempre, hacia sus locales (ver diagrama Nº2). Por este servicio completo,
 Walmart también le cobrará al proveedor un porcentaje que corresponderá al 6% del valor ($) de las compras que
 Walmart le haya hecho a ellos. En caso de implementar este nuevo sistema, Walmart lo haría únicamente con sus
 grandes proveedores.
 Diagrama Nº2
 L
 O
 P C
 R A
 O L
 V E
 Centro de
 E S
 Distribución
 E
 D W
 O A
 R L
 E M
 S A
 R
 T
 Según Kelly Abney, Vicepresidente de Transporte de Walmart, “el nuevo sistema permitirá que nuestros proveedores se
 focalicen en los que saben hacer mejor: fabricación y desarrollo de productos de excelencia”
 A Ud. se le pide responder lo siguiente:
 1. Desde el punto de vista comercial, ¿por qué Walmart estaría analizando la alternativa o decisión de ser ella la que se
 encargue del transporte de los productos desde las bodegas de sus proveedores hasta sus centros de distribución?
 ¿cuáles son los principales beneficios potenciales para Walmart de esta medida? Fundamente su respuesta.
 2. ¿Cuáles son las principales consecuencias negativas para los proveedores que aceptasen la propuesta de Walmart?
 Fundamente su respuesta.
 3. Si Walmart tomara esta decisión, ¿Cuál sería la principal consecuencia negativa para las cadenas de supermercados
 que compiten con Walmart? Fundamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 123

[pág. 124]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2013 | pregunta 1
 Convocatoria 2 | página original 127 | Capital y posicionamiento de marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº 1
 En 1960, el etíope Abebe Bikila ganó la maratón de los Juegos Olímpicos de Roma, corriendo totalmente descalzo.
 Sin embargo, la industria de zapatillas piensa que sí puede agregar valor y cientos de miles de clientes así lo confirman.
 El mercado mundial de zapatillas/zapatos deportivos para el 2012, se estimaba en 67 billones de dólares (USD), de los
 cuales Nike tuvo una participación de mercado del 20% con 13,4 billones de USD. Le siguió Adidas (incluyendo la
 marca Reebok que es de su propiedad) con 9,1 billones de USD, lo que representa un 13,6% del mercado.
 No obstante lo anterior, la situación del mercado específico de zapatillas para correr (running) es diferente. En este
 caso, Nike es el claro líder con una participación superior al 40% a nivel mundial y de 55% en el mercado más
 relevante que es el de Estados Unidos, mientras que Adidas sólo llega al 4,5% en este último mercado y cerca del 7% a
 nivel mundial. Le siguen a Nike, aunque a larga distancia, la marca ASICS (Japón) y Brooks, y luego un fragmentado
 conjunto de marcas, en que Adidas es la sexta en ventas.
 Nike ha sido el líder desde que hace 25 años exactamente, lanzara su conocido slogan “Just do it”, que apelaba a la
 emocionalidad tras la decisión de hacer deportes y en particular el deporte de correr (running), y que se transformó en
 una de las frases más recordadas en el mundo publicitario. Los rostros de los deportistas más famosos como Tiger
 Woods en Golf, Messi y el Barcelona en Fútbol, Lebron James y Koby Byant en Basketball, Roger Federer, Rafael
 Nadal, Maria Sharapova en Tennis, y Michael Schumacher en Fórmula Uno, son algunos de los deportistas top que
 representan a Nike en la publicidad global. Sin embargo, en el caso de las zapatillas de correr, Nike sólo usa rostros
 anónimos de corredores aficionados de ambos sexos. La innovación en atributos de productos es relevante para Nike,
 pero no tanto como su inversión en imagen de marca.
 El 2013 Nike está usando en su publicidad el slogan “haremos que valga la pena” (“We will make it count”) llamando
 a comprometerse a correr (ver aviso que se adjunta a continuación).
 Adidas por su parte, ha dicho que busca alcanzar a Nike en participación de mercado en unidades vendidas y superar en
 participación en valor a su rival en este mercado de las zapatillas de correr (running). Desde hace ya tres años, Adidas
 ha concentrado sus recursos en la investigación tecnológica para desarrollar nuevos materiales y tecnologías para
 innovar en modelos de zapatillas. Un gran logro fue la Adidas ONE, que incluía un chip inteligente que reconocía la
 superficie sobre la que se corría y adaptaba la tensión de resortes internos para dar el mejor desempeño. Esta zapatilla
 tenía un premium de precio de 20% sobre Nike. A inicios de este año 2013, Adidas lanzó su modelo “BOOST” en
 alianza con las multinacional química alemana BASF, la cual desarrolló una innovadora planta para las zapatillas
 compuesta por cientos de pequeñas esferas de poliuretano que dan un gran rebote. En su publicidad, Adidas enfatiza
 los atributos de sus productos y el beneficio técnico que generan. El protagonista es el producto (ver aviso que se
 adjunta en la siguiente página).
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 124

[pág. 125]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2013 | pregunta 1
 Convocatoria 2 | página original 128 | Capital y posicionamiento de marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 Durante el mes de agosto de 2013, Adidas lanzará su nuevo modelo “SPRINGBLADE” (foto de la derecha en el aviso
 que está encima de este párrafo), promocionado como la gran revolución tecnológica, el incluir una suela con 16
 pequeños resortes en forma de hojas anguladas que aceleran el rebote al correr, tal como la garra de un cheetah o
 guepardo (el animal más rápido del mundo).
 Los precios y canales de distribución de ambas compañías son similares para su portfolio de productos de running.
 Un analista de la industria deportiva decía que: “Adidas, a través de sus innovaciones tecnológicas y las campañas
 comunicacionales que enfatizaban dichas innovaciones, estaba en el camino correcto para alcanzar en participación de
 mercado a Nike en el mundo del running, es decir, de las zapatillas para correr.”
 PREGUNTAS
 1) Considerando la información del enunciado y utilizando conceptos de marketing, señale, en forma breve y precisa,
 los tres principales argumentos que Ud. daría en contra de la opinión del analista de la industria deportiva.
 2) Es indudable que ambas marcas han alcanzado la condición de marcas valiosas en el mundo del running. ¿En qué se
 diferencia la forma como Nike crea valor a su marca respecto de la forma en que lo hace Adidas? Fundamente su
 respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 125

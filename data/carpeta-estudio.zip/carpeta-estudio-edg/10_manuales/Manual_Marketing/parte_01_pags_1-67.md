# Manual de Marketing · parte 1 (páginas 1-67)

Fuente: 01_MANUAL_ULTIMATE_MARKETING_EDG_2027_V2_FORMULAS_Y_METRICAS_CLARAS

[pág. 1]
Marketing - versión clara y reordenada
 Marketing manual definitivo
 V2
 Fórmulas y métricas visuales, materia desde cero, 70 preguntas
 históricas y respuestas completas
 Examen de Grado de Ingeniería Comercial UC · preparación 2027
 Esta versión conserva los documentos anteriores y corrige la legibilidad y el orden. La estructura de
 estudio es materia → preguntas → respuestas.
Examen de Grado UC | materia, preguntas y respuestas 1

[pág. 2]
Marketing - versión clara y reordenada
 Índice con páginas del documento
 ATLAS VISUAL - FÓRMULAS, MÉTRICAS Y NÚMEROS 16
 1. Mercado, crecimiento y economía de la oferta . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 17
 2. Clientes, embudo, retención y valor de vida . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 20
 3. Precio, elasticidad y experimentación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 23
 4. Investigación, muestra e inferencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 25
 5. Conjoint, elección y disposición a pagar . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 28
 6. Compra repetida y difusión . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 30
 Marketing · preparación del Examen de Grado UC 2027 31
 Cómo estudiar con este libro . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 31
 Mapa de la materia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 32
 PARTE I - FUNDAMENTOS DE MARKETING 33
 1. Marketing, orientación al mercado y economía de valor . . . . . . . . . . . . . . . . . . . . . . . . . . . . 33
 Qué es marketing: crear, entregar y capturar valor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 33
 Integración de Fundamentos: resolver casos sin saltar al framework . . . . . . . . . . . . . . . . . . . . . . . . . 34
 Estrategia competitiva y modelo de negocio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 35
 Marketing participa en toda la propuesta . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 36
 Ventaja competitiva y coherencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 37
 Centralidad del cliente y CRM . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 37
 Modelo de negocio y plan . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 38
 Medidas básicas y crecimiento . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 38
 2. Conducta del consumidor y decisión de compra . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 38
 Cliente, conducta de compra y experiencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 38
 Conducta del consumidor: mecanismos que compiten . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 39
Examen de Grado UC | materia, preguntas y respuestas 2

[pág. 3]
Marketing - versión clara y reordenada
 Necesidad, motivación y contexto . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 40
 Percepción, actitud y conducta . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 40
 Reglas compensatorias y no compensatorias . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 41
 3. Segmentación, targeting y posicionamiento . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 41
 Segmentación, targeting y posicionamiento . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 41
 Tres niveles de segmentación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 42
 Posicionamiento, paridad y diferencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 43
 De análisis a recomendación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 43
 4. Centralidad del cliente y gestión de la relación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 43
 Centralidad del cliente y gestión de la experiencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 43
 5. Shopper marketing y recorrido de compra . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 44
 Consumidor, comprador y retailer tienen problemas distintos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 44
 La misión de compra modifica la importancia de los atributos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 44
 Árbol de decisión y experiencia de compra . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 45
 Descomponer el crecimiento con PITA . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 45
 Omnicanalidad y respuesta de caso . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 46
 6. Marca, arquitectura y portafolio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 46
 Marca, producto, portafolio e innovación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 46
 Marca, portafolio y crecimiento: análisis de trade-offs . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 47
 Identificar, significar y generar una respuesta diferente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 48
 Identidad, imagen y posicionamiento . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 48
 Arquitectura: compartir confianza y compartir riesgo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 49
 Valorar la marca y medir su contribución . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 49
 Portafolio, complejidad y canibalización . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 50
 Ejercicio adicional: aislar el efecto de la marca . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 50
 7. Innovación, prueba y repetición . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 51
 La idea inicial debe convertirse en una hipótesis . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 51
Examen de Grado UC | materia, preguntas y respuestas 3

[pág. 4]
Marketing - versión clara y reordenada
 Concepto, producto y promesa son pruebas distintas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 51
 Separar prueba y repetición . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 52
 Ciclo de vida y difusión requieren juicio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 52
 Defender un lanzamiento en el examen . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 52
 8. Marketing industrial y decisiones B2B . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 53
 Por qué cambia el problema comercial . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 53
 El centro de compra y sus criterios . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 53
 Proceso y propuesta de valor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 53
 Segmentación y relación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 54
 Recomendación completa . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 54
 9. Servicios, calidad y recuperación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 55
 Qué hace particular a un servicio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 55
 Tres relaciones deben sostener la misma promesa . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 55
 Las cinco brechas y su diagnóstico . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 55
 Calidad percibida y zona de tolerancia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 56
 Capacidad, variabilidad y recuperación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 56
 Relacionar calidad con economía . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 57
 Caso adicional de diagnóstico de servicio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 57
 10. Precio, contribución y modelos de ingreso . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 58
 Precio: convertir valor en ingresos sostenibles . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 58
 Precio y promociones: procedimiento completo para el grado . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 59
 El precio observado no es la disposición a pagar . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 60
 Cinco perspectivas para decidir . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 60
 Elasticidad, ingresos y contribución . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 60
 Diseñar la forma de cobro . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 61
 Psicología y estrategia sin convertirlas en leyes . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 61
 Corrección puntual de las afirmaciones legales del apunte . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 62
Examen de Grado UC | materia, preguntas y respuestas 4

[pág. 5]
Marketing - versión clara y reordenada
 11. Canales, retail y fuerza de ventas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 62
 Canales, ventas y distribución . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 62
 Las funciones del canal no desaparecen . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 62
 Cobertura, push y pull . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 63
 Retail: elegir una promesa viable . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 63
 Organización de ventas y gestión de cuentas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 63
 Calcular dotación sin perder unidades . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 64
 Incentivos y efectos no deseados . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 64
 12. Comunicación, planificación y evaluación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 65
 Comunicación, plan de marketing y medición . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 65
 PARTE II - MARKETING ANALYTICS 66
 Comunicación: elegir el mecanismo antes que el medio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 66
 Del mensaje a una consecuencia comprobable . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 67
 Diseñar un brief y una campaña . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 68
 Alcance, frecuencia y embudos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 68
 Presupuesto y presencia temporal . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 69
 13. Marketing digital y automatización . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 69
 Digital, automatización y ética como decisiones de marketing . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 69
 Digital e inteligencia artificial con criterio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 71
 14. Ética y responsabilidad comercial . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 71
 Ética, incentivos y responsabilidad social . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 71
 Cómo cerrar una respuesta . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 72
 15. Lecturas y comprensión profunda del cliente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 72
 Lecturas de Fundamentos: mecanismos y aplicación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 72
 16. Aplicación integral de Fundamentos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 74
 A. Fundamentos de Marketing . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 74
 Profundización adicional de Marketing Analytics . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 77
Examen de Grado UC | materia, preguntas y respuestas 5

[pág. 6]
Marketing - versión clara y reordenada
 17. Decisiones de investigación y diseño . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 77
 De la pregunta de negocio al diseño de investigación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 77
 Diseño de investigación: de una pregunta a datos defendibles . . . . . . . . . . . . . . . . . . . . . . . . . . . . 78
 Marketing Analytics como sistema de decisión . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 79
 18. Valor de información y elección bajo incertidumbre . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 79
 19. Medición, muestreo e inferencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 80
 Muestreo e inferencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 80
 Estadística aplicada: lectura de resultados con criterio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 80
 Estadística que faltaba entre la pregunta y la decisión . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 81
 20. ANOVA y comparación de grupos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 82
 ANOVA y comparación de grupos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 82
 21. Segmentación analítica y representación de mercado . . . . . . . . . . . . . . . . . . . . . . . . . . . . 82
 Segmentación analítica: k-medias . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 82
 Segmentación y representación de mercado en profundidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 83
 RFM, clustering jerárquico y Assessor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 84
 22. Factorial, MDS y medición de percepción . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 84
 Análisis factorial, MDS y preferencias . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 84
 Medición de marca y mapas perceptuales . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 85
 23. Métricas de compra, heterogeneidad y repetición . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 85
 Compra repetida y modelos de heterogeneidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 85
 Modelos probabilísticos de compra y elección: conexiones . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 86
 Métricas de mercado y compra repetida . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 87
 Gamma-Poisson: derivación y ejercicio completo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 87
 Dirichlet como modelo de compra de categoría y marcas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 88
 24. Logit, elección y datos de panel . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 88
 Logit y modelos de elección . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 88
 Panel y logit: ejecutar cálculos y reconocer restricciones . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 89
Examen de Grado UC | materia, preguntas y respuestas 6

[pág. 7]
Marketing - versión clara y reordenada
 25. Difusión, Bass y dinámica del mercado . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 90
 Difusión de Bass . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 90
 Bass: derivación y decisiones de adopción . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 91
 26. Conjoint, atributos, DAP y simulación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 91
 Conjoint, DAP y simulación de ofertas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 91
 Conjoint: diseño, estimación y límites en profundidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 92
 Conjoint y difusión: cálculos adicionales de evaluaciones del curso . . . . . . . . . . . . . . . . . . . . . . . . . . 92
 27. Investigación de precios y lanzamiento . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 94
 Investigación de precios: Gabor-Granger y Van Westendorp . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 94
 Medir intención, adopción y comportamiento real . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 95
 28. Causalidad y experimentación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 95
 Causalidad y experimentación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 95
 29. Texto y análisis cualitativo digital . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 96
 Texto y analítica cualitativa de datos digitales . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 96
 30. Extensiones cuantitativas y correcciones de resúmenes . . . . . . . . . . . . . . . . . . . . . . . . . . . 96
 Panel, repetición y denominadores . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 96
 Bass generalizado: ecuación, mecanismo y cálculo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 97
 Norton-Bass: evitar doble conteo entre generaciones . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 98
 Tres funciones de demanda y una regla de simulación que exige escala . . . . . . . . . . . . . . . . . . . . . . . 98
 31. Laboratorios y auditoría de pautas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 99
 Laboratorio cuantitativo integrado . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 99
 Taller de verificación: resolver y auditar una pauta cuantitativa . . . . . . . . . . . . . . . . . . . . . . . . . . . 100
 32. Integración y redacción de una respuesta completa . . . . . . . . . . . . . . . . . . . . . . . . . . . . 103
 Cómo redactar una respuesta de Analytics de Distinción . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 103
 Examen de grado: construcción de la respuesta . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 103
 B. Marketing Analytics . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 103
Examen de Grado UC | materia, preguntas y respuestas 7

[pág. 8]
Marketing - versión clara y reordenada
 MATERIA RECUPERADA · MARKETING ANALYTICS 110
 1. Del problema de gestión al análisis que realmente permite decidir . . . . . . . . . . . . . . . . . . . . . 110
 2. Segmentación: construir grupos útiles, no solo grupos separados . . . . . . . . . . . . . . . . . . . . . . 110
 Jerárquico y k-means . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 110
 Elegir k y validar . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 111
 3. Factores y mapas perceptuales . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 111
 4. Preferencias, conjoint y disposición a pagar . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 111
 5. Integración con Fundamentos: Zoom y WOM . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 112
 PARTE DE PRÁCTICA - 70 preguntas históricas 113
 Fundamentos de Marketing - 35 preguntas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 113
 enero 2018 - pregunta 1 - Amenaza low-cost y submarca . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 114
 enero 2021 - pregunta 1 - Brand equity y arquitectura . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 116
 enero 2023 - pregunta 1 - Campañas y customer journey . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 118
 agosto 2021 - pregunta 4 - Canal online y omnicanalidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 120
 marzo 2011 - pregunta 1 - Canales y cadena de valor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 122
 agosto 2013 - pregunta 1 - Capital y posicionamiento de marca . . . . . . . . . . . . . . . . . . . . . . . . . . . 124
 agosto 2020 - pregunta 1 - Crecimiento de categoría y canales . . . . . . . . . . . . . . . . . . . . . . . . . . . 126
 enero 2020 - pregunta 1 - Crecimiento, canal y marca . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 128
 enero 2019 - pregunta 1 - Crecimiento, premium y ecosistema . . . . . . . . . . . . . . . . . . . . . . . . . . . 130
 enero 2012 - pregunta 1 - Entrada y difusión de nueva categoría . . . . . . . . . . . . . . . . . . . . . . . . . . 132
 enero 2022 - pregunta 1 - Extensión de línea/marca . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 134
 agosto 2022 - pregunta 1 - Formato low-cost y marcas propias . . . . . . . . . . . . . . . . . . . . . . . . . . . 136
 agosto 2017 - pregunta 1 - Guerra de precios y diferenciación . . . . . . . . . . . . . . . . . . . . . . . . . . . . 138
 agosto 2023 - pregunta 1 - Guerra de precios y posición . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 140
 agosto 2010 - pregunta 1 - Investigación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 142
 agosto 2024 - pregunta 3 - Investigación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 144
 enero 2013 - pregunta 1 - Marcas propias y posicionamiento . . . . . . . . . . . . . . . . . . . . . . . . . . . . 146
Examen de Grado UC | materia, preguntas y respuestas 8

[pág. 9]
Marketing - versión clara y reordenada
 enero 2024 - pregunta 1 - Marketplace y estrategia de marca . . . . . . . . . . . . . . . . . . . . . . . . . . . . 148
 enero 2014 - pregunta 1 - Nuevo producto, posicionamiento y canibalización . . . . . . . . . . . . . . . . . . . . 150
 agosto 2018 - pregunta 1 - Plataforma de dos clientes y precio . . . . . . . . . . . . . . . . . . . . . . . . . . . 152
 agosto 2015 - pregunta 1 - Plataforma de dos lados y surge pricing . . . . . . . . . . . . . . . . . . . . . . . . . 154
 agosto 2011 - pregunta 1 - Precio, difusión y canales . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 156
 agosto 2019 - pregunta 1 - Precio, servicio y modelo de negocio . . . . . . . . . . . . . . . . . . . . . . . . . . 158
 enero 2016 - pregunta 1 - Premiumización y prueba de producto . . . . . . . . . . . . . . . . . . . . . . . . . . 160
 agosto 2012 - pregunta 1 - Promociones y plataforma de descuentos . . . . . . . . . . . . . . . . . . . . . . . . 162
 enero 2015 - pregunta 1 - Respuesta competitiva y esencia de marca . . . . . . . . . . . . . . . . . . . . . . . . 164
 agosto 2014 - pregunta 1 - Respuesta de marketing y regulación . . . . . . . . . . . . . . . . . . . . . . . . . . 166
 enero 2017 - pregunta 1 - Segmentos, crecimiento y precio-calidad . . . . . . . . . . . . . . . . . . . . . . . . . 168
 agosto 2016 - pregunta 1 - Servicio, precio y canal . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 170
 enero 2025 - pregunta 4 - Valor, orientación al mercado y coherencia comercial . . . . . . . . . . . . . . . . . . 174
 marzo 2009 - pregunta 1 - Valor/cliente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 176
 agosto 2009 - pregunta 1 - Valor/cliente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 178
 marzo 2010 - pregunta 1 - Valor/cliente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 180
 agosto 2025 - pregunta 1 - Valor/cliente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 182
 enero 2026 - pregunta 3 - Valor/cliente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 184
 Marketing Analytics - 35 preguntas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 186
 enero 2012 - pregunta 6 - ANOVA y análisis factorial . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 187
 enero 2013 - pregunta 5 - ANOVA, clustering y cuestionario . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 191
 agosto 2011 - pregunta 5 - Calidad de clustering . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 193
 enero 2014 - pregunta 5 - Causalidad publicitaria . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 195
 agosto 2023 - pregunta 5 - Conjoint por segmento . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 196
 enero 2021 - pregunta 5 - Conjoint versus datos históricos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 198
 agosto 2017 - pregunta 5 - Conjoint y DAP . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 199
 agosto 2021 - pregunta 2 - Conjoint y DAP . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 201
Examen de Grado UC | materia, preguntas y respuestas 9

[pág. 10]
Marketing - versión clara y reordenada
 enero 2019 - pregunta 5 - Conjoint y diseño . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 203
 agosto 2020 - pregunta 6 - Conjoint y diseño de oferta . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 204
 enero 2025 - pregunta 6 - Conjoint y disposición a pagar . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 205
 agosto 2019 - pregunta 5 - Difusión de Bass . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 207
 agosto 2012 - pregunta 5 - Diseño muestral . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 209
 marzo 2011 - pregunta 5 - Encuesta y muestreo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 211
 agosto 2015 - pregunta 5 - Factores, segmentos y targeting . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 213
 agosto 2013 - pregunta 6 - Factorial y segmentación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 215
 marzo 2009 - pregunta 5 - Investigación/datos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 217
 agosto 2009 - pregunta 5 - Investigación/datos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 219
 marzo 2010 - pregunta 5 - Investigación/datos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 221
 agosto 2010 - pregunta 5 - Investigación/datos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 223
 agosto 2024 - pregunta 5 - Investigación/datos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 225
 agosto 2025 - pregunta 5 - Investigación/datos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 226
 enero 2024 - pregunta 5 - K-means y promociones . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 228
 enero 2026 - pregunta 6 - Logit multinomial y rentabilidad de promoción . . . . . . . . . . . . . . . . . . . . . . 229
 enero 2020 - pregunta 5 - Logit y heterogeneidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 231
 enero 2018 - pregunta 5 - Mapa perceptual . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 233
 enero 2022 - pregunta 5 - Mapa perceptual dinámico . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 235
 enero 2017 - pregunta 5 - Modelo Assessor/pretest . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 236
 agosto 2022 - pregunta 5 - Modelo de elección de marca . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 238
 enero 2015 - pregunta 5 - Mystery shopper y diseño exploratorio . . . . . . . . . . . . . . . . . . . . . . . . . . 240
 agosto 2014 - pregunta 5 - Necesidad y diseño de investigación . . . . . . . . . . . . . . . . . . . . . . . . . . . 242
 agosto 2018 - pregunta 5 - Panel, frecuencia y Assessor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 243
 enero 2016 - pregunta 5 - Participación y conjoint . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 245
 agosto 2016 - pregunta 5 - Problema gerencial e investigación . . . . . . . . . . . . . . . . . . . . . . . . . . . 247
 enero 2023 - pregunta 5 - Segmentación en modelo de elección . . . . . . . . . . . . . . . . . . . . . . . . . . 251
Examen de Grado UC | materia, preguntas y respuestas 10

[pág. 11]
Marketing - versión clara y reordenada
 PREGUNTAS ADICIONALES · MARKETING 253
 Pregunta M-U1 · Segmentación de clientes . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 253
 Pregunta M-U2 · Factores y mapa perceptual . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 253
 Pregunta M-U3 · Conjoint y precio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 253
 Pregunta M-U4 · Zoom, freemium y causalidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 253
 RESPUESTAS - soluciones completas 254
 Fundamentos de Marketing . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 254
 enero 2018 - pregunta 1 - Amenaza low-cost y submarca . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 254
 enero 2021 - pregunta 1 - Brand equity y arquitectura . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 255
 enero 2023 - pregunta 1 - Campañas y customer journey . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 256
 agosto 2021 - pregunta 4 - Canal online y omnicanalidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 257
 marzo 2011 - pregunta 1 - Canales y cadena de valor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 259
 agosto 2013 - pregunta 1 - Capital y posicionamiento de marca . . . . . . . . . . . . . . . . . . . . . . . . . . . 260
 agosto 2020 - pregunta 1 - Crecimiento de categoría y canales . . . . . . . . . . . . . . . . . . . . . . . . . . . 261
 enero 2020 - pregunta 1 - Crecimiento, canal y marca . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 262
 enero 2019 - pregunta 1 - Crecimiento, premium y ecosistema . . . . . . . . . . . . . . . . . . . . . . . . . . . 263
 enero 2012 - pregunta 1 - Entrada y difusión de nueva categoría . . . . . . . . . . . . . . . . . . . . . . . . . . 264
 enero 2022 - pregunta 1 - Extensión de línea/marca . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 265
 agosto 2022 - pregunta 1 - Formato low-cost y marcas propias . . . . . . . . . . . . . . . . . . . . . . . . . . . 267
 agosto 2017 - pregunta 1 - Guerra de precios y diferenciación . . . . . . . . . . . . . . . . . . . . . . . . . . . . 268
 agosto 2023 - pregunta 1 - Guerra de precios y posición . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 269
 agosto 2010 - pregunta 1 - Investigación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 271
 agosto 2024 - pregunta 3 - Investigación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 272
 enero 2013 - pregunta 1 - Marcas propias y posicionamiento . . . . . . . . . . . . . . . . . . . . . . . . . . . . 273
 enero 2024 - pregunta 1 - Marketplace y estrategia de marca . . . . . . . . . . . . . . . . . . . . . . . . . . . . 274
 enero 2014 - pregunta 1 - Nuevo producto, posicionamiento y canibalización . . . . . . . . . . . . . . . . . . . . 276
 agosto 2018 - pregunta 1 - Plataforma de dos clientes y precio . . . . . . . . . . . . . . . . . . . . . . . . . . . 277
Examen de Grado UC | materia, preguntas y respuestas 11

[pág. 12]
Marketing - versión clara y reordenada
 agosto 2015 - pregunta 1 - Plataforma de dos lados y surge pricing . . . . . . . . . . . . . . . . . . . . . . . . . 278
 agosto 2011 - pregunta 1 - Precio, difusión y canales . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 279
 agosto 2019 - pregunta 1 - Precio, servicio y modelo de negocio . . . . . . . . . . . . . . . . . . . . . . . . . . 280
 enero 2016 - pregunta 1 - Premiumización y prueba de producto . . . . . . . . . . . . . . . . . . . . . . . . . . 281
 agosto 2012 - pregunta 1 - Promociones y plataforma de descuentos . . . . . . . . . . . . . . . . . . . . . . . . 282
 enero 2015 - pregunta 1 - Respuesta competitiva y esencia de marca . . . . . . . . . . . . . . . . . . . . . . . . 283
 agosto 2014 - pregunta 1 - Respuesta de marketing y regulación . . . . . . . . . . . . . . . . . . . . . . . . . . 284
 enero 2017 - pregunta 1 - Segmentos, crecimiento y precio-calidad . . . . . . . . . . . . . . . . . . . . . . . . . 285
 agosto 2016 - pregunta 1 - Servicio, precio y canal . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 287
 enero 2025 - pregunta 4 - Valor, orientación al mercado y coherencia comercial . . . . . . . . . . . . . . . . . . 288
 marzo 2009 - pregunta 1 - Valor/cliente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 289
 agosto 2009 - pregunta 1 - Valor/cliente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 291
 marzo 2010 - pregunta 1 - Valor/cliente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 292
 agosto 2025 - pregunta 1 - Valor/cliente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 293
 enero 2026 - pregunta 3 - Valor/cliente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 295
 Marketing Analytics . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 297
 enero 2012 - pregunta 6 - ANOVA y análisis factorial . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 297
 enero 2013 - pregunta 5 - ANOVA, clustering y cuestionario . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 298
 agosto 2011 - pregunta 5 - Calidad de clustering . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 299
 enero 2014 - pregunta 5 - Causalidad publicitaria . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 300
 agosto 2023 - pregunta 5 - Conjoint por segmento . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 301
 enero 2021 - pregunta 5 - Conjoint versus datos históricos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 302
 agosto 2017 - pregunta 5 - Conjoint y DAP . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 303
 agosto 2021 - pregunta 2 - Conjoint y DAP . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 304
 enero 2019 - pregunta 5 - Conjoint y diseño . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 305
 agosto 2020 - pregunta 6 - Conjoint y diseño de oferta . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 306
 enero 2025 - pregunta 6 - Conjoint y disposición a pagar . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 307
Examen de Grado UC | materia, preguntas y respuestas 12

[pág. 13]
Marketing - versión clara y reordenada
 agosto 2019 - pregunta 5 - Difusión de Bass . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 309
 agosto 2012 - pregunta 5 - Diseño muestral . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 310
 marzo 2011 - pregunta 5 - Encuesta y muestreo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 311
 agosto 2015 - pregunta 5 - Factores, segmentos y targeting . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 312
 agosto 2013 - pregunta 6 - Factorial y segmentación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 312
 marzo 2009 - pregunta 5 - Investigación/datos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 313
 agosto 2009 - pregunta 5 - Investigación/datos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 314
 marzo 2010 - pregunta 5 - Investigación/datos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 315
 agosto 2010 - pregunta 5 - Investigación/datos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 316
 agosto 2024 - pregunta 5 - Investigación/datos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 317
 agosto 2025 - pregunta 5 - Investigación/datos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 318
 enero 2024 - pregunta 5 - K-means y promociones . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 319
 enero 2026 - pregunta 6 - Logit multinomial y rentabilidad de promoción . . . . . . . . . . . . . . . . . . . . . . 321
 enero 2020 - pregunta 5 - Logit y heterogeneidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 322
 enero 2018 - pregunta 5 - Mapa perceptual . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 323
 enero 2022 - pregunta 5 - Mapa perceptual dinámico . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 324
 enero 2017 - pregunta 5 - Modelo Assessor/pretest . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 325
 agosto 2022 - pregunta 5 - Modelo de elección de marca . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 326
 enero 2015 - pregunta 5 - Mystery shopper y diseño exploratorio . . . . . . . . . . . . . . . . . . . . . . . . . . 327
 agosto 2014 - pregunta 5 - Necesidad y diseño de investigación . . . . . . . . . . . . . . . . . . . . . . . . . . . 328
 agosto 2018 - pregunta 5 - Panel, frecuencia y Assessor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 329
 enero 2016 - pregunta 5 - Participación y conjoint . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 330
 agosto 2016 - pregunta 5 - Problema gerencial e investigación . . . . . . . . . . . . . . . . . . . . . . . . . . . 331
 enero 2023 - pregunta 5 - Segmentación en modelo de elección . . . . . . . . . . . . . . . . . . . . . . . . . . 332
 RESPUESTAS DESARROLLADAS · MARKETING 335
 Respuesta M-U1 · Segmentación de clientes . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 335
 Respuesta M-U2 · Factores y mapa perceptual . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 335
Examen de Grado UC | materia, preguntas y respuestas 13

[pág. 14]
Marketing - versión clara y reordenada
 Respuesta M-U3 · Conjoint y precio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 336
 Respuesta M-U4 · Zoom, freemium y causalidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 336
 CONTROL FINAL DE FUENTES · MARKETING 337
 Fuentes cruzadas en esta ampliación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 337
 Archivos no usados como fuente sustantiva . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 337
Examen de Grado UC | materia, preguntas y respuestas 14

[pág. 15]
Marketing - versión clara y reordenada
Examen de Grado UC | materia, preguntas y respuestas 15

[pág. 16]
Marketing - versión clara y reordenada
 ATLAS VISUAL - FÓRMULAS, MÉTRICAS Y
 NÚMEROS
 Este atlas transforma los cálculos de Fundamentos de Marketing y Marketing Analytics en una
 secuencia legible. Cada tarjeta responde seis preguntas: qué calcula, qué significa cada variable,
 cómo se usa, qué error evitar y, cuando ayuda, cómo se ve con números.
 Cómo leer las listas del manual: si una lista describe etapas, respeta el orden; si presenta
 alternativas, elige y justifica; si enumera variables diagnósticas, busca evidencia para cada una;
 si contiene supuestos, comprueba cuáles se cumplen antes de calcular.
Examen de Grado UC | materia, preguntas y respuestas 16

[pág. 17]
Marketing - versión clara y reordenada
 1. Mercado, crecimiento y economía de la oferta
 Primero define población, período, unidad y decisión; después sustituye valores y traduce el
 resultado a una acción comercial.
 Valor neto percibido
 Valor neto = Beneficios percibidos - Costos percibidos
 Qué responde. Organiza por qué una persona preferiría una oferta.
 Variables. Los costos incluyen dinero, tiempo, esfuerzo, riesgo y costos de cambio; los beneficios dependen del
 segmento y la ocasión.
 Procedimiento. Compara la oferta con la alternativa relevante y valida qué atributos cambian la decisión.
 Error típico. Tratar todos los atributos como igualmente importantes o confundir valor para el cliente con margen
 para la empresa.
 Contribución unitaria
 m = Precio neto - Costo variable unitario
 Qué responde. Cuánto aporta cada unidad a cubrir costos fijos y utilidad.
 Variables. Usa precio realmente recibido después de descuentos y costo variable incremental completo.
 Procedimiento. Calcula antes de evaluar volumen, promociones o adquisición.
 Error típico. Usar margen porcentual sin declarar base o ignorar comisión, despacho y devoluciones.
 Ejemplo. Precio neto $8.000 y costo variable $4.800: m = $3.200.
 Margen porcentual
 Margen (%) = (Precio neto - Costo variable) / Precio neto × 100
 Qué responde. Proporción de la venta que queda como contribución antes de costos fijos.
 Variables. El denominador es precio de venta; el markup usa costo y produce otro porcentaje.
 Procedimiento. Declara si se trata de margen bruto, contribución u otra definición.
 Error típico. Confundir margen con recargo sobre costo.
Examen de Grado UC | materia, preguntas y respuestas 17

[pág. 18]
Marketing - versión clara y reordenada
 Punto de equilibrio
 Q* = Costos fijos incrementales / Contribución unitaria
 Qué responde. Unidades necesarias para recuperar el costo fijo incremental.
 Variables. La contribución debe ser positiva y considerar canibalización y costos del canal cuando correspondan.
 Procedimiento. Calcula Q*, compáralo con demanda alcanzable y prueba sensibilidad.
 Error típico. Interpretar Q* como pronóstico de ventas o usar ingresos en el denominador.
 Ejemplo. $16.000.000 / $3.200 = 5.000 unidades.
 Contribución neta de un segmento
 Contribución = Demanda × Cuota alcanzable × Margen unitario -
 Gasto atribuible
 Qué responde. Economía esperada de atender un segmento bajo supuestos explícitos.
 Variables. Demanda, cuota, margen y gasto deben referirse al mismo período, canal y alcance.
 Procedimiento. Modela escenario base, pesimista y optimista; incluye costo de servir e inversión adicional.
 Error típico. Elegir el segmento más grande sin examinar captura, ajuste estratégico y costo.
 Participación de mercado
 Share unidades = Unidades marca / Unidades mercado | Share valor
 = Ventas marca / Ventas mercado
 Qué responde. Peso de la marca dentro de una categoría definida.
 Variables. Numerador y denominador requieren igual categoría, geografía, canal y período.
 Procedimiento. Mira unidades y valor: una marca premium puede diferir entre ambos.
 Error típico. Inferir rentabilidad o causalidad a partir de share.
Examen de Grado UC | materia, preguntas y respuestas 18

[pág. 19]
Marketing - versión clara y reordenada
 Participación relativa
 Share relativo = Share del negocio / Share del competidor de
 referencia
 Qué responde. Compara posición con el rival escogido, usada por ejemplo en BCG.
 Variables. Define mercado y rival; el referente suele ser el líder o competidor relevante.
 Procedimiento. Interpreta mayor que 1 como cuota superior al referente, sin convertirlo automáticamente en
 ventaja sostenible.
 Error típico. Dividir por toda la categoría o usar un competidor distinto entre períodos.
 Crecimiento y CAGR
 Crecimiento = Valor final / Valor inicial - 1 | CAGR = (Final / Inicial)(1/n)
 -1
 Qué responde. Cambio total y ritmo anual compuesto equivalente.
 Variables. n es número de intervalos, no número de observaciones.
 Procedimiento. Expresa en porcentaje después del cálculo y declara período.
 Error típico. Promediar variaciones anuales cuando se necesita crecimiento compuesto.
 Ejemplo. 100 en 2021 y 133,1 en 2024: n=3 y CAGR=10%.
 Puntos porcentuales y cambio relativo
 Cambio en puntos = Tasa final - Tasa inicial | Cambio relativo = Final
 / Inicial - 1
 Qué responde. Distingue variación de una tasa de su crecimiento proporcional.
 Variables. Las dos tasas deben compartir población, período y definición.
 Procedimiento. Informa ambos cuando ayuda a interpretar magnitud.
 Error típico. Decir que pasar de 40% a 44% es un aumento de 4%; son 4 puntos o 10% relativo.
Examen de Grado UC | materia, preguntas y respuestas 19

[pág. 20]
Marketing - versión clara y reordenada
 2. Clientes, embudo, retención y valor de vida
 Primero define población, período, unidad y decisión; después sustituye valores y traduce el
 resultado a una acción comercial.
 Descomposición del volumen
 Volumen = Población × Incidencia × Transacciones por comprador ×
 Unidades por transacción
 Qué responde. Separa crecimiento entre más compradores, más ocasiones y mayor cantidad.
 Variables. Incidencia se expresa como proporción y todas las frecuencias comparten período.
 Procedimiento. Cambia un factor por vez y luego reconoce efectos multiplicativos.
 Error típico. Sumar crecimientos de factores sin considerar interacción.
 Ejemplo. 10.000×0,40×3×2 = 24.000 unidades trimestrales.
 Prueba y repetición
 Volumen total = H×t×q0 + H×t×r×f×qr
 Qué responde. Proyecta volumen inicial y compras adicionales de quienes repiten.
 Variables. H es hogares; t, tasa de prueba; q_0, cantidad inicial; r, repetición; f, compras adicionales; q_r, cantidad
 repetida.
 Procedimiento. Alinea períodos y excluye la prueba de las compras adicionales.
 Error típico. Contar dos veces la primera compra o aplicar repetición a todos los hogares.
 Tasa de conversión
 Conversión (%) = Personas que completan la acción / Personas
 elegibles expuestas × 100
 Qué responde. Proporción que avanza en una etapa definida del embudo.
 Variables. Define acción, exposición, elegibilidad, ventana y deduplicación.
 Procedimiento. Mide cada transición del embudo y agrega margen o calidad como guardarraíl.
 Error típico. Cambiar el denominador entre campañas o celebrar conversión creada por descuentos no rentables.
Examen de Grado UC | materia, preguntas y respuestas 20

[pág. 21]
Marketing - versión clara y reordenada
 Retención y churn
 Retención = Clientes que continúan / Clientes elegibles al inicio |
 Churn = 1 - Retención
 Qué responde. Continuidad o abandono de una cohorte en un período.
 Variables. Define cliente activo, cohorte, inicio, fin y tratamiento de reactivaciones.
 Procedimiento. Sigue cohortes comparables y separa abandono voluntario, involuntario y estacional.
 Error típico. Calcular con clientes finales sobre clientes finales o mezclar altas nuevas.
 Net Promoter Score
 NPS = % Promotores - % Detractores
 Qué responde. Balance de respuestas extremas según la escala NPS.
 Variables. Los pasivos entran en el total de respuestas, aunque no se suman ni restan.
 Procedimiento. Reporta base, población, canal y razones; contrasta con conducta.
 Error típico. Interpretar NPS=30 como 30% de satisfacción o como prueba causal de crecimiento.
 Ejemplo. 50% promotores y 20% detractores: NPS = 30 puntos.
 Customer Lifetime Value simplificado
 CLV = m × r / (1 + d - r)
 Qué responde. Valor presente esperado de márgenes futuros con retención constante.
 Variables. m es margen periódico; r, probabilidad de retención; d, tasa de descuento del mismo período.
 Procedimiento. Resta CAC si buscas valor neto y muestra sensibilidad a r y m.
 Error típico. Usar ingresos en lugar de margen o mezclar retención mensual con descuento anual.
 Ejemplo. m=$12.000, r=0,80 y d=0,02: CLV≈$43.636 antes del CAC.
Examen de Grado UC | materia, preguntas y respuestas 21

[pág. 22]
Marketing - versión clara y reordenada
 Costo de adquisición
 CAC = Gasto incremental de adquisición / Clientes nuevos
 incrementales
 Qué responde. Costo por cliente adicional atribuible a la acción.
 Variables. Incluye medios, descuentos, agencia, ventas y costos pertinentes; usa clientes incrementales cuando
 existe contrafactual.
 Procedimiento. Compara CAC con CLV por cohorte y considera plazo de recuperación.
 Error típico. Dividir gasto por todas las altas observadas y atribuirlas completas a la campaña.
 ROMI
 ROMI = (Margen incremental atribuible - Inversión de marketing) /
 Inversión de marketing
 Qué responde. Retorno económico incremental de una inversión comercial.
 Variables. Usa margen después de devoluciones, canibalización y costos variables; atribución requiere
 contrafactual.
 Procedimiento. Declara horizonte y si incluye valor futuro de clientes.
 Error típico. Usar ventas brutas como beneficio o atribución de último clic como causalidad.
Examen de Grado UC | materia, preguntas y respuestas 22

[pág. 23]
Marketing - versión clara y reordenada
 3. Precio, elasticidad y experimentación
 Primero define población, período, unidad y decisión; después sustituye valores y traduce el
 resultado a una acción comercial.
 Elasticidad precio de la demanda
 Elasticidad = (%Δ Cantidad demandada) / (%Δ Precio)
 Qué responde. Sensibilidad porcentual de cantidad ante cambio porcentual de precio.
 Variables. Para demanda usual es negativa; declara elasticidad propia, cruzada o ingreso y método de estimación.
 Procedimiento. Usa cambios pequeños o elasticidad arco cuando el cambio es grande.
 Error típico. Llamar elasticidad a un coeficiente de precio sin ajustar unidades y nivel de demanda.
 Elasticidad arco
 Earco = [(Q2-Q1)/((Q1+Q2)/2)] / [(P2-P1)/((P1+P2)/2)]
 Qué responde. Elasticidad simétrica entre dos puntos observados.
 Variables. Q y P corresponden a escenarios comparables; otros factores deberían mantenerse o controlarse.
 Procedimiento. Interpreta magnitud y signo, y traduce a contribución.
 Error típico. Atribuir todo cambio de cantidad al precio cuando cambiaron promoción, stock o competencia.
 Ingreso y contribución esperada a un precio
 Ingreso(P) = P × Q(P) | Contribución(P) = [P - CV] × Q(P) - Costos fijos
 Qué responde. Compara precios usando demanda prevista y economía, no solo intención.
 Variables. Q(P) debe estimarse para el precio; CV y costos corresponden al mismo escenario.
 Procedimiento. Evalúa varios precios y agrega restricciones de marca, capacidad y canal.
 Error típico. Elegir el precio con mayor intención o ingreso cuando el objetivo es contribución.
 Lift experimental
 Lift absoluto = Resultado tratamiento - Resultado control
 Qué responde. Cambio causal promedio si la asignación y medición son comparables.
 Variables. También puede informarse lift relativo = Tratamiento/Control - 1.
 Procedimiento. Define unidad de aleatorización, período, cumplimiento y guardarraíles.
 Error típico. Comparar antes y después sin control o confundir significancia con impacto económico.
Examen de Grado UC | materia, preguntas y respuestas 23

[pág. 24]
Marketing - versión clara y reordenada
 Ventas incrementales
 Incremento = Ventas observadas con acción - Ventas contrafactuales
 sin acción
 Qué responde. Ventas que no habrían ocurrido sin la intervención.
 Variables. El contrafactual puede venir de control aleatorio, holdout o diseño cuasiexperimental defendible.
 Procedimiento. Convierte ventas incrementales a margen y descuenta canibalización.
 Error típico. Usar todas las ventas expuestas o último clic como incremento.
 Efecto neto de canibalización
 Efecto = Unidades nuevas×margen nuevo - Unidades
 sustituidas×margen antiguo - Costos incrementales
 Qué responde. Resultado económico del lanzamiento respecto del escenario sin producto nuevo.
 Variables. Las unidades sustituidas son ventas propias que habrían ocurrido sin el lanzamiento.
 Procedimiento. Incluye nuevos clientes, sustitución de competidor y costos de inventario o canal.
 Error típico. Tratar toda venta de la variante como crecimiento incremental.
Examen de Grado UC | materia, preguntas y respuestas 24

[pág. 25]
Marketing - versión clara y reordenada
 4. Investigación, muestra e inferencia
 Primero define población, período, unidad y decisión; después sustituye valores y traduce el
 resultado a una acción comercial.
 Tamaño muestral para una proporción
 n = z² × p(1-p) / e²
 0
 Qué responde. Respuestas completas necesarias para un margen de error aproximado bajo muestreo aleatorio
 simple.
 Variables. z depende de confianza; p es proporción esperada; e es error absoluto deseado.
 Procedimiento. Si p es desconocida, 0,5 entrega el tamaño conservador; ajusta por no respuesta y diseño.
 Error típico. Creer que más muestra corrige marco incompleto o sesgo de no respuesta.
 Ejemplo. 95%, p=0,5 y e=0,05: n_0≈385 respuestas completas.
 Corrección por población finita
 n = n0 / [1 + (n0-1)/N]
 Qué responde. Reduce muestra requerida cuando la población finita N no es muy grande.
 Variables. N es población elegible real; n_0 viene del cálculo para población grande.
 Procedimiento. Aplica después del tamaño inicial y antes de inflar por no respuesta.
 Error típico. Usarla cuando el marco no cubre realmente a toda la población objetivo.
 Puntaje estandarizado
 z = (x - Media) / Desviación estándar
 Qué responde. Expresa una observación en desviaciones estándar respecto de su distribución.
 Variables. Media y desviación se calculan en población o muestra definida; revisa outliers y asimetría.
 Procedimiento. Estandariza variables antes de clustering cuando sus escalas dominarían la distancia.
 Error típico. Interpretar z como porcentaje o comparar z obtenidos de poblaciones distintas sin contexto.
Examen de Grado UC | materia, preguntas y respuestas 25

[pág. 26]
Marketing - versión clara y reordenada
 ANOVA
 SSTotal = SSEntre + SSDentro | F = MSEntre / MSDentro
 Qué responde. Evalúa si existe evidencia de que alguna media de grupo difiere.
 Variables. MS_Entre=SS_Entre/(k-1); MS_Dentro=SS_Dentro/(N-k).
 Procedimiento. Verifica supuestos y, si F es significativo, usa contrastes o post hoc para localizar diferencias.
 Error típico. Concluir que todos los grupos difieren o que la diferencia es importante solo por p<0,05.
 Correlación
 rxy = Cov(x,y) / (σx × σy)
 Qué responde. Fuerza y dirección de asociación lineal entre dos variables.
 Variables. Toma valores entre -1 y 1; depende de rango, outliers y forma de la relación.
 Procedimiento. Grafica datos, reporta incertidumbre y evita causalidad automática.
 Error típico. Interpretar r=0 como ausencia de toda relación o r² como porcentaje causal.
 Distancia euclidiana
 d(i,c) = √[Σj (xij - cj)²]
 Qué responde. Distancia de una observación i a un centroide c en variables numéricas.
 Variables. j recorre variables; deben tener escala y ponderación justificadas.
 Procedimiento. Estandariza cuando las unidades son incomparables y revisa sensibilidad.
 Error típico. Permitir que una variable de gran escala domine todos los clusters.
 Objetivo de k-means
 Minimizar Σclusters Σi cluster ||xi - centroidecluster||²
 Qué responde. Crea grupos compactos alrededor de centroides.
 Variables. Se elige k, se inicializan centros, se asigna, actualiza e itera.
 Procedimiento. Compara inicializaciones, estabilidad y utilidad externa de los segmentos.
 Error típico. Tratar cualquier partición como segmentos accionables o usar p-valor como calidad universal.
Examen de Grado UC | materia, preguntas y respuestas 26

[pág. 27]
Marketing - versión clara y reordenada
 Stress en MDS
 Stress ≈ √[Σ(dobservada - dmapa)² / Σ(dobservada)²]
 Qué responde. Resume cuánto distorsiona el mapa las disimilitudes originales.
 Variables. La definición exacta depende del tipo de stress y escalamiento usados.
 Procedimiento. Compara dimensiones, estabilidad e interpretación; un valor menor suele indicar mejor ajuste.
 Error típico. Tratar ejes como atributos causales o un espacio vacío como oportunidad demostrada.
Examen de Grado UC | materia, preguntas y respuestas 27

[pág. 28]
Marketing - versión clara y reordenada
 5. Conjoint, elección y disposición a pagar
 Primero define población, período, unidad y decisión; después sustituye valores y traduce el
 resultado a una acción comercial.
 Regla compensatoria
 Puntaje de alternativa = Σ Peso × Evaluación
 atributo atributo
 Qué responde. Representa una decisión donde fortalezas pueden compensar debilidades.
 Variables. Los pesos deben sumar 1 o tener una escala interpretable; evaluaciones comparten dirección.
 Procedimiento. Calcula cada aporte y compara alternativas, reconociendo que es una regla hipotética.
 Error típico. Usar escalas donde en algunos atributos un número alto es peor sin invertirlas.
 Utilidad total en conjoint
 U(perfil) = Constante + Σ Utilidades parciales de sus niveles
 Qué responde. Preferencia estimada para una combinación de atributos.
 Variables. Cada nivel aporta una utilidad parcial bajo la codificación y modelo estimados.
 Procedimiento. Suma niveles presentes y compara escenarios dentro del rango estudiado.
 Error típico. Interpretar utilidad como pesos, dinero o probabilidad de compra sin transformación.
 Importancia de un atributo
 Importanciaj = Rango de utilidadesj / Σ rangos × 100
 Qué responde. Variación relativa de utilidad permitida por los niveles estudiados.
 Variables. Rango = máximo-mínimo de utilidades parciales del atributo.
 Procedimiento. Interpreta condicionado a niveles incluidos; no es importancia universal.
 Error típico. Comparar importancias entre estudios con rangos de niveles distintos.
Examen de Grado UC | materia, preguntas y respuestas 28

[pág. 29]
Marketing - versión clara y reordenada
 Probabilidad logit multinomial
 Pij = exp(Vij) / Σk exp(Vik)
 Qué responde. Convierte utilidades sistemáticas en probabilidades de elección.
 Variables. V_ij=β'x_ij; el denominador incluye todas las alternativas, incluida no compra cuando corresponde.
 Procedimiento. Calcula exponentes, suma y normaliza; las probabilidades deben sumar 1.
 Error típico. Leer un coeficiente como porcentaje o cambiar el signo al sustituir.
 Ejemplo. V_A=0 y V_B=ln(2): P_A=1/3 y P_B=2/3.
 Odds ratio
 Odds ratio por una unidad en x = exp(βx)
 Qué responde. Cambio multiplicativo de odds asociado a una unidad del atributo, manteniendo lo demás.
 Variables. β_x depende de unidad y codificación; odds no es lo mismo que probabilidad.
 Procedimiento. Traduce después a probabilidades en escenarios relevantes.
 Error típico. Decir que exp(β)=2 significa duplicar directamente la probabilidad.
 Disposición a pagar marginal
 DAPx = βx / (-βprecio)
 Qué responde. Cambio de precio que compensa una unidad del atributo en utilidad.
 Variables. Precio debe entrar linealmente con coeficiente negativo y unidades monetarias claras.
 Procedimiento. Reporta intervalo y reconoce heterogeneidad y límites del rango experimental.
 Error típico. Usar un coeficiente de precio en centavos con atributos en pesos sin conversión.
 Simulación de cuota y contribución
 Cuota previstaj = Promedioi[Pij] | Contribuciónj = Volumen mercado ×
 Cuotaj × Margenj
 Qué responde. Traduce elecciones individuales estimadas a escenario comercial.
 Variables. Ajusta por disponibilidad, distribución, no compra, población y costos.
 Procedimiento. Simula competidores plausibles y valida fuera de muestra o con piloto.
 Error típico. Presentar share logit como venta asegurada o elegir producto por cuota sin margen.
Examen de Grado UC | materia, preguntas y respuestas 29

[pág. 30]
Marketing - versión clara y reordenada
 6. Compra repetida y difusión
 Primero define población, período, unidad y decisión; después sustituye valores y traduce el
 resultado a una acción comercial.
 Poisson para frecuencia
 P(N=n | λ) = exp(-λt) × (λt)n / n!
 Qué responde. Probabilidad de n eventos en exposición t para tasa individual λ constante.
 Variables. N es conteo; λ es tasa por unidad de tiempo; t usa la misma unidad.
 Procedimiento. Comprueba sobredispersión y heterogeneidad antes de usar Poisson simple.
 Error típico. Confundir tasa con probabilidad o ignorar exposiciones distintas.
 Gamma-Poisson
 E(λ)=α/β | Var(λ)=α/β² | Posterior: Gamma(α+n, β+t)
 Qué responde. Modela heterogeneidad de tasas de compra y actualiza con historial.
 Variables. La expresión usa parametrización forma α y tasa β.
 Procedimiento. Declara parametrización porque algunas fuentes usan escala en vez de tasa.
 Error típico. Aplicar medias de compra sin reconocer que pocos compradores intensivos pueden dominarlas.
 Beta-Binomial
 p | datos ~ Beta(a+x, b+m-x) | Media posterior = (a+x)/(a+b+m)
 Qué responde. Actualiza una probabilidad individual de éxito con x éxitos en m oportunidades.
 Variables. a y b son parámetros previos; x y m-x son éxitos y fracasos observados.
 Procedimiento. Úsalo para proporciones por oportunidad, no tasas continuas de eventos.
 Error típico. Intercambiarlo con Gamma-Poisson sin mirar qué variable se modela.
 Modelo de Bass: intensidad de adopción
 Adopción entre no adoptantes = p + q × F(t)
 Qué responde. Combina innovación externa p e imitación q según adopción acumulada F(t).
 Variables. F(t)=N(t)/m; m es mercado potencial; p y q dependen del período.
 Procedimiento. Estima con datos pertinentes y separa adopción de ventas repetidas o reposición.
 Error típico. Interpretar p como publicidad pura, q como boca a boca puro o m como población total sin filtro.
Examen de Grado UC | materia, preguntas y respuestas 30

[pág. 31]
Marketing - versión clara y reordenada
 Bass: adopción acumulada
 N(t) = m × [1 - exp(-(p+q)t)] / [1 + (q/p)exp(-(p+q)t)]
 Qué responde. Número acumulado de adoptantes en la forma continua usual.
 Variables. m es potencial; p y q comparten la unidad temporal de t.
 Procedimiento. Obtén adopciones del período por diferencia N(t)-N(t-1) y valida sensibilidad.
 Error típico. Confundir acumulado con ventas del período o extrapolar fuera del rango sin revisar saturación.
 Marketing · preparación del Examen de Grado
 UC 2027
 Banco de Marketing: 70 preguntas en total · Parte I: Fundamentos de Marketing (35
 preguntas) · Parte II: Marketing Analytics (35 preguntas)
 Este manual está diseñado para reconstruir la materia desde una base débil. El mapa curricular se
 apoya en el programa EAA2310 (Fundamentos de Marketing, 2021-2) y en el programa EAA331A
 (Mercados II: Datos, Modelos y Decisiones en Marketing, 2022), usado como correspondencia
 provisional para Marketing Analytics. No se encontró un programa único oficial del Examen de
 Grado 2027; cuando aparezca, debe cotejarse con este mapa.
 El índice se genera con páginas de este libro. Las preguntas reproducen los enunciados desde el
 compendio histórico; sus respuestas se reúnen en la parte IV y se identifican como propuestas
 salvo verificación expresa de pauta oficial.
 Cómo estudiar con este libro
 El calendario organiza el foco, no el estándar académico. Octubre prioriza Marketing; noviembre,
 Finanzas junto con repaso de Marketing; diciembre, Dirección junto con repaso de las otras dos; y
 fines de diciembre/enero integran las tres en simulaciones. Marketing, Finanzas y Dirección
 mantienen igual profundidad, análisis, cuidado y objetivo de Distinción.
 No empieces memorizando definiciones. En cada unidad sigue cuatro movimientos: (1) explica el
 problema en palabras simples, (2) reconstruye el mecanismo o modelo, (3) resuelve un ejercicio sin
 mirar y (4) recomienda una decisión mencionando supuestos y evidencia que podría cambiarla.
 Marca una unidad como dominada solo si puedes explicar por qué el método sirve, ejecutarlo con
 datos y discutir qué no permite concluir.
 En preguntas de caso, distingue síntoma de causa, segmento de mercado, decisión, alternativas,
 valor para cliente, economía para la empresa, implementación y medición. En preguntas
 cuantitativas escribe datos, fórmula, sustitución, resultado con unidad, interpretación y limitación.
 Después de estudiar el cuerpo, practica las preguntas históricas completas reunidas en la sección
 final. La frecuencia histórica describe el corpus 2009-2026; no predice por sí sola el examen 2027.
Examen de Grado UC | materia, preguntas y respuestas 31

[pág. 32]
Marketing - versión clara y reordenada
 Mapa de la materia
 Parte Unidad Qué debe poder hacer el estudiante
 Fundamentos Valor, orientación al mercado y Explicar cómo una oferta crea valor
 modelo de negocio para un grupo y cómo la empresa
 captura una parte sostenible
 Fundamentos Conducta, comprador, usuario y Diagnosticar barreras en el proceso
 experiencia de decisión y diseñar una experiencia
 coherente
 Fundamentos Segmentación, targeting y Elegir un segmento servible y
 posicionamiento formular una diferencia relevante y
 creíble
 Fundamentos Marca, portafolio, producto e Proteger significado de marca,
 innovación evaluar extensiones y justificar
 lanzamientos
 Fundamentos Precio y captura de valor Conectar disposición a pagar,
 demanda, margen, competencia y
 decisión de precio
 Fundamentos Canales, venta y comunicación Diseñar acceso, coordinación y
 comunicación; evaluar desempeño
 sin confundir atribución con
 causalidad
 Analytics Problema, investigación, datos y Transformar una decisión incierta en
 medición un diseño de datos válido y ético
 Analytics Muestreo, inferencia y ANOVA Cuantificar incertidumbre y comparar
 grupos bajo supuestos explícitos
 Analytics Segmentación, factores y mapas Encontrar estructura útil sin tratar una
 perceptuales solución estadística como verdad
 natural
 Analytics Compra repetida, Gamma-Poisson, Construir benchmarks y explicar
 Beta-Binomial y Dirichlet heterogeneidad de comportamiento
 Analytics Elección logística Estimar y comunicar probabilidades y
 trade-offs de elección
 Analytics Difusión de Bass Interpretar adopción en el tiempo y
 proyectar con cautela
 Analytics Conjoint, disposición a pagar y Inferir trade-offs declarados y evaluar
 simulación ofertas bajo escenarios
 Analytics Pricing research y causalidad Usar investigación de precio y
 diseños causales para decidir con
 evidencia
Examen de Grado UC | materia, preguntas y respuestas 32

[pág. 33]
Marketing - versión clara y reordenada
 PARTE I - FUNDAMENTOS DE MARKETING
 1. Marketing, orientación al mercado y economía de valor
 Qué es marketing: crear, entregar y capturar valor
 El problema que resuelve
 Una organización dispone de recursos limitados y enfrenta personas con necesidades, alternativas
 y restricciones. Marketing ayuda a decidir a quién servir, qué problema resolver, con qué oferta,
 cómo hacerla accesible, qué cobrar y cómo aprender de la respuesta del mercado. Por eso no es
 sinónimo de publicidad. Publicidad es una herramienta de comunicación; marketing integra
 decisiones de cliente, producto, precio, canal, comunicación y economía.
 Una necesidad es una carencia o tarea que una persona intenta resolver. Un deseo es una forma
 específica de satisfacerla, influida por cultura, experiencia y contexto. La demanda aparece cuando
 existe deseo junto con disposición y capacidad de pago. Una empresa no crea libremente las
 necesidades: identifica problemas y compite por ofrecer una solución preferida.
 Valor para el cliente y valor para la empresa
 Una forma útil de ordenar el valor percibido es:
 Valor neto percibido = beneficios percibidos - costos percibidos.
 Los beneficios pueden ser funcionales (desempeño), económicos (ahorro), emocionales
 (confianza), sociales (identidad), de conveniencia o de reducción de riesgo. Los costos incluyen
 precio, tiempo, esfuerzo, aprendizaje, incertidumbre, privacidad y costo de cambiar desde una
 alternativa. La comparación siempre es relativa a opciones concretas: una oferta puede ser
 excelente en términos absolutos y poco atractiva frente a una alternativa más conveniente.
 La empresa captura valor mediante precio, recurrencia, volumen, datos, economías de escala o
 ingresos complementarios. Crear más valor para el cliente no garantiza capturar más margen: una
 mejora puede costar demasiado, ser copiada o beneficiar sobre todo al canal. Hay que analizar
 simultáneamente valor para el cliente, costo de servir y apropiación económica.
 Intuición: si un supermercado promete precios bajos, logística eficiente y alta disponibilidad, su
 ventaja depende de que las actividades operativas hagan posible esa promesa. Si paga más por
 abastecerse, genera quiebres o necesita descuentos permanentes, la promesa y la economía dejan
 de ser coherentes.
 Propuesta de valor y modelo de negocio
 Una propuesta de valor debe responder con precisión: para quién, en qué situación o tarea, qué
 beneficio diferencial, frente a qué alternativa y con qué evidencia la empresa puede cumplir.
 «Calidad e innovación» no es una propuesta suficiente si no se identifica qué calidad importa, para
 quién y por qué es preferible.
 El modelo de negocio organiza la lógica completa: clientes y usuarios, propuesta, canales,
 actividades y recursos, socios, costos e ingresos. En una plataforma hay varios lados. La
 plataforma puede subsidiar a un lado para atraer al otro; el precio de un lado aislado no informa si el
Examen de Grado UC | materia, preguntas y respuestas 33

[pág. 34]
Marketing - versión clara y reordenada
 sistema total es rentable. Importan externalidades cruzadas, confianza, congestión y costo de
 adquirir a cada grupo.
 Economía básica de una propuesta
 Con precio neto (p), costo variable unitario (v), cantidad (Q) y costo fijo atribuible (F):
 • Contribución unitaria: (m=p-v).
 • Contribución total antes de costos fijos: (Q(p-v)).
 • Resultado incremental simplificado: (Q(p-v)-F).
 • Punto de equilibrio: (Q^*=F/(p-v)), si (p>v).
 Ejemplo resuelto. Una nueva presentación se vendería a $8.000, cuesta $4.800 por unidad y exige
 $16 millones de lanzamiento. Su contribución unitaria es $3.200. El volumen para recuperar solo el
 costo fijo es $16.000.000/$3.200 = 5.000 unidades. Si sustituye ventas de una presentación actual,
 el cálculo correcto resta la contribución perdida por canibalización. Si el canal exige descuentos o
 hay costos variables de despacho, deben incorporarse antes de recomendar el lanzamiento.
 Orientación al mercado y diagnóstico
 Orientarse al mercado significa obtener información sobre clientes, competidores y cambios del
 entorno, compartirla entre áreas y responder coordinadamente. La investigación no reemplaza
 criterio; mejora el diagnóstico y permite aprender. Ante caída de ventas, no se concluye
 automáticamente que falta publicidad. Se separa el resultado en precio, volumen, mezcla,
 distribución, disponibilidad, experiencia, adquisición, retención y cambios de la categoría.
 Una respuesta de Distinción declara el mecanismo causal plausible, muestra qué dato lo apoya,
 ofrece al menos una explicación alternativa y dice qué prueba distinguiría ambas explicaciones.
 Integración de Fundamentos: resolver casos sin saltar al framework
 Del síntoma al mecanismo
 En un caso, separa cuatro capas. El resultado es el síntoma descrito (ventas caen, churn sube,
 share se mueve). El mecanismo es lo que podría producirlo (menos disponibilidad, sustitución,
 menor valor percibido, menor consideración, ruptura de servicio). La causa es una intervención o
 condición que cambia el mecanismo. La decisión es qué puede cambiar la empresa. El diagnóstico
 se fortalece cuando cada capa está conectada por evidencia y se distingue de hipótesis.
 Una caída de ventas se descompone primero en volumen, precio neto y mezcla. El volumen
 depende, entre otras cosas, de clientes activos, frecuencia y unidades por ocasión. Cada pieza
 puede cambiar por tamaño de categoría, distribución, disponibilidad, competencia, conversión o
 retención. Un dato de share no revela si el mercado creció o si cayó la venta propia; una encuesta
 de awareness no revela disponibilidad; una correlación entre promoción y venta no identifica
 incremento si la promoción se aplicó justo donde se esperaba mayor demanda.
 Secuencia de caso: (1) define objetivo y horizonte; (2) describe cliente y ocasión; (3) mapea
 alternativa y causa plausible; (4) localiza la fricción en propuesta, precio, acceso o comunicación;
 (5) calcula impacto unitario y total; (6) contrasta opciones; (7) recomienda prueba y guardarraíles.
 En una recomendación de Distinción, cada iniciativa cambia un mecanismo identificable y tiene una
Examen de Grado UC | materia, preguntas y respuestas 34

[pág. 35]
Marketing - versión clara y reordenada
 métrica de éxito.
 Ventaja competitiva, recursos y coherencia
 Una diferencia apreciada por el cliente puede no ser ventaja defendible si competidores la replican
 rápido o si la empresa no puede capturar el retorno. Examina valor para el cliente, rareza, dificultad
 de imitación, sustitutos y organización para explotar la capacidad. Un activo como marca, datos,
 relación con canal o escala puede ser fuente de ventaja solo si influye en elección/costos y está
 protegido por actividades complementarias.
 La cadena de actividades conecta operaciones con promesa. Una firma de bajo precio debe
 controlar costos que realmente importan al cliente sin deteriorar disponibilidad o calidad mínima.
 Una marca premium debe justificar precio con desempeño, señal, experiencia o servicio
 consistente. La ejecución genera reputación acumulada; una campaña no reemplaza capacidad de
 entrega.
 Objetivos, métricas y tablero
 Una métrica es útil si su definición permite actuar. Documenta fórmula, unidad, población, periodo,
 fuente, responsable y decisión asociada. Ventas, share, margen, prueba, repetición, awareness y
 satisfacción responden preguntas distintas. Un tablero mezcla resultados rezagados (margen,
 share, retención) con antecedentes (disponibilidad, consideración, conversión, calidad de servicio)
 pero evita acumular indicadores sin propietario.
 La métrica principal y guardarraíles deben ser explícitos. Por ejemplo, optimizar conversiones con
 un guardarraíl de margen y reclamos puede impedir que una oferta atraiga clientes que luego
 abandonan o demandan costoso servicio. Si el indicador puede manipularse, considera métricas de
 balance y auditoría.
 Estrategia competitiva y modelo de negocio
 Cinco fuerzas y complementos
 El análisis de industria pregunta quién captura valor y qué limita rentabilidad: rivalidad, amenaza de
 entrada, sustitutos, poder de proveedores y compradores. La intensidad de cada fuerza depende de
 estructura, costos de cambio, diferenciación, capacidad, concentración, economías y regulación. No
 es una puntuación automática ni reemplaza el análisis de segmento. Complementos pueden
 aumentar disposición a pagar o demanda cuando la oferta se usa con otra; también pueden
 concentrar poder en un socio.
 Cómo responder. Para cada fuerza, nombra el actor/mecanismo y un dato del caso. Después
 explica su efecto probable en margen, crecimiento o capacidad de diferenciarse. Cierra con acción:
 reducir dependencia, agregar valor diferencial, diseñar asociación, proteger acceso o enfocarse en
 segmento. No recites las cinco fuerzas si solo una explica la decisión.
 Canvas como mapa de hipótesis
 Canvas organiza nueve preguntas: segmentos; propuesta de valor; canales; relación con clientes;
 ingresos; recursos clave; actividades clave; socios clave; estructura de costos. Sirve para hacer
 visible coherencia e hipótesis, no prueba la viabilidad. Cada bloque tiene dependencias: un canal
 directo requiere adquisición, atención y logística; un ingreso por suscripción requiere retención y
 entrega continua; un subsidio de plataforma requiere monetización en el otro lado.
Examen de Grado UC | materia, preguntas y respuestas 35

[pág. 36]
Marketing - versión clara y reordenada
 Un modelo es débil cuando propuesta exige una capacidad que la empresa no posee, canales no
 alcanzan segmento, relación prometida cuesta más que el margen, o ingreso depende de conducta
 que no se ha validado. Cambiar Canvas es una hipótesis; el aprendizaje viene de prueba que
 pueda refutarla.
 La rentabilidad por segmento puede expresarse como:
 Contribución neta del segmento = demanda del segmento × participación alcanzable ×
 (ingreso unitario - costo variable unitario) - gasto de marketing atribuible.
 Ejemplo. Un segmento compra 50.000 unidades anuales; la empresa estima capturar 12%, con
 ingreso unitario neto $6.000, costo variable $3.500 y gasto atribuible de $8 millones. Contribución
 neta estimada =50.000×0,12×$2.500-$8.000.000=$7.000.000. Si el costo de servir o la inversión
 inicial adicional no está incluida, el segmento puede ser menos atractivo de lo calculado. Ejecuta
 sensibilidad sobre captura y volumen.
 Sostenibilidad de la ventaja
 Una ventaja es percibida por el cliente o se traduce en menor costo relevante; debe poder
 apropiarse y persistir. Imitación reduce diferencia; sustitución elimina necesidad o cambia
 tecnología; hold-up permite que un socio capture retorno; slack o complacencia deteriora disciplina
 y ejecución. Evalúa cómo la capacidad produce resultado, qué actividad la soporta y qué impediría
 que competidores la copien. La marca por sí sola no protege una oferta sin experiencia y acceso
 congruentes.
 Marketing participa en toda la propuesta
 Marketing estudia cómo una organización crea, comunica, entrega e intercambia valor con un
 mercado. No se reduce a publicidad ni a presionar ventas. Una campaña puede comunicar una
 solución, pero si el producto no resuelve la necesidad, el precio no tiene sentido o el canal no
 entrega, la promesa falla. La gestión exige decisiones coherentes entre mercado, propuesta y
 capacidades.
 El valor para el cliente surge de beneficios frente a sacrificios y alternativas. El valor para la
 empresa requiere capturar una parte suficiente para cubrir recursos, riesgos e inversión. Si una
 oferta atrae clientes mediante un costo de servicio superior a lo que pagan, puede producir
 satisfacción y destruir recursos al mismo tiempo. Una recomendación académica debe considerar
 ambas perspectivas.
 La orientación al mercado incluye obtener información de necesidades y competencia, compartirla
 entre funciones y responder. Investigar sin modificar decisiones no completa el proceso. Responder
 no significa obedecer cualquier deseo declarado: algunas preferencias no son viables, otras se
 expresan de forma incompleta y existen necesidades latentes. La empresa contrasta evidencia,
 evalúa alternativas y elige una propuesta que puede sostener.
Examen de Grado UC | materia, preguntas y respuestas 36

[pág. 37]
Marketing - versión clara y reordenada
 Ventaja competitiva y coherencia
 La cadena de valor permite localizar actividades que crean beneficios o reducen costos. Una oferta
 económica puede depender de compras, diseño modular, logística y autoservicio; una oferta
 especializada puede requerir formación y diagnóstico. El costo bajo no obliga a cobrar el precio más
 bajo: puede utilizarse para margen, inversión o una combinación. La diferenciación debe importar al
 cliente y tener una economía defendible.
 Las economías de escala distribuyen ciertos costos o mejoran procesos al aumentar escala; no
 significan que todo costo fijo total disminuya siempre. El aprendizaje depende de experiencia
 acumulada y puede reducir errores o tiempo. Una gran empresa no posee automáticamente ambos
 beneficios. Hay que mostrar qué actividad cambia y por qué.
 VRIO pregunta si un recurso o capacidad crea valor, es relativamente escaso, resulta difícil de
 imitar y está respaldado por la organización para aprovecharlo. Una tecnología disponible para
 todos puede ser útil sin generar una ventaja sostenible. Una base de datos puede ser valiosa, pero
 inútil si no hay capacidad de análisis ni decisiones. La aplicación requiere un recurso concreto y un
 mecanismo, no cuatro respuestas afirmativas sin evidencia.
 No se enseña como ley que toda empresa deba ser simultáneamente líder en costos y
 diferenciación. Puede existir una combinación eficiente, pero también tensiones reales entre
 objetivos. La recomendación debe justificar qué beneficios prioriza el segmento, qué actividades los
 sostienen y qué costos acepta. La coherencia permite comprender por qué dos empresas rentables
 pueden organizarse de forma distinta.
 Centralidad del cliente y CRM
 La centralidad del cliente necesita cultura, capacidad para comprender el mercado, sistemas de
 información y prácticas de personas que permitan responder. Cambiar el discurso corporativo no
 transforma por sí solo el comportamiento. Si una empresa dice escuchar, pero remunera solo por
 rapidez y volumen, puede desalentar la atención de problemas complejos.
 El recorrido de relación incluye adquisición, primera experiencia, desarrollo, retención y eventual
 recuperación. En adquisición se evalúan acceso, costo y calidad de clientes; en primera
 experiencia, activación y cumplimiento; en desarrollo, usos pertinentes; en retención, causas de
 continuidad y abandono. Recuperar a todos los desertores no es necesariamente rentable: algunos
 no encajan con la propuesta o son costosos de atender.
 Un CRM integra información para gestionar relaciones; no es únicamente una agenda de contactos.
 Puede combinar transacciones, interacciones y preferencias bajo reglas pertinentes. RFM resume
 recencia, frecuencia y valor monetario, pero no observa por sí solo rentabilidad, causalidad o
 necesidad. Un cliente de gasto alto puede tener costos de devolución elevados. Una clasificación
 sirve para formular y probar decisiones, no para asignar valor definitivo a una persona.
 NPS distingue promotores, pasivos y detractores según una escala y resta porcentajes de
 promotores y detractores. Si hay 50% de promotores y 20% de detractores, NPS=30 puntos; no es
 30% de satisfacción ni prueba de crecimiento futuro. Debe complementarse con conducta y
 razones. Churn mide abandono bajo una definición de cliente activo y período. LTV estima
 contribución esperada de una relación, no suma ingresos sin costos ni descuento. Cada indicador
 debe responder a una decisión concreta.
Examen de Grado UC | materia, preguntas y respuestas 37

[pág. 38]
Marketing - versión clara y reordenada
 Modelo de negocio y plan
 Canvas conecta segmentos, propuesta de valor, canales, relaciones, ingresos, recursos,
 actividades, socios y costos. Su utilidad es hacer visibles relaciones e hipótesis. Una empresa
 puede atender varios segmentos mediante un modelo coherente; no se exige crear un modelo
 independiente por cada segmento si comparte actividades y economía. Si segmentos requieren
 promesas incompatibles, conviene examinar separación o diseño de ofertas.
 Un plan parte de diagnóstico, elige segmentos y objetivos, define propuesta y acciones, asigna
 recursos y establece evaluación. La flexibilidad surge de escenarios, señales y reglas de ajuste, no
 de improvisación permanente. Por ejemplo, se puede autorizar una expansión si el piloto cumple
 margen y retención, y detenerla si aumenta el costo de servicio sin mejorar contribución. El objetivo
 debe incluir período, línea base y resultado.
 Medidas básicas y crecimiento
 La participación en unidades divide unidades de la empresa por unidades del mercado; la
 participación en valor divide ventas monetarias por ventas del mercado. Una marca de precio alto
 puede tener más participación en valor que en unidades. Ambas necesitan igual categoría,
 geografía, canal y período. Una cuota no demuestra rentabilidad ni identifica qué produjo su
 cambio.
 La tasa de crecimiento entre dos valores es(final/inicial)-1. El crecimiento anual compuesto se
 calcula como(final/inicial)^(1/n)-1, donde n es el número de intervalos anuales. Si las ventas pasan
 de 100 en 2021 a 133,1 en 2024, hay 3 intervalos y CAGR=10%. Hay 4 observaciones anuales,
 pero 3 intervalos. Una media aritmética de variaciones anuales no sustituye siempre el crecimiento
 compuesto: crecer 50% y luego caer 50% deja 100×1,5×0,5=75, aunque el promedio aritmético sea
 0%.
 Las identidades y marcos apoyan el diagnóstico. Una respuesta de dominio propone cómo cambiar
 un resultado, explica el mecanismo, reconoce recursos y establece cómo distinguir una mejora real
 de un efecto temporal o de un cambio del mercado.
 Base local: resumen completo, pp.1-10; conexiones con medición y uso responsable de datos
 pp.28-34 y 102-119. Se corrigen el conteo ambiguo de períodos y fórmulas de margen y equilibrio
 que omiten paréntesis.
 2. Conducta del consumidor y decisión de compra
 Cliente, conducta de compra y experiencia
 Roles y situaciones
 Quien inicia una compra puede no ser quien influye, decide, paga o usa. En una compra familiar o
 industrial estos roles importan mucho: el usuario valora desempeño, el comprador compara
 proveedores, el pagador controla presupuesto y un influenciador puede imponer requisitos. En
 retail, el shopper enfrenta la elección en una tienda y bajo una misión de compra concreta;
 disponibilidad, exhibición, tiempo y promociones afectan lo que termina comprando.
Examen de Grado UC | materia, preguntas y respuestas 38

[pág. 39]
Marketing - versión clara y reordenada
 Proceso de decisión y recorrido real
 Un modelo clásico propone reconocimiento de necesidad, búsqueda de información, evaluación de
 alternativas, compra y evaluación posterior. Es una guía diagnóstica, no una secuencia rígida:
 compras habituales pueden saltarse etapas; una experiencia negativa puede reiniciar búsqueda;
 una compra digital puede intercalar recomendación, comparación y conversación.
 Para analizar un caso, dibuja el recorrido con acciones observables. En cada etapa pregunta: ¿qué
 intenta hacer la persona?, ¿qué fricción enfrenta?, ¿qué alternativas considera?, ¿qué señal
 recibe?, ¿qué podría hacerla abandonar? Distingue punto de contacto de causa de compra: una
 interacción puede coincidir con la compra porque capturó demanda ya existente.
 Riesgo, involucramiento y aprendizaje
 El involucramiento depende de consecuencias percibidas, identidad, precio y frecuencia. A mayor
 riesgo, suele crecer la búsqueda de información, garantías, reputación y asesoría. En compras
 frecuentes pueden dominar disponibilidad, hábito y memoria. La prueba gratuita reduce riesgo pero
 también puede atraer usuarios que no representan al mercado objetivo; mide conversión posterior y
 costo de servir.
 Satisfacción, retención y valor de vida
 Satisfacción es una evaluación posterior; retención es continuidad observada; lealtad actitudinal
 implica preferencia o compromiso. Pueden separarse: alguien puede recomprar por falta de
 alternativas y no preferir la marca, o estar satisfecho y cambiar por precio. Correlación entre
 satisfacción y recompra no demuestra que elevar una encuesta cause retención.
 Una fórmula simplificada de valor de vida con margen periódico constante (m), probabilidad de
 retención (r) y tasa de descuento periódica (d) es:
 CLV = m × r / (1 + d - r)
 Esta expresión supone margen constante, retención estable, horizonte largo y primer margen al
 cierre del primer periodo. Si hay costos de adquisición iniciales, se restan; si el margen cambia por
 cohorte, canal o antigüedad, se proyecta periodo a periodo. No reemplaces supervivencia real con
 un promedio de todos los clientes.
 Ejercicio guiado. Una cohorte genera $12.000 de margen mensual por cliente, retiene 80% y usa
 descuento mensual de 2%. CLV aproximado = 12.000×0,80/(1,02-0,80) = $43.636. Si captar cada
 cliente cuesta $20.000, el valor neto aproximado es $23.636, antes de costos no incluidos. Como
 retención determina fuertemente el resultado, conviene mostrar sensibilidad: con r=70%, CLV ≈
 $26.250; una diferencia de diez puntos en retención cambia materialmente la decisión.
 Conducta del consumidor: mecanismos que compiten
 Las teorías de conducta no son perfiles mutuamente excluyentes. Una misma persona compara
 racionalmente atributos en una compra de alto riesgo, aprende una rutina en una compra habitual y
 elige símbolos de pertenencia en una categoría visible. Para usar una explicación, identifica
 situación, involucramiento, riesgo, experiencia, restricciones y evidencia observable.
 La perspectiva económica destaca alternativas, precios, beneficios y restricciones; es útil para
 modelar trade-offs, pero la información puede ser limitada y preferencias no siempre estables.
Examen de Grado UC | materia, preguntas y respuestas 39

[pág. 40]
Marketing - versión clara y reordenada
 Aprendizaje explica hábitos y respuestas a refuerzo; promociones repetidas pueden enseñar a
 esperar descuento. La perspectiva social explica normas, familia, grupos de referencia y señales de
 identidad; una innovación puede adoptarse para pertenecer o diferenciarse. La perspectiva
 psicológica aborda motivación, percepción selectiva, memoria, actitud y emoción. No uses una
 jerarquía de necesidades como algoritmo de predicción: sirve como lente, requiere evidencia y
 puede simplificar motivaciones diversas.
 Aplicación. Para un producto de compra rutinaria, una caída de recompra puede surgir por
 ausencia en góndola aun si la actitud no cambió. Para un producto durable, búsqueda y riesgo
 percibido pueden pesar más. Para una compra industrial, participan varios roles y criterios formales;
 entrevista al usuario final y al comprador, no asumas que una sola voz representa el centro de
 compra.
 El proceso industrial puede incluir reconocimiento del problema, descripción de necesidad,
 especificación, búsqueda de proveedor, solicitud de propuestas, evaluación/selección, pedido y
 evaluación de desempeño. Distingue recompra rutinaria, recompra modificada y compra nueva:
 cambia el número de actores, riesgo, información y duración. La demanda es derivada de la
 demanda final, aunque en el corto plazo puede responder poco al precio por contratos o criticidad.
 Necesidad, motivación y contexto
 Una necesidad describe una carencia o un resultado buscado; el deseo expresa una forma de
 resolverla influida por experiencia y contexto; la demanda efectiva incorpora disposición y
 capacidad de adquirir. Decir que todos necesitan comodidad no define un mercado útil. Hay que
 identificar una situación, alternativa y beneficio que puedan sostener una elección.
 El apunte presenta miradas económicas, de aprendizaje, psicológicas y sociales. Se emplean como
 lentes que pueden complementarse. La comparación de beneficios y costos puede importar junto
 con hábitos, emociones, identidad e influencia de otros. No se explica toda compra por una sola
 teoría ni se supone que una conducta irracional es cualquier decisión que no maximiza un atributo
 técnico.
 El aprendizaje puede hacer que experiencias y señales orienten elecciones futuras. Una
 experiencia consistente reduce esfuerzo; una falla cambia expectativas. Las motivaciones pueden
 ser funcionales, emocionales o de expresión personal. La jerarquía de necesidades de Maslow que
 aparece en el material ayuda a formular preguntas sobre motivación, pero no se convierte en una
 regla de orden rígido para todas las personas y culturas.
 El involucramiento depende de relevancia, riesgo y situación. Puede haber riesgo financiero,
 funcional, social, físico o de tiempo. Una compra habitual puede volverse importante si el producto
 se usará en una ocasión crítica. La empresa debe entender qué incertidumbre necesita reducir y no
 suponer que un precio bajo elimina todo riesgo.
 Percepción, actitud y conducta
 La atención selectiva limita qué señales se procesan; la interpretación puede depender de
 expectativas y conocimientos; la retención no conserva todo mensaje recibido. Por eso publicar
 información no garantiza comprensión. Un empaque puede comunicar una característica que el
 comprador interpreta de otra manera. Es necesario comprobar qué significado produce, no solo qué
 quiso decir la empresa.
Examen de Grado UC | materia, preguntas y respuestas 40

[pág. 41]
Marketing - versión clara y reordenada
 Una creencia describe lo que una persona considera cierto; una actitud expresa una evaluación
 relativamente estable; una conducta es lo que hace. Pueden divergir por restricciones, hábitos,
 incentivos o falta de disponibilidad. Una encuesta favorable no asegura compra; una compra
 repetida no demuestra preferencia si no hay alternativas. La disonancia posterior puede surgir
 cuando una decisión importante entra en conflicto con dudas o información nueva, pero no aparece
 de la misma forma en toda adquisición.
 La percepción importa para elección y experiencia. Eso no vuelve irrelevante la calidad real. En
 salud, seguridad o desempeño técnico se deben cumplir resultados aunque el consumidor no pueda
 observarlos. La recomendación combina evidencia del beneficio y una comunicación que permita
 comprenderlo.
 Reglas compensatorias y no compensatorias
 Una regla compensatoria permite que una fortaleza compense una debilidad. Ejemplo didáctico:
 una persona pondera precio 40%, confiabilidad 40% y diseño 20%, todos en una escala donde
 mayor es mejor. A obtiene 8,6 y 5; B obtiene 5,9 y 7. El puntaje de A es 0,4×8+0,4×6+0,2×5=6,6; el
 de B es 0,4×5+0,4×9+0,2×7=7,0. Con esa regla preferiría B.
 Una regla no compensatoria puede exigir un mínimo de 7 en confiabilidad. A queda descartado
 aunque tenga mejor precio. Otra regla puede elegir primero por el atributo más importante y usar los
 demás solo para empates. Los datos de elección deben permitir inferir qué mecanismo es plausible.
 No se ajustan ponderaciones después de ver la elección solo para hacerla coincidir.
 En el examen, el procedimiento consiste en identificar alternativas y criterios, aplicar la regla
 indicada y explicar el resultado. Si el caso no entrega pesos o umbrales, se propone qué investigar.
 La forma de presentar opciones puede modificar atención y simplificar comparación, pero debe
 preservar veracidad y capacidad de decisión.
 3. Segmentación, targeting y posicionamiento
 Segmentación, targeting y posicionamiento
 Segmentar es explicar heterogeneidad relevante
 Segmentar divide un mercado en grupos que difieren de manera útil en necesidades, conducta o
 respuesta. Las bases pueden ser geográficas, demográficas, psicográficas, por beneficios, uso,
 ocasión, canal, sensibilidad al precio o etapa de vida. Una variable no forma por sí sola un
 segmento accionable: «jóvenes» puede ocultar necesidades y economía muy distintas.
 Un segmento útil debe poder identificarse y estimarse, tener tamaño o valor suficiente, ser
 accesible, diferenciarse de otros en respuesta y permitir una acción concreta. Estabilidad ayuda a
 ejecutar, aunque las necesidades y segmentos evolucionen.
Examen de Grado UC | materia, preguntas y respuestas 41

[pág. 42]
Marketing - versión clara y reordenada
 Targeting: elegir dónde competir
 Evalúa atractivo del segmento (tamaño, crecimiento, margen, intensidad competitiva, poder del
 canal, riesgo) junto con ajuste estratégico (capacidades, marca, tecnología, datos y costo de servir).
 La cobertura puede ser indiferenciada, diferenciada, concentrada o personalizada. La elección no
 es «segmento más grande»; puede ser un segmento pequeño con necesidad desatendida y ventaja
 defendible.
 Ejemplo de diagnóstico. Un fabricante enfrenta tres grupos: hogares sensibles a precio,
 compradores premium que priorizan conveniencia y restaurantes que exigen formatos grandes y
 despacho estable. Si sus capacidades son marca premium y venta directa digital, el mercado de
 restaurantes puede parecer grande pero exigir logística y servicio que aún no tiene. El targeting
 debe evaluar rentabilidad alcanzable, no tamaño bruto.
 Posicionamiento: significado relativo
 Posicionamiento es el significado distintivo que una oferta busca ocupar para un público frente a
 alternativas. Una frase de trabajo es: «Para [segmento y situación], [marca] es [categoría/marco]
 que ofrece [beneficio relevante], porque [razón verificable para creer]». Los puntos de paridad
 permiten ser considerado dentro de la categoría; los puntos de diferencia entregan una razón de
 preferencia. No basta con afirmar una diferencia: debe ser importante, reconocible, sostenible y
 demostrable.
 La promesa debe traducirse en producto, precio, canal y comunicación. Un servicio que se
 posiciona como rápido necesita inventario y procesos compatibles. Si la experiencia real contradice
 el mensaje, la campaña acelera decepción.
 Prueba de calidad: ¿el segmento reconoce la diferencia?, ¿la valora frente a competidores?, ¿la
 empresa puede sostenerla?, ¿es consistente con precio y canal?, ¿qué evidencia mostraría que el
 posicionamiento está funcionando? Un mapa perceptual describe percepciones observadas; no
 decide por sí mismo dónde debe ubicarse la marca.
 Tres niveles de segmentación
 La segmentación estratégica ayuda a definir en qué mercados competir. La táctica identifica grupos
 con necesidades o respuestas distintas y permite diseñar propuestas. La operacional traduce esas
 decisiones en clientes identificables, contacto y ejecución. Los niveles se conectan: un segmento
 conceptual interesante puede ser difícil de localizar, y una base identificable puede no representar
 una diferencia pertinente de necesidades.
 Las bases geográficas, demográficas, psicográficas y conductuales describen dimensiones
 posibles. La edad puede ayudar a localizar personas, pero no siempre explica la necesidad. La
 ocasión, beneficio buscado, sensibilidad al precio o comportamiento de compra pueden ser más
 útiles. Es necesario comprobar diferencias dentro y entre grupos y la capacidad de responder con
 acciones.
 Un segmento debe ser suficientemente medible, accesible, relevante y diferenciable para la
 decisión, y la empresa debe poder actuar sobre él. Una población numerosa no es
 automáticamente atractiva: puede tener baja contribución o un costo de atención alto. La ausencia
 de competidores tampoco demuestra oportunidad: podría reflejar escasa demanda o barreras. Se
 evalúan tamaño y crecimiento, economía, competencia y capacidades.
Examen de Grado UC | materia, preguntas y respuestas 42

[pág. 43]
Marketing - versión clara y reordenada
 Targeting significa elegir prioridades. Cobertura amplia, diferenciada, concentrada o individualizada
 genera exigencias distintas de variedad, comunicación y operación. Personalizar no equivale
 siempre a mejorar rentabilidad. Se considera valor añadido frente a costo, datos y riesgo. Rechazar
 algunos segmentos puede ser parte de una estrategia coherente.
 Posicionamiento, paridad y diferencia
 El posicionamiento establece para quién es la oferta, en qué contexto compite, qué beneficio
 relevante ofrece y por qué creerlo. Una declaración puede organizar esos elementos, pero no
 sustituye evidencia. «Somos de alta calidad» es insuficiente si el caso requiere elegir una
 dimensión, compararla con alternativas y mostrar cómo se entrega.
 Los puntos de paridad son requisitos para ser considerado o neutralizar una desventaja competitiva.
 Los puntos de diferencia buscan una asociación relevante y distintiva. La diferencia debe importar al
 segmento, ser creíble y poder entregarse; además necesita una forma de comunicación y una
 economía sostenible. Una propiedad única que nadie valora no basta.
 La diferenciación vertical compara mayor o menor desempeño en una dimensión valorada en una
 dirección común; la horizontal responde a preferencias distintas, como sabores o estilos. La
 disposición a pagar y las restricciones pueden hacer que compradores elijan niveles diferentes
 incluso ante una dimensión vertical. Horizontal y vertical no indican aquí ubicación geográfica ni
 integración empresarial.
 Los conflictos percibidos entre atributos pueden limitar credibilidad: una persona puede dudar de
 que una oferta sea a la vez muy barata y durable. No son incompatibilidades físicas universales. Se
 puede demostrar un proceso eficiente, usar pruebas o separar ofertas. Reposicionar exige decidir
 qué asociaciones conservar, cambiar o abandonar. A veces una nueva promesa aprovecha un
 activo; otras puede requerir una marca diferente para no confundir al público.
 De análisis a recomendación
 La secuencia de una respuesta es identificar heterogeneidad y mecanismo de elección; formar y
 evaluar segmentos; escoger el público; definir beneficio y prueba; alinear producto, precio, canal y
 comunicación; establecer ejecución y medición. Se explican también límites: información faltante,
 respuesta de competidores y posibilidad de que la segmentación no sea estable. Enumerar STP sin
 tomar ni justificar decisiones deja el problema sin resolver.
 Base local: resumen completo, pp.11-18 y 35-44; conexiones con shopper pp.19-27, B2B pp.60-65
 e investigación pp.28-34.
 4. Centralidad del cliente y gestión de la relación
 Centralidad del cliente y gestión de la experiencia
 La centralidad del cliente no significa aprobar cualquier solicitud: significa usar información de
 cliente para decidir dentro de restricciones estratégicas y económicas. Requiere cultura de cliente y
 competencia, observación, escucha e investigación, sistemas que integren
 transacciones/interacciones y políticas de personas que permitan entregar la promesa. Si incentivos
 premian solo ventas de corto plazo, atención puede hacer promesas que operaciones no cumple.
Examen de Grado UC | materia, preguntas y respuestas 43

[pág. 44]
Marketing - versión clara y reordenada
 Para mapear experiencia registra etapas, tarea, acción, pensamiento/emoción, canal, fricción,
 recuperación y resultado. Añade evidencia y magnitud: tasa de abandono, duración, reclamo o
 repetición. Después prioriza fricciones por importancia para cliente, frecuencia, costo y capacidad
 de la empresa. Un mapa de viaje sin decisión, responsable y medida queda como ilustración.
 Ejemplo. Una app de supermercado pierde pedidos en pago. El equipo podría atribuirlo a
 publicidad insuficiente; el journey ubica caída en checkout. Compara error por dispositivo, medio de
 pago, costo de despacho y disponibilidad, observa sesiones y entrevista usuarios. Una prueba
 aleatoria de pago simplificado mide pedidos completados y reclamos/fraude como guardarraíles. Si
 conversión sube pero margen cae por cupones no incrementales, la mejora de experiencia debe
 evaluarse junto a economía.
 5. Shopper marketing y recorrido de compra
 Consumidor, comprador y retailer tienen problemas distintos
 Una persona puede disfrutar una marca y comprar otra. Imagina que prefieres una pasta de dientes
 por su sabor, pero quien compra para tu hogar encuentra otra en promoción o no logra encontrar la
 presentación que buscas. El consumidor es quien utiliza el producto; el comprador o shopper decide
 y ejecuta la adquisición; el retailer organiza una oferta comercial y opera el punto de venta. Una
 misma persona puede cumplir los primeros dos roles, pero sus criterios cambian entre usar un
 producto y comprarlo.
 El shopper marketing estudia ese paso desde una necesidad o preferencia hasta una elección
 efectiva. No se limita a decorar una góndola. Busca comprender una misión de compra y facilitar
 una decisión que cree valor para la persona, el distribuidor y el fabricante. El fabricante puede
 perseguir prueba o participación; el distribuidor puede priorizar margen de la categoría, rotación y
 satisfacción; el comprador puede querer resolver una urgencia con poco tiempo. Una exhibición que
 aumenta las ventas de una marca a costa de reducir la rentabilidad total de la categoría puede
 interesar al fabricante y ser poco atractiva para el retailer.
 La colaboración requiere mostrar el beneficio conjunto. Por ejemplo, una zona claramente
 señalizada para alimentos sin gluten puede reducir el esfuerzo de búsqueda, atraer compradores
 que antes abandonaban la tienda y aumentar la venta de una categoría. Para evaluar ese
 mecanismo se necesita medir disponibilidad, conversión, ventas de categoría y contribución,
 además de las ventas de la marca. No basta observar que el producto exhibido vendió más: quizá
 desplazó otro de mayor margen o se benefició de un cambio estacional.
 La misión de compra modifica la importancia de los atributos
 Una misión de abastecimiento suele permitir más planificación y comparación; una reposición busca
 recuperar lo que se agotó; una compra inmediata privilegia cercanía, disponibilidad y rapidez. Son
 categorías útiles para investigar, no identidades permanentes de las personas. El mismo cliente
 puede comparar cuidadosamente precios el sábado y pagar más el martes por resolver una
 urgencia.
 También hay que distinguir compra planificada, recordatorio e impulso. Recordar en la tienda que
 faltaba detergente no equivale necesariamente a adquirir un producto por un deseo surgido en ese
 momento. Las intervenciones cambian: un recordatorio puede funcionar con señalización; un
Examen de Grado UC | materia, preguntas y respuestas 44

[pág. 45]
Marketing - versión clara y reordenada
 producto de impulso puede requerir visibilidad y una ocasión atractiva; una compra planificada
 puede depender principalmente de stock, precio y ubicación. Etiquetar toda compra no planificada
 como impulso pierde ese mecanismo.
 Un insight explica una tensión que ayuda a intervenir. «Mujeres de 35-45 años» describe un grupo.
 «Quiero comprar sano para mi familia, pero las etiquetas me hacen sentir que necesito
 conocimientos técnicos y termino eligiendo lo conocido» propone una explicación. De ella surgen
 hipótesis comprobables: simplificar comparaciones relevantes, aclarar el uso o facilitar una
 selección. Antes de invertir, se investiga si la tensión existe en el segmento y si la solución cambia
 la conducta.
 El recorrido incluye antes, durante y después de la compra. Antes importan necesidad, búsqueda y
 lista; durante, acceso, navegación, comparación y pago; después, uso, devolución, recompra y
 recomendación. Una campaña puede atraer personas y fracasar porque el retiro tarda demasiado.
 La gestión comercial debe localizar la fricción en el recorrido y asignar responsables, en lugar de
 atribuir automáticamente el problema a falta de publicidad.
 Árbol de decisión y experiencia de compra
 El árbol de decisión describe el orden en que un comprador reduce alternativas. En una categoría
 podría elegir primero necesidad, luego formato, marca y precio. En otra, el presupuesto puede
 determinar todo lo demás. El orden debe investigarse con observación, entrevistas, datos de
 elección o experimentos; no se deduce de la estructura organizacional de la empresa. Si el
 comprador busca «para piel sensible», ordenar exclusivamente por fabricante puede dificultar la
 elección.
 Las zonas de transición, destino e impulso ayudan a pensar el espacio. La transición permite
 orientarse; el destino concentra una categoría buscada; una zona de impulso presenta una
 oportunidad adicional. Son hipótesis de diseño que deben adaptarse al local y pueden trasladarse a
 un sitio digital: página de entrada, navegación por necesidad, resultados y complementos
 pertinentes. No hay una cifra universal sobre cuánto decide toda persona dentro de la tienda ni un
 recorrido único válido para todas las categorías.
 El apunte propone evaluar ubicación, transparencia, relevancia, servicio, relaciones y comodidad.
 Para convertir esas dimensiones en diagnóstico, formula preguntas concretas: ¿puedo encontrar lo
 que necesito?, ¿entiendo el precio total?, ¿la oferta responde a mi misión?, ¿recibo ayuda útil?, ¿se
 reconoce mi relación previa?, ¿cuánto esfuerzo exige comprar? Cada respuesta debe vincularse
 con evidencia y una acción. «Mejorar la experiencia» sin identificar una fricción y una medida de
 resultado es una recomendación incompleta.
 Descomponer el crecimiento con PITA
 Una forma de localizar el crecimiento de volumen es separar población, incidencia de compra,
 transacciones por comprador y cantidad por transacción. Definamos, en un mismo mercado y
 período:
 Volumen = población potencial × proporción que compra × transacciones por comprador ×
 unidades por transacción.
Examen de Grado UC | materia, preguntas y respuestas 45

[pág. 46]
Marketing - versión clara y reordenada
 La incidencia debe expresarse como proporción, no como un número de 0 a 100. Las transacciones
 y cantidades necesitan un período común. Si hay 10.000 hogares, el 40% compra, cada hogar
 comprador realiza 3 transacciones al trimestre y compra 2 unidades en cada una, el volumen
 trimestral es 10.000×0,40×3×2=24.000 unidades.
 Supongamos que una intervención eleva la incidencia a 44% y la cantidad a 2,1, manteniendo los
 otros factores. El nuevo volumen es 10.000×0,44×3×2,1=27.720 unidades. El aumento es 15,5%,
 no 15%: los factores se multiplican y existe un efecto conjunto. El aumento de incidencia es 4
 puntos porcentuales, equivalente a 10% respecto de la incidencia inicial; la cantidad crece 5%. Por
 eso 1,10×1,05-1=15,5%.
 Esta identidad organiza preguntas, pero no identifica por sí sola causas. Una promoción puede
 aumentar unidades por transacción hoy y reducir compras del mes siguiente por almacenamiento.
 Hay que observar el horizonte completo y descontar el margen sacrificado. La decisión de
 crecimiento puede perseguir nuevos compradores, más ocasiones o mayor cantidad, y cada vía
 exige una propuesta e intervención distintas.
 Omnicanalidad y respuesta de caso
 Multicanalidad significa operar varios canales. Omnicanalidad busca que la relación y el recorrido
 puedan continuar entre ellos: consultar stock, comprar, retirar, cambiar y recibir atención sin repetir
 todo el proceso. La integración exige inventario, datos y reglas operativas. No obliga a cobrar
 siempre el mismo precio: diferencias de servicio o costos pueden justificar políticas distintas si son
 claras y coherentes con la promesa.
 Una respuesta completa de examen identifica quién compra, con qué misión, en qué etapa se
 pierde la compra y qué evidencia respalda el diagnóstico. Luego propone una intervención, explica
 por qué debería funcionar, considera incentivos del retailer y calcula o define el resultado esperado.
 Finalmente reconoce alternativas: un problema de stock se resuelve de forma distinta de uno de
 comprensión o de una oferta económicamente poco atractiva.
 Base local: resumen completo, pp.19-27; conexiones con conducta de compra pp.11-18 y canales
 pp.82-90. No se incorporan como reglas los porcentajes generales de conducta ni diferencias
 perceptuales por género que el apunte afirma sin evidencia suficiente.
 6. Marca, arquitectura y portafolio
 Marca, producto, portafolio e innovación
 Marca como memoria y reducción de riesgo
 Una marca reúne nombre, señales, experiencias y asociaciones que ayudan a reconocer y evaluar
 una oferta. Equity se expresa en conocimiento, asociaciones, calidad percibida, preferencia, lealtad
 y efectos económicos. Awareness es una condición posible, no prueba de preferencia o
 rentabilidad. Identidad es lo que la empresa busca proyectar; imagen es lo que públicos
 efectivamente perciben.
 La arquitectura ordena marca corporativa, marcas individuales, submarcas y extensiones. Una
 extensión puede transferir confianza y reducir costo de lanzamiento cuando hay ajuste entre
 categorías; también puede diluir significados, confundir al público o canibalizar productos. Evalúa
Examen de Grado UC | materia, preguntas y respuestas 46

[pág. 47]
Marketing - versión clara y reordenada
 ajuste funcional y simbólico, credibilidad, espacio de marca, reacción del canal, costo y resultado
 incremental del portafolio.
 Producto y servicio
 Analiza el beneficio central, la oferta tangible, servicio aumentado, proceso de entrega y
 experiencia. En servicios, variabilidad, inseparabilidad de producción/consumo, capacidad perecible
 e intangibilidad pueden volver central la gestión de personas, procesos y evidencia física. La calidad
 no es solo atributo técnico: incluye confiabilidad, facilidad, respuesta y recuperación de fallas.
 Innovación y ciclo de vida
 La adopción de una novedad depende de ventaja relativa, compatibilidad, complejidad, posibilidad
 de prueba y observabilidad. El ciclo de vida (introducción, crecimiento, madurez y declive) es una
 descripción general, no una ley que permita fechar automáticamente el futuro. Puede haber
 reinvención, nichos y ciclos múltiples. La curva de categoría tampoco predice por sí sola la
 rentabilidad de una marca.
 Un proceso disciplinado formula problema y cliente, genera conceptos, estima atractivo y
 capacidades, prueba el concepto, diseña piloto, define criterios de escalar/detener y evalúa
 aprendizaje. Métricas de avance deben combinar demanda, costo, calidad, repetición,
 disponibilidad y riesgo. Evita medir éxito solo por ventas iniciales subsidiadas.
 Marca, portafolio y crecimiento: análisis de trade-offs
 Equity como mecanismo, no como adjetivo
 Para explicar un resultado de marca, conecta conocimiento con disponibilidad mental, asociaciones
 con evaluación, experiencia con confianza y preferencia con respuesta económica. Una marca
 fuerte puede reducir costo de búsqueda y riesgo, elevar DAP o disminuir elasticidad, pero cada
 efecto depende de segmento y categoría. No afirmes que equity «es alto» solo por notoriedad
 espontánea.
 La extensión a una nueva categoría puede transferir asociaciones de calidad y reducir costos de
 lanzamiento. El mismo movimiento puede confundir asociaciones centrales. Antes de extender,
 pregunta qué significado se transferiría, si la extensión es creíble, qué evidencia o experiencia
 necesita el consumidor, qué ocurre con la marca madre y si la unidad incremental supera
 canibalización. Valora marca por escenario, no por una tabla abstracta de pros y contras.
 Arquitectura y marcas propias
 Una estrategia de marca corporativa concentra reputación y economías de inversión, pero hace que
 fallas de una línea salpiquen a otras. Marcas individuales permiten posicionamientos distintos y
 aislar riesgo, pero duplican gasto y pueden competir entre sí. Submarcas equilibran asociación y
 diferenciación, a costa de complejidad. La arquitectura debe reflejar heterogeneidad de públicos,
 riesgos, canales y capacidades.
 Cuando el distribuidor introduce marca propia, el fabricante compara defender precio, diferenciar
 producto, innovar, cubrir segmentos o cambiar canal. La marca propia del retail no es una amenaza
 única: puede capturar segmentos que valoran precio, mejorar margen del canal y fortalecer
 negociación. Evalúa elasticidad cruzada, diferenciación, espacio de estante, dependencia del
 minorista, salud de categoría y costo de respuesta.
Examen de Grado UC | materia, preguntas y respuestas 47

[pág. 48]
Marketing - versión clara y reordenada
 Portafolio y canibalización
 Una extensión puede vender unidades y aun así reducir valor total si desvía compradores desde
 una oferta existente de mayor contribución. Estima ventas brutas de la nueva oferta, sustitución de
 productos propios, ventas a nuevos clientes, efecto sobre precio/referencia, inversión y costos
 incrementales. La contribución neta es nueva contribución menos contribución desplazada y costos
 adicionales. Separa canibalización planificada (retener clientes ante una alternativa externa) de
 canibalización accidental (erosión sin defensa estratégica).
 Identificar, significar y generar una respuesta diferente
 Una marca permite identificar una oferta y asociarla con experiencias, expectativas y significados.
 Puede reducir incertidumbre, facilitar recuerdo y comunicar pertenencia o calidad. El compromiso
 emocional es una posibilidad, pero una marca puede influir en la elección sin que el consumidor
 sienta amor por ella. Una marca de repuestos puede crear valor principalmente por confianza,
 disponibilidad y reducción del riesgo de una falla.
 El apunte distingue dos miradas. Aaker organiza el patrimonio de marca mediante conocimiento,
 calidad percibida, asociaciones, lealtad y otros activos vinculados con ella. Keller pone el foco en la
 respuesta diferencial que produce el conocimiento de la marca. La conexión es que las
 asociaciones y experiencias pueden cambiar cómo una persona interpreta y responde a una misma
 oferta. Para aplicar ambos enfoques, pregunta qué cambia realmente: consideración, disposición a
 pagar, probabilidad de prueba, recompra o recomendación.
 Conocimiento incluye reconocimiento al ver una señal y recuerdo cuando surge una categoría o
 necesidad. Calidad percibida es una evaluación del cliente, que puede diferir de una medición
 técnica. Asociaciones son vínculos en la memoria: confiabilidad, uso, usuario, personalidad o
 situación. Lealtad puede ser conductual o actitudinal. Repetir una compra por falta de alternativas
 no demuestra un compromiso profundo; declarar afecto sin comprar tampoco asegura ingresos.
 Otros activos, como protección de marca o relaciones del canal, pueden ayudar a sostener el valor,
 pero su relevancia depende del negocio.
 Identidad, imagen y posicionamiento
 La identidad expresa lo que la empresa pretende que la marca represente. La imagen recoge lo que
 las personas efectivamente perciben y asocian. El posicionamiento define la propuesta relativa para
 un público y un contexto competitivo. Los tres deben relacionarse, pero no son sinónimos. Cambiar
 un logotipo modifica una expresión de identidad; no asegura que se modifique la imagen ni que
 exista una razón económica para elegir la oferta.
 Para desarrollar una marca, enlaza atributos con beneficios y consecuencias. «Filtro de tres
 etapas» es un atributo. «Reduce estas impurezas verificadas» es un beneficio funcional. «Me
 permite sentir que protejo a mi familia» puede ser un beneficio emocional. Hay que comprobar la
 conexión y demostrar la afirmación técnica. Una promesa emocional no sustituye la entrega del
 beneficio funcional cuando este es central para el consumidor.
 El apunte conecta visión de marca con insights de categoría, entorno competitivo, atributos,
 beneficios y personas. Su utilidad está en la coherencia. Si una marca promete simplicidad, sus
 formularios, precios, atención y devoluciones deben respaldarla. La ambición de negocio -por
 ejemplo, aumentar la contribución de un segmento- debe transformarse en una tarea de marca
Examen de Grado UC | materia, preguntas y respuestas 48

[pág. 49]
Marketing - versión clara y reordenada
 concreta: ganar consideración en una ocasión, reducir una asociación negativa o demostrar una
 ventaja creíble. No se debe usar «fortalecer la marca» como objetivo sin medida y sin conducta
 esperada.
 Arquitectura: compartir confianza y compartir riesgo
 La arquitectura establece cómo se relacionan la marca corporativa y las marcas de productos o
 negocios. En una casa de marcas o arquitectura tipo holding, las ofertas tienen identidades más
 separadas. Puede facilitar posiciones distintas y contener algunos riesgos reputacionales, a costa
 de invertir en cada marca. En una marca maestra, varias ofertas comparten nombre y asociaciones.
 Puede abaratar el lanzamiento y transferir confianza, pero también transmitir una falla a otras
 categorías. Una estructura asimétrica o híbrida combina vínculos diferentes.
 No hay una arquitectura óptima para toda empresa. Evalúa la similitud de públicos y promesas, el
 patrimonio transferible, el riesgo de conflicto y los costos. Si una empresa conocida por lujo entra en
 una línea de bajo precio, una marca separada puede proteger la señal de exclusividad, pero pierde
 parte de la familiaridad. Una submarca respaldada puede equilibrar ambos efectos, siempre que el
 comprador entienda qué comparte y qué cambia.
 La extensión de línea agrega variantes dentro de una categoría; la extensión de marca introduce la
 marca en otra categoría. Para una bebida, un nuevo sabor puede ser una extensión de línea; usar
 el nombre en un servicio financiero implica otra categoría. La evaluación necesita ajuste percibido y
 capacidad real. Una asociación con precisión puede transferirse entre cámaras y equipos ópticos;
 no se puede asumir que cualquier asociación positiva justifica cualquier expansión.
 El cobranding combina marcas en una oferta. Puede reunir competencias y asociaciones
 complementarias, pero también crea dependencia y riesgo compartido. Una respuesta completa
 indica qué aporta cada socio, para qué segmento, cómo se entrega la promesa y cómo se
 resolverán control, calidad y eventuales conflictos. «Sumar dos marcas fuertes» no demuestra que
 la combinación tenga sentido.
 Valorar la marca y medir su contribución
 El patrimonio de marca basado en consumidores y la valoración financiera de una marca contestan
 preguntas diferentes. Una encuesta puede mostrar reconocimiento y asociaciones; una valoración
 intenta estimar cuánto valor económico es atribuible a la marca. El diagrama histórico de Interbrand
 incluido en el apunte combina proyección financiera, rol de la marca y fortaleza asociada con riesgo.
 Se presenta aquí como la lógica del material local, no como una descripción verificada de su
 metodología vigente.
 Un ejemplo didáctico ilustra el mecanismo. Si el beneficio económico atribuible al conjunto del
 negocio es 100 anuales y se estima que 30% depende del rol de la marca, el flujo atribuible sería
 30. Si se mantuviera como perpetuidad sin crecimiento y una tasa pertinente fuera 10%, el valor
 sería 30/0,10=300. Si el flujo fuese incierto o transitorio, el cálculo debe cambiar. No se puede
 multiplicar cualquier utilidad contable por un porcentaje intuitivo y presentar el resultado como una
 valoración rigurosa. Se requiere justificar la atribución, horizonte, reinversión y tasa.
 Para gestionar, un tablero puede combinar disponibilidad mental, asociaciones relevantes, prueba,
 repetición, precio relativo y contribución. El reconocimiento alto con compra baja puede reflejar falta
 de distribución, una promesa poco pertinente o un precio incompatible con el valor percibido. La
Examen de Grado UC | materia, preguntas y respuestas 49

[pág. 50]
Marketing - versión clara y reordenada
 interpretación depende de los datos del caso. Una métrica aislada no demuestra ni salud ni daño de
 marca.
 Portafolio, complejidad y canibalización
 La amplitud del portafolio cuenta líneas; la longitud cuenta el total de productos o ítems según la
 definición adoptada; la profundidad describe variantes dentro de una línea o producto. Es necesario
 declarar qué se está contando. Una empresa con 2 líneas y 3 variantes por línea tiene 6 variantes
 totales; confundir esas dimensiones impide evaluar complejidad de inventario y cobertura de
 necesidades.
 La matriz BCG cruza crecimiento del mercado con participación relativa. La participación relativa
 exige un denominador explícito, normalmente el rival de referencia, y la definición del mercado. Un
 negocio con 40% frente al líder con 50% tiene una participación relativa de 0,8. No basta que la
 cuota absoluta parezca alta. Los cuadrantes sugieren preguntas sobre inversión y flujo; no ordenan
 automáticamente vender todo negocio con poca cuota. Puede haber complementariedades, nichos
 rentables, barreras o transiciones.
 La canibalización compara con lo que habría ocurrido sin el nuevo producto. Ejemplo didáctico: una
 variante nueva vende 1.000 unidades con contribución 3 por unidad;400 ventas reemplazan una
 variante antigua que habría aportado 2 por unidad. Si hay un costo incremental fijo de 1.000, el
 efecto es 1.000×3-400×2-1.000=1.200. El lanzamiento mejora el resultado bajo esos supuestos. Si
 los clientes antiguos habrían migrado a un competidor de todos modos, el costo de canibalización
 sería menor; si se necesitan gastos adicionales de inventario o canal, debe incluirlos. El crecimiento
 de ventas no resuelve la evaluación.
 Base local: resumen completo, pp.40-59, con inspección de diagramas pp.45-47 y 52-59. La
 pirámide awareness-like-love-loyal de p.46 se trata como una representación del apunte, no como
 una secuencia universal ni como la pirámide CBBE de Keller.
 Ejercicio adicional: aislar el efecto de la marca
 Los resúmenes locales utilizan cuatro dimensiones de Aaker: reconocimiento, calidad percibida,
 asociaciones y lealtad. Se complementan. El reconocimiento facilita entrar al conjunto
 considerado; las asociaciones dan significado; la calidad percibida reduce riesgo y puede sostener
 precio; la lealtad puede favorecer repetición y permanencia. Tener una de ellas no prueba
 automáticamente las otras. Mucha notoriedad puede corresponder a una crisis; una marca pequeña
 puede tener compradores intensivos sin gran penetración; una recompra puede depender de
 disponibilidad y no de afecto.
 Para diagnosticar, vincula cada dimensión con una medición y una decisión. Reconocimiento:
 recordación espontánea y reconocimiento asistido en la población pertinente. Asociaciones: cuáles
 aparecen, su fuerza, favorabilidad y carácter distintivo frente a alternativas. Calidad percibida:
 evaluación de atributos relevantes y credibilidad del desempeño. Lealtad: repetición, retención y
 asignación de compras de categoría, junto con preferencia y razones de permanencia. Luego
 contrasta con efectos económicos: contribución, disposición a pagar, costo de adquisición y
 estabilidad de flujos. Una lista de indicadores no es una valoración financiera de marca.
 Ejercicio de interpretación. En una prueba ciega, 50% elige el producto A; con marca visible, 65%
 lo elige. La diferencia de 15 puntos es evidencia compatible con un efecto de la señal de marca bajo
Examen de Grado UC | materia, preguntas y respuestas 50

[pág. 51]
Marketing - versión clara y reordenada
 ese diseño. No equivale por sí sola a un valor monetario ni demuestra un aumento de ventas en
 tienda. Es necesario controlar orden, muestra, conocimiento y comparabilidad; después observar si
 la preferencia permite mayor precio, conversión o retención y cuánto cuesta sostenerla. El
 rendimiento del producto y la marca pueden contribuir conjuntamente: la frase de un resumen «solo
 la marca diferencia los commodities» no convierte todos los productos en commodities.
 Una extensión se evalúa por ajuste funcional y simbólico, credibilidad y efectos sobre la marca
 madre. Si una marca de confianza entra a una categoría donde esa confianza ayuda pero no tiene
 capacidad técnica, la extensión puede facilitar la prueba y aumentar el daño de una falla. Compara
 marca madre, submarca, marca nueva y asociación con un especialista. Que una propuesta sirva a
 pocos clientes actuales no obliga a rechazarla: puede atraer un segmento nuevo rentable. Que sirva
 a muchos tampoco obliga a aceptarla: importa la contribución incremental, el costo de servir y el
 riesgo para la ventaja existente.
 7. Innovación, prueba y repetición
 La idea inicial debe convertirse en una hipótesis
 Innovar no empieza necesariamente con una tecnología. Puede comenzar con una dificultad del
 consumidor, un costo del canal, una ocasión desatendida o un cambio de hábitos. La idea «usar
 inteligencia artificial» no define por sí sola un beneficio. La hipótesis debe conectar segmento,
 necesidad, solución, razón para creer, forma de entrega y economía del negocio.
 El apunte separa innovaciones centrales, adyacentes y transformadoras. Las centrales mejoran
 negocios existentes; las adyacentes trasladan capacidades a una oportunidad cercana; las
 transformadoras cambian de forma más profunda la oferta o el modelo. La distinción ayuda a
 pensar incertidumbre y recursos. No corresponde asignar una tasa de éxito universal a cada
 categoría ni aprobar automáticamente una iniciativa porque sea transformadora.
 El proceso por etapas y puertas de decisión organiza aprendizaje: idea, evaluación preliminar, caso
 de negocio, desarrollo y preparación del lanzamiento. Una puerta no debe ser una ceremonia. Debe
 establecer evidencia necesaria y criterios para continuar, modificar o detener. En una etapa
 temprana puede importar que la necesidad exista; más adelante, que el producto entregue el
 beneficio y que las personas compren en condiciones realistas.
 Concepto, producto y promesa son pruebas distintas
 La prueba de concepto examina si una descripción de la oferta interesa y se entiende. Una prueba
 de producto evalúa experiencia y desempeño. Una prueba comercial observa conducta con precio,
 disponibilidad y alternativas. Un concepto atractivo puede fracasar por mala experiencia; un
 producto excelente puede no vender por un precio o acceso inadecuados. Usar intención declarada
 como demanda efectiva omite esa cadena.
 La innovación debe comprobar coherencia entre consumidor, tecnología y posicionamiento. Si el
 beneficio prometido es rapidez, las características técnicas y la entrega deben sostenerlo. Si un
 producto incorpora capacidades que encarecen la oferta sin importar al segmento, la superioridad
 técnica puede destruir valor comercial. La investigación debe ayudar a priorizar atributos y también
 reconocer lo que conviene simplificar.
Examen de Grado UC | materia, preguntas y respuestas 51

[pág. 52]
Marketing - versión clara y reordenada
 Separar prueba y repetición
 Una previsión básica de ventas puede separar el primer uso de la compra repetida. Sea H el
 número de hogares alcanzables, t la proporción que prueba, q₀ las unidades en la prueba, r la
 proporción de quienes probaron que vuelve a comprar, f el número de transacciones adicionales
 entre los repetidores y qᵣ las unidades por transacción repetida. Entonces:
 Volumen de prueba = H×t×q₀.
 Volumen de repetición = H×t×r×f×qᵣ.
 Volumen total = H×t×q₀ + H×t×r×f×qᵣ.
 Los períodos deben coincidir y las compras adicionales deben excluir la prueba para evitar doble
 conteo. Ejemplo didáctico:20.000 hogares, prueba 20%, una unidad inicial, repetición 50%,3
 compras adicionales y 2 unidades por compra. La prueba aporta 4.000 unidades; la
 repetición,20.000×0,20×0,50×3×2=12.000. El total es 16.000 unidades. Una promoción puede
 aumentar t y reducir r si atrae personas poco interesadas en el producto; conviene evaluar ambos
 cambios.
 El diagrama de p.56 del resumen contiene una etiqueta repetida de tasa de prueba dentro del
 componente de repetición. Aquí se utiliza la probabilidad condicional de repetir entre quienes
 probaron. No se copia la etiqueta ambigua, porque llevaría a aplicar dos veces la tasa incorrecta.
 Ciclo de vida y difusión requieren juicio
 Introducción, crecimiento, madurez y declinación ayudan a describir una trayectoria, pero no todo
 producto sigue la misma curva. Es necesario definir si se habla de una categoría, una tecnología,
 una marca o una presentación. Una marca puede crecer dentro de una categoría madura; una
 categoría puede estabilizarse mientras cambian sus empresas líderes.
 La matriz BCG y el ciclo de vida no son equivalentes. Una categoría en crecimiento no asegura alta
 participación relativa de una marca, y un producto maduro puede ser rentable con baja
 participación. El gráfico del apunte que empareja ambos esquemas se utiliza solo como una
 ilustración posible, no como identidad conceptual.
 El paso de compradores tempranos a una mayoría pragmática puede exigir nuevas pruebas,
 servicio y reducción del riesgo. Ese es el problema comercial que ayuda a pensar el esquema de
 cruzar el abismo. No establece que todo lanzamiento atraviese una discontinuidad idéntica. Para
 decidir, identifica qué barrera cambia: confianza, compatibilidad, costo total, habilidades, canales o
 redes de usuarios.
 Defender un lanzamiento en el examen
 Una respuesta debe explicitar la oportunidad y el segmento; describir el beneficio y su evidencia;
 estimar prueba, repetición y contribución; considerar canibalización y reacción del canal; proponer
 un lanzamiento con indicadores y criterios de ajuste. El estudiante demuestra dominio al distinguir
 una hipótesis de una conclusión y al indicar qué dato adicional modificaría su recomendación.
 Base local: resumen completo, pp.52-59; conexiones con investigación pp.28-34 y marca pp.45-51.
 Los modelos estadísticos de adopción y elección se desarrollan en Marketing Analytics.
Examen de Grado UC | materia, preguntas y respuestas 52

[pág. 53]
Marketing - versión clara y reordenada
 8. Marketing industrial y decisiones B2B
 Por qué cambia el problema comercial
 En B2B el comprador adquiere un insumo, servicio o activo para operar, producir o servir a otros.
 Parte de la demanda puede ser derivada de la demanda final: si aumenta la construcción, puede
 crecer la necesidad de materiales. Ese vínculo no significa que todo mercado industrial sea poco
 sensible al precio. La respuesta depende de sustitutos, contratos, horizonte, capacidad y de cuánto
 representa el insumo en el costo o valor de la producción.
 Los mercados B2B pueden tener pocos compradores grandes, negociaciones prolongadas y
 soluciones complejas. Sin embargo, hay compras industriales rutinarias, numerosos clientes
 pequeños y productos estandarizados. En el examen deben usarse los rasgos que muestra el caso.
 «Es B2B, por tanto importa solo el precio y no hay emociones» es una inferencia equivocada: las
 personas siguen considerando confianza, reputación, riesgos para su carrera y relaciones.
 El centro de compra y sus criterios
 El centro de compra reúne roles que influyen en la decisión. Los usuarios evalúan funcionamiento;
 los influenciadores aportan especificaciones o conocimiento; quienes deciden eligen; quienes
 aprueban autorizan; compras gestiona la transacción. Una persona puede ocupar varios roles. La
 tarea comercial es entender cómo se distribuyen criterios y poder, no enviar el mismo argumento a
 todos.
 Imagina la venta de un equipo de diagnóstico. El usuario puede priorizar precisión y facilidad de
 uso; tecnología, compatibilidad y seguridad; finanzas, costo total; compras, condiciones y
 cumplimiento; la dirección, continuidad operacional. Una propuesta que solo destaca el descuento
 puede no resolver la objeción técnica que bloquea la aprobación. La comunicación necesita
 evidencia pertinente para cada rol y consistencia entre promesas.
 El apunte distingue compra nueva, recompra modificada y recompra directa. Una compra nueva
 requiere más búsqueda y aprendizaje; una recompra modificada revisa alguna condición; una
 recompra directa repite una solución aceptada. Son situaciones, no etapas que toda compra recorre
 obligatoriamente. Si un cliente está satisfecho con su proveedor, entrar exige demostrar por qué
 merece asumir un costo de cambio.
 Proceso y propuesta de valor
 El proceso puede incluir reconocer el problema, describir necesidades, especificar el producto,
 buscar proveedores, solicitar propuestas, seleccionar, acordar la rutina y evaluar desempeño. La
 empresa vendedora debe conocer la etapa para ofrecer el soporte correcto. Presentar una
 cotización antes de definir necesidades puede convertir la solución en una comparación de precios
 incompleta. Por el contrario, insistir en un diagnóstico extenso para una reposición simple puede
 elevar costos sin aportar valor.
 Una propuesta B2B sólida muestra consecuencias operativas y económicas. El costo total de
 propiedad incluye adquisición, instalación, capacitación, operación, mantenimiento, fallas y eventual
 salida, dentro de un horizonte definido. No todo componente debe inventarse: se solicita o explicita
 como supuesto. La diferencia frente a una alternativa puede justificar un mayor precio inicial si
Examen de Grado UC | materia, preguntas y respuestas 53

[pág. 54]
Marketing - versión clara y reordenada
 reduce costos o riesgos relevantes.
 Ejemplo didáctico: dos equipos duran 3 años. A cuesta 100 y requiere 40 de operación anual; B
 cuesta 140 y requiere 20. Sin descuento, A cuesta 220 y B200. Con tasa 10% y pagos operativos al
 final de cada año, el factor de anualidad es 1/1,10+1/1,10²+1/1,10³≈2,48685. El costo presente de A
 es 100+40×2,48685=199,47; el de B,140+20×2,48685=189,74. B ahorra 9,73 de valor presente.
 Eso no significa que su precio máximo sea infinito: frente a A, con la misma tasa y los demás
 supuestos, podría costar 149,74 para igualar el costo presente. La liquidez, incertidumbre del ahorro
 o capacidad de financiamiento pueden cambiar la preferencia.
 La fuerza comercial debe demostrar el ahorro con datos comparables. Si promete una reducción de
 fallas, necesita describir línea base, condiciones y medición. Una referencia de otro cliente puede
 ayudar, pero no garantiza que el nuevo contexto sea idéntico. Conviene separar beneficio técnico,
 percepción de confianza y mecanismo económico.
 Segmentación y relación
 La segmentación industrial puede usar industria, tamaño, tecnología, necesidades operativas,
 procedimiento de compra, aplicación o situación. Segmentar por industria permite especialización
 vertical; vender una solución común a varias industrias permite una estrategia horizontal. Aquí
 vertical y horizontal describen cobertura de mercados, no integración de la cadena de valor.
 La elección del segmento debe considerar valor potencial y capacidad para atenderlo. Un contrato
 grande puede requerir adaptación costosa, capital de trabajo y riesgo de concentración. Un cliente
 pequeño puede ser atractivo con una oferta estandarizada de bajo costo de atención. La evaluación
 necesita contribución y recursos, además de facturación.
 La gestión de leads identifica oportunidades y acompaña su avance. Un contacto no es
 automáticamente una oportunidad calificada; una oportunidad no es una venta. La información del
 CRM debe registrar necesidad, autoridad de decisión, etapa, restricciones y próximo paso.
 Nurturing significa aportar información útil y mantener relación mientras madura la decisión.
 Presionar por una firma cuando falta una validación crítica puede dañar la confianza y generar
 promesas inviables.
 Recomendación completa
 En un caso B2B, define organización compradora, aplicación y centro de compra; identifica tipo y
 etapa de adquisición; cuantifica beneficios y costo total; diseña propuesta y evidencia para cada rol;
 evalúa capacidad de cumplimiento y riesgos contractuales. Luego propone cómo se verificará el
 desempeño. La distinción académica está en explicar por qué esa estrategia resuelve la decisión
 organizacional y cómo sostiene resultados para ambas partes.
 Base local: resumen completo, pp.60-65; conexiones con segmentación pp.35-39, precio pp.71-81
 y ventas pp.91-94.
Examen de Grado UC | materia, preguntas y respuestas 54

[pág. 55]
Marketing - versión clara y reordenada
 9. Servicios, calidad y recuperación
 Qué hace particular a un servicio
 Un servicio consiste en una prestación o experiencia que crea valor; no siempre transfiere
 propiedad de un bien. Sus características frecuentes ayudan a localizar dificultades. La
 intangibilidad hace que antes de comprar sea más difícil examinar el resultado. La heterogeneidad
 significa que la entrega puede variar entre personas, momentos y situaciones. La simultaneidad de
 producción y consumo hace que el cliente participe en parte del proceso. La perecibilidad implica
 que una unidad de capacidad no utilizada hoy -una hora de atención, por ejemplo- no
 necesariamente puede venderse mañana.
 Estas características admiten matices. Un servicio digital puede entregar información reproducible;
 una atención a distancia separa ubicación; un protocolo puede reducir variabilidad. La capacidad
 temporal de un profesional sigue pudiendo perecer aunque el informe producido se almacene. La
 aplicación exige indicar qué componente presenta el problema y qué consecuencia tiene para la
 gestión.
 Los atributos de búsqueda se pueden evaluar antes de comprar; los de experiencia se juzgan al
 usar; los de credibilidad siguen siendo difíciles de evaluar incluso después. En una reparación, el
 cliente puede observar plazo y trato, pero no saber si el diagnóstico técnico era necesario. Esto
 aumenta la importancia de evidencia, garantías, transparencia y confianza. No autoriza a manipular
 la asimetría de información.
 Tres relaciones deben sostener la misma promesa
 El triángulo de servicios conecta empresa, empleados y clientes. El marketing externo formula la
 promesa. El marketing interno prepara las condiciones para cumplirla. El marketing interactivo
 ocurre en la entrega. Si una empresa anuncia atención inmediata pero no ajusta dotación ni
 capacidad, la publicidad eleva expectativas y amplía la brecha de servicio.
 La preparación interna incluye competencias, herramientas, reglas, incentivos y coordinación. Pedir
 amabilidad al personal no resuelve un sistema que exige cerrar cada atención antes de comprender
 el problema. Tampoco basta aumentar dotación si la causa de la demora es una autorización
 centralizada. Marketing, operaciones y dirección de personas deben actuar sobre el proceso real.
 Las cinco brechas y su diagnóstico
 La primera brecha separa lo que espera el cliente de lo que la dirección cree que espera. Se reduce
 con investigación, escucha y contacto con situaciones reales. La segunda separa esa comprensión
 del diseño y estándares: la empresa sabe que importa la rapidez, pero no define plazo ni recursos.
 La tercera aparece entre estándar y entrega: existe un protocolo, pero faltan entrenamiento,
 herramientas o coordinación. La cuarta separa entrega y comunicación externa: se promete más de
 lo que puede cumplirse. La quinta es la diferencia entre expectativas y percepción del cliente;
 recoge el resultado de las anteriores y de otros factores que deben investigarse.
 Supongamos que una clínica promete resultados en 24 horas. Las entrevistas muestran que los
 pacientes esperan 24 horas corridas, mientras la dirección interpreta un día hábil: hay una brecha
 de comprensión. Si no existe un responsable de validar resultados, hay una brecha de diseño. Si el
Examen de Grado UC | materia, preguntas y respuestas 55

[pág. 56]
Marketing - versión clara y reordenada
 procedimiento está definido pero el sistema falla, hay una brecha de ejecución. Si la publicidad
 sigue prometiendo 24 horas aunque ciertos exámenes tardan 72, hay una brecha de comunicación.
 Cada causa exige una acción distinta. «Capacitar al personal» como solución única no aborda todo
 el problema.
 No todas las diferencias prueban que el servicio sea malo en términos técnicos. Una experiencia
 clínicamente correcta puede ser percibida como incierta por falta de información. La solución puede
 mejorar comunicación sin rebajar el estándar técnico. También puede suceder que una experiencia
 agradable oculte un problema de calidad; por eso la percepción debe complementarse con
 indicadores del resultado.
 Calidad percibida y zona de tolerancia
 El material organiza la calidad en confiabilidad, seguridad o confianza, elementos tangibles,
 empatía y capacidad de respuesta. Confiabilidad significa cumplir de forma consistente; seguridad
 recoge competencia y confianza; tangibles son señales visibles; empatía implica comprender y
 atender circunstancias; respuesta es disposición y oportunidad para ayudar. Ninguna dimensión se
 reduce a «ser simpático».
 El servicio deseado es el nivel que el cliente quisiera recibir. El adecuado es el mínimo aceptable.
 Entre ambos existe una zona de tolerancia que puede variar por dimensión, urgencia, alternativas y
 promesas previas. Una persona puede tolerar una sala de espera sencilla y no tolerar un error en el
 diagnóstico. No se debe promediar todo y concluir que una falla crítica se compensa con una mejor
 decoración.
 La matriz importancia-desempeño ayuda a priorizar: dimensiones importantes y de bajo desempeño
 sugieren investigar mejoras; las importantes y bien evaluadas requieren sostenerlas. El gráfico no
 determina automáticamente la inversión óptima. Importancia declarada, costo, interdependencias y
 umbrales críticos pueden cambiar la decisión. Quitar un atributo «poco importante» podría afectar
 seguridad o cumplimiento aunque los clientes no lo mencionen.
 Capacidad, variabilidad y recuperación
 La perecibilidad y la variación de demanda obligan a coordinar capacidad y promesa. Citas,
 preparación previa, autoservicio pertinente, distribución de horarios y gestión de ausencias pueden
 reducir presión. Una promoción en horas punta puede empeorar la experiencia si atrae demanda
 que no se puede atender. Una oferta en horarios de baja utilización puede crear valor si el costo
 incremental y la disposición del segmento lo permiten.
 Hay que medir más que el promedio. Si la espera media es 15 minutos, pero una parte de los
 pacientes espera 90, la dispersión puede explicar reclamos. Un indicador de percentil 90 muestra el
 tiempo dentro del cual se atiende al 90% de los casos. Se puede seguir también cumplimiento de
 promesa, resolución en primer contacto, errores, reincidencia y abandono. Cada indicador necesita
 definición y período.
 La recuperación del servicio incluye reconocer el problema, escuchar, resolver lo posible,
 comunicar plazo y corregir causas. Una compensación puede ayudar, pero no sustituye la solución
 ni garantiza mayor lealtad que si no hubiese ocurrido una falla. Prometer demasiado para calmar al
 cliente puede generar una segunda decepción. El aprendizaje requiere clasificar incidentes y
 verificar que las acciones reduzcan repetición.
Examen de Grado UC | materia, preguntas y respuestas 56

[pág. 57]
Marketing - versión clara y reordenada
 Relacionar calidad con economía
 La calidad puede afectar retención, frecuencia, precio aceptado, recomendación y costo de
 atención. Son mecanismos posibles, no ganancias automáticas. Ejemplo didáctico: una mejora
 cuesta 10 millones anuales y evita 200 deserciones que habrían eliminado una contribución de
 80.000 pesos por cliente en el mismo año. La contribución preservada es 16 millones; el beneficio
 neto anual sería 6 millones bajo ese contrafactual. Si solo la mitad de la retención es atribuible a la
 intervención, el beneficio es 8 millones y el costo excede ese ahorro en 2 millones. La atribución
 cambia la decisión.
 El caso exige además mirar futuras contribuciones, capacidad y efectos de reputación si existen
 datos para justificarlos. No se asigna un valor inventado a cada recomendación. Se propone cómo
 medirlo o se expresa como incertidumbre. Una respuesta distinguida integra experiencia, ejecución
 y economía, y no promete que cualquier mejora de satisfacción eleva siempre las utilidades.
 Base local: resumen completo, pp.66-70. La página 66 tiene contenido impreso que no quedó en la
 extracción digital; se revisó visualmente junto con los diagramas pp.67-70. Sus estadísticas
 históricas no se presentan como cifras actuales.
 Caso adicional de diagnóstico de servicio
 Un servicio puede evaluarse por el resultado y por la manera de obtenerlo. Una clínica puede
 resolver correctamente un problema médico y aun así generar una mala experiencia por esperas,
 instrucciones incomprensibles o trato distante. Una experiencia amable tampoco compensa un
 resultado defectuoso. El diagnóstico debe separar ambas dimensiones y localizar la falla dentro del
 recorrido del cliente.
 Los resúmenes de Maca Azolas y las notas de Daniel Molina distinguen tres vínculos. El marketing
 externo comunica y hace una promesa al cliente. El marketing interno prepara a las personas
 mediante selección, formación, herramientas, incentivos y capacidad de resolver problemas. El
 marketing interactivo ocurre durante la prestación: la persona que atiende cumple, adapta o
 incumple la promesa. Una campaña que ofrece respuesta inmediata fracasa si el equipo no tiene
 inventario, autoridad o información. Estos vínculos conectan Marketing con Dirección de Personas,
 sin reducir el problema a «capacitar al personal» cuando la restricción es de procesos o recursos.
 Las dimensiones de calidad presentes en los apuntes son tangibles, confiabilidad, capacidad de
 respuesta, seguridad y empatía. Tangibles son las señales físicas y digitales que permiten inferir
 calidad: instalaciones, claridad de una interfaz, orden o presentación. Confiabilidad significa cumplir
 bien lo prometido. Respuesta se refiere a disponibilidad y prontitud para ayudar. Seguridad incluye
 conocimiento, credibilidad y confianza transmitida. Empatía implica comprender la situación
 particular del cliente. No son cinco objetivos independientes: una atención rápida que falla en
 exactitud puede deteriorar la confianza, y una atención muy personalizada puede elevar tiempos de
 espera de otros usuarios.
 Caso resuelto. Un servicio de despacho promete entrega al día siguiente. La encuesta arroja
 buena amabilidad, pero baja satisfacción y reclamaciones por atraso. Primero distingue expectativa,
 fecha prometida, entrega efectiva, aviso de cambios y solución. Si el equipo acepta pedidos sin
 revisar capacidad, el origen está antes del contacto final. La propuesta es calcular capacidad por
 zona, ajustar la promesa, entregar seguimiento y facultar una recuperación proporcional cuando se
Examen de Grado UC | materia, preguntas y respuestas 57

[pág. 58]
Marketing - versión clara y reordenada
 incumple. Mide cumplimiento de fecha, tiempo hasta resolución, repetición de la falla, costo de
 recuperación y recompra. Una mejora de satisfacción se evalúa junto con contribución; regalar
 compensaciones ilimitadas puede comprar satisfacción y destruir la rentabilidad del servicio.
 La capacidad perecible exige gestionar el tiempo. Una hora disponible de un profesional que no se
 utiliza no se almacena para mañana. Reservas, previsión, turnos y precios por horario pueden
 equilibrar demanda y capacidad; también pueden generar costos de espera, cancelación o equidad.
 El análisis compara margen incremental con capacidad, confianza y transparencia. La variabilidad
 se reduce con protocolos y herramientas, pero se conserva flexibilidad donde el cliente necesita
 adaptación. Un protocolo es un apoyo para cumplir la promesa, no una razón para ignorar una
 necesidad legítima.
 10. Precio, contribución y modelos de ingreso
 Precio: convertir valor en ingresos sostenibles
 Precio y disposición a pagar
 El precio es ingreso unitario para la empresa y costo monetario para el cliente. También comunica
 calidad y posicionamiento, afecta referencia, demanda y margen, y puede redistribuir valor a través
 del canal. Disposición a pagar (DAP) es heterogénea: una media puede esconder grupos que
 valoran atributos distintos.
 La elasticidad precio propia es (ε=(%ΔQ)/(%ΔP)). Habitualmente es negativa. Si |ε|>1, demanda es
 elástica: el cambio porcentual en cantidad supera al cambio porcentual en precio; si |ε|<1, es
 inelástica localmente. La elasticidad depende de periodo, segmento, sustitutos, marca,
 disponibilidad y método de medición.
 Precio, contribución y volumen de equilibrio
 Con precio inicial p, costo variable v y volumen Q, contribución inicial es Q(p-v). Si se cambia el
 precio a p' sin variar costo, el volumen requerido para conservar contribución es:
 Q' = Q × (p-v)/(p'-v)
 Ejemplo paso a paso. Precio $10.000, costo variable $6.000, volumen 1.000: contribución =
 $4.000.000. Se propone bajar precio a $9.000. Nueva contribución unitaria = $3.000; para
 conservar $4 millones se requieren 1.333,3 unidades, es decir, al menos 1.334. La caída de precio
 de 10% exige crecimiento de volumen de 33,4%. Si la promoción no puede generar ese aumento
 incremental, destruye contribución.
 La regla de Lerner bajo maximización de utilidad, demanda diferenciable y costo marginal estable
 conecta markup con elasticidad: ((p-c)/p=-1/ε). Es una referencia teórica; una empresa real enfrenta
 costos fijos, competencia, restricciones, referencias y decisiones multiproducto.
Examen de Grado UC | materia, preguntas y respuestas 58

[pág. 59]
Marketing - versión clara y reordenada
 Estrategias, discriminación y plataformas
 Precio basado en costo fija un piso económico; basado en valor parte del beneficio diferencial y
 DAP; basado en competencia responde a alternativas. Ninguno debe aplicarse aislado. Precios
 segmentados requieren identificar grupos, limitar arbitraje, justificar diferencias y cumplir reglas
 aplicables. En plataformas se analiza el precio total entre lados y las externalidades: cobrar poco a
 un lado puede elevar valor del otro. Surge pricing necesita capacidad, demanda, transparencia y
 evaluación de confianza/reputación, no solo algoritmo.
 Precio y promociones: procedimiento completo para el grado
 Árbol de decisión de precio
 Primero define objetivo (margen, entrada, volumen, inventario, retención, posicionamiento).
 Después identifica segmento y alternativa de referencia; estima valor/DAP y sensibilidad; define
 restricciones de costo, canal y regulación; pronostica demanda con incertidumbre; compara
 contribución total, respuesta competitiva y efectos de largo plazo. Finalmente selecciona
 precio/lista/promoción, prueba, monitorea y actualiza.
 Una promoción temporal puede adelantar compras (stockpiling), cambiar mezcla, atraer nuevos
 clientes o solo subsidiar compras que habrían ocurrido. Para calcular lift incremental usa
 contrafactual, no ventas durante la promoción contra período base sin ajustar estacionalidad.
 Revisa margen después de descuento, costo de exhibición, canibalización entre SKU,
 canibalización entre semanas y referencia futura.
 Separar ingreso, margen y participación
 Un precio menor puede elevar unidades e ingreso, pero bajar margen. Para dos escenarios calcula
 por separado: ingreso (pQ), costo variable (vQ), contribución ((p-v)Q), costos comerciales y margen
 de portafolio. Si hay costo fijo diferente, agrégalo al final. Evalúa elasticidad cruzada cuando hay
 sustitutos cercanos y elasticidad por segmento; el promedio puede ocultar quién cambia realmente.
 Caso de Distinción. Un fabricante propone descuentos porque el volumen cae. La respuesta
 rigurosa pide base de comparación y si hay stockouts. Calcula volumen de equilibrio tras el
 descuento; modela mezcla y canibalización; identifica segmentos cuyo precio de referencia cambió;
 evalúa si promoción permanente daña posicionamiento. Si la hipótesis es disponibilidad, descuento
 puede empeorar el margen sin corregir la causa. Recomienda prueba por tiendas/zonas o período
 con control, criterio de rentabilidad y guardarraíl de repetición.
 Plataformas y precio total
 En una plataforma de dos lados, demanda de compradores depende de cantidad/calidad de
 vendedores y viceversa. El subsidio de un lado puede crear valor de red, pero debe contabilizarse
 el costo de adquirirlo y el valor capturado en el otro lado. La pregunta correcta no es «¿el precio de
 este lado cubre su costo?», sino «¿la estructura y nivel conjunto generan participación y margen
 sostenibles?» Evalúa multi-homing (usar varias plataformas), costos de cambio, exclusividad,
 congestión y confianza.
Examen de Grado UC | materia, preguntas y respuestas 59

[pág. 60]
Marketing - versión clara y reordenada
 El precio observado no es la disposición a pagar
 El precio es una condición de intercambio. La disposición a pagar es el máximo que una persona
 aceptaría en una situación definida, considerando alternativas y restricciones. El valor económico
 frente a una alternativa puede estimarse por costos ahorrados y beneficios diferenciadores; el valor
 percibido depende de qué entiende y cree el comprador. No son cantidades intercambiables. Una
 persona puede no reconocer un ahorro real, o valorar una consecuencia que no se expresa solo en
 costos monetarios.
 El costo para el cliente incluye dinero, tiempo, esfuerzo y riesgo. Una compra de menor precio
 puede ser más costosa si requiere transporte, instalación o genera incertidumbre. La comparación
 debe usar el mismo horizonte y alcance. Un precio de suscripción mensual no se compara
 directamente con una compra de equipo de cinco años sin ajustar uso y duración.
 Cinco perspectivas para decidir
 El costo indica restricciones económicas, pero asignar un porcentaje a un costo arbitrario no
 identifica lo que el mercado acepta. La demanda y el valor percibido muestran respuesta del cliente.
 La competencia proporciona alternativas, aunque copiar el precio puede copiar también una
 economía distinta. El canal exige repartir incentivos y márgenes. La capacidad y los objetivos de la
 empresa completan la evaluación.
 Hay que separar decisiones de corto y largo plazo. Si una venta adicional utiliza capacidad ociosa y
 no afecta otras ventas, su costo incremental puede ser menor que el costo promedio contable. Si
 desplaza un cliente rentable en un horario limitado, existe costo de oportunidad. En el largo plazo
 deben cubrirse recursos y reinversiones necesarios para sostener la oferta. «Nunca vender bajo
 costo promedio» y «todo ingreso sobre costo variable es bueno» son reglas incompletas sin
 horizonte y restricciones.
 El margen sobre ventas es(precio-costo)/precio; el recargo sobre costo es(precio-costo)/costo. Con
 costo 80 y precio 100, el margen es 20% y el recargo 25%. Para lograr 25% de margen sobre
 ventas con costo 80, el precio debe ser 80/(1-0,25)=106,67. Multiplicar 80 por 1,25 da 100 y no
 alcanza el margen objetivo. La definición evita errores tanto en una negociación como en la lectura
 de tablas del examen.
 Elasticidad, ingresos y contribución
 La elasticidad precio mide un cambio porcentual de cantidad respecto del cambio porcentual de
 precio, con las demás condiciones pertinentes. Para una demanda descendente suele ser negativa;
 muchas expresiones comerciales usan su valor absoluto. Una elasticidad de-2 implica que un
 aumento pequeño de 1% de precio se asocia con una caída aproximada de 2% de cantidad en el
 punto estudiado. Es una aproximación local, no una predicción exacta para cualquier cambio
 grande.
 La elasticidad unitaria se relaciona con ingresos en un punto bajo una demanda diferenciable, pero
 no garantiza el máximo de utilidad cuando hay costos. Con demanda Q=1.000-10p y costo variable
 20, la contribución es(p-20)(1.000-10p). Al expandir, queda 1.200p-10p²-20.000. La derivada es
 1.200-20p; el máximo interior se encuentra enp=60 yQ=400. Los ingresos se maximizan enp=50
 yQ=500. La diferencia muestra por qué volumen o ventas no bastan para elegir precio.
Examen de Grado UC | materia, preguntas y respuestas 60

[pág. 61]
Marketing - versión clara y reordenada
 Enp=60, la elasticidad puntual es(dQ/dp)(p/Q)=-10×60/400=-1,5. El margen sobre precio
 es(60-20)/60=2/3, igual a 1/|elasticidad| bajo los supuestos del ejemplo. Esa relación requiere
 demanda y costo marginal pertinentes, decisión interior y ausencia de restricciones adicionales. No
 se aplica mecánicamente cuando hay capacidad, múltiples productos, interacción competitiva o
 costos no capturados.
 Diseñar la forma de cobro
 Cobrar por transacción, uso, licencia, suscripción o resultado distribuye valor y riesgo de forma
 diferente. La suscripción puede facilitar recurrencia e ingresos previsibles, pero genera cancelación
 y exigencia continua de valor. El pago por uso reduce compromiso inicial, pero hace más variable el
 gasto y los ingresos. Una tarifa en dos partes combina cargo fijo y consumo. El gain sharing vincula
 el cobro a un resultado acordado y exige una regla verificable de atribución.
 Freemium ofrece una versión gratuita y una pagada. Su viabilidad depende de conversión,
 contribución de clientes pagados, costo de usuarios gratuitos y costos fijos. Ejemplo
 didáctico:10.000 usuarios; un pagado aporta 8 al mes después de su costo variable y uno gratuito
 cuesta 1. Si la proporción pagada esx, la contribución neta es 10.000[8x-(1-x)]=10.000(9x-1). Antes
 de costos fijos, se necesita x≥1/9≈11,11%. El tamaño de la base gratuita no demuestra viabilidad. El
 valor de red o aprendizaje puede ser relevante, pero debe argumentarse y medirse.
 Bundling reúne componentes; una venta atada obliga a adquirir otro componente como condición.
 No todo paquete crea mayor valor: puede simplificar elección y permitir segmentar, o incluir
 elementos poco útiles y reducir transparencia. En una plataforma hay que considerar ambos lados:
 un cobro menor a un grupo puede atraerlo y aumentar el valor para otro, pero solo si existe el efecto
 de red pertinente.
 Psicología y estrategia sin convertirlas en leyes
 Los precios de referencia, el encuadre, la aversión a pérdidas y la forma de pago pueden afectar
 percepción. El efecto depende de experiencia, contexto y presentación. No se usa como constante
 universal que una pérdida siempre tenga exactamente el doble del efecto de una ganancia, ni que
 un precio alto cree calidad por sí solo. Una señal de prestigio necesita credibilidad y consistencia
 con el producto y segmento.
 El descreme busca captar inicialmente compradores con mayor disposición a pagar; la penetración
 busca adopción con una entrada atractiva. La elección depende de respuesta de demanda,
 economías, aprendizaje, capacidad, competencia y riesgo de comprometer una referencia baja.
 Bajar precio porque «el mercado es elástico» requiere además mostrar que el aumento de
 contribución compensa la pérdida por unidad.
 Los precios dinámicos pueden responder a capacidad perecedera y demanda variable. Deben
 considerar oportunidad, claridad y percepción de trato. Para un inventario con vencimiento, un
 markdown puede reducir pérdida; debe compararse con esperar y con sus efectos sobre compras
 futuras. Una respuesta de caso explica objetivo, datos, política y control, no solo menciona yield
 management.
Examen de Grado UC | materia, preguntas y respuestas 61

[pág. 62]
Marketing - versión clara y reordenada
 Corrección puntual de las afirmaciones legales del apunte
 El resumen reúne conductas comerciales distintas como si todas fueran ilícitas de manera
 automática. Para estudiar se separa el mecanismo económico de su evaluación jurídica. La FNE
 explica que las restricciones verticales se analizan considerando riesgos y eficiencias; una
 exclusividad o condición de distribución no basta por sí sola para concluir ilegalidad. La formulación
 y contexto del caso deben analizarse. Verificación externa puntual,11 de octubre de 2026:
 Fiscalía Nacional Económica, análisis de conductas anticompetitivas.
 Base local: resumen completo, pp.71-81 y pauta Prueba_1_2020-1_(pauta).pdf del mismo ramo
 para la relación entre servicio gratuito y pagado. Las afirmaciones legales generales del resumen no
 se reproducen como reglas.
 11. Canales, retail y fuerza de ventas
 Canales, ventas y distribución
 Los canales resuelven acceso y servicios: surtido, almacenamiento, transporte, financiación,
 negociación, información, instalación o devoluciones. Una decisión de canal compara cobertura,
 experiencia, costo total, control, datos, dependencia, poder negociador y conflicto. La venta directa
 no siempre es superior: puede mejorar datos y control, pero elevar costo y complejidad; un
 intermediario puede ser más eficiente y aportar legitimidad.
 Push incentiva al canal a almacenar/exhibir/vender; pull desarrolla preferencia del comprador y
 demanda hacia el canal. Ambos pueden coexistir. Omnicanalidad requiere continuidad de
 inventario, precio, información, identidad del cliente, servicio y devoluciones entre canales, no solo
 abrir una tienda digital.
 En un caso de integración vertical, compara el margen capturado y control agregado con inversión,
 escala, capacidades, capital de trabajo, riesgo y pérdida de flexibilidad. Pregunta qué actividad
 genera ventaja, quién tiene poder, cómo cambia el costo de servir y qué pasaría si la demanda cae.
 Las funciones del canal no desaparecen
 Un canal conecta oferta y demanda, pero también informa, almacena, transporta, financia, asume
 riesgos, negocia y presta servicio. Eliminar un intermediario puede trasladar esas funciones al
 fabricante o al cliente. La decisión debe comparar costos, control, cobertura y experiencia,
 incluyendo tareas que antes estaban incorporadas en el margen del distribuidor.
 Un canal directo puede mejorar acceso a datos y control, pero exige capacidades e inversión. Un
 distribuidor puede aportar cobertura, surtido y relaciones, y a la vez priorizar otros productos. Un
 agente puede apoyar la transacción sin asumir las mismas funciones de inventario. La etiqueta del
 canal no determina su economía: hay que identificar quién realiza cada tarea y quién asume sus
 costos y riesgos.
 Diseñar el canal comienza por la necesidad de servicio del segmento. Luego se fijan objetivos, se
 definen tareas, se desarrollan alternativas, se comparan variables relevantes, se elige una
 estructura y se seleccionan miembros. El criterio económico compara resultado total; el de control
 evalúa capacidad para sostener promesa y decisiones; el de adaptación considera cambios futuros.
 Una alternativa barata hoy puede ser rígida o incompatible con la experiencia exigida.
Examen de Grado UC | materia, preguntas y respuestas 62

[pág. 63]
Marketing - versión clara y reordenada
 Cobertura, push y pull
 La distribución intensiva busca amplia disponibilidad; la selectiva utiliza un conjunto elegido; la
 exclusiva restringe más la representación en un mercado definido. Se elige considerando producto,
 comportamiento de compra, servicio y control. Un producto de conveniencia puede perder ventas
 por baja disponibilidad; una solución compleja puede requerir intermediarios capaces de instalar y
 atender.
 Push busca movilizar al canal mediante incentivos, soporte o fuerza comercial. Pull estimula
 preferencia y demanda del comprador final. Pueden complementarse: una campaña atrae interés y
 el canal necesita stock y capacidad. Pull no significa necesariamente prescindir de intermediarios.
 Push sin compra final puede llenar el canal, generar devoluciones y ocultar un problema de
 demanda.
 En una franquicia, un tercero opera con una marca y un sistema bajo condiciones acordadas.
 Puede facilitar expansión y aprovechar esfuerzo local, pero exige control de calidad, formación y
 coordinación. El royalty no es todo el beneficio ni garantiza éxito. El análisis debe considerar
 inversión, incentivos, riesgo de incumplimiento y quién decide aspectos de la experiencia.
 Retail: elegir una promesa viable
 El apunte propone distintas prioridades de retail: precio accesible, novedad, amplitud de surtido,
 rapidez o facilidad para resolver una necesidad. No se puede maximizar todo sin analizar costos y
 compensaciones. Un surtido extenso exige inventario y navegación; rapidez puede requerir
 ubicación y dotación; precio bajo necesita eficiencia o una economía que lo financie.
 El gráfico de precio y servicio ayuda a pensar coherencia, pero no prueba que toda combinación de
 precio alto y servicio reducido fracase ni que un precio bajo con buen servicio sea imposible. Una
 operación eficiente puede alterar la relación. Hay que explicar qué atributos valora el segmento y
 cómo se producen al costo necesario.
 Margen y rotación también se complementan. Una venta de gran margen con inventario
 inmovilizado puede generar menos retorno que una de margen reducido y alta rotación. Para
 comparar, define el margen, el período y el capital involucrado. La rentabilidad del canal incluye
 costos de local, personal, logística, devolución, promociones e inventario, no solo diferencia entre
 precio de compra y venta.
 Organización de ventas y gestión de cuentas
 Una fuerza de ventas puede organizarse por territorio, producto, mercado o cuentas clave. El
 territorio reduce desplazamiento y facilita responsabilidad local; la especialización por producto
 aporta conocimiento técnico, pero puede duplicar contactos; la organización por mercado
 comprende necesidades de una industria; las cuentas clave coordinan una relación compleja. Una
 estructura mixta puede combinar beneficios y elevar costos de coordinación. La recomendación
 depende de dispersión, complejidad y valor del cliente.
 Ventas directas permiten mayor control sobre la ejecución, aunque exigen costo fijo y gestión.
 Ventas indirectas pueden ampliar cobertura con menos estructura propia, pero dejan más
 decisiones en terceros. La tabla de p.92 del apunte debe leerse por columnas: la falta de control
 corresponde a la alternativa indirecta, no a toda venta directa. El diseño puede combinar atención
Examen de Grado UC | materia, preguntas y respuestas 63

[pág. 64]
Marketing - versión clara y reordenada
 personal, representantes y medios remotos según la necesidad.
 La matriz de volumen actual y potencial distingue cuentas estratégicas, maduras, pequeñas y en
 desarrollo. Una cuenta de volumen actual alto y poco potencial puede necesitar servicio eficiente y
 defensa; una de poco volumen y alto potencial puede justificar inversión selectiva. Potencial no es
 una cifra deseada por el vendedor: debe estimarse con necesidad, tamaño, acceso y probabilidad
 de ganar. También importa costo de atención y contribución; vender mucho a pérdida no convierte a
 una cuenta en estratégica.
 Calcular dotación sin perder unidades
 La planificación de vendedores compara carga de trabajo y capacidad efectiva. Ejemplo del apunte
 corregido:3.000 clientes necesitan 2 visitas semanales de 10 minutos. Son 6.000 visitas y 60.000
 minutos de atención a la semana. Cada vendedor dispone de 6 horas productivas al día por 5 días,
 es decir 1.800 minutos o 180 visitas semanales. Se necesitan 6.000/180=33,33 vendedores
 equivalentes; para cubrir la carga con personas enteras hay que redondear hacia arriba:34.
 El apunte presenta 33 y una expresión sin paréntesis adecuados. El cálculo debe explicitar si las 6
 horas ya descuentan viaje, administración y otras tareas. Si no lo hacen, se resta ese tiempo; si ya
 lo hacen, descontarlo de nuevo subestima capacidad. La planificación debe considerar además
 variación por clientes, ausencias, prioridades y posibilidad de visitas remotas. Una media puede
 ocultar territorios muy diferentes.
 Incentivos y efectos no deseados
 La remuneración fija protege ingresos y facilita tareas no inmediatamente vendibles; la comisión
 puede vincular esfuerzo con resultados, pero induce decisiones según lo medido. Pagar solo por
 facturación puede incentivar descuentos, clientes riesgosos o ventas que luego se devuelven.
 Pagar solo por margen puede desalentar inversiones de relación cuyo beneficio tarda. Un diseño
 adecuado combina objetivos y reglas verificables con la estrategia y el control del vendedor.
 Por ejemplo, una comisión por ventas al distribuidor puede favorecer cargar inventario sin demanda
 final. Si se añaden devoluciones y cobranza a la medición, cambia el incentivo, pero también el
 riesgo que enfrenta el vendedor por factores fuera de su control. Conviene distinguir venta al canal,
 venta final y calidad de la relación. La supervisión y formación deben acompañar la remuneración.
 Una respuesta de caso presenta una estructura, calcula recursos cuando hay datos, describe
 incentivos y anticipa efectos secundarios. Debe indicar cómo comprobará cobertura, contribución,
 satisfacción y cumplimiento de promesa. El nombre de una estructura o la recomendación de
 «aumentar comisiones» no constituyen una solución completa.
 Base local: resumen completo, pp.82-94; revisión visual de estructuras de canal p.83, matrices
 retail p.88, tabla de alternativas p.92 y gráfico de gestión de cuentas p.94.
Examen de Grado UC | materia, preguntas y respuestas 64

[pág. 65]
Marketing - versión clara y reordenada
 12. Comunicación, planificación y evaluación
 Comunicación, plan de marketing y medición
 Comunicación integrada
 Parte por conducta objetivo y audiencia; después define mensaje, prueba, fuente, medio,
 frecuencia, calendario, presupuesto y medición. Una secuencia posible es exposición, atención,
 comprensión, recuerdo, actitud, prueba, compra y recompra. No es una ley universal y puede haber
 efectos directos, repetición o exposición selectiva.
 Alcance es personas únicas expuestas; frecuencia es exposiciones promedio. GRP = alcance
 porcentual × frecuencia. CPC, CTR, conversión y costo de adquisición tienen denominadores
 distintos; un valor bajo no informa por sí solo si hubo ventas incrementales rentables.
 Plan comercial coherente
 Un plan práctico une diagnóstico, objetivo, público, posicionamiento, oferta, precio, canal,
 comunicación, recursos, riesgos y control. El objetivo debe incluir métrica, población, horizonte y
 nivel deseado. La mezcla comercial no es una lista: precio puede afectar marca, promociones
 afectar referencia, canal afectar datos y experiencia, comunicación elevar demanda en una cadena
 con falta de inventario.
 ROI y causalidad de marketing
 Ingresos atribuidos no equivalen a efecto causado. Personas expuestas pueden comprar más
 porque ya tenían mayor intención. Define retorno como margen incremental contra contrafactual
 menos costo incremental; declara horizonte y costos incluidos. Cuando sea posible, utiliza grupo de
 control, holdout, experimento geográfico o una estrategia cuasiexperimental defendible. Last-click
 sirve para asignar crédito bajo una regla; no identifica por sí solo causalidad.
 Marketing digital, IA y responsabilidad
 RACE (Reach, Act, Convert, Engage) organiza objetivos por etapa; no sustituye el diagnóstico.
 APCEC y marcos de medios propios, pagados y ganados pueden ayudar a generar preguntas.
 Datos digitales pueden tener selección, duplicación, bots, privacidad y errores de clasificación. Para
 IA, define objetivo, calidad/representatividad, daño de falsos positivos y negativos, consentimiento,
 sesgo, deriva, transparencia, revisión humana y monitoreo. Precisión predictiva no demuestra que
 una política sea justa o rentable.
 En responsabilidad y bienestar identifica efectos sobre terceros, vulnerabilidad, accesibilidad,
 externalidades, información engañosa y privacidad. Recomienda indicadores y mecanismos de
 cumplimiento, no una declaración reputacional sin evidencia.
Examen de Grado UC | materia, preguntas y respuestas 65

[pág. 66]
Marketing - versión clara y reordenada
 PARTE II - MARKETING ANALYTICS
 Comunicación: elegir el mecanismo antes que el medio
 Las comunicaciones integradas coordinan publicidad, promoción de ventas, relaciones públicas,
 venta personal y contacto directo para que la promesa sea reconocible y verificable. Una pauta de
 medios responde dónde aparecer; una estrategia de comunicación explica qué conducta se quiere
 cambiar y por qué el mensaje puede cambiarla. Si el obstáculo es desconocimiento, informar puede
 ayudar; si es desconfianza, se necesita evidencia; si es falta de disponibilidad, más comunicación
 puede generar frustración.
 Involucramiento, motivos y modelos de respuesta
 El modelo FCB cruza involucramiento con predominio relativo de procesamiento más racional o
 más afectivo. Su utilidad consiste en formular una hipótesis sobre secuencia de aprendizaje,
 emoción y conducta. Una compra de seguro de alto riesgo requiere comprensión y credibilidad; una
 compra expresiva puede requerir identificación y demostración del significado; una compra rutinaria
 puede depender de memoria, prueba y disponibilidad. La matriz no convierte categorías enteras en
 personas idénticas: situación, experiencia y riesgo cambian cómo decide alguien.
 Rossiter y Percy distinguen conocimiento de marca y actitud hacia ella. Reconocimiento significa
 identificar la marca ante una señal, como verla en góndola; recuerdo significa recuperarla desde
 memoria ante una necesidad. Si la decisión ocurre en tienda, empaque y reconocimiento pueden
 ser cruciales; si primero se arma una lista o se busca un proveedor, el recuerdo puede importar
 más. Tampoco son sustitutos de consideración o elección.
 Los motivos informacionales se relacionan con reducir un problema, riesgo o insatisfacción; los
 transformacionales, con una experiencia positiva, expresión o recompensa. Se combinan con
 involucramiento y riesgo. Para una solución informacional de alto riesgo, muestra mecanismo,
 prueba, garantía y límites; para una experiencia transformacional, muestra una escena creíble y su
 significado para el segmento. Una pieza emocional puede ser útil en ambos casos, pero debe
 apoyar el beneficio y no esconder información que el cliente necesita.
 Caso resuelto. Una clínica quiere aumentar procedimientos electivos. El síntoma es poca
 conversión después de visitas informativas. Si pacientes entienden el tratamiento pero temen
 resultados o recuperación, el objetivo no es elevar impresiones. Se recomienda información clara
 sobre elegibilidad, riesgos, proceso y evidencia, acompañada de conversación profesional y
 expectativas realistas. Se mide comprensión, consultas apropiadas, decisión informada y
 satisfacción posterior. La recomendación respeta que una comunicación efectiva puede terminar en
 una decisión de no contratar: la métrica de éxito no debe inducir tratamientos inadecuados.
 Promoción de ventas y aprendizaje del precio
 Una promoción temporal modifica el incentivo de una conducta concreta. Puede inducir prueba,
 adelantar compra, aumentar cantidad, estimular cambio de marca o desplazar compras entre
 canales. Esos efectos no tienen la misma rentabilidad. Si el cliente habría comprado la próxima
 semana al precio regular, la venta adicional de hoy puede ser solo adelantamiento.
Examen de Grado UC | materia, preguntas y respuestas 66

[pág. 67]
Marketing - versión clara y reordenada
 El condicionamiento ayuda a entender repetición de respuesta ante un estímulo; la atribución, la
 explicación que el cliente construye sobre la promoción; la referencia de precio, la comparación con
 un precio esperado; y la utilidad de transacción, la valoración de «haber conseguido una buena
 oferta», distinta de la utilidad de consumir el producto. Se pueden combinar: promociones
 frecuentes enseñan a esperar descuentos y pueden hacer que el precio regular parezca
 injustificado. No es inevitable que dañen marca: depende de frecuencia, motivo, ejecución y
 segmento.
 Ejercicio. A precio regular se esperaban 1.000 unidades con contribución de $4.000 cada una. La
 promoción vende 1.400 unidades con contribución de $3.000. Si 250 unidades son compras
 adelantadas que reducen ventas posteriores, la contribución de la promoción es $4,2 millones, pero
 se pierden $1 millón de contribución futura frente al contrafactual. Resultado incremental total =
 $4,2 millones - $4 millones - $1 millón = -$800.000, antes de costos de campaña. Contar solo el
 aumento de 400 unidades habría dado una conclusión equivocada. Deben añadirse canibalización,
 costos, compra repetida y cualquier demanda nueva posterior.
 Push, pull y fuerza de ventas
 Push actúa sobre intermediarios y vendedores para que incorporen, abastezcan, exhiban o
 recomienden la oferta. Pull actúa sobre compradores para que busquen o pidan la oferta. Algunas
 notas invierten los nombres; usa el destinatario de la acción para reconocerlos. Un descuento al
 distribuidor es push; una comunicación al consumidor que genera solicitudes en tienda es pull. Una
 campaña puede necesitar ambos: demanda sin inventario pierde ventas, e inventario sin demanda
 aumenta devoluciones.
 Gestionar fuerza de ventas implica definir cuentas, cobertura, tareas, habilidades, metas,
 compensación, seguimiento y coordinación con operaciones. No se evalúa solo volumen facturado:
 margen, cobro, devoluciones, adecuación de la solución, retención y calidad de información pueden
 revelar una venta que destruye valor. Un incentivo sobre sell-in puede inducir sobreinventario en el
 canal; sell-out permite observar compra final, aunque también requiere denominadores y períodos
 comparables.
 Del mensaje a una consecuencia comprobable
 Comunicar requiere definir qué persona debe entender, sentir o hacer algo y por qué el mensaje
 debería modificarlo. El proceso incluye emisor, codificación, mensaje, canal, interpretación, ruido y
 respuesta. Que una pieza se publique no significa que el público la vea; verla no asegura
 comprensión; comprender no implica compra. Cada paso puede fallar por una razón diferente.
 Los modelos AIDA o jerarquías de respuesta ayudan a organizar atención, interés, deseo y acción,
 o conocimiento, actitudes y conducta. No describen una secuencia obligatoria. Una compra de bajo
 riesgo puede ocurrir antes de formar una actitud elaborada; una experiencia puede modificar
 después la percepción. El esquema integrado de Franzen presentado en el apunte conecta
 conocimiento, significado, sentimientos, posición, actitudes, vínculo y conducta. Se usa para pensar
 relaciones y retroalimentación, sin presentarlo como una ley causal demostrada para toda
 categoría.
 El involucramiento y la motivación ayudan a elegir mecanismo. Una decisión de riesgo alto puede
 exigir pruebas y explicación; una de gratificación inmediata puede beneficiarse de experiencia e
 imaginación. La comunicación informativa demuestra utilidad o evita un problema; la
Examen de Grado UC | materia, preguntas y respuestas 67

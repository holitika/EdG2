# Manual de Marketing · parte 3 (páginas 126-182)

Fuente: 01_MANUAL_ULTIMATE_MARKETING_EDG_2027_V2_FORMULAS_Y_METRICAS_CLARAS

[pág. 126]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2020 | pregunta 1
 Convocatoria 2 | página original 315 | Crecimiento de categoría y canales
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 1
 PREGUNTA N° 1
 “Mientras otros piden salvataje, Carozzi sale de compras durante la pandemia”. Así titulaba el diario la
 Segunda, el pasado 25 de junio, luego de que la empresa anunciara la adquisición de los activos, las marcas
 Bresler y Melevi, y la licencia de las marcas globales de helados de Unilever presentes en el mercado local,
 comercializadas por Unilever Chile, en US$20,8 millones. De esta manera, la firma controlada por la familia
 Bofill entrará a competir de lleno con Savory de Nestlé y otros competidores en este segmento del rubro
 alimentos1.
 Bresler pertenece a Heartbrand, filial de Unilever dedicada a la fabricación de helados que está presente en
 más de 40 países y es el primer productor mundial de este tipo de alimentos. De forma global se conoce como
 Heartbrand por el característico logotipo del corazón de la firma que caracteriza también a Bresler. Su helado
 insignia es Magnum, un producto con palo de madera que tiene una gruesa cubierta de chocolate, y que fue
 lanzado al mercado en 1989. Hoy, junto a Cornetto y Carte D’Or, Magnum figura entre los seis helados más
 consumidos en el mundo. Según analistas de la industria, sería este robusto portfolio de marcas, que lleva años
 en Chile, el que Carozzi buscaría potenciar para hacer crecer este negocio en el país.
 Chile lidera el ranking de consumo de helados en Latinoamérica con ocho litros per cápita al año, según cifras
 de Euromonitor Internacional de 2019, muy por sobre el segundo y tercer lugar que ocupan Costa Rica y
 Uruguay, con 2,8 y 2,7 litros, respectivamente, sin embargo, muy lejos de los líderes mundiales que son Nueva
 Zelanda y Estados Unidos con 26,4 litros y 24,5 litros per cápita respectivamente.
 La industria de los helados en nuestro país se ha desarrollado fuertemente durante los últimos años,
 experimentando un crecimiento constante superior al 7% anual. En efecto, durante el 2015 el mercado de
 helados se valorizó en US$700 millones, cifra que para este año 2020 se espera que alcance los US$1.000
 millones, logrando un crecimiento de casi 43% en los últimos cinco años.
 Bresler produce tanto helados de consumo individual o impulsivo, como productos de consumo hogareño
 (postres y cassatas). Dentro de los helados de consumo impulsivo existen varios productos como Magnum,
 Cornetto, Viennetta, Futtare, Cate D’or, entre otros, los cuales presentan atributos similares a los helados de
 la misma categoría que comercializa la empresa Trendy, como también el líder del mercado, Nestlé, con su
 marca Savory. Estos competidores también producen helados de consumo hogareño.
 En la siguiente tabla se puede ver la participación de mercado, tanto del mercado de helados impulsivos como
 del mercado de postres, de las cuatro principales marcas (medido en miles de litros):
 Mercado Helados Consumo Mercado Helados
 Individual o Impulsivos Hogareños o Postres
 Nestlé 38,5% 44,40%
 Trendy 37,4% 18,80%
 Fruna 16,8% 17,80%
 Bresler 4,6% 13,10%
 Otros 2,7% 5,90%
 Los helados son comercializados a los consumidores finales, principalmente a través de dos canales de
 distribución: los supermercados y el canal tradicional. Este último incluye almacenes, tiendas de conveniencia,
 kioscos y otros similares. El canal tradicional se focaliza en los helados de consumo individual o impulsivo,
 mientras que en el canal supermercados el foco está puesto en aquellos productos de consumo doméstico u
 hogareño (cassatas y postres). De hecho, del total de ventas de helado de consumo impulsivo, el porcentaje
 que se realiza en el canal supermercados no supera el 10%.
 1
 El Grupo Carozzi participa en 19 categorías de productos diferentes como: pastas, chocolates, dulces y comida para
 mascotas entre otros.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 126

[pág. 127]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2020 | pregunta 1
 Convocatoria 2 | página original 316 | Crecimiento de categoría y canales
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 Durante el semestre primavera-verano (octubre-marzo) las ventas se triplican en relación al semestre otoño-
 invierno (abril-septiembre). Las ocasiones de consumo de helado son gatilladas en un 54% por antojos, en un
 16% en oportunidades que involucren reuniones con amigas o amigos, alrededor de un 9% de las personas
 consumen helado cuando salen de compras, un 8% durante paseos de fin de semana, casi un 6% lo consume
 para capear el calor o como postre, y solo un 1% de los consumidores lo hace para saciar el hambre después
 de una noche de fiesta u ocasión afín. En general, los distintos análisis de mercado muestran que la decisión
 de marca del helado se toma en el momento y lugar de la compra.
 El plan estratégico del Grupo Carozzi consiste en que Bresler y su portfolio de marcas aumenten su
 participación de mercado y el volumen de ventas en el mercado de los helados durante el semestre octubre-
 marzo (2020-2021). De acuerdo al plan estratégico, el principal mercado objetivo serán los actuales
 consumidores, sin embargo, también se destinarán esfuerzos y recursos para atraer nuevos consumidores de
 las marcas de la competencia. Para lograr lo anterior, Bresler ha decido llevar a cabo una inversión de $500
 millones en programas de marketing, los cuales serán dirigidos a los consumidores finales y canales de
 distribución a través de distintas promociones.
 Iván “Loly” Fernandez, nuevo Gerente de Marketing de Bresler, proponía destinar los $500 millones en una
 campaña comunicacional usando medios tradicionales, dirigida a los consumidores finales, de manera de
 lograr preferencia de marca. Esta campaña comunicacional sería tanto en medios tradicionales (diarios,
 revistas, TV abierta, letreros en las calles, etc.) como en las principales redes sociales como Facebook e
 Instagram (ej: descuentos en una app de la marca, puntos por compras de helados de la marca Bresler
 canjeables por premios, concursos en las cuales la plata ganada por los participantes iría a organizaciones sin
 fines de lucro, etc.). El objetivo de esta campaña según “Loly” Fernández, era lograr preferencia por la marca
 Bresler y su portfolio de marcas en el consumidor final.
 Por su parte, Jaime “Chocolito” Ramírez, nuevo Gerente de Ventas de Bresler, tenía un plan diferente. Su
 propuesta se focalizaba fundamentalmente en hacer promociones al comercio, esto es, a los distintos canales
 de distribución de Bresler. Específicamente, su plan consistía en hacer descuentos de precio por volumen
 (cantidad de cajas compradas por los distribuidores), cajas de helados de regalo por órdenes mínimas de
 compra, congeladores para exhibir los helados y material publicitario en los puntos de venta de los diferentes
 distribuidores. Su objetivo era mantener la lealtad de los actuales distribuidores y atraer nuevos canales de
 distribución a la marca.
 En la siguiente tabla se muestran los resultados proyectados para las estrategias propuestas por los Gerentes
 de Marketing y de Ventas de Bresler para el período octubre-marzo (2020-2021) con respecto al año anterior:
 Aumento Ingresos Aumento
 por Ventas Utilidad Operacional
 Promociones al Consumidor Final 4,3% 3,1%
 Promociones al Comercio 8,5% 1,2%
 PREGUNTAS
 a) Usando los conceptos fundamentales de marketing y de acuerdo con la información entregada en el caso,
 ¿cuál de las dos estrategias que proponen los Gerentes de Bresler elegiría usted? ¿Por qué? Señale tres
 razones que sustenten su decisión justificando claramente cada una de ellas.
 b) ¿Cuáles serían los dos principales riesgos de la estrategia elegida? ¿Qué medidas propondría para mitigar
 los riesgos señalados? Justifique claramente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 127

[pág. 128]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2020 | pregunta 1
 Convocatoria 1 | página original 303 | Crecimiento, canal y marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº1
 Jorge Salmon, gerente general de Redington, pequeña empresa que fabrica cañas para la pesca con mosca, se
 preguntaba cuál sería la mejor estrategia de crecimiento para este año 2020. Las ventas del año 2019 de
 Redington habían logrado el presupuesto establecido para el año. Para este año, Jorge había presupuestado un
 crecimiento en ventas del 20% con respecto al año anterior y no estaba seguro de cuál era la mejor forma de
 lograrlo.
 La Pesca con Mosca
 La pesca con mosca es una actividad que tiene por objeto la captura de peces, tanto en agua salada como dulce,
 con una finalidad comercial, alimenticia, deportiva, turística o de pasatiempo. Este tipo de pesca no admite el
 uso de redes, trampas, espineles, arpones, etc. Como en todo deporte, en la pesca con mosca el equipo resulta
 fundamental a la hora de llevar a cabo esta actividad. Los elementos básicos para llevar a cabo este deporte
 son una caña, carrete, varilla y línea. La caña es la extensión del brazo del pescador, permitiéndole lanzar, dar
 dirección a la línea y pelear al pez. Las primeras cañas fueron de bambú, siendo reemplazadas por las de fibra
 de vidrio, y éstas por las de grafito, tratando siempre de lograr menor peso con la mayor resistencia y
 flexibilidad posible. Las cañas son sin duda, el elemento más preciado del pescador con mosca, y se diferencian
 por su numeración, el alcance y su longitud.
 El Mercado de la Pesca con Mosca y Redington
 La pesca con mosca es un mercado que se encuentra en crecimiento en nuestro país y abarca tanto a los hombres
 como a las mujeres. La industria clasifica a los consumidores en cuatro segmentos: principiantes, ocasionales,
 serios y profesionales. Los pescadores serios y profesionales representan el 80% del gasto en equipos de pesca,
 sin embargo, representan el 5% y el 40% de los pescadores respectivamente.
 Redington ofrece una amplia línea de cañas para la pesca con mosca para distintos tipos de pescadores. En
 general, sus cañas se caracterizan por tener un buen desempeño a un precio medio. Los precios de las cañas de
 pescar de Redington varían entre $150.000 y $450.000, con un precio promedio de $250.000. Su precio es
 consistente con muchos de los de sus competidores directos para una caña de calidad dirigida principalmente
 a los pescadores serios, sin embargo las marcas más prestigiosas, como: St.Croix, Shimano, Penn, Okuma y
 Wilson por nombrar algunas, tenían precios superiores a los $700.000.
 En el mercado de la pesca con mosca se pueden encontrar cañas que van desde los $100.000 para el segmento
 principiante, hasta aproximadamente entre $700.000 y $800.000 para el segmento profesional.
 Redington ha desarrollado una relación cercana con muchos de sus distribuidores minoristas de equipos de
 pesca, que contaban con tiendas especializadas, las cuales representan aproximadamente el 70% de sus ventas
 en valor y 50% en volumen. El 50% restante del volumen de ventas, se comercializa a través del canal
 mayorista y la página web de Redington. A fines del 2019 la empresa contaba con 50 distribuidores minoristas
 en Santiago y regiones, especializados en pesca con mosca como: Fly Shop, Flyfishing store, Pesca Total, Rod
 and Gun, etc. Además, la marca se encuentra en casi todos los lodges1 de pesca del sur de nuestro país. En
 general, los distribuidores minoristas como lodges, ofrecen distintas marcas de caña para pesca con mosca para
 los segmentos serios y profesionales. Redington le ofrece distintos servicios a sus distribuidores minoristas:
 los modelos de cañas de su línea de productos de acuerdo a las necesidades de cada uno de ellos, capacitación
 a los vendedores, ya que la compra de una caña para los segmentos serios y profesional requiere de la ayuda y
 recomendación del vendedor del local, y al mismo tiempo ofrece excursiones programadas de pesca a distintos
 lugares para los potenciales interesados que los distribuidores se encargan de promocionar.
 1 Los lodges son alojamientos ubicados en destinos no masivos, apartados de las grandes ciudades, rodeados de naturaleza y construidos
 en madera y materiales amigables con el medio ambiente.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 128

[pág. 129]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2020 | pregunta 1
 Convocatoria 1 | página original 304 | Crecimiento, canal y marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 Estrategias de Crecimiento para Redington
 Oscar “Jurel” Herrera, gerente de ventas de Redington, planteaba que la mejor estrategia para lograr la meta
 de crecimiento en ventas de la empresa, era a través de la incorporación de la cadena de tiendas de deporte
 Decathlon como nuevo canal de venta de las cañas de pescar de Redington. Según Herrera, este canal ya estaba
 ofreciendo cañas para pesca con mosca principalmente para los pescadores principiantes y ocasionales. Por lo
 tanto, según él, las marcas que ya estaban en esta cadena no representaban una competencia directa para
 Redington. Además, otro beneficio para Redington era que la orden de compra inicial de Decathlon sería más
 grande comparada a lo que piden el resto de los distribuidores de la empresa.
 Decathlon es una cadena de deportes multinacional francesa que nació en 1976 con la idea de hacer accesible
 el deporte a un mayor número de personas, desde que se inician en un deporte, hasta que se convierten en
 expertos. Sus tiendas se caracterizan por tener entre 1.000 y 12.000 metros cuadrados en las cuales se ofrecen
 productos y marcas para más de 70 deportes bajo el mismo techo y donde los clientes eligen sus productos a
 través de un sistema de autoservicio. Decathlon tiene un posicionamiento de precios bajos y un gran surtido
 de productos y marcas. En nuestro país, Decathlon ya cuenta con dos locales: uno en la comuna de La Reina
 y el otro en el mall recientemente inaugurado Open Kennedy. Se espera que en los próximos dos años abran
 20 nuevos locales en nuestro país.
 Por su parte, Renato “Tiburón” Ramos, gerente de Marketing de Redington, planteaba que la mejor estrategia
 era incorporar una caña de pescar de más alta calidad en relación a su actual línea de productos lo que les
 permitiría diferenciarse de su competencia directa. Específicamente, planteaba incorporar la nueva marca
 Crux, la cual contaría con el aval de la marca Redington. Esta nueva marca se caracterizaría por ser la mejor
 caña que haya sido fabricado por Redington, ya que incorporaría una tecnología innovadora denominada Line
 Speed Taper y nuevos puños Angled Key Grip. La nueva marca se caracterizaría por su menor peso, su alcance,
 longitud y el ser producida por materiales nobles y de manera artesanal. Ésta estaría orientada
 fundamentalmente al mercado profesional y su precio de venta a público se espera que alcance los $550.000.
 De acuerdo a Ramos, llevar a cabo esta opción implicaba un alta inversión que tendría que llevar a cabo
 Redington. En efecto, la orden mínima de producción era de 7.000 nuevas cañas de pescar Crux lo que
 representaba aproximadamente un 25% del volumen de cañas de pescar de la empresa. Según él, este riesgo
 se justificaría ya que la empresa necesitaba lograr las metas de crecimiento para este año. Además, con esta
 nueva marca podrían ampliar la base del segmento de pescadores serios y alcanzar al segmento profesional.
 PREGUNTAS
 a) Desde el punto de vista de marketing, y de acuerdo a los conceptos de estrategia de producto y distribución,
 señale y explique claramente las tres principales desventajas de las estrategias planteadas en su conjunto
 por ambos gerentes para lograr los objetivos de crecimiento de Redington. (no necesita señalar 3
 desventajas por cada una de las estrategias, sólo 3 en su conjunto). Justifique claramente su respuesta.
 b) Desde el punto de vista de marketing, y de acuerdo a los conceptos de estrategia de marca, ¿qué le parece
 la estrategia de marca sugerida por Renato “Tiburón” Ramos, gerente de marketing de Redington, para
 lograr los objetivos de crecimiento? ¿Buena? ¿Mala? Señale y explique claramente las dos principales
 razones que justifican su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 129

[pág. 130]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2019 | pregunta 1
 Convocatoria 1 | página original 279 | Crecimiento, premium y ecosistema
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N'1
 El mercado de celulares, y en particular de smartphones, ha sido muy dinámico y se expandió hasta el año 2015
 a tasas de dos dígitos. Sin embargo, tal como se observa en la Gráfica N"1, la tasa de crecimiento (línea en el
 gráfico) de las ventas anuales de aparatos smartphones es hoy casi nula y trae una fuerte tendencia negativa en
 los últimos 2 años.
 Gráfica N21
 En muchos países, incluido Chile, la
 Ventas en unidades Smartphones y Crecimiento Anual %
 penetración de los smartphones en la
 1.58 m - población total es superior al 65% y la de
 c celulares totales, sobre el 110%. En Chile,
 r ;
 y a el 85% de los accesos a intemet son
 c EA realizados desde un smartphone. Algunos
 1 . .
 '; e analistas estiman que algunos segmentos
 a 0.58 , como niños y adultos mayores no
 - 30% e
 n
 necesitan/valoran las características de un
 t Smartphone.
 [o)
 4 0%
 o Al parecer, también los consumidores
 Z7 Anároid Hios — ==Other — están cada vez más sensibles a los precios
 y están demorando el cambio de equipos,
 pese a la incorporación de mejores cámaras fotográficas, mayor duración de la batería y una serie de nuevos
 atributos en aplicaciones. En los últimos tres años, la posesión promedio de un mismo modelo de Smartphone
 ha subido de 16 meses a 27 meses. Una parte significativa de las ventas se hacen a través de las empresas de
 telecomunicaciones tales como Entel, Movistar, WOM y Claro, y como condición para no comprar el equipo al
 contado, el cliente se compromete contratar el plan por un mínimo de 18 meses. De esta forma, paga un monto
 menor por el equipo. La relativamente alta penetración de smartphones ha desarrollado también un mercado
 secundario muy activo de modelos más antiguos.
 La empresa Apple, posee un portafolio de productos (Smartphones, tablets, relojes, accesorios) y servicios
 (¡Tunes[música], iPhoto, iCloud [memoria en la nube], Apple Play [Música y videos] y Apple Pay [servicio de
 pago]), así como una serie de proyectos en curso en distintas categorías.
 Para Apple, las ventas de sus aparatos iPhone con sistema operativo propio IOS, están reflejando la tendencia
 negativa del mercado. Las expectativas de sus iPhone X en distintas versiones no se han cumplido y para este
 año 2019, varios de sus proveedores de componentes1 están rebajando sus estimaciones de ventas, ya que Apple
 está recortando sus estimaciones de producción.
 Por otro lado, el mercado se ha hecho aún más competitivo, tal como se muestra en el Cuadro N*1, con el ingreso
 de las marcas chinas tales como Huawei, Xiaomi, Oppo y el relanzamiento de Motorola bajo la mano de Lenovo.
 1 Apple no fabrica sus aparatos, sino que diseña e integra componentes de otros fabricantes, incluso de competidores
 (Samsung, Sony, LG, Toshiba). Ej. Las pantallas OLED son provistas por Samsung, los chips por Intel, etc. El ensamblaje
 lo hace FoxConn, una empresa Taiwanesa con fábricas en China.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 130

[pág. 131]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2019 | pregunta 1
 Convocatoria 1 | página original 280 | Crecimiento, premium y ecosistema
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Cuadro Ne1
 Participación Mercado Mundial 5 principales marcas (unid.)
 En particular, Huawei, con lanzamientos de
 201703| 201704 201801| - 201802; - 201803
 productos Premium (que al igual que Apple y
 Samsung 23,0% 19,0% 24,0% 21,0% 20,0%| Samsung, han superado la barrera de los USD
 Apple 12,5% 19,5% 15,5% 12,0% 1374| 1.000), y una amplia gama de modelos, tanto
 Huawei 10,2%| — 107%| — 120%| — 160%| - 145%| regulares como smartphones, ha logrado
 Yiaomi 7,5% 6,5% 7,2% 92% 9.8% quitarle participación a Apple y en parte a
 Samsung.
 Oppo 7,6% 6,5% 6,8% 8,3% 8,1%
 Tal como se muestra en la Gráfica N”, las marcas chinas, todas bajo el sistema Android, tienen precios
 promedio de sus líneas de productos, significativamente por debajo de Apple y más cercanas al líder del
 mercado, Samsung, además de costos Gráfica N22
 menores por ser fabricantes de sus equipos. I T
 Las marcas chinas están lanzando modelos de
 equipos con tecnología, si bien inferior a la de
 Samsung o Apple, relativamente buenos y
 con atributos valorados por una gran parte del
 mercado. Apple comercializa 6 modelos de 500
 smartphones y no tiene celulares fuera de esa
 categoría. Sus competidores tienen, cada uno,
 más de 15 modelos distintos en smartphones
 y varios más en celulares simples. Ape Samsung — OPPO Huawel Xizomi — Transsion
 Source: IDC
 2018 01
 Los ejecutivos de Apple Chile están
 preocupados con los desafíos para el 2019,
 que son crecer en ventas y en margen de contribución. Uno de sus Gerentes planteaba que debían pedir a la
 matriz que lanzara productos con la marca iPhone en el nivel medio de precios, más simples y accesibles, para
 poder competir con Samsung y las marcas chinas. Un Director se oponía y proponía concentrar los recursos en
 quitarle participación a Samsung y Huawei en la categoría Premium (Equipos sobre USD$1,000) mediante
 campañas publicitarias y promociones de precios.
 PREGUNTAS
 a) Desde el punto de vista comercial, analice la principal ventaja y la principal desventaja de las
 propuestas de ambos ejecutivos.
 b) Identifique y argumente una forma altemativa a lo propuesto por los ejecutivos, y factible dada la
 información del enunciado, para cumplir los objetivos de crecer en ventas y márgenes para el año 2019.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 131

[pág. 132]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2012 | pregunta 1
 Convocatoria 1 | página original 88 | Entrada y difusión de nueva categoría
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº 1
 El consumo per cápita en yogur en Chile ha aumentado significativamente en los últimos años, alcanzando los 11 kgs. en 2011 y
 un mercado total de US$445 millones. Estas son las cifras más altas de consumo per cápita de yogur de América Latina (ejemplos
 de otros países: México 5,3 kgs; Brasil 6 kgs) y el nivel de penetración de la categoría yogur en Chile es superior al 95%. Sin
 embargo, en Europa se consume cerca de 30 kgs per cápita anuales y de mayor valor agregado que en América Latina. El
 mercado chileno, en su dinamismo competitivo, ha cambiado respecto de la participación de mercado en términos de volumen
 físico de ventas de las marcas más relevantes; el Cuadro Nº1, muestra dichos cambios. La composición de los tipos de yogures
 dentro de la categoría en Chile también ha cambiado significativamente a través del tiempo, aumentando la importancia relativa
 de los así llamados yogures funcionales, también medida en volumen físico de ventas, tal como lo muestra el Cuadro Nº2:
 Cuadro Nº1 Cuadro Nº2
 Participación % en Volumen Físico Ventas Participación % en Volumen Físico Ventas
 Marca Empresa 2009 2011 Categoría Yogur
 Soprole 38% 33% SubCategoría 1995 2011
 Nestlé 14% 16% Batidos 65% 40%
 Colún 21% 18% Batidos c/fruta 25% 20%
 Danone 10% 27% Dieta (light) 6% 10%
 Otros 17% 6% Funcionales 4% 30%
 Los productos funcionales corresponden a una de las tendencias más importantes en alimentos, la cual tiene relación con la
 preocupación creciente por una mejor calidad de vida (wellness), lo que se refleja en una creciente demanda de productos
 saludables y naturales. En el caso de los yogures, ello se ha reflejado en el crecimiento de productos que incluyen atributos
 funcionales para promover la salud ósea, cardiovascular, del sistema inmunológico, cerebral y digestivo. Aparecen así los
 extracalcio, probióticos, prebióticos, y “mejora del tránsito intestinal”. Así mismo, crece a nivel mundial la demanda por
 productos más naturales (“orgánicos”) y éticos (no contaminan, comercio justo (“fair trade”), etc).
 Danone es el productor de yogur más grande del mundo, uno de los más relevantes tomando el total de lácteos y tiene operaciones
 en decenas de países. Danone ingresa al país el 2006, trayendo importaciones de su marca “Activia” para mejorar el tránsito
 intestinal y otras marcas menores desde Argentina. En Abril de 2007 Danone adquiere plantas en el país, lo que le permite iniciar
 su proceso productivo en Chile. Para ingresar al mercado Chileno, Danone utiliza su marca de yogures funcionales “Activia”, para
 facilitar el tránsito intestinal, con comunicación masiva muy agresiva en términos de volumen e inversión (ver Gráfica Nº1),
 comparada con la competencia. Soprole, uno de sus más importantes competidores, reacciona usando su submarca “Next” y
 lanzando al mercado su producto “Tránsito+". Ver muestra de envases en página siguiente
 Gráfica Nº1: Inversión Publicitaria en Yogur
 (Fuente: Megatime, Inversión en Medios Masivos a valor tarifa)
 Danone
 Soprole
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 132

[pág. 133]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2012 | pregunta 1
 Convocatoria 1 | página original 89 | Entrada y difusión de nueva categoría
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 En Abril de 2009, Danone lanza la campaña “Desafío 14 Días Activia”, actividad publicitaria y promocional que se transforma en
 un hito para el mercado lácteo, dado los fuertes niveles de inversión con los que se desarrolló esta actividad con más de $3.000
 millones (5.978 GRPs1), en sólo 3 meses.
 y
 Activia por Danone Next Tránsito + por Soprole
 En los primeros tres años, Danone se concentró en desarrollar “Activia”, marca destinada al “bienestar digestivo” de la mujer,
 acompañándola de campañas de comunicación, que han tenido como rostros a las animadoras Diana Bolocco y Karen
 Doggenweiler. Yogur “Activia” genera el mismo nivel de presencia publicitaria (“share of voice”) que la submarca de Soprole,
 “Next”, en la suma de todas las categorías en las que “Next” participa. (yogur, postres, otros lácteos).
 A su vez, “Activia” ha sido un actor relevante en la inversión en los puntos de venta, comprando espacios y ubicaciones en los
 supermercados. El potenciar la marca de nicho “Activia”, a su vez, le ha permitido ingresar en forma gradual a las categorías de
 mayor volumen (específicamente a yogur “batido”) y productos de valor agregado (“Griego con Nueces”) con la marca Danone,
 gracias al reconocimiento obtenido con “Activia”.
 Durante los años 2010 y 2011, Danone ha sido líder en inversión publicitaria en la categoría, con especial énfasis en sus sub
 marcas “Danone - Activia” y “Danone - Griego”.
 A usted se le pide responder:
 1. El ingreso al mercado chileno por parte de Danone ha sido claramente exitoso desde el punto de vista de participación de
 mercado, rentabilidad y construcción de marca. ¿Qué explicaría, desde el punto de vista de una estrategia de producto, que
 Danone, gran productor mundial con significativos recursos y un gran portfolio de productos y marcas, haya elegido una
 estrategia de penetración al mercado chileno a través de un producto de nicho como los funcionales, y en particular “Danone -
 Activia” (“mejoramiento del tránsito intestinal”)?
 2. ¿Qué podría explicar que Danone invierta en la categoría yogurt,, en particular en la subcategoría funcionales,
 significativamente más que sus competidores Soprole y Nestlé en publicidad y apoyo en el punto de venta? En su respuesta
 use conceptos de estrategia comercial y de difusión de productos y marcas.
 1 GRP = Gross Rating Points
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 133

[pág. 134]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2022 | pregunta 1
 Convocatoria 1 | página original 354 | Extensión de línea/marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº1
 “Notco”, un nombre muy singular que enfatiza la contradicción. La empresa se fundó en Chile hace unos años
 basándose en una gran cantidad de investigación y ciencia, que han logrado patentar. Lo que querían hacer era
 replicar la composición molecular de productos alimenticios con ingredientes de origen animal como la leche,
 la mayonesa, los helados y las carnes mismas, con combinaciones de productos de origen vegetal. Su gran
 innovación fue crear a Giuseppe, un algoritmo capaz de generar fórmulas de alimentos conocidos basándose
 sólo en ingredientes vegetales, imitando la funcionalidad (múltiples usos), el sabor y la textura de los alimentos
 a reemplazar. Giuseppe fue desarrollado a partir de un algoritmo de inteligencia artificial que busca patrones
 que ocurren en el comportamiento de plantas y alimentos tradicionales.
 Actualmente, tienen en su base de datos más de 300 plantas y frutas con su estructura molecular. El algoritmo
 encuentra una combinación de plantas o "receta" que replica el sabor, la sensación y textura de los productos
 de origen animal, para que puedan reemplazarlos de una manera sostenible y tener un excelente sabor. Sus
 ejecutivos plantean que sus productos son para “todos”, incluyendo a veganos, alérgicos, pero lo más relevante,
 es que va dirigido a todos a los que quieren seguir comiendo las categorías que tienen ingredientes de origen
 animal, pero sin el impacto negativo que producen los animales sobre el medio ambiente o por el maltrato a
 los animales.
 “Hoy día, la producción animal pasa a ser el principal factor del cambio climático. Deforestación, uso de agua,
 uso de tierra, contaminación de los océanos, pérdidas de especies, deforestación del Amazonas, emisiones de
 CO2. ¿Adivina quién es el número uno? Es la industria de alimentos”, explica Matías Muchnik, cofundador
 de la empresa, en entrevista a un medio.
 El propósito estratégico de esta empresa y la motivación de su innovación, es ser amigables con el medio
 ambiente por la vía de eliminar a los animales en la cadena alimenticia humana, pero a la vez, ofrecer productos
 con un sabor similar o mejor, a quienes quieren seguir sintiendo los sabores y texturas de los productos cárnicos
 o lácteos, sin impacto ambiental y a menor precio relativo. "Estamos tratando de revolucionar la industria de
 la alimentación y que cada vez más personas se cambien a una dieta sin elementos animales", explica Javiera
 Bravo, jefa de Innovación de la compañía, en entrevista a 3Claves. Si bien el uso de plantas como insumo hace
 que los productos tengan algunas características positivas para la salud, algunos de sus productos siguen
 teniendo altas calorías, alto contenido de azúcar, alto sodio y altas grasas saturadas, lo que se refleja en los
 sellos que tienen la mayoría de los productos de Notco.
 NotCo lanzó NotMilk en los EE.UU. con dos variedades (Leche Entera y 2% Grasa), en Whole Foods, una
 cadena de 468 supermercados Premium, hoy propiedad de Amazon (Jeff Bezos, dueño de Amazon es socio
 inversionista en NotCo), y en Starbucks. Los primeros productos en Chile y luego en otros países de América
 Latina, fueron NotMayo y NotMilk, y luego siguieron con NotIceCream, NotBurger y NotChicken, con las
 mismas proteínas e imitando el sabor de sus símiles de origen animal. En la foto siguiente, pueden observar
 algunos de sus productos.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 134

[pág. 135]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2022 | pregunta 1
 Convocatoria 1 | página original 355 | Extensión de línea/marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 Las variedades (SKUs) en cada categoría son limitadas en comparación a su competencia. Por ejemplo, en
 helados, hay sólo cuatro sabores, en leches tres (Original, chocolate y low fat) y en Mayonesa, cinco sabores
 (Original, Low Fat, Spicy, Olive y Garlic).
 Las ventas minoristas de alimentos de origen vegetal en los EE.UU.
 han aumentado en dos dígitos en los últimos años. En 2020, crecieron
 un 27 por ciento, llevando el valor de mercado total de productos
 vegetales a $ 7 mil millones de dólares. Un estudio de Mintel
 Consulting, reveló que en Chile la oferta de productos de origen
 vegetal, ha crecido en los últimos 4 años, 8 puntos porcentuales en la
 cuota de mercado de estos productos, que hoy alcanzan el 12% de la
 torta del rubro alimentario.
 De los tres países analizados en el estudio (Chile, Argentina y Brasil),
 Chile lleva la delantera en términos de aumento de la oferta de
 productos.
 Suponga que el equipo comercial de NOTCO está evaluando
 alternativas de crecimiento, dado que crecer aceleradamente, tanto en Chile como a nivel global, es una
 iniciativa estratégica para este año y el próximo.
 Una de sus ejecutivas, Rúcula Berry, planteaba que el camino más atractivo era seguir extendiendo su marca
 “NOT”, la cual ya tenía reconocimiento y recordación tanto en Chile como en otros países, a distintas
 categorías de alimentos, incluyendo aquellas que no tienen origen animal, tales como pastas, azúcar, cereales
 de desayuno, bebidas no alcohólicas, etc., enfatizando sus ingredientes orgánicos y sanos. La idea es sacar una
 línea de productos bajo los atributos de “sano” (sin o con nivel reducido de gluten, azúcar, sodio, grasas
 saturadas, calorías, etc.), con la marca “NOT”, evitando los sellos del Minsal, que por ley deben ir en los
 empaques y que alertan a la población del potencial daño a la salud.
 Por otro lado, el Gerente de Marketing, Rábano Celery, planteaba que el mejor camino de crecimiento era
 potenciar la marca NOT en las categorías que ya manejaban (lácteos, aderezos, carnes) y que reemplazan
 ingredientes de origen animal, creciendo en ellas vía la proliferación de sabores (en helados, leches
 saborizadas), presentaciones de empaque (tamaños, tipos de empaque), funcionalidades y variedades de
 sustitutos cárnicos (ej. Not Pork (cerdo), Not Fish (Salmón, Atún), NotCream (crema), NotCheese (Queso),
 etc.). También proponía ampliarse al segmento de servicios de alimentación (restoranes, cadenas de comida
 rápida, hoteles y casinos de empresas) como proveedor de las categorías mencionadas.
 Preguntas:
 a) De acuerdo a la información del enunciado y desde el punto de vista de marketing, señale y explique
 claramente, tres argumentos en contra de cada una de las propuestas de los ejecutivos, dado el objetivo
 de crecimiento de la empresa y el contexto de NotCo.
 b) ¿Cuál debiera ser la estrategia de marcas de NotCo para su portfolio de productos, si se adoptan las
 propuestas de cada uno de los ejecutivos? Justifique claramente su respuesta para cada propuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 135

[pág. 136]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2022 | pregunta 1
 Convocatoria 2 | página original 364 | Formato low-cost y marcas propias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº1
 SMU, holding de distintos formatos supermercadistas, presentó hace un año, Super10, un nuevo formato de
 supermercados que surge con el concepto de “soft discount”. ¿Qué significa ser un supermercado soft discount?
 El formato soft discount se caracteriza por ser un supermercado entre 1.200 a 1.500 metros cuadrados, que
 ofrece precios más bajos en relación a un supermercado tradicional y dónde el 40 a 50% de los productos son
 de marca propia, a diferencia de un supermercado tradicional dónde representan un 15% aproximadamente. Con
 esta inauguración, Super10 se incorpora al portfolio de SMU, supermercadista con cobertura geográfica
 presente en las 16 regiones de Chile, y que cuenta con Unimarc, Unimarc.cl, Alvi y Mayorista10. Este nuevo
 formato soft discount de supermercados ofrece un surtido más limitado de productos para las familias, a bajos
 precios relativos a la cadena Unimarc.
 Si bien no todas las marcas de cada categoría están presentes en Super10, están las
 más populares y de alta rotación, junto con las marcas propias de la cadena. En ese
 sentido, Marcelo Gálvez, Gerente General de SMU, reveló los beneficios que ofrece
 este modelo a los consumidores. “Permite una operación más rápida y más simple.
 Toda esa eficiencia se traspasa a precios, así que finalmente el cliente encuentra de
 todo, con buena calidad y a precios súper económicos”, sostuvo.
 De acuerdo al Gerente General, este nuevo formato, a diferencia de Alvi y
 Mayorista10, busca que los clientes sean los consumidores finales y reforzar la
 presencia de marcas propias. En el caso de Alvi, éste se caracteriza por ser es un
 supermercado de autoservicio mayorista para comerciantes, que también atiende a consumidores finales que
 compran grandes volúmenes. Este formato se caracteriza por no vender productos en forma unitaria, por ejemplo
 un empaque de shampoo, sino que cajas de 6 ó 12. Lo mismo ocurre con todo el resto de las categorías de
 productos. Por su parte, Mayorista10 se focaliza 100% en comerciantes que luego revenden esos productos en
 sus propios locales (por ejemplo una pequeña tienda de abarrotes de barrio se abastece de productos en locales
 como Mayorista10). En Super10 el mercado objetivo es el cliente final y no los comerciantes.
 De acuerdo a Nicolás Delsol, gerente de Super10, “se busca entregar una nueva propuesta de valor centrada en
 el cliente, brindando una buena experiencia de compra con un surtido optimizado que permite la adquisición
 completa de productos como panadería, abarrotes, perecibles, perfumería, frutas y verduras, ya sea para
 abastecimiento o reposición para el hogar. Es una tienda centrada totalmente en garantizar al cliente una compra
 rápida”. El tamaño de las tiendas es de alrededor de 1.300 metros cuadrados, lo que se compara con los
 supermercados Unimarc que tienen un tamaño medio de 3.000 metros cuadrados, siendo el de mayor tamaño
 de cerca de 6.000 m2. Agregaba el gerente, “las cajas de checkout (de pago) están diseñadas para un pago ágil
 y práctico, las góndolas no superan una altura de 1,65 metros, para estar al alcance de todos los clientes e
 incorpora una etiqueta de precio de fácil lectura. Además, se exhibe el 100% del stock disponible a la venta, por
 lo que no existen bodegas. Los camiones de reposición llegan con carga y ésta es dispuesta inmediatamente en
 tienda”.
 Los principales competidores de SMU, Walmart y Cencosud cuentan también con distintos formatos de
 supermercados. En el caso de Walmart, tiene: los supermercados Líder, los cuáles compiten con Unimarc. Este
 formato se caracteriza por ofrecer una amplia gama de categorías, abarcando desde productos comestibles hasta
 otros como hogar, electrónica, juguetería y vestuario con marcas de diferentes proveedores y contando además
 con productos de marca propia, nacionales e importados; Super Bodega aCuenta, el cual se caracteriza por
 ofrecer sólo productos comestibles, foco en marcas propias y locales de menor tamaño y bajo costo de operación,
 lo que le permite ofrecer precios bajos relativos a sus otros formatos; y finalmente, con Central Mayorista, el
 cual se focaliza en comerciantes y HORECA (Hoteles, Restaurantes y Casinos), de manera de ofrecerle a estos
 segmentos lo que necesitan en un solo lugar, y a precios bajos relativos a la venta al detalle, generando una
 experiencia de compra rápida, simple y conveniente en sus locales. Cencosud por su parte, cuenta con:
 Hipermercados Jumbo, el cual compite con Líder y Unimarc; con el supermercado de tamaño medio, Santa
 Isabel, un formato económico que atiende a clientes finales; y, el formato Spid35, el cual está enfocado en
 compras express, para ocasiones de consumo no planificadas y de conveniencia. Su propuesta de valor está
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 136

[pág. 137]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2022 | pregunta 1
 Convocatoria 2 | página original 365 | Formato low-cost y marcas propias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 pensada en ofrecer despachos rápidos en menos de 35 minutos en compras por web, tiendas de menor tamaño
 y surtido de alta rotación. Sus principales competidores son las tiendas de conveniencia de Oxxo y OK Market.
 Super10 tiene una mayor presencia de marcas propias de SMU en las góndolas que en los otros formatos de
 SMU. En cada categoría ofrece una marca de un proveedor líder más su marca propia. En ese sentido, el grupo
 supermercadista está potenciando nuevas marcas propias con precio inferior a la marca del proveedor líder.
 “Nosotros partimos este año cambiando la estrategia. Ahora desarrollamos marcas por agrupación de productos.
 En abarrotes tenemos la marca “Nuestra Cocina”, para artículos de limpieza está “SmartClean”, “Fundo Río
 Alegre” en carnicería, y en panadería-pastelería, contamos con “Amada Masa”. Estas son marcas transversales
 que vendemos en todos nuestros formatos”, explicó Marcelo Gálvez, gerente general de SMU.
 El tema de las marcas propias de los distribuidores ha sido recurrente desde hace mucho tiempo en nuestro país
 al igual que en el resto del mundo, mostrando un crecimiento sostenido en los últimos años. Estas categorías de
 productos con marcas propias son, por lo general, producidas por pequeños proveedores que operan en nuestro
 país. Desde el punto de vista de los consumidores, el atributo más valorado, entre quienes consumen marcas
 propias, es su precio más bajo, relativo a las marcas reconocidas de proveedores.
 Preguntas:
 1. Desde el punto de vista comercial, señale y explique claramente los tres argumentos principales que
 justifiquen la decisión de SMU de incorporar esta nueva marca Super10 y formato soft discount a su
 portfolio.
 2. Señale y explique tres desventajas de potenciar las marcas propias de SMU en su formato Super10 por
 sobre las marcas de proveedores.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 137

[pág. 138]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2017 | pregunta 1
 Convocatoria 2 | página original 240 | Guerra de precios y diferenciación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N" 1
 La cadena de tiendas “xyzpin” es la empresa más importante de retail en nuestro país en la venta de electro hogar
 (TV, proyectores, equipos de blue-ray, máquinas fotográficas, etc.), tecnología (computadores, impresoras,
 telefonía, etc.), y línea blanca (refrigeradores, lavadoras, secadoras, etc.). La cadena posee actualmente 90 locales
 a nivel nacional, los cuales se caracterizan por tener amplias salas de venta para exhibir y comercializar las
 distintas marcas de estas categorías. Además, cuenta con personal de ventas altamente capacitado para resolver
 las distintas dudas que tengan los clientes en relación con las diferentes marcas y modelos de estas categorías.
 Esta cadena de retail tiene una estrategia multicana!: realiza ventas tanto en sus tiendas físicas como en su página
 de internet, donde los clientes pueden hacer compras con despacho a domicilio.
 Desde la fusión del 2008 entre las empresas de retail XYZ y PIN, la cadena “xyzpin” había mostrado un
 crecimiento tanto en sus ventas como en utilidades, pero en el último año ambas habían caído. El Gerente General
 de la cadena se encuentra preocupado por la situación actual de la compañía. Observa, por un lado, cómo caen las
 ventas de las tiendas físicas de la empresa y por otro, cómo la estrategia de precios seguida por el departamento a
 cargo de la tienda virtual, ha llevado a una disminución de los márgenes en las ventas de e-commerce.
 Según el Gerente General de “xyzpin”, una de las principales razones de por qué habían caído las ventas y los
 márgenes de los locales de la cadena, era al efecto “showrooming” (efecto “vitrineo”). Este efecto consiste en la
 práctica de los consumidores de visitar un local, examinar, probar y preguntar todo lo referente a un determinado
 producto, para luego hacer la compra online en otra tienda digital a un precio más bajo. En general, las tiendas
 online suelen ofrecer precios más bajos ya que tienen estructuras de menores costos, producto de que no cuentan
 con locales y personal de tiendas. Actualmente, más del 70% de los consumidores está utilizando el
 “showrooming” sobre todo en categorías como electro hogar, tecnología y línea blanca, las cuáles requieren de
 un proceso de decisión de compra más complejo. Estas categorías se caracterizan por requerir, de parte de los
 clientes, de información más específica de los distintos modelos de productos, asesoría en el proceso de compra
 y en algunos casos demostraciones de productos. 4
 La conocida cadena Walmart ha sido una de las empresas pioneras en facilitar el efecto showrooming en nuestro
 país. En efecto, hoy en día es posible bajar una aplicación en los smartphones de las personas, que les permite a
 ellas comparar el precio de un determinado producto, que podrían adquirir en la tienda online de Walmart,
 mientras se encuentran visitando locales de la competencia. Así, por ejemplo, un consumidor podría estar
 analizando la compra de un refrigerador Mademsa en un local de “xyzpin” y comparar en su teléfono el precio al
 cual podría adquirirlo en la tienda online de Walmart.
 Á pesar de contar con distintos formatos y un gran número de locales, Walmart es capaz de ofrecer precios más
 bajos que los competidores, debido a las fuertes economías de escala que logra en la operación de sus distintos
 tipos de formatos y en los grandes volúmenes de compra a los proveedores, lo que le permite tener menores costos
 de operación de sus locales y tienda on-Line.
 Después de un año de caída en las ventas y utilidades de la empresa, el Gerente General de “xyzpin” estaba
 pensando aplicar una “Política de Igualación de Precios Permanente”, a partir del segundo semestre de este año,
 como una forma de defenderse de la agresiva política de precios de los retailers online, especialmente de Walmarí.
 Esta política consistía en igualar el precio que encontraba n cliente al hacer “showrooming” en los locales de
 “xyzpin”. Por ejemplo, si un consumidor estaba analizando la compra de un computador en un local de la cadena
 y encontraba el mismo producto en una tienda online como Walmart.com u otra, “xyzpin” le igualaba el precio
 inmediatamente en el local. De esta manera, “xyzpin” se aseguraba que el cliente materializara la compra del
 computador en la tienda y no a través de un competidor onfine.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 138

[pág. 139]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2017 | pregunta 1
 Convocatoria 2 | página original 241 | Guerra de precios y diferenciación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 El Gerente de Marketing de “xyzpin” no estaba tan convencido de aplicar la “Política de Igualación de Precios
 Permanente” que estaba sugiriendo el Gerente General de la cadena. El sugería dos estrategias alternativas para
 enfrentar la agresiva estrategia de precios de Walmart. La primera estrategía consistía en reducir el tamaño de las
 tiendas de “xyzpin”, en términos de metros cuadrados, de manera de bajar costos fijos producto del pago del
 arriendo de los locales y del menór número de empleados que se necesitarían en cada uno de ellos. Además, el
 tener tiendas más pequeñas le permitía a “xzypin” disminuir los costos de inventario y los costos asociados al
 espacio destinado a la bodega utilizada para mantener dicho inventario. Así, la cadena podría disminuir los precios
 de los productos en los cuales eran amenazados por Walmart. La segunda, consistía en mejorar el servicio que
 ofrecían las tiendas a sus clientes. Por ejemplo, “xyzpin” le ofrecería a los clientes que compraran los productos
 en sus locales, la instalación de estos en forma gratuita en sus casas u oficinas, o bien que ellos pudieran traer los
 productos a las tiendas donde existiría un área donde podrían ser revisados y reparados en caso de tener algún
 problema. El mayor costo que implicaba este servicio para “xyzpin” sería financiado por los proveedores, a
 quienes la cadena les cobraría un pago por el concepto de exhibición de los productos en el punto de venta y
 asesoría en la venta de los productos a los clientes. De acuerdo al Gerente de Marketing, este cobro a los
 proveedores se estaba convirtiendo en una práctica común en la industria del retail a nivel global.
 PREGUNTAS
 1. Deacuerdo ala información entregada, señale y explique claramente dos razones por las cuales la cadena
 de tiendas "xyzpin" no debiera mantener una "Política de Igualación de Precios Permanente". Justifique
 claramente su respuesta.
 2. ¿Cuál de las dos estrategias planteadas por el Gerente de Marketing implementaría Ud. para enfrentar las
 consecuencias del efecto showrooming en la cadena “xyzpin”? Justifique su respuesta señalando las
 principales ventajas y desventajas de cada una de ellas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 139

[pág. 140]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2023 | pregunta 1
 Convocatoria 2 | página original 390 | Guerra de precios y posición
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº 1
 Ha estallado una intensa guerra de precios en el mercado de automóviles eléctricos (EVs1) más grande del mundo:
 China. En marzo de 2023, la empresa conjunta en China de Volkswagen y Xpeng, recortó los precios de sus
 autos eléctricos ID.3 en un 18 %. Varios otros productores chinos, así como extranjeros, han hecho rebajas de
 hasta un 40% en los EV, así como en los tradicionales autos a combustión.
 La Gráfica N°1 muestra que el mercado mundial de EVs
 ha estado creciendo exponencialmente en los últimos años,
 liderado por Tesla y seguido cada vez más de cerca por
 fabricantes chinos como BYD. El año pasado se vendieron
 en el mundo más de 10 millones de unidades, con un
 crecimiento del 55% respecto de 2021, lo que representa
 un 13% de participación de las ventas totales de vehículos
 en el mundo. Alrededor de uno de cada siete automóviles
 de pasajeros comprados en 2022 en todo el mundo, fue un
 EV. Esto se compara con uno de cada 70, solo cinco años
 antes.
 En China, existen hoy cerca de 100 productores de EVs con más
 de 300 modelos de autos, liderados por BYD, e incluye a algunas
 empresas extranjeras (Volkswagen y Tesla con participaciones de
 mercado de 3% y 7% respectivamente), tal como muestra la
 Gráfica N°2. Las ventas de vehículos eléctricos nuevos en China
 aumentaron un 82 % en 2022 en comparación con el año anterior.
 Este país representó el 59% de las ventas mundiales de vehículos
 eléctricos el año pasado, consolidando su posición como el
 mercado de vehículos eléctricos más grande del mundo. China
 también es el mayor productor de vehículos eléctricos del mundo,
 con el 64 % del volumen mundial. Según analistas, la gran cantidad
 de productores chinos se explica por los subsidios estatales de su
 Gobierno.
 La Gráfica N°3 muestra las ventas en unidades (100%
 eléctricos con batería e híbridos) de EVs en China y las
 estimaciones para los próximos años. Las marcas chinas
 tienen una participación superior al 80% en su país. La
 capacidad anual china de producción de EVs ascendió a
 5,7 millones de vehículos a fines de 2022, lo que
 significa la utilización del 58% de la capacidad instalada
 de las fábricas operativas de EVs en China. Las fábricas
 de EVs en construcción desde 2022, tendrán una
 capacidad total de producción de 10,5 millones de
 vehículos eléctricos, y se cree que la mayoría serán EVs.
 Una vez que todas estas fábricas estén operando, se
 espera que China alcance una capacidad de producción
 de 16 millones de EVs por año. La alta tecnología de las
 plantas determina que la estructura de costos de las empresas es principalmente fija. Este año 2023, se espera
 que las exportaciones totales de EV desde China al resto del mundo, lleguen a 1,3 millones de unidades.
 1 EVs: Autos eléctricos, incluyendo los híbridos (eléctricos + combustión) y los 100% eléctricos con batería.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 140

[pág. 141]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2023 | pregunta 1
 Convocatoria 2 | página original 391 | Guerra de precios y posición
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 Por muchos años, Tesla fue el productor de EVs más grande del mundo con mega fábricas en USA, Alemania y
 China. En este último país, Tesla fabrica más del 50% del total mundial de su producción de EVs. Su producción
 total mundial en 2022, fue de 1,6 millones de EVs. Hoy, su liderazgo (50% de participación en USA y 15% en
 Europa) está amenazado por empresas chinas como BYD, que en China tiene una participación de mercado del
 30% y que, a diferencia de Tesla, es una empresa altamente integrada en su cadena de valor y produce gran parte
 de sus insumos y partes. BYD exporta a diversos países y espera tener plantas de fabricación en Europa para
 2025. En Europa y Estados Unidos existen hoy barreras arancelarias para los autos fabricados en China y estos
 no acceden a los subsidios estatales a la compra, que los gobiernos occidentales ofrecen.
 Desde los comienzos de la fabricación de EVs en 2008, Tesla ha tenido una ventaja de costos respecto de los
 autos a combustible y también del resto de productores de EVs, gracias a su simple tecnología de montaje, al
 reducido número de modelos (2 modelos representan más del 80% de su producción), y a que sus fábricas fueron
 diseñadas para EVs y no reconvertidas de plantas de autos a combustible. También ha influido que su inversión
 en publicidad es mínima y se basa en el boca-a-boca, y que además usa un canal de venta directa, evitando los
 concesionarios. Esta ventaja de costos, sumada a su imagen premium y de calidad, le ha permitido tener márgenes
 operacionales porcentuales cercanos al 20%.
 Sin embargo, el haber recientemente reaccionado a la guerra de precios en
 China, ha llevado a Tesla a reducir sus márgenes operacionales a cerca de
 la mitad en dicho país (ver Gráfica N°4). Bajo la presión de una
 competencia cada vez mayor y la incertidumbre económica en China,
 Tesla ha bajado en este país sus precios en más de un 25% durante 2023
 para disminuir sus inventarios. El presidente ejecutivo de Tesla, Elon
 Musk, redobló dicha guerra de precios, señalando que la compañía
 priorizaría el crecimiento de las ventas más que las ganancias en una
 economía china débil y en un entorno de creciente competencia.
 Zhu Jiangming, CEO de Leapmotor, comentó que es muy posible que un
 vehículo eléctrico promedio o de gama alta en China, se venda por
 alrededor de US$7.000 en pocos años. Elon Musk, estima que el precio
 promedio de un automóvil eléctrico en China ya es significativamente más
 bajo que en el resto del mundo, alrededor de US$ 35.000, en comparación
 con US$ 60.000 en Europa y US$ 70.000 en los Estados Unidos. En parte, esta diferencia se debe a significativos
 subsidios estatales chinos a la compra de EVs producidos en China, que debieran terminarse este año.
 William Li, director ejecutivo de Nio, una de las empresas chinas emergentes de vehículos eléctricos de alta gama,
 dijo que planeaba mantener a Nio fuera de la guerra de precios, a la que calificó de "poco saludable e insostenible".
 PREGUNTAS
 1.- Considerando el mercado chino de EVs, ¿debiera Tesla seguir en la guerra de precios y mantener sus rebajas
 y promociones de precios en dicho país? ¿Sí o no? Desarrolle los 3 principales argumentos que justifican su
 decisión. En su respuesta utilice conceptos de marketing.
 2.- Desde el punto de vista de marketing señale, entregando los fundamentos correspondientes, las 3 ventajas
 más importantes para Tesla de iniciar una guerra de precios a nivel de los mercados occidentales más
 importantes, como Estados Unidos y Europa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 141

[pág. 142]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2010 | pregunta 1
 Convocatoria 2 | página original 46 | Investigación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº 1
 ¿Un zapato de goma de colores y con agujeros puede ser exitoso? Crocs demostró poder hacerlo. Entre 2003 y 2007,
 Crocs Inc creció aceleradamente y se expandió por el mundo, vendiendo más de 100 millones de pares de su exitoso y
 curioso (algunos dirían feo) modelo en dicho período, logrando además altos niveles de conocimiento y recordación de
 marca. Copias han surgido por todo el mundo en los últimos años, aunque no con la misma tecnología y calidad.
 La Compañía Crocs Inc fue creada en Colorado, EE.UU en 2002 a partir del uso de una tecnología canadiense que tres
 emprendedores amigos adquirieron y patentaron como Croslite™. Esta tecnología, cuya patente se vence en el año
 2014, permitía crear una zapatilla de goma liviana y muy resistente, confortable, no resbaladiza y anti-olores. La calidad
 de su material las hacía prácticamente indestructibles. Estas características hacían a las Crocs muy atractivas para uso
 casual o informal en la casa y en la playa y para uso recreacional, como navegación y jardinería. Estudios mostraban que
 también eran compradas, incipientemente, por profesionales que debían estar parados mucho tiempo (médicos,
 enfermeras, operarios de fábricas, etc). Estas zapatillas de gomas de variados colores que se vendían a US$30 el par,
 aparecieron en pleno inicio del boom económico de EE.UU. George W. Bush usaba una, al igual que el cantante de
 Aerosmith, Steven Tyler, ¡su abuelita también!. Todos querían tener un par de Crocs, pese a que el mundo tradicional de
 la moda los miraba en menos.
 Crocs debió su éxito inicial a su modelo de negocio que tenía como características: la alta productividad por foco
 productivo y comercial en un solo producto (con diversidad de colores); una tecnología patentada; su cadena logística
 (bodegas, flota de despacho) propia y altamente eficiente, que le permitía suplir y reponer stocks con una velocidad que
 ningún fabricante de calzado disponía; y, a una estrecha relación con los pequeños, pero especializados minoristas en
 calzado, más que con grandes tiendas por departamentos o supermercados. También Crocs había desarrollado una
 extensa red de pequeñas tiendas propias o kioskos en malls, donde el autoservicio era clave. En una entrevista, el
 Gerente de Marketing de Crocs, Ken Chaplin, decía: “Lo que queremos hacer es establecer a Crocs como una marca y no
 sólo como una zapatilla de goma. Hay grandes oportunidades si expandimos las ocasiones de uso y las estaciones del año
 en que jugamos”.
 A partir del año 2008, coincidiendo con el inicio de la desaceleración de la economía norteamericana, la situación
 financiera de la Compañía cambió significativamente; muchos analistas temían el fin de Crocs Inc. El cuadro siguiente
 muestra la evolución de las cifras operacionales entre los años 2007 y 2009 de la Compañía:
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 142

[pág. 143]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2010 | pregunta 1
 Convocatoria 2 | página original 47 | Investigación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 (Miles de US$) 2007 2008 2009
 Ingresos por Ventas $847.350 $721.589 $610.000
 Costo de Ventas - $349.701 - $398.623 - $366.000
 Gastos de Adm. y Ventas - $359.882 - $411.800 - $380.000
 Resultado Operacional $137.767 -$88.834 - $136.000
 Para enfrentar la difícil situación financiera, el nuevo Gerente General (CEO) de la Compañía pensaba en extender la
 línea de productos hacia zapatos de moda y con otros de materiales distintos de Croslite (cuero, lona, etc), entrando a
 competir con distintos fabricantes de zapatos de uso casual, deportivo o de vestir. También, sugería abarcar más líneas de
 productos complementarias tales como ropa y accesorios. Así, podrían potenciar su marca, su buena distribución y
 acceder a productos de mayor margen. Por otra parte, uno de los analistas del sector y al mismo tiempo Asesor de la
 Compañía, pensaba que la Compañía debía focalizarse aún más en su tecnología Croslite y seguir lanzando nuevas
 versiones de sus coloridas zapatillas de goma para las mujeres e innovar en niños y hombres, así como además desarrollar
 la penetración de segmentos profesionales que requerían una zapatilla Croslite cómoda y segura.
 A Ud. se le pide responder lo siguiente:
 1. ¿Cuáles serían los argumentos que respaldarían el camino propuesto por el nuevo Gerente General (CEO) de la
 Compañía?; ¿cuáles serían los riesgos del camino propuesto por el Gerente General?
 2. ¿Cuáles podrían ser los argumentos comerciales que respaldarían la sugerencia del Asesor de la Compañía?; ¿cuáles
 serían los riesgos de su sugerencia?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 143

[pág. 144]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2024 | pregunta 3
 Convocatoria 2 | página original 419 | Investigación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N'3
 En consumo masivo, algunas de las categorías más relevantes de productos son las relacionadas con cuidado personal
 (piel, cabello, cosmética, fragancias, etc), medicamentos OTC (venta sin receta) y bebidas “isotónicas”. A nivel mundial,
 los productos de cuidado personal han crecido en los últimos 5 años a una tasa inferior al 3% anual, mientras que los
 OTC a menos del 2% anual, alineado con el bajo crecimiento demográfico. La pandemia ha cambiado hábitos y las
 ventas tienden a estabilizarse en estas dos categorías.
 Genomma Lab Internacional, S.A.B. de C.V es una de las empresas líderes en la industria de productos farmacéuticos
 OTC, cuidado personal y bebidas isotónicas en México, con una creciente presencia internacional. Genomma Lab se
 dedica al desarrollo, venta y promoción de una gran variedad de productos de marca, muchos de los cuales son líderes
 en términos de ventas en la categoría en la cual compiten.
 Genomma Lab, viene desarrollando desde el 2009, una estrategia para crecer sus ventas, que contempla entre otras
 acciones, generar eficiencias en su portafolio de productos. Así el 2009 tenía 62 marcas y 430 UPC!. Hoy posee cerca
 de 30 marcas y 211 UPC. Sus ventas totales han crecido sobre el 15% anual.
 La empresa pretende desinvertir o vender las marcas que no son parte de su foco principal de crecimiento, aun cuando
 sean rentables. Así, busca enfocarse en sólo algunas categorías. “Vemos una gran posibilidad de desinvertir en ciertas
 categorías. En las categorías en las que estamos ahora o en otras de OTC [medicamentos de venta libre o sin receta]
 podemos crear mucho valor”, dijo Rodrigo Herrera, fundador y presidente de Genomma Lab, durante el evento de la
 compañía, “Día de los inversionistas 2023”.
 ISOTONIC BEVERAGES SUEROX — 12050MM
 +1140 MM La tabla de la izquierda muestra el ranking de ventas 2023 de
 . . — marcas de Genomma Lab. La empresa produce y comercializa
 SKINCARE/DERMA » “íare oee productos para el cuidado del cabello basados en jalea real de
 HAIR CARE SS Te — +SOMM abejas bajo la marca Tío Nacho, la bebida isotónica
 N — — electrolítica Suerox, el medicamento para osteoartritis X-RA Y
 ANALGESICS SA Al — as y analgésicos como Alliviax, así como las máquinas de afeitar
 ecec Tukolo == X2 — 2s00MM desechables Groomen y productos de cuidado de la piel como
 — , — Asepxia y Cicatricure, entre otros.
 INFANT NUTRITION Novamif +500 MM
 RAZORS 2 BLADES GRCOMEN +150 MM
 OTHERS 41800 MM
 Una de las categorías de mayor crecimiento para Genomma Lab es la de bebidas
 isotónicas (electrolíticas e hidratantes) con su marca Suerox. El año 2023 su
 volumen creció 42%, alcanzando un 4,2% de participación del mercado
 mundial y un 44% de crecimiento compuesto anual (CAGR) desde el 2018. A
 nivel mundial, la categoría de bebidas isotónicas crece significativamente en
 ventas y las predicciones apuntan a un continuo crecimiento, tal como se puede
 observar en la Gráfica siguiente.
 ¡ código universal de producto (UPC, por sus siglas en inglés), combinación de marca, formato,
 versión, con un código de producto único,
 independiente de dónde se venda.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 144

[pág. 145]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2024 | pregunta 3
 Convocatoria 2 | página original 420 | Investigación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Ventas Mundiales de Bebidas Isotónicas (USSB).
 o
 563
 726
 22346
 2169
 Z045
 z 1914
 1770
 1643
 . 2532
 |;G 1.”1 - I
 1qw | I
 2018 2019 2020 2021 2 922 2023 2024 2025 2026 2027 2028
 Cambio en Ventas de Suerox (%)
 | KEY HIGHLIGHTS:
 * :Robust performance across regioris
 * Suerox launched in +10 markets
 CAGR +44% (2018-2023)
 Suponga que uno de los ejecutivos de Genomma Lab, planteaba que se debían tomar decisiones comerciales claves
 respecto de Suerox, en particular, reducir la inversión publicitaria de Suerox en los distintos mercados donde se
 comercializa exitosamente, aumentar el número de formatos y sabores, desde 6 UPC a 15 UPC, e incrementar las
 promociones de precios vía descuentos a los canales de distribución.
 Preguntas:
 1. Considerando la estrategia de reducción del portfolio de UPCs y marcas de Gennoma Lab., identifique los cuatro
 factores principales que debiera considerar la empresa, al eliminar una categoría o marcas de su portfolio.
 Argumente conceptualmente cada factor.
 2. Anmalice críticamente cada una de las propuestas del ejecutivo, respecto de la mezcla comercial para Suerox.
 Argumente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 145

[pág. 146]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2013 | pregunta 1
 Convocatoria 1 | página original 115 | Marcas propias y posicionamiento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº 1
 Filipo Mássimo, gerente general de una de las cadenas de supermercados más importante de nuestro país, se encontraba
 feliz con los resultados obtenidos en la división de marcas propias durante el año pasado. En efecto, éstas habían
 mostrado un crecimiento de aproximadamente un 13,5% con respecto al año 2011 y el margen bruto de todos los
 productos de marca propia había crecido para llegar en el año 2012 a un 14,5%. Actualmente, las marcas propias
 representaban casi un 15% de las ventas totales de esta cadena.
 Las ventas de marcas propias en los supermercados han sido un tema recurrente, desde hace mucho tiempo, en nuestro
 país, al igual que en el resto del mundo, mostrando un crecimiento sostenido en los últimos años.
 Hasta ahora, la estrategia de las cadenas supermercadistas más importantes de nuestro país había consistido en
 desarrollar marcas propias en productos básicos o de conveniencia, como por ejemplo el aceite, azúcar, sal, fideos,
 salsas de tomate, leche, mermeladas y productos de limpieza por nombrar algunos. Estas categorías de productos, que
 en general son producidas por los principales proveedores de marcas tradicionales que operan en nuestro país, se
 caracterizan por enfrentar una alta sensibilidad de precios por parte de los consumidores.
 Desde el punto de vista de los consumidores, el atributo más valorado, en nuestro país, entre quienes consumen marcas
 propias, es su precio más bajo. Le siguen la calidad del producto y la confianza en el punto de venta (supermercado).
 Como contrapartida, para el grupo demandante de marcas tradicionales, el factor determinante para justificar su
 preferencia por éstas resulta ser la percepción de “menor calidad” atribuida a las marcas propias.
 Los resultados de los últimos tres años de la cadena, los cuales se presentan en la siguiente tabla, impulsaron a que su
 gerente general, Filipo Mássimo, se pusiera metas aun más exigentes para el año 2013:
 2010 2011 2012
 Ventas totales (en USS millones) 4.300 4.450 4.600
 Participación de mercado 30% 28% 25%
 Ventas de marcas propias como % de las ventas totales 10,0% 12,5% 14,9%
 Margen bruto sobre el total de las ventas 8,3% 8,1% 7,8%
 Margen bruto de las marcas propias 11,5% 12,5% 14,5%
 Aportes promocionales y publicitarios de los proveedores 16,0% 15,5% 14,5%
 a la cadena como % de las ventas totales
 EBITDA como % de las ventas totales (1) 7,2% 6,5% 6,0%
 (1): Utilidad antes de impuestos, intereses, depreciaciones y amortizaciones de activos
 El nuevo plan comercial
 La nueva estrategia para la división de marcas propias de la cadena era incursionar, antes que cualquier otro
 competidor, en categorías de productos que tuvieran un mayor margen de comercialización para el supermercado.
 El plan incluía el lanzamiento de más 500 productos nuevos en los próximos tres años en categorías de mayor valor
 agregado. Dentro de la propuesta se consideraban productos en categorías como: higiene y aseo personal (ej: shampoo,
 crema de afeitar, desodorante, cremas para el cuerpo), vinos, chocolates finos, productos de fiambrería premium, etc.
 El objetivo fundamental de estos nuevos productos de marca propia, era focalizarse en consumidores de nivel socio-
 económico ABC1 y C2, y en todos los grupos etarios. La idea era dirigirse a consumidores que valoraran más la
 calidad del producto pero con cierta sensibilidad al precio.
 Todos estos nuevos productos de marca propia serían producidos por proveedores locales, siendo algunos de ellos ya
 proveedores de este supermercado a través de sus marcas tradicionales. Además, estos nuevos productos serían
 vendidos en los distintos formatos de esta cadena de supermercado y serían ubicados en los lugares estratégicos y de
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 146

[pág. 147]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2013 | pregunta 1
 Convocatoria 1 | página original 116 | Marcas propias y posicionamiento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 mayor circulación de cada local. La idea era que el consumidor encontrara fácilmente estos productos al interior de
 cada supermercado. Asimismo, la única publicidad que se haría para estos y todos los productos de marca propia sería
 en las salas de venta de cada local y en los catálogos que distribuyera el supermercado a sus potenciales clientes.
 La idea de Filipo, en cuanto a la estrategia de precios para estos nuevos productos, era posicionarse como una
 alternativa levemente más barata, entre un 10% y un 15%, que el resto de las marcas tradicionales en cada una de las
 categorías en que se incursionara.
 Filipo sabía que probablemente los principales detractores a su plan serían sus actuales proveedores, ya que verían
 cómo la cadena de supermercados se convertiría en un nuevo competidor en las categorías en las cuales ellos
 participaban. Lo anterior, podría llevar a una guerra de precios de los productos de estas categorías. También, el plan
 de Filipo incluía el racionamiento (reducción) en el número de marcas tradicionales en las categorías que se
 incursionara con marcas propias. Incluso, los proveedores podrían molestarse ya que no verían reflejado en sus
 resultados la fuerte inversión promocional que estaban haciendo en los distintos puntos de venta de la cadena. A pesar
 de lo anterior, Filipo decidió seguir adelante.
 Sobre la base de la información entregada, a Ud. se le pide responder, de manera breve y precisa, las preguntas que se
 le formulan a continuación:
 1. Un analista al observar los resultados de la cadena, antes del nuevo plan presentado por Filipo, llegaba a la
 siguiente conclusión: “la estrategia de marcas propias desarrollada por la cadena de supermercados ha sido
 equivocada, por cuanto ha deteriorado sus resultados y su participación de mercado”. Señale y explique
 claramente, desde un punto de vista de marketing, los tres principales factores que pueden explicar las conclusiones
 del analista.
 2. Desde el punto de vista de la conducta del consumidor, le parece atractivo el nuevo plan comercial propuesto por
 Filipo para el segmento objetivo. ¿Por qué Sí o Por qué No? Fundamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 147

[pág. 148]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2024 | pregunta 1
 Convocatoria 1 | página original 403 | Marketplace y estrategia de marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº1
 Sin duda, la electromovilidad llegó para quedarse en nuestro país. A nivel gubernamental se están acordando
 diversas acciones y estrategias para sustituir los autos a combustión por alternativas más limpias. Pero no sólo a
 nivel de políticas públicas están impulsándose estas mejoras, las personas también están tomando mayor conciencia
 de la relevancia de hacer un cambio en pro de una mejor calidad de vida. Lo anterior se refleja en el alza que ha
 tenido el uso de bicicletas eléctricas, que en 2023 alcanzaron ventas de más de cinco mil unidades, lo que implicó
 un crecimiento de aproximadamente un 25% con respecto al 2022.
 Este crecimiento del mercado de bicicletas eléctricas ha llevado a una mejora en la infraestructura para ciclistas en
 algunas ciudades de nuestro país. Además, se están implementando más ciclovías para bicicletas y estaciones de
 carga, lo que favorece el uso de este medio de transporte. Asimismo, se ha visto una mayor diversidad de marcas y
 modelos de bicicletas eléctricas tanto locales como internacionales en el mercado que ofrecen opciones para
 diferentes necesidades y preferencias. Así también, los precios de las bicicletas se encuentran en un rango que va
 desde los $500,000 las más básicas hasta los casi $7,500,000 las más sofisticadas.
 Los principales canales de distribución de bicicletas eléctricas pueden variar según la ubicación y el mercado
 específico, pero en general, los más comunes incluyen: a) Tiendas especializadas en bicicletas, las cuales se
 focalizan en la venta de bicicletas y productos relacionados, como accesorios y ropa para ciclistas; b) Cadenas de
 tiendas de deportes, las cuales venden una variedad de productos deportivos, incluyendo bicicletas y productos
 relacionados; c) Tiendas online y marketplaces, las cuales incluyen distintos tipos de plataformas de comercio
 electrónico que permiten a los consumidores comprar bicicletas y accesorios en línea y recibirlos en sus hogares
 (ej: Falabella.com, Mercado Libre, Ripley.com, etc.); d) Tiendas de departamentos y grandes cadenas de
 supermercados, las cuales tienen áreas dedicadas a artículos deportivos, donde también se pueden encontrar
 bicicletas; y e) Venta directa del fabricante o D2C, los cuales se caracterizan por ser el fabricante y/o marca de la
 bicicleta quien le vende directamente a los consumidores a través de sus propios canales online o tiendas físicas.
 Cannondale es una marca muy reconocida en el mercado y fabrica una variedad de bicicletas, incluyendo bicicletas
 eléctricas. Estas son conocidas por su alta calidad y rendimiento. Hasta ahora, la empresa se ha focalizado en las
 bicicletas eléctricas de alta gama y al mercado que valora el tiempo de duración de la batería y la capacidad del
 motor por sobre el precio. Actualmente, la marca comercializa los modelos de bicicletas eléctricas Moterra Neo
 Carbón 1 y Moterra Neo Carbón 2 a un precio de $6,499,990 y $5,499,990 respectivamente. Los canales de
 distribución de Cannondale para sus bicicletas eléctricas y bicicletas incluyen sólo su página web, locales propios
 y algunos distribuidores exclusivos de la marca en nuestro país. La página web y los locales propios de la marca
 representaban el 60% de las ventas y el resto se lograba a través de los distribuidores exclusivos que sólo venden
 bicicletas Cannondale.
 El Gerente General de Cannondale acaba de recibir una invitación de parte de la cadena Falabella para que la marca
 comience a comercializar estos dos modelos de bicicletas eléctricas a través de su marketplace.
 Falabella es una cadena de tiendas de retail con presencia en varios países de América Latina. Originalmente
 comenzó como una tienda de confección, pero con el tiempo se expandió para incluir una amplia gama de productos,
 desde ropa y accesorios hasta electrodomésticos, muebles, artículos para el hogar y artículos deportivos. Esta cadena
 tiene como principal segmento objetivo los sectores de clase media y media alta de nuestro país y se caracteriza por
 ofrecer una gran cantidad de marcas de reconocidos proveedores en múltiples categorías, así como así también una
 importante y creciente oferta de marcas propias en prácticamente todas las categorías que ofrece. Además, Falabella
 ofrece un servicio de financiamiento a través de su propio banco y de su tarjeta CMR, la cual ofrece la posibilidad
 a los clientes de comprar productos a crédito.
 Por su parte el marketplace de Falabella es una plataforma digital que reúne a varios vendedores y una gran gama
 de categorías y productos. El marketplace actúa como intermediario en el proceso de compraventa, con distintas
 tarifas o comisiones para los vendedores que deciden comercializar sus productos a través de este. Los compradores
 online pueden acceder al marketplace de Falabella para consultar el catálogo de varias marcas, realizar búsquedas
 por tipo de producto, precio y multitud de palabras claves. En este marketplace los vendedores pueden publicar
 pagando una comisión sobre el valor del producto vendido, que incluye el costo de utilizar el procesador de pago,
 y una mejor ubicación en los listados de búsqueda. Por su parte, el marketplace de Falabella establece la ubicación
 de los productos de los vendedores en las distintas secciones de su plataforma y les pide una foto estándar a cada
 uno de ellos de los distintos modelos ofrecidos. El precio público del producto es establecido por los vendedores y
 no por el marketplace.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 148

[pág. 149]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2024 | pregunta 1
 Convocatoria 1 | página original 404 | Marketplace y estrategia de marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 El Gerente General de Cannondale le pidió al Gerente de Marketing y al Gerente de Ventas de la empresa su
 recomendación en cuanto a si debían aceptar la invitación de Falabella para comercializar sus dos modelos de
 bicicletas eléctricas en el marketplace de la cadena.
 El Gerente de Marketing de Cannondale pensaba que no deberían comercializar las bicicletas eléctricas a través este
 canal. Sus principales preocupaciones eran la posibilidad de no cumplir con los requerimientos de entrega y plazo
 de los productos que los clientes ordenaban a través de esta plataforma. Asimismo, le preocupaban los costos que
 implicaría vender a través de este marketplace, desde la publicidad que debían pagar, hasta el mayor costo financiero
 que implicaba vender a través de este portal, ya que Falabella se demoraba en promedio 45-60 días en hacer las
 liquidaciones de las compras de sus clientes a los proveedores. De acuerdo a sus cálculos el margen operacional por
 comercializar en este canal era un 15% menor comparado al logrado en sus actuales canales. El Gerente de
 Marketing señalaba que estos modelos de bicicletas debían seguir siendo comercializado a través de los actuales
 canales de la marca.
 Por su parte, el Gerente de Ventas pensaba que entrar al marketplace de Falabella era una gran oportunidad para la
 marca. Dentro de las fortalezas que destacaba de este marketplace era el potencial número de clientes que podía
 atraer a la marca que hoy era inalcanzable con los canales con que contaba. El marketplace de Falabella era el líder
 en cuanto a venta de comercio electrónico en el país alcanzando un 34% de las ventas online (Mercado Libre
 alcanzaba sólo el 24%). Además, señalaba que al estar en el marketplace líder del mercado le daba un mayor
 reconocimiento de marca y la posibilidad de acceder a un nuevo segmento de mercado para la marca. Asimismo,
 mostraba que más del 50% de los clientes que compran online iniciaban su proceso de compra a través de un
 marketplace. También señalaba que existía una gran cantidad de marcas con diferentes modelos de bicicletas
 eléctricas y con un amplio rango de precios. De hecho, señalaba que existían más de cuatro marcas que ya
 comercializaban sus modelos de bicicletas eléctricas en el marketplace de Falabella a precios similares a la de los
 modelos de Cannodale. Finalmente, señalaba que no existían riesgos en cuanto a la fijación de precios de las
 bicicletas en al marketplace, ya que estos eran fijados por Cannondale lo que permitía alinearlo con los del resto de
 sus canales de distribución.
 Preguntas
 a) De acuerdo a la información señalada en el caso, señale y explique claramente cuatro factores que debiera
 considerar el Gerente General de Cannondale para tomar la decisión de entrar a comercializar sus modelos de
 bicicletas eléctricas en el marketplace de Falabella.
 b) De acuerdo a la información entregada en el caso, señale y explique claramente los tres principales riesgos para
 Cannodale, desde el punto de vista de su estrategia de marca, de comercializar sus modelos de bicicletas
 eléctricas a través del marketplace de Falabella.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 149

[pág. 150]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2014 | pregunta 1
 Convocatoria 1 | página original 138 | Nuevo producto, posicionamiento y canibalización
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 1
 En 1982 la empresa Coca-Cola introdujo en Estados Unidos la bebida gaseosa Diet Coke (que fue vendida como
 Coca-Cola Light en el resto del mundo), eliminando las calorías de la tradicional Coca-Cola al usar aspartame, un
 endulzante artificial. En 2005, la empresa lanzó exitosamente Coca-Cola Zero, originalmente dirigida a los hombres
 y promocionada como libre de calorías pero con similar sabor al de la Coca-Cola tradicional, usando también
 endulzantes artificiales. Ambas bebidas (Light y Zero) representan hoy aproximadamente el 20% del total de bebidas
 cola que vende Coca-Cola en el mundo, y en varios países, Zero supera actualmente en ventas a Light. Hacia fines del
 2013, la bebida “Coca-Cola Life” fue introducida exclusivamente en Argentina y Chile, como mercados de prueba.
 “Coca-Cola Life” es endulzada con extracto de Stevia, hierba originaria de Brasil y Paraguay, y en menor medida con
 azúcar, logrando tener un 60% menos calorías que la Coca-Cola regular.
 El nuevo producto, Coca-Cola Life, tiene 36 calorías por cada 200 cc. Es la primera Coca-Cola endulzada
 naturalmente con Stevia y azúcar. Esto es una mezcla que permite que la bebida sea baja en calorías, y hace que se
 encuentre en el intermedio entre las Coca-Cola Light y Zero -que no tienen calorías- y la Coca-Cola regular. Stevia es
 percibido como el endulzante más natural respecto de otros endulzantes como la sucralosa, sacarina, aspartame y el
 azúcar mismo.
 La marca Coca-Cola, con 127 años de antigtiedad, es una de las más reconocidas y valiosas del mundo (Interbrand,
 2013). En los últimos 20 años, la empresa ha expandido su alcance en el mundo de las bebidas en categorías tales
 como: aguas filtradas, saborizadas, vitaminizadas y minerales; jugos de fruta; isotónicas; energizantes; entre otras
 bebidas. Del total de bebidas vendidas por la empresa Coca-Cola, un 75% son gaseosas y un 48% son vendidas bajo
 la marca Coca-Cola,
 La venta de bebidas gaseosas en EE.UU., el principal mercado, han estado cayendo entre un 1% y 2% por año,
 llegando el 2013 al nivel que tenían en 1996. Algo similar ocurre en todo el mundo, respondiendo a una tendencia que
 busca productos de bajas calorías, como resultado de una mayor conciencia sobre los problemas de la obesidad y una
 preferencia creciente por productos naturales. A. lo anterior se agrega el efecto demográfico de envejecimiento de la
 población, lo que la hace que las personas se preocupen relativamente más de su salud y bienestar.
 Un reciente estudio a nivel mundial, en una muestra representativa de consumidores de bebidas gaseosas, cuyos
 beneficios buscados en una bebida gaseosa y su importancia relativa son homogéneos, arrojó los resultados que se
 muestran en la siguiente Tabla:
 Notas (Ver Observación 1)
 Beneficios Percibidos Importancia Re_lativa Coca-Cola Cocg-Cala Coca-Cola Marca ! Marca . Marca |
 (Ver Observación 2) | Regular Light Zero Competencia 1 | Competencia 2 | Competencia 3
 Quita la sed 14 7 6 6 5 5 2
 Es sabrosa 9 7 5 7 4 5 3
 Es natural 4 2 4 3 7 1 1
 Es dulce 9 7 4 6 4 6 5
 Nutritiva 1 0 3 2 6 3 1
 “IMe despierta 12 6 6 6 3 5 7
 No engorda 16 0 7 6 6 0 3
 Me llena 2 6 5 6 2 3 2
 Su endulzante es natural 3 0 4 3 6 Le) 1
 Es alegre 7 7 6 7 4 5 7
 Buena para compartir 9 7 7 7 5 5 6
 Bajas calorías 10 3 7 5 7 2 1
 Me da energía 4 5 5 5 2 4 7
 100
 Observación 1: Las percepciones de cada beneficio percibido en las distintas marcas de la Tabla, son evaluadas con una
 nota que va desde 0 a 7, siendo 7 la mejor evaluada.
 Observación 2: La importancia relativa es porcentual. A mayor %, mayor importancia tiene ese beneficio en la decisión de
 compra.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 150

[pág. 151]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2014 | pregunta 1
 Convocatoria 1 | página original 139 | Nuevo producto, posicionamiento y canibalización
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Un analista de la industria, planteaba que el lanzamiento de “Coca-Cola Life” era un gran error y que sólo confundiría al
 consumidor y afectaría negativamente las ventas de la familia completa de las bebidas que se vendían bajo la marca
 Coca-Cola. En cambio, ejecutivos de Coca-Cola respondían que “Coca-Cola Life” era una correcta aplicación de los
 conceptos de marketing en beneficio de la categoría de bebidas gaseosas.
 PREGUNTAS:
 a) Si el objetivo de la empresa Coca-Cola fuera aumentar las ventas en la categoría de bebidas gaseosas con marca Coca-
 Cola, ¿qué debe lograr Coca-Cola Life en la mente de los segmentos meta? Argumente su respuesta precisando la (s)
 fuente (s) de origen más probable (s) del volumen incremental esperado.
 b) Más allá de aumentar las ventas, ¿qué otros argumentos podría haber tenido en mente la empresa Coca-Cola para
 lanzar al mercado “Coca-Cola Life”? Respanda en forma breve y precisa.
 e) ¿Qué factores podrían hacer fracasar a “Coca-Cola Life”, considerando que su estrategia comunicacional ha sido
 evaluada como bien hecha y que sus precios son competitivos? Argumente en forma concisa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 151

[pág. 152]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2018 | pregunta 1
 Convocatoria 2 | página original 266 | Plataforma de dos clientes y precio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTAN'1
 notable del
 El sistema Autocar representa un nuevo modelo de negocio en la industria automotriz y un cambio
 o (distribuidor) de la
 proceso de distribución automotriz tradicional. Autocar.com se ubica entre el concesionari
 Cuando
 marca tradicional de automóviles y el consumidor final del vehículo, proveyendo una serie de servicios.
 gran cantidad de información objetiva en un solo lugar
 un cliente visitaba el sitio web Autocar.com, accedía a una
 vehículos, teniendo pre-acordado el precio vía Autocar.com . Es decir, no necesitaba
 y podía pre-comprar
 “negociar” el precio con el vendedor del concesionario.
 y
 Los compradores que iniciaban el proceso de búsqueda de un auto en Autocar.com, lo podían hacer por marca
 También accedían a información acerca de las especificacio nes del modelo
 modelo mediante distintos filtros.
 sus
 base y su precio acordado con el concesionario. Una vez que los compradores comenzaban a reducir
 de información automotriz (artículos, testimonios, videos, etc.) acerca
 alternativas, podían acceder a una variedad
 de sus autos preferidos. Cuando los clientes finalmente se habían decidido por una marca y un modelo, Autocar
 les permitía “construir” su auto desde lo más básico a lo más elaborado. Autocar automáticamente incluía las
 cómo
 características estándar del vehículo y los clientes podían agregar paquetes de opcionales y observar
 cambiaban los precios ya “negociados” del concesionario , Una vez que el vehículo estaba “construido”, los
 podían enviar una pre-solicitud de compra, gratis y libre de obligaciones (no tenían ninguna
 consumidores
 eran
 obligación de comprar) para el vehículo de su elección. Los prospectos de compra (potenciales clientes)
 derivados a un concesionario de la marca elegida y asociado a Autocar (el cual había recibido derechos exclusivos
 para
 de una marca para un territorio geográfico determinado), y el concesionario contactaba al potencial cliente
 el precio acordado
 que fuera a probar el auto. El concesionario que operaba con Autocar estaba obligado a respetar
 con
 con Autocar para el consumidor, el cual era entre un 4-5 % menor que el precio de lista. Esto se comparaba
 el 6% de descuento que un comprador buen negociador, podía lograr en una negociación presencial.
 en
 En la industria automotriz los autos nuevos se venden tradicionalmente a través de transacciones negociadas
 , este
 forma personal entre el comprador y el vendedor del concesionario de la marca. Para muchos consumidores
 más grande
 proceso les produce angustia e inseguridad. La compra de un auto es considerada la segunda compra
 que la mayoría de los consumidores hace en su vida (después de la compra de una casa). Por este motivo, la
 compra de un auto tiende a ser un proceso tanto racional como emocional.
 tienen
 Por lo general, cuando los consumidores entran en un concesionario para comprar un auto nuevo,
 poca información con respecto a las variables de calidad de los distintos modelos y marcas, precios,
 relativamente
 opcionales, y otro tipo de información relevante. Sin embargo, como saben que el precio del auto es negociable,
 favorable.
 se ven enfrentados a la ardua tarea de regatear con el vendedor para obtener un precio percibido como
 Después de Jlegar a un acuerdo en el precio, el cliente por lo general tiene que encontrarse con varios otros
 parte
 ejecutivos antes de poder retirar el auto del concesionario. Si el cliente tiene un vehículo usado para dar en
 de pago por el vehículo nuevo, se llama a un encargado de autos usados para que inspeccione ese vehículo usado
 y negocie su precio. Si el cliente busca financiamiento (cerca del 75% de las transacciones automotrices
 Y
 involucraban algún tipo de financiamiento y seguro), un ejecutivo distinto maneja esta parte de la transacción.
 si el cliente busca repuestos y accesorios adicionales, es dirigido a un vendedor de servicio post venta.
 En general, los concesionarios automotrices derivan sus ingresos de tres fuentes principales: la venta de vehículos
 las
 nuevos y usados, servicios técnicos, repuestos y financiamiento. El siguiente cuadro muestra las ventas y
 utilidades de un concesionario típico y su evolución en 10 años,
 ( 2007 _ 2017
 Participación en las ventas (%)
 Autos nuevos 62% 50%
 Autos usados 20% 20%
 Servicio € repuestos, financiamiento 18% 30%
 Margen Bruto (%)
 Autos nuevos 10% 6%
 Autos usados 27% 30%
 Servicio ¿z repuestos, financiamiento 40% — 60%
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 152

[pág. 153]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2018 | pregunta 1
 Convocatoria 2 | página original 267 | Plataforma de dos clientes y precio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 de la
 El vicepresidente de marketing de Autocar.com, estaba revisando los resultados del primer semestre
 un 70% en
 empresa. Al revisar las cifras se dio cuenta que los ingresos de la empresa no sólo habían aumentado
 67
 comparación con el mismo semestre del año anterior, simo que la empresa además estaba promediando
 de compra (potenciales clientes) al mes para cada uno de los 300 concesionario s de su red a lo largo
 prospectos
 el primer
 del país. La mala noticia era que la empresa aún estaba con problemas de caja. Las ventas durante
 de U$10 millones, sín embargo, las pérdidas alcanzaron los US$150.000 durante el mismo
 semestre fueron
 que el crecimiento era esencial para mantener la
 período. El vicepresidente de marketing estaba consciente
 inversionistas . Por ende, el principal objetivo de la empresa era acelerar el crecimiento de los
 confianza de los
 ingresos.
 la red.
 El 100% de los ingresos de Autocar provienen de pagos hechos por los concesionarios pertenecientes a
 inscripción, por una sola vez, de US$ 2.000 por concesionario además de una
 Anutocar recibía un pago inicial de
 puerta
 cuota mensual de US$ 1.000 por cada uno de los concesionarios participantes, por envíar casi-clientes a la
 marcas
 del concesionario. Autocar asignaba a cada concesionario un territorio geográfico exclusivo en base a
 Autocar
 específicas de vehículos y ya estaba alcanzando el nivel de 90% de cobertura en el territorio nacional.
 que la
 estimaba que el 20% de los prospectos de compra que recibía la empresa terminaban en ventas, cifra
 mayoría de los analistas de la industria consideraba que era significativamente mayor que la de sus competidores
 un ahorro
 y la de los propios concesionarios, Además, los concesionarios que participaban en Autocar tenían
 importante en costos de personal y marketing.
 de compra
 Autocar enfrentaba una dura competencia por parte de una serie de fuentes, incluyendo los servicios
 onlíne, los sitios web de los fabricantes y los sitios web de los concesionari os locales. Los principales
 os
 competidores de Autocar eran: Autoweb.com y AutoDirecto.com. Estos trabajaban con muchos concesionari
 La
 en un área determinada, no dando territorios exclusivos, de manera de ofrecer un precio más competitivo.
 a los concesionari os era de U$30 por solicitud más un cobro de una sola
 cuota que le cobraban estas empresas
 vez por ser miembro del sistema de U$2.000.
 PREGUNTAS
 a) Como una forma de mejorar sus resultados, el vicepresidente de marketing de Autocar está pensando lanzar
 un nuevo servicio: Autocarservicios.com, el cual consistiría en ofrecerle a los consumidores la oportunidad
 de obtener servicios de mantenimiento, repuestos, y financiamiento y seguros para sus vehículos, utilizando
 un sistema de precios pre-negociados (similar al que ya tiene). De esta manera, los consumidores tendrían,
 además de los concesionarios de la red, más opciones donde comparar y llevar a cabo la compra (por ejemplo:
 de
 bancos, compañías de seguros, talleres de autos, mecánicos independientes, etc.). Desde el punto de vista
 no?
 marketing, ¿le parece acertada la estrategia del vicepresidente de marketing? ¿Por qué sí o por qué
 Justifique claramente su respuesta.
 los
 b) Algunos analistas pensaban que una forma rápida para mejorar los resultados de Autocar era subiendo
 ¿está Ud. de
 precios que cobraba a los concesionarios por su servicio. Desde el punto de vista de marketing,
 acuerdo con los analistas? Justifique claramente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 153

[pág. 154]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2015 | pregunta 1
 Convocatoria 2 | página original 173 | Plataforma de dos lados y surge pricing
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 1
 El mercado de los taxis en el mundo no había cambiado mucho en los últimos 50 años hasta la llegada de
 una nueva generación de empresas de taxi tales como Uber, SaferTaxi, EasyTaxi y varias más. El tradicional
 taxi en Londres o en Santiago, se contrata en la calle con un precio base (bajada de bandera) y luego un
 cargo que está asociado a la distancia recorrida y un recargo cuando el auto está detenido. Estos precios por
 bajada de bandera y distancia recorrida están regulados y no pueden ser cambiados por el chofer. Por ello,
 existe un taxímetro que va en el auto. También están las empresas de “radio taxi” a las cuales uno llama para
 que lo vayan a buscar a una determinada dirección y finalmente, están los colectivos, con precios fijos
 basados en recorridos preestablecidos,
 La empresa Uber fue creada el año 2009 en Estados Unidos y hoy existe en alrededor de 50 países y en 200
 ciudades, incluida Santiago. Uber es una plataforma que permite unir a los usuarios en necesidad de
 transporte con choferes independientes, dispuestos a llevarlos por un precio, de los cuales Uber obtiene
 aproximadamente el 20%, El servicio que ofrece Uber al usuario es el uso de una aplicación móvil sobre un
 teléfono inteligente y con capacidad de uso de GPS, para solicitar un auto y chofer previamente calificados
 por Uber y con altos estándares de servicio. La aplicación entrega el tiempo exacto para ser recogido e
 informa de la llegada del auto vía el celular. El cobro por el servicio es una combinación de tarifa base (ej.
 $800) más un cargo por distancia (ej. $300/km) y por minutos recorridos (ej. $120/min.). Al terminar el
 viaje, Uber informa al usuario el costo total del viaje vía el celular y lo carga a la tarjeta de crédito
 (previamente registrada en web) del pasajero, con la aprobación de éste. El pasajero puede luego evaluar al
 chofer y el trayecto vía su aplicación.
 El chofer, que se une junto con su auto a la red de Uber como independiente, recibe como depósito directo
 en su cuenta aproximadamente el 80% de la tarifa cobrada por Uber en cada trayecto. El chofer aporta el
 auto (con estándares mínimos exigidos de calidad del vehículo, tales como marca, antigiiedad y tamaño,
 entre otros), y asume todos los costos de mantención, combustible y seguros.
 Uber, por su parte, asume los costos del pago con tarjeta de crédito, y se preocupa del servicio de atención
 a clientes (call center y web) y del desarrollo de la aplicación. Los choferes son independientes y ellos
 deciden libremente, en cada solicitud de trayecto, si la aceptan o no, así como las horas y días en que salen
 a trabajar. Ellos no tienen vínculo contractual de trabajo con Uber. Uber selecciona estrictamente a los
 choferes/autos que postulan a pertenecer a la red y mantiene limitado el número de choferes de la red para
 garantizar la calidad. El auto debe cumplir con las exigencias de Uber, pero no requiere pintarse de color
 negro—amarillo ni tener taxímetro. Los choferes no necesitan permiso oficial especial alguno para operar
 sus autos con Uber.
 En los días en que ocurren extremos climáticos (Illuvias, nevazones, etc.) o eventos masivos (ej. eventos
 deportivos, manifestaciones, conciertos, etc.), Uber aplica una tarifa especial mayor en el área del evento,
 que duplica o triplica el valor regular mientras dure el evento (se conoce como “Surge Price”: 2X 6 3X), la
 cual es informada al potencial pasajero cuando pide el taxi vía su aplicación.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 154

[pág. 155]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2015 | pregunta 1
 Convocatoria 2 | página original 174 | Plataforma de dos lados y surge pricing
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTAS
 1) Considerando el modelo de negocios de Uber, ¿qué tipos de clientes ha descubierto Uber que le han
 permitido diferenciarse y ser exitoso? ¿Cuál es la propuesta de valor de Uber para cada tipo de cliente?
 2) El uso del incremento en precios (“Surge Price”) en días de eventos especiales ha generado muchas
 críticas de algunos pasajeros y de la opinión pública, que han visto que el costo del trayecto, mientras
 dure el evento, se multiplica por dos o tres veces respecto del precio normal. Aplicando conceptos de
 marketing, argumente por qué es fundamental esta política de precios para el modelo de negocios de
 Uber,
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 155

[pág. 156]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2011 | pregunta 1
 Convocatoria 2 | página original 73 | Precio, difusión y canales
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº 1
 Los autos eléctricos están llegando a Chile. Varias marcas están comenzando a pensar en lanzar modelos con propulsión
 eléctrica dado el interés mundial y también en nuestro país por estas nuevas tecnologías. Por el alto costo, todavía se
 clama por ayuda estatal para incentivar su uso.
 Un auto eléctrico se caracteriza por el bajo nivel de ruido y su bajo consumo de energía. A esas cualidades se suman
 varias otras, como que no contaminan el medioambiente y, pese a que su precio es relativamente alto al compararlo con
 autos similares pero de combustible tradicional (bencina), el costo de la carga de electricidad para su funcionamiento es
 mucho más bajo que si llenáramos el estanque con bencina. Cuatro veces más económico que este último. La autonomía
 de viaje con carga eléctrica total es de 100 kilómetros versus los 400 kms. del auto convencional con estanque lleno. La
 carga de su batería se realiza a través de un equipo en el hogar (carga lenta durante la noche) y a través de “electrolineras”
 o puntos de recarga de baterías en diversas partes de la ciudad y de la carretera. Un auto tradicional consume anualmente
 cerca de $1,8 Millones en bencina. Una carga rápida de 20 minutos en una electrolinera, permitiría que la batería quedara
 a una capacidad del 100%. En Chile, los clientes que tienen vehículos en los rangos de precios entre $15M y $25
 millones, los cambian cada 4 años.
 La primera marca en aterrizar comercialmente con estos modelos en Chile fue la japonesa Mitsubishi, que ha vendido
 cinco unidades de su iMiev en la Región Metropolitana sólo en el primer mes de oferta. Varias otras firmas tales como
 Nissan, han anunciado la llegada de modelos eléctricos para el próximo año. También la china BYD -que a nivel local
 trabaja en alianza con la distribuidora de autos “Indumotora”- y cuyos ejecutivos estuvieron hace poco en el país
 promocionando sus “hatchbacks” eléctricos.
 Hoy un iMiev se vende al consumidor en Chile en $20 millones, mientras que un auto equivalente en características
 técnicas y diseño, pero con motor a bencina, tiene un precio de $16 millones. Al precio de venta de $20 millones, el
 margen bruto sobre ventas para Mitsubishi, en su modelo iMiev en Chile, es de 60%. Con otros modelos similares de
 Mitsubishi pero con motor a bencina, el margen bruto es de 50%. A su vez, la simpleza de su motor eléctrico, permite que
 el costo de mantención anual de un auto eléctrico para el cliente sea de $1,0 millones por año, versus $1,6 millones de un
 auto a bencina convencional similar.
 Si bien el potencial de los autos eléctricos en Chile es alto, para que todo esto funcione en la práctica casi todos los
 involucrados advierten que se requiere apoyo estatal, porque el precio de los vehículos todavía es muy alto. Pero los
 beneficios ambientales justificarían los subsidios, dicen, como se hace en Estados Unidos, Europa o recientemente en
 China, donde a través de diversos mecanismos, el estado sí está dando subsidios. “En Chile también esperamos que el
 gobierno pueda proporcionar algunos subsidios para apoyar esta iniciativa”, sostuvo, Henry Li, director de operaciones
 internacionales de BYD Auto, uno de los ejecutivos chinos que estuvo en Chile.
 En el Ministerio del Medio Ambiente, las autoridades están trabajando en un conjunto de incentivos para vehículos
 eléctricos. Una alternativa es que los autos de estas características puedan tener una reducción en el pago del permiso de
 circulación anual. Por ejemplo, en el caso del iMiev se podría rebajar en $500.000 por año el pago de impuestos por los
 primeros 4 años.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 156

[pág. 157]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2011 | pregunta 1
 Convocatoria 2 | página original 74 | Precio, difusión y canales
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 Entre los impulsores de estos vehículos en Chile está también el grupo Enersis, que a través de Chilectra está evaluando
 masificar la idea de usar la electricidad también para mover autos. Incluso adquirieron un iMiev con el que promocionan
 el uso de estos vehículos entre sus clientes.
 Como se supone que estos autos, de un modo u otro llegarán al país, Chilectra comenzó a trabajar en un plan para instalar
 puntos de carga, también conocidos como electrolineras. La empresa ha recibido dos alternativas de puntos de carga. Por
 un lado, Petrobras, la empresa distribuidora de combustibles, ha ofrecido instalar puntos de carga en 120 de sus
 estaciones de servicio de combustibles. La otra oferta es de la cadena de supermercados Lider-Walmart que instalaría
 puntos de carga en los estacionamientos de sus cerca de 100 supermercados Hiper-Lider y Express Lider. Suponga que
 ambas empresas cubren geográficamente en forma similar tanto las principales ciudades como las carreteras a lo largo del
 país. Por otra parte, se sabe que Chilectra le vendería al mismo precio-distribuidor a cualquiera de las empresas que
 finalmente elija, la que a su vez lo venderá al consumidor al precio que le cobra Chilectra más un margen. Por el alto
 costo de la inversión que Chilectra tendría que hacer en los puntos de carga, las alternativas de distribuidores son
 mutuamente excluyentes, es decir, Chilectra deberá elegir sólo uno de ellos.
 A usted se le pide responder:
 1. ¿Por qué la empresa Mitsubishi piensa que puede cobrar un precio superior por sus modelos iMiev en relación a un
 auto convencional similar de la misma marca?. Fundamente su respuesta. Suponga que para Mitsubishi el costo de
 fabricar un auto eléctrico es igual al de fabricar un auto con motor a bencina y si lo requiere, suponga que la tasa de
 descuento apropiada para actualizar cualquier flujo futuro es cero.
 2. ¿Si usted fuera ejecutivo de Chilectra, qué opción de distribución elegiría: Petrobras o Walmart? Indique las tres
 principales ventajas de la opción de distribución que usted elegiría.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 157

[pág. 158]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2019 | pregunta 1
 Convocatoria 2 | página original 290 | Precio, servicio y modelo de negocio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N'1
 La industria de la minería de cobre en Chile es de alto nivel
 deinversión en bienes de capital, los cuales se usan en los
 distintos procesos extractivos. Aspectos claves de su
 modelo de negocios son el control de costos, la continuidad
 seguridad y el eficiente uso
 Ta ivos,
 de los procesos product
 de activos. Una de las inversiones relevantes son los
 camiones tolva (que transportan hasta 400 toneladas de
 mineral y roca desde la mina hasta las plantas de proceso),
 los cuales tienen un costo de adquisición superior a los
 USD$4 millones. Una mina de gran tamaño en Chile, ocupa
 entre 60 y 100 camiones tolva en su operación diaria, La
 vida útil de un camión es de 15 años en promedio.
 En el contexto de la continuidad de procesos, una variable clave en la gestión de la flota de camiones tolva, es
 garantizar su máxima disponibilidad operativa las 24 horas del día, los 365 días del año, de tal forma de no
 interrumpir los traslados de mineral a la planta. Un ejemplo de reducción en la disponibilidad en los camiones
 tolva, se refiere a los tiempos dedicados a mantención, en los que el camión debe parar. Dado que el tamaño
 del motor del camión minero es de más de 16 cilindros, su consumo de aceite es significativo y requiere un
 proceso de cambio de aceite, en el que éste debe decantarse, luego aspirarse y finalmente rellenar con aceite
 nuevo, para permitir el funcionamiento del camión. Cuando el aceite debe ser cambiado, el camión debe
 [levarse al taller de la mina y hacer el “cambio de aceite”, faena que debe hacerse cada S00 horas de
 funcionamiento y que, dado el alto consumo, demora aproximadamente 4 horas. Un proceso de duración
 similar ocurre cuando deben cambiarse los neumáticos (de más de 3,5 metros de diámetro), cuyo valor de
 compra es de USD$100.000 cada uno y su duración promedio de uso es de 15 meses,
 En los últimos 20 años, el líder en ventas de camiones para la Minería ha sido Caterpillar, representado en
 Chile por Fiming, con un 52% de participación de mercado. Otros competidores son la japonesa Komatsu
 (44%) y otras empresas (4%). Estas empresas venden sus camiones a las Mineras y luego prestan servicios de
 mantención y reparación en la Mina bajo un contrato de pago fijo mensual. La tasa de disponibilidad técnica!
 promedio de los camiones de estos proveedores, fue de 85% en el último año.
 Suponga que un nuevo competidor, la alemana Liebherr, empresa relevante en el mercado mundial, quiere
 entrar al mercado chileno. Hasta ahora no ha podido obtener contratos de venta de camiones a empresas
 mineras, debido a que el precio de venta de sus camiones es superior al de la competencia. Según uno de sus
 gerentes, el precio de mercado en Chile no es suficiente para sus expectativas de rentabilidad ni para cubrir
 sus costos, los que se justifican debido a la mejor tecnología en los equipos. Por ejemplo, en el caso del
 consumo de aceite, sus camiones usan un sistema de relleno permanente lo que evita tener que parar el camión
 por varias horas, ya que simplemente rellena el depósito de aceite, con aceite nuevo, tal como se hace con el
 combustible. Así, el tiempo de parada se reduce a media hora y coincide con el de llenado de combustible.
 En una reunión de ejecutivos de Liebherr, se discutía la mejor forma de entrar el mercado chileno. Sigmund,
 gerente comercial, planteaba que no quedaba más alternativa que bajar precios por debajo de la competencia,
 junto con ofrecer una serie de servicios de mantención de los camiones en la mina, a costo cero en mano de
 obra para los clientes. “Lo importante es entrar como proveedor de camiones y luego ir subiendo los precios
 cuando los clientes, solos, se den cuenta de lo bueno que es Liebherr y de sus grandes beneficios”, enfatizaba
 Sigmund.
 Por otra parte, el gerente de Marketing, Wolfgang, planteaba que “había que pensar fuera de la caja, y que era
 mejor que solamente arrendáramos nuestros camiones, incluyendo un innovador contrato que garantizada una
 disponibilidad técnica del 95%, Liebherr se haría cargo de todos los costos de mantención y reparación,
 incluyendo aquellos de los neumáticos, y de todos los repuestos e insumos. El cobro mensual sería por tonelada
 1 Se entiende por disponibilidad técnica el número de horas sobre un total potencial, en que el camión está operativo para
 el transporte de mineral.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 158

[pág. 159]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2019 | pregunta 1
 Convocatoria 2 | página original 291 | Precio, servicio y modelo de negocio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 métrica transportada. “Esto significa que el cliente siempre conoce su costo por tonelada mientras dure el
 contrato. El no tiene que preocuparse por reclamos de garantía, disponibilidad de repuestos, ni aspectos
 mecánicos; nosotros 0s encargamos de todo. El cliente puede concentrarse en hacer minería,” dijo Wolfgang.
 De acuerdo a la información entregada en el caso y a sus conocimientos comerciales, se le pide responder lo
 siguiente:
 a) Señale y explique los tres argumentos principales en contra de la opción planteada por Sigmund, el
 Gerente Comercial.
 b) Señale y explique los tres argumentos principales a favor de la opción de Wolfgang, Gerente de
 Marketing.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 159

[pág. 160]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2016 | pregunta 1
 Convocatoria 1 | página original 185 | Premiumización y prueba de producto
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 1
 PREGUNTA N* 1
 Un reciente estudio concluyó que los chilenos somos los que tomamos más té en latinoamérica, llegando a la
 cifra de 77 litros anuales, Se trata de 387 tazas anuales per cápita (versus 86,7 en Argentina). El té en Chile tiene
 una penetración de mercado del 99,4% y mientras nuestros vecinos siguen deleitándose con el mate, la hoja de
 cocay el café, nosotros seguimos disfrutando este legado británico. Las estadísticas nos indican que cada chileno
 consume por lo menos una taza de té al día, lo que nos ubica dentro de los 20 consumidores, per cápita, más
 grandes del mundo. A nivel mundial el consumo del té va en aumento, debido a clientes que buscan estilos de
 vida más saludables y que han reorientado su consumo hacia el té de variedades como el té verde y los
 saborizados, dejando de lado otras bebidas con mayor cafeína o azúcar, así como también clientes que buscan
 sofisticar su consumo con productos de mayor valor agregado. Al igual que con el café, se observa un segmento
 creciente de consumidores que valoran y conocen los distintos orígenes geográficos y variedades de té.
 La categoría en Chile ha crecido un 10% en valor en los últimos 5 años, llegando a US$ 205 millones en ventas,
 aunque a nivel de volumen creció menos del 5% en dicho período. El mercado nacional está liderado por dos
 empresas: Cambiaso Hermanos, con un 46% de participación de mercado en volumen (Té Supremo y Pure
 Ceylon Tea) y Unilever con un 43% de participación (Lipton y Té Club). Aproximadamente un 85% de las
 ventas de Cambiaso Hnos. y Unilever en la categoría Té, provienen de las líneas tradicionales más económicas
 (precio menor a $800 por caja de 30 unidades).
 Durante el año 2015, Cambiaso Hnos. lanzó al mercado, bajo su marca Té Supremo, la línea “Pirámides”, con
 mezclas de té premium de la India y bajo un empaque en forma de pirámide que aprovecha de manera más
 eficaz el té y se acerca a los envases similares de marcas premium como Twinnings y otras importadas, que las
 tienen en sus líneas de productos.
 La mezcla comercial de “Piramides” incluye publicidad en medios masivos como TV abierta , diarios y redes
 sociales, con un personaje indio y un mensaje que privilegia el humor y el origen indio del té, y distribución
 intensiva a nivel nacional a través del canal “supermercados” orientados al segmento socio económico medio-
 alto. Los precios a público de “Pirámides” son de aproximadamente $2.800 (por caja de 15 unidades)
 comparados con la línea Té Supremo Ceylán (precio de $880 por caja de 30 unidades) y Té Supremo Rendidora
 (precio de $360 por caja de 30 unidades). Otros competidores que traen té importados tales como Twinnings,
 tienen precios que oscilan en el rango $3.000 - $3.960. Unilever, el mayor competidor de Cambiaso Hnos.
 tiene líneas de té con precios similares en los rangos menores a $1.300.
 El cuadro que se muestra a la derecha, resume los rangos de precios Eºz¿%remo
 promedio
 , 1
 a público
 Thlic
 a los cuales se venden las distintas
 1eti
 líneas
 í
 de tés bajoi Y Adom le Ce
 la marca Té Supremo de Cambiaso Hermanos. Los precios corresponden
 Pirámides $2.820
 a cajas que contienen 20 unidades (bolsitas) con excepción de “Pirámides
 que trae 15 unidades (bolsitas) por caja.
 Saborizados ! [$ 1.080-$1.200]
 Ceylan [$ 750 - $ 879]
 Rendidora [$ 320 - $ 400]
 Nota:
 Cajas de 20 unidades excepto Pirámides
 que trae 15 unidades por caja.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 160

[pág. 161]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2016 | pregunta 1
 Convocatoria 1 | página original 186 | Premiumización y prueba de producto
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTAS
 1) Considerando la posición competitiva de Cambiaso Hermanos y el contexto del mercado descrito,
 explique las tres principales razones comerciales que justificarían el lanzamiento de “Pirámides” para
 dicha compañía. Sea breve y preciso en su respuesta.
 2) Usted recibe un estudio de seguimiento de las compras (“tracking de marca”) de los 3 primeros meses del
 lanzamiento de “Pirámides”, el cual muestra que la tasa de prueba del nuevo producto por parte del
 segmento objetivo, es la mitad de lo presupuestado, pero la tasa de recompra de estos consumidores es
 mucho más alta de lo esperado, así como también la cantidad comprada y la frecuencia de compra.
 ¿Cuáles son los factores comerciales más relevantes para explicar los resultados a la fecha del estudio?
 Argumente usando conceptos de marketing y la información provista en el enunciado.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 161

[pág. 162]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2012 | pregunta 1
 Convocatoria 2 | página original 103 | Promociones y plataforma de descuentos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº 1
 Uno de los fenómenos de internet de los últimos dos años ha sido la empresa Groupon, que consiste en una plataforma
 virtual que conecta a personas buscando promociones con los comerciantes (típicamente llamados comercios asociados)
 dispuestos a hacerles esas rebajas. Groupon tiene hoy sobre 170 millones de suscriptores, cerca de 33 millones de clientes
 activos (clientes que han comprado alguna promoción) y 250.000 comercios asociados en 48 países. Durante el 2011
 Groupon generó cerca de US$ 2 billones en negocios para los comercios asociados. Los tipos de comercios que participan
 en Groupon son de distintos rubros, incluidas grandes empresas y marcas de productos de consumo masivo y tecnología,
 tales como Hewlett Packard y también empresas de servicios de diversos tamaños en rubros tales como: Spa – Belleza,
 Bienestar (Wellness), Entretención, Restaurantes, Viajes, Hoteles, Gimnasios y otros.
 La base de suscriptores de Groupon es una gran lista de emails de personas, segmentada geográficamente, que
 voluntariamente se suscriben para recibir las ofertas. Es a través del email que Groupon comunica a sus suscriptores en
 forma atractiva los atributos y beneficios del producto/servicio promocionado, así como la oferta de precio de los
 comerciantes. Groupon elige a los comercios con los cuales hace las promociones sobre la base de la buena calidad de sus
 productos o servicios, y si bien no se responsabiliza del efectivo cumplimiento de la promoción ante los suscriptores,
 Groupon mantiene un servicio de atención a sus suscriptores a través de teléfonos, correos electrónicos e internet, para
 recibir las quejas y reclamos e intentar resolverlas.
 Las ofertas de Groupon buscan dar la percepción de unicidad y oportunidad especial para los suscriptores. Para ello recurre
 entre otras medidas a lo siguiente:
 - una promoción por día en una determinada área geográfica (Vitacura por ejemplo) y por categoría de producto/servicio
 (ejemplo: Peluquería);
 - la promoción tiene una duración limitada (ejemplo: 24 a 48 horas);
 - establecimiento de limitaciones para acceder a las ofertas de servicios tales como días/horarios restringidos o bloqueados;
 - fijación de una cantidad mínima de clientes que adhieran a la promoción para que ésta se haga efectiva.
 El suscriptor que compra la promoción ofrecida, debe pagarla por adelantado y queda en él la responsabilidad de ”cobrar” o
 canjear la compra del servicio o producto concurriendo físicamente al local de venta o solicitando el despacho a domicilio.
 Al recibir la confirmación del cliente, Groupon carga la tarjeta de crédito de éste y le paga al comercio asociado un precio
 acordado previamente, menor al que se le vendió al cliente (suscriptor), generando así un ingreso para Groupon.
 Sobre la base de la información entregada, a Ud. se le pide responder, de manera breve y precisa, las preguntas que se le
 formulan a continuación:
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 162

[pág. 163]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2012 | pregunta 1
 Convocatoria 2 | página original 104 | Promociones y plataforma de descuentos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 1) Identifique la propuesta de valor de Groupon para los comercios asociados, señalando claramente sus principales
 fortalezas y debilidades.
 2) El promedio de las ofertas que hace Groupon supera el 50% de descuento sobre el precio normal de los productos y
 servicios promocionados. ¿Cómo evita Groupon el deterioro en la percepción de calidad de la marca promocionada y con
 ello, la percepción negativa que los suscriptores pueden tener de Groupon?
 3) ¿Por qué puede ser atractiva la propuesta de valor de Groupon para tres empresas que son tan distintas entre sí como por
 ejemplo Hewlett Packard (computadores personales, impresoras, etc.), un nuevo hotel boutique en Valparaíso como
 CasaCero, y una peluquería establecida y ampliamente conocida como Palumbo?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 163

[pág. 164]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2015 | pregunta 1
 Convocatoria 1 | página original 160 | Respuesta competitiva y esencia de marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTAN'1
 La empresa McDonald's tuvo un mal año 2014 en Estados Unidos: Las ventas cayeron cerca de 5% y los
 índices de lealtad también. Aquella época en que los adolescentes iban a McDonald's debido a los bajos
 precios y utilizaban sus locales como centro de reunión ha ido quedando atrás. De acuerdo a un artículo en
 Brandchannel escrito por el periodista Dale Buss, “el principal problema de McDonald's, es que muchos
 jóvenes americanos pertenecientes a la generación Millennials, no perciben razones claras para seguir
 prefiriéndolo respecto de otras altermativas emergentes, tales como Chipotle (líder en comida mexicana
 casual tipo gourmet), Panera Bread (sándwiches gourmets, ensaladas y sopas) y Panda Express (comida
 china gourmet)”. La generación Millennials, compuesta por jóvenes nacidos entre las décadas de los 80's
 hasta principios de la primera década del 2000, se caracteriza por su uso masivo de las redes sociales y su
 familiarización innata con la comunicación, los medios y la tecnología digital. Los Millennials no sólo son
 consumidores, sino también influenciadores y provocan cambios en los mercados.
 Panera y Chipotle corresponden a una nueva categoría de restaurantes llamada “Casual-Rápida” (Fast-
 Casual), que ofrecen comida mejor y más elaborada que las tradicionales cadenas de “Comida Rápida”
 (Fast-Food), con un servicio rápido pero a precios mayores en un 20% a 30% que un McDonald”s. Una
 comida promedio en un Fast-Food no supera los US$6 mientras que en los Fast-Casual cuesta
 aproximadamente US$8. Las cadenas Fast-Casual tienden a enfatizar sus insumos frescos y sanos y el
 cliente puede elegir sus ingredientes. Del total de ventas de restaurantes en EE.UU., los Fast-Food
 representan el 44% y los Fast-Casual el 8%. -
 McDonaid's, la principal cadena de Fast-Food a nivel mundial, tiene hoy cerca de 35.000 locales en más de
 100 países y sirve a alrededor de 70 millones-de personas diariamente. Sus dos competidores más directos,
 Burger King y Wendy's, cuentan a nivel mundial con 12.200 locales y 6.550 respectivamente. El
 crecimiento en los últimos años de los locales que venden hamburguesas, principal categoría de alimentos de
 los restaurantes Fast-Food, ha sido estable y en torno al 2% anual, mientras que los locales de las cadenas de
 comida Fast-Casual han crecido a tasas superiores al 10% anual. Las estimaciones de crecimiento para los -
 restaurantes de comida Fast-Casual en Estados Unidos son de un 9% amual para el período comprendido
 entre los años 2015-2017, Este mayor crecimiento es explicado fundamentalmente por los nueVós hábitos de
 consumo en Estados Unidos, en especial de los Millennials, que favorecen una comida rápida más sana, de
 mejor calidad y en ambientes más atractivos. >
 McDonald”s es una de las marcas más reconocidas en el mundo entero y ha llegado a constiftuirse en una
 marca símbolo de EE.UU, La propuesta de valor tradicional de la empresa ha sido “comida con una calidad
 estandarizada que es servida en forma rápida y consistente en todo el mundo a un precio bajo.” Los
 Millenmnials, como segmento, representan para McDonald's un 20% de sus ingresos.
 Los competidores tradicionales de McDonald's son las cadenasde hamburguesas Í&Í_x7<—3ndyºs y Burger King.
 McDonald's es el líder de la industria y controla aproximadamente el 50% del mercado de los restaurantes
 del tipo Fast-Food de hamburguesas en Estados Unidos. Sin embargo, y a diferencia de McDonald's, sus
 competidores tradicionales han mostrado resultados positivos en sus ventas e indicadores de lealtad. La
 estrategia de estos competidores ha sido incorporar productos de mayor calidad a su menú tradicional y
 modernizar sus Jocajes. Algunas de las alternativas que han agregado estas cadenas a su menú tradicional son
 las hamburguesas de soya, de carne wagyu, las hamburguesas de menor contenido calórico, etc. También han
 introducido papas fritas 7ighf que contienen un 50% de menos calorías que las tradicionales.
 Como una forma de ir adecuándose a las nuevas tendencias de mercado del segmento joven, McDonald”s ha
 ido cambiando en los últimos años su propuesta de valor original ampliando constantemente su menú, de
 manera de cubrir las necesidades de todo su mercado objetivo. Las nueve alternativas que contenía su menú
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 164

[pág. 165]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2015 | pregunta 1
 Convocatoria 1 | página original 161 | Respuesta competitiva y esencia de marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 en 1948, en las cuales las hamburguesas representaban el 85% de su oferta, se han ampliado hasta 121,
 incluyendo nuevas categorías tales como postres y batidos, wraps, ensaladas, sándwiches de pollo y de
 pescado, entre otras. Incluso, en su declaración de misión actual, la empresa ni siquiera menciona las
 hamburguesas. A pesar de lo anterior, sus resultados de ventas e indicadores de lealtad durante el año 2014
 no han mejorado.
 El recientemente nombrado Presidente y CEO de McDonald's, Don Thompson, dijo en una entrevista:
 “Estos desafíos significativos requieren de cambios igualmente significativos en la forma que hacemos los
 negocios. Los consumidores de hoy crecientemente prefieren flexibilidad y opciones al comer, ambientes
 atractivos y conveniencia al ordenar. En McDonald's estamos trabajando para entregar una mejor
 experiencia.”
 En la última reunión de Directorio de la empresa, un director presentó una nueva propuesta de innovación.
 Esta consistía en el lanzamiento de una nueva hamburguesa al mercado, la cual sería puesta reción en la
 parrilla cuando el consumidor hiciera su orden. Además, al cliente se le ofrecerían más de 20 alternativas
 (desde tomate hasta champiñones a la parrilla) para que él construyera la hamburguesa que deseara. Todo
 esto se haría en el mismo sector donde hoy se producen las hamburguesas tradicionales. Además, el precio
 promedio de la hamburguesa pasaría de U$5,79 a U$7,79 convirtiéndose en el producto de mayor precio del
 menú, lo que permitiría a la empresa mejorar sus resultados financieros. Asimismo, el director proponía
 sustituir en un 30% la variedad de productos actualmente ofrecidos. Su idea era incorporar,
 fundamentalmente, productos bajos en calorías como por ejemplo ensaladas y frutas, sopas_, Jugos, yogures
 — naturales, y otros productos saludables, en detrimento de las hamburguesas, papas fritas y bebidas.
 Otro director de la empresa opinaba que está propuesta era un error. De acuerdo a su razonamiento, si
 McDonald's quería mantenerse creciendo y siendo rentable debía reforzar lo que históricamente hizo,
 hamburguesas estandarizadas de bajo precio, reducir las categorías de productos para acelerar el proceso de
 compra e invertir en renovar los locales y agregarles tecnología de punta (wi-fi, cargadores de celulares,
 pago a través de teléfonos, etc.).
 PREGUNTAS
 1) Desde el punto de vista de la propuesta de valor tradicional de McDonald's, ¿qué aspectos se verían
 negativamente afectados con las proposiciones hechas por cada uno de los directores? Refiérase a cada
 una de ellas por separado.
 2) Utilizando los conceptos de marketing, ¿cuál de las dos propuestas presentadas por los directores
 contribuye de mejor manera a que McDonald's mejore su posición competitiva en los próximos tres
 años? Justifique claramente su respuesta de manera breve y precisa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 165

[pág. 166]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2014 | pregunta 1
 Convocatoria 2 | página original 149 | Respuesta de marketing y regulación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N*1
 A fines de abril de este año, el Tribunal de Defensa de la Libre Competencia (TDLC) aprobó un acuerdo
 conciliatorio entre la Fiscalía Nacional Económica (FNE) y la empresa Unilever Chile (UL), tras una denuncia de
 presunto abuso de posición de dominio, por parte de UL, mediante prácticas exclusorias en el mercado de
 detergentes para lavado de ropa, con sus marcas Omo, Drive y Rinso. De acuerdo a la FNE, UL entregaba en forma
 sistemática incentivos a los distribuidores por exclusividad en la venta de detergentes, además de descuentos o
 premios condicionales a desempeño y para privilegiar el uso de espacios para la venta, tanto en el canal tradicional
 como en el supermercadista. '
 Entre los términos del acuerdo, está que respecto de las categorías donde UL tenga más de un 60% de participación
 de mercado total en ventas a nivel nacional, UL no podrá pactar con los distribuidores ni pagos, ni descuentos ni
 premios asociados a: exclusividad en la venta en el local; metas de crecimiento en ventas; asignación de espacios en
 góndolas ! mayores a su participación de mercado nacional, para la exhibición de sus productos en supermercados y
 otros comercios que tengan góndolas de autoservicio (almacenes, supermercados - mayoristas, etc.). En el caso de
 UL, la participación promedio actual que la empresa tiene en el espacio en góndolas de supermercados, es un poco
 inferior a la participación de mercado total en ventas que UL tiene en Chile.
 La estructura de la industria de detergentes en Chile Tabla N* 1
 corresponde a una de alta competencia, caracterizada por la N£ de Skus por Empresa
 presencia de una gran cantidad de empresas multinacionales (categoría detergentes ropa)
 y chilenas, que comercializan (fabrican y/o importan) en
 conjunto más de 200 Skus ? (ver Tabla N* 1) y más de 70 FABRICANTE
 marcas de detergentes para la ropa (incluyendo las marcas 1.Y KRAUSE 1 1
 propias de los distribuidores). VELARDE HNOS. 1 1
 CLINSOL 2 2
 Varias de las empresas nacionales compiten en el mercado KLAREN E 2
 tanto con sus propias marcas como también a través de la REB 2 2
 fabricación de las marcas propias de los supermercados, las CLEANER CHILE 2 3
 cuales no son fabricadas por UL o PéG (Procter and Gamble). IBERIA 2 3
 Unilever, principal actor de la categoría detergentes para el -- I HENKEL 6 5
 lavado de ropa, es una empresa multinacional que compite - OT.CIAS; 15 7
 además en otras categorías tales como cosmética y cuidado TLABACH 5 9
 personal (Dove, Ponds, Pepsodent, LeSancy, Axe, Rexona, MARITANO 16 11
 etc.), alir_nentación (Hellmanns, Knorr, Malloa, Bresler, Lipton, Marcas Propias 26 26
 etc.), cuidado del pelo (Sedal, St.Ives, Tresemme, Clear, etc.), PaRG 37 37
 cuidado del hogar (Vim, Cif, etc.), y así sucesivamente. Tanto UNILEVER 107 94
 . . .a .
 UL como PéG tienen centros de investigación en distintas
 Total general 224| 203
 partes del mundo. -
 Fuente: AC Nielsen
 Además de las empresas multinacionales como UL y P£G, en la categoría de detergentes para el lavado de la ropa
 compiten una serie de empresas locales como Maritano, Cleaner, Brillex y Ballerina, entre otras. UL y P£G son las
 únicas empresas que compiten en el rubro con tres o más marcas y gran cantidad de Skus. La venta se realiza a
 través de múltiples canales de distribución incluyendo: cadenas de supermercados (los cuales representan el 80%
 del volumen de ventas totales), cadenas de tiendas por conveniencia, almacenes (a través de mayoristas) y ferias.
 Estudios de mercado recientes muestran que la mayoría de los consumidores chilenos compra detergentes
 mayoritariamente en base a preferencia de marca, luego funcionalidad, precio, y en menor medida, por conveniencia
 en la compra. La Tabla N* 2, describe la evolución de la participación de mercado en ventas a nivel nacional,
 considerando todos los canales de distribución de las principales empresas que componen el mercado de los
 detergentes.
 1 La participación porcentual en góndola se mide tomando los metros lineales que tiene la marca sobre el total de metros
 lineales de la categoría.
 2 Sku: “Stock Keeping Unit”, corresponde a una combinación de marca, tamaño, empaque y variedad o modelo. Es la
 unidad de referencia que se utiliza para el control de inventarios y ventas,
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 166

[pág. 167]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2014 | pregunta 1
 Convocatoria 2 | página original 150 | Respuesta de marketing y regulación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Tabla N* 2: Participación de Mercado Detergentes
 2005 2006 2007 2008 2005 2010 2011 2012
 UNILEVER 76,4% 73,9% 74,1% 72,0% 73,5% 73,2% 69,7% 67,5%
 P8G 17,3% 17,8% 17,0% 17,7% 17,4% 20,7% 22,0% — 21,9%
 MARITANO 3,2% . 3,2% 3,0% 3,1% 2,7% 1,5% 1,9% 2,2%
 LABACH 0,2% * 0,3% 0,2% 0,2% 0,2% 0,1% 0,2% 1,1%
 CLEANER CHILE — | —0,0% 1,0% 0,4% 1,5% 1,8% 0,8% 1,3% 1,6%
 MARCAS PROPIAS 1,1% | 2,6% 4,2% 4,9% 3,4% 2,8% 4,0% 4,8%
 OTROS 1,8% : 1,2% 1,12% 0,65% 1,0% 0,9% 0,9% 0,2%
 TOTAL 100,0% 100,0% 100,0% 100,0% 100,0% 100,0% 100,0% 100,0%
 Fuente: AC Nielsen
 Entre los años 2005-2012, el mercado de detergentes muestra un comportamiento competitivo, con frecuentes
 promociones de valor agregado (regalos a los consumidores) por parte de UL y P£:G, así como de promociones de
 precios por parte de todos los actores, logrando que los precios promedio hayan sido más bien estables. Las marcas ,
 de UL y P£G tienen precios superiores al resto del mercado. La inversión publicitaria en la categoría durante el año
 2012 sobrepasó los 5 mil millones de pesos, representando UL y P£G juntos, más del 85% de ese total. -
 |
 Actualmente, en nuestro país existen cuatro cadenas de supermercados (Walmart, Cencosud, SMU, Tottus) que -
 |
 representan cerca del 90% de las ventas de productos en supermercados, Por otra parte, existen más de 500 empresas f
 o locales mayoristas que atienden a más de 100.000 almacenes que comercializan detergentes para el lavado de ropa.
 -
 |
 |
 |
 Como era de esperar, las marcas con menor participación en el mercado de detergentes estaban felices con el f
 acuerdo entre la FNE y UL. Un analista del sector planteaba que “ahora que UL no podrá pagar por exhibir sus E
 '
 marcas en más del 67% del espacio en góndolas de supermercados, destinado a la categoría de detergentes, lo más ||
 probable es que el conjunio de empresas nacionales que representan a las marcas más pequeñas (sin incluir las
 marcas propias de los supermercados) llegará en el corto plazo a tener una participación de mercado mínima de un
 15% de las ventas totales”.
 i
 PREGUNTAS
 En base a la información provista en el enunciado y respecto de la categoría de detergentes de ropa, responda las
 siguientes preguntas: . | .
 1) Desde un punto de vista comercial, ¿le parece correcta la afirmación del analista? Argumente en forma breve y
 precisa.
 2) ¿Qué impactos de corto y largo plazo, sobre la estrategia comercial de detergentes de UL, pueden tener las
 restricciones acordadas con la FNE? Fundamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 167

[pág. 168]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2017 | pregunta 1
 Convocatoria 1 | página original 226 | Segmentos, crecimiento y precio-calidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 1
 A comienzos de enero de este año, César Plast, Director Ejecutivo de Multiplast, se echó hacia atrás en su silla a
 medida que el Gerente de Marketing salía de la sala de reuniones. “Otra reunión y aún no se logra una resolución",
 pensaba. Después de dos prolongadas reuniones, todavía no se decidía acerca de cómo y dónde desplegar los
 esfuerzos de marketing entre los distintos mercados atendidos por la empresa en la zona sur y la Región
 Metropolitana del país.
 Multiplast comercializa estanques, fosas sépticas, plantas de tratamiento y accesorios relacionados con la
 acumulación y conducción de agua. Sus productos se caracterizan por tener la mejor calidad de la industria como
 resultado de la materia prima usada en la producción y la duración de sus productos. En general, sus distintas
 líneas de productos generalmente presentan los precios más altos de la industria.
 En la Región Metropolitana existe una fuerte competencia a nivel de distribuidores. Sodimac, Easy y Construmart,
 principales cadenas ferreteras, tienen múltiples locales y la competencia entre ellos por ganar participación de
 mercado ha aumentado fuertemente en los últimos años. Sin embargo, el crecimiento de la parficipacíón de
 mercado de éstas se ha dado fundamentalmente por la disminución de las ventas de las ferreterías independientes,
 a las cuales se les hace difícil competir contra los menores costos y los mayores servicios ofrecidos por las
 primeras, y no por crecimiento de mercado. De hecho, las ventas en la Región Metropolitana no han mostrado
 crecimiento en volumen en los últimos cinco años. Según datos de la industria, las principales cadenas ferreteras
 controlaban el 60% del mercado de estanques, fosas y plantas de tratamiento en la Región Metropolitana y se
 esperaba que su participación siguiera creciendo en el futuro. Multiplast no participaba en este canal ya que en
 general las grandes cadenas sólo comercializan una marca y preferentemente la que ofrezca los precios más bajos.
 En la zona sur las ventas de la industria han crecido a una tasa promedio del 15% amal producto de la gran sequía
 que afecta a estos lugares, la cual se espera que continúe por los próximos cinco años. En el sur, la existencia de
 cadenas ferreteras es más bien baja, no existen muchas marcas competidoras a Multiplast, y los principales
 distribuidores son las ferreterías independientes que se encuentran en las distintas cindades y pueblos.
 El volumen de ventas en valor ($) de los estanques, fosas sépticas, plantas de tratamiento y accesorios que se
 venden en el área total de mercado de Multiplast durante el año 2016 alcanzaron los $40.000 millones. Los
 principales clientes en esta industria son los hogares que utilizaban estos productos en sus casas y los instaladores
 que son profesionales que atienden a distintos tipos de clientes, incluidos los del segmento hogar donde además
 actúan como influenciadores de una determinada marca. En la siguiente tabla se muestran las ventas por zona
 geográfica y tipo de clientes en las áreas donde compite Multiplast, y la participación de mercado de la empresa
 en cada uno de estos segmentos:
 VENTA TOTAL MERCADO RELEVANTE MULTIPLAST (en millones de $) PARTICIPACIÓN DE MERCADO MULTIPLAST -
 Region Metropolitana Zona Sur Total Region Metropolitana Zona Sur
 Hogar 19.000 8.000 26.000 - Hogar 8,22% 18,75%
 Instaladores 9,000 5.000 14.000 Instaladores 28,0% 50,0%
 Total 27.000 13.000 40.000
 Ed
 Multiplast logró una venta anual de $8.000 millones el 2016. La mitad de sus ventas se dirigían a la Región
 Metropolitana y el otro 50% a la zona sur del país. La empresa distribuye todas sus líneas de productos a través
 de 200 ferreterías mdependientes a lo largo del país. Las ventas de la empresa han permanecido estables durante
 los últimos cinco años. "Hemos sido muy exitosos en mantener nuestros márgenes incluso con un aumento en los
 costos de la materia prima y mano de obra, pero me temo que nos estamos acercando al umbral en nuestros precios.
 Ahora somos la empresa con el precio más alto en los mercados que atendemos y la que ofrece los mejores
 márgenes a nuestros distribuidores", señalaba César, Director Ejecutivo de la empresa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 168

[pág. 169]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2017 | pregunta 1
 Convocatoria 1 | página original 227 | Segmentos, crecimiento y precio-calidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 El siguiente cuadro muestra un reciente estudio de mercado donde se señalan las principales características de
 compra de ambos segrentos: -
 Hogar Instaladores
 - La principal razón para elegir - Buscan producto de alta calidad y duraderos
 una marca es el precio bajo sin problemas de filtraciones y olores
 - Elige primero el distribuidor - Quieren hacer un buen trabajo
 | _y luego la marca . porgue está en juego su reputación
 - Noson leales a las marcas ni - Solicitan créditos a los distribuldores
 a los canales de distribución - Buscan un alto nivel de servicios
 - Conoce poco la categoría dada -
 su baja frecuencia de compra
 - Prívilegia la marca p obre el canal de distribución
 - Prefieren las ferreterías como Jugar de compra
 César Plast y el Gerente de Marketing se reunieron nuevamente para considerar el asunto de dónde y cómo
 desplegar los esfuerzos de marketing de la empresa. La temporada alta para la venta de los productos que
 comercializaba la empresa estaba próxima a comenzar por lo que se debían tomar decisiones pronto.
 La estrategia comercial propuesta por el Gerente de Marketing consistía en dirigir los esfuerzos al segmento
 hogar en la Región Metropolitana, ya que era el segmento con el mayor tamaño de mercado y en donde la
 empresa tenía la menor participación de mercado en relaciónal resto de los segmentos. Para ello, sugería
 aumentar la publicidad de la marca, con énfasis en la televisión, de manera de persuadir al segmento a que
 comprara la marca. Consideraba que aumentando el reconocimiento de marca de un 15% a un 30% entre este
 tipo de consumidores se produciría un impacto en las ventas. Además, proponía que las ferreterías bajaran en
 un 15% los precios a público de todos los estanques y fosas de manera de lograr una paridad de precios con el
 resto de las marcas competidoras.
 PREGUNTAS
 1. César Plast, Director Ejecutivo de Multiplast, tiene como objetivo aumentar las ventas de la empresa con
 su actual línea de productos y sin deteriorar sus márgenes. De acuerdo a la información entregada en el
 caso y utilizando los conceptos de marketing, ¿cuáles son los tres segmentos de mercado donde Mutiplast
 debiera focalizar sus esfuerzos comerciales de manera alcanzar su objetivo? Justifique su respuesta en
 forma precisa para cada uno de los segmentos elegidos.
 2. Deacuerdo con la información entregada en el caso y utilizando los conceptos de marketing, ¿está Ud. de
 acuerdo con la estrategia comercial propuesta por el Gerente de Marketing? ¿Por qué si o por qué n0?
 Justifique claramente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 169

[pág. 170]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2016 | pregunta 1
 Convocatoria 2 | página original 199 | Servicio, precio y canal
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 lo
 PREGUNTA N* 1
 Goodyear, empresa líder en la producción y comercialización de neumáticos a nivel mundial, atiende a una
 amplia variedad de clientes que requieren de distintos tipos de neumáticos. Entre ellos podemos destacar la
 industria automotriz, de transporte (pasajeros y carga), de maquinarias (construcción, minería, forestal, etc.) y
 la industria aérea. En el caso de la industria automotriz, Goodyear cuenta con dos tipos de clientes: las empresas
 productoras de automóviles y los consumidores finales que requieren de repuestos para cambiar los neumáticos
 originales producto del desgaste por el uso.
 En nuestro país, Goodyear sólo atiende el mercado automotriz en lo que se refiere a repuestos de neumáticos.
 Durante todos estos años, Goodyear ha mantenido una posición de liderazgo indiscutido en el mercado chileno,
 proceso en el cual ha sido clave su potente red de comercialización y distribución exclusiva, con más de 100
 distribuidores independientes en todo el país, donde los usuarios acceden a los mejores neumáticos y reciben
 el servicio profesional y especializado que requieren para distintas necesidades relacionadas con el auto.
 Los distribuidores Goodyear ofrecen sólo las marcas de neumáticos Goodyear y no cuentan con territorios
 exclusivos para la comercialización de los neumáticos. Lo anterior hace que esta red de distribuidores
 independientes de Goodyear no sólo tenga que competir con distribuidores de otras marcas (Pirelli, Michelin
 y Bridgestone entre las más importantes), sino que también entre ellos mismos.
 Todos los distribuidores, además de ofrecer las distintas marcas de neumáticos de Goodyear, ofrecen una serie
 de servicios de valor agregado a los consumidores de manera de satisfacer las múltiples necesidades de éstos.
 Entre los servicios ofrecidos se encuentran: balanceo, alineación de neumáticos, cambio de las pastillas de
 frenos y amortiguación, por nombrar algunos. Cada distribuidor de Goodyear fija en forma independiente sus
 precios a público en lo referente a los servicios de valor agregado. Los costos de los servicios de valor agregado
 ofrecidos por los distintos distribuidores son similares y se han mantenido constantes en el tiempo.
 Goodyear segmenta a sus clientes en tres grupos en base a su comportamiento de compra:
 a) Compradores orientados a la variable precio: se caracterizan por adquirir la mejor marca que su
 presupuesto les permite siendo muy sensibles al precio. Son poco leales a una determinada marca o
 punto de venta, ya que no valoran los servicios de valor agregado ofrecidos por los distribuidores, y
 tienden a visitar muchos locales antes de realizar la compra. Representan el 10% de las ventas de los
 distribuidores Goodyear.
 b) Compradores fieles a la marca: se caracterizan por ser fieles tanto a la marca y a los distribuidores
 autorizados de ésta. Demandan por sobretodo calidad de los neumáticos. Representan el 50% de las
 ventas de los distribuidores Goodyear.
 c) Compradores orientados a la calidad del servicio entregado por el local de venta: se caracterizan por
 buscar la mejor experiencia de compra en el punto de venta. Valoran la marca pero por sobretodo los
 servicios de valor agregado entregados en el punto de venta. Representan el 40% de las ventas de los
 distribuidores Goodyear.
 Hasta ahora la relación de Goodyear con sus distribuidores independientes ha sido buena. Goodyear entrega a
 los distribuidores productos y marcas de acuerdo con las necesidades que cada uno de ellos tenga, además de
 publicidad en distintos medios de forma de atraer consumidores a su marca, publicidad y promociones en el
 punto de venta, y desarrollo de nuevos productos, todo lo cual permite dar una mejor atención a los
 consumidores. Adicionalmente, Goodyear entrega a sus distribuidores el precio final a público para cada marca
 de neumáticos Goodyear, el cual es el mismo para todos los distribuidores de la red. Dentro de los neumáticos
 ofrecidos por Goodyear a sus distribuidores se encuentran marcas premium (alta calidad) y marcas de precio
 bajo. Las marcas premium les entregan a los distribuidores de Goodyear un margen mayor que las marcas de
 precio bajo. -
 En la siguiente tabla se muestran los ingresos y márgenes sobre el precio de venta de las categorías neumáticos
 y servicios de valor agregado para los distintos distribuidores de la red de Goodyear en los últimos 4 años.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 170

[pág. 171]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2016 | pregunta 1
 Convocatoria 2 | página original 200 | Servicio, precio y canal
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 171

[pág. 172]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2016 | pregunta 1
 Convocatoria 2 | página original 201 | Servicio, precio y canal
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2012-2013 2014-2015
 Ingresos ; Márgenes Ingresos — Márgenes
 Neumáticos 7206 . 50%6 | 75% - 50%
 Servicios de Valor Agregado 30% — 5% 25% 25% %— 5%
 Producto de la fuerte competencia, Goodyear perdió un 3% de participación de mercado durante el año anterior
 (2015). Como una forma de revertir los resultados y recuperar la participación de mercado, Goodyear se
 encuentra evaluando la posibilidad de ampliar sus canales de distribución de manera de aumentar sus ventas.
 Especificamente, la empresa se encuentra en conversaciones con Walmart, cadena de supermercados líder de
 nuestro país, para que se convierta en la primera cadena en comercializar las marcas de neumáticos Goodyear
 en los 47 locales Hiper Líder que tiene Walmart a lo Jargo de Chile. Hiper Líder se caracteriza por tener un
 posicionamiento de precios bajos, un gran surtido de productos, salas de venta de gran amplitud y por tener
 locales ubicados en lugares estratégicos, buscando atender la mayor cantidad de clientes.
 En caso de llegar a acuerdo, Hiper Líder ofrecería sólo neumáticos de marca Goodyear al interior de sus
 locales, No ofrecería servicios de valor agregado a sus consumidores como los ofrecidos por los distribuidores
 Goodyear. Hiper Lider fijaría el precio final de los neumáticos a los consumidores de acuerdo a la ubicación
 de sus locales y la competencia existente. Se espera que Hiper Líder pueda acceder a más de dos millones de
 potenciales consumidores de neumáticos Goodyear.
 Ante la posible incorporación de Hiper Líder como un nuevo canal de distribución de Goodyear, los
 distribuidores de la marca se han mostrado molestos e incluso decepcionados con esta posibilidad. Muchos
 sienten que perderían los derechos de exclusividad sobre las famosas marcas de Goodyear. Otros temen que
 se desencadene una disminución más acentuada en sus márgenes. Incluso uno de los distribuidores más
 importantes manifestó que esta era una seria amenaza y que de ocurrir evaluaría seriamente si seguir
 comercializando las marcas Goodyear o bien convertirse en distribuidor de alguna marca de la competencia.
 PREGUNTAS
 1. Según lo señalado en el caso y utilizando conceptos de marketing, ¿Cómo explica Ud. que el margen
 logrado por los distribuidores de la red de Goodyear, en la categoría neumáticos, se haya mantenido
 constante en los últimos cuatro años, mientras que el mar gen logrado por los servicios de valor agregado
 haya caído durante los dos últimos años en comparación al período 2012-2013? Justifique claramente su
 respuesta.
 2. De acuerdo con la información entregada en el caso y utilizando conceptos de marketing, ¿Está Ud. de
 acuerdo con la aftrmación de uno de los distribuidores más importantes de Goodyear, que señalaba que en
 caso de que la empresa cerrara el acuerdo con Walmart, éste sería una seria amenaza para los distribuidores
 de la marca Goodyear? ¿Por qué sí o por qué no? Fundamente su respuesta,
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 172

[pág. 173]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2016 | pregunta 1
 Convocatoria 2 | página original 202 | Servicio, precio y canal
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 173

[pág. 174]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2025 | pregunta 4
 Convocatoria 1 | página original 433 | Valor, orientación al mercado y coherencia comercial
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N'4
 TRICORP presenta su nueva imagen corporativa
 Tricorp es una empresa dedicada a la prestación de servicios financieros y seguros, orientada a brindar
 soluciones de protección financiera a individuos y empresas. Su objetivo principal es gestionar riesgos y
 ofrecer coberturas que incluyan seguros de vida, salud, vehículos, propiedades y otros bienes. Reconocido
 por su enfoque en la innovación y la adaptabilidad, esta empresa busca garantizar la tranquilidad y estabilidad
 económica de sus clientes, promoviendo confianza y sostenibilidad a través de productos y servicios
 personalizados. Tricorp se ha caracterizado por ser la empresa más eficiente en el mercado, gracias a una
 preocupación constante por mantener los costos operacionales bajos.
 En 2022, la entidad que construye el Índice Nacional de Satisfacción del Consumidor reportó un aumento
 del 11% en los reclamos presentados por los consumidores contra empresas relacionadas con el mercado
 financiero respecto al primer semestre del año anterior, alcanzando un total de 48.103 quejas. Las principales
 causas fueron cobros indebidos, incumplimiento de las condiciones contractuales y cobranzas extrajudiciales
 abusivas. Con el objetivo de evaluar a las empresas bajo los mismos parámetros, la entidad elaboró un ranking
 que mide el comportamiento de las empresas en términos de respuesta a reclamos. En este análisis, Tricorp
 obtuvo la peor evaluación del sector.
 Para abordar estas deficiencias, Tricorp realizó cerca de 20 estudios de investigación de mercado con el
 objetivo de analizar y mejorar su propuesta de valor. Estos estudios incluyeron una evaluación detallada de
 los principales “viajes del cliente” (customer journeys), identificando problemáticas y puntos sensibles en la
 experiencia del usuario. Además, la empresa implementó un sistema de revisión semanal y mensual de los
 reclamos ingresados en todas sus líneas de negocio. Un hallazgo destacable fue que el 62% de las quejas+
 provenían de interacciones realizadas a través de canales digitales.
 En 2023, Tricorp lanzó una nueva imagen corporativa como parte de una nueva visión estratégica. Con logo
 remozado y bajo el lema “Resolvemos todas las necesidades financieras de nuestros clientes, entregándoles
 la mejor experiencia personal”, se abarca a todas sus líneas de negocio: Seguros, Banco, Inversiones,
 Previsión y Salud. La estrategia comercial de Tricorp combina equipos de venta, una red de 27 sucursales a
 nivel nacional, un Contact Center, una Sucursal Virtual y una App Corporativa.
 El Gerente Corporativo de Marketing y Clientes destacó: “La nueva imagen de marca de Tricorp representa
 una evolución significativa que rescata todos los elementos de confianza y solidez que ha tenido la marca
 durante sus más de 100 años de trayectoria. Este cambio de logo refuerza la relevancia de la marca y le da
 una mirada más contemporánea, cercana para abordar el desafío de acompañar a nuestros clientes en cada
 etapa de sus vidas”.
 La nueva identidad corporativa ya se encuentra implementada en los principales puntos de contacto con los
 clientes, como el frontis del edificio corporativo, las sucursales, las comunicaciones corporativas, folletos, el
 sitio web y la aplicación móvil.
 Según datos internos, el índice de Experiencia del Cliente en sucursales mostró una mejora significativa,
 pasando de 14,9% en 2023 a 30,9% en 2024. Este avance fue atribuido a una mejora en el servicio a los
 clientes, la cual se focalizó en la empatía y el conocimiento de los clientes, respaldada por herramientas
 tecnológicas avanzadas como sistemas de inteligencia artificial para la gestión de correos electrónicos,
 control de tiempos de respuesta y resolución de requerimientos y enriquecimiento de la base de clientes.
 Estas iniciativas contribuyeron a resultados positivos en productos clave como Vida Individual, Seguro
 Automotriz, Seguro de Hogar, Créditos de Consumo, y Fondos Mutuos, fortaleciendo el posicionamiento de
 Tricorp en diversas líneas de negocio con respecto a su competencia.
 A través de sus 27 sucursales a nivel nacional, Tricorp atiende a sus clientes bancarios y de las Compañías
 de Seguros, con 181 ejecutivos comerciales y 38 de servicio de posventa para Banco y Seguros. En 2024 esta
 red presentó un incremento de visitas de 25% en comparación con 2023.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 174

[pág. 175]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | enero 2025 | pregunta 4
 Convocatoria 1 | página original 434 | Valor, orientación al mercado y coherencia comercial
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Para el 2025, el 75% del total del presupuesto de marketing anual será destinado a campañas publicitarias
 tradicionales, como televisión y radio, y a la mejora de las sucursales físicas, un 10% será asignado al
 desarrollo y optimización de los canales digitales, incluyendo la app y el sitio web, y el resto, para invertir
 en un chatbot automatizado de atención a clientes, lo que permitirá sustituir a más de la mitad ejecutivos de
 postventa y lograr mayor eficiencia.
 Preguntas:
 1. Uno de los Directores de Tricorp, planteaba que el cambio de imagen corporativa debía hacerse en el
 contexto de una estrategia de centralidad en el cliente, de lo contrario, sería un desperdicio de recursos.
 El Gerente General le replicaba que eso era precisamente lo que había iniciado Tricorp el 2023 y que
 hasta hoy se ejecutaba. Considerando la información entregada, ¿quién tiene la razón, El Director o el
 Gerente General? Argumente su respuesta.
 2. Enuna reunión interna, el Gerente de Ventas y Sucursales expondrá posibles riesgos asociados con la
 implementación de la nueva imagen corporativa. Anticipe y evalúe al menos dos riesgos específicos
 que podrían surgir en 2025 y proponga una acción de mitigación para cada uno de ellos.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 175

[pág. 176]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | marzo 2009 | pregunta 1
 Convocatoria 1 | página original 2 | Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº 1
 La empresa “Lautaro” está en el rubro de consumo masivo y ocupa la posición de líder en volumen de ventas en
 varias de las categorías en las que compite. La mayoría de sus marcas de productos tienen un fuerte posicionamiento
 en la mente de sus consumidores. Lo anterior es el resultado de una mezcla comercial consistente, especialmente en lo
 que se refiere a calidad e innovación en productos y a un mensaje comunicacional basado en atributos diferenciadores.
 “Lautaro” tenía un extenso portafolio de productos en varias categorías. En la principal categoría tenía 56 SKU1,
 aunque el 85% de los ingresos y el 60% de los márgenes provenían de sólo 5 SKU.
 El principal canal de distribución para “Lautaro” está constituido por las cadenas de supermercados, las cuales
 representan más del 70% de sus ventas. Un 20% es distribuido a través de mayoristas a los pequeños locales
 minoristas y el 10% restante corresponde a ventas industriales.
 En una reciente reunión interna hubo una presentación del Gerente General, en la cual planteaba una fuerte reducción
 esperada en la demanda por los productos de las distintas categorías en que compite la empresa, dada la restricción de
 ingresos y alza del desempleo esperada para el 2009. Además, comentó los principales cambios que se avecinaban en
 los clientes - distribuidores de la compañía: consolidación de las cadenas de supermercados regionales en dos
 compañías (SMU con 27 cadenas y Southern Cross con 9 cadenas); la reciente adquisición de la cadena de
 supermercados D&S por parte de la cadena de supermercados más grande del mundo, WalMart. Se esperaba que esta
 consolidación del sector, tendría como consecuencia, entre otras, el aumento de la presencia de marcas propias de los
 distribuidores, en desmedro de la participación de las marcas de proveedores.
 Luego de la presentación, el Gerente General de “Lautaro” pidió a los Gerentes de Ventas y de Marketing de la
 empresa, le entregasen a la brevedad sus propuestas respecto de la forma cómo la empresa debía enfrentar
 comercialmente el año 2009.
 Las siguientes son las propuestas del Gerente de Ventas (GV) de “Lautaro”:
 GV-1: Retirar del mercado decenas de SKU que en este momento se encuentran orientados a nichos de bajo
 volumen.
 GV-2: Reducir el presupuesto de publicidad masiva.
 GV-3: Reorientar los recursos a promociones de precio y activaciones en punto de venta.
 Por su parte, el Gerente de Marketing de la empresa manifestó su desacuerdo con lo anterior. Según él, en épocas de
 crisis hay muchas oportunidades atractivas y por lo tanto, él hizo las siguientes propuestas:
 1 SKU: Stock Keeping Unit. Corresponde a la identificación de una combinación de marca, tamaño envase y formato. Asì,
 por ejemplo, en bebidas, el envase de CocaCola de 1lt en empaque desechable es un SKU y el envase de 2 lts retornable es
 otro SKU.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 176

[pág. 177]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | marzo 2009 | pregunta 1
 Convocatoria 1 | página original 3 | Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 Propuestas del Gerente de Marketing (GM) de “Lautaro”:
 GM-1: Mantener la inversión en marca.
 GM-2: Buscar nuevos nichos de mercado.
 GM-3: Mejorar la propuesta de valor de los productos.
 Se Pide:
 1. De manera independiente para cada una de las tres propuestas hechas por el Gerente de Ventas de la empresa,
 indique el principal argumento a favor o por el cuál usted estaría de acuerdo con dicha propuesta.
 2. De manera independiente para cada una de las tres propuestas hechas por el Gerente de Marketing de la
 empresa, indique el principal argumento a favor o por el cuál usted estaría de acuerdo con dicha propuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 177

[pág. 178]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2009 | pregunta 1
 Convocatoria 2 | página original 15 | Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº 1
 A fines del mes pasado, el Directorio de la Viña Lapesti le pidió a su Gerente General, que evaluara la conveniencia
 de cambiar el sistema de distribución de la Viña, desde el actual sistema de distribución a través de mayoristas hacia
 un sistema de distribución más directa. La idea del Directorio, era analizar la posibilidad de que la Viña exportara y
 atendiera en forma directa a las principales cadenas de supermercados y tiendas especializadas de vino en Europa, las
 cuales eran atendidas hasta hoy por sus distribuidores mayoristas.
 Viña Lapesti es un productor de vinos de un rango de precios medio a alto, dirigida exclusivamente al mercado
 europeo. La distribución de sus vinos se hace a través de siete distribuidores no exclusivos1 ubicados en las
 principales ciudades de Europa. Estos distribuidores, a su vez, proveen a 1.000 clientes minoristas, incluyendo
 supermercados y tiendas especializadas en vino. Las ventas totales de la Viña a los distribuidores durante el año
 pasado fueron de US$ 90 millones, con una utilidad neta de US$ 6 millones.
 Los distribuidores de vino habían jugado un rol importante en la estrategia de entrada a Europa de Viña Lapesti y su
 posterior crecimiento. Sin embargo, en los últimos dos años, las ventas se habían estancado. El año 2008, los
 distribuidores compraron US$ 90 millones en vino a la Viña y luego lo revendieron en US$ 100 millones a los
 minoristas. Los distribuidores le cobraban a la Viña Lapesti un 5% de las compras que ellos le hacían, como
 honorarios por servicios que ellos como distribuidores le prestaban a la Viña. Además de realizar las ventas
 (promoción y toma de pedidos), los distribuidores manejaban el inventario de vino, de manera de tener suficiente
 stock para mantener un buen servicio a sus clientes. También, otorgaban crédito a las cuentas minoristas y se
 encargaban de la cobranza.
 Los ejecutivos de la Viña, estaban preocupados con la gestión del crédito y cobranza hecha por los distribuidores. En
 muchos casos, la Viña debía esperar hasta 90 días para poder recibir de los distribuidores los dineros adeudados por
 los minoristas, lo que significaba un costo financiero para la Viña equivalente a un 0,5% de las ventas anuales hechas
 a los distribuidores. El Gerente de Exportaciones de la Viña, había recibido varios llamados de los distribuidores,
 contándole que estaban siendo presionados por los minoristas para que redujeran sus precios, si no querían perder
 competitividad.
 La Viña contaba con una fuerza de venta de 6 personas ubicada en Europa, la cual desempeñaba un sinnúmero de
 tareas, incluyendo la verificación de inventario y las promociones de vinos, la disposición de la exhibición en
 minoristas y el manejo de las preguntas y reclamos de los supermercados y tiendas especializadas de vino. Muchas
 veces los vendedores de la Viña Lapesti trabajaban en conjunto con los vendedores de los distribuidores. En total, los
 siete distribuidores contaban con una fuerza de venta de 35 vendedores, quienes atendían a los casi 1.000 locales de
 venta repartidos en diferentes ciudades europeas.
 1 Distribuidor no exclusivo se refiere a que éste trabaja no sólo con Viña Lapesti, sino también con otras viñas de diferentes
 países.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 178

[pág. 179]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2009 | pregunta 1
 Convocatoria 2 | página original 16 | Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 Los principales competidores de Viña Lapesti, contaban con un sistema de distribución directa y operaban oficinas y
 bodegas en cada una de las principales ciudades de Europa donde también competía la Viña Lapesti. El Gerente de la
 Viña había conseguido información estimativa de algunos gastos relevantes. La operación promedio de una oficina y
 bodega podría efectuarse a un costo anual fijo, incluyendo arriendo, personal y gastos operacionales, de US$ 900.000.
 Los salarios, gastos y beneficios incrementales de la fuerza de venta necesaria para cubrir los 1.000 clientes
 minoristas, serían de aproximadamente US$ 3,5 millones al año. Lo anterior, no incluía los cuatro supervisores de
 venta que necesitaría para administrar a dicha fuerza de ventas. Además, proyectaba que los costos de transporte y
 entrega para los minoristas equivaldrían a un 5% de las ventas a minoristas. Finalmente, la Viña no contaba en este
 momento con una estimación de los gastos incrementales en Administración y Ventas de una oficina y su bodega.
 El Directorio se encontraba optimista con la información obtenida en relación con el eventual cambio del actual
 sistema de distribución, ya que al adoptar la distribución directa, la Viña se quedaría con el margen que estaban
 obteniendo los distribuidores y les permitiría ser más competitivos en precios al minorista.
 Se Pide:
 A la luz de los antecedentes entregados en el enunciado de la pregunta, a Ud. se le pide que entregue los elementos o
 variables tanto cuantitativas, como cualitativas más importantes, que a su juicio la Viña Lapesti debiera considerar
 para tomar la decisión respecto de la conveniencia o no de cambiar su actual sistema de distribución. En relación con
 los aspectos cuantitativos, presente los cálculos numéricos que son posibles de realizar con la información disponible
 y que puedan ayudar al análisis de la decisión que se está evaluando. En relación con los aspectos cualitativos, sea
 ordenado al momento de presentar los elementos que deben ser considerados en el análisis de la decisión que se está
 evaluando.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 179

[pág. 180]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | marzo 2010 | pregunta 1
 Convocatoria 1 | página original 31 | Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 PREGUNTA Nº 1
 El formato de “tiendas de conveniencia” (o “tiendas por conveniencia”) en Chile, sigue creciendo en número de locales,
 participación en las ventas de consumo y presencia de marcas. La reciente compra de los 25 locales de la cadena OK
 Market de Salcobrand por parte de SMU, la cadena de supermercados de los empresarios Saieh y Rendic, es el más
 reciente evento en esta dinámica categoría de tiendas. Por otra parte, Walmart ha manifestado en Chile su intención de
 crecer en esta categoría de formato de tienda a través de la marca Ekono u otra marca. Las tradicionales tiendas por
 conveniencia asociadas a distribuidoras de combustibles, cerca de 400 en Chile, se han visto potenciadas con la entrada
 de la colombiana Terpel y de la brasileña Petrobras. Otra de las cadenas fuertes en este segmento es Big John del
 Ingeniero Comercial UC, Juan Pablo Correa., que tiene 33 locales.
 Se llaman “tiendas de conveniencia” a los establecimientos con superficies de 200-500 m², con un horario comercial
 extendido. La mayor cadena del mundo, 7-Eleven, tiene más locales que McDonald en el mundo. Otro caso de “tienda
 de conveniencia” es la cadena Oxxo de México, que tiene unas 6.700 tiendas en su país. Las “tiendas por conveniencia”
 tienen un surtido limitado de productos, centrado en bebidas, alimentación, confites, higiene personal, etc. Por su
 formato, ofrecen conveniente ubicación, horario extendido, rapidez en la compra, entre otros beneficios, y sus precios
 suelen ser superiores a los de los supermercados1. Ejecutivos del sector explican que este tipo de local no se enfoca
 tanto en el precio de los productos, sino en el ahorro de tiempo que logran los clientes al comprar allí, en lugar de ir a un
 supermercado o un hipermercado. Generalmente, se ubican en el centro de las ciudades, en sectores residenciales de alta
 densidad y de alto tráfico de personas, por lo que las rentas de arriendo por metro cuadrado son más altas que las que
 pagan los supermercados.
 Un ejecutivo del sector aseguró que “con esta nueva adquisición, SMU incursiona en un modelo de negocio altamente
 atractivo, con alta rentabilidad sobre sus activos y tasa de crecimiento, con tiendas de conveniencia instaladas en sectores
 de mucho tráfico, aprovechando el consolidado posicionamiento de OK Market, lo que los convierte en líderes
 indiscutidos del mercado de tiendas de conveniencia”. En 2008, Unimarc fue comprada por la sociedad SMU, que la
 anexó a una serie de cadenas regionales como Deca, Bryc, Korlaet, Cofrima, entre otras, convirtiéndose en la red de
 supermercados más grande de Chile, superando en número de locales a sus competidores. El grupo SMU logró unir 38
 cadenas de supermercados convencionales y algunos hipermercados bajo las marcas “HiperUnimarc”, “Unimarc” y
 “Mayorista 10”. Como resultado de todo lo anterior el grupo SMU se ubica en el tercer lugar del mercado, medido por
 participación nacional en ventas, tras D&S-Walmart (HiperLider, Lider, Ekono, ACuenta) y Cencosud (Jumbo y Sta.
 Isabel).
 1 Nota: A lo largo del enunciado se hace referencia a los supermercados convencionales. Ello excluye a los “Hipermercados”
 (HiperLider, Jumbo, HiperUnimarc, Tottus), los cuales tienen tamaños superiores, un significativo componente de SKU´s no
 alimenticios y mayor número de productos (SKU2) que los supermercados convencionales (Líder, Sta. Isabel, Unimarc, entre
 otros)
 2 SKU: Stock Keeping Unit. Corresponde a la identificación de una combinación de marca, tamaño envase y formato. Así, por
 ejemplo, en bebidas, el envase de Coca Cola de 1 litro en empaque desechable es un SKU y el envase de 2 litros retornable es
 otro SKU.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 180

[pág. 181]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | marzo 2010 | pregunta 1
 Convocatoria 1 | página original 32 | Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 En la siguiente tabla se entrega información comparativa de los distintos tipos de formatos en la distribución comercial en
 Chile:
 Ventas Márgen Rotación de
 Nº de Variedad
 Tamaño Nº de Anuales por Bruto Existencias
 2
 Ítemes de
 (M ) Cajas Local Unitario (Nº de veces
 (SKU’s) Productos
 (US$) (%) al año)
 Tienda de Conveniencia 200 3.000 2 1.500.000 35% Baja 9 veces
 Supermercado Convencional 1.800 30.000 10 11.000.000 20% Alta 6 veces
 Almacén de Barrio 50 500 1 200.000 15% Muy Baja 3 veces
 A usted se le pide responder:
 1. ¿Por qué las “tiendas por conveniencia” son exitosas desde el punto de vista de rentabilidad sobre sus inversiones
 (activos)? En otras palabras, ¿cuáles son los factores críticos de su éxito?. En su respuesta utilice argumentos
 comerciales y financieros.
 2. Desde el punto de vista de su estrategia comercial, ¿qué le aporta al Grupo SMU la compra de OK Market?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 181

[pág. 182]
Marketing - versión clara y reordenada
 Fundamentos de Marketing | agosto 2025 | pregunta 1
 Convocatoria 2 | página original 439 | Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N%1
 En el competitivo mercado global de zapatillas deportivas, dominado históricam
 ente por gigantes como
 Nike y
 Adidas, pocas marcas emergentes han logrado abrirse camino. La suiza On, fundada
 en 2010, es una de esas
 excepciones. En menos de 15 años, On pasó de ser una “startup” con un producto
 experimental a una marca
 global valorada en más de 11.000 millones de dólares, con presencia en más de 80
 países.
 La historia de la marca suiza On comenzó en 2010, cuando tres
 amigos -—Olivier Bernhard, Caspar Coppetti y David
 Allemann— decidieron reinventar la experiencia de correr. La
 motivación surgió de una búsqueda personal por mejorar la
 sensación del running, protegiendo las articulaciones y ofreciendo
 un mayor confort. Su primer prototipo, bautizado informalmente
 como “Frankenstein”, incorporaba trozos de manguera en la
 suela, buscando crear aterrizajes suaves y despegues potentes. Aunque visualmen
 te poco atractivo, el concepto
 fue revolucionario y rápidamente ganó el premio ISPO BrandNew ese mismo
 año, marcando el inicio del
 posicionamiento diferencial de la marca.
 Desde el inicio, On eligió un camino diferente a los de Nike y
 Adidas. Mientras estas marcas se construían alrededor del alto
 rendimiento competitivo y del estilo urbano, respectivamente,
 Ón apostó por la comodidad, la innovación tecnológica y la
 sustentabilidad. Su tecnología patentada, CloudTecO', permite
 una experiencia de carrera que se describe como “correr sobre
 nubes”, enfocada en reducir el impacto en las articulaciones.
 Así, On se posicionó como una marca premium orientada a
 corredores serios y conscientes del medioambiente, dispuestosa |
 _
 pagar por una experiencia distinta que combina ciencia, confort y responsabi
 lidad social.
 Durante sus primeros años, On creció consistentemente, ganando adeptos
 entre atletas amateurs avanzados y
 profesionales que valoraban su propuesta. La marca reforzó su imagen con
 evidencia científica sobre beneficios
 fisiológicos (como menores niveles de lactato? y frecuencia cardiaca durante
 el ejercicio), el patrocinio de atletas
 como Nicola Spirigi, y la apertura de oficinas en
 Portland, EE.UU., cerca del corazón de la industria del
 deporte. La incorporación del tenista Roger Federer como
 inversor y embajador, en 2019, consolidó su estatus
 aspiracional y premium.
 Sin embargo, el crecimiento de On ha estado centrado en
 un segmento relativamente pequeño del mercado global
 de running. Según estimaciones, el mercado total
 asciende a 54.000 millones de dólares anuales, donde los
 - — corredores ocasionales representan el 60% (=32.400
 millones de USD), los regulares un 30%, y los profesionales/élite apenas
 un 10%. Hasta hoy, On se ha enfocado
 principalmente en este 10%, dejando sin atender un segmento ocasional
 masivo, con hábitos menos exigentes
 pero con alto volumen.
 ! CioudTec es una tecnología de amortiguación y propulsión basada
 en una serie de cavidades huecas ("clouds") que se comprimen y
 expanden durante el movimiento, ubicadas en la suela del calzado. Estas
 "nubes" permiten que el impacto al aterrizar se absorba
 vertical y horizontalmente, ofreciendo amortiguación cuando el pie toca
 el suelo y una respuesta firme al despegar.
 ? El lactato es un compuesto químico que se produce de forma natural en
 el cuerpo cuando se descomponen los carbohidratos para obtener
 energía en condiciones de bajo oxígeno. Esto puede ocurrir durante el ejercicio
 intenso, o cuando hay una infección o enfermedad que
 reduce el suministro de oxígeno a los tejidos. Los niveles de lactato son una
 medida de la concentración de lactato en la sangre, que se
 utiliza para evaluar la salud del paciente
 y su función metabólica.
 3 Nicola Spirig es una abogada suiza y ex triatleta profesional. Es
 campeona olímpica de 2012 y seis veces campeona europea.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 182

# Manual de Marketing · parte 6 (páginas 301-338)

Fuente: 01_MANUAL_ULTIMATE_MARKETING_EDG_2027_V2_FORMULAS_Y_METRICAS_CLARAS

[pág. 301]
Marketing - versión clara y reordenada
 garantiza un efecto estable durante todo el horizonte.
 agosto 2023 - pregunta 5 - Conjoint por segmento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 398-399 | convocatoria
 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 1. Diferencias de preferencia e importancia. Ambos segmentos prefieren los beneficios
 disponibles y menor precio, pero en el primero los servicios pesan más y en el segundo el precio
 domina. La importancia relativa se calcula con rangos de part-worth, condicional a los niveles del
 estudio:
 Atributo Rango S1 Importancia S1 Rango S2 Importancia S2
 Precio 0,5 22,73% 0,9 56,25%
 Todas las clases 0,3 13,64% 0,1 6,25%
 Interacción 0,6 27,27% 0,2 12,50%
 Material extra 0,4 18,18% 0,2 12,50%
 Offline 0,4 18,18% 0,2 12,50%
 Total 2,2 100% 1,6 100%
 El segmento 1 representa 40% y el 2, 60%; no se ponderan las utilidades y luego se concluye que
 todos quieren la misma oferta. Todos los coeficientes individuales significativos tampoco prueban
 que cada diferencia entre clases sea significativa: para eso se necesita el contraste
 correspondiente. En modelos por clase pueden existir diferencias de escala; las importancias
 relativas y los trade-offs monetarios ayudan a interpretar sin convertir el tamaño de un coeficiente
 aislado en una preferencia universal.
 2. Interacción a US$10 frente al plan de US$9. La tabla entrega precio como part-worth en tres
 niveles y no muestra una pendiente única perfectamente lineal: en S1 el cambio es -0,3 entre 9 y
 11, pero -0,2 entre 11 y 13; en S2 es -0,7 y -0,2. Por eso debe declararse cómo se interpola el
 precio nuevo, en lugar de atribuir a la tabla una derivada exacta no reportada.
 Usando una aproximación lineal sobre el rango completo 9-13, las pendientes son -0,5/4=-0,125 en
 S1 y -0,9/4=-0,225 en S2. DAP por interacción=0,6/0,125=US$4,80 y 0,2/0,225≈US$0,89. Cobrar
 US$1 extra por ese atributo mejora utilidad de S1 en 0,6-0,125=+0,475, pero empeora la de S2 en
 0,2-0,225=-0,025. Por tanto, recomendaría ofrecer ambos planes, sujeto a costos: el original sin
 interacción a US$9 y el nuevo con interacción a US$10, para que se autoseleccionen.
 Como comprobación más local, interpolar solo entre US$9 y US$11 da pendientes -0,15 y -0,35; las
 DAP locales son US$4 y US$0,57, y los cambios de utilidad al precio US$10 son +0,45 y -0,15. La
 recomendación de dos ofertas se mantiene. No se deben presentar estas dos DAP como
 simultáneamente exactas; son convenciones diferentes ante la falta de linealidad precisa de los
 niveles. La DAP de S1, en particular, requiere extrapolación si se interpreta como un premium
 completo: el estudio solo observó hasta US$13.
Examen de Grado UC | materia, preguntas y respuestas 301

[pág. 302]
Marketing - versión clara y reordenada
 El plan premium tiene que financiar el costo de interacción y evitar congestión o una promesa
 imposible para los instructores. Tampoco es correcto suponer que 40% comprará exactamente el
 nuevo plan y 60% el antiguo: las clases son probabilísticas, existen preferencias no observadas y
 puede haber no compra. Se debe simular elección y contribución y validar conversión/retención.
 Reemplazar el plan original podría perder al segmento mayor, mientras mantener solo el antiguo
 desaprovecha valor en S1.
 3. Por qué CBC indirecto. Los consumidores eligen entre paquetes completos y enfrentan
 restricciones; es difícil que declaren en una escala comparable cuántas “unidades de utilidad” les
 entrega cada nivel aislado. Preguntar importancia directa favorece respuestas en que todo es
 importante y no obliga a intercambiar precio por beneficios. CBC hace variar atributos en tareas
 diseñadas y observa elecciones, a partir de las cuales se estiman trade-offs y heterogeneidad.
 Puede imitar mejor una decisión que calificar cada atributo por separado. Sus límites siguen siendo
 hipoteticidad, diseño, carga cognitiva, sesgo de muestra y supuestos de elección; por ello se incluye
 una alternativa realista de no suscripción y se contrasta con conducta real. “Indirecto” no significa
 que se pueda prescindir de preguntar ni que el resultado sea automáticamente causal en el
 mercado.
 enero 2021 - pregunta 5 - Conjoint versus datos históricos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 337-337 | convocatoria
 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 a. Aporte del conjoint frente al panel. El director 1 tiene razón en que el panel contiene
 decisiones efectivas, precios pagados y cambios de marca, lo que evita parte del sesgo hipotético.
 Sin embargo, ese dato solo observa productos y combinaciones disponibles. Si Arcor introduce
 formatos, ingredientes o combinaciones nuevas, la base puede no tener variación suficiente para
 identificar cómo se valorarían. El conjoint de perfil completo permite variar marca, formato, fruto y
 precio de forma diseñada y evaluar configuraciones no existentes, separando efectos principales
 bajo sus supuestos. Por eso sí existe una ganancia informativa; no se debe sustituir una fuente por
 otra. Usaría panel para dimensionar comportamiento y calibrar, y conjoint para trade-offs de la
 innovación. La predicción final debe contrastarse con elección y recompra reales. Además, precios
 y promociones del panel pueden ser endógenos: millones de registros no garantizan identificación
 causal.
 b. Segmentación por preferencias. Sí puede hacerse una segmentación más fina que edad y
 sexo si el diseño de perfil completo permite estimar utilidades por persona, con suficientes tareas y
 calidad de respuesta. Esas utilidades pueden agruparse en conglomerados de preferencias, o
 estimarse con un modelo de clases/heterogeneidad apropiado. Luego se perfila cada grupo con
 variables demográficas y de comportamiento para poder encontrarlo y atenderlo. No basta dividir la
 tabla promedio por edad/sexo si se descartó la información individual o cada encuestado evaluó
 muy pocos perfiles. Una muestra de 720 casos ofrece volumen, pero no prueba por sí sola
 identificación de utilidades ni estabilidad de los segmentos.
 El beneficio para Arcor es descubrir un nicho que valore una combinación donde la marca tenga
 posibilidades, aunque en el agregado Costa y Nestlé sean más preferidas. La segmentación debe
Examen de Grado UC | materia, preguntas y respuestas 302

[pág. 303]
Marketing - versión clara y reordenada
 mostrar tamaño, accesibilidad, contribución y estabilidad; no se deben escoger segmentos solo
 porque entregan a Arcor una utilidad alta. También hay que evitar comparar utilidades absolutas
 entre modelos con escalas distintas sin normalización y validación.
 c. Omisión de logos. No aceptaría la afirmación categórica de que toda ausencia de un atributo
 sesga significativamente el estudio. El efecto depende de si los sellos cambian entre alternativas,
 de cómo se muestran los perfiles y de si se correlacionan con los atributos incluidos. Si todos los
 productos llevaran idénticos sellos y esa condición se informara de forma constante, el atributo no
 permitiría diferenciar dentro del experimento; su omisión como variable no sesgaría
 automáticamente los trade-offs estimados en ese contexto. En cambio, si las opciones reales tienen
 sellos distintos, si los consumidores los infieren a partir de marca/ingrediente o si se presentan
 perfiles incompletos que sugieren ausencia de sellos, puede haber falta de realismo y atribución
 equivocada de preferencias a otros atributos.
 Investigaría si el sello es relevante y varía de manera verosímil, y lo mantendría visible/constante o
 lo incorporaría como atributo cuando sea necesario y compatible con el producto. Un diseño más
 cargado también aumenta fatiga, por lo que no se agrega todo indiscriminadamente. La tabla del
 enunciado menciona “Alto en... Calcio”; no se debe convertir ese texto en una afirmación sobre
 sellos regulatorios reales: la resolución analiza la omisión de información del producto tal como se
 plantea en el ejercicio. La recomendación es justificar el alcance del diseño, comprobar
 comprensión y validar predicción, en lugar de proclamar que un atributo omitido siempre es inocuo
 o siempre invalida todos los resultados.
 agosto 2017 - pregunta 5 - Conjoint y DAP
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 248-249 | convocatoria
 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 a. Formato omitido. Si volumen es relevante y varía entre alternativas reales, omitirlo puede
 reducir realismo y atribuir a precio/marca utilidades que corresponden a cantidad. El consumidor
 puede juzgar precio por litro o asumir tamaños distintos para marcas. Hay que especificar un
 formato constante en todos los perfiles, si se quiere estimar preferencias condicionales a ese
 formato, o incorporarlo como atributo con niveles verosímiles. Si permanece idéntico y explícito en
 todas las opciones, no hay automáticamente sesgo de sus diferencias dentro del experimento, pero
 el estudio no informa cómo se valoran otros formatos. La omisión de un atributo no obliga a concluir
 que todos los resultados son inválidos, ni autoriza ignorar una característica importante en la
 decisión de mercado.
 b. Homogeneidad y segmentación. No estoy de acuerdo con inferir homogeneidad de
 preferencias a partir de importancias parecidas por sexo, edad o GSE. La importancia resume el
 rango de utilidad, no cuál nivel se prefiere: dos personas pueden tener igual importancia de sabor y
 preferir sabores opuestos. Además, el promedio de un grupo demográfico puede ocultar
 heterogeneidad interna. Las tablas no presentan pruebas suficientes de igualdad de preferencias
 individuales. Se podrían estimar utilidades por persona y segmentar por esas preferencias, validar
 tamaño/estabilidad y luego perfilar demográficamente. Eso puede descubrir diferencias que una
 segmentación por demografía no capta.
Examen de Grado UC | materia, preguntas y respuestas 303

[pág. 304]
Marketing - versión clara y reordenada
 El grupo de no consumidores tiene solo diez observaciones frente a 533 consumidores según la
 tabla; sus porcentajes son especialmente inciertos. La tabla contiene una cifra de muestra total
 incompatible con las sumas de subgrupos en el OCR: se debe leer el original y no usar ese dato
 aislado para sostener precisión. La ausencia de grandes diferencias en esos promedios no
 demuestra ausencia de beneficio comercial de toda segmentación.
 c. Valor monetario de marca. Para este consumidor, Gatorade tiene utilidad 0 y Powerade -10: la
 ventaja de Gatorade es 10 unidades de utilidad, manteniendo atributos. Convertirla a pesos
 requiere la relación precio-utilidad. Los niveles son $800→10, $900→0 y $1.000→-5: no son
 perfectamente lineales. Por eso no existe una única DAP exacta independiente del precio base
 con la tabla dada.
 Si se usa la pendiente promedio entre $800 y $1.000, βprecio=(-5-10)/200=-0,075 y el valor de
 marca es 10/0,075≈$133,33. Debe declararse que es una aproximación lineal sobre el rango. Una
 comparación exacta de niveles sí puede hacerse: Powerade a $800 tiene precio+marca=10-10=0;
 Gatorade a $900 tiene 0+0=0. Por tanto, un premium de $100 de Gatorade sobre Powerade a
 $800 deja indiferente al consumidor, con los otros atributos iguales. En el tramo $900-$1.000 la
 pendiente es -0,05, que sugeriría $200 si se extrapola, pero ese premium no se observa completo
 dentro del tramo; no debe presentarse como dato exacto probado.
 El intercepto o utilidad del perfil base, 25, se cancela al comparar perfiles y no se suma a la DAP de
 marca. El R²=0,96 del ajuste individual no corrige la falta de una pendiente única ni garantiza
 compra real. La respuesta distingue ventaja de marca, conversión monetaria y supuesto de precio,
 en lugar de dividir por una pendiente escogida sin explicación.
 agosto 2021 - pregunta 2 - Conjoint y DAP
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 343-344 | convocatoria
 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 a. Dos beneficios del conjoint. Primero, permite evaluar atributos/configuraciones nuevas que aún
 no existen en compras históricas, relevantes cuando se decide desarrollo tecnológico. Una base
 enorme de transacciones no identifica por sí sola preferencia por una característica sin variación
 observada. Segundo, el diseño varía atributos para estimar trade-offs separando sus efectos bajo
 un modelo; las transacciones pueden confundir marca, precio, memoria y disponibilidad cuando
 aparecen juntos. La información histórica aporta conducta real y sirve para calibrar, mientras el
 conjoint sigue siendo hipotético y depende de diseño/muestra. No se afirma que toda compra
 observada sea inútil ni que una encuesta garantice demanda.
 b. DAP de 16 a 32 GB. La mejora de utilidad es 120-100=20, no 120: el punto de partida es 16 GB.
 La pendiente de precio es -60/100=-0,6 unidades de utilidad por dólar, consistente también entre
 US$500 y US$600. DAP=-20/(-0,6)=US$33,33. Un fabricante puede comparar ese valor con costo
 incremental, diseñar un premium, evaluar configuraciones y simular elección. Si la mejora cuesta
 más que el valor capturable y no aporta otro beneficio, podría priorizar 16 GB. No significa que
 cobrará exactamente US$33,33 a todos: es un trade-off del consumidor promedio dentro del modelo
 y la utilidad marginal de RAM muestra rendimientos decrecientes (100 por pasar 8→16; solo 20 por
 16→32).
Examen de Grado UC | materia, preguntas y respuestas 304

[pág. 305]
Marketing - versión clara y reordenada
 c. Comparación de consolas. Bajo utilidad aditiva, misma escala y sin interacciones, la consola A
 suma Sony 100 + RAM8 0 + almacenamiento500 0 + precio500 -60 + resolución8K 10 = 50. B suma
 Nintendo -50 + RAM16 100 + almacenamiento1TB 80 + precio400 0 + resolución4K 0 = 130. B es
 más preferida, por 80 unidades de utilidad, pese a la marca Sony y mejor resolución de A. No se
 escoge la consola mirando un único atributo.
 Son utilidades del consumidor promedio; no son probabilidades de compra ni permiten asegurar
 que cada usuario prefiera B. Si se adopta un modelo de elección, hay que especificar escala,
 alternativas y no compra. La conclusión comparativa se obtiene con los supuestos explícitos que el
 ejercicio pide, sin sustituirla por un análisis genérico de crecimiento de videojuegos durante
 pandemia.
 enero 2019 - pregunta 5 - Conjoint y diseño
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 286-286 | convocatoria
 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 a. Problema de marketing y uso de resultados. Uber debe decidir cómo ajustar su servicio para
 mantener una propuesta competitiva ante Cabify: cuánto invertir en rapidez, calidad del vehículo,
 desempeño, selección y experiencia del conductor. El problema no es simplemente “conocer
 opiniones”, sino elegir cambios de servicio que mejoren preferencia y rentabilidad sin sacrificar
 disponibilidad. Los resultados estiman intercambios entre atributos. La utilidad de un perfil completo
 es la suma de sus utilidades parciales, bajo el supuesto aditivo del estudio.
 El rango de utilidad es 4 en demora (0 a -4), 2 en antigüedad del vehículo (0 a -2), 2 en desempeño
 (0 a -2), 3 en selección (0 a +3) y 4 en experiencia (0 a +4). Sobre un total de 15, las importancias
 son 26,67%, 13,33%, 13,33%, 20% y 26,67%, respectivamente. Demora y experiencia tienen el
 mayor rango en los niveles examinados. La entrevista presencial añade 3 unidades de utilidad: si
 para aplicarla la espera aumentara de 5 a 7 minutos, la ganancia neta sería +3-2=+1; si aumentara
 de 5 a 10, sería +3-4=-1. Es un ejemplo de por qué no basta recomendar el nivel más preferido de
 cada atributo sin considerar sus efectos operacionales. El OCR pierde los signos negativos de
 varias celdas; en el original, las utilidades de 10 minutos y de vehículos más antiguos son -4 y -2.
 Uber puede simular configuraciones, identificar grupos con preferencias diferentes y comparar
 ganancias de preferencia con costos, disponibilidad de conductores y contribución. No se puede
 calcular disposición a pagar monetaria con esta tabla porque no incluye precio; tampoco se puede
 afirmar una participación de mercado sin una regla de elección y ofertas competidoras definidas.
 Las importancias calculadas son condicionales a los niveles ofrecidos, no universales.
 b. Por qué encuestar aunque existan millones de viajes. Las transacciones muestran elecciones
 entre servicios que realmente estuvieron disponibles, a los precios y tiempos históricos. Sirven para
 estudiar comportamiento y validar pronósticos, pero pueden no contener una política nueva de
 entrevista presencial, o separar el efecto de experiencia del conductor del vehículo y de los usuarios
 a quienes se le asigna. Una base muy grande no compensa ausencia de variación, confusión entre
 atributos ni selección. El conjoint permite variar atributos de manera diseñada, incluyendo
 configuraciones nuevas, y obtener trade-offs. Sus límites son el carácter hipotético, la carga de
 evaluación y la muestra de usuarios de Uber: esta última no representa automáticamente a no
Examen de Grado UC | materia, preguntas y respuestas 305

[pág. 306]
Marketing - versión clara y reordenada
 usuarios o clientes exclusivos de Cabify. Recomendaría complementar preferencias declaradas con
 experimentos de servicio y compras reales.
 c. Cantidad de perfiles completos. Hay cuatro atributos de tres niveles y uno de dos. El factorial
 completo tiene 3×3×3×2×3=162 perfiles, excesivo para cada persona. Para un modelo aditivo con
 codificación por nivel base se estiman (3-1)+(3-1)+(3-1)+(2-1)+(3-1)=9 efectos, más intercepto: 10
 parámetros. Diez perfiles linealmente independientes son un mínimo algebraico para estimarlos,
 pero dejarían cero grados de libertad para error y poca capacidad de validación. No elegiría diez
 solo por alcanzar identificación.
 Una elección defendible es 18 perfiles de estimación en un diseño fraccionado balanceado de
 rango completo, más algunos perfiles reservados para comprobar predicción. Debe revisarse la
 matriz del diseño y distribuir la carga si es necesario; “18” no garantiza por sí solo ortogonalidad. La
 justificación es preservar identificación de los efectos principales, repetir información para estimar
 error y evitar el cansancio del factorial completo. Si se quieren interacciones, harán falta parámetros
 y un diseño más amplio. El número de encuestados es otra decisión y no sustituye el número de
 perfiles necesarios para identificar utilidades individuales.
 agosto 2020 - pregunta 6 - Conjoint y diseño de oferta
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 327-327 | convocatoria
 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 a. Dos problemas precisos de marketing. Primero, Cornershop debe transformar la prueba
 inducida por restricciones sanitarias en uso rentable y repetido cuando vuelvan las alternativas
 presenciales. Que una persona descargue la aplicación no prueba un hábito ni retención; hay que
 decidir qué propuesta y estímulos mantienen la conveniencia más allá de la pandemia. Segundo,
 debe adaptar su oferta a nuevos perfiles y zonas: la incorporación de consumidores de estratos
 medios/bajos y la expansión regional pueden cambiar sensibilidad a tarifas, tiempos, cobertura y
 membresía. La decisión es qué combinación de atributos y segmentos atender, considerando
 operación y margen. Son problemas gerenciales, distintos de la necesidad de recolectar
 información.
 b.i. Selección de un solo desafío y metodología. Elijo ajustar la propuesta de valor a nuevos
 clientes -tarifa, membresía Pop, comercios y entrega- y propongo un conjoint basado en elección.
 Es apropiado porque la gerencia debe elegir una combinación de atributos y no solo medir
 satisfacción con una oferta actual. Las elecciones entre perfiles permiten estimar cuánto valoran
 diferentes configuraciones y sus trade-offs. El diseño incluiría opciones plausibles, precio, una
 alternativa actual y no usar el servicio; se evitarían combinaciones operativamente imposibles. No
 resuelvo aquí, simultáneamente, el desafío de predecir hábitos o expansión geográfica: esos
 requerirían evidencia adicional.
 b.ii. Datos requeridos. Se necesita una investigación previa para determinar atributos y niveles
 comprensibles, una muestra del público objetivo con clientes nuevos, antiguos y potenciales -sin
 reducirla a los más activos- y las elecciones repetidas frente a tareas diseñadas. Se registran
 características para interpretar heterogeneidad, zona, experiencia con apps y hábitos de compra.
 Para convertir las preferencias en una decisión económica se requieren costos de
Examen de Grado UC | materia, preguntas y respuestas 306

[pág. 307]
Marketing - versión clara y reordenada
 preparación/despacho, cobertura, capacidad, tarifas competidoras y márgenes; para calibrar, datos
 de compras reales y repetición por cohorte. Una muestra de usuarios de altos ingresos adquiridos
 antes de la pandemia no representa por sí sola a todos los clientes nuevos.
 b.iii. Resultados y decisiones. Se obtendrían utilidades parciales por atributo, sensibilidad al
 precio, disposición a pagar e importancia relativa dentro de los niveles estudiados. Es posible
 identificar grupos con preferencias distintas, simular combinaciones de tarifa/membresía/comercios
 y estimar elección relativa bajo una oferta competidora y no compra. Se compararía contribución
 esperada y factibilidad, no solo el perfil que maximiza preferencia. Por ejemplo, un segmento podría
 pagar por membresía con despacho frecuente y otro preferir tarifa por pedido; esa es una hipótesis
 que el estudio debe estimar, no un resultado inventado del caso. La gerencia usaría la simulación
 para seleccionar ofertas y luego probarlas en un piloto con compra, repetición y margen.
 El conjoint produce preferencias declaradas, no garantiza retención cuando termine la pandemia.
 La recomendación debe especificar ese límite y validar la propuesta con conducta real. Una
 respuesta completa vincula explícitamente problema, modelo, datos, resultados y decisión;
 enumerar herramientas no satisface los tres incisos.
 enero 2025 - pregunta 6 - Conjoint y disposición a pagar
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 436-437 | convocatoria
 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 1. Por qué los datos históricos no bastan para pronosticar la nueva línea. Los dos años de
 transacciones permiten estudiar la categoría existente: estacionalidad, relación entre precio y
 volumen, promociones, sabores y diferencias de canal. Sin embargo, ningún helado observado
 tiene el atributo “enriquecido con proteínas”. Por tanto, la base no contiene variación que permita
 identificar su efecto. Un modelo que ajuste muy bien las ventas de helados convencionales puede
 predecir mal el nuevo producto: ajustar el pasado no demuestra capacidad de extrapolar a un
 atributo que nunca se observó. Tampoco basta agregar una variable proteína si vale cero en todas
 las observaciones; su coeficiente no se puede estimar con esos datos.
 La tendencia de productos proteicos en yogures, leche o pan constituye una hipótesis de
 oportunidad, no una estimación de demanda de helados. Las ocasiones de consumo, el sabor, el
 precio y las expectativas pueden ser distintos. Además, precio y promoción históricos pueden
 responder a demanda esperada; su correlación con ventas no identifica automáticamente un efecto
 causal. Usaría esas transacciones para establecer el tamaño de la categoría, estacionalidad,
 distribución, precios de referencia y comportamiento de los productos actuales, y complementaría
 con investigación de la nueva propuesta: comprensión del concepto, prueba sensorial, conjoint y
 una prueba de compra/recompra en un piloto. Para convertir preferencia en ventas se requiere,
 además, un supuesto verificable sobre disponibilidad, exposición, competencia, opción de no
 compra y canibalización. La recomendación es combinar fuentes, explicando qué parámetro
 identifica cada una.
 2. Disposición a pagar por proteína. La utilidad del precio aumenta cuando este disminuye. En el
 segmento 1, bajar de $12.000 a $10.000 aumenta la utilidad en 0,5; bajar otros $2.000 agrega otros
 0,5. Bajo una aproximación lineal, la pendiente es -0,5/2.000=-0,00025 unidades de utilidad por
Examen de Grado UC | materia, preguntas y respuestas 307

[pág. 308]
Marketing - versión clara y reordenada
 peso. En el segmento 2 es -0,3/2.000=-0,00015. La disposición a pagar por una mejora equivale al
 aumento de precio que anula su ganancia de utilidad: DAP=-Δu/βprecio.
 Mejora frente al nivel base Segmento 1 Segmento 2
 Proteína enriquecida frente a regular 0,8/0,00025 = $3.200 1,2/0,00015 = $8.000
 Vainilla frente a manjar 0,5/0,00025 = $2.000 0,8/0,00015 ≈ $5.333
 Marca B frente a A -$1.600 +$8.000
 Marca C frente a A -$2.400 -$10.000
 Los valores negativos para una marca indican el descuento necesario para compensar su menor
 utilidad frente a A. Los clientes actuales de A valoran más la proteína y son menos sensibles al
 precio en el rango estudiado, pero prefieren B a A, según los resultados entregados. No se debe
 cambiar ese resultado por una presunción de lealtad. Puede ser una oportunidad para mejorar A o
 una amenaza competitiva; habría que verificar por qué ocurre.
 3. Importancia relativa de los atributos. Se calcula el rango de utilidad de cada atributo -máximo
 menos mínimo- y se divide por la suma de rangos. No se usa el mayor coeficiente aislado, ni un
 valor p, ni se suman las utilidades de todos los niveles.
 Atributo Rango segmento 1 Importancia Rango segmento 2 Importancia
 segmento 1 segmento 2
 Sabor 0,5-(-0,3)=0,8 25,00% 0,8-(-0,4)=1,2 21,05%
 Proteína 0,8-0=0,8 25,00% 1,2-0=1,2 21,05%
 Precio 1,0-0=1,0 31,25% 0,6-0=0,6 10,53%
 Marca 0-(-0,6)=0,6 18,75% 1,2-(-1,5)=2,7 47,37%
 Total de rangos 3,2 100% 5,7 100%
 La importancia depende de los niveles incluidos. Un rango de precios más estrecho reduciría su
 importancia relativa aunque la sensibilidad marginal no cambiara. Asimismo, significancia al 5% no
 implica que todos los atributos tengan igual relevancia comercial, ni que todas las diferencias entre
 segmentos hayan sido probadas estadísticamente.
 4. Evaluación del plan de marca A, segmento 1 y precio premium. El segmento 1 reúne 70% de
 la población del estudio y prefiere A a B y C: es una razón a favor del alcance y del uso de A.
 También valora el enriquecimiento, con DAP de $3.200 respecto de proteína regular, manteniendo
 los otros atributos. Sin embargo, es el segmento más sensible al precio y el precio es su atributo de
 mayor importancia. El tamaño por sí solo no justifica un premium grande. En el segmento 2 -30%- la
 DAP por proteína es mayor y el precio pesa menos, lo que favorece un producto premium; pero la
 preferencia por B representa una desventaja de A que debe enfrentar la propuesta. En los niveles
 examinados, el perfil de mayor utilidad en el segmento 1 es vainilla, enriquecido, A y $8.000; en el 2
 es vainilla, enriquecido, B y $8.000. El perfil más preferido no es necesariamente el que maximiza
 contribución: faltan costos, márgenes y respuesta de competidores.
 No aprobaría el plan sin simular precios y ofertas completas para ambos segmentos, incorporar una
 opción de no compra y contrastar volumen incremental con canibalización de helados actuales. La
 DAP calculada es un intercambio de utilidad bajo linealidad del precio; no significa que se venderá
Examen de Grado UC | materia, preguntas y respuestas 308

[pág. 309]
Marketing - versión clara y reordenada
 el mismo volumen al cobrar el premium ni que $8.000 adicionales sean seguros. En particular, ese
 valor del segmento 2 supera el rango total de precios observado ($8.000-$12.000), por lo que
 extrapolarlo exige cautela y una prueba adicional. La recomendación defendible es probar A
 enriquecido, con sabor preferido y precios dentro del rango, comparar contribución por segmento y
 escalar según compra y recompra reales. Así se usan todos los resultados sin confundir preferencia
 declarada con ventas garantizadas.
 agosto 2019 - pregunta 5 - Difusión de Bass
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 298-299 | convocatoria
 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 a. Fertilidad y velocidad de crecimiento. Bass expresa las primeras adopciones como un proceso
 con influencia externa y contagio entre adoptantes: la velocidad depende de p, q y del mercado
 potencial M. Menos nacimientos reducen el número de hogares con niños en edad de usar pañales
 y, por tanto, el mercado potencial de Pants. Manteniendo p y q, un M menor reduce el volumen de
 nuevas adopciones; una proporción creciente de una base que se contrae puede coexistir con
 ventas de categoría decrecientes. No se debe interpretar el alza de penetración de Pants como
 crecimiento automático de todas las ventas.
 En el Bass de M constante, escribir dN/dt=[p+q(N/M)](M-N) ayuda a ver la relación. No obstante, la
 categoría recibe nuevos padres y pierde usuarios cuando los niños crecen; sus ventas también
 incluyen compras repetidas. Por eso, para pronosticar unidades debe distinguirse primera adopción
 de consumo posterior y modelar la base demográfica que cambia. Un escenario puede reducir M
 según cohortes y luego convertir adoptantes activos en frecuencia y unidades. La caída de fertilidad
 no implica necesariamente menores p o q: reduce la base potencial, salvo evidencia de que
 también modifica comunicación o imitación.
 b. Precio y difusión. La gráfica original muestra que la penetración aumenta mientras el precio
 relativo de Pants frente al pañal clásico disminuye. Esto es compatible con que una menor barrera
 de precio facilite prueba y acelere adopción, pero la coincidencia temporal no identifica causalidad:
 pueden cambiar distribución, comunicación y aprendizaje. El Bass básico no incluye precio y no
 puede atribuir ese cambio a un coeficiente que no tiene. Puede usarse una extensión de difusión en
 la que la tasa de adopción aumenta al disminuir el precio relativo, por ejemplo multiplicando la
 fuerza de adopción por una función decreciente del precio, y estimar su sensibilidad con datos
 adecuados. Otra opción es modelar la elección Pants/clásico con utilidad dependiente de precios y
 combinarla con el número de hogares y la difusión. Deben explicitarse la especificación y la
 identificación; no basta ajustar la curva y llamar al residuo “efecto precio”.
 Si la caída de precio aumenta la probabilidad de elegir Pants, acelera penetración y compras en
 unidades, pero el ingreso o margen puede no aumentar: precio menor y traslado desde pañales
 propios clásicos pueden compensar el volumen. La comparación pertinente requiere unidades
 incrementales, contribución y respuesta competitiva.
 c. Participaciones con precios iguales. La utilidad determinística de proveedor es 0,56-1,5P y la
 de marca propia es 0-1,5P. Bajo logit binario con la misma sensibilidad al precio y los precios
 iguales, el componente de precio se cancela. La diferencia es 0,56. Entonces
Examen de Grado UC | materia, preguntas y respuestas 309

[pág. 310]
Marketing - versión clara y reordenada
 Pproveedor=exp(0,56)/[1+exp(0,56)]=0,636453, aproximadamente 63,65%;
 Ppropia=1/[1+exp(0,56)]=36,35%. La razón de probabilidades es exp(0,56)≈1,7507. No se
 interpreta 0,56 como 56% de participación ni como un aumento de 56 puntos.
 Estas son participaciones predichas dentro de las dos alternativas del ejercicio para el consumidor
 promedio. No incorporan no compra, disponibilidad ni una distribución de preferencias: si existiera
 heterogeneidad, aplicar logit al coeficiente promedio no sería necesariamente igual al promedio de
 probabilidades individuales. La escala del precio resulta inusual si se expresa literalmente en pesos,
 pero no afecta este cálculo porque los precios son iguales y se cancelan.
 agosto 2012 - pregunta 5 - Diseño muestral
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 110-111 | convocatoria
 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 1. Comparación según el objetivo. Se busca estimar cuántas personas irán en automóvil cuando
 termine la novedad y el mall opere plenamente. No basta contar visitantes actuales ni estimar una
 proporción de quienes ya asistieron. Alpha entrevista asistentes actuales en una sola entrada y en
 horarios determinados: observa personas que conocen el lugar y puede medir condiciones
 concretas de visita, pero excluye no asistentes y otras entradas, sobreselecciona visitantes
 frecuentes y captura justamente la etapa inicial que el objetivo pretende superar. Seleccionar a
 alguien cada tres minutos no garantiza probabilidades iguales para cada persona; tampoco cubre
 todo el día. La distribución de días/horarios solo representa el flujo cubierto, no la demanda futura.
 Su tamaño es apropiado por supuesto del caso; no corresponde rechazarla por ser 580 frente a
 1.800.
 Beta alcanza hogares de varias comunas, puede incluir futuros visitantes que no han ido y usa
 selección aleatoria dentro de estratos. Esa cobertura respecto de la población futura es una ventaja
 decisiva. Sin embargo, define como objetivo jefes de hogar, mientras el problema se refiere a
 visitantes adultos en general; excluye a otros miembros con decisiones independientes. El marco de
 teléfonos fijos excluye hogares sin teléfono fijo y puede tener cobertura desigual; las llamadas de
 lunes a viernes entre 16 y 21 pueden no encontrar a todos. Proporcionalidad por comuna o estrato
 no corrige esas exclusiones ni la no respuesta. Ambos diseños usan intención de transporte, que
 puede diferir de conducta real bajo congestión, precios de estacionamiento o nuevas ofertas.
 2. Elección. Si debo elegir solo entre ambos, prefiero Beta, porque evita condicionar la muestra a
 haber visitado el mall durante su lanzamiento y puede aproximar mejor la población de quienes irían
 cuando opere plenamente. Es una elección por validez de cobertura, no por número de ventajas ni
 por tamaño muestral. La prefiero reconociendo la restricción a jefes de hogar y teléfonos fijos; no la
 llamaría representativa de toda la demanda futura sin ajustes.
 3. Dos mejoras principales. Primera: ampliar población y marco a todos los adultos relevantes del
 Gran Santiago, seleccionar aleatoriamente una persona elegible por hogar y usar un marco que
 incluya quienes carecen de teléfono fijo, con probabilidades y ajustes de no respuesta
 documentados. Eso corrige la exclusión más importante. Segunda: medir conjuntamente
 probabilidad/frecuencia de visita bajo un escenario explícito de plena operación y elección de
 transporte, con motivos, horarios y acompañantes. Para obtener número de personas o vehículos
Examen de Grado UC | materia, preguntas y respuestas 310

[pág. 311]
Marketing - versión clara y reordenada
 no basta la proporción que dice “iré en auto”: hay que estimar cuántos irán, cuántas visitas harán y
 ocupación de vehículos, distinguiendo personas de autos y visitas.
 Se puede triangular con tráfico y estacionamiento actuales y validar después cuando termine la
 novedad, pero el estudio debe concluir dentro de cuatro semanas: no resolvería el problema
 proponiendo esperar meses como única metodología. Presentaría un pronóstico condicionado, con
 sensibilidad a brecha intención-conducta, capacidad, congestión y transporte público. La
 disponibilidad actual de estacionamientos y menos de 20% en auto en días hábiles son
 antecedentes, no pruebas concluyentes de ausencia de congestión en régimen.
 marzo 2011 - pregunta 5 - Encuesta y muestreo
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 66-67 | convocatoria 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 El estudio no demuestra la afirmación específica de que personas compran Monterrey creyendo
 que compran Nescafé debido a semejanza del envase. Su variable es reconocimiento o confusión
 declarada en una tarea, no compra equivocada en condiciones reales. Tampoco separa el efecto
 causal de diseño del envase de conocimiento de marca u otras señales mediante una comparación
 experimental de envases alternativos.
 En P1, tras ver Monterrey tres segundos, 90,2% reconoce la marca y 3,1% dice Nescafé. Esto
 muestra que la gran mayoría distingue el producto en esa tarea. No prueba ausencia absoluta de
 confusión, pero no coincide con usar 57,6% como si fueran compras equivocadas. P2 pregunta
 “¿con qué marca cree que podría confundir...?”, después de mostrar de nuevo el envase: induce a
 considerar una posibilidad y mide asociación hipotética; 57,6% menciona Nescafé, no que lo haya
 comprado por error. P3 muestra ambos y pide elegir entre similitud/confusión: 71,3% declara
 similitud sin confundir al comprar, 22,9% cree que podría confundirse y 5,8% no ve parecido. Una
 posibilidad declarada tampoco mide incidencia conductual. El orden de preguntas puede aumentar
 saliencia y priming de similitud.
 La muestra por edad/sexo y puntos de alto tráfico no demuestra por sí sola una selección
 probabilística de todos los compradores de café de Santiago. Se desconoce probabilidad de
 inclusión, cobertura de compradores y no respuesta. Un margen nominal de 5,5% requiere
 supuestos de diseño; cumplir cuotas de censo no elimina sesgo. No corresponde declarar cero
 confusión porque 3,1% sea menor que 5,5%: un margen máximo no es una regla para convertir
 toda proporción menor en inexistente. Tampoco sin tamaños por sexo puede concluirse una
 diferencia estadísticamente probada entre hombres y mujeres.
 Propondría una tarea de compra con anaquel, alternativas, precios, tiempos y población
 pertinentes, registrando qué marca cree haber comprado y cuál eligió, con un diseño que varíe
 elementos del envase y un control adecuado. Ello ayuda a distinguir reconocimiento, parecido,
 posibilidad y error efectivo, y a aislar el papel del diseño. El informe debe limitarse al alcance
 metodológico; no decide por sí solo intención de imitación, responsabilidad jurídica o la validez
 completa de la demanda. La respuesta explica por qué las cifras no identifican la afirmación litigada,
 sin negar arbitrariamente todo dato de semejanza.
Examen de Grado UC | materia, preguntas y respuestas 311

[pág. 312]
Marketing - versión clara y reordenada
 agosto 2015 - pregunta 5 - Factores, segmentos y targeting
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 181-182 | convocatoria
 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 Interpretación. F1 se asocia con atractivo (+0,934), buena construcción -“mal construido” tiene
 -0,989- y prestigio (+0,903). F2 representa deportividad (+0,923) y buen diseño (+0,899). F3
 representa valor o desempeño respecto de precio (+0,866). Los factores explican 43%, 28% y 18%,
 en total 89%; un mapa bidimensional deja información fuera, por lo que deben leerse ambas
 proyecciones. Las correlaciones describen percepciones, mientras el cuadro B relaciona factores
 con preferencias declaradas.
 a. Segmentos 2 y 3 y elección. El segmento 2 es 12% del mercado estudiado y su preferencia
 responde a F2 (coeficiente 0,95), mientras F1 y F3 se reportan no significativos y se reemplazan por
 cero. Es el segmento más directamente alineado con una promesa deportiva y de buen diseño. El
 segmento 3 es 48%, responde a F1 (1,10) y sobre todo F3 (2,08), y no muestra un efecto
 significativo de F2 en esa regresión. Para una oferta que también promete buen desempeño
 respecto de precio, recomendaría como objetivo principal el segmento 3, por su tamaño y su
 valoración del valor, siempre que Jaguar pueda mantener calidad/atractivo/prestigio y demostrar
 ese desempeño. S2 es una alternativa o objetivo secundario si la fortaleza diferenciadora acaba
 siendo solo deportividad/diseño; no conviene tratar ambos como idénticos.
 No elijo S3 por tener un mayor R² (0,85 frente a 0,60): ese indicador describe ajuste, no atractivo
 comercial. Tampoco se demuestra que una diferencia entre coeficientes sea significativa por que
 uno fue reemplazado por cero. Para rentabilidad definitiva faltan costos, precio, acceso y respuesta
 competitiva; la elección es condicionada a la promesa planteada y a las preferencias del caso.
 b. Ubicación hipotética. El gráfico 1 muestra que Audi tiene la mayor coordenada en F2,
 aproximadamente +1,8. El gráfico 2 muestra que Accura, con la grafía del enunciado, tiene la
 mayor coordenada en F3, aproximadamente +1,3. Si Jaguar alcanza deportividad/diseño y valor del
 mejor mercado actual, debe situarse a la misma altura que Audi en la proyección F1-F2 y a la
 misma altura que Accura en F1-F3.
 La información no fija una coordenada única en F1: la promesa especifica esos dos factores, pero
 no declara que Jaguar iguale a una marca concreta en atractivo/construcción/prestigio. Por ello se
 grafica Jaguar=(x,≈1,8) en el primer mapa y Jaguar=(x,≈1,3) en el segundo, usando el mismo x y
 señalando que su valor requiere información adicional. No se coloca automáticamente en BMW, en
 el origen o en la mejor posición de F1. Si se adopta un supuesto sobre F1 para ilustrarlo, debe
 escribirse; no puede presentarse como una coordenada deducida del enunciado. Los valores son
 lecturas aproximadas de la figura, no puntajes tabulados exactos.
 agosto 2013 - pregunta 6 - Factorial y segmentación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 135-136 | convocatoria
 2
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 312

[pág. 313]
Marketing - versión clara y reordenada
 Respuesta desarrollada para estudio (no oficial)
 Lectura de factores. F1 representa preocupación por alimentación saludable: calorías, ausencia
 de aditivos, enfermedades, grasas y rotulación tienen cargas positivas importantes. F2 se relaciona
 con actividad física/deportiva e hidratación con cargas negativas (-0,69; -0,78; -0,75). Por tanto, un
 puntaje más negativo de F2 indica mayor acuerdo con esas conductas, en la orientación reportada.
 El signo de un factor puede invertirse sin cambiar el ajuste, pero hay que interpretar
 consistentemente cargas y puntajes. F3 representa descanso/sueño, con cargas +0,86 y +0,84. Los
 tres factores explican aproximadamente 60% de la varianza, dejando una parte no representada.
 1. Dos segmentos para la comunicación del gimnasio. Elegiría segmento 3 (20%, 60
 personas) y segmento 1 (33%, 99 personas). S3 tiene F2=-0,92: es el más asociado a
 ejercicio/deporte/hidratación, conducta directamente afín al gimnasio. Tiene más hombres (62%) y
 más jóvenes de 15-24 (38%), aunque no todos sus miembros son hombres jóvenes. S1 también
 tiene F2 negativo (-0,26), y F1=+0,91: combina afinidad moderada a actividad con alta
 preocupación alimentaria, que puede vincularse con vida saludable. Es 58% mujeres y tiene mayor
 proporción de edades 45-54 y 55+ (24% y 23%). El mensaje debe adaptar la propuesta a beneficios
 y acceso, en vez de usar un estereotipo demográfico como explicación causal.
 S2 tiene F2=+1,18, señal de menor actividad en la orientación del factor; confundir positivo con
 “más deporte” llevaría a elegir mal. Puede ser una oportunidad de activación si el gimnasio diseña
 barreras y apoyo, pero no es el grupo de afinidad inmediata. S4 destaca por F3=-1,33, descanso
 bajo, y F2≈0: los datos no lo hacen un objetivo prioritario para la oferta actual. La selección combina
 ajuste al servicio y tamaño; no prueba conversiones porque el estudio mide hábitos declarados y no
 una campaña.
 2. Programa Alimentación Sana y Vida Balanceada. No aceptaría como objetivo principal
 “hombres jóvenes que estudian o trabajan” solo por la propuesta de la agencia. El grupo más
 cercano a hombres jóvenes es S3, cuyo F1=-0,81 indica menor preocupación alimentaria, aunque
 es activo físicamente. S1, en cambio, tiene la mayor orientación a alimentación saludable y algo de
 actividad; es más coherente como objetivo inicial del nuevo programa. S3 podría requerir un
 mensaje distinto y educación, y merece una prueba, pero no se debe afirmar que su demografía
 garantiza interés en nutrición. La ocupación -estudia/trabaja- no está en la tabla.
 Sexo y edad muestran asociación global con segmentación según p=0,043 y 0,030; GSE no es
 significativo al 5% (p=0,170). Eso no autoriza elegir un grupo socioeconómico particular ni declarar
 significativas todas las diferencias de celdas. Perfil, necesidad, disposición a pagar y posibilidad de
 atender al segmento deben validarse antes de invertir. La respuesta correcta utiliza signo, tamaño,
 demografía y ajuste de la propuesta, sin reducir el análisis a “F2 alto es bueno”.
 marzo 2009 - pregunta 5 - Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 10-11 | convocatoria 1
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 313

[pág. 314]
Marketing - versión clara y reordenada
 Respuesta desarrollada para estudio (no oficial)
 1. Evaluación de la propuesta de alza. No estoy de acuerdo con que pueda subirse
 “tranquilamente” de $2.000 a $3.000. La mejor nota promedio simple de atributos no significa
 máxima preferencia ni mayor disposición a pagar: CAT tiene preferencia de 10%, inferior a
 Divertilandia (22%) y otros competidores. El promedio pondera igual entretención, educación y
 precio sin demostrar que los niños o padres les asignen ese mismo peso. Además, padres informan
 las preferencias de sus hijos, y la muestra mezcla 200 asistentes actuales con 200 personas en
 hogares: selección aleatoria dentro de cada subpoblación no hace que la combinación 50/50
 represente automáticamente al mercado de visitantes potenciales. La respuesta también puede
 estar influida por experiencia reciente y por preguntar hipotéticamente, sin gasto efectivo.
 El cuadro de intención reporta “sí” de 50% al precio actual y 36% a $3.000. Si esos porcentajes
 fueran demanda proporcional -supuesto fuerte-, la razón de ingreso sería
 3.000×0,36/(2.000×0,50)=1,08, solo 8% más, no una garantía de éxito. Hay una inconsistencia
 visible: en la fila $2.000, 22% definitivamente sí +33% probablemente sí suma 55%, pero el total
 impreso dice 50%. Con 55% como total, el mismo cálculo da 0,9818, es decir -1,82%. Por tanto,
 incluso esa conclusión de ingresos depende de un dato contradictorio que debe aclararse. No se
 mezclan certeza e intención probable sin calibración de conversión; tampoco se confunde ingreso
 con utilidad. Falta costo variable y efecto en misión/acceso y reputación.
 2. Evidencia econométrica. El modelo log-log entrega elasticidad precio de cantidad -2,2,
 elasticidad publicitaria 0,8 y respecto de IMACEC 0,1. El caso exige asumir buen ajuste y
 especificación; no rechazaría el modelo argumentando que precio nominal fue constante, pues se
 usan precios reales y el supuesto está dado. Manteniendo publicidad e IMACEC, subir precio 50%
 da Qnuevo/Qactual=(3.000/2.000)^(-2,2)≈0,4098: caída aproximada de 59,02% en entradas.
 Ingreso nuevo/actual=1,5×0,4098≈0,6147, una caída de 38,53%. La aproximación
 -2,2×50%=-110% no sirve para un cambio tan grande y produciría una cantidad imposible; se usa la
 razón exacta de potencias.
 No recomendaría el alza a $3.000 con esta información, porque la demanda es elástica y el
 pronóstico de ingresos se deteriora fuertemente. La intención declarada más optimista entra en
 conflicto con conducta modelada y tiene la inconsistencia del cuadro; merece aclaración y
 calibración, no ignorar la elasticidad. La utilidad podría reaccionar de forma distinta si costos
 variables fueran muy altos, pero no se proporcionan para afirmar que el alza maximiza excedente.
 Como museo sin fines de lucro, también importa acceso y misión. Evaluaría alzas menores o
 tarifas/beneficios por segmento en una prueba, verificando ingreso, contribución y asistencia. Eso
 constituye una recomendación condicionada; el cálculo histórico no demuestra un precio óptimo
 que el caso no permite identificar.
 agosto 2009 - pregunta 5 - Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 23-24 | convocatoria 2
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 314

[pág. 315]
Marketing - versión clara y reordenada
 Respuesta desarrollada para estudio (no oficial)
 1. Conclusión de los focus groups. No basta que 55% de las 240 ideas recomiende publicidad
 masiva para concluir que esa es la mejor intervención. Hay 120 participantes con dos sugerencias
 cada uno: no son 240 personas independientes. Los grupos son útiles para generar hipótesis y
 entender motivos, pero la respuesta oral frente a otros puede producir conformidad y deseabilidad
 social. La selección aleatoria inicial no convierte la frecuencia de ideas de una discusión en un
 porcentaje representativo de preferencias o de efecto de una campaña. Tampoco se demuestra que
 los participantes hayan identificado la causa de vacancia ni que más tráfico produzca arrendatarios
 rentables.
 Publicitar, fidelizar o realizar eventos son hipótesis de solución que se compararían según
 mecanismo, público, costos y beneficio incremental. La decisión requiere entender barreras y la
 relación tráfico-venta-ocupación, luego dimensionar o probar alternativas. La conclusión “publicidad
 es lo más mencionado, por tanto lo mejor” confunde popularidad de una idea con eficacia causal y
 rentabilidad.
 2.a. Composición de la muestra. Las cuotas por comuna -1.000, 500 y 500- guardan proporción
 con su población según el dato entregado, una ventaja para representar el conjunto de esas
 comunas. Pero no se describe selección dentro de cada comuna, cobertura de GSE o no respuesta.
 No se puede concluir que el diseño sea representativo de los cuatro GSE ni de todo Santiago por
 esos tres números, ni exigir que cada GSE tenga el mismo tamaño sin conocer su peso poblacional.
 La muestra grande reduce error aleatorio bajo un diseño adecuado; no corrige cobertura o
 selección. La inferencia debe limitarse a la población efectivamente cubierta y ponderarse según
 probabilidades, si están disponibles.
 2.b. Análisis estadístico. GSE tiene un orden, pero los códigos DE=1, C3=2, C2=3, ABC1=4 no
 prueban intervalos iguales entre niveles. Un Pearson de 0,76 depende de esa codificación y no
 entrega una comparación transparente de las medias de visita por categoría. Examinaría
 medias/distribuciones de visitas por GSE y sus intervalos, con ANOVA o un modelo adecuado de
 conteos, y eventualmente una asociación ordinal, considerando comuna, distancia y otros
 confundentes. La correlación agregada positiva no prueba que GSE cause visitas ni que todos
 ABC1/C2 respondan igual.
 Incluso si una asociación positiva fuera válida, frecuencia actual no equivale a retorno
 incremental de publicidad. El grupo de mayor visita puede estar ya saturado o comprar aunque no
 vea campaña; otro puede tener una barrera corregible y mayor respuesta marginal. Para dirigir el
 presupuesto se necesitan tamaño, accesibilidad, contribución y respuesta causal de cada
 segmento. La preferencia por ABC1/C2 es una hipótesis, no una decisión demostrada por una
 correlación con un código. Las dos críticas -composición y análisis- se plantean
 independientemente, como exige el enunciado.
 marzo 2010 - pregunta 5 - Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 39-40 | convocatoria 1
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 315

[pág. 316]
Marketing - versión clara y reordenada
 Respuesta desarrollada para estudio (no oficial)
 1. Directores A y B. La evidencia descriptiva respalda al director B: edad discrimina intensidad y
 la diferencia agregada por estado marital se explica en gran medida por composición. Entre 18-24,
 casados tienen 38% y solteros 39%; entre 25-29, 16% y 14%. En cambio, el total de casados es
 94/450=20,89% y el de solteros 177/550=32,18%. La agregación mezcla proporciones de edades
 diferentes: solo 100/450=22,22% de casados están en el grupo joven, frente a 400/550=72,73% de
 solteros. Comparar 21% con 32% sin controlar edad confunde asociación marital con esa mezcla.
 La intensidad por edad es (38+156)/(100+400)=38,8% en 18-24 y (56+21)/(350+150)=15,4% en
 25-29. La relación se mantiene para ambos estados maritales. Por ello, si se busca el grupo con
 mayor consumo observado, concentrarse en jóvenes 18-24 resulta más defendible que excluir
 casados jóvenes. No se debe afirmar que matrimonio causa el abandono a partir de estos datos ni
 que el estudio cualitativo probó su hipótesis; este generó una explicación que el cuantitativo no
 confirma de esa forma.
 La tabla tampoco ofrece un test que demuestre exactamente igualdad de casados/solteros dentro
 de cada edad, ni mide rentabilidad o respuesta publicitaria. La campaña final requeriría considerar
 alcance y contribución incremental. Descriptivamente, B identifica mejor la segmentación; esa
 conclusión no convierte edad en una causa experimental ni justifica extrapolar a mujeres, otras
 edades o fuera de Gran Santiago.
 2. Entrevistas profundas frente a grupo. El tema incluye uso intensivo de videojuegos y
 expectativas del rol de adulto/esposo; frente a otras personas, un participante puede dar una
 respuesta socialmente aceptable, ocultar conducta o adherir a una explicación del grupo. Una
 entrevista individual permite explorar experiencias y contradicciones con mayor privacidad y
 profundidad y reducir presión de pares. Esa es una razón principal por la que C puede tener razón.
 No prueba que toda sesión de grupo sea inválida ni que una entrevista elimine memoria o
 deseabilidad; requiere buena conducción y triangulación. La mejora cualitativa ayuda a construir
 hipótesis más precisas, y su contraste sigue siendo necesario.
 agosto 2010 - pregunta 5 - Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 54-55 | convocatoria 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 1. TOM no es elección. No concuerdo con el ejecutivo de C. C tiene TOM de 32,9% frente a 24,8%
 de D, diferencia de 8,1 puntos, pero D tiene mayor recordación espontánea acumulada (46,3%
 frente a 40,7%) y ayudada acumulada (67,8% frente a 45,6%). No se suman las tres columnas: el
 caso explica que cada nivel incluye a quienes recordaron antes. C puede estar primero en la mente
 de más personas, mientras D está en el repertorio conocido de más personas.
 Conocimiento es una condición que puede favorecer consideración, pero elegir una clínica también
 depende de calidad, conveniencia, necesidad, disponibilidad, cobertura y otras restricciones. Mayor
 TOM no demuestra mayor probabilidad de elegir, share o superioridad de valor. Además, el
 agregado oculta segmentos: C tiene 95% de recuerdo espontáneo en S1, mientras D tiene 87% en
 S2 y 48% en S4. No se puede descartar un rival porque pierde una medida promedio. El caso
 estipula que el procedimiento de muestreo es adecuado; no sustituiría la respuesta por objeciones a
Examen de Grado UC | materia, preguntas y respuestas 316

[pág. 317]
Marketing - versión clara y reordenada
 las dos comunas que contradigan ese supuesto.
 2. Estrategia para B. B se caracteriza por conveniencia alta y calidad promedio. El grupo más
 alineado a esa promesa es S2, 35% de la población: asigna 58% de importancia a conveniencia y
 42% a calidad, pero solo 2% recuerda B. Eso señala una oportunidad de aumentar conocimiento y
 asociación creíble con acceso, ubicación/precio y facilidad, mientras se aseguran niveles de calidad
 aceptables. D tiene 87% de recuerdo en ese grupo, de modo que la comunicación debe diferenciar
 beneficios concretos y no asumir que basta ser conocido para ganarle.
 S1, 24%, pondera 50/50 y recuerda B en 40%; podría ser un segundo frente si B demuestra calidad
 suficiente. S4, 30%, recuerda B en 80% pero asigna 81% a calidad y solo 19% a conveniencia.
 Tener gran conocimiento allí no asegura ajuste de la propuesta: insistir solo en conveniencia puede
 desperdiciar inversión y sería necesario mejorar o acreditar calidad si se elige ese segmento. S3,
 11%, prioriza calidad (77%) y casi no conoce B (1%); no lo escogería por el solo bajo recuerdo dado
 el producto actual.
 Recomendaría foco inicial en S2 con comunicación y acceso coherentes, mejoras de fricciones y
 una medición de consultas, reservas, uso y contribución incremental. Validaría diferencias de
 calidad percibida y barreras de elección: los porcentajes son de recuerdo, no de compra. No se
 inventa que B ya tiene la mayor participación, ni se elige S4 únicamente por ser el que más la
 conoce.
 agosto 2024 - pregunta 5 - Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 423-423 | convocatoria
 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 1. Complementariedad o sustitución entre medios. Los modelos son aditivos: la contribución
 marginal de TV es a2 o β2 y la de redes es a3 o β3, independientemente del gasto en el otro medio.
 No contienen una interacción TV×Redes ni otra estructura que permita estimar si el efecto de un
 medio aumenta o disminuye cuando crece el otro. Que ambos coeficientes sean positivos y
 significativos significa asociación positiva con el resultado, condicionada a las variables incluidas;
 no prueba complementariedad. Tampoco que los medios sirvan para el mismo objetivo prueba
 sustitución. Para estudiar el mecanismo habría que incluir y estimar la interacción, o comparar
 combinaciones de medios mediante un experimento factorial. En el modelo de ventas, una
 interacción positiva apoyaría complementariedad en el rango estimado; negativa, sustitución en el
 efecto marginal. Esa interpretación todavía exige identificación y una escala adecuada.
 2. Retorno financiero. El modelo 1 explica cuentas creadas, que son un resultado intermedio: una
 descarga no equivale a una venta ni a una contribución. El modelo 2 asocia cada millón invertido en
 TV con 0,25 miles de unidades adicionales y cada millón en redes con 0,40 miles, manteniendo lo
 demás constante. Bajo iguales condiciones, redes muestra mayor respuesta marginal de ventas:
 400 frente a 250 cilindros por millón. Sin embargo, no basta para afirmar que genera el mayor
 retorno financiero neto. Faltan margen por cilindro, efecto causal, costos asociados, persistencia,
 saturación y horizonte. Si el margen incremental por unidad fuera común y los efectos fueran
 causales y contemporáneos, el modelo permitiría comparar contribución incremental por peso; ese
 es un supuesto adicional, no un dato entregado. El R² ajustado alto y la significancia no resuelven
Examen de Grado UC | materia, preguntas y respuestas 317

[pág. 318]
Marketing - versión clara y reordenada
 causalidad ni rentabilidad. Además, la muestra corresponde a 52 semanas en la Región
 Metropolitana; extrapolar a otros periodos, regiones o montos mayores exige validación.
 3. Publicidad equivalente a bajar el precio. La inversión simultánea es TV=10 y Redes=5,
 medidas en millones de pesos. El aumento pronosticado por el modelo 2 es
 ΔVentas=0,25×10+0,40×5=4,50 miles de unidades. Para obtener ese mismo aumento mediante
 precio, se resuelve -0,16×ΔPrecio=4,50: ΔPrecio=-28,125 unidades de la variable de precio. No se
 utiliza el modelo de descargas para esta equivalencia.
 Advertencia necesaria sobre una inconsistencia del propio enunciado. La descripción inicial
 dice que Precio está en miles de pesos, pero la nota final dice que está en pesos. Ambas
 expresiones se ven en la página original; no es una corrección que deba adivinarse. Si se aplica
 literalmente la nota final, la reducción equivalente es 28,125 pesos -aproximadamente $28- y el
 precio pasa de $30.000 a $29.971,875. Si se aplica la unidad de la descripción inicial, la reducción
 es 28,125 miles de pesos = $28.125, y el precio queda en $1.875. La segunda reducción es
 enorme y extrapola muy lejos de un precio de $30.000: no constituye una recomendación comercial
 realista aunque sea el resultado algebraico del modelo lineal. En el examen debe declararse qué
 unidad se usa; sin aclaración oficial o pauta validada, no corresponde presentar una de estas
 interpretaciones como inequívoca.
 La equivalencia es de volumen previsto, no de beneficio: una rebaja reduce el margen de las
 unidades que ya se vendían, mientras que la publicidad tiene un costo fijo de $15 millones. Para
 recomendar una opción financiera habría que comparar contribuciones y costos completos, además
 de revisar la validez del modelo en ese rango.
 agosto 2025 - pregunta 5 - Investigación/datos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 447-448 | convocatoria
 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 1. Dos ventajas y dos desventajas. Ventajas: (i) costo y tiempo de generar evaluaciones bajo un
 protocolo pueden ser menores que reclutar/encuestar personas, facilitando exploración inicial de
 atributos y marcas; (ii) se pueden repetir preguntas, escenarios y análisis con trazabilidad de
 versiones/prompts y ampliar hipótesis con rapidez. Eso sirve para diseñar investigación, no prueba
 equivalencia con clientes. Desventajas: (i) pedir que una IA “actúe como un joven de altos ingresos”
 no la vuelve una muestra de ese segmento; refleja información y sesgos de entrenamiento, puede
 omitir experiencia reciente y repetir estereotipos; (ii) resultados dependen de prompt, versión y
 contexto, con incertidumbre distinta de la muestral, y pueden inventar o alisar asociaciones. Muchos
 outputs del mismo modelo no equivalen a muchas observaciones humanas independientes. La
 metodología tradicional también tiene sesgos de muestreo/recuerdo, pero puede observar
 directamente al público definido y estimar incertidumbre bajo su diseño.
 2. Similitudes y diferencias reales del caso. Ambos F1 se interpretan en sentido parecido:
 deportivo carga negativo (-0,90 IA; -0,84 encuesta), mientras eficiencia (+0,60/+0,59) y eco-friendly
 (+0,70/+0,64) cargan positivo. F2 se relaciona con durabilidad, pero la carga es 0,89 en IA y 0,55
 en encuesta. Los mapas comparten algunos extremos -Ferrari/Porsche y otras deportivas hacia la
 izquierda, Tesla/Renault/Hyundai hacia la derecha, Jeep/Subaru altos en F2-, de modo que hay
Examen de Grado UC | materia, preguntas y respuestas 318

[pág. 319]
Marketing - versión clara y reordenada
 similitud parcial de orden y asociaciones. Sin embargo, no afirmaría equivalencia de percepciones.
 Los primeros dos factores explican 57% en IA (41+16) y 82% en encuesta (70+12). La proyección
 de IA deja 43% sin representar frente a 18% en la de consumidores. La varianza está más
 distribuida en otras dimensiones en IA; el F4 original es 12%, no 1% como pierde el OCR. Las
 escalas de los ejes también difieren: no se compara distancia absoluta entre mapas como si fuera la
 misma unidad. Hay relaciones que cambian -por ejemplo Ford/Nissan respecto de F2 y
 Honda/Toyota-; se necesitaría alinear soluciones y contrastar estabilidad/posición, no mirar solo
 que algunos nombres estén a la derecha.
 Mayor varianza explicada por dos factores no demuestra que un método “mida mejor” la verdad,
 pues resume sus propios datos. La encuesta es la referencia directa del segmento de 402 personas
 bajo la representatividad estipulada, y la IA debe validarse contra ella y conducta. La similitud
 parcial puede hacerla útil para explorar, pero no justifica reemplazar toda encuesta ni extrapolar a
 otros segmentos.
 3. Toyota y tres acciones. En Figura 2, Toyota está a la derecha del origen en F1, dimensión
 asociada positivamente a eficiencia y eco-friendly, por lo que esa parte del posicionamiento es
 coherente/creíble como dirección relativa. Pero no es la marca más extrema: Tesla y otras
 marcas aparecen más a la derecha. El gráfico no prueba que consumidores la vean como líder
 absoluta en ambos atributos ni mide preferencia o desempeño técnico. Estar cerca de un atributo
 no verifica superioridad causal o un claim publicitario.
 Primera acción: sostener la promesa en producto y experiencia comprobables, con mejoras y
 evidencia de consumo/emisiones para los modelos relevantes, evitando generalizar una prueba a
 todo el portafolio. Segunda: usar comunicación consistente y verificable que explique beneficio y
 razones para creer, comparando métricas pertinentes y transparentes cuando proceda; adaptar el
 mensaje al segmento sin prometer liderazgo que el estudio no acredita. Tercera: reforzar puntos de
 contacto y prueba, con información y demostraciones de uso en concesionarios/canal digital y una
 experiencia coherente, y medir si cambian asociación, consideración y elección. Son tres acciones
 concretas que conectan oferta, mensaje y experiencia.
 Validaría el posicionamiento con un nuevo estudio comparable y resultados de compra,
 distinguiendo cambio perceptual de share y retorno de campaña. Ningún mapa por sí solo permite
 fijar presupuesto óptimo o afirmar que una comunicación causará liderazgo. La respuesta usa
 porcentajes, cargas y la posición visual de Toyota, en lugar de una advertencia genérica sobre IA
 sin contestar los incisos.
 enero 2024 - pregunta 5 - K-means y promociones
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 411-411 | convocatoria
 1
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 319

[pág. 320]
Marketing - versión clara y reordenada
 Respuesta desarrollada para estudio (no oficial)
 1. Elección de segmento. Si el objetivo es captar volumen de categoría en el corto plazo mediante
 promociones, elegiría segmento 1, que tiene 75% de clientes y mayor efecto contemporáneo de
 promoción (0,4 frente a 0,3). En un modelo semilogarítmico, una promoción se asocia con
 exp(0,4)-1=49,18% más ventas en S1 y exp(0,3)-1=34,99% en S2, manteniendo las otras variables.
 El mayor tamaño y respuesta respaldan esa prioridad bajo ese objetivo. No prueba por sí solo
 mayor rentabilidad ni que la venta adicional sea de las nuevas galletas: la variable dependiente es
 toda la categoría.
 S1 también tiene mayor sensibilidad al precio regular (elasticidad -0,8 frente a -0,3) y una caída
 posterior mayor: exp(-0,2)-1=-18,13%, frente a exp(-0,05)-1=-4,88%. S2, aunque menor, ofrece una
 respuesta más persistente y reúne compradores experimentados en productos sin gluten/lactosa. Si
 el objetivo fuera margen sostenible o consolidación de la nueva línea, compararía esos costos y la
 postpromoción antes de concluir. El punto de una elección defendible es declarar el objetivo y
 reconocer el trade-off, no llamar “mejor” a un segmento para todas las decisiones.
 2. Segmentación. K-medias con datos demográficos e historial en otras categorías facilita perfiles
 observables y usa conducta efectiva para aproximar experiencia con el tipo de producto. También
 puede revelar consumidores que una tabla agregada oculta. Sus límites son imponer una
 geometría/grupos que dependen de escalas, variables, outliers y k; edad o compra en otra
 categoría no demuestra el motivo de compra ni una respuesta homogénea en galletas. Hay que
 tratar variables categóricas adecuadamente y comprobar estabilidad y utilidad.
 Incluiría, si están disponibles y son pertinentes, frecuencia y monto de compra de productos sin
 esos ingredientes, proporción de gasto que representan, categorías efectivamente compradas,
 sensibilidad a precio/promoción, necesidades dietarias declaradas y verificadas con cuidado,
 beneficios buscados, sabor, ocasión y canal. No asumiría que todo joven compra por salud o toda
 persona mayor desconoce los productos. Para evitar circularidad, no usaría la futura respuesta a la
 promoción que luego se desea evaluar como si fuera una variable conocida para segmentar antes
 de la campaña. Perfiles de necesidad y conducta deben poder localizarse y atenderse en la
 práctica.
 3. Impacto observado y promociones más frecuentes. Una promoción aislada produce un alza
 contemporánea y una caída al periodo siguiente. El signo negativo del rezago es compatible con
 acopio/adelanto de compra, pero no demuestra ese mecanismo sin inventarios y conducta
 individual. Con igual base de ventas en ambas semanas y manteniendo precio, el cambio
 acumulado en unidades durante dos semanas es [(exp(0,4)-1)+(exp(-0,2)-1)]×base≈0,31056×base
 en S1 y 0,30109×base en S2. Sumar los coeficientes da 0,20 y 0,25 en logaritmos, pero no es el
 mismo cálculo que sumar unidades de dos semanas. Si promoción actual y pasada están ambas
 activas en una misma semana, el efecto condicionado es exp(α2+α3)-1: 22,14% y 28,40%,
 respectivamente. Debe distinguirse ese escenario de una promoción aislada.
 Con promociones frecuentes, cabe esperar que los consumidores aprendan a esperar descuentos y
 cambien sus precios de referencia. Bajo ese mecanismo, el efecto contemporáneo α2 podría
 disminuir por menor sorpresa, α3 podría hacerse más negativo por mayor traslado de compras y la
 respuesta al precio regular α1 podría hacerse más negativa por mayor sensibilidad. Son hipótesis
 económicas, no consecuencias matemáticas inevitables: promociones muy próximas pueden
 acumular efectos, cambiar competencia o confundir rezagos y debilitar identificación. La dirección y
Examen de Grado UC | materia, preguntas y respuestas 320

[pág. 321]
Marketing - versión clara y reordenada
 magnitud deben estimarse y validarse con nuevos datos. Los coeficientes actuales no garantizan
 que duplicar frecuencia duplique ventas; tampoco dan el margen de un 2×1. Para decidir, mediría
 contribución incremental, canibalización, acopio, recompra y persistencia, con un control que
 separe promoción de variaciones de demanda.
 enero 2026 - pregunta 6 - Logit multinomial y rentabilidad de promoción
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 461-462 | convocatoria
 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 Planteamiento. Cada visita genera una de tres elecciones: marca propia PL, Fitness FN o no
 compra. La opción de no compra tiene utilidad cero y debe incluirse en el denominador. Una
 campaña de FN cambia únicamente su utilidad sistemática en +0,30; los precios y las otras
 actividades permanecen iguales. Para evitar inconsistencias de redondeo, primero uso las
 probabilidades base explícitamente entregadas: P0=0,678; PPL=0,264; PFN=0,058. Luego muestro
 la pequeña diferencia al recalcular desde coeficientes.
 1.a. Probabilidades con campaña. En logit, aumentar la utilidad de FN en 0,30 multiplica su peso
 por exp(0,30)=1,3498588. No aumenta su probabilidad en 30 puntos porcentuales. El nuevo factor
 de normalización es D=P0+PPL+PFN×exp(0,30)=1,02029181. Así:
 Elección Base Con campaña Cambio
 No compra 0,678000 0,664516 -0,013484
 Marca propia PL 0,264000 0,258750 -0,005250
 Fitness FN 0,058000 0,076735 +0,018735
 Total 1 1 0
 La suma es uno. FN gana aproximadamente 18.735 unidades por millón de visitas; una parte
 proviene de atraer visitas que no compraban cereal y otra de sustituir PL. Se supone una unidad por
 elección, conforme al enunciado.
 1.b y 1.c. Beneficio de Nestlé. Contribución
 incremental=1.000.000×(0,076734724-0,058)×US$1=US$18.734,72. Beneficio neto
 incremental=18.734,72-14.000=US$4.734,72. Bajo la regla solicitada, Nestlé debiera invertir porque
 el beneficio neto es positivo. El punto de equilibrio es un aumento de 0,014 en la probabilidad de
 compra de FN; la simulación entrega 0,018735. Esto muestra el margen de seguridad, pero no
 elimina incertidumbre de estimación ni problemas de causalidad.
 2.a. Dos fuentes del cambio para el retailer. La campaña puede aumentar su margen de
 categoría porque convierte no compradores en compradores de FN, que deja US$0,30 por unidad.
 A la vez, puede reducirlo porque algunas ventas se trasladan desde PL, que deja US$0,80, hacia
 FN. Estos mecanismos operan en sentidos opuestos; sin cuantificar ambos no se puede asegurar el
 signo por el solo hecho de que FN venda más. Con los parámetros del caso cabe anticipar un
 aumento pequeño: existe mucha más masa inicial de no compradores que de PL y, en logit, los
 desvíos desde las alternativas no promovidas son proporcionales a sus participaciones iniciales.
Examen de Grado UC | materia, preguntas y respuestas 321

[pág. 322]
Marketing - versión clara y reordenada
 2.b. Márgenes y negocio publicitario. En base, margen de
 venta=1.000.000×(0,264×0,80+0,058×0,30)=US$228.600. Con campaña, margen de
 venta=1.000.000×(0,258749504×0,80+0,076734724×0,30)=US$230.020,02. El cambio de margen
 de ventas es +US$1.420,02. Puede comprobarse separando la ganancia en FN, US$5.620,42, de la
 pérdida en PL, US$4.200,40. El beneficio neto del retailer por implementar y vender la activación es
 cambio de margen de ventas + precio recibido de Nestlé - costo de implementación:
 1.420,02+14.000-3.000=US$12.420,02. Si “beneficio del paquete publicitario” se usa para referirse
 solo a la operación de publicidad, es US$11.000; la contribución total solicitada, incorporando
 ventas de categoría, es US$12.420,02. No se debe contar dos veces el cobro de US$14.000 ni
 tratarlo como costo del retailer.
 Comprobación de redondeo. Desde los coeficientes, VPL=0,35-0,76×1,70=-0,942 y
 VFN=-0,60-0,76×2,45=-2,462. Las probabilidades exactas base son aproximadamente 0,677915;
 0,264283; 0,057802. Con campaña son 0,664477; 0,259045; 0,076478. Aplicando esta convención
 consistentemente, el beneficio de Nestlé es US$4.675,93: difiere por usar probabilidades base
 redondeadas en el primer cálculo, pero la decisión no cambia. Se debe indicar la convención y no
 mezclar un escenario exacto con otro redondeado.
 Alcance de la recomendación. El ejercicio pide una simulación manteniendo todo lo demás
 constante. Un coeficiente de RMN estadísticamente significativo no demuestra por sí solo que la
 campaña cause ese incremento: la publicidad puede coincidir con promociones, cambios de surtido
 o demanda. En una aplicación real se comprobarían exposición, heterogeneidad, estabilidad,
 costos y ventas incrementales mediante un diseño con control. Eso complementa el cálculo pedido;
 no lo reemplaza por una discusión general sobre publicidad.
 enero 2020 - pregunta 5 - Logit y heterogeneidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 311-312 | convocatoria
 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 a. Heterogeneidad. En un modelo de utilidad aleatoria, consumidores con los mismos atributos
 observados no eligen necesariamente lo mismo porque la utilidad incluye un componente no
 observado. Con coeficientes comunes y errores independientes de valor extremo, esto produce
 probabilidades logit. Es una representación probabilística de heterogeneidad no observada, pero no
 un modelo completo de diferencias persistentes de gustos: no entrega una sensibilidad al precio
 distinta para cada consumidor ni correlación arbitraria entre alternativas. Para esas diferencias
 harían falta interacciones con características, segmentos, clases latentes o coeficientes aleatorios,
 y datos que permitan estimarlos. También debe distinguirse variación en atributos de la oferta
 -precio y distancia- de variación en preferencias de las personas.
 b. “Variable más importante”. No es correcto elegir el mayor coeficiente en valor absoluto porque
 precio se mide en miles de pesos, distancia en kilómetros y las marcas son variables indicadoras.
 Un cambio de unidad cambiaría el coeficiente de precio sin cambiar las preferencias. Tampoco el
 mayor estadístico z mide mayor importancia comercial: mide evidencia contra coeficiente cero en
 relación con su error estándar. Con la tabla se puede concluir que los efectos mostrados son
 significativos aproximadamente al 5%, que mayor precio y distancia reducen utilidad, y que B e
Examen de Grado UC | materia, preguntas y respuestas 322

[pág. 323]
Marketing - versión clara y reordenada
 independiente tienen mayor constante que A mientras C tiene menor constante. No se puede
 establecer una importancia universal sin definir rangos de cambio o una métrica comparable.
 Una comparación útil es el trade-off: βdistancia/βprecio=(-1)/(-0,20)=5 miles de pesos por kilómetro.
 Bajo el modelo 2, acercar una farmacia un kilómetro equivale a mejorar precio en $5.000. Las
 constantes se reducen al agregar precio y distancia: parte de las diferencias del modelo 1 estaba
 asociada a esos atributos omitidos. Eso no demuestra un mecanismo causal, pero advierte que la
 preferencia aparente por marca depende de la especificación.
 c. Condiciones cuantitativas de competitividad. Trabajo con modelo 2, porque incluye los
 precios y distancias necesarios. Sea dI la distancia a la farmacia independiente y dA, dB, dC las
 distancias a cada cadena. Precio de cadena=10 miles de pesos y de independiente=5. Las
 utilidades sistemáticas son VI=1,50-0,20×5-dI=0,50-dI; VA=-0,20×10-dA=-2-dA;
 VB=0,50-2-dB=-1,50-dB; VC=-0,50-2-dC=-2,50-dC.
 Para que una cadena tenga al menos la misma utilidad -y, en el mismo conjunto de elección, al
 menos la misma probabilidad- que la independiente:
 Cadena Condición Interpretación
 A dI-dA ≥ 2,5 km Debe estar al menos 2,5 km más
 cerca
 B dI-dB ≥ 2,0 km Debe estar al menos 2 km más cerca
 C dI-dC ≥ 3,0 km Debe estar al menos 3 km más cerca
 En igualdad de distancias, ninguna iguala la utilidad de la independiente con estos precios. La
 ventaja requerida incorpora el diferencial de precio ($5.000) y la constante de marca. Por ejemplo,
 para A el precio resta una unidad adicional de utilidad y la constante independiente añade 1,5: debe
 compensar 2,5 unidades con cercanía. Competitiva aquí significa utilidad relativa comparable; no
 implica una venta segura, pues logit mantiene incertidumbre. Estas condiciones tampoco autorizan
 inferir participaciones totales sin las distancias y el conjunto de alternativas.
 enero 2018 - pregunta 5 - Mapa perceptual
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 262-263 | convocatoria
 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 1. Servicio al cliente fuera de los factores. No significa que al consumidor no le importe. El
 análisis factorial describe covariación y dimensiones de percepciones, no cuánto pesa cada atributo
 en elección. Un atributo puede variar poco entre canales, relacionarse con otras dimensiones no
 retenidas, estar medido deficientemente o tener información propia que los dos factores no
 capturan. Los dos factores conservan 75% de la varianza, no toda. Para evaluar importancia de
 servicio habría que medir preferencia/elección y su relación con servicio, no inferirla de una carga
 pequeña en el mapa. “No aparece significativo” en una proyección no equivale a valor comercial
 cero.
 2. Mayoristas con share positivo aunque no sean el máximo en los vectores. El mapa es una
 representación parcial y agregada; los vectores muestran direcciones de preferencia de algunos
Examen de Grado UC | materia, preguntas y respuestas 323

[pág. 324]
Marketing - versión clara y reordenada
 segmentos, no todas las decisiones de cada persona en todas las ocasiones. Un comprador puede
 elegir una opción que no maximiza su preferencia declarada por disponibilidad, precio efectivo,
 ubicación, tamaño de compra u ocasión. Además, hay heterogeneidad dentro de segmentos,
 factores omitidos y variación no observada. Un modelo probabilístico, a diferencia de uno
 determinístico de “todo al más preferido”, permite participaciones positivas de alternativas de menor
 utilidad. La participación también pondera tamaños de segmentos que no son iguales. Por tanto, 5%
 de share mayorista no contradice que no aparezca como preferido por los vectores graficados.
 3.a. Efecto en el mapa. La campaña enfatiza importancia de variedad y confianza, atributos en
 que el hipermercado puede apoyar su posición. Puede cambiar los pesos o dirección de los
 vectores de preferencia hacia esos atributos, haciendo más valorada una percepción ya existente.
 Eso es distinto de mover necesariamente el punto del hipermercado: para cambiar posición
 perceptual tendría que cambiar cómo lo evalúan, y una campaña puede o no lograrlo. El gráfico
 muestra hipermercado en dirección de variedad; confianza apunta al lado derecho. Una respuesta
 debe distinguir comunicación que revaloriza un atributo de una que cambia su asociación a la
 tienda. No se presume que todos los vectores giren igual ni que la campaña garantice ese cambio.
 3.b. Efecto en beneficio. En B=(Precio-Costo)×MercadoTotal×PM-GastoMarketing, la campaña
 aumenta GastoMarketing y pretende elevar o defender PM al modificar preferencia. Con precio,
 costo y tamaño de mercado constantes, conviene si el margen unitario×MercadoTotal×ΔPM supera
 ΔGastoMarketing. Se podría expresar el umbral como
 ΔPM>ΔGastoMarketing/[(Precio-Costo)×MercadoTotal], con unidades consistentes. Si el mercado
 total, precio o costo cambian, se recalcula la diferencia completa de beneficio; no se mantienen
 constantes en silencio.
 Ganar participación no es sinónimo de mayor utilidad y defenderla puede ser valioso frente a un
 contrafactual de pérdida. La publicidad no prueba que aumente el consumo total de productos ni
 que pueda sostener un precio mayor: esas son posibilidades que requieren evidencia. Se medirían
 cambio de percepciones, pesos, visitas y contribución incremental con un control, separando éxito
 comunicacional de éxito económico.
 enero 2022 - pregunta 5 - Mapa perceptual dinámico
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 361-361 | convocatoria
 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 a. Diferencia de metodología. La figura representa precio y un rating calculado desde atributos
 físicos, con tamaño de etiqueta proporcional a participación. Es un mapa de características
 observables; no es automáticamente un mapa de percepciones de consumidores. Un mapa
 perceptual clásico obtiene evaluaciones, asociaciones o semejanzas de personas del segmento y
 resume esas respuestas -por ejemplo mediante factores o escalamiento multidimensional-. Las
 dimensiones se interpretan a partir de esas percepciones. Aquí se han elegido precio y rating de
 antemano y el rating depende de cómo la plataforma pondera seguridad, consumo, frenos, espacio
 y potencia.
 Las ventajas del método presentado son rapidez, actualización y comparabilidad de una misma
 regla de medición; no requiere una nueva encuesta para cada cambio de precio y puede integrar
Examen de Grado UC | materia, preguntas y respuestas 324

[pág. 325]
Marketing - versión clara y reordenada
 indicadores técnicos y participación observable. Permite reconocer relaciones entre oferta y precio y
 formular hipótesis. Sus desventajas son no medir directamente la imagen de marca ni la
 importancia que cada segmento asigna a los atributos; una ponderación técnica puede diferir de la
 evaluación de un comprador. Agregar toda una marca omitiendo modelos también oculta
 heterogeneidad de producto y compradores. La calidad del dato, cobertura y actualización de la
 plataforma deben revisarse; “muchos datos” no equivale a validez del constructo. El tamaño de
 texto aproxima share, pero no convierte rating en preferencia ni establece causalidad.
 Un estudio perceptual cuesta más, tarda y depende de muestreo, cuestionario y memoria, pero
 puede capturar prestigio, identidad, confianza, estilo y otras asociaciones que no están en las fichas
 técnicas. Complementaría ambas fuentes, en lugar de proclamar que la metodología nueva
 sustituye toda investigación del consumidor.
 b. Por qué Mercedes-Benz o BMW pueden vender más con menor rating o mayor precio. Los
 consumidores eligen según valor percibido total, no exclusivamente por el rating definido por
 Statista. La marca puede aportar prestigio, identidad, confianza, diseño, experiencia, servicio, red
 de concesionarios, valor de reventa o coherencia con una ocasión de uso. La importancia de cada
 beneficio depende del segmento; un comprador puede preferir estatus o deportividad a los atributos
 técnicos ponderados en el rating. Además, disponibilidad, financiamiento, portafolio de modelos y
 base instalada afectan ventas. Estas son explicaciones plausibles que deben contrastarse, no
 hechos demostrados sobre cada comprador por el gráfico.
 Que una marca tenga mayor share no prueba que sus características técnicas sean objetivamente
 mejores; y que otra tenga mejor rating y menor precio no demuestra que deba dominar la elección.
 Para evaluar la aparente contradicción investigaría percepciones y pesos de atributos por
 segmento, costos totales, disponibilidad y elecciones, y comprobaría si precio/rating se miden de
 forma comparable entre modelos. La figura describe la posición bajo dos medidas seleccionadas;
 no identifica por sí sola demanda, brand equity o causas del share.
 enero 2017 - pregunta 5 - Modelo Assessor/pretest
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 234-235 | convocatoria
 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 a. Pretest frente a test de mercado. El pretest permite evaluar una oferta antes de un lanzamiento
 amplio, más rápido y con menor costo y exposición competitiva; ayuda a decidir concepto,
 comunicación y condiciones de lanzamiento sin entregar de inmediato todo el plan a rivales. El test
 de mercado implica venta en condiciones reales y aporta evidencia conductual y operacional, pero
 demora, cuesta y puede alertar a competidores, además de depender de qué mercados piloto se
 elijan. Assessor es pertinente cuando se busca un pronóstico previo de prueba/preferencia de una
 nueva marca, aunque exige ajustes de conocimiento, disponibilidad y calibración; no reemplaza sin
 límites una venta real.
 b. Prueba y participación. La prueba de laboratorio es 20% entre personas que conocieron el
 producto. La campaña prevé 75% de conocimiento y la cobertura excluye farmacias, que
 representan 30% del volumen, de modo que se usa 70% de disponibilidad como aproximación del
 ejercicio. Bajo esa convención multiplicativa, la proporción del mercado objetivo que probaría es
Examen de Grado UC | materia, preguntas y respuestas 325

[pág. 326]
Marketing - versión clara y reordenada
 0,20×0,75×0,70=0,105 = 10,5%.
 El modelo de preferencias obtiene 12% para la nueva marca después de conocerla y probarla, con
 los precios supuestos similares. Ajustando conocimiento y distribución, el share previsto es
 0,12×0,75×0,70=0,063 = 6,3%. No se multiplica nuevamente por 20%: todos recibieron el producto
 para la fase de seguimiento y el 12% es la participación de preferencias de esa fase, no una tasa de
 repetición condicionada únicamente a los que compraron voluntariamente en laboratorio. Mezclar
 ambos modelos produciría 1,26% sin justificación.
 Los factores son aproximaciones del lanzamiento y pueden estar relacionados: comprar en
 farmacias no implica que una persona nunca compre en supermercados. El cálculo sigue los
 supuestos simplificados del caso; un pronóstico real usaría disponibilidad ponderada, exposición y
 comportamiento por canal. El resultado no es una garantía de ventas ni permite concluir que la
 marca alcanzará exactamente ese share a cualquier precio.
 c. Cambio de lanzamiento. Propondría incluir farmacias, si su economía permite el acuerdo, para
 aumentar disponibilidad de 70% a 100% bajo el ejercicio. Con conocimiento mantenido en 75%, la
 prueba prevista sube a 0,20×0,75=15% y el share a 0,12×0,75=9%: mejora de 2,7 puntos de share
 respecto a 6,3%. Es una palanca mayor que llevar solo conocimiento de 75% a 100% manteniendo
 distribución en 70%, que daría 8,4% de share. Si se lograran ambos al 100%, el límite del
 pronóstico de preferencias sería 12% con los parámetros actuales.
 Expandir canal tiene costos y puede afectar margen; “exitoso” requiere compararlos con el beneficio
 incremental, no solo ganar share. También hay una señal de propuesta: Sensodyne permanece en
 4% y otras en 16%, mientras la nueva marca toma preferencias de Pepsodent/Colgate/Aquafresh.
 Un relato de reparación avanzada no permite asumir de qué marca vendrán ventas reales sin
 validar elección y desempeño. La recomendación explicita qué variable del modelo cambia y
 recalcula el pronóstico.
 agosto 2022 - pregunta 5 - Modelo de elección de marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 372-373 | convocatoria
 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 a. Información de los modelos. El modelo 1 estima diferencias de utilidad asociadas a marcas en
 las ofertas observadas, tomando San Francisco como base. Savory tiene constante 0,84 y Bresler
 0,73: ambas son positivas y estadísticamente distintas de cero según los estadísticos reportados.
 Sus odds relativos a San Francisco son exp(0,84)≈2,32 y exp(0,73)≈2,08 en ese modelo. Eso no
 demuestra que la marca sola cause esas diferencias: precio y acciones omitidas pueden formar
 parte de la asociación.
 El modelo 2 incorpora precio, display y flyer. Precio tiene efecto -1,25 por cada mil pesos; display
 añade 0,88 y flyer 0,19 a la utilidad. Savory conserva ventaja de 0,83, mientras Bresler baja a 0,44.
 El estadístico de display es 1,9 y el de Bresler 1,8: con una prueba bilateral aproximada al 5%, no
 superan 1,96. Por tanto, no hay que afirmar que todas las estimaciones son significativas al 5%.
 Flyer y precio muestran evidencia más clara contra efecto cero. El pseudo R² de 68% no equivale a
 “68% de ventas explicado” como en regresión lineal.
Examen de Grado UC | materia, preguntas y respuestas 326

[pág. 327]
Marketing - versión clara y reordenada
 Se pueden simular participaciones de las tres marcas bajo cambios de precio o actividad,
 manteniendo lo demás constante; estimar trade-offs y, con costos y margen, evaluar contribución.
 Para probabilidades hay que formar utilidades de cada alternativa y normalizarlas: Pj=exp(Vj)/suma
 exp(Vk). No se convierte directamente un coeficiente en puntos de participación.
 b. Precio frente a display. La rebaja de $1.000 aumenta utilidad de San Francisco en 1,25. Activar
 display la aumenta en 0,88. Manteniendo todas las otras condiciones y mirando solo la participación
 prevista, la rebaja genera el mayor incremento: multiplica los odds por exp(1,25)≈3,49, frente a
 exp(0,88)≈2,41 con display. Además, display tiene mayor incertidumbre y no es significativo al 5%
 bilateral con los datos de la tabla. En equivalencia de utilidad, display corresponde a una rebaja de
 0,88/1,25=0,704 miles de pesos, es decir $704.
 Recomendaría la rebaja si el objetivo solicitado es maximizar share previsto y no se impone un
 costo distinto. Para recomendar rentabilidad, la conclusión necesita margen y costo del espacio:
 bajar precio reduce contribución en todas las unidades vendidas, incluso las que se comprarían sin
 rebaja, mientras display puede tener un costo fijo. La decisión financiera puede invertir el orden; no
 debe confundirse el mayor efecto de preferencia con el mayor beneficio. Sin precio base ni share
 inicial del escenario no hay un aumento exacto de puntos porcentuales que pueda calcularse.
 c. Críticas de datos y metodología. El panel de 400 consumidores registra cassatas compradas
 en supermercados: la inferencia no cubre necesariamente helados individuales, canales
 tradicionales o personas que no compran cassata. Son compras repetidas de los mismos
 consumidores; debe considerarse correlación dentro de persona y heterogeneidad de gustos. La
 muestra y su permanencia deben ser representativas y el periodo anual debe capturar
 estacionalidad.
 Precio, display y flyer pueden responder a demanda esperada y aplicarse juntos, produciendo
 endogeneidad y colinealidad. Faltan atributos como sabor, tamaño comparable, distribución,
 disponibilidad o quiebres; una marca ausente no debería incluirse como opción disponible. El
 modelo supone solo tres marcas y no compra está ausente: predice elección condicionada entre las
 tres, no necesariamente expansión de toda la categoría. IIA y coeficientes comunes pueden ser
 restrictivos. Validaría fuera de muestra y, para decisiones causales, mediante variación
 experimental o una identificación defendible. Estas críticas precisan el uso del modelo; no eliminan
 su utilidad para simular bajo supuestos explícitos.
 enero 2015 - pregunta 5 - Mystery shopper y diseño exploratorio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 168-169 | convocatoria
 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 1. Beneficios. RevNext acompaña a clientes reales en el recorrido y recoge emociones,
 motivaciones, fotografías, fricciones y razones de compra en el momento, en vez de depender solo
 de recuerdos al terminar. Puede revelar por qué una exhibición confunde, qué ocasión busca
 resolver un cliente, cómo una cola afecta su experiencia y qué interacciones cambian su cesta. La
 repetición de visitas durante dos semanas permite comparar situaciones para cada participante. Es
 pertinente para entender cómo mejorar la experiencia de clientes locales, cuyo aumento y
 recurrencia, y no el turismo por sí solo, constituyen el desafío económico descrito.
Examen de Grado UC | materia, preguntas y respuestas 327

[pág. 328]
Marketing - versión clara y reordenada
 Limitaciones de implementación. Veinte clientes con smartphone, reclutados desde la base
 actual y recompensados con una canasta, no representan automáticamente a todos los clientes
 locales ni a potenciales no clientes. Cubrir edades/ciclos de vida mejora diversidad cualitativa, pero
 no vuelve probabilística la muestra. Planificar visitas y recibir mensajes del investigador puede
 modificar recorrido, atención y compra; escribir/filmar en el teléfono puede interrumpir la
 experiencia. Hay carga de registro y posibles problemas de interpretación, conectividad y
 privacidad. Debe distinguirse reacción espontánea de respuesta inducida por una pregunta.
 Limitaciones de conclusión. El estudio explora mecanismos y puntos de fricción, pero no estima
 con precisión poblacional cuántos clientes viven cada experiencia, ni demuestra que corregirla
 aumentará rentabilidad. Intención de volver o recomendar no es conducta futura. Satisfacción ya es
 alta en el caso y no garantiza cesta rentable: hacen falta costos, mix y transacciones para vincular
 mejoras con margen. Usaría hallazgos para priorizar cambios y luego comprobar compra, repetición
 y contribución en condiciones comparables.
 2. Cliente incógnito. Discrepo con que 300 informes objetivos sustituyan la experiencia de clientes
 reales y garanticen mejoras de rotación/rentabilidad. Un investigador entrenado puede auditar
 disponibilidad, tiempos, precios, señalización y cumplimiento de atención con protocolos
 consistentes. Eso es útil para detectar fallas del servicio. Pero reporta condiciones y conducta de
 empleados ante una situación preparada; no capta necesariamente motivos, emociones,
 necesidades ni elecciones de los locales. Que una cajera sonría o una cola dure menos no
 demuestra cuánto valoró eso un cliente o por qué compró un surtido no rentable.
 Trescientos reportes aumentan observaciones del protocolo, pero una medida del constructo
 equivocado sigue siendo insuficiente. Con igual costo y el objetivo de entender experiencia y
 propuesta para clientes locales, prefiero RevNext como exploración, conservando sus límites.
 Cliente incógnito puede complementarlo después para controlar estándares, y ninguno por sí solo
 permite afirmar un aumento causal de utilidad. La recomendación conecta evidencia cualitativa con
 decisiones de surtido/experiencia y con validación económica, en vez de llamar “experiencia
 completa” a una lista de estándares operacionales.
 agosto 2014 - pregunta 5 - Necesidad y diseño de investigación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 156-156 | convocatoria
 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 1. Evaluación del argumento. Enrique tiene una preocupación válida: pedir que el público diseñe
 literalmente una innovación que nunca ha visto puede conducir a reproducciones de lo conocido.
 Una compañía artística necesita criterio creativo y no debe transformar una encuesta en un
 plebiscito sobre cada montaje. Pero de eso no se sigue que investigar al público carezca de utilidad.
 Se puede observar cómo vive experiencias, qué lo emociona, barreras, contexto cultural, ocasiones
 y condiciones de asistencia sin pedirle que invente el espectáculo. La investigación orienta
 necesidades y evaluación de propuestas; no sustituye la creación artística. Ser innovador y estar
 orientado al mercado son compatibles si se distinguen necesidades de soluciones actuales.
 Las declaraciones de Tiffany, Apple o Cirque du Soleil ilustran una filosofía, pero no prueban que
 nunca investiguen ni que el mismo método sirva en todos los países. La expansión internacional
Examen de Grado UC | materia, preguntas y respuestas 328

[pág. 329]
Marketing - versión clara y reordenada
 añade diferencias de lenguaje, expectativas, acceso y significado que no pueden suponerse iguales
 a Chile. Por tanto, discrepo con rechazar categóricamente toda investigación. El estudio debe
 preservar misión y novedad mientras reduce incertidumbre sobre experiencia y adopción.
 2. Elección de una metodología. Elegiría etnografía durante e inmediatamente después de
 espectáculos, para observar conducta y reacciones en contexto e interactuar brevemente. Es
 pertinente al problema de desarrollar una experiencia nueva cuando el público puede explicar mal
 por anticipado qué quiere. Permite captar atención, emoción, interacción, momentos de
 desconexión y cómo se interpreta el montaje, reduciendo parte del filtrado de memoria. Debe
 realizarse con audiencias pertinentes del mercado de destino y un protocolo interpretativo; no
 equivale a contar gestos y declarar demanda.
 La encuesta cerrada de veinte minutos sirve para cuantificar conceptos ya definidos, pero restringe
 respuestas a lo que los investigadores anticipan; no es mi primera opción exploratoria para
 experiencias innovadoras. La entrevista profunda revela motivos y lenguaje, y sería una alternativa
 defendible, pero depende de narración y racionalización fuera de la experiencia. La etnografía
 ofrece mejor acceso a esa experiencia vivida para el objetivo planteado.
 Sus limitaciones son selección de asistentes actuales, interpretación del observador, dificultad para
 generalizar y reactividad al ser observado. No produce una estimación probabilística de ventas ni
 garantiza asistencia a un montaje nuevo. Los hallazgos alimentarían criterios creativos y conceptos;
 después habría que validar aceptación y economía con una prueba adecuada. Como el caso
 permite un solo estudio, no respondo eligiendo simultáneamente las tres técnicas; explico qué
 aporta la elegida y qué deja sin resolver.
 agosto 2018 - pregunta 5 - Panel, frecuencia y Assessor
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 274-275 | convocatoria
 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 a. Ventaja de un panel frente a muestras independientes. Un panel observa a los mismos
 hogares a través del tiempo. Permite distinguir captación, pérdida y permanencia de compradores;
 separar compra ocasional de frecuencia; estudiar cambio de marca, repertorio, duplicación y
 respuesta a promociones. Dos muestras independientes pueden estimar penetración agregada en
 cada año, pero una disminución no permite saber quién abandonó ni quién ingresó. El panel
 también permite modelar heterogeneidad de tasas de compra. Requiere controlar representatividad,
 abandono del panel, errores de registro y posibles cambios de conducta por participar; no es
 superior automáticamente si su medición es deficiente.
 b. Elegir una estrategia: aumentar penetración de marca. Recomendaría penetración, con
 costos comparables, apoyándome en la brecha entre categoría y marca. En 2017, shampoo llega al
 99,2% de hogares, pero la marca líder solo al 55,9%; acondicionador llega al 94,0%, pero el líder al
 34,5%. Hay, respectivamente, 43,3 y 59,5 puntos porcentuales de hogares compradores de
 categoría que no compran al líder durante el año. La categoría casi no puede crecer incorporando
 hogares que nunca la compran, pero la marca sí puede ganar compradores dentro de la categoría.
 No se debe confundir penetración de categoría con penetración de marca.
Examen de Grado UC | materia, preguntas y respuestas 329

[pág. 330]
Marketing - versión clara y reordenada
 La frecuencia del líder es 3,3 para shampoo y 2,3 para acondicionador; la de categoría, 10,0 y 6,7.
 Esa brecha no significa que cada comprador pueda trasladar mecánicamente todas sus compras al
 líder: los consumidores suelen mantener repertorios y comprar marcas distintas. En consumo
 masivo, marcas grandes suelen diferenciarse más por número de compradores que por una lealtad
 extraordinaria. Además, la penetración del líder cae de 56,3% a 55,9% en shampoo y de 35,5% a
 34,5% en acondicionador, mientras la frecuencia aumenta de 2,9 a 3,3 y de 2,2 a 2,3. Concentrarse
 otra vez solo en frecuencia podría ignorar pérdida de alcance. Buscaría disponibilidad física y
 mental, acceso y captación rentable de compradores livianos; mediría compradores incrementales,
 repetición y contribución, evitando interpretar una promoción que adelanta compras como
 crecimiento permanente.
 La decisión no se basa en que frecuencia sea irrelevante. Como control contable, ventas por hogar
 del mercado=penetración×frecuencia×gasto por compra. Esa identidad permite distinguir los tres
 motores, pero la capacidad de aumentar cada uno depende de datos y costos. La pregunta obliga a
 elegir una estrategia y la evidencia respalda penetración de marca.
 c. Proyección de penetración a doce meses. Usaría un modelo de compra repetida
 Gamma-Poisson, cuya distribución agregada es binomial negativa. La idea es que cada hogar
 tenga una tasa de compra propia: algunos compran a menudo, otros muy poco; durante un periodo,
 sus compras se modelan con Poisson y las tasas difieren entre hogares según una distribución
 gamma. Con la penetración y frecuencia de los primeros tres meses, o preferentemente con la
 distribución individual de compras del panel, se estiman el nivel promedio de compra y la
 heterogeneidad. Luego se amplía el horizonte de observación a doce meses y se calcula la
 proporción esperada que habrá comprado al menos una vez. No se multiplica la penetración
 trimestral por cuatro porque un mismo hogar puede aparecer en varios trimestres.
 La proyección requiere una tasa de compra relativamente estable y una población/exposición
 comparables. En un lanzamiento, distribución, comunicación, conocimiento y disponibilidad suelen
 cambiar; habría que ajustar escenarios y validar sucesivamente con nuevos trimestres. Bass puede
 servir para estudiar difusión de adopción cuando hay innovadores e imitadores, pero no se lo debe
 escoger automáticamente para extrapolar penetración de una categoría de compra repetida con
 datos de frecuencia. Assessor tampoco reemplaza la relación de compra repetida solicitada. Debe
 explicarse el mecanismo y el supuesto que convierte tres meses en doce.
 enero 2016 - pregunta 5 - Participación y conjoint
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 193-194 | convocatoria
 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 1. Efecto del producto sin sello. H Foods tiene una oportunidad de diferenciación si es el único
 que cumple la norma, pero debe intercambiar beneficio saludable y ausencia de sello con pérdida
 de sabor. La categoría actual está dominada por la línea sabor: 11.570/18.522≈62,47% del
 volumen, frente a 17,43% saludable y 20,11% económica. H Foods concentra 4.647/7.147≈65,02%
 de su propio volumen en sabor. Por tanto, el atributo que empeora es relevante para una parte
 importante de la oferta y no se puede concluir que todos migrarán al nuevo producto.
Examen de Grado UC | materia, preguntas y respuestas 330

[pág. 331]
Marketing - versión clara y reordenada
 Sus participaciones dentro de cada línea son aproximadamente 40,16% en sabor, 24,88% en
 saludable y 45,57% en económica; hay una posición relativamente menor en la línea saludable,
 donde la nueva propuesta podría abrir espacio. El sello puede modificar preferencias y disposición a
 pagar, pero su efecto depende de comprensión, necesidades y de que todos los demás lo lleven.
 Consumidores orientados a sabor pueden mantener marcas anteriores; los sensibles a precio
 pueden rechazar un costo mayor, y algunos compradores saludables pueden priorizar ausencia de
 sello. La venta nueva puede venir de competencia, expansión de consumo o canibalización de
 líneas propias. No se debe sumar toda venta nueva como crecimiento neto.
 La conclusión es una oportunidad condicionada, no una predicción de aumento automático de
 participación o utilidades. Compararía contribución de la nueva oferta con lo que se pierde en
 productos actuales, costos de reformulación y credibilidad de marca. El caso se analiza según sus
 supuestos de 2016; no pretende describir la regulación vigente hoy.
 2. Estudio para decidir lanzamiento y precio. Propongo un análisis conjunto con elección de
 perfiles que represente marca/línea, sabor o desempeño sensorial, sello/condición nutricional y
 precio dentro de niveles realistas. Debe permitir evaluar configuraciones nuevas y trade-offs, e
 incorporar los productos competidores que siguen en mercado con sello. La valoración de sabor no
 puede prometer un desempeño que la prueba de producto contradice; las evaluaciones deben
 reflejar el producto realmente disponible. El enunciado pide no desarrollar muestra, cuestionario o
 entrevista, de modo que centro la respuesta en el modelo y cómo se usa.
 Los resultados entregarían utilidades, preferencias heterogéneas, importancia relativa y DAP por
 ausencia de sello frente a pérdida de sabor. Se simularían escenarios con y sin lanzamiento y
 distintos precios, con ofertas propias y rivales, para estimar sustitución, adopción y canibalización.
 Con costos y márgenes se transforma la elección relativa en contribución esperada del portafolio.
 Se lanzaría si un precio factible permite un incremento de valor neto suficiente bajo escenarios
 razonables, no si maximiza solo preferencia. No hay datos de utilidades del estudio en el caso, por
 lo que no se inventa un precio óptimo.
 La simulación declarada debe calibrarse con conducta y disponibilidad; si se busca un pronóstico de
 lanzamiento también podría complementarse con un pretest tipo Assessor y validación de
 prueba/repetición. La elección principal de estudio sigue siendo conjoint porque permite estimar
 directamente el intercambio sello-sabor-precio y evaluar precios alternativos. Una propuesta de
 encuesta genérica sobre “me gusta lo saludable” no resuelve esa decisión.
 agosto 2016 - pregunta 5 - Problema gerencial e investigación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 217-220 | convocatoria
 2
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 331

[pág. 332]
Marketing - versión clara y reordenada
 Respuesta desarrollada para estudio (no oficial)
 a. Problema de marketing. Algramo debe decidir cómo crecer rentablemente y sostener su
 impacto: aumentar cobertura y compradores, frecuencia y cantidad comprada, y ajustar surtido,
 formatos, precio, envase y acceso para que su propuesta se elija y se repita. Debe atender dos
 actores relacionados: almaceneros que adoptan el dispensador y compradores del hogar que
 adquieren la recarga. No basta decir “necesita más ventas”; el problema es qué propuesta y
 expansión producirán esas ventas sostenibles, evitando que el ahorro desaparezca por
 inconveniencia o costo inicial del envase.
 b. Problema de investigación. Se requiere información sobre necesidades y decisiones de los
 compradores, barreras de prueba/recompra, atributos valorados, DAP, uso de retornables y hábitos,
 además de condiciones de adopción de los almaceneros. Debe distinguirse consumidor final que
 usa el producto de quien decide la compra del hogar, y clientes actuales de quienes podrían
 incorporarse. El problema de investigación transforma las decisiones en preguntas de información;
 no consiste simplemente en repetir “crecer”.
 c. Comparación y juicio. Descartar A por su población puede ser correcto para el foco principal:
 selecciona consumidores que no toman decisiones de compra del hogar, aunque combine
 cualitativo y una muestra cuantitativa estratificada. Un buen método aplicado a la población
 equivocada no identifica las decisiones del comprador. Sus focus groups por sexo pueden explorar
 experiencia de uso, pero no sustituyen investigación de quien compra; ejecutar fases en paralelo
 además limita adaptar el cuestionario a los hallazgos cualitativos.
 B entrevista a almaceneros actuales y potenciales: aporta adopción del equipo, espacio, margen,
 logística, servicio y evaluación del canal. Es importante para cobertura, pero no estima directamente
 preferencias ni DAP de compradores del hogar. C observa e interactúa con compradores actuales
 de Algramo en el almacén: aporta decisiones, fricciones, cantidades y uso del envase en contexto.
 Sin embargo, excluye a no compradores, condición clave para penetración, y sus cuarenta casos
 por cuotas no permiten estimar tasas representativas del mercado.
 Por tanto, B y C no son igualmente válidas para todo el problema: responden a poblaciones y
 decisiones diferentes. Son complementarias para el sistema y ninguna, por sí sola, cubre todas las
 necesidades planteadas. Si la prioridad inmediata es comprender propuesta y repetición del
 comprador, C es más pertinente, pero la ampliaría a compradores potenciales/no usuarios y luego
 dimensionaría hallazgos. Si la prioridad es instalar más puntos, B es pertinente para el canal. No
 declararía cubierto el mercado a partir de cuarenta entrevistas de conveniencia o cuarenta
 observaciones de usuarios actuales. Se necesita una secuencia que integre ambos actores y
 cuantifique lo que deba estimarse, con pruebas de conducta para distinguir simpatía ambiental de
 compra efectiva.
 enero 2023 - pregunta 5 - Segmentación en modelo de elección
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 385-386 | convocatoria
 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 1. Caracterización de segmentos. Tomando como común la escala de utilidad de los modelos
 entregados, los resultados muestran:
Examen de Grado UC | materia, preguntas y respuestas 332

[pág. 333]
Marketing - versión clara y reordenada
 Aspecto Segmento 1, 32% Segmento 2, 19% Segmento 3, 49%
 Marca A es la más valorada Todas las tradicionales A es la más valorada
 (1,715); C y B también tienen constante negativa; (1,946), seguida de B y C,
 superan a propia propia es la base preferida todas sobre propia
 Precio Sensibilidad intermedia: Mayor sensibilidad: -0,659 Menor sensibilidad: -0,122
 -0,367
 Exhibición Efecto positivo intermedio: Mayor efecto positivo: Efecto positivo menor:
 0,491 0,773 0,265
 Catálogo Efecto positivo intermedio: Mayor efecto positivo: Efecto positivo menor:
 0,231 0,481 0,115
 Share previsto de A/propia 35%/18% 17%/36% 42%/11%
 El segmento 2 es más orientado a precio/actividades y a la marca propia; el 3 favorece A y es
 menos sensible al precio; el 1 es intermedio. No se deben inventar edad, ingreso o motivos
 psicológicos específicos: la tabla no los entrega. El share agregado previsto de A, ponderado por
 tamaño, es 0,32×0,35+0,19×0,17+0,49×0,42=35,01%, no el promedio simple de los tres shares.
 Si la escala del error fuera distinta entre segmentos, comparar coeficientes absolutos podría
 confundir sensibilidad con escala. Un control útil es comparar trade-offs dentro de cada modelo. La
 exhibición equivale a una rebaja de aproximadamente $1.338, $1.173 y $2.172, respectivamente
 (coeficiente de exhibición dividido por valor absoluto del de precio, en miles de pesos). Esto
 muestra por qué “coeficiente más alto” no es sinónimo de mayor valoración monetaria. El enunciado
 marca todos los coeficientes con *** al 1%, aunque algunas razones coeficiente/error de segmento
 3 no son compatibles con ese nivel en un test usual; la caracterización descriptiva no debe inventar
 una precisión que la tabla no sostiene.
 2.i. Por qué K-medias antes del logit. El equipo intenta capturar heterogeneidad: un único
 promedio puede ocultar un grupo que prefiere A y otro que prefiere marca propia. K-medias agrupa
 personas según variables sociodemográficas y de conducta; estimar por grupo permite tener
 constantes y respuestas diferentes para dirigir acciones. Los grupos deben ser estables y
 accionables. La segmentación previa no garantiza que quienes sean similares en sus variables
 también tengan preferencias iguales, ni que el k elegido sea correcto; requiere estandarización
 pertinente, revisión de outliers y validación. No se confunde un cluster estadístico con una verdad
 natural.
 2.ii. Ventaja y desventaja del modelo agregado. Su ventaja es utilizar todos los datos en una
 estimación más parsimoniosa, con potencialmente menor varianza y sin error adicional de
 clasificación en clusters. Su desventaja es imponer preferencias/respuestas comunes y producir
 una recomendación promedio inadecuada para la KAM. El procedimiento por segmentos gana
 capacidad de focalizar, pero reduce tamaño por modelo y depende de cómo se formaron los
 grupos. Una comparación defendible usa validación predictiva y utilidad de decisión, no solo pseudo
 R² de cada regresión.
 3. Dos acciones con presupuesto. Primera: defender y facilitar la compra de A en el segmento 3,
 el más grande, con disponibilidad consistente y comunicación de la propuesta que sostiene su
 preferencia, reservando descuentos para cuando sean incrementales. El grupo tiene share de A de
 42%, poca sensibilidad al precio y una clara ventaja de marca. Rebajar indiscriminadamente a todos
 sus compradores puede regalar margen a quienes ya elegirían A. Se puede probar una exhibición
Examen de Grado UC | materia, preguntas y respuestas 333

[pág. 334]
Marketing - versión clara y reordenada
 acotada donde ese grupo sea accesible, verificando su contribución y no atribuyendo a la tabla un
 efecto de disponibilidad que no fue estimado.
 Segunda: probar una oferta/promoción de captación dirigida al segmento 2, con catálogo y/o
 exhibición según costos, comparando un incentivo de precio con un grupo control. Su sensibilidad al
 precio y a esas actividades es mayor en la escala común y la marca propia obtiene 36%: hay una
 amenaza concreta. Por ejemplo, una rebaja de $500 suma 0,3295 de utilidad en el 2, frente a
 0,1835 en el 1 y 0,061 en el 3. La promoción debe ser focalizable en la práctica y evaluarse por
 margen incremental, no solo share; un presupuesto puede gastarse rápido subsidiando ventas
 existentes. El segmento 1 se mantiene como posible expansión si la contribución marginal estimada
 supera a las otras acciones.
 No fijaría porcentajes exactos del presupuesto sin costos, márgenes, exposición y capacidad de
 identificar a cada grupo. La tabla permite diseñar hipótesis específicas y simulaciones de elección;
 falta información para una asignación óptima inequívoca. Se medirían migración desde propia,
 canibalización entre A/B/C y compra repetida después de la promoción.
Examen de Grado UC | materia, preguntas y respuestas 334

[pág. 335]
Marketing - versión clara y reordenada
 RESPUESTAS DESARROLLADAS ·
 MARKETING
 Pautas de estudio con mecanismo, evidencia, límites y decisión
 Respuesta M-U1 · Segmentación de clientes
 El mayor gasto promedio no basta para escoger el cluster 4. Puede tratarse de pocos clientes
 extremos, una solución inestable o consumidores cuyo gasto depende justamente de descuentos
 que destruyen margen. Primero revisaría tamaño absoluto, distribución y outliers; luego repetiría
 k-means con varias inicializaciones y muestras, compararía soluciones con k vecinos y mediría
 estabilidad de asignación. Revisaría si estandarizar dio el mismo peso a variables que tienen
 relevancia económica distinta.
 La validación externa debe usar un período posterior o una muestra reservada. Compararía margen
 de contribución, retención, sensibilidad a promoción y categorías compradas. El porcentaje con
 descuento puede definir el cluster y luego reaparecer como “hallazgo”; eso describe la construcción,
 no una validación independiente. Para activar el segmento se necesita una regla que clasifique
 clientes nuevos con datos disponibles y un tratamiento comercial distinto.
 Finalmente ejecutaría un experimento o una comparación creíble entre una oferta diseñada para el
 cluster y la política actual. La métrica es utilidad incremental: margen adicional menos descuento,
 contacto, canibalización y costo de servicio. Elegiría el cluster 4 solo si es identificable, estable,
 accesible, responde de forma diferencial y genera valor incremental. Si es pequeño pero muy
 rentable puede ser atractivo; si su volumen proviene de promociones, el gasto bruto induce una
 conclusión equivocada.
 Respuesta M-U2 · Factores y mapa perceptual
 El mapa sugiere que, dentro de las dimensiones retenidas y de la muestra, A está asociada
 relativamente con premium/diseño/exclusividad y menos con salud/pureza. Antes de leerlo revisaría
 cargas, comunalidades, varianza explicada, rotación y estabilidad. La distancia es una
 representación aproximada; no mide automáticamente importancia, preferencia ni causalidad.
 Que salud tenga alto promedio indica que los encuestados declaran valorarla, pero no prueba que
 diferencie marcas ni que mover la comunicación aumente elección. Podría ser un punto de paridad:
 todos esperan salud. También puede haber una brecha real de producto. Investigararía si A tiene
 sustancia para sostener la promesa, si el segmento objetivo percibe una carencia, qué
 competidores ocupan esa posición y qué costo de oportunidad existe al debilitar su asociación
 premium.
 Probaría conceptos o creatividades manteniendo coherencia con producto y canal. Mediría cambio
 perceptual y conducta en grupos comparables; luego margen y retención. Recomendaría
 reposicionar solo si existe una necesidad relevante, credibilidad, espacio competitivo y evidencia de
 respuesta incremental. Si no, reforzaría premium y usaría salud como requisito de confianza, sin
 convertirla en el eje.
Examen de Grado UC | materia, preguntas y respuestas 335

[pág. 336]
Marketing - versión clara y reordenada
 Respuesta M-U3 · Conjoint y precio
 Con utilidad lineal en precio, la disposición a pagar marginal es 0,60/0,015 = US$40. El signo se
 interpreta así: el beneficio agrega 0,60 de utilidad y un aumento de US$40 resta 0,60, dejando
 indiferencia. El cálculo exige que el coeficiente esté expresado por dólar, que el rango estudiado
 sostenga linealidad y que las utilidades de atributo y precio pertenezcan al mismo modelo y
 segmento.
 US$40 no es un precio óptimo. Conjoint estima trade-offs dentro de perfiles hipotéticos y de la
 muestra. Para fijar precio se necesita la utilidad total de todas las alternativas, distribución de
 preferencias, precios rivales, costos, canibalización, tamaño del segmento y reglas de elección. Un
 aumento que captura disposición a pagar puede reducir participación; el objetivo es maximizar
 contribución o valor de cliente, no utilidad parcial.
 Simularía escenarios de precio y producto, traduciría preferencia a demanda con una calibración
 apropiada y haría sensibilidad. Luego validaría en mercado o experimento, porque sesgo hipotético,
 omisión de atributos y restricciones de presupuesto pueden alejar la elección real. La respuesta de
 Distinción entrega el número, sus unidades, supuestos y la decisión adicional que todavía falta.
 Respuesta M-U4 · Zoom, freemium y causalidad
 Las cohortes no son comparables de forma automática. Quienes llegan por instituciones pueden
 tener uso obligatorio, mayor frecuencia, presupuesto institucional o soporte. La diferencia combina
 selección, ocasión y producto. Separaría invitación, activación, repetición, pago y retención.
 Compararía calidad de conexión, uso de funciones, tamaño de reunión y rol del decisor.
 El diseño ideal asigna aleatoriamente la alianza o intensidad cuando sea factible. Si no, usaría una
 implementación escalonada o grupos comparables, verificando tendencias previas y cambios
 simultáneos. La variable dependiente debe corresponder a la decisión: conversión y retención
 pagada, no solo cuentas creadas. El mecanismo se prueba si la intervención cambia una fricción o
 beneficio intermedio y luego conducta.
 La regla económica compara valor incremental esperado con costo. Para cada cohorte estimaría
 margen pagado esperado, retención y costo de capacidad, soporte, comisión o alianza. Descontaría
 el valor futuro y haría sensibilidad a atribución. Duplicaría el gasto solo si el incremento causal de
 contribución supera el costo y no deteriora servicio. La conclusión puede ser segmentada: alianzas
 funcionan donde existe uso repetido y autoridad de compra, pero no necesariamente en reuniones
 ocasionales.
Examen de Grado UC | materia, preguntas y respuestas 336

[pág. 337]
Marketing - versión clara y reordenada
 CONTROL FINAL DE FUENTES · MARKETING
 Qué se incorporó, qué se descartó y por qué no queda un vacío temático
 Fuentes cruzadas en esta ampliación
 Fuente local Acción Aporte al manual
 EDG_E_2009-2026_OCR.pdf + Cruce pregunta-página-curso 70 preguntas históricas de Marketing y sus
 mapa verificado de 210 respuestas desarrolladas
 preguntas
 Resúmenes de Sofía Pieraj y Lectura completa y cotejo Conducta, STP, marca, servicios, precios,
 compilados de Marketing temático canales, investigación, modelos de elección y
 difusión
 Guía Maestra EDG 2026 y Comparación por concepto Norton-Bass, control de alcance y estructura de
 Manual Power respuesta
 Prueba Zoom/WOM 2020-1 con Lectura de las ocho páginas Cinco preguntas y cinco respuestas ya
 pauta incorporadas antes de esta ampliación
 Clases 1-4 Marketing Analytics Muestreo visual en cinco Investigación, segmentación, distancia, k-means,
 2021 (F1008-F1011) momentos por video y cruce factores, mapas perceptuales y conjoint
 con resúmenes escritos
 HTML/Notion de Mercados II y Extracción completa Nombres, criterios y relaciones que confirman el
 resúmenes de Prueba 1/2 contenido visible de los videos
 ZIP, imágenes y documentos Cierre visual y extracción por Ejercicios, pautas y precisiones añadidas al
 recuperados miembro manual maestro y al anexo de fuentes
 recuperadas
 Archivos no usados como fuente sustantiva
 Se excluyeron copias binarias, accesos directos, inventarios, planes de horario y compilaciones
 derivadas que no agregaban contenido académico. Los audios de corrección con versión escrita o
 transcripción identificable se usaron por esa versión para evitar errores de oído. Los videos de
 Analytics fueron revisados visualmente y su temario coincidió con los resúmenes del mismo curso;
 por eso no se duplicó una transcripción literal de más de siete horas.
 Resultado: el cuerpo maestro conserva 35 preguntas de Fundamentos y 35 de Marketing
 Analytics. Esta ampliación añade materia y práctica recuperada sin cambiar el orden materia →
 preguntas → respuestas.
Examen de Grado UC | materia, preguntas y respuestas 337

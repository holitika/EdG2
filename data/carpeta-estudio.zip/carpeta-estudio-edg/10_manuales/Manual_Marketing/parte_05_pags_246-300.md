# Manual de Marketing · parte 5 (páginas 246-300)

Fuente: 01_MANUAL_ULTIMATE_MARKETING_EDG_2027_V2_FORMULAS_Y_METRICAS_CLARAS

[pág. 246]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2016 | pregunta 5
 Convocatoria 1 | página original 194 | Participación y conjoint
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 PREGUNTAS
 1) En base a la información entregada, ¿Cómo cree Ud. que afectará a H. Foods la nueva ley de etiquetado si
 esta empresa es la única en lanzar al mercado un nuevo producto que cumple la norma? Justifique su
 respuesta y suponga que todas las marcas existentes en el mercado se mantienen aunque, desde Junio de
 2016, con el sello negro.
 2) Proponga un estudio de mercado específico ? que le permita a H. Foods apoyar, de la forma más integral
 posible, la decisión de lanzar o no al mercado su marca saludable y con qué precio. Concretamente, a Ud.
 se le pide que explique de qué manera usaría los resultados de dicho estudio para apoyar la decisión que
 enfrentan los ejecutivos de H Foods.
 2 Ensu propuesta de estudio no se refiera a aspectos de diseño metodológico tales como: muestra, cuestionario,
 método de entrevista, etc... que estarán a cargo de la empresa de investigación que desarrolle el estudio.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 246

[pág. 247]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2016 | pregunta 5
 Convocatoria 2 | página original 217 | Problema gerencial e investigación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTANS
 Algramo es una empresa B', creada en 2013 por José Manuel Moller, egresado de Ingeniería Comercial
 UC, que comercializa productos de primera necesidad en almacenes de sectores residenciales de bajos
 ingresos en la ciudad de Santiago. La idea básica de Algramo es utilizar una máquina dispensadora de
 productos a granel (sin envasar o empaquetar) que se instala en el almacén, y que permite al consumidor
 comprar la cantidad que desee a un precio similar al precio que compra el mayorista por los productos de
 una canasta básica, en lugar de pagar el mayor precio que significa la compra en formatos fijos y pequeños.
 El ahorro en precio para el consumidor final llega a 20% - 30%,
 dependiendo del producto, aunque este no es el único beneficio que
 busca Algramo; también aspira a tener un impacto medioambiental y
 social. Algramo instala la máquina dispensadora en los locales
 adheridos y vende los productos a los almaceneros quienes, a su vez,
 venden sus productos al consumidor final.
 Algramo negocia con los almaceneros la instalación de la máquina
 en su local (ver figura a la derecha). En la primera compra, el
 consumidor paga el producto a granel y adicionalmente paga un
 envase retornable. En las siguientes compras, el cliente sólo paga el
 producto a granel si utiliza el mismo envase, El mayor ahorro para el
 consumidor final se produce en las compras sucesivas en las cuales
 no se paga el envase.
 Los ejecutivos de Algramo buscan hacer crecer las ventas de la
 empresa, ya sea en penetración (mayor cobertura) como en frecuencia
 e intensidad de compra a través de consumidores más leales con la
 marca. Así, se busca poder conocer mejor al consumidor y al
 comprador de Algramo, la viabilidad de una estrategia de crecimiento, los atributos que los consumidores
 valoran, los formatos de productos requeridos, las líneas de productos de consumo básico que debiera
 ofrecer la empresa, el modo de compra de los consumidores, el uso del envase desechable, la disposición
 a pagar y la valoración de productos social y ambientalmente responsables.
 Hasta ahora, los dueños y ejecutivos de
 Algramo no han hecho ningún estudio de
 mercado y todas sus decisiones se han basado
 en información no estructurada respecto de los
 almaceneros y de los clientes fmales. Para
 hacer frente al nuevo desafío que enfrenta la
 empresa, los ejecutivos de Algramo han
 cotizado en tres empresas de investigación de
 mercado un estudio que permita responder a
 las interrogantes planteadas. El Cuadro 1 que
 está en la página siguiente presenta, en forma
 resumida, características metodológicas de los
 tres estudios propuestos.
 1 Las empresas B tienen como objetivo no sólo las utilidades para sus dueños sino también el impacto social y
 medioambiental.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 247

[pág. 248]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2016 | pregunta 5
 Convocatoria 2 | página original 218 | Problema gerencial e investigación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 248

[pág. 249]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2016 | pregunta 5
 Convocatoria 2 | página original 219 | Problema gerencial e investigación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 Cuadro 1: Características Metodológicas Estudios de Mercado
 Dimensión Empresa A Empresa B Empresa C
 Consumidores Finales Compradores Algramo
 Población (de productos Algramo Almaceneros (quienes toman decisiones
 Objetivo y no Algrax_np que no (Algramo y no de compra en el hogar y
 toman decisiones de Algramo) compran productos
 compra en el hogar) Algramo
 40 entrevistas en
 2 Focus Group para profundidad de Investigación etnográfica
 Metodología cada uno de los aproximadamente | de 40 casos en el almacén,
 Cualitativa segmentos: Hombres 20 minutos c/u selección mediante cuotas
 y Mujeres con selección por por comuna
 conveniencia.
 En paralelo a la fase
 cualitativa, muestra
 de 400 casos con
 Metodología selección de la . .
 Cuantítati%¡a muestra estratificada No considerado No considerado
 por comuna y en tres
 etapas (manzana,
 hogar, persona)
 PREGUNTAS
 a) ¿Cuál es el problema de marketing de Algramo según se describe en el caso? Sea específico.
 b) ¿Cuál es el problema de investigación de Algramo según se describe en el caso? Sea preciso.
 c) El Cuadro 1 presenta, en forma resumida, tres propuestas metodológicas que ha recibido Algramo. El
 gerente de marketing de Algramo ha descartado la alternativa A y considera que las alternativas B y
 C son igualmente válidas. ¿Está usted de acuerdo con el ejecutivo de Algramo? Explique por qué.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 249

[pág. 250]
Marketing - versión clara y reordenada
 Marketing Analytics | agosto 2016 | pregunta 5
 Convocatoria 2 | página original 220 | Problema gerencial e investigación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 250

[pág. 251]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2023 | pregunta 5
 Convocatoria 1 | página original 385 | Segmentación en modelo de elección
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº5
 La mayor inflación y el menor dinamismo de la actividad observado en años recientes han llevado al consumidor
 chileno a privilegiar la búsqueda de alternativas más económicas. En este sentido, son cada vez más los
 consumidores que optan por marcas propias de las principales cadenas de supermercados del país. De acuerdo a un
 informe de Euromonitor International, las ventas de productos de marcas propias en Chile aumentaron 27% entre
 2019 y 2021, pasando de US$896,5 millones a US$1.140 millones. Las ventas de marcas propias en la categoría de
 productos lácteos es la que más crecimiento ha mostrado (45%), pasando sus ingresos de US$110,6 millones a
 US$160,7 millones en el mismo período.
 En este contexto, la Key Account Manager (KAM) –ejecutiva a cargo de la relación con una cadena de
 supermercados específica—de una importante marca de leches, está preocupada por la pérdida de participación de
 mercado de su marca como consecuencia del crecimiento de la marca propia de la cadena de supermercado. Para
 entender mejor las consecuencias de distintos cursos de acción, la KAM encarga a su equipo de analítica avanzada
 hacer un análisis del comportamiento de compra del consumidor de la categoría leches en esta cadena de
 supermercado. El equipo de analítica realiza preliminarmente un análisis de segmentación usando un algoritmo de
 K-medias, basado en distintas variables sociodemográficas y de comportamiento de un panel de consumidores1, el
 cuál identifica a tres segmentos distintos de consumidores. En una segunda etapa, el equipo de analítica estima un
 modelo de elección de marca para cada uno de los segmentos de clientes identificados por el algoritmo de análisis
 de clusters (K-medias). El estudio considera tres marcas tradicionales: A (marca a cargo de la KAM), B y C; y una
 marca propia de la cadena de supermercados.
 Específicamente, utilizando los datos del panel de consumidores, que indica las compras realizadas en la categoría
 leches, los analistas estiman un modelo logístico multinomial (también conocido como multinomial logit o regresión
 logística) que asume que la parte observable de la función de utilidad del consumidor depende de las siguientes
 variables: (1) Precio (en miles de pesos); (2) Presencia de la marca en una exhibición especial2 realizada en la sala
 de ventas del supermercado (variable dicotómica que toma el valor 1 si la marca está presente en una exhibición
 especial y cero de otro modo); (3) Presencia de la marca en un catálogo semanal publicado por la cadena de
 supermercado (variable dicotómica que toma el valor 1 si la marca es destacada en el catálogo y 0 de otro modo).
 Además, todas las estimaciones incluyen constantes asociadas a las marcas incluidas en el análisis.
 La siguiente tabla presenta los resultados de la estimación para cada uno de los segmentos de consumidores.
 Segmento 1 Segmento 2 Segmento 3
 Marca A 1.715*** -0.677*** 1.946***
 (0.145) (0.145) (0.169)
 Marca B 0.641*** -0.258*** 0.962***
 (0.054) (0.029) (0.059)
 Marca C 0.735*** -0.319*** 0.571***
 (0.081) (0.080642) (0.048)
 Precio -0.367*** -0.659*** -0.122***
 (0.024) (0.028) (0.012)
 Exhibición Especial 0.491*** 0.773*** 0.265***
 (0.120) (0.182) (0.137)
 Catálogo Publicitario 0.231*** 0.481*** 0.115***
 (0.009) (0.134) (0.06)
 # de Observaciones 2160 1250 3240
 Pseudo R-cuadrado 0.21 0.34 0.29
 Errores estándar en paréntesis. (***) indica significancia al 1%.
 La constante de marca de la marca propia se encuentra normalizada a cero.
 1 Asuma que el panel de consumidores es representativo de los segmentos de la población.
 2 Exhibición especial corresponde a cabezas de góndola, pasillos centrales, entrada, etc, que no es la ubicación habitual
 de la marca, y que genera mayor exposición a la marca, por ser una ubicación de alto tráfico.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 251

[pág. 252]
Marketing - versión clara y reordenada
 Marketing Analytics | enero 2023 | pregunta 5
 Convocatoria 1 | página original 386 | Segmentación en modelo de elección
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 La siguiente tabla presenta las participaciones de mercado predichas por el modelo logístico, para cada segmento
 de clientes, además del tamaño relativo de cada segmento:
 Segmento 1 Segmento 2 Segmento 3
 Marca A 35% 17% 42%
 Marca B 26% 22% 28%
 Marca C 21% 25% 19%
 Marca Propia 18% 36% 11%
 Tamaño Relativo (segmento) 32% 19% 49%
 Responda las preguntas que se realizan a continuación:
 1. ¿Cómo caracterizaría a cada uno de los segmentos identificados en el análisis de clusters en base a los resultados
 de las estimaciones del modelo de elección de marca? En particular, describa a cada uno de los segmentos en
 relación con las siguientes características: (i) Valoración de cada marca; (ii) Sensibilidad al precio; (iii)
 Sensibilidad a exhibiciones especiales; y (iv) Sensibilidad a publicidad (aparición de marca en catálogo
 publicitario).
 2. i) ¿Por qué cree Ud. que el equipo de analítica decidió realizar un análisis de K-medias previo a la estimación
 del modelo de elección de marca?
 ii) Dado el objetivo de la KAM, mencione una ventaja y una desventaja de estimar el modelo de elección de
 marca usando la muestra completa de clientes versus el procedimiento de dos etapas, que estima el modelo de
 elección de marca para cada segmento identificado usando K-medias.
 3. Con el objetivo de apoyar a la KAM, diseñe dos acciones de marketing orientadas a aumentar la participación
 de mercado en base a un presupuesto dado. Justifique las características de sus acciones en base a las preferencias
 y características de los segmentos.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 252

[pág. 253]
Marketing - versión clara y reordenada
 PREGUNTAS ADICIONALES · MARKETING
 Cuatro problemas integrados; las respuestas se encuentran en la sección siguiente
 Pregunta M-U1 · Segmentación de clientes
 Una cadena de retail dispone de recencia, frecuencia, monto, porcentaje de compra con descuento
 y número de categorías. Estandariza todas las variables y obtiene cuatro clusters con k-means. El
 cluster 4 es muy pequeño, compra mucho y usa descuentos intensamente. El gerente concluye que
 es el segmento objetivo porque tiene el mayor gasto promedio. Evalúa la conclusión y diseña la
 validación mínima necesaria.
 Pregunta M-U2 · Factores y mapa perceptual
 Un estudio de agua embotellada obtiene dos factores. En el primero cargan con signo positivo
 premium, diseño y exclusividad; en el segundo cargan salud y pureza. La marca A aparece cerca
 de premium y lejos de salud. El equipo propone comunicar salud porque es el atributo con mayor
 promedio en la encuesta. Explica qué permite concluir el mapa, qué no permite y cómo decidirías si
 reposicionar.
 Pregunta M-U3 · Conjoint y precio
 Para un plan digital, la utilidad parcial de interacción en vivo sube 0,60 al pasar de nivel básico a
 completo. El coeficiente de precio es -0,015 por dólar. Calcula una disposición a pagar marginal,
 explica sus supuestos y señala por qué ese número no basta para fijar precio.
 Pregunta M-U4 · Zoom, freemium y causalidad
 Zoom observa que las cohortes expuestas a invitaciones institucionales repiten más y pagan más
 que quienes llegan por búsqueda orgánica. El gerente atribuye todo el efecto a la experiencia
 superior del producto y quiere duplicar el gasto en alianzas. Propón un diagnóstico, un diseño de
 validación y un criterio económico de decisión.
Examen de Grado UC | materia, preguntas y respuestas 253

[pág. 254]
Marketing - versión clara y reordenada
 RESPUESTAS - soluciones completas
 Las respuestas siguen el mismo orden de las preguntas. Son propuestas de estudio; una atribución
 a pauta oficial exige identificación expresa y verificada.
 Fundamentos de Marketing
 enero 2018 - pregunta 1 - Amenaza low-cost y submarca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 253-254 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 a) Sí conviene evaluar una línea económica diferenciada del núcleo premium.
 La amenaza afecta necesidades de clientes, no solo identidad de marca. En alimentos,30% de
 ventas corresponde a decisiones de ingenieros que valoran protección, calidad y desempeño;70%
 corresponde a compras que priorizan precio sujeto a mínimos. Sobre US$75 millones de alimentos,
 esa segunda base equivale a US$52,5 millones potencialmente expuestos, no ventas ya perdidas.
 La utilidad bruta de alimentos es aproximadamente75×67%=US$50,25 millones frente
 a25×20%=US$5 millones de limpieza, por lo que defender ese negocio importa especialmente.
 Envasin satisface una calidad menor aceptable para parte del mercado; no hay barreras de entrada
 y distribuidores no exclusivos ya lo venden o piden una opción económica. Mantener solo la línea
 cara podría ceder clientes y acceso al canal. Una línea de entrada con mínimos apropiados,
 marca/beneficios claramente diferenciados y menor costo puede retenerlos, evitando bajar precio
 de todo el portafolio. Al mismo tiempo, debe seguir demostrando el valor/costo de fallas de la
 premium a ingenieros y a quien realmente se beneficie.
 Los riesgos son canibalizar premium, confundir promesa de alta calidad, dispersar capacidad y
 provocar respuesta rival. Se define para qué uso es adecuada cada línea y se compara contribución
 de clientes retenidos/captados con sustitución y costos de operar dos ofertas. La misión tecnológica
 no exige ignorar un segmento que solo necesita un mínimo; tampoco justifica vender un producto
 económico inseguro o sin beneficio claro.
 b) La propuesta de precios protege contribución unitaria, pero puede frustrar la defensa.
 La tabla visual da: premium EDELTA costo US$0,5, venta al distribuidor US$1,5 y reventa US$2,0;
 Envasin costo US$0,3, venta al distribuidor US$0,9 y reventa US$1,7. Aproximando costo unitario
 como costo relevante, EDELTA obtiene US$1 por unidad premium y su distribuidor US$0,5. Si el
 económico cuesta US$0,3 y se conservan esos importes, su precio mayorista sería0,3+1,0=US$1,3
 y reventa1,3+0,5=US$1,8.
 Oferta Contribución fabricante por Margen bruto del Precio final
 unidad distribuidor por unidad
 EDELTA premium US$1,0 US$0,5 US$2,0
Examen de Grado UC | materia, preguntas y respuestas 254

[pág. 255]
Marketing - versión clara y reordenada
 Oferta Contribución fabricante por Margen bruto del Precio final
 unidad distribuidor por unidad
 EDELTA económico US$1,0 US$0,5 US$1,8
 propuesto
 Envasin US$0,6 US$0,8 US$1,7
 Aunque EDELTA conserva US$1, su margen porcentual pasa de66,67% a76,92%; conservar
 dólares por unidad no significa conservar porcentaje. El producto económico queda US$0,1,
 aproximadamente5,88%, sobre Envasin con calidad similar según la propuesta. Su distribuidor
 gana US$0,5 frente a US$0,8 con el rival, incentivos especialmente relevantes en una red no
 exclusiva donde15 de60 distribuidores generan más80% de ventas. Pedir cooperación con menor
 beneficio y oferta final más cara puede perder demanda/canal pese a la buena cuenta por unidad.
 Si se igualara US$1,7 final y se conservara US$0,5 al distribuidor, el mayorista seríaUS$1,2 y
 EDELTA ganaríaUS$0,9. Si además se ofrecieraUS$0,8 al distribuidor, el mayorista seríaUS$0,9 y
 EDELTA ganaríaUS$0,6. Son escenarios, no precios óptimos. La generación de valor depende de
 contribución total, volumen incremental, canibalización y apoyo comercial; imponer el importe
 histórico como restricción puede evitar precisamente la respuesta que necesita el segmento.
 Compararía esos escenarios con datos de elección/canal y un posicionamiento claro.
 enero 2021 - pregunta 1 - Brand equity y arquitectura
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 329-330 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 a) Tres argumentos para pagar por valor superior al de activos físicos.
 1. Asociaciones diferenciadoras que sostienen preferencia y prima: BlueBottle representa
 origen responsable, tostado fresco, preparación refinada y una experiencia sensorial/artesanal. El
 símbolo reconocible, diseño local y comunidad no son solo una fábrica y50 tiendas. El caso informa
 precio de café dos a tres vecesStarbucks; esa disposición a pagar, si es persistente, permite flujos
 superiores a los de un negocio sin marca. Prima de precio no equivale a margen: hay costos de
 calidad, experiencia y frescura. 2. Relación directa y lealtad de un segmento valioso:
 fanáticos/jóvenes exploradores buscan pertenencia y experiencia especial, acuden a locales y
 mantienen suscripciones online. La marca reduce incertidumbre de calidad y puede generar
 repetición, recomendación y acceso propio al cliente. Guías, cursos y videos refuerzan experiencia
 y ayudan a sostener valor; esa capacidad de atraer/retener demanda no queda capturada en el
 precio de edificios/equipos. Debe verificarse con retención, contribución y conducta, sin suponer
 que toda fila frente al local sea lealtad rentable. 3. Plataforma de crecimiento y
 complementariedad del portafolio: BlueBottle crece enEE.UU. cinco a seis veces más rápido que
 las marcasNestlé según el relato; aporta un público/propuesta distinto de instantáneo y cápsulas, y
 oportunidades en tostado/molido, listo para beber y suscripciones. Capital y capacidades deNestlé
 pueden apoyar expansión conservando el activo de marca. La compra evita reconstruir desde cero
 reputación/comunidad, aunque exige preservar autenticidad y cumplir calidad al crecer.
 Los US$500 millones pagados por68% no se justifican solo declarando «marca valiosa». Hay que
 estimar flujos incrementales, riesgos, derechos adquiridos y sinergias realizables; US$50 millones
Examen de Grado UC | materia, preguntas y respuestas 255

[pág. 256]
Marketing - versión clara y reordenada
 de activos tangibles no son necesariamente valoración de toda la empresa ni valor liquidable de su
 marca. El enunciado compara500/50=10; no atribuyo automáticamente US$450 millones a marca
 aislada ni igualo una participación68% a100% del negocio. Los argumentos explican activos
 económicos omitidos por una tasación física, no prueban por sí solos que el precio fue justo.
 b) No incorporaría BlueBottle como sublínea de Nescafé; elegiría una casa de marcas.
 En una arquitectura de marcas independientes o house of brands, Nestlé conserva BlueBottle
 como identidad propia y propuesta distinta dentro de su portafolio corporativo, en vez de convertirla
 en «NescaféBlueBottle». Nescafé remite al consumo masivo/instantáneo y producción industrial del
 caso; BlueBottle a preparación artesanal, frescura, diseño, origen y comunidad. Hacerla una
 extensión explícita deNescafé puede transferir asociaciones que reduzcan la diferencia y la prima
 por la que se compró, aunque aumente notoriedad.
 La autonomía mantenida desde la adquisición respalda proteger esas señales. Se pueden
 compartir capacidades de compras, financiación o logística donde no afecten calidad/experiencia,
 sin imponer identidadNescafé al consumidor. Nespresso también muestra que el portafolio admite
 una marca premium distinta, aunque su experiencia/cápsulas no sean iguales aBlueBottle.
 Los costos de independencia son administrar varias marcas y no aprovechar toda notoriedad
 publicitaria del nombreNescafé. Aun así, excelentes resultados actuales no prueban que un cambio
 de arquitectura los mejore; la marca adquirida es precisamente el activo a conservar. Evaluaría
 asociaciones, disposición a pagar y retención antes de cualquier aval corporativo discreto; ese
 eventual respaldo es distinto de convertirla en subproductoNescafé. Expansión se aprueba por
 ajuste y contribución, manteniendo la promesa artesanal verificable.
 enero 2023 - pregunta 1 - Campañas y customer journey
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 377-378 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Campaña con $100.000 mensuales para aumentar suscripciones en el tiempo.
 Recomendaría una combinación de prospección y retargeting, con seguimiento de resultados
 marginales. Si la decisión fuese maximizar suscripciones inmediatas con los mismos públicos y
 rendimientos observados, el retargeting tiene la ventaja: produjo 2.628 suscripciones frente a 1.285
 con igual inversión. Pero el objetivo incluye sostenerlas en el tiempo, y el público que ha
 interactuado antes con la marca es limitado. La prospección alimenta ese público; eliminarla puede
 agotar el crecimiento posterior.
 La tabla permite distinguir alcance, interés y compra:
 Indicador recalculado Prospección Retargeting
 Costo por suscripción completada $77,82 $38,05
 Clics / impresiones 1,53% 5,27%
 Suscripciones / clics 1,31% 11,95%
 Suscripciones / procesos iniciados 25,00% 83,35%
Examen de Grado UC | materia, preguntas y respuestas 256

[pág. 257]
Marketing - versión clara y reordenada
 La “tasa de conversión a compra” original de 0,02% y 0,63% usa impresiones como denominador;
 no es la conversión por clic. El retargeting presenta CPM y CPC mayores -$239,76 y $4,55 frente a
 $15,56 y $1,02- y aun así menor costo por adquisición. Elegir prospección porque sus clics son
 baratos confundiría una acción intermedia con el resultado económico. A la vez, la comparación no
 prueba que el anuncio de retargeting cause toda la diferencia: alcanza personas seleccionadas por
 una interacción previa, probablemente con mayor intención.
 Asignaría inicialmente una fracción mayor a retargeting mientras exista un público elegible de
 calidad y mantendría prospección para incorporar usuarios nuevos. El caso no permite calcular un
 porcentaje óptimo: faltan curvas de respuesta, tamaño de audiencia, frecuencia, superposición y
 retención de las cohortes. Revisaría el CPA incremental al variar presupuesto, excluiría suscriptores
 ya adquiridos y mediría suscripciones netas sostenidas, cancelaciones y contribución del cliente
 después de producto y entrega. No multiplicaría mecánicamente los resultados históricos para
 prometer ventas con otra mezcla presupuestaria.
 El recorrido relevante comienza cuando la persona detecta un problema visual, visita al oftalmólogo
 y obtiene receta; después busca información en amigos e internet, compara ópticas y sitios, registra
 su receta y compra. La publicidad ayuda a progresar entre esas etapas. Reducir la fricción para
 registrar la receta y dar confianza en calidad y entrega puede mejorar la conversión más allá de
 comprar más impresiones.
 2. Evaluación de listas de correos con promociones y campaña masiva de marca. Comprar
 listas según edad tiene una lógica de segmentación: una probabilidad de necesitar corrección visual
 podría ayudar a evitar parte del desperdicio de medios masivos. Sin embargo, necesitar corrección
 no equivale a preferir lentes de contacto, tener receta vigente, querer comprar online o aceptar una
 suscripción mensual de US$30. Una lista adquirida tampoco asegura datos correctos, interés o
 disposición a recibir mensajes. Basar la comunicación sólo en descuentos puede debilitar la
 confianza necesaria para un producto ligado a la salud y atraer compradores que abandonen al
 terminar la oferta. Evaluaría procedencia y calidad de los datos, permisos pertinentes, respuesta y
 adquisición incremental antes de escalar, sin asumir que cualquier lista es utilizable.
 La campaña de marca aporta reconocimiento y seguridad en las primeras etapas del recorrido,
 puede llegar al entorno que recomienda y fortalecer las relaciones con médicos y clientes. Esto
 importa porque ContactVision vende directamente y requiere una receta de todos los compradores
 según el caso. Su debilidad es que una campaña indiscriminada también llega a personas sin
 necesidad, sin capacidad de compra o sin preferencia por contactos. Una subida de alcance no
 demuestra suscripciones causadas por esa campaña.
 Priorizaría comunicación de confianza dirigida a públicos y etapas pertinentes, junto con captación y
 retargeting medibles; usaría mensajes de precio como apoyo a una propuesta de calidad,
 comodidad y entrega confiable. Compararía las alternativas por CAC incremental y valor de clientes
 retenidos, incluyendo pruebas con grupos de comparación. La decisión no es exclusivamente
 “emails baratos” frente a “marca masiva”: ambas deben justificarse por su contribución al recorrido y
 la suscripción sostenible.
 agosto 2021 - pregunta 4 - Canal online y omnicanalidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 348-349 | convocatoria
 2
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 257

[pág. 258]
Marketing - versión clara y reordenada
 Respuesta modelo desarrollada (no oficial)
 a. Dos argumentos que apoyan a cada director. Las propuestas compiten por el mismo
 presupuesto; para compararlas hay que separar el atractivo de un canal de su contribución
 económica y de su función para el cliente.
 Director A: renovar las tiendas y su comunicación. Primero, la tienda conserva una ventaja de
 experiencia que un catálogo digital reproduce parcialmente. HomeTips vende regalos y productos
 para el hogar con ayuda de vendedores capacitados en decoración, envoltorio, entrega e
 instalación; además, la exhibición estimula compras de impulso. El 65% de los clientes declara
 querer volver a comprar físicamente. Renovar esa experiencia y comunicar su reapertura permite
 recuperar una mayoría de clientes utilizando una capacidad ya desarrollada. La encuesta respalda
 esta hipótesis, aunque no prueba que todos vuelvan con la misma frecuencia ni describe a los
 potenciales clientes nuevos.
 Segundo, el costo fijo de CornerTop erosiona especialmente los tickets pequeños. Con un ticket de
 $18.000 y margen comercial de 40%, la contribución antes de otros costos es $7.200; descontar
 $5.000 deja $2.200, equivalente a 12,2% de la venta. Para el ticket anterior de $14.000, deja $600,
 o 4,3%. La tarifa representa 27,8% y 35,7% de los tickets respectivos. Esto apoya revisar ese
 convenio y dirigir recursos a ventas presenciales que no pagan dicha tarifa. No permite afirmar que
 toda venta física sea más rentable: todavía faltan costos de tienda, preparación y atención, y la
 comisión podría tener una definición distinta del margen informado.
 Director Z: construir comercio electrónico propio con retiro y logística. Primero, el 10% que
 prefiere exclusivamente internet y el 25% restante de modalidad mixta representan una demanda
 relevante. Un canal propio permitiría conocer clientes y sus recorridos, información que hoy
 conserva CornerTop. HomeTips podría relacionar compras, preferencias y servicio, ofrecer
 recomendaciones pertinentes y gestionar recompra sin depender exclusivamente del intermediario.
 La permanencia de esos hábitos debe medirse; la afirmación de que todo cambió para siempre es
 una hipótesis.
 Segundo, el retiro en las 50 tiendas permite combinar conveniencia digital y servicio presencial:
 consultar disponibilidad, elegir un regalo y recogerlo envuelto o pedir instalación. Puede aumentar
 frecuencia y aprovechar inventario y ubicaciones existentes. Al internalizar la operación se podría
 evitar la tarifa de $5.000, pero aparecen costos propios de plataforma, pagos, adquisición y
 despacho. La conveniencia económica exige comparar esos costos con la tarifa evitada y la
 contribución adicional, descontando las ventas simplemente trasladadas desde la tienda.
 b. Tres factores al operar simultáneamente los cuatro canales. Este inciso supone
 expresamente que están activos tiendas, canal propio, CornerTop y marketplace; esa hipótesis es
 distinta de la elección presupuestaria anterior.
 1. Diseñar un recorrido coherente para el cliente. Cada canal debe cumplir una función y una
 promesa explícita. Una compra de marketplace no puede prometer automáticamente los mismos
 servicios de instalación o envoltorio que la tienda sin capacidad para entregarlos. Se necesitan
 reglas claras de retiro, devoluciones, garantías, precios y atención; los vendedores deben poder
 resolver los traspasos entre canales. Omnicanalidad requiere continuidad de la experiencia,
 además de presencia en varias plataformas. 2. Coordinar inventario y cumplimiento. Una visión
 fiable del stock y de los pedidos evita vender dos veces una unidad disponible en tienda, cancelar
 regalos y fallar en la fecha prometida. Hay que asignar responsables de preparación, entrega,
Examen de Grado UC | materia, preguntas y respuestas 258

[pág. 259]
Marketing - versión clara y reordenada
 reposición y posventa, incluyendo los compromisos de disponibilidad y servicio del marketplace.
 Mediría pedidos completos y puntuales, quiebres, devoluciones y satisfacción por canal. 3.
 Controlar rentabilidad, información y conflictos entre canales. Compararía contribución
 después de comisiones, tarifa fija, despacho, promociones, devoluciones y captación, distinguiendo
 ventas incrementales de canibalización. Definiría reglas para promociones y atribución de ventas, y
 acuerdos sobre los datos que cada plataforma realmente comparte; participar en un marketplace no
 concede automáticamente una base propia de clientes. La combinación debe ampliar cobertura y
 frecuencia sin deteriorar servicio ni pagar dos veces por la misma venta.
 marzo 2011 - pregunta 1 - Canales y cadena de valor
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 58-59 | convocatoria 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Razón comercial y beneficios potenciales para Walmart.
 Walmart busca extender el control logístico desde la fábrica/bodega del proveedor hasta el local
 para apoyar disponibilidad y «precios bajos todos los días». Sus camiones pueden coordinar retiros,
 consolidar cargas y aprovechar retornos que antes viajaban vacíos, programar entregas y reducir
 demoras/stock de seguridad. En el esquema inicial el proveedor entrega al centro de distribución y
 Walmart realiza el último tramo; en el nuevo Walmart organiza ambos, como muestran los
 diagramas. Mejor servicio y menor costo total pueden traducirse en precio competitivo, menos
 quiebres y mayor satisfacción/venta.
 La medida se concentra en grandes proveedores que representan80% de las compras: ahí es
 mayor el volumen coordinable y la ganancia potencial por ruta. Walmart pasa de cobrar3% a6% de
 sus compras, tres puntos adicionales. Para una base de compras B, ingreso adicional por
 servicio=0,03B, antes de los costos de retiros. No se puede aplicarlo directamente a los US$416mil
 millones de ingresos minoristas: ventas no equivalen a compras y no todas están cubiertas. El
 beneficio puede provenir de eficiencia, ingreso logístico y mayor poder de
 coordinación/negociación; no conocemos su magnitud neta.
 2. Consecuencias negativas para proveedores que aceptan.
 El proveedor pierde25-30% del volumen atendido por su propia red, aproximadamente la
 participación de Walmart en sus ventas según el caso. Si quedan camiones, contratos o personal
 fijos que no puede ajustar, esos costos se reparten sobre el70-75% restante. Por ejemplo, una red
 con costo fijo F mantendría F/0,75V a F/0,70V por unidad de base de ventas,33,3-42,9% más que
 F/V; es un efecto condicional, no un costo estimado del caso. Desaparecen economías de
 densidad, cargas completas y retornos compartidos con otros clientes.
 Además paga tres puntos adicionales a Walmart, pierde control de calendario/transporte y queda
 más dependiente de un cliente dominante, con menor capacidad de usar logística como ventaja
 negociadora. Los ahorros de su propio tramo no son íntegros si los costos son hundidos o fijos. La
 propuesta podría permitir foco productivo y evitar costos variables; para evaluar la pérdida hay que
 comparar esos ahorros reales con0,03B, activos ociosos y servicios deteriorados al resto del canal.
 La afirmación de que los proveedores se enfocarán en fabricar no asegura beneficio económico
 para ellos.
Examen de Grado UC | materia, preguntas y respuestas 259

[pág. 260]
Marketing - versión clara y reordenada
 3. Principal consecuencia negativa para supermercados rivales.
 Al retirar de las rutas comunes el gran volumen de Walmart, la logística de proveedores que
 también abastece a Safeway, Kroger o Publix pierde escala/densidad. El costo de servir a esos
 otros clientes puede subir, trasladándose a precio de compra, entregas menos frecuentes o
 condiciones menos favorables. Mientras Walmart aprovecha su escala y control para bajar costo y
 sostener precio/servicio, los rivales afrontan una desventaja relativa. Esta es una consecuencia
 indirecta sobre el costo y servicio del abastecimiento compartido, no solo que Walmart se vuelva
 «más eficiente».
 La transferencia no es inevitable: depende de costos ajustables, rediseño de rutas, negociación y
 respuesta de proveedores/rivales. El análisis distingue el ahorro del sistema, quién lo captura y qué
 costos se desplazan al resto del canal.
 agosto 2013 - pregunta 1 - Capital y posicionamiento de marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 127-128 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Tres argumentos contra que tecnología y sus campañas basten para alcanzar a Nike.
 1. Atributo no equivale a beneficio relevante ni a elección: chip, rebote o16 resortes son
 razones de producto, pero el corredor también elige por comodidad percibida, confianza, identidad,
 estética y experiencia. Hay que comprobar si la mejora resuelve un problema valorado, se percibe
 al usarla y cambia disposición a pagar. Adidas ONE ya tuvo un precio20% superior a Nike; ese
 antecedente no muestra que alcanzara al líder. Una innovación costosa o compleja puede limitar
 adopción aun siendo técnicamente novedosa. 2. La marca instalada crea una barrera de
 asociaciones y hábitos: Nike supera40% mundial de running y55% en EE.UU., frente a
 aproximadamente7% y4,5% de Adidas. «Just do it» y corredores aficionados vinculan producto con
 motivación e identificación personal, desarrolladas durante años. Para cambiar preferencia no basta
 informar un componente superior: Adidas debe construir una relación creíble y sostenida que
 compita con reconocimiento, confianza y experiencia acumulados. Cuota alta no vuelve invencible a
 Nike, pero hace insuficiente extrapolar un lanzamiento al cierre de esa distancia. 3. La
 diferenciación tecnológica puede ser transitoria y el mix debe funcionar completo: otras
 firmas pueden responder con mejoras propias; ASICS, Brooks y marcas especializadas también
 compiten. Una sucesión de modelos no asegura diferenciación sostenible, disponibilidad, prueba ni
 experiencia consistente. El caso dice que precios/canales de ambos portafolios son similares, por lo
 que no demuestra una nueva ventaja allí; tampoco aporta ventas, repetición o pruebas
 comparativas que permitan pronosticar cuotas. El objetivo de ganar unidades y superar valor exige
 además resolver volumen versus prima de precio y contribución, no solo elevar inversión en I+D.
 Estos argumentos niegan la suficiencia del camino, no el valor de innovar. Adidas puede avanzar si
 traduce innovación en beneficios comprobados y construye asociaciones relevantes, con ejecución
 y resultados.
 2. Diferencia en creación de valor de marca.
Examen de Grado UC | materia, preguntas y respuestas 260

[pág. 261]
Marketing - versión clara y reordenada
 En el relato del caso, Nike enfatiza al corredor y su aspiración: esfuerzo, compromiso, pertenencia e
 identidad, incluso con rostros anónimos en running. El aviso llama a levantarse, correr y hacerlo
 juntos; el producto funciona como vehículo para una historia personal. Así genera asociaciones
 emocionales, recuerdo y significado que pueden extender consideración más allá del especialista
 técnico.
 Adidas pone al producto y su desempeño en el centro: materiales BOOST desarrollados con BASF,
 amortiguación, impulso, adaptación y diseño de SPRINGBLADE. Su valor se apoya especialmente
 en calidad percibida, competencia tecnológica y beneficios funcionales. Para que ese valor sea
 duradero el corredor debe entender y experimentar la promesa, no solo recordar un nombre técnico.
 Ambas vías pueden generar preferencia y disposición a pagar. Nike también necesita desempeño y
 Adidas puede crear emoción/identidad; no son categorías excluyentes. La diferencia es el énfasis
 comunicacional y el camino desde atributo o aspiración hacia asociaciones de marca. Evaluaría
 relevancia, confianza, consideración, uso y repetición por segmento antes de declarar superior una
 estrategia.
 agosto 2020 - pregunta 1 - Crecimiento de categoría y canales
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 315-316 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 a) Elijo promociones al comercio, por tres razones vinculadas al objetivo del semestre.
 1. La disponibilidad y ejecución en el lugar de elección son centrales: el caso dice que la
 marca se decide en el momento/lugar de compra y54% de ocasiones nace de un antojo.
 Congeladores, stock, exhibición y material facilitan convertir esa ocasión en una ventaBresler.
 Construir preferencia mediante medios sin encontrar la marca puede terminar en elección de un
 sustituto de atributos similares. 2. Se alinea con canal y estación de mayor oportunidad: el canal
 tradicional concentra la mayor parte de helados individuales; supermercados no superan10% de
 esas ventas. Bresler tiene solo4,6% de cuota impulsiva frente a38,5% deNestlé y37,4% deTrendy,
 mientras en hogar tiene13,1%. Asegurar más puntos activos y mantener distribuidores en
 octubre-marzo, cuando ventas triplican al otro semestre, puede ganar cobertura y rotación con
 efecto dentro del plazo. El consumo8 litros frente a otros países no garantiza adopción local; es más
 directo trabajar la compra existente. 3. La proyección favorece el ingreso de la opción elegida:
 con el mismo presupuesto$500 millones, comercio proyecta+8,5% ingresos frente a+4,3%
 consumidor. Esto es consistente con buscar expansión de ventas/participación por ejecución,
 aunque son ingresos, no volúmenes físicos calculados. Reconozco el sacrificio: utilidad operacional
 crece solo1,2% frente a3,1% en la alternativa. No se puede declarar mejorROI sin utilidades base y
 tratamiento del presupuesto; elegir comercio prioriza el objetivo declarado de cuota/volumen a corto
 plazo, sujeto a contribución sostenible.
 La campaña al consumidor puede fortalecer preferencia y retención, pero no sustituye la compra
 accesible/ejecución en una categoría impulsiva. La decisión no autoriza descuidar experiencia y
 marca; deben mantener coherencia en los materiales del canal.
 b) Dos riesgos y mitigación.
Examen de Grado UC | materia, preguntas y respuestas 261

[pág. 262]
Marketing - versión clara y reordenada
 Riesgo1: cargar inventario al canal sin generar consumo incremental. Descuentos por
 volumen y cajas gratis pueden adelantar pedidos, acumular existencias, desplazar pedidos
 posteriores o llegar a locales sin demanda. Se vendería al distribuidor, pero no se cumpliría
 necesariamente la meta de consumo/cuota. Mitigaría con límites por rotación/capacidad, entregas
 por etapas y compromisos medibles de stock/exhibición; seguiría sell-out, puntos realmente activos,
 quiebres, devoluciones y comparación con el semestre anterior, separando carga inicial de
 reposición.
 Riesgo2: pérdida de contribución y dependencia de incentivos/precio. Mayoristas pueden
 capturar descuentos sin mejorar precio/servicio al consumidor; promociones repetidas pueden
 erosionar referencia, estimular guerra o financiar ventas que ocurrirían igual. La proyección ya
 muestra crecimiento de utilidad mucho menor que ingreso. Mitigaría con beneficios acotados por
 producto/plazo/objetivo, cálculo de contribución después de regalos/equipos/cadena de frío y
 evaluación de rendimiento por distribuidor. Mantendría calidad, mantenimiento de congeladores y
 capacidad de abastecer la temporada para que el incentivo no produzca mala experiencia.
 Solo escalaría si volumen de consumidor y contribución incremental sostienen el gasto. Cuota
 necesita comparar con el mercado total de la misma categoría/período; más ingresos nominales no
 prueban automáticamente ganancia de participación física.
 enero 2020 - pregunta 1 - Crecimiento, canal y marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 303-304 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 a) Tres desventajas principales de las dos estrategias consideradas conjuntamente.
 1. Falta de encaje entre cliente, canal y producto: Decathlon ofrece autoservicio, precio bajo y
 cañas principalmente para principiantes/ocasionales; Redington vende calidad/precio medio para
 serios, y Crux busca profesionales con tecnología/precio mayores. La compra de
 serios/profesionales requiere asesoría y recomendación según el caso. Un gran local con70
 deportes no asegura atención técnica o prueba pertinente; que las marcas actuales sean de menor
 precio no elimina sustitución ni barrera de elección. Ampliar alcance sin el apoyo que exige el
 producto puede producir stock antes que sell-out. 2. Riesgo para relaciones y posicionamiento
 que ya crean valor: tiendas especializadas generan70% de ventas en valor y50% en volumen,
 con50 distribuidores y presencia en lodges. Ellos reciben capacitación y organizan excursiones,
 construyendo credibilidad y demanda. Un canal masivo de bajo precio puede canibalizar ese
 esfuerzo, generar comparación/promociones y debilitar el incentivo de distribuidores que también
 venden competidores. Al mismo tiempo, intentar afirmar una marca profesional con mayor precio
 mientras se masifica la oferta puede confundir los niveles si no se separan roles claramente. 3.
 Compromiso de recursos sin demanda incremental acreditada: el pedido inicial grande de
 Decathlon es venta al canal, no consumo/recompra. Sus20 aperturas previstas son expectativa, no
 cobertura ya disponible. Crux exige al menos7.000 unidades, aproximadamente25% del volumen
 propio actual; representa una inversión/inventario importante para una firma pequeña frente a
 objetivo de crecimiento20%. No conocemos costo, capacidad, disposición a pagar ni canibalización;
 una cantidad física25% no se compara directamente con crecimiento20% en valor. La presión por
Examen de Grado UC | materia, preguntas y respuestas 262

[pág. 263]
Marketing - versión clara y reordenada
 presupuesto no justifica arriesgar ambos frentes a la vez sin validación.
 Podría probarse presencia acotada y asesoría en un canal nuevo o un lanzamiento profesional por
 especialistas, pero las propuestas no demuestran que el incremento de pedidos sea crecimiento
 rentable y sostenible.
 b) La arquitectura Crux avalada por Redington es razonable, con dos argumentos.
 1. Identidad diferenciada para la promesa superior: usar Crux permite señalar una oferta de
 menor peso, alcance/longitud y tecnología propias, dirigida al profesional, sin convertir toda la línea
 media de$150.000-450.000 en el mismo producto. El precio propuesto$550.000 está sobre la línea
 habitual pero bajo marcas prestigiosas de más$700.000; la marca nueva puede explicar una
 alternativa profesional accesible si el desempeño se verifica. El nombre no prueba por sí solo
 superioridad. 2. El aval transfiere confianza y reduce riesgo de una marca desconocida:
 Redington ya tiene producto, vendedores entrenados, distribuidores y relación con pescadores. Una
 marca respaldada puede aprovechar esa credibilidad para la prueba y conservar coherencia con
 cañas, una extensión cercana de capacidades. Mantener identidadCrux con respaldoRedington
 combina diferenciación y reconocimiento mejor que ocultar todo vínculo o cambiar indistintamente
 el nombre de la línea existente.
 Apoyaría ese diseño de marca, separado de aprobar automáticamente producción mínima/canal. Si
 Crux no entrega la calidad prometida, el aval también puede dañar Redington; y una percepción
 arraigada de gama media puede limitar su credibilidad profesional. Probaría desempeño, precio y
 relato mediante especialistas/lodges antes del compromiso total, midiendo captura nueva y
 canibalización. La arquitectura ayuda a gestionar esas tensiones, no elimina el riesgo económico.
 enero 2019 - pregunta 1 - Crecimiento, premium y ecosistema
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 279-280 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 a) Principal ventaja y desventaja de cada propuesta.
 Propuesta Principal ventaja comercial Principal desventaja comercial
 iPhone de precio medio, más simple Acceder a compradores que desean Canibalizar modelos rentables y
 la marca/ecosistema pero no pueden debilitar el posicionamiento/precio de
 o no quieren pagar el nivel premium; referencia premium. Vender más
 ampliar cobertura frente a una unidades de menor contribución, con
 competencia con más15 modelos complejidad adicional y sin ventaja
 versus seis de Apple. de costos demostrada frente a
 fabricantes chinos, puede incumplir el
 objetivo de margen.
Examen de Grado UC | materia, preguntas y respuestas 263

[pág. 264]
Marketing - versión clara y reordenada
 Propuesta Principal ventaja comercial Principal desventaja comercial
 Capturar premium de Aprovechar marca, diseño y La promoción reduce captura por
 Samsung/Huawei mediante ecosistema existentes para captar unidad en un mercado de reemplazo
 publicidad y promociones clientes que valoran prestaciones y más lento; publicidad no elimina la
 precio alto, manteniendo foco de falta de urgencia para renovar ni
 capacidades y oferta. garantiza suficiente migración desde
 competidores. Puede generar
 compras adelantadas o
 canibalización antes que contribución
 nueva.
 La caída del crecimiento de unidades, penetración sobre65% y renovación de16 a27 meses
 explican por qué no conviene extrapolar expansión pasada. La tabla muestra Huawei de10,2%
 en2017Q3 a14,5% en2018Q3 y Xiaomi de7,5% a9,8%; Apple de12,5% a13,7% en esos trimestres,
 aunque fluctúa entre12% y19,5% durante la serie. Por ello, el relato de presión competitiva no
 autoriza afirmar que Apple perdió cuota en cada comparación. El gráfico de precio promedio
 respalda amplitud de niveles, pero no da márgenes para comparar ambas estrategias.
 b) Alternativa: aumentar valor/contribución por cliente del ecosistema existente.
 Desarrollaría venta cruzada y uso sostenido de accesorios, tablets/relojes y servicios ya incluidos
 en el portafolio: música, almacenamiento, contenidos y pagos, con ofertas que resuelvan
 necesidades reales de quienes ya tienen iPhone. Una mayor base instalada y el85% de accesos a
 internet por smartphone enChile permiten explorar uso/servicios aun cuando la renovación de
 hardware se retrase. No es obligar a cambiar aparato antes de necesitarlo; es ofrecer un beneficio
 complementario durante su vida de uso.
 La propuesta aprovecha relación, compatibilidad y canales existentes, puede generar ingresos
 recurrentes y retención, y no requiere posicionar iPhone como producto barato ni depender
 únicamente de promociones premium. Paquetes transparentes, demostraciones y programas por
 necesidad pueden aumentar adopción si el precio conjunto y la experiencia aportan valor. Servicios
 no son de margen infinito: incluyen infraestructura, derechos, atención y adquisición; accesorios
 también tienen costo y competencia.
 Mediría adopción por cohorte, ingreso/contribución por cliente, retención, canibalización y costo de
 servir, comparando con compras que ocurrirían sin campaña. Priorizaría usos con contribución
 incremental positiva y mantendría una experiencia consistente. Es factible por los
 productos/servicios explícitos del caso, pero no garantiza cumplir2019 sin dimensionar mercado y
 costos.
 enero 2012 - pregunta 1 - Entrada y difusión de nueva categoría
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 88-89 | convocatoria 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Por qué entrar mediante Activia en vez de desplegar todo el portafolio.
 Danone necesita una razón para que el consumidor cambie, en una categoría con penetración
 superior a 95%. Entrar con otro yogur batido indiferenciado la enfrentaría a hábitos, marcas y
 espacio comercial ya ocupados. Activia concentra la propuesta en un beneficio funcional específico
Examen de Grado UC | materia, preguntas y respuestas 264

[pág. 265]
Marketing - versión clara y reordenada
 -bienestar digestivo de la mujer en el caso-, con una marca identificable y posibilidad de mayor valor
 percibido. La tendencia hacia bienestar y productos funcionales hace ese nicho atractivo: los
 funcionales pasan de 4% del volumen en 1995 a 30% en 2011, mientras batidos bajan de 65% a
 40%. Es cambio de mix, no prueba de que cada comprador nuevo abandone otro yogur.
 Un producto enfocado permite concentrar recursos, mensaje, prueba, aprendizaje y distribución
 donde la firma tiene capacidad tecnológica y experiencia. Un posicionamiento claro favorece
 diferenciación y dificulta que el comprador compare solo precios. Aunque dispone de muchas
 marcas, dispersar el lanzamiento puede fragmentar presupuesto y confundir asociaciones antes de
 construir confianza local. Después, el reconocimiento de Activia/Danone facilita entrar gradualmente
 en batidos y griego: es una secuencia de construcción de marca y ampliación, no equivalencia
 automática entre todos los beneficios.
 La participación física de Danone aumenta de 10% en 2009 a 27% en 2011, 17 puntos; Soprole
 baja de 38% a 33% y Colún de 21% a 18%. Eso es consistente con una entrada exitosa en
 participación, pero no demuestra la causalidad de una sola medida. El caso afirma rentabilidad,
 aunque no entrega una cuenta de costos para verificarla. El consumo chileno de 11 kg frente a
 cerca de 30 kg en Europa sugiere oportunidades de frecuencia/mix, sin garantizar que Chile
 alcance ese nivel.
 2. Por qué invertir más en publicidad y apoyo en punto de venta.
 Un entrante necesita superar baja familiaridad e incertidumbre y alcanzar disponibilidad frente a
 marcas instaladas. La publicidad explica el beneficio, construye asociaciones y hace reconocible el
 envase; el punto de venta facilita que la intención se convierta en prueba. Comprar
 ubicaciones/exhibición evita que la marca nueva quede invisible en un canal donde se decide la
 compra. Ambos instrumentos son complementarios: awareness sin stock no genera experiencia y
 stock sin conocimiento puede no generar elección.
 La difusión requiere conocimiento, interés/evaluación, prueba y recompra. El «Desafío 14 Días»
 traduce el beneficio en una pauta de uso y una invitación concreta a probar, apoyada por rostros y
 comunicación repetida. El caso informa más de $3.000 millones y 5.978 GRP en tres meses. Los
 GRP agregan alcance y frecuencia de exposición: no son personas únicas, compradores ni efecto
 causal. La comparación de share of voice de Activia con todo Next muestra concentración de
 recursos en una promesa; no garantiza proporcionalidad entre inversión y ventas.
 La inversión inicial puede construir un activo que apoye categorías futuras, educar sobre un atributo
 menos conocido y acelerar adopción antes de respuestas como Next Tránsito+. Danone también
 dispone de escala para financiar ese proceso. Debe comprobar si los beneficios prometidos son
 creíbles y la experiencia induce repetición; no presentar como verdad clínica todas las afirmaciones
 del envase. Evaluaría prueba incremental, repetición, distribución efectiva, contribución y
 asociaciones, distinguiendo crecimiento de la subcategoría de captura de marca. La gran inversión
 se explica por el objetivo y la etapa competitiva, no por una regla de que gastar más siempre gana.
 enero 2022 - pregunta 1 - Extensión de línea/marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 354-355 | convocatoria
 1
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 265

[pág. 266]
Marketing - versión clara y reordenada
 Respuesta modelo desarrollada (no oficial)
 a. Tres argumentos en contra de cada propuesta. El activo central de NotCo es usar Giuseppe
 para desarrollar sustitutos de alimentos de origen animal que reproduzcan sabor, textura y
 funcionalidad. Su público incluye vegetarianos y alérgicos, pero también consumidores omnívoros.
 El crecimiento de la categoría no valida cualquier extensión de productos: se debe conservar una
 razón clara para elegir la marca.
 En contra de Rúcula: ampliar a alimentos vegetales saludables, orgánicos y con menos
 nutrientes críticos.
 1. Debilita la coherencia del posicionamiento. “NOT” permite reconocer un reemplazo de una
 categoría animal: NotMilk, NotMayo o NotBurger. Pasta, cereales o bebidas que ya son vegetales
 no ofrecen ese contraste. Además, algunos productos actuales tienen calorías, azúcar, sodio o
 sellos; convertir toda la marca en una promesa de alimentación saludable crea expectativas que su
 portafolio no satisface uniformemente. Que un alimento sea vegetal no implica que sea bajo en
 azúcar o calorías. 2. La ventaja tecnológica no se traduce automáticamente a esas categorías.
 La imitación funcional del alimento animal resuelve un problema difícil y relevante para el cliente. En
 productos que ya son vegetales, habría que demostrar otra superioridad frente a marcas
 consolidadas de pasta o cereales. Ser orgánico, reducir gluten o evitar sellos requiere decisiones
 reales de formulación, abastecimiento y certificación, según corresponda; no basta extender el
 nombre ni asumir que Giuseppe garantiza todos esos atributos. 3. Dispersa recursos comerciales
 y de desarrollo. NotCo tiene todavía un surtido limitado: cuatro helados, tres leches y cinco
 mayonesas según el caso. Expandirse a muchas categorías nuevas puede sacrificar oportunidades
 en los sustitutos que ya conoce. El crecimiento estadounidense de productos vegetales -27% y
 US$7.000 millones en 2020- respalda el atractivo de una categoría amplia, pero no demuestra
 demanda rentable para cada nueva pasta o bebida saludable de NotCo. Habría que medir
 potencial, disposición a pagar y contribución incremental de cada lanzamiento.
 En contra de Rábano: más sabores, formatos, sustitutos animales y canal HORECA.
 1. Aumenta complejidad y riesgo de ejecución. NotPork, NotFish, NotCream y NotCheese
 exigen reproducir funciones y sensaciones distintas, además de asegurar estabilidad y calidad.
 Sumados a nuevos formatos y sabores, elevan costos de investigación, producción, inventario y
 control. Tener un algoritmo patentado no elimina las restricciones de tiempo, capacidad ni la
 necesidad de validar cada producto con usuarios. 2. Parte de la proliferación puede canibalizar
 ventas. Más variedades no equivalen a más consumidores ni a espacio adicional en Whole Foods o
 Starbucks. Variantes de leche o helado pueden repartirse la misma demanda y disminuir rotación
 por SKU. Se debe priorizar sustitutos con una ocasión de uso o un beneficio claramente distinto, y
 evaluar ventas netas de sustitución interna frente a sus costos de complejidad. 3. HORECA
 requiere una propuesta y capacidades específicas. Restaurantes, hoteles y cafeterías compran
 regularidad de abastecimiento, formatos profesionales, rendimiento por porción y consistencia
 culinaria. Sus condiciones comerciales, capacitación y sensibilidad al costo pueden diferir de las del
 consumidor final. Entrar con el mismo surtido y precio minorista puede producir márgenes bajos o
 fallas de servicio. El canal es una oportunidad, pero no una expansión automática por el solo hecho
 de que el producto guste en supermercados.
 b. Estrategia de marca para cada propuesta. Para Rúcula usaría una marca distinta para la
 oferta saludable, con una promesa específica y verificable. La empresa podría respaldarla de
Examen de Grado UC | materia, preguntas y respuestas 266

[pág. 267]
Marketing - versión clara y reordenada
 manera discreta si su reputación tecnológica aporta confianza, pero evitaría trasladar a todo NotCo
 una promesa nutricional incompatible con productos existentes. Esta arquitectura separa
 asociaciones y permite competir por salud u organicidad con identidad propia; su costo es construir
 reconocimiento y duplicar parte de la comunicación. No daría por acreditado un nombre o una
 certificación no presentes en el caso.
 Para Rábano mantendría una marca maestra NOT con descriptores de categoría, como las
 extensiones planteadas NotFish o NotCheese. Conservan la lógica del reemplazo animal y
 aprovechan reconocimiento y confianza: el consumidor entiende qué sustituye cada producto. Los
 formatos profesionales pueden llevar un descriptor de uso para HORECA conservando la misma
 promesa central, siempre que la experiencia sea consistente. Aquí el riesgo es el contagio
 reputacional entre productos y la confusión por demasiadas variantes, por lo que la selección del
 portafolio y la calidad son requisitos de la arquitectura. Las estrategias de marca no reemplazan la
 validación comercial de las propuestas.
 agosto 2022 - pregunta 1 - Formato low-cost y marcas propias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 364-365 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Tres razones que justifican Super10 en el portafolio de SMU.
 1. Atiende una combinación de necesidad y ocasión de compra insuficientemente cubierta.
 Super10 se dirige al consumidor final que necesita reponer una canasta familiar a precios bajos y
 con rapidez. No equivale a Alvi, que combina clientes comerciales y finales con compras por seis o
 doce unidades, ni a Mayorista10, orientado a comerciantes. Tampoco necesita la amplitud de
 Unimarc: aproximadamente 1.300 productos frente a un promedio de 3.000 y hasta 6.000. La
 selección de productos de alta rotación, un líder y alternativas propias por categoría, hace viable
 una misión de compra distinta. El beneficio para el cliente es ahorro de dinero y esfuerzo, a cambio
 de menor variedad. 2. Completa la cobertura competitiva con un posicionamiento reconocible.
 aCuenta representa una alternativa cercana de bajo precio y marcas propias; Lider ofrece el
 formato hipermercado y Cencosud combina Jumbo, Santa Isabel y propuestas de conveniencia.
 Oxxo, OK Market o Spid atienden principalmente rapidez y proximidad, con otra amplitud de
 canasta. Super10 permite defender y captar la misión de compra económica sin convertir todos los
 Unimarc en tiendas de surtido reducido. Una identidad de formato separada ayuda a comunicar esa
 diferencia y evitar expectativas de supermercado tradicional. El éxito requiere atraer clientes de
 rivales o nuevas ocasiones; trasladar clientes internos sin mayor contribución no prueba crecimiento
 del grupo. 3. El diseño operacional respalda la promesa de precio. El surtido corto concentra
 compras y rotación; la mercadería se repone directamente en sala, sin bodega, y el stock queda
 exhibido. Góndolas de hasta 1,65 metros, precios fáciles de identificar y cajas rápidas reducen
 fricción. Una proporción de 40-50% de productos propios, frente al 15% informado para otros
 formatos, puede aportar control del surtido y del costo de adquisición. La cobertura de SMU en 16
 regiones y sus marcas transversales permiten aprovechar capacidades existentes. Son
 mecanismos de eficiencia, no prueba de que el margen neto esté asegurado: reposición, calidad y
 quiebres deben controlarse.
Examen de Grado UC | materia, preguntas y respuestas 267

[pág. 268]
Marketing - versión clara y reordenada
 2. Tres desventajas de aumentar las marcas propias.
 1. Puede reducir el atractivo para clientes que buscan marcas conocidas. El consumidor no
 elige siempre por precio: confía en sabor, calidad o desempeño de su marca habitual. Limitarse a
 una marca líder y productos propios puede excluir preferencias, y el ahorro percibido debe superar
 el costo de experimentar. Nuestra Cocina, Smart Clean, Fundo Río Alegre y Amada Masa requieren
 una calidad consistente que justifique su elección y la promesa económica de Super10. Una falla
 puede afectar a SMU porque estas marcas son transversales a sus formatos. La mitigación es
 validar calidad, informar claramente la equivalencia de uso y ofrecer una alternativa reconocida
 donde la lealtad sea elevada. 2. Debilita parte del aporte de los proveedores de marcas
 nacionales. Reducir su espacio puede disminuir disposición a financiar promociones, exhibiciones
 o innovación, y limitar acceso a lanzamientos demandados. También cambia el equilibrio de
 negociación: SMU gana una alternativa propia, pero pierde parte del apoyo que ayuda a generar
 tráfico y diferenciación. No corresponde asegurar represalias de proveedores; se trata de un riesgo
 comercial que debe evaluarse por categoría. Mantendría marcas líderes que aportan demanda,
 comparando la contribución total y la rotación del espacio, no sólo el margen porcentual del
 producto propio. 3. Traslada responsabilidades y costos al retailer. El nombre propio implica
 responder por especificaciones, selección de fabricantes, seguridad, consistencia, reposición y
 retiros de productos. Un margen bruto más alto puede quedar absorbido por controles, merma,
 inventario o fallas de suministro. El esquema sin bodega exige entregas frecuentes y fiables: exhibir
 todo el stock no equivale a tener inventario cero. También debe vigilarse que precios distintos de las
 mismas marcas transversales no confundan al cliente o desplacen ventas de otros formatos sin
 compensación. Establecería estándares, proveedores alternativos y seguimiento de margen
 después de estos costos y de la canibalización.
 El objetivo no es alcanzar 50% de productos propios por sí mismo, sino ofrecer una canasta
 confiable y competitiva cuya contribución total sostenga el formato. La amplitud menor y la mayor
 presencia propia funcionan si ambas sirven a la misión de compra elegida.
 agosto 2017 - pregunta 1 - Guerra de precios y diferenciación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 240-241 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Dos razones para no mantener igualación permanente de precios.
 1. Incompatibilidad con la economía del servicio: xyzpin mantiene90 locales amplios y personal
 especializado que informa/demuestra productos complejos. Una tienda online sin esos recursos o
 Walmart con escala puede sostener precios menores. Igualar toda oferta permanentemente
 conserva el costo de asesorar mientras cede su precio, incluso en compras que habrían ocurrido sin
 rebaja. Vender más no garantiza contribución suficiente para cubrir la red. La política no corrige la
 causa del showrooming: otros capturan la compra después de que xyzpin financia información. 2.
 Debilita la diferenciación y facilita presión competitiva: enseña a evaluar la oferta solo por el
 producto idéntico/precio, aunque instalación, respaldo o asesoría sean valiosos. Rivales pueden
 bajar precios que xyzpin debe seguir; el cliente puede usar siempre la amenaza online. Se erosiona
 disposición a pagar por servicio y se inicia una carrera donde la firma no tiene ventaja de costos
Examen de Grado UC | materia, preguntas y respuestas 268

[pág. 269]
Marketing - versión clara y reordenada
 demostrada. Comparar oferta debe incluir condiciones, disponibilidad y servicio, no solo una cifra
 mostrada en el teléfono.
 Una igualación selectiva podría ser útil para una misión/categoría concreta si es rentable; la
 objeción es a hacerla permanente y transversal sin economía ni diferenciación.
 2. Elegiría la segunda estrategia: servicio adicional financiado de forma comprobada.
 Reducir tamaño de tiendas: ventajas: bajar arriendos, dotación, inventario y espacio de bodega;
 liberar capital y permitir precios menores cuando esos costos efectivamente se evitan. Desventajas:
 puede restar exhibición, prueba y asesoría que distinguen a xyzpin; menor stock puede empeorar
 disponibilidad, desplazando todavía más compras online. Reconfigurar locales tiene costos de
 transición y no asegura igualar escala/costo de Walmart. Es defendible en tiendas
 sobredimensionadas, pero una reducción uniforme puede eliminar la razón para visitarlas.
 Mejorar instalación y posventa: ventajas: agrega un beneficio difícil de comparar solo por precio y
 reduce incertidumbre/costo de resolver fallas de productos complejos. La instalación domiciliaria o
 revisión/reparación en tienda conecta demostración con uso, da una razón para completar la
 compra allí y aprovecha capacidades existentes. Los proveedores también pueden valorar
 exhibición y venta asesorada; su aporte puede financiar parte del servicio que otros canales
 aprovechan sin pagar.
 Desventajas: instalación/reparación exige personal, logística, capacidad, coordinación y
 cumplimiento; prometer gratis no elimina el costo. Los proveedores pueden rechazar el pago o
 trasladarlo a precios, por lo que no se considera financiamiento garantizado solo porque la práctica
 sea común. El cobro podría reducir cooperación o surtido si no representa valor incremental. Una
 posventa lenta dañaría la confianza más que el beneficio prometido.
 Implementaría primero en categorías/locales donde el cliente valore el servicio, pactando aportes y
 obligaciones antes de anunciarlo. Mediría conversión tras asesoría, contribución neta después de
 servicio y aportes, tiempos, fallas/reclamos y repetición; coordinaría compra física/online propia
 para que el cliente pueda completar dentro de xyzpin. El más70% que usa showrooming señala
 relevancia del problema, no proporción de ventas perdidas automáticamente. Conservaría ajustes
 selectivos de espacio donde no dañen experiencia, subordinados a esa propuesta diferenciadora.
 agosto 2023 - pregunta 1 - Guerra de precios y posición
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 390-391 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. ¿Debe Tesla continuar la guerra de precios en China? No mantendría una guerra general y
 reiterada como estrategia de crecimiento. Admitiría promociones acotadas para resolver inventario
 o capacidad ociosa, con una evaluación de contribución incremental y una fecha de revisión. La
 diferencia es que una rebaja táctica responde a una situación medible; una escalada permanente
 convierte el precio en el principal criterio de elección. Tres argumentos apoyan esta decisión:
 1. La competencia china limita la duración de una ventaja obtenida sólo por precio. Hay cerca
 de 100 fabricantes y más de 300 modelos, con marcas chinas superiores al 80% del mercado. BYD
 tiene 30% frente al 7% de Tesla y está integrado en insumos y partes. Los rivales pueden responder
Examen de Grado UC | materia, preguntas y respuestas 269

[pág. 270]
Marketing - versión clara y reordenada
 a los descuentos, reduciendo el aumento neto de cuota que Tesla obtiene por cada sacrificio de
 margen. El exceso de capacidad y la construcción de plantas agravan esa presión. Las rebajas de
 competidores de hasta 40% describen una dinámica donde tener costos bajos no asegura ser el
 único que puede sostener precios menores. 2. El crecimiento de volumen debe compensar la
 pérdida de contribución. Los costos principalmente fijos hacen atractivo utilizar plantas, y más de
 la mitad de la producción de Tesla se realiza en China. Sin embargo, la rebaja superior a 25% llevó
 sus márgenes operacionales cerca de la mitad de su nivel previo cercano a 20%. El beneficio
 depende de (Q(P-v)-F, no del volumen aislado. Aumentar ventas puede ayudar a cubrir costos fijos
 si el precio supera el costo variable; no garantiza una mejora del beneficio total después de bajar
 precio sobre todas las unidades. El caso no informa costo variable, elasticidad ni contribución por
 modelo, por lo que no permite demostrar que otra rebaja sea rentable. 3. Las rebajas repetidas
 pueden deteriorar valor y disposición a pagar. Tesla combina una imagen premium y de calidad
 con eficiencia de costos. Convertir esa oferta en descuentos cada vez mayores debilita el precio de
 referencia, puede generar espera de nuevas rebajas y malestar en compradores recientes.
 Además, una economía débil y el término esperado de subsidios hacen incierta la demanda
 incremental. Defendería beneficios diferenciados y comunicaría claramente el alcance temporal de
 las promociones, en vez de enseñar al mercado que toda compra debe postergarse hasta el
 siguiente recorte.
 La recomendación reconoce el costo de no competir en precio: Tesla podría perder ventas en el
 corto plazo. Lo compensaría con promociones selectivas por inventario, modelo y ocasión, pruebas
 de elasticidad y seguimiento de participación y beneficio. No recomiendo ignorar el precio, sino
 evitar que la respuesta automática a cada rival destruya la rentabilidad y la diferenciación.
 2. Tres ventajas potenciales de iniciar una guerra de precios en Estados Unidos y Europa.
 Son ventajas posibles en el escenario del caso, no una prueba de que una rebaja de cualquier
 tamaño convenga.
 1. Aprovechar una estructura de costos favorable frente a fabricantes tradicionales. Tesla
 utiliza montaje simple, plantas diseñadas para vehículos eléctricos, pocos modelos -dos concentran
 más del 80% de la producción-, venta directa y poca publicidad. Puede trasladar parte de esa
 eficiencia al precio sin soportar los mismos costos de reconversión, concesionarios o surtido de
 algunos rivales. Esto aumenta la relación beneficio/precio para el comprador y presiona a
 competidores menos eficientes. Hay que conservar contribución positiva y calcular cuánto margen
 queda después de la rebaja. 2. Ampliar adopción y aprovechar escala antes de que otros
 consoliden su oferta. El mercado mundial superó 10 millones de vehículos eléctricos, creció 55%
 y alcanzó 13% de las ventas en 2022. Un precio de entrada más accesible puede convertir
 interesados en compradores y ampliar el segmento atendido por Tesla, utilizando capacidad y
 repartiendo costos fijos entre más unidades. En Estados Unidos parte de una cuota de 50%, y en
 Europa de 15%: hay oportunidades y situaciones competitivas distintas, por lo que los efectos no
 deben suponerse idénticos. Más volumen sólo es una ventaja económica si su contribución
 adicional compensa el menor margen sobre ventas existentes. 3. Reforzar su posición mientras
 la expansión china enfrenta barreras locales. El caso describe barreras arancelarias y ausencia
 de subsidios de compra occidentales para vehículos fabricados en China, mientras Tesla cuenta
 con plantas estadounidenses y alemanas. Esa presencia puede darle margen competitivo frente a
 importadores al bajar precios y ampliar base de clientes antes de que éstos instalen producción
 local. No significa que toda unidad Tesla sea elegible para subsidios ni que las barreras sean
Examen de Grado UC | materia, preguntas y respuestas 270

[pág. 271]
Marketing - versión clara y reordenada
 permanentes. La ventaja es relativa al lugar de producción, las reglas del escenario y la respuesta
 de rivales, y debe evaluarse por mercado.
 agosto 2010 - pregunta 1 - Investigación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 46-47 | convocatoria 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 El problema es elegir cómo recuperar rentabilidad después de un deterioro operativo, no
 simplemente estudiar si al consumidor le gusta el zapato. Ventas caen de US$847,35 millones
 en2007 a US$610 millones en2009, aproximadamente28,0%. El margen bruto pasa de58,73%
 a40,0%, mientras gastos de administración/ventas sobre ingresos suben de42,47% a62,30%. El
 margen operativo cambia de16,26% a-22,30%. La tabla muestra presión de margen y gasto
 además de menor venta; no identifica por sí sola cuánto obedece a recesión, moda o decisiones
 internas.
 1. Camino del CEO: otros materiales/calzado y categorías complementarias.
 Argumentos a favor. La marca ya es conocida y tiene canales propios, kioscos, minoristas
 especializados y logística rápida. Extender ocasiones de uso y estaciones puede permitir vender a
 clientes que no usarían la zapatilla original, aumentar compra por cliente y distribuir costos de
 marca/red en una base mayor. Calzado de cuero/lona, ropa o accesorios podrían reducir
 dependencia de un modelo muy durable y de una moda puntual, generar ventas cruzadas y abrir
 productos de mayor contribución. Además, la patente vence en2014 según el caso: una identidad y
 experiencia de marca más amplia podrían reducir dependencia de la protección tecnológica.
 Ninguno de esos beneficios demuestra que los nuevos productos tendrán mayor margen neto.
 Riesgos. Reconocimiento no garantiza credibilidad en calzado de vestir, deporte o ropa. Allí
 compite con firmas de diseño/materiales diferentes y podría diluir asociaciones de comodidad y
 funcionalidad. La expansión exige capacidades, proveedores, tallas, temporadas, inventarios y
 canales nuevos; más SKU pueden aumentar capital, descuentos por sobrantes y gasto cuando ya
 hay pérdidas. Abandonar Croslite debilita la diferenciación que sustentó el éxito y la productividad
 de foco. Los canales que venden bien un zapato especializado no necesariamente venden una
 marca de moda completa. La diversificación puede repartir demanda, pero también dispersar
 atención y recursos.
 2. Camino del asesor: profundizar Croslite y nuevos segmentos cercanos.
 Argumentos comerciales a favor. Aprovecha beneficios probados de ligereza, comodidad,
 resistencia y atributos antideslizantes/antiolores, así como conocimientos de fabricación y
 reposición. Innovar en mujeres, niños y hombres amplía perfiles sin cambiar íntegramente la
 competencia central. Profesionales que permanecen de pie tienen una necesidad funcional menos
 dependiente de moda; modelos apropiados y una propuesta demostrable pueden ampliar uso
 durante el año. La especialización y la velocidad de abastecimiento apoyan disponibilidad y
 relaciones con minoristas; la marca se vuelve una promesa funcional consistente, más que un único
 diseño.
 Riesgos. Concentrarse conserva exposición a un material, tecnología y asociación estética.
 Patente próxima a vencer y copias pueden erosionar diferenciación; la durabilidad limita frecuencia
Examen de Grado UC | materia, preguntas y respuestas 271

[pág. 272]
Marketing - versión clara y reordenada
 de reposición. Versiones parecidas pueden canibalizarse y multiplicar inventario. Un beneficio
 apreciado por hogares/playa no acredita seguridad o adecuación en todo trabajo profesional: habría
 que comprobar requisitos, desempeño y aceptación. La demanda del modelo podría haber sido
 parcialmente una moda, por lo que foco por sí solo no corrige una base de costos
 sobredimensionada.
 Una decisión razonada prioriza saneamiento de inventario/gastos y pruebas de segmentos
 funcionales cercanos, mientras evalúa adyacencias acotadas con evidencia de ajuste de marca y
 contribución. Debe comparar inversión, costo de servir, demanda incremental y riesgo de cada
 opción; el caso pide argumentos y riesgos de ambas, no declarar una ganadora sin datos.
 agosto 2024 - pregunta 3 - Investigación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 419-420 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Cuatro factores para eliminar una categoría o marca del portafolio. Genomma Lab redujo
 sus marcas de 62 a cerca de 30 y los UPC de 430 a 211, mientras sus ventas crecieron más de
 15% anual. La concentración puede liberar recursos, pero no demuestra que reducir toda variedad
 produzca crecimiento. Tampoco basta eliminar lo que vende menos o conservar todo lo rentable.
 1. Atractivo futuro del mercado y espacio competitivo. Evaluaría crecimiento, necesidades no
 atendidas, intensidad de competencia y capacidad para ganar cuota. Cuidado personal crece
 menos de 3% anual y OTC menos de 2%, mientras isotónicas muestra mayor dinamismo. Aun en
 una categoría lenta puede haber un nicho atractivo o una marca con crecimiento propio. Las
 previsiones de mercado son escenarios, no ventas garantizadas; deben compararse con la posición
 de la empresa en cada mercado y la sensibilidad a cambios en consumidores y competidores. 2.
 Rentabilidad económica incremental y costo de oportunidad. Una marca rentable puede
 consumir recursos que generarían más valor en otra categoría. Compararía contribución después
 de marketing, distribución, inventarios, devoluciones y complejidad; distinguiría costos evitables de
 gastos comunes que seguirán existiendo después de eliminarla. Incluiría el valor de vender la
 marca y los costos de salida. El ranking de ventas no permite este cálculo: Suerox encabeza la
 tabla, pero faltan márgenes, inversión y capital por marca. 3. Ajuste estratégico y capacidades
 diferenciadoras. Revisaría si la marca sirve al foco elegido, aprovecha tecnología, formulación,
 promoción y relaciones comerciales, y si la empresa puede crear una ventaja defendible en ella.
 Mantener negocios fuera del foco sólo porque son rentables puede distraer gestión; venderlos
 puede liberar recursos para categorías donde Genomma crea más valor. Debe comprobarse que
 las capacidades son transferibles y no abandonar activos necesarios para la propuesta futura. 4.
 Efectos sobre el conjunto del portafolio, clientes y canales. Una marca pequeña puede aportar
 clientes, complementar compras, abrir acceso a distribuidores o equilibrar riesgos. Su eliminación
 puede transferir consumidores a una marca propia más fuerte o perderlos a un competidor. Mediría
 sustitución interna, cobertura de necesidades, valor de marca y condiciones comerciales que
 cambiarían al retirar la categoría. Haría la transición del surtido y la comunicación con el canal de
 manera ordenada, incluyendo compromisos existentes.
 2. Evaluación crítica de las tres propuestas para Suerox.
Examen de Grado UC | materia, preguntas y respuestas 272

[pág. 273]
Marketing - versión clara y reordenada
 Reducir publicidad donde ya tiene éxito. No lo haría sólo porque vende bien. Suerox creció 42%
 en volumen en 2023, presenta CAGR de 44% desde 2018 y 4,2% de participación mundial; ha
 entrado en más de diez mercados. Tiene espacio para captar consumidores y defender sus
 asociaciones, y una categoría en crecimiento atrae competidores. Parte de su éxito puede depender
 del soporte actual: recortarlo sin medirlo confunde resultado con causa. Sí reasignaría inversión de
 medios o mercados con baja contribución incremental a otros con mayor oportunidad, distinguiendo
 notoriedad, captación y recordación. Probaría recortes acotados con comparación y observaría
 cuota, ventas netas y contribución, no sólo ahorro inmediato.
 Aumentar de 6 a 15 UPC. Son nueve códigos adicionales y un aumento de 150%; no equivalen
 automáticamente a nueve necesidades nuevas. Sabores y formatos pueden atraer usos distintos,
 facilitar prueba, consumo individual o familiar y mejorar cobertura. Pero también fragmentan
 rotación, elevan inventario y desplazan ventas del surtido actual, con costos productivos y espacio
 limitado. La simplificación global no prohíbe expandir una marca prioritaria: exige demostrar que
 cada extensión agrega contribución y diferenciación. Priorizaría necesidades identificadas, probaría
 pocas variantes y retiraría las que sólo reparten demanda existente.
 Aumentar descuentos a canales. Pueden incentivar distribución, exhibición y prueba, pero una
 venta al distribuidor no asegura consumo final ni una rebaja efectiva al consumidor. El descuento
 puede quedarse en el margen del canal, adelantar pedidos o volver al intermediario dependiente de
 promociones; además, erosiona contribución y precio de referencia. Lo ligaría a objetivos
 observables de cobertura, exhibición y venta final, con duración definida y comparación contra una
 base sin promoción. La alternativa comercial puede ser apoyar información y experiencia del
 producto, no aumentar descuentos permanentemente. En una marca de fuerte crecimiento
 conviene proteger demanda de marca y negociación, además de empujar inventario al canal.
 enero 2013 - pregunta 1 - Marcas propias y posicionamiento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 115-116 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Tres factores de marketing que podrían explicar el deterioro observado.
 La tabla muestra participación de mercado de 30% a 25% y EBITDA sobre ventas de 7,2% a 6,0%
 entre2010 y2012, mientras la venta total sube de US$4.300 a US$4.600 millones. EBITDA absoluto
 cae de US$309,6 a US$276 millones. Es evidencia de deterioro relativo y operativo; no identifica
 por sí sola que la causa sea la estrategia de marca propia. Tres mecanismos plausibles son:
 1. Pérdida de atractivo del surtido y tráfico: si las marcas propias sustituyen marcas tradicionales
 valoradas por calidad/confianza, algunos compradores pueden trasladar su cesta a competidores.
 El caso identifica percepción de menor calidad entre consumidores de marcas tradicionales. Ganar
 mezcla de marca propia dentro del local no asegura ganar clientes para la cadena; una oferta de
 precio puede ser insuficiente para consumidores que priorizan calidad o variedad. 2.
 Canibalización y economía de la mezcla: un mayor margen por producto propio no garantiza
 mayor margen del conjunto si sustituye ventas, obliga a bajar precios o deja crecer menos
 categorías rentables. La utilidad bruta total se mantiene alrededor de US$356,9 millones en2010 y
 US$358,8 millones en2012, aunque aumenta la facturación. La utilidad bruta aproximada de propios
Examen de Grado UC | materia, preguntas y respuestas 273

[pág. 274]
Marketing - versión clara y reordenada
 pasa de US$49,45 a US$99,38 millones; por diferencia, la de las demás ventas baja de US$307,45
 a US$259,42 millones. Esto señala que hay que analizar la cesta completa y sus costos, no
 celebrar la división aislada; tampoco prueba por sí solo quién causó el cambio. 3. Menor apoyo de
 proveedores y respuesta competitiva: los aportes promocionales/publicitarios bajan de16%
 a14,5% de ventas, de US$688 a US$667 millones. Conflicto de canal puede reducir cooperación,
 innovación/exhibición o recursos para atraer compradores; rivales pueden mejorar surtido/precios.
 Menos apoyo y mayor costo de gestionar propios presionan resultados. No se puede sumar
 mecánicamente cada fila para explicar el EBITDA sin conocer su tratamiento contable.
 La conclusión absoluta del analista es demasiado fuerte: faltan mercado por categoría, precios,
 tráfico, costos y contrafactual. La cadena crece menos que el mercado implícito en las cuotas; eso
 puede deberse también a expansión rival o factores externos. El análisis propone mecanismos
 contrastables, no causalidad demostrada.
 2. Atractivo del plan premium desde la conducta del segmento objetivo.
 Es potencialmente atractivo para ABC1/C2 que valoren calidad y sean sensibles al precio, pero su
 ejecución enfrenta una barrera distinta de la de básicos. Descuento de10-15% puede ofrecer valor
 si desempeño, sabor, seguridad, diseño y experiencia son creíbles. La confianza en el
 supermercado ayuda a la prueba y la ubicación visible reduce costo de búsqueda; no reemplaza
 evidencia de calidad.
 En cosmética, vino, chocolates o fiambrería, marca, riesgo percibido, simbolismo y gusto pueden
 pesar más que en sal o azúcar. La asociación existente de marca propia con menor calidad puede
 impedir transferirla a una categoría premium. Que el proveedor fabrique también marcas
 tradicionales no asegura idéntico producto ni que el cliente lo sepa. «Todos los grupos etarios» no
 es un segmento homogéneo: conviene separar necesidades/ocasiones y credibilidad por categoría.
 Lanzar más de500 productos en tres años y publicitarlos solo en locales/catálogos puede conseguir
 prueba entre visitantes actuales, pero tiene alcance limitado para atraer quienes compran en otra
 cadena. Reducir marcas tradicionales puede restar variedad y empujar a compradores leales hacia
 rivales. Recomiendo pilotos por categoría, prueba de producto, arquitectura de marca clara y
 comunicación de calidad comprobable; medir cesta incremental, repetición, percepción, tráfico y
 contribución después de apoyo perdido. El plan será atractivo si convierte «premium accesible» en
 una experiencia creíble, no simplemente en precio menor y mejor ubicación.
 enero 2024 - pregunta 1 - Marketplace y estrategia de marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 403-404 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 a. Cuatro factores para evaluar el ingreso al marketplace de Falabella.
 1. Acceso a clientes pertinentes y ventas incrementales. Cannondale ofrece modelos de
 $6.499.990 y $5.499.990 a compradores que privilegian batería y motor por sobre precio. Falabella
 puede facilitar su descubrimiento: posee 34% de las ventas online del caso, frente a 24% de
 Mercado Libre, y más de 50% de compradores online inicia su búsqueda en un marketplace. Su
 público medio y medio alto y su financiamiento podrían acercar nuevos compradores a una compra
Examen de Grado UC | materia, preguntas y respuestas 274

[pág. 275]
Marketing - versión clara y reordenada
 de alto valor. Pero estas cifras no son participación de bicicletas ni garantizan demanda para
 Cannondale. Hay que estimar cuántos compradores nuevos valoran su propuesta y cuántos sólo
 trasladarían allí una compra que ya harían en sus canales actuales. 2. Contribución económica y
 capital de trabajo. Marketing calcula un margen operacional 15% menor que en los canales
 actuales. Deben incluirse comisión, publicidad, preparación, entrega, devoluciones y el
 financiamiento de los 45-60 días hasta la liquidación. No se debe traducir “15% menor” en 15
 puntos porcentuales sin aclarar su definición. Compararía contribución total incremental con la
 pérdida de margen de ventas canibalizadas y la necesidad de financiar inventario y cuentas por
 cobrar. Más volumen con menor margen unitario puede convenir, pero sólo si compensa estos
 costos y no reduce el beneficio total. 3. Compatibilidad con la red y el posicionamiento. El canal
 propio representa 60% de las ventas y los distribuidores exclusivos el 40%. Ingresar en una
 plataforma multimarcas altera esa distribución y puede afectar el incentivo de distribuidores para
 exhibir, asesorar o dar servicio. La existencia de cuatro marcas con precios semejantes sugiere que
 la categoría puede tener compradores, pero no garantiza que su imagen premium se conserve.
 Definiría el papel del marketplace como captación y compra conveniente, articulado con atención
 técnica de la red; evaluaría reacciones y acuerdos con los distribuidores antes del lanzamiento. 4.
 Capacidad y control de la experiencia de compra. Batería, motor, ajuste y posventa son
 aspectos relevantes en una bicicleta cara. Cannondale debe garantizar información útil y
 cumplimiento de stock, entrega y plazos, porque una falla puede atribuirse a la marca. Falabella
 decide ubicación y exige fotografías estándar, lo que restringe parte de la presentación. En cambio,
 el precio público lo fija Cannondale: es incorrecto afirmar que la plataforma se lo impone. Se deben
 comprobar qué información adicional, contacto y derivación a servicio permite la plataforma, y
 acordar procedimientos para reclamos y devoluciones.
 Estos factores permiten decidir mediante un piloto acotado de los dos modelos, con metas de
 contribución incremental y satisfacción. No permiten aceptar automáticamente por liderazgo del
 portal ni rechazar automáticamente por el menor margen porcentual.
 b. Tres riesgos principales para la estrategia de marca.
 1. Dilución de la diferenciación premium. La búsqueda por precio y la fotografía estándar ponen
 a Cannondale junto a muchas alternativas. Si el cliente no entiende su batería, motor, rendimiento y
 respaldo, puede percibirla como una bicicleta cara intercambiable con otras. Mantendría contenidos
 y razones de compra coherentes con su posicionamiento y evitaría depender de descuentos.
 Igualar precios entre canales no elimina este riesgo perceptual. 2. Contagio de una experiencia
 de servicio deficiente. Retrasos, información insuficiente, daños o conflictos de garantía pueden
 reducir confianza y asociaciones de calidad, aunque parte de la operación pertenezca al
 marketplace. La marca debe asegurar una promesa realizable, responsables identificables y
 continuidad hacia atención especializada. Mediría satisfacción y reclamos de ese recorrido antes de
 expandirlo; el prestigio del portal no sustituye el control del servicio de Cannondale. 3. Pérdida de
 exclusividad y debilitamiento de sus embajadores comerciales. Sus distribuidores venden
 exclusivamente Cannondale y refuerzan conocimiento, confianza y una experiencia especializada.
 Si perciben que sólo asesoran ventas que se cierran en una plataforma general, pueden reducir
 inversión y recomendación. Ello afecta la marca además del volumen del distribuidor. Acordaría
 funciones de entrega, asesoría y servicio, incentivos coherentes y una política transparente de
 promociones; preservaría la experiencia que hace creíble la propuesta premium.
Examen de Grado UC | materia, preguntas y respuestas 275

[pág. 276]
Marketing - versión clara y reordenada
 enero 2014 - pregunta 1 - Nuevo producto, posicionamiento y canibalización
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 138-139 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 a) Qué debe lograr Life y de dónde puede venir volumen incremental.
 Debe construir una razón relevante y diferenciada para elegir una Coca-Cola con sabor
 satisfactorio, menos calorías que Regular y un endulzante percibido como natural. No basta decir
 «Stevia» o añadir otra variante: el comprador tiene que reconocer el beneficio, confiar en él y
 preferirla frente a sus alternativas. Life tiene36 calorías por200cc y60% menos que Regular, pero no
 es cero calorías como Light/Zero. Se debe distinguir claramente esa combinación, sin prometer
 equivalencia nutricional con otras bebidas ni superioridad de salud por naturalidad.
 La tabla muestra que «no engorda» pesa16%, bajas calorías10% y quitar la sed14%; naturalidad
 del producto4% y del endulzante3%. La diferenciación natural aislada atiende solo parte de la
 evaluación. Regular tiene nota0 en «no engorda» y3 en bajas calorías; Light obtiene7 en ambos,
 pero5 en sabor frente a7 de Regular/Zero. Competencia1 obtiene7 en naturalidad y bajas calorías.
 Life no tiene notas en el estudio: no puedo asignarle preferencias ni cuota. El caso declara
 homogéneos los beneficios e importancias de los encuestados, por lo que no se inventan
 segmentos estadísticos de esas mismas filas; las hipótesis de público deben validarse.
 Si el objetivo es aumentar volumen de gaseosas con marca Coca-Cola, las fuentes incrementales
 son capturar compradores/ocasiones de marcas competidoras y recuperar consumo que se estaba
 trasladando a otras bebidas o abandonando por preocupaciones calóricas/naturalidad. También
 puede ampliar ocasiones o frecuencia de clientes actuales si satisface una necesidad antes no
 atendida. Cambiar una compra de Regular, Light o Zero por Life es canibalización dentro de la
 familia y, por sí solo, no aumenta ese volumen. Sustituir una bebida de otra marca propiedad de la
 compañía puede incrementar Coca-Cola, pero no necesariamente el volumen total de la empresa.
 Se debe medir cada origen contra lo que se habría comprado sin lanzamiento.
 b) Otros argumentos para lanzarla.
 Defender relevancia de una marca histórica en una categoría que cae1-2% anual; retener clientes
 que de otro modo abandonarían la familia; ampliar asociaciones y opciones; aprender sobre
 formulación, aceptación y portafolio mediante los mercados de prueba Chile/Argentina; y construir
 una plataforma para responder a competencia/tendencias. Una canibalización puede ser defensiva
 si preserva clientes o contribución que se perderían, pero no se etiqueta como volumen
 incremental. Faltan márgenes para afirmar que Life mejora rentabilidad.
 c) Factores de fracaso aun con comunicación bien hecha y precio competitivo.
 El beneficio puede tener baja importancia relativa, no resultar creíble o no compensar el sabor
 percibido y las calorías restantes. La promesa intermedia puede quedar sin una razón clara frente a
 Regular y Zero, confundir el portafolio o atraer sobre todo canibalización. Prueba favorable de
 concepto no garantiza experiencia, recompra ni distribución: disponibilidad, exhibición, calidad
 consistente y aceptación del canal son indispensables. También puede fracasar económicamente
 por costos de formulación, inventario, inversión o margen insuficiente. El envase/mensaje deben
Examen de Grado UC | materia, preguntas y respuestas 276

[pág. 277]
Marketing - versión clara y reordenada
 conservar una promesa verificable; la campaña no corrige un desempeño que no satisface.
 Separaría prueba, repetición, origen del volumen y contribución antes de escalar el piloto.
 agosto 2018 - pregunta 1 - Plataforma de dos clientes y precio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 266-267 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 a) No apoyaría Autocarservicios tal como se propone sin rediseñar los incentivos.
 Para consumidores es coherente extender comparación/precio preacordado a mantenimiento,
 repuestos, financiamiento y seguros: reduce búsqueda, negociación e incertidumbre también
 después de comprar el auto. Hay relación previa y necesidad recurrente, por lo que puede crear
 valor y crecimiento. No garantiza el precio mínimo: Autocar descuenta4-5% de lista, mientras un
 buen negociador presencial logra6%; el beneficio incluye comodidad/confianza además de precio.
 El problema es quién financia el sistema:100% de ingresos proviene de concesionarios. En2017,
 sus ventas se distribuyen50% nuevos,20% usados y30% servicios/repuestos/financiamiento, con
 márgenes6%,30% y60%. Sobre una base de100 de ventas, utilidad bruta sería3+6+18=27; el último
 grupo aporta18/27=66,67% de esa utilidad. En2007 aportaba7,2 sobre18,8,
 aproximadamente38,30%. Dar a los clientes alternativas externas para esas actividades amenaza
 la parte más rentable del cliente pagador de Autocar y puede inducir salida o resistencia a las
 tarifas.
 Más opciones benefician a un lado, pero pueden restar apoyo/cobertura del otro y reducir valor de
 toda la plataforma. Debe comparar negocio nuevo con contribución y permanencia de
 concesionarios, costos de atender proveedores y calidad de servicios. Probaría una extensión con
 oferta de concesionarios y proveedores externos, términos transparentes y pago vinculado al valor
 efectivamente creado; mediría fuga, satisfacción, demanda incremental y contribución. No asumiría
 que «más ingresos» resuelve pérdidas si destruye el lado financiador o añade costos excesivos.
 b) Sí hay base para revisar precios al alza, pero no para un aumento indiscriminado.
 La red recibe67 prospectos mensuales por concesionario por US$1.000:
 aproximadamenteUS$14,93 por prospecto. Los rivales cobranUS$30 por solicitud; para67
 seríanUS$2.010. Los US$2.000 de inscripción son iguales y de una sola vez, por lo que no se
 agregan como costo mensual. Con conversión estimada20%, serían13,4 ventas mensuales
 yUS$74,63 de tarifa mensual por venta atribuida aritméticamente; no mide adquisiciones
 causalmente incrementales ni beneficio por auto. Mayor conversión y ahorro de personal/marketing
 pueden justificar captar parte del valor con un precio mayor.
 Sin embargo, US$2.010 no es automáticamente tarifa óptima: competidores ofrecen otro grado de
 exclusividad/precio, los prospectos pueden diferir y la disposición a pagar depende del
 margen/conversión real por concesionario. Autocar tiene90% de cobertura territorial, así que
 mejorar monetización/calidad puede ser más defendible que esperar expansión geográfica ilimitada,
 pero aumentos que provoquen salida reducirían variedad y acceso para consumidores.
 Probaría niveles o planes por volumen/calidad, estimando beneficio incremental del concesionario y
 elasticidad de permanencia; mantendría alineados precio y promesa. La extensión de a) no puede
Examen de Grado UC | materia, preguntas y respuestas 277

[pág. 278]
Marketing - versión clara y reordenada
 ignorarse al subir tarifas: si reduce el negocio más rentable del distribuidor, su valor percibido cae.
 El diagnóstico financiero debe además reconciliar un dato incoherente:300
 concesionarios×US$1.000×6 meses=US$1,8 millones, más hastaUS$0,6 millones de inscripciones
 si todos fueran nuevos, no los US$10 millones de ventas semestrales declarados. Faltan
 bases/cronología u otros cobros; no usaría esa inconsistencia para fijar un precio «necesario» de
 equilibrio.
 agosto 2015 - pregunta 1 - Plataforma de dos lados y surge pricing
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 173-174 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Dos tipos de cliente y sus propuestas de valor.
 Pasajeros: Uber ofrece encontrar transporte desde el teléfono, información de llegada, un
 auto/conductor calificado y pago sin gestionar efectivo, con un mecanismo de evaluación. Atiende a
 quien valora previsibilidad, comodidad, confianza y menor búsqueda frente a detener un taxi o
 llamar a un radio taxi; no necesita que sea el viaje de menor precio para todos. Smartphone, GPS,
 conectividad y tarjeta son requisitos que pueden excluir parte de la demanda. Selección/evaluación
 reducen incertidumbre, pero no garantizan una experiencia perfecta.
 Conductores con auto: ofrece acceso a solicitudes y cobro organizado mediante una aplicación,
 uso productivo del vehículo y flexibilidad para escoger horas/aceptar viajes. Reciben
 aproximadamente80% de la tarifa, pero pagan mantención, combustible y seguros; ese80% no es
 utilidad. Para ellos importan ingreso neto por hora, viajes vacíos, espera, costos y flexibilidad, no
 solo la tarifa bruta. La plataforma retiene aproximadamente20% y asume tarjeta, atención y
 desarrollo, por lo que tampoco ese20% es beneficio neto.
 Los dos lados son interdependientes: disponibilidad de conductores aumenta valor para pasajeros;
 demanda de pasajeros aumenta oportunidades de ingresos para conductores. La diferenciación
 nace de coordinación, información y servicio de ambos, no simplemente de interponer una
 aplicación entre el taxi y el usuario.
 2. Por qué el precio dinámico es central al modelo descrito.
 En lluvia/eventos la demanda aumenta mientras cada conductor decide libremente si sale o acepta.
 Mantener tarifa fija puede producir escasez, largas esperas y solicitudes no atendidas, destruyendo
 la promesa de transporte disponible. Multiplicar temporalmente la tarifa por dos o tres eleva el
 incentivo bruto para entrar en esa zona/hora y aceptar trayectos; puede compensar congestión,
 demora y costo de oportunidad. A la vez, pasajeros con menor valoración pueden posponer,
 compartir o buscar alternativa, moderando exceso de demanda. No se necesita afirmar que todos
 los conductores respondan instantáneamente para explicar ese mecanismo.
 Con las tarifas ilustrativas del enunciado, precio regular=800+300×km+120×minutos; si el
 multiplicador se aplica al total, el pasajero ve2P o3P y el conductor recibe aproximadamente1,6P
 o2,4P, antes de costos. Uber percibe0,4P o0,6P, antes de los suyos. Sin distancia/tiempo de un
 viaje no corresponde inventar una tarifa concreta. Un precio más alto puede equilibrar el servicio y
 no solo extraer excedente del mismo pasajero.
Examen de Grado UC | materia, preguntas y respuestas 278

[pág. 279]
Marketing - versión clara y reordenada
 Hay una tensión de confianza/equidad percibida, sobre todo en urgencias. Informar claramente el
 precio antes de aceptar, mostrar estimaciones y evitar sorpresas protege la relación; la
 transparencia no vuelve irrelevante un precio excesivo. Mediría espera, aceptación, cancelación,
 oferta efectiva e ingreso neto por hora, además de satisfacción/retención. El texto describe una
 política necesaria para coordinar oferta flexible con picos, pero no demuestra que2x o3x sean
 multiplicadores óptimos ni que la calidad se mantenga sin capacidad.
 agosto 2011 - pregunta 1 - Precio, difusión y canales
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 73-74 | convocatoria 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Precio superior de iMiev: valor económico y beneficios para el cliente.
 Con los supuestos del caso, fabricar ambos autos cuesta lo mismo: el convencional de $16 millones
 con margen bruto de 50% implica costo de $8 millones; el eléctrico de $20 millones con margen de
 60% implica también $8 millones. La prima de $4 millones aumenta el margen bruto del fabricante
 de $8 a $12 millones por unidad. Se puede cobrar por valor y disposición a pagar, no solo por costo
 más un porcentaje.
 Para el comprador que recorre lo supuesto, el gasto anual en energía eléctrica sería $1,8
 millones/4=$0,45 millones, frente a $1,8 millones en bencina: ahorro de $1,35 millones. Mantención
 añade $1,6-$1,0=$0,6 millones de ahorro anual. Total: $1,95 millones por año. En cuatro años y con
 descuento cero, el ahorro asciende a $7,8 millones; supera la prima inicial de $4 millones en $3,8
 millones. El costo simplificado de compra+energía+mantención sería $29,6 millones para el
 convencional y $25,8 millones para iMiev. El plazo simple de recuperación de la prima es
 4/1,95≈2,05 años.
 Si se implementara la rebaja propuesta de permiso de circulación de $0,5 millones por año durante
 cuatro años, el beneficio adicional sería $2 millones: la ventaja simplificada subiría a $5,8 millones.
 Es una propuesta del enunciado, no un subsidio ya recibido. Bajo idénticas condiciones y sin otras
 diferencias, el precio máximo de equivalencia económica sería $23,8 millones sin ese incentivo o
 $25,8 millones con él; son umbrales aritméticos, no estimaciones de precio óptimo o disposición
 real a pagar.
 Además hay menor ruido y un beneficio ambiental percibido. No se debe asumir ausencia de
 impactos en todo el ciclo de vida por la frase del caso. La autonomía de 100 km frente a 400 km,
 recarga, riesgo tecnológico/reventa, equipo domiciliario y comodidad tienen costos/beneficios no
 monetizados. La prima será defendible para quienes valoren esos beneficios y puedan usar el auto
 con esa autonomía; no para todos por igual. Se necesitan costos de batería, infraestructura,
 residual y uso real antes de una comparación completa.
 2. Elección de distribución: Walmart, con tres ventajas principales.
 1. Recargar durante una actividad ya necesaria: los 20 minutos de carga rápida pueden coincidir
 con compra en el supermercado. Se reduce el tiempo dedicado exclusivamente a recargar y la
 molestia asociada a la autonomía. Es ventaja de ocasión de uso, no una afirmación de que siempre
 haya un cargador libre. 2. Contacto con demanda y prueba: el tráfico habitual de cerca de 100
 locales permite presentar la recarga a compradores, facilitar demostración y asociación con una
Examen de Grado UC | materia, preguntas y respuestas 279

[pág. 280]
Marketing - versión clara y reordenada
 rutina cotidiana. Puede reducir incertidumbre de adopción y generar visitas conjuntas, mientras un
 canal solo de combustible depende más de una parada específica. 3. Incentivos comerciales
 complementarios: el supermercado puede beneficiarse de visitas/compra mientras se carga, por lo
 que tiene un motivo adicional para ejecutar bien el servicio. Estacionamientos y coordinación con el
 flujo de clientes pueden facilitar acceso y comunicación. Deben acordarse servicio, disponibilidad y
 reglas para que la complementariedad funcione; no se presupone menor margen minorista.
 Petrobras ofrece 120 estaciones, hábito de abastecimiento y experiencia con conductores; es una
 alternativa defendible. Sin embargo, el caso iguala cobertura geográfica y precio de compra a
 Chilectra: no puedo justificar Walmart por una cobertura superior ni por costo mayorista menor.
 Como las opciones son excluyentes, elijo la que mejor integra recarga con una ocasión de
 permanencia; confirmaría capacidad, utilización, tarifa final y calidad antes de invertir.
 agosto 2019 - pregunta 1 - Precio, servicio y modelo de negocio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 290-291 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 a) Tres argumentos en contra de la propuesta de Sigmund.
 1. No responde a la economía ni al valor relevante: el caso dice que el precio de mercado no
 cubre costos/expectativas de Liebherr. Bajar por debajo y regalar mano de obra de mantención
 agrava esa restricción. La mina necesita continuidad, seguridad y costo por tonelada, no
 necesariamente el activo de menor precio; hay que demostrar el valor de tecnología que reduce
 detenciones en lugar de subvencionarla sin cuenta de contribución. 2. Ancla precio/servicio que
 luego será difícil revertir: una entrada barata puede crear referencia e inducir elección por
 descuento, mientras subir después contradice la promesa inicial. Camiones de vida media15 años y
 contratos de servicio tienen una relación larga; no se puede asumir que el cliente aceptará
 aumentos al descubrir beneficios. La firma también puede verse como alternativa barata,
 debilitando la credibilidad de tecnología superior y generando reacción de incumbentes con52%
 y44% de cuota. 3. Deja el aprendizaje y la prueba de desempeño al cliente: afirmar que «solos
 se darán cuenta» omite una compra industrial de alto riesgo, con equipos superiores aUS$4
 millones y flotas de60-100. Se necesitan evidencia de disponibilidad/costo total, respaldo en mina,
 repuestos y gestión de riesgo para cambiar proveedor. El descuento y servicio gratis no acreditan
 capacidad; fallas iniciales podrían cerrar nuevas oportunidades y volver costosa la expansión.
 b) Tres argumentos a favor del contrato de Wolfgang.
 1. Transforma tecnología en el resultado que compra la mina: disponibilidad garantizada de95%
 frente al promedio85% significa diez puntos adicionales. Sobre8.760 horas potenciales de un año,
 serían8.322 frente a7.446 horas operativas:876 más, aproximadamente11,76% sobre la base
 disponible. Eso permite expresar el beneficio en producción y continuidad, en vez de pedir pagar
 más por una especificación difícil de valorar. No se convierten automáticamente esas horas en
 toneladas: faltan utilización, rutas, ciclos y restricciones de planta. 2. Reduce y ordena
 riesgos/capital del cliente: el arriendo evita o difiere el desembolso de compra y el pago por
 tonelada hace visible una unidad económica ligada a minería. Liebherr asume
 mantención/reparación, neumáticos, repuestos e insumos; la mina puede enfocarse en extracción
Examen de Grado UC | materia, preguntas y respuestas 280

[pág. 281]
Marketing - versión clara y reordenada
 sin gestionar múltiples fallas/garantías. Los neumáticos deUS$100.000 y duración15 meses ilustran
 que el paquete transfiere costos significativos, no solo tareas administrativas. El costo por tonelada
 contractual no elimina otros costos mineros ni hace gratuita la flota. 3. Alinea incentivos y permite
 capturar parte del valor: el proveedor que cobra por toneladas y garantiza disponibilidad tiene un
 motivo para prevenir fallas y operar eficientemente. Su sistema de aceite evita la parada habitual de
 cuatro horas cada500 de funcionamiento: la media hora coincide con combustible. Esa ventaja
 puede ayudar a financiar un contrato atractivo al cliente y rentable para Liebherr, permitiendo
 diferenciar sin bajar indiscriminadamente el precio del camión.
 El ahorro de aceite por sí solo no demuestra el salto completo de85% a95%. La garantía exige
 datos, infraestructura, técnicos, repuestos, medición acordada, responsabilidades y consecuencias
 por incumplimiento. Liebherr asume financiamiento, costo de servicio y riesgo de
 demanda/utilización al cobrar por tonelada; debe modelarlos y probar una flota antes de escalar. La
 propuesta crea valor si puede cumplir y si la tarifa captura contribución suficiente, no por cambiar el
 nombre de venta a arriendo.
 enero 2016 - pregunta 1 - Premiumización y prueba de producto
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 185-186 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Tres razones comerciales para lanzar Pirámides.
 1. Capturar crecimiento en valor de una categoría penetrada: con99,4% de penetración, sumar
 compradores de té tiene poco espacio relativo. El mercado crece10% en valor y menos5% en
 volumen en cinco años; origen, variedades y experiencia premium permiten mejorar mix y atender
 demanda de sofisticación. No significa que cada comprador quiera pagar más ni que el precio
 explique todo el crecimiento. 2. Defender participación en la evolución competitiva: Cambiaso
 tiene46% del volumen y Unilever43%, pero85% de sus ventas procede de líneas económicas según
 el texto. Un segmento que migra a variedades/orígenes premium puede ir a marcas importadas si el
 líder no ofrece una alternativa relevante. Pirámides puede retenerlo y captar consumo de
 competidores, usando distribución y confianza de Té Supremo. Canibalizar una línea propia puede
 ser defensivo, pero no constituye por sí solo volumen incremental. 3. Construir una extensión con
 beneficios diferenciados y valor por cliente: mezcla india y envase que favorece uso del té
 aportan una razón funcional/experiencial para extender una marca conocida a un rango mayor.
 Puede generar ocasiones de consumo, preferencia y contribución si el beneficio compensa el
 sacrificio. Debe evitar que asociaciones de precio económico hagan poco creíble la promesa
 premium; el alcance de marca es una capacidad, no aceptación garantizada.
 2. Interpretación de prueba baja y recompra/cantidad/frecuencia altas.
 Las personas que prueban están encontrando valor y la conducta posterior sugiere una experiencia
 satisfactoria; no corresponde reformular automáticamente el producto. El cuello de botella puede
 estar antes de la primera compra: conocimiento relevante, comprensión de beneficio, riesgo de
 pagar más, ubicación o disponibilidad efectiva. La publicidad humorística y el origen indio pueden
 generar recuerdo sin explicar por qué la mezcla/envase vale la prima. Medios masivos tampoco
 aseguran llegar con el mensaje apropiado al segmento medio-alto; distribución intensiva declarada
Examen de Grado UC | materia, preguntas y respuestas 281

[pág. 282]
Marketing - versión clara y reordenada
 no garantiza exhibición, stock o acceso en los locales usados por él.
 La prima es significativa. En el cuadro, Pirámides cuesta$2.820/15=$188 por bolsita;
 Ceylán,$750-879/20=$37,50-43,95; es aproximadamente4,28-5,01 veces más por unidad. Un
 comprador familiarizado con Té Supremo económico puede percibir riesgo de pagar tanto antes de
 probar. El cuerpo del caso entrega otras cantidades/precios de cajas, por lo que no se mezclan
 esos denominadores con el cuadro. La comparación por bolsita tampoco ajusta gramos/calidad ni
 mide disposición a pagar, pero revela que comparar solo precio por caja subestima la barrera.
 Haría diagnóstico de awareness, comprensión, consideración, stock/exhibición y precio percibido
 por etapa, seguido de prueba/degustación o formatos de entrada que reduzcan riesgo sin
 establecer descuento permanente. Si el mensaje no transmite la experiencia, debe mostrar
 beneficio demostrable, no solo humor/origen. Mantendría los atributos que sustentan recompra,
 cuidando abastecimiento.
 Hay un límite inferencial: los primeros probadores pueden ser los más interesados o menos
 sensibles al precio. Alta recompra en ellos no garantiza idéntica respuesta de todo el segmento ni
 que el negocio cumpla presupuesto. Se deben seguir cohortes, costo de adquisición, repetición y
 contribución incremental. La respuesta explica simultáneamente baja entrada al embudo y buen
 desempeño posterior; no atribuye ambos a una sola causa sin comprobarla.
 agosto 2012 - pregunta 1 - Promociones y plataforma de descuentos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 103-104 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Propuesta para comercios: fortalezas y debilidades.
 Groupon agrega acceso a demanda y organiza una campaña segmentada por zona/categoría,
 comunicando beneficios y precio a una base optativa de correos. Puede crear notoriedad, prueba,
 tráfico y uso de inventario o capacidad ociosa. La duración breve y un mínimo de compradores
 ayudan a activar la campaña; el prepago mejora previsibilidad de canjes, aunque el comercio recibe
 solo el importe pactado con Groupon. Los 170 millones de suscriptores y 33 millones de
 compradores activos describen escala global; no son 170 millones de clientes rentables disponibles
 para cada comercio local.
 La debilidad central es el costo de comprar demanda: descuento superior al 50%, participación de
 Groupon y costo de atender pueden dejar contribución muy baja o negativa. También puede atraer
 cazadores de ofertas, desplazar compras a precio regular, elevar aglomeración y dañar reputación.
 Para cada canje, contribución=efectivo neto recibido-costo variable-costo de atención incremental;
 el beneficio total debe descontar ventas normales desplazadas, costos de campaña y capacidad
 comprometida. La recompra futura puede compensar adquisición solo si efectivamente ocurre.
 Cupones vendidos no equivalen a demanda incremental ni a fidelización.
 2. Cómo reduce el riesgo de deterioro de calidad percibida.
 Selecciona comercios por calidad y comunica atributos/beneficios además del precio. La oferta
 limitada por tiempo, zona, categoría y condiciones de uso permite interpretar la rebaja como
 oportunidad excepcional, no como precio habitual de una marca de baja calidad. Restricciones de
Examen de Grado UC | materia, preguntas y respuestas 282

[pág. 283]
Marketing - versión clara y reordenada
 días/horarios pueden explicar la venta de capacidad ociosa sin bajar permanentemente el
 posicionamiento. La plataforma recibe reclamos y busca resolverlos; eso puede proteger confianza,
 pero el caso dice que no garantiza el cumplimiento del comercio.
 No elimina el riesgo: promociones repetidas, precios normales poco creíbles, canje impracticable o
 trato inferior al cliente con cupón erosionan tanto la marca como Groupon. Como propuesta de
 gestión, transparentaría condiciones, limitaría volumen/frecuencia, comprobaría capacidad y
 suspendería asociados con incumplimientos. Selección, comunicación, experiencia y recuperación
 de servicio deben ser consistentes; urgencia por sí sola no demuestra buena calidad.
 3. Ajuste a tres empresas diferentes.
 Comercio Mecanismo principal de valor Condición y riesgo
 Hewlett Packard Dar salida a inventario/modelos con Acotar lotes/modelos y comprobar
 obsolescencia, probar producto y contribución versus mantener/liquidar
 facilitar venta de complementos. stock. Evitar conflicto de canal,
 subvencionar demanda normal o
 erosionar precio de referencia.
 CasaCero, hotel boutique nuevo Comprar notoriedad y primeras Asegurar servicio y capacidad;
 experiencias/recomendaciones; proteger fechas que ya se venderían.
 vender habitaciones perecibles en Medir ocupación incremental y
 fechas de baja demanda. reservas posteriores, sin asumir que
 toda prueba genera WOM positivo.
 Palumbo, peluquería conocida Llenar horas valle con Limitar horarios/cupones y mantener
 personal/sillones disponibles y captar tiempo/calidad de atención. Si invade
 clientes cercanos que luego repitan. horas punta desplaza clientes
 rentables y puede destruir
 contribución por hora.
 La plataforma común crea valor por motivos distintos: liquidación/exposición de bienes, adquisición
 para un negocio nuevo y gestión de capacidad de un servicio establecido. Cada comercio debe
 medir canje, cliente nuevo, margen incremental, experiencia y recompra a precio normal.
 enero 2015 - pregunta 1 - Respuesta competitiva y esencia de marca
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 160-161 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Efectos sobre la propuesta tradicional, separando las proposiciones.
 La promesa de McDonald’s es calidad estandarizada, rapidez y consistencia a precio bajo. Del
 primer director, cocinar solo al ordenar y permitir más20 ingredientes favorece
 personalización/frescura, pero puede demorar preparación y elección, aumentar variabilidad y
 dificultar consistencia. Usar la misma área que las hamburguesas tradicionales puede trasladar
 esperas/errores también a quienes no eligen el producto nuevo. La complejidad exige capacidad,
 entrenamiento y control de calidad.
 Subir el precio medio de US$5,79 a US$7,79 es un aumento de US$2, aproximadamente34,54%.
 Debilita accesibilidad del producto y acerca la comparación a Fast-Casual; mayor precio no
 demuestra mejor resultado financiero si pierde volumen o eleva costo. Sustituir30% de variedad por
Examen de Grado UC | materia, preguntas y respuestas 283

[pág. 284]
Marketing - versión clara y reordenada
 ensaladas/frutas/sopas/etc. puede atraer ciertos intereses saludables, pero desplazar productos
 emblemáticos y diluir claridad de la marca. Si se añade o conserva mucha complejidad, puede
 deteriorar escala y velocidad sin diferenciarla convincentemente de competidores especializados.
 Del segundo director, reforzar hamburguesas estandarizadas/baratas y simplificar categorías
 protege rapidez, precio y consistencia. No hay que inventar que esas dos decisiones contradicen
 necesariamente la promesa tradicional. Su costo comercial es reducir opciones para clientes con
 necesidades diferentes y riesgo de dejar de ser relevante para Millennials si interpreta foco como
 inmovilidad de producto. Renovar locales, wifi, cargadores y pagos móviles puede mejorar
 comodidad/ambiente sin cambiar el núcleo; requiere inversión y buena ejecución para no elevar
 precios o crear fricción. Tecnología ornamental que no resuelva una necesidad aportaría poco.
 2. Propuesta que elegiría para mejorar posición competitiva en tres años.
 Elijo la segunda como base, con mejoras de calidad/experiencia coherentes con el núcleo.
 McDonald’s ya pasó de nueve a121 alternativas y no recuperó ventas/lealtad; más variedad no ha
 demostrado resolver la falta de una razón para preferirlo. Los Millennials representan20% de
 ingresos, por lo que una sustitución amplia y encarecimiento del centro de la oferta arriesga al resto
 sin asegurar conquista de quienes buscan Fast-Casual. Precio mayor no compra por sí solo
 credibilidad de frescura/calidad o personalización.
 La simplificación puede reducir tiempo, errores, inventario y costos, reforzando una ventaja que
 Fast-Casual no copia a igual precio. Renovar experiencia y facilitar pedidos/pago aborda algunas
 preferencias jóvenes, mientras mejoras selectivas de hamburguesas y alternativas pertinentes
 evitan congelar el menú. Wendy’s y Burger King muestran en el relato que mejorar calidad/locales
 dentro del formato puede ser compatible con resultados positivos; es antecedente, no prueba
 causal suficiente.
 Haría pruebas por locales de una oferta limitada de mejor calidad y de tiempos/pago, sin ocupar
 indiscriminadamente la línea común con personalización compleja. Mediría conversión, repetición,
 espera, contribución y percepción por segmento, con atención a canibalización. Si la base sigue sin
 ofrecer una razón de elección o un piloto premium logra contribución incremental sin perjudicar
 servicio, revisaría la decisión. La recomendación articula posicionamiento y ejecución; no supone
 que la nostalgia por el menú tradicional bastará.
 agosto 2014 - pregunta 1 - Respuesta de marketing y regulación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 149-150 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. La predicción del analista no está justificada.
 El acuerdo descrito limita pagos, descuentos o premios asociados a exclusividad, metas de
 crecimiento y asignación de góndola superior a la cuota nacional en categorías donde UL
 supera60%. No establece que toda asignación voluntaria de espacio deba ser exactamente67%, ni
 que el espacio no financiado por UL se entregue a fabricantes nacionales pequeños. El caso
 informa además que el espacio promedio de UL ya es algo inferior a su participación nacional; no
 hay necesariamente una gran liberación automática de góndola.
Examen de Grado UC | materia, preguntas y respuestas 284

[pág. 285]
Marketing - versión clara y reordenada
 La disponibilidad facilita elección, pero centímetros de exhibición no equivalen a porcentaje de
 ventas. Los consumidores priorizan marca, luego funcionalidad y precio. UL y P&G tienen marcas
 reconocidas, capacidad de investigación, muchos SKU y más85% de inversión publicitaria conjunta.
 UL conserva67,5% de ventas en2012 y P&G21,9%; las marcas propias suman4,8%. La suma de
 Maritano2,2%, Labach1,1%, Cleaner1,6% y «otros»0,9% es5,8%, sin asegurar que todos los
 «otros» sean nacionales. Pasar de esa base a15% exigiría al menos9,2 puntos de ganancia
 agregada: no surge mecánicamente de la restricción.
 P&G o marcas propias podrían captar parte de la oportunidad; cuatro cadenas concentran
 cerca90% de ventas de supermercados y decidirán espacio por rotación, margen y preferencias.
 Los supermercados explican80% del volumen de detergentes; la cuota nacional también incluye
 canales tradicionales con dinámicas diferentes. Las pequeñas firmas necesitan producto, marca,
 abastecimiento y apoyo que conviertan acceso en prueba/recompra. La restricción abre
 posibilidades, pero el mínimo15% y su plazo no están demostrados.
 2. Impactos sobre UL a corto y largo plazo, dentro de las reglas del caso.
 Corto plazo: revisar contratos/incentivos afectados; perder una herramienta de presión sobre
 exclusividad, crecimiento y exhibición; enfrentar entrada o mejor presencia de rivales; y renegociar
 colaboración con minoristas. Podría aumentar el costo comercial de mantener ventas o reducir
 algunos pagos anteriores. Como el espacio actual no excede su cuota, no se presupone pérdida
 proporcional de exhibición o venta. Debe conservar disponibilidad, reposición y una oferta atractiva
 para comprador/canal sin reproducir los incentivos restringidos.
 Largo plazo: depender relativamente más de preferencia del consumidor que de acceso
 condicionado al canal. Calidad, innovación, asociaciones de Omo/Drive/Rinso, diferenciación entre
 marcas y comunicación de beneficios pueden sostener demanda que el retailer quiera atender. La
 estrategia debe evaluar productividad de cada SKU y cubrir segmentos sin usar un portafolio
 extenso como sustituto de valor. Puede coordinar reposición, información y servicio del canal con
 reglas compatibles con el acuerdo, y desarrollar demanda mediante comunicaciones y promociones
 al consumidor cuya ejecución respete sus condiciones.
 Si rivales ganan prueba y mejoran producto/distribución, la cuota de UL podría bajar; también puede
 sostenerla si su preferencia y desempeño son fuertes. No se conoce una elasticidad que permita
 calcular ese efecto. Mediría disponibilidad, rotación, preferencia, precio/mix y contribución por
 canal; distinguiría efectos iniciales de ajuste contractual de cambios persistentes de marca. La
 respuesta es comercial sobre un caso histórico, no una afirmación de la normativa vigente.
 enero 2017 - pregunta 1 - Segmentos, crecimiento y precio-calidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 226-227 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Tres segmentos para crecer sin deteriorar márgenes.
 Priorizaría instaladores de la zona sur, instaladores de la Región Metropolitana y hogares de
 la zona sur. La elección combina crecimiento, ajuste a calidad/precio y acceso por las200
 ferreterías independientes, en vez de ordenar por tamaño de mercado solamente.
Examen de Grado UC | materia, preguntas y respuestas 285

[pág. 286]
Marketing - versión clara y reordenada
 Segmento elegido Tamaño del Cuota Multiplast Venta propia Justificación
 mercado2016, aproximada
 $millones
 Instaladores sur 5.000 50% 2.500 Valoran
 calidad/duración,
 reputación de su
 trabajo y servicio;
 prefieren ferreterías
 y marca antes que
 canal. Coinciden con
 la propuesta
 premium y la zona
 crece15% anual. La
 cuota alta limita
 captura adicional
 relativa, pero hay
 expansión de
 demanda y venta
 asociada.
 Instaladores RM 9.000 28% 2.520 Aun en mercado total
 estancado, pueden
 capturarse clientes
 de otras marcas que
 valoren desempeño
 y asesoría. Su
 elección de marca y
 preferencia por
 ferreterías reducen el
 obstáculo del canal
 de grandes cadenas.
 Hay espacio de
 cuota con mejor
 ajuste que el hogar
 orientado a precio.
 Hogares sur 8.000 18,75% 1.500 Mercado regional
 creciente, pocas
 marcas y predominio
 de ferreterías
 independientes
 donde ya existe
 acceso. Los
 instaladores pueden
 influir, demostrando
 duración y costo de
 fallas. La sensibilidad
 al precio exige una
 explicación
 convincente de valor,
 no asumir que
 pagarán la prima sin
 evidencia.
 El crecimiento previsto de15% es de la industria del sur, no un pronóstico automático de cada
 segmento o de Multiplast. La empresa tiene ventas estables pese a ese entorno: debe investigar
 distribución, desempeño comercial y participación perdida, no esperar que el mercado la arrastre.
Examen de Grado UC | materia, preguntas y respuestas 286

[pág. 287]
Marketing - versión clara y reordenada
 Hogares RM, el segmento excluido como prioridad, tiene$18.000 millones y8,22% de cuota,
 aproximadamente$1.479,6 millones propios. Es grande, pero elige distribuidor antes que marca,
 conoce poco la categoría, no es leal y privilegia precio bajo. Las cadenas controlan60% del
 mercado RM y crecen a costa de ferreterías, mientras Multiplast no participa porque suelen elegir
 una marca barata. Se combina bajo ajuste premium, canal restrictivo y crecimiento total nulo.
 2. No apoyaría la propuesta del gerente tal como está formulada.
 Aumentar reconocimiento de15% a30% mediante TV no equivale a duplicar ventas. Para hogares
 RM, el cuello de botella puede ser disponibilidad en el distribuidor elegido y precio, no falta de
 recuerdo. Invertir masivamente sin cambiar ese acceso podría construir awareness que se
 convierte en compra de otra marca; falta explicar beneficio tangible y comprobar disposición a
 pagar.
 Bajar15% todos los precios a público para igualar competidores debilita señal de calidad y margen
 del canal si Multiplast no reduce su precio de suministro. Si también baja éste, pone en riesgo el
 objetivo de no deteriorar márgenes de la empresa. No se conocen márgenes absolutos ni
 elasticidad para justificar que el volumen lo compense. Una paridad amplia convierte a la firma de
 mayor calidad en rival de precio sin demostrar que tenga costos apropiados.
 Dirigiría ventas técnicas, demostraciones de duración, asistencia, disponibilidad y acuerdos de
 servicio/crédito pertinentes hacia instaladores, que valoran desempeño y además influyen en
 hogares. En el sur reforzaría cobertura de ferreterías y comunicación local de valor/costo de fallas.
 El crédito supone costo/riesgo que debe evaluarse, no prometerse indiscriminadamente. Mediría
 contribución incremental, cuota, reposición y satisfacción por segmento; investigar hogares RM
 sería posible después, con evidencia de acceso rentable.
 agosto 2016 - pregunta 1 - Servicio, precio y canal
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 199-202 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Por qué se mantiene el margen de neumáticos y cae el de servicios.
 El caso chileno trata exclusivamente de neumáticos de reposición, no de contratos con fabricantes
 de automóviles. Goodyear entrega el mismo precio final para cada marca a toda su red; así, la
 competencia entre sus distribuidores no se traslada del mismo modo al precio del neumático.
 Marca, calidad, publicidad y desarrollo del fabricante sostienen demanda; el portafolio premium/bajo
 precio y sus condiciones permiten mantener un margen agregado de50% en ambos períodos. El
 cuadro no entrega costos/precios por SKU ni mezcla exacta para atribuir una causa cuantitativa
 adicional.
 Los servicios son diferentes: cada distribuidor fija libremente sus precios y no tiene territorio
 exclusivo. Compite con otras marcas y con locales Goodyear cercanos en balanceo, alineación,
 frenos y amortiguación. Con costos similares y constantes, la competencia puede traducirse en
 rebajas, paquetes o servicio bonificado para atraer/retener la compra de neumáticos. El margen de
 servicios pasa de15-25% en2012-2013 a5-15% en2014-2015; es consistente con presión de
 precio/mezcla, no con aumento de costos informado. El40% de ventas asociado a clientes que
Examen de Grado UC | materia, preguntas y respuestas 287

[pág. 288]
Marketing - versión clara y reordenada
 valoran servicio vuelve esa palanca comercial importante.
 Los neumáticos pasan de70% a75% de ingresos y los servicios de30% a25%. No se confunde
 cuota de ingreso con margen. Incluso con más peso de neumáticos, menor contribución del servicio
 puede presionar resultado total: usando únicamente los puntos medios ilustrativos20% y10%,
 margen ponderado sería0,70×50%+0,30×20%=41% frente a0,75×50%+0,25×10%=40%. No son
 márgenes observados exactos; los rangos no autorizan escoger una cifra puntual como dato.
 2. El acuerdo con Walmart sí puede ser una amenaza seria, pero debe segmentarse.
 Hiper Líder ofrecería la misma marca con libertad para fijar precio,47 locales y acceso potencial a
 más de dos millones de consumidores, aunque sin servicios. El10% de ventas de compradores
 orientados a precio es el más directamente expuesto. El50% fiel a marca/distribuidor y el40%
 orientado a servicio dan protección relativa a la red; no garantizan que ninguno cambie. Un precio
 menor de la misma marca puede servir de referencia, llevar a comprar neumáticos en el
 supermercado y buscar servicios aparte, o reducir la disposición a pagar del conjunto.
 La amenaza es relevante porque neumáticos representan75% de ingresos recientes y50% de
 margen, mientras el margen de servicios ya está comprimido. Si se pierde la venta de neumáticos y
 queda solo instalación/servicio de baja contribución, la economía del local puede deteriorarse.
 Además, la pérdida percibida de exclusividad puede reducir inversión/apoyo de distribuidores o
 provocar salida a marcas rivales, debilitando la capacidad de atender a quienes sí valoran servicio.
 Dos millones de potenciales consumidores no son ventas incrementales aseguradas ni todo
 volumen nuevo para Goodyear.
 No predigo desaparición de la red: clientes que valoran asesoría, calidad y experiencia pueden
 preferir una solución completa. Antes de ampliar canal, Goodyear debería estimar origen del
 volumen, canibalización, precio final, rentabilidad y compromiso de cada distribuidor; diferenciar
 ofertas/servicio con beneficios reales y acordar roles sostenibles. El fabricante debe comparar la
 contribución neta de expansión con la pérdida de capacidad especializada, no solo recuperar una
 cuota de3%.
 enero 2025 - pregunta 4 - Valor, orientación al mercado y coherencia comercial
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 433-434 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. ¿Tiene razón el Director o el Gerente General? La objeción del Director es más sólida respecto
 de la estrategia completa y de su continuidad en 2025. Tricorp inició acciones reales de orientación
 al cliente, por lo que el Gerente General tiene evidencia de avance; sin embargo, cambiar el logo y
 mejorar algunas sucursales no prueba que toda la empresa haya adoptado centralidad en el cliente.
 La asignación de recursos y la reducción de capacidad de posventa presentan contradicciones con
 la promesa de entregar la mejor experiencia personal.
 Una estrategia centrada en el cliente comprende sus necesidades y recorridos, coordina procesos
 para resolverlas y evalúa experiencia y valor de la relación a lo largo del tiempo. Los cerca de 20
 estudios, la revisión semanal y mensual de reclamos, el uso de tecnología para tiempos y
 resolución, y la empatía en atención son pasos coherentes con ese enfoque. El índice de
Examen de Grado UC | materia, preguntas y respuestas 288

[pág. 289]
Marketing - versión clara y reordenada
 experiencia en sucursales pasó de 14,9% a 30,9%, una mejora de 16 puntos porcentuales; las
 visitas crecieron 25%. Son evidencias favorables de ese ámbito, aunque no se informa un diseño
 que atribuya causalmente toda la mejora al cambio de marca ni resultados equivalentes del canal
 digital.
 La mayor debilidad es que 62% de las quejas proviene de interacciones digitales. En 2025 se
 destinará 75% del presupuesto a publicidad tradicional y mejora de sucursales, sólo 10% al sitio y
 app, y el 15% restante a un chatbot que sustituiría a más de la mitad de ejecutivos de posventa. La
 composición de quejas no mide la tasa de falla por canal: faltan número de interacciones, gravedad
 y tipo de requerimientos. Por tanto, no exige mecánicamente asignar 62% del presupuesto a digital.
 Sí obliga a investigar y corregir sus problemas antes de ampliar una promesa de servicio y reducir la
 escalación humana.
 Su reputación inicial de costos bajos y peor evaluación de respuesta a reclamos sugiere que
 eficiencia interna y valor para el cliente no habían estado bien alineados. La tecnología puede
 mejorar ambos, pero reemplazar personas es un medio, no evidencia de mejor experiencia.
 Mantendría la identidad renovada como señal de una mejora verificable del servicio, subordinando
 publicidad, procesos, incentivos y automatización a resultados del cliente. El Director acierta al
 exigir esta coherencia; el Gerente General sólo puede sostener que el proceso comenzó, no que el
 plan previsto lo completa satisfactoriamente.
 2. Dos riesgos específicos de 2025 y sus mitigaciones.
 Riesgo 1: aumentar la brecha entre promesa y experiencia digital. Una campaña que dice
 resolver todas las necesidades y dar la mejor experiencia puede atraer más contactos hacia app y
 web todavía problemáticas. Más clientes expuestos a fallas aumentan reclamos, pérdida de
 confianza y abandono, afectando varias líneas bajo la misma marca corporativa. El dato de 62%
 señala una prioridad de diagnóstico; el 10% presupuestado podría resultar insuficiente, pero su
 suficiencia depende del costo y la naturaleza de las correcciones. Mitigación: priorizar los
 recorridos de mayor fricción y gravedad, rediseñarlos y probarlos con clientes, integrar
 antecedentes entre canales y reasignar recursos según su impacto. Escalar publicidad sólo cuando
 se cumplan metas de resolución, esfuerzo y satisfacción, con seguimiento por canal y tipo de
 cliente.
 Riesgo 2: reducir atención humana antes de que el chatbot resuelva casos complejos. Banco
 y Seguros cuentan con 38 ejecutivos de posventa y las visitas crecieron 25%. Sustituir más de la
 mitad sin verificar capacidad puede dejar cobros, condiciones contractuales, seguros y reclamos
 sensibles en respuestas automáticas que no solucionan el problema. Una respuesta rápida pero
 incorrecta agrava la experiencia, produce reiteración de contactos y congestiona sucursales.
 Mitigación: comenzar con solicitudes simples y repetitivas, realizar un piloto y mantener derivación
 clara a personas con facultades de solución y contexto del caso. Condicionaría cualquier reducción
 de personal a resolución efectiva, errores y contactos repetidos, además de satisfacción;
 preservaría capacidad humana para excepciones, sin premiar sólo rapidez ni ahorro de dotación.
 marzo 2009 - pregunta 1 - Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 2-3 | convocatoria 1
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 289

[pág. 290]
Marketing - versión clara y reordenada
 Respuesta modelo desarrollada (no oficial)
 1. Argumento principal a favor de cada propuesta del Gerente de Ventas.
 GV-1, retirar SKU de bajo volumen: reducir complejidad libera capital de trabajo, espacio,
 cambios de producción y atención comercial cuando cae la demanda. Cinco de los56 SKU
 concentran85% de ingresos, por lo que sostener inventarios de toda la línea puede ser costoso. La
 defensa válida es racionalizar referencias cuya contribución incremental, después del costo de
 servir, no compense su complejidad. Sin embargo, esos cinco generan solo60% de los márgenes:
 los otros51 aportan40% con15% de ingresos. Si ambos porcentajes usan una base comparable, la
 intensidad relativa de margen del resto es(40/15)/(60/85)=3,78 veces la de los cinco principales; no
 se conocen tasas absolutas. Por tanto, el enunciado respalda estudiar selectivamente los SKU,
 pero contradice eliminar toda la cola solo por bajo volumen. También importan complementariedad,
 retención y sustitución dentro de la marca.
 GV-2, reducir publicidad masiva: permite ahorrar gasto inmediato y reasignar recursos si el
 retorno marginal de medios masivos es bajo frente a una menor demanda. Una marca ya conocida
 puede priorizar comunicación más dirigida o programas con mejor contribución por peso invertido.
 El argumento no es que una crisis vuelva inútil toda publicidad: ante marcas propias y mayor
 concentración del canal, cortar inversión eficaz puede erosionar preferencia y precio sostenible. La
 reducción defendible afecta actividades de baja efectividad, conservando los mensajes que prueban
 la diferenciación.
 GV-3, reorientar hacia promociones y activaciones: una mayor sensibilidad al precio vuelve
 relevante una ventaja tangible al momento de comprar; exhibición, demostración o un incentivo
 temporal pueden estimular prueba y conversión. El supermercado concentra más70% de ventas y
 tiene mayor poder tras las consolidaciones, por lo que ejecutar en ese punto es comercialmente
 importante. Se evalúa contribución incremental, no solo unidades despachadas: parte de la
 promoción puede financiar compras que habrían ocurrido, adelantar demanda o transferir margen al
 canal. El apoyo principal es la eficacia de corto plazo en una ocasión de compra concreta.
 2. Argumento principal a favor de cada propuesta del Gerente de Marketing.
 GM-1, mantener inversión en marca: protege el activo construido mediante calidad, innovación y
 atributos diferenciadores. La preferencia del consumidor ayuda a que el supermercado quiera
 mantener la marca y a sostener disposición a pagar frente a sus marcas propias. En una recesión,
 la confianza y la prueba de beneficios pueden reducir el riesgo percibido. Mantener inversión eficaz
 evita deteriorar un activo cuya recuperación sería costosa; no obliga a conservar cada partida del
 presupuesto.
 GM-2, buscar nuevos nichos: la crisis modifica necesidades y no afecta por igual a todos los
 compradores. Pueden aparecer ocasiones, formatos accesibles o grupos que aún valoran
 determinados beneficios, menos disputados por ofertas generales. La búsqueda puede diversificar
 demanda y descubrir contribución rentable. Debe comprobar necesidad, tamaño, disposición a
 pagar, acceso y capacidad de servir; no se debe inventar que Lautaro opera en viviendas u otros
 sectores ausentes del caso. Más nichos también elevan complejidad, por lo que la propuesta es
 compatible con retirar referencias sin valor y conservar nichos rentables.
 GM-3, mejorar la propuesta de valor: aumentar el beneficio relevante por el sacrificio total que
 enfrenta el cliente permite defender preferencia sin depender de descuentos permanentes. Puede
Examen de Grado UC | materia, preguntas y respuestas 290

[pág. 291]
Marketing - versión clara y reordenada
 significar formatos de menor desembolso, calidad útil, ahorro de uso, conveniencia o comunicación
 más clara del beneficio. Se coordinan producto, precio, distribución y comunicación, manteniendo
 contribución sostenible. Mejorar valor no significa necesariamente agregar atributos costosos ni
 bajar todos los precios.
 Las seis propuestas se defienden de manera independiente, como pide la consigna. Sus
 argumentos pueden coexistir: racionalizar selectivamente, conservar inversión eficaz y mejorar
 valor con ejecución rentable en el canal.
 agosto 2009 - pregunta 1 - Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 15-16 | convocatoria 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 Análisis cuantitativo: comparar el cambio incremental de funciones y costos.
 Los siete distribuidores compran por US$90 millones y revenden por US$100 millones: el margen
 bruto de intermediación es US$10 millones, equivalente a10% de sus ventas o11,11% de su costo
 de compra. Además, cobran5% de90 millones=US$4,5 millones a la viña; no confundir este
 honorario con el margen de reventa. El costo financiero informado es0,5% de90 millones=US$0,45
 millones. Los US$6 millones de utilidad neta actual son una base de contexto, no el beneficio
 incremental de cambiar el canal.
 Si Lapesti conserva el mismo volumen y logra vender directamente por US$100 millones, podría
 capturar10 millones adicionales de ingresos y evitar4,5 millones de honorarios. Evitar los0,45
 millones financieros exige comprobar que el cobro directo realmente mejora el ciclo; vender directo
 también genera cuentas por cobrar, financiamiento y riesgo de impago.
 Los costos conocidos de la alternativa son US$3,5 millones anuales de vendedores
 incrementales;5% de100 millones=US$5 millones de transporte y entrega; y US$0,9 millones por
 oficina/bodega. El original no define cuántas oficinas/bodegas se instalarían. Sea n su número y C
 el resto de costos incrementales anuales aún no estimados, incluyendo cuatro supervisores,
 administración/ventas y costo neto de crédito/inventario:
 Δresultado preliminar=10+4,5+0,45-3,5-5-0,9n-C=US$[6,45-0,9n-C] millones al año.
 Con una instalación resulta+US$5,55 millones antes de C. Con siete instalaciones, una por cada
 distribuidor como escenario y no dato obligatorio, queda apenas+US$0,15 millones antes de C. Por
 tanto, el cambio no puede declararse desfavorable usando solo una bodega, ni rentable
 usando+5,55 millones sin justificar cobertura e instalaciones. Además, no se deben sumar estos
 valores directamente a la utilidad neta sin ajustar impuestos y diferencias entre flujo y resultado.
 Si S son las ventas directas en millones de dólares, manteniendo el volumen/costo de producción
 original y suponiendo que se eliminan los dos cargos existentes, Δ=0,95S-88,55-0,9n-C. El
 equilibrio operativo preliminar exige S≥(88,55+0,9n+C)/0,95; con n=7 y C=0, S≈US$99,84 millones.
 Una reducción de precio o costos faltantes puede eliminar el estrecho excedente. Si cambia el
 volumen, esta fórmula deja de bastar: también cambian fabricación, inventario y funciones
 comerciales.
Examen de Grado UC | materia, preguntas y respuestas 291

[pág. 292]
Marketing - versión clara y reordenada
 Para un VAN faltan inversión inicial, capital de trabajo, supervisores, costos administrativos, crédito
 incobrable, financiamiento, merma/devoluciones, transición, impuestos, valor residual y respuesta
 de precio/volumen. Los hasta90 días del sistema actual no prueban que el nuevo sistema cobre al
 contado.
 Análisis cualitativo, ordenado por función comercial.
 1. Mercado y cliente: atender cadenas/tiendas clave directamente puede mejorar información,
 relación, exhibición, coordinación promocional y rapidez de respuesta. Los mayoristas no exclusivos
 comparten esfuerzo con otras viñas; el canal propio puede priorizar Lapesti. No se garantiza que el
 minorista mantenga sus compras ni que el menor precio origine suficiente demanda. 2. Cobertura y
 servicio: siete distribuidores y35 vendedores ya atienden aproximadamente1.000 locales. Los seis
 vendedores actuales de Lapesti apoyan inventario, exhibición y reclamos; no constituyen
 automáticamente una red sustituta. Hay que asegurar densidad de rutas, bodegas, frecuencia,
 stock y conocimiento local. 3. Riesgo y negociación: se internalizan crédito, cobranza, inventario y
 devoluciones. También puede aumentar dependencia de grandes cadenas y producir conflicto o
 pérdida de cobertura al retirar mayoristas. Los competidores directos prueban factibilidad de otro
 canal, no su rentabilidad para esta viña. 4. Capacidad y transición: comparar instalar red propia,
 contratar operadores o un esquema híbrido: directo a cuentas densas/estratégicas y distribuidores
 para clientes dispersos. Un piloto debe medir contribución, capital empleado, servicio, crecimiento y
 costos de transición antes de expandirse.
 Recomiendo decidir por VAN y servicio incremental de cada configuración, con las funciones del
 intermediario explícitamente sustituidas. El margen visible no es ahorro neto por sí mismo.
 marzo 2010 - pregunta 1 - Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 31-32 | convocatoria 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Factores comerciales y financieros de rentabilidad de las tiendas de conveniencia.
 El cliente compra proximidad, horario extendido y ahorro de tiempo para una misión breve o
 urgente. Una ubicación de alto tráfico y un surtido pertinente permiten cobrar un precio superior al
 supermercado sin ofrecer su amplitud. La tabla compara200m²,3.000 SKU y dos cajas de
 conveniencia con1.800m²,30.000 SKU y diez cajas de supermercado; el almacén tiene50m²,500
 SKU y una caja. Menor superficie y una elección rápida pueden elevar productividad del espacio,
 aunque el arriendo por metro cuadrado y el costo de horarios largos sean altos.
 Indicador anual Conveniencia Supermercado Almacén
 aproximado
 Ventas por local, US$ 1.500.000 11.000.000 200.000
 Margen bruto sobre venta 35% 20% 15%
 Utilidad bruta, US$ 525.000 2.200.000 30.000
 Ventas por m², US$ 7.500 6.111,11 4.000
 Utilidad bruta por m², US$ 2.625 1.222,22 600
Examen de Grado UC | materia, preguntas y respuestas 292

[pág. 293]
Marketing - versión clara y reordenada
 Indicador anual Conveniencia Supermercado Almacén
 aproximado
 Rotación de existencias del 9 6 3
 caso
 La conveniencia produce menos utilidad bruta total que un supermercado, pero más por metro
 cuadrado. El margen35% y la rotación9 ayudan a compensar espacio y capital limitados. Si se
 define rotación como costo de ventas dividido por inventario promedio, los inventarios aproximados
 serían(1-margen)×ventas/rotación: US$108.333; US$1.466.667; US$56.667. La utilidad
 bruta/inventario sería4,85;1,50;0,53 veces al año. Es una ilustración condicional de productividad
 del inventario; la tabla no define expresamente su convención de rotación.
 La rentabilidad sobre activos completos depende de margen operativo y ventas/activos, no de
 margen bruto solo. Faltan salarios, arriendo, merma, logística, equipamiento e inversión total. El
 enunciado respalda los mecanismos de alto margen, rotación, proximidad, surtido y reposición
 eficiente, pero no calcula un ROA exacto ni prueba que todo local sea rentable. Reponer con
 frecuencia mantiene disponibilidad y reduce capital atrapado; quedarse sin los pocos productos
 clave destruiría la conveniencia que permite el sobreprecio.
 2. Aporte de OK Market a la estrategia comercial de SMU.
 La adquisición de25 locales incorpora una marca posicionada y ubicaciones para compras rápidas,
 complementarias a compras grandes de Unimarc y otros formatos. Aumenta cobertura y contacto
 con clientes urbanos, añade aprendizaje de microlocalización/surtido y reduce el tiempo para entrar
 frente a desarrollar locales desde cero. Permite atender ocasiones que SMU no cubría con igual
 eficacia, y competir con Big John y las tiendas vinculadas a combustible sin convertir cada marca en
 un supermercado pequeño.
 SMU puede compartir negociación con proveedores, compras, reposición, sistemas y conocimiento
 de demanda; mayor densidad de red puede reducir costos. Esas sinergias deben preservar rapidez
 y surtido local. Integrar todo bajo una propuesta indiferenciada arriesga perder la disposición a
 pagar por conveniencia; también hay canibalización entre locales, alto arriendo y costo de
 adquisición. La expansión se justifica por contribución y capital incremental por zona, no por
 declarar liderazgo a partir del número de tiendas. El caso distingue explícitamente número de
 locales de participación nacional en ventas.
 agosto 2025 - pregunta 1 - Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 439-440 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1. Variables de segmentación y perfil de corredores ocasionales. “Ocasional” describe una
 conducta, no un segmento automáticamente homogéneo. El caso incluye personas que corren
 recreativamente y otras que usan zapatillas en su vida diaria; para elegir un público compatible con
 On hay que combinar motivaciones y uso, sin asumir que todo el 60% del mercado comparte
 valores premium o ambientales.
 Variables psicográficas.
Examen de Grado UC | materia, preguntas y respuestas 293

[pág. 294]
Marketing - versión clara y reordenada
 • Estilo de vida y relación con la actividad física: distinguiría quienes buscan movimiento y
 bienestar sin una meta competitiva de quienes incorporan el calzado deportivo principalmente a su
 rutina diaria. El perfil prioritario puede correr ocasionalmente, caminar y realizar actividades
 cotidianas, valorando sentirse cómodo y activo. No necesita entrenamiento de élite para apreciar el
 producto.
 • Motivaciones y valores personales: identificaría cuánto importan confort, bienestar, cuidado
 ambiental, autenticidad y consumo responsable. Para preservar la condición del Directorio,
 priorizaría consumidores que valoran calidad y sustentabilidad y están dispuestos a pagar por ellas,
 en vez de captar indistintamente a todo comprador económico. No se puede atribuir preocupación
 ambiental a todos los ocasionales sin validación.
 • Personalidad y aspiración: analizaría interés por innovación, gusto por un diseño discreto o
 distintivo y deseo de pertenecer a una comunidad activa. El comprador compatible busca una
 experiencia premium accesible a su práctica recreativa; puede apreciar reconocimiento social de
 una marca contemporánea sin perseguir el desempeño extremo de atletas. Son perfiles propuestos
 a partir del caso, no resultados de una encuesta no presentada.
 Variables conductuales.
 • Frecuencia e intensidad de uso: corren menos regularmente y sin exigencias profesionales;
 algunos usarán el calzado más días para caminar o vida cotidiana que para entrenar. Esto cambia
 la relevancia de beneficios y el desgaste, y distingue consumidores recreativos de quienes sólo
 quieren estilo.
 • Ocasión de uso y beneficios buscados: actividades recreativas, trayectos diarios y bienestar,
 con énfasis en comodidad prolongada, amortiguación, diseño y versatilidad. Se debe probar cuál
 combinación importa más a cada subgrupo. El retorno de energía o indicadores de rendimiento
 especializado pueden servir como respaldo, pero no son necesariamente su principal motivo de
 compra.
 • Respuesta a precio, marca y compra: evaluaría disposición a pagar por esos beneficios, lealtad,
 experiencia previa con On y criterios de elección. Que el consumidor sea ocasional no permite
 concluir que sólo busca descuentos. Segmentar por beneficio y disposición a pagar ayuda a
 seleccionar quienes pueden sostener una oferta premium y distinguir interesados, compradores de
 prueba y usuarios repetidos.
 El perfil elegido sería un corredor recreativo o usuario cotidiano que desea una vida activa con
 comodidad, aprecia innovación y responsabilidad ambiental verificables y acepta pagar por una
 experiencia de calidad. La frecuencia menor define su conducta; sus valores y beneficios buscados
 justifican que On lo atienda. Los US$32.400 millones del segmento ocasional indican tamaño
 agregado estimado, no mercado alcanzable íntegramente por esta propuesta.
 2. Declaración de posicionamiento propuesta. “Para personas que corren por recreación y se
 mantienen activas en su vida diaria, valoran su bienestar y el cuidado ambiental, On es la marca
 premium de zapatillas para running y uso cotidiano que entrega comodidad para correr y moverse a
 diario, porque combina la amortiguación y respuesta de CloudTec con diseño innovador y un
 compromiso ambiental demostrado en sus productos.”
 La declaración especifica público, categoría, beneficio principal y razones para creer. “Compromiso
 ambiental demostrado” exige sostener la promesa con atributos y prácticas verificables; no supone
Examen de Grado UC | materia, preguntas y respuestas 294

[pág. 295]
Marketing - versión clara y reordenada
 que todos los productos sean ecológicos ni que una tecnología de amortiguación pruebe
 sustentabilidad. La protección de articulaciones y resultados fisiológicos mencionados en el caso no
 deben convertirse en garantía médica individual.
 Diferencias clave. Respecto del On actual, conserva precio premium, innovación, comodidad y
 orientación ambiental, pero desplaza la ocasión central desde el corredor serio hacia recreación y
 bienestar cotidiano; explica la tecnología mediante un beneficio comprensible sin exigir identidad de
 élite. Frente a Nike, evita centrar la promesa en rendimiento extremo y superación de límites. Frente
 a Adidas, no coloca primero el estilo urbano aspiracional o la colaboración de moda, aunque el
 diseño siga siendo importante. La amplitud nueva proviene de extender la utilidad del confort y el
 movimiento consciente, manteniendo una razón de compra distintiva. Debe validarse con
 consumidores y productos apropiados antes de escalar: incorporar el segmento masivo no requiere
 diluir el significado de On.
 enero 2026 - pregunta 3 - Valor/cliente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 456-457 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo desarrollada (no oficial)
 1.a. Evaluación crítica del portafolio. Viña Ladera concentra 75% del volumen en Base, con
 precios públicos de US$7-12, margen de 28-32%, distribución masiva dependiente de importadores
 y promociones, y una imagen confiable pero genérica. Esa línea aporta escala y flujo comercial,
 pero está expuesta al consumo estructuralmente decreciente y a la presión de descuentos. Su
 predominio dificulta crecer en valor si cada venta requiere sacrificar precio.
 Gran Reserva aporta 20% del volumen, precios públicos de US$15-22 y márgenes de 38-42%.
 Tiene mejores canales para explicar el producto -tiendas especializadas y restaurantes- y mayor
 potencial para “beber menos, pero mejor”. Sin embargo, “calidad del vino chileno” es una asociación
 compartida y no una ventaja suficiente para cobrar más o retener clientes. Granel representa 5%,
 margen de 8-12% y ayuda a manejar inventario; no construye marca y debe conservar una función
 táctica, sin asignarle producción que tenga una alternativa de mayor contribución.
 La debilidad transversal es la marca: reconocimiento asistido de 18% frente a 35-45% de
 competidores, espontáneo de 4% y asociaciones genéricas. NPS +22 se califica como neutral en el
 caso, pero no mide reconocimiento ni disposición a pagar. La reducción del consumo por cohortes
 no se resuelve esperando que los jóvenes alcancen la edad de sus mayores: las diferencias se
 comparan a igual edad. Además, formatos, moderación e información influyen en la elección,
 mientras otras bebidas compiten por ocasiones. No calcularía un margen EBITDA ponderando
 75%, 20% y 5% por sus márgenes: son pesos de volumen y márgenes de línea, no pesos de
 ingreso ni costos totales.
 1.b. Redefinir el foco de segmentación. Priorizaría consumidores que buscan beber menos, pero
 mejor: valoran origen auténtico, experiencia sensorial, moderación y atributos ambientales
 comprobables, y aceptan pagar por una ocasión significativa. Segmentar por beneficios y ocasión
 es más preciso que elegir “jóvenes” o “premium” en abstracto. Un segundo foco sería el comprador
 que necesita selección simple y formatos adecuados para una ocasión pequeña, siempre que
 sostenga contribución suficiente. No propondría captar a todos los consumidores de No/Low
Examen de Grado UC | materia, preguntas y respuestas 295

[pág. 296]
Marketing - versión clara y reordenada
 Alcohol sólo por el crecimiento de 13%: primero habría que validar demanda, calidad y viabilidad
 técnica sin nueva capacidad ni compra de vino externo.
 Reasignaría parte del vino apto desde Base y granel hacia una Gran Reserva diferenciada por
 origen específico, historia verificable y experiencia, con menor complejidad y apoyo comercial. No
 todo vino Base puede convertirse legítimamente en Gran Reserva: la disponibilidad y calidad de
 cada cosecha limitan esa reasignación. Mantendría la Base que aporte contribución y clientes útiles,
 reduciendo descuentos y SKU de baja productividad. Probaría formatos que faciliten moderación y
 comunicación sencilla, incorporando su costo de envase y distribución. La sustentabilidad exige
 respaldo real; no declararía orgánico o biodinámico un vino sin sustento.
 Con producción limitada, el crecimiento de 8% en valor debe venir principalmente de precio neto
 realizado, mezcla y canales, no de una expansión física prometida. Con ventas actuales de
 US$35-45 millones, la meta equivale a US$37,8-48,6 millones y un incremento de US$2,8-3,6
 millones. Mantener 16% de EBITDA exigiría US$6,048-7,776 millones en el nivel objetivo, después
 de marketing y canales, sin convertir márgenes de línea en EBITDA. Presupuestaría el mix con
 precios de salida de la viña, volumen disponible y todos los costos; los precios públicos no son
 ingresos de Ladera. La mejora de marca, margen y canales es la hipótesis a validar, no garantía
 aritmética de cumplir la meta.
 1.c. Dos riesgos principales. Riesgo de demanda y marca: una oferta más cara podría no ser
 creíble con notoriedad baja; se perdería volumen Base sin compensación de valor, o el nuevo
 producto sólo canibalizaría Gran Reserva. Lo mitigaría con pilotos por ocasión y mercado, prueba
 de disposición a pagar, comunicación de diferencias verificables y revisión de contribución
 incremental. Riesgo de ejecución y margen: formatos, calidad superior, venta directa y
 experiencias generan costos y exigen capacidades; una cosecha volátil puede limitar vino apto y el
 crecimiento comercial superar la oferta. Lo mitigaría con lanzamientos graduales sujetos a
 disponibilidad, presupuesto de costos completos y disciplina de surtido, manteniendo el umbral de
 EBITDA y sin recurrir a compras externas para cubrir demanda.
 2. Dos decisiones concretas de canales y su riesgo principal.
 Decisión 1: desarrollar un canal directo con club y comercio electrónico, inicialmente donde
 Ladera pueda cumplir servicio y costos. Aprovecharía la mayor relevancia del e-commerce -18%
 en mercados desarrollados frente a 6% en 2019- para vender selección curada, recompra y
 experiencias vinculadas a la viña. La relación propia permite recoger preferencias, explicar origen y
 defender precio sin que la marca sea una entre las 40-80 de un importador. Probaría primero una
 oferta y territorio acotados; vender directamente no elimina automáticamente intermediarios ni
 requisitos de acceso en exportación. Su riesgo principal es que adquisición, despacho, atención y
 retención consuman el margen aparente, o que sólo se trasladen compradores existentes. Mediría
 contribución después de todos esos costos y ventas incrementales, y expandiría únicamente
 cohortes rentables.
 Decisión 2: diversificar intermediarios mediante acuerdos selectivos con importadores y
 distribuidores que desarrollen la marca. Priorizaría socios y territorios que no dependan de los
 dos actuales, con cobertura en tiendas especializadas y restaurantes apropiados para Gran
 Reserva. Pactaría metas de venta final, formación, acciones de marca y condiciones de
 promociones; no sólo volumen comprado. Mantendría una transición gradual con los socios
 actuales para evitar perder acceso e inventario. Su riesgo principal es incorporar pequeños
Examen de Grado UC | materia, preguntas y respuestas 296

[pág. 297]
Marketing - versión clara y reordenada
 distribuidores sin capacidad de rotación, que multipliquen costo de gestión y dejen stock
 inmovilizado. Seleccionaría solvencia y capacidad de servicio, probaría territorios y supervisaría
 venta final y cobro antes de ampliar compromisos.
 La concentración se mide sobre ventas de la viña, no número de socios. Si ventas actuales son S y
 los dos importadores aportan 0,55S, un año de crecimiento total de 8% manteniendo esas ventas
 deja su peso en 0,55/1,08 = 50,9%, todavía sobre 45%. Con ventas de esos socios constantes,
 llegar a 45% exige ventas totales de 1,222S, es decir, más de 22,2% de crecimiento acumulado;
 para quedar bajo 45% se requiere algo más. Tres años de 8% compuesto darían 1,260S y 43,7%,
 sólo bajo la hipótesis de que el Directorio mantenga ese crecimiento anual y las ventas de ambos
 no aumenten. Estas relaciones ilustran por qué el plan debe desarrollar ventas fuera de ellos y
 coordinar denominador y numerador; no son una proyección asegurada por el caso.
 Marketing Analytics
 enero 2012 - pregunta 6 - ANOVA y análisis factorial
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 98-101 | convocatoria 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 1. Tres conclusiones principales. Primera, hay una dimensión de confianza/seguridad
 bancaria: confiable y seguro cargan +0,881 y +0,870 en F1. Segunda, se distinguen
 flexibilidad/agilidad/acceso al crédito de casas comerciales (F2, cargas +0,730/+0,763/+0,711)
 y conveniencia física bancaria (F3, horarios/cobertura/ubicación con +0,803/+0,705/+0,701).
 Tercera, existe una dimensión de fricción documental/complejidad bancaria (F4,
 +0,751/+0,784). Son patrones entre afirmaciones, no cuatro segmentos de personas ni cuatro
 coeficientes de efecto sobre contratación. Las comunalidades de 0,507-0,811 indican una
 representación desigual, no perfecta, de cada variable.
 La tabla reporta 62,4% de varianza explicada, sumando los porcentajes 17,4+16,2+15,9+12,9. Sin
 embargo, también muestra cuatro valores propios que suman 6,87 para diez afirmaciones: bajo
 componentes estandarizados, 6,87/10 sería 68,7%, no 62,4%. La inconsistencia se conserva y
 señala; no se inventa una undécima variable ni se cambia el porcentaje silenciosamente. La
 interpretación de cargas y el argumento causal posterior no dependen de resolver esa discrepancia.
 Las páginas físicas 100-101 del rango anterior son tablas financieras; el enunciado de Banco X está
 en 98-99.
 2. ¿Asignar todo a seguridad? No concuerdo con la inferencia del gerente. El ANOVA muestra
 asociación entre ser cliente actual y puntajes de percepción. F1 tiene p reportado 0,000 -se
 comunica como p<0,001- y F4 p=0,031. Clientes tienen mayor F1 (0,1757 frente a -0,2001),
 mientras no clientes mayor F4 (0,1151 frente a -0,1011). F2 y F3 no rechazan igualdad al 5%
 (p=0,861 y 0,136). Esto sugiere que confianza y fricción distinguen grupos en la muestra; no
 demuestra que seguridad sea la palanca que más convierte potenciales en clientes.
 Ser cliente puede cambiar la percepción por experiencia; también pueden existir selección,
 necesidades, edad, ingresos u otros factores que expliquen ambas variables. No se observó una
 campaña ni conversión futura. Un menor valor p tampoco ordena importancia de efecto o retorno:
Examen de Grado UC | materia, preguntas y respuestas 297

[pág. 298]
Marketing - versión clara y reordenada
 depende de variabilidad y tamaño. El análisis factorial resume percepciones; el ANOVA compara
 grupos; ninguno estima por sí solo probabilidad causal de adquisición.
 Mantendría confianza como promesa que debe acreditarse y compararía mensajes de seguridad
 con claridad/simplicidad y flexibilidad en una prueba de captación asignada a potenciales clientes
 comparables. Mediría solicitud, apertura, activación y uso junto a costo, abandono y contribución.
 Antes revisaría población, medición y si se evalúan bancos en general o Banco X; no usaría una
 percepción general como evaluación específica sin comprobarlo. Esa recomendación se basa en la
 brecha del razonamiento del gerente y conserva la utilidad descriptiva del estudio sin prometer un
 efecto no identificado.
 enero 2013 - pregunta 5 - ANOVA, clustering y cuestionario
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 123-124 | convocatoria
 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 A.1. Comparación entre hombres y mujeres. Para comparar medias de una variable cuantitativa
 entre dos grupos independientes usaría un test t -preferentemente Welch si varianzas difieren- o un
 ANOVA de un factor con dos grupos. Se plantea igualdad de medias, se estima diferencia e
 intervalo y se contrasta con variabilidad muestral, revisando independencia y comportamiento de
 los datos. Si se pretende comparar simultáneamente formato y sexo sobre mediciones de los
 mismos participantes, hay medidas repetidas y no corresponde tratar respuestas impresas/digitales
 como observaciones independientes. Sin embargo, la variable requerida “nivel promedio de
 consumo” no está bien medida por todas las preguntas propuestas.
 A.2. Adecuación de preguntas. P1/P2 son ordinales, con etiquetas imprecisas como “a veces” y
 “bastante seguido”; no tienen periodo ni unidades y no garantizan intervalos iguales. Asignar 1-5 y
 promediarlo produciría un puntaje, no horas o frecuencia real. Para esas respuestas puede
 compararse distribución con una prueba apropiada o un modelo ordinal; si se usan medias, hay que
 justificar la aproximación. P3 entrega porcentaje de tiempo dedicado a cada formato, una medida de
 composición, no cantidad absoluta. Dos personas pueden dedicar 50% a digital y leer una hora o
 veinte; con P3 no se estima nivel de consumo promedio en tiempo. Además, ambos porcentajes
 deberían sumar 100 y no son variables independientes. Recomendaría tiempo o frecuencia
 absolutos de cada formato en un periodo definido, con categorías claras si la persona no puede
 recordar cantidades precisas. Luego sí se comparan medias y su incertidumbre. No basta escoger
 ANOVA ignorando que el cuestionario no mide el objetivo.
 B.1. Segmentación por percepciones. Se puede usar análisis de conglomerados para agrupar
 personas con respuestas parecidas y separar grupos entre sí. Antes puede emplearse análisis
 factorial para resumir ítems correlacionados en dimensiones interpretables, pero factores agrupan
 variables y clusters agrupan personas: no son sustitutos. K-medias requiere distancias con sentido
 y variables compatibles; la pregunta binaria P4 no debería combinarse sin cuidado con puntajes
 ordinales de P5 como si todas las unidades fueran equivalentes. Un método adecuado para datos
 mixtos o una transformación justificada puede ser preferible. Se seleccionan y validan grupos por
 estabilidad, tamaño y utilidad comercial; luego se perfilan con demografía.
Examen de Grado UC | materia, preguntas y respuestas 298

[pág. 299]
Marketing - versión clara y reordenada
 B.2. Adecuación de preguntas. P4 pregunta intención futura de reemplazo y usa solo sí/no: omite
 reemplazo parcial, incertidumbre y categorías de medios diferentes. P5 mezcla comprensión de
 texto, novedad, creencias sobre mayores, habilidad propia, ocasiones de uso y gustos de la familia.
 No todas son percepciones de diferencias entre formatos ni todas miden una misma dimensión
 personal. Una afirmación sobre “personas mayores” no demuestra la preferencia del encuestado, y
 una opinión sobre la familia no equivale a la suya. Por tanto, los clusters podrían reflejar edad,
 alfabetización o familia más que la percepción objetivo. Construiría ítems comparables sobre
 legibilidad, comprensión, conveniencia, portabilidad, confianza y ocasión de cada formato, con
 redacción neutral y validación previa, distinguiendo percepción, habilidad e intención. La acción
 comercial se define solo después de comprobar que segmentos responden de manera diferente y
 pueden localizarse. Con estas preguntas originales no declararía automáticamente cumplido el
 objetivo de segmentación.
 agosto 2011 - pregunta 5 - Calidad de clustering
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 81-82 | convocatoria 2
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 1. Elección de solución. Elegiría cuatro segmentos, condicionada a poder sostener propuestas
 diferenciadas y a validar estabilidad. La distancia media interna ponderada cae de
 0,46×21+0,15×14+0,39×15=17,61 a 0,17×10+0,15×11+0,32×13+0,36×19=14,35, reducción
 aproximada de 18,51%. Pero aumentar k suele reducir dispersión, así que no es prueba suficiente.
 El argumento decisivo es que aparecen diferencias accionables, en especial precio/personas frente
 a resolución de reclamos/trato, que la solución de tres mezcla más.
 Con cuatro, S1 (17%) prioriza precio 36, calidad 22, personas 18 y reputación 12; S2 (15%) prioriza
 calidad 41,7 y luego precio 19,9, reputación 12,9 e interacción 11,1; S3 (32%) prioriza confiabilidad
 de entrega 36,3, calidad 28,2 y precio 26,3; S4 (36%) tiene una combinación más equilibrada de
 calidad 23,8, entrega 20,7 y precio 20,5, junto con manejo de reclamos 16,2 y justicia 7,1,
 superiores a otros grupos. Los segmentos tienen tamaños relevantes; no se crea un nicho residual
 diminuto. Aun así, la distancia S3-S4 de 24 y dispersión interna de S4 de 19 aconsejan revisar
 solapamiento y consistencia. Si implementar esas diferencias fuera muy costoso o los grupos no
 fueran estables, tres podría ser una opción más parsimoniosa defendible.
 2. Diferencias e implicancias. En tres, el grupo de 46% combina precio (27,6), calidad (22,8),
 reclamos (10,3), personas (9,4) y otras prioridades; un mensaje único a ese grupo puede diluir
 diferencias. El grupo de calidad, 15%, sigue siendo reconocible en cuatro, y el de entrega pasa de
 39% a 32% con perfil semejante. No debe decirse que cuatro es una subdivisión exacta del primer
 cluster: tamaños y centroides cambian y k-medias reasigna personas; los 17%+36% no equivalen a
 46%.
 La acción comercial sería diseñar una oferta eficiente en costo/trato personal para S1; evidencia de
 desempeño de producto y calidad para S2; coordinación y fiabilidad logística para S3; y servicio de
 resolución y relación más completo para S4, siempre garantizando estándares básicos a todos. La
 empresa puede reasignar recursos de servicio según lo que el cliente valora y cuesta atender. “Dar
 soluciones integrales” y flexibilidad reciben valores bajos en estas respuestas, pero eso no
 demuestra inutilidad universal: el cuestionario obliga a repartir 100 puntos entre solo cuatro
Examen de Grado UC | materia, preguntas y respuestas 299

[pág. 300]
Marketing - versión clara y reordenada
 aspectos, generando datos relativos y dependientes.
 Validaría repetición de la solución, capacidad de asignar clientes nuevos, diferencia de
 compras/márgenes y reacción a acciones antes de desplegar cuatro equipos o tarifas. El caso
 obliga a suponer adecuado muestreo y cuestionario; no usaría objeciones a la encuesta como
 sustituto de comparar los dos anexos. La recomendación combina compactación, separación,
 interpretación y costo de implementar, en lugar de limitarse a escoger el k con menor distancia.
 enero 2014 - pregunta 5 - Causalidad publicitaria
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 146-146 | convocatoria
 1
 Volver al enunciado original
 Respuesta desarrollada para estudio (no oficial)
 a. Comparación. ComRate observa navegación y compras efectivas en el mismo mes: tiene
 validez conductual y permite relacionar exposición con dinero gastado en un ambiente natural. Evita
 depender exclusivamente de una intención declarada. Pero quienes ven anuncios no son asignados
 aleatoriamente: pueden estar buscando productos o tener mayor interés previo. La comparación
 entre expuestos y no expuestos mezcla efecto publicitario con selección, actividad online,
 demografía y otros determinantes. Significancia de una diferencia no la vuelve causal. La
 participación voluntaria y los incentivos del panel pueden limitar representación, y el software solo
 mide las superficies observadas. En el ejercicio se supone que entrar a la página equivale a ver el
 aviso; en una aplicación real esa exposición también tendría que validarse.
 E-Test asigna aleatoriamente a cinco grupos, lo que permite una comparación causal de las
 condiciones de exposición sobre la intención declarada dentro de la tarea. Los grupos 1/2/3
 separan medios, grupo 4 controla participar en la tarea sin aviso y grupo 5 permite detectar efectos
 de la propia tarea. Sin embargo, la variable dependiente es probabilidad subjetiva 1-7, no compra ni
 ventas reales; la tarea de 15 minutos es artificial y puede alterar atención. La población descrita
 -navegantes- tampoco coincide necesariamente con compradores de Faris de los últimos seis
 meses. Aleatorización da validez interna, no elimina una mala medición del resultado ni asegura
 generalización a dieciocho meses.
 b. Recomendación. Con igual costo y fecha, elegiría E-Test como base para identificar el efecto
 causal, porque el problema pregunta impacto y no asociación. Es una recomendación
 condicionada: el diseño tal como está mide impacto en intención, de modo que no concluiría que ya
 estima ventas. Lo mejoraría registrando compras reales durante una ventana predefinida y usando
 la población objetivo del gerente, manteniendo aleatorización y grupos de control. La validez causal
 es más difícil de reparar en la comparación simple de ComRate; medir compras en E-Test requiere
 seguimiento y autorización adecuados, pero no cambia el principio del diseño.
 Si se obligara a ejecutar una propuesta estrictamente sin modificaciones, diría que ninguna
 identifica por completo el efecto sobre ventas: ComRate mide el resultado correcto sin identificación
 causal; E-Test identifica un efecto sobre un resultado sustituto. Una elección distinta puede
 defenderse según la prioridad del gerente, siempre que reconozca ese límite. No basta recomendar
 un experimento genérico sin comparar las propuestas concretas, ni usar R² o significancia para
 resolver la tensión entre validez interna y conducta real. Para el presupuesto de 18 meses, además,
 habría que revisar persistencia, frecuencia, saturación y margen; el mes o la tarea observada no
Examen de Grado UC | materia, preguntas y respuestas 300

# Manual de Finanzas · parte 3 (páginas 128-181)

Fuente: 02_MANUAL_ULTIMATE_FINANZAS_EDG_2027_V2_FORMULAS_CLARAS

[pág. 128]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2012 | pregunta 3
 Convocatoria 1 | página original 93 | APV y escudo tributario
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 • Suponga que el total de la inversión inicial se paga al inicio del proyecto y todos los ingresos y gastos del Estado de
 Resultados Anual Esperado de la empresa, con la sola excepción de la depreciación del ejercicio, son flujos de caja
 que se producen al término de cada año. Suponga además que no hay inflación y que el primer flujo de caja del proyecto
 se produce exactamente un año después de realizada la inversión inicial.
 • Al término de cada año, la empresa reparte a sus accionistas, el flujo de caja residual disponible de la empresa.
 • Se espera que todas las tasas (%) vigentes en este momento en el mercado (tasa de interés de la deuda, tasa exigida por
 los accionistas, tasa de C.C.P.P., tasa de impuesto, etc.) permanecerán invariables en el largo plazo
 • Si usted tiene que obtener alguna tasa de rentabilidad en % o en decimales, hágalo usando cuatro decimales. Ejemplo: si
 E(R) = 15,4632%, al transformar esa tasa en decimales use 0,154632.
 • Al final del enunciado del examen usted puede encontrar tablas de matemáticas financieras, las que son habitualmente
 entregadas simplemente por si el(la) alumno(a) las considera necesarias.
 Suponiendo que las proyecciones de resultados del proyecto estuvieran correctas, que como se ha indicado no existen
 impuestos personales ni inflación y que la estructura de financiamiento utilizada para el proyecto fuese la óptima de largo
 plazo para la empresa, a usted se le pide responder las siguientes preguntas:
 1. Obtenga el V.A.N. del nuevo proyecto de inversión, desde la perspectiva de la empresa o del Activo (o Enfoque de
 “Costo de Capital Promedio Ponderado”). En su respuesta refiérase y sea preciso en la determinación de: el monto
 de la inversión inicial a considerar, los flujos de caja relevantes y la tasa de descuento, que a su juicio se debiera utilizar
 en el cómputo del Valor Actual Neto (VAN), desde la perspectiva del Activo.
 2. Desde la perspectiva de los dueños o accionistas de la empresa (o Enfoque de Dividendos), obtenga el V.A.N. que
 ellos obtendrían en caso que la empresa realizara el nuevo proyecto de inversión. En su respuesta refiérase y sea
 preciso en la determinación de: el monto de la inversión inicial a considerar, los flujos de caja relevantes y la tasa de
 descuento, que a su juicio se debiera utilizarse en el cómputo del Valor Actual Neto (VAN), desde la perspectiva de los
 dueños (o accionistas) del proyecto.
 3. Finalmente, suponga que su máxima capacidad de endeudamiento es de $ 2.400 y que a última hora se le ha presentado
 la posibilidad de emprender un proyecto alternativo al que usted ha analizado en las preguntas anteriores, es decir,
 mutuamente excluyente con el anterior. Este nuevo proyecto, cuya inversión inicial requerida también sería de
 $ 4.000, cuyo riesgo relevante sería el mismo que el del proyecto anteriormente evaluado, también podría usar
 $ 2.400 de deuda (con las mismas condiciones de tasa, plazo, etc. de la deuda anterior) y cuyo V.A.N. (suponiendo que
 este nuevo proyecto es financiado 100% con capital aportado por los dueños) es de $ 100. ¿Cuál de los dos proyectos
 realizaría?. (¿el proyecto original o el nuevo proyecto?). Fundamente numéricamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 128

[pág. 129]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2014 | pregunta 6
 Convocatoria 2 | página original 157 | Alternativas productivas y VAN
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA N* 6
 Catalina es una joven empresaria, egresada de Ingeniería Comercial de la PUC, que ha estado operando un
 negocio que consiste en vender trajes de novia a través de su local Novia”s. Lo que ella hace, es vender vestidos
 en Chile, mandados a hacer a pedido por las novias. Actualmente, Catalina envía el modelo y las medidas a una
 pequeña fábrica en Vietnam, lugar donde los vestidos son pre-confeccionados y posteriormente enviados a Chile.
 Luego, en Chile, el vestido es probado por la novia y se procede a terminar su confección, afinando únicamente
 sus detalles finales,
 Lamentablemente, en los últimos meses Catalina ha venido enfrentando algunos atrasos en el cumplimiento de los
 pedidos que deben llegar desde Vietnam, lo que acarrea muy serios problemas con sus clientas. Como resultado
 de lo anterior, Catalina está evaluando la posibilidad de fabricar los vestidos en Chile.
 A usted se le pide evaluar el proyecto que ella tiene en mente, esto es, evaluar la conveniencia financiera de
 dejar de importar los vestidos y pasar a fabricarlos integramente en Chile.
 Algunos datos que Catalina estima deberá tener en Cuenta en el análisis de su decisión, son los siguientes:
 * Se supondrá que hoy es el 31/12/2014 (t = 0) y que Catalina debe tomar hoy la decisión de seguir importando
 o comenzar a fabricar los vestidos en Chile.
 e En primer lugar, Catalina sabe que en el caso de fabricar, ella tendría que firmar hoy (t = 0) un contrato de
 arriendo de un pequeño local adicional al que arrienda actualmente, en el que podría fabricar los vestidos, cuyo
 costo anual sería de M$400. Los pagos de arriendo anuales serían hechos por adelantado, por lo que al
 finalizar cada año, excepto el año en que termina el contrato, ella debe pagar el arriendo completo del año que
 comienza el día siguiente. Adicionalmente a los pagos anuales de arriendo, la empresa tendría que pagar en
 efectivo y al momento de firmar el contrato, una garantía correspondiente a un año de arriendo (M$400) El
 contrato de arriendo sería por tres años, y en él se estipula que al término del segundo año de vigencia del
 contrato, esto es, el 31/12/2016, a Catalina se le devolverá, en efectivo, el monto total de la garantía (M$400).
 o La remodelación y adaptación del local, para dejarlo en condiciones de comenzar a operar como fábrica,
 tendrían un costo de M$200, los que tendrían que ser pagados completamente y en efectivo al momento de
 firmar el contrato de arriendo (t = 0). Para efectos tributarios, la empresa puede llevar a gasto al término del
 primer año de operación (no antes), el costo '£0tal de la remodelacmn
 e Finalmente, se sabe que en caso de optar por la produccwn propia de ]os vest1dos la empresa Novia's tendrá
 que comprar hoy, pagando al contado, una máquina adicional que tendría un costo de M$1.500, una vida útil
 de 3 años y para efectos tributarios se podría depreciar de mánera lineal y sin valor residual.
 e El Cuadro N*%1 de la página siguiente presenta la siguiente información:
 - Estado de Resultados proyectado para los próximos 3 años, en el evento en que la empresa Novia”s optase
 por continuar importando todo desde Vietnam (columna IM).
 - — El Estado de Resultados proyectado para los próximos 3 años, en el evento en que la empresa Novia”s
 decidiera dejar de importar y pasara a un esquema de producción propia (columna PP).
 o En lo que se refiere a inversión en Capital de Trabajo (CT”), se sabe que en el caso de optar por la producción
 propia (PP), la operación de la empresa de Catalina requeriría, al iniciar sus operaciones y luego al término de
 cada año, de una inversión en CT* algo mayor que la que se necesitaría en el caso de seguir con el modelo de
 importar los vestidos (IM). El Cuadro N?2 de la página siguiente muestra la inversión en Capital de Trabajo
 reguerida al término de cada año (para iniciar el año siguiente de operaciones), para ambas alternativas (IM o
 PP). Se sabe, en todo caso, que al 31/12/2014 y antes de evaluar la opción de fabricar los vestidos en Chile, la
 empresa ya cuenta con una inversión en CT* de M$2.000.
 9 Se sabe también, que para operar de manera eficiente, sea que la empresa decide seguir importando o que
 comience a fabricar los vestidos, ella deberá realizar al término de cada año reinversiones por el equivalente a
 1,2 veces el gasto por depreciación anual. Estas reinversiones no afectan el monto del gasto anual por
 depreciación que aparece en el Cuadro N? 1 para las alternativas IM y PP.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 129

[pág. 130]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2014 | pregunta 6
 Convocatoria 2 | página original 158 | Alternativas productivas y VAN
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 * Para estar más tranquila con las estimaciones de venta, la empresa ha encargado un estudio de mercado cuyo
 costo es de M$1.000 y que debe ser pagado en efectivo íntegramente el primer día del proyecto (t = 0).
 * La política de dividendos de la empresa, es repartir al término de cada año, el monto total de efectivo residual
 disponible para los dueños.
 * Se ha determinado que la tasa de actualización relevante para los flujos de caja que recibiría Catalina, única
 dueña de la empresa, es de 10% anual. Se espera que esta tasa se mantenga constante en el futuro.
 * Los flujos de caja, con la sola excepción de la inversión inicial, toda la cual se produce el 31/12/2014 (t = 0),
 se producen al término de cada año. Suponga también que la empresa mantiene únicamente activos
 operacionales, que no hay impuestos personales, inflación, ni IVA. '
 * Suponga que, en caso de continuar el negocio importando los vestidos, al término del tercer año la dueña de
 Novia's podría vender el negocio “en marcha” (funcionando) y recibir M$45.000 en efectivo, luego de haber
 considerado tanto la deuda del negocio vigente en ese momento, como los impuestos que pudiera corresponder
 pagar. Por otra parte, si se opta por cambiar hoy a producción propia, dicho valor a recibir por parte de la
 dueña sería de M$60.000. -
 Cuadro N'1
 Definiciones: Estados de Resultados Proyectados
 IM = Con Importación de Vestidos Novia's
 PP = Con Producción Propia (Montos son en Miles de $)
 2015 2016 2017
 IM PP M PP 1M PP
 Ingresos por Venta 8.000 12.000 10.000 14.000I 12.000 18.000|
 - Costo de Ventas -1,600 -3.000 -2.000 -3.500 -2.400 -4.500
 - Gastos de Administración y Ventas IGAV]
 GAY Fijos -800 -1.440 -1.000 -1.680 -1.200 -2.160|
 GAV Variables -400 -1.200 -500 -1.400 -600! -1.800
 - Depreciación del Ejercicio H ] [2] -500 -1.000 -500: -1.0001 -500 -1.000
 = Resultado Operacional 4.700 5.360 6.000: 6.420| 7.300 8.540
 - Gastos Financieros -1.000 -1.000 -1.000: -1.000 -1.000 -1.000
 - Gasto No Operacional (Remodelación) -200
 - = Utilidad Antes de Impuesto 3.700 . 4.160 5:000 5:420 6300 7.540|
 - Impuesto a las Utilidades (25%) -925 -1.040J . — -1.2508. --1,355 -1,575 -1.885
 = Resultado del Ejercicio (Utilidad Neta) 2.775 — 3.120 3,750F. 4.065 - 4725 5.655|
 11]: El total de la depreciación del ejercicio del año de la empresa, [2] La opción de PP incluye M$500 de depreciación
 está reflejado en esta cuenta. Las cuentas "Costo de Venta" anual por la nueva máquina que habría
 Y "GAV”, no incluyen gastos por depreciación. que comprar,
 Inversión en Capital de Trabajo Operacional Reguerida
 Novia's
 (Montos son en Miles de $)
 31/12/2014 31/12/2015 31/12/2016 31/12/2017
 Inversión en Capital de Trabajo Importaciones (IM) 2.000 [3] 2.500 3.000 3.500
 Inversión en Capital de Trabajo Producción Propia_('f'l') 4.200 4.900 6.300 8.400
 [3]: 31/12/2014 (IM): Corresponde a la Inversión en CT* que ya tiene la empresa al 31/12/2014.
 PREGUNTA
 Evalúe financieramente la conveniencia de dejar de importar los vestidos y pasar a fabricarlos íntegramente en
 Chile. — .
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 130

[pág. 131]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2015 | pregunta 3
 Convocatoria 2 | página original 177 | Aumento de capital y derechos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N*3
 La compañía OKLEDOK S.A. cuenta actualmente con un capital de 5.000 de acciones en circulación
 (emitidas, suscritas y pagadas) y su propiedad está dividida entre un grupo que controla el 51% de las
 acciones y varios accionistas minoritarios que son dueños del 49% restante. En este momento la
 capitalización de mercado de OKLEDOK S.A. o el valor de mercado de su patrimonio es de US$50.000 y la
 empresa tiene un monto de deuda total cuyo valor de mercado alcanza los US$30.000. Las acciones de
 OKLEDOK S.A. se transan tanto en Chile como en el extranjero.
 La empresa ha estimado necesario realizar nuevas inversiones que le permitan mantener el liderazgo que ella
 tiene en la región y para ello necesita llevar a cabo un aumento de capital por la suma de US$10.000.
 En este momento, el grupo controlador de la compañía está analizando una propuesta con relación al precio
 de emisión de las nuevas acciones que se requerirían para recaudar los US$10.000 de fondos necesarios para
 las futuras inversiones, En la discusión respecto del precio al cuál emitir las nuevas acciones, han surgido
 dos posturas: la de quienes plantean que se debieran emitir acciones a US$8 cada una y la de quienes
 consideran que se debieran emitir a US$16 cada una. El precio de emisión aún no ha sido decidido.
 Suponga que, antes de la emisión de las nuevas acciones, Don Pepe es dueño de 1.000 acciones de
 OKLEDOK S.A., y que toda su riqueza consiste en esas 1.000 acciones, más US$2.000 que él tiene en
 efectivo.
 Por otra parte, se sabe que de acuerdo a la legislación actualmente vigente en el país, existe lo que se conoce
 como el derecho preferente de suscripción, que consiste en que, cuando una empresa emite nuevas acciones,
 dichas acciones deben ser ofrecidas en primer lugar, al precio de emisión acordado, a sus actuales
 accionistas, en la proporción de la propiedad que cada uno de ellos tenía de la empresa al momento de la
 emisión, De este modo, el derecho preferente de suscripción otorga, a todos los accionistas, la posibilidad de
 mantener, luego de la emisión de nuevas acciones, el porcentaje de la propiedad que cada uno de ellos tenía
 antes del aumento de capital.
 PREGUNTAS
 1. Suponga que todos los accionistas de OKLEDOK S.A.(mayoritarios y minoritarios), han decidido
 suscribir el aumento de capital y por lo tanto comprar las acciones en los porcentajes que les permitirán
 mantener la participación en la propiedad que cada uno de ellos tenía antes de la emisión de las nuevas
 acciones,
 a. Si las nuevas acciones hubiesen sido emitidas a US$8 cada una; obtenga el valor de la riqueza de
 Don Pepe luego de la emisión de las nuevas acciones. Para ello, indique expresamente tanto el
 número total de acciones que Don Pepe tendría luego de la nueva emisión, como el valor de
 mercado por acción de OKLEDOK S.A. luego de la nueva emisión. Para números no enteros, use
 cuatro decimales. Fundamente su respuesta mostrando los cálculos necesarios.
 b. Responda la pregunta “a” anterior, suponiendo ahora que las nuevas acciones hubiesen sido
 emitidas a US$16 cada una. Justifique su respuesta mostrando los cálculos pertinentes.
 2. Suponga ahora, y sólo para efectos de responder esta pregunta, que las normas legales indicaran que
 si en la primera oportunidad en que se ofrece a los actuales dueños comprar las nuevas acciones del
 aumento de capital (primera vuelta), un accionista no hace uso de su derecho preferente de suscripción,
 las nuevas acciones emitidas y no compradas por los actuales accionistas, en dicha primera vuelta, serán
 ofrecidas en una segunda vuelta, a los accionistas que compraron en la primera oportunidad, al mismo
 precio de suscripción original, pudiendo entonces estos últimos aumentar su porcentaje de participación
 en la propiedad de la empresa. El accionista que en primera vuelta no compró acciones de la nueva
 emisión, no puede vender en el mercado esos derechos de compra o suscripción de nuevas acciones.
 Suponga ahora que Don Pepe no tuviera los recursos que le permitirían comprar las nuevas acciones del
 aumento de capital, pero él sabe que en este caso, los accionistas mayoritarios, quienes en primera
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 131

[pág. 132]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2015 | pregunta 3
 Convocatoria 2 | página original 178 | Aumento de capital y derechos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 vuelta ya suscribieron el porcentaje que les correspondía, estarán dispuestos a comprar el mayor número
 de acciones posibles de aquellas que se ofrezcan en segunda vuelta, cualquiera que sea el valor de
 suscripción que ellas tengan.
 El día en que se deba decidir el precio de suscripción de las acciones de la nueva emisión (US$8 o
 US$16), ¿por cuál precio de suscripción debería votar Don Pepe y por qué?
 Suponga ahora que en la primera vuelta en que se ofrecen las nuevas acciones, un accionista decide no
 hacer uso de su derecho de suscripción preferente. Suponga también que estos derechos preferentes
 pueden ser vendidos en el mercado y que el accionista controlador ha decidido utilizar el precio menor
 (US$8) para realizar el aumento de capital de OKLEDOK S.A. Finalmente, suponga que todos los
 accionistas antiguos (controladores y minoritarios) tienen el derecho preferente a suscribir su fracción
 (prorrata) del aumento de capital y que, como se ha indicado en esta pregunta, dicho derecho preferente
 puede ejercerse (pagando la fracción correspondiente del aumento de capital) o venderse a un tercero.
 a. ¿A qué instrumento financiero conocido se asemeja el derecho preferente de suscripción? Explique
 su respuesta.
 b. Algunos accionistas minoritarios, han efectuado sendas declaraciones a los medios de
 comunicación, denunciando un desmedido afán de lucro y la “expropiación” que pretende llevar a
 cabo el accionista controlador al emitir las nuevas acciones “a precios tan bajos”. ¿Está usted de
 acuerdo con este planteamiento de los minoritarios? Fundamente numéricamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 132

[pág. 133]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2025 | pregunta 1
 Convocatoria 1 | página original 427 | CAPM de proyecto y emisión
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N*1
 La empresa de arriendo de vehículos “El Auto Prestado” (*EAP”) es una empresa que durante los últimos 50
 años se ha dedicado al arriendo de autos. Hoy, que es 1 de enero de 2025 (1/1/25) “EAP” ha observado que el
 negocio de arriendo de autos en los últimos años ha experimentado una fuerte caída, pero al mismo tiempo ha
 constatado el sistemático y casi exponencial aumento en la demanda por las compras “on line”, a través de las
 innumerables plataformas hoy disponibles para adquirir bienes, principalmente en el rubro de alimentos y
 bebidas, incluyendo el despacho al domicilio de los clientes. Esta realidad, ha Ilevado a la empresa a evaluar
 la posibilidad de destinar los autos que no se estén arrendando, para ofrecer el servicio de envío o traslado de
 pedidos a domicilio. La empresa sabe que se trata de un negocio completamente distinto al que ha gestionado
 por años, pero la disminución de la demanda en su negocio actual la ha llevado a evaluarlo.
 El nuevo negocio de envíos a domicilio de distintos tipos de pedidos le significaría a “EAP” tener que realizar
 hoy 1/1/25 (t=0) una inversión inicial total de M$90.000 (M$ = Miles de $) en nuevos activos. Por otra parte,
 “EAP” ha estimado que esta inversión estaría en condiciones de generar un flujo de caja anual (total de entradas
 menos total de salidas de caja anuales generadas por el proyecto) a perpetuidad de M$38.000 anuales. Se
 espera que el primer flujo anual que genere el proyecto se reciba dentro de exactamente un año, es decir el
 31/12/25 (t=1).
 En este momento, 1/1/25, el total del Patrimonio de “EAP” se encuentra distribuido entre muchos accionistas
 que son dueños(as) de los 20 millones de acciones comunes de la empresa, cada una de las cuales se está
 transando hoy en el mercado a $20. El beta de este Patrimonio se ha estimado en 1,0. Adicionalmente, una
 parte de los activos de “EAP” se financia con deuda financiera, la que en este momento tiene un valor de
 mercado de M$100.000; el beta de esta deuda financiera se ha estimado en 0,25. “EAP” no tiene ningún otro
 tipo de deudas. Se sabe que del total de activos que “EAP” mantiene en este momento, M$90.000 son
 inversiones en activos libres de riesgo, de fácil liquidación (depósitos a plazo, valores negociables, etc.), para
 uso en su gestión operacional y para destinar a eventuales proyectos de inversión. -
 Para evaluar el nuevo proyecto, un analista financiero ha estimado adecuado usar el modelo C.A.P.M. (Capital
 Asset Pricing Model) o M.V.A.C. (Modelo de Valoración de Activos de Capital) para estimar la tasa de
 descuento que debe usar para dicha evaluación y ha recurrido a la información disponible a partir de la cual
 espera obtener una estimación de dicha tasa de descuento. Lo que el analista sabe es que hay una empresa, la
 empresa “SERVIMOS” cuyo negocio principal es precisamente el de ofrecer el servicio de envío de pedidos
 a domicilio. La información que el analista conoce de la empresa “SERVIMOS” es que hoy ella tiene un
 Patrimonio a valor de mercado de M$400.000 y que no tiene deudas. También sabe que la mejor estimación
 del beta del Patrimonio de “SERVIMOS” es de 1,2. Por último, el analista ha averiguado que “SERVIMOS”
 mantiene entre sus activos una inversión en activos no operacionales, esto es una inversión no necesaria para
 el desarrollo de su actual negocio de ofrecer el servicio de envío de pedidos a domicilio. Esta inversión en
 activos no operacionales corresponde a un depósito a plazo por un valor total de M$100.000 y que se considera
 como una inversión libre de riesgo.
 Suponga que:
 * El mercado de capitales es perfecto
 * No hay inflación
 e Latasa libre de riesgo (Rr) es igual a 8%
 * El premio por riesgo de mercado (Ry - Rr) es de un 7,5%
 * Todoslos flujos, con la sola excepción de la inversión inicial, se producen al término de cada año.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 133

[pág. 134]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2025 | pregunta 1
 Convocatoria 1 | página original 428 | CAPM de proyecto y emisión
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Se Pide:
 Responda cada una de las siguientes preguntas, presentando el desarrollo de sus respuestas de manera ordenada
 y fundamentando la respuesta de manera precisa. Cada respuesta, cuando lo requiera, debe estar acompañada
 de todos y cada uno de los cómputos que la sustentan. Trabaje los valores monetarios en M$ (Miles de $).
 1. Obtenga el VAN o VPN del proyecto que está pensando desarrollar la empresa “EAP” (ofrecer el servicio
 de envío de pedidos a domicilio), suponiendo que en caso de llegar a ejecutarse el proyecto se financiaría
 enteramente con nuevo capital.
 Para las preguntas 2 y 3 que se plantean a continuación, suponga ahora que la empresa ha decidido hacer
 pública su intención de llevar a cabo el nuevo proyecto de inversión, entregando al mercado todos los
 antecedentes necesarios y relevantes para su evaluación.
 2. Suponga, en primer lugar, que para financiar el nuevo proyecto la empresa “EAP” utilizaría M$45.000 de
 sus actuales inversiones en activos libres de riesgo y de fácil liquidación, y que los M$45.000 restantes los
 obtendría a través de un aumento de capital a través de la emisión de nuevas acciones comunes. Los actuales
 accionistas de la empresa “EAP” han informado su decisión de no participar del aumento de capital
 ¿Cuántas acciones debiera emitir “EAP” para obtener el saldo de M$45.000 que ella requiere para
 completar el financiamiento del nuevo proyecto, adicionales a los M$45.000 con los que la empresa ya
 cuenta? Fundamente su respuesta mostrando los cálculos necesarios.
 3. Suponga ahora que, para el financiamiento del nuevo proyecto de inversión la empresa “EAP” decidiera
 utilizar M$45.000 de sus inversiones en activos libres de riesgo y de fácil liquidación y que los M$45.000
 restantes los obtuviese a través de la emisión de nueva deuda financiera. La nueva deuda sería emitida en
 condiciones de mercado, a un plazo perpetuo (es decir, “EAP” sólo tendría que pagar los intereses de la
 nueva deuda al final de cada año, pero el principal o monto original de la deuda, “nunca” se paga o si Ud.
 lo prefiere se renueva anualmente todos los años, durante los próximos “infinitos” años). Suponga, además
 que la nueva deuda tiene el mismo riesgo que la deuda actual de “EAP” (beta igual a 0,25). “EAP” ha
 estimado que la emisión de esta nueva deuda no haría cambiar el riesgo de su deuda actual u original de
 M$100.000 (su deuda al 1/1/25 antes del nuevo proyecto) lo que significaría que el beta de dicha deuda
 actual se mantendría en 0,25.
 ¿Cuál sería el VAN o VPN que tendría el nuevo proyecto de inversión de la empresa “EAP” (servicio de
 envío de pedidos a domicilio) y el Costo de Capital Promedio Ponderado (C.C.P.P.) o tasa de descuento
 que se debiera usar para la evaluación de dicho nuevo proyecto de inversión, bajo esta nueva forma de
 financiamiento? Fundamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 134

[pág. 135]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2018 | pregunta 3
 Convocatoria 1 | página original 258 | DuPont y alfa
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N'3
 de la
 Suponga que hoy, 1 de enero de 2018, los siguientes son los valores esperados para el año 2018 de parte
 financiera de dos empresas (“E-1” y “E-2”), que pertenecen a distintas industrías y que operan en
 información
 Chile:
 Valores Esperados 2018 Empresa “E-1” Empresa “E-27”
 Utilidad (Resultado) Operacional Desconocido $36
 Rentabilidad de los Activos Desconocido 6%
 2,25 . 2,0
 Rotación de Activos = Ventas/Activos
 Utilidad Neta $54 Desconocido
 Margen Neto = Utilidad Neta/Ventas 4% 2%
 1,0 2,0
 Razón de Endeudamiento = Deuda Total/Patrimonio
 Beta Activos 1,8 Desconocido
 Desconocido 1,2
 Beta Patrimonio
 Beta Deuda 0 0
 Supuestos e Información Complementaria:
 e Las empresas sólo tienen activos operacionales.
 al término
 e Todas las partidas del Estado de Resultados de las dos empresas, son flujos de caja que se producen
 del año.
 * Toda la deuda de las empresas es deuda financiera, libre de riesgo, que genera intereses de manera explícita.
 Rel es igual
 » Latasa libre de riesgo en la economía es de un 3% anual y el premio por riesgo de mercado [EC(Rm) —
 a 5% anual.
 financiero
 e El único resultado no operacional presente en el Estado de Resultados de las empresas, es el gasto
 (intereses de la deuda).
 e No hay inflación ni impuestos.
 0
 e Todos los valores de activos, pasivos y patrimonio que se han usado para la obtención de los indicadores
 razones financieras de las empresas, en la tabla anterior, o que se puedan obtener a partir de la información
 disponible, corresponden a valores económicos. -
 permitirán
 e Se sabe que durante el año 2018, ambas empresas (*E-1” y “E-2”) realizarán transacciones que les
 por lo tanto al 31/12/2018, tanto el monío total de sus activos, como la relación
 mantener, durante todo el año, y
 año 2018).
 (Deuda Total/Patrimonio), que ellas tenían al finalizar el año 2017 (0 lo que es mismo, al comenzar el
 valor de la
 e En aquellas razones financieras en las que intervengan variables de flujo y variables de stock, use el
 variable de stock al comienzo del año 2018, es decir, al 1/1/18.
 * Suponga que ambas empresas (*E-1” y “E-27), tienen la política de distribuir al término de cada año, un
 dividendo equivalente al 100% de sus utilidades.
 1 de enero
 e Se sabe que el mercado accionario es eficiente, esto es, toda la información relevante y conocida el
 la empresa, es información que está incorporada en el precio de mercado de la
 de 2018, respecto del futuro de
 acción a esta fecha.
 e En sus cómputos, use dos decimales
 se
 Sobre la base de Ja información que se le ha proporcionado, a Ud. se le pide responder las preguntas que
 le formulan a continuación:
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 135

[pág. 136]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2018 | pregunta 3
 Convocatoria 1 | página original 259 | DuPont y alfa
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTAS
 se entregó en
 Suponga que un inversionista sólo cuenta con la información de las empresas “E-1” y “E-2” que
 o no una acción
 el enunciado anterior y que hoy (1 de enero de 2018) él debe tomar una decisión de si comprar
 recomendaría
 de alguna de estas dos empresas, para venderlas exactamente dentro de un año (el 31/12/18). ¿Le
 En caso de responder
 Ud. al inversionista en cuestión la compra de una acción de alguna de estas dos empresas?
 Usted debe fundamentar su respuesta tanto a través de
 positivamente, ¿cuál de ellas le recomendaría adquirir?
 que respalde su recomendaci ón, como también a través de cálculos numéricos
 un argumento conceptual
 a mostrar si la compra el 1 de enero de 2018, crearía o no riqueza para el inversionist a.
 orientados
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 136

[pág. 137]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2014 | pregunta 3
 Convocatoria 1 | página original 142 | DuPont, ROA y ROE
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 3
 En enero de 2014, Malaquías Matamala, un alumno en práctica en el banco de inversiones “Banco
 del Sur”,
 fue llamado a la oficina del Jefe del Departamento de Análisis Financiero de dicho Banco.
 Los siguientes son los comentarios hechos en esa oportunidad por el Jefe de Análisis Financiero del
 Banco a
 nuestro estimado Malaquías (se reproducen a continuación en letra itálica o cursiva):
 Malaquías, aquí están los Estados Financieros de la “Viña Los Huasos” del año 201 3,
 correspondiente a la información del último ejercicio contable disponible de la Viña, y del año
 2008
 (Ver Figuras N*1 y N?2 en la página siguiente). Nuestro departamento de inversiones ha mantenido
 acciones de la “Viña Los Huasos” desde comienzos del año 2008. Como usted sabe, al seleccionar
 las
 inversiones que hace nuestro Banco, se pone mucho énfasis en el análisis de la “calidad” de
 las
 rentabilidades contables de las empresas en las que se invierte, esto es, se pone especial cuidado
 en
 tratar de entender las causas o variables que explican la obtención de dichas rentabilidades ), en
 particular, de las rentabilidades del patrimonio de las empresas en que se invierte.
 La Memoria Anual del año 2013 de la “Viña Los Huasos”, muestra una preocupante disminución
 en
 la rentabilidad patrimonial de sus dueños. Pues bien, nuestra gente de inversiones quiere que
 nosotros le comentemos respecto de la forma como la “Viña Los Huasos” ha obtenido sus
 rentabilidades sobre el patrimonio en el último tiempo, comparando su rentabilidad patrimonial del
 año 2013, con la rentabilidad del patrimonio obtenida por la empresa durante el año 2008.
 A usted se le pide que entregue un análisis o informe en el que indique, acompañando ordenadamente
 los
 cómputos que avalan sus cifras, cuáles son a su juicio las causas o factores de mayor importancia que
 explican la disminución que ha experimentado la rentabilidad patrimonial (rentabilidad de los dueños) de la
 “Viña Los Huasos”, cuando se comparan los años 2008 y 2013. Su informe debe tomar en cuenta los
 distintos elementos o variables que, desde una perspectiva financiera, determinan la rentabilidad del
 patrimonio de una empresa.
 Sea profundo en su análisis y específico en su respuesta y además tome en consideración las notas y
 supuestos que se detallan a continuación:
 Notas y supuestos:
 * — En los cálculos aritméticos que usted haga (particularmente razones financieras), use dos decimales.
 Cuando deba obtener un porcentaje (%), expréselo con dos decimales. Ejemplo: 10,45%
 * — Cuando usted deba calcular una razón financiera en la que en el numerador tiene un “flujo” y en el
 denominador un “stock”, para la variable de “stock” use el valor que ella tiene al final del período,
 Este supuesto se hace únicamente por razones de orden práctico que se aplican a este Caso.
 * No hay inflación en el período 2008 — 2013.
 * — Suponga que la empresa “Viña Los Huasos” no ha tenido cambios significativos en sus criterios y
 prácticas contables durante los últimos 5 años.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 137

[pág. 138]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2014 | pregunta 3
 Convocatoria 1 | página original 143 | DuPont, ROA y ROE
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Figura N*1
 "Viña Los Huasos"
 Balances
 (A131 de diciembre de cada año; cifras en Millones de $)
 2008 2013
 ACTIVOS
 Activos Corrientes o Circulantes:
 Caja 315 580|
 Cuentas por Cobrar Existencias 2.594 2.124
 Existencias 2.257 2.274
 Total de Activos Corrientes o Circulantes 5.166 4.978
 Activos de Largo Plazo Operacionales:
 Plantas y Equipos (Neta) 2.616 2.074
 Terrenos 159 592
 Total Activos de Largo Plazo Operacionales: 2.775 2.666
 Activos de Largo Plazo No Operacionales:
 Inversiones Financieras de Largo Plazo 2.131 2.196
 Total de Activos (Operac. + No Operac.) 10.072 9.840
 PASIVOS + PATRIMONIO
 Pasivos Corrientes o Circulantes:
 Cuentas por Pagar a Proveedores 69% 752
 Ingresos Percibidos por Adelantado 1.000 600
 Dividendos por Pagar 73 118
 Impuestos por Pagar 337 636
 Otros Gastos Devengados por Pagar 1.128 786
 Préstamos Bancarios de Corto Plazo 645 242
 Total Pasivos Corrientes o Circulantes 3,234 2.892
 Pasivos de Largo Plazo:
 Préstamos Bancarios de Largo Plazo 1.195 728
 Bonos de Largo Plazo 519 522
 Total Pasivos de Largo Plazo (Deuda Financiera) 1.714 1.250
 Total de Pasivos 4.948 4,142
 Patrimonio:
 Capital Pagado 1.000 1.000:
 Utilidades Retenidas 2410 3448
 Total de Patrimonio 3.410 4,448
 Total Pasivos + Patrimonio 10.072 9.840
 Figura N2
 "Viña Los Huasos"
 (2008 versus 2013)
 (Montos son en Millones de $)
 2008 2013
 Ingresos por Venta de Bienes y Servicios 13.500 13.000
 - Costo de Ventas -10.125 -9.750
 - Gastos de Administración y Ventas [GAV] -2.295 -1.950
 - Depreciación del Ejercicio [1] -314 -249
 = Resultado Operacional 766 1.051
 + Otros Ingresos 170 176
 - Gastos Financieros -137 -175
 = Utilidad Antes de Impuesto 799 1.052
 - Impuesto a las Utilidades -280 -526
 = Resultado del Ejercicio (Utilidad Neta) 520 526
 [1]: El total de la depreciación del ejercicio del año de la empresa, está reflejado
 en esta cuenta. Las cuentas "Costo de Ventas" y "GA V", no incluyen gastos
 por depreciación.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 138

[pág. 139]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2015 | pregunta 3
 Convocatoria 1 | página original 164 | FCF, perpetuidad y financiamiento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N'3
 Suponga que hoy es 31/12/14 y el balance, a valores de mercado, de la empresa Minera Nacional S.A, (MINASA), de
 giro Explotación Minera, es el siguiente:
 ACTIVOS PASIVOS Y PATRIMONIO
 Caja $ 500 Deuda de Largo Plazo $ 3.600 ()
 Yacimiento $ 5.500 Patrimonio $ 2.400 (
 Total $ 6.000 Total $ 6.000
 (*): Valores de mercado antes de que se haga pública la posibilidad que tiene la empresa de invertir en un nuevo proyecto,
 que se describe más adelante, y que en este momento está siendo analizado en el Directorio.
 El mismo día 31/12/14, el Directorio de la empresa debe decidir si emprender un nuevo proyecto y la forma de
 financiarlo, en caso que se opte por llevarlo a cabo. Este nuevo y único proyecto que la empresa tiene como
 alternativa de inversión, es una expansión operacional de la compañía y tiene el mismo riesgo relevante que sus
 actuales inversiones. Las principales características del proyecto que está evaluando son las siguientes:
 e Lainversión inicial sería de $3.000 (el total de ella se debe realizar al inicio de la vida del proyecto) y se destinará
 integramente a la adquisición de activos operacionales que se depreciarán contablemente a razón de $500 por año.
 * El 60% del total de recursos necesarios para el financiamiento de la inversión inicial, es decir $1.800, sería
 financiado usando un préstamo de un Banco que cobra un interés de 10% anual, equivalente a la tasa de mercado
 para este tipo de deuda. El interés debe ser pagado al término de cada año. Sin embargo, se sabe que si al término
 de cada año la empresa paga al Banco los intereses de la deuda, el préstamo de $1.800 se puede renovar de manera
 indefinida. Los restantes $1.200 de la inversión inicial del proyecto, serían financiados con el aporte de un nuevo
 socio, al que los actuales dueños, a cambio de dicho aporte, le han ofrecido una participación del 30% en la
 propiedad de la empresa.
 e La decisión que la compañía ha tomado para el financiamiento de esta inversión (60% nueva deuda y 40% nuevo
 capital), le permite operar con lo que ella estima es su nivel de endeudamiento económico óptimo de largo plazo y
 la política es mantener dicho nivel a perpetuidad.
 e Los resultados esperados del nuevo proyecto, en términos anuales, son los que se presentan a continuación (la
 depreciación del ejercicio, única partida del estado de resultados que no es flujo de caja al final de cada período,
 se incluye dentro de los “Gastos de Administración y Ventas”). Para todos los efectos prácticos, estos resultados
 anuales se mantendrán constantes en forma indefinida:
 Estado de Resultados Anual Esperado del Nuevo Proyecto
 Ventas $ 5.000
 Costos de Explotación (3.000)
 Margen Bruto 2.000
 Gastos de Administración y Ventas (1.360)
 Resultado Operacional 640
 Intereses (10%) (180)
 Resultado antes de Impuestos - 460
 Impuestos (30%) — (138)
 Utilidad Neta - $ 322
 Información Adiciona! y Supuestos:
 e Se estima que los flujos de caja anuales esperados del proyecto son perpetuos y constantes. La perpetuidad de
 estos flujos se logra gracias a que al término de cada año la empresa reinvertiría la suma de $438. No obstante
 estas reinversiones anuales, se sabe que en el futuro y de manera permanente, el gasto contable anual por
 depreciación del nuevo proyecto, se mantendría en $500 lo que perm1t1r1a mantener, de manera perpetua, el
 Resultado Operacional anual esperado.
 e Latasa de impuestos corporativos es de 30%. No hay impuestos personales.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 139

[pág. 140]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2015 | pregunta 3
 Convocatoria 1 | página original 165 | FCF, perpetuidad y financiamiento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 La tasa de Costo de Capital Promedio Ponderado (C.C.P.P.) relevante para la evaluación financiera del nuevo
 proyecto es de 15,0% (C.C.P.P. anual, después de impuestos corporativos).
 El total de la inversión inicial se paga al inicio del proyecto y todos los ingresos y gastos del Estado de
 Resultados Anual Esperado de la empresa, con la sola excepción de la depreciación del ejercicio, son flujos
 de caja que se producen al término de cada año. Suponga además que no hay inflación y que el primer flujo de
 caja del proyecto se produce exactamente un año después de realizada la inversión inicial.
 Al término de cada año, la empresa reparte a sus accionistas el flujo de caja residual disponible.
 Se espera que todas las tasas (%) vigentes en este momento en el mercado (tasa de interés de la deuda, tasa
 exigida por los accionistas, tasa de C.C.P.P., tasa de impuestos, etc.) permanecerán invariables en el largo plazo.
 Si usted tiene que calcular alguna tasa de rentabilidad en % o en decimales, hágalo usando cuatro decimales,
 Ejemplo: si r = 15,4632%, al transformar esa tasa en decimales use 0,1 54632 y viceversa.
 Suponiendo que las proyecciones de resultados del proyecto estuvieran correcías, que no existen impuestos
 personales ni inflación y que la estructura de financiamiento utilizada para el proyecto fuese la óptima de largo plazo
 para la empresa, a usted se le pide responder las siguientes preguntas:
 1) Obtenga el Valor Actual Neto (VAN) del nuevo proyecto de inversión, desde la perspectiva de la empresa o del
 activo (Enfoque de “Costo de Capital Promedio Ponderado”). En su respuesta refiérase y sea preciso en la
 determinación de: el monto de la inversión inicial a considerar, los flujos de caja relevantes y la tasa de descuento
 que a su juicio se debiera utilizar en el cómputo del Valor Actual Neto (VAN).
 2) Uno de los Directores de la empresa, el Sr. Concerned, preocupado por los cambios que ha observado en la
 legislación tributaria, ha planteado que él no descarta la posibilidad de que el Parlamento apruebe una ley que
 establezca que, a partir de este mismo momento (31/12/14), los intereses de las deudas de las empresas no puedan
 ser considerados como gasto para efectos de disminuir la base imponible. El Directorio quiere evaluar el mismo
 proyecto pero ahora considerando la posibilidad que ha planteado el Sr. Concerned. Suponiendo que la tasa de
 C.C.P.P. relevante para la evaluación financiera del nuevo proyecto es de 15,0% y que los impuestos a las
 empresas fuesen la única imperfección presente en el mercado de capitales, ¿recomendaría usted emprender el
 nuevo proyecto bajo tales condiciones? Fundamente numéricamente.
 3) Suponga ahora que el eventual nuevo socio, que aportaría los $1.200 de capital para financiar el nuevo proyecto,
 le ha hecho saber a los actuales dueños de la empresa que él no está dispuesto a realizar el aporte si a cambio
 recibe sólo un 30% de la propiedad. Dado lo anterior, los actuales dueños han recurrido al Banco del Sur para ver
 la posibilidad de conseguir un préstamo por el total de los $3.000 de recursos que se necesitan para financiar el
 nuevo proyecto. El Banco ha informado a los dueños su disposición a prestarles los $3.000 que requiere el
 proyecto, pero con una tasa de interés mayor que la ofrecida inicialmente a la empresa. Se sabe que como
 resultado de la nueva tasa de interés que el Banco cobraría por el nuevo préstamo, y por distintas imperfecciones
 que se observan en el mercado de capitales, el VAN del nuevo proyecto sería de $200. -
 “Conocida esta nueva información, los actuales dueños saben que tendrían dos formas alternativas para financiar
 los $3.000 que requiere el proyecto. La primera opción es financiarlo con $1.800 de nueva deuda más el aporte de
 un nuevo socio que entregaría los $1.200 restantes, a cambio de un porcentaje de la propiedad de la empresa que
 tendría que ser mayor al 30%. La segunda altemativa sería pedir los $3.000 al Banco, en cuyo caso el VAN del
 nuevo proyecto sería de $200. -
 Sobre la base de la información disponible, y suponiendo que usted como representante de los actuales
 accionistas, hoy en la tarde (31/12/14) tiene que reunirse con el eventual nuevo socio para informarle si los dueños
 están dispuestos a ofrecerle un % mayor al 30% de la propiedad de la empresa, a usted se le pide determinar, de
 manera fundamentada, el máximo % de propiedad de la empresa MINASA que los actuales (o antiguos)
 dueños de la compañía, podrían estar dispuestos a ofrecerle al potencial nuevo socio de la empresa, si ellos saben
 que, en caso que el nuevo socio no acepte el nuevo porcentaje ofrecido, entonces el proyecto se tendría que hacer
 pidiéndole al Banco los $3.000 de inversión inicial que se requieren. Fundamente numéricamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 140

[pág. 141]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2016 | pregunta 3
 Convocatoria 1 | página original 189 | FER
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N”3
 La compañía PPTT tiene el siguiente balance al 31/12/2015:
 Activos Pasivos y Patrimonio
 Activos Corrientes o Circulantes Pasivos Corrientes o Circulantes
 Caja $ 5.000 Cuentas por Pagar a Proveedores $ 150.000
 Cuentas. por Cobrar a Clientes 100.000 Deudas con Bancos (Corto Plazo) 0
 Existencias 100.000 Pasivos No Corrientes (Largo Plazo)
 Activos No Corrientes Deudas con Bancos (Largo Plazo) 100.000
 Terrenos 295.000 (Ver Nota N*1)
 Patrimonio
 Capital 50.000
 Utilidades Retenidas (UR) 200.000
 (Ver Nota N*%2)
 Total Activos $ 500.000 Total $500.000
 Nota N? 1: La primera amortización o pago de la deuda de largo plazo con los bancos, se debe hacer el año 2021.
 Durante los próximos 5 años, anualmente se deben pagar únicamente los intereses devengados
 Nota N? 2: Las UR son posteriores al pago de dividendos correspondientes al resultado del ejercicio 2015.
 Información financiera relevante de la empresa:
 * Las ventas del año 2015 de la empresa fueron de $1.000.000.
 * Seespera que las ventas del año 2016 sean de $1.200.000
 * Laproyección de margen neto anual sobre ventas (Utilidad Neta / Ventas) de los próximos 4 años es de un 15%
 anual.
 o El único movimiento de activos no corrientes que hará la empresa durante el año 2016, será la compra y pago al
 contado un nuevo terreno para sus bodegas por valor de $172.000.
 * Dado suciclo de efectivo, se sabe que las siguientes relaciones se dan de manera permanente en la empresa:
 Ítemes Corrientes o Circulantes que Varían Espontáneamente con las Ventas (%):
 (o Itemes Circulantes como Función de las Ventas Anuales (%))
 Cuentas por Cobrar a Clientes 10%|Cuentas por Pagar a Proveedores - 15%
 Existencias 10%
 % Activos Circulantes Espontáneos 20%|% Pasivos Circulantes Espontáneos 15%
 e Se sabe que al 31/12/2015, la empresa está financiada cumpliendo con el principio de “igualdad” o “calce”
 (también llamado enfoque de equiparación de vencimientos para financiar el capital de trabajo).
 o El Directorio ha definido las siguientes políticas financieras para la empresa:
 * Al término de cada año, el saldo en la cuenta “Caja” de la Compañía, debe ser de $5.000.
 .Q
 ,
 Al término de cada año, la razón de endeudamiento (Deuda o Pasivos Totales/Patrimonio), medida en términos
 0.0
 *
 contables, debe ser igual a 1,0.
 * Al término de cada año, se debe pagar como dividendos y en efectivo, el 63% del resultado del ejercicio de
 <
 dicho año.
 Al término de cada año, el financiamiento de la empresa debe cumplir con el principio de “igualdad” o “calce.”
 **
 ,
 Suponiendo que:
 * Todoslosactivos de la empresa son operacionales.
 e Todas las ventas de la empresa son hechas otorgando crédito de corto plazo a sus clientes.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 141

[pág. 142]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2016 | pregunta 3
 Convocatoria 1 | página original 190 | FER
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Todas las compras de existencias que hace la empresa, son hechas usando crédito de sus proveedores.
 Todas las compras y ventas de la empresa son uniformes durante el año.
 La empresa sólo tiene tres tipos de pasivos: Cuentas por Pagar a Proveedores (que no genera intereses explícitos),
 Deuda de Corto Plazo con Bancos y Deuda de Largo Plazo con Bancos.
 Todos los fondos que la empresa requiera para su financiamiento, cualquiera sea su origen, se solicitan y se dispone
 de ellos al inicio (el primer día) del año en que se solicitan o emiten en el caso de acciones.
 Todos los costos o gastos financieros (intereses) relacionados con el financiamiento con deuda tanto pasada (deuda
 al 31/12/2015) como futura (nueva deuda) de la empresa ya han sido considerados en el margen neto de ventas de
 15%. Este margen neto no cambia frente a las distintas formas de financiamiento que adopte la empresa.
 Un año tiene 360 días y un mes 30 días.
 No hay inflación y se espera que no haya cambios en los valores de mercado de activos o pasivos.
 El balance de la empresa está constituido únicamente por las cuentas que se desprenden del enunciado.
 Responda las preguntas que se le formulan a continuación, mostrando los cálculos que sean necesarios:
 1) Obtenga el monto ($) de "Financiamiento Externo Requerido" (F.E.R.) por la empresa “PPTT” para el año
 2016 (recuerde que para el año 2016 se estima que las ventas aumentarán a $1.200.000). Fundamente su
 respuesta.
 2) Suponga ahora que, luego de conocido el F.ER. para el año 2016 (obtenido por Ud. en la pregunta anterior),
 la empresa ha proyectado todos los movimientos de caja esperados para cada uno de los años 2017, 2018 y
 2019, y ellos son los siguientes:
 Año 2017 Año 2018 Año 2019
 Superávit/(Déficit) de Caja del Año ($80.000) + $95.400 (superávit) ($120.000)
 A usted se le pide que obtenga el “Financiamiento Permanente” requerido por la empresa, considerando el
 período 2016 a 2019 (ambos años incluidos). Muestre el procedimiento.
 3) Suponga ahora que la empresa está elaborando su plan de financiamiento para el período 2016 a 2019 (ambos
 años incluidos), de modo de cumplir con las cuatro políticas financieras señaladas anteriormente en el
 enunciado.
 La empresa ha estimado que para el período que se está planificando (2016 a 2019), ella usará como fuentes
 de financiamiento, complementarias a las que se encuentra actualmente utilizando al 31/12/2015, las siguientes
 tres fuentes de financiamiento, que pueden ser usadas en las proporciones que la compañía estime conveniente:
 “ Deuda Bancaria de Corto Plazo
 “ Nueva Deuda de Largo Plazo la que se puede emitir con 6 años de gracia (la primera amortización del
 principal de la deuda se debe hacer en 6 años más). Los intereses siempre se deben pagar al término del
 año.
 * Nuevo Patrimonio o Aportes de Capital en efectivo por parte de los dueños.
 A usted se le solicita determinar el monto de recursos ($) de cada una de las tres fuentes de financiamiento que
 se le han indicado, que debiera proyectar la empresa PPTT, para el financiamiento de sus actividades en el año
 2016 (solamente el 2016), de modo de cumplir con las cuatro políticas financieras señaladas en el enunciado.
 Para responder esta pregunta, Ud. debe presentar el balance proyectado de “PPTT” al 31/12/2016, incluido el
 nuevo financiamiento que sea necesario.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 142

[pág. 143]
Finanzas - versión clara y reordenada
 Dirección Financiera | marzo 2011 | pregunta 3
 Convocatoria 1 | página original 62 | Flujo de caja incremental y VAN
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº3
 Executive Fitness es una cadena de gimnasios orientada a ejecutivos de alto nivel que hoy, 1 de enero de 2011 (o
 momento t = 0), está evaluando abrir un nuevo gimnasio en la comuna de Huechuraba. Esta empresa cuenta con otros
 negocios relacionados en Chile que le reportan una utilidad neta de $800 millones anuales. El nuevo gimnasio se
 construiría y pagaría completamente hoy (en t = 0) remodelando una antigua bodega de propiedad de Executive Fitness,
 que actualmente está desocupada, y sobre la cual existe una oferta de una empresa constructora que quiere comprarla al
 contado en $90 millones (después de impuestos) para construir un edificio de oficinas. La bodega está completamente
 depreciada, desde el punto de vista contable, y se estima que su remodelación tendrá un costo de $72 millones en moneda
 de hoy, el cual se reconocerá completamente como gasto tributario en un año más, es decir, el 31-12-2011 (t = 1).
 Otros datos del proyecto son los siguientes:
 • Ingresos estimados en términos nominales: $147 millones al término del primer año, los cuales crecerán anualmente
 al mismo ritmo de la inflación esperada (5% anual).
 • Costo de adquisición de equipos y aparatos de gimnasia a ser comprados al contado y necesarios para emprender el
 proyecto: $42 millones en moneda de hoy. La vida útil de estos equipos se estima en tres años, con un valor residual
 contable de $6 millones en moneda de hoy.
 • Costos anuales estimados (todas las cifras son en moneda de hoy y se proyecta que todos los costos se mantendrán
 constantes en términos reales a lo largo del proyecto):
 Nuevo personal a contratar: $32 millones.
 Costos variables de operación (agua, luz, gas, etc.): $18 millones.
 Costos fijos: $20 millones. La mitad de estos costos corresponden a seguridad, aseo y mantención de equipos y están
 asociados directamente al nuevo gimnasio, mientras que la otra mitad corresponden a gastos de la casa matriz de
 Executive Fitness, tales como sueldo del Gerente General y dietas del Directorio, que serán asignados al nuevo
 gimnasio. Los gastos de la casa matriz no se verán incrementados con la apertura del nuevo gimnasio y la política de la
 empresa es asignar dichos gastos sobre la base del volumen de ventas de cada gimnasio.
 • Costo del proyecto de arquitectura: $10 millones en moneda de hoy. Este costo fue incurrido y reconocido como
 gasto por la empresa el año pasado, pero se pagará en dos años más.
 • El capital de trabajo que debe tener la empresa el último día de cada año, debe ser el equivalente a un 5% de las
 ventas estimadas para el año siguiente. Al final del proyecto, se recuperará, en moneda de hoy (t = 0), la totalidad del
 capital de trabajo invertido en él.
 • La tasa de impuestos alcanza al 25% de las utilidades antes de impuestos.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 143

[pág. 144]
Finanzas - versión clara y reordenada
 Dirección Financiera | marzo 2011 | pregunta 3
 Convocatoria 1 | página original 63 | Flujo de caja incremental y VAN
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 • Al final del proyecto se venderán los equipos usados en $14 millones y la bodega en $30 millones, ambas cifras en
 moneda de hoy.
 • El proyecto será evaluado por un asesor de la empresa al que se le pagará hoy (en t = 0) la suma de $2 millones
 • La tasa de descuento relevante para el proyecto alcanza a 13,4% nominal anual.
 Sobre la base de los antecedentes presentados, y suponiendo que todos los flujos de caja del proyecto, con la sola
 excepción de la inversión inicial que ocurre en t = 0, se producen al término de cada período (año), a Ud. se le pide que
 evalúe el proyecto del nuevo gimnasio que planea abrir Executive Fitness, considerando un horizonte de tres años.
 Presente todos los cálculos correspondientes en forma ordenada y explicite cualquier supuesto adicional que Ud. estime
 necesario realizar.
 Nota: Si para responder esta pregunta Ud. considera necesario el uso de tablas de matemáticas financieras, ellas se
 encuentran disponibles al término de este examen. En el caso de usar dichas tablas y tener que obtener alguna tasa de
 interés o rentabilidad a partir de una extrapolación entre dos valores de la tabla, dicha extrapolación hágala de manera
 lineal.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 144

[pág. 145]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2019 | pregunta 6
 Convocatoria 1 | página original 287 | Flujo incremental y financiamiento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA N6
 Hoy 31 de diciembre de 2019, la Panquequería “Panqueques de Mora”, presenta el siguiente balance (todas las cifras están
 en valor “económico” y expresadas en miles de $ o MS):
 Balance en Valor Económico
 (31/12/2019)
 Activos Pasivos y Patrimonio
 Caja 1.500 |¡Deuda Financiera 4.000
 CTNO (distinto de Caja) (Nota 1) 2.500
 Edificios y equipos (Nota 2) 4.000 — |Patrimonio (Nota 3) 4.000
 Total activos 8.000 |Total Pas. + Pat. 8.000
 (1): CTNO = Capital de Trabajo Neto Operacional
 CTNO = [Activos Corrientes Operacionales (distintos de “Caja”) menos Pasivos Corrientes Operacionales]
 (2): Neto de Depreciación Acumulada
 (3): Compuesto por 1.000 acciones comunes, a valor de mercado de $4.000 cada una
 Justo en la medianoche de hoy, los dueños de “Panqueques de Mora”, han decidido evaluar la posibilidad de abrir una
 nueva sucursal, a través de la compra de un nuevo local, también dedicada a la producción de panqueques, la que sería
 financiada con recursos propios de la empresa, más un nuevo aporte de capital por parte de los actuales dueños. La siguiente
 es la información disponible respecto de las proyecciones de la empresa, con y sin el nuevo local:
 Definiciones:
 SNL = Proyecciones “Sin Nuevo Local; 1 CNL = Proyecciones “Con Nuevo Local”
 Estados de Resultados Proyectados
 Panquequería "Panqueques de Mora"
 (Montos son en Miles de $)
 SNL CNL
 Año 2020 al infinito | Año 2020 al infinito
 Ingresos por Venta 10.000 12.000
 - Costo de Ventas -6.000| -7.000
 - Gastos de Administración y Ventas [GAV]
 GAV Fijos -1.000 -1.000
 GAV Variables -1.300 -1.400
 - Depreciación del Ejercicio [1] [2] -500 -600
 = Resultado Operacional 1.200 2.000
 - Gastos Financieros -320 -320
 = Utilidad Antes de Impuesto 880 1.680
 - Impuesto a las Utilidades (25%) -220 420
 = Resultado del Ejercicio (Utilidad Neta) 660 1.260
 (1): El total del “Gasto por Depreciación del Ejercicio” de cada año de la empresa, está reflejado en esta cuenta. Las cuentas “Costo
 de Ventas” y Gastos de Administración y Ventas” (GAV), no incluyen gastos por depreciación.
 (2): Laalternativa o escenario “CNL”, incluye M$100 de gasto por depreciación anual por el nuevo local.
 A continuación, se presentan los requerimientos de inversión inicial en caso de comprar el nuevo local o sucursal. Los
 requerimientos de inversión inicial se deben desembolsar al momento de la inversión, que en caso de resultar conveniente
 el proyecto, se debiera concretar al inicio del 1 de enero de 2020 o T =0:
 Inversión Inicial (MS): 1 de enero de 2020 (T=0)
 Nuevo Local: 2.900
 Aumento de CTNO: 100
 Se sabe además, que los siguientes son los requerimientos de reinversiones anuales, al término de cada año, tanto para el
 caso en que no se abra un nuevo local, como aquel en que se abra un nuevo local:
 Reinversión Anual (MS): Fin Año 2020 al Infinito
 Sin Nuevo Local (SNL) 600
 Con Nuevo Local (CNL) 800
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 145

[pág. 146]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2019 | pregunta 6
 Convocatoria 1 | página original 288 | Flujo incremental y financiamiento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Por otra parte, se sabe que los requerimientos de Capital de Trabajo Neto Operacional (CTNO), se deben cumplir o contar
 con ellos, al inicio del primer día del año en que se espera se produzcan las ventas que requieren de dicho CTNO. Se ha
 estimado que los requerimientos de CTNO, sin el nuevo local (condición “Actual”) y con el nuevo local (CNL), serían los
 siguientes:
 Monto (stock) de Capital de Trabajo Neto Operacional (CTNO) Requerido
 Panquequería "Panquegues de Mora"
 (Montos son en Miles de $)
 31-12-2019 31/12/2020 al infinito
 Monto (stock) de CTNO Sin Nuevo Local (SNL) 2.500 [1] 2.500 3]
 Monto (stock) de CTNO Con Nuevo Local (CNL) 2.600 A 2.600 [4]
 [1]: 31/12/2019 (Actual): Corresponde al monto de la Inversión en CTNO que ya tiene la empresa al 31/12/2019.
 [2]: 31/12/2019 (CNL): Corresponde al monto de la Inversión en CTNO que tendría que tener el 31/12/19,
 en caso de adquirir el nuevo local.
 B]:31/12/20 al infinito (Actual): Corresponde al monto de la mversión en CTNO que tendría que tener la empresa
 al término de cada año, a partir del 31/12/20 y hasta el infínito, SIN un nuevo local.
 14]:31/12/20 al infínito (CNL): Corresponde al monto de la Inversión en CTNO que tendría que tener la empresa
 al término de cada año, a partir del 31/12/20 y hasta el infínito, CON un nuevo local.
 El financiamiento del nuevo local, sería del modo siguiente:
 Financiamiento Original (MS): .
 Emisión de Nuevas Acciones (Nuevo Aporte de dueños actuales): 1.500
 Uso de "Caja": 1,500
 Finalmente, se sabe que la empresa ha contratado un asesor, quien evaluará la conveniencia de emprender o no el proyecto,
 al cual se le pagará la suma de M$500, en T =0, es decir, el 1 de enero de 2020.
 PREGUNTAS
 Suponga en primer lugar, que los actuales accionistas o dueños de la empresa, están dispuestos y en condiciones de aportar
 los M$1.500 necesarios para invertir en el nuevo local, si dicha inversión resultase conveniente. Se sabe además, que en
 dichas condiciones, el Costo de Capital Promedio Ponderado (CCPP) relevante de largo plazo de la empresa, aplicable
 también a los activos del nuevo proyecto, es de un 10% anual, después de impuestos. ¿Conviene la adquisición del nuevo
 local? Presente ordenadamente, todos los cómputos necesarios para fundamentar su respuesta.
 Suponga ahora, que por distintas razones, los actuales dueños o accionistas no podrán aportar los M$1.500 de nuevo capital
 requerido para la compra del nuevo local y que una altemativa que tendría la empresa para el financiamiento de los
 M$1.500 faltantes para la compra del nuevo local, sería obtener un préstamo especial de un banco, atado al proyecto, el
 que entre otras características, exigiría el pago anual y de manera indefinida, únicamente de sus intereses. Con esta
 información, los dueños han determinado que en caso de usar dicho préstamo para completar el financiamiento, una buena
 estimación del CCPP anual, relevante para ser usada en la evaluación del nuevo local, ya no sería del 10%, sino, y debido
 a una serie de imperfecciones del mercado de capitales, de un 12,5% marginal, anual, después de impuesto. Con la
 información anterior, los actuales dueños, han decidido abrirse a la posibilidad de invitar a una nueva inversionista, para
 que aporte como capital los M$1.500 faltantes, en cuyo caso el CCPP relevante para la evaluación de la nueva inversión,
 sería el 10% inicialmente estimado, Teniendo presente estas dos altemativas de financiamiento de los M$1.500 (con el
 crédito del banco o através de un aporte de capital de un nuevo accionista), ¿Cuál sería el máximo porcentaje (%) de
 la propiedad o patrimonio de la nueva empresa (empresa actual más nuevo local), que los actuales dueños de la
 panquequería debieran estar dispuestos a ofrecer a la nueva accionista, a cambio de los nuevos M$1.500 de capital
 que ella aportaría?
 Suponga que el cambio en el CCPP marginal relevante para la evaluación del nuevo local en caso de usar los M$1.500 del
 crédito bancario, no afectaría el valor económico que tenía la empresa, antes de evaluar la posibilidad de invertir en este
 nuevo proyecto.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 146

[pág. 147]
Finanzas - versión clara y reordenada
 Dirección Financiera | marzo 2009 | pregunta 3
 Convocatoria 1 | página original 6 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº3
 A continuación se presenta el balance no auditado al 30/09/08 de la empresa “La Central S.A.”, que es una gran
 librería cuya actividad es la venta de libros y cuadernos para estudiantes de educación básica y media de Santiago.
 Todas las cifras están en pesos:
 ACTIVOS $ PASIVOS Y PATRIMONIO $
 Caja 5.000 Impuestos por Pagar al Fisco 30.000
 Cuentas por Cobrar (bruto) (1) 48.000 Deuda Bancaria de Corto Plazo 20.000
 Existencias de Libros y Cuadernos (2) 25.000 Total Pasivo Circulante 50.000
 Gastos Pagados por Anticipado (3) 52.000 Deuda Bancaria de Largo Plazo 150.000
 Dividendos por Cobrar a Empresa “Z” (4) 20.000 Total Pasivos 200.000
 Total Activo Circulante 150.000 Capital 250.000
 Utilidades Retenidas 123.000
 Terrenos 450.000 Utilidad Neta del Ejercicio 27.000
 Total Activo Fijo 450.000 Total Patrimonio 400.000
 Total Activos $ 600.000 Total Pasivos y Patrimonio $ 600.000
 Notas (1) : Incluye $39.000 de Cuentas por Cobrar al Sr. X, dueño de esta empresa.
 (2) : Se desconoce el estado de mantención (bueno, regular o malo) tanto de los libros como de los cuadernos.
 Se sabe además que, como resultado de una reforma al sistema educacional que están estudiando las
 autoridades, parte de los libros de estudio que se tienen en Existencias, muy pronto podrían quedar
 obsoletos.
 (3) : Corresponde a gastos de arriendo pagados por anticipado de los locales donde opera la “La Central
 S.A.”.
 (4) : La empresa “La Central S.A.” es dueña del 90% de la Empresa “Z”.
 El Comité de Crédito de un conocido Banco de la Plaza estaba analizando la posibilidad de hacer un préstamo de
 $27.000 a 30 días, a contar del 1/10/2008, a la empresa “La Central S.A.”. Lo que se reproduce a continuación en letra
 cursiva, son algunos de las opiniones emitidas por diversos ejecutivos del Comité del Crédito del Banco, respecto del
 préstamo en cuestión:
 OPINIÓN DEL GERENTE GENERAL DEL BANCO:
 Por tratarse de un crédito de corto plazo, yo calculé la razón “circulante” o “corriente” [activos circulantes/pasivos
 circulantes] de la Empresa “La Central S.A.” y concluí que ésta bajaría desde el actual nivel de 3,0 veces a 2,3 veces
 en caso de conceder el crédito. Adicionalmente, y con el objeto de tener una versión más restringida de la liquidez,
 también calculé la razón (o prueba) “ácida” [activos circulantes, excluyendo las existencias, sobre los pasivos
 circulantes] comprobando que ésta descendería desde 2,5 veces a 2,0 en el evento de otorgarse el préstamo.
 Sobre la base de estos indicadores, mi recomendación es que se apruebe inmediatamente el crédito ya que el hecho
 de que ambas razones de liquidez sean mayores que 1 (uno), después de concederse el préstamo, es una clara
 demostración de que la Empresa contará, oportunamente, con la caja necesaria para el pago de sus obligaciones de
 corto plazo.
 OPINIÓN DEL GERENTE DE CRÉDITO DEL BANCO:
 Si bien los tradicionales ratios que se usan para medir la liquidez de una compañía (razón circulante y razón ácida)
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 147

[pág. 148]
Finanzas - versión clara y reordenada
 Dirección Financiera | marzo 2009 | pregunta 3
 Convocatoria 1 | página original 7 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 pueden ser útiles, se trata fundamentalmente de indicadores que comparan stocks y no flujos, siendo esto último lo
 relevante para ver la capacidad de pago de una empresa. Por esta razón, me parece que lo más apropiado para
 medir el impacto que tendrá la deuda de corto plazo en la empresa, es calcular el cuociente entre el monto total de
 las Deudas (Pasivos) de la empresa que vencen en los próximos 30 días (numerador) y los “Ingresos por Ventas”
 esperados en los siguientes 30 días (denominador), los que se obtendrían a partir de un “Estado de Resultados”
 proyectado de la empresa. Si este ratio o cuociente es cercano o mayor que 1 (uno), ello quiere decir que la empresa
 no tendrá suficientes recursos para pagar oportunamente sus créditos de corto plazo, y deberá negársele el crédito.
 Por el contrario, si este ratio es bajo o cercano a cero, entonces la empresa claramente estará en condiciones de
 cumplir con sus obligaciones de corto plazo.
 OPINIÓN DEL GERENTE DE RIESGO DEL BANCO:
 El indicador más apropiado para medir la capacidad de pago de una deuda es ver si la rentabilidad que obtiene la
 empresa en el negocio es mayor que la tasa de interés que el Banco le cobraría a la Empresa por el préstamo que le
 otorgaría.. En el caso de esta Empresa, si se toma la “Utilidad Neta del Ejercicio” de $27.000 que la empresa tiene
 acumulada en los nueve primeros meses del año 2008 (hasta el 30/09/08) y ella se anualiza linealmente [($27.000 / 9)
 x 12 = $36.000]) y esta cifra se divide por el total de activos al 30/09/08 ($600.000), vemos que la rentabilidad
 proyectada para el año 2008 para la Empresa es del 6% anual, cifra que es inferior a la tasa de interés de 8% anual
 que el Banco le estaría cobrando a la compañía por el crédito de corto plazo. En consecuencia, creo que no
 debiéramos prestarle plata a 30 días a “La Central S.A.”.
 Se Pide:
 Sobre la base de la información presentada, a usted se le pide evaluar y entregar los comentarios, desde una
 perspectiva financiera, que a usted le merecen las opiniones que han emitido cada uno de los tres Gerentes del Banco,
 para justificar el otorgamiento o la denegación del crédito de corto plazo a la Empresa “La Central S.A.”. Presente
 sus comentarios en forma independiente para cada uno de los tres Gerentes, y sea breve pero preciso en cada uno de
 ellos.
 Supuestos para su Análisis:
 • Cuando en alguna razón o ratio financiero deba usar una variable de flujo y una de stock, para esta última use su
 valor al término del período, en este caso, su valor al 30/09/08
 • No hay impuestos.
 Forma de Presentación de su Respuesta:
 Comentarios Respecto de la Opinión del Gerente General del Banco:
 Comentario Nº1:
 Etc.
 Comentarios Respecto de la Opinión del Gerente de Crédito del Banco:
 Comentario Nº1:
 Etc.
 Comentarios Respecto de la Opinión del Gerente de Riesgo del Banco:
 Comentario Nº1:
 Etc.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 148

[pág. 149]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2009 | pregunta 3
 Convocatoria 2 | página original 19 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº3
 La empresa minera “Caracoles” se encuentra ubicada en una zona cordillerana de difícil acceso por lo cual se
 autoabastece de energía eléctrica mediante el uso de una turbina que opera con petróleo (diésel). Esta turbina que fue
 comprada 3 años atrás, en $24 millones al contado, y actualmente su operación le significa a la empresa egresos de
 caja anuales totales (ya considerados los efectos tributarios de todos los gastos correspondientes) por un total de $38
 millones y se calcula que podrá continuar operando por otros dos años más. Por tratarse de un activo bastante
 específico, la turbina no tiene ningún valor comercial, es decir, si la empresa minera se deshiciera de dicho activo en
 cualquier momento de su vida útil, no recibiría dinero alguno. En exactamente dos años más, y en general en cualquier
 momento en el futuro, “Caracoles” puede volver a adquirir una nueva turbina con las mismas características de la
 turbina original (precio de compra de $24 millones al contado, egresos anuales de caja de $38 millones al término de
 cada año y vida útil de 5 años con valor de desecho igual a cero).
 Los dueños de “Caracoles” acaban de recibir una oferta para adquirir un aerogenerador que permite la generación
 eléctrica vía eólica, esto es, a través de la acción del viento. Este equipo tiene un valor de $60 millones, al contado, y
 tiene costos operacionales anuales, excluyendo (es decir, no habiendo considerado todavía) la depreciación, de $35
 millones, que corresponden en su totalidad a un desembolso de caja que debe pagarse al término de cada año, al
 fabricante del equipo por un programa de mantención que debe hacerse todos los años. La vida útil del aerogenerador,
 para efectos tributarios, es de 6 años con un valor de desecho, al término de su vida útil, igual a cero. Sin embargo,
 dicho aerogenerador puede ser vendido al término de su quinto año de uso, en la suma de $15 millones, al contado.
 La política de la minera “Caracoles” es reemplazar los equipos de generación de energía eléctrica cada 5 años. El
 costo de capital promedio ponderado de la empresa, después de impuestos y relevante para la evaluación de estos
 proyectos, es de 12% anual y la tasa anual de impuestos alcanza a un 20%. Para efectos tributarios “Caracoles” utiliza
 depreciación lineal y tiene suficientes ingresos como para absorber cualquier costo y gasto relacionado con los
 equipos generadores de energía eléctrica.
 El Gerente de Faenas Mineras cree que ha llegado el momento de reemplazar la turbina diésel por el aerogenerador,
 no sólo porque la turbina tiene costos de operación más altos, sino también porque su valor de desecho es igual a cero.
 En este caso, luego del reemplazo, la Empresa seguiría operando de manera permanente con el aerogenerador.
 Por su parte, el Gerente de la División Óxidos está de acuerdo con el Gerente anterior, pero cree que el reemplazo de
 la turbina no debiera hacerse hoy, sino en dos años más cuando ésta ya no pueda seguir operando. Lo mismo que en
 el caso anterior, luego del cambio dentro de 2 años, la Empresa seguiría operando de manera indefinida con el
 aerogenerador.
 Finalmente el Gerente de Operaciones es partidario de seguir operando con turbinas a diésel. A su juicio, el menor
 costo operacional que tiene un aerogenerador no es suficiente para compensar la mayor inversión que es necesario
 efectuar para poder adquirirlo, y por lo tanto es mejor continuar operando indefinidamente con turbinas que operan
 con petróleo (diesel)
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 149

[pág. 150]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2009 | pregunta 3
 Convocatoria 2 | página original 20 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 Suponga que:
 • Todos los flujos de caja relacionados con los distintos proyectos anteriores, se producen el último día de cada año
 (salvo la inversión inicial) y comienzan a producirse exactamente un año después de realizada la inversión
 inicial.
 • La empresa minera “Caracoles” requiere seguir contando con equipos de generación de energía eléctrica en
 forma indefinida.
 • La instalación de cualquier equipo nuevo, es “instantánea, es decir, comienza a operar de inmediato y a generar
 sus flujos justo un año luego de su instalación o del momento de su inversión inicial.
 A Ud. se le pide evaluar, desde un punto de vista financiero, las distintas alternativas de reemplazo de equipos
 generadores de energía eléctrica que sugieren cada uno de los Gerentes para la minera “Caracoles”, indicando
 claramente cuál de las alternativas posibles es la más conveniente para la empresa.. Explique claramente su respuesta
 y para sus cálculos, si lo requiere, utilice las tablas de matemáticas financieras que se adjuntan al final del enunciado.
 De cualquier modo, todo cálculo numérico debe estar suficientemente respaldado por la expresión matemática que lo
 ha originado.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 150

[pág. 151]
Finanzas - versión clara y reordenada
 Dirección Financiera | marzo 2010 | pregunta 3
 Convocatoria 1 | página original 35 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº3
 La empresa “Desarrollos Inmobiliarios S.A” (DISA), tiene entre sus activos un terreno (o un “paño de tierra”) de 20
 hectáreas (hás) en una zona de crecimiento urbano, comprado hace dos años y ha decidido que ha llegado el momento de
 desarrollar un nuevo proyecto inmobiliario. Como resultado de lo anterior, la empresa en este momento tiene que decidir
 entre dos proyectos mutuamente excluyentes, cuál será el proyecto que desarrolle en dicho terreno. La estrategia de la
 empresa es la de desarrollar proyectos inmobiliarios, esperar que el valor del proyecto aumente con los años y luego
 venderlos.
 Los proyectos alternativos (mutuamente excluyentes) para el terreno son los siguientes:
 Proyecto Nº 1:
 Utilizar 8 de las 20 hás. disponibles, para el desarrollo de un centro comercial, de modo que una vez que se haya
 alcanzado un nivel de desarrollo relativamente importante del centro comercial, vender el paño de tierra de las 12 hás.
 restantes, a través de una licitación pública.
 Proyecto Nº 2:
 Utilizar 5 de las 20 hás. disponibles, para la construcción de un gran Colegio y un Hiper Mercado, de modo que una vez
 que se haya terminado la instalación del Colegio y del Hipermercado, vender el paño de tierra de las 15 hás. restantes, a
 través de una licitación pública.
 El desarrollo de cualquiera de los dos proyectos alternativos, significa destinar en este momento (esto es, hoy o lo que es
 lo mismo en t = 0), distintos montos de recursos para preparar el paño de tierra de 12 hás. o 15 hás. (según cual sea el
 proyecto que desarrolle la empresa) y que posteriormente sería motivo de la licitación. Por otra parte, el precio al que se
 espera vender cada uno de los dos paños de tierra en el futuro, no sólo es distinto dependiendo de cuál de los dos
 proyectos (Nº 1 o Nº 2) desarrolle la empresa, sino también del año en que la empresa decide vender, a través de la
 licitación, el paño de tierra que quede disponible.
 Los siguientes son los montos de inversión inicial que DISA tendría que hacer en t = 0 (hoy) en cada uno de los dos
 proyectos alternativos que ella enfrenta y los precios de venta esperados de los paños de tierra disponibles al término de
 cada uno de los 5 próximos años
 Si Desarrolla el Proyecto Nº1
 Inversión Inicial Precio de Venta Esperado al Término de Cada Año ($):
 ($ hoy; t = 0) Año 1 Año 2 Año 3 Año 4 Año 5
 -30.000,00 33.000,00 36.003,00 38.991,20 41.993,50 45.059,03
 Si Desarrolla el Proyecto Nº2
 Inversión Inicial Precio de Venta Esperado al Término de Cada Año ($):
 ($ hoy; t = 0) Año 1 Año 2 Año 3 Año 4 Año 5
 -50.000,00 54.700,00 59.458,90 64.096,70 68.711,70 73.177,96
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 151

[pág. 152]
Finanzas - versión clara y reordenada
 Dirección Financiera | marzo 2010 | pregunta 3
 Convocatoria 1 | página original 36 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 Suponiendo que:
 • El mercado de capitales del país en el que opera la empresa es “perfecto”.
 • La tasa de actualización o de descuento relevante para los flujos futuros de cada uno de los dos proyectos es de
 un 8% anual (Inflación = 0%)
 • La inversión inicial es al contado y se lleva a cabo en t = 0 (hoy). Los precios de venta de cada uno de los paños
 de tierra de los proyectos, son precios de venta al contado y se producen y reciben al final del año en que se
 venden.
 • Mientras la empresa DISA mantenga en su poder los terrenos disponibles para la venta, dichos terrenos no
 generarían a DISA movimiento de caja alguno (ni entradas ni salidas de caja).
 • Por normas de urbanización que debe cumplir la empresa, los paños de tierra disponibles, deben, necesariamente,
 ser vendidos en un plazo máximo de 5 años a contar del día de hoy.
 • La empresa DISA no tiene otros proyectos de inversión, distintos de los Proyectos Nº1 y Nº2 descritos en la
 pregunta, que ella pueda emprender o desarrollar en los próximos años.
 • Si para responder esta pregunta Ud. considera necesario el uso de tablas de matemáticas financieras, ellas se
 encuentran disponibles al término de este examen. En el caso de usar dichas tablas y tener que obtener alguna
 tasa de interés o rentabilidad a partir de una extrapolación entre dos valores de la tabla, dicha extrapolación
 hágala de manera lineal.
 A Ud. se le pide responder las preguntas que se le formulan a continuación. Justifique numérica y
 conceptualmente sus respuestas y presente todos sus cálculos, especialmente los que se refieren a las tasas de
 interés o rentabilidad (%), con dos decimales (Ejemplo: 99,99%).
 1. Dado que la empresa DISA sólo puede desarrollar uno de los dos proyectos alternativos, a usted se le pide
 responder:
 a) ¿Cuál de los dos proyectos (Nº 1 o Nº 2) le recomendaría Ud. llevar a cabo?. Para responder esta pregunta
 utilice única y exclusivamente el criterio de la Tasa Interna de Retorno o TIR.
 b) Teniendo presente el proyecto que en la letra “a” Ud le ha recomendado desarrollar a la empresa y utilizando
 única y exclusivamente el criterio de la Tasa Interna de Retorno o TIR, ¿En cuál año, debiera la empresa DISA
 vender el paño de tierra que quedaría disponible para la venta?
 2. Suponga ahora que Ud. es el propietario de una empresa constructora que podría estar interesada en presentarse a la
 licitación del paño de tierra que licitaría la empresa DISA al término del año que Ud. ha determinado en la pregunta
 anterior, y que su objetivo es el de ofrecer en la licitación un precio que le permita aumentar su riqueza, ¿Cuál es el
 precio máximo que Ud., como propietario de la empresa constructora, estaría dispuesto a pagar por dicho paño de
 terreno el día de la licitación?
 NOTA IMPORTANTE
 Si en aquellas preguntas en que se le solicita una respuesta, análisis o decisión en base al criterio de la TIR
 (Preguntas Nº 1.a y Pregunta Nº 1.b), usted lo hace utilizando otros criterios de evaluación de proyectos (como
 por ejemplo Valor Actual Neto, Período de Recuperación de la Inversión, Índice de Rentabilidad, etc.) sin incluir
 el análisis en base a la TIR, usted NO habrá respondido lo que se le pregunta. Si al análisis en base a la TIR, usted
 agrega un análisis en base a otros criterios de evaluación de proyectos (lo que no se está pidiendo) su respuesta no
 mejora.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 152

[pág. 153]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2010 | pregunta 3
 Convocatoria 2 | página original 50 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº3
 A continuación se muestran el Balance al 31/12/09 y el Estado de Resultados del año 2009, construidos de acuerdo a los
 Principios de Contabilidad Generalmente Aceptados (PCGA), de las Empresas “A” y “B”, más algunos indicadores
 financieros complementarios de cada una de ellas:
 Balance al 31/12/2009: Empresa A Empresa B
 ACTIVOS $ $
 Activo Circulante
 Cuentas por Cobrar a Clientes (CxC) 45.000 225.000
 Existencias 90.000 45.000
 Total Activo Circulante 135.000 270.000
 Activo Fijo 915.000 1.230.000
 Total Activos 1.050.000 1.500.000
 PASIVOS Y PATRIMONIO
 Pasivo Circulante
 Cuentas por Pagar a Proveedores (CxP) 90.000 180.000
 Pasivos de Largo Plazo (L.P.): 540.000 382.500
 Patrimonio:
 Capital 195.000 562.500
 Utilidades Retenidas 225.000 375.000
 Total Pas. + Patrimonio 1.050.000 1.500.000
 ESTADO DE RESULTADOS AÑO 2009 $ $
 Ingresos por Ventas 2.100.000 3.000.000
 Menos: Costo de Ventas 1.365.000 1.920.000
 = Margen Bruto 735.000 1.080.000
 Menos: Gtos. de Administración y Ventas (Nota 1) 525.000 720.000
 Menos: Depreciación del Ejercicio 0 0
 = Resultado Operacional 210.000 360.000
 Menos: Gastos Financieros 57.780 40.545
 = Resultado Afecto a Impuesto 152.220 319.455
 Menos: Impuestos 15.222 31.946
 = Utilidad Neta o Resultado del Ejercicio $ 136.998 $ 287.509
 Nota 1: No incluye Gasto por Depreciación del Ejercicio
 Algunos Indicadores Relevantes: Empresa A Empresa B
 Beta de Activos 1,20 0,80
 Rotación de Cuentas por Cobrar a Clientes (veces): 8 8
 Rotación de Existencias (veces): 6 6
 Rotación de Cuentas por Pagar a Proveedores (veces): 12 6
 Notas:
 1. Las Empresas tienen sólo activos operacionales
 2. Suponga 1 Año = 360 días
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 153

[pág. 154]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2010 | pregunta 3
 Convocatoria 2 | página original 51 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 Con fecha 2 de enero de 2010, un analista de inversiones emitió un informe que hacía mención a la eficiencia operacional
 con que habían sido gestionadas las Empresas “A” y “B” durante el año 2009 y a la capacidad de pago que estas
 empresas tenían en el muy corto plazo (30 días) respecto de las obligaciones que ellas mantenían con sus proveedores.
 En su parte medular, el informe en cuestión decía lo siguiente:
 “El 32,6% de rentabilidad patrimonial (ROE) conseguido por la Empresa “A” es mayor que el 30,7% de ROE
 obtenido por los dueños de la Empresa “B”, lo que es un claro reflejo de la mayor eficiencia operacional con
 que la administración de la Empresa “A” manejó los activos de la Compañía durante el 2009. Por otra parte,
 es evidente que con la información disponible al 31/12/09 no habría diferencias en términos de la capacidad de
 pago, durante el mes de enero de 2010, de las obligaciones que cada una de las empresas mantiene con sus
 proveedores. Esto se puede fundamentar sobre la base del Índice o Razón de Liquidez o Circulante de 1,5 veces
 que exhiben tanto la Empresa “A” como la Empresa “B” al 31/12/09.”
 Desde una perspectiva financiera y solamente teniendo como base la información disponible, a usted se le pide
 responder lo siguiente:
 1. ¿Está Ud. de acuerdo con lo indicado en el informe, en relación con la mayor eficiencia operacional mostrada por la
 Empresa “A”, respecto de la Empresa “B” durante el año 2009?. Fundamente brevemente.
 2. ¿Cuáles son las “causas” más importantes u orígenes que explican la diferencia entre las rentabilidades del
 patrimonio (ROE) generadas durante el año 2009 por cada una de las dos Empresas, es decir, las causas que explican
 la diferencia entre el 32,6% y el 30,7% de las Empresas “A” y “B”, respectivamente?. Fundamente numéricamente
 su respuesta con la mayor profundidad que la información entregada le permitan.
 3. ¿Está Ud. de acuerdo con lo indicado en el informe, que las dos empresas presentan la misma capacidad de pago de
 sus obligaciones de corto plazo (30 días a contar del 31/12/09)?. Responda esta pregunta teniendo como base
 únicamente los activos y pasivos que ellas presentan en sus balances al 31/12/09, esto es, no incluya en su análisis
 nuevos recursos que las empresas pudieran obtener en los próximos 30 días (tales como nuevos préstamos, nuevos
 aportes de capital) o renegociaciones de deuda, etc.
 Para responder considere lo siguiente:
 • Todos los datos de activos, pasivos, patrimonio y de resultados que se conocen de la empresa, son datos contables y
 por lo tanto para responder las preguntas se debe hacer uso únicamente de los datos contables de la empresa.
 • Para ambas Empresas, como resultado de todas las transacciones que ellas han hecho durante el año 2009, se
 observa que los datos de sus balances al comienzo del año 2009 (1/01/09) y al término de dicho año (31/12/09), son
 idénticos. Esto significa que para el cálculo de razones financieras en que intervienen variables de flujo y variables
 de stock, para esta última variable puede usar su valor al 31/12/09.
 • Todas las ventas y compras de Existencias de ambas empresas son hechas otorgando crédito de corto plazo a sus
 clientes (CxC) en el caso de las ventas y usando crédito de los proveedores (CxP) en el caso de las compras y tanto
 las compras como las ventas se realizan de manera uniforme a través del año. El % de incobrabilidad de CxC = 0%
 • En su respuesta no se refiera a las evidentes limitaciones que surgen al utilizar indicadores (ratios) de naturaleza
 contable (los datos son históricos, devengado no implica flujo de caja, información es manipulable, etc.).
 • No necesariamente todas las cifras que se obtienen como resultados son cifras enteras, pudiendo tener decimales.
 En sus cálculos use dos decimales.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 154

[pág. 155]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2024 | pregunta 4
 Convocatoria 2 | página original 421 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N“4
 El estado chileno es dueño de un terreno en una zona del desierto de Atacama y ha decidido licitar y entregar dicho
 terreno en concesión a alguna empresa que ofrezca desarrollar en él un proyecto de generación de energía solar. El
 proyecto consistiría en la construcción y operación de una planta solar generadora de energía eléctrica. Las bases de la
 licitación estipulan que el estado chileno ofrece el terreno para que sea usado indefinidamente, es decir, durante infinitos
 años y del mismo modo la empresa que gane la licitación se debe comprometer a operar (generar y vender la energía
 generada por la planta solar) para siempre.
 Las bases de la licitación estipulan también que la empresa que gane la licitación tendrá que construir e iniciar la
 operación de la planta el 1 de enero del año 2025 (hoy). Luego de estas fechas no hay posibilidades de desarrollar el
 proyecto. Suponga que la construcción de la planta es instantánea, lo que hace que el momento en el que se construye la
 planta y aquel en el que la empresa ganadora de la licitación puede comenzar a operarla es el mismo, y corresponde al
 17 de enero del año 2025. :
 Para entregar el terreno a la empresa que se gane la licitación, el estado chileno pide un pago anual constante en US$
 que deberá ser pagado por la empresa ganadora el último día de cada año, es decir a partir de fines del año 2025 y durante
 los infinitos años que duraría la concesión del terreno.
 Las empresas interesadas en presentarse a la licitación deben tener en cuenta la siguiente información:
 * — Inversión: Se estima que el monto que se deberá invertir es de US$ 50.000, monto total que debe ser pagado el
 179 de enero del año 2025.
 * Mantenciones y reinversiones: Se estima que en la medida que a la planta de energía solar se le haga todos los
 años las mantenciones necesarias y además se realicen las reinversiones que permitan que cada año ella quede
 como nueva, la planta estaría en condiciones de generar energía solar durante infinitos años.
 * Ingresos de caja estimados para la empresa que gane la licitación: Se ha estimado que producto de la venta
 de energía, la empresa que gane la licitación pueda obtener a fines del año 2025 y anualmente de manera
 perpetua, un flujo de ingresos de caja total anual esperado de US$60.000
 * Egresos de caja estimados para la empresa que gane la licitación: Se ha estimado que producto de la
 generación de energía, la empresa que gane la licitación pueda obtener a fines del año 2025 y anualmente de
 manera perpetua, un flujo de egresos de caja total anual esperado (incluidos egresos de caja por mantenciones
 y reinversiones) de US$50.000.
 * — Tasa de descuento anual: La tasa anual relevante para la evaluación del proyecto dado su riesgo es de 10%
 anual y es constante a través del tiempo.
 En todas las preguntas que se le formulan más adelante suponga que:
 e Las empresas que se presenten a la licitación no tienen ni tendrán deudas y buscan maximizar su valor
 económico o de mercado.
 * — Por “monto máximo” se entenderá aquel monto que a quien lo ofrece le dejaría indiferente entre ofrecer o no
 dicho monto, es decir aquel que no haría cambiar la riqueza de quien lo ofrece.
 * — No hay impuestos
 * — Todos los flujos de caja, con la sola excepción de lo relativo a la inversión inicial, se producen al término de
 cada año.
 Responda las preguntas que se le formulan a continuación mostrando los cáleulos necesarios:
 1. Suponga que la empresa “Rayo de Luz” está interesada en presentarse a la licitación. Obtenga el monto máximo
 anual constante en US$ de hoy (1 de enero de 2025) que “Rayo de Luz” debiera estar dispuesta a pagar al estado
 chileno, al término de cada año, por tener la concesión que le permitiría operar durante infinitos años la planta de
 energía.
 2. Suponga ahora que se produce un cambio en las condiciones de la licitación. Ahora el estado chileno está dispuesto
 a que la planta de energía se pueda construir y comenzar a operar ya no solo el 1 de enero del año 2025, sino
 altenativamente el 1" de enero de los años 2026 o 2027 o 2028. Luego de este último año no hay posibilidades de
 construir la planta. Respecto de los próximos años se sabe que la cantidad de energía que la empresa podría generar
 y vender anualmente podría variar cada año, en un porcentaje respecto del flujo de caja de ingresos del año anterior,
 según lo indicado en la tabla que se muestra más adelante. Por otra parte, razones regulatorias han llevado a las
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 155

[pág. 156]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2024 | pregunta 4
 Convocatoria 2 | página original 422 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 empresas interesadas en presentarse a la licitación a estimar un aumento en el flujo de egreso
 de caja total anual, en
 un porcentaje respecto del flujo de egresos de caja del año anterior según lo indicado en la tabla que se
 muestra más
 adelante.
 Tasa de aumento anual respecto del año anterior
 Año Aumento % del Flujo de Ingresos de Caja | Aumento % del Flujo de Egresos de Caja
 (respecto del año anterior) (respecto del año anterior)
 2025 Dato de Flujo de Ingreso de Caja: US$60.000|Dato de Flujo de Egreso de Caja: US$50.000
 2026 3,0% 2,0%
 2027 4,5% 5,0%
 2028 4,0% 6,0%
 2029 en adelante 0,0% 0,0%
 En todo caso las empresas interesadas en presentarse a la licitación han estimado que lo relevante para determinar
 el
 monto (US$) de la oferta que cada una de ellas haría en este caso, sería suponer que tanto el flujo de ingresos de caja
 total anual esperado como de egresos de caja total anual esperado que se generaría a perpetuidad sería el que
 corresponde al año en que decidan construir y comenzar a operar la planta. De este modo, de la lectura del cuadro
 de
 ingresos y egresos de caja anuales presentado anteriormente se debe desprender que, si la empresa comienza a operar
 el año 2025, los ingresos de caja de todos los años en que ella opere serían de US$60.000 a perpetuidad. Si comienza
 a operar el año 2026 los ingresos de caja de todos los años en que ella opere serían de US$61.800 a perpetuidad y así
 sucesivamente. Lo mismo se aplica a los egresos de caja.
 Sin embargo, para tener la opción de poder construir y comenzar a operar la central en alguno de los años futuros
 posibles (2026 o 2027 o 2028) la empresa que se presente a la licitación deberá ofrecer pagar al estado hoy (1
 de
 enero de 2025) y por una sola vez, un monto (US$) adicional a lo que ella estaba dispuesta a pagar anualmente en la
 pregunta anterior. En este caso entonces y bajo las nuevas condiciones de la licitación, la empresa ganadora tendría
 que pagar al término de cada año, a partir del 31 de diciembre de 2025, el monto en US$ ofrecido en la pregunta
 anterior y además pagar hoy, por una sola vez, el monto adicional que haya ofrecido pagar y que le permitiría tener
 la opción de construir la planta en el año que más le convenga.
 Suponiendo que cualquiera que sea el año en el que se decida construir la planta el monto de la inversión inicial se
 mantendrá en US$50.000 y que dicha suma se debe pagar el primer día del año de su construcción, a usted se le pide
 determinar el máximo monto adicional en US$ de hoy (1"* de enero de 2025) que la empresa “Rayo de Luz” debiera
 estar dispuesta a ofrecer pagar hoy al estado con las nuevas condiciones de la licitación.
 3. Finalmente suponga que las condiciones de la licitación son las que permiten que la planta se construya al comienzo
 de alguno de los cuatro años que se han descrito previamente, pero que ahora el estado ha flexibilizado la forma
 de
 pago del monto (US$) adicional que de acuerdo a la pregunta anterior la empresa estaría dispuesta a pagar hoy (1
 de enero de 2025), por una sola vez, por tener la opción de poder construir y comenzar a operar la central en alguno
 de los años futuros posibles (2026 0 2027 o 2028). El estado ahora permitiría que dicho pago adicional se agregue al
 monto anual que la empresa tendría que pagarle por la concesión a partir del 31 de diciembre de 2025 y que
 usted
 obtuvo en la primera pregunta. Obtenga el máximo monto total anual constante en US$ de hoy (1 de enero de 2025)
 que “Rayo de Luz” debiera estar dispuesta a pagar al estado chileno, al término de cada año, bajo las condiciones
 aquí señaladas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 156

[pág. 157]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2025 | pregunta 4
 Convocatoria 2 | página original 445 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N%4
 Doña Javiera es una de las dueñas de la recién creada empresa “Los Huasos” y se encuentra
 evaluando lo que
 podría ser su primer proyecto de inversión. Este nuevo proyecto requeriría de un monto
 de inversión inicial de
 US$ 14.000.
 La siguiente es la información que se conoce del primer y nuevo proyecto:
 * Los resultados esperados del proyecto en términos anuales son los que se presentan a continuación. Para
 todos los efectos prácticos, estos resultados esperados se mantendrán constantes a perpetuidad:
 = Resultado Operacional US$ 2.500
 - — Intereses (6%) (336)
 = Resultado antes de Impuestos 2.164
 - Impuestos (20%) (432.8)
 = Utilidad Neta USS 1.731,2
 * Gasto por Depreciación Anual = US$65
 * Requerimientos de Reinversión Anual (al término de cada año)
 = US$ 725
 Este monto de reinversión anual (US$ 725) le permitiría a la Empresa mantener
 a perpetuidad su capacidad
 para generar el Resultado Operacional anual de US$ 2.500 del nuevo proyecto. No obstante
 dicho monto de
 reinversión anual (US$ 725), el gasto anual por depreciación se mantendría constante en
 US $ 625.
 * Financiamiento de los US$ 14.000 requeridos para la Inversión Inicial:
 Nueva Deuda de Largo Plazo con un Banco (ver detalle en Tasa de Interés de la Deuda)
 = US$ 5.600
 Nuevo Aporte de Capital por parte de las dueñas de la Empresa
 = US$ 8.400
 * Tasa de Interés Anual de la Deuda (US$)
 = 6%
 La deuda estaría pactada en condiciones de mercado, dado su riesgo. Los
 intereses deben ser pagados al
 término de cada año. Mientras la empresa pague anualmente los intereses
 de la deuda, ella puede y espera
 mantener su nivel de deuda a perpetuidad.
 * Tasa de Costo de Capital Promedio Ponderado (CCPP); (usar este CCPP
 con tres decimales) = 15,079%
 Un análisis hecho por las dueñas de la empresa ha indicado que dadas las
 características de este proyecto de
 inversión (activos), este 15,079% es el CCPP anual, después de impuestos,
 relevante para los activos del
 proyecto que se está evaluando. Este es el CCPP óptimo de largo plazo
 y que se espera se mantenga a
 perpetuidad.
 * Tasa de Impuesto a las Utilidades de las Empresas
 = 20%
 SUPUESTOS:
 * El total de la inversión inicial se paga al inicio del proyecto y todos los ingresos
 y gastos del estado de
 resultados de la empresa, con la sola excepción de la depreciación del ejercicio,
 son flujos de caja que
 se producen al término de cada año. Suponga además que no hay inflación
 y que la empresa sólo tiene
 activos operacionales.
 * El mercado espera que las tasas que se han indicado se mantengan constantes
 en el largo plazo (perpetuidad).
 Al término de cada año, la empresa reparte a sus dueños el flujo de caja
 residua! disponible de la empresa.
 Preguntas:
 1. Obtenga el V.A.N del nuevo proyecto de inversión para las dueñas o socias
 de la empresa. Para responder,
 usted debe evaluar el nuevo proyecto desde la perspectiva de las dueñas
 de la empresa (o Enfoque de
 “Dividendos” o “Flujo de Caja Residual”), indicando si bajo
 estas condiciones convendría o no
 emprender el nuevo proyecto. En su respuesta refiérase y sea preciso
 en la determinación de: el monto de
 la inversión inicial a considerar, los flujos de caja relevantes y la tasa
 de descuento que a su juicio se debiera
 utilizar en el cómputo del Valor Actual Neto (VAN), desde la perspectiv
 a de las dueñas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 157

[pág. 158]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2025 | pregunta 4
 Convocatoria 2 | página original 446 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2. Enuna discusión entre dos ejecutivos de la empresa se produjo el siguiente
 diálogo:
 Ejecutivo 1: “Les comento que para llegar a ese CCPP de 15,079% que
 estamos usando, hemos tomado
 como base una empresa que es en todo idéntica a la nuestra (considerando
 también el nuevo proyecto),
 salvo en la relación entre los costos operacionales fijos y los costos operaciona
 les totales (fijos más
 variables) presentes en cada flujo. En el caso de la empresa que usamos
 como base, dicha relación era de
 un 50%, mientras que en el caso de nuestra empresa y en el proyecto que estamos
 evaluando dicha relación
 es de un 80%. Esa es la razón por la cual, en mi opinión y dado que como
 se nos ha informado ambas
 empresas tienen y seguirán teniendo el mismo nivel de riesgo financiero, a los
 activos de nuestro proyecto
 debemos exigirle un mayor rendimiento, esto es a estos activos debemos exigirle
 un CCPP mayor que el
 de la empresa usada como base, debemos exigirle ese 15,079%”
 Ejecutivo 2: “Entiendo aquello de que en este proyecto la relación a la
 que tú te refieres es más alta que
 aquella de la empresa usada como base y que por esa razón, y de acuerdo a tu
 opinión, se deba usar ese
 CCPP de 15,079% algo mayor que el de la empresa usada como base, sin
 embargo yo no estoy de acuerdo
 con esto último. Yo entiendo que precisamente por tratarse de costos
 “fijos”, es decir porque son costos
 que no cambian frente a cambios en el nivel de operaciones de la empresa
 (al menos dentro de cierto rango
 de actividad) y siendo todo lo demás idéntico entre nuestra empresa y
 la que hemos tomado como base,
 desde un punto de vista operacional ambas empresas enfrenarían el mismo
 nivel de riesgo operacional.
 Como además se sabe que ambas tienen también el mismo riesgo fimanciero
 relevante para la determinación
 de su CCPP, en mi opinión no habría motivo para que la relación entre
 los costos operacionales fijos y los
 costos operacionales totales deba afectar al CCPP de nuestra empresa
 o proyecto”
 Se Pide: Indique en primer lugar con cuál de las dos opiniones o planteami
 ento anteriores (Ejecutivo 1 0
 Ejecutivo 2) está usted de acuerdo y fundamente de manera conceptua
 l su respuesta
 Finalmente, ahora suponga que para el financiamiento de los recursos
 que la empresa obtendría a través de
 deuda con el Banco (US$ 5.600), ella pudiera acceder a un préstamo
 especial (deuda subsidiada) que puede
 ser usado únicamente para este proyecto, préstamo que tendría
 una tasa de interés preferencial de 3% amual
 a perpetuidad (antes de impuestos).
 Se pide responder: Dadas las características de la nueva deuda
 ¿Qué efecto tendría sobre el VAN del
 proyecto el que la empresa decidiese cambiar-el total de la actual deuda
 a “tasa de mercado” que tendría
 con el Banco para el financiamiento del nuevo proyecto por
 la nueva deuda a una “tasa subsidiada”?
 (cambio en el VAN del proyecto respecto del VAN que tenía cuando
 los US$5.600 de deuda usada para su
 financiamiento era a la tasa de mercado del 6% anual a perpetuid
 ad).
 Nota: Solo para efectos de simplificar su análisis y por lo tanto su respuesta
 , suponga que como resultado
 del endeudamiento a la nueva tasa “subsidiada” del 3%, tanto
 el CCPP de la empresa “Los Huasos”
 (15,079% ), como la Tasa de Rendimiento o de Rentabilidad originalmente
 exigida por las dueñas a su
 inversión NO cambian.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 158

[pág. 159]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2026 | pregunta 2
 Convocatoria 1 | página original 454 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N2
 Usted trabaja para la cadena de supermercados chilena “Chile Lindo”, con locales en varias regiones del país. Se le ha
 pedido evaluar la apertura de un nuevo local en Lima, Perú, lo cual representaría la primera expansión internacional de
 esta empresa. Para el desarrollo de este proyecto de inversión del nuevo local, la empresa “Chile Lindo”, ocupará un
 terreno de su propiedad ubicado en el centro de Lima, que actualmente no se está utilizando, por el cual pagó al momento
 de su compra MUSD 12.000 (miles de dólares americanos) y sobre el cual existe una oferta de una empresa inmobiliaría
 para comprarlo al contado por la suma de MUSD 20.000 (luego de considerar cualquier impuesto que para “Chile
 Lindo” pudiera significar la venta de dicho terreno). Por otro lado, “Chile Lindo”, deberá desembolsar MUSD 15.000
 en las instalaciones de la sala del supermercado y MUSD 1.000 como inversión el capital de trabajo inicial. El estudio
 de impacto vial solicitado por la municipalidad de Lima ya fue realizado y tuvo un costo de MUSD 200. Las ventas,
 costos y gastos esperados el primer año de operación de la sala de supermercado son los siguientes:
 Ventas MUSD 14.000
 Costo de venta (no incluye depreciación) MUSD 9.500
 Gastos de Administración y Ventas (no incluye depreciación) MUSD 1.200
 Nota: Todos los ingresos y gastos del proyecto que se quiere evaluar, con la sola excepción del gasto por depreciación
 anual, son flujos de caja que se producen al término de cada año.
 Otros datos:
 * Las instalaciones de la sala del supermercado se deprecian linealmente en 15 años y al término del año 15 tanto su
 valor residual para efectos contables como su valor comercial es de MUSD 0.
 e Latasa de impuestos a las utilidades de las empresas es de 27%.
 * Lavida útil u horizonte durante el cual se espera que el proyecto genere beneficios es de 15 años.
 * Al término de su primer año de operaciones la empresa deberá aumentar en MUSD 20 su inversión en capital de
 trabajo.
 * A partir del año 2 y hasta el año 15, se espera que los flujos de caja netos del proyecto en MUSD y que usted obtuvo
 para fines del año 1, crezcan cada año a una tasa constante del 2% anual, con respecto al año anterior.
 e Latasa de costo del capital promedio ponderado (WACC) después de impuestos de la compañía chilena se supone
 constante e igual a 6% (en USD).
 * Suponga que inmediatamente después de los 15 años de duración del proyecto, el terreno se puede vender al contado
 en MUSD 30.000 (neto de impuestos) y que también se recupera completamente el capital de trabajo inicial (MUSD
 1.000). El resto de capital de trabajo acumulado durante la vida del proyecto se utiliza en pagar el total de los costos
 de desmantelamiento de las instalaciones de la sala del supermercado y limpieza del terreno para su venta,
 alcanzando justo para ese propósito y no generando efecto tributario alguno.
 Se Pide:
 1. Dada la información y los supuestos ya mencionados, y otros que usted considere necesario explicitar, se pide
 responder lo siguiente: ¿Es este un proyecto del cuál la empresa pueda esperar que haya creación de valor financiero?
 Su respuesta debe presentar tanto el resultado a la pregunta (MUSD) como el detalle de su desarrollo
 Nota: Recuerde que la fórmula para obtener el Valor Presente (VP) de una anualidad de pago
 F para el primer año de un flujo, por n años, con tasa de crecimiento constante de 9% anual con respecto al año
 anterior, y tasa de descuento r% anual, es:
 F 1+9y
 VP = 1—( )
 r—g l+r
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 159

[pág. 160]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2026 | pregunta 2
 Convocatoria 1 | página original 455 | Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2. El ejecutivo a cargo de la expansión internacional ha planteado lo siguiente: “Dado que la empresa había comprado
 y pagado el terreno que se usaría para el proyecto hace ya varios años, no corresponde imputar como parte de la
 inversión en la evaluación económica de este proyecto valor alguno al terreno, por tratarse de un costo hundido y
 por lo tanto irrelevante”. ¿Esta Ud. de acuerdo con el planteamiento del ejecutivo? Fundamente su respuesta de
 manera conceptual.
 Un Director de la empresa le comenta: “este proyecto tiene un riesgo y costo de financiamiento particulares, lo cual
 invalida el análisis anterior usando el WACC. Por ejemplo, la industria de supermercados en Perú es distinta, por
 la mayor informalidad en el comercio y la mayor relevancia del canal tradicional (por ejemplo, almacenes de
 barrio), y que la hace más sensible al ciclo económico. A su vez, en Perú los créditos hipotecarios (para financiar
 la compra del terreno) son a tasas de interés inferiores a las observadas actualmente en Chile.”
 Se pide responder:
 3.1 ¿Qué supuesto relativo al riesgo del nuevo proyecto tiene el análisis presentado por usted en la pregunta N*1
 usando el WACC que se le entregó?
 3.2 Dado que el proyecto se desarrollaría en Perú y no en Chile ¿Qué ajustes o modificaciones Ud. sugeriría hacer
 en la evaluación del proyecto que Ud. ha presentado de modo de incorporar el punto de vista que ha hecho ver
 el Director con relación al WACC? Para esta pregunta se espera una respuesta cualitativa, no cuantitativa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 160

[pág. 161]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2022 | pregunta 3
 Convocatoria 1 | página original 358 | Leasing/arriendo y equivalencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº3
 La empresa Queulat es una compañía que tiene la concesión exclusiva de generación de energía eléctrica en una
 amplia zona del norte de su país. Por contrato con el Estado de Chile, Queulat es la única empresa autorizada para
 generar energía en la zona de concesión. Para cumplir con los compromisos de la concesión, la empresa genera
 energía a través de paneles solares por ser ésta una solución no sólo de mayor eficiencia y menor riesgo que otras
 fuentes de energía tradicionales, sino además una fuente muchísimo más amigable con el medio ambiente.
 Queulat adquiere paneles de energía solar y los instala en el lugar que se ha estimado es el más adecuado para
 cumplir con los requerimientos de la demanda de energía de cada sector que corresponde a su zona de concesión.
 Como resultado de su experiencia y de una relación de varios años con su proveedor de paneles solares, en este
 momento se ha llegado a un nivel de eficiencia que ha hecho que, en la práctica, la demora entre el momento en que
 Queulat compra los paneles solares y el momento en que ellos quedan instalados y listos para ser usados es mínima
 (despreciable).
 Por otra parte, se sabe que por distintas razones el proveedor acepta únicamente órdenes de compra de nueve paneles
 solares por pedido. El pedido de nueve paneles tiene un costo total de UF 900, las que deben ser pagadas en el
 mismo momento de la compra. Se estima que este precio se mantendrá sin cambios en el futuro.
 Se espera que cada panel pueda ser usado sin límite en el tiempo, en otras palabras, su vida útil es “infinita”. Se
 sabe también que cada tres años la compañía debe instalar, y ella se ha comprometido a hacerlo, tres nuevos
 paneles solares de modo de lograr satisfacer la creciente demanda por energía solar que se espera en su zona de
 concesión. Dado que justamente ayer, 31/12/2021, Queulat hizo el último pedido de nueve paneles, y hoy 1/1/2022
 instaló y comenzaron a operar tres de ellos, en este momento la compañía tiene en sus bodegas seis paneles sin uso.
 Suponga que para las empresas el costo del bodegaje propiamente tal (bodega y seguro) de los paneles solares es
 de $0.
 La Sra. Yanara, Gerente de Gestión de la empresa minera “El Alambre Pelado”, empresa que se encuentra fuera de
 la zona de concesión de energía de Queulat, se ha acercado a usted, Gerente Comercial de Queulat y le ha solicitado
 que Queulat le arriende, a partir de hoy 1/1/2022, cuatro paneles solares durante un período de exactamente cinco
 años. Si bien la empresa minera “El Alambre Pelado” podría acceder a la compra de los paneles por cuenta propia,
 ella no está en condiciones financieras que le permitan financiar dicha inversión en este momento, razón por la cual
 estaría optando por el arriendo. Aun cuando el arriendo de paneles solares no es parte del negocio de Queulat, y
 sabiendo que este eventual arriendo en nada cambiaría las ventas de energía de Queulat en su zona de concesión y
 con el solo propósito de colaborar con la empresa minera, Queulat ha accedido a arrendarle los cuatro paneles
 solares a un plazo de exactamente cinco años a partir del día de hoy. Por su parte, la empresa “El Alambre Pelado”,
 se ha comprometido a que, al término del quinto año, los paneles serían devueltos a Queulat en perfectas
 condiciones, listos para ser usados por Queulat cuando lo estime conveniente.
 La política de “Queulat” es la de ayudar a todos quienes pueda, con la condición de que, en este caso, este eventual
 arriendo no signifique una disminución de valor de la riqueza de sus propios accionistas. “Queulat” tampoco busca
 aumentar la riqueza de los accionistas producto de este eventual contrato de arriendo.
 Se sabe que el costo de oportunidad relevante para las inversiones en paneles solares es de 10% real anual y que el
 Estado ha otorgado una ventaja tributaria permanente a las empresas generadoras de energía solar, a la que está
 sujeta “Queulat”, que consiste en el no pago de impuestos durante toda la vida de la empresa.
 Sobre la base de la información que se le ha entregado a usted se le pide responder la pregunta que se le formula a
 continuación, presentando un análisis ordenado con todos los cálculos que corresponda:
 Si el acuerdo del arriendo considerase que la empresa “El Alambre Pelado” pagaría el arriendo anual en UF al
 término de cada uno de los cinco años de duración del contrato (teniendo presente que el primer pago de arriendo
 sería el 31/12/2022), a usted se le solicita que obtenga el monto anual que Queulat debiera cobrar por el arriendo de
 los paneles a la empresa “El Alambre Pelado”, de modo de cumplir satisfactoriamente con el objetivo que ella se
 ha propuesto. Recuerde que este objetivo es el de colaborar con la empresa minera, con la condición de que el
 contrato de arriendo no altere el valor de la empresa “Queulat” para sus dueños, respecto de la alternativa de no
 arrendar los paneles. Explicite sus supuestos si los hubiera.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 161

[pág. 162]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2016 | pregunta 3
 Convocatoria 2 | página original 207 | Liquidez y capital de trabajo
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N'*3
 La empresa “Los Bicampeones” (LB) se dedica a la compra y venta a mayoristas de un único producto: la
 camiseta oficial de la selección chilena. -
 La siguiente es la información financiera de la empresa LB, al 31 de diciembre de 2016:
 Balance al 31/12/2016
 Caja 100.000|Cuentas x Pagar Proveedores
 Cuentas x Cobrar 125.000 -
 Existencias 225.000
 Terrenos 550.000[Patrimonio
 Activos Totales $1.000.000Pasivos + Patrimonio
 Se sabe que la rentabilidad operacional de la empresa el año 2016 alcanzó a un 5%, lo que ha llevado a su
 Gerente a plantear al Directorio la conveniencia de aumentar el plazo que se otorga a los clientes para el pago
 de sus compras, con la finalidad de acceder a nuevos mercados y así aumentar las ventas de LB.
 A continuación se presentan los valores, de algunas variables de la política de crédito que sigue actualmente
 la empresa con sus clientes, y los cambios que propone el Gerente para el año 2017:
 Política Actual (2016) | Nueva Política (2017)
 Ventas Anuales ($) $1.000.000 $1.100.000
 Rotación de Cuentas por Cobrar (veces al año) E
 Rotación de Existencias (veces al año) E s 4 —
 Período Promedio de Pago a Proveedores (días) 36 36
 Incobrables (% sobre ventas) 0% 0%
 Margen operacional (% de Utilidad Operacional/Ventas) 5% - 5%
 Descuento por Pronto Pago 0% 0%
 En opinión del Gerente, el cambio de política que él propone, no sólo generará un aumento en la liquidez y en
 la rentabilidad operacional de la empresa, sino que también permitirá aumentar la riqueza de los dueños.
 Algunas de las características más relevantes de la empresa son las siguientes:
 e Laempresa compra todo a crédito a sus proveedores y vende todo a crédito a sus ¿]ientes.
 e Todas las compras y ventas se producen de manera uniforme durante el año.
 * Laempresa comercializa un único producto, con el mismo costo y el mismo precio de venta unitario.
 * El costo de adquisición de cada camiseta, corresponde a un 90% de su precio de venta y se mantendrá sin
 cambios con la nueva política de crédito.
 e Laempresa tiene únicamente los cuatro tipos de activos que aparecen en el balance que se ha presentado,
 y todos ellos son operacionales: Caja, Cuentas por Cobrar, Existencias y Terrenos. De manera similar, la
 empresa tiene únicamente un tipo de pasivo: Cuentas por Pagar a Proveedores, las que no generan intereses
 de manera explícita. Todo el financiamiento complementario corresponde a Patrimonio.
 e El total de los activos de la empresa durante los dos últimos años, situación que se espera se repita en los
 próximos dos años, se ha mantenido constante en $1.000.000.
 * No hay impuestos ni inflación.
 e La empresa no tiene transacciones que den origen a resultados contables (utilidades o pérdidas) no
 operacionales, Los únicos gastos operacionales de la empresa son 100% variables y corresponden al Costo
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 162

[pág. 163]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2016 | pregunta 3
 Convocatoria 2 | página original 209 | Liquidez y capital de trabajo
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 de Ventas y a los Gastos de Administración y Ventas. De este modo, el Resultado del Ejercicio anual de la
 empresa (Utilidad o Pérdida) es idéntico a su Resultado Operacional anual.
 * Latasa de costo de oportunidad o de descuento, según el riesgo relevante tanto de cada uno como de los
 activos de la empresa considerados individualmente, como del total de sus activos en conjunto, es de 15,5%
 anual, compuesta diariamente.
 * Unaño tiene 360 días (meses de 30 días).
 * — Es política de la empresa, disponer el 31 de diciembre de cada año, de Caja o Efectivo equivalente al 10%
 del total de las ventas del año que está terminando.
 * Los pedidos de existencias se reciben en la bodega de la empresa el mismo día en que ellos se realizan.
 PREGUNTAS
 Sobre la base de la información presentada, a Ud. se le pide:
 Evaluar financieramente la propuesta del Gerente de LB. Específicamente, refiérase y fundamente de manera
 numérica, su opinión sobre cada uno de los siguientes tres aspectos señalados por el Gerente y que se
 producirían durante el año 2017, como resultado de la implementación de la nueva política de crédito:
 * Habrá un aumento en la riqueza de los dueños de la empresa.
 e Habrá un aumento en la rentabilidad operacional de la empresa.
 * Habrá un aumento en la liquidez de la empresa (para su medición, use los dos indicadores contables
 tradicionalmente utilizados para ello).
 NOTA: En la página siguiente encontrará una tabla de interés diaria correspondiente a una tasa de interés del
 15,5% amual, compuesta diariamente.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 163

[pág. 164]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2021 | pregunta 3
 Convocatoria 2 | página original 345 | Liquidez, ciclo y GLO
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 PREGUNTA Nº3
 Santa Juana es una viña que se encuentra en la zona central de nuestro país y sus propietarios son chilenos que
 viven en Chile. La viña se ha dedicado durante los últimos años a la producción y exportación de vinos de
 primera calidad y si bien, en promedio, sus rentabilidades operacionales han sido relativamente buenas,
 siempre ha debido enfrentar fuertes cambios en sus ingresos por ventas, tanto por las permanentes y abruptas
 variaciones del tipo de cambio, como por la cantidad de vino exportada, producto de las variaciones en el clima
 al momento de la cosecha de uva apta para vinos de exportación. Además, la empresa enfrenta fluctuaciones
 significativas en sus costos, principalmente debido a los cambios en los precios de algunos insumos como
 fletes y los sueldos y arriendos que se debe pagar a las personas y por las maquinarias que debe contratar
 durante la etapa de recolección de la uva, todo lo cual genera desembolsos que dependen de la cantidad
 cosechada.
 La siguiente es la última información financiera disponible del año 2020 de la Viña Santa Juana:
 BALANCE "VIÑA SANTA JUANA" S.A.
 31 DE DICIEMBRE DE 2020
 $ $
 Activos Corrientes Pasivos Corrientes
 Caja y Activos Equivalentes a Caja 5.000 Cuentas por Pagar a Proveedores 24.000
 Cuentas por Cobrar a Clientes (Neto) 50.000 Sueldos por Pagar 30.000
 Existencias 240.000 Gastos Acumulados por Pagar 73.400
 Arriendo Pagado por Adelantado 25.000 IVA por Pagar 21.000
 Porción de C.P. de Bonos por Pagar 10.000
 Intereses por Pagar 1.600
 Total Activos Corrientes 320.000 Total Pasivos Corrientes 160.000
 Activos No Corrientes Pasivos de Largo Plazo
 Terrenos 40.000 Bonos por Pagar 40.000
 Máquinas 70.000
 Menos: Depreciación Acumulada -30.000 Patrimonio
 Capital 50.000
 Utilidades Retenidas 120.000
 Resultado del Ejercicio 30.000
 TOTAL ACTIVOS $400.000 TOTAL PASIVOS + PATRIMONIO $400.000
 ESTADO DE RESULTADOS 2020
 "VIÑA SANTA JUANA"
 Ingreso por Ventas 300.000
 Costo de Ventas -192.000
 = Margen Bruto 108.000
 Gastos de Distribución y Ventas (GDV) -13.500
 Gasto por Depreciación -10.000
 Gasto en Sueldos de Administración -60.000
 Gasto en Arriendo -16.000
 Gasto por Provisión por Deudores Incobrables -4.500
 = Resultado Operacional 4.000
 Gasto por Intereses -4.000
 Utilidad en Venta de Activo Fijo 40.000
 = Resultado Afecto a Impuestos 40.000
 Gastos por Impuestos -10.000
 Resultado del Ejercicio 30.000
 Otra información disponible de la Viña Santa Juana:
 ● Tanto la producción, como las ventas de vino son uniformes a través del año.
 ● Todas las ventas de existencias de la empresa son hechas con crédito que otorga a sus clientes.
 ● Todas las compras de existencias de la empresa son hechas con crédito de sus proveedores.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 164

[pág. 165]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2021 | pregunta 3
 Convocatoria 2 | página original 346 | Liquidez, ciclo y GLO
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 ● La empresa ha presentado una rotación de existencias promedio en los últimos años de 0,8 veces.
 ● La viña ha presentado una rotación de cuentas por pagar promedio en los últimos años de 18 veces.
 ● La suma de los costos y gastos operacionales fijos anuales de Santa Juana representa el 80% del total de
 sus gastos y costos operacionales anuales.
 ● El IVA que se adeuda al 31/12/2020, se debe pagar no después del 12/01/2021
 Supuestos para su análisis:
 ● Para las razones financieras en las que intervenga una variable de stock y una de flujo, para la variable de
 stock suponga su valor al término del año 2020.
 ● El año tiene 360 días
 En la reunión de directorio del 1 de enero de 2021, en la que se analizó la única información financiera
 disponible de la empresa y que es también la única de la que usted dispone, distintos(as) directores(as) hicieron
 ver sus opiniones respecto de diversos aspectos financieros de la empresa y que ellos(as) estimaban se podían
 desprender de la información financiera disponible.
 Respecto de la liquidez de la empresa, el director 1 dijo lo siguiente:
 “Dado que al 31/12/20 la razón corriente o circulante de la viña es tranquilizadora, de hecho es de 2,0 veces,
 y teniendo presente el ciclo de efectivo que tiene la empresa, esto es, el plazo que en promedio la empresa
 demora en cobrar sus cuentas por cobrar menos el plazo que en promedio se paga a los proveedores, es de solo
 40 días, opino que como empresa no debiéramos enfrentar problemas de liquidez, es decir, no debiéramos
 tener inconvenientes para pagar oportunamente nuestras obligaciones de corto plazo”.
 Respecto del riesgo operacional o variabilidad de los retornos de los activos de la empresa, la directora
 2 ha dicho lo siguiente:
 “Conociendo los elementos que determinan el riesgo operacional de una empresa, yo diría que a la luz de la
 información de la que disponemos, Santa Juana es una empresa de bajo riesgo operacional”.
 Además, esta directora agregó: “Otro argumento que me permite reforzar mi opinión en términos de que el
 riesgo operacional que enfrentamos es bajo, es constatar que en nuestra viña estamos operando con un nivel
 de endeudamiento [(Deuda Total/Patrimonio) = 1,0], cifra bastante inferior respecto del nivel de
 endeudamiento promedio que exhiben otras empresas comparables”.
 Finalmente, respecto de lo que conocemos como el principio de “igualdad” o “calce” en el tema del
 financiamiento general de la empresa, la directora 3 dice:
 “Yo agregaría que otro de los aspectos que me da tranquilidad, es que el principio que conocemos como
 principio de "igualdad" o "calce" se cumple holgadamente en la empresa. En efecto, la información que se
 nos ha entregado muestra que nuestros activos de largo plazo o "No Corrientes" son de $80.000 y la suma de
 nuestras fuentes de financiamiento de largo plazo (Deuda de Largo Plazo + Patrimonio) es de $240.000, es
 decir es tres veces el valor total de nuestros activos de largo plazo, que en el fondo es el valor que representa
 nuestras necesidades de financiamiento permanentes”.
 PREGUNTA
 A partir únicamente de la información de la que se dispone y que es la entregada previamente a usted se le
 pide analizar y comentar de manera independiente, los conceptos financieros, afirmaciones y conclusiones que
 pudieran contener las opiniones emitidas por cada uno de los(as) tres directores(as) de la empresa Santa Juana.
 Su análisis de los aspectos tanto cuantitativos como cualitativos o conceptuales de las opiniones de cada uno
 de los(as) tres directores(as), debe ser el resultado de la aplicación de sus conocimientos financieros a la
 información que se entrega de la viña.
 Nota:
 En el desarrollo de su respuesta, separe e indique claramente el análisis de las intervenciones de cada uno de
 los(as) tres directores(as), identificándolos(as) por su número (1, 2 o 3), de este modo: Director(a) 1: desarrollo
 de la respuesta; etc.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 165

[pág. 166]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2022 | pregunta 3
 Convocatoria 2 | página original 368 | Patrimonio y negociación bancaria
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº3
 Suponga que la empresa minera “Último Año” tiene al día de hoy, 1 de enero de 2023, sólo dos activos: el
 primero de ellos, es un activo actualmente en operaciones al que le queda un solo año de vida (se termina el
 31/12/2023) y cuyo flujo de caja de éste, su último año de operación, es completamente incierto; el segundo
 activo es una inversión en caja.
 Primer activo: el negocio actualmente en operaciones:
 Respecto del primero de los activos, el negocio actualmente en operaciones, las estimaciones de generación de
 flujo de caja neto operacional para el año 2023, muestran que se podría dar uno de sólo dos posibles resultados.
 Si el escenario del año que comienza hoy (año 2023) resulta ser un “buen año” para la economía, se espera que
 dicho activo genere un flujo de caja (al término del año) de $80. Si por el contrario, el año que comienza hoy
 resulta ser un “mal año” para la economía, se espera que dicho activo genere un flujo de caja (al término del
 año) de $0. No hay más flujos de caja después del año 2023 y cada uno de los dos posibles escenarios (“buen”
 o “mal” año para la economía) tiene una probabilidad de ocurrencia de 50%
 Segundo activo: caja
 Este segundo activo, corresponde a $10 que actualmente (1/1/2023) la empresa mantiene en caja.
 Financiamiento actual de la empresa:
 En este momento, 1/1/2023, la empresa está financiada con una combinación de deuda y patrimonio. La única
 deuda que mantiene la empresa es una deuda financiera cuyo saldo por amortizar en el día de hoy (1/1/2023) es
 de $30, que no devenga intereses, y que vence el 31/12/2023, una vez conocidos los flujos de caja que pudieran
 generar los activos de la compañía.
 Posibilidad de desarrollo de un nuevo proyecto de inversión:
 Adicionalmente se sabe que hoy 1 de enero de 2023, la empresa podría invertir en un nuevo proyecto el que
 requeriría de una inversión inicial de $10 y tendría una duración de un año, es decir, se invertiría hoy 1 de enero
 y generaría un único flujo de caja el 31/12/23. Si el año que comienza hoy (año 2023) resulta ser un “buen año”
 para la economía, se espera que este nuevo proyecto genere un flujo de caja neto operacional (al término del
 año) de $15. Si por el contrario, el año que comienza hoy resulta ser un “mal año” para la economía, se espera
 que este nuevo proyecto genere un flujo de caja (al término del año) de $0. Las probabilidades de “buen año” y
 de “mal año” de la economía para el año 2023, siguen siendo de 50% para cada escenario.
 Algunos supuestos:
 • Suponga que todos los agentes son neutrales al riesgo y que la tasa de descuento relevante para todos y
 cada uno de los flujos de caja presentes en el ejercicio (flujos generados por activos, deuda o patrimonio)
 es de 0% anual.
 • Suponga que la tasa de interés que las instituciones financieras pagan por depósitos a plazo es de un 0%
 anual (es decir, no hay una pérdida para la empresa si ella mantiene la caja guardada).
 • No hay inflación, impuestos ni costos de transacción.
 • Suponga que todo lo relacionado con esta empresa termina el 31/12/2023, es decir, suponga que todo
 dura un solo período.
 • Si al término del año la empresa dispusiera de caja para repartir a sus dueños, ella sería repartida a sus
 dueños en la forma de un dividendo en efectivo.
 • Respecto de los $10 que la empresa mantiene en caja en este momento (1/1/2023), suponga que:
 - Ellos pueden ser usados únicamente para el financiamiento del nuevo proyecto en el caso en que
 ella se decida a emprenderlo o para el pago de sus deudas financieras en el momento en que la
 empresa lo estime conveniente.
 - La empresa no puede usar esos $10 para ningún otro fin que no sea alguno de los dos indicados
 anteriormente. Si la empresa no emprende el nuevo proyecto, esos $10 deben quedar en caja hasta
 el término del año.
 • Suponga que durante el año 2023 la empresa no emitirá nueva deuda ni habrá nuevos aportes de capital.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 166

[pág. 167]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2022 | pregunta 3
 Convocatoria 2 | página original 369 | Patrimonio y negociación bancaria
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 Se Pide:
 1. Usando la información entregada en la pregunta, determine el valor económico del patrimonio o valor
 presente del patrimonio de los dueños de la empresa al 1/1/2023 sin considerar el nuevo proyecto de
 inversión.
 2. El Directorio de la empresa debe decidir si usar o no los $10 de caja de que dispone para financiar el nuevo
 posible proyecto de inversión. Desde una perspectiva únicamente financiera y por lo tanto en el contexto
 de accionistas o dueños que buscan maximizar el valor económico de su patrimonio, ¿Debiera la empresa
 emprender el nuevo proyecto de inversión? Fundamente numéricamente su respuesta.
 3. Suponga que el Banco está pensando en hacer una oferta a la empresa, consistente en un descuento por la
 deuda que ésta tiene con el Banco. Esta oferta consistiría en que si la empresa le prepaga hoy (1/1/2023) al
 Banco $10 de la deuda que vence el 31/12/2023 (esto es, si la empresa le prepaga antes de saber si el
 escenario del año 2023 ha de ser de un “buen” o un “mal” año para la economía y por lo tanto para las
 inversiones de la empresa y antes de que ella haya decidido si hacer o no el nuevo proyecto de inversión)
 el Banco le reduciría el valor a pagar por la deuda el 31/12/2023. Se sabe entonces que si la empresa hace
 el prepago al Banco usando los $10 de que dispone el 1/1/2023, ella no podría emprender el nuevo proyecto
 de inversión.
 ¿Cuánto es el monto máximo (en pesos) que el Banco debiera estar dispuesto a ofrecer a la empresa como
 descuento en el monto de $20, que la empresa le quedaría debiendo al Banco con vencimiento a fines del
 año 2023 para saldar completamente su deuda, si hoy (1/1/2023) ella le prepaga al Banco los $10?
 Fundamente numéricamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 167

[pág. 168]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2013 | pregunta 2
 Convocatoria 2 | página original 129 | Perpetuidad, VAN y patrimonio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº 2
 En la última reunión de los ejecutivos del departamento de estudios de un importante grupo de empresas chilenas, se
 discutía si se debía o no comprar parte de las acciones que emitiría una nueva empresa maderera que iniciaría un gran
 proyecto con la más avanzada tecnología. La empresa maderera ha puesto a la venta 10 acciones, que constituyen el
 total de la emisión, a un precio de $5.000 cada una. Para la empresa maderera, dicho proyecto sería la única inversión
 que ella tendría.
 Para la realización del proyecto, se requiere una inversión inicial de $75.000 ($ del presente). De esta inversión inicial,
 $50.000 se destinarían a la compra de maquinas de alta tecnología y $25.000 a inversión en capital de trabajo
 (específicamente existencias). Para efectos tributarios, la depreciación anual de la máquina sería de $5.000. Se estima
 que para mantener de manera invariable y perpetua la capacidad generadora de beneficios futuros de la empresa, al
 término de cada año ella tendría que reinvertir la suma de $5.500. Por las características de dichas reinversiones, se ha
 estimado que ellas no harían cambiar el gasto por depreciación de $5.000 que al término de cada año en el futuro y de
 manera indefinida tendría que reconocer la empresa.
 La inversión inicial se financiaría con los $50.000 de fondos provenientes de la nueva emisión de acciones y los
 $25.000 restantes con un préstamo bancario. Los accionistas recibirán al término de cada año, el total de los excedentes
 de caja disponibles para reparto. La deuda con el banco, que sería recibida por la empresa maderera el mismo día en
 que se inicia el proyecto, no tendría vencimiento y sólo requeriría el pago de los intereses al término de cada año (no
 habría por lo tanto amortizaciones del préstamo). El banco prestará los $25.000 a la tasa vigente en el mercado para
 ese tipo de deudas. Dadas las características de la empresa maderera y del proyecto que se está evaluando, el mercado
 estima que dicho préstamo tendría cero riesgo y por lo tanto la tasa que corresponde cobrar es la tasa libre de riesgo, la
 que alcanza a un 8% anual (antes de impuesto). La tasa de interés anterior, es la que corresponde a un mercado
 bancario competitivo.
 Se sabe también que la tasa de retorno exigida por el mercado a las acciones de una empresa dedicada a este tipo de
 negocios, considerando además el leverage económico con el cual ella operaría, es de 11,4545% anual y que la tasa de
 Costo de Capital Promedio Ponderado (CCPP) es de 10% anual, después de impuestos. Se estima que dichas tasas no
 cambiarían en el futuro.
 La tasa de impuesto sobre las utilidades contables de la empresa es de 15%.
 El Departamento de Estudios que está evaluando la decisión de comprar o no las nuevas acciones, espera que al
 término de cada año, la empresa genere una Utilidad Operacional de $10.000 (antes de impuestos) y un Flujo de Caja
 Operacional Neto (Ingresos de Caja Operacionales menos Egresos de Caja Operacionales), antes de impuestos, de
 $15.000, constantes hasta el infinito.
 Con la información anterior, el Departamento de Estudios presentó el siguiente cálculo de flujos de caja relevantes para
 determinar el valor de la empresa maderera:
 Flujo de Caja Operacional Neto $ 15.000
 Menos Impuestos (15%) 2.250
 Flujo de Caja Después de Impuestos $ 12.750
 Dado el flujo anterior, concluyó que el valor económico de la empresa era de $111.310 (obtenido de: $12.750/0,114545
 y aproximado al entero más cercano) y por lo tanto recomienda que el precio máximo que se debería estar dispuesto a
 pagar por una acción de la empresa maderera es de $11.131. Teniendo en cuenta que las acciones se estaban ofreciendo
 a un precio de $5.000 cada una, era evidente que debían comprarse.
 Suponga que no hay inflación y que todos los ingresos y gastos contables (excepto la depreciación del ejercicio) son
 flujos de caja y se producen al término de cada año de operación.
 El Presidente del grupo de empresas inversionistas, le ha solicitado a usted su asesoría para analizar esta inversión, para
 lo cual le ha hecho llegar toda la información anterior y le pide un informe en que le responda lo siguiente:
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 168

[pág. 169]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2013 | pregunta 2
 Convocatoria 2 | página original 130 | Perpetuidad, VAN y patrimonio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 1) Si usted está o no de acuerdo con el valor económico de la empresa obtenido por el Departamento de Estudios
 ($111.310). Si no está de acuerdo, le solicita que le entregue el valor económico de la empresa de acuerdo a su
 criterio, mostrando muy claramente la tasa de descuento que utiliza y la forma como obtiene los flujos para su
 evaluación.
 2) Si usted está o no de acuerdo con el precio máximo que se debería estar dispuesto a pagar por acción recomendado
 por el Departamento de Estudios ($11.131). Si no está de acuerdo, le solicita que le entregue el valor que a su
 juicio sería el precio máximo que se debería estar dispuesto a pagar por cada acción, mostrando muy claramente la
 manera como usted lo obtiene.
 3) Que en definitiva, le indique cual sería la Tasa Interna de Retorno (TIR) anual esperada de los accionistas, por su
 inversión en esta empresa maderera, si en realidad compran acciones a $5.000. En su respuesta, muestre muy
 claramente la forma como obtiene los flujos que utiliza en el cálculo de dicha TIR (use un decimal).
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 169

[pág. 170]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2011 | pregunta 3
 Convocatoria 2 | página original 77 | Proyecto, deuda y nuevo socio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº 3
 La empresa EL TREMENDO POZO, de giro Exploración y Explotación Petrolera, contaba con los siguientes activos y
 pasivos a fines del año pasado (31/12/X0):
 • $1.500 en caja.
 • Un terreno con un valor de mercado de $4.500.
 • Una deuda de largo plazo con un valor de mercado de $3.000.
 • Una licencia de exploración y explotación petrolera en el Estrecho de Magallanes.
 Adicionalmente se sabe que el patrimonio de la empresa está compuesto por 1.500 acciones.
 A primera hora de hoy, 1/1/X1, el geólogo de EL TREMENDO POZO descubre en el Estrecho de Magallanes un
 yacimiento de petróleo en la zona asignada a la empresa para su explotación a perpetuidad. La explotación del yacimiento
 demandaría una inversión inicial de $3.000 (hoy), la que se pagaría al contado y en efectivo, y generaría flujos de caja
 netos anuales de $600 a fines de cada año (el primer flujo el 31/12/X1), en forma perpetua.
 Sabiendo los actuales dueños de la empresa que el monto en efectivo (caja) de que dispone en este momento la Compañía
 no alcanza para financiar la nueva inversión (faltarían $1.500) y teniendo en cuenta que ellos (los dueños) no estarían en
 condiciones de aportar hoy los $1.500 que faltan, ellos han decidido que los $1.500 faltantes sean financiados con el
 aporte de capital ($1.500) de un nuevo socio. Los actuales dueños saben que si los $1.500 que faltan se financian con el
 aporte de capital de un nuevo socio, el Costo de Capital Promedio Ponderado (C.C.P.P.) relevante para evaluar el nuevo
 proyecto sería de 10% anual.
 Suponga que no hay inflación ni impuestos. Si a su juicio la respuesta a la pregunta requiere de algún supuesto, usted
 debe dejarlo claramente explicitado. Al final del enunciado del examen usted puede encontrar tablas de matemáticas
 financieras, las que son habitualmente entregadas simplemente por si el alumno las considera necesarias.
 Preguntas:
 1. Suponga que los actuales dueños de la empresa deciden emitir $1.500 de nuevo capital y lo invitan a usted a ser ese
 nuevo socio.
 Para responder esta primera pregunta “1”, suponga que el mercado de capitales ES perfecto. Esto significa entre
 otras cosas que: el C.C.P.P. no varía frente a distintos niveles de endeudamiento de la empresa, y que la empresa
 puede endeudarse a la “tasa de interés de mercado relevante para su riesgo”
 ¿Debieran los actuales dueños de la empresa, estar dispuestos a ofrecerle un 25% de la propiedad de la Compañía EL
 TREMENDO POZO al nuevo socio por su aporte de $1.500 de nuevo capital? Fundamente numéricamente su
 respuesta.
 2. Suponga ahora que el mercado de capitales NO ES perfecto y que los actuales dueños han estudiado todas sus
 alternativas de financiamiento y han llegado a la conclusión que, dadas las imperfecciones del mercado, ellos
 disponen únicamente de las siguientes dos alternativas de financiamiento posibles:
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 170

[pág. 171]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2011 | pregunta 3
 Convocatoria 2 | página original 78 | Proyecto, deuda y nuevo socio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 ALTERNATIVA 1 (Financiamiento con Deuda Bancaria): un Banco está dispuesto a prestarles los $1.500 que se
 necesitan para hacer la nueva inversión. Desgraciadamente, ahora y por las distintas imperfecciones que se observan
 en el mercado de capitales, el Costo de Capital Promedio Ponderado relevante para evaluar el nuevo proyecto en este
 caso de financiamiento con deuda, sería de 16% anual.
 ALTERNATIVA 2 (Financiamiento con aumento de Capital de un Nuevo Socio): invitarlo a usted como nuevo
 socio de la empresa. Suponga que usted tiene “alergia a la deuda” y solamente está dispuesto a invertir en empresas
 sin deuda. La empresa EL TREMENDO POZO, asesorada por su banco de inversión, quiere proponerle a usted
 suscribir el total de un aumento de capital por $4.500 a cambio de un X% de la propiedad de EL TREMENDO
 POZO. Los fondos se destinarían en parte a pagar el total de la deuda vigente y el resto para invertir en el proyecto.
 En este caso el C.C.P.P. relevante para evaluar el nuevo proyecto sería de 10% anual.
 ¿Cuál es el máximo porcentaje de propiedad de EL TREMENDO POZO que sus actuales dueños debieran estar
 dispuesto a entregarle a usted, como nuevo socio de la empresa, a cambio del aporte de capital de $4.500?, ¿Cuál es
 el mínimo porcentaje de propiedad que usted, como nuevo socio de EL TREMENDO POZO, estaría dispuesto a
 aceptar por su aporte de capital de $4.500?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 171

[pág. 172]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2021 | pregunta 6
 Convocatoria 1 | página original 338 | Proyecto, externalidades y precio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº6
 La empresa minera “El Litio Dorado”, acaba de construir un túnel para el uso privado de sus camiones, que
 permite acortar el camino entre dos ciudades en 40 kms. y evita transitar por cuestas muy pronunciadas.
 El monto de la inversión inicial en el túnel (costo de construcción y de sus vías de acceso) fue de $10.000.000 ($ de
 hoy) y los costos de mantenimiento y reparación anual del túnel, que son función exclusiva de la variable tiempo
 (no dependen de la densidad del tráfico), ascienden a $65.000 anuales, los que se deben pagar en efectivo al final
 de cada año.
 Para ayudar a cubrir sus costos, la empresa decidió abrir el túnel al público y cobrar un peaje. Dado que mañana
 será la inauguración del túnel al público, la empresa se ha visto obligada a fijar rápidamente y sin mayor análisis el
 precio que cobrará por el peaje (derecho a usar el túnel) a los vehículos que decidan usarlo, por supuesto en el
 entendido que los camiones de la propia empresa no pagarían dicho peaje. El precio que ha fijado es de $250 por
 vehículo.
 Se estima que la demanda anual por el uso del túnel es una función del siguiente tipo:
 q = 6.000 – 2p (ver Nota #1)
 Donde: q = Número de vehículos que paga peaje en el año
 p = Precio del peaje por vehículo, en pesos.
 Nota #1: Esta función de demanda, excluye a los camiones de la propia empresa que podrían llegar a usar el túnel
 Para todos los proyectos que se deban evaluar, suponga que:
  Todos los costos y gastos anuales, lo mismo que las reinversiones que haya que hacer anualmente, son
 flujos de caja que se producen al término de cada año.
  No hay inflación y tampoco IVA.
  Hay una única tasa de descuento relevante y ésta es de 10% anual.
 Se Pide:
 1. Suponiendo que:
  La empresa dueña del túnel ha fijado un único valor del peaje de $250 por vehículo, distinto de los
 vehículos de la propia empresa, que use el túnel.
  Por el hecho de poder usar el túnel, la empresa ahorra $20.000 al año (menores egresos de caja al término
 de cada año) por concepto de sus propios costos de transporte.
  Si al término de cada año de operación del túnel la empresa reinvierte $88.000, el túnel tendría una vida
 útil de infinitos años y una depreciación de $100.000 por año hasta el infinito.
  La tasa de impuesto a la renta de las empresas privadas es de 40% sobre sus utilidades.
 Suponiendo que para la empresa no hay otros costos o beneficios involucrados como resultado del túnel que
 acaba de construir y que el túnel no genera cambio alguno en los demás ingresos y egresos de caja de la empresa
 como un todo, a usted se le pide que obtenga:
 a. El Valor Actual Neto o Valor Presente Neto (VAN) que tiene para la empresa el túnel que acaba de
 construir, teniendo en cuenta los $10.000.000 que tuvo que invertir.
 b. La Tasa Interna de Retorno (TIR) que tiene para la empresa el túnel que acaba de construir, teniendo en
 cuenta los $10.000.000 que tuvo que invertir.
 Nota #2: Usted debe presentar el detalle de los cómputos que sustentan sus respuestas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 172

[pág. 173]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2021 | pregunta 6
 Convocatoria 1 | página original 339 | Proyecto, externalidades y precio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 2. Luego de 5 años de funcionamiento del túnel, el Gobierno ha estudiado la situación del túnel y teniendo en
 cuenta que el costo marginal de usar el túnel por vehículo es cero y que, por lo tanto, según el Gobierno, no se
 debería cobrar peaje, éste ha decidido negociar con la empresa dueña del túnel.
 El Gobierno ha decidido ofrecerle a la empresa un convenio, por medio del cual se compromete a pagarle un
 monto (en $) por cada vehículo que use el túnel (excluidos los vehículos de la empresa), en cuyo caso la
 empresa no cobraría peaje a los vehículos que usen el túnel, sino que se lo cobraría directamente al Gobierno.
 El Gobierno ha informado que, en caso de no llegar a un acuerdo con la empresa, procederá a construir otro
 túnel a 2 kms. de distancia del que actualmente tiene la empresa y canalizaría por el nuevo túnel el total del
 tráfico público, cobrando peaje cero. El costo de construcción del túnel para el Gobierno alcanza a los
 $16.500.000 ($ de hoy) y el costo de mantener el nuevo túnel sería de $80.000 al año, los que se pagarían al
 final de cada año. Suponga que si al término de cada año de operación del túnel el Gobierno reinvierte
 $120.000, el túnel tendría una depreciación anual de $100.000 y una vida útil de infinitos años.
 A Ud. se le solicita calcular el monto en pesos ($) del máximo valor por vehículo que use el túnel (excluidos
 los vehículos de la empresa), que la empresa dueña del túnel puede cobrar al Gobierno, de modo que éste (el
 Gobierno), esté indiferente entre aceptar ese convenio o construir su propio túnel. Fundamente su respuesta
 mostrando los cálculos necesarios y suponga que el Gobierno no paga impuestos.
 Ayuda:
  Recuerde la función de demanda entregada al inicio de la pregunta.
  Recuerde el supuesto de que la tasa de descuento siempre es de 10% anual.
 3. Suponga ahora que el Gobierno decidiera eliminar el subsidio al uso del túnel que Ud. determinó en el punto
 anterior, para concentrar la ayuda económica en las múltiples familias y empresas que han sido afectadas por
 la pandemia del Covid 19. Concretamente, el Gobierno le otorga plena libertad a la empresa dueña del túnel
 para que ésta fije el precio del peaje a cobrar por cada vehículo que atraviesa el túnel.
 Suponiendo que se mantiene vigente toda la información entregada para el desarrollo de la pregunta “1”,
 excepto el precio de $250 a cobrar por vehículo, a Ud. se le pide determinar el precio del peaje por vehículo,
 que la empresa “El Litio Dorado” debiera cobrar a cada vehículo, si su objetivo fuese maximizar el total de sus
 ingresos anuales. Fundamente su respuesta mostrando los cálculos necesarios.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 173

[pág. 174]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2020 | pregunta 2
 Convocatoria 2 | página original 317 | ROA, WACC y planificación financiera
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 PREGUNTA N° 2
 San Lorenzo S.A. es una empresa dedicada a la venta y distribución de implementos para la minería. Algunas de las
 políticas financieras de esta compañía son las siguientes:
  Caja: La política actual de la empresa, es la de terminar, al final de cada año, luego de pagados los dividendos que
 le corresponda pagar el último día del año, con un monto en Caja equivalente a 15 días, de las ventas en pesos
 esperadas para el año siguiente.
  Crédito a sus Clientes (Cuentas por Cobrar): San Lorenzo ofrece a sus clientes un plazo de 30 días para el pago
 de sus compras.
  Inventarios de Productos (Existencias): La política de existencias de la compañía, es la de operar con un Período
 Promedio de Permanencia de sus Existencias (P.P.P.E.) en bodega, de 45 días, es decir, ella debiera mantener en
 Existencias, como promedio, el equivalente a las ventas de 45 días de actividad, valoradas a su costo de adquisición.
 A continuación, se muestran el Balance de la empresa al día de hoy, 31 de diciembre de 2019, y el Estado de
 Resultados Proyectado para el año 2020 (todas las cifras en $):
 Balance de San Lorenzo S.A. al 31 de diciembre de 2019
 Activos Pasivos y Patrimonio
 Caja (1) $ 26.250 Bonos por Pagar (5) 250.000
 Cuentas por Cobrar (2) 87.500
 Existencias (3) 70.000 Capital 50.000
 Utilidades Retenidas (6) 100.000
 Instalaciones y Terrenos (4) 216.250
 Totales $ 400.000 Totales $ 400.000
 Estado de Resultados Proyectado de San Lorenzo S.A. para el año 2020
 Ingresos por Ventas $ 630.000
 ‐ Costo de Ventas -336.000
 = Margen Bruto 294.000
 ‐ Gastos de Adm. y Ventas -278.000
 = Resultado Operacional 16.000
 Gastos Financieros -5.000
 = Resultado Afecto a Impuestos 11.000
 ‐ Impuestos (20%) -2.200
 = Utilidad Neta o Res. del Ejercicio $ 8.800
 Notas al Balance (en sus cómputos suponga 1 año = 360 días)
 (1): El requerimiento de caja mínimo para la operación de la empresa, se ha estimado en el equivalente a 15 días de las
 ventas esperadas para el año siguiente (2020).
 (2): Si bien la política de la empresa es la de operar con un Período Promedio de Cobranza (PPC) de 30 días, en este
 momento (31-12-19) el PPC es de 50 días.
 (3): Aun cuando la política de la empresa es la de operar con un P.P.P.E. en bodega, de 45 días, los números muestran
 que al 31-12-19 el P.P.P.E. es de 75 días.
 (4): Los activos fijos depreciables, se deprecian a un ritmo de $5.000 anuales y dicha depreciación ya está incluida en
 los Gastos de Administración y Ventas del Estado de Resultados de San Lorenzo S.A. Además, se sabe que la
 empresa reinvierte todos los años una cifra igual a la depreciación contable ($5.000), para así poder mantener su
 capacidad operativa indefinidamente.
 (5): Cada 31 de diciembre, la empresa debe amortizar $50.000 de sus Bonos por Pagar. El saldo de esta cuenta al
 31/12/19, es posterior a dicha amortización. Estos bonos ofrecen pagar una tasa de interés del 2,0% anual (tasa de
 carátula) y la tasa de interés anual que el mercado exige a estos bonos es también del 2,0% anual.
 (6): El último día de cada año, la empresa reparte, como mínimo, dividendos en efectivo por un monto equivalente al
 total de las utilidades del ejercicio del año que está terminando. Dado lo anterior, el monto de Utilidades Retenidas
 que se presenta en el balance al terminar el año 2019, es posterior al reparto de las utilidades de dicho año.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 174

[pág. 175]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2020 | pregunta 2
 Convocatoria 2 | página original 318 | ROA, WACC y planificación financiera
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 En reunión de Directorio de hoy, 31/12/19, el Gerente de San Lorenzo, comentó lo siguiente: “Los resultados
 proyectados para el año 2020, nos permiten ver que la rentabilidad esperada sobre los activos será de un 10,7% tal
 como se aprecia en el siguiente indicador:
 (Rentabilidad de los Activos)2020 = [Resultado Operacional)2020 / Patrimonio(31/12/2019)] = [16.000/150.000] = 10,7%
 Esto demuestra que estamos creando valor para los dueños de la empresa, porque el 10,7% anterior es mayor que el
 Costo de Capital Promedio Ponderado (CCPP) relevante para San Lorenzo que asciende a un 4,5% anual.
 Suponiendo que:
  Todos los activos de la empresa son operacionales.
  Todas las ventas de San Lorenzo S.A. se efectúan a crédito, son parejas durante el año y de montos similares en $.
  Todas las compras de Existencias se efectúan al contado, son parejas durante el año y de montos similares en $.
  La tasa de impuesto a las utilidades de las empresas es de 20%.
  Las proyecciones de resultados operacionales de San Lorenzo para el año 2020, no se verán afectadas por los
 cambios que más adelante se propondrán para mejorar la gestión de sus activos.
  1 año = 360 días; Inflación = 0%;
  Para las razones financieras en las que intervenga una variable de flujo y una de stock, para la variable de stock use
 el valor al 31-12-19.
 A Ud. se le pide responder las preguntas que se le formulan a continuación, mostrando claramente todos los cálculos
 necesarios en los cuales se sustentan sus respuestas. Use dos decimales en sus cálculos, y suponga que la información
 contable que se entrega es la única disponible y relevante para su análisis.
 1. ¿Está Ud. de acuerdo con el análisis de la rentabilidad hecho por el Gerente de San Lorenzo y su conclusión en
 términos de una “creación de valor” por parte de la empresa en el año 2020?
 2. A diferencia de su Gerente, el Presidente de San Lorenzo, preocupado por lo que podría ser una señal de mala
 gestión de los activos de la empresa, le ha contratado a usted para analizar el impacto que tendría sobre la
 compañía, las medidas destinadas a mejorar su gestión y que se describen a continuación:
  Cambios tecnológicos aplicados a la gestión de la caja de la empresa, permitirían que el nivel de caja mínimo
 con el que actualmente ella opera, que equivale a 15 días de ventas, disminuya a 10 días de ventas, es decir,
 una disminución de 5 días.
  Disminuir el Período Promedio de Cobranza, desde los actuales 50 días a un período promedio de 30 días, es
 decir, lo disminuirá en 20 días.
  Disminuir el Período Promedio de Permanencia de su Existencias en bodega, desde los actuales 75 días a un
 período promedio de 45 días, es decir, una disminución de 30 días.
  Venta al contado, el mismo 31 de diciembre de 2019, de un terreno colindante con los terrenos de la empresa,
 que estaba destinado al estacionamiento de visitas y que se consideró como innecesario para el negocio. El
 terreno se vendería a su precio de mercado, el que casualmente correspondía a su costo histórico, y que
 alcanzaba a la suma de $8.250.
 Se sabe que si, el último día del año, la empresa presenta un exceso de caja en relación al nuevo monto de caja
 óptimo que ha determinado la compañía (10 días de ventas), dicho exceso que se produciría como resultado de la
 implementación de las medidas ya señaladas de mejora en la gestión de la empresa, lo repartiría completamente
 como dividendo en efectivo a sus dueños, el mismo 31 de diciembre de 2019, es decir, el reparto de dicho
 dividendo en efectivo, sería lo último que la compañía haría ese 31/12/19.
 Para su análisis, suponga que San Lorenzo se beneficiaría de manera completa e inmediata, es decir, en el
 mismo momento de su implementación, esto es, al término del año 2019, del total de los beneficios que se puedan
 producir como resultado de las medidas que se han propuesto.
 En base a lo anterior, responda las siguientes preguntas:
 a) Obtenga el monto ($) de la creación de valor que podría generarse en la empresa el 31/12/2019, como
 resultados del conjunto de medidas que se ha descrito y que han sido propuestas por su Presidente.
 b) Obtenga el monto ($) de la creación de valor esperada para el año 2020, luego de las medidas descritas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 175

[pág. 176]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2019 | pregunta 3
 Convocatoria 2 | página original 294 | Ratios y ciclo de caja
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N'3
 Hoy 1 de enero del año 2020, usted dispone únicamente de la siguiente información financiera al 31 de
 diciembre de cada uno de los últimos dos años de la empresa importadora y comercializadora de juegos
 novedosos para niños “La Novedad del Año S.A.”
 BALANCES 31/12/2018 | 31/12/2019
 ACTIVOS US$ US$
 Disponible (Caja, Depósitos Corto Plazo, etc.) 2.675 1,500
 Cuentas por Cobrar a Clientes 2.200 4.000
 Existencias 1.500 2.000
 Total Activo Circulante 6.375 7.500
 Activos Fijos (Netos de Depreciación) 13.661 15.250
 TOTAL ACTIVOS 22.036 22.750
 PASIVOS Y PATRIMONIO
 Cuentas por Pagar a Proveedores (Corto Plazo) 722 963
 Cuentas por Págar a los Bancos (Corto Plazo) 1.500 3.000
 Cuentas por Pagar al Fisco (Corto Plazo) 1.028 2.287
 Total Pasivo Circulante 3.250 6.250
 Pasivo de Largo Plazo 3.036 250
 Patrimonio Total 15.750 16.250
 TOTAL PASIVOS + PATRIMONIO 22.036 22.750
 ESTADO DE RESULTADOS (US$): Año 2018 Año 2019
 Ingresos por Venta 10,000 15.000
 Menos: Costo de Ventas de Existencias Vendidas -4.000 -6.000
 Menos: Gastos de Administración y Ventas -2,000 -2.300
 (No incluye Depreciación del Ejercicio)
 Menos: Depreciación del Ejercicio -1.000 -1.200
 Resultado Operacional 3.000 5.500
 Menos: Gastos Financieros (Intereses) -200 -335
 Igual: Resultado Afecto a Impuestos 2.800 5.165
 Menos: Impuestos (10%) -280 -516
 Jgual: Resultado del Ejercicio (Utilidad Neta) 2,520 4.,645
 Las preguntas se deben responder sobre la base de los siguientes supuestos:
 * No hay inflación y la tasa de impuestos a las utilidades de las empresas es de 10%
 * Todas las ventas se realizan otorgando crédito de corto plazo a los clientes y todas las compras de
 existencias a los proveedores son con crédito de corto plazo que ellos le otorgan a la empresa.
 * Todas las compras y las ventas de los productos que comercializa la empresa, se producen de manera
 uniforme a través del tiempo y son de montos ($) similares.
 * Laempresa sólo tiene Activos Operacionales,
 * Si enel cálculo de una “razón financiera” (ratio o cuociente financiero), intervienen variables de
 “flujo” (estado de resultados) y de “stock” (variables del balance), para la variable de “stock” considere
 el valor que dicha variable tenga al inicio del período (o valor final del período anterior). En sus
 cálculos use dos decimales.
 * Suponga: 1 mes = 30 días; 1 año = 360 días
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 176

[pág. 177]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2019 | pregunta 3
 Convocatoria 2 | página original 295 | Ratios y ciclo de caja
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 El cuadro siguiente, presenta información de los saldos de algunas cuentas al 31/12/2017 (cifras en US$):
 Algunos otros datos (US$): 31/12/2017
 Total de Activos: 14.000
 Total de Patrimonio: 10.000
 Saldo de Activo Disponible: 2,909
 Saldo de Cuentas por Cobrar: 1.000
 Saldo de Existencias: 1,000
 Saldo de Activo Fijo (Neto de Depreciación): 9.091
 Saldo de Cuentas por Pagar a Proveedores: 500
 Suponga que los siguientes son los datos relevantes para cada uno de los indicadores o razones de rotación
 de la empresa;
 Año 2018 Año 2019
 Rotación de Cuentas por Cobrar (veces) 10 6,8
 Rotación de Existencias (veces) 4 4
 Rotación de Cuentas por Pagar a Proveedores (veces) 9 9
 A usted se le pide que, desde una perspectiva financiera, analice la información financiera que se le ha
 entregado de la empresa “La Novedad del Año” y usando únicamente dicha información, responda las
 siguientes preguntas: N -
 a) Indique cuáles son las “debilidades” financieras más importantes que ha tenido la empresa en el
 último año (2019), en relación al año anferior (2018) y que se desprenden de la información entregada;
 sea preciso en su respuesta. Como parte de su respuesta, usted debe presentar el cálculo de las razones
 (ratios) financieros o-indicadores, que le permitan fundamentar dicha respuesta.
 ») En el último tiempo, se ha notado un aumento en el interés de los inversionistas por comprar acciones
 de la empresa. A usted se le pide que indique cuál es la “fortaleza” o “atractivo” financiero más
 importante que desde el punto de vista de los inversionistas potenciales, ha tenido la empresa en el
 último año (2019) en relación al año anterior (2018) y que se desprenden de la información entregada;
 sea preciso en su respuesta. Como parte de su respuesta, usted debe presentar el cálculo de dos razones
 (ratios) financieros o indicadores, que le permitan fundamentar dicha respuesta.
 Siusted, como Ingeniero Comercial, fuese contratado como asesor de esta empresa, indique cuál sería
 la recomendación, relacionada con un mejoramiento de la gestión financiera de la empresa, más
 importante que usted le haría a esta empresa. Usted deber ser muy claro y específico al momento de
 indicar cuál sería su recomendación. A modo de ejemplo: no es suficiente decir que se debe mejorar
 una determinada razón o ratio financiero, además de ello, se debe plantear la forma en que 2 su juicio
 se podría mejorar dicha razón o ratio financiero.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 177

[pág. 178]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2023 | pregunta 3
 Convocatoria 2 | página original 394 | Reemplazo de máquina y VAN
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº 3
 Una empresa analiza la conveniencia financiera de cambiar de una máquina antigua por una nueva. El cambio le
 permitiría a la empresa disminuir desde $500 millones a $350 millones sus costos de producción anuales a
 perpetuidad, manteniendo constante tanto su capacidad de producción, como sus ventas. La empresa reinvertirá
 anualmente en la máquina nueva el monto necesario para que su vida útil sea infinita. Los montos tanto de
 depreciación anual como de las reinversiones anuales necesarias para el funcionamiento de la nueva máquina son
 iguales a los de la máquina que se está reemplazando. La máquina antigua se puede vender al contado a su valor
 neto de libros (costo histórico menos depreciación acumulada), que es de $200 millones. La tasa de impuestos a
 las utilidades de las empresas es de 30%.
 Para el financiamiento y pago al contado del costo total de la nueva máquina, se podría disponer de un crédito
 por el cual la empresa tendría que pagar como intereses anuales a perpetuidad y al término de cada año, la suma
 de $60 millones, correspondientes a una tasa de interés anual de 5%. Cumpliendo con el pago anual de los
 intereses, la empresa no requeriría de amortizaciones o pagos del crédito solicitado.
 El Costo de Capital Promedio Ponderado (C.C.P.P. o W.A.C.C.) de la empresa, relevante para este tipo de
 inversiones, dado su nivel de endeudamiento objetivo (óptimo) de largo plazo, es de 12% anual después de
 impuestos. El proyecto que se evalúa no cambiará dicho nivel de endeudamiento objetivo de largo plazo.
 Suponga que no hay inflación y que todos los flujos a que se refiere el tema se producen al término del año.
 El siguiente es un resumen de las opiniones emitidas por tres Gerentes de la compañía respecto del proyecto de
 inversión:
 Gerente de Proyectos: En primer lugar, quiero exhibir una evaluación financiera, que muestra tanto lo que a mi
 juicio sería la inversión inicial que la empresa tendría que hacer, como los flujos de caja que la nueva máquina
 podría generar y por lo tanto el impacto que tendría el cambio de máquina sobre el valor de la empresa:
 Inversión Flujos de Caja Anuales
 Inicial (Desde Fines del Año 1
 (Al comenzar el Año 1) hasta el Infinito)
 Ahorro de costos - MM$ 150
 - Pago de intereses por la nueva deuda - (60)
 + Ahorro de impuestos por uso de la deuda - 18
 Flujo de Caja Neto de la Nueva Máquina MM$ 0 MM$ 108
 En mi opinión, dado que según la evaluación financiera que he presentado, la empresa tendría a perpetuidad un
 mayor flujo de caja anual de $108 millones con la nueva máquina, y teniendo en cuenta que la tasa de descuento
 relevante para este tipo de inversiones, es decir, la que corresponde dado el riesgo de sus flujos de caja, es de
 12% anual, el proyecto tiene un VAN o VPN de $900 millones (= [MMS108/0,12]), me parece obvio que la
 empresa debe comprar la nueva máquina. ¡¿qué mejor argumento que un VAN positivo?!
 Gerente de Finanzas: En mi opinión, debemos tener en cuenta que para la realización de este proyecto la única
 inversión que como empresa tendríamos que hacer serían los $200 millones que se recaudarían por la venta de la
 máquina antigua, puesto que el resto del financiamiento necesario se puede solicitar al banco a una tasa de interés
 del 5% anual, lo cual generaría un desembolso de $50 millones en intereses anuales a perpetuidad y al término
 de cada año. Esto haría aumentar los flujos de caja anuales del proyecto (desde fines del año 1 al infinito) que se
 muestran en el cuadro anterior desde MM$ 108 a MM$ 115 (intereses de la nueva deuda serían de MM$50 y el
 ahorro de impuestos por el uso de deuda ascendería a MM$15). Podemos decir entonces, que la interna de retorno
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 178

[pág. 179]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2023 | pregunta 3
 Convocatoria 2 | página original 395 | Reemplazo de máquina y VAN
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 (TIR) del proyecto es de un 57,5% anual (= 115/200) a perpetuidad. Por lo tanto, estamos frente a un proyecto
 cuya TIR es mayor que su CCPP (12% anual), lo que significa que hay creación de valor.
 Gerente General: He escuchado con mucha atención sus opiniones, pero quiero darles a conocer una información
 que recién me ha sido entregada. El Resultado del Ejercicio de la empresa del último período es una pérdida de
 $600 millones. De este modo, nuestra empresa tiene una “Pérdida Acumulada” de $600 millones que puede ser
 usada para disminuir los pagos futuros de impuestos hasta que se agote dicho monto1. De hecho, la empresa
 espera obtener grandes utilidades en los próximos períodos, lo que sin duda le permitiría aprovechar la “Pérdida
 Acumulada” en cuestión. Según mis cómputos, el valor presente de los menores pagos de impuestos que
 tendríamos con la Pérdida Acumulada sería de $136,7 millones (Nota: suponga que este valor es correcto. No se
 pide demostrarlo).
 Con la nueva información he procedido a evaluar el proyecto de compra de la nueva máquina de la forma que yo
 considero correcta y en realidad, aunque no estoy de acuerdo con los resultados que ustedes me han entregado
 (VAN = $900 millones y TIR anual = 57,5%), mi conclusión es la siguiente: lo mejor que puede hacer la
 empresa en este momento, dado el monto de Pérdida Acumulada con la que ella cuenta, es comprar la nueva
 máquina. Mi principal argumento para fundamentar esta conclusión es que estamos frente a un proyecto que por
 sí mismo crea valor y tiene méritos propios suficientes como para ser emprendido. Sin embargo, termina diciendo
 el Gerente General, de acuerdo con mis cálculos, de no contar con la ventaja tributaria que genera la “Pérdida
 Acumulada” que les he comentado, nosotros no debiéramos comprar la nueva máquina.
 A usted se le pide contestar las preguntas que se le formulan a continuación mostrando los cálculos y argumentos
 necesarios para fundamentar sus respuestas. Trabaje las cifras en millones de $ (MM$).
 PREGUNTAS
 1. Analice y evalúe los comentarios y la evaluación financiera del Gerente de Proyectos de la empresa
 (teniendo en cuenta únicamente la información con que él contaba al momento de hacer su evaluación),
 indicando expresamente, si los hubiera, los errores o críticas que usted le haría ya sea a los comentarios o a
 la evaluación que él ha presentado. Si no está de acuerdo con el VAN o VPN que él presenta, entregue lo
 que a su juicio sería el verdadero VAN (Indique: inversión inicial, flujos relevantes, tasa de descuento y
 VAN).
 2. Responda lo solicitado en la pregunta anterior, ahora respecto de los planteamientos del Gerente de
 Finanzas. Si no está de acuerdo con la TIR que él presenta, entregue lo que a su juicio sería la verdadera
 TIR (Indique: inversión inicial, flujos relevantes y TIR).
 3. Respecto del planteamiento hecho por el Gerente General, analice críticamente la conclusión y el argumento
 que él entrega para fundamentar su opinión favorable respecto de la compra de la nueva máquina.
 1 : Esto significa que, si el resultado antes de impuestos generado en su primer año de actividad por el activo que se está evaluando, fuese
 por ejemplo de $200 millones, en ese año no se pagarían impuestos ya que se podrían ocupar $200 millones de los $600 millones de
 “Pérdida Acumulada” disponible, y así sucesivamente en los años siguientes, hasta que ésta se agote.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 179

[pág. 180]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2020 | pregunta 3
 Convocatoria 1 | página original 307 | Reemplazo y costo anual equivalente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº3
 “San Roque” es una empresa dedicada al transporte de rocas para la construcción de “roqueríos”, que opera
 con un camión de manera permanente, el que cada cierto tiempo debe ser reemplazado por uno nuevo.
 Camión Petrolero:
 Hoy, 31 de diciembre de 2019, la empresa dispone de un camión petrolero (en adelante “el petrolero”), que
 fue comprado nuevo por “San Roque” el 31 de diciembre de 2014. El costo de adquisición del “petrolero”,
 fue de MM$ 64 (millones de $), precio pagado al contado. Al momento de su adquisición, el “petrolero” tenía
 una vida útil (VU) de 8 años, un valor residual (VR) o de desecho para fines contables y tributarios de MM$
 0 y se deprecia linealmente. La empresa “San Roque”, sabe que, si el camión “petrolero” se vende antes del
 término de su vida útil o al término de ella, su precio de venta en el mercado (PV) sería de MM$ 0. La operación
 anual del “petrolero”, le significa a “San Roque”, un total de egresos de caja, tanto cuando el camión está
 nuevo, como en la actualidad, de MM$ 20, antes de impuestos.
 Se sabe que este modelo de camión “petrolero”, se encuentra siempre disponible en el mercado, manteniendo
 sus características operacionales y financieras: costo de adquisición = MM$ 64 (contado); total egresos de
 caja anuales (antes de impuestos) = MM$ 20; V.U. = 8 años; VR = MM$ 0; PV (antes o a fines del año 8 de
 uso) = MM$ 0.
 En este momento se ha comenzado a ofrecer en el mercado un nuevo modelo de camión, que para su operación
 usaría energía eléctrica (en adelante “el eléctrico”), y que se sabe cumpliría perfectamente con los
 requerimientos técnicos que “San Roque” exige a sus camiones.
 Camión Eléctrico:
 El costo de adquisición del eléctrico es de MM$ 100 (precio contado), tiene una vida útil (VU) de 10 años, un
 valor residual (VR) o de desecho para fines contables y tributarios de MM$ 10 y se deprecia linealmente. Se
 estima que al término de su vida útil (fines del año 10 de uso), este camión, “eléctrico” podría ser vendido
 (PV) en MM$ 14 (al contado). La operación anual del “eléctrico”, le significaría a “San Roque”, un total de
 egresos de caja de MM$ 15 antes de impuestos. En caso de comprar este camión, la empresa no lo vendería
 antes del término de su vida útil.
 Se sabe que este modelo de camión “eléctrico”, se encontraría siempre disponible en el mercado, manteniendo
 sus características operacionales y financieras: costo de adquisición = MM$ 100 (contado); total egresos de
 caja anuales (antes de impuestos) = MM$ 15; V.U. = 10 años; VR = MM$ 10; PV (fines del año 10 de uso) =
 MM$ 14.
 En este momento, la empresa “San Roque”, se encuentra evaluando las siguientes tres opciones, mutuamente
 excluyentes:
 Opción 1: Cambiar hoy el camión petrolero por un camión eléctrico y en el futuro seguir operando
 siempre con camiones eléctricos.
 Opción 2: No cambiar hoy el camión petrolero, pero sí cambiarlo por un camión eléctrico al término de
 su vida útil, esto es, dentro de tres años. Luego de dicho cambio, seguir operando siempre con camiones
 eléctricos.
 Opción 3: No cambiar hoy el camión petrolero y seguir operando con él durante los tres años que le
 restan de vida útil y al término de esos tres años, volver a invertir en la compra de un nuevo camión petrolero,
 y al término de su vida útil, renovarlo por el mismo tipo de camión de manera indefinida, de modo de seguir
 operando de manera permanente con camiones petroleros.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 180

[pág. 181]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2020 | pregunta 3
 Convocatoria 1 | página original 308 | Reemplazo y costo anual equivalente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 Suponga que:
  Todos los flujos de caja relacionados con los distintos proyectos anteriores, se producen el último día
 de cada año y comienzan a producirse exactamente un año después de realizada la inversión inicial.
  El “Costo de Capital Promedio Ponderado” (después de impuestos), relevante para la evaluación
 financiera de ambos camiones, es de 8% anual.
  La Tasa de Impuestos es de 25%; Inflación = 0%
  La empresa minera “San Roque” requiere seguir contando con un camión para el transporte de rocas,
 de manera permanente y en forma indefinida.
  La disponibilidad de cualquier camión nuevo, es “instantánea”, es decir, comienza a operar de
 inmediato y a generar sus flujos justo un año después de su inversión inicial.
  Los ingresos por ventas anuales que se pueden generar con cada uno de los dos tipos de camiones son
 los mismos.
  Para efectos tributarios “San Roque” utiliza depreciación lineal y tiene suficientes ingresos como para
 absorber cualquier costo y gasto derivado de la operación de los camiones.
  Trabaje las cifras en millones de $ (MM$) y con dos decimales.
 A usted se le pide, evaluar desde un punto de vista financiero, las tres opciones o alternativas, mutuamente
 excluyentes, de reemplazo de los camiones de la minera “San Roque”, indicando claramente cuál de las tres
 alternativas, es la más conveniente para la empresa. Explique claramente su respuesta y para sus cálculos, si
 lo requiere, utilice las tablas de matemáticas financieras que se adjuntan al final del enunciado. De cualquier
 modo, todo cálculo numérico debe estar suficientemente respaldado por la expresión matemática que lo ha
 originado.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 181

# Manual de Finanzas · parte 5 (páginas 237-256)

Fuente: 02_MANUAL_ULTIMATE_FINANZAS_EDG_2027_V2_FORMULAS_CLARAS

[pág. 237]
Finanzas - versión clara y reordenada
 La primera compra de UF 900 ocurre en t=9, cuando deben instalarse tres más. Después se
 compra en t=18,27,…
 Con arriendo: en t=0 se entregan 4 y quedan 2. En t=3 hay que instalar 3, por lo que se compran 9
 y quedan 2+9-3=8. En t=5 vuelven los 4 arrendados: quedan 12. Luego de instalar 3 en t=6,9,12,15,
 los saldos son 9,6,3,0. La siguiente compra ocurre en t=18, y desde allí el calendario coincide con el
 caso sin arriendo.
 El único desembolso diferencial es adelantar la compra de t=9 a t=3:
 VP_costo=900/(1,10)^3-900/(1,10)^9=294,49546 UF.
 Si el canon constante C se paga al final de los años 1 a 5:
 Cfrac1-(1,10)^-50,10=294,49546; C=77,68716 UF/año.
 El cobro de UF 77,69 por año, cinco veces, deja VAN incremental cero. El valor se expresa en UF y
 se descuenta a la tasa real de 10%. No se cobra el costo original de los cuatro paneles como si se
 perdieran; tampoco se permite pedir menos de nueve unidades ni se anticipa una compra mientras
 hay inventario suficiente.
 agosto 2016 - pregunta 3 - Liquidez y capital de trabajo
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 207-212 | convocatoria
 2
 Volver al enunciado original
 RESOLUCIÓN / RESPUESTA MODELO PROPUESTA PARA ESTUDIO (no oficial; hipótesis
 de valoración explícitas)
 Datos contrastados con pp.207-212. Ventas 1.000.000 → 1.100.000; rotación CxC 8 → 5;
 inventario rota 4 en ambas políticas; pago a proveedores a 36 días; costo de compra 90% de
 ventas; margen operacional 5%; caja al cierre 10% de ventas; activos totales constantes en
 1.000.000; cero impuesto e inflación. Año 360 días. Se interpreta 15,5% como tasa efectiva anual
 con equivalencia diaria: k = (1,155)^(1/360)-1. Si se interpretara como tasa nominal anual
 convertible diariamente, se usaría k = 0,155/360: no mezclar ambas convenciones.
 1. Rentabilidad operacional: sí aumenta el ROA, no el margen. Resultado operacional 50.000 →
 55.000. Con activos totales fijados por el caso, ROA = 5% → 5,5%. Margen operacional permanece
 en 5%. Aumentar una razón contable no demuestra creación de riqueza: no incorpora por sí sola
 cuándo se reciben los cobros.
 2. Liquidez: sí aumentan los dos indicadores contables solicitados. Se reconstruyen los saldos
 con compras = costo de ventas en régimen estable:
 Cuenta Actual Propuesta Diferencia
 Caja 100.000 110.000 10.000
 CxC = ventas/rotación 125.000 220.000 95.000
 Inventario = costo ventas/4 225.000 247.500 22.500
 CxP = compras×36/360 90.000 99.000 9.000
Examen de Grado UC | materia, preguntas y respuestas 237

[pág. 238]
Finanzas - versión clara y reordenada
 Cuenta Actual Propuesta Diferencia
 CTNO = caja + CxC + 360.000 478.500 118.500
 inventario - CxP
 Razón corriente actual = 450.000/90.000 = 5,00; nueva = 577.500/99.000 = 5,83. Prueba ácida
 actual = 225.000/90.000 = 2,50; nueva = 330.000/99.000 = 3,33. Sin embargo, DSO pasa de 45 a
 72 días; DIO = 90; DPO = 36. Ciclo de caja pasa de 99 a 126 días. Mejoran las fotografías del
 balance y se prolonga el tiempo que se financia una venta. Ambas afirmaciones pueden ser ciertas.
 3. Riqueza: valorar el ciclo diario; no presentar una perpetuidad como resultado único de
 2017. El caso pide el efecto durante 2017 y entrega una tabla diaria. Normaliza una venta de 100:
 costo de adquisición 90 y GAV 5, puesto que todos los costos son variables y el margen es 5%.
 Tomando la fecha de venta como referencia, el proveedor se paga 90-36 = 54 días antes de
 vender. Bajo la hipótesis de GAV pagado al vender, el valor de una unidad monetaria de venta es:
 v(D) = 1/(1+k)^D - 0,90(1+k)^54 - 0,05.
 Política actual: v(45) ≈ 0,0124834. Política nueva: v(72) ≈ 0,00192595. Al expresar todos los ciclos
 en una fecha de venta representativa, las contribuciones correspondientes a ventas anuales son
 1.000.000×v(45) ≈ 12.483,40 y 1.100.000×v(72) ≈ 2.118,55: diferencia -10.364,85, antes de ajustes
 por caja requerida, transición y otros activos. Los 27 días adicionales retrasan los cobros de todas
 las ventas de la política, no solo de las 100.000 de ventas adicionales.
 Para llevar los 360 días de ventas uniformes a t=0, aplica a cada cohorte el factor correspondiente.
 Si se inicia una secuencia idéntica de ciclos en días 0,...,359, el valor es ventas
 diarias×v(D)×Σ(1+k)^(-t); la diferencia anterior se multiplica por Σ(1+k)^(-t)/360. Si se toma la
 primera compra como t=0, agrega a ambas políticas el descuento común de los 90 días hasta
 vender. Estos factores positivos preservan el signo negativo en la comparación de los ciclos, sin
 inventar un horizonte perpetuo.
 Ajustes indispensables. Debe explicitarse cuándo se constituye y libera la caja adicional de
 10.000, qué ocurre con inventarios y CxC al terminar el horizonte y cómo se mantiene constante el
 activo total. Los activos corrientes aumentan 127.500; como solo hay terrenos además de ellos, el
 supuesto contable de activos totales constantes implica que la cuenta terrenos disminuye en
 127.500. Si se liberan terrenos mediante una venta, modela su ingreso y el costo de oportunidad o
 flujos operacionales perdidos. El enunciado no describe esa transacción ni sus fechas. Por eso los
 saldos de CTNO identifican necesidades y los ciclos identifican el costo del plazo; no autorizan a
 sumar una inversión inicial de 118.500 a ciclos que ya contabilizan inventarios, cobros y
 proveedores, pues sería doble conteo.
 Comprobación alternativa, condicionada. Solo si se supone que el aumento de beneficio de
 5.000 se repite perpetuamente, que se compromete hoy CTNO adicional 118.500 y que no hay
 recuperación ni flujos por otros activos, VAN ≈ 5.000/0,155-118.500 = -86.241,94. Esa cifra
 corresponde a una perpetuidad suplementaria; no es el resultado único exigido por el horizonte
 2017. El rendimiento 5.000/118.500 = 4,22% y el cargo anual 0,155×118.500 = 18.367,50 sirven
 como diagnóstico de esa hipótesis.
 Respuesta al gerente. Tiene razón sobre ROA y las dos razones contables. No basta para
 justificar un aumento de riqueza. Bajo el modelo de ciclos diarios descrito, prolongar el crédito
 reduce el valor operativo pese a vender 10% más. No aprobaría la propuesta invocando solo
Examen de Grado UC | materia, preguntas y respuestas 238

[pág. 239]
Finanzas - versión clara y reordenada
 ventas, margen y razón corriente; exigiría que su evaluación incluya la transición, caja y
 reasignación de terrenos. La respuesta distinguida separa lo que se deduce exactamente del
 balance de las hipótesis adicionales de valoración.
 agosto 2021 - pregunta 3 - Liquidez, ciclo y GLO
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 345-346 | convocatoria
 2
 Volver al enunciado original
 Los directores hacen tres afirmaciones independientes. Montos monetarios en las unidades del
 balance; año comercial de 360 días. Director 1: razón corriente no basta; el ciclo de 40 días omite
 inventario. La razón circulante sí es 320.000/160.000=2,0, pero incluye 240.000 de existencias y
 25.000 de arriendo pagado por adelantado, que no son efectivo disponible para pagar obligaciones.
 Razón rápida=(caja 5.000+Cx C 50.000)/160.000=0,344; razón de caja=5.000/160.000=0,031. El
 12/1/21 se deben pagar 21.000 de IVA, más obligaciones que vencen a corto plazo; la caja indicada
 de 5.000 no cubre por sí sola el IVA próximo. Cobros futuros y líneas de crédito podrían cubrirlo,
 pero no se informan. DSO=50.000/300.000×360=60 días. Rotación de inventario dada 0,8 implica
 DIO=360/0,8=450 días. Rotación de Cx P 18 implica DPO=360/18=20 días. El ciclo de conversión
 de efectivo completo es DIO+DSO-DPO=450+60-20=490 días, no 40. El cálculo 40 corresponde
 solo a cobrar menos pagar e ignora el tiempo que caja queda inmovilizada en existencias. Por estos
 datos no se puede concluir que no habrá problemas de liquidez; el inventario lento y la falta de
 efectivo inmediato son señales relevantes. La conclusión debe considerar estacionalidad, cobros y
 calendario real de pagos. Directora 2: en desacuerdo con “bajo riesgo operacional”; además
 confunde riesgo operativo y financiero. El negocio enfrenta variación de tipo de cambio y
 cantidad/calidad de cosecha; ciertos costos de cosecha, flete y contratación se mueven con
 volumen, y costos fijos generan apalancamiento operacional. El estado de resultados muestra
 ventas 300.000 y EBIT operacional 4.000 (margen 1,33%), resultado estrecho que hace sensible la
 utilidad operacional a cambios de actividad. Los costos/gastos operacionales suman 296.000; 80%
 fijos=236.800 y 20% variables=59.200. Con el supuesto lineal y manteniendo estructura, margen de
 contribución=300.000-59.200=240.800 y grado de apalancamiento operacional aproximado
 DOL=240.800/4.000=60,2. Una variación de 1% en ventas implicaría, cerca del punto observado,
 alrededor de 60,2% en EBIT antes de cambios de precios/productividad; esta gran sensibilidad no
 significa que el pronóstico sea exacto, pero contradice la seguridad de “bajo riesgo”. El cociente
 total pasivos/patrimonio sí es (160.000+40.000)/200.000=1,0, si deuda total incluye todos los
 pasivos. Pero es apalancamiento financiero, no evidencia de bajo riesgo operacional. La deuda
 financiera explícita es 10.000 de corto plazo+40.000 de largo plazo=50.000, razón deuda
 financiera/patrimonio=0,25. Además, la utilidad por venta de activo fijo de 40.000 hace que el
 resultado antes de impuestos no represente solo operación; no debe usarse para inferir estabilidad
 operativa. Directora 3: el cálculo de fuentes de largo plazo es correcto, pero no prueba holgura ni
 ausencia de riesgo. Activos no corrientes=40.000+(70.000-30.000)=80.000; financiamiento largo
 plazo=40.000+patrimonio 200.000=240.000; el excedente=160.000 coincide con capital de trabajo
 neto=activos corrientes 320.000-pasivos corrientes 160.000=160.000. En el balance puntual,
 recursos de largo plazo cubren los activos no corrientes y financian el capital de trabajo neto. Sin
 embargo, el principio de calce no exige que fuentes largas sean tres veces activos no corrientes ni
 demuestra “holgura” por sí solo: hay que estimar qué parte del capital de trabajo es permanente,
 estacional o de lenta rotación, y hacer coincidir vencimientos y flujos. Con DIO de 450 días, IVA
Examen de Grado UC | materia, preguntas y respuestas 239

[pág. 240]
Finanzas - versión clara y reordenada
 próximo a pago y caja reducida, puede existir estrés de liquidez aun con capital de trabajo neto
 positivo. Se requieren proyección de caja y prueba de estrés de cosecha, tipo de cambio y
 cobranza. Síntesis. La razón corriente es correcta aritméticamente, pero no sostiene el juicio del
 director 1; los factores del caso apuntan a riesgo operacional alto y el endeudamiento no lo mide; la
 estructura de largo plazo cubre formalmente activos no corrientes más NWC en la fecha, pero la
 mezcla y los vencimientos de capital de trabajo impiden proclamar calce holgado.
 agosto 2022 - pregunta 3 - Patrimonio y negociación bancaria
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 368-369 | convocatoria
 2
 Volver al enunciado original
 Todos los valores son en pesos y ocurren en un período. Tasa de descuento cero, neutralidad al
 riesgo, responsabilidad limitada del accionista y prioridad de la deuda al cierre. 1. Patrimonio sin
 proyecto. Al 31/12/23, activos: negocio paga 80 en año bueno (prob. 0,5) o 0 en año malo; la caja
 entrega 10 en ambos estados. Deuda de 30 vence al final. El dividendo al accionista es lo que sobra
 después de deuda, nunca negativo: Dividendo bueno = max(80+10-30,0)=60; dividendo
 malo=max(0+10-30,0)=0. Valor del patrimonio al 1/1/23 =0,5×60+0,5×0=$30. No se resta deuda de
 la caja sin respetar prioridad y estados; responsabilidad limitada hace que en el escenario malo el
 accionista no cubra el déficit. 2. Decisión de invertir. La caja 10 se usa en el proyecto. En buen año,
 negocio existente paga 80 y proyecto 15, total 95; tras deuda 30 quedan 65 para accionistas. En
 mal año, flujos totales 0 y la deuda absorbe lo que hubiera; accionista recibe 0. Valor del patrimonio
 con proyecto=0,5×65=$32,5. Para accionistas, se acepta porque aumenta valor en $2,5. Esto no
 significa que el activo cree valor: flujo esperado del proyecto es 0,5×15+0,5×0=7,5; inversión 10;
 VAN de activos a tasa cero=-$2,5. El proyecto paga solo en buen estado, cuando la firma ya puede
 pagar deuda, y no agrega nada en el estado malo. El accionista captura upside y parte del costo de
 pérdida lo soporta el acreedor (deuda en dificultades/debt overhang). La decisión que maximiza el
 valor conjunto de financiadores sería rechazarlo, pero la decisión individual de los accionistas bajo
 deuda existente es invertirlo. 3. Descuento máximo que el banco ofrecería por prepago. Si la
 empresa entrega 10 hoy, pierde la posibilidad del proyecto. La deuda nominal restante es 20; con
 descuento d, al cierre debe 20-d. En año bueno, la operación produce 80 y el banco cobra 20-d
 (para d entre 0 y 20); en malo no hay flujo y cobra 0. Valor esperado para el banco con oferta
 =10+0,5(20-d)=20-0,5 d. Sin oferta, los accionistas emprenden el proyecto y el banco recupera 30
 en buen año y 0 en malo: valor esperado=15. El máximo descuento que deja indiferente al banco
 cumple: 20-0,5 d=15; de donde d=$10. Así, el banco no debería ofrecer más de $10 como rebaja al
 saldo de $20 si compara con su alternativa de no hacer oferta y que se realice el proyecto. La
 empresa, por su lado, compara el patrimonio bajo prepago: bueno 80-(20-d)=60+d; malo 0. Valor
 esperado accionista=30+0,5 d. Para igualar $32,5 del proyecto necesita d≥$5. Existe zona de
 acuerdo: descuento entre $5 y $10 (límite inferior hace indiferente al accionista; superior hace
 indiferente al banco). A d=10, accionistas obtienen 35 y el banco 15; el banco queda indiferente
 frente a no ofrecer. Si el propósito fuese que ambas partes estrictamente mejoren, el descuento
 debe ser mayor que 5 y menor que 10. Qué hace sólida la respuesta: distingue valor de activos y
 valor del equity bajo responsabilidad limitada, muestra el conflicto accionista-acreedor con flujos por
 estado y calcula por separado el mínimo que acepta la empresa y el máximo que conviene al
 banco.
Examen de Grado UC | materia, preguntas y respuestas 240

[pág. 241]
Finanzas - versión clara y reordenada
 agosto 2013 - pregunta 2 - Perpetuidad, VAN y patrimonio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 129-130 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 El departamento descuenta $12.750 (flujo antes de impuesto menos impuesto calculado sobre caja)
 a costo de equity y obtiene valor de firma. No corresponde: el flujo de $15.000 no es base tributaria.
 La utilidad operacional contable $10.000 ya incluye depreciación de $5.000; impuesto
 operativo=$1.500. FCFF after-tax=$15.000-$1.500-reinversión necesaria $5.500=$8.000. La
 depreciación no se agrega aparte porque el flujo operativo de $15.000 ya es caja antes de
 impuestos; si se construyera desde NOPAT, sería 10.000(0,85)+5.000-5.500=8.000. A WACC 10%,
 valor de activos=$8.000/0,10=$80.000. Incluye capital de trabajo $25.000 que permanece invertido;
 no se recupera al infinito mientras la empresa siga operando. El VAN del proyecto frente a inversión
 inicial $75.000 es $5.000.
 Deuda perpetua de $25.000 vale $25.000 a 8%; equity vale 80.000-25.000=$55.000. Con 10
 acciones, precio máximo coherente con valor de mercado=$5.500 por acción, no $11.131.
 Verificación desde equity: intereses=$2.000; utilidad afecta a impuesto=10.000-2.000=8.000;
 impuesto=$1.200; utilidad neta=$6.800. FCFE distribuible=6.800+depreciación 5.000-reinversión
 5.500=$6.300. Al costo de equity 11,4545%, valor equity=6.300/0,114545≈$55.000. El flujo de
 $12.750 del análisis previo no es flujo atribuible al equity ni al activo: omite reinversión y trata
 impuesto como 15% del OCF.
 Si inversionistas compran las 10 acciones por $5.000 cada una, aportan $50.000 y reciben
 dividendos perpetuos de $6.300 anuales en total. TIR anual=6.300/50.000=12,6% (un decimal). Por
 acción, dividendos=$630 anuales y precio=$5.000; misma TIR. Asume perpetuidad constante y
 distribución total del excedente.
 Qué haría esta respuesta distinguida: separa flujo de activos y de equity, ubica impuestos en la
 base contable correcta, descuenta cada flujo con su tasa y reconcilia valor total, deuda, acciones y
 TIR.
 agosto 2011 - pregunta 3 - Proyecto, deuda y nuevo socio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 77-78 | convocatoria 2
 Volver al enunciado original
 RESOLUCIÓN / RESPUESTA MODELO PROPUESTA PARA ESTUDIO (no oficial)
 La licencia antes del descubrimiento se toma sin valor incremental adicional al informado. Caja
 1.500 + terreno 4.500 = activos previos 6.000; menos deuda 3.000 = patrimonio previo 3.000. El
 nuevo yacimiento exige inversión 3.000 y genera 600 anuales perpetuos desde t=1. A 10%, VP del
 proyecto = 6.000 y VAN = 3.000.
 1. Mercado perfecto: no conviene entregar 25%. Un aporte nuevo de 1.500 completa la
 inversión. Patrimonio posterior = patrimonio anterior 3.000 + aporte 1.500 + VAN 3.000 = 7.500.
 Comprobación: terreno 4.500 + proyecto 6.000 - deuda 3.000 = 7.500, tras usar la caja inicial y el
 aporte. La participación justa del socio es 1.500/7.500 = 20%. Al 25% recibe valor 1.875 por aportar
 1.500, transfiriendo 375 desde los antiguos. En mercado perfecto los antiguos pueden financiarse a
Examen de Grado UC | materia, preguntas y respuestas 241

[pág. 242]
Finanzas - versión clara y reordenada
 valor justo, por lo que no necesitan esa concesión.
 2. Mercado imperfecto: intervalo de negociación 42,86%-64,29%. La alternativa bancaria tiene
 WACC 16%: VP = 600/0,16 = 3.750; VAN = 750. Los antiguos retienen patrimonio previo 3.000 +
 VAN 750 = 3.750. Comprobación: terreno 4.500 + proyecto 3.750 - deuda total 4.500 = 3.750.
 Con la alternativa del socio, este aporta 4.500, de los que 3.000 cancelan deuda antigua y 1.500
 completan la inversión junto a la caja previa. Queda deuda cero y patrimonio post-money = terreno
 4.500 + proyecto 6.000 = 10.500; también 3.000 de equity previo + aporte 4.500 + VAN 3.000 =
 10.500.
 El socio requiere p×10.500 ≥ 4.500, por lo que p mínimo = 42,86% si su alternativa es invertir a
 valor justo y no exige prima por control. Los antiguos requieren (1-p)10.500 ≥ 3.750, por lo que p
 máximo = 64,29%. A precio justo, p = 42,86% deja 6.000 a los antiguos; a 64,29% estos conservan
 3.750 y el socio obtiene valor 6.750, compartiendo los 2.250 de ventaja frente al banco. El acuerdo
 es posible porque la alternativa con socio crea más valor bajo las tasas explícitas del caso.
 Corrección comprobada contra pp.77-78. La versión anterior confundía el porcentaje
 justo/mínimo del socio con el máximo negociable de los antiguos y daba 42,86% para ambos. En la
 segunda parte hay dos alternativas imperfectas y la reserva de los antiguos es el patrimonio de
 3.750 obtenido con el banco, no el valor de 6.000 que retendrían si el socio comprara a precio justo.
 enero 2021 - pregunta 6 - Proyecto, externalidades y precio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 338-339 | convocatoria
 1
 Volver al enunciado original
 Tasa anual 10%; flujos al cierre. El costo de construir el túnel se trata como desembolso inicial para
 evaluar el proyecto desde su origen. La demanda pública es q=6.000-2 p; camiones propios no
 pagan peaje. 1 a. VAN con peaje p=$250. Vehículos públicos: q=6.000-2(250)=5.500. Ingreso anual
 por peajes=250×5.500=$1.375.000. Se suma ahorro de transporte propio 20.000, se resta
 mantenimiento 65.000. Resultado operacional
 imponible=1.375.000+20.000-65.000-100.000=$1.230.000. Impuesto=0,40×1.230.000=492.000.
 Flujo de caja anual:
 FCF=(ingresos+ahorro-mantenimiento-depreciación)(1-T)+depreciación-reinversión
 =1.230.000×0,60+100.000-88.000=$750.000. Es perpetuidad con inversión de mantenimiento anual
 incluida: VAN=-10.000.000+750.000/0,10=-$2.500.000. Con p 250, el proyecto destruye valor bajo
 los supuestos, pese a ingresos por peaje. El ahorro propio es beneficio incremental; la depreciación
 reduce impuesto y la reinversión es desembolso de caja, no gasto deducible según el
 planteamiento. 1 b. TIR. Para flujo inicial-10.000.000 y flujo perpetuo positivo 750.000 anual desde
 el primer año, TIR r satisface 10.000.000=750.000/r; r=7,50%, inferior a tasa requerida 10%. El
 proyecto no se acepta a esa tarifa bajo este modelo. 2. Subsidio máximo por vehículo. Si el
 Gobierno construye su alternativa, costo inicial 16.500.000 y egreso recurrente anual de
 mantenimiento 80.000 más reinversión 120.000=200.000. Como no paga impuestos, el valor
 presente del costo es: VP construir=16.500.000+200.000/0,10=$18.500.000. Con convenio, el
 usuario enfrenta peaje cero; la demanda pública es q=6.000 vehículos al año (p consumidor=0), y el
 Gobierno paga s por vehículo al dueño actual. El costo anual es 6.000 s. Para ser indiferente: 6.000
 s/0,10=18.500.000; s=18.500.000×0,10/6.000=$308,33 por vehículo. Es el máximo que pagaría por
 unidad si no hay otros costos/beneficios, la demanda no se desplaza ni crece con el nuevo túnel y
Examen de Grado UC | materia, preguntas y respuestas 242

[pág. 243]
Finanzas - versión clara y reordenada
 ambas alternativas prestan el mismo servicio. No se usa p=250 en demanda durante el subsidio
 porque el usuario ya no paga; el precio al consumidor es cero. 3. Precio que maximiza ingresos
 anuales. R(p)=p(6.000-2 p)=6.000 p-2 p². Derivada 6.000-4 p=0, por lo que p=$1.500 por vehículo;
 q=6.000-3.000=3.000 vehículos, ingreso máximo anual=$4.500.000. La segunda derivada es-4<0,
 así que es máximo. Este precio maximiza ingresos brutos, no necesariamente utilidad ni VAN
 después de impuestos y costos; no se debe confundir objetivo comercial con precio óptimo
 económico. Qué hace sólida la respuesta: construye flujo libre con impuestos, depreciación y
 reinversión sin mezclarlos, calcula la TIR de perpetuidad, compara el costo público total en valor
 presente y resuelve el óptimo de ingreso por demanda lineal.
 agosto 2020 - pregunta 2 - ROA, WACC y planificación financiera
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 317-318 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 1. Rentabilidad y creación de valor. El gerente divide EBIT por patrimonio y llama al resultado
 rentabilidad de activos; mezcla bases. Los activos son 400.000 y el EBIT esperado 16.000, por lo
 que ROA antes de impuestos es 4%. Para comparar con WACC después de impuestos 4,5%, el
 NOPAT es 16.000(0,8)=12.800,ROIC es 3,2% y la utilidad económica o EVA es
 12.800-0,045(400.000)=-5.200. No crea valor operativo esperado en 2020 con la estructura original.
 2 a. Fondos liberados al 31/12/2019. Ventas diarias 630.000/360=1.750; costo de ventas diario
 336.000/360=933,3333. La reducción de caja en 5 días libera 8.750; la reducción de cobros en 20
 días libera 35.000; la reducción de inventario en 30 días libera 28.000. La menor necesidad de
 capital de trabajo libera 71.750. La venta del terreno aporta 8.250 sin impuesto a ganancia porque
 coincide con costo tributario. El monto líquido que el paquete deja disponible para el dividendo
 extraordinario es 80.000. Después del pago quedan caja 17.500, cuentas por cobrar 52.500,
 existencias 42.000 e instalaciones/terrenos 208.000; activos totales 320.000.
 Conviene distinguir liberación de fondos y ganancia de transacción. Las mejoras de capital de
 trabajo permiten operar con igual flujo y menos capital inmovilizado según el supuesto expreso. La
 venta a precio justo convierte un terreno en efectivo; por sí misma no genera una ganancia frente al
 valor de mercado que ya tenía el activo. Por eso reporto 80.000 como capital liberado/dividendo
 del paquete, y 71.750 como liberación atribuible a la mejora de capital de trabajo. Una
 medición del incremento de riqueza total exige un contrafactual del valor de los activos liberados; no
 se suma el dividendo otra vez a la reducción de capital.
 2 b. Creación de valor operativo esperada en 2020. El EBIT no cambia. Con activos operativos
 restantes 320.000 y el WACC dado, ROIC=12.800/320.000=4% y
 EVA=12.800-0,045(320.000)=-1.600. Todavía destruye 1.600 de valor económico en 2020, aunque
 mejora en -1.600-(-5.200)=3.600 frente al escenario original. De la mejora anual,
 71.750(4,5%)=3.228,75 proviene del capital de trabajo y 8.250(4,5%)=371,25 del capital que deja
 de estar inmovilizado en el terreno. No se puede afirmar simultáneamente que la salida del terreno
 está incluida en la mejora total de EVA y que no afecta esa EVA.
Examen de Grado UC | materia, preguntas y respuestas 243

[pág. 244]
Finanzas - versión clara y reordenada
 agosto 2019 - pregunta 3 - Ratios y ciclo de caja
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 294-295 | convocatoria
 2
 Volver al enunciado original
 Montos en US$. Año 360 días; para ratios flujo/stock uso saldo inicial como pide el caso. No infiero
 valor bursátil ni precio de acción porque no se entrega número de acciones ni cotización. a)
 Principal debilidad financiera: liquidez y financiamiento de capital de trabajo se deterioran pese al
 fuerte crecimiento.
 Indicador 2018 2019 Lectura
 Razón corriente=AC/PC 6.375/3.250=1,96 7.500/6.250=1,20 Menor colchón de activos
 corrientes
 Razón rápida=(caja+Cx 4.875/3.250=1,50 5.500/6.250=0,88 Activos líquidos rápidos ya
 C)/PC no
 cubren pasivo corriente |
 Razón de caja=caja/PC 2.675/3.250=0,82 1.500/6.250=0,24 Efectivo cae aunque
 ventas crecen
 Capital de trabajo 3.125 1.250 Reducción de 1.875
 neto=AC-PC
 Período de 36,00 días 52,94 días Cobranza se demora más
 cobro=360/rotación Cx C
 Días 90 días 90 días Sin mejora en permanencia
 inventario=360/rotación
 Días de pago=360/rotación 40 días 40 días No compensa aumento del
 Cx P cobro
 Ciclo de 86,00 días 102,94 días Más fondos inmovilizados
 caja=DSO+DIO-DPO en operación
 Las ventas crecieron 50%, de 10.000 a 15.000; las cuentas por cobrar aumentaron de 2.200 a
 4.000 (+81,8%) y existencias de 1.500 a 2.000 (+33,3%), mientras caja bajó de 2.675 a 1.500
 (-43,9%). La empresa creció más rápido en cartera y mantiene ciclo de conversión de efectivo más
 largo, y los pasivos corrientes subieron de 3.250 a 6.250. Aunque el inventario no aumenta en días
 según rotación reportada, el volumen absoluto sube y exige financiar el crecimiento. La razón rápida
 bajo 1 y vencimientos de bancos/fisco sugieren presión de liquidez. No se afirma insolvencia: hace
 falta calendario de caja y vencimientos. b) Principal atractivo para inversionistas: rentabilidad
 creciente. Con saldos iniciales indicados, ROE=utilidad neta/patrimonio inicial:
 2018=2.520/10.000=25,20%; 2019=4.645/15.750=29,49%. Retorno sobre activos operacional
 before tax=EBIT/activos iniciales: 2018=3.000/14.000=21,43%; 2019=5.500/22.036=24,96%.
 Alternativamente, ROIC after-tax: EBIT(1-0,10)/activos iniciales =2.700/14.000=19,29% en 2018 y
 4.950/22.036=22,46% en 2019. Las ventas, EBIT y utilidad neta crecen más rápido que la base
 inicial de capital, por lo que estas métricas muestran mayor rentabilidad contable. No prueban por sí
 solas que las acciones estén subvaloradas o que el retorno futuro continúe; falta precio de mercado,
 riesgo y flujo libre. c) Recomendación financiera concreta: programa de capital de trabajo y caja con
 metas de cobro y financiamiento. Priorizar cuentas por cobrar: segmentar clientes por riesgo y
Examen de Grado UC | materia, preguntas y respuestas 244

[pág. 245]
Finanzas - versión clara y reordenada
 conducta, verificar límites antes de vender, facturar sin demora, emitir recordatorios automáticos,
 escalar saldos vencidos y ofrecer pronto pago solo si el descuento cuesta menos que financiar ese
 cobro. Mantener acceso comercial para clientes valiosos; no endurecer términos uniformemente.
 Integrarlo con pronóstico de demanda y compras para no acumular inventario, revisar rotación por
 SKU y renegociar con proveedores plazos que se acerquen al ciclo operativo sin perjudicar
 suministro. Preparar flujo de caja semanal, reservas para impuestos/deuda y líneas comprometidas
 para crecimiento. Metas: recuperar días de cobro hacia el plazo contractual que la firma decida,
 sostener disponibilidad y evitar financiar permanentemente cartera con deuda bancaria de corto
 plazo. Monitorear ciclo de efectivo, mora, quiebres de stock, margen después de descuentos y
 liquidez mínima. Conclusión. La empresa es más rentable y crece, pero financia ese crecimiento
 con deterioro de caja y liquidez. Una mejora de cobranza coordinada con inventario y pagos reduce
 la vulnerabilidad sin sacrificar ventas rentables. Qué hace sólida la respuesta: calcula tendencias
 con denominadores consistentes, distingue rentabilidad atractiva de precio justo de acciones y
 convierte el diagnóstico de liquidez en una intervención operativa con salvaguardas comerciales.
 agosto 2023 - pregunta 3 - Reemplazo de máquina y VAN
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 394-395 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 1. Gerente de Proyectos. El costo de la nueva máquina se infiere de la perpetuidad de intereses:
 deuda de (60/5%=1.200). Se vende la máquina antigua por su valor libro 200, sin ganancia/pérdida
 imponible; inversión incremental neta (I_0=1.200-200=1.000). Depreciación y reinversión son
 iguales entre alternativas, así que se cancelan en el flujo diferencial. Ahorro operativo anual150;
 después de impuestos (FCFF=150(1-0,30)=105) perpetuo. Con WACC objetivo12%:
 (VAN=-1.000+105/0,12=-125). El reemplazo destruye valor bajo esos supuestos.
 La evaluación de Proyectos es inconsistente: no puede descontar FCFE que ya incluye intereses y
 escudo de deuda a WACC (tasa para FCFF); además no incorpora correctamente inversión neta ni
 venta de máquina antigua, y omite impuesto a los ahorros operativos. Financiamiento no hace
 desaparecer el costo del activo. Si el WACC de12% corresponde al riesgo y apalancamiento
 objetivo, valoro FCFF after-tax con esa tasa sin restar intereses en el flujo.
 2. Gerente de Finanzas. (115/200=57,5% no es la TIR del proyecto operativo: mezcla flujo al
 equity, escudo financiero y una base de inversión que no representa el costo incremental del activo;
 tampoco se compara esa TIR de equity con el WACC. Con inversión neta1.000 y flujo perpetuo
 FCFF105, la TIR del proyecto es (105/1.000=10,5%, inferior al WACC12%; por tanto, se rechaza.
 La venta del activo antiguo se incluye como flujo inicial a favor del reemplazo, no como una
 inversión de 200 sin explicar qué financia. Un análisis FCFE puede hacerse solo si se proyectan
 consistentemente aportes, deuda emitida, servicio de deuda, impuestos, política de apalancamiento
 y costo de equity; con la información resumida, FCFF/WACC es el camino consistente.
 3. Gerente General y pérdidas tributarias. Un activo tributario por pérdidas acumuladas sí puede
 tener valor: el valor presente dado de136,7 representa impuestos futuros que se evitarían si las
 pérdidas pueden utilizarse, la empresa genera renta imponible y la norma permite compensarlas.
 Pero ese valor pertenece a la empresa aun sin comprar la máquina; no es automáticamente VAN
Examen de Grado UC | materia, preguntas y respuestas 245

[pág. 246]
Finanzas - versión clara y reordenada
 incremental del reemplazo. Debe compararse la trayectoria de impuestos con máquina y sin
 máquina, reconociendo que los ahorros operativos elevan la renta imponible y pueden acelerar el
 uso de las pérdidas, alterando el momento de pago de impuestos. Si, por supuesto adicional,
 los136,7 fueran íntegramente un beneficio incremental causado por el proyecto y no disponible en
 el contrafactual, el VAN combinado sería (-125+136,7=+11,7) y convendría; el caso no basta para
 afirmar esa incrementalidad. Si la pérdida se aprovecharía de todos modos contra utilidades
 existentes, sumar su valor íntegro al proyecto cuenta dos veces un activo fiscal previo. La
 conclusión requiere flujos tributarios incrementales y consistentes; el proyecto antes de ese efecto
 tiene VAN negativo, y su conveniencia final no puede inferirse de una ventaja tributaria existente sin
 construir el contrafactual.
 Qué hace sólida la respuesta: identifica inversión neta, separa FCFF de FCFE, corrige la
 comparación TIR/WACC y valora la pérdida tributaria solo en la medida en que cambie flujos
 incrementales frente al escenario sin proyecto.
 enero 2020 - pregunta 3 - Reemplazo y costo anual equivalente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 307-308 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Trabajamos en MM$, con 8% anual y 25% de impuesto. Los ingresos de los camiones son iguales:
 se comparan costos presentes de prestar el servicio para siempre. La compra histórica del petrolero
 es hundida; sí importan sus tres años restantes y su base tributaria.
 Costos anuales. El petrolero deprecia 64/8=8 y su costo operacional neto de impuestos es
 20(0,75)-8(0,25)=13 al año. El eléctrico deprecia (100-10)/10=9; su costo anual after-tax es
 15(0,75)-9(0,25)=9. Al fin de cada ciclo eléctrico se vende a 14, con libro 10; su venta neta es
 14-(14-10)0,25=13.
 Denotemos a_n=[1-(1,08)^-n]/0,08 y v_n=(1,08)^-n. El costo de un ciclo eléctrico es C_E=100+9
 a_10-13 v_10=154,36922. Su serie indefinida cuesta PV_E=C_E/(1-v_10)=287,56957. Para un
 petrolero nuevo, C_P=64+13 a_8=138,70631 y PV_P=C_P/(1-v_8)=301,71181.
 Opción 1: eléctrico hoy. El petrolero actual tiene valor libro 64-5(8)=24 y precio de venta 0. Su
 enajenación hoy genera pérdida tributaria 24 y ahorro fiscal 24(25%)=6, absorbible por el supuesto
 del caso. Con venta/desecho reconocido tributariamente hoy, el costo presente es
 287,56957-6=281,56957. Si ese reconocimiento ocurre al cierre del primer año, el ahorro se
 descuenta; sería 287,56957-6/1,08=282,01401. La conclusión no cambia. No se debe afirmar que
 venta 0 significa necesariamente impuesto 0 mientras el valor libro aún es positivo.
 Opción 2: usar tres años y luego eléctricos. Se pagan 13 por año mientras se agota el petrolero
 y en t=3 comienza la serie eléctrica: PV_2=13 a_3+v_3 PV_E=261,78426.
 Opción 3: usar tres años y luego petroleros para siempre. PV_3=13 a_3+v_3 PV_P=273,01082.
 La opción 2 tiene el menor costo presente: MM$261,78, frente a 281,57 en la opción 1 y 273,01 en
 la opción 3. Conviene agotar el camión actual y cambiar a eléctricos en tres años. Los costos
 anuales de los tres años iniciales son futuros, no hundidos; las inversiones y ventas se repiten al
 cerrar cada ciclo. El ahorro fiscal por retiro anticipado debe fecharse y justificarse, pero no altera el
Examen de Grado UC | materia, preguntas y respuestas 246

[pág. 247]
Finanzas - versión clara y reordenada
 orden de las alternativas bajo ninguna de las dos fechas indicadas.
 enero 2013 - pregunta 3 - Riesgo operacional y deuda
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 119-120 | convocatoria
 1
 Volver al enunciado original
 1. Por qué TRANSEJEC podría sostener mayor deuda. La razón D/E por sí sola no determina si una
 estructura es prudente; importa la capacidad de pagar intereses y principal en estados adversos.
 TRANSEJEC ofrece flujos operacionales relativamente estables incluso en recesión, tiene contratos
 anuales renovables, prestigio y una trayectoria de más de veinte años. Aunque opera en una
 industria con entrada/salida, sus clientes diversificados por sectores y la renovación de flota vía
 arriendo permiten previsibilidad y evitan una inversión fija alta. Flujos menos volátiles, bajos activos
 propios en flota y menor probabilidad de distress permiten asumir más deuda, aprovechar escudos
 tributarios si existen y disciplinar caja, siempre que los contratos y márgenes cubran obligaciones.
 DETECOM presenta riesgo de negocio mayor: solo una de cada cien aplicaciones tiene éxito, el
 éxito es procíclico y los ingresos pueden ser muy discontinuos; una licencia ganadora produce
 grandes resultados, pero además impone compromisos de soporte, actualizaciones, virus y
 reposición durante diez años. Debe respaldar 10% del contrato con garantía, inmovilizando
 capacidad y liquidez. Sus activos principales son equipo, know-how y capacidad de marketing local,
 de difícil uso como colateral; si pierde ingenieros o enfrenta recesión, puede no financiar I+D ni
 garantías. Endeudarse demasiado puede causar distress, recortar proyectos de valor o incumplir
 obligaciones a clientes. Una política más conservadora preserva flexibilidad, solvencia y capacidad
 de absorber años sin licencias exitosas. Con preferencias idénticas de accionistas, la diferencia
 puede explicarse por riesgo del activo, capacidad de deuda y costos esperados de
 insolvencia/agencia, no porque los accionistas de TRANSEJEC sean más tolerantes. La deuda
 óptima equilibra escudo fiscal y disciplina con distress, pérdida de oportunidades, garantías y
 volatilidad de flujo. El caso no informa impuestos ni costo explícito de distress; por tanto, se
 fundamenta dirección de la decisión, no un D/E numérico óptimo. 2. Por qué menor D/E no significa
 menor riesgo para los accionistas de DETECOM. El riesgo patrimonial suma riesgo operacional del
 activo y amplificación por apalancamiento. Una relación simplificada de betas con deuda riesgosa
 es: β_E=β_A+(D/E)(β_A-β_D). DETECOM puede tener β_A mucho mayor por la sensibilidad de
 éxitos tecnológicos a ciclo económico y distribución de resultados; incluso con D/E=0,5, su β_E
 puede exceder el de TRANSEJEC con D/E=1,5 si el β_A de esta última es suficientemente bajo.
 Como ilustración, sin afirmar betas del caso: β_A,DETECOM=2 y β_D≈0 implica β_E≈3;
 β_A,TRANSEJEC=0,5 y β_D≈0 implica β_E≈1,25 aun con D/E 1,5. También hay riesgo
 idiosincrático de éxito/fracaso en DETECOM, concentración en equipo clave, garantías y
 compromisos. El apalancamiento más bajo no elimina esos riesgos. Bajo CAPM, solo el riesgo
 sistemático se remunera con prima de mercado; la volatilidad total sigue siendo relevante para
 distress y accionistas concentrados. Qué hace distinguida la respuesta: separa riesgo del negocio
 de riesgo financiero, integra colateral, liquidez y obligaciones futuras, y explica por qué ratios de
 endeudamiento comparables no equivalen a riesgo patrimonial comparable.
 enero 2024 - pregunta 3 - Riesgo, TIR y múltiplos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 407-408 | convocatoria
 1
Examen de Grado UC | materia, preguntas y respuestas 247

[pág. 248]
Finanzas - versión clara y reordenada
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Comentario 1: en desacuerdo. Igual variabilidad de ventas no asegura igual variabilidad de EBIT.
 Con ventas S=PQ, precio constante, costo variable unitario u y costo fijo F,
 EBIT=(P-u)Q-F=(1-u/P)S-F. Por tanto, σ(EBIT)=|1-u/P|σ(S). Dos empresas con igual σ(S), pero
 distinto margen de contribución, tienen distinto riesgo operacional absoluto. Por ejemplo, si σ(S)=20
 y el costo variable representa 80% de ventas en una empresa y 20% en otra, sus desviaciones de
 EBIT son 4 y 16. Que los activos se mantengan constantes no iguala estas sensibilidades. Un costo
 fijo verdaderamente constante no altera por sí solo la desviación absoluta de EBIT manteniendo
 igual el margen variable; sí modifica EBIT medio, probabilidad de pérdidas y apalancamiento
 operativo relativo.
 Comentario 2: la afirmación necesita precisar qué rentabilidad se pregunta. La TIR es la tasa
 interna i que satisface -I_0+Σ_t=1^nF_t/(1+i)^t=0. Si hay una inversión inicial y entradas posteriores
 convencionales, puede describirse como la tasa interna anual equivalente de esos flujos. Incluso si
 se realizan exactamente, no basta para afirmar que la riqueza inicial se capitaliza a esa tasa
 durante toda la vida del proyecto: los cobros intermedios dejan de estar invertidos en el proyecto y
 su rentabilidad posterior depende de cómo se reinviertan.
 Si cada flujo intermedio se reinvierte a q, la riqueza terminal asociada a esos cobros es VF=Σ_t
 F_t(1+q)^n-t y el rendimiento compuesto de la inversión inicial es (VF/I_0)^1/n-1. Coincide con la
 TIR cuando la reinversión resulta compatible con esa tasa; en general, puede diferir. Tampoco todo
 proyecto tiene una TIR única. Por eso, estaría de acuerdo si el gerente habla de rentabilidad
 interna de los flujos; discreparía si la presenta sin condiciones como el rendimiento compuesto
 de la riqueza de los inversionistas. El VAN positivo expresa creación de valor a la tasa de
 oportunidad, pero no elimina esta distinción. La respuesta no debe basarse en que los flujos
 podrían diferir: la pregunta exige analizarlos bajo la hipótesis de que se realizan exactamente.
 Comentario 3: en desacuerdo con identificar el resultado como patrimonio. Para VSF,
 capitalización =14(21.000)=294.000; valor empresa EV=294.000+32.000=326.000; múltiplo
 326.000/32.600=10. Para VST, capitalización =18(14.000)=252.000; EV=252.000+28.000=280.000;
 múltiplo 280.000/20.000=14. El promedio simple de 12 es correcto. Aplicarlo a VSJ entrega
 EV=12(14.500)=174.000, que corresponde al valor operacional para deuda y patrimonio en
 conjunto. Como la caja es cero y la deuda financiera es 24.000:
 E=174.000-24.000=150.000.
 Con 5.000 acciones, el valor por acción sería 30. El error está en el puente desde EV a patrimonio,
 no en calcular el múltiplo promedio.
 enero 2017 - pregunta 3 - TIR incremental y VAN
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 230-231 | convocatoria
 1
 Volver al enunciado original
 Las cifras están en MM$. El problema exige usar TIR para decidir y seleccionar la altura, y después
 usar CAPM/valor presente para valorar el derecho exclusivo. No se incluyen impuestos ni inflación.
 1) Flujos perpetuos y TIR. La reinversión anual mantiene el edificio “como nuevo” y permite flujos
 perpetuos. Las depreciaciones son contables, no caja, y con impuestos cero no afectan flujo
Examen de Grado UC | materia, preguntas y respuestas 248

[pág. 249]
Finanzas - versión clara y reordenada
 económico. FC anual neto = ingresos de caja operacionales - egresos de caja operacionales -
 reinversión.
 Altura Desembolso inicial FC perpetuo TIR de la perpetuidad (FC/I
 0)
 30 pisos 3.500 1.680-280-210 = 1.190 34,00%
 40 pisos 5.600 2.380-420-280 = 1.680 30,00%
 50 pisos 8.400 2.758-560-350 = 1.848 22,00%
 Los tres superan el costo de oportunidad del activo que se obtiene en la siguiente parte (20%), así
 que cada uno es aceptable frente a no invertir. Como son mutuamente excluyentes y de distinta
 escala, se usa TIR incremental para escoger tamaño: subir de 30 a 40 pisos exige 2.100
 adicionales y agrega 490 anuales; TIR incremental=490/2.100=23,33%, mayor que 20%, por lo que
 conviene ampliar a 40. Pasar de 40 a 50 requiere 2.800 adicionales y agrega 168 anuales; TIR
 incremental=168/2.800=6,00%, menor que 20%, por lo que se rechaza esa expansión. Se elige 40
 pisos. Esta comparación incremental es la forma correcta de usar TIR en alternativas excluyentes;
 no escoger mecánicamente el mayor porcentaje individual. 2) Valor máximo por una acción tras
 obtener el permiso gratuito. CAPM: k = Rf + β(Rm-Rf)=8%+2×6%=20%. Valor del permiso para
 Queulat es el mayor VAN entre alternativas usando el desembolso total informado, que incluye
 terreno: VAN 30=1.190/0,20-3.500=2.450; VAN 40=1.680/0,20-5.600=2.800; VAN
 50=1.848/0,20-8.400=840. Se elige 40 pisos y el derecho incrementa el patrimonio en MM$2.800. El
 balance de mercado previo muestra caja 10.000 y deuda 5.000, patrimonio 5.000. El valor
 económico post noticia del patrimonio es 5.000+2.800=7.800. Con 100 acciones, el máximo por una
 acción es MM$78 (o $78 millones por acción, respetando unidades del caso). Se supone que el
 permiso es transferible y no hay costos ni otras noticias. 3) Precio máximo de licitación por terreno
 más permiso, después de comprar el terreno por 400. Para el comprador, el valor de los flujos del
 edificio de 40 pisos es 1.680/0,20=MM$8.400. Debe pagar además la construcción, que cuesta
 5.600-400=MM$5.200; por tanto, el máximo por terreno + derecho es 8.400-5.200=MM$3.200.
 Equivale al valor de oportunidad del terreno (400) más el valor del permiso (2.800). La empresa
 pagó 400, pero ese costo es hundido al decidir licitar; el comprador no debe pagar de nuevo el
 costo histórico más allá del valor económico de la parcela. Pagar más de 3.200 produciría VAN
 negativo para el comprador. Comprobación por VAN, no sustituto del criterio solicitado. A 20%, los
 VAN individuales son 2.450, 2.800 y 840 para 30,40 y 50 pisos. La comparación incremental
 coincide: 40 pisos crea el mayor valor. Mostrarla sirve como control de consistencia, mientras que la
 decisión de tamaño se fundamenta con TIR incremental. Qué hace distinguida la respuesta:
 identifica la perpetuidad y elimina correctamente la depreciación sin impuestos, calcula TIR y VAN,
 y separa costo hundido de costo económico del derecho/terreno.
 enero 2023 - pregunta 3 - Valor empresa, opción y aporte
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 381-382 | convocatoria
 1
 Volver al enunciado original
 Valores en millones de pesos, al 31/12/22 salvo que se indique. La operación actual es perpetua,
 con flujo anual 47,5 y tasa 10%. El proyecto de última milla requiere 50; si es favorable produce 18
 anuales perpetuos desde el año siguiente, con tasa de proyecto 12%. El estudio gratuito revela si el
 escenario es favorable; en el desfavorable no se invierte. 1. Valor de CSD antes del resultado del
Examen de Grado UC | materia, preguntas y respuestas 249

[pág. 250]
Finanzas - versión clara y reordenada
 estudio. Valor operación actual =47,5/0,10=475. Si el proyecto es favorable, su valor de activos es
 18/0,12=150 y su VAN=150-50=100; si desfavorable se abandona y VAN=0. Valor esperado de la
 oportunidad de invertir =0,30(100)+0,70(0)=30. Por tanto, con información pública y mercado
 semi-fuerte, valor total hoy =475+30=$505 millones. Es valor de una opción de inversión con
 información antes de comprometer los 50, no el VAN esperado de invertir obligatoriamente en todos
 los estados. Si el estudio no identificara perfectamente el estado, faltaría sensibilidad/especificidad
 y se requeriría valorar la decisión según cada señal. 2. Mínima participación para Don Jacinto en
 escenario favorable. Con señal positiva, se ejecuta. Valor bruto del proyecto=150; valor agregado al
 negocio de CSD=475+150=625 antes de repartir propiedad. Don aporta 50. Para quedar indiferente
 entre aportar y no hacerlo, debe recibir participación p tal que p×625=50: p=50/625=8,00%. Es el
 mínimo justo bajo una emisión a valor de mercado. Las fundadoras conservan 92% de una
 compañía cuyo valor es 625, equivalente a 575; respecto de los 475 previos capturan el VAN de
 100. 3. Máxima participación aceptable frente a deuda bancaria. Con deuda, el proyecto tiene VAN
 75. El valor bruto del proyecto en esta alternativa es 50+75=125. Después de invertir y emitir deuda
 de 50, el valor patrimonial de CSD es operación 475 + activo proyecto 125 - deuda 50 = 550. Si se
 incorpora a Jacinto con capital y el proyecto conserva el VAN de 100 (sin deuda), valor total equity
 post-money=625. Las fundadoras aceptarían a lo sumo una fracción p que las deje con igual
 patrimonio que en la alternativa bancaria: (1-p)×625=550; p=1-550/625=12,00%. Con p=12%, valor
 de las fundadoras=550; por encima, prefieren deuda. Existe un rango de negociación 8% a 12%: el
 mínimo de Jacinto para aportar es 8%; el máximo de las fundadoras para preferir capital al
 préstamo es 12%. Se supone que la valoración post-money usa el valor económico completo de las
 operaciones y que el préstamo se reconoce a su valor indicado. Qué hace sólida la respuesta:
 valora la opción de esperar una señal, distingue valor bruto de proyecto y VAN, calcula dilución
 sobre valor post-money y compara la riqueza de fundadoras bajo deuda y capital sin contar dos
 veces los fondos aportados.
 agosto 2017 - pregunta 3 - Valoración y WACC
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 244-245 | convocatoria
 2
 Volver al enunciado original
 RESOLUCIÓN / RESPUESTA MODELO PROPUESTA PARA ESTUDIO (no oficial)
 Flujo operacional perpetuo10.500; deuda bancaria principal40.000, interés inicial5%;100 acciones.
 No hay impuestos ni inflación. El balance presentado es a costo histórico: su patrimonio
 contable60.000 no sirve de ponderación económica del WACC.
 1. WACC en mercado perfecto:8,75%. Intereses anuales=40.000×5%=2.000. Flujo al
 patrimonio=10.500-2.000=8.500. Con ke10,625%, Emercado=8.500/0,10625=80.000. La deuda fue
 contratada a condiciones de mercado, de modo que Dmercado=40.000. V=120.000.
 WACC=(80.000/120.000)10,625%+(40.000/120.000)5%=8,75%.
 Comprobación:10.500/120.000=8,75%. Para expansión con igual riesgo operacional se usa esta
 tasa. La versión anterior usaba valores contables y daba8,375%, que era incorrecto.
 2. Subsidio y valor por acción. Con el WACC7,5% que fija el segundo apartado, valor
 empresa=10.500/0,075=140.000. Bajo la interpretación de un subsidio al costo del préstamo de la
 empresa, manteniendo deuda bancaria por principal40.000, E=140.000-40.000=100.000 y precio
 máximo=100.000/100=1.000 por acción. El texto mantiene monto/plazo del préstamo; se adopta
Examen de Grado UC | materia, preguntas y respuestas 250

[pág. 251]
Finanzas - versión clara y reordenada
 que su obligación económica frente al banco sigue siendo40.000 y que el subsidio beneficia al
 prestatario. No se llama a ese préstamo 'emitido de nuevo a condiciones de mercado', pues desde
 este apartado existe una imperfección explícita.
 3. Rentabilidad accionaria bajo esa interpretación. Interés soportado por
 empresa=40.000×3%=1.200; flujo equity=10.500-1.200=9.300. ke=9.300/100.000=9,30%.
 Comprobación:WACC=(100.000/140.000)9,30%+(40.000/140.000)3%=7,5%.
 Ambigüedad de valoración de la deuda subsidiada. Si se interpretara, en cambio, que el
 acreedor recibe únicamente un cupón perpetuo1.200, que este contrato es negociable y que el
 rendimiento de mercado exigido a ese derecho permanece5%, su valor de mercado
 sería1.200/0,05=24.000, no40.000. Entonces E=116.000, precio1.160 y ke=9.300/116.000=8,02%;
 el WACC7,5% se verifica ponderando deuda24.000 a costo de mercado5%. Es una estructura
 distinta del subsidio al prestatario que preserva el valor del crédito bancario. Una respuesta rigurosa
 explicita quién recibe el subsidio y qué derecho se está valorando. El enunciado no describe la
 mecánica contractual suficiente para borrar esta distinción.
 agosto 2012 - pregunta 3 - WACC, beta y emisión de acciones
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 107-107 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 La deuda existente paga $40,8 en un año y es libre de riesgo con tasa 2%, por lo que su valor hoy
 es 40,8/1,02=$40. El equity vale 20 millones de acciones×$3=$60; valor de activos de la
 firma=$100. Tomo 2% como tasa libre de riesgo, inferida del bono sin riesgo, y supongo que la
 nueva veta tiene riesgo sistemático igual al activo minero existente. Beta de
 activos=βE×E/V=1,2×60/100=0,72. CAPM para el proyecto: rA=2%+0,72(7%-2%)=5,60%.
 PV del flujo nuevo=66/1,056=$62,5; VAN=$62,5-$24,5=$38. Bajo mercado perfecto, financiar con
 equity o deuda libre de riesgo no cambia el VAN operacional si los flujos/riesgo son iguales; solo
 cambia distribución y apalancamiento. No descuento a 2% solo porque el financiamiento propuesto
 sea deuda: el flujo del proyecto tiene beta operacional.
 Antes del aumento de capital, el mercado incorpora el anuncio: valor firma pasa de $100 a $138
 (VAN). Restando deuda de $40, el equity pre-money es $98; precio por acción=98/20=$4,90. Para
 recaudar $24,5 se emiten 24,5/4,9=5 millones de acciones. Post emisión hay 25 millones; los
 accionistas antiguos mantienen 20/25=80% y su participación vale $98. El equity total post-money
 vale $122,5 y la firma $162,5 incluyendo la inversión financiada.
 Beta del equity después del proyecto, si todo el activo agregado conserva βA=0,72, es
 βE=βA×V/E=0,72×162,5/122,5≈0,9551. CAPM: rE=2%+0,9551×5%≈6,78%. La disminución frente
 al 8% previo refleja menor apalancamiento relativo del equity tras emitir acciones para un activo de
 igual riesgo. Si la nueva veta tiene beta distinta, la beta combinada debe ponderarse por valores y
 no puede determinarse solo con los datos del enunciado.
 Qué haría esta respuesta distinguida: distingue valor del activo y costo del financiamiento, usa
 precios de mercado antes de calcular dilución y declara la premisa de riesgo que falta para el
 retorno accionarial final.
Examen de Grado UC | materia, preguntas y respuestas 251

[pág. 252]
Finanzas - versión clara y reordenada
 agosto 2018 - pregunta 6 - Árbol de decisión y opción real
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 276-277 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Trabajamos en miles de USD para los flujos, manteniendo los precios unitarios en USD. El original
 establece cambios de precio de ±USD 60: desde 500, en t=1 el precio es 560 o 440; en t=2 es
 620,500 o 380. Las menciones a 2010 son erratas del original: el horizonte y el árbol corresponden
 a 2019-2020. La probabilidad de cada alza es 0,6 y de cada baja 0,4. El motor entrega 7.000
 unidades, costo variable 490 por unidad, inversión 400 mil, costo de cierre 35 mil y compensación
 por no generar 40 mil.
 1. Contrato obligatorio. El margen de operación anual en miles es 7(P-490). En t=1: a 560 el
 margen es 490; a 440 es-350. Su esperanza es 0,6(490)+0,4(-350)=154. En t=2, los precios
 620,500,380 tienen probabilidades 0,36;0,48;0,16. Sus márgenes son 910,70,-770; todos deben
 operar y al final pagar 35 de cierre. El flujo esperado final es
 0,36(910)+0,48(70)+0,16(-770)-35=203.
 VAN_obligatorio=-400+154/1,10+203/(1,10)^2=-92,23140 mil USD.
 Se rechazaría ese contrato si se dispone de la alternativa de no emprender.
 2. Contrato con opción: resolver desde t=2 hacia t=0. En el último año, operar paga margen
 menos 35 de cierre. Abandonar sin operar paga -40-35=-75. A precio 620, operar paga 875 y
 conviene; a 500, paga 35 y conviene; a 380, paga-805 y conviene abandonar pagando-75.
 En t=1, después de un alza a 560, operar hoy produce 490 y permite seguir en t=2. La continuación
 óptima esperada es 0,6(875)+0,4(35)=539; su valor en t=1 es 490+539/1,10=980. Abandonar hoy
 paga-75; se opera.
 Después de una baja a 440, operar produce-350 y permite una continuación cuyo valor esperado es
 0,6(35)+0,4(-75)=-9. El valor de seguir es -350-9/1,10=-358,18182, peor que abandonar por-75. Se
 abandona en t=1: no habrá operaciones ni otro cierre en t=2.
 VAN_flexible=-400+[0,6(980)+0,4(-75)]/1,10=107,27273 mil USD.
 3. Valor de la opción contractual. La ventaja frente al mismo proyecto obligado es
 107,27273-(-92,23140)=199,50413 mil USD, es decir USD 199.504,13. Es el valor incremental de
 contar con la flexibilidad una vez comparados ambos contratos con la misma inversión. Si se
 compara la decisión global con la alternativa de no invertir, la oportunidad flexible permite un VAN
 positivo de USD 107.272,73; esa cifra y el valor contractual de la opción responden preguntas
 distintas. Las probabilidades y la tasa de 10% son las entregadas por el examen; no se sustituyen
 por una valoración de derivados bajo otra medida.
Examen de Grado UC | materia, preguntas y respuestas 252

[pág. 253]
Finanzas - versión clara y reordenada
 RESPUESTAS DESARROLLADAS · FINANZAS
 Resoluciones completas y lectura económica
 Respuesta F-U1 · CML, SML y desempeño
 La SML evalúa retorno contra beta; la CML evalúa carteras eficientes contra volatilidad total. Un
 portafolio puede tener alfa positivo respecto del CAPM y, al mismo tiempo, demasiado riesgo
 específico. En ese caso aparece sobre la SML porque su retorno supera lo exigido por beta, pero
 bajo la CML porque una combinación eficiente de activo seguro y cartera tangente entrega mejor
 retorno por desviación estándar.
 Si el fondo constituye la mayor parte de la inversión riesgosa del cliente, importa el riesgo total:
 usaría Sharpe, drawdowns, colas y consistencia, además de costos. Si es una pieza dentro de una
 cartera ya diversificada, beta y Treynor pueden ser más informativos, aunque evaluaría contribución
 marginal al riesgo de la cartera completa. Jensen compara con CAPM; una regresión multifactorial
 ayuda a separar habilidad de exposiciones conocidas.
 No escogería por una sola razón histórica. Verificaría benchmark, significancia y persistencia fuera
 de muestra, comisiones, cambios de estrategia y capacidad. La medida correcta depende del rol del
 fondo en el portafolio, no del nombre más conocido.
 Respuesta F-U2 · Fama-French-Carhart
 βMKT=1,05 indica sensibilidad de mercado algo mayor que uno. s=0,40 muestra inclinación hacia
 firmas pequeñas; h=-0,25, hacia growth más que value; m=0,30, hacia acciones con momentum
 positivo. Son exposiciones marginales condicionadas a los otros factores y deben interpretarse con
 unidades, período y construcción de factores.
 El alfa mensual estimado es 0,20%, pero t=1,1 no permite distinguirlo de cero con un umbral usual
 de 5%. No hay evidencia suficiente de habilidad después de controlar factores. Tampoco
 corresponde multiplicar 0,20% por doce y declararlo retorno seguro: la estimación tiene error, puede
 variar y debe tratarse de forma compuesta solo si el supuesto temporal es razonable.
 No podemos concluir causalidad ni que SMB/HML/MOM sean riesgos verdaderos. Revisaría R²,
 residuos, autocorrelación, estabilidad por subperíodo, costos y exposición dinámica. Una buena
 respuesta separa descripción de factores, inferencia estadística y juicio económico.
 Respuesta F-U3 · Inmunización del patrimonio
 E=A-D=300-100=200. La duración del patrimonio es
 DE=(A/E)DA-(D/E)DD=(300/200)10-(100/200)20=15-10=5. Con Δy=0,03,
 ΔE≈-DE·E·Δy=-5·200·0,03=-30. La misma cifra surge de activos y deuda:
 -10·300·0,03-[-20·100·0,03]=-90+60=-30.
 Para inmunizar el primer orden: DA·A=DD·D. Por tanto D=10·300/20=150. Con A fijo, E=150 y
 DE=(300/150)10-(150/150)20=20-20=0. La razón D/E queda en uno.
Examen de Grado UC | materia, preguntas y respuestas 253

[pág. 254]
Finanzas - versión clara y reordenada
 La solución no elimina riesgo completo. Cambiar deuda puede alterar costo, crédito e impuestos;
 las duraciones evolucionan; la curva puede moverse de forma no paralela; y la convexidad genera
 error para cambios grandes. La empresa debe rebalancear y evaluar restricciones contractuales.
 Respuesta F-U4 · Opción binomial y no arbitraje
 Los pagos de la call son Cu=max(120-100,0)=20 y Cd=max(80-100,0)=0. La cartera replicante usa
 Δ=(Cu-Cd)/(Su-Sd)=20/40=0,5 acciones. En el estado bajo, 0,5·80+B·1,05=0, por lo que
 B=-40/1,05=-38,095. El costo inicial es C0=0,5·100-38,095=11,905.
 Por valoración neutral al riesgo, q=[1,05·100-80]/(120-80)=25/40=0,625. Entonces
 C0=[0,625·20+0,375·0]/1,05=11,905. Ambos métodos coinciden porque la opción queda replicada.
 La probabilidad real no es necesaria: el precio se fija por ausencia de arbitraje y el costo de una
 cartera con los mismos pagos. Los supuestos son negociación sin fricciones, posibilidad de
 pedir/prestar a 5%, posiciones fraccionarias y ausencia de oportunidades de arbitraje. Si esos
 supuestos fallan, puede aparecer un rango de precios.
Examen de Grado UC | materia, preguntas y respuestas 254

[pág. 255]
Finanzas - versión clara y reordenada
 CONTROL FINAL DE FUENTES · FINANZAS
 Cruce de resúmenes, ayudantías, pautas y soluciones históricas
 Fuentes cruzadas en esta ampliación
 Fuente local Acción Aporte al manual
 EDG_E_2009-2026_OCR.pdf + Cruce exacto 35 preguntas de Teoría Financiera y 35 de
 mapa de 210 Dirección Financiera
 Resumen Finanzas I Caro / Lectura completa CAPM, SML, Jensen, APT y
 Sofía Pieraj (F0610) Fama-French-Carhart
 Compilados financieros F0833, Lectura y comparación CML/SML, duración, convexidad, inmunización,
 F0837, F0886 y cuadernos capital y valoración
 Siete ayudantías grabadas Muestreo visual de cinco Arbitraje, derivados, binomial, Black-Scholes,
 F0064-F0070 momentos por video bonos, CAPM, APT y multifactoriales
 Enunciados y pautas de las Fuente escrita preferente Procedimientos y resultados usados para validar
 ayudantías lo visible en los videos
 Resolución integral 2011-2026 y Cotejo por examen Respuesta histórica contrastada, con separación
 correcciones por convocatoria entre pauta y propuesta de estudio
 Resúmenes Maida, Cata, Extracción completa o Ejercicios, fórmulas, errores recurrentes y
 Gloffka y fuentes ZIP revisión visual variantes
 recuperadas
 Archivos audiovisuales y duplicados
 De 90 registros multimedia, 79 contienen solo audio y 11 video real. Se comprobaron múltiples
 duplicados exactos -por ejemplo, las copias m4a/mp4 de Finanzas I y II 2021-2- y audios de
 2023-2/2024-2 repetidos con nombres genéricos. Para las correcciones se priorizaron
 transcripciones y documentos escritos del mismo examen. Los siete videos financieros tienen
 material escrito equivalente; por eso la revisión visual se usó para verificar temario y procedimiento,
 sin duplicar una transcripción literal.
 Resultado: el manual mantiene 70 preguntas históricas y respuestas completas. La ampliación
 cierra los conceptos que aparecían en resúmenes completos pero no con nombre o
 procedimiento suficiente en el cuerpo anterior.
Examen de Grado UC | materia, preguntas y respuestas 255

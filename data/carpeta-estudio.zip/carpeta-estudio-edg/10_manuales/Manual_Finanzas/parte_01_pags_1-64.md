# Manual de Finanzas · parte 1 (páginas 1-64)

Fuente: 02_MANUAL_ULTIMATE_FINANZAS_EDG_2027_V2_FORMULAS_CLARAS

[pág. 1]
Finanzas - versión clara y reordenada
 Finanzas manual definitivo V2
 Ecuaciones visuales, materia desde cero, 70 preguntas
 históricas, preguntas adicionales y respuestas completas
 Examen de Grado de Ingeniería Comercial UC · preparación 2027
 Esta versión conserva los documentos anteriores y corrige la legibilidad y el orden. La estructura de
 estudio es materia → preguntas → respuestas.
Examen de Grado UC | materia, preguntas y respuestas 1

[pág. 2]
Finanzas - versión clara y reordenada
 Índice con páginas del documento
 FORMULARIO VISUAL - ECUACIONES CLARAS 13
 1. Valor del dinero y evaluación de proyectos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 14
 2. Bonos, curva y sensibilidad a tasas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 16
 3. Riesgo, diversificación y modelos de retorno . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 18
 4. Derivados y ausencia de arbitraje . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 21
 5. Flujos, costo de capital y valoración . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 22
 6. Capital de trabajo y finanzas internacionales . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 24
 Finanzas · preparación del Examen de Grado UC 2027 25
 Examen de Grado de Ingeniería Comercial UC · enero de 2027 . . . . . . . . . . . . . . . . . . . . . . . . 25
 Cómo usar este manual . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 26
 Mapa del ramo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 26
 Marco común para resolver problemas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 26
 PARTE I - TEORÍA FINANCIERA 27
 1. Valor del dinero en el tiempo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 27
 2. Bonos, curva y riesgo de tasa . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 27
 3. Riesgo, portafolios y CAPM . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 27
 4. Derivados y opciones . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 28
 4A. Activos contingentes, cartera eficiente y APT . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 28
 5. Eficiencia, arbitraje y retornos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 28
 Complemento docente: Teoría Financiera . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 28
 TF01. Retornos, tasas e índices: medir antes de comparar . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 28
 TF02. Incertidumbre y preferencias: por qué una media no basta . . . . . . . . . . . . . . . . . . . . . . . . . . . 29
 TF03. Arbitraje, réplica y precios de estado . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 31
Examen de Grado UC | materia, preguntas y respuestas 2

[pág. 3]
Finanzas - versión clara y reordenada
 TF04. Diversificación y frontera eficiente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 32
 TF05. Activo seguro, cartera tangente y CAPM . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 33
 TF06. Modelos multifactoriales e interpretación de regresiones . . . . . . . . . . . . . . . . . . . . . . . . . . . . 34
 TF07. Eficiencia, información y conducta del inversionista . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 35
 TF08. Bonos, curva de tasas y sensibilidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 36
 TF09. Forwards, futuros y arbitraje de divisas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 37
 TF10. Opciones: pagos, paridad y árbol binomial . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 38
 TF11. Black-Scholes, sensibilidades y volatilidad implícita . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 39
 TF12. Estructura de capital, Modigliani-Miller e impuestos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 40
 TF13. Agencia, información asimétrica, emisiones y gobierno corporativo . . . . . . . . . . . . . . . . . . . . . . 41
 TF14. Dividendos, recompra y crecimiento que crea valor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 43
 PARTE II - DIRECCIÓN FINANCIERA 45
 1. VAN y decisión de inversión . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 45
 2. Tasa de descuento, WACC y riesgo de proyecto . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 45
 3. Capital de trabajo y liquidez . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 45
 4. Deuda, capital, dividendos y valoración . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 46
 5. Impuestos y decisiones . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 46
 Procedimiento para ejercicios cuantitativos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 46
 Errores frecuentes que esta guía corrige . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 46
 Complemento docente: Dirección Financiera . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 47
 DF01. Leer estados financieros, diagnosticar ratios y comprender apalancamiento . . . . . . . . . . . . . . . . . . 47
 DF02. Planificación, proformas, FER y crecimiento sostenible . . . . . . . . . . . . . . . . . . . . . . . . . . . . 48
 DF03. Inventarios: EOQ, reposición y descuentos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 49
 DF04. Administración de caja: Baumol y Miller-Orr . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 50
 Desarrollo desde cero: Teoría Financiera y Dirección Financiera . . . . . . . . . . . . . . . . . . . . . . . . 51
 1. Qué pregunta responde Finanzas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 51
 2. Valor del dinero en el tiempo y tasas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 51
Examen de Grado UC | materia, preguntas y respuestas 3

[pág. 4]
Finanzas - versión clara y reordenada
 3. Bonos, rendimiento y riesgo de tasas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 52
 4. Riesgo, diversificación, CAPM y costo de capital . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 52
 5. Derivados, arbitraje y opciones . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 53
 6. Evaluación de proyectos: construir flujos incrementales . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 53
 7. WACC, riesgo de proyecto, APV y sensibilidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 54
 8. Liquidez, capital de trabajo y financiamiento de corto plazo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 54
 9. Capital structure, dividendos y valor empresa . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 55
 10. Impuestos, fusiones y decisiones de valor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 55
 11. Guía para resolver ejercicios y contestar el grado . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 55
 Taller de problemas financieros resueltos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 56
 Problema 1. Comparar tasas y flujos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 56
 Problema 2. Precio de un bono y sensibilidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 56
 Problema 3. Diversificación y beta . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 56
 Problema 4. Opción, réplica y no arbitraje . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 57
 Problema 5. Flujo de caja con impuestos y capital de trabajo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 57
 Problema 6. WACC y riesgo comparable . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 57
 Problema 7. Capital de trabajo y decisión de liquidez . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 58
 Problema 8. Adquisición y captura de sinergias . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 58
 12. Errores que debes detectar en una solución . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 58
 Materias respaldadas por los resúmenes de Finanzas I y II . . . . . . . . . . . . . . . . . . . . . . . . . . . 59
 A. Preferencias bajo incertidumbre . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 59
 B. Más allá del CAPM de un factor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 59
 C. Precio forward y arbitraje de divisas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 59
 D. Valoración de acciones y de empresas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 60
 E. Apalancamiento operativo, financiero y combinado . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 60
 F. Planificación financiera y fondos externos requeridos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 60
 G. Inventarios y administración de efectivo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 61
Examen de Grado UC | materia, preguntas y respuestas 4

[pág. 5]
Finanzas - versión clara y reordenada
 H. Crédito comercial, cobranza y ciclo de caja . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 61
 I. Arrendamiento financiero y deuda de largo plazo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 61
 J. Opciones reales: valorar flexibilidad sin duplicarla . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 62
 K. Razones financieras: diagnóstico y límites . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 62
 Unidades de profundización: decisiones de Dirección Financiera . . . . . . . . . . . . . . . . . . . . . . . . 62
 Pronóstico financiero, crecimiento y fondos externos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 62
 Gestión de inventario y efectivo: costos que compiten . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 63
 Crédito comercial, morosidad y descuento por pronto pago . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 64
 Financiamiento de corto plazo y factoring . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 64
 Valoración de empresas: FCFF, FCFE, múltiplos y consistencia . . . . . . . . . . . . . . . . . . . . . . . . . . . 65
 Arrendamientos, deuda y estructura de capital . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 65
 Lectura integrada de ratios y diagnóstico financiero . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 66
 Taller avanzado: pasar de un dato financiero a una decisión . . . . . . . . . . . . . . . . . . . . . . . . . . 66
 Preferencias, riesgo y equivalente cierto . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 66
 Construir beta y costo de capital con datos coherentes . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 67
 Bonos, duración y cambio de curva: un cálculo interpretable . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 67
 Precio forward de moneda y cobertura con descalce . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 67
 Opciones: replicar para entender precio, no memorizar fórmula . . . . . . . . . . . . . . . . . . . . . . . . . . . . 68
 Sensibilidad, escenarios y tasa de descuento . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 68
 Fuentes y trazabilidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 68
 MATERIA RECUPERADA · FINANZAS 69
 1. CML y SML: dos rectas, dos objetos de riesgo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 69
 Sharpe, Treynor y alfa de Jensen . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 69
 2. De CAPM a Fama-French-Carhart . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 69
 3. Duración, convexidad e inmunización . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 70
 Ejemplo completo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 70
 4. Qué aportaron las siete ayudantías grabadas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 70
Examen de Grado UC | materia, preguntas y respuestas 5

[pág. 6]
Finanzas - versión clara y reordenada
 PARTE DE PRÁCTICA - 70 preguntas históricas 71
 Teoría Financiera - 35 preguntas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 71
 agosto 2015 - pregunta 6 - Alfa, beta y elección de fondos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 72
 agosto 2013 - pregunta 5 - Apalancamiento, múltiplos y eficiencia . . . . . . . . . . . . . . . . . . . . . . . . . . 73
 agosto 2021 - pregunta 6 - Beta, CAPM y WACC . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 74
 enero 2019 - pregunta 3 - Betas y WACC . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 75
 marzo 2011 - pregunta 6 - Bonos, impuestos y TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 76
 marzo 2009 - pregunta 6 - Bonos/renta fija . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 78
 agosto 2010 - pregunta 6 - Bonos/renta fija . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 80
 agosto 2024 - pregunta 1 - Bonos/renta fija . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 81
 agosto 2025 - pregunta 6 - Bonos/renta fija . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 83
 agosto 2023 - pregunta 6 - CDS, beta y arbitraje . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 85
 enero 2020 - pregunta 6 - Correlación y cobertura cambiaria . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 87
 enero 2012 - pregunta 5 - Curva de tasas, spreads y duración . . . . . . . . . . . . . . . . . . . . . . . . . . . . 88
 enero 2014 - pregunta 6 - Deuda, estados y debt overhang . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 90
 agosto 2017 - pregunta 6 - Deuda, patrimonio y estados . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 91
 agosto 2011 - pregunta 6 - Diversificación y tipo de cambio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 93
 enero 2015 - pregunta 6 - Eficiencia de mercado y fondos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 95
 agosto 2019 - pregunta 6 - Flujo residual y valor del equity . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 97
 agosto 2012 - pregunta 6 - Fusión, pérdidas tributarias y canje . . . . . . . . . . . . . . . . . . . . . . . . . . . . 99
 enero 2017 - pregunta 6 - Goodwill y ahorro tributario . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 101
 agosto 2014 - pregunta 3 - Gordon y crecimiento sostenible . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 102
 agosto 2022 - pregunta 6 - HME, VIX y valor presente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 103
 enero 2018 - pregunta 6 - Liquidez y opciones societarias . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 105
 enero 2021 - pregunta 3 - Mercados eficientes y señalización . . . . . . . . . . . . . . . . . . . . . . . . . . . . 106
 enero 2013 - pregunta 6 - Opciones y cobertura por estados . . . . . . . . . . . . . . . . . . . . . . . . . . . . 107
 agosto 2016 - pregunta 6 - Opciones y paridad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 108
Examen de Grado UC | materia, preguntas y respuestas 6

[pág. 7]
Finanzas - versión clara y reordenada
 agosto 2009 - pregunta 6 - Opciones/derivados . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 109
 enero 2023 - pregunta 6 - Paridad cubierta y arbitraje . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 111
 enero 2016 - pregunta 6 - Pesos, UF e inflación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 113
 enero 2025 - pregunta 5 - Portafolio, CAPM y puts . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 115
 agosto 2018 - pregunta 3 - Portafolios, beta y Sharpe . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 116
 agosto 2020 - pregunta 4 - Retorno, riesgo, probabilidades y Sharpe . . . . . . . . . . . . . . . . . . . . . . . . 118
 marzo 2010 - pregunta 6 - Riesgo y portafolios . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 120
 enero 2026 - pregunta 5 - Riesgo y portafolios . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 122
 enero 2024 - pregunta 6 - Tasas, portafolio y HME . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 123
 enero 2022 - pregunta 6 - UF, inflación y eficiencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 125
 Dirección Financiera - 35 preguntas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 126
 enero 2012 - pregunta 3 - APV y escudo tributario . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 127
 agosto 2014 - pregunta 6 - Alternativas productivas y VAN . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 129
 agosto 2015 - pregunta 3 - Aumento de capital y derechos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 131
 enero 2025 - pregunta 1 - CAPM de proyecto y emisión . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 133
 enero 2018 - pregunta 3 - DuPont y alfa . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 135
 enero 2014 - pregunta 3 - DuPont, ROA y ROE . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 137
 enero 2015 - pregunta 3 - FCF, perpetuidad y financiamiento . . . . . . . . . . . . . . . . . . . . . . . . . . . . 139
 enero 2016 - pregunta 3 - FER . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 141
 marzo 2011 - pregunta 3 - Flujo de caja incremental y VAN . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 143
 enero 2019 - pregunta 6 - Flujo incremental y financiamiento . . . . . . . . . . . . . . . . . . . . . . . . . . . . 145
 marzo 2009 - pregunta 3 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 147
 agosto 2009 - pregunta 3 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 149
 marzo 2010 - pregunta 3 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 151
 agosto 2010 - pregunta 3 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 153
 agosto 2024 - pregunta 4 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 155
 agosto 2025 - pregunta 4 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 157
 enero 2026 - pregunta 2 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 159
Examen de Grado UC | materia, preguntas y respuestas 7

[pág. 8]
Finanzas - versión clara y reordenada
 enero 2022 - pregunta 3 - Leasing/arriendo y equivalencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 161
 agosto 2016 - pregunta 3 - Liquidez y capital de trabajo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 162
 agosto 2021 - pregunta 3 - Liquidez, ciclo y GLO . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 164
 agosto 2022 - pregunta 3 - Patrimonio y negociación bancaria . . . . . . . . . . . . . . . . . . . . . . . . . . . . 166
 agosto 2013 - pregunta 2 - Perpetuidad, VAN y patrimonio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 168
 agosto 2011 - pregunta 3 - Proyecto, deuda y nuevo socio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 170
 enero 2021 - pregunta 6 - Proyecto, externalidades y precio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 172
 agosto 2020 - pregunta 2 - ROA, WACC y planificación financiera . . . . . . . . . . . . . . . . . . . . . . . . . . 174
 agosto 2019 - pregunta 3 - Ratios y ciclo de caja . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 176
 agosto 2023 - pregunta 3 - Reemplazo de máquina y VAN . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 178
 enero 2020 - pregunta 3 - Reemplazo y costo anual equivalente . . . . . . . . . . . . . . . . . . . . . . . . . . . 180
 enero 2013 - pregunta 3 - Riesgo operacional y deuda . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 182
 enero 2024 - pregunta 3 - Riesgo, TIR y múltiplos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 184
 enero 2017 - pregunta 3 - TIR incremental y VAN . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 186
 enero 2023 - pregunta 3 - Valor empresa, opción y aporte . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 188
 agosto 2017 - pregunta 3 - Valoración y WACC . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 190
 agosto 2012 - pregunta 3 - WACC, beta y emisión de acciones . . . . . . . . . . . . . . . . . . . . . . . . . . . 192
 agosto 2018 - pregunta 6 - Árbol de decisión y opción real . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 193
 PREGUNTAS ADICIONALES · FINANZAS 195
 Pregunta F-U1 · CML, SML y desempeño . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 195
 Pregunta F-U2 · Fama-French-Carhart . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 195
 Pregunta F-U3 · Inmunización del patrimonio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 195
 Pregunta F-U4 · Opción binomial y no arbitraje . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 195
 RESPUESTAS - soluciones completas 196
 Teoría Financiera . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 196
 agosto 2015 - pregunta 6 - Alfa, beta y elección de fondos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 196
Examen de Grado UC | materia, preguntas y respuestas 8

[pág. 9]
Finanzas - versión clara y reordenada
 agosto 2013 - pregunta 5 - Apalancamiento, múltiplos y eficiencia . . . . . . . . . . . . . . . . . . . . . . . . . . 196
 agosto 2021 - pregunta 6 - Beta, CAPM y WACC . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 197
 enero 2019 - pregunta 3 - Betas y WACC . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 198
 marzo 2011 - pregunta 6 - Bonos, impuestos y TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 199
 marzo 2009 - pregunta 6 - Bonos/renta fija . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 199
 agosto 2010 - pregunta 6 - Bonos/renta fija . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 200
 agosto 2024 - pregunta 1 - Bonos/renta fija . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 201
 agosto 2025 - pregunta 6 - Bonos/renta fija . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 201
 agosto 2023 - pregunta 6 - CDS, beta y arbitraje . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 202
 enero 2020 - pregunta 6 - Correlación y cobertura cambiaria . . . . . . . . . . . . . . . . . . . . . . . . . . . . 202
 enero 2012 - pregunta 5 - Curva de tasas, spreads y duración . . . . . . . . . . . . . . . . . . . . . . . . . . . . 203
 enero 2014 - pregunta 6 - Deuda, estados y debt overhang . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 204
 agosto 2017 - pregunta 6 - Deuda, patrimonio y estados . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 204
 agosto 2011 - pregunta 6 - Diversificación y tipo de cambio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 205
 enero 2015 - pregunta 6 - Eficiencia de mercado y fondos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 205
 agosto 2019 - pregunta 6 - Flujo residual y valor del equity . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 206
 agosto 2012 - pregunta 6 - Fusión, pérdidas tributarias y canje . . . . . . . . . . . . . . . . . . . . . . . . . . . 207
 enero 2017 - pregunta 6 - Goodwill y ahorro tributario . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 208
 agosto 2014 - pregunta 3 - Gordon y crecimiento sostenible . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 208
 agosto 2022 - pregunta 6 - HME, VIX y valor presente . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 209
 enero 2018 - pregunta 6 - Liquidez y opciones societarias . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 210
 enero 2021 - pregunta 3 - Mercados eficientes y señalización . . . . . . . . . . . . . . . . . . . . . . . . . . . . 210
 enero 2013 - pregunta 6 - Opciones y cobertura por estados . . . . . . . . . . . . . . . . . . . . . . . . . . . . 212
 agosto 2016 - pregunta 6 - Opciones y paridad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 212
 agosto 2009 - pregunta 6 - Opciones/derivados . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 213
 enero 2023 - pregunta 6 - Paridad cubierta y arbitraje . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 214
 enero 2016 - pregunta 6 - Pesos, UF e inflación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 214
 enero 2025 - pregunta 5 - Portafolio, CAPM y puts . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 215
Examen de Grado UC | materia, preguntas y respuestas 9

[pág. 10]
Finanzas - versión clara y reordenada
 agosto 2018 - pregunta 3 - Portafolios, beta y Sharpe . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 216
 agosto 2020 - pregunta 4 - Retorno, riesgo, probabilidades y Sharpe . . . . . . . . . . . . . . . . . . . . . . . . 216
 marzo 2010 - pregunta 6 - Riesgo y portafolios . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 217
 enero 2026 - pregunta 5 - Riesgo y portafolios . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 217
 enero 2024 - pregunta 6 - Tasas, portafolio y HME . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 218
 enero 2022 - pregunta 6 - UF, inflación y eficiencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 219
 Dirección Financiera . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 219
 enero 2012 - pregunta 3 - APV y escudo tributario . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 219
 agosto 2014 - pregunta 6 - Alternativas productivas y VAN . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 220
 agosto 2015 - pregunta 3 - Aumento de capital y derechos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 222
 enero 2025 - pregunta 1 - CAPM de proyecto y emisión . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 223
 enero 2018 - pregunta 3 - DuPont y alfa . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 224
 enero 2014 - pregunta 3 - DuPont, ROA y ROE . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 225
 enero 2015 - pregunta 3 - FCF, perpetuidad y financiamiento . . . . . . . . . . . . . . . . . . . . . . . . . . . . 225
 enero 2016 - pregunta 3 - FER . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 226
 marzo 2011 - pregunta 3 - Flujo de caja incremental y VAN . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 227
 enero 2019 - pregunta 6 - Flujo incremental y financiamiento . . . . . . . . . . . . . . . . . . . . . . . . . . . . 229
 marzo 2009 - pregunta 3 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 229
 agosto 2009 - pregunta 3 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 230
 marzo 2010 - pregunta 3 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 231
 agosto 2010 - pregunta 3 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 232
 agosto 2024 - pregunta 4 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 234
 agosto 2025 - pregunta 4 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 234
 enero 2026 - pregunta 2 - Flujos/VAN/TIR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 235
 enero 2022 - pregunta 3 - Leasing/arriendo y equivalencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 236
 agosto 2016 - pregunta 3 - Liquidez y capital de trabajo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 237
 agosto 2021 - pregunta 3 - Liquidez, ciclo y GLO . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 239
Examen de Grado UC | materia, preguntas y respuestas 10

[pág. 11]
Finanzas - versión clara y reordenada
 agosto 2022 - pregunta 3 - Patrimonio y negociación bancaria . . . . . . . . . . . . . . . . . . . . . . . . . . . . 240
 agosto 2013 - pregunta 2 - Perpetuidad, VAN y patrimonio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 241
 agosto 2011 - pregunta 3 - Proyecto, deuda y nuevo socio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 241
 enero 2021 - pregunta 6 - Proyecto, externalidades y precio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 242
 agosto 2020 - pregunta 2 - ROA, WACC y planificación financiera . . . . . . . . . . . . . . . . . . . . . . . . . . 243
 agosto 2019 - pregunta 3 - Ratios y ciclo de caja . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 244
 agosto 2023 - pregunta 3 - Reemplazo de máquina y VAN . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 245
 enero 2020 - pregunta 3 - Reemplazo y costo anual equivalente . . . . . . . . . . . . . . . . . . . . . . . . . . . 246
 enero 2013 - pregunta 3 - Riesgo operacional y deuda . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 247
 enero 2024 - pregunta 3 - Riesgo, TIR y múltiplos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 247
 enero 2017 - pregunta 3 - TIR incremental y VAN . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 248
 enero 2023 - pregunta 3 - Valor empresa, opción y aporte . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 249
 agosto 2017 - pregunta 3 - Valoración y WACC . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 250
 agosto 2012 - pregunta 3 - WACC, beta y emisión de acciones . . . . . . . . . . . . . . . . . . . . . . . . . . . 251
 agosto 2018 - pregunta 6 - Árbol de decisión y opción real . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 252
 RESPUESTAS DESARROLLADAS · FINANZAS 253
 Respuesta F-U1 · CML, SML y desempeño . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 253
 Respuesta F-U2 · Fama-French-Carhart . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 253
 Respuesta F-U3 · Inmunización del patrimonio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 253
 Respuesta F-U4 · Opción binomial y no arbitraje . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 254
 CONTROL FINAL DE FUENTES · FINANZAS 255
 Fuentes cruzadas en esta ampliación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 255
 Archivos audiovisuales y duplicados . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 255
Examen de Grado UC | materia, preguntas y respuestas 11

[pág. 12]
Finanzas - versión clara y reordenada
Examen de Grado UC | materia, preguntas y respuestas 12

[pág. 13]
Finanzas - versión clara y reordenada
 FORMULARIO VISUAL - ECUACIONES
 CLARAS
 Este formulario corrige la notación lineal del cuerpo anterior. Cada ecuación aparece aislada, con
 variables, procedimiento, error típico y, cuando agrega valor, un ejemplo. No se memoriza sin
 criterio: primero identifica el flujo, su dueño, el horizonte, la moneda, el riesgo y el supuesto del
 modelo.
 Ruta de uso: 1) dibuja línea de tiempo o estados; 2) elige la ecuación; 3) homologa unidades; 4)
 calcula; 5) interpreta; 6) prueba sensibilidad; 7) cierra con decisión y límite.
Examen de Grado UC | materia, preguntas y respuestas 13

[pág. 14]
Finanzas - versión clara y reordenada
 1. Valor del dinero y evaluación de proyectos
 Las fórmulas de este bloque comparten unidades y supuestos que deben declararse antes de
 calcular.
 Valor futuro con capitalización compuesta
 VF = VP × (1 + r)n
 Qué responde. Cuánto vale en n períodos un monto invertido hoy.
 Variables. VP es el valor presente; r, la tasa efectiva por período; n, el número de períodos.
 Procedimiento. Alinea tasa y período. Si r es mensual, n debe contar meses.
 Error típico. Usar una tasa anual con meses o multiplicar VP × (1 + r × n) cuando existe capitalización.
 Ejemplo. VP = 1.000, r = 10% anual y n = 2: VF = 1.000 × 1,10² = 1.210.
 Valor presente de un flujo
 VP = CFt / (1 + r)t
 Qué responde. Qué vale hoy un flujo futuro compatible con una tasa de descuento.
 Variables. CF_t es el flujo en t; r incorpora tiempo y riesgo compatibles; t cuenta períodos.
 Procedimiento. Identifica primero el dueño del flujo y su riesgo; después elige la tasa.
 Error típico. Descontar un flujo de deuda con costo de patrimonio, o un flujo real con tasa nominal.
 Anualidad ordinaria
 VP = C × [1 - (1 + r)(-n)] / r
 Qué responde. Valor presente de n pagos iguales al final de cada período.
 Variables. C es el pago periódico; r, la tasa efectiva del período; n, la cantidad de pagos.
 Procedimiento. Para una anualidad anticipada multiplica el resultado por (1 + r).
 Error típico. Aplicar la fórmula a pagos variables o confundir pago al inicio con pago al final.
Examen de Grado UC | materia, preguntas y respuestas 14

[pág. 15]
Finanzas - versión clara y reordenada
 Perpetuidad y perpetuidad creciente
 VP = C1 / r | VP = C1 / (r - g)
 Qué responde. Valor de flujos que continúan indefinidamente, constantes o creciendo a tasa g.
 Variables. C_1 es el flujo del próximo período; g es crecimiento de largo plazo; debe cumplirse r > g.
 Procedimiento. Usa supuestos sostenibles y explícitos. Una diferencia pequeña entre r y g cambia mucho el valor.
 Error típico. Usar el flujo actual C_0 como si fuera C_1 o escoger g mayor o igual que r.
 Valor actual neto
 VAN = -I0 + Σ[t=1…n] CFt / (1 + k)t
 Qué responde. Cuánto valor económico incremental crea el proyecto hoy.
 Variables. I_0 es la inversión inicial; CF_t, flujo incremental; k, tasa compatible con riesgo y moneda.
 Procedimiento. Incluye capital de trabajo, impuestos, costos de oportunidad y efectos secundarios. Acepta si VAN
 > 0.
 Error típico. Usar utilidad contable, olvidar la inversión al cierre o mezclar flujos nominales y tasas reales.
 Ejemplo. Si I_0 = 100, CF_1 = 60, CF_2 = 70 y k = 10%, VAN = -100 + 60/1,10 + 70/1,10² = 12,40.
 Tasa efectiva anual
 TEA = (1 + inominal / m)m - 1
 Qué responde. Tasa anual que incorpora capitalización m veces dentro del año.
 Variables. i_nominal es tasa nominal anual; m es número de capitalizaciones por año.
 Procedimiento. Convierte todas las alternativas a una base efectiva comparable.
 Error típico. Dividir una TEA por 12 para obtener tasa mensual o comparar nominal con efectiva.
 Relación de Fisher
 1 + inominal = (1 + rreal) × (1 + inflación)
 Qué responde. Separa tasa nominal, tasa real e inflación esperada.
 Variables. i_nominal está en moneda corriente; r_real, en poder adquisitivo; inflación corresponde al mismo
 período.
 Procedimiento. Usa la relación exacta; la suma r + inflación es solo aproximación para tasas pequeñas.
 Error típico. Descontar flujos nominales con tasa real o viceversa.
Examen de Grado UC | materia, preguntas y respuestas 15

[pág. 16]
Finanzas - versión clara y reordenada
 2. Bonos, curva y sensibilidad a tasas
 Las fórmulas de este bloque comparten unidades y supuestos que deben declararse antes de
 calcular.
 Precio de un bono
 P = Σ[t=1…n] Cupón / (1 + y)t + Valor / (1 + y)n
 0 t par
 Qué responde. Valor presente de cupones y principal descontados a rendimiento y.
 Variables. y es rendimiento por período; n es número de períodos; los cupones deben usar la misma frecuencia.
 Procedimiento. Dibuja la línea de tiempo y separa cupón final de principal.
 Error típico. Usar y anual para cupones semestrales sin conversión o confundir tasa cupón con rendimiento.
 Tasa forward implícita
 (1 + sn)n = (1 + sm)m × (1 + f(m,n))(n-m)
 Qué responde. Tasa futura implícita entre m y n bajo ausencia de arbitraje.
 Variables. s_m y s_n son tasas spot; f_(m,n) cubre desde m hasta n.
 Procedimiento. Iguala dos estrategias con el mismo horizonte y despeja la tasa forward.
 Error típico. Promediar tasas spot aritméticamente o mezclar convenciones de capitalización.
 Duración de Macaulay
 DMac = [Σ t × VP(CFt)] / Precio
 Qué responde. Plazo promedio ponderado por valor presente de los flujos.
 Variables. t es momento del flujo; VP(CF_t) es su valor presente; Precio es la suma de valores presentes.
 Procedimiento. Calcula cada peso como VP(CF_t)/Precio y verifica que los pesos sumen 1.
 Error típico. Promediar fechas sin ponderar por valor o usar flujos sin descontar.
Examen de Grado UC | materia, preguntas y respuestas 16

[pág. 17]
Finanzas - versión clara y reordenada
 Duración modificada
 Dmod = DMac / (1 + y) y ΔP / P ≈ -Dmod × Δy
 Qué responde. Sensibilidad porcentual aproximada del precio a un cambio pequeño del rendimiento.
 Variables. Δy se expresa en decimal: 100 puntos base = 0,01.
 Procedimiento. Aplica el signo negativo: si sube la tasa, baja el precio.
 Error típico. Ingresar 100 en vez de 0,01 o tratar la aproximación como exacta ante cambios grandes.
 Ejemplo. D_mod = 5 y Δy = +0,01: ΔP/P ≈ -5%, antes de convexidad.
 Duración con convexidad
 ΔP / P ≈ -Dmod × Δy + 0,5 × Convexidad × (Δy)2
 Qué responde. Mejora la aproximación al reconocer curvatura precio-tasa.
 Variables. La convexidad debe usar la misma convención de rendimiento y frecuencia.
 Procedimiento. Primero calcula efecto lineal; luego agrega el término cuadrático.
 Error típico. Olvidar elevar Δy al cuadrado o asumir movimientos paralelos cuando cambia la forma de la curva.
 Duración del patrimonio
 DE = (A / E) × DA - (D / E) × DD
 Qué responde. Sensibilidad del patrimonio cuando activos y deuda reaccionan a tasas.
 Variables. E = A - D; D_A y D_D son duraciones de activos y deuda.
 Procedimiento. Para inmunizar el primer orden busca D_A × A = D_D × D.
 Error típico. Confundir D de deuda con duración o creer que duración cero elimina crédito, convexidad y liquidez.
Examen de Grado UC | materia, preguntas y respuestas 17

[pág. 18]
Finanzas - versión clara y reordenada
 3. Riesgo, diversificación y modelos de retorno
 Las fórmulas de este bloque comparten unidades y supuestos que deben declararse antes de
 calcular.
 Retorno esperado
 E(R ) = Σ w × E(R )
 p i i
 Qué responde. Retorno medio esperado de una cartera.
 Variables. w_i es el peso del activo i; los pesos suman 1 si no hay financiamiento neto externo.
 Procedimiento. Pondera retornos esperados; no ponderes desviaciones estándar de la misma forma.
 Error típico. Confundir retorno esperado con retorno garantizado.
 Varianza de dos activos
 σp² = w1²σ1² + w2²σ2² + 2w1w2ρ12σ1σ2
 Qué responde. Riesgo total de una cartera de dos activos.
 Variables. σ es desviación estándar; ρ_12 es correlación; cov_12 = ρ_12σ_1σ_2.
 Procedimiento. Calcula varianza primero y luego raíz cuadrada para obtener σ_p.
 Error típico. Omitir covarianza, sumar desviaciones directamente o olvidar el factor 2.
 Beta
 βi = Cov(Ri, RM) / Var(RM)
 Qué responde. Sensibilidad del activo al riesgo sistemático del mercado.
 Variables. Cov mide comovimiento; Var(R_M) es varianza del mercado.
 Procedimiento. Interpreta β = 1,2 como sensibilidad, no como 20% de retorno extra asegurado.
 Error típico. Usar correlación como beta sin ajustar por volatilidades.
Examen de Grado UC | materia, preguntas y respuestas 18

[pág. 19]
Finanzas - versión clara y reordenada
 CAPM y Security Market Line
 E(Ri) = Rf + βi × [E(RM) - Rf]
 Qué responde. Retorno exigido por exposición al riesgo sistemático bajo los supuestos del CAPM.
 Variables. R_f es tasa libre de riesgo; E(R_M) - R_f es prima de mercado.
 Procedimiento. Separa tasa base y prima. Un activo sobre la SML tiene alfa positivo respecto del modelo.
 Error típico. Usar desviación estándar en la SML o aplicar CAPM sin coherencia de moneda y horizonte.
 Ejemplo. R_f = 3%, β = 1,2 y prima = 6%: retorno exigido = 3% + 1,2×6% = 10,2%.
 Sharpe
 Sharpe = [Rp - Rf] / σp
 Qué responde. Exceso de retorno por unidad de riesgo total.
 Variables. R_p y R_f usan el mismo período; σ_p es volatilidad total.
 Procedimiento. Úsalo cuando el portafolio representa gran parte de la riqueza riesgosa.
 Error típico. Comparar períodos o monedas distintas; ignorar colas, costos y sesgo de selección.
 Treynor
 Treynor = [Rp - Rf] / βp
 Qué responde. Exceso de retorno por unidad de riesgo sistemático.
 Variables. β_p es beta de la cartera respecto del benchmark.
 Procedimiento. Es más pertinente para una pieza dentro de una cartera ya diversificada.
 Error típico. Usarlo en una cartera concentrada donde el riesgo específico importa mucho.
 Alfa de Jensen
 αp = Rp - {Rf + βp × [RM - Rf]}
 Qué responde. Retorno no explicado por CAPM en el período.
 Variables. Los retornos y R_f deben compartir frecuencia; β y benchmark deben ser pertinentes.
 Procedimiento. Evalúa significancia, persistencia, costos y estabilidad fuera de muestra.
 Error típico. Declarar habilidad por un alfa positivo sin error estándar ni benchmark adecuado.
Examen de Grado UC | materia, preguntas y respuestas 19

[pág. 20]
Finanzas - versión clara y reordenada
 Modelo multifactorial
 Ri - Rf = α + βMKT·MKT + s·SMB + h·HML + m·MOM + ε
 Qué responde. Separa retorno en exposiciones a mercado, tamaño, valor y momentum.
 Variables. α es parte no explicada; los coeficientes describen sensibilidad condicional a los demás factores.
 Procedimiento. Interpreta signo, magnitud, significancia y estabilidad; después juzga desempeño.
 Error típico. Creer que R² alto demuestra habilidad o que un coeficiente implica causalidad.
Examen de Grado UC | materia, preguntas y respuestas 20

[pág. 21]
Finanzas - versión clara y reordenada
 4. Derivados y ausencia de arbitraje
 Las fórmulas de este bloque comparten unidades y supuestos que deben declararse antes de
 calcular.
 Pagos de opciones europeas al vencimiento
 Call = max(S - K, 0) | Put = max(K - S , 0)
 T T T T
 Qué responde. Pago bruto de comprar una call o put al vencimiento.
 Variables. S_T es precio final; K es precio de ejercicio.
 Procedimiento. Distingue pago final de utilidad: la utilidad resta la prima llevada al horizonte.
 Error típico. Olvidar la prima o invertir comprador y vendedor.
 Paridad put-call
 C0 - P0 = S0 - VP(K)
 Qué responde. Relación de no arbitraje para opciones europeas con mismo K y vencimiento, sin dividendos.
 Variables. VP(K) es valor presente del strike; C y P son primas hoy.
 Procedimiento. Construye ambos lados como carteras con el mismo pago final.
 Error típico. Aplicar sin ajustar dividendos o a opciones con condiciones distintas.
 Binomial de un período
 Δ = (Cu - Cd)/(Su - Sd) | C0 = [qCu + (1-q)Cd]/(1+r)
 Qué responde. Valor de una opción por réplica o probabilidad neutral al riesgo.
 Variables. q = [(1+r)S_0 - S_d]/(S_u - S_d); debe quedar entre 0 y 1 sin arbitraje.
 Procedimiento. Calcula pagos, delta, posición segura y costo replicante; verifica con q.
 Error típico. Usar probabilidad real de alza cuando la réplica completa fija el precio.
 Black-Scholes para una call
 C0 = S0N(d1) - K e(-rT) N(d2)
 Qué responde. Valor de una call europea bajo los supuestos de Black-Scholes.
 Variables. d_1 = [ln(S_0/K)+(r+σ²/2)T]/(σ√T); d_2 = d_1-σ√T.
 Procedimiento. Mantén r y σ anualizados, T en años y usa la normal acumulada N(·).
 Error típico. Confundir N(d) con densidad, usar volatilidad porcentual como número entero o ignorar dividendos.
Examen de Grado UC | materia, preguntas y respuestas 21

[pág. 22]
Finanzas - versión clara y reordenada
 5. Flujos, costo de capital y valoración
 Las fórmulas de este bloque comparten unidades y supuestos que deben declararse antes de
 calcular.
 Flujo libre para la firma
 FCFF = EBIT(1-T) + Depreciación - CAPEX - ΔCapital
 detrabajo
 Qué responde. Efectivo operativo disponible para deuda y patrimonio.
 Variables. EBIT es resultado operacional; CAPEX es inversión; ΔCT positivo consume caja.
 Procedimiento. Usa WACC para descontar FCFF si riesgo y estructura son compatibles.
 Error típico. Restar intereses dentro de FCFF y descontar además con WACC, contando deuda dos veces.
 Costo promedio ponderado de capital
 WACC = [E/(D+E)]Re + [D/(D+E)]Rd(1-Tc)
 Qué responde. Tasa para FCFF cuando la estructura objetivo y el riesgo son apropiados.
 Variables. E y D son valores de mercado; R_e y R_d son costos exigidos; T_c es tasa tributaria marginal
 pertinente.
 Procedimiento. Pondera a valores de mercado y aplica escudo solo a deuda cuyo interés es deducible.
 Error típico. Usar valores contables, costo histórico o descontar flujo al accionista con WACC.
 Ejemplo. E=60, D=40, R_e=12%, R_d=6%, T=25%: WACC=0,6×12%+0,4×6%×0,75=9,0%.
 Valor terminal con crecimiento
 VTn = FCFF(n+1) / (WACC - g)
 Qué responde. Valor en n de flujos posteriores que crecen a g de modo estable.
 Variables. FCFF_(n+1) es el primer flujo estable; WACC > g.
 Procedimiento. Descuenta VT_n nuevamente desde n hasta hoy y prueba sensibilidad a WACC y g.
 Error típico. Usar FCFF_n sin crecerlo, g insostenible o tratar el terminal como valor presente.
Examen de Grado UC | materia, preguntas y respuestas 22

[pág. 23]
Finanzas - versión clara y reordenada
 Valor presente ajustado
 APV = VAN del proyecto sin deuda + VP(beneficios financieros) -
 VP(costos financieros)
 Qué responde. Separa valor operacional de efectos de financiamiento.
 Variables. Incluye escudos, costos de emisión, dificultades financieras y subsidios cuando corresponden.
 Procedimiento. Es útil si la deuda cambia materialmente en el tiempo.
 Error típico. Sumar un escudo tributario ya incorporado en una tasa después de impuestos.
 Beta desapalancada y reapalancada
 βA = βE / [1 + (1-T)D/E] | βE = βA[1 + (1-T)D/E]
 Qué responde. Traslada riesgo operativo entre empresas o estructuras de capital.
 Variables. La versión supone deuda con beta cercana a cero; si no, debe ajustarse.
 Procedimiento. Desapalanca comparables, promedia con criterio y reapalanca a estructura objetivo.
 Error típico. Combinar D/E contable con beta de mercado o ignorar diferencias de negocio.
 Equivalente cierto
 Valor = CE(CFt) / (1 + Rf)t
 Qué responde. Convierte un flujo riesgoso en monto cierto equivalente y lo descuenta a tasa segura.
 Variables. CE refleja aversión al riesgo y distribución; no es simplemente el flujo esperado.
 Procedimiento. Usa este método o descuento ajustado por riesgo, evitando castigar el riesgo dos veces.
 Error típico. Reducir el flujo por riesgo y además usar una tasa con prima completa.
Examen de Grado UC | materia, preguntas y respuestas 23

[pág. 24]
Finanzas - versión clara y reordenada
 6. Capital de trabajo y finanzas internacionales
 Las fórmulas de este bloque comparten unidades y supuestos que deben declararse antes de
 calcular.
 Ciclo de conversión de caja
 CCC = Días + Días - Días
 inventario cobro pago
 Qué responde. Tiempo neto que el efectivo queda comprometido en operación.
 Variables. Cada componente debe usar bases coherentes: inventario/costo, cuentas por cobrar/ventas, cuentas
 por pagar/compras.
 Procedimiento. Compara tendencia y causa; un CCC menor puede venir de eficiencia o de tensionar proveedores.
 Error típico. Mezclar saldos finales con flujos de períodos distintos.
 Lote económico de compra
 EOQ = √(2DS / H)
 Qué responde. Cantidad por pedido que equilibra costo de ordenar y mantener inventario.
 Variables. D es demanda anual; S, costo por pedido; H, costo anual de mantener una unidad.
 Procedimiento. Verifica supuestos de demanda estable, reposición y ausencia de quiebres.
 Error típico. Usar porcentajes de costo de mantener sin convertirlos a moneda por unidad y año.
 Modelo de Baumol para efectivo
 C* = √(2FT / i)
 Qué responde. Transferencia óptima entre inversiones líquidas y caja bajo uso predecible.
 Variables. F es costo fijo por transferencia; T, necesidad total de efectivo; i, costo de oportunidad.
 Procedimiento. Interpreta como referencia: incertidumbre y límites de saldo requieren modelos más ricos.
 Error típico. Aplicarlo cuando los flujos son muy volátiles sin reconocer el supuesto.
Examen de Grado UC | materia, preguntas y respuestas 24

[pág. 25]
Finanzas - versión clara y reordenada
 Costo anual de no tomar descuento
 Costo ≈ [d/(1-d)] × [365/(N-n)]
 Qué responde. Costo implícito aproximado de pagar tarde en términos de crédito comercial d/n, neto N.
 Variables. d es descuento; n, día con descuento; N, vencimiento normal.
 Procedimiento. Compara con costo marginal de financiamiento y capacidad de pago.
 Error típico. Tratar el descuento perdido como porcentaje pequeño sin anualizar.
 Paridad cubierta de tasas
 F0 / S0 = (1 + rdoméstica)T / (1 + rextranjera)T
 Qué responde. Forward de no arbitraje entre dos monedas bajo inversión cubierta.
 Variables. S_0 y F_0 deben usar la misma convención de cotización; tasas comparten plazo y capitalización.
 Procedimiento. Construye dos estrategias que terminan en la misma moneda y fecha.
 Error típico. Invertir numerador por cambiar la convención de pesos por dólar a dólares por peso.
 Capital de trabajo neto
 CTN = Activoscorrientesoperativos - Pasivoscorrientesoperativos
 Qué responde. Recursos netos invertidos en la operación de corto plazo.
 Variables. En valoración suele excluir caja excedente y deuda financiera de corto plazo.
 Procedimiento. Un aumento de CTN consume FCFF; una liberación lo aumenta.
 Error típico. Confundir saldo de CTN con variación de CTN en el flujo.
 Finanzas · preparación del Examen de Grado
 UC 2027
 Examen de Grado de Ingeniería Comercial UC · enero de 2027
 Este manual contiene 70 preguntas históricas de Finanzas: 35 de Teoría Financiera y 35 de
 Dirección Financiera. Enseña ambas materias desde los conceptos iniciales hasta su aplicación y
 discusión crítica; las dos tienen el mismo estándar y profundidad. Las preguntas históricas aparecen
 después del desarrollo; las respuestas modelo se incorporarán únicamente como propuestas no
 oficiales cuando no exista pauta confiable.
Examen de Grado UC | materia, preguntas y respuestas 25

[pág. 26]
Finanzas - versión clara y reordenada
 Cómo usar este manual
 El calendario organiza el foco, no el estándar académico. Octubre prioriza Marketing; noviembre,
 Finanzas junto con repaso de Marketing; diciembre, Dirección junto con repaso de las otras dos; y
 fines de diciembre/enero integran las tres en simulaciones. Marketing, Finanzas y Dirección
 mantienen igual profundidad, análisis, cuidado y objetivo de Distinción.
 Estudia cada capítulo en tres pasadas: comprende la intuición, reconstruye
 fórmulas/procedimientos sin mirar y resuelve ejercicios explicando unidades y decisión. En
 finanzas, escribir el supuesto y la línea de tiempo es parte de la solución. No memorices una
 respuesta numérica sin saber qué tasa, moneda, fecha y riesgo la producen.
 Mapa del ramo
 Sección Unidad Capacidades que se desarrollan
 Teoría Financiera Valor del dinero y tasas Capitalizar, descontar, convertir tasas
 y valorar anualidades
 Teoría Financiera Bonos y tasas de interés Precio, yield, curva, forwards,
 duración y riesgo
 Teoría Financiera Riesgo y portafolios Covarianza, diversificación, CAPM,
 beta y cobertura
 Teoría Financiera Derivados y mercados Payoffs, replicación, no arbitraje,
 eficiencia y APT
 Dirección Financiera Inversión y VAN Flujos incrementales, impuestos,
 capital de trabajo y terminal
 Dirección Financiera Costo de capital WACC, costo de equity, APV y riesgo
 de proyecto
 Dirección Financiera Liquidez y financiamiento Ciclo de caja, deuda, dividendos,
 estructura y covenants
 Dirección Financiera Valoración y decisiones DCF, sinergias, pérdidas tributarias,
 sensibilidad y recomendación
 Marco común para resolver problemas
 Empieza identificando fecha de valorización, unidad monetaria, flujos (monto y fecha), tasa
 adecuada y riesgo. Dibuja la línea de tiempo. Mantén consistencia: flujos nominales con tasa
 nominal; flujos reales con tasa real; después de impuestos con tasa acorde; pesos con pesos. El
 valor es la suma de flujos futuros descontados por tasas que reflejan su riesgo. La tasa no es un
 «castigo» arbitrario: representa costo de oportunidad/compensación exigida.
 Para recomendar, separa creación de valor del reparto de valor. VAN positivo puede crear valor,
 pero no significa que el financiamiento sea inocuo, la empresa tenga liquidez suficiente o la decisión
 sea viable. NPV y riesgo, liquidez, covenants, incentivos, impuestos y restricciones pueden conducir
 a decisiones distintas.
Examen de Grado UC | materia, preguntas y respuestas 26

[pág. 27]
Finanzas - versión clara y reordenada
 PARTE I - TEORÍA FINANCIERA
 1. Valor del dinero en el tiempo
 Un peso hoy puede invertirse. Con tasa efectiva (r) por periodo, (FV_n=PV(1+r)^n), y
 (PV=FV_n/(1+r)^n). Para tasa nominal anual (j), capitalizable (m) veces: tasa efectiva anual
 (=(1+j/m)^m-1). Asegura que (n) esté expresado en periodos consistentes con la tasa.
 Perpetuidad constante a partir del próximo periodo: (P=C/r). Anualidad vencida:
 (PV=C[1-(1+r)^-n]/r). Perpetuidad creciente: (P_0=C_1/(r-g)), si (r>g) y el crecimiento es sostenible.
 Si el primer pago es hoy, sepáralo: (PV=C_0+PV) de flujos futuros. No apliques fórmula perpetua a
 flujos irregulares sin justificar normalización.
 2. Bonos, curva y riesgo de tasa
 Precio de bono = suma de cupones y principal descontados por rendimiento requerido compatible
 con plazo, moneda y riesgo. Precio y yield se mueven inversamente. Cupón alto no implica yield
 alto: precio también importa. Bono bajo par tiene cupón relativo menor que el yield, bajo
 condiciones usuales.
 Spot (s_n) descuenta un flujo único al vencimiento (n). Forwards implícitas satisfacen, por no
 arbitraje,
 (1+s_n)^n=(1+s_k)^k(1+f_k,n)^n-k.
 La forward es tasa implícita en precios de hoy; no es pronóstico puro sin supuestos sobre primas
 por plazo/riesgo. Comparar rollover corto y deuda larga requiere valor presente, riesgo de
 refinanciamiento y escenario de tasas futuras.
 Duración Macaulay es vencimiento promedio ponderado por valores presentes de flujos; duración
 modificada aproxima sensibilidad: Δ P/P ≈ -D_modΔ y. Convexidad mejora aproximación para
 cambios mayores. Un pago temprano reduce duración manteniendo otros rasgos; vencimiento final
 y duración no son sinónimos.
 Spread frente a benchmark puede reflejar crédito, liquidez, impuestos, opciones, moneda y primas
 de plazo. No llames arbitraje a mayor yield sin comparar riesgo y flujos.
 3. Riesgo, portafolios y CAPM
 Rendimiento esperado de portafolio es suma ponderada: (E[R_p]=Σ_iw_iE[R_i]), con pesos que
 suman uno. Varianza incorpora covarianzas: (σ_p^2=Σ_iw_i^2σ_i^2+2Σ_i<jw_iw_jCov(R_i,R_j)). La
 diversificación reduce riesgo idiosincrático cuando correlaciones son imperfectas; no elimina riesgo
 sistemático. El efecto de un activo depende de su covarianza con el portafolio, no solo de su
 volatilidad individual.
 CAPM: (E[R_i]=R_f+β_i(E[R_m]-R_f)), (β_i=Cov(R_i,R_m)/Var(R_m)). Beta mide exposición
 sistemática al benchmark, no volatilidad total ni calidad de empresa. El costo de equity CAPM
 requiere tasa libre de riesgo coherente en plazo/moneda y prima de mercado en misma moneda y
 horizonte. En un problema de cobertura (p. ej. pasivo en moneda extranjera), minimiza varianza del
 resultado total activos-pasivos: incorpora varianzas y covarianza; elegir el activo de menor varianza
Examen de Grado UC | materia, preguntas y respuestas 27

[pág. 28]
Finanzas - versión clara y reordenada
 aislado puede empeorar el hedge.
 4. Derivados y opciones
 Una opción call da derecho, no obligación, a comprar por (K); put a vender por (K), antes/en fecha
 según estilo. Payoffs al vencimiento: call max(S_T-K,0), put max(K-S_T,0). Beneficio resta prima y
 considera financiamiento. Posición larga limita pérdida a prima; posición corta puede tener pérdida
 importante.
 Paridad put-call europea sin dividendos: (C+PV(K)=P+S_0), bajo mismos (K,T), tasas y posibilidad
 de arbitraje/fricciones suficientemente pequeñas. Para replicación/binomial descuenta según
 medida neutral al riesgo; probabilidad neutral no es pronóstico real. Una opción de venta puede
 cubrir caída de precio con costo de prima; futuros fijan precio y también sacrifican upside.
 4A. Activos contingentes, cartera eficiente y APT
 Un activo Arrow-Debreu paga una unidad solo en un estado futuro determinado. Si los estados son
 mutuamente excluyentes y exhaustivos, el precio actual de un flujo contingente es la suma de sus
 pagos por el precio de cada estado. Replicación/arbitraje restringen esos precios; precios de estado
 positivos descartan carteras que garantizan pagos negativos sin compensación. En modelos
 binomiales, la probabilidad neutral al riesgo es un instrumento de valoración derivado de precios, no
 la creencia subjetiva del mercado.
 La frontera eficiente media-varianza reúne carteras que, para una rentabilidad esperada dada,
 minimizan varianza (o, de forma equivalente, maximizan retorno para riesgo dado). Con activo libre
 de riesgo, la combinación óptima depende de aversión al riesgo; la cartera tangente maximiza
 Sharpe (E[R_p]-R_f)/σ_p. En CAPM, la línea del mercado de capitales describe carteras eficientes
 totales; la línea del mercado de valores relaciona retorno esperado y beta sistemática para todos los
 activos.
 APT permite varios factores sistemáticos: R_i-R_f=α_i+Σ_kβ_ikF_k+epsilon_i. En equilibrio sin
 arbitraje, la prima esperada queda explicada por exposiciones a factores y sus primas:
 E[R_i]-R_f=Σ_kβ_ikλ_k. Los factores requieren justificación y estimación; «multifactor» no significa
 incluir variables indiscriminadamente. El riesgo idiosincrático diversificable no genera prima en una
 cartera suficientemente diversificada bajo los supuestos del modelo.
 5. Eficiencia, arbitraje y retornos
 El precio refleja información disponible en algún grado; eficiencia débil/semi-fuerte/fuerte define
 conjunto informativo y no garantiza precio «correcto» bajo incertidumbre. Arbitraje clásico es cartera
 con costo inicial nulo/positivo favorable y payoff no negativo en todos los estados y positivo en
 algún estado, con supuestos sobre venta corta, financiamiento y ejecución. Una oportunidad
 aparente puede ser riesgo no modelado, iliquidez, impuestos o restricción.
 Complemento docente: Teoría Financiera
 TF01. Retornos, tasas e índices: medir antes de comparar
 Fuente: Finanzas I Caro, pp. 2-3. Complemento de aplicación: fuente de examen
 EDG_E_2009-2026_OCR.pdf, pp. 195-196, comparación de rendimientos nominales y reales.
Examen de Grado UC | materia, preguntas y respuestas 28

[pág. 29]
Finanzas - versión clara y reordenada
 Una inversión produce riqueza mediante pagos y cambios de precio. Si se compra a P0, se cobra
 un dividendo D y se vende a P1, el retorno total simple es R = (P1-P0+D)/P0. Separar sus dos
 partes ayuda a interpretar el resultado: D/P0 es rendimiento por distribución y (P1-P0)/P0 es
 ganancia de capital. Una acción comprada a 100, vendida a 108 y con dividendo 2 entrega 10%, no
 8%. La base de comparación es el dinero comprometido, no el precio final.
 Para llevar riqueza entre fechas se multiplican factores: W2 = W0(1+R1)(1+R2). Por eso no se
 suman retornos simples de períodos consecutivos. Si un activo sube 20% y después baja 20%, 100
 se convierten en 120 y luego en 96: retorno acumulado -4%. Su media aritmética es cero, pero su
 retorno geométrico por período es √0,96-1 = -2,020410%. La media aritmética sirve para un retorno
 esperado de un período; la geométrica resume crecimiento compuesto de una trayectoria. No son
 intercambiables.
 El retorno logarítmico r = ln(1+R) tiene la propiedad de sumar a lo largo del tiempo: ln(W2/W0) =
 r1+r2. En el ejemplo, ln(1,2)+ln(0,8)=ln(0,96)=-0,040822. Esto no equivale a un retorno simple de
 -4,0822%: para volver a retorno simple se calcula exp(r)-1. Una media de logaritmos no se usa
 como si fuera directamente el promedio aritmético del retorno simple.
 Una tasa solo adquiere significado con su período y convención. Si 12% es nominal anual
 convertible mensualmente, cada mes rinde 1%; la tasa efectiva anual es 1,01^12-1 = 12,682503%.
 Si 12% es efectiva anual, la efectiva mensual es 1,12^(1/12)-1 = 0,948879%. Ambos contratos
 dicen «12% anual», pero producen cajas distintas. Para un año de 360 días, la tasa diaria
 compatible con una efectiva anual k es (1+k)^(1/360)-1; k/360 corresponde a una convención
 nominal diferente.
 La inflación exige distinguir unidades monetarias de poder de compra. La relación exacta de Fisher
 es 1+r_nominal = (1+r_real)(1+π). Con 10% nominal y 6% inflación, r_real = 1,10/1,06-1 =
 3,773585%, no 4% exacto. Se descuentan flujos nominales con tasa nominal y flujos en moneda
 constante con tasa real. Un bono en UF protege una unidad indexada según sus reglas, pero puede
 tener riesgo de precio si cambia su rendimiento real exigido; indexado no significa que su precio de
 mercado sea constante.
 Un índice resume una cartera y su ponderación importa. En un índice de dos acciones ponderado
 por precio, acciones que valen 10 y 90 pesan 10% y 90% aun cuando la primera empresa sea más
 grande. Si sus retornos son 10% y cero, el índice sube 1%. En una cartera igualmente ponderada,
 sube 5%. En una cartera ponderada por capitalización, se necesitan además las acciones en
 circulación: una empresa con precio 10 y 100 títulos tiene valor 1.000; otra con precio 90 y 10 títulos
 tiene valor 900. La primera pesa 52,6316% y el retorno del índice es 5,2632%. Ajustes de divisor
 evitan que un split se interprete como pérdida; un índice de precio y uno de retorno total difieren por
 el tratamiento de dividendos.
 Cómo resolver. Anota moneda, fechas, dividendos y unidad temporal. Construye primero factores
 de riqueza; después transforma la tasa a la periodicidad de los flujos. Si se comparan inversiones,
 exige igual moneda, plazo y tratamiento tributario, y distingue rendimiento esperado de realizado.
 Un mayor porcentaje en una unidad diferente no demuestra una mejor inversión.
 TF02. Incertidumbre y preferencias: por qué una media no basta
 Fuente: Finanzas I Caro, pp. 11-12.
Examen de Grado UC | materia, preguntas y respuestas 29

[pág. 30]
Finanzas - versión clara y reordenada
 Cuando el futuro tiene varios estados, una inversión es una distribución de riqueza. Su media
 resume el promedio ponderado; su varianza resume dispersión, pero ninguna de ellas dice sola
 cuánto desea el inversionista esa distribución. La utilidad esperada representa preferencias:
 E[u(W)] = Σp_s u(W_s), con probabilidades que suman uno. Se aplica utilidad a cada riqueza
 posible y luego se promedia; en general E[u(W)] no es u(E[W]).
 Una persona que valora más riqueza tiene u'(W)>0. Si además es aversa al riesgo, u''(W)<0: su
 utilidad crece, pero a una tasa marginal decreciente. La concavidad no significa que la utilidad
 disminuya al aumentar la riqueza. Con esa curvatura, una pérdida pesa más que una ganancia de
 igual tamaño alrededor del mismo nivel de riqueza. Jensen expresa el resultado: E[u(W)] ≤ u(E[W]).
 Ejemplo resuelto. Dos estados igualmente probables entregan riqueza 80 o 120. La media es 100.
 Con utilidad u(W)=√W, utilidad esperada = (√80+√120)/2 = 9,949362. El equivalente cierto CE es la
 riqueza segura que produce esa utilidad: √CE=9,949362, por lo que CE = 98,989795. La prima de
 riesgo monetaria es E[W]-CE = 1,010205. Esta persona es indiferente entre el sorteo y recibir
 98,989795 con certeza; pagar 100 por el sorteo cuando existe una alternativa segura de 100 no le
 conviene. La prima de riesgo de preferencias no debe confundirse con el retorno excedente de
 equilibrio de un activo.
 La aversión absoluta al riesgo es ARA(W)=-u''(W)/u'(W). Mide curvatura respecto de cambios
 monetarios de tamaño fijo. La aversión relativa es RRA(W)=W×ARA(W), adecuada para riesgos
 que escalan con la riqueza. Para √W, u'=1/(2√W), u''=-1/(4W^(3/2)); por tanto ARA=1/(2W) y
 RRA=1/2. La aversión absoluta cae cuando crece W, mientras la relativa permanece constante. No
 son dos etiquetas del mismo número.
 Para riesgos pequeños y media μ_W, una expansión de Taylor da una aproximación útil: prima de
 riesgo ≈ ½ ARA(μ_W) Var(W). En el ejemplo, Var(W)=400 y ARA(100)=0,005, de modo que prima ≈
 ½×0,005×400=1, cercana a 1,010205. La aproximación pierde precisión si hay colas extremas,
 variaciones grandes o una utilidad cuyo dominio excluye algunas riquezas.
 En ejercicios de cartera se usa a menudo una representación media-varianza U = E[R]-(A/2)Var(R),
 con A>0. Si una cartera ofrece media 12% y volatilidad 20%, y otra media 8% y volatilidad 10%, sus
 utilidades son 0,12-0,02A y 0,08-0,005A. La primera se prefiere si 0,04>0,015A, es decir
 A<2,666667. Con A=4 la segunda es preferible. Si las cifras se introducen como «12» y «20» en
 lugar de 0,12 y 0,20, A necesita una escala compatible; mezclar escalas cambia el resultado.
 Esto explica por qué un mayor Sharpe no necesariamente ordena dos inversiones si se exige
 invertir 100% en una sola y no se permite ajustar el riesgo con un activo seguro. El Sharpe compara
 retorno excedente por volatilidad; las preferencias comparan utilidades de las carteras realmente
 disponibles. Una cartera dominada en media y varianza puede descartarse para una persona
 media-varianza aversa al riesgo, pero si una tiene mayor media y mayor riesgo se necesita su A o
 una condición explícita de indiferencia.
 Cómo interpretar. Calcula distribución, media, varianza y equivalente cierto en unidades
 consistentes. Luego explica qué pérdida segura aceptaría la persona para evitar el riesgo. La
 solución debe identificar las preferencias o dejar la recomendación condicionada; «más rentable»
 no equivale a «preferida por todos».
Examen de Grado UC | materia, preguntas y respuestas 30

[pág. 31]
Finanzas - versión clara y reordenada
 TF03. Arbitraje, réplica y precios de estado
 Fuente: Finanzas I Caro, pp. 4-5.
 La valoración por no arbitraje compara flujos idénticos. Una oportunidad de arbitraje tiene una
 inversión inicial no positiva, pagos futuros nunca negativos y alguna ganancia estricta al inicio o en
 un estado con probabilidad positiva. La definición requiere considerar todos los pagos y
 obligaciones; comprar barato y vender caro con una posición expuesta a una caída no basta.
 Si dos carteras entregan exactamente el mismo flujo en todos los estados y fechas, deben tener el
 mismo precio en un mercado sin fricciones que permita las transacciones necesarias. Si A cuesta
 95 y B cuesta 100, pero ambas pagan 110 seguro en un año, comprar A y vender B en corto
 produce +5 hoy y cero neto futuro. En la realidad, límites al préstamo de títulos, garantías y costos
 pueden impedir implementar la estrategia; la igualdad es una restricción del modelo, no una
 promesa de ejecución ilimitada.
 Un activo Arrow-Debreu paga una unidad solo en un estado. Su precio q_s convierte ese pago
 contingente a valor actual. Si existe un precio por estado, un activo con pagos X_s vale P=Σq_s
 X_s. Los q_s no son probabilidades físicas: incorporan cuánto vale recibir dinero en cada estado.
 Las probabilidades físicas se usan para promediar resultados; los precios de estado se usan para
 valorar.
 Ejemplo de dos estados. Un bono paga 1 en ambos estados y cuesta 1/1,05=0,952381. Una
 acción cuesta 100 y paga 120 en el estado alto y 80 en el bajo. Los precios de estado satisfacen:
 q_alto+q_bajo=0,952381; 120q_alto+80q_bajo=100.
 Restando 80 veces la primera ecuación a la segunda: 40q_alto=23,809524. Así, q_alto=0,595238 y
 q_bajo=0,357143. Un contrato que paga 30 solo en el estado bajo vale 30×0,357143 = 10,714286.
 El precio alto mayor no afirma que su probabilidad física sea mayor: el sistema se deriva de precios
 negociados, sin una estimación de esas probabilidades.
 También puede replicarse el contrato. Se busca una cantidad Δ de acciones y B invertido hoy en el
 bono: 120Δ+1,05B=0 y 80Δ+1,05B=30. La resta da Δ=-0,75; entonces B=85,714286. Precio de
 réplica = -75+85,714286 = 10,714286. En el estado alto, -90+90=0; en el bajo, -60+90=30. Vender
 0,75 acciones e invertir lo recibido junto al costo del contrato produce sus pagos exactos.
 Un mercado es completo si los activos permiten replicar cualquier vector de pagos entre los estados
 considerados. Se necesitan suficientes vectores de pagos linealmente independientes; contar
 títulos sin revisar independencia no basta. En el ejemplo, bono y acción abarcan dos estados. Un
 mercado incompleto puede carecer de oportunidades de arbitraje: la incompletitud indica que
 algunos pagos no tienen réplica única, no que exista una ganancia gratuita. Este matiz corrige una
 simplificación del resumen fuente.
 Los precios de estado estrictamente positivos y consistentes con los activos observados impiden
 que una cartera no negativa y no nula tenga precio no positivo en el modelo finito apropiado. Si el
 sistema requiere un precio negativo, se debe buscar una cartera que haga visible la contradicción;
 un número negativo aislado no reemplaza la prueba de flujos y las condiciones de mercado.
 Cómo resolver. Escribe una tabla de estados y pagos, ubica la inversión inicial y resuelve el
 sistema de réplica. Verifica la igualdad en cada estado. Después explica el arbitraje si el precio de
 mercado difiere: qué compras, qué vendes, cuánto recibes hoy y por qué las obligaciones futuras se
Examen de Grado UC | materia, preguntas y respuestas 31

[pág. 32]
Finanzas - versión clara y reordenada
 cancelan. Ese calendario convierte una fórmula en una demostración.
 TF04. Diversificación y frontera eficiente
 Fuente: Finanzas I Caro, pp. 13-17.
 Una cartera distribuye riqueza entre activos. Si las ponderaciones w_i suman uno, el retorno es
 R_p=Σw_iR_i y la media es E[R_p]=Σw_iμ_i. La varianza exige considerar cómo se mueven juntos:
 Var(R_p)=Σ_iΣ_j w_iw_j Cov(R_i,R_j). La diversificación aparece en esas covarianzas, no en el
 mero número de nombres de una cartera.
 Con dos activos, σ_p²=w²σ_A²+(1-w)²σ_B²+2w(1-w)ρσ_Aσ_B. Si ρ<1, combinar puede reducir
 volatilidad respecto del promedio de volatilidades. La reducción no garantiza eliminar todo riesgo: el
 componente común puede permanecer aun con muchos activos. Si ρ=1 y solo se permiten
 posiciones largas, la volatilidad es wσ_A+(1-w)σ_B; no existe un beneficio de diversificación sobre
 ese promedio. Si ρ=-1, σ_p=|wσ_A-(1-w)σ_B|, que se anula para w=σ_B/(σ_A+σ_B).
 Ejemplo resuelto. A tiene media 10% y volatilidad 20%; B, media 6% y volatilidad 10%; correlación
 cero. Para w=0,5, media = 8% y varianza = 0,25×0,04+0,25×0,01=0,0125. Volatilidad =
 11,180340%, menor que la volatilidad media de 15%.
 Para encontrar la cartera de mínima varianza se deriva respecto de w. La condición es
 2wσ_A²-2(1-w)σ_B²+2(1-2w)Cov(A,B)=0. Por tanto:
 w_A,GMV = [σ_B²-Cov(A,B)]/[σ_A²+σ_B²-2Cov(A,B)].
 En el ejemplo, w_A=0,01/0,05=0,20; B pesa 0,80. Su media es 6,8%, varianza 0,008 y volatilidad
 8,944272%. Esta cartera minimiza riesgo, pero no es la preferida por toda persona: quien valore un
 retorno mayor puede aceptar más volatilidad en otra cartera eficiente.
 Una cartera es eficiente si ninguna cartera factible ofrece media igual o mayor con varianza igual o
 menor y al menos una mejora estricta. La frontera de mínima varianza tiene una rama inferior que
 no es eficiente: con igual riesgo puede existir una cartera con mayor media en la rama superior. En
 el ejemplo, w_A=0 produce media 6% y volatilidad 10%; w_A=0,4 produce media 7,6% y volatilidad
 también 10%. La segunda domina a la primera, de modo que «estar sobre la curva de mínima
 varianza para algún retorno» no equivale automáticamente a eficiencia.
 Si se prohíbe vender en corto, debe imponerse 0≤w≤1. Un óptimo calculado fuera de ese intervalo
 no es factible; se revisan fronteras. Con más activos, la versión matricial minimiza w'Σw sujeto a
 1'w=1 y μ'w=m. Σ contiene las covarianzas; las restricciones de apalancamiento, concentración y
 liquidez cambian el conjunto disponible. Una solución algebraica sin reconocer estas restricciones
 puede ser inviable.
 La contribución de un activo al riesgo depende de Cov(R_i,R_p). Por eso un activo de alta
 volatilidad puede mejorar una cartera si tiene covarianza baja o negativa con ella. Un fondo que
 debe cubrir una obligación futura no necesariamente busca minimizar varianza de sus retornos
 solos: también importa su covarianza con el ingreso o el pasivo. En el caso fiscal, si gasto
 G=I+F(1+R_p), Var(G)=Var(I)+F²Var(R_p)+2F Cov(I,R_p). Omitir el último término pierde la función
 de cobertura.
 Cómo interpretar. Presenta media y volatilidad de la mezcla, indica restricciones y muestra cuál
 cartera se descarta por dominancia. Luego explica qué riesgo se elimina, qué riesgo permanece y
Examen de Grado UC | materia, preguntas y respuestas 32

[pág. 33]
Finanzas - versión clara y reordenada
 por qué la preferencia personal aún importa. «Más diversificada» debe traducirse a una covarianza
 y una reducción de riesgo concreta.
 TF05. Activo seguro, cartera tangente y CAPM
 Fuente: Finanzas I Caro, pp. 18-28.
 Agregar un activo seguro permite ajustar la cantidad de riesgo sin cambiar necesariamente la
 composición interna de la cartera riesgosa. Si la tasa segura es r_f y se invierte una fracción y en
 una cartera P, R_c=(1-y)r_f+yR_p. Media = r_f+y(μ_p-r_f) y volatilidad = |y|σ_p. Para y entre cero y
 uno se presta parte de la riqueza al activo seguro; y>1 implica pedir prestado para invertir más de la
 riqueza propia; y<0 implica una posición corta en P. La recta de asignación de capital tiene
 pendiente Sharpe_P=(μ_p-r_f)/σ_p para su rama larga.
 Ejercicio de asignación. P ofrece media 10%, volatilidad 20%, y el depósito rinde 3%. El
 inversionista maximiza U=μ_c-Aσ_c²/2, con A=4. Sustituyendo, U=0,03+0,07y-(4/2)(0,04)y². La
 derivada 0,07-0,16y se anula en y=0,4375. Invierte 43,75% en P y 56,25% en depósito. Media =
 6,0625% y volatilidad = 8,75%. Si A baja a 1, el óptimo sin restricciones es y=1,75: se financia 75%
 adicional mediante préstamo. Si el contrato impide endeudarse, el óptimo debe limitarse al conjunto
 permitido, en este caso y≤1.
 Si puede elegir entre todas las carteras riesgosas y prestar y endeudarse a la misma tasa, la cartera
 tangente maximiza Sharpe. La separación en dos fondos dice que primero se identifica la
 composición riesgosa óptima y luego cada persona ajusta y según sus preferencias. No dice que
 todos posean el mismo porcentaje de acciones. Si tasas de préstamo y depósito difieren o hay
 restricciones, la separación simple deja de ser exacta.
 El CAPM añade equilibrio: bajo decisiones media-varianza, expectativas homogéneas, activos
 negociables y mercado sin las fricciones que el modelo excluye, la cartera tangente agregada es la
 cartera de mercado. El retorno esperado exigido a un activo i es μ_i=r_f+β_i(μ_m-r_f), con
 β_i=Cov(R_i,R_m)/Var(R_m). La intuición está en el riesgo marginal: un activo que paga poco
 cuando la cartera de todos pierde requiere una prima mayor; la parte propia de su volatilidad que se
 diversifica no obtiene una prima adicional en este modelo.
 Ejercicio CAPM y descomposición. Tasa segura 3%, prima de mercado 6%, beta de la acción
 1,2: retorno requerido = 10,2%. Si el retorno esperado estimado es 11%, su alpha respecto de ese
 modelo es +0,8 puntos. Eso es una comparación condicionada a las estimaciones y a la validez del
 CAPM, no una certeza de ganancia ni una demostración libre de riesgo. Si σ_m=10% y σ_i=20%,
 bajo R_i=α+βR_m+ε y Cov(ε,R_m)=0, varianza sistemática = 1,2²×0,1²=0,0144; residual =
 0,04-0,0144=0,0256. El riesgo residual tiene volatilidad 16% y R²=0,0144/0,04=36%. Beta 1,2 no
 significa que cada variación de precio de la acción sea exactamente 1,2 veces la del mercado.
 La línea del mercado de capitales relaciona media y volatilidad para carteras eficientes que
 combinan mercado y activo seguro. La línea del mercado de valores relaciona retorno esperado y
 beta para activos o carteras, sean eficientes o no. Una acción individual puede quedar fuera de la
 primera por tener riesgo residual y, a la vez, sobre la segunda si está bien valorada según CAPM.
 La prima de mercado no es el retorno total del mercado. Si μ_m=9% y r_f=3%, la prima es 6%, no
 9%. Tampoco se deben usar tasa libre anual y prima mensual en una misma suma. Con deuda, el
 beta del patrimonio cambia porque los accionistas reciben el residual más apalancado; el beta
Examen de Grado UC | materia, preguntas y respuestas 33

[pág. 34]
Finanzas - versión clara y reordenada
 operativo del activo se distingue del de la acción. Esa distinción se desarrolla en TF12 y DF09.
 Cómo responder. Identifica cartera, restricciones y periodicidad; calcula Sharpe, asignación o beta
 según la pregunta. Explica qué riesgo remunera el modelo y cuándo la conclusión queda
 condicionada. Una cartera de mayor media puede necesitar menor ponderación si sube también su
 varianza o la aversión del inversionista.
 TF06. Modelos multifactoriales e interpretación de regresiones
 Fuente: Finanzas I Caro, pp. 29-31; discusión de contrastación del CAPM en pp. 27-28.
 Una regresión de retornos describe relaciones estadísticas; un modelo de valoración agrega una
 hipótesis acerca de qué exposiciones requieren remuneración. En un modelo de factores,
 R_i-r_f=α_i+Σβ_ik F_k+ε_i. Los F_k son retornos o shocks definidos por el modelo, β_ik son
 sensibilidades y ε_i es el componente no explicado. Si E[F_k]=λ_k, una condición de valoración sin
 alpha dice E[R_i]-r_f=Σβ_ikλ_k. No se debe confundir el valor realizado de un factor este mes con
 su prima esperada futura.
 La APT restringe precios mediante ausencia de arbitraje y diversificación de residuos en una
 economía con estructura factorial; no usa exactamente los mismos supuestos de preferencias y
 cartera de mercado que CAPM. Exige justificar cuáles factores representan riesgos sistemáticos y
 cómo se estiman sus primas. Llamarla simplemente «CAPM con más variables» oculta la diferencia
 entre una regresión empírica y una restricción económica de precios.
 Fama-French utiliza, además del mercado, factores relacionados con tamaño (SMB, pequeñas
 menos grandes) y valor (HML, alto menos bajo valor libro/mercado). Carhart añade un factor de
 momentum, construido con diferencias de desempeño pasado. Estas carteras de factores permiten
 medir exposiciones; sus primas no son garantizadas, y la construcción de cada mercado y muestra
 importa. «La empresa es pequeña» no reemplaza la estimación de su beta SMB, ni momentum
 significa que una acción que subió seguirá subiendo con certeza.
 Ejercicio de retorno requerido. r_f=2%; primas esperadas de mercado, SMB, HML y momentum =
 5%,2%,3%,4%. Una acción tiene sensibilidades 1,2;0,5;-0,3;0,4. Su retorno requerido bajo el
 modelo es 2%+1,2×5%+0,5×2%-0,3×3%+0,4×4% = 9,7%. El beta HML negativo reduce en 0,9
 puntos la prima neta del ejemplo porque se asocia con una prima positiva y exposición contraria. No
 se toman valores absolutos de los betas para forzar todas las contribuciones a ser positivas.
 Si un fondo obtuvo 12% cuando su combinación factorial implica 10%, el alpha de la muestra es 2
 puntos. Antes de atribuirlo a habilidad se necesitan frecuencia, errores estándar, costos y
 estabilidad. Un alpha mensual estimado 0,5% con error estándar 0,4% tiene t=1,25. Ese cociente
 por sí solo no ofrece evidencia fuerte contra alpha cero en una prueba bilateral convencional; se
 requieren grados de libertad y supuestos sobre errores para fijar el criterio exacto. No significativo
 no equivale a demostrado cero, y significativo no garantiza persistencia fuera de muestra.
 R² mide la fracción de variación explicada en la muestra. Un R² alto no prueba buen rendimiento ni
 que el modelo sea causal; un fondo índice puede tener R² alto y alpha neto negativo por costos. Un
 beta bien estimado tampoco identifica un retorno anormal seguro. Deben revisarse
 heterocedasticidad, dependencia temporal, factores omitidos, cambios de régimen y el uso de
 observaciones solapadas. Once ventanas que comparten gran parte de sus meses no equivalen a
 once experimentos independientes.
Examen de Grado UC | materia, preguntas y respuestas 34

[pág. 35]
Finanzas - versión clara y reordenada
 La crítica de Roll recuerda que probar CAPM implica también identificar la cartera de mercado
 relevante y verificar eficiencia de esa cartera. Si se utiliza un índice incompleto de activos
 negociables, un rechazo puede pertenecer al proxy, al CAPM o a ambas cosas. La misma
 prudencia se aplica a escoger retrospectivamente el benchmark que produzca el alpha más
 favorable.
 Cómo responder. Escribe modelo, periodicidad y significado de cada factor. Separa exposición
 estimada, prima esperada y retorno realizado; presenta alpha y su incertidumbre. Explica qué
 cambia al añadir factores y evalúa resultados después de costos y fuera de la muestra usada para
 diseñar la estrategia.
 TF07. Eficiencia, información y conducta del inversionista
 Fuente: Finanzas I Caro, pp. 32-33; señales informativas en pp. 41-43.
 Un precio eficiente incorpora la información pertinente disponible según una hipótesis y un modelo
 de riesgo. La forma débil considera información de precios y retornos pasados; la semifuerte, toda
 información pública; la fuerte agrega información privada. Son proposiciones distintas: que una
 noticia pública se incorpore rápidamente no significa que nadie pueda beneficiarse de información
 privada, ni que los precios conocidos de hoy sean los que se realizarán mañana.
 Eficiencia no exige precio constante, ausencia de volatilidad ni acertar el futuro. Una noticia cambia
 los flujos esperados, su riesgo o la tasa de descuento y puede causar un gran ajuste. Si un
 dividendo esperado es 10 perpetuo y la tasa exigida pasa de 10% a 12%, su valor cae de 100 a
 83,333333, aun sin cambiar el flujo esperado. En un modelo de crecimiento, cambios pequeños en
 k-g pueden producir movimientos aún mayores. Por eso una caída de 20% del precio no obliga a
 concluir que los flujos caen 20% para siempre.
 Ejercicio de anuncio y sorpresa. Un activo pagará en un mes 120 si se aprueba una autorización
 y 80 si se rechaza, sin otros riesgos ni descuento para este ejemplo. Hoy la probabilidad de
 aprobación es 75%, así que el precio es 0,75×120+0,25×80 = 110. Si se aprueba, sube a 120,
 retorno 9,090909%; si se rechaza, baja a 80, retorno -27,272727%. La media condicional del
 retorno es cero. La aprobación era más probable, pero no completamente cierta: puede generar un
 salto sin ineficiencia. Si la autorización ya tuviera probabilidad uno, su mera ocurrencia no
 justificaría una ganancia adicional por una noticia que no aporta información nueva.
 El rendimiento anormal se calcula contra un rendimiento esperado apropiado al riesgo y al
 horizonte. Si una acción de beta 0,8 cae 3% mientras el mercado cae 2%, y r_f del día es
 despreciable, el componente explicado es -1,6% y el residual es -1,4 puntos, no -1 punto. Un
 residual observado puede ser una sorpresa informativa; solo una rentabilidad predecible y
 explotable después de costos, con modelo y riesgo adecuados, cuestiona directamente la eficiencia
 correspondiente.
 Los sesgos conductuales ayudan a describir decisiones: exceso de confianza puede llevar a operar
 demasiado; anclaje mantiene una referencia de precio irrelevante; representatividad extrapola una
 muestra corta; aversión a pérdidas puede provocar retener perdedoras y vender ganadoras; efecto
 disposición no es lo mismo que aversión general al riesgo. Identificar un sesgo en una persona no
 basta para demostrar que todo el mercado tiene un precio explotable.
Examen de Grado UC | materia, preguntas y respuestas 35

[pág. 36]
Finanzas - versión clara y reordenada
 Los límites al arbitraje explican por qué un analista que cree detectar una desviación puede no
 corregirla: financiamiento limitado, imposibilidad de corto, riesgo de base, demora en la
 convergencia y posibilidad de que el precio se aleje más antes de ajustarse. Arbitraje sin riesgo,
 especulación y estrategia de valor son conceptos distintos. Un fondo puede perder solvencia
 durante una desviación aunque su valoración de largo plazo termine siendo correcta.
 Cómo responder. Identifica qué información era conocida antes, qué noticia llegó y cuál era la
 probabilidad incorporada. Distingue una explicación compatible con eficiencia de una prueba
 empírica de ineficiencia. No uses una recuperación posterior como evidencia automática de que la
 caída previa fue irracional: ese juicio conoce información que el mercado original aún no tenía.
 TF08. Bonos, curva de tasas y sensibilidad
 Fuente: Finanzas II Caro, pp. 40-41; aplicación de tasas cero cupón y forwards en la fuente de
 examen, pp. 96-97. Este desarrollo amplía la derivación resumida de duración del apunte.
 Un bono es un calendario contractual de pagos. El cupón indica cuánto paga, mientras el
 rendimiento exigido indica cuánto vale ese calendario hoy. Si el bono promete C_t en cada fecha y
 existen tasas spot z_t para cada plazo, P=ΣC_t/(1+z_t)^t. La tasa spot de dos años descuenta el
 pago de dos años; usarla para todos los pagos de un bono con cupón solo es coherente si se
 declara esa aproximación o una curva plana.
 Ejercicio con curva. Un bono de nominal 100 paga cupón 10 al cierre del primer año y 110 al
 segundo. Si z_1=4% y z_2=6%, P=10/1,04+110/1,06². Cada pago se descuenta por su
 vencimiento. La TIR o yield del bono es la única y que satisface P=10/(1+y)+110/(1+y)²; resume el
 precio, pero no reproduce necesariamente la curva spot. El cupón de 10% no es esa y si el precio
 difiere del nominal.
 La tasa forward de un período entre los años uno y dos satisface (1+z_2)²=(1+z_1)(1+f_1,2). Con la
 curva anterior, f=1,06²/1,04-1 = 8,038462%. La demostración compara invertir dos años hoy con
 invertir un año y contratar hoy la reinversión del siguiente. Si una estrategia fuese estrictamente
 más rentable y ambas tuvieran pagos seguros en la misma moneda, se compraría la barata y se
 financiaría con la cara. La forward es un precio actual de una operación futura; no es
 automáticamente una predicción insesgada de la tasa corta que se realizará, porque puede
 incorporar prima de plazo.
 Duración desde el precio. Con una curva plana y rendimiento efectivo anual y, P=ΣC_t(1+y)^-t.
 Derivando: dP/dy=-ΣtC_t(1+y)^-t-1. La duración Macaulay D_M=Σt VP(C_t)/P es el promedio
 temporal ponderado de pagos. La modificada D_mod=D_M/(1+y) satisface dP/P≈-D_mod dy. El
 signo negativo expresa que mayores tasas reducen precios. Un bono cero cupón tiene D_M igual a
 vencimiento; con cupones positivos, D_M suele ser menor porque devuelve caja antes.
 Para nominal 100, cupón anual 10, dos años y y=5%, precio = 109,297052. Pesos de VP: primer
 cupón 9,523810 y pago final 99,773243. D_M=(9,523810+2×99,773243)/109,297052=1,912863
 años; D_mod=1,821774. Ante un alza de un punto porcentual, dy=0,01, la caída aproximada es
 1,821774%, precio estimado 107,305906. El precio exacto a 6% es 107,333571. La diferencia surge
 de la curvatura positiva: agregar ½ convexidad×dy² mejora la aproximación. Introducir dy=1
 confunde un punto porcentual con un cambio de cien puntos.
Examen de Grado UC | materia, preguntas y respuestas 36

[pág. 37]
Finanzas - versión clara y reordenada
 Los bonos presentan riesgo de crédito, tasa, inflación, moneda, liquidez y reinversión de cupones.
 Un bono seguro al vencimiento puede ser riesgoso para quien debe venderlo antes. Duración
 aproxima un desplazamiento del rendimiento especificado; una curva que cambia de pendiente
 requiere analizar las exposiciones por vencimiento. Dos bonos con igual plazo no tienen
 necesariamente igual sensibilidad.
 Cómo resolver. Lista todos los cupones y el principal; calcula precio, pesos de valor presente y
 duración sin tratar un bono con cupón como cero cupón. Define el tamaño y tipo de shock. Explica
 si la pérdida es de precio al vender, de poder adquisitivo, de crédito o de una reinversión futura.
 TF09. Forwards, futuros y arbitraje de divisas
 Fuente: Finanzas I Caro, pp. 5-6. Se corrige la dirección de conversión de moneda que aparece
 invertida en la sección C del manual anterior.
 Un forward fija hoy un intercambio que se ejecutará en una fecha futura. Una posición larga sobre
 una unidad de activo paga S_T-K al vencimiento; la corta paga K-S_T. El precio de entrega justo F0
 se elige para que el contrato tenga valor inicial cero. Después de contratar, K permanece fijo,
 mientras el precio justo de un nuevo forward puede cambiar; «precio forward» y «valor actual del
 contrato antiguo» son cantidades diferentes.
 Para un activo sin pagos ni costos de tenencia, comprarlo hoy a S0 financiado a tasa r permite
 tenerlo en T, pero genera deuda S0(1+r)^T. Si un forward de compra fuese más caro, se compraría
 hoy el activo y se vendería forward; la igualdad sin arbitraje es F0=S0(1+r)^T. Dividendos conocidos
 se restan del spot por su VP antes de capitalizar; costos de almacenamiento y beneficios de
 tenencia requieren su tratamiento propio. Una convenience yield no es un dividendo cobrado en
 caja: resume el beneficio económico de disponer físicamente del activo bajo un modelo de carry.
 En divisas, define S0 como pesos por dólar y F0 en la misma cotización. Comprar un dólar cuesta
 S0 pesos, invertirlo produce (1+r_USD)^T dólares y venderlos a forward produce F0(1+r_USD)^T
 pesos. Invertir directamente S0 pesos produce S0(1+r_CLP)^T pesos. Igualando:
 F0=S0[(1+r_CLP)/(1+r_USD)]^T. Partiendo de un peso, la estrategia extranjera produce
 (F0/S0)(1+r_USD)^T pesos, no S0(1+r_USD)^T/F0. Escribir la unidad en cada conversión evita
 invertir la fórmula por memoria.
 Arbitraje completo. Spot 800 CLP/USD, tasas anuales 8% CLP y 4% USD, plazo un año. Forward
 justo = 800×1,08/1,04 = 830,769231 CLP/USD. Si el mercado ofrece vender dólares forward a 850
 y todas las operaciones son ejecutables a esas tasas, procede así:
 Fecha Operación Caja CLP Caja USD
 Hoy Pedir prestados pesos +800 0
 Hoy Comprar dólares -800 +1
 Hoy Invertir el dólar 0 -1
 Año 1 Cobrar inversión en 0 +1,04
 dólares
 Año 1 Entregar 1,04 USD al +884 -1,04
 forward a 850
Examen de Grado UC | materia, preguntas y respuestas 37

[pág. 38]
Finanzas - versión clara y reordenada
 Fecha Operación Caja CLP Caja USD
 Año 1 Pagar préstamo en pesos -864 0
 Neto +20 en año 1 0
 El neto inicial es cero y el pago final es seguro bajo los contratos supuestos. La moneda con mayor
 tasa puede cotizar con un descuento a plazo cuando se invierte la cotización; hay que expresar
 siempre qué moneda se encarece en qué unidad.
 Un futuro negocia contratos estandarizados y liquida pérdidas y ganancias diariamente mediante
 márgenes. Si una posición larga de 1.000 unidades entra a precio 100 y el futuro baja a 97, pierde
 3.000 ese día. Con margen inicial 5.000 y mantenimiento 3.000, la cuenta queda en 2.000; si la
 regla exige restaurar el inicial, la llamada de margen es 3.000, no 1.000. La diferencia entre forward
 y futuro no está en que uno pueda perder y el otro no: ambos tienen exposición; el calendario de
 caja, garantías y eventualmente la correlación con tasas importan.
 Cobertura exige calzar moneda, fecha y monto. Un exportador que venderá un millón de dólares
 puede vender ese millón a forward para fijar pesos. Si finalmente recibe solo medio millón, el
 contrato sigue obligándolo por el millón y deja media posición especulativa corta; una opción de
 venta de dólares compra un derecho, con prima, y no genera la misma obligación. Reducir
 variabilidad puede crear valor cuando evita insolvencia, financiamiento costoso o interrupciones; en
 mercados perfectos, los accionistas pueden ajustar por sí mismos riesgos negociables. Cubrir no
 demuestra que el precio final realizado será mejor que el precio sin cobertura.
 TF10. Opciones: pagos, paridad y árbol binomial
 Fuente: Finanzas I Caro, pp. 7-9.
 Una call concede derecho a comprar a K; su comprador recibe max(S_T-K,0). Una put concede
 derecho a vender a K; recibe max(K-S_T,0). El vendedor asume la obligación y cobra una prima al
 inicio. Una opción europea se ejerce solo al vencimiento; una americana permite hacerlo antes bajo
 sus condiciones. La posibilidad de no ejercer evita un pago de ejercicio desfavorable, pero el
 comprador todavía puede perder la prima pagada.
 Para una call comprada por c, el beneficio al vencimiento, sin capitalizar la prima, es
 max(S_T-K,0)-c; su breakeven es K+c. Para una put comprada por p es max(K-S_T,0)-p; el
 breakeven es K-p. El payoff excluye prima y el resultado económico la incluye. Si se quiere medir
 riqueza al vencimiento, se resta además el costo futuro de la prima, c(1+r)^T o p(1+r)^T, según la
 alternativa pertinente.
 La paridad europea sin dividendos compara dos carteras: acción + put versus call + bono que paga
 K. Ambas pagan max(S_T,K). Por no arbitraje, S0+P0=C0+K/(1+r)^T. La igualdad supone mismo
 subyacente, strike, vencimiento y condiciones, y las operaciones necesarias disponibles. No se
 aplica sin ajustes a opciones americanas o a una acción que distribuye dividendos. La probabilidad
 física de una subida no es la que determina directamente esta identidad.
 Ejemplo binomial de una call. S0=100; en un año puede valer 120 o 80; K=100; tasa segura 5%.
 La call paga 20 o cero. Una réplica de Δ acciones más B en el activo seguro satisface
 120Δ+1,05B=20 y 80Δ+1,05B=0. Restando: Δ=20/40=0,5. Entonces B=-40/1,05=-38,095238: pedir
 prestado. Precio de la call = 0,5×100-38,095238 = 11,904762. Se verifica: estado alto 60-40=20;
Examen de Grado UC | materia, preguntas y respuestas 38

[pág. 39]
Finanzas - versión clara y reordenada
 bajo 40-40=0.
 La probabilidad neutral al riesgo del mismo árbol es p=(1,05-0,8)/(1,2-0,8)=0,625. Valorar
 C0=[0,625×20+0,375×0]/1,05 produce 11,904762. p es una herramienta derivada de los precios de
 acción y bono; puede diferir de la probabilidad subjetiva de subida. La condición d<1+r<u asegura
 p* entre cero y uno en este modelo de dos estados. Si falla, debe analizarse una contradicción de
 precios, no forzar una probabilidad negativa como si fuera una creencia.
 La put de K=100 paga cero o 20. Precio neutral = 0,375×20/1,05 = 7,142857. Paridad:
 100+7,142857 = 11,904762+95,238095. Un protective put, acción más put, fija un piso de 100 en
 sus pagos finales; cuesta hoy 107,142857. El piso no elimina el costo del seguro ni garantiza mayor
 retorno esperado que conservar la acción.
 Un straddle combina una call y una put largas con igual K. Su pago es |S_T-K| y su resultado es
 |S_T-K|-(c+p), antes de financiar primas. Con K=100 y primas totales 12, pierde como máximo 12
 cuando S_T=100; sus breakevens son 88 y 112. Se beneficia de movimientos grandes en cualquier
 dirección, no de que el precio simplemente tenga alta media. El valor del contrato ya puede
 incorporar una volatilidad elevada, por lo que «se viene incertidumbre» no prueba que esté barato.
 Cómo resolver. Dibuja o tabula pagos por regiones S_T<K, S_T=K, S_T>K. Distingue lado
 largo/corto, strike y prima. Para valorar, construye réplica o usa probabilidades neutrales derivadas
 coherentemente; para decidir una compra según preferencias, usa distribución subjetiva y utilidad,
 además del precio. Valoración y preferencia son problemas relacionados pero distintos.
 TF11. Black-Scholes, sensibilidades y volatilidad implícita
 Fuente: Finanzas I Caro, p. 10, revisada también visualmente para las fórmulas y la tabla de
 signos.
 El modelo Black-Scholes aproxima el valor de una opción europea mediante un proceso continuo
 de precios y una réplica que se reajusta. En su versión básica supone subyacente sin dividendos,
 volatilidad constante, tasa segura continua constante, negociación y financiamiento compatibles con
 réplica y ausencia de las fricciones excluidas. No describe perfectamente saltos, cambios de
 volatilidad o costos de transar, pero muestra cómo los parámetros afectan un precio de opción.
 Para una call sin dividendos:
 C = S0 N(d1) - K exp(-rT)N(d2);
 d1 = [ln(S0/K)+(r+σ²/2)T]/(σ√T); d2=d1-σ√T.
 N(x) es la probabilidad acumulada de una normal estándar. r es continua anual, σ volatilidad anual y
 T años. No se introduce 20 donde σ debe ser 0,20. La put se obtiene por paridad: P=C-S0+K
 exp(-rT). Con rendimiento por dividendos continuo q, la acción aparece descontada como S0
 exp(-qT) y d1 usa r-q; ese ajuste no se reemplaza restando un porcentaje sin identificar su
 calendario.
 Ejercicio completo. S0=K=100, r=0,05, σ=0,20 y T=1. ln(1)=0; d1=(0,05+0,02)/0,20=0,35;
 d2=0,15. N(0,35)=0,636831 y N(0,15)=0,559618. C=100×0,636831-100 exp(-0,05)×0,559618 =
 10,450584. P=10,450584-100+95,122942=5,573526. Estos valores son precios del modelo, no
 ganancias futuras ciertas.
Examen de Grado UC | materia, preguntas y respuestas 39

[pág. 40]
Finanzas - versión clara y reordenada
 Delta es ∂C/∂S=N(d1): 0,636831. Un alza pequeña de una unidad de precio aumenta
 aproximadamente la call en 0,636831. Para cubrir una call vendida, se mantienen
 aproximadamente 0,636831 acciones en este instante y se financia la posición restante de la
 réplica. La delta cambia al variar precio y tiempo; una cobertura inicial mantenida fija no reproduce
 exactamente una opción durante toda su vida.
 Gamma mide el cambio de delta: ∂²C/∂S²=φ(d1)/(Sσ√T), 0,018762 en el ejemplo. Una aproximación
 local incorpora ΔC≈delta×ΔS+½gamma×ΔS². Vega = Sφ(d1)√T = 37,524035 por una unidad
 completa de σ; por un punto porcentual de volatilidad, el cambio aproximado es 0,375240, no
 37,52. Calls y puts largas de este modelo tienen vega positiva: mayor dispersión aumenta el valor
 de un derecho con pérdida de ejercicio acotada.
 La call aumenta con S0 y disminuye con K; la put disminuye con S0 y aumenta con K. La tabla del
 resumen no debe transferirse con un signo positivo de K para la call. Con los supuestos básicos y
 sin dividendos, una mayor tasa reduce VP del strike y favorece la call; perjudica la put. El efecto de
 más tiempo requiere reconocer intereses, dividendos y tipo de opción: no se impone una regla
 universal para todas las puts europeas o todas las opciones con dividendos. Theta se suele definir
 como cambio de valor al transcurrir el calendario, mientras derivar respecto de tiempo restante tiene
 el signo opuesto.
 La volatilidad implícita es el σ que hace coincidir el precio del modelo con una cotización. Si una call
 cuesta más que 10,450584 y todos los otros parámetros permanecen iguales, su volatilidad
 implícita es mayor que 20% en el modelo básico. No es necesariamente la volatilidad física que se
 realizará: incorpora precios de riesgo, expectativas y limitaciones del modelo. Sonrisas de
 volatilidad entre strikes muestran que una única σ constante no reproduce simultáneamente todas
 las cotizaciones.
 Cómo interpretar. Explica cada entrada y su unidad, calcula d1 y d2 antes del precio y verifica
 paridad. Expresa las sensibilidades para un cambio concreto, distinguiendo unidad completa de un
 punto porcentual. Un precio mayor de una opción puede reflejar mayor incertidumbre y un seguro
 más caro, sin identificar una dirección futura del subyacente.
 TF12. Estructura de capital, Modigliani-Miller e impuestos
 Fuente: Finanzas I Caro, pp. 34-40.
 La empresa genera flujos operacionales y los reparte entre acreedores y accionistas. Financiar con
 deuda cambia la prioridad de pagos y el riesgo del residual, pero no crea por sí solo activos
 productivos. Para separar esos efectos, Modigliani-Miller estudia mercados perfectos con supuestos
 explícitos: iguales oportunidades de financiamiento relevantes, información compatible, ausencia de
 las fricciones excluidas y flujos operacionales que no dependen de la estructura elegida.
 Sin impuestos, una empresa que genera 120 perpetuos con riesgo operacional que exige 12% vale
 V=120/0,12=1.000. Si no tiene deuda, E=1.000 y el accionista exige 12%. Si emite deuda de 400 a
 5% y distribuye esos recursos, el equity ex distribución vale 600; su flujo anual es 120-20=100, así
 que k_E=100/600=16,666667%. La riqueza de los antiguos es 600 en equity más 400 distribuidos =
 1.000. El WACC sigue siendo 0,6×16,666667%+0,4×5%=12%. Endeudarse elevó el costo del
 equity, pero no redujo automáticamente la riqueza ni cambió el riesgo operacional.
Examen de Grado UC | materia, preguntas y respuestas 40

[pág. 41]
Finanzas - versión clara y reordenada
 La fórmula surge de k_A V=k_E E+k_D D y V=E+D: k_E=k_A+(D/E)(k_A-k_D). El riesgo se
 traslada al residual. Un inversionista puede crear o deshacer apalancamiento en su cartera bajo las
 oportunidades perfectas del modelo; si una estructura societaria duplicara el valor sin cambiar
 flujos, se podrían replicar pagos a menor costo y arbitrar la diferencia. Esta lógica no significa que
 una persona real pueda endeudarse siempre al costo de una empresa.
 Con impuesto corporativo T y capacidad de deducir intereses, una deuda fija perpetua D genera
 ahorro anual T k_D D. Si el escudo tiene riesgo de deuda y se descuenta a k_D, su VP es TD. Así,
 V_L=V_U+TD. Ejercicio: EBIT 160, impuesto 25%, k_U=12%, deuda 400 a 5%. Flujo operativo
 después de impuestos = 120; V_U=1.000; escudo anual=5, VP=100; V_L=1.100 y E=700.
 FCFE=(160-20)×0,75=105; k_E=105/700=15%. La fórmula consistente es
 k_E=k_U+(D/E)(k_U-k_D)(1-T). WACC=(700/1.100)15%+(400/1.100)5%×0,75=10,909091%;
 120/WACC=1.100.
 Si el dinero de la deuda se distribuye, los antiguos suman 700 ex distribución más 400 recibidos =
 1.100: el aumento de 100 es el VP del escudo, no el monto del préstamo. Confundir empresa,
 equity y riqueza total produce conclusiones falsas sobre una recapitalización. La identidad con
 betas sin impuestos es β_A=(E/V)β_E+(D/V)β_D; con impuestos se debe identificar el activo
 escudo y su riesgo antes de trasladar una fórmula simplificada.
 El beneficio fiscal no obliga a recomendar deuda ilimitada. Pueden aparecer costos esperados de
 insolvencia, restricciones a utilizar escudos, costos de agencia, pérdida de flexibilidad y primas de
 financiamiento. Un esquema de trade-off escribe valor como V_U+VP beneficios tributarios-VP
 costos esperados incrementales. No se resta otra vez un costo ya incorporado en los flujos ni se
 asume que el retorno de deuda permanece constante al aumentar fuertemente el riesgo de impago.
 En el modelo de Miller con tasas personales efectivas constantes sobre ingresos de deuda T_D e
 ingresos accionarios T_E, el beneficio relativo de deuda puede expresarse como
 [1-(1-T_C)(1-T_E)/(1-T_D)]D, bajo sus supuestos. Si T_C=25%, T_E=10% y T_D=35%, el
 coeficiente es 1-0,75×0,90/0,65 = -3,846154%. El beneficio corporativo puede quedar
 contrarrestado por desventaja personal relativa. Es un ejemplo teórico, no una descripción de la
 normativa tributaria chilena vigente.
 Cómo resolver. Separa operación de financiamiento, define política de deuda y riesgo del escudo,
 y reconcilia V, D, E, distribución y riqueza. Explica cuál supuesto hace cambiar el valor. Si la
 deducción de intereses desaparece pero el ejercicio mantiene explícitamente un WACC, responde
 con esa tasa y distingue la comparación del modelo usual donde el costo compatible podría
 cambiar.
 TF13. Agencia, información asimétrica, emisiones y gobierno corporativo
 Fuente: Finanzas I Caro, pp. 41-43 y 46. Derechos y emisiones también se aplican en la fuente de
 examen, pp. 177-178.
 Los agentes de una empresa pueden valorar decisiones distintas porque reciben pagos distintos o
 tienen información distinta. Los accionistas obtienen el residual después de pagar deuda; los
 gerentes pueden valorar remuneración, estabilidad o expansión; el controlador puede obtener
 beneficios privados que no recibe un minoritario. El análisis debe identificar incentivo, decisión y
 quién asume su costo.
Examen de Grado UC | materia, preguntas y respuestas 41

[pág. 42]
Finanzas - versión clara y reordenada
 Sustitución de activos. Una empresa debe pagar deuda 60 en un año. Proyecto A genera 100
 seguro; acreedor recibe 60 y equity 40. Proyecto B genera cero o 180 con probabilidades iguales; el
 valor esperado total es 90, menor en 10. El acreedor recibe cero o 60, media 30; equity recibe cero
 o 120, media 60. El accionista gana 20 al elegir B, mientras el acreedor pierde 30; la pérdida total es
 10. Un proyecto de menor valor puede ser preferido por quienes tienen el residual gracias a
 responsabilidad limitada. Los acreedores anticipan este incentivo y lo incorporan al precio y a los
 contratos.
 Sobreendeudamiento y subinversión. La empresa tiene flujo seguro 90 y deuda prometida 100.
 Un proyecto cuesta 20 y agrega 25 al flujo. Su VAN total, con tasa cero para simplificar, es +5. Sin
 hacerlo, banco recibe 90 y equity cero; al hacerlo, flujo 115, banco recibe 100 y equity 15. Si los
 accionistas deben aportar 20, su ganancia neta es -5: rechazan un proyecto positivo. El banco gana
 10, más que el VAN de 5, capturando parte del nuevo aporte. Renegociar la deuda o compartir el
 beneficio puede recuperar inversión que ambas partes no financian bajo el contrato original.
 Los covenants pueden limitar nueva deuda, garantías, dividendos o cambios de activos; la deuda
 de menor plazo, garantías y monitoreo pueden reducir incentivos, pero también restringen
 flexibilidad. Una convertible modifica el reparto de upside, y no elimina todo conflicto por el solo
 nombre del instrumento. La agencia del flujo de caja libre puede inducir inversiones de VAN
 negativo cuando el gerente busca crecer; dividendos, recompra o disciplina contractual pueden
 reducir recursos disponibles para esa conducta, con costos si se restringen proyectos buenos.
 La selección adversa aparece cuando el vendedor conoce mejor el valor que el comprador. Una
 emisión puede ser interpretada como señal de que los controladores consideran alto el precio. El
 pecking order describe una preferencia por fondos internos, luego deuda y finalmente equity cuando
 diferencias de información hacen más costosas ciertas emisiones. Es una explicación de
 comportamiento bajo condiciones; no una regla que ordene siempre el financiamiento más barato ni
 una prueba de que toda emisión destruye valor.
 Emisión a precio justo. Equity previo vale 100 y hay un proyecto que cuesta 50 y tiene VAN 20.
 Antes de emitir, el anuncio incorpora el VAN: equity pre-money=120. Emitir 50 a precio justo da
 equity post-money=170. Nuevos accionistas reciben 50/170=29,411765%; los antiguos conservan
 120/170=70,588235% y valor 120. Su porcentaje cae, pero ganan los 20 del proyecto. El capital
 nuevo entra como recurso: Epost=Eprevio+VAN+aporte, cuando VAN ya resta toda la inversión y
 no hay otros cambios de deuda o caja omitidos.
 Con diez acciones antiguas, el precio anunciado es 12 y emitir a precio justo exige 50/12=4,166667
 acciones nuevas. Si se emiten cinco a 10 con derechos para los antiguos, el precio ex derechos es
 170/15=11,333333. Cada acción antigua genera un derecho de valor 12-11,333333=0,666667; dos
 derechos permiten comprar una nueva a 10: 10+2×0,666667=11,333333. Quien vende sus diez
 derechos conserva riqueza 10×11,333333+10×0,666667=120. Quien no suscribe ni vende pierde
 ese valor de sus derechos. Una emisión con derechos no destruye riqueza por sí sola; sí puede
 transferirla si una persona deja expirar derechos valiosos.
 El gobierno corporativo asigna decisiones, controles, información y derechos de minoritarios. Una
 put contractual facilita salida; tag along protege acceso a una venta de control; drag along facilita
 vender el total; un derecho de primera oferta o de igualar debe examinarse según su texto y no
 confundirse automáticamente con cualquier call estándar. Directorio, transparencia y protección
 contractual pueden reducir conflictos, pero los efectos se evalúan por sus condiciones. Las reglas
Examen de Grado UC | materia, preguntas y respuestas 42

[pág. 43]
Finanzas - versión clara y reordenada
 de oferta pública, información privilegiada y preferencias legales deben verificarse en normativa
 vigente cuando se requiera una afirmación legal; este capítulo enseña sus incentivos económicos.
 TF14. Dividendos, recompra y crecimiento que crea valor
 Fuente: Finanzas I Caro, pp. 44-45; Finanzas II Caro, pp. 33-39, para relación entre flujo y valor.
 El dividendo entrega caja de la empresa a sus accionistas. En un mercado perfecto y manteniendo
 la inversión, aumentar el dividendo no crea un flujo adicional: reduce recursos que quedan dentro o
 exige financiamiento nuevo. Si una firma vale 1.000, tiene 100 acciones y paga dividendo total 200,
 distribuye 2 por acción y su valor ex distribución es 800, precio 8. Quien tenía una acción termina
 con 8 en acción y 2 en caja: riqueza 10. La igualdad es un resultado del modelo sin los efectos que
 se excluyen, no una identidad empírica exacta para todo mercado, impuesto o día de negociación.
 Con recompra a precio justo 10, la misma firma usa 200 para retirar 20 acciones. Quedan 80 y
 equity 800; precio sigue en 10. Quien vende cobra 10 y quien permanece conserva una acción de
 valor 10. La utilidad por acción puede aumentar porque hay menos títulos, pero ese cociente
 contable no demuestra creación de valor. Recomprar sobre el valor justo puede transferir riqueza de
 quienes permanecen a quienes venden; recomprar bajo él produce la transferencia contraria si no
 cambia otra cosa.
 Las políticas reales pueden importar por impuestos, costos de transacción, señales, contratos,
 clientelas y agencia. Una distribución inesperada puede revelar mejores expectativas de caja o la
 ausencia de proyectos; reducir dividendos puede señalar dificultad o financiar una buena
 oportunidad. El mecanismo debe identificarse; no se concluye que subir dividendos sea siempre
 noticia positiva. El suavizamiento de dividendos describe que las empresas procuran evitar
 variaciones frecuentes cuando sus resultados fluctúan, con compromisos y expectativas que
 conviene modelar.
 El crecimiento solo crea valor si las nuevas inversiones rinden más que su costo de oportunidad
 ajustado por riesgo. En un esquema estacionario, con retorno sobre inversión nueva ROI, fracción
 retenida b y utilidades que se reinvierten en esa actividad, g=b×ROI. El modelo de Gordon vale
 P0=D1/(k_E-g), con primer dividendo D1 al final del primer período, crecimiento perpetuo
 compatible y k_E>g. P/E depende de si la utilidad del denominador es la del año cero o uno; no se
 elimina ese desfase al comparar múltiplos.
 Ejercicio de reinversión. Capital productivo inicial 10.000; ROI neto 12%; beneficio del primer año
 1.200; se retiene 40%. D1=720; g=0,4×12%=4,8%. Con k_E=10%, valor =
 720/(0,10-0,048)=13.846,153846. Si se distribuyera todo sin reinvertir y el beneficio se mantuviera,
 valor =1.200/0,10=12.000. Retener crea 1.846,153846 porque la actividad nueva rinde 12% frente
 al 10% exigido. Si ROI fuera igual a k_E, retener no agregaría valor en este esquema; si fuese
 menor, podría destruirlo.
 Los impuestos modifican los fondos disponibles y el rendimiento de reinversión. Supón que el 12%
 neto anterior proviene de ROI antes de impuesto 15% y tasa 20%. Si el impuesto sube a 30% y se
 conserva la productividad antes de impuestos, ROI neto pasa a 10,5%, no permanece en 12%.
 Utilidad inicial 1.050; D1=630; g=4,2%; con k_E constante 10%, valor =630/0,058=10.862,068966.
 Mantener la ROI neta pese al impuesto requeriría una mejora del retorno bruto o un supuesto
 adicional. Si se exige mantener g, se resuelve b=g/ROI neta y cambia el payout; no se pueden fijar
 simultáneamente crecimiento, retención y ROI cuando su identidad deja de cumplirse.
Examen de Grado UC | materia, preguntas y respuestas 43

[pág. 44]
Finanzas - versión clara y reordenada
 Cómo responder. Separa flujo distribuido, flujo retenido y oportunidades de inversión. Reconcilia
 precio antes y después de la distribución con riqueza total. Para Gordon, muestra D1, ROI, b, g y
 k_E; explica cuál variable cambia con la noticia y comprueba k_E>g. Un múltiplo elevado puede
 reflejar bajo descuento o buen crecimiento, pero no certifica por sí solo eficiencia ni burbuja.
Examen de Grado UC | materia, preguntas y respuestas 44

[pág. 45]
Finanzas - versión clara y reordenada
 PARTE II - DIRECCIÓN FINANCIERA
 1. VAN y decisión de inversión
 Profundización desde fuente manuscrita no oficial: Respuestas Finanzas I, apuntes
 manuscritos de estudiante (2011-1, p. 2), desarrolla un flujo incremental con inversión inicial,
 remodelación/equipos, capital de trabajo, depreciación, impuestos, valor de rescate y recuperación
 de capital de trabajo. Reconstruye cada flujo por periodo y verifica signos, tributación y fechas
 contra el enunciado del caso; el VAN anotado es una respuesta estudiantil y no una clave oficial. La
 página 3 repasa el vínculo entre valor de activos y patrimonio, escudo tributario y mezcla
 deuda/patrimonio; úsala bajo supuestos explícitos.
 VAN del proyecto: VAN=Σ_t=0^n FCF_t/(1+r)^t. Aceptar proyectos independientes con VAN positivo
 si presupuestos y restricciones no alteran el criterio; para proyectos mutuamente excluyentes
 compara VAN incremental y restricciones, no el mayor porcentaje TIR. TIR puede ser múltiple/no
 existir con flujos no convencionales y puede ordenar proyectos de escala distinta incorrectamente.
 El flujo incremental es «con proyecto menos sin proyecto». Incluye inversión inicial, capital de
 trabajo (desembolso cuando se invierte y recuperación final si se libera), impuestos pagados, costos
 de oportunidad y externalidades. Excluye costos hundidos y asignaciones contables que no
 cambian caja. Incluye efectos sobre ventas/operaciones existentes (canibalización) cuando sean
 incrementales. Valor terminal y recuperación tributaria requieren supuesto expreso.
 Flujo libre de la firma simplificado: (FCFF=EBIT(1-T)+Dep-Capex-Δ NWC). Descuéntalo al WACC
 para obtener valor de operaciones; el valor patrimonial se obtiene ajustando caja/deuda y otros
 derechos. No descuentas FCFF al costo de equity ni flujo al equity al WACC.
 2. Tasa de descuento, WACC y riesgo de proyecto
 WACC=(E)/(D+E)r_E+(D)/(D+E)r_D(1-T_c)
 con valores de mercado y estructura de capital objetivo, si escudo tributario de deuda es utilizable;
 define si D incluye pasivos relevantes. (r_E) puede estimarse con CAPM. Aplica WACC solo a flujos
 con riesgo operativo parecido al de la empresa y estructura coherente. Un proyecto en otro
 negocio/país puede requerir comparables y desapalancar/reapalancar beta. Para VAN ajustado
 (APV), separa valor sin deuda y valor presente de efectos de financiamiento cuando el
 apalancamiento cambia.
 Sensibiliza variables de valor (precio, volumen, margen, inversión, plazo, tasa, tipo de cambio) y
 escenarios coherentes. Punto de equilibrio es útil para riesgo operativo, pero no reemplaza valor
 temporal ni probabilidad de escenarios.
 3. Capital de trabajo y liquidez
 Capital de trabajo neto operativo aproximado: cuentas por cobrar + inventarios - cuentas por pagar
 operacionales. Ciclo de conversión de efectivo = días inventario + días cuentas por cobrar - días
 cuentas por pagar. Acortar ciclo puede liberar caja, pero costos de inventario bajo, cobranza estricta
 o plazo proveedor deterioran ventas/relaciones. Liquidez contable no equivale a solvencia; analiza
 calendario, volatilidad, líneas disponibles, vencimientos y covenants.
Examen de Grado UC | materia, preguntas y respuestas 45

[pág. 46]
Finanzas - versión clara y reordenada
 4. Deuda, capital, dividendos y valoración
 La deuda puede crear escudo tributario y disciplina, pero eleva distress, agencia, pérdida de
 flexibilidad y riesgo de refinanciamiento. MM sin impuestos/fricciones: estructura de capital no
 cambia valor; con impuestos corporativos, la deuda añade escudo bajo supuestos; costos de
 insolvencia/agencia pueden revertir beneficio. Deuda no crea valor por simple apalancamiento
 contable.
 Dividendos/recompras distribuyen efectivo; si la empresa carece de proyectos de VAN positivo,
 distribuir puede ser razonable, considerando impuestos, señales, restricciones y necesidades de
 caja. La fecha ex dividendo y financiación importan. Para valoración por dividendos
 (P_0=D_1/(r_E-g)) con (r_E>g); DCF depende de proyecciones y terminal, así que presenta
 sensibilidad.
 Fusión/adquisición crea valor solo si valor conjunto supera valor separado más costo de
 transacción, integración y pagos. Sinergia debe especificar fuente (ingresos, costos, impuestos,
 activos, capacidad) y riesgo de captura. Para relación de canje, calcula valor de aportes y
 distribución de sinergia; una pérdida tributaria vale solo si existe renta gravable, plazo/ley permiten
 uso y se considera riesgo y descuento.
 5. Impuestos y decisiones
 Distingue gasto contable, depreciación fiscal, pérdida tributaria y pago efectivo. Escudo de
 depreciación es depreciación fiscal por tasa marginal cuando puede usarse. Pérdida acumulada no
 es activo de valor completo si no hay utilidades esperadas/permitidas contra las cuales aplicarla.
 Impuestos deben seguir flujos incrementales y legislación indicada por el caso; no inventes
 tratamiento si falta información.
 Procedimiento para ejercicios cuantitativos
 1. Dibuja una línea de tiempo y anota signos y fecha de cada flujo. 2. Declara tasa por periodo y
 conversión necesaria. 3. Formula el criterio antes de reemplazar números. 4. Presenta cálculos
 intermedios, unidad y resultado redondeado razonablemente. 5. Interpreta: ¿qué alternativa crea
 más valor, cuánto y por qué? Menciona riesgo/supuesto sensible. 6. Comprueba sentido: subir tasa
 baja valor de flujos positivos futuros; mayor spread refleja mayor rendimiento requerido; doble de
 escala de flujos duplica valor si todo lo demás es lineal.
 Errores frecuentes que esta guía corrige
 • No se compara yield de bonos como si sus riesgos, flujos, duration y liquidez fueran idénticos.
 • No se usa la varianza aislada para diseñar cobertura de pasivos: incluye covarianza con el pasivo
 y varianza total.
 • Las pérdidas tributarias no tienen valor automático; se descuentan los ahorros que efectivamente
 puedan usarse.
 • En fusiones, una participación mínima debe derivarse de aportes/valor conjunto y derechos; no
 asumir que todo accionista recibe la misma sinergia.
Examen de Grado UC | materia, preguntas y respuestas 46

[pág. 47]
Finanzas - versión clara y reordenada
 • La TIR no es criterio universal: conflictos de escala/tiempo o múltiples cambios de signo exigen
 VAN o flujos incrementales.
 Complemento docente: Dirección Financiera
 DF01. Leer estados financieros, diagnosticar ratios y comprender
 apalancamiento
 Fuente: Finanzas II Caro, pp. 2-11.
 El balance registra recursos y obligaciones en una fecha: activos = pasivos + patrimonio. El estado
 de resultados registra ingresos y gastos de un período conforme al devengamiento. La caja registra
 cuándo se cobran y pagan. Vender a crédito puede aumentar utilidad y cuentas por cobrar sin
 aumentar efectivo; comprar una máquina consume efectivo hoy, aunque su costo contable se
 distribuya por depreciación. Esta separación es la base de una decisión de liquidez.
 El objetivo financiero de maximizar valor para los dueños exige considerar oportunidad, riesgo y
 tiempo de los flujos. No equivale a maximizar utilidad contable del próximo mes. Un proyecto puede
 aumentar ventas y ROE y, a la vez, tener VAN negativo si necesita demasiado capital o tarda en
 cobrar. Liquidez es capacidad de pagar oportunamente; solvencia incorpora sostenibilidad de
 obligaciones; rentabilidad mide resultado relativo a una base. Ninguna sustituye las otras.
 Empresa de ejemplo. Activos 1.000; corrientes 500, compuestos por caja 100, CxC 200 e
 inventario 200; fijos netos 500. Proveedores corrientes 200, deuda bancaria LP 200 y patrimonio
 600. Ventas anuales 2.000, costo de ventas 1.200, GAV 500; EBIT 300. Intereses 40, impuesto
 25%; utilidad neta = (300-40)×0,75 = 195. Se supone que las bases del ejemplo son representativas
 del promedio anual para las razones que mezclan flujo y stock.
 Razón corriente =500/200=2,5; prueba ácida=(500-200)/200=1,5; razón de caja=100/200=0,5. Las
 primeras no garantizan caja en 30 días: deben examinarse fechas y calidad de CxC e inventario. Un
 préstamo CP que agrega 100 a caja y pasivos lleva corriente a 600/300=2,0 y ácido a
 400/300=1,333333. La cobertura en ratios disminuye aunque haya entrado efectivo, porque el
 pasivo crece proporcionalmente más desde una base menor.
 ROA operativo antes de impuestos = EBIT/A = 30%; ROE =195/600=32,5%. DuPont con resultado
 neto se calcula como margen neto×rotación×multiplicador:
 (195/2.000)×(2.000/1.000)×(1.000/600)=9,75%×2×1,666667=32,5%. La identidad requiere que
 activo del segundo denominador y tercer numerador sea el mismo; no se usa activo operacional en
 un factor y total en el siguiente sin ajustar. Para explicar ROA operativo se usa margen
 operacional, no margen neto.
 Con año de 360 días, DSO=200/2.000×360=36 días; DIO=200/1.200×360=60; si compras
 anuales=1.200 en régimen sin cambio de inventario, DPO=200/1.200×360=60. Ciclo de caja =
 DSO+DIO-DPO=36 días. Si inventario crece, compras no son necesariamente costo de ventas:
 compras = costo de ventas+Δinventario bajo el esquema sencillo, y se ajusta la rotación de
 proveedores. Un ciclo menor ayuda a financiar ventas, pero no incorpora por sí solo morosidad,
 estacionalidad ni el tamaño total de operación.
 El retorno sobre capital invertido after-tax se compara con una tasa también after-tax. Capital
 empleado = activos operacionales-pasivos espontáneos =1.000-200=800; NOPAT=300×0,75=225;
Examen de Grado UC | materia, preguntas y respuestas 47

[pág. 48]
Finanzas - versión clara y reordenada
 ROIC=28,125%. A WACC12%, cargo por capital=96 y EVA=225-96=129. Comparar ROA antes de
 impuestos con WACC después de impuestos distorsiona el diagnóstico de valor.
 El apalancamiento operativo amplifica cambios de ventas por costos fijos. En el ejemplo,
 contribución antes de GAV fijo =800 y EBIT=300: DOL=800/300=2,666667. Apalancamiento
 financiero DFL=EBIT/(EBIT-intereses)=300/260=1,153846; combinado DCL=DOL×DFL=3,076923.
 Cerca del nivel actual y bajo los supuestos de costos constantes, aumentar ventas 1% eleva EBIT
 aproximadamente 2,67% y utilidad antes de impuesto 3,08%. No son pronósticos para cambios
 arbitrariamente grandes ni porcentajes de crecimiento absolutos del resultado.
 Cómo diagnosticar. Presenta ratios de liquidez, actividad, financiamiento y rentabilidad, explica su
 relación y la perspectiva del analista. Usa saldos promedio cuando corresponda y declara si solo
 hay cierres. Un crédito a 30 días se decide con una proyección de cobros y pagos de esos 30 días;
 un ROE anual alto no reemplaza la fuente de repago.
 DF02. Planificación, proformas, FER y crecimiento sostenible
 Fuente: Finanzas II Caro, pp. 12-15. Aplicación histórica de calce: fuente de examen pp. 189-190.
 Planificar consiste en convertir decisiones de ventas, inversión y financiamiento en estados y caja
 compatibles. El presupuesto de ventas inicia muchas proyecciones: vender más puede requerir
 CxC e inventario adicionales, mientras el proveedor financia espontáneamente una parte. El activo
 fijo puede aumentar de manera discreta al agotarse la capacidad, no necesariamente como un
 porcentaje continuo de ventas. Las utilidades retenidas son otra fuente, pero su disponibilidad
 depende del resultado y de la política de dividendos.
 FER = aumento de activos requeridos-aumento de pasivos espontáneos-generación interna
 retenida, antes de elegir fuentes externas adicionales. Si se modelan por separado inversiones,
 depreciación o caja, la ecuación debe usar movimientos compatibles de los activos netos. La deuda
 bancaria decidida para cubrir el FER no se resta como si fuera una fuente espontánea inicial; sería
 esconder el déficit que se intenta calcular.
 Ejercicio de proforma. Ventas iniciales 1.000 y proyectadas 1.200. CxC+inventario equivalen a
 40% de ventas; proveedores, a 15%. La empresa requiere además inversión fija neta adicional 100.
 El margen neto previsto es 12%, ya considerando intereses bajo los supuestos del ejercicio, y se
 distribuye 50% de utilidad. Δactivos =0,4×200+100=180; Δproveedores=0,15×200=30; utilidad
 nueva=0,12×1.200=144; retención=72. FER=180-30-72=78.
 Balance inicial: corrientes operacionales 400+fijos300=700; proveedores150+deuda
 bancaria250+patrimonio300=700. Final: activos480+400=880; proveedores180; patrimonio372
 antes de un aporte nuevo. Si todo el FER se obtiene por deuda, deuda bancaria328 y fuentes
 totales180+328+372=880. Este cierre prueba que la proforma usa la misma inversión y retención
 que el cálculo del FER. No se trata el dividendo de 72 como retenido y distribuido a la vez.
 Si se exige mantener deuda total/patrimonio inicial 400/300=4/3, un aporte X reemplaza igual monto
 de deuda nueva. Pasivos finales=508-X; equity=372+X. Se resuelve 508-X=(4/3)(372+X), dando
 X=5,142857 de patrimonio nuevo y 72,857143 de nueva deuda bancaria. Ambos suman FER78. Si
 el margen neto dependiera de los intereses de esta deuda y no estuviese fijado, habría que iterar o
 resolver simultáneamente resultado, retención y financiamiento.
Examen de Grado UC | materia, preguntas y respuestas 48

[pág. 49]
Finanzas - versión clara y reordenada
 El crecimiento sostenible depende de restricciones: margen, rotación, dividendos, capacidad y
 apalancamiento. No existe una fórmula universal sin definir bases. Si ROE se mide sobre
 patrimonio inicial, no hay aportes y la razón financiera se mantiene, la tasa que financia la retención
 puede expresarse g=b×ROE_inicial. Si ROE se define sobre patrimonio final E1 y la retención es
 bNI, E1=E0+bNI=E0+bROE_final E1, de donde g=(E1/E0)-1=bROE_final/(1-bROE_final). Con
 ROE final18% y b40%, g=0,072/0,928=7,758621%, mientras usar una ROE inicial18% daría7,2%.
 La diferencia proviene de la base, no de una contradicción matemática.
 El principio de calce financia necesidades permanentes con fuentes permanentes y necesidades
 transitorias con fuentes que puedan liberarse al desaparecer esas necesidades. Supón déficits
 anuales adicionales 80,60,-90,110. Sus acumulados son80,140,50,160. Dentro de ese horizonte, el
 piso adicional es 50; las necesidades transitorias son30,90,0,110. El último acumulado160 no es
 todo permanente: 110 desaparece respecto del piso en un año de menor requerimiento. La
 identificación exige revisar también el horizonte futuro y la base de financiamiento ya existente; un
 mínimo de cuatro años no asegura permanencia eterna.
 Cómo resolver. Construye usos, fuentes internas y déficit; cierra balance; elige financiamiento
 respetando caja, dividendos, ratio y vencimientos. Presenta los acumulados si se pregunta
 permanencia. Un saldo de caja mínimo se trata como activo exigido, y una línea bancaria no
 utilizada no entra como deuda efectivamente recibida.
 DF03. Inventarios: EOQ, reposición y descuentos
 Fuente: Finanzas II Caro, pp. 16-17.
 Mantener inventario evita quiebres y permite servir clientes, pero compromete dinero y produce
 almacenamiento, seguros o deterioro. Comprar muy seguido reduce saldo medio y aumenta costos
 de ordenar. El modelo EOQ equilibra ambos con demanda constante conocida, reposición
 instantánea, ausencia de quiebres y costos definidos. Es un punto de partida para entender el
 conflicto, no una regla sin contexto.
 Con demanda anual D, costo por pedido S, costo anual de mantener una unidad H y lote Q, número
 de pedidos=D/Q y saldo medio=Q/2. El costo relevante es TC(Q)=DS/Q+HQ/2. Derivando:
 TC'(Q)=-DS/Q²+H/2=0; por tanto **Q*=√(2DS/H)**. La segunda derivada es2DS/Q³>0: el punto
 minimiza esos costos. El costo de comprar D unidades no afecta Q si el precio unitario no cambia,
 pero sí importa cuando existen descuentos.
 Ejercicio resuelto. D=10.000 unidades/año, S=20 pesos/pedido, H=2 pesos/unidad/año.
 Q*=√200.000=447,213595 unidades. Costo de ordenar=10.000×20/447,213595=447,213595
 pesos/año; mantener=2×447,213595/2=447,213595. Total relevante=894,427191. Se
 realizan22,360680 pedidos equivalentes por año, con intervalo360/22,360680=16,099689 días. En
 una política real se ajustan tamaños y calendarios a unidades factibles; que D/Q no sea entero no
 invalida el óptimo continuo del modelo.
 El punto de pedido incorpora el plazo de reposición: ROP=demanda diaria×lead time+stock de
 seguridad. Con360 días, demanda27,777778 por día, plazo5 días y stock de seguridad50, se pide
 al llegar a 188,888889 unidades. Sin incertidumbre ni stock de seguridad sería138,888889. El stock
 de seguridad no se elige arbitrariamente: depende de la distribución de demanda durante
 reposición, nivel de servicio y costo de quiebre; si se mantiene constante, agrega H×stock de
 seguridad al costo anual.
Examen de Grado UC | materia, preguntas y respuestas 49

[pág. 50]
Finanzas - versión clara y reordenada
 Descuento por volumen. Supón precio normal100 y precio99 si Q≥1.000, con H fijo en2 para
 simplificar. El EOQ447,213595 no califica para descuento. Se comparan el óptimo factible del tramo
 normal y el límite1.000 del tramo con descuento. A precio100,
 total=10.000×100+894,427191=1.000.894,427191. A Q1.000 y precio99, compra990.000,
 órdenes200, mantención1.000: total 991.200. Conviene el lote1.000 en estos datos, aunque exceda
 EOQ, porque el ahorro de compra supera el costo adicional de mantener. Si H fuese porcentaje del
 precio, habría que recalcular H y cada EOQ por tramo.
 Con varios descuentos se calcula el EOQ de cada tramo, se comprueba su elegibilidad y se
 evalúan los límites relevantes. No se acepta un EOQ que usa un precio al que su cantidad no tiene
 acceso. La demanda que aumenta por un descuento al cliente es un problema diferente: debe
 valorarse el margen de esas ventas y sus necesidades de crédito e inventario.
 Cómo interpretar. Presenta cantidades, frecuencia, costo total y restricciones. Explica qué
 supuesto permite usar Q/2 y qué cambia al haber incertidumbre o capacidad. Reducir inventario
 mejora caja solo si no provoca pérdidas de ventas o costos de urgencia mayores que el ahorro.
 DF04. Administración de caja: Baumol y Miller-Orr
 Fuente: Finanzas II Caro, pp. 18-20. La p.20 se contrastó visualmente: el término de raíz cúbica es
 el margen sobre el límite inferior, no siempre el saldo absoluto de retorno.
 Caja permite pagar operaciones y contingencias, pero una unidad ociosa pierde el rendimiento de
 una alternativa segura compatible. La política de tesorería busca equilibrar costo de convertir
 inversiones a efectivo con costo de mantenerlo y riesgo de liquidez. «Minimizar caja» puede ser una
 mala decisión si fuerza incumplimientos o ventas urgentes de activos.
 Baumol supone desembolsos uniformes y previsibles entre reposiciones de efectivo. Si se
 necesitan T pesos por año, cada conversión trae C pesos, cuesta b por transacción y el rendimiento
 alternativo anual es i, el número de conversiones esT/C y caja mediaC/2. TC(C)=bT/C+iC/2. La
 derivada iguala costos marginales y produce **C*=√(2bT/i)**, análoga a EOQ. Un saldo mínimo
 adicional se suma a la caja media y puede requerir un calendario de reposición diferente.
 Ejercicio Baumol. T=360.000 pesos/año, b=30 pesos/conversión e i=6% anual.
 C*=√(21.600.000/0,06)=18.973,665961 pesos. Saldo medio9.486,832981; conversiones18,973666
 por año. Costo anual de conversión = 569,209979 y costo de oportunidad =569,209979; total
 1.138,419958. La coincidencia de componentes es una comprobación del óptimo, no una exigencia
 impuesta antes de calcular. El ejemplo usa el mismo período anual en T e i.
 Miller-Orr trata flujos netos aleatorios según sus hipótesis. Se fija un piso de caja L y se decide un
 punto de retorno Z y un techo H. Mientras el saldo esté dentro de las bandas, no se convierte; al
 llegar a H se invierte H-Z; al llegar a L se venden inversiones por Z-L. Esto reduce transacciones
 frecuentes frente a corregir cada movimiento pequeño.
 Con costo b por transacción, varianza diaria del flujo σ² y costo de oportunidad diario i, define
 h=[3bσ²/(4i)]^(1/3). El punto de retorno es Z=L+h y el techo H=L+3h=3Z-2L. h es una distancia
 monetaria, no el saldo completo salvo que L=0. En el modelo estacionario, caja media=L+4h/3. Una
 expresión del costo esperado es bσ²/(2h²)+i(L+4h/3); derivar respecto de h da-bσ²/h³+4i/3=0, que
 produce la regla anterior bajo los supuestos del modelo.
Examen de Grado UC | materia, preguntas y respuestas 50

[pág. 51]
Finanzas - versión clara y reordenada
 Ejercicio de bandas. L=1.000 pesos, b=10, varianza diaria10.000 pesos² e i=0,0001 diario.
 h=908,560296 pesos; Z=1.908,560296; H=3.725,680889. Al tocar el techo se
 invierten1.817,120593; al tocar el piso se convierten a caja908,560296. Mayor incertidumbre σ²
 amplía las bandas; mayor costo de transar b también las amplía; mayor costo de oportunidad i
 reduce los saldos elegidos. No se confunde σ=100 con σ²=10.000 ni tasa anual con diaria.
 El modelo no determina qué pérdida de servicio o incumplimiento tolera la empresa al fijar L.
 Límites bancarios, pagos grandes conocidos y estacionalidad requieren complementar las bandas
 con pronósticos de caja. Una política puede incorporar ambos: presupuesto para eventos
 previsibles y reglas de ajuste para la variación aleatoria restante.
 Cómo responder. Define si el flujo es previsible o aleatorio, escribe período y unidades, deriva el
 conflicto de costos y calcula el saldo o bandas. Explica qué transacción concreta se realiza al llegar
 a cada límite. El resultado es una política de decisión, no una predicción perfecta de la caja futura.
 Desarrollo desde cero: Teoría Financiera y Dirección Financiera
 1. Qué pregunta responde Finanzas
 Finanzas organiza decisiones sobre recursos que llegan en fechas distintas y están expuestos a
 incertidumbre. Una empresa recibe hoy un peso o lo recibirá después; puede invertirlo, mantenerlo
 líquido o distribuirlo; y debe decidir qué rendimiento justifica inmovilizar recursos y asumir riesgo. El
 valor de una alternativa depende de caja futura incremental, momento, riesgo y costo de
 oportunidad. El cálculo es una herramienta para disciplinar la decisión, no un sustituto de entender
 el negocio.
 Antes de sustituir números en cualquier fórmula, escribe: (a) fecha de valoración; (b) línea de
 tiempo y signo de cada flujo; (c) unidad monetaria y escala; (d) si cada flujo es nominal o real; (e)
 tasa por periodo y riesgo que remunera; (f) criterio de comparación. Esta disciplina resuelve muchos
 errores de grado antes de hacer algebra.
 2. Valor del dinero en el tiempo y tasas
 Si una inversión de PV gana una tasa efectiva r por periodo, su valor futuro tras n periodos es
 (FV=PV(1+r)^n). Despejando: (PV=FV/(1+r)^n). La tasa representa la alternativa sacrificada y la
 compensación exigida por plazo y riesgo. Un flujo cercano vale más que el mismo flujo futuro
 cuando r>0.
 Ejemplo de frecuencia. Se invierten $1.000.000 por 2 años a 12% nominal anual capitalizable
 mensualmente. La tasa mensual es 0,12/12=1%, n=24 y (FV=1.000.000(1,01)^24approx1.269.735).
 La tasa efectiva anual es ((1,01)^12-1approx12,68%), no 12%. No mezcles tasa mensual con
 periodos anuales.
 Anualidad vencida de C durante n periodos: (PV=C[1-(1+r)^-n]/r). Si paga al inicio de cada periodo,
 multiplica por (1+r) porque cada flujo se adelanta un periodo. Una perpetuidad constante que
 comienza en t=1 vale (C/r); una perpetuidad creciente vale (C_1/(r-g)), con r>g y crecimiento
 sostenible. Si el primer flujo ocurre hoy, sepáralo como C₀ y descuenta el resto. Un flujo irregular se
 descuenta periodo a periodo.
Examen de Grado UC | materia, preguntas y respuestas 51

[pág. 52]
Finanzas - versión clara y reordenada
 Nominal/real: por Fisher, (1+r_nom=(1+r_real)(1+π)); como aproximación (r_nom≈ r_real+π). Usa
 flujos y tasa en el mismo marco. De igual modo, moneda local requiere tasa local coherente; no
 descuentas dólares con tasa en pesos sin convertir flujos y riesgo cambiario.
 3. Bonos, rendimiento y riesgo de tasas
 Un bono es una secuencia de cupones y principal prometidos, sujeto a riesgo de crédito y otros
 riesgos. Su precio es el valor presente de esos flujos descontados a rendimientos compatibles con
 plazo, moneda y riesgo. Para cupón anual C, principal F y yield y: (P=Σ_t=1^TC/(1+y)^t+F/(1+y)^T).
 Si el cupón queda fijo, precio y yield se mueven en direcciones opuestas. Un cupón alto no significa
 que el bono sea más rentable: puede venderse a prima.
 La curva spot asigna una tasa a cada vencimiento. Cada flujo se descuenta a su spot: (P=Σ
 CF_t/(1+s_t)^t). Una tasa forward implícita se obtiene por no arbitraje:
 ((1+s_n)^n=(1+s_k)^k(1+f_k,n)^n-k). Es una tasa implícita en precios presentes, no una predicción
 segura de la tasa que se observará; las primas por plazo y riesgo pueden influir.
 Sensibilidad. La duración Macaulay pondera vencimientos por valor presente de cada flujo. La
 duración modificada aproxima cambio porcentual de precio ante un movimiento pequeño de yield:
 ΔP/P≈-DmodΔy. Con Dmod=4, un alza de 0,01 (100 puntos base) implica aproximadamente -4%,
 antes de convexidad. Convexidad captura curvatura y mejora la aproximación para cambios
 grandes. Bonos de cupón bajo y vencimiento largo suelen tener mayor duración. Spread remunera
 varios riesgos; mayor spread no es arbitraje hasta aislar crédito, liquidez, opciones, moneda,
 impuestos y financiamiento.
 4. Riesgo, diversificación, CAPM y costo de capital
 Rendimiento esperado es media ponderada de resultados posibles; riesgo puede medirse por
 varianza, desviación u otras medidas según objetivo. Para dos activos A y B:
 (E(R_p)=w_AE(R_A)+w_BE(R_B)), y (Var(R_p)=w_A^2σ_A^2+w_B^2σ_B^2+2w_Aw_BCov(A,B)).
 La covarianza explica diversificación: activos volátiles pueden combinarse con menor riesgo si no
 se mueven juntos. No evalúes una inversión por volatilidad aislada si forma parte de una cartera o
 cubre un pasivo.
 La frontera eficiente contiene carteras que maximizan rendimiento esperado para riesgo dado (o
 minimizan riesgo para rendimiento dado). Con activo libre de riesgo, el inversionista elige una
 combinación de ese activo y cartera tangente según aversión al riesgo. Sharpe es
 ((E[R_p]-R_f)/σ_p), pero no compara correctamente carteras con exposiciones o restricciones
 diferentes sin contexto.
 CAPM: (E[R_i]=R_f+β_i(E[R_m]-R_f)), donde β=Cov(Ri,Rm)/Var(Rm). Beta mide exposición
 sistemática al mercado de referencia; no es riesgo total ni probabilidad de fracaso. El CAPM es un
 modelo de equilibrio con supuestos fuertes; se usa para estimar rendimiento requerido, no para
 afirmar que el retorno futuro está garantizado. APT amplía a varios factores: la prima requerida se
 vincula con exposiciones β a factores y primas λ, cuyos fundamentos deben justificarse.
 Para cobertura, minimiza varianza del resultado neto entre activos y pasivos. Si una empresa tiene
 pasivo en dólares, un instrumento en dólares puede reducir riesgo aunque su volatilidad aislada sea
 alta. La pregunta correcta es cómo cambia la exposición neta ante el instrumento, usando
 covarianza, monto, vencimiento y base.
Examen de Grado UC | materia, preguntas y respuestas 52

[pág. 53]
Finanzas - versión clara y reordenada
 5. Derivados, arbitraje y opciones
 Un futuro obliga a comprar/vender al precio pactado en fecha futura; fija precio y elimina upside
 además de proteger downside. Una opción call da derecho a comprar al strike K; una put, derecho a
 vender. Al vencimiento, payoffs son max(S_T-K,0) y max(K-S_T,0). Beneficio de posición larga
 resta prima y financiamiento. La pérdida de opción comprada se limita a prima; posición corta puede
 tener pérdida mayor.
 La paridad put-call para opciones europeas sin dividendos es (C+PV(K)=P+S_0), bajo condiciones
 de mismo strike/plazo, posibilidad de replicar y costos/fricciones acotados. Si falla materialmente, se
 construye cartera de arbitraje con posiciones opuestas, pero primero se verifica cotización,
 opciones de estilo, dividendos, tasas, spreads, préstamo y restricciones de venta corta.
 En binomial de un periodo, si el activo sube a uS₀ o baja a dS₀, replica el payoff de la opción con Δ
 acciones y préstamo/deuda. La probabilidad neutral al riesgo (q=(1+r-d)/(u-d)) sirve para valorar
 bajo precios sin arbitraje: (C=[qC_u+(1-q)C_d]/(1+r)). q no es probabilidad real ni pronóstico
 subjetivo. Un buen desarrollo muestra árbol, payoffs, cobertura, préstamo y valor, y comprueba
 replicación en ambos estados.
 Eficiencia de mercado se clasifica por información reflejada en precios: pasada (débil), pública
 (semifuerte) o toda información (fuerte). La hipótesis no dice que precio observado sea infalible ni
 que nadie tenga información privada; plantea dificultad de obtener retornos anormales ajustados a
 riesgo y costos. Una anomalía histórica no demuestra una estrategia explotable sin controlar riesgo,
 selección, costos, impuestos y sesgo de supervivencia.
 6. Evaluación de proyectos: construir flujos incrementales
 VAN mide creación de valor: (VAN=Σ_t=0^nFCF_t/(1+r)^t). Un proyecto independiente con VAN
 positivo suele aceptarse si no hay restricciones que alteren decisión; proyectos mutuamente
 excluyentes se comparan por VAN incremental. TIR puede ser múltiple con cambios de signo, no
 existir o ordenar mal proyectos de escala/plazo diferente. Si VAN y TIR discrepan, examina
 reinversión, escala, timing y flujo incremental.
 Flujo incremental es “con proyecto menos sin proyecto”. Incluye costo de oportunidad de activos,
 efectos en ventas existentes, costos operativos evitables, impuestos, capex, inversión de trabajo y
 liberación final. Excluye costos hundidos; una asignación contable solo importa si cambia
 caja/impuesto. Capital de trabajo invertido reduce caja cuando se incurre y suele recuperarse
 cuando se libera, si el caso lo permite. Valor de rescate se incluye neto de impuestos
 correspondientes.
 FCFF simplificado: (EBIT(1-T)+Dep-Capex-Δ NWC). Depreciación no es salida de caja, pero reduce
 base imponible; se suma y el ahorro de impuestos se refleja. Descuenta FCFF al WACC para valor
 de operaciones. Flujo a accionistas se descuenta al costo de equity; no cruces flujo y tasa.
 Ejercicio completo. Proyecto requiere capex 100 hoy, capital de trabajo 10 hoy, dura dos años.
 Genera EBIT 40 cada año, depreciación 50 anual lineal, tasa de impuesto 25%, sin valor residual;
 recupera NWC 10 al final del año 2. FCFF anual de operación=40(0,75)+50=80. Flujos: t0=-110;
 t1=80; t2=90. Con WACC 10%, VAN=-110+80/1,1+90/1,1²=-110+72,73+74,38=37,11. Bajo estos
 supuestos crea valor. Antes de recomendar, verifica si depreciación 50/año corresponde a
 base/costo y valor residual fiscal, si hay ventas/costos incrementales omitidos, y si tasa representa
Examen de Grado UC | materia, preguntas y respuestas 53

[pág. 54]
Finanzas - versión clara y reordenada
 riesgo del proyecto. El resultado no prueba que haya liquidez o capacidad para ejecutarlo.
 7. WACC, riesgo de proyecto, APV y sensibilidad
 WACC usual: (E/(D+E)r_E+D/(D+E)r_D(1-T_c)), con pesos de mercado y estructura objetivo, si el
 escudo es usable y riesgo financiero relativamente estable. (r_E) puede estimarse con CAPM; costo
 de deuda debe representar rendimiento exigido, no necesariamente cupón contable. WACC de la
 empresa solo sirve para proyectos con riesgo operativo y apalancamiento comparables. Un
 proyecto en otra industria o país puede requerir beta comparable: desapalancar beta de empresas
 pares, estimar beta de activos, luego reapalancar a estructura objetivo.
 APV separa valor sin deuda de efectos de financiamiento:
 (APV=VAN_unlevered+PV(escudos)-costos de financiamiento/distress). Es práctico cuando
 apalancamiento cambia en el tiempo. Escudo fiscal de intereses no equivale automáticamente a
 T×deuda: depende de intereses, uso de pérdidas tributarias, sostenibilidad y riesgo. Sensibilidad
 altera un supuesto a la vez; escenarios combinan supuestos coherentes; análisis probabilístico
 requiere distribuciones justificadas. Umbral de equilibrio informa exposición operacional, pero no
 reemplaza VAN.
 Respuesta distinguida identifica la variable que más mueve el VAN, plantea por qué podría diferir
 del caso base y qué decisión robusta se mantiene en escenarios. No elige un WACC alto “por
 prudencia”; ajusta los flujos o tasa de forma consistente para evitar doble contabilizar riesgo.
 8. Liquidez, capital de trabajo y financiamiento de corto plazo
 Liquidez pregunta si una organización puede cumplir obligaciones en fecha; solvencia pregunta si
 valor/flujo de largo plazo soporta compromisos. Razón corriente e indicadores de caja resumen
 balances, pero no calendario de vencimientos, calidad de cuentas por cobrar, obsolescencia de
 inventario o disponibilidad real de líneas.
 Capital de trabajo operativo aproximado=cuentas por cobrar+inventarios-cuentas por pagar
 operacionales. Ciclo de conversión de efectivo=Días de inventario+Días de cuentas por cobrar-Días
 de cuentas por pagar. Reducir inventario libera caja pero puede causar quiebres; extender pagos
 preserva efectivo pero puede deteriorar precio, confianza y abastecimiento. Política agresiva de
 capital de trabajo financia activos corrientes con pasivos de corto plazo: menor costo potencial y
 mayor riesgo de refinanciamiento. Política conservadora mantiene colchón, con costo de
 financiamiento/capital inmovilizado.
 Para diagnosticar una crisis, proyecta caja semanal/mensual, cobros y pagos por vencimiento,
 prueba restricciones contractuales, vencimientos de deuda, covenants y fuentes contingentes. Un
 VAN positivo puede coexistir con insolvencia de caja si pagos ocurren antes de ingresos. Una
 decisión distinguida propone medida inmediata y plan estructural, reconoce costos a
 proveedores/clientes y evita recortar activos que generan caja crítica sin evaluar consecuencias.
Examen de Grado UC | materia, preguntas y respuestas 54

[pág. 55]
Finanzas - versión clara y reordenada
 9. Capital structure, dividendos y valor empresa
 MM sin impuestos, costos de transacción ni distress propone que estructura de financiamiento no
 cambia valor total bajo supuestos de mercados perfectos; cambia reparto entre deuda y equity y
 riesgo de equity. Con impuesto corporativo, intereses deducibles pueden añadir valor mediante
 escudo, pero costos de insolvencia, agencia, pérdida de flexibilidad y subinversión limitan deuda. La
 estructura óptima equilibra beneficios marginales y costos marginales, y depende de estabilidad de
 caja, activos colaterales, oportunidades de crecimiento, impuestos y acceso a mercado.
 Apalancamiento puede elevar retorno esperado del equity y también su riesgo. No crea riqueza por
 aumentar EPS en el corto plazo. Un covenant reduce margen de maniobra; deuda de tasa variable
 transfiere riesgo de tasas; vencimientos concentrados crean riesgo de refinanciamiento. Compara
 costo total y escenarios de cobertura de intereses, deuda/EBITDA y caja, más cláusulas relevantes.
 Dividendos y recompras distribuyen caja. Si no hay inversiones con VAN positivo, devolver recursos
 puede ser eficiente, pero decisiones también reflejan impuestos personales, señal, restricciones,
 liquidez, covenants y estabilidad de política. DDM (P_0=D_1/(r_E-g)) requiere r_E>g y crecimiento
 sostenible. DCF estima valor presente de flujos; valor terminal suele ser sensible y debe ocupar un
 papel razonable, con sensibilidad de g y r.
 10. Impuestos, fusiones y decisiones de valor
 Impuesto incremental depende de utilidad imponible y caja pagada. Depreciación fiscal genera
 escudo cuando reduce impuesto efectivamente pagado; pérdidas acumuladas solo valen si pueden
 compensar utilidades futuras según ley, plazo y probabilidad. No asumas reembolso inmediato ni
 uso completo si los flujos gravables no lo permiten.
 Una adquisición crea valor si valor combinado supera valor separado más precio pagado, costos de
 transacción, integración e inversiones necesarias. Sinergia debe desglosarse en mayores ingresos
 atribuibles, ahorros realizables, activos liberados, impuestos o costo de capital y plazo de captura.
 Una proyección “sinergia 20%” sin mecanismo es una afirmación, no valoración. Comprador puede
 crear sinergia y destruir valor por pagar prima excesiva; compara precio y valor presente
 incremental. Relación de canje distribuye propiedad; calcula participación y efectos de deuda, caja y
 sinergia, con las reglas tributarias explícitas del caso.
 11. Guía para resolver ejercicios y contestar el grado
 1. Representa la línea de tiempo, signos, unidades y moneda. 2. Clasifica flujo, tasa, riesgo y
 horizonte. 3. Plantea fórmula antes de reemplazar cifras. 4. Calcula pasos intermedios y redondeo
 al final. 5. Comprueba orden de magnitud y sentido económico. 6. Interpreta qué alternativa crea
 valor y para quién. 7. Prueba sensibilidad del supuesto que domina. 8. Recomienda con
 condición, riesgo y evidencia faltante.
 Memoriza fórmulas base y convenciones; comprende de dónde viene la tasa y qué flujo debe
 descontar; practica pasar del relato a una línea de tiempo y explicar el número. Una respuesta de
 Distinción muestra ecuación, sustitución, unidad, interpretación y limitación. Si una tabla histórica es
 ilegible o la convención del enunciado contradice un dato, presenta la lectura adoptada y su
 alternativa, sin ocultar ambigüedad.
Examen de Grado UC | materia, preguntas y respuestas 55

[pág. 56]
Finanzas - versión clara y reordenada
 Taller de problemas financieros resueltos
 Los ejercicios siguientes practican procedimientos completos. Las cifras son didácticas, salvo
 cuando se identifican expresamente como un caso histórico. En una prueba, sustituye por los datos
 del enunciado y declara cualquier convención ambigua.
 Problema 1. Comparar tasas y flujos
 Una inversión paga $4 millones al final de cada año durante tres años y $10 millones adicionales al
 final del tercero. La tasa anual efectiva apropiada es 10%. Se calcula desde hoy:
 Fecha Flujo Factor Valor presente
 1 $4m 1/1,10 $3,636m
 2 $4m 1/1,10² $3,306m
 3 $14m 1/1,10³ $10,518m
 Valor presente total ≈ $17,460 millones. Si hoy cuesta $16m, VAN≈$1,460m. El error típico es
 sumar los flujos sin descontar o descontar el principal desde t=2. Si la tasa efectiva mensual fuera
 0,8%, conviértela a anual efectiva ((1,008)^12-1≈10,03%); no multipliques automáticamente por 12.
 Problema 2. Precio de un bono y sensibilidad
 Bono con valor par $1.000, cupón anual 6%, vencimiento a tres años y rendimiento requerido 8%.
 Precio:
 (P=60/1,08+60/1,08^2+1.060/1,08^3≈55,56+51,44+841,46=$948,46.)
 Vende bajo par porque cupón (6%) < yield (8%). Si el yield baja, el precio sube. La duración se
 calcula con pesos (PV(CF_t)/P) multiplicados por t. Con flujos presentes aproximados 55,56; 51,44;
 841,46, duración Macaulay ≈(55,56×1+51,44×2+841,46×3)/948,46≈2,83 años. Duración modificada
 ≈2,83/1,08=2,62. Para alza yield de 0,5 puntos porcentuales, ΔP/P≈-2,62×0,005=-1,31%; el precio
 aproximado cae $12,42. Convexidad ajustaría esta aproximación. Cupón, yield y retorno realizado
 deben distinguirse; el precio futuro también depende de reinversión, default y venta.
 Problema 3. Diversificación y beta
 Activo A: retorno esperado 8%, desviación 10%; B: retorno esperado 12%, desviación 20%;
 correlación 0,25. Cartera 60% A y 40% B:
 (E(R_p)=0,6(8%)+0,4(12%)=9,6%.)
 Varianza (=0,6^2(0,10^2)+0,4^2(0,20^2)+2(0,6)(0,4)(0,25)(0,10)(0,20))
 (=0,0036+0,0064+0,0024=0,0124), por tanto σ≈11,14%. El promedio ponderado de volatilidades
 sería 14%; la menor volatilidad de cartera proviene de covarianza imperfecta. No se eliminó riesgo
 sistemático. Para cobertura de pasivo, se debe sustituir la variable por resultado neto de activos
 menos pasivos y buscar cobertura, no elegir el activo de menor varianza aislada.
 Si (R_f=4%), prima de mercado=6% y beta=1,2, CAPM estima costo de equity
 (4%+1,2(6%)=11,2%). Beta sobre 1 representa mayor sensibilidad sistemática que mercado en el
 modelo, no 20% más riesgo total. Si moneda/horizonte de Rf no corresponde a flujos, la tasa no es
Examen de Grado UC | materia, preguntas y respuestas 56

[pág. 57]
Finanzas - versión clara y reordenada
 consistente.
 Problema 4. Opción, réplica y no arbitraje
 Acción vale100 hoy; en un año será120 u80. Tasa libre de riesgo5%. Call europea con strike100
 paga20 en el estado alto y0 en el bajo. Sea Δ el número de acciones y B el monto invertido en bono
 hoy (negativo si se pide prestado). Las ecuaciones de pagos son120Δ+1,05B=20 y80Δ+1,05B=0.
 Restando,40Δ=20 y Δ=0,5. De la segunda,1,05B=-40 y B=-38,095. Precio de la
 call=0,5×100-38,095=11,905. Verificación al vencimiento:estado alto60-40=20;estado bajo40-40=0.
 Si se confundiera la deuda terminal40 con su valor presente38,095, se obtendría erróneamente10.
 Mantener fecha y unidades de cada variable evita ese error.
 Con probabilidad neutral (q=(1,05-0,8)/(1,2-0,8)=0,625), precio también es
 ([0,625(20)+0,375(0)]/1,05=11,905). q es valoración bajo medida neutral, no probabilidad empírica
 de alza. La réplica y fórmula coinciden; si no, hay inconsistencia aritmética o de convención.
 Problema 5. Flujo de caja con impuestos y capital de trabajo
 Una nueva línea exige maquinaria por $120m hoy, vida útil 4 años, depreciación recta a cero,
 capital de trabajo $15m hoy y recuperación íntegra al final. Ingresos anuales $100m, costos
 operativos de caja $55m, impuesto 25%, sin valor de rescate. Depreciación anual=30.
 EBIT=100-55-30=15; impuesto=3,75; utilidad neta=11,25; flujo
 operativo=utilidad+depreciación=41,25. Flujos: t0=-135; t1-t3=41,25; t4=56,25 (incluye liberación de
 NWC). A WACC 10%, factor anualidad a 4 años ≈3,1699, PV operación=41,25×3,1699≈130,76; PV
 liberación de NWC=15/1,1⁴≈10,25; VAN≈130,76+10,25-135=6,01m.
 El cálculo supone ventas/costos constantes, NWC recuperable, impuesto pagado en periodo,
 WACC adecuado y depreciación fiscal igual a contable. Sensibiliza margen, uso de capacidad,
 inversión y demanda; prueba si capital de trabajo debe crecer con ventas y si hay valor residual o
 costos de cierre. Nunca sumes depreciación como salida de caja; su efecto opera vía impuestos.
 Problema 6. WACC y riesgo comparable
 Firma tiene deuda de mercado 40 y equity 60; costo de deuda antes de impuesto 7%, costo equity
 12%, impuesto 25%. (WACC=0,6(12%)+0,4(7%)(1-0,25)=9,3%.) Este cálculo solo vale si pesos y
 riesgos son correctos, escudo utilizable y estructura estable. Si un proyecto tiene negocio de menor
 riesgo, aplicar 9,3% puede rechazar inversión valiosa; si es más riesgoso, puede aceptar un
 proyecto que destruye valor. Usa comparables operativos y estructura objetivo.
 El riesgo financiero y operativo deben separarse. Si un comparable tiene beta equity 1,5,
 deuda/equity 0,5 e impuesto 25%, beta de activos aproximada
 βA=βE/[1+(1-T)D/E]=1,5/[1+0,75(0,5)]=1,091. Si proyecto objetivo usa D/E=1, beta equity
 aproximada 1,091[1+0,75(1)]=1,909. Luego CAPM requiere Rf y prima de mercado coherentes.
 Fórmulas de apalancamiento dependen de supuestos de deuda/riesgo; indica si hay beta de deuda
 relevante.
Examen de Grado UC | materia, preguntas y respuestas 57

[pág. 58]
Finanzas - versión clara y reordenada
 Problema 7. Capital de trabajo y decisión de liquidez
 Una distribuidora tiene días inventario 55, días de cobro 42 y días de pago 35. Ciclo de
 caja=55+42-35=62 días. Con ventas diarias a crédito $20m, bajar cobro en 7 días libera
 aproximadamente $140m brutos de caja, aunque puede implicar descuento, costo de cobranza o
 pérdida de clientes. Reducir inventario 10 días puede liberar caja adicional; su costo esperado son
 quiebres y ventas perdidas. Negociar pago 10 días más largo también libera caja, pero puede dañar
 relación o elevar precio proveedor.
 La decisión compara valor presente de liberación y costos, riesgo de servicio y efecto en
 proveedores. Revisa vencimientos próximos, líneas comprometidas y covenants. No recomiendes
 “maximizar cuentas por pagar” si expone suministro esencial o incumple contrato. Liquidez se
 planifica por fechas, no solo razón corriente.
 Problema 8. Adquisición y captura de sinergias
 Comprador vale $500m; objetivo vale $100m stand-alone. Sinergias esperadas: ahorro anual
 después de impuestos $12m durante 5 años, riesgo equivalente a 10%, inversión de integración
 hoy $20m. Factor anualidad a 10%, cinco años ≈3,7908; PV ahorro≈$45,49m; valor combinado neto
 de integración=500+100+45,49-20=$625,49m. Si comprador paga $130m por objetivo, prima sobre
 stand-alone es $30m; valor neto de la transacción para comprador=sinergia PV
 45,49-integración20-prima30=-$4,51m, antes de otros riesgos. La compra puede tener lógica
 industrial y aun así destruir valor para accionistas del comprador.
 Valida qué parte del ahorro es realmente adicional, quién la ejecuta, costos de salida, retención de
 talento, reacción de clientes y plazo. Sensibiliza sinergia y descuento. El precio pagado transfiere
 valor al vendedor; no confundir tamaño de la empresa combinada con valor creado.
 12. Errores que debes detectar en una solución
 • Descontar flujo nominal con tasa real o mezclar mensual y anual.
 • Descontar FCFF al costo de equity o flujo a accionista al WACC.
 • Usar WACC corporativo en un proyecto con otro riesgo.
 • Incluir costo hundido y omitir costo de oportunidad.
 • Olvidar impuestos, capital de trabajo, inversión de mantenimiento o efectos en ventas existentes.
 • Aceptar TIR alta sin comparar escala, plazo y VAN incremental.
 • Llamar “retorno” al cambio de precio de un bono sin separar cupón y ganancia de capital.
 • Interpretar probabilidad neutral como pronóstico de mercado.
 • Confundir creación de valor de una adquisición con prima pagada.
 • Dar un resultado numérico sin unidad, calendario ni interpretación de decisión.
Examen de Grado UC | materia, preguntas y respuestas 58

[pág. 59]
Finanzas - versión clara y reordenada
 Materias respaldadas por los resúmenes de Finanzas I y II
 A. Preferencias bajo incertidumbre
 Un resultado riesgoso no se evalúa solo por su promedio. La utilidad esperada es (EU=Σ_s p_s
 U(W_s)), donde W_s es riqueza final en estado s. Aversión al riesgo significa utilidad cóncava: la
 persona prefiere una riqueza segura igual al valor esperado de una lotería antes que la lotería
 misma. La prima de riesgo es la diferencia entre valor esperado monetario y equivalente cierto. Un
 mayor retorno esperado puede compensar un mayor riesgo, pero no existe una regla universal de
 “más retorno por más riesgo” en cada activo aislado.
 La medida ARA (A(W)=-U''(W)/U'(W)) y la medida relativa RRA (R(W)=-WU''(W)/U'(W)) caracterizan
 curvatura local. Sirven para discutir cómo cambia tolerancia al riesgo con riqueza bajo una función
 elegida; no se observan directamente sin supuestos. No confundir una persona con una firma: una
 empresa diversificada puede gestionar riesgos de forma distinta al accionista y existen impuestos,
 distress y costos de agencia. En una respuesta, define estados/probabilidades y riqueza terminal,
 calcula utilidad si se entrega U, y explica qué preferencia o restricción cambia la decisión.
 B. Más allá del CAPM de un factor
 CAPM conecta beta de mercado con retorno esperado en equilibrio y bajo supuestos de cartera
 media-varianza, mercado y expectativas. APT propone que varios factores sistemáticos explican
 retornos: (R_i-R_f=α_i+Σ_kβ_ikF_k+epsilon_i). Sin arbitraje, exposición a factores relaciona prima
 esperada con primas λ. En aplicaciones empíricas, modelos multifactoriales como SMB/HML
 añaden exposiciones vinculadas a tamaño y valor contable/mercado; sus nombres no garantizan
 que sean factores correctos para todo mercado o periodo.
 Un alpha estimado es retorno no explicado por el modelo escogido, no prueba automáticamente
 habilidad. Puede reflejar factor omitido, error de estimación, selección retrospectiva, costos,
 iliquidez o riesgo raro. Compara CAPM y multifactor fuera de muestra, examina estabilidad temporal
 y no uses el modelo con mejor ajuste histórico sin justificación. Beta equity y beta activos se
 relacionan por apalancamiento; fórmula depende de impuestos, deuda riesgosa y supuestos de
 MM. Para costo de capital, el objetivo es retorno requerido pertinente al flujo y riesgo; no forzar un
 modelo por tener más factores.
 C. Precio forward y arbitraje de divisas
 Para activo sin beneficios, precio forward por no arbitraje (F_0=S_0(1+r)^T) en capitalización anual;
 con tasa continua (F_0=S_0e^rT). Si hay costo de almacenamiento u otros flujos, ajusta carry. En
 tipo de cambio, la paridad cubierta relaciona spot, forward y tasas en las dos monedas. Define
 cotización con precisión (moneda doméstica por extranjera o inversa) y periodo. Una diferencia
 frente a paridad solo permite arbitraje si todos los contratos, fechas, tasas, costos y límites de
 financiamiento son comparables.
 Ejemplo en forma genérica. Si 1 unidad de moneda extranjera cuesta S domésticas, invertir
 doméstico produce ((1+r_d)^T) por unidad inicial; comprar moneda extranjera, invertir y vender a
 forward produce (S_0(1+r_f)^T/F_0) unidades domésticas, según cotización y dirección. La
 igualdad define F₀. Para demostrar oportunidad, construye cuatro pasos de caja hoy y al
 vencimiento; no basta comparar “tasas altas” entre países.
Examen de Grado UC | materia, preguntas y respuestas 59

[pág. 60]
Finanzas - versión clara y reordenada
 D. Valoración de acciones y de empresas
 En Gordon, (P_0=D_1/(r_E-g)) si dividendos crecen a tasa constante sostenible, r_E>g y el riesgo
 está contenido en la tasa. Si D₀ es dividendo recién pagado, D₁=D₀(1+g). Para crecimiento por
 etapas, proyecta dividendos específicos durante fase alta, calcula valor terminal con crecimiento
 estable y descuenta todo. Una variación pequeña en g cuando se acerca a r_E cambia mucho
 valor; presenta sensibilidad y valida reinversión y payout.
 Valor firma corresponde a activos operacionales y se obtiene descontando FCFF al WACC o por
 APV. Valor equity deriva de flujos del accionista descontados al costo de equity o valor firma menos
 deuda neta y otros derechos, con coherencia de fechas. No restes deuda dos veces. EBITDA no es
 flujo libre: omite impuestos, capex y capital de trabajo. Múltiplos P/U, bolsa/libro y EV/EBITDA son
 comparables relativos, no sustitutos automáticos de DCF. Elige pares de industria, crecimiento,
 riesgo, margen, inversión y definición de la métrica; diferencia en múltiplo puede reflejar
 fundamentos o error de comparación.
 E. Apalancamiento operativo, financiero y combinado
 Costos fijos operacionales amplifican variación de EBIT ante ventas; deuda amplifica variación de
 utilidad/patrimonio ante EBIT. El grado de apalancamiento operativo, en una aproximación de
 costos fijos, es porcentaje de cambio de EBIT sobre porcentaje de cambio de ventas; el financiero
 relaciona cambio porcentual de utilidad por acción con cambio porcentual de EBIT; combinado
 refleja efecto conjunto. Estas medidas dependen del punto de operación y se vuelven muy grandes
 cerca del punto de equilibrio, por lo que no son propiedades constantes de una empresa.
 Interpretación. Una estructura con alto costo fijo puede ser atractiva cuando demanda estable
 supera equilibrio, y peligrosa ante baja de volumen. La deuda puede elevar ROE en escenarios
 positivos, pero aumenta probabilidad de incumplimiento y volatilidad del accionista. Evalúa
 escenarios sobre volumen, precio, costos, intereses y covenants, no solo el ROE esperado.
 Derechos de acreedores tienen prioridad según contrato/ley; accionistas reciben residual. Distingue
 insolvencia económica de problema temporal de liquidez.
 F. Planificación financiera y fondos externos requeridos
 La planificación conecta ventas proyectadas con activos necesarios, pasivos espontáneos, utilidad
 retenida, capacidad y financiamiento. Pro forma no consiste en multiplicar todo por crecimiento:
 inventarios y cuentas por cobrar pueden seguir ventas; capacidad fija sube discretamente al
 agotarse capacidad; deuda/acciones dependen de política de financiamiento; dividendos dependen
 de payout. Fondos externos requeridos aproximados (FER=Δ activos-Δ pasivos
 espontáneos-ganancias retenidas), ajustando capex, capacidad o crecimiento según el caso.
 Ejemplo. Ventas crecen 10%, activos operacionales base 500 requieren proporcionalmente 50
 adicionales, pasivos espontáneos crecen 15, utilidad neta proyectada 40 y payout 25%; utilidades
 retenidas=30. FER=50-15-30=5. La empresa necesitaría $5 de capital externo bajo esos supuestos.
 Si hay capacidad ociosa, la inversión en activo fijo puede ser menor; si el crecimiento supera
 crecimiento sustentable, debe cambiar margen, retención, rotación o apalancamiento. La tasa de
 crecimiento sustentable se deriva de crecimiento compatible con rentabilidad, payout y estructura
 de capital estable; define fórmula del curso antes de aplicarla porque las variantes difieren.
Examen de Grado UC | materia, preguntas y respuestas 60

[pág. 61]
Finanzas - versión clara y reordenada
 G. Inventarios y administración de efectivo
 Inventario equilibra costo de ordenar, mantener, quiebre y oportunidad. En modelo EOQ básico con
 demanda anual D, costo por pedido S y costo anual de mantener una unidad H, cantidad
 económica (Q^*=√2DS/H). La fórmula minimiza costo de pedido (DS/Q) más costo de mantención
 (HQ/2), bajo demanda conocida y constante, reposición instantánea, sin descuentos y sin quiebres.
 No es una regla automática: incertidumbre lleva stock de seguridad, lead time y nivel de servicio;
 descuentos por volumen requieren comparar costo total.
 Tesorería debe conservar efectivo para transacciones, precaución y oportunidad, equilibrándolo con
 rendimiento alternativo. Modelo Baumol trata flujos netos relativamente predecibles y costo fijo de
 convertir valores en efectivo; Miller-Orr permite flujos aleatorios y establece límite inferior L, punto
 de retorno Z y límite superior H, transfiriendo fondos al tocar límites. En términos generales,
 (Z=L+[3bσ^2/(4i)]^1/3), y H=3Z-2L bajo supuestos clásicos. b es costo por transacción, σ² varianza
 diaria del flujo e i costo de oportunidad diario. Unidades de periodo deben coincidir. Modelo
 recomienda regla de saldo, no predice incertidumbre perfectamente; restricciones bancarias y
 riesgo de liquidez importan.
 H. Crédito comercial, cobranza y ciclo de caja
 Dar crédito puede aumentar ventas o adelantar compra, pero inmoviliza fondos, agrega
 administración y riesgo de incobrable. Política define plazo, descuento por pronto pago, evaluación
 del cliente, límite y cobranza. Analiza flujo incremental: margen de ventas adicionales, costo de
 financiamiento durante el plazo, incobrables, descuento aceptado, costo administrativo, efecto de
 adelantar ventas y cambios de precio. Venta financiada que solo adelanta compra no equivale a
 demanda incremental.
 Para descuento “d/periodo neto t”, el costo efectivo implícito de no tomar descuento se calcula con
 dinero ahorrado vs costo de pagar después. Por ejemplo, términos 2/10 neto 30: renunciar a 2%
 para conservar fondos 20 días tiene tasa periódica (0,02/(1-0,02)=2,0408%); anualización simple
 aproximada multiplica por 365/20, mientras efectiva compone. La alternativa de crédito bancario se
 compara con tasa efectiva consistente, fees y efecto de relación con proveedor.
 Al aprobar una nueva política, calcula (VAN_nueva-VAN_actual). Considera probabilidad de pago,
 margen por venta, gasto de cobranza, descuentos, duración de cartera y retorno del capital. Una
 política que minimiza morosidad puede rechazar clientes rentables; otra que maximiza ventas
 puede aumentar pérdidas. Segmenta por riesgo y revisa con datos históricos, protección al cliente y
 concentración.
 I. Arrendamiento financiero y deuda de largo plazo
 Leasing distribuye pagos por uso de activo y puede incluir opción de compra, transferencia de
 riesgos, garantías y tratamiento contable/tributario. Compara adquirir versus arrendar en flujos
 después de impuestos, incluyendo desembolso, pagos, depreciación/escudo, valor residual,
 mantenimiento, flexibilidad y costo de financiamiento. Tratamiento legal y contable depende de
 norma vigente y contrato; no infieras propiedad económica solo por nombre “operativo/financiero”.
 Deuda de corto plazo incluye crédito proveedor, línea bancaria y factoring; costo depende de tasa,
 comisiones, garantías y días. Factoring adelanta caja a cambio de descuento y, según contrato,
 puede transferir o no el riesgo de incobrabilidad. Warrants pueden usar inventario como garantía y
Examen de Grado UC | materia, preguntas y respuestas 61

[pág. 62]
Finanzas - versión clara y reordenada
 restringir disponibilidad. Deuda pública/bonos define moneda, plazo, cupón, covenants, garantías,
 rescate, clasificación, subordinación y riesgo de tasa/crédito. El menor cupón no siempre implica
 menor costo económico si emisión bajo par, fees o garantías son relevantes.
 J. Opciones reales: valorar flexibilidad sin duplicarla
 Una opción real es la posibilidad de alterar una decisión de inversión cuando llega información:
 postergar, expandir, reducir, abandonar o cambiar insumo/producto. VAN estático puede omitir
 flexibilidad valiosa, sobre todo si incertidumbre es alta y decisión irreversible. Sin embargo, una
 “opción” no debe añadirse como número arbitrario: identifica decisión futura, información que la
 habilita, costo de ejercer, valor de espera y pérdida de caja por retraso. Si empresa puede
 abandonar, reconoce precio de venta/costos de cierre y pérdidas futuras evitadas.
 La flexibilidad tiene valor cuando existen incertidumbre, irreversibilidad y posibilidad de decidir
 después. Esperar también tiene costo: pérdida de ventaja, competencia, vencimiento de permiso o
 flujo postergado. Árbol de decisión ayuda a organizar estados, probabilidades y decisiones;
 valoración por opciones requiere supuestos de distribución, riesgo y posibilidad de replicar. No
 descuentas al retorno esperado simplemente por cambiar etiquetas. Muestra VAN base, escenarios
 con flexibilidad y condición para ejercer; evita contar dos veces la misma contingencia en
 proyección y valor terminal.
 K. Razones financieras: diagnóstico y límites
 ROA puede expresarse como utilidad operacional sobre activos operacionales y descomponerse en
 margen operacional × rotación de activos. ROE=utilidad neta/patrimonio; DuPont lo separa en
 margen, rotación y apalancamiento bajo definiciones consistentes. Liquidez corriente=activos
 corrientes/pasivos corrientes; prueba ácida excluye inventario según convención. Cobertura de
 intereses compara generación de caja/utilidad operacional con interés, especificando medida.
 Rotación de cuentas por cobrar y días de cobro describen eficiencia de crédito; rotación de
 inventario y días de inventario describen permanencia; cuentas por pagar/días de pago muestran
 financiamiento proveedor.
 Las razones usan valores contables, pueden verse afectadas por política, estacionalidad, inflación,
 clasificación, valoración de inventario y ventanas de cierre. Compara misma industria, periodo y
 definición. Una razón alta no siempre es buena: exceso de caja puede indicar uso ineficiente o
 colchón necesario; baja deuda puede limitar crecimiento o reflejar menor riesgo. Razones no
 revelan monto/timing de flujos futuros; complementa con caja proyectada, deuda, covenants y
 análisis cualitativo.
 Unidades de profundización: decisiones de Dirección
 Financiera
 Pronóstico financiero, crecimiento y fondos externos
 Una empresa puede crecer y aun así quedarse sin caja. El pronóstico financiero convierte una
 hipótesis comercial -más unidades, precio, margen y plazos de cobro/pago- en estados proyectados
 y en una pregunta de financiamiento. El orden evita el error de proyectar ventas y “añadir” deuda al
 final sin entender qué la produce.
Examen de Grado UC | materia, preguntas y respuestas 62

[pág. 63]
Finanzas - versión clara y reordenada
 1. Proyecta ventas por volumen, precio, mezcla y capacidad, separando crecimiento nominal de
 real. 2. Proyecta costos variables, costos fijos y gastos con su respectivo impulsor; no supongas
 que todo crece al mismo porcentaje. 3. Proyecta cuentas por cobrar, inventarios y cuentas por
 pagar según días o rotaciones, y activos fijos según capacidad/inversión. 4. Integra resultados,
 balance y flujo de caja: el mayor capital de trabajo y la inversión pueden consumir efectivo aunque
 exista utilidad contable. 5. Calcula el financiamiento requerido, revisa holguras de deuda y
 covenants y diseña un plan con escenarios.
 El crecimiento sostenible es una relación entre rentabilidad, retención y financiamiento, no una cifra
 universal. En un modelo simplificado con ROE constante, razón de retención (b), sin emisión nueva
 y sin cambio de apalancamiento, (g_s approx ROE imes b). La relación supone que la rentabilidad y
 política de dividendos persisten y que la empresa puede mantener su estructura. Crecer sobre esa
 tasa puede requerir nueva deuda/capital, mayor eficiencia, cambios de margen/rotación o menor
 distribución. No significa que crecer por sobre ella sea imposible o malo; identifica que el
 crecimiento requiere recursos adicionales.
 Ejemplo. Si ROE = 15% y la empresa retiene 60% de utilidades, (g_s approx 9%). Si ventas crecen
 15%, la diferencia alerta sobre financiamiento o cambio en eficiencia, pero no cuantifica por sí sola
 cuánto pedir prestado. Debes hacer balance pro forma porque inventario, cuentas por cobrar,
 capacidad, proveedores y margen pueden cambiar.
 Fondos externos requeridos (FER/EFN) es el monto de financiamiento que equilibra el balance
 proyectado cuando ciertas partidas crecen con ventas y otras se financian espontáneamente. La
 forma abreviada “activos necesarios menos pasivos espontáneos menos utilidades retenidas”
 depende de supuestos de proporcionalidad, capacidad instalada, dividendos y margen. Para una
 respuesta distinguida, declara cuáles partidas se modelan como variables de ventas y presenta un
 escenario de sensibilidad (crecimiento, margen, días de cobro, inventario, proveedores).
 Gestión de inventario y efectivo: costos que compiten
 El inventario protege continuidad y servicio, pero ocupa capital, genera almacenamiento, seguro,
 merma y obsolescencia. Pedir más unidades reduce frecuencia de pedidos y puede capturar
 descuentos, pero eleva inventario promedio. El modelo EOQ encuentra una cantidad que equilibra
 costos de pedido y mantención bajo demanda y plazos conocidos, precio unitario constante,
 reposición instantánea y ausencia de quiebres:
 Q^*=√(2DS)/(H)
 Aquí (D) es demanda anual en unidades, (S) el costo fijo por pedido y (H) el costo anual por
 mantener una unidad. El costo relevante anual es (DS/Q + HQ/2). En el óptimo, ambos
 componentes se igualan. Si hay plazo de entrega (L), el punto de reorden básico es demanda diaria
 esperada por (L); con incertidumbre se agrega stock de seguridad para un nivel de servicio
 explícito. La fórmula deja de ser óptima ante demanda volátil, múltiples productos con restricciones
 de caja/capacidad o descuentos escalonados; en esos casos compara políticas, costo de faltantes y
 capital inmovilizado.
 Ejemplo. (D=10.000) unidades/año, (S=$20) por pedido y (H=$2) por unidad/año:
 (Q^*=√200.000≈447) unidades. Son unos 22,4 pedidos al año y el inventario cíclico promedio es
 223,5 unidades. No concluyas que esa política es óptima en la práctica sin agregar variabilidad,
 lead time, perecibilidad y costo de quiebre.
Examen de Grado UC | materia, preguntas y respuestas 63

[pág. 64]
Finanzas - versión clara y reordenada
 El modelo de Baumol aplica una lógica parecida a caja: transferir inversiones líquidas a efectivo
 incurre en costo fijo por operación y mantener efectivo sacrifica rendimiento. Bajo uso de efectivo
 conocido y uniforme, saldo óptimo (C^*=√2FT/i), donde (F) es costo por conversión, (T) necesidad
 total de caja del periodo e (i) rendimiento por periodo perdido. Miller-Orr adapta una banda de
 saldos cuando los flujos son inciertos: define límite inferior, punto de retorno y límite superior según
 variabilidad, costo de transacción e interés. Ambos son modelos de decisión, no sustitutos de una
 previsión semanal de pagos, nómina, impuestos y vencimientos.
 Crédito comercial, morosidad y descuento por pronto pago
 Otorgar crédito puede aumentar ventas al reducir fricción y permitir que el cliente financie su
 compra; también desplaza la cobranza, exige capital y expone a impago. Una política se evalúa por
 contribución incremental, no solo por ventas. Estima quién recibe crédito, cuánto compra, margen
 unitario, probabilidad de pago, plazo, costos de cobranza y efecto en clientes que ya habrían
 comprado al contado.
 Un descuento “(d/ n), neto (N)” ofrece descuento (d) si se paga en (n) días; vencido ese plazo, se
 paga el total al día (N). Renunciar al descuento equivale a financiarse por el periodo adicional a una
 tasa implícita aproximada (d/(1-d)× 365/(N-n)), anualizada simple. La efectiva es
 ((1/(1-d))^365/(N-n)-1). Compara con costo de financiamiento y riesgo, cuidando que el cliente
 valore liquidez y que la empresa no regale margen a quienes igual pagaban pronto.
 El costo de una política más liberal incluye más saldo promedio de cuentas por cobrar, incobrables
 y administración. El beneficio es margen de ventas verdaderamente incremental; no atribuyas toda
 venta de clientes aprobados a la nueva política si existía canibalización desde ventas al contado.
 Segmenta límites, scoring y cobranza; monitorea tasa de aprobación, días de cobro, mora por
 cohorte, pérdida esperada, contribución y concentración. Rechazar a todo cliente de riesgo puede
 destruir valor; aprobar sin precio/riesgo también.
 Financiamiento de corto plazo y factoring
 Las fuentes de corto plazo incluyen crédito de proveedores, línea bancaria, pagaré, factoring y otras
 soluciones. La comparación usa costo efectivo total, disponibilidad, garantías, covenants, moneda,
 renovación, recurso contra el cedente, impacto comercial y riesgo de refinanciamiento. Un
 financiamiento barato que vence antes de convertirse el inventario en caja crea riesgo de liquidez.
 La regla práctica es alinear vencimiento y moneda de la fuente con el ciclo del activo financiado,
 salvo que la empresa pueda administrar explícitamente la brecha.
 El factoring vende o cede cuentas por cobrar para adelantar caja; puede ser con recurso (el cedente
 conserva parte del riesgo de incobrabilidad) o sin recurso según contrato. El anticipo no equivale a
 ingreso: se paga una comisión/descuento, se transfiere gestión o riesgo en la medida pactada y
 puede existir notificación al cliente. Para decidir, calcula caja neta recibida, costo anual equivalente,
 impacto en cobro y relación con clientes, y compara con una línea bancaria. El warrant o garantía
 puede ampliar acceso a fondos pero compromete activos y prioridad futura. Leer “factoring” o
 “warrant” en una alternativa no resuelve por sí solo si es conveniente.
Examen de Grado UC | materia, preguntas y respuestas 64

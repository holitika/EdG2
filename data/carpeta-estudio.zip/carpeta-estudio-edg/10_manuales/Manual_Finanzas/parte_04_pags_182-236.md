# Manual de Finanzas · parte 4 (páginas 182-236)

Fuente: 02_MANUAL_ULTIMATE_FINANZAS_EDG_2027_V2_FORMULAS_CLARAS

[pág. 182]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2013 | pregunta 3
 Convocatoria 1 | página original 119 | Riesgo operacional y deuda
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº 3
 Jorge y Cristina son analistas de una AFP, que conversan sobre el riesgo relevante de las acciones de dos empresas
 chilenas, de propiedad muy diseminada entre miles de accionistas, que se transan en el mercado de capitales chileno y
 que a cada uno de ellos les corresponde analizar. Jorge es analista de la Empresa “Desarrollos Tecnológicos
 Comunicacionales S.A” (DETECOM S.A.), y Cristina de la Empresa “Transportes Ejecutivos S.A.” (TRANSEJEC
 S.A.).
 Algunas características financieras y del negocio propiamente tal de cada una de estas dos empresas, se exponen a
 continuación.
 DETECOM S.A., se dedica a la investigación y desarrollo de nuevas y complejas aplicaciones comunicacionales para
 computadores y aparatos de comunicación de venta masiva, como tabletas y smartphones, etc. La empresa desarrolla
 nuevas aplicaciones que son ofrecidas a los grandes fabricantes de equipos de las marcas de mayor prestigio, quienes
 adquieren estas aplicaciones a DETECOM S.A., a través de la compra de una licencia que les da el derecho a instalar la
 aplicación en los equipos que ellas comercializan. En promedio la tasa esperada de éxito no supera el 1% por
 aplicación, esto es, de cada 100 aplicaciones se espera que una de ellas sea finalmente comprada por los fabricantes de
 equipos. Esta tasa de éxito es más alta cuando la economía está en expansión que cuando hay recesiones (la gente no
 adopta nuevas tecnologías con tanta intensidad cuando el mercado laboral está complicado). Cuando se tiene éxito con
 una aplicación, los resultados financieros de DETECOM S.A. son verdaderamente significativos. Por otra parte,
 cuando DETECOM S.A. logra “colocar” (vender) alguno de sus desarrollos, queda obligada al cumplimiento de una
 serie de compromisos futuros, entre los cuales destacan la obligación de actualizar periódicamente la aplicación,
 garantizar a los usuarios de la aplicación que ellas estarán siempre libres de cualquier “contaminación” con “virus”
 computacionales, reponer la aplicación a cualquier usuario que sufra un desperfecto, etc., todo esto por un plazo de 10
 años a contar de la fecha de venta de la licencia al fabricante de equipos. Para respaldar el cumplimiento de estos
 compromisos, la empresa debe dejar una garantía a favor de la compañía compradora de la aplicación computacional,
 equivalente al 10% del monto total (US$) de la compra que haga el fabricante de los equipos. Esta garantía no puede
 ser ejecutada unilateralmente por el cliente sin antes demostrar ante tribunales que DETECOM S.A. no cumplió con
 alguno de sus compromisos. Por cierto, si al término del décimo año de efectuada la venta de las licencias, DETECOM
 S.A. ha cumplido los compromisos adquiridos con sus clientes, se le devuelve la garantía respectiva. Finalmente, se
 sabe que DETECOM S.A. es una de las pocas empresas chilenas en esta industria y sin lugar a dudas la más exitosa.
 Con 15 años de existencia, su mayor activo es el afiatado y exitoso equipo de ingenieros, quienes vienen trabajando
 juntos desde la creación de la empresa. Ellos han sido capaces de competir con los desarrolladores internacionales, sin
 desafiarlos en el mercado mundial, sino que centrándose en dar soluciones adaptadas a la realidad del mercado local,
 aprovechando así tanto su capacidad técnica como sus capacidades de marketing y entendimiento del consumidor local.
 TRANSEJEC S.A., por su parte, es una empresa que presta servicios de transporte a ejecutivos de grandes compañías
 de prácticamente todos los sectores de la economía (ejecutivos de empresas mineras, del sector financiero, del sector
 forestal, de tiendas de departamentos, etc.). Su negocio consiste básicamente en suscribir contratos con grandes
 empresas, en los que TRANSEJEC S.A. se compromete a disponer de una flota de automóviles, de marcas de
 reconocido prestigio, con no más de dos años de uso, para el traslado de ejecutivos, clientes, invitados, etc. dentro de
 Santiago y en ciudades cercanas a Santiago, etc. Los contratos son anuales y renovables. Para disponer de los
 automóviles, TRANSEJEC S.A. suscribe contratos de arriendo operativos2 por dos años con las compañías de
 arrendamiento o “leasing” de automóviles que poseen las empresas distribuidoras de automóviles, contratos que si bien
 tienen una opción de compra del automóvil por parte del arrendatario al término del segundo año, en sus años de
 operación TRANSEJEC S.A. no ha ejercido esta opción sino que ha preferido devolver los vehículos y firmar nuevos
 contratos para así modernizar su flota y cumplir con lo que ofrece a sus clientes. TRANSEJEC S.A es una relativa
 2: En este tipo de contratos, el costo del arriendo se reconoce mensualmente como gasto.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 182

[pág. 183]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2013 | pregunta 3
 Convocatoria 1 | página original 120 | Riesgo operacional y deuda
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 rareza en esta industria, ya que pese a la importante entrada y salida de participantes, ha mantenido sus operaciones en
 el país por más de 20 años. Esta permanencia en el tiempo da cuenta de su alto prestigio en el medio, y de la seriedad y
 alta calidad de su servicio. Lo anterior le permite generar flujos de caja operacionales bastante estables tanto en
 períodos de expansión como de contracción de la economía.
 Revisado el nivel de endeudamiento de cada una de estas empresas, se ha encontrado lo siguiente:
 DETECOM S.A TRANSEJEC S.A.
 Razón de Endeudamiento [Deuda/Patrimonio]: 0,5 1,5
 (medida usando valores económicos o de mercado)
 Conocido todos los antecedentes expuestos, Jorge, analista de DETECOM S.A, ha hecho ver a Cristina, analista de
 TRANSEJEC S.A., que sin duda desde el punto de vista de los accionistas o dueños de TRANSEJEC S.A., el alto
 nivel de endeudamiento que presenta la empresa de la que ellos son propietarios, debe ser motivo de preocupación.
 Para Jorge, una razón de endeudamiento de 1,5 veces, en una economía en la que el promedio de la Razón de
 Endeudamiento de las empresas, medida (usando valores económicos o de mercado) como el cuociente
 [Deuda/Patrimonio], se puede estimar en 1,0, no puede sino ser preocupante. Jorge le ha planteado a Cristina que
 seguramente en el próximo Comité de Inversiones, ella deberá tener razones muy fundadas para “defender” la
 inversión de la AFP en una empresa con tan alto nivel de endeudamiento
 Se Pide:
 1. Indicar y fundamentar, los conceptos más importantes que, desde el punto de vista de la teoría financiera, podrían
 explicar que, dadas las características de cada una de las dos empresas, es razonable esperar los dueños de
 TRANSEJEC S.A., estén dispuestos a operar su empresa con un nivel de endeudamiento mayor que el de
 DETECOM S.A. Suponga que, en términos de su preferencia frente al riesgo, los accionistas de ambas empresas
 son idénticos.
 2. A partir de la respuesta anterior, indicar por qué, incluso se podría estar dando que, el nivel de endeudamiento
 actual de DETECOM S.A ([D/P] = 0,5), podría estar significando un mayor nivel de riesgo relevante de la inversión
 para sus accionistas, que el de TRANSEJEC S.A para los suyos.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 183

[pág. 184]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2024 | pregunta 3
 Convocatoria 1 | página original 407 | Riesgo, TIR y múltiplos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº3
 A continuación, se desarrollan de manera breve tres temas o comentarios completamente independientes entre sí.
 Usted debe responder lo que se pide en cada uno de ellos en forma independiente, identificando con claridad el tema
 o comentario que usted responderá (Comentario N°1, etc.). La ponderación de cada uno de los tres temas o
 comentarios que se plantean en esta pregunta del examen no necesariamente es la misma para cada uno de ellos. La
 evaluación final de esta pregunta corresponde al resultado de una evaluación global del conjunto de los tres temas
 o comentarios que se habrán planteado.
 Comentario N°1:
 Para el análisis de este primer comentario, en el que se hará referencia a dos empresas que operan en distintos rubros
 (industrias), suponga lo siguiente:
 • Ambas empresas venden un solo producto.
 • Las ventas de ambas empresas (P x Q) se comportan de acuerdo a una distribución normal y tienen la
 misma desviación estándar.
 • Debido al alto nivel de competencia en los mercados en que ellas operan, las compañías enfrentan un precio
 que, para todos los efectos prácticos, está “dado”.
 • El nivel de activos (monto en $) que ellas mantienen a través del tiempo se mantiene constante.
 Comentario: “Dos empresas para las cuáles se cumplen los supuestos anteriores, son empresas que tienen el mismo
 nivel de riesgo operacional, medido como la variabilidad (o desviación estándar) de su resultado operacional, toda
 vez que las características de las variables que determinan dicho riesgo son las mismas para ambas”.
 Se pide: Entregar en primer lugar su opinión en términos de si usted está “de acuerdo” o “en desacuerdo” con el
 comentario y luego fundamentar su opinión.
 Comentario N°2:
 En la última reunión del directorio de una empresa, el Gerente General comentaba lo siguiente: “hemos evaluado
 un nuevo proyecto de inversión, que tiene varios años de duración, calculando su valor actual (presente) neto o
 VAN con un resultado ampliamente positivo, con lo cual se estaría creando valor para los dueños de la compañía”.
 Al conocer este resultado un director de la empresa preguntó, cuál sería la rentabilidad anual esperada del proyecto,
 en el escenario que se dieran exactamente los flujos de caja que se proyectaron al momento de su evaluación. Frente
 a esta consulta, el Gerente de Finanzas le comenta al director que dicha rentabilidad anual era la Tasa Interna de
 Retorno (TIR) del proyecto.
 Se pide: Entregar en primer lugar su opinión en términos de si usted está “de acuerdo” o “en desacuerdo” con el
 comentario del Gerente de Finanzas y luego fundamentar su opinión.
 Comentario N°3:
 Es sabido que, para la valoración de una empresa desde la perspectiva financiera, hay básicamente dos métodos o
 metodologías que se usan habitualmente: el primero es el método de los “Flujos de Caja Descontados” y el segundo
 el método de los “Múltiplos” o de los “Comparables”.
 Estando en una negociación, en la que se tenía como objetivo estimar el precio al que se iba a ofrecer a la venta un
 porcentaje del patrimonio de la “Viña Santa Juana” (VSJ), habiendo optado por el camino o metodología de los
 “Múltiplos” y respecto de la que se contaba con la siguiente información, se siguió el procedimiento o metodología
 que se describe más adelante.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 184

[pág. 185]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2024 | pregunta 3
 Convocatoria 1 | página original 408 | Riesgo, TIR y múltiplos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 Información disponible: Se contaba con la siguiente información de dos empresas (viñas) comparables, la “Viña
 Santa Francisca” (VSF) y “Viña Santo Tomás” (VST):
 Empresa "Objetivo" "Comparables"
 Datos: Viña Santa Juana (VSJ) Viña Santa Francisca (VSF) Viña Santo Tomás (VST)
 Precio de M° por Acción ($ por Acción): No se transa en bolsa $14 $18
 N° de Acciones: 5.000 21.000 14.000
 Caja disponible: $0 $0 $0
 Deuda Financiera: $24.000 $32.000 $28.000
 EBITDA (estimado próximos 12 meses): $14.500 $32.600 $20.000
 Nota: EBITDA = Earnings Before Interests Taxes Depreciation and Amortization
 Cuya traducción es: Utilidad Antes de Intereses, Impuestos, Depreciación y Amortización
 Las tres empresas sólo tienen activos operacionales y toda su deuda es “Deuda Financiera” (deuda con bancos que
 genera intereses de manera explícita).
 Resultado y Metodología: Dado lo anterior, el analista cuyo objetivo es el de valorar el patrimonio de la “Viña
 Santa Juana”, obtuvo como resultado de dicho valor un monto de $174.000. Preguntado por el procedimiento o
 metodología seguido, él lo resumió de la siguiente manera:
 • Sabemos que uno de los múltiplos más usados en el proceso de valoración por “Múltiplos” es el múltiplo
 [Valor de la Empresa/EBITDA]
 • Obtenido este múltiplo para cada una de las dos empresas y tomando luego el promedio simple de ellos, es
 posible calcular que el múltiplo [Valor de la Empresa/EBITDA] promedio para las dos empresas
 comparables de las que disponemos información es de 12 veces
 • Al aplicar este promedio de 12 veces al EBITDA estimado para los próximos 12 meses de la Viña Santa
 Juana, obtenemos que, de acuerdo con este método, la estimación del valor de su patrimonio total es de
 $174.000 (= 12 veces x $14.500)
 Se pide: Entregue en primer lugar su opinión en términos de si usted está “de acuerdo” o “en desacuerdo” con el
 procedimiento seguido por el analista y luego fundamente su opinión.
 Nota: No se pide un análisis del método de valoración usando múltiplos, ni tampoco comentar la poca información
 de la que se dispone o las características o sesgos que pueda tener dicha información. Lo que se pide es analizar la
 aplicación del método de los múltiplos que en este caso específico está haciendo el analista para estimar el valor
 que tiene como objetivo estimar.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 185

[pág. 186]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2017 | pregunta 3
 Convocatoria 1 | página original 230 | TIR incremental y VAN
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N*3
 La siguiente es la información de valor económico o de mercado, al día 31 de diciembre de 2016, de la empresa
 constructora e inmobiliaria “Queulat S.A.” (cifras en MM$ = Millones de $)
 Activos MMS$ Pasivos y Patrimonio MMS
 Caja 10.000 Deuda Bancaria 5.000 (Ver Nota 1)
 Patrimonio (Ver Nota 2)
 Capital (100 acciones) 5.000
 Total de AÁctivos MMS 10.000 Total Pasivo + Patrimonio MMS 10.000
 Nota 1: Esta deuda devengaun interés anual del 10% y está pactada en condiciones de mercado. En todo caso, se
 sabe que mientras la empresa pague al banco anualmente los intereses que dicha deuda genera, el banco está
 dispuesto a renovarla anualmente, de manera indefinida y sin la necesidad de hacer amortizaciones de la deuda. Se
 espera que la tasa de interés de mercado para una deuda con las características de la deuda actual de “Queulat”, se
 mantenga constante en el futuro.
 Nota 2: Estos valores, incluyen toda la información financiera relevante para la empresa y conocida hasta el
 momento de dicho balance a valores económicos o de mercado, al 31 de diciembre de 2016.
 Inesperadamente, a primera hora de hoy, 1 de enero de 2017, la empresa obtuvo, sin costo alguno, un permiso o
 derecho exclusivo de construcción para construir un edificio para oficinas, en el único sitio que se encuentra
 actualmente disponible en la comuna en la que opera la empresa “Queulat”. Se sabe que por regulaciones
 municipales, en este momento existe una única oportunidad de construir en dicha comuna, un solo edificio y en ese
 único sitio que está actualmente disponible. En este momento, los ejecutivos de la empresa “Queulat”, deben
 tomar la decisión respecto de la altura que debiera tener el edificio que se construya. Felizmente para la empresa
 “Queulat”, se sabe que en el caso que ella no pudiera o no quisiera hacer uso de su derecho exclusivo de
 construcción, ella puede venderlo en un mercado que se sabe es muy competitivo.
 Desde el punto de vista ingenieril, el edificio se puede construir de 30, 40 o de 50 pisos. Por supuesto, a mayor
 tamaño del edificio, mayor es el costo de construcción del edificio o monto de inversión requerida, pero también
 mayaor es el flujo de beneficios anuales que se puede esperar.
 Los siguientes son los montos de inversión requeridos (compra del terreno más costos de construcción propiamente
 tal), para cada uno de los proyectos alternativos o mutuamente excluyentes, sus ingresos operacionales anuales, sus
 gastos operacionales anuales y los montos de reinversión anual que se requeriría para cada proyecto.
 Edificio | Costo del Terreno Ingresos de Caja Egresos de Caja Depreciación Reinversión
 más Construcción | Operacionales Anuales| Operacionales Anuales Anual Anual
 (), 2) y ) (4) (5.a) (5.b) (6)
 30 pisos | $3.500 millones $ 1.680 millones $ 280 millones $ 62 millones |$ 210 miltones
 40 pisos | $ 5.600 millones $ 2.380 millones $ 420 millones $ 104 millones ($ 280 millones
 50 pisos | $8.400 millones $ 2.758 millones $ 560 millones $ 160 millones |$ 350 millones
 Notas, información adicional y supuestos:
 (1): Estos desembolsos incluyen un costo de adquisición del terreno por un monto total de $ 400 millones.
 (2): Suponga que la construcción del edificio (cualquiera sea su altura) es instantánea y ella se inicia y termina en
 £ =0 (digamos que se inicia y termina hoy, 1 de enero de 2017) y su pago es enteramente al contado.
 (3): Cualquiera que sea la altura del edificio que se construya, su vida útil es de 50 años, se deprecia linealmente y
 no tiene valor residual.
 (4): El total de los ingresos operacionales devengados durante cada uno de los años del proyecto, corresponde a
 entradas de caja operacionales que se producen al término de cada año. En consecuencia, el primer ingreso
 operacional se produce a fines del año 2017.
 (5): El total de los gastos operacionales devengados durante cada uno de los años del proyecto, está compuesto
 únicamente por dos tipos de gastos:
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 186

[pág. 187]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2017 | pregunta 3
 Convocatoria 1 | página original 231 | TIR incremental y VAN
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 a. Un conjunto de gastos operacionales que corresponden a egresos de caja operacionales annales que se
 producen al término de cada año (columna 5.a).
 b. El gasto por depreciación amual del edificio que se devenga al término de cada año (columna 3.b)
 (6): Estos montos de reinversión anual, que se producirían al término de cada año, permitirían que los edificios se
 mantengan para siempre “como nuevos”, esto es, que en la práctica se pueda considerar que tienen una vida
 útil infinita, y por lo tanto los flujos de caja que se generen, sean también hasta el infinito o perpetuos.
 7 : Suponga: _
 a. Mercado de Capitales Perfecto, es decir: tasas de impuestos = 0%, no hay costos de transacción, etc.
 b. — Inflación = 0%
 Adicionalmente, se cuenta con la siguiente información, constante para todos los años futuros:
 Tasa libre de riesgo de la economía = 8% anual
 Beta de la empresa “Queulat” (activos) y de cada uno de los proyectos de inversión = 2,0
 Premio por Riesgo de Mercado [E(Rm) — Rí] = 6%:
 Responda las preguntas que se le formulan a continuación. Para facilitar su respuesta trabaje todas las cifras en
 MMS (millones de pesos). Al final de este examen, se le entregan algunas tablas de matemáticas financieras.
 PREGUNTAS
 1. Usando el criterio de la Tasa Interna de Retorno o T.LR., evalúe la decisión de si la empresa “Queulat”,
 debiera o no emprender el proyecto del edificio y en caso de estimar que el proyecto es bueno, use el criterio
 de la T.LR. para determinar cuál de las tres alturas alternativas del edifício o proyecto es la óptima (30, 40 o 50
 pisos). Note que la decisión debe ser evaluada usando el criterio de la T.LR. Cualquier otro criterio que se use
 para responder esta primera pregunta, aunque la decisión sea correcta, se considerará como pregunta no
 respondida.
 Notas:
 e Cuando obtenga ma tasa porcentual use dos decimales (XX,XX%).
 e Recuerde que al momento de evaluar la decisión, la empresa “Queulat” no tiene el terreno en el que se
 construiría el nuevo edificio, sólo es dueña del derecho exclusivo para construir el último edificio que se
 puede construir en el único sitio disponible para la construcción de un edificio en la comuna.
 Suponga que a primera hora de hoy, 1 de enero de 2017, el mercado se entera de que inesperadamente, la empresa
 “Queulat” obtuvo, sin costo alguno, el permiso o derecho exclusivo de construcción que se ha descrito
 previamente. Por alguna razón, uno de los socios de “Queulat” le ofrece a usted, venderle una acción de dicha
 empresa. ¿Cuál es el máximo precio que usted estaría dispuesto a pagar por esa acción ese día? Fundamente su
 respuesta
 Suponga ahora que, al inicio del día de hoy, 1 de enero de 2017, la empresa “Queulat” compró el terreno donde
 construiría el edificio y pagó por él $ 400 millones. Lamentablemente, en el mismo momento en que compró el
 terreno, se entera que por razones absolutamente internas de la empresa, “Queulat” no podrá realizar la inversión
 en la construcción del más conveniente de los edificios que ella podría construir y procederá a licitar (vender
 con amplia información al mercado), el terreno junto con el derecho exclusivo de construcción que ella posee.
 ¿Cuál debiera ser el máximo precio que el mercado debiera estar dispuesto a pagar en esta licitación por el
 terreno más el derecho exclusivo de construcción? Fundamente su respuesta y suponga que no ha habido
 cambios en los precios de mercado de los terrenos, que el mercado en el cual se transan estos derechos es n
 mercado perfecto y que quien compre el derecho, construiría en el terreno, el mismo 1 de enero de 2017, el mejor
 de los proyectos de construcción de un edificio de oficinas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 187

[pág. 188]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2023 | pregunta 3
 Convocatoria 1 | página original 381 | Valor empresa, opción y aporte
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº3
 Hoy es 31/12/2022 y hemos conocido el caso de dos amigas que recién salidas de la universidad crearon, hace 5
 años, la empresa “Comidas Sanas y Deliciosas” (CSD) la que ha alcanzado gran prestigio en el mercado local. La
 empresa se dedica únicamente a la elaboración y venta de comidas sanas, todos sus activos son operacionales y su
 financiamiento actual es de un 100% de patrimonio. El negocio que actualmente opera la empresa CSD se espera
 genere un flujo de caja operacional anual de $47,5 millones y las dueñas estiman que este sería su flujo de caja
 operacional anual esperado por muchos años, en la práctica “a perpetuidad”. Se sabe que la tasa de descuento
 relevante para los flujos futuros esperado de la operación actual de la empresa dado sus riesgos es de un 10% anual.
 Dado el éxito que ha tenido el negocio, sus dueñas están evaluando hoy, 24:00 hrs del 31/12/2022, la posibilidad de
 desarrollar un nuevo proyecto o negocio, que consistiría en una plataforma que le permitirá a la empresa CSD entrar
 al negocio de “última milla”, el que se agregaría al actual sistema de ventas en el local que tiene la empresa. A juicio
 de las dueñas de la empresa CSD, la probabilidad de que el escenario para el nuevo proyecto sea favorable y por lo
 tanto sus resultados esperados sean positivos, tanto desde el punto de vista comercial como financiero, es de un
 30%. Por otro lado, estiman un 70% de probabilidades que el escenario sea desfavorable o negativo, en cuyo caso
 ellas no emprenderían el nuevo negocio.
 El nuevo negocio requeriría de una inversión inicial de $50 millones y ellas estiman que, en el caso de un escenario
 positivo para el nuevo negocio, se podría esperar que éste genere anualmente, a partir del 31/12/23, un flujo de caja
 operacional anual de $18 millones a perpetuidad (adicionales a los $47,5 millones anuales que genera la actual
 operación de la empresa). Dadas las características del nuevo negocio, se estima que la tasa de descuento relevante
 para sus flujos de caja esperados es de 12% anual. Tanto los flujos de caja esperados como el riesgo del negocio
 que CSD opera actualmente se mantendrían.
 Como una forma de revisar las probabilidades de que se presente un escenario positivo o negativo para el nuevo
 negocio, las dueñas han contratado un estudio de mercado, cuyo costo es de $0 millones, que les permitiría estimar
 con mayor precisión lo que podría ser su mercado y en definitiva su nivel de ventas e ingresos en el caso de
 desarrollar el nuevo proyecto de comercialización. Luego de conocidos los resultados del estudio de mercado, ellas
 tomarían la decisión de desarrollar o no este nuevo proyecto. Las dueñas han decidido que en el caso que la
 investigación de mercado muestre resultados esperados positivos, ellas emprenderían de inmediato el nuevo
 negocio, es decir lo harían a partir del 1/1/2023.
 Por otra parte, se sabe que las dueñas de CSD han decidido que toda nueva inversión, será financiada manteniendo
 su actual estructura de financiamiento (100% Patrimonio).
 Suponga que el mercado de capitales (MC) es eficiente en su forma “semi-fuerte” y que no hay impuestos, inflación
 ni costos de transacción.
 Se pide responder las preguntas que se le irán planteando a continuación y en cada caso fundamentar
 ordenadamente sus respuestas con los cálculos necesarios para su desarrollo:
 1. Suponga que en este momento son las 24:00 hrs del 31/12/2022 y que la información respecto de las expectativas
 futuras del negocio que actualmente opera la empresa es conocida y compartida por el mercado. Por otro lado,
 las dueñas de la empresa han decidido dar a conocer al mercado toda la información de la que ellas disponen
 relativa al nuevo proyecto, pero todavía sin conocer los resultados de la investigación de mercado. ¿Cuál debiera
 ser en este momento el valor de mercado total de la empresa CSD, dada la información relativa a las operaciones
 que ella actualmente desarrolla considerando además la información que sus dueñas han dado a conocer respecto
 del nuevo proyecto?
 2. Suponga ahora que a las 08:00 hrs del 1/1/2023, las dueñas informan al mercado que los resultados del estudio
 que habían contratado indican un escenario positivo para el nuevo proyecto, de manera que ellas emprenderán
 el nuevo negocio. En este momento, por lo tanto, el mercado internaliza toda la información relativa al nuevo
 negocio de última milla.
 Sin embargo, y dado que las dos amigas no cuentan con recursos para el financiamiento de los $50 millones
 necesarios para emprender el nuevo negocio, han decidido invitar a su amigo Don Jacinto a que aporte como
 capital los $50 millones que se necesitan. Así Don Jacinto pasaría a ser propietario de una parte de la empresa
 CSD, que incluye tanto el negocio que ellas actualmente operan como el nuevo negocio de última milla.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 188

[pág. 189]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2023 | pregunta 3
 Convocatoria 1 | página original 382 | Valor empresa, opción y aporte
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 Se Pide: Determine el mínimo porcentaje de la propiedad de CSD que Don Jacinto debiera estar dispuesto a
 recibir para aportar los $50 millones.
 Nota: Por “mínimo porcentaje”, entiéndase aquel porcentaje que lo dejaría indiferente entre aportar o no los
 $50 millones.
 3. Suponga ahora que Don Jacinto ha decidido pedir un 16% de la propiedad de CSD a cambio de los $50 millones
 de su eventual aporte de capital. Las dueñas, no están dispuestas a entregar dicho porcentaje de la propiedad y
 dado que ellas saben que la única opción que tienen de incorporar a un nuevo socio es a Don Jacinto y que ellas
 no disponen de recursos para aportar como capital, han decidido recurrir al Banco para solicitar un préstamo por
 los $50 millones que requieren. El Banco ha ofrecido prestarles los $50 millones, pero por distintas
 imperfecciones del mercado de capitales, esto haría subir la tasa de descuento relevante para la evaluación del
 nuevo proyecto, de modo tal que el nuevo VAN del proyecto de última milla sería de $75 millones. Dado lo
 anterior, ellas saben que las únicas opciones de llevar a cabo el nuevo proyecto son incorporando a Don Jacinto
 como socio con algún porcentaje de propiedad de la empresa o financiar los $50 millones que les faltan con la
 deuda que les está ofreciendo el Banco. Se sabe que el valor que tenía la empresa como resultado de sus actuales
 operaciones, antes del nuevo proyecto, no se vería afectado
 Se Pide: Determine el máximo porcentaje (%) de propiedad de la empresa CSD, que las amigas debieran estar
 dispuestas a entregar a Don Jacinto a cambio de su aporte de $50 millones.
 Nota: Por “máximo porcentaje” entienda aquel porcentaje que a las amigas les dejaría indiferente entre
 incorporar a Don Jacinto como nuevo socio o recurrir al Banco para el financiamiento de los $50 millones.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 189

[pág. 190]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2017 | pregunta 3
 Convocatoria 2 | página original 244 | Valoración y WACC
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N*3
 Usted es una joven egresada de nuestra Facultad y como resultado de un emprendimiento, ha logrado construir
 la empresa “Vaya Seguro” S.A., dedicada al negocio de los estacionamientos en el sector del desierto florido,
 cerca de Copiapó, empresa que felizmente ha alcanzado muy buenos resultados fmancieros desde el momento
 de su creación. En este momento, usted es la dueña del 100% de las acciones de la empresa.
 Se sabe que el único activo que en este momento mantiene la empresa “Vaya Seguro” S.A., valorado a costo
 histórico en su contabilidad, es un terreno por $100.000. El siguiente es el balance de la contabilidad financiera
 de la empresa, “Vaya Seguro” S.A, en el día de hoy 31 de diciembre de 2017.
 Activos $ Pasivos y Patrimonio $
 Terreno 100.000 Deuda Bancaria 40.000
 Patrimonio
 Capital (100 acciones) 60.000
 Total de Activos 5% 100.000 Total Pasivos + Patrimonio $ 100.000
 La única denda vigente de la empresa al 31/12/17, es la Deuda Bancaria de $40.000, la que está pactada en
 condiciones de mercado a una tasa de interés anual de un 5%. Se sabe además que, si al final de cada año la
 empresa paga al banco los intereses que dicha deuda genera, su plazo se puede extender indefinidamente sin
 necesidad de amortizaciones.
 Adicionalmente, se sabe que el valor esperado del Flujo de Caja Operacional Neto Anual (Ingresos de Caja
 Operacionales anuales menos Egresos de Caja Operacionales anuales) de Vaya Seguro S.A., es de $10.500.
 Todos los flujos de caja se generan y se pagan el último día de cada año y se espera que ellos se produzcan
 indefinidamente, a partir del año 2018, sin necesidad de reinversiones. Así entonces, lo que se espera es que
 el flujo de caja de $10.500, se produzca de manera perpetua.
 Si bien, como se ha dicho, la empresa ha logrado muy buenos resultados en su gestión a partir del momento
 de su creación, usted como dneña de “Vaya Seguro” S.A., ha decidido vender el 100% de sus acciones, de
 modo de poder contar con los recursos que le permitan el desarrollo de nuevas ideas.
 Conteste las preguntas que se le formulan a contmuación, mostrando todos los cálculos necesarios en los
 cuales se fundamentan sus respuestas. En todos los casos suponga que no hay inflación ni impuestos.
 PREGUNTAS
 1. En esta primera pregunta, suponga que “Vaya Seguro” S.A. opera en un Mercado de Capitales Perfecto
 (MCP), y que bajo estas condiciones la tasa de retorno anual exigida por los accionistas de la empresa fuera
 de 10,625% (Nota: en sus cómputos, este porcentaje trabájelo con sus tres decimales). ¿Cuál es la tasa de
 costo de capital que “Vaya Seguro” S.A. debiera utilizar en la evaluación financiera de un nuevo proyecto
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 190

[pág. 191]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2017 | pregunta 3
 Convocatoria 2 | página original 245 | Valoración y WACC
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 de inversión, que consistiría en una expansión de su negocio actual, es decir en una expansión del negocio
 de estacionamientos en la zona en la que ella actualmente opera?
 En esta segunda pregunta, dejaremos de lado el supuesto de mercado de capitales perfecto. Suponga ahora,
 que dado que la empresa “Vaya Seguro” S.A., se encuentra en una zona que el gobierno quiere desarrollar
 con nuevas inversiones, el Estado le ofrece a la compañía un subsidio a la tasa de interés de la deuda, que
 consiste en que, a partir de este momento (31/12/17), la deuda de $40.000 que la empresa tiene con el
 Banco, dejaría de devengar una tasa de interés anual del 5% y pasaría a devengar una tasa de interés anual
 del 3% anual, manteniendo las condiciones originales de dicha deuda (plazo, forma de pago, etc.). Suponga
 también que, en este nuevo contexto de un mercado de capitales con imperfecciones, el costo de capital
 promedio ponderado de “Vaya Seguro” S.A., fuese de un 7,5% anual.
 ¿Cuál sería ahora, el máximo precio que un inversionista, que cuenta con la información anterior, debiera
 estar dispuesto a pagar por una acción de “Vaya Seguro” S.A. ese día 31/12/17?
 En esta tercera pregunta, segnimos trabajando en un escenario en que el mercado de capitales no es perfecto
 y en el cual se mantienen las condiciones de la pregunta 2 anterior. ¿Cuál sería ahora (dada la tasa de -interés
 con subsidio de la deuda yv suponiendo que el nuevo costo de capital de la empresa es de un 7,5% anual),
 la tasa de retorno o rentabilidad anual que exigiría un potencial accionista a su inversión en “Vaya Seguro”
 S.A?
 Notas para todas las precuntas:
 Trabaje los porcentajes con dos decimales XX,
 Y Y %
 "Si bien se espera que, salvo que expresamente se indique otra cosa, los porcentajes se trabajen con 2
 Y Y %), para entregar los valores de sus respuestas, hágalo usando números enteros.
 decimales XX,
 Suponga que el mercado espera que las tasas que se han indicado, se mantengan constantes en el largo
 plazo.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 191

[pág. 192]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2012 | pregunta 3
 Convocatoria 2 | página original 107 | WACC, beta y emisión de acciones
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº 3
 La compañía minera Dorada S.A. es una empresa nacional que se dedica a la extracción y comercialización de oro que extrae
 desde un yacimiento en una pertenencia minera de su propiedad en la cordillera del norte de Chile. Actualmente (t = 0), el
 patrimonio de la empresa está compuesto por 20 millones de acciones que se transan activamente en la bolsa chilena y cuyo
 precio de mercado es de $3 por acción. La única deuda que Dorada S.A. mantiene, corresponde a bonos que, para todos los
 efectos prácticos, son totalmente libres de riesgo. Estos bonos devengan un interés del 2% anual y vencen en su totalidad en
 un año más (t = 1), fecha en la cual Dorada S.A. deberá pagar la suma de $40,8 millones para extinguir el total de sus
 obligaciones por bonos (capital más intereses).
 Los geólogos de Dorada S.A. acaban de descubrir, de manera casual y absolutamente inesperada, una nueva veta de oro en la
 misma pertenencia minera donde se encuentra el actual yacimiento desde el cual se extrae el oro que explota y comercializa
 la empresa. Las estimaciones preliminares muestran que, para llevar a cabo el proyecto de expandir el negocio actual de
 Dorada S.A. y comenzar a explotar la nueva veta de oro, la compañía deberá invertir hoy (t = 0) la suma de $24,5 millones y
 que el proyecto generará, en un año más (t = 1), un único flujo de caja esperado de $66 millones.
 Si el beta del patrimonio (o beta de las acciones) de Dorada S.A., justo antes del anuncio del descubrimiento de la nueva veta
 de oro, es igual a 1,2 mientras que el retorno esperado de la cartera (portafolio) de mercado asciende a un 7% anual y
 suponiendo que no hay inflación y que el mercado de capitales chileno fuera perfecto, es decir, no hay impuestos ni costos de
 transacción e intermediación y la información es gratis y está ampliamente disponible, al mismo instante, para todos los
 inversionistas del mercado, a Ud. se le pide responder las preguntas que se le formulan a continuación, mostrando todos los
 cálculos que sean necesarios para justificar sus respuestas.
 a) Suponiendo que Dorada S.A. financiará el 100% de la inversión requerida en el proyecto de expansión de la mina de oro
 a través de un aumento de capital (emisión de nuevas acciones) ¿Cuál será el valor presente neto de dicho proyecto?
 ¿Cambiaría su respuesta anterior si el 100% de la inversión requerida en el referido proyecto de expansión fuese
 financiada con deuda libre de riesgo, que devenga un interés del 2% anual, y que se pagaría íntegramente (capital más
 intereses) en un año más (t = 1)?
 b) Suponga que Dorada S.A. decide financiar la totalidad del proyecto de expansión con una emisión de nuevas acciones.
 ¿Cuántas acciones deberá emitir hoy Dorada S.A. a fin de recaudar los $24,5 millones que requiere el proyecto?
 c) Suponga que Dorada S.A. lleva a cabo la emisión y colocación de acciones para financiar el nuevo proyecto en las
 condiciones que Ud. obtuvo en la letra (b) anterior. ¿Cuál será el rendimiento que exigirán los inversionistas en el
 mercado de capitales chileno, a una acción de la empresa minera Dorada S.A., inmediatamente después que se haya
 llevado a cabo la emisión y colocación de las nuevas acciones?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 192

[pág. 193]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2018 | pregunta 6
 Convocatoria 2 | página original 276 | Árbol de decisión y opción real
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA N* 6
 capaz de
 Hoy, 1 de enero de 2019, usted está evaluando un negocio, que consiste en la compra de un motor
 (se prende el motor y de inmediato comienza el proceso de generación de
 generar energía de manera instantánea
 La energía generada se vendería, a través de un contfrato, al proveedor oficial y responsable final de
 energía).
 Por ley, este
 satisfacer la demanda de energía de los habitantes de la zona en que usted operaría su negocio.
 del total de la energía que sus propios clientes le demanden,
 proveedor está obligado a disponer en todo momento,
 diciembre, a las 24:00 hrs., momento de máxima demanda por energía que él
 y le preocupa que los días 31 de
 pudiera no contar con la energía requerida para satisfacer la demanda de ese momento. Se sabe que la
 enfrenta,
 satisfacer
 multa que tendría que pagar el proveedor oficial de energía de la zona, en caso de no poder
 oportunamente la demanda por energía de sus clientes, es muy elevada.
 encargado
 Así entonces, este tipo de contrato es una especie de respaldo o seguro con el que el proveedor oficial
 entre Ud. y el
 de abastecer energía en la zona, espera contar en caso de necesidad. En particular, el contrato
 a El, en
 proveedor oficial, que sería su único y exclusivo cliente, estipularía que usted se compromete a venderle
 el último día de cada año (31
 caso que lo requiera, toda la energía que su motor sea capaz de generar, únicamente
 de diciembre), entre las 23:00 y las 24:00 hrs., que es cuando se produce el peak de demanda.
 el generador
 La inversión inicial total requerida hoy 1 de enero de 2019 (t=0), en este nuevo negocio, para dejar
 de cada año, alcanzaría los US $400.000 al contado. La máxima
 en condiciones de operar los días 31 de diciembre
 de energía del motor es de 7.000 unidades de energía por hora, en cada uno de los dos
 capacidad de generación
 segundo año (2020), el
 años de vida útil que tiene el motor, es decir, en los años 2019 y 2010. Al término del
 (termina su vida útil), y el valor comercial de las
 motor dejaría de tener la capacidad de volver a generar energía
 sería de US$ 0 (cero). Al término del segundo año se acaba el negocio y
 inversiones hechas en el nuevo negocio
 habría que pagar, en ese mismo momento y en efectivo, indemnizaci ones laborales y otros
 se estima que
 desembolsos, por un total de US$35.000.
 de US$ 500
 El precio al cual ayer, 31 de diciembre de 2018 en la noche, se transó una unidad de energía fue
 próximos dos años (2019 y 2010), se estima que
 (precio contado) y, para los días de finales de cada ino de los
 precio por unidad de energía pueda subir en US$ 60 y un 40% de
 hay un 60% de probabilidad de que el
 de que pueda bajar en US$ 60 con respecto, en ambos casos, al precio vigente en el perfodo
 probabilidad
 inmediatamente anterior, tal como se muestra en el siguiente cuadro:
 Fin año 2018 Fin año 2019 Fin año 2020
 . (t=1) — (t=2)
 — HOY(t=0)
 — 620
 — e F-
 500 Ñ Í 500
 -H EZ
 — 380
 del tiempo,
 El costo total de generación de una unidad de energía, que se estima permanecerá constante a través
 de este nuevo negocio es de 10% anual. Tanto el costo de
 es de US$ 490 por unidad. La tasa de descuento
 año.
 generación de la energía, como el ingreso por su venta, ocurren simultáneamente a fines de cada
 decide hoy emprender
 El proveedor oficial le ha ofrecido a usted un contrato, en el cual se estipula que si usted
 (negocio), es decir, comprar y dejar en condiciones de operar el nuevo generador, entonces
 el nuevo proyecto
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 193

[pág. 194]
Finanzas - versión clara y reordenada
 Dirección Financiera | agosto 2018 | pregunta 6
 Convocatoria 2 | página original 277 | Árbol de decisión y opción real
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 usted está obligado a generar y entregarle a él, al término de cada uno de los años 2019 y 2010, el total de la
 energía que su generador es capaz de producir, es decir, él le demandaría y usted le tendría que vender, las 7.000
 unidades de energía que su generador es capaz de producir, al precio que esté vigente en cada uno de esos dos
 momentos futuros, 31 de diciembre de 2019 y de 2020,
 Como usted no tiene certeza respecto de los precios que se le pagarían por cada unidad de energía que le venda
 al proveedor (su único cliente), usted ha decidido proponerle un contrato distinto, en el cual usted tenga la opción
 de no venderle energía si el precio vigente en el momento de la venta no le resulta conveniente. El contrato en
 cuestión estipularía que el día 31 de diciembre de los años 2019 y 2010, usted tendría el derecho a decidir si hacer
 funcionar o no su generador, es decir, si venderle o no energía al proveedor, dependiendo del precio de compra
 que en ese momento le ofrezca su único cliente, De este modo, usted haría funcionar el generador y le vendería
 energía al proveedor, sólo en la medida en que el precio vigente en el momento sea conveniente para usted. Esta
 opción, sin embargo no sería gratis, ya que si usted decide o generar energía en un período, deberá compensar a
 su cliente, en ese mismo momento, con un pago en efectivo de US$40.000.
 Usted tendría la opción de “abandonar” el proyecto (terminar con el contrato con el proveedor) tanto a fines del
 primer año, como a fines del segundo año. Sin embargo, si Ud. ejerce esta opción a fines del primer año, el
 contrato se termina y no existen posibilidades de vender energía, a nadie, el segundo y último año de vida útil del
 generador. Adicionalmente, cualquiera que sea el momento en que usted deje de generar energía, y por lo tanto
 . termine la empresa, habrá que pagar, en efectivo y en ese mismo momento, la suma de US$35 .000, por concepto
 de indemnizaciones laborales y otros desembolsos asociados al cierre del negocio. Este pago es adicional a la
 compensación de US$40.000 que debe pagársele al proveedor como compensación en caso de no generar energía.
 En resumen, el contrato con el proveedor seguiría vigente durante el segundo año (2020), siempre que usted le
 haya vendido a él, en el caso que lo hubiese requerido, las 7.000 unidades de energía que es capaz de generar su
 motor, cualquiera que haya sido el precio vigente el 31 de diciembre de 2019. En caso contrario, el contrato se
 entiende terminado a fines del año 2019 y además habrá que pagar la compensación de US$ 40.000 antes
 mencionada.
 El cliente escuchó detenidamente su ofrecimiento y quedó de estudiarlo.
 Suponiendo que:
 e No hay inflación ni impuestos.
 e Que todos los valores en US$, son flujos de caja que se producen al inicio del proyecto (1 de enero de
 2019) en el caso de la inversión inicial, y al final del año (31 de diciembre de 2019 y 2020) en el caso de
 los flujos de caja que el proyecto podría generar.
 * Quenoexiste la opción de postergar el inicio de la operación, es decir, si se decide emprender el proyecto,
 éste debe partir en t = 0. Tampoco existe la posibilidad de modificar las 7.000 unidades de energía que el
 motor es capaz de generar entre las 23:00 y las 24:00 de cada 31 de diciembre,
 Responda las preguntas que se le formulan a continuación:
 PREGUNTAS
 Estime al valor que tendría para usted, en su calidad de inversionista en este emprendimiento, la opción de poder
 decidir si vender o no energía a su cliente al término de cada uno de los años 2019 y 2020 de operaciones del
 generador. Fundamente su respuesta mostrando los cálculos correspondientes.
 Ayuda: Para responder la pregunta, lo primero que usted debe hacer, es determinar el valor del proyecto bajo las
 condiciones del contrato inicial propuesto por su cliente, es decir, cuando usted está obligado a venderle al
 proveedor aun cuando el precio no le resulte conveniente.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 194

[pág. 195]
Finanzas - versión clara y reordenada
 PREGUNTAS ADICIONALES · FINANZAS
 Cuatro problemas para integrar intuición, fórmulas y procedimiento
 Pregunta F-U1 · CML, SML y desempeño
 Explica por qué un portafolio puede estar sobre la SML y bajo la CML. Indica qué métricas usarías
 para evaluar a un fondo que constituye toda la riqueza riesgosa de un cliente y a otro que es una
 pieza pequeña dentro de una cartera diversificada.
 Pregunta F-U2 · Fama-French-Carhart
 Un fondo tiene la regresión mensual Ri-Rf=0,20%+1,05MKT+0,40SMB-0,25HML+0,30MOM+ε. El t
 del alfa es 1,1; los demás coeficientes son significativos. Interpreta exposiciones, desempeño y qué
 no puedes concluir.
 Pregunta F-U3 · Inmunización del patrimonio
 Una empresa tiene activos de 300 con duración 10 y deuda de 100 con duración 20. Calcula el
 patrimonio, su duración y el cambio aproximado de valor ante un alza de tasas de 3 puntos
 porcentuales. Luego determina la deuda que inmuniza el patrimonio si A, DA y DD permanecen
 fijos.
 Pregunta F-U4 · Opción binomial y no arbitraje
 Una acción vale 100. En un período subirá a 120 o bajará a 80. La tasa libre de riesgo del período
 es 5%. Valora una call europea con strike 100 por réplica y por probabilidad neutral al riesgo.
 Explica por qué la probabilidad real de alza no es necesaria.
Examen de Grado UC | materia, preguntas y respuestas 195

[pág. 196]
Finanzas - versión clara y reordenada
 RESPUESTAS - soluciones completas
 Las respuestas siguen el mismo orden de las preguntas. Son propuestas de estudio; una atribución
 a pauta oficial exige identificación expresa y verificada.
 Teoría Financiera
 agosto 2015 - pregunta 6 - Alfa, beta y elección de fondos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 183-183 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 La imagen primaria confirma betas 1,1; 0,8 y 0,9 para fondos 1, 2 y 3. Los retornos entregados son
 excesos sobre la tasa libre de riesgo, netos de comisiones e impuestos, para todo el período
 histórico; no son retornos anuales.
 a) Para ajustar por riesgo sistemático, calculo α_i = (R_i-R_f)-β_i(R_M-R_f), con exceso del IPSA
 de 5,7%. Fondo 1: 6,3%-1,1×5,7% = 0,03 puntos porcentuales; fondo 2: 5,8%-0,8×5,7% = 1,24
 puntos; fondo 3: 5,4%-0,9×5,7% = 0,27 puntos. Elegiría fondo 2 por el mejor desempeño histórico
 ajustado por riesgo. No se garantiza que ese alfa continúe.
 b) Si el criterio es el mayor retorno absoluto histórico, fondo 1 ganó 6,3% frente al IPSA de 5,7%,
 superándolo en 0,6 puntos; fondo 2 lo superó en 0,1 y fondo 3 quedó debajo. Elegiría fondo 1 bajo
 ese criterio. Si se pide una elección futura bajo CAPM sin alfa persistente, fondo 1 es también el
 más expuesto al mercado y ofrece mayor retorno esperado cuando el premio esperado del mercado
 es positivo; superar al índice no está garantizado.
 c) Con certeza de boom, el mayor beta de fondo 1 favorece el objetivo de retorno absoluto de b. No
 cambiaría esa elección. La elección de a continúa siendo fondo 2 si se mantiene la evidencia sobre
 alfa, pues una predicción de mercado no altera por sí sola la habilidad ajustada por riesgo del
 administrador.
 d) Con certeza de crisis, una beta menor reduce la caída asociada al mercado. Para superar al
 IPSA en ese escenario elegiría fondo 2, que tiene beta 0,8. Para el criterio ajustado por riesgo de a
 también conservaría fondo 2, bajo el mismo supuesto sobre alfa. Una pérdida menor que la del
 índice puede constituir mejor desempeño relativo aunque el retorno absoluto sea negativo.
 agosto 2013 - pregunta 5 - Apalancamiento, múltiplos y eficiencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 134-134 | convocatoria
 2
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 196

[pág. 197]
Finanzas - versión clara y reordenada
 Respuesta modelo propuesta para estudio (no oficial)
 El proyecto no anunciado tiene inversión $400 y VAN $100, por lo tanto el valor presente de sus
 flujos es $500 bajo la tasa relevante y los supuestos del caso. Aceptarlo crea valor esperado
 aunque la emisión de acciones aumente el número de títulos o reduzca la UPA contable. Una EPS
 menor no implica que el patrimonio valga menos: el accionista recibe participación de un proyecto
 cuyo valor supera su costo en $100. La cantidad de nuevas acciones calculada con el precio previo
 de $2 también debe revisarse: si la información del proyecto es pública antes de emitir y el mercado
 la incorpora, precio y cantidad se ajustan; 200 acciones basado en precio no actualizado puede ser
 una comparación inconsistente.
 Sobre la razón deuda/patrimonio, un nivel superior al estándar no basta para prohibir más deuda.
 Se analiza capacidad de pago, covenants, clasificación, volatilidad de flujo, costo marginal,
 beneficios tributarios y costos esperados de distress; el proyecto podría ser financiable con deuda si
 sus flujos soportan pagos, o no si empeora materialmente riesgo/costo. Capital propio evita
 obligación fija, pero diluye control y puede ser costoso; decisión compara estructura y valor, no una
 regla de industria aislada.
 El argumento de caída de UPA tras emitir acciones confunde contabilidad por acción con VAN.
 Antes del anuncio, UPA $0,60 y utilidad $600. Si el proyecto eleva utilidad perpetua $60 y acciones
 fueran 1.200, UPA sería $660/1.200=$0,55 bajo los precios dados, pero ese cálculo no incluye la
 revalorización del negocio ni corrige la emisión a precio justo. No es prueba de destrucción de valor.
 En mercado semifuertemente eficiente, posponer hasta “mejor momento” basándose en
 información pública no garantiza precio mayor; esperar puede perder valor del proyecto. Si
 imperfecciones, información privada, costos de emisión o restricciones importan, se analizan
 explícitamente sin asumir que el mercado está mal valorando.
 Recomendaría aceptar el proyecto positivo si sus flujos/riesgo están correctamente modelados y
 financiarlo con combinación que mantenga flexibilidad y no viole covenants, explicando sensibilidad
 a riesgo y precio de emisión.
 Qué haría esta respuesta distinguida: contesta por separado los tres argumentos, distingue VAN
 de UPA, y corrige la inconsistencia temporal de usar el precio anterior al anuncio para calcular
 dilución.
 agosto 2021 - pregunta 6 - Beta, CAPM y WACC
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 352-352 | convocatoria
 2
 Volver al enunciado original
 Datos: r_f=4%, prima de mercado=6%. CAPM: k_i=4%+β_i×6%. Los betas de acciones entregados
 son patrimoniales apalancados salvo que se indique otra cosa. a) CC.PP. de Diver. Holding sin
 deuda, con patrimonio en tres acciones. Beta de cartera, ponderado por valor de mercado:
 β_Diver=0,20(1,8)+0,40(1,0)+0,40(0,6)=0,36+0,40+0,24=1,00. k_E=4%+1,00×6%=10,00%. Como
 Diver no tiene deuda ni otro tipo de activo, su costo promedio ponderado es k_E=10,00%. Los
 pesos son participaciones de valor de mercado, no cantidades de acciones ni pesos iguales. b)
 Retorno esperado del patrimonio apalancado de Edison. Chispita tiene β_E=0,6, por lo que:
 E(R_Chispita)=4%+0,6×6%=7,60%. Edison compra $15 millones de acciones con $10 millones
 propios y $5 millones de préstamo al 4%. Retorno monetario esperado de acciones
Examen de Grado UC | materia, preguntas y respuestas 197

[pág. 198]
Finanzas - versión clara y reordenada
 =15×7,60%=$1,14 millones; interés anual=$5×4%=$0,20 millones. Retorno esperado sobre su
 patrimonio de $10 millones: E(R_Edison)=[15×7,60%-5×4%]/10=($1,14-$0,20)/$10=9,40%. Es
 distinto y mayor que 7,60%, porque amplifica la exposición al riesgo de la acción con deuda cuyo
 costo fijo esperado es la tasa libre de riesgo. La rentabilidad adicional esperada no es una ganancia
 gratuita: el patrimonio soporta mayor volatilidad y pérdidas pueden superar su aporte. Si la deuda
 tuviera riesgo distinto o costo mayor, la fórmula usaría su costo/riesgo correspondiente. c) Tasa
 para la adquisición de Londres. Como Londres no tiene deuda y sus activos tienen el mismo riesgo
 que los activos de BCD Pin, primero recupero beta de activos de BCD. Con D/E=1 y β_D=0,6,
 β_E=1,8: β_A,BCD=[E/(D+E)]β_E+[D/(D+E)]β_D=0,5(1,8)+0,5(0,6)=1,20. Al ser Londres sin deuda,
 β_E,Londres=β_A,Londres=1,20. CAPM entrega tasa de descuento del negocio:
 k_Londres=4%+1,20×6%=11,20%. La adquisición debe descontarse a 11,20% para flujos del activo
 operativo (sin deuda), bajo beta y supuestos del caso. La venta de acciones forestales cambia la
 composición de la cartera de Diver y el financiamiento de la compra, pero no convierte el riesgo del
 flujo de Londres en riesgo forestal: la tasa sigue el riesgo del activo adquirido. Una estimación de
 retorno patrimonial de Diver posterior podría cambiar con el nuevo portafolio, pero no es la tasa
 correcta para evaluar estos flujos. Qué hace sólida la respuesta: separa riesgo de cartera de
 estructura de financiamiento, muestra el efecto de apalancamiento sobre retorno patrimonial y
 desapalanca el comparable para igualar riesgo del negocio objetivo.
 enero 2019 - pregunta 3 - Betas y WACC
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 283-283 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Primero calculo el beta de activos de cada comparable como promedio ponderado por valor de
 mercado de equity y deuda: β_A=(E/V)β_E+(D/V)β_D. Marad:
 (1.700(1,2)+850(0,15))/2.550=0,8500. Oleada, sin deuda: 0,9000. Navegación:
 (1.050(1,8)+3.150(0,25))/4.200=0,6375. Para el proyecto “similar al promedio ponderado” uso
 ponderadores de valor de empresa: V totales 2.550, 800 y 4.200, sumando 7.550. Beta de activos
 promedio (=(0,8500(2.550)+0,9000(800)+0,6375(4.200))/7.550=0,7371). Costo de activos por
 CAPM (r_A=3%+0,7371(5%)=6,685%.
 Sin impuestos, la empresa agregada tiene deuda 4.000 y equity 3.550, de modo que (D/E=1,1268),
 y beta de deuda ponderado (=(0,15(850)+0,25(3.150))/4.000=0,22875). En mercado perfecto,
 (β_A=(E/V)β_E+(D/V)β_D), por lo que (β_E=β_A+(D/E)(β_A-β_D)=1,3099). La fórmula del analista
 (β_E=β_A[1+(D/E)]) solo sería adecuada con deuda de beta cero; aquí la deuda tiene beta positivo.
 Costo del equity (r_E=3%+1,3099(5%)=9,550%. La tasa para FCFF de activos sigue siendo
 6,685%; 9,55% es para flujos al patrimonio.
 Con impuesto corporativo 25% y escudo, la relación depende del supuesto de riesgo del escudo.
 Bajo deuda que mantiene su riesgo y escudo con riesgo de deuda, uso
 (β_E=β_A+(1-T)(D/E)(β_A-β_D)=1,1667), por lo que (r_E=8,833%. La deuda ponderada mantiene
 (r_D=3%+0,22875(5%)=4,144%. El WACC after-tax, con los pesos de mercado, es
 (0,4702(8,833%)+0,5298(4,144%)(1-0,25)=5,800%. Equivalentemente, bajo política de
 apalancamiento indicada, (WACC=r_A[1-T(D/V)]=6,685%[1-0,25(4.000/7.550)]=5,800%. El costo de
 activos operativo sin escudo sigue siendo 6,685%; para descontar FCFF con financiamiento/escudo
Examen de Grado UC | materia, preguntas y respuestas 198

[pág. 199]
Finanzas - versión clara y reordenada
 incorporados se usa el WACC 5,800%. Si el riesgo del escudo o la política de deuda fueran
 distintos, la fórmula requeriría adaptación.
 Qué hace sólida la respuesta: desapalanca y re-apalanca betas incluyendo deuda riesgosa, usa
 valores de mercado, separa tasa de activos de costo de equity y declara el supuesto sobre riesgo
 del escudo tributario.
 marzo 2011 - pregunta 6 - Bonos, impuestos y TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 68-71 | convocatoria 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Se aplica únicamente el régimen histórico que describe el enunciado. El bono recauda 960 y paga
 1.050 al final del año. La base imponible permite aprovechar todos los gastos.
 a.i) Emisor, régimen normal. Deduce intereses 50 y descuento de emisión 40: ahorro tributario
 terminal = 90×20% = 18. El pago neto terminal es 1.050-18 = 1.032. Costo efectivo = 1.032/960-1 =
 7,50%.
 a.ii) Emisor, artículo 104. Paga hoy (1.000-960)×20% = 8, por lo que recibe neto 952. Al
 vencimiento deduce tanto los intereses 50 como el descuento 40; el artículo agrega el impuesto
 inicial, pero no elimina la deducción de intereses. Ahorro terminal = 18 y pago neto = 1.032. Costo
 efectivo = 1.032/952-1 = 8,403361%. Contar solo el escudo de 8 por descuento y omitir el de 10 por
 intereses sobrestima el costo.
 b.i) Comprador, régimen normal. La ganancia imponible es 50 de intereses más 40 de mayor
 valor = 90. Impuesto = 18; cobra neto 1.032 sobre inversión 960. Retorno = 7,50%.
 b.ii) Comprador, artículo 104. Solo tributa por los intereses: 50×20% = 10. Recibe 1.040; retorno =
 1.040/960-1 = 8,333333%. La exención favorece al comprador, mientras el impuesto inicial
 adicional encarece al emisor. Son flujos de agentes distintos y fechas distintas.
 marzo 2009 - pregunta 6 - Bonos/renta fija
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 12-13 | convocatoria 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 1) En el gráfico, entre 2003 y mediados de 2008 el spread TR-TN se ubica aproximadamente entre
 -2 y -3 puntos porcentuales. Por tanto, TN-TR es aproximadamente 2%-3%, usualmente alrededor
 de 2,5% anual. Esa es una estimación visual de inflación compensada a diez años. Identificarla con
 inflación esperada requiere suponer primas de riesgo inflacionario y diferencias de liquidez
 pequeñas; no corresponde leer el signo inverso como inflación negativa durante ese período.
 2) Mayor probabilidad de impago reduce el pago esperado del bono Baa frente a sus pagos
 prometidos. Su precio cae y aumenta la TIR calculada sobre esos pagos prometidos. Un mayor
 premio por riesgo eleva además el rendimiento esperado requerido, por ejemplo porque las
 pérdidas de crédito ocurren en estados malos para los inversionistas. Ambos mecanismos elevan
 Baa y Baa-TN; el refugio en bonos nominales del Tesoro también baja TN y amplía el spread.
 Pérdida esperada y compensación por riesgo son conceptos distintos.
Examen de Grado UC | materia, preguntas y respuestas 199

[pág. 200]
Finanzas - versión clara y reordenada
 3) El spread TR-TN sube desde alrededor de -2,5% hacia cero en los últimos meses de 2008; no
 se vuelve más negativo. Los dos bonos son emitidos por el Tesoro, por lo que no es razonable
 explicar esa divergencia con un mayor riesgo de incumplimiento de uno frente al otro. TN-TR, la
 inflación compensada, se reduce. Podrían contribuir menores expectativas de inflación de largo
 plazo y mayor demanda relativa por los nominales, que son muy líquidos. Las perturbaciones de
 liquidez de los bonos indexados también pueden elevar TR relativamente. Puesto que son bonos a
 diez años, atribuirlo exclusivamente a inflación de unos meses sería insuficiente; deben
 considerarse expectativas y primas durante su horizonte.
 4) La evidencia no respalda el temor a un rebrote inflacionario como explicación principal del
 gráfico. Si ese temor elevara la demanda relativa por bonos indexados, su precio subiría y TR
 bajaría relativamente a TN; aumentaría TN-TR. Se observa la evolución contraria, una fuerte
 reducción de esa brecha. No identifica una causa única, pero sí contradice la inferencia formulada a
 partir de estos precios.
 agosto 2010 - pregunta 6 - Bonos/renta fija
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 56-56 | convocatoria 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Ambos proyectos requieren $15 millones hoy y la tasa de descuento se fija en cero. Su flujo
 esperado al año es igual: (0,6(20)+0,4(30)=24) en A; (0,6(10)+0,4(45)=24) en B. Por ello, cada
 proyecto tiene VAN esperado $9 millones bajo tasa cero. Pero los pagos de bonos dependen del
 flujo y los dueños pueden escoger el proyecto después de emitir: existe riesgo de sustitución de
 activos.
 En A, el flujo mínimo es $20, así que una deuda con pago prometido de $15 al año puede cubrirse
 en ambos estados, dejando equity residual de $5 o $15. Bajo tasas y supuestos del caso, los
 acreedores podrían pagar $15 hoy por una promesa de $15, sin default. En B el flujo bajo es $10;
 un bono con promesa de $15 incumple en ese estado. Si inversionistas son neutrales al riesgo y
 descuento cero, se podría emitir una promesa mayor: para valor nominal (F) entre 10 y 45, cobro
 esperado sería (0,6(10)+0,4F); al igualarlo a $15 resulta (F=22,5), con cobro de 10 en estado bajo y
 22,5 en alto. Esto ilustra capacidad de recaudar $15 solo bajo neutralidad al riesgo y ausencia de
 prima de crédito/costos de insolvencia.
 Los dueños preferirán B tras emitir deuda porque su equity recibe cero en el estado bajo y (45-F) en
 el alto, concentrando upside; acreedores anticipan la elección. Si el mercado exige prima positiva
 por riesgo, hay costos de quiebra o los bonos deben pagarse con prioridad limitada, el valor
 esperado no determina por sí solo precio. La respuesta responsable es condicional: A sostiene
 deuda segura de $15; B también podría financiarse si los acreedores reciben una compensación
 que valoren en $15, pero el caso no especifica aversión al riesgo ni prima exigida, por lo que no
 puede afirmarse precio exacto sin ese supuesto.
 Qué haría esta respuesta distinguida: calcula ambos VAN, distingue el valor de activos de la
 distribución entre acreedor y accionista y detecta el incentivo a cambiar el riesgo después de emitir.
Examen de Grado UC | materia, preguntas y respuestas 200

[pág. 201]
Finanzas - versión clara y reordenada
 agosto 2024 - pregunta 1 - Bonos/renta fija
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 415-416 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Un modelo de valor presente resume el múltiplo como precio relativo al flujo: si dividendos crecen a
 g y el retorno requerido es r, P/E≈payout/(r-g), con r=rf+prima por riesgo sistemático. Para diez
 años, se puede separar el valor presente de flujos explícitos y valor terminal. Un CAPE de 35 frente
 a 20 requiere una combinación más favorable de tasas libres de riesgo, prima exigida,
 crecimiento/payout o utilidades normalizadas. Las tasas cortas y largas subieron de casi cero a
 cerca de 5%; manteniendo lo demás, ello baja el múltiplo. Para sostenerlo se necesitarían utilidades
 futuras mucho más altas, una prima menor u otra explicación de medición.
 Si utilidades no aceleran o r sube, el múltiplo puede comprimirse. Una caída de 35 a 20 equivale a
 -42,9% en el precio relativo a utilidades antes de dividendos, no una predicción puntual. Un múltiplo
 alto puede sugerir menores retornos futuros si se normaliza sin suficiente crecimiento, pero no
 demuestra burbuja ni anticipa fecha de corrección: CAPE usa utilidades rezagadas y pocos
 episodios extremos no identifican causalidad.
 Para cubrir una posición larga en índice, compraría una put sobre índice amplio con vencimiento
 que cubra el horizonte y strike que fije el piso. Payoff max(K-S_T,0) por unidad contractual, menos
 prima; conserva el alza sobre K, pero la prima reduce retorno. Ajustaría monto cubierto al tamaño
 de cartera; un put spread puede abaratar prima a cambio de limitar protección bajo el segundo
 strike.
 Qué haría esta respuesta distinguida: conecta tasas, crecimiento y prima con el múltiplo,
 distingue señal de valoración de certeza y define el payoff y costo de cobertura.
 agosto 2025 - pregunta 6 - Bonos/renta fija
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 449-450 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Flujo operacional después de impuesto=6.000(1-0,25)=4.500 anual. Sin deuda, rendimiento exigido
 12%: V_U=4.500/0,12=$37.500. Con deuda perpetua de $10.000 a 6%, intereses son $600; escudo
 anual $150. Si se mantiene la deuda y se descuenta al 6%, PV del escudo=150/0,06=$2.500. Bajo
 MM con impuestos y sin otras fricciones, V_L=37.500+2.500=$40.000. Tras pagar dividendo de
 $10.000, equity ex dividendo vale $30.000. La riqueza de accionistas originales es equity 30.000 +
 dividendo 10.000=$40.000, superior en $2.500 por el escudo fiscal.
 El costo del equity sube: rE=rU+(D/E)(rU-rD)(1-T)=12%+(10/30)(6%)(0,75)=13,50%. WACC
 after-tax=0,75(13,50%)+0,25(6%)(0,75)=11,25%; 4.500/11,25%=$40.000. El director acierta
 respecto del mayor riesgo/costo de equity, pero no se sigue que baje riqueza; el gerente se
 equivoca al decir que no cambia costo de capital: el WACC cae con escudo mientras rE sube.
 Supone deuda perpetua, escudo íntegramente utilizable y ausencia de distress, agencia y costos de
 emisión.
Examen de Grado UC | materia, preguntas y respuestas 201

[pág. 202]
Finanzas - versión clara y reordenada
 Qué haría esta respuesta distinguida: reconcilia firma, deuda, equity y dividendo, distinguiendo el
 costo del patrimonio del WACC.
 agosto 2023 - pregunta 6 - CDS, beta y arbitraje
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 400-401 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 a. Beta de una cartera compradora de protección CDS. Los CDS pagan cuando los soberanos
 incumplen. El enunciado indica que esos incumplimientos se concentran en recesiones mundiales,
 cuando la cartera de mercado tiene resultados malos. Los pagos de protección tienden entonces a
 covariar negativamente con el mercado: la beta de los flujos de una posición larga en protección es
 negativa, bajo el supuesto de que el vendedor del CDS paga y el resto de las condiciones se
 mantiene. No desaparece este riesgo común al comprar CDS de varios países si los defaults están
 coordinados. Al agregar esa protección a bonos soberanos emergentes con exposición positiva al
 ciclo, se reduce la beta del conjunto; el monto exacto depende de ponderaciones, nocionales y
 correspondencia de la cobertura. Puede eliminar riesgo de default del emisor cubierto, pero no toda
 duración, riesgo cambiario o liquidez.
 b. Relación de arbitraje. El tenedor del bono chileno paga la prima del CDS para comprar la
 protección. Por eso el rendimiento neto de la combinación es aproximadamente y_chi-r_CDS, no la
 suma de ambos. Para bonos comparables en moneda, plazo y condiciones, y una protección que
 replica las pérdidas de default:
 y_chi-r_CDS=y_USA; r_CDS=y_chi-y_USA.
 La prima compensa el spread de crédito: bono riesgoso más protección deja un flujo equivalente al
 bono seguro. Esta es la relación simplificada pedida; requiere vendedor solvente, mismo
 emisor/nocional/vencimiento/seniority, recuperación y eventos de crédito compatibles, capacidad de
 financiar y vender corto, y ausencia de costos. La valoración exacta compara patas de flujos
 descontados y no supone automáticamente que todos los bonos tengan idénticos cupones o
 precios.
 c. Fricciones y estrés. Riesgo de contraparte y correlación del asegurador con defaults,
 diferencias de entregabilidad o evento de crédito, bases de recuperación, bid/ask, liquidez distinta
 de bono y CDS, restricciones de ventas cortas, costo de financiamiento/repos, garantías y
 márgenes pueden quebrar la equivalencia ejecutable. En crisis de crédito y liquidez, las demandas
 de protección y de colateral aumentan mientras se reduce la capacidad de intermediación; es más
 probable observar desviaciones persistentes. Un spread aparente no es una ganancia sin riesgo si
 la estrategia conserva esas exposiciones.
 enero 2020 - pregunta 6 - Correlación y cobertura cambiaria
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 313-313 | convocatoria
 1
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 202

[pág. 203]
Finanzas - versión clara y reordenada
 Respuesta modelo propuesta para estudio (no oficial)
 a) El supuesto de volatilidades similares permite demostrar el beneficio de diversificar. Si ambas
 inversiones tienen desviación σ y su correlación es ρ, una cartera de 50% IPSA y 50% dólares tiene
 varianza σ²(1+ρ)/2. Es menor que σ² siempre que ρ<1. La tabla muestra que durante la crisis el
 IPSA cae mientras el dólar sube; ilustra una correlación baja o negativa y la compensación de
 pérdidas. No acredita que esa correlación sea permanente, pero, bajo los supuestos del ejercicio,
 favorece la diversificación. La afirmación de que faltan volatilidades omite un dato expresamente
 entregado.
 b) La rentabilidad en pesos del S&P 500 incorpora tanto su retorno en USD como el cambio del
 dólar: (1+r_USD)(1+r_FX)-1. Cubrir completamente el dólar elimina esa fuente de variación, pero
 también elimina su posible cobertura frente a caídas del IPSA. El riesgo de la cartera completa
 puede aumentar si se pierde una covarianza suficientemente negativa. La cobertura debe evaluarse
 por su efecto sobre el conjunto y por los pasivos del inversionista.
 c) Una posición corta en dólares gana cuando el peso se aprecia y pierde cuando el dólar sube. Si
 el dólar tiende a subir cuando el IPSA cae, esa posición aumenta la exposición conjunta a crisis
 chilenas. Una posición larga moderada en dólares puede compensarla. El tamaño óptimo depende
 de varianzas y covarianzas; comprar una cantidad arbitrariamente grande también puede elevar el
 riesgo. Diversificar no equivale a apostar sin límite por una moneda.
 enero 2012 - pregunta 5 - Curva de tasas, spreads y duración
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 96-97 | convocatoria 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 1) No basta que hoy la tasa a un año sea 3,5% frente a 5% a cuatro años. El bono largo fija el costo;
 el roll over expone a tasas futuras y a la posibilidad de no poder refinanciar. Los forwards de un año
 implícitos son f_1,2 = 1,04²/1,035-1 = 4,502415%; f_2,3 = 1,045³/1,04²-1 = 5,507223%; f_3,4 =
 1,05⁴/1,045³-1 = 6,514400%. Si se financia a estas tasas sucesivas, el factor acumulado coincide
 con 1,05⁴. No son necesariamente pronósticos: incluyen premios por riesgo y plazo. El roll over
 podría salir más barato o más caro según las tasas efectivas futuras; la curva creciente no
 demuestra una ventaja segura.
 2) No hay arbitraje por el solo aumento del spread de 1% a 1,5%. Los bonos categoría A y los libres
 de riesgo no tienen pagos igualmente seguros. El diferencial puede reflejar probabilidad de
 incumplimiento, pérdida en ese evento, riesgo sistemático del crédito, menor liquidez y mayor
 exposición de los bonos largos a cambios de solvencia. Una clasificación de riesgo común no
 convierte todos los vencimientos en flujos equivalentes. Arbitrar requeriría carteras de pagos
 idénticos con precios diferentes; un spread mayor por plazo no satisface esa condición.
 3) El bono A paga 500, 460 y 220 en los años 1-3, con TIR 10,8%. El B paga 83 y 1.083 en los años
 1-2, con TIR 9%. La duración de Macaulay es D = Σt·CF_t/(1+y)^t / P. Usando los precios
 calculados con esas TIR (las pequeñas diferencias con 987,69 son redondeo), D_A = 1,706864
 años y D_B = 1,922904 años. Las duraciones modificadas D/(1+y) son 1,540491 y 1,764132. Así,
 A es menos sensible a un desplazamiento pequeño y paralelo de rendimientos, pese a vencer más
 tarde. Para un horizonte de inversión de un año, su duración también está más cerca del horizonte.
Examen de Grado UC | materia, preguntas y respuestas 203

[pág. 204]
Finanzas - versión clara y reordenada
 El asesor confundió vencimiento con sensibilidad: recomendaría A para el criterio indicado,
 manteniendo los demás supuestos del ejercicio.
 enero 2014 - pregunta 6 - Deuda, estados y debt overhang
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 147-147 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Las cifras son millones y la tasa de descuento es cero.
 A) Si se mantiene la empresa, el banco recibe min(50;100)=50 en el estado alto y min(50;40)=40 en
 el bajo; su recuperación esperada es 45. Si liquida por 52, el banco solo tiene derecho a cobrar la
 deuda de 50; los 2 restantes corresponden a los accionistas. Como el acreedor paga hoy el costo
 de quiebra de 5, su recuperación neta es 50-5 = 45. Es indiferente entre liquidar y continuar, desde
 el punto de vista financiero y bajo estos supuestos. No puede apropiarse de los 52 completos.
 B) Sin tecnología, el accionista recibe 50 o 0; E_0 = 25. Con tecnología, los activos pagan 110 o 50,
 la deuda cobra 50 en ambos estados y el patrimonio recibe 60 o 0. Su valor es 30, pero debe
 aportar 3. La ganancia del accionista es 30-25-3 = 2; sí conviene. El proyecto crea 10-3 = 7 en total:
 5 benefician al banco y 2 a los dueños.
 C) Con probabilidades 25%/75%, el patrimonio sin proyecto vale 0,25×50 = 12,5. Con proyecto vale
 0,25×60 = 15, antes de aportar 3. La ganancia neta es 15-12,5-3 = -0,5. Los dueños rechazarían el
 proyecto. El proyecto conserva VAN total 7, pero los acreedores capturan 7,5 y los dueños pierden
 0,5. No basta que el flujo incremental total sea seguro: importa cómo se reparte entre deuda y
 patrimonio.
 agosto 2017 - pregunta 6 - Deuda, patrimonio y estados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 250-251 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Todos los valores son millones. Se mantienen las tasas exigidas que impone el enunciado: 10% a
 los activos y 2% a la deuda, ambas para seis meses. La deuda se paga en seis meses y no tiene
 intereses adicionales.
 1) Los activos pagan 120 o 60, con probabilidades de 50%. Por tanto, V = (120+60)/2 / 1,10 =
 81,818182. Con deuda de carátula 80, los acreedores reciben 80 o 60: D = 70/1,02 = 68,627451. El
 patrimonio vale E = V-D = 13,190731 y sus flujos son 40 o 0. Su rentabilidad esperada semestral es
 20/13,190731-1 = 51,6225%.
 2) Si la deuda de carátula sube a 90, los acreedores reciben 90 o 60. D' = 75/1,02 = 73,529412 y E'
 = 81,818182-73,529412 = 8,288770. La colocación adicional permite repartir 73,529412-68,627451
 = 4,901961 a los dueños. Su riqueza, incluyendo ese reparto, sigue siendo 8,288770+4,901961 =
 13,190731. La rentabilidad del patrimonio remanente aumenta a 15/8,288770-1 = 80,9677%,
 porque aumenta su riesgo. Mayor retorno exigido no implica mayor riqueza.
Examen de Grado UC | materia, preguntas y respuestas 204

[pág. 205]
Finanzas - versión clara y reordenada
 3) Con las noticias adversas, los activos pagan 91 o 60. Su valor es 75,5/1,10 = 68,636364.
 Volviendo a la deuda original de carátula 80, su valor sigue siendo 68,627451 porque sus cobros
 son 80 y 60. E = 0,008913. La pérdida se concentra casi por completo en los accionistas; los
 acreedores mantienen los mismos pagos por estado.
 4) El proyecto cuesta 6 y paga 11 o 10. Su valor es 10,5/1,10 = 9,545455 y su VAN total es
 3,545455. Los activos conjuntos pagarían 102 o 70: V' = 86/1,10 = 78,181818. Los acreedores
 cobrarían 80 o 70: D' = 75/1,02 = 73,529412. El patrimonio nuevo vale 4,652406. Los dueños deben
 comparar el aumento de su patrimonio con el aporte de 6: 4,652406-0,008913-6 = -1,356506.
 Rechazarían el proyecto, aunque su VAN total sea positivo. Los acreedores ganan 4,901961 y se
 verifica -1,356506+4,901961 = 3,545455. Es un problema de sobreendeudamiento: parte del valor
 creado recupera deuda existente.
 agosto 2011 - pregunta 6 - Diversificación y tipo de cambio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 83-86 | convocatoria 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 1. No: AAA informa principalmente riesgo de crédito, no riesgo nulo para Chile. Importan precio ante
 cambios de tasas, inflación, tipo de cambio, liquidez y, sobre todo, el retorno precisamente cuando
 cae la recaudación fiscal. Un activo es seguro en relación con el pasivo o necesidad que cubre.
 2. El FEES debe estar disponible cuando bajan ingresos no mineros por menor PIB, caen ingresos
 mineros por precio del cobre o aumentan necesidades de gasto. El portafolio de bajo riesgo fiscal
 busca preservar poder de compra y valor en pesos en esos estados; considera moneda, inflación,
 duration, liquidez y covarianza con ingresos fiscales. Un activo volátil por sí solo puede reducir la
 volatilidad del gasto si paga bien durante la recesión fiscal.
 3. No basta minimizar Var(RP). Como G=I+F(1+RP) y F es cierto: Var(G)=Var(I)+F²Var(RP)+2F
 Cov(I,RP). Con RP=wRA+(1-w)RB:
 Var(G)=Var(I)+F²[w²Var(RA)+(1-w)²Var(RB)+2w(1-w)Cov(RA,RB)]+2F[wCov(I,RA)+(1-w)Cov(I,RB)].
 Se minimiza esta función en w, sujeto a límites de inversión, liquidez, moneda y duración. La
 covarianza ingreso-rentabilidad puede cambiar la ponderación óptima; el objetivo es estabilizar
 gasto consolidado, no minimizar riesgo financiero aislado.
 Qué haría esta respuesta distinguida: define el riesgo desde la perspectiva fiscal, explicita todas
 las fuentes y deriva la función objetivo correcta.
 enero 2015 - pregunta 6 - Eficiencia de mercado y fondos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 170-171 | convocatoria
 1
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 205

[pág. 206]
Finanzas - versión clara y reordenada
 Respuesta modelo propuesta para estudio (no oficial)
 1) No hay contradicción lógica automática con eficiencia semifuerte. Esta hipótesis dice que precios
 incorporan con rapidez información pública; no dice que toda recomendación realizada gane ni que
 cada muestra de 11 fechas entregue el mismo resultado. Los retornos CSN dependen del punto de
 inicio y algunos superan a ambos fondos estáticos, otros quedan debajo de Fondo A o E. Para
 concluir alpha se necesitaría retorno ajustado por riesgo, un benchmark ex ante, intervalo de señal
 no solapado, datos fuera de muestra, honorarios, costos/impuestos por cambios y control de
 selección retrospectiva. La evidencia tabular no prueba que el método gane de modo persistente ni
 que la eficiencia sea falsa.
 2a) Para un afiliado conservador, el Fondo E tiene menor volatilidad histórica (1,11% frente a 6,12%
 en A) y menor retorno real promedio (3,95% frente a 6,99%). Cambiar a A puede elevar retorno
 esperado si el premio accionario compensa riesgo, pero también aumenta exposición a caídas.
 Alternar según “economía mala/buena” solo funciona si el modelo predice retornos futuros fuera de
 muestra; usar desempeño reciente puede inducir comprar tras alzas y salir tras bajas, perder
 rebotes y pagar costos. No garantiza aumentar retorno y reducir riesgo al mismo tiempo. Una
 asignación estratégica acorde al horizonte y tolerancia, con rebalanceo definido, es más defendible
 que prometer una mejora gratis.
 2b) Un cotizante agresivo que mantiene A acepta más riesgo por retorno potencial. Moverse a E
 ante crisis puede reducir volatilidad y pérdida inmediata, pero renuncia a prima de riesgo y puede
 cristalizar pérdidas antes de una recuperación; volver a A requiere acertar dos decisiones de timing.
 Para mejorar simultáneamente retorno y riesgo el sistema debe crear alpha o diversificación
 predictiva suficiente después de costos, evidencia que el cuadro no establece. Compararía cartera
 dinámica con permanencia A y estrategia de riesgo equivalente, neta de fees y drawdown, y
 validaría prospectivamente. La elección depende de horizonte, capacidad de soportar pérdidas y
 liquidez previsional; un suscriptor no puede interpretar backtest como garantía.
 Qué haría esta respuesta distinguida: aplica eficiencia a una prueba concreta, separa retorno
 bruto de alpha neta y vincula política de fondo con preferencias y riesgo, sin confundir reducir
 volatilidad con mejorar riqueza.
 agosto 2019 - pregunta 6 - Flujo residual y valor del equity
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 300-301 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 a) Valor del equity con flujos residuales. Activos valen 1.000 y generan (0,028(1.000)=28) al año;
 pasivos de rentas vitalicias valen 900 y pagan (0,025(900)=22,5). Flujo residual anual para
 accionistas (=5,5), perpetuo. El valor del patrimonio es activos menos pasivos (=1.000-900=100);
 por consistencia, el rendimiento requerido de equity implícito es (5,5/100=5,5%. En mercado
 perfecto, el precio máximo por el 100% es 100, sujeto a que activos/pasivos y flujos estén valorados
 a mercado y el perpetuo sea el modelo pertinente.
 b) Mayor leverage no crea valor. No concuerdo con la conclusión de KERCER bajo mercados
 perfectos sin impuestos. Elevar D/E y distribuir fondos cambia el reparto de riesgo y el costo de
 equity, no el valor del activo operativo. Para D/E=15, con deuda 900 y equity 60, se han distribuido
Examen de Grado UC | materia, preguntas y respuestas 206

[pág. 207]
Finanzas - versión clara y reordenada
 40; los activos operativos quedan 960. Su flujo residual (=0,028(960)-22,5=4,38). Mantener el costo
 de equity de 5,5% sería inconsistente porque el equity es más riesgoso. Con deuda tratada como
 de bajo riesgo y MM, (r_E=r_A+(D/E)(r_A-r_D)=2,8%+15(2,8%-2,5%)=7,3%; valor post-operación
 (4,38/0,073=60). Sumando la distribución de 40, riqueza total de accionistas (=100). Para
 leverage20, activos945, FCFE (=0,028(945)-22,5=3,96), (r_E=2,8%+20(0,3%)=8,8%, equity
 (=3,96/0,088=45); más distribución55 da nuevamente100. Los 119,6 y127 de la tabla mantienen
 indebidamente el costo de equity de5,5% pese al riesgo mayor.
 c) Activos con mayor rentabilidad esperada. No basta observar que un activo ofrece retorno
 esperado 3,0% o 3,2% frente a 2,8% y concluir que el valor del patrimonio sube. En mercado
 eficiente, retornos esperados más altos pueden compensar mayor riesgo, menor liquidez u otras
 exposiciones; el rendimiento requerido también cambia. El precio correcto es el valor presente de
 flujos esperados descontados a una tasa consistente con su riesgo. Si se compra un activo de
 mayor retorno pero también mayor riesgo a precio justo, no se crea NPV solo por cambiar el
 porcentaje de retorno. Si los nuevos activos tienen mismo riesgo que los anteriores y verdaderos
 flujos esperados mayores, sin mayor precio/costo ni efectos de pasivos, la riqueza económica sí
 podría subir; pero esa premisa debe probarse y los datos dados no informan el riesgo/costo de
 capital. En un mercado eficiente, la oferta de mayor retorno esperada debe explicarse por riesgo o
 por información nueva que eleva el valor y se incorpora al precio; comparar solo retornos confunde
 premio por riesgo con creación de valor.
 Qué hace sólida la respuesta: reconcilia flujo residual con valor patrimonial, corrige el costo de
 equity al cambiar leverage y separa retorno esperado de VAN ajustado por riesgo.
 agosto 2012 - pregunta 6 - Fusión, pérdidas tributarias y canje
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 112-113 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Las cifras son millones; los ahorros tributarios se reciben al cierre de cada año.
 a) PASADA vale 100/0,08 = 1.250. Los valores libro de sus activos no cambian el valor presente del
 flujo y todos son necesarios. MARELÉCTRICA vale 30 de liquidación más 20 de caja = 50, porque
 se supone que no puede usar sus pérdidas por separado. El grupo posee 100% de PASADA y 80%
 de MARELÉCTRICA: su patrimonio vale 1.250+0,8×50 = 1.290. CHISPITA posee los 10 restantes.
 La suma de ambas empresas es 1.300; ese total no es íntegramente propiedad del grupo.
 b) La utilidad antes de impuestos de PASADA es 125 anual. Las pérdidas 340 evitan impuestos
 sobre 125, 125 y 90 en los primeros tres años: ahorros 25, 25 y 18. VP del escudo =
 25/1,08+25/1,08²+18/1,08³ = 58,870599. La fusionada vale 1.250+50+58,870599 = 1.358,870599.
 El incremento total sobre la suma separada es 58,870599 y procede exclusivamente de aprovechar
 pérdidas tributarias bajo las reglas impuestas por el caso.
 c) La participación previa de CHISPITA vale 10. Para mantener ese valor, basta recibir
 10/1.358,870599 = 0,735905% de la fusionada; recibir 2% valdría 27,177412, es decir, asignaría
 además 17,177412 de la sinergia a CHISPITA. Puede negociar ese reparto, pero no es un mínimo
 que se deduzca de sus derechos previos. Incluso si se atribuyera a MARELÉCTRICA todo el valor
 del escudo y a CHISPITA un 20% de esa contribución, su valor sería 0,2×108,870599 = 21,774120,
Examen de Grado UC | materia, preguntas y respuestas 207

[pág. 208]
Finanzas - versión clara y reordenada
 equivalente a 1,602369%, todavía inferior al 2%. La relación de canje debe pactarse; el porcentaje
 no es consecuencia automática de poseer 20% de la empresa pequeña.
 enero 2017 - pregunta 6 - Goodwill y ahorro tributario
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 236-238 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 1) El goodwill es 1.500-1.000 = 500. Su amortización anual es 50 durante diez años, que ahorra
 50×25% = 12,5 de impuestos por año. El valor presente del ahorro es 12,5[1-1,08^-10]/0,08 =
 83,876017, equivalente a 5,591734% del precio 1.500. Se supone que la empresa puede usar
 íntegramente las deducciones, como indica su utilidad suficiente.
 2.1) Manteniendo los flujos operativos y el riesgo, el comprador pierde ese escudo al eliminarse la
 deducción. Si 1.500 era su disposición máxima a pagar con el régimen antiguo, su máximo
 equivalente nuevo es 1.500-83,876017 = 1.416,123983. El supuesto es que no cambian otras
 sinergias ni condiciones del negocio.
 2.2) Es necesario incorporar el nuevo precio solicitado en 2.1. Antes, el vendedor pagaba
 (1.500-1.000)×25% = 125 inmediatamente, y la empresa compradora ahorraba impuestos futuros
 con VP 83,876017. La recaudación neta en VP vinculada al sobreprecio era 125-83,876017 =
 41,123983. Con la reforma y el precio 1.416,123983, el vendedor paga (1.416,123983-1.000)×25%
 = 104,030996 y ya no hay amortización. La recaudación neta aumenta en 104,030996-41,123983 =
 62,907013. Equivale a 83,876017 de deducciones eliminadas menos 20,969004 de menor impuesto
 por la venta. Mantener el impuesto del vendedor en 125 mientras se reduce el precio a 1.416,12 es
 inconsistente.
 agosto 2014 - pregunta 3 - Gordon y crecimiento sostenible
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 153-153 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Las cifras son millones. Se supone que la reforma mantiene las utilidades y los retornos de los
 proyectos antes de impuestos; la tasa neta de 10% entregada es la que rige con el impuesto inicial
 de 20%. También se mantienen la tasa de descuento neta de 8%, las oportunidades de reinversión
 y la aplicación inmediata de la nueva tasa.
 1) Utilidad neta 2015 = 2.500. Dividendo D_1 = 0,60×2.500 = 1.500. Retención b = 0,40 y retorno
 neto 10% producen g = b×ROE = 4%. V_0 = 1.500/(0,08-0,04) = 37.500.
 2) La utilidad antes de impuestos es 2.500/0,80 = 3.125; con impuesto de 27%, utilidad neta =
 3.125×0,73 = 2.281,25. El retorno de reinversión antes de impuestos es 10%/0,80 = 12,5%; el
 nuevo retorno neto es 12,5%×0,73 = 9,125%. Mantener retención 40% reduce g a 3,65%. D_1 =
 0,60×2.281,25 = 1.368,75 y V = 1.368,75/(0,08-0,0365) = 31.465,517241. El valor cae
 6.034,482759, o 16,091954%.
Examen de Grado UC | materia, preguntas y respuestas 208

[pág. 209]
Finanzas - versión clara y reordenada
 3) Para conservar g = 4%, la retención debe ser b = 0,04/0,09125 = 43,835616%, y el reparto debe
 bajar a 56,164384%. La reinversión es 2.281,25×b = 1.000; el dividendo es 1.281,25. V =
 1.281,25/(0,08-0,04) = 32.031,25, que está 5.468,75 (14,583333%) debajo del valor inicial. Al
 reinvertir más se mantiene el crecimiento, sacrificando dividendos actuales.
 Si se impusiera como supuesto distinto que el rendimiento neto de los proyectos permanece 10%
 pese al mayor impuesto, g seguiría en 4% con reparto 60% y V sería 34.218,75. En ese supuesto
 no haría falta ajustar el reparto en 3. El enunciado permite explicitar supuestos, pero no debe
 presentarse ese rendimiento neto constante como una consecuencia automática de la reforma.
 agosto 2022 - pregunta 6 - HME, VIX y valor presente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 374-375 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 a) VIX y diversificación. No concuerdo con el analista. El VIX se construye a partir de precios de
 opciones del S&P 500 y mide volatilidad implícita de corto plazo, asociada al riesgo agregado del
 mercado y a expectativas bajo medida neutral al riesgo; no es una medida de volatilidad
 idiosincrática de una acción. En episodios de aversión al riesgo suele aumentar cuando caen
 acciones, generando relación contemporánea inversa entre VIX y nivel del índice. Esto no
 contradice eficiencia: los precios se ajustan a noticias y la volatilidad no diversificable/las primas de
 riesgo pueden cambiar. El VIX no es pronóstico direccional ni volatilidad realizada exacta; incorpora
 prima de varianza y otros componentes.
 b) Caída y recuperación. La caída de 30% y el posterior rebote no demuestran por sí solos
 sobrerreacción ni refutan eficiencia. La hipótesis de mercados eficientes sostiene que precios
 incorporan información disponible dadas fricciones y expectativas; no exige que los precios sigan
 una trayectoria suave ni que los resultados ex post parezcan obvios. Entre marzo y diciembre
 cambió información: políticas fiscales/monetarias, probabilidad de reapertura, tratamientos,
 expectativas de utilidades, tasas de descuento y primas de riesgo. Para evaluar sobrerreacción hay
 que definir el modelo de retornos esperados, evento e información en cada fecha y documentar
 retornos anormales/predecibles después de controlar riesgo, costos y riesgo de supervivencia. Que
 el mercado suba 63% desde el mínimo es una base de comparación elegida ex post.
 c) Flujos y descuento. No concuerdo con inferir que una caída de precio exige que los flujos
 nominales esperados hayan caído 30% a perpetuidad. Valor presente depende de flujos esperados
 por horizonte y de tasas de descuento/condiciones de riesgo. Una crisis puede reducir
 temporalmente flujos, elevar probabilidad de escenarios extremos, aumentar prima de riesgo,
 liquidez o costo de capital y alterar tasas; efectos pequeños pero persistentes en crecimiento
 terminal también tienen gran impacto en valoración. La recuperación puede reflejar menor
 incertidumbre o una caída de tasas, aunque los flujos no hayan vuelto a su trayectoria inicial. La
 afirmación de “30% de riqueza destruida permanentemente” confunde cambio de precio hoy con
 pérdida permanente de riqueza real; se requiere estimar escenarios, flujos y tasa coherentes para
 concluir mispricing.
 Qué hace sólida la respuesta: distingue volatilidad implícita de riesgo idiosincrático, no usa
 trayectorias ex post como prueba de ineficiencia y separa flujos esperados de tasas/primas de
Examen de Grado UC | materia, preguntas y respuestas 209

[pág. 210]
Finanzas - versión clara y reordenada
 descuento.
 enero 2018 - pregunta 6 - Liquidez y opciones societarias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 264-264 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 a) Rendimiento de empresa cerrada. Manteniendo beta y exposición sistemática idénticos, CAPM
 por sí solo no predice retorno esperado mayor por el hecho de no transarse públicamente. Sin
 embargo, la iliquidez, restricciones de diversificación, información menos transparente y horizonte
 de salida largo pueden exigir primas adicionales o compensación contractual; beta no captura todos
 esos riesgos/fricciones. Por tanto, en la práctica esperaría un retorno requerido potencialmente
 mayor por iliquidez y concentración, pero no afirmaría una prima universal ni atribuiría un diferencial
 solo a beta igual sin precisar modelo, costos y derechos.
 b) Opciones implícitas y beneficiarios. (i) Derecho del minoritario a vender al controlador a precio
 preestablecido: put del minoritario, que limita pérdida/salida si se cumplen condiciones; el
 controlador asume la obligación de compra. (ii) Tag along: opción de venta/put del minoritario para
 participar en la venta del controlador en los mismos términos, protegiéndolo de quedar en una
 empresa con nuevo controlador; beneficia principalmente al minoritario y puede limitar al
 comprador/controlador. (iii) Drag along: derecho del controlador a obligar la venta de las acciones
 minoritarias al tercero en términos iguales, análogo a una call/control de venta sobre los paquetes
 minoritarios; facilita transferir 100% y puede beneficiar a todos al evitar un descuento de minoría,
 aunque reduce autonomía del minoritario. (iv) Right of First Refusal: derecho prioritario del
 controlador a comprar si un tercero hace oferta, opción de compra (call) del controlador sobre las
 acciones del minoritario a precio ofertado; protege control, pero puede desalentar ofertas o bajar
 precio si el tercero anticipa que su oferta será usada.
 c) Función económica de cada cláusula. Put a precio preestablecido: crea salida y reduce riesgo
 de iliquidez/hold-up del minoritario, aunque precio y condiciones deben evitar incentivos perversos.
 Tag along: protege al minoritario frente a cambio de control y asegura acceso proporcional a prima
 de control. Drag along: permite una venta integral, elimina problema de accionista bloqueador y
 facilita capturar valor de una oferta por toda la empresa; igualdad de términos protege trato
 económico, sin eliminar la importancia de salvaguardas. ROFR: permite al controlador conservar
 control/adquirir participaciones y filtra transferencias a terceros, pero introduce fricción y posible
 costo para el minoritario. En conjunto, los pactos asignan derechos de salida y control, reducen
 conflicto agencia y hacen invertible un activo ilíquido; a la vez, redistribuyen valor/riesgo y no
 reemplazan una valoración justa ni gobierno corporativo.
 Qué hace sólida la respuesta: identifica opción y parte beneficiada, explica el mecanismo de
 liquidez/control y distingue predicción CAPM de primas por fricciones privadas.
 enero 2021 - pregunta 3 - Mercados eficientes y señalización
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 333-333 | convocatoria
 1
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 210

[pág. 211]
Finanzas - versión clara y reordenada
 Respuesta modelo propuesta para estudio (no oficial)
 Se analiza el anuncio histórico de SQM del 24 de diciembre de 2020, con el conjunto de información
 y los supuestos del enunciado. Se distingue una reacción de precio de una predicción posterior y el
 valor de invertir de los efectos informativos de emitir acciones.
 a. Información simétrica y mercado eficiente. El mercado aprende un plan de expansión antes
 desconocido. Una caída de la acción puede indicar que el valor presente de los beneficios
 esperados de la expansión es menor que su costo, o que cambian el riesgo y las perspectivas del
 negocio previo. Emitir a un precio justo no destruye riqueza automáticamente: el mayor número de
 acciones va acompañado por recursos nuevos; una dilución del porcentaje de propiedad no es, por
 sí sola, una pérdida de valor económico.
 Las «cuentas» pueden ilustrarse con las cifras del texto. Si US$1.100 millones representan 10% de
 la capitalización previa, esta era aproximadamente US$11.000 millones. Una caída de 4,21%
 representa unos US$463,1 millones de menor valor patrimonial antes de emitir. Bajo el supuesto
 adicional de que no cambia nada más y que el 4,21% se atribuye íntegramente al plan, el VAN que
 el mercado asigna a la expansión sería -463,1 millones; con inversión de 1.900 millones, el VP de
 sus beneficios sería 1.436,9 millones. Es una ilustración condicional: no identifica por sí sola cuál
 componente del plan fue revisado.
 Para separar la caída común del mercado, el retorno esperado de un día según CAPM es r_f,d +
 0,9(R_m,d-r_f,d), no r_f,d + 0,9R_m,d. Con R_m,d = -0,55%, el rendimiento ajustado al movimiento
 de mercado es -0,495% + 0,1r_f,d. El retorno anormal aproximado es -3,715 puntos porcentuales
 - 0,1r_f,d. Si la tasa libre diaria es despreciable, la pérdida adicional al mercado es
 aproximadamente 11.000×3,715% = US$408,65 millones. Restar simplemente el IPSA da -3,66
 puntos, pero no ajusta por el beta 0,9. Tampoco se deben atribuir simultáneamente la caída bruta y
 la ajustada a dos pérdidas distintas.
 b. Información asimétrica. Si los controladores conocen la calidad o el valor de SQM mejor que
 los compradores y su decisión de emitir depende de esa información, el anuncio puede revelar que
 consideran elevado el precio actual. El mercado actualiza la probabilidad de sobrevaloración y
 reduce el precio ofrecido. Son necesarios: una diferencia relevante de información, una elección de
 financiamiento relacionada con esa información y una actualización racional de creencias. No basta
 decir «hay asimetría» sin describir el mecanismo. La selección adversa puede producir caída aun si
 la expansión tiene VAN positivo; por ello, atribuir toda la pérdida del precio al VAN del proyecto,
 como en la ilustración de a, dejaría de ser válido.
 c. Predicción justo antes de la junta del 22 de enero de 2021. Al cierre del 24 de diciembre, el
 precio 33.698 ya recoge la probabilidad de aprobación, rechazo y condiciones que el mercado
 conoce. En ausencia de dividendos durante el intervalo, un pronóstico condicional de precio parte
 de ese valor y acumula el rendimiento esperado apropiado al riesgo: E[P_T | información actual] =
 33.698×(1+k_horizonte), bajo un modelo de retorno esperado para el intervalo. No se puede
 calcular k_horizonte con el solo beta: faltan tasa libre y prima esperada consistentes con el plazo.
 Un precio aproximadamente plano puede ser una aproximación razonable si el rendimiento
 esperado del corto intervalo es pequeño; la eficiencia no exige que el precio realizado sea
 constante. Tampoco permite predecir una recuperación o profundización anormal de la caída por la
 sola cercanía de la junta. Noticias no anticipadas modifican flujos o probabilidades y producen
 nuevos ajustes. Si la aprobación ya se espera, el hecho de aprobar no crea una ganancia anormal
Examen de Grado UC | materia, preguntas y respuestas 211

[pág. 212]
Finanzas - versión clara y reordenada
 segura: el anuncio esperado estaba incorporado. La elección de emitir y la decisión de invertir
 deben valorarse con supuestos coherentes, sin confundir el evento conocido con una sorpresa
 futura.
 enero 2013 - pregunta 6 - Opciones y cobertura por estados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 125-125 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 a) Con K = 50, el call paga 50, 0, 0 y 0 en los cuatro estados; el put paga 0, 0, 20 y 40. Con las
 probabilidades del mercado y tasa cero, C = 0,2×50 = 10 y P = 0,3×20+0,2×40 = 14. La acción vale
 S_0 = 0,2×100+0,3×50+0,3×30+0,2×10 = 46. Se verifica P = C-S_0+K = 14.
 b1) Compraría el put si se busca mantener la acción y asegurar un piso. Acción más put paga 100,
 50, 50 y 50: preserva el alza y cubre los estados 3 y 4. Un call no cubre una caída de la acción ya
 poseída.
 b2) El cobro terminal esperado es 0,2×100+0,8×50 = 60. Restando la prima de 14 pagada hoy, el
 flujo neto esperado de mantener la acción y agregar protección es 46. Si se incluye también el costo
 de oportunidad de la acción existente de 46, la ganancia esperada neta de toda la posición es cero;
 adquirir desde cero la cartera costaría 46+14 = 60. Conviene distinguir cobro terminal, prima y valor
 de un activo ya poseído.
 c) Bajo las probabilidades del gerente, el put tiene pago esperado 0,3×40 = 12, inferior a su precio
 de 14. Comprar protección reduce en 2 el valor esperado subjetivo, aunque la probabilidad del peor
 estado aumente; desaparece a la vez la probabilidad del estado intermedio que antes pagaba 20.
 La acción sola tiene valor esperado 53; protegida cobra 65 y, tras restar prima, 51. Si el criterio es
 maximizar valor esperado, no recomendaría el put a 14 bajo estas expectativas. Un gerente
 suficientemente averso a pérdidas puede comprarlo como seguro, aceptando el costo esperado de
 2. Tener más probabilidad de un estado extremo no basta para valorar una opción: importan todos
 los estados y sus pagos.
 agosto 2016 - pregunta 6 - Opciones y paridad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 221-224 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 1.i) Quien tiene libras y debe cambiarlas a dólares pierde si baja S, medido en USD/GBP.
 Compraría puts sobre la libra: max(K-S_T,0) establece un piso de conversión. La combinación libra
 más put vale max(S_T,K) antes de descontar la prima; conserva la ganancia si la libra se aprecia.
 1.ii) Manteniendo iguales spot, vencimiento, ejercicio y tasas, el aumento de volatilidad aumenta el
 valor de calls y puts: crecen sus posibilidades de pagos altos, mientras su pago mínimo sigue
 siendo cero. No se necesita saber la dirección del resultado del referendo.
 2) Compraría un call y un put, ambos con K = 1,5 y vencimiento el 24 de junio: un straddle largo. Si
 q = C+P es la prima total por libra, el resultado neto es |S_T-1,5|-q. Es positivo si S_T<1,5-q o
Examen de Grado UC | materia, preguntas y respuestas 212

[pág. 213]
Finanzas - versión clara y reordenada
 S_T>1,5+q. El punto mínimo es -q cuando S_T = 1,5. Los movimientos deben superar las primas
 para producir una ganancia.
 text Resultado neto / 0 -- -----------------------/---------------- / / -q / (vértice en S = 1,5) 1,5-q 1,5 1,5+q
 S_T (USD/GBP)
 El gráfico representa dos rectas con pendientes -1 y +1 que se unen en (1,5; -q).
 3) Con tasa de un día cero y K = S_0 = 1,5, P = C-S_0+K = C. Esta igualdad proviene del no
 arbitraje entre carteras con los mismos pagos. No implica probabilidad física de 50% para cada
 resultado: pueden diferir la magnitud de las variaciones, las probabilidades y la valoración de pagos
 en cada estado.
 agosto 2009 - pregunta 6 - Opciones/derivados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 25-29 | convocatoria 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 1) El gerente 1 acierta si la caída del dólar obedece a un cambio permanente en condiciones
 competitivas y la firma solo cubre un año: la cobertura protege los ingresos contratados de ese año,
 pero no sustituye ajustes operativos para los años siguientes. Sin embargo, si el mercado es
 eficiente, el precio corriente incorpora información disponible y no permite afirmar con certeza que
 el dólar seguirá bajo o caerá más. Cubrir es transferir riesgo, no demostrar un pronóstico. En un
 mercado perfecto sin costos de dificultades financieras, restricciones o efectos tributarios, una
 cobertura a precio justo no crea riqueza por sí sola y los accionistas pueden modificar su exposición
 individualmente.
 2) Su comentario es válido para el forward, pero no en la misma forma para la put comprada.
 Suponga cobertura por USD 10 millones a K = 566 y exportación efectiva de solo USD 5 millones.
 Si S_T = 580, las exportaciones cobran 2.900 millones de pesos y el forward obliga a pagar al
 banco 10 millones×(580-566) = 140 millones. Parte del contrato cubre dólares que nunca se
 exportaron; una insuficiencia de caja puede dificultar el pago. Si S_T = 700, esa obligación sería
 1.340 millones. En cambio, la put comprada no se ejerce cuando S_T>K y no genera una obligación
 terminal adversa adicional: su prima ya se pagó al contratar. Si S_T = 500, tanto el forward corto
 como la put larga por 10 millones pagan 660 millones a la empresa. También hay sobrecobertura en
 volumen, pero la put larga no obliga a realizar un pago terminal negativo. La prima y su
 financiamiento sí pueden exigir caja inicial.
 3) La eficiencia semifuerte elimina una expectativa de ganancia anormal sistemática por
 información pública; no elimina el valor de gestionar descalces. La cobertura puede crear riqueza si
 reduce costos esperados de insolvencia, evita abandonar proyectos rentables por falta de caja,
 facilita financiamiento o corrige una exposición que los accionistas no pueden cubrir igual de
 eficientemente. Deben compararse esos beneficios con prima, costos y riesgo de volumen. Un
 forward grande sobre exportaciones inciertas puede aumentar el riesgo; una put o cobertura parcial
 puede reducirlo. Por sí solos, la caída del dólar o un resultado positivo del derivado no prueban
 creación de valor: debe evaluarse el negocio más la cobertura y el contrafactual sin ella.
Examen de Grado UC | materia, preguntas y respuestas 213

[pág. 214]
Finanzas - versión clara y reordenada
 enero 2023 - pregunta 6 - Paridad cubierta y arbitraje
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 387-388 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 a. La diferencia entre expectativa spot y forward no demuestra arbitraje. Con las tasas
 efectivas de tres meses entregadas, F^*=832(1,08)/(1,04)=864 CLP/USD. El forward observado 864
 cumple exactamente la paridad cubierta. Que el mercado espere un spot 900 permite una apuesta
 riesgosa sobre el dólar, pero no fija un beneficio positivo en todos los estados: el spot efectivo
 puede diferir de 900. La paridad cubierta relaciona rendimientos contractuales y precioforward, no
 obliga a que forward sea igual al spot físico esperado; las primas por riesgo cambiario pueden
 separar ambos.
 b. Estrategia con CCB negativa. Con los datos exclusivos de esta parte, el forward teórico es
 832(1,105)/(1,04)=884, superior al observado 845. Por cada USD 1 prestado hoy: se venden esos
 dólares spot por CLP 832; se depositan a 10,5% por tres meses para recibir CLP 919,36;
 simultáneamente se compra forward el monto de USD 1,04 necesario para pagar el préstamo. Ese
 forward requiere 1,04(845)=878,80 CLP al vencimiento. Tras repagar la deuda en dólares quedan
 CLP 40,56 seguros por cada USD 1 de préstamo inicial. Equivalentemente, convertir la totalidad del
 depósito al forward da 919,36/845-1,04=0,048 USD de ganancia. Todas las operaciones se pactan
 hoy y usan el mismo vencimiento; no queda una exposición abierta al spot futuro.
 c. Persistencia. El caso ideal concede acceso ilimitado, pero en la práctica restricciones de
 balance y crédito, colateral y márgenes, distintos precios de préstamo/deposito y compra/venta,
 riesgo de contraparte/liquidación y costos de transacción limitan el tamaño y rentabilidad de la
 operación. En crisis, escasez de financiamiento en dólares y límites regulatorios de balance pueden
 hacer especialmente costoso expandir posiciones, permitiendo que el basis persista. Antes de
 llamar arbitraje a una diferencia publicada, se comprueba que las cotizaciones sean simultáneas y
 ejecutables al mismo plazo.
 enero 2016 - pregunta 6 - Pesos, UF e inflación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 195-196 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 a) No se recibe cupón durante los tres meses y se esperan las mismas TIR al vender. Con la
 convención de TIR anual efectiva, el precio con intereses devengados crece durante el trimestre por
 (1+y)^(3/12). El BCP obtiene (1,0401)^0,25-1 = 0,987768% nominal. La variación de la UF es
 25.830,58/25.629,09-1 = 0,786177%. El retorno nominal del BCU es
 (1,0126)^0,25×(25.830,58/25.629,09)-1 = 1,102164%. Favorecería el BCU, por aproximadamente
 0,1144 puntos porcentuales. Si la TIR estuviese expresada como nominal anual con capitalización
 semestral, los factores trimestrales serían (1+y/2)^0,5; la comparación sigue favoreciendo BCU.
 Debe compararse precio con devengo en ambos instrumentos y traducir la UF a pesos, sin tratar la
 tasa anual como un retorno trimestral completo.
Examen de Grado UC | materia, preguntas y respuestas 214

[pág. 215]
Finanzas - versión clara y reordenada
 b) No es cierto que «siempre» convenga UF. BCU supera a BCP en 2010, 2012, 2014 y 2015; BCP
 supera a BCU en 2009, 2011 y 2013. En 2011 los retornos son 1,36% y 1,42%, respectivamente. La
 media simple de los siete trimestres es 1,9829% real para BCU y 1,4300% para BCP. Aunque la
 media observada favorece BCU, no prueba una ganancia segura futura. Una estacionalidad
 conocida puede incorporarse en precios y tasas, y los retornos de bonos también dependen de
 movimientos inesperados de tasas e inflación.
 c) Para ahorrantes con horizonte largo y consumo real, el bono nominal añade incertidumbre sobre
 poder adquisitivo, mientras la UF cubre ese riesgo. Si el riesgo inflacionario es adverso para estos
 ahorrantes, exigirán un premio y el nominal tendrá mayor rentabilidad real esperada. No hay
 garantía de mayor retorno realizado: inflación inesperadamente alta perjudica al nominal. La
 comparación debe hacerse en la misma moneda y separar inflación esperada del premio por riesgo.
 enero 2025 - pregunta 5 - Portafolio, CAPM y puts
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 435-435 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 1. Riesgos pesqueros. No basta afirmar que hay “demasiado riesgo incontrolable”. En CAPM
 importa el riesgo sistemático que co-varía con el mercado, no la volatilidad total de una acción
 aislada. Si una huelga, veda o evento climático es específico de una firma/industria y el Fondo
 mantiene una cartera diversificada, parte de ese riesgo se diversifica; no desaparece si afecta
 simultáneamente a muchas empresas o coincide con caídas del mercado, y puede haber riesgo
 regulatorio, liquidez o cola que la diversificación imperfecta no elimine. Por tanto, se evalúa beta,
 correlación, contribución marginal al riesgo de cartera, retorno esperado, concentración y límites de
 mandato; no se rechaza solo por volatilidad idiosincrática.
 2. Rodantes y Barcarola. CAPM exige (E[R_i]=R_f+β_i(E[R_m]-R_f)). Rodantes: retorno requerido
 (4%+0,9(6%)=9,4%; retorno informado 10%, alpha respecto del CAPM (+0,6) puntos porcentuales.
 Barcarola: requerido (4%+2(6%)=16%; retorno informado 15%, alpha (-1) pp. Bajo el supuesto de
 que los retornos esperados y betas son comparables y correctos, Rodantes parece más atractiva
 respecto del CAPM y Barcarola no compensa su exposición sistemática. La volatilidad total
 (30%/40%) no sustituye el beta ni basta para ordenar títulos en una cartera diversificada. Aun así,
 sin covarianzas, costos, horizonte, liquidez y validación de estimaciones, la recomendación es
 condicional.
 3. Opciones. Si la apuesta era beneficiarse de una caída del precio del subyacente, la posición
 coherente es comprar (posición larga en) puts: su payoff al vencimiento es max(K-S_T,0), antes de
 restar la prima. Al subir sustancialmente la acción, los puts pueden quedar fuera del dinero y no
 conviene ejercerlos; la pérdida del comprador queda acotada a la prima. Comprar calls sería la
 apuesta alcista y no ejercer una call con (S_T>K) requeriría una explicación adicional (por ejemplo,
 opción aún fuera del dinero, costos/condiciones, barreras o mala ejecución). La dirección se infiere
 del dato descrito; el texto no da strikes ni primas para calcular rentabilidad.
 Qué hace sólida la respuesta: separa riesgo diversificable de sistemático, calcula alphas contra
 CAPM y explica el payoff y la pérdida máxima de la posición comprada.
Examen de Grado UC | materia, preguntas y respuestas 215

[pág. 216]
Finanzas - versión clara y reordenada
 agosto 2018 - pregunta 3 - Portafolios, beta y Sharpe
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 270-271 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 a) Si el inversionista posee únicamente una acción, importa su riesgo total; no basta escoger por
 beta. El CAPM remunera riesgo sistemático porque supone inversionistas capaces de diversificar el
 riesgo específico. Un inversionista concentrado todavía soporta ese riesgo específico.
 b) Para una cartera con 99% en el índice y 1% en A o B, el retorno esperado es
 0,99×10%+0,01×13% = 10,03% con A y 10,04% con B. La varianza es
 w_M²σ_M²+w_i²σ_i²+2w_Mw_iρσ_Mσ_i. Con A resulta 0,03980425 y σ = 19,9510%; con B resulta
 0,03961600 y σ = 19,9038%. Por tanto, la cartera con B domina: tiene mayor retorno esperado y
 menor volatilidad. La volatilidad individual mayor de B no impide que su menor correlación aporte
 mejor diversificación.
 c) Los cocientes de Sharpe son (15%-4%)/22% = 0,50 para C y (18%-4%)/35% = 0,40 para D. C es
 mejor si se compara retorno excedente por unidad de riesgo, y si se permite combinar el fondo con
 el activo libre de riesgo para igualar la exposición deseada. Pero la pregunta establece inversión de
 100% en uno de los dos fondos; C no domina a D, porque ofrece menor retorno y menor riesgo. Ser
 averso al riesgo no basta para determinar cuál prefiere sin cuantificar esa aversión. En el criterio
 media-varianza U = μ-Aσ²/2, C es preferible cuando A > 2(0,18-0,15)/(0,35²-0,22²) = 0,809717; D
 cuando A es menor. Así, la respuesta habitual «C por Sharpe» requiere explicitar el criterio o la
 posibilidad de ajustar la exposición.
 agosto 2020 - pregunta 4 - Retorno, riesgo, probabilidades y Sharpe
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 322-323 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Las cifras de rentabilidad y volatilidad son mensuales. Los retornos de meses distintos son
 independientes; bonos y acciones tienen correlación cero.
 a) A: μ_A = 0,2×0,4%+0,8×1% = 0,88%; σ_A = √[(0,2×0,6%)²+(0,8×2%)²] = 1,604494%. C: μ_C =
 0,5×0,2%+0,1×0,4%+0,4×1% = 0,54%; σ_C = √[(0,1×0,6%)²+(0,4×2%)²] = 0,802247%. C es mitad
 depósito y mitad A.
 b) Los fondos comparten activos y no son independientes. R_A-R_C = 0,5(R_A-0,2%). Su media es
 0,34 puntos porcentuales y su desviación 0,802247 puntos. P(R_A<R_C) = Φ(-0,34/0,802247) ≈
 33,59%. En la escala pedida es «probable», entre 5% y 95%. Tener mayor media no garantiza
 ganar cada mes.
 c) El ranking de retornos aritméticos esperados es 2 > 3 > 1. La independencia implica que un mes
 negativo de A no predice el mes siguiente; cambiar a C sustituye algunos retornos esperados de
 0,88% por 0,54%. La política 3 queda entre ambos. No se pide una media exacta, pero, si se
 calcula, debe respetarse que después de un mes en C se vuelve obligatoriamente a A. Sea q =
Examen de Grado UC | materia, preguntas y respuestas 216

[pág. 217]
Finanzas - versión clara y reordenada
 P(A<0) = Φ(-0,88/1,604494) ≈ 0,29169. Las transiciones son A→C con q y C→A con certeza. La
 proporción de meses en C en régimen es q/(1+q) ≈ 22,5819%, no q. La media de la política 3 es
 0,88%-0,34%×q/(1+q) ≈ 0,803221%, no 0,78%. Para un horizonte finito que parte en A se usa la
 recursión p_(t+1,C)=q[1-p_(t,C)]; el ranking permanece. El retorno geométrico y una trayectoria
 realizada son conceptos distintos.
 d) Los retornos excedentes y las volatilidades de C son exactamente la mitad de los de A;
 Sharpe_A = (0,88-0,20)/1,604494 = 0,423810, y Sharpe_C = (0,54-0,20)/0,802247 = el mismo. Si
 ambas son combinaciones eficientes de una cartera tangente común y depósitos, la igualdad es
 coherente. No significa que cualquier estimación de veinte años sea idéntica sin error muestral ni
 que todo inversionista quiera el mismo riesgo total.
 marzo 2010 - pregunta 6 - Riesgo y portafolios
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 41-44 | convocatoria 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 a) La eficiencia de mercado no equivale a predecir toda noticia futura. Una caída abrupta puede ser
 una reacción inmediata a nueva información sobre flujos, riesgo y financiamiento. Si hubiera sido
 públicamente predecible con certeza, los precios se habrían ajustado antes. Observar -20% frente a
 una media histórica de 10% no basta para rechazar eficiencia ni toda la teoría financiera: una
 rentabilidad realizada puede diferir mucho de la esperada. Eso no impide investigar fallas concretas
 de valoración o gestión del riesgo; exige evidencia adicional.
 b) No. Un fondo A tiene alta exposición a renta variable; puede perder con el mercado en 2008 y
 recuperar durante 2009 sin que cambie la habilidad del administrador. Debe compararse contra un
 benchmark de igual riesgo y las restricciones del mandato, incluyendo comisiones, diversificación y
 decisiones de inversión. Pérdidas sistemáticas del mercado no prueban negligencia; tampoco un
 rebote prueba habilidad. La información entregada no permite concluir ninguna de las dos cosas.
 c) El gráfico primario muestra movimientos frecuentemente contrapuestos: por ejemplo, IGPA
 negativo y commodities positivos en enero, septiembre y octubre. Bajo la evidencia hipotética del
 ejercicio, una combinación puede reducir la volatilidad y amortiguar pérdidas. Para peso w en
 acciones, Var(R_P) = w²σ_A²+(1-w)²σ_C²+2w(1-w)Cov(R_A,R_C). Una covarianza baja o negativa
 produce el beneficio incluso si ambos activos son volátiles. Tener más de cien acciones ayuda a
 diversificar riesgos específicos, pero no elimina el riesgo común del mercado; commodities pueden
 aportar otra fuente de diversificación. El retorno esperado del conjunto es wE(R_A)+(1-w)E(R_C):
 incluir commodities no garantiza aumentarlo. En la muestra puede aliviar las pérdidas accionarias,
 pero no demuestra protección en toda crisis futura. El propio enunciado advierte que la serie de
 commodities es ilustrativa.
 enero 2026 - pregunta 5 - Riesgo y portafolios
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 460-460 | convocatoria
 1
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 217

[pág. 218]
Finanzas - versión clara y reordenada
 Respuesta modelo propuesta para estudio (no oficial)
 CAPM para equity: rE=4%+0,75(20%-4%)=16%. Costo de activos rA=0,25×4%+0,75×16%=13%.
 FCF perpetuo $26: V=26/0,13=$200, con deuda $50 y equity $150.
 Al bajar deuda a 10%, MM sin impuestos mantiene V=$200; deuda=$20 y equity=$180. Beta de
 activos=0,75×0,75=0,5625; beta equity nueva=0,5625/0,90=0,625; rE=4%+0,625×16%=14%.
 Disminuye retorno requerido por menor apalancamiento, aunque el riesgo operacional permanezca.
 El proyecto tiene descuento 13%; PV de flujos=15,6/0,13=$120, VAN=$60. Al anunciarlo, valor
 firma pre-emisión=$200+$60=$260. Con deuda $20, equity pre-money=$240. Tras emitir $60 a
 precio justo para financiar inversión, equity post-money vale $300; el dueño único que no suscribe
 conserva participación de 240/300=80%. La emisión diluye porcentaje, pero el dueño mantiene
 valor económico $240 bajo precio justo. Supone mismo riesgo, CAPM, mercado perfecto y ausencia
 de costos de emisión.
 Qué haría esta respuesta distinguida: deriva beta y costo de activos, usa el VAN incremental y
 distingue valor pre-money, capital nuevo y propiedad post-money.
 enero 2024 - pregunta 6 - Tasas, portafolio y HME
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 412-413 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 a) Mayor TPM neutral. En media-varianza, si el activo seguro ofrece una tasa mayor y se
 mantienen constantes retorno esperado y riesgo de los activos riesgosos, cae su retorno excedente
 esperado (E[R_P]-R_f). Para una misma aversión al riesgo, el peso óptimo en el portafolio riesgoso
 tiende a bajar y aumenta el peso en depósitos; formalmente, con un portafolio tangente fijo, el peso
 riesgoso (y=(E[R_P]-R_f)/(Aσ_P^2)). Pero el portafolio tangente también podría cambiar si cambian
 covarianzas/primas de riesgo; la TPM neutral no determina por sí sola una asignación exacta. Hay
 que distinguir tasa neutral estructural, TPM efectiva y depósitos de corto plazo que la siguen con
 rezago.
 b) Curva invertida y bonos largos. No es suficiente comparar retorno esperado aislado y riesgo
 propio de cada activo. La elección depende de su contribución marginal al riesgo y retorno de la
 cartera: una clase con retorno esperado igual o algo menor puede ser eficiente si su correlación con
 acciones y depósitos es baja/negativa o si cubre pasivos de larga duración. En conjunto reduce
 volatilidad o mejora frontera eficiente. Si el bono está dominado en retorno y riesgo por depósitos y
 sus covarianzas no aportan diversificación, sí se excluye. Bonos largos sí tienen riesgo de
 duración/precio y depósitos riesgo de reinversión e inflación/horizonte; un bono de gobierno nominal
 no es “sin riesgo” para un inversionista que liquida antes del vencimiento. La recomendación
 depende del horizonte, pasivos, tolerancia a pérdidas, impuestos y liquidez.
 c) Recortes esperados y retornos de bonos. Una trayectoria de TPM que el mercado espera con
 credibilidad debe estar incorporada en precios actuales y en la curva. Cuando cada recorte
 esperado ocurre, no garantiza una ganancia anormal ese día: el precio ya reflejaba la noticia. Un
 bono largo gana si las tasas relevantes caen más de lo incorporado, y pierde si suben o descienden
 menos; aproximadamente Δ P/P≈-D_modΔ y, con convexidad para movimientos grandes. Su
Examen de Grado UC | materia, preguntas y respuestas 218

[pág. 219]
Finanzas - versión clara y reordenada
 retorno total incluye cupón, reinversión, roll-down y cambios no anticipados de tasa/spread.
 Depósitos renuevan a tasas futuras y tienen menor volatilidad de precio pero riesgo de reinversión.
 Elegir requiere pronóstico sobre sorpresa de tasas, duración y horizonte, no solo prever una baja
 anunciada. “La trayectoria está perfectamente incorporada” y “habrá una ganancia por cada baja
 esperada” son premisas incompatibles si por ganancia se entiende exceso inesperado.
 Qué hace sólida la respuesta: explica retorno excedente, diversificación y precio de bonos a
 través de duración; distingue retorno esperado de sorpresa y adecua la asignación al horizonte.
 enero 2022 - pregunta 6 - UF, inflación y eficiencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 362-362 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 a. Regla para una inversionista neutral al riesgo. Bajo la aproximación o tasas logarítmicas que
 admite el enunciado, el retorno nominal del bono UF es y_UF+π, frente a y_P en el bono nominal.
 Si b=y_P-y_UF es el breakeven, el retorno nominal esperado diferencial de indexar es E[π]-b. Por
 ello: indexar si la inflación esperada propia supera b; nominalizar si queda por debajo;
 indiferencia si son iguales. Se comparan instrumentos de igual horizonte y se mantienen los
 demás flujos y características; que la inflación pasada sea 7,2% no determina la inflación futura
 pertinente. No basta observar que los precios han subido para escoger UF.
 b. Aversión al riesgo medida en UF. En poder adquisitivo, el bono UF fija el retorno real y_UF,
 mientras el nominal entrega aproximadamente y_P-π, que cae cuando la inflación sorprende al
 alza. Ahora hay que comparar utilidad esperada o equivalentes ciertos, incorporando dispersión y
 riesgo de cola de inflación, aversión al riesgo y relación con otros ingresos/pasivos reales. Indexar
 puede ser preferible incluso con E[π]<b: el menor retorno medio puede pagar una protección
 valiosa. Con una aproximación media-varianza, el retorno cierto equivalente nominal en UF sería
 y_P-E[π]-(A/2)Var(π), frente a y_UF, bajo supuestos locales de la aproximación. Mayor
 incertidumbre de inflación aumenta el valor de esa protección. No se pide una cifra porque faltan
 preferencias y distribución.
 c. Eficiencia y regresión. Un breakeven incorpora expectativas y el precio de protegerse de
 inflación, además de diferencias de liquidez y otras condiciones de los bonos. Si la demanda por
 seguro de poder adquisitivo eleva el precio del bono UF y reduce su yield, el spread puede superar
 la inflación física esperada por una prima de inflación. Esas primas pueden variar en el tiempo;
 shocks futuros no anticipados también explican que inflación realizada y breakeven difieran. Un
 coeficiente pequeño o R²bajo no prueba ineficiencia: eficiencia no exige perfecta predicción de la
 inflación realizada ni que el spread sea una expectativa pura. Haría coincidir horizontes de tasas e
 inflación, consideraría primas y errores de medición y evaluaría si hay errores sistemáticos
 aprovechables después de ajustar riesgo y costos.
 Dirección Financiera
 enero 2012 - pregunta 3 - APV y escudo tributario
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 92-93 | convocatoria 1
Examen de Grado UC | materia, preguntas y respuestas 219

[pág. 220]
Finanzas - versión clara y reordenada
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 1) Enfoque de activos: FCF perpetuo = EBIT(1-T)+depreciación-reinversión
 =1.000(0,70)+250-290=$660. La inversión inicial es $4.000. Con WACC después de impuestos
 15%: VP=660/0,15=$4.400; VAN=$400. No resto intereses en FCFF porque WACC ya incorpora
 financiamiento; los $290 de reinversión son caja real necesaria para sostener perpetuidad, mientras
 $250 de depreciación se agrega de vuelta.
 2) Enfoque de accionistas: flujo de caja anual para equity = utilidad neta $532 + depreciación $250 -
 reinversión $290=$492, suponiendo que el excedente se distribuye. La inversión inicial de los
 dueños es 40%×$4.000=$1.600. El valor del equity por el enfoque de activos es $4.400-deuda
 $2.400=$2.000. Como FCFE es una perpetuidad, costo de equity implícito=492/2.000=24,60%;
 entonces VAN equity=492/0,246-1.600=$400. Es coherente con el VAN de activos. Los pesos de
 mercado son E/V=2.000/4.400 y D/V=2.400/4.400; no sustituyo automáticamente pesos de
 financiamiento inicial (40/60) por pesos de mercado.
 3) El proyecto original crea $400 con estructura óptima. El alternativo tiene VAN sin deuda=$100. Si
 usa los mismos $2.400 de deuda perpetua a 10%, el escudo anual es 2.400×10%×30%=$72;
 suponiendo capacidad tributaria y riesgo del escudo como la deuda, VP del escudo=72/0,10=$720.
 APV del alternativo=$100+$720=$820; elegiría el alternativo, que supera en $420 al valor del
 proyecto original bajo la financiación descrita. La conclusión depende de que el préstamo sea
 renovable a perpetuidad, el escudo sea utilizable y que el VAN original de $400 ya esté calculado
 con el WACC levered dado. Si el enunciado entiende la deuda como amortizable o el escudo tiene
 riesgo distinto, debe cambiarse su calendario/tasa.
 Qué haría esta respuesta distinguida: construye FCFF y FCFE sin mezclar intereses, reconcilia
 ambos VAN con valores de mercado y compara APV solo después de identificar el escudo
 incremental.
 agosto 2014 - pregunta 6 - Alternativas productivas y VAN
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 157-158 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Las cifras son M$, miles de pesos. Comparamos producir en Chile (PP) contra seguir importando
 (IM). El negocio importador es la alternativa que ya existe, por lo que no se evalúa PP contra cero.
 La tasa para los flujos residuales de la dueña es 10% anual. Los intereses son idénticos entre
 alternativas y se cancelan en la diferencia.
 1. Inversión inicial incremental. Máquina 1.500 + remodelación 200 + garantía de arriendo 400 +
 primer arriendo prepagado 400 + capital de trabajo adicional (4.200-2.000) = 4.700. El estudio de
 mercado de 1.000 ya fue encargado: su obligación de pago existe tanto al elegir PP como IM. Se
 excluye de la comparación entre ambas; si se valorase una decisión previa que pudiera evitar el
 estudio, habría que incluirlo en esa decisión diferente.
 2. De resultado contable a caja incremental. Las diferencias de utilidad neta son 3.120-2.775 =
 345, 4.065-3.750 = 315 y 5.655-4.725 = 930. Cada año se suma la depreciación adicional 500 y se
Examen de Grado UC | materia, preguntas y respuestas 220

[pág. 221]
Finanzas - versión clara y reordenada
 resta la reinversión adicional 1,2×500 = 600.
 Además, en 2015 se suma de vuelta la remodelación 200, porque el estado de resultados la
 reconoce como gasto ese año, pero su caja ya salió en t0. No se suma solo su escudo fiscal ni se
 deduce nuevamente su desembolso. El ahorro tributario de 200×25% = 50 queda contenido en la
 utilidad neta de 2015; el ajuste de 200 convierte correctamente devengamiento a caja. Así, el flujo
 antes de cambios de capital de trabajo y del ajuste temporal del arriendo es:
 Año Diferencia + Depreciación + Remodelación - Reinversión Caja incremental
 utilidad neta ya pagada
 2015 345 500 200 600 445
 2016 315 500 0 600 215
 2017 930 500 0 600 830
 3. Capital de trabajo, arriendo y venta. El CT incremental requerido al cierre de 2014, 2015, 2016
 y 2017 es 2.200, 2.400, 3.300 y 4.900. Ya se financian 2.200 en t0; las nuevas salidas son 200, 900
 y 1.600. Se respetan los saldos exigidos en el cuadro, incluidos los del último año.
 La garantía de 400 se devuelve al cierre de 2016, no al cierre del contrato. Se supone que el gasto
 anual de arriendo de 400 está incluido en GAV fijo, dado que el cuadro es un estado de resultados
 completo de PP. El arriendo de 2015 se paga en t0; en t1 se paga el de 2016 y en t2 el de 2017. Por
 tanto, el gasto anual y el pago al cierre se compensan en t1 y t2: sumar el gasto del año y restar el
 pago del siguiente da ajuste neto cero. En t3 se suma 400, porque hay gasto de arriendo de 2017
 en utilidad, pero ningún nuevo pago para 2018. Este ajuste no es una devolución en efectivo de
 un prepago remanente: convierte el gasto contable a la caja efectivamente pagada por
 adelantado.
 El valor terminal de venta del negocio en marcha, después de deuda e impuestos, es 60.000 en PP
 y 45.000 en IM: diferencia 15.000. Se supone que esa venta incluye el CT operacional transferido
 con la empresa. No se agrega otra recuperación de CT ni venta separada de la máquina: hacerlo
 contaría activos por segunda vez. Si el precio terminal no incluyera algún activo, el contrato de
 venta debería identificarlo antes de agregar su realización.
 Flujo incremental t0 2015 2016 2017
 Inversión inicial -4.700
 Caja desde 445 215 830
 resultado, ajustada
 por remodelación
 Aumento CT -200 -900 -1.600
 incremental
 Devolución garantía +400
 Gasto de arriendo +400
 sin nuevo pago al
 cierre
 Diferencia de venta +15.000
 en marcha
Examen de Grado UC | materia, preguntas y respuestas 221

[pág. 222]
Finanzas - versión clara y reordenada
 Flujo incremental t0 2015 2016 2017
 Total -4.700 245 -285 14.630
 4. Decisión. VAN = -4.700 + 245/1,10 - 285/1,10² + 14.630/1,10³ = M$6.278,925620. Conviene
 fabricar en Chile bajo estos supuestos y proyecciones. El valor terminal es decisivo: sin su
 diferencia de 15.000, el VAN sería -4.990,80 aproximadamente. La mejora se explica por flujos
 operacionales y, sobre todo, por el mayor valor del negocio al final; no por la forma de distribuir
 dividendos.
 La respuesta anterior daba t1 = 45 y VAN aproximado 6.098 porque olvidaba sumar de vuelta los
 200 de remodelación pagados en t0. Este bloque corrige esa doble deducción y explicita el
 calendario del arriendo.
 agosto 2015 - pregunta 3 - Aumento de capital y derechos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 177-178 | convocatoria
 2
 Volver al enunciado original
 Datos y relación de emisión. Antes de emitir hay 5.000 acciones y patrimonio de mercado de
 US$50.000; precio previo = US$10. Para financiar US$10.000, emisión a US$8 requiere 1.250
 acciones; a US$16, 625 acciones. Supongo que la nueva inversión tiene VAN cero o que el
 mercado valora la caja captada peso por peso, pues el enunciado no entrega VAN del proyecto. De
 otro modo, el precio ex emisión incluiría ese VAN y no puede determinarse solo con lo dado. 1.
 Todos ejercen sus derechos. Don Pepe tiene 1.000/5.000=20% de las acciones. Recibe derecho a
 comprar 20% de la emisión.
 • A US$8: compra 250 acciones por US$2.000. Patrimonio post-money=60.000; acciones=6.250;
 precio
 ex derecho=60.000/6.250=US$9,60. Don Pepe termina con 1.250 acciones, valoradas en
 US$12.000, y sin los US$2.000 de caja. Riqueza total: US$12.000, igual a antes (1.000×10+2.000).
 • A US$16: compra 125 acciones por US$2.000. Patrimonio post-money=60.000; acciones=5.625;
 precio=60.000/5.625=US$10,6667. Termina con 1.125 acciones por US$12.000 y caja cero.
 Riqueza: US$12.000. El precio de emisión cambia el número de acciones, no crea por sí solo
 riqueza si todos participan proporcionalmente y la emisión se valora justamente. 2. Don Pepe no
 tiene fondos y sus derechos no se pueden vender. En la segunda vuelta el controlador está
 dispuesto a comprar acciones sobrantes cualquiera sea el precio. Debe preferir votar por US$16:
 bajo los supuestos del caso, el comprador aporta efectivo que entra a la compañía y recibe
 acciones cuyo precio ex emisión estimado es US$10,6667; paga 16 por algo que vale
 aproximadamente 10,6667. Ese sobreprecio beneficia a los accionistas preexistentes que no
 participan, entre ellos Don Pepe. A US$8, por el contrario, el controlador adquiere acciones con
 valor ex emisión 9,60 pagando 8, capturando una transferencia; el derecho no negociable de Don
 Pepe vence sin compensación. Es una conclusión del supuesto extremo de segunda vuelta y
 demanda garantizada; si el controlador no comprara sobrevalorado, o la inversión tuviera VAN
 distinto de cero, la comparación cambia. 3 a. Naturaleza del derecho preferente. Se asemeja a una
 opción de compra de corto plazo (call) sobre las nuevas acciones: da el derecho, no la obligación,
 de comprar a un precio de suscripción fijado. Si puede transarse, el antiguo accionista puede
Examen de Grado UC | materia, preguntas y respuestas 222

[pág. 223]
Finanzas - versión clara y reordenada
 ejercerlo o venderlo; por ello se evita que una emisión bajo el valor de mercado le transfiera
 gratuitamente valor al nuevo suscriptor. 3 b. ¿Hay expropiación a precio US$8? No, por sí sola la
 emisión barata no expropia a los minoritarios si el derecho es proporcional, transferible y se negocia
 a valor justo. El precio ex derecho es 9,60. Cada acción antigua baja de 10 a 9,60, pero lleva un
 derecho cuyo valor es 0,40 por acción antigua; un bloque de cuatro derechos permite comprar una
 acción a 8 y vale 1,60 (9,60-8). Don Pepe puede vender sus 1.000 derechos por aproximadamente
 US$400: conserva acciones por US$9.600 y caja inicial US$2.000 más US$400 por derechos,
 riqueza total US$12.000. También puede ejercer y llegar al mismo valor total. La acusación sí
 podría sostenerse si se impide ejercer o vender, se asignan derechos de forma desigual, se
 manipula el precio, o hay costos/fricciones que impiden capturar su valor. Hay que distinguir dilución
 porcentual de transferencia económica. Qué hace distinguida la respuesta: calcula acciones y
 precio ex emisión, trata explícitamente la caja personal y separa el caso de derechos no
 negociables del caso de derechos transferibles, identificando cuándo sí habría transferencia de
 riqueza.
 enero 2025 - pregunta 1 - CAPM de proyecto y emisión
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 427-428 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 1. Riesgo operativo y VAN del proyecto. Trabajamos en M$ (miles de pesos). SERVIMOS no
 tiene deuda, pero su patrimonio de M$400.000 incluye M$100.000 de depósito libre de riesgo. Por
 tanto, el negocio de despacho vale M$300.000. La beta observada de 1,2 es la beta promedio de
 negocio y depósito:
 1,2=(300.000/400.000)β_despacho+(100.000/400.000)0.
 Así, β_despacho=1,6. No corresponde usar 1,2 sin eliminar la caja ni usar el beta 1,0 del patrimonio
 de EAP: el despacho tiene otro riesgo operativo. CAPM entrega k_A=8%+1,6(7,5%)=20%. La
 inversión es M$90.000 hoy y el primer flujo perpetuo de M$38.000 llega en un año. Por eso:
 VP=38.000/0,20=190.000; VAN=190.000-90.000=+100.000 M$.
 El proyecto crea valor bajo los flujos y el riesgo estimados.
 2. Emisión de acciones. Antes del anuncio, 20 millones de acciones a $20 representan $400
 millones, equivalentes a M$400.000. El anuncio incorpora el VAN de M$100.000 al valor de las
 acciones existentes. El patrimonio antes de la emisión vale M$500.000, es decir $500 millones; el
 nuevo precio es:
 P=500.000(1.000)/(20.000.000)=$25 por acción.
 La emisión debe recaudar M$45.000, equivalentes a $45 millones. Se emiten:
 N_nuevas=45.000(1.000)/25=1.800.000 acciones.
 La otra mitad se paga con caja ya perteneciente a la compañía. Esa caja tiene costo de oportunidad
 y forma parte de la inversión; no se resta otra vez del patrimonio previo al anuncio. Como control,
 después de invertir, los activos valen 500.000-45.000+190.000=645.000 M$; restando deuda de
 M$100.000, el patrimonio vale M$545.000. Los antiguos conservan 20/21,8=91,7431%, cuyo valor
Examen de Grado UC | materia, preguntas y respuestas 223

[pág. 224]
Finanzas - versión clara y reordenada
 es M$500.000; los nuevos reciben M$45.000. La dilución porcentual no destruye riqueza cuando se
 emite a precio justo.
 3. Caja más deuda. En el mercado perfecto del caso, cambiar la financiación no cambia los flujos ni
 el riesgo del activo de despacho. Su beta sigue siendo 1,6, su WACC sin impuestos sigue siendo
 20% y su VAN sigue siendo M$100.000. La nueva deuda tiene k_D=8%+0,25(7,5%)=9,875%, pero
 no se descuentan los flujos operativos a ese costo de deuda.
 Si se separa el proyecto como una unidad financiada por deuda de M$45.000, su activo económico
 vale M$190.000 y su patrimonio económico vale M$145.000. Los porcentajes de mercado son
 45.000/190.000 y 145.000/190.000; no son los porcentajes 50/50 de la inversión inicial. Con deuda
 riesgosa:
 β_E=(190.000(1,6)-45.000(0,25))/145.000=2,0198276,
 k_E=8%+2,0198276(7,5%)=23,1487069%.
 La comprobación es (145.000/190.000)23,1487069%+(45.000/190.000)9,875%=20%. El WACC de
 la empresa completa, que mezcla arriendo, caja y despacho, no es automáticamente la tasa del
 nuevo proyecto.
 enero 2018 - pregunta 3 - DuPont y alfa
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 258-259 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Reconstrucción de E-1. Ventas = 54/0,04 = 1.350; activos = 1.350/2,25 = 600. Con D/E = 1, deuda
 y patrimonio son 300 cada uno. Intereses = 300(3%) = 9; EBIT = 54+9 = 63; ROA = 10,50%; ROE =
 18%. La deuda tiene beta cero, por lo que beta equity = 1,8(1+1) = 3,6; CAPM exige k E =
 3%+3,6(5%) = 21%. La utilidad residual del negocio es 54-0,21(300) = -9.
 Reconstrucción de E-2. No se puede obtener un monto absoluto de activos con los datos
 disponibles: sea A ese monto. EBIT = 0,06 A, ventas = 2 A y utilidad neta = 0,02(2 A) = 0,04 A.
 Patrimonio = A/3 y deuda = 2 A/3 producen intereses de 0,02 A, coherentes con la utilidad indicada.
 ROE = 0,04 A/(A/3) = 12%. Beta de activos = (1/3)(1,2) = 0,4; CAPM exige a los accionistas
 3%+1,2(5%) = 9%. La utilidad residual es 0,04 A-0,09(A/3) = 0,01 A, positiva. E-2 muestra mejor
 rentabilidad económica respecto de su costo de oportunidad, pese a tener más D/E; E-1 tiene
 mayor riesgo operativo y patrimonial.
 Comprar la acción no es idéntico a aprobar la operación de la empresa. El enunciado supone
 que la información ya está incorporada en precios eficientes. Las razones anteriores diagnostican la
 operación, pero no acreditan una oportunidad de retorno anormal para quien compra ahora. El
 retorno total de una acción es (dividendo+P 1-P 0)/P 0. Bajo CAPM y precio justo, su valor presente
 neto esperado es [E(dividendo)+E(P 1)]/(1+k E)-P 0 = 0, ajustado al riesgo.
 Si además se supusiera número de acciones constante, precio de cierre igual al inicial y reparto de
 toda la utilidad, los yields 18% y 12% serían también retornos totales y chocarían con CAPM 21% y
 9%. No se deben imponer a la vez esas premisas adicionales y el equilibrio eficiente. El caso solo
 dice que se realizan transacciones para mantener monto de activos y D/E; no especifica el número
Examen de Grado UC | materia, preguntas y respuestas 224

[pág. 225]
Finanzas - versión clara y reordenada
 de acciones ni todos los flujos de esas transacciones. Para recomendar una compra a un año con
 ganancia anormal faltaría la trayectoria del precio por acción y de las transacciones. Puede
 preferirse E-2 como negocio cuya operación supera su costo de equity, pero con la información
 pública y eficiencia supuestas no se demuestra creación de riqueza por comprar una acción ya
 emitida. La selección de una inversión a precio justo depende del riesgo y cartera del comprador;
 no se conoce su preferencia.
 enero 2014 - pregunta 3 - DuPont, ROA y ROE
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 142-143 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Usamos saldos de cierre, como pide el caso. En 2008, ROE = 520/3.410 = 15,25%; en 2013,
 526/4.448 = 11,83%. La utilidad sube 1,15%, pero el patrimonio reportado aumenta 30,44%, y ROE
 cae 3,42 puntos porcentuales.
 La identidad Du Pont es ROE = (NI/S)(S/A)(A/E). Margen neto pasa de 3,85% a 4,05%; rotación de
 activos de 1,34 a 1,32; multiplicador activos/patrimonio de 2,95 a 2,21. La caída fuerte del
 multiplicador domina, mientras el margen mejora y la rotación baja poco. Usando valores sin
 redondear, el producto reproduce ambos ROE. Una atribución secuencial -primero margen, luego
 rotación, luego multiplicador- da aproximadamente +0,77; -0,23; -3,96 puntos porcentuales; las
 interacciones hacen que esa asignación dependa del orden.
 La operación mejora. EBIT/ventas pasa de 766/13.500 = 5,67% a 1.051/13.000 = 8,08%. Costo de
 ventas sigue en 75% de ventas; GAV baja de 17% a 15%; depreciación/ventas baja de 2,33% a
 1,92%. Pese a menores ventas, EBIT crece 37,21%. El resultado operativo mejora, pero gasto
 financiero sube de 137 a 175 y el impuesto reportado de 280 a 526. La tasa efectiva observada
 sube aproximadamente de 35% a 50%; no se puede inferir un cambio de ley tributaria sin notas. La
 deuda financiera explícita baja de 645+1.195+519 = 2.359 a 242+728+522 = 1.492; D financiera/E
 baja de 0,69 a 0,34. Esto es coherente con menor apalancamiento patrimonial, aunque los intereses
 no bajan en proporción: hace falta examinar tasas y composición.
 Limitación del balance original. La inspección visual de la fuente p. 143 confirma que el balance
 impreso no cuadra: en 2008 los activos 10.072 superan pasivos 4.948 + patrimonio 3.410 = 8.358
 en 1.714; en 2013 activos 9.840 superan 4.142+4.448 = 8.590 en 1.250. Esas diferencias son
 iguales a las deudas de largo plazo reportadas. Esta es una inconsistencia del original, no un error
 que deba corregirse inventando cifras. Los ROE y la identidad Du Pont anteriores usan cada saldo
 expreso; se pueden reconstruir como identidades aritméticas, pero no se debe afirmar que A/E sea
 igual a 1+D/E usando este balance inconsistente. Para una distribución completa de estructura
 financiera se debe obtener una corrección autorizada del balance. La caída del ROE no demuestra
 por sí sola deterioro operativo ni menor rendimiento ajustado por riesgo.
 enero 2015 - pregunta 3 - FCF, perpetuidad y financiamiento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 164-165 | convocatoria
 1
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 225

[pág. 226]
Finanzas - versión clara y reordenada
 RESOLUCIÓN / RESPUESTA MODELO PROPUESTA PARA ESTUDIO (no oficial)
 Inversión inicial3.000; EBIT640; depreciación500; reinversión anual438; impuesto30%; WACC15%.
 Se supone continuidad perpetua y primer flujo en t=1.
 1. VAN del activo. FCFF=640(1-0,30)+500-438=510. VAN=-3.000+510/0,15=400. Los intereses no
 se restan del FCFF: la tasa WACC recoge la remuneración del financiamiento.
 2. Intereses no deducibles. El impuesto operativo es640×30%=192.
 FCFF=640-192+500-438=510. Con el WACC que el apartado fija explícitamente en15%, VAN=400,
 por lo que se acepta. Eliminar el escudo de intereses no cambia este FCFF antes de
 financiamiento; normalmente puede cambiar la tasa compatible, pero aquí el enunciado la
 mantiene. No se suma un escudo que no existe.
 3. Participación máxima del socio:35%. El aporte de1.200 sí pertenece al patrimonio posterior a
 la emisión. El valor pre-money de los antiguos incorporando el excedente del proyecto
 es2.400+400=2.800; el valor post-money del patrimonio total es2.800+1.200=4.000.
 Comprobación desde los activos: Vnuevo=6.000+3.000+400=9.400; Dnuevo=3.600+1.800=5.400;
 Epost=9.400-5.400=4.000.
 La alternativa de deuda total deja a los actuales accionistas Ealternativa=2.400+200=2.600. Si el
 socio recibe x, los antiguos conservan (1-x)×4.000. Indiferencia: (1-x)4.000=2.600; x=35% máximo.
 Con30% conservarían2.800 y con35% conservarían2.600. El socio aporta1.200 y a35% recibe una
 participación valorada en1.400; su ganancia de200 consume parte del mayor VAN de la alternativa
 con socio. A precio justo, sin compartir excedente,1.200/4.000=30%.
 Corrección verificada contra el enunciado, pp.164-165. La versión anterior omitía el aporte
 nuevo del valor post-money y daba7,14%; ese cálculo era incorrecto. La regla general es
 Epost=Eprevio+aporte equity nuevo+VAN, cuando VAN ya descuenta toda la inversión y la deuda
 se emite a valor justo. El aporte añade recursos; no es por sí solo creación de valor.
 enero 2016 - pregunta 3 - FER
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 189-190 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Todas las cifras siguientes son pesos, como en el enunciado; no se cambia implícitamente a miles.
 1) FER de 2016. Ventas aumentan 200.000. CxC y existencias aumentan 20%×200.000 = 40.000;
 el terreno exige 172.000 y caja se mantiene 5.000. Aumento total de activos = 212.000.
 Proveedores aumentan 15%×200.000 = 30.000. Utilidad neta = 15%×1.200.000 = 180.000;
 dividendos = 63%×180.000 = 113.400; retención = 66.600. FER = 212.000-30.000-66.600 =
 115.400.
 2) Financiamiento permanente 2016-2019. Se acumulan los déficits y se resta el superávit,
 tomando como base el balance existente:
Examen de Grado UC | materia, preguntas y respuestas 226

[pág. 227]
Finanzas - versión clara y reordenada
 Cierre Requerimiento anual Necesidad externa Parte transitoria sobre
 acumulada 100.000
 2016 115.400 115.400 15.400
 2017 80.000 195.400 95.400
 2018 -95.400 100.000 0
 2019 120.000 220.000 120.000
 El financiamiento permanente nuevo es 100.000, el piso que nunca se libera durante el horizonte.
 Los 220.000 son el requerimiento acumulado del último año, no el piso permanente. Lo restante se
 financia transitoriamente bajo el principio de calce del ejercicio.
 3) Fuentes de 2016 y balance. Activos finales: caja 5.000, CxC 120.000, inventario 120.000,
 terrenos 295.000+172.000 = 467.000; total 712.000. Como pasivos/patrimonio = 1, ambos deben
 valer 356.000. Proveedores son 180.000. Patrimonio antes del nuevo aporte =
 50.000+200.000+66.600 = 316.600; por tanto, aporte nuevo = 39.400. Para calzar el requerimiento
 transitorio, la deuda bancaria CP nueva es 15.400. La financiación permanente nueva debe sumar
 100.000: nueva deuda LP = 100.000-39.400 = 60.600.
 Pasivos y patrimonio al 31/12/2016 Pesos
 Proveedores 180.000
 Deuda bancaria CP nueva 15.400
 Deuda bancaria LP antigua 100.000
 Deuda bancaria LP nueva 60.600
 Total pasivos 356.000
 Capital antiguo + aporte 89.400
 Utilidades retenidas finales 266.600
 Total patrimonio 356.000
 Total pasivos + patrimonio 712.000
 Fuentes externas nuevas = 15.400+60.600+39.400 = 115.400, igual al FER. Se cumplen
 simultáneamente caja mínima 5.000, reparto 63%, endeudamiento uno y calce entre fondos
 permanentes y transitorios. Financiar todo con nueva deuda LP 76.000 cumple el ratio contable,
 pero incumple el calce requerido para la parte transitoria.
 marzo 2011 - pregunta 3 - Flujo de caja incremental y VAN
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 62-63 | convocatoria 1
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 227

[pág. 228]
Finanzas - versión clara y reordenada
 Respuesta modelo propuesta para estudio (no oficial)
 Las cifras son millones de pesos. Desarrollo una solución íntegra declarando cómo se tratan
 inflación, bases tributarias y costo de evaluación. La convención principal expresa los flujos en
 moneda de hoy y ajusta monetariamente las bases tributarias dadas en esa moneda. Por Fisher,
 tasa real = 1,134/1,05-1 = 8%. Los ingresos reales anuales son 147/1,05 = 140; personal 32, costos
 variables 18 y costos fijos específicos 10 suman 60 reales por año. Los otros 10 de casa matriz no
 cambian con el proyecto y se excluyen. Personal no es 35.
 La arquitectura de 10 ya fue incurrida y existe la obligación de pagarla aun sin emprender el
 proyecto: no es incremental. La bodega tiene costo de oportunidad 90 netos hoy; que esté
 depreciada no elimina ese costo. La remodelación cuesta 72 hoy y genera una deducción tributaria
 completa al cierre del primer año. El equipo cuesta 42, con valor residual contable 6 y depreciación
 real anual (42-6)/3 = 12.
 Capital de trabajo al cierre del año t = 5% de las ventas nominales del año t+1. Por tanto, CT
 nominal es 7,35 en t0, 7,7175 en t1 y 8,103375 en t2; dividido por 1,05^t, es 7,35 real en cada
 fecha. Se recupera 7,35 real al terminar el proyecto. No se incluye el gasto asignado de casa matriz
 ni se vuelve a agregar depreciación a una caja que ya la excluye.
 Flujo en moneda de t0 t1 t2 t3
 hoy
 Costo oportunidad -90
 bodega
 Remodelación y -114
 equipo
 CT inicial / -7,35 0 0 +7,35
 recuperación
 Caja operacional 81 63 63
 después de impuesto
 Venta equipo 12
 después de impuesto
 Venta bodega 22,5
 después de impuesto
 Flujo total -211,35 81 63 104,85
 Caja ordinaria = (140-60)(1-0,25)+12×0,25 = 63. En t1 se agrega escudo de remodelación 72×25%
 = 18; la empresa tiene utilidades suficientes para usarlo incluso si el proyecto presenta una pérdida
 tributaria ese año. Venta de equipo: 14-(14-6)×25% = 12. Bodega depreciada y remodelación
 llevada a gasto: 30×(1-25%) = 22,5. VAN de emprender, una vez tomada la decisión de estudiar =
 -211,35+81/1,08+63/1,08²+104,85/1,08³ = +0,895656. Es marginalmente conveniente bajo esta
 convención, con alta sensibilidad a supuestos.
 El honorario de evaluación de 2 se paga hoy para evaluar el proyecto, tanto si se aprueba como si
 se rechaza; por ello no cambia la decisión posterior de emprender. Si se evalúa la decisión previa
 conjunta «contratar el estudio y realizar el proyecto», se incluye: inversión 213,35 y VAN -1,104344.
 El enunciado permite explicitar supuestos; debe indicarse qué decisión se valora en vez de excluir
 el monto sin mostrar su efecto.
Examen de Grado UC | materia, preguntas y respuestas 228

[pág. 229]
Finanzas - versión clara y reordenada
 Convención tributaria alternativa completa. Si las bases fiscales no se reajustan por inflación, la
 depreciación es 12 nominal anual y la remodelación se deduce por 72 nominal en t1. Manteniendo
 los flujos operativos reales, CT y recuperación final especificados, los flujos nominales son -211,35;
 83,6325; 68,764125; 120,667669. El terminal incluye equipo vendido por 14×1,05³ con base libro 6
 nominal, bodega por 30×1,05³ con base cero y CT recuperado 7,35×1,05³. Descontados al 13,4%
 arrojan VAN -1,379940, o -3,379940 incluyendo el estudio. Esta diferencia proviene de la
 convención de base fiscal; debe aclararse antes de presentar una aprobación categórica. En
 cualquier convención, la respuesta ya contiene todos los flujos y su cálculo, sin aplazar la
 evaluación a otra fuente.
 enero 2019 - pregunta 6 - Flujo incremental y financiamiento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 287-288 | convocatoria
 1
 Volver al enunciado original
 RESOLUCIÓN / RESPUESTA MODELO PROPUESTA PARA ESTUDIO (no oficial)
 Todas las cifras están en M$. Se compara empresa con nuevo local menos sin nuevo local.
 Inversión inicial=2.900+100 de CTNO=3.000. Incremento EBIT=2.000-1.200=800; impuesto
 incremental=200; incremento depreciación100; reinversión incremental=800-600=200. Por tanto,
 ΔFCFF=800(0,75)+100-200=500 anuales perpetuos.
 1. Conveniencia. VAN=-3.000+500/0,10=2.000. Se acepta el local. El asesor de500 ya contratado
 para evaluar se paga cualquiera sea la decisión: es no incremental entre ejecutar/no ejecutar. Se
 excluye del VAN de aceptar el local. Si el contrato todavía fuese evitable únicamente al no ejecutar,
 se incluiría y el VAN sería1.500; esa es otra hipótesis.
 2. Participación máxima de nueva socia:33,33%. Con equity nuevo, el valor patrimonial posterior
 es Epost=4.000+1.500 de aporte nuevo+2.000 de VAN=7.500. El uso de la caja propia1.500 ya está
 contabilizado en la inversión inicial3.000 que se resta al calcular VAN; no se descuenta dos veces.
 Comprobación desde activos:8.000-1.500 de caja usada+5.000 de valor del proyecto=11.500;
 menos deuda vigente4.000 da Epost7.500.
 Con banco, VAN=-3.000+500/0,125=1.000. Como el enunciado preserva el valor previo del
 negocio, el patrimonio de los antiguos resulta4.000+1.000=5.000. Comprobación:
 activos8.000-1.500+4.000=10.500; deuda4.000+1.500=5.500; equity5.000.
 Los antiguos comparan (1-p)7.500 con5.000. Máximo p=1-5.000/7.500=33,33%. A precio justo,
 aporte1.500/7.500=20%. Existe un intervalo de negociación20%-33,33% bajo los supuestos del
 caso: al20% los antiguos retienen6.000; al33,33% retienen5.000 y la socia recibe una participación
 valorada en2.500 por aportar1.500. El mayor excedente de la alternativa equity permite repartir
 parte del valor y seguir siendo preferible al banco.
 Corrección contra pp.287-288. El anterior post-money6.000, máximo16,67% y conclusión de
 ausencia de acuerdo omitían el aporte nuevo de1.500. Una emisión justa no crea VAN por sí
 misma, pero incrementa el patrimonio total porque entran recursos. Distingue ese aumento del valor
 retenido por los antiguos.
 marzo 2009 - pregunta 3 - Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 6-7 | convocatoria 1
Examen de Grado UC | materia, preguntas y respuestas 229

[pág. 230]
Finanzas - versión clara y reordenada
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 La pregunta pide evaluar por separado tres criterios para aprobar un crédito de 30 días. El Gerente
 General calcula ratios correctamente bajo la definición dada: corriente inicial (150/50=3); tras recibir
 el préstamo, caja sube 27 y deuda corriente 27, por lo que (177/77=2,30). Prueba ácida inicial
 ((150-25)/50=2,50); posterior ((177-25)/77=1,97), aproximadamente 2,0. Eso muestra cobertura
 contable, pero no prueba pago oportuno: parte del corriente son $39.000 por cobrar al dueño,
 anticipos de arriendo y dividendos de filial, no caja libre; existencias pueden
 deteriorarse/obsolescer. Recomiendo revisar calidad, vencimientos, concentración y flujo de caja de
 30 días antes de aprobar.
 El Gerente de Crédito acierta en que los ratios son stocks y debe analizarse caja/tiempo, pero su
 razón pasivos vencidos/ventas no mide capacidad de pago. Ventas no son cobros ni flujo
 disponible: hay costos, impuestos, capital de trabajo y desfase de cobranza. Debe proyectar cobros
 por fecha y probabilidad, pagos operativos/deuda/impuestos, caja inicial disponible y línea
 comprometida, y probar escenarios. El saldo $39.000 del accionista requiere confirmar
 cobro/relación y no asumirlo como liquidez.
 El Gerente de Riesgo compara rentabilidad anualizada con tasa de interés y mezcla
 riesgo/rentabilidad de largo plazo con liquidez de 30 días. La utilidad neta no equivale a caja y
 anualizar nueve meses supone estacionalidad lineal; dividir utilidad por activos de cierre mezcla
 flujo y stock, además de ser ROA aproximado, no rendimiento del crédito. Que 6% sea menor a 8%
 tampoco prueba incapacidad de pagar un préstamo breve: el principal se paga desde
 caja/financiamiento y la tasa se aplica al monto/plazo. La recomendación prudente es condicional a
 flujo de caja verificable, calidad de cuentas por cobrar e inventario, garantía, covenants y fuente de
 repago. Ningún ratio aislado decide.
 Qué haría esta respuesta distinguida: calcula el cambio correcto en ratios, separa liquidez,
 solvencia y rentabilidad, identifica activos de calidad dudosa y propone una prueba directa de
 repago con calendario y escenarios.
 agosto 2009 - pregunta 3 - Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 19-20 | convocatoria 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Las cifras son millones de pesos. Debe compararse el costo de prestar el mismo servicio
 indefinidamente, incluyendo la diferencia de fechas de todos los reemplazos, no solo la primera
 compra.
 El factor de anualidad de cinco años al 12% es a_5 = [1-1,12^-5]/0,12 = 3,604776. Una turbina
 diésel nueva cuesta 24 y requiere egresos anuales de 38 ya netos de impuestos. Su costo anual
 equivalente es CAE_D = 38+24/a_5 = 44,657834; su costo de servicio perpetuo es 44,657834/0,12
 = 372,148613.
 El aerogenerador cuesta 60. Depreciación anual = 60/6 = 10. Su costo de operación neto es
 35(1-0,20)-10×0,20 = 26. Al venderlo tras cinco años, su valor libro es 10; el precio neto de
 impuesto es 15-(15-10)×0,20 = 14. CAE_E = 26+[60-14/1,12^5]/a_5 = 40,440848. El costo de
Examen de Grado UC | materia, preguntas y respuestas 230

[pág. 231]
Finanzas - versión clara y reordenada
 servicio eólico perpetuo al comenzar cada cadena de reemplazos es C_E = CAE_E/0,12 =
 337,007064.
 La turbina existente fue comprada hace tres años y puede operar dos años más por 38 anual. Su
 compra es hundida, pero disponer de dos años restantes evita comprar de inmediato.
 Alternativa Expresión del costo presente Millones
 Eólico desde hoy C_E 337,007064
 Diésel existente dos años y luego 38a_2+C_E/1,12² 332,881907
 eólico
 Diésel existente dos años y luego 38a_2+(CAE_D/0,12)/1,12² 360,896535
 turbinas nuevas
 Aquí a_2 = [1-1,12^-2]/0,12 = 1,690051. La opción de esperar dos años y pasar entonces a
 eólico minimiza el costo. Frente a cambiar hoy ahorra 4,125157 de valor presente; frente a
 mantener diésel perpetuo ahorra 28,014628. Aunque el eólico nuevo es mejor que el diésel nuevo,
 su CAE de 40,44 es mayor que los 38 de usar la turbina ya disponible durante esos dos años.
 Una sensibilidad tributaria adicional: si la turbina antigua se deprecia en cinco años, queda valor
 libro 24×2/5 = 9,6; retirarla hoy a precio cero generaría deducción de 9,6 y ahorro 1,92. Con la regla
 del enunciado de flujos tributarios al cierre del año, el costo de cambiar hoy sería
 337,007064-1,92/1,12 = 335,292778; todavía es superior a esperar. Esta sensibilidad no debe
 contarse nuevamente si los 38 del ejercicio ya incorporasen ese efecto de retiro, y no es necesaria
 para concluir.
 No es válido comparar únicamente ahorros operativos de dos años con el adelanto de una compra
 de 60: eso omite que también se adelantan todas las compras, ventas y ciclos eólicos posteriores.
 marzo 2010 - pregunta 3 - Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 35-36 | convocatoria 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Se usa TIR, como exige el enunciado, distinguiendo tres decisiones: escala inicial, fecha de venta y
 precio de adquisición posterior. No se supone que puedan repetirse estos proyectos; el ejercicio
 dice expresamente que no hay otros proyectos disponibles.
 Las TIR promedio desde hoy hasta una venta en el año n son (P_n/I_0)^(1/n)-1:
 Año de venta Proyecto 1 Proyecto 2
 1 10,00% 9,40%
 2 9,55% 9,05%
 3 9,13% 8,63%
 4 8,77% 8,27%
 5 8,48% 7,92%
Examen de Grado UC | materia, preguntas y respuestas 231

[pág. 232]
Finanzas - versión clara y reordenada
 Escoger el mayor porcentaje promedio, 10% del proyecto 1 a un año, omite el rendimiento de
 invertir más y el de mantener el terreno un año adicional.
 1.a) Proyecto recomendado: 2. Para comparar las dos escalas con venta en un año, el flujo
 incremental de elegir 2 en vez de 1 es -20.000 hoy y +(54.700-33.000) = 21.700 en un año. Su TIR
 incremental es 8,50%, superior al costo de oportunidad 8%; la inversión adicional está justificada.
 La elección se comprueba también usando las fechas de venta óptimas que se obtienen a
 continuación. El proyecto 1 se vendería en el año 3 por 38.991,20; en un mercado perfecto, el
 equivalente de ese cobro en el año 2 es 38.991,20/1,08 = 36.102,96. Comparado con el proyecto 2
 vendido en el año 2 por 59.458,90, el flujo incremental equivalente es -20.000 hoy y +23.355,94 en
 el año 2. TIR incremental = (23.355,94/20.000)^0,5-1 = 8,06% > 8%. El proyecto 2 sigue siendo
 preferible. La conversión de fecha usa la alternativa financiera explícita del mercado perfecto; no se
 compara una TIR de distinto plazo como si todas las ventas fueran en la misma fecha.
 1.b) Venta recomendada: al final del año 2. Para decidir esperar un año más, se renuncia al
 precio P_n que se podría recibir hoy y se obtiene P_(n+1) al año siguiente. La TIR marginal de
 esperar es P_(n+1)/P_n-1:
 Intervalo Proyecto 1 Proyecto 2
 1→2 9,10% 8,70%
 2→3 8,30% 7,80%
 3→4 7,70% 7,20%
 4→5 7,30% 6,50%
 En el proyecto 2 conviene esperar desde el año 1 al 2 porque 8,70%>8%; no conviene esperar
 desde el 2 al 3 porque 7,80%<8%, y los retornos posteriores son todavía menores. Se vende al año
 2. Para el proyecto 1, la fecha óptima sería año 3. La TIR promedio más alta del año 1 no determina
 la fecha óptima de una inversión no repetible.
 2) Precio máximo de la constructora. Compra las 15 hectáreas del proyecto 2 al final del año 2.
 Suponiendo que los precios futuros entregados siguen disponibles para ella, y que no hay
 beneficios propios de construcción ni costos adicionales, sus valores máximos según venta en los
 años 3, 4 y 5 son 64.096,70/1,08 = 59.348,80; 68.711,70/1,08² = 58.909,21; 73.177,96/1,08³ =
 58.091,02. El máximo es 59.348,80 en la fecha de la licitación, con venta un año después. A ese
 precio la TIR es exactamente 8%; para aumentar estrictamente su riqueza debe ofertar menos que
 ese techo. El precio esperado de DISA de 59.458,90 supera ese techo bajo estas oportunidades. Si
 la constructora desarrollara un negocio distinto en el terreno, se necesitarían sus propios flujos:
 esos no están informados.
 agosto 2010 - pregunta 3 - Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 50-51 | convocatoria 2
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 232

[pág. 233]
Finanzas - versión clara y reordenada
 Respuesta modelo propuesta para estudio (no oficial)
 1) Eficiencia operacional. No concuerdo con usar ROE para concluir que A opera mejor. A genera
 EBIT/activos = 210.000/1.050.000 = 20,00%; B genera 360.000/1.500.000 = 24,00%. Ambas rotan
 activos dos veces al año, pero el margen operacional es 10% en A y 12% en B. La mayor
 rentabilidad operacional de B viene de ese margen.
 2) Origen de la diferencia de ROE. Los patrimonios son 420.000 y 937.500. ROE_A =
 136.998/420.000 = 32,62% y ROE_B = 287.509/937.500 = 30,67%. DuPont separa margen neto,
 rotación de activos y multiplicador patrimonial:
 Componente A B
 Margen bruto 35,00% 36,00%
 GAV / ventas 25,00% 24,00%
 Margen operacional 10,00% 12,00%
 Intereses / ventas 2,75% 1,35%
 Margen neto 6,52% 9,58%
 Rotación activos 2,00 2,00
 Activos / patrimonio 2,50 1,60
 Así, A: 6,523714%×2×2,5 = 32,618571%; B: 9,583633%×2×1,6 = 30,667627%. B tiene mejor
 margen antes y después de intereses; A compensa con mayor apalancamiento. La tasa de
 impuesto es 10% en ambas. Sobre deuda bancaria de largo plazo, sus costos son 57.780/540.000
 = 10,70% y 40.545/382.500 = 10,60%. Incluyendo proveedores sin interés, el costo financiero medio
 sobre pasivos totales es 9,171429% en A y 7,208000% en B, y D/E es 1,50 y 0,60. Se comprueba la
 identidad ROE = [ROA+(ROA-costo medio pasivos)D/E](1-T): A obtiene 18,00% operativo neto más
 14,62 puntos de palanca; B, 21,60% más 9,07. El beta de activos mayor de A (1,2 versus 0,8)
 tampoco es evidencia de mayor eficiencia: indica mayor riesgo sistemático operacional.
 3) Pago en 30 días. Siguiendo los indicadores de rotación explícitos del ejercicio, CxC rota 8 veces
 en ambas: DSO = 360/8 = 45 días. De las cuentas existentes se cobran A: 45.000×30/45 = 30.000;
 B: 225.000×30/45 = 150.000. CxP rota 12 en A y 6 en B: plazos de pago 30 y 60 días. A debe pagar
 sus 90.000 de proveedores; B paga aproximadamente 180.000×30/60 = 90.000. No hay caja en el
 balance ni nuevos recursos autorizados para este análisis. A presenta faltante de 60.000, mientras
 B tiene excedente de 60.000. La razón corriente idéntica de 1,5 no implica la misma capacidad de
 pago; las pruebas ácidas son 0,50 y 1,25.
 Inconsistencia aritmética del original. Las rotaciones entregadas no coinciden con las calculadas
 a partir de las ventas, costos y saldos impresos: por ejemplo, ventas/CxC de A = 46,67, no 8. Se
 han usado los indicadores explícitos para el calendario pedido en 3 y los estados impresos para
 1-2. No se afirma a la vez que compras = costo de ventas y que compras/CxP tiene la rotación
 entregada, pues esas cifras son incompatibles. Es una contradicción concreta de datos, no una
 objeción genérica a la contabilidad. Bajo una interpretación diferente del dato de rotación se debe
 reconstruir el calendario, sin corregir el original silenciosamente.
Examen de Grado UC | materia, preguntas y respuestas 233

[pág. 234]
Finanzas - versión clara y reordenada
 agosto 2024 - pregunta 4 - Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 421-422 | convocatoria
 2
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 1. Oferta anual máxima por la concesión. La planta genera flujo operativo neto anual perpetuo de
 (60.000-50.000=10.000), con primer pago al fin de 2025 y tasa 10%. Valor presente de los flujos
 operativos a 1-1-2025: (10.000/0,10=100.000). Menos inversión inicial de 50.000, queda excedente
 de valor 50.000 para pagar concesión. Si la renta anual constante (L) se paga cada fin de año a
 perpetuidad, (VP(L)=L/0,10). Indiferencia: (100.000-50.000-L/0,10=0), así que (L_max=5.000) por
 año. Sin impuestos; la renta se trata como pago fijo de concesión y el horizonte perpetuo empieza
 con el flujo al fin de año 1.
 2. Valor de la opción de aplazar la construcción. Comparo el VAN operativo (antes de renta
 anual, que se paga igual bajo todas las fechas y por tanto se cancela al comparar) en la fecha inicial
 y lo traigo a 1-1-2025. Si opera desde 2025, valor de la perpetuidad neta (=10.000/0,10=100.000),
 menos inversión 50.000: VAN 50.000. Si posterga a 2026, flujo anual neto perpetuo
 (=61.800-51.000=10.800); valor al inicio de 2026 (=108.000-50.000=58.000); VP hoy
 (=58.000/1,10=52.727,27). Si elige 2027, neto anual (=61.800(1,045)-51.000(1,05)=11.031); VAN al
 inicio 2027 (=110.310-50.000=60.310), VP hoy (=49.842,98). En 2028, neto perpetuo
 (=61.800(1,045)(1,04)-51.000(1,05)(1,06)=10.401,24); VAN al inicio 2028 (=54.012,40), VP hoy
 (=40.580,32). La mejor fecha es 2026: esperar un año eleva el valor en
 (52.727,27-50.000=2.727,27). Ese es el pago adicional único máximo hoy por la opción de elegir la
 fecha, bajo la hipótesis de que la renta base de 5.000 continúa pagándose en las fechas previstas
 incluso durante la espera. El valor opcional no es el VAN total del proyecto diferido: se resta el valor
 de la mejor alternativa sin opción.
 3. Renta anual total equivalente. Un pago adicional único de 2.727,27 hoy equivale a una renta
 perpetua adicional (A) con (A/0,10=2.727,27), es decir (A=272,73) al año. La renta anual total
 máxima sería (5.000+272,73=5.272,73) al fin de cada año. Si el contrato eximiera la renta durante
 la espera, el valor de la opción cambiaría; el cálculo sigue la condición del enunciado de pagar la
 renta base desde fin de 2025.
 Qué hace sólida la respuesta: compara fechas con flujos y descuento consistentes, separa el
 valor de operación de la renta, y calcula la opción como valor incremental contra construir de
 inmediato.
 agosto 2025 - pregunta 4 - Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 445-446 | convocatoria
 2
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 234

[pág. 235]
Finanzas - versión clara y reordenada
 Respuesta modelo propuesta para estudio (no oficial)
 1. VAN desde las dueñas. El original dice depreciación anual US$625 tanto en el dato inicial como
 en la explicación de reinversión. La inversión accionaria inicial es US$8.400; el banco aporta
 US$5.600. El FCFF anual es 2.500(1-0,20)+625-725=1.900. El WACC después de impuestos es
 15,079%, por lo que el valor del activo del proyecto es:
 V=1.900/0,15079=12.600,30506.
 La deuda perpetua emitida a condiciones de mercado vale US$5.600; el patrimonio económico vale
 E=12.600,30506-5.600=7.000,30506. No se deben usar 40% y 60% como pesos de mercado: esos
 porcentajes describen los aportes iniciales, pero el proyecto tiene VAN distinto de cero.
 El interés anual es 5.600(6%)=336, la utilidad neta es 1.731,2 y el dividendo o flujo residual anual
 es:
 FCFE=1.731,2+625-725=1.631,2.
 Para una perpetuidad coherente con el valor de patrimonio obtenido,
 k_E=1.631,2/7.000,30506=23,30184165%, aproximadamente 23,30%. También se obtiene
 despejando el WACC con los pesos económicos D/V=5.600/12.600,30506 y
 E/V=7.000,30506/12.600,30506. Así:
 VAN_dueñas=1.631,2/0,2330184165-8.400=-1.399,69494 US$.
 El proyecto destruye US$1.399,69 y no conviene bajo los datos dados. Coincide con el VAN de
 activos 12.600,30506-14.000, como exige que la deuda se contrate a precio de mercado.
 2. Riesgo operativo. Concuerdo con el ejecutivo 1 bajo la comparación del enunciado, que
 mantiene lo demás idéntico. Con mayor proporción de costos fijos y, para un mismo nivel esperado
 de costos totales, menor costo variable marginal, la contribución de una variación de ventas al EBIT
 es mayor; aumenta la sensibilidad operacional y puede aumentar el riesgo sistemático del activo.
 Que ambos tengan igual riesgo financiero no iguala el riesgo del negocio. El ejecutivo 2 confunde
 que el costo fijo no fluctúa con que la utilidad no fluctúe: ingresos inciertos menos compromisos fijos
 pueden producir resultados muy sensibles. Fuera de la premisa de comparabilidad, la proporción de
 costos fijos aislada no determina un WACC numérico.
 3. Variación de VAN por la deuda subsidiada. Aquí el enunciado ordena mantener tanto WACC
 como rendimiento exigido por las dueñas. El nuevo interés es 5.600(3%)=168, frente a 336 antes. El
 ahorro antes de impuestos es 168, pero al haber menos deducción por intereses se pagan
 168(20%)=33,6 de impuesto adicional. El aumento de FCFE anual es 168(1-0,20)=134,4. Como
 k_E no cambia por supuesto expreso:
 Δ VAN=134,4/0,2330184165=+576,77845 US$.
 El nuevo FCFE es 1.631,2+134,4=1.765,6; el nuevo VAN para las dueñas es
 -1.399,69494+576,77845=-822,91649 US$, aproximadamente -US$822,92. El subsidio mejora el
 VAN, pero no lo hace positivo. En esta parte se usa la condición especial de tasas constantes del
 examen; no se sustituye por una discusión genérica de APV ni se vuelve a cobrar la inversión.
 enero 2026 - pregunta 2 - Flujos/VAN/TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 454-455 | convocatoria
 1
Examen de Grado UC | materia, preguntas y respuestas 235

[pág. 236]
Finanzas - versión clara y reordenada
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 1. Flujos y VAN. El terreno sacrifica una venta actual neta de impuestos de MUSD 20.000, aunque
 su costo histórico haya sido 12.000. La inversión relevante hoy es 20.000+15.000+1.000 = 36.000
 MUSD. El estudio vial ya realizado de 200 es hundido. La depreciación anual es 15.000/15 = 1.000.
 En el año 1: EBIT = 14.000-9.500-1.200-1.000 = 2.300; impuesto = 2.300(27%) = 621; NOPAT =
 1.679; al agregar depreciación, FCFF operativo = 2.679. El incremento de capital de trabajo de 20 al
 final del año 1 deja F 1 = 2.659.
 El original dice explícitamente que de los años 2 a 15 crecen al 2% los flujos netos que se
 obtuvieron para el año 1. Así, Ft = 2.659(1,02)^(t-1). No se interpreta el crecimiento solo sobre
 2.679 para luego deducir 20 una única vez: es otra serie diferente.
 VP operación = 2.659/(0,06-0,02) × [1-(1,02/1,06)^15] = 29.143,71464.
 En t=15 se reciben 30.000 del terreno netos de impuestos y 1.000 del capital de trabajo inicial. El
 resto del capital de trabajo acumulado se utiliza exactamente para desmantelamiento y limpieza;
 por premisa no genera caja ni impuesto adicional. Por tanto, VP terminal = 31.000/(1,06)^15 =
 12.935,21688 y VAN = -36.000+29.143,71464+12.935,21688 = +6.078,93152 MUSD. El proyecto
 crea valor bajo la tasa 6% supuesta.
 2. Terreno. Discrepo con el ejecutivo: la compra histórica es hundida, pero la venta actual
 disponible de 20.000 es un costo de oportunidad. Usar un activo propio no elimina el valor de la
 alternativa que se sacrifica.
 3.1. Riesgo supuesto por el WACC. La aplicación del WACC chileno presupone riesgo operativo
 comparable, estructura financiera compatible con esa estimación y consistencia entre tasa en USD
 después de impuestos y flujos en USD.
 3.2. Ajustes. Si el supermercado peruano es más sensible al ciclo económico, estimaría el costo de
 activos con comparables del negocio y exposición pertinente; desapalancaría sus betas y
 reapalancaría a la estructura objetivo del proyecto. Incorporaría riesgos de país, moneda y
 regulación en flujos o tasa según supuestos explícitos, sin duplicarlos. Un crédito hipotecario más
 barato no determina el riesgo del activo ni permite descontar todo el proyecto al interés de esa
 deuda. Revaluaría márgenes, demanda y escenarios en Perú y recomputaría el VAN con tasa y
 moneda coherentes.
 enero 2022 - pregunta 3 - Leasing/arriendo y equivalencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 358-358 | convocatoria
 1
 Volver al enunciado original
 Respuesta modelo propuesta para estudio (no oficial)
 Al comenzar t=0 ya se instalaron tres de los nueve paneles comprados ayer y quedan seis en
 bodega. El pedido antiguo es hundido. Arrendar cuatro por cinco años no consume los paneles y no
 afecta ventas; el costo relevante es adelantar el próximo pedido de nueve unidades.
 Sin arriendo: en t=0 quedan 6; en t=3 se instalan 3 y quedan 3; en t=6 se instalan los otros 3 y
 quedan 0. La compra no hace falta en t=6, porque los tres que se necesitan aún están disponibles.
Examen de Grado UC | materia, preguntas y respuestas 236

# Manual de Finanzas · parte 2 (páginas 65-127)

Fuente: 02_MANUAL_ULTIMATE_FINANZAS_EDG_2027_V2_FORMULAS_CLARAS

[pág. 65]
Finanzas - versión clara y reordenada
 Valoración de empresas: FCFF, FCFE, múltiplos y consistencia
 El FCFF es caja para todos los proveedores de capital después de operar e invertir; se descuenta al
 WACC y produce valor de operaciones. El FCFE es caja residual para accionistas después de
 deuda neta y se descuenta a costo de equity. Un modelo DCF requiere proyección explícita, valor
 terminal, tasa consistente y puente desde valor de operaciones hasta patrimonio (deuda, caja,
 activos no operacionales, minoritarios y otros derechos). Las definiciones de deuda y caja deben
 corresponder al flujo calculado.
 Para crecimiento estable desde el periodo (n+1), valor terminal al final de (n):
 (TV_n=FCF_n+1/(r-g)), con (r>g). El flujo terminal debe representar una empresa en estado
 sostenible: inversión de mantenimiento y capital de trabajo suficientes, margen normalizado y
 crecimiento financiable. Si el crecimiento perpetuo excede la tasa de largo plazo del mercado sin
 explicación, el valor terminal queda inflado. Reporta cuánto del valor proviene del terminal y
 sensibilidad a (r) y (g).
 Múltiplos comparan precio o valor con una métrica (por ejemplo EV/EBITDA o P/U). Son rápidos y
 reflejan precios transados; no eliminan necesidad de comprender crecimiento, riesgo, contabilidad,
 ciclo, deuda ni comparabilidad. EV/EBITDA se compara con valor de empresa y una métrica antes
 de intereses; P/U con valor patrimonial y utilidad atribuible al accionista. Un múltiplo mayor puede
 reflejar crecimiento/riesgo distintos o precio excesivo; no implica causalmente mayor valor. Usa
 pares razonables, normaliza eventos, y triangula con DCF. La corrección docente local de 2025
 insiste en contestar el mecanismo pedido y no inferir mecánicamente que una emisión o un
 proyecto positivo reduce siempre el múltiplo.
 Arrendamientos, deuda y estructura de capital
 La decisión entre arrendar y comprar compara flujos equivalentes: desembolso inicial, pagos,
 impuestos, depreciación, valor residual, mantenimiento, restricciones, flexibilidad y costo de
 financiamiento. Bajo normas contables actuales, el reconocimiento puede diferir del tratamiento
 económico pedido; identifica la convención del ejercicio y no mezcles EBIT, deuda y flujo dos veces.
 Arrendar puede liberar inversión inicial y trasladar riesgos de valor residual, aunque pagos
 contractuales siguen presionando caja y capacidad de deuda.
 Modigliani-Miller sin impuestos, costos de quiebra, información asimétrica ni agencia establece que,
 en mercados perfectos, cambiar deuda por patrimonio no altera valor total: cambia cómo se reparte
 riesgo y retorno. Con impuesto corporativo, intereses deducibles pueden crear escudo fiscal; con
 distress esperado, costos de agencia, impuestos personales, flexibilidad y señales, hay costos y
 beneficios. La empresa elige apalancamiento atendiendo a valor esperado, capacidad de pago bajo
 escenarios y acceso a capital, no una razón objetivo separada del negocio.
 El apalancamiento financiero amplifica el rendimiento y riesgo del patrimonio al fijar obligaciones
 antes de distribuir a accionistas. Una empresa con rentabilidad de activos mayor al costo de deuda
 puede elevar ROE mecánicamente en escenarios favorables, pero la misma deuda aumenta
 pérdidas y probabilidad de incumplimiento en escenarios malos. No confundas el aumento de ROE
 por menor patrimonio con creación de valor. Distingue beta de activos, beta de deuda y beta
 patrimonial; bajo hipótesis simples, (β_A=(E/V)β_E+(D/V)β_D), y beta de equity responde también
 al apalancamiento. La relación exacta depende de impuestos y definiciones.
Examen de Grado UC | materia, preguntas y respuestas 65

[pág. 66]
Finanzas - versión clara y reordenada
 Lectura integrada de ratios y diagnóstico financiero
 Una razón es una pregunta estructurada, no un veredicto. Liquidez corriente estima cobertura
 contable de obligaciones próximas, pero inventario obsoleto o caja restringida pueden hacerla
 engañosa. Prueba ácida reduce dependencia de inventarios, pero no reemplaza calendario de caja.
 Deuda/activos mide estructura, no capacidad de pagar; cobertura de intereses exige escoger EBIT,
 EBITDA o flujo de caja y considerar amortización principal. Márgenes muestran captura por cada
 venta; rotación de activos muestra intensidad de capital. Descompón ROE para distinguir margen,
 rotación y apalancamiento y pregunta si el cambio es operativo, financiero o contable.
 El diagnóstico compara: (1) varios años y estacionalidad; (2) pares y definición homogénea; (3)
 presupuesto versus real; (4) caja, vencimientos y covenants; (5) calidad de activos y utilidad; (6)
 factores cualitativos de negocio. Cierra con hipótesis verificable y acción: renegociar deuda,
 acelerar cobro, ajustar inventario, revisar inversión o mantener liquidez preventiva. Una mejora en
 razón puede esconder deterioro real -por ejemplo, liquidar inventario sano para pagar deuda y
 perder ventas-, por lo que explica el mecanismo.
 Taller avanzado: pasar de un dato financiero a una decisión
 Preferencias, riesgo y equivalente cierto
 La rentabilidad esperada resume resultados posibles, pero no indica por sí sola qué alternativa
 prefiere un inversionista. Si (X) es riqueza final incierta, la utilidad esperada es (E[U(X)]). Una
 persona aversa al riesgo tiene utilidad cóncava: el costo de una pérdida pesa más que el beneficio
 de igual magnitud y certeza. El equivalente cierto (CE) es la cantidad segura que da la misma
 utilidad que la alternativa riesgosa: (U(CE)=E[U(X)]). La prima de riesgo es (E[X]-CE), bajo esa
 definición. No es idéntica al spread de un bono ni a la prima del CAPM; todos requieren contexto.
 Ejemplo de dos estados. Invertir $100 entrega $150 con probabilidad 1/2 y $70 con probabilidad
 1/2: valor esperado $110, pero resultados pueden diferir. Una alternativa segura de $110 iguala el
 promedio, no necesariamente utilidad. Con utilidad logarítmica, (E[ln X]=0,5ln150+0,5ln70); el
 equivalente cierto es su exponencial, cercano a $102,47. La persona aversa prefiere el promedio
 seguro de $110 sobre la lotería. La riqueza inicial, horizonte, posibilidad de diversificar y correlación
 con ingresos laborales cambian la preferencia. Un inversionista diversificado puede aceptar más
 riesgo idiosincrático que alguien cuyo empleo y patrimonio dependen de la misma empresa.
 Media-varianza aproxima preferencias usando (E[R]) y varianza cuando retornos son normales o
 las preferencias/quadrática hacen suficiente la media y varianza. Bajo utilidad cuadrática, o con una
 distribución normal y preferencias compatibles, aversión (A) produce equivalente de certeza
 aproximado (E[R]-(A)/(2)σ^2). No trates esa expresión como universal: retornos sesgados, colas,
 pérdidas máximas y necesidades de liquidez pueden exigir otros indicadores. En un examen, si
 preguntan por portafolio, explica tanto rendimiento como covarianza y para qué inversionista se
 interpreta.
Examen de Grado UC | materia, preguntas y respuestas 66

[pág. 67]
Finanzas - versión clara y reordenada
 Construir beta y costo de capital con datos coherentes
 CAPM convierte riesgo sistemático en retorno requerido: (r_E=R_f+β_E(E[R_m]-R_f)). Ejemplo:
 (R_f=4%), prima de mercado (6%), ( eta_E=1,2); retorno requerido (=4+1,2(6)=11,2%. El cálculo
 solo es interpretable si tasa libre, beta y prima están en misma moneda, horizonte y convención. No
 sustituyas rentabilidad histórica de la acción por tasa libre ni confundas prima de mercado con
 (E[R_m]).
 La beta estima covarianza relativa al índice: (β_i=Cov(R_i,R_m)/Var(R_m)). En regresión,
 pendiente responde a cambios históricos y depende de frecuencia, ventana, índice, deuda y
 eventos. Separa riesgo operativo del efecto financiero: beta de activos pondera riesgo del negocio;
 beta del patrimonio aumenta con deuda por la prioridad fija de acreedores. En estructura simple sin
 impuestos, (β_A=(E/V)β_E+(D/V)β_D); si deuda sin riesgo (β_D≈0), desapalancar permite
 comparar negocios. Con impuestos y distress, usa la fórmula que corresponda a supuestos
 indicados y no mezcles deuda contable con valor de mercado.
 Para un proyecto nuevo, identifica comparables cuyo negocio se parezca, retira deuda de su beta
 patrimonial, calcula beta de activos representativa y vuelve a apalancar al financiamiento objetivo.
 Si el proyecto opera en otro rubro, la beta promedio de la compañía puede ser mala aproximación.
 Verifica activos no operacionales: una empresa con caja/depósitos libres de riesgo tiene beta de
 activos totales diluida frente a la de su operación. La corrección local de 2025 usa precisamente esa
 distinción en un proyecto distinto del negocio original; su procedimiento es una guía de cálculo, no
 una regla para todas las estructuras.
 Bonos, duración y cambio de curva: un cálculo interpretable
 Supón un bono con valor facial $1.000, cupón anual 5%, plazo 3 años y yield 6%. Su precio es
 (50/1,06+50/1,06^2+1.050/1,06^3≈973,27). Está bajo par porque cupón (5%) es menor que yield
 (6%). No confundas cupón con retorno total. Si la tasa baja a 5%, el precio sube a par; el alza del
 precio compensa el menor rendimiento futuro al nuevo comprador.
 Los flujos descontados son aproximadamente 47,17; 44,50; 881,60. Duración Macaulay
 (D_M=(1·47,17+2·44,50+3·881,60)/973,27≈2,86) años. Duración modificada
 (D_mod=D_M/(1+y)≈2,70). Para un aumento pequeño de yield de 0,01, cambio aproximado (Δ
 P≈-2,70%, es decir caída cercana a $26,28. Si el cambio es grande, agrega convexidad
 ((1)/(2)Conv(Δ y)^2) y recalcula con curva de cada vencimiento si el movimiento no es paralelo.
 Si los bonos tienen opción de prepago, cambio de tasas altera la fecha esperada de flujos y
 duración; la duración efectiva es más apropiada que la simple. En un bono indexado, flujo y tasa
 real deben relacionarse con inflación según el contrato. La diferencia entre bono nominal y real
 refleja inflación compensada y primas de liquidez/riesgo; no equivale sin más a una expectativa sin
 sesgo.
 Precio forward de moneda y cobertura con descalce
 Bajo no arbitraje sin fricciones, el forward de moneda depende de tasas en ambas monedas. Si
 (S_0) está en pesos por dólar, tasas efectivas anuales en pesos (r_CLP) y dólares (r_USD),
 entonces (F_0,T=S_0[(1+r_CLP)/(1+r_USD)]^T). La paridad cubierta impide un retorno libre de
 riesgo por invertir una moneda y cubrir con forward la conversión final. No significa que el tipo
 forward pronostique el spot futuro; refleja tasas y precio presente.
Examen de Grado UC | materia, preguntas y respuestas 67

[pág. 68]
Finanzas - versión clara y reordenada
 Ejemplo. (S_0=900), tasas 8% CLP y 4% USD a un año: (F≈900(1,08/1,04)=934,62) pesos/USD.
 Un importador que debe USD 1 millón puede comprar dólares forward y conoce el desembolso de
 unos $934,62 millones. Si en verdad debe solo $700.000, una cobertura por USD 1 millón deja
 posición especulativa de USD 300.000. La exposición también puede desfasarse en fecha o variar
 con volumen y default de cliente. Para coberturas de caja incierta utiliza cobertura parcial, bandas o
 opciones y mide la varianza de caja neta.
 Opciones: replicar para entender precio, no memorizar fórmula
 En árbol binomial de un periodo, (S_0=100), al vencimiento sube a 120 o cae a 80; call con
 (K=100), tasa efectiva 5%. Payoffs: (C_u=20), (C_d=0). Probabilidad neutral al riesgo
 (q=((1,05)-0,80)/(1,20-0,80)=0,625). Precio (C_0=[0,625(20)+0,375(0)]/1,05≈11,90). La réplica
 compra Δ=(20-0)/(120-80)=0,5 acciones y toma deuda (B=(C_d-Δ S_d)/1,05=-38,10); cartera cuesta
 (50-38,10=11,90) y paga 20/0 según estado. La posición es una deuda de $38,10 hoy. La
 probabilidad 0,625 es de valoración neutral al riesgo, no probabilidad física.
 Black-Scholes para call europea sobre acción sin dividendos: (C=S_0N(d_1)-Ke^-rTN(d_2)),
 (d_1=[ln(S_0/K)+(r+σ^2/2)T]/(σ√T)), (d_2=d_1-σ√T). El precio aumenta normalmente con volatilidad
 y plazo, baja con strike; relación con tasas depende de opción. Supone dinámica lognormal,
 volatilidad constante, negociación continua/fricciones nulas, tasa constante y ejercicio europeo.
 Volatilidad histórica no garantiza volatilidad futura. Ajusta por dividendos, tasas discretas y estilo
 cuando el problema lo pida; la fórmula no convierte una hipótesis arriesgada en certeza.
 Sensibilidad, escenarios y tasa de descuento
 Un VAN es función de supuestos. Sensibilidad cambia una variable cada vez y muestra exposición
 local, pero puede combinar escenarios incompatibles (precio cae mientras costos bajan por razón
 equivocada). Análisis de escenarios cambia un conjunto coherente de variables; simulación asigna
 distribuciones y correlaciones y estima distribución del VAN, con riesgo de falsa precisión si
 parámetros son pobres. Valor esperado no resume liquidez ni posibilidad de insolvencia. Separa
 riesgo modelable y riesgo no cuantificado.
 Una tasa alta no compensa automáticamente un flujo mal pronosticado ni elimina asimetrías. No
 dupliques riesgo subiendo tasa y reduciendo flujos por el mismo riesgo sin explicar por qué. Para
 riesgo diversificable se suele usar retorno requerido por beta en CAPM, no añadir prima arbitraria al
 WACC. Para incertidumbre de proyecto que puede cambiar etapa o tamaño, valora opción real o
 escenario de decisión en vez de inflar tasa.
 Fuentes y trazabilidad
 Este manual conserva la materia y los talleres del manual previo de Finanzas e integra
 ampliaciones docentes construidas con resúmenes de Finanzas I y II, casos, pruebas y
 solucionarios revisados en el proyecto. Las referencias de páginas de esos documentos se indican
 en cada desarrollo cuando están disponibles. El banco histórico reproduce las páginas originales
 del compendio EDG_E_2009-2026_OCR.pdf. Las respuestas son propuestas de estudio y no se
 presentan como pauta oficial salvo identificación expresa en la fuente. La revisión del material se
 registra en “auditoria_finanzas_20261011.md” y el cotejo de respuestas en “cotejo_cierre_70.md”.
Examen de Grado UC | materia, preguntas y respuestas 68

[pág. 69]
Finanzas - versión clara y reordenada
 MATERIA RECUPERADA · FINANZAS
 CML, SML, desempeño multifactorial e inmunización con duración
 1. CML y SML: dos rectas, dos objetos de riesgo
 La Capital Market Line relaciona retorno esperado y desviación estándar total para carteras
 eficientes formadas por el activo libre de riesgo y la cartera tangente. Solo las combinaciones
 eficientes pertenecen a la CML. Su pendiente es el Sharpe de la cartera de mercado:
 [E(RM)-Rf]/σM. Un portafolio por debajo de la CML ofrece poco retorno para su riesgo total; uno
 sobre la CML sería superior al conjunto factible bajo los supuestos del modelo.
 La Security Market Line es la representación del CAPM para cualquier activo o cartera:
 E(Ri)=Rf+βi[E(RM)-Rf]. Usa beta porque un inversionista diversificado no recibe premio por riesgo
 específico. Un activo sobre la SML tiene retorno esperado o realizado mayor que el predicho por su
 beta; esa distancia vertical es alfa. No confundas: CML usa desviación estándar y solo portafolios
 eficientes; SML usa beta y admite activos individuales.
 Sharpe, Treynor y alfa de Jensen
 • Sharpe = (Rp-Rf)/σp. Evalúa exceso de retorno por unidad de riesgo total y sirve cuando el
 portafolio puede ser la inversión completa.
 • Treynor = (Rp-Rf)/βp. Usa riesgo sistemático; es más pertinente para una cartera dentro de un
 portafolio ya diversificado.
 • Alfa de Jensen = Rp-[Rf+βp(RM-Rf)]. Mide desempeño no explicado por CAPM para el período;
 debe evaluarse con significancia, persistencia, costos y sesgos.
 Un Sharpe mayor no prueba habilidad si hay exposición no modelada, opciones implícitas, retornos
 no normales o sesgo de selección. Un alfa muestral positivo tampoco basta: se revisa error
 estándar, período, benchmark y estabilidad fuera de muestra.
 2. De CAPM a Fama-French-Carhart
 APT permite varios factores comunes. En Fama-French, MKT recoge mercado; SMB es el retorno
 de pequeñas menos grandes; HML es alto book-to-market menos bajo. Carhart agrega momentum
 -ganadoras menos perdedoras recientes-. Una regresión
 Ri-Rf=α+βMKT·MKT+s·SMB+h·HML+m·MOM+ε describe exposiciones. Un s positivo indica sesgo
 hacia empresas pequeñas; h positivo, hacia value; m positivo, hacia momentum. El alfa pregunta
 qué queda sin explicar por esos factores.
 La interpretación no es automática. Las primas pueden representar riesgos omitidos o patrones de
 conducta; el modelo es empírico. Un coeficiente sin significancia no justifica una historia. R² alto
 indica que el modelo explica variación, no que la estrategia sea buena ni que el alfa sea causal.
 Para evaluar gestión se descuentan comisiones, costos, rotación y posibles cambios de exposición.
Examen de Grado UC | materia, preguntas y respuestas 69

[pág. 70]
Finanzas - versión clara y reordenada
 3. Duración, convexidad e inmunización
 La duración de Macaulay es el promedio temporal ponderado de los flujos. La duración modificada
 aproxima sensibilidad: ΔP/P≈-Dmod·Δy. La convexidad agrega curvatura:
 ΔP/P≈-Dmod·Δy+½·Conv·(Δy)². La aproximación supone un desplazamiento pequeño de tasas y,
 en su versión simple, paralelo de la curva.
 Inmunizar significa diseñar activos y pasivos para que un cambio pequeño de tasas no destruya el
 objetivo. Para un compromiso único, se igualan valor presente y duración en el horizonte; luego se
 rebalancea porque el tiempo, tasas y flujos cambian. Para patrimonio E=A-D, la sensibilidad
 aproximada es ΔE≈-DA·A·Δy+DD·D·Δy. La duración del patrimonio es DE=(A/E)DA-(D/E)DD.
 Hacer DE=0 neutraliza el efecto de primer orden, pero no elimina convexidad, movimientos no
 paralelos, crédito o liquidez.
 Ejemplo completo
 Si activos valen 300 y duran 10, deuda vale 100 y dura 20, el patrimonio vale 200 y
 DE=(300/200)10-(100/200)20=5. Ante un alza de 3 puntos porcentuales,
 ΔE≈-10·300·0,03+20·100·0,03=-30. Con duraciones fijas, se inmuniza haciendo
 D=DA·A/DD=10·300/20=150; entonces E=150 y DE=(300/150)10-(150/150)20=0. El ejemplo es de
 primer orden y requiere revisar la factibilidad económica de cambiar la deuda.
 4. Qué aportaron las siete ayudantías grabadas
 El muestreo visual de cinco momentos por video identificó la secuencia del curso de Teoría
 Financiera: retornos y estados; arbitraje y precios contingentes; forwards; cobertura con derivados;
 árbol binomial y Black-Scholes; bonos, curva y CAPM; APT, liquidez y multifactoriales. Cada bloque
 tiene enunciados y pautas escritas en la carpeta. El manual maestro ya desarrolla esos temas; esta
 ampliación hace explícitas las distinciones CML/SML, desempeño y la inmunización que aparecían
 en los resúmenes completos.
 Respuesta de Distinción en Finanzas: define el dueño del flujo, dibuja la línea de tiempo o
 estados, fija supuestos, elige la tasa compatible, calcula, interpreta económicamente, hace
 sensibilidad y cierra con decisión y límites.
Examen de Grado UC | materia, preguntas y respuestas 70

[pág. 71]
Finanzas - versión clara y reordenada
 PARTE DE PRÁCTICA - 70 preguntas
 históricas
 Teoría Financiera - 35 preguntas
Examen de Grado UC | materia, preguntas y respuestas 71

[pág. 72]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2015 | pregunta 6
 Convocatoria 2 | página original 183 | Alfa, beta y elección de fondos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 R
 PREGUNTA N" 6
 Usted acaba de ingresar al Family Office de la familia L£R, en particular al equipo que maneja el
 portafolio de inversiones financieras de dicha familia. Su primera tarea es seleccionar un Fondo de
 acciones chilenas donde se invertirá aproximadamente el 10% de los recursos disponibles. Su
 predecesor redujo las múltiples opciones a tres Fondos de Inversión con las siguientes características:
 F0ndo'(,1e a c&f;g;:30nflt&_e Beta con resz;ecto al
 Inversión 1-01-13 / 30-06-15 (1) IPSA
 Fondo 1 6,3% L]
 Fondo 2 5,8% 0,8
 Fondo 3 5,4% 0,9
 (1): — Corresponde al exceso de retorno, por sobre la tasa libre de riesgo, que exhibe el Fondo en cuestión en el
 período señalado, neto de comisiones e impuestos.
 (2): El IPSA es el Índice de Precios Selectivo de Acciones, y se considera representativo de la cartera de
 mercado chilena. Durante el período analizado (1-01-13 al 30-06-15), este índice accionario acumuló un
 exceso de retorno (rendimiento por sobre la tasa libre de riesgo) de 5,7%.
 Suponga que el modelo CAPM fuera válido, que no hay inflación, y que el Family Office pretende
 mantener la inversión en el Fondo que Ud. le recomiende por un período no inferior a un año.
 Utilizando solamente la información que se le ha proporcionado, responda las preguntas que se le
 formulan a continuación. En todos los casos justifique sus repuestas.
 a) ¿Cuál de los tres Fondos elegiría usted si el objetivo de su inversión fuera entregar el mejor retorno
 ajustado por riesgo en acciones chilenas?
 b) ¿Cuál de los tres Fondos elegiría usted si el objetivo de su inversión fuera superar el índice
 accionario IPSA?
 €) Suponga ahora que su propio análisis del mercado chileno y la opinión de expertos es que el mercado
 chileno vivirá un boom en el próximo año. Si Ud. tiene plena confianza en esta información y la cree
 verdadera, ¿cambiaría el Fondo de Inversión elegido en las letras (a) y (b) anteriores?
 d) Suponga ahora que su propio análisis del mercado chileno y la opinión de expertos es que el mercado
 chileno vivirá una fuerte crisis en el próximo año. Si Ud. tiene absoluta confianza en esta
 información y la cree verdadera, ¿cambiaría el Fondo de Inversión elegido en las letras (a) y (b)
 anteriores?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 72

[pág. 73]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2013 | pregunta 5
 Convocatoria 2 | página original 134 | Apalancamiento, múltiplos y eficiencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 PREGUNTA Nº 5
 Durante los últimos años, una empresa que usted asesora ha experimentado un fuerte crecimiento en sus activos por la
 vía de adquisiciones de firmas competidoras de menor tamaño. Este crecimiento ha sido financiado en su mayor parte
 con deuda no bancaria (emisión de bonos corporativos), lo que ha llevado a que la empresa tenga en la actualidad una
 razón deuda / patrimonio (medida a valores de mercado) que supera los estándares de la industria en que ella opera. En
 esta compañía hay quienes piensan que si se continúa emitiendo deuda (bonos), la empresa muy probablemente se verá
 afectada en forma negativa en las clasificaciones de riesgos que constantemente realizan diversos analistas financieros.
 Por esta razón, ellos desearían que las nuevas inversiones que tiene contemplado realizar la firma, sean financiadas
 únicamente con patrimonio (acciones).
 Por otra parte, la agresiva estrategia de crecimiento de la empresa ha generado una serie de trastornos operativos, y la
 compañía ha tenido malos resultados operacionales en el último tiempo. Actualmente, el valor de mercado del
 patrimonio de la firma (compuesto por 1.000 acciones que tienen un precio de mercado de $2 cada una) es igual a la
 mitad de su valor libro (contable). Esto significa que incluso si un proyecto es rentable, hace caer la utilidad por acción
 (UPA) que actualmente tiene la compañía ($0,60) si es financiado con la emisión de nuevas acciones (aumento de
 capital).
 Por ejemplo, entre los múltiples proyectos que la empresa está considerando llevar a cabo, y que todavía no ha sido
 anunciado al mercado, existe uno que demandaría hoy una inversión total de $400. Este proyecto tiene un valor actual
 neto (VAN) de $100 y haría aumentar las utilidades netas de la compañía en $60 al año de manera indefinida. Si el
 proyecto es financiado únicamente con patrimonio, los $400 requerirán la emisión de, aproximadamente, 200 nuevas
 acciones, llevando el número total de éstas a 1.200. Con esto, la utilidad neta de la empresa subiría desde $600 anuales
 a $660, haciendo que la utilidad por acción (UPA) disminuya desde $0,60 a $0,55.
 El Presidente de la compañía piensa que el proyecto anterior debe ser pospuesto por las siguientes tres razones:
 a) En las actuales condiciones, la firma no debe aumentar su razón deuda / patrimonio. Hacerlo sería demasiado caro y
 provocaría una pérdida de riqueza para los accionistas de la empresa.
 b) Si el proyecto es financiado con acciones, la utilidad por acción disminuirá. Esto sería una mala señal para el
 mercado, ya que a menudo los inversionistas utilizan múltiplos, como por ejemplo la razón precio / utilidad (esto es, el
 precio de mercado de la acción dividido por la UPA), para valorizar las acciones de las compañías.
 c) El mercado accionario está deprimido, al punto que los precios de las acciones, medidos a través del Índice General
 de Precios de las Acciones (IGPA), acumulan este año una caída cercana al 13%. Si la firma posterga la emisión de
 acciones y espera hasta que el mercado accionario repunte nuevamente, el valor de mercado del patrimonio será
 superior a su valor libro, por lo que el financiamiento a través de acciones no producirá una caída en la UPA.
 Utilizando sus conocimientos de teoría financiera y suponiendo que el mercado de capitales no es perfecto, a usted se
 le pide evaluar, en forma separada, cada una de las razones entregadas por el Presidente de la compañía para postergar
 el proyecto. Sea breve y preciso en su respuesta, e indique expresamente si Ud. está o no de acuerdo con lo planteado
 por el Presidente, analizando los argumentos que él ha entregado. Si en su respuesta Ud. hace uso de algún supuesto,
 éste debe quedar explicitado.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 73

[pág. 74]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2021 | pregunta 6
 Convocatoria 2 | página original 352 | Beta, CAPM y WACC
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 PREGUNTA Nº6
 La empresa Diver S.A. es un holding financiero cuyo único activo son acciones de tres compañías que
 pertenecen a diversos rubros (industrias). Las acciones de estas compañías se transan activamente en bolsa y
 presentan las siguientes características financieras:
 Valor de Mercado del
 Deuda / Patrimonio Beta Beta
 Compañía Industria Patrimonio (cifras en (*)
 Deuda Acciones
 millones de $)
 BCD Pin Retail MM$ 2.000 1,0 0,6 1,8
 Los Troncos Forestal MM$ 4.000 0,5 0,25 1,0
 Chispita Energía MM$ 6.000 2/3 0,1 0,6
 (*): Las compañías se financian únicamente con bonos. El índice de endeudamiento está calculado sobre el
 patrimonio medido a valor de mercado.
 El 20% de los activos de Diver S.A. corresponden a acciones de la compañía BCD Pin, y el 80% restante está
 repartido en partes iguales (40% cada una) en acciones de la empresa Los Troncos y de la compañía Chispita.
 El holding no tiene otros activos y no utiliza deuda (100% de financiamiento patrimonial). El premio por riesgo
 de mercado [E(RM) – RF)] es un 6% y la tasa libre de riesgo igual a 4%.
 Suponiendo que el mercado de capitales es perfecto y que se cumple el modelo CAPM, responda las preguntas
 que se le formulan a continuación, mostrando todos los cálculos que correspondan. Para sus cálculos y
 respuestas utilice un mínimo de dos decimales, (ejemplo 12,23%).
 a) ¿Cuál es el costo de capital promedio ponderado de Diver S.A.?
 b) La señora Edison, es una inversionista que en este momento dispone de $10 millones de recursos propios y
 que ha decidido comprar en el mercado $15 millones en acciones de Chispita. Dado que la señora Edison
 contaba solamente con $10 millones para la compra de las acciones, ella decidió tomar una deuda por $5
 millones en un Banco, que consiguió pactarla a la tasa libre de riesgo (4% anual) y así reunir el monto requerido
 para llevar a cabo su inversión.
 ¿Cuál será el retorno anual esperado del patrimonio de la señora Edison, como resultado de su estrategia? ¿Es
 este retorno distinto del rendimiento esperado de las acciones de Chispita? Si los retornos esperados son iguales
 explique brevemente porqué son iguales y si, por el contrario, son distintos, explique porqué son distintos.
 c) Diver S.A. está analizando la posibilidad de adquirir el 100% de la propiedad de la cadena de tiendas
 “Londres”, que es el principal competidor de BCD Pin. Ambas empresas son totalmente representativas de la
 industria del retail y la idea del holding, con esta adquisición, es fortalecer su posición en el rubro del retail.
 “Londres” es una empresa que no tiene deuda y sus activos tienen el mismo riesgo que los activos de BCD
 Pin.
 Para financiar la adquisición de “Londres”, la administración de Diver S.A. venderá una parte de las acciones
 que el holding actualmente posee en la empresa “Los Troncos”, con la idea de reducir la exposición al sector
 forestal por razones estratégicas.
 El Gerente General de Diver S.A. estaba un poco confundido respecto de la tasa de descuento que debía
 utilizarse para descontar los flujos de caja de la potencial adquisición de la cadena de tiendas “Londres” y le
 pide a Ud. que lo asesore en dicha tarea. En concreto, a usted se le solicita determinar la tasa de descuento
 apropiada para descontar los flujos de caja de la eventual compra de la citada cadena de tiendas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 74

[pág. 75]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2019 | pregunta 3
 Convocatoria 1 | página original 283 | Betas y WACC
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N'3
 Usted debe evaluar la conveniencia de iniciar una nueva empresa (proyecto) llamada CMV S.A. en el rubro de
 transporte marítimo. Su gran duda es qué tasa de descuento usar para evaluar este proyecto. Investigando, usted
 encontró tres empresas cuyo giro sería similar al del proyecto que usted desea evaluar. Los datos encontrados
 son los siguientes:
 Beta Valor de mercado del Valor de mercado de
 .e . atrimonio Beta Deuda la deuda
 Patrimonio p
 (millones de US$) (millones de US$)
 Transportes Marad S.A. 1,2 1.700 0:15 850
 Oleada S.A. 0,9 800 0 0
 Navegación Oceánica S.A. 1,8 1.050 0,25 3.150
 Se ha determinado además que el CAPM (Modelo de Valoración de Activos de Capital) es un buen modelo a
 ser utilizado para los efectos de estimar tasas de descuento. La tasa libre de riesgo es 3% anual y el premio por
 riesgo de mercado es 5% anual. La empresa que usted evalúa será similar, en términos de activos y estructura
 de financiamiento, al promedio ponderado de las empresas del cuadro anterior. Suponga inicialmente que el
 mercado de capitales es perfecto.
 Responda las preguntas que se le formulan a continuación mostrando todos los cálculos que sean necesarios:
 a) Si CMV S.A. será similar al promedio ponderado de las empresas en el cuadro anterior, determine el Beta y
 la tasa de descuento que debería utilizar esta empresa para descontar los flujos de caja de sus activos.
 b) Mantenga el supuesto de mercado de capitales perfecto. Usted también desea calcular la tasa de costo de
 capital del patrimonio, para explicarle a sus accionistas cuál sería la rentabilidad esperada “justa” de largo plazo
 de este negocio. Para calcular el Beta del patrimonio y así poder obtener el costo de capital del patrimonio, un
 analista le recomienda utilizar la siguiente fórmula:
 B1 == Bal1+777)
 .
 donde:
 B = beta del patrimonio
 Ba = beta de los activos
 — razón (deuda / patrimonio) utilizando valores de mercado
 La relación (deuda / patrimonio), usando valores de mercado, que planea usar la empresa CMV S.A. es de
 1,1268, que corresponde al promedio ponderado de las empresas del cuadro anterior. ¿Está usted de acuerdo
 con utilizar la fórmula propuesta para calcular el Beta del patrimonio? ¿Qué Beta y qué tasa de descuento para
 el patrimonio debería usarse para evaluar el proyecto de CMV S.A.?
 c) Suponga ahora que existen impuestos con una tasa corporativa de 25% y que la deuda tiene ventajas
 tributarias. Suponiendo que la única imperfección del mercado de capitales fuera la existencia de impuestos
 corporativos, ¿Cuál sería ahora el costo de capital de los activos y del patrimonio de CMV S.A.? Fundamente
 su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 75

[pág. 76]
Finanzas - versión clara y reordenada
 Teoría Financiera | marzo 2011 | pregunta 6
 Convocatoria 1 | página original 68 | Bonos, impuestos y TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA Nº6
 En el llamado “régimen normal” de la Ley de Impuesto a la Renta (LIR), si una empresa emite un bono para financiar
 sus operaciones, podrá rebajar de la base imponible los intereses pagados por el bono (según la tabla de desarrollo a
 través de la cual se determinan dichos intereses) y además amortizará, llevando a “resultado”, el “sobre-precio” o “bajo-
 precio” generado al momento de la venta o colocación del bono (diferencia entre el valor de mercado y el valor par del
 bono), linealmente en el tiempo.
 Por lo tanto, en el régimen normal, si el primer día de vida de un bono a un año plazo, con tasa de interés de carátula de
 5% anual, con pago del total del principal e intereses al final del año de vida del bono, cuyo valor par en ese momento es
 de $1.000, la empresa emisora lo vende en $960, dicha empresa emisora podrá reconocer al cabo de un año un gasto por
 intereses de $50 (5% de $1.000) y un gasto por la amortización del bajo precio de $40 (diferencia entre los $1.000 y
 $960), reduciendo así la base imponible en $90 (la suma de $40 y $50).
 El año 2009, se modificó la Ley de Impuesto a la Renta (LIR) introduciendo el Artículo N°104, con el fin de incentivar
 el desarrollo del mercado de bonos de empresas, por la vía de eximir a los compradores de estos instrumentos del pago
 de impuestos a las ganancias de capital. De esta manera, un nuevo bono emitido por una empresa, si se acoge al Artículo
 104 de la LIR, eximirá a sus compradores de pagar impuestos sobre las ganancias de capital que ellos obtengan, si
 deciden vender dicho bono en el mercado secundario. Sin embargo, el legislador, preocupado por la “elusión
 tributaria”1, puso la siguiente restricción en el Artículo 104: si el bono se vende bajo la par, el emisor del bono deberá
 pagar impuestos por la diferencia entre el valor par y el valor de mercado al momento de vender (colocar) el bono. Por
 ejemplo, con una tasa de impuestos a las empresas de 20%, un bono con valor par de $1.000 que se vende en $960 genera
 un “bajo-precio” de $40 y el emisor deberá pagar al fisco, al momento de la venta del bono, un impuesto de $8 sobre esa
 diferencia (20% de $40). El “bajo-precio” de $40 de nuestro ejemplo, el emisor lo podrá considerar como gasto para
 efectos tributarios, al final del año de vida del bono.
 En todo lo que sigue suponga lo siguiente:
 • Que la base imponible de la empresa es lo suficientemente “grande” como para que, al rebajar los gastos financieros
 y las eventuales amortizaciones que se tuviese que rebajar de la base imponible, ésta siga siendo positiva.
 • Que no hay inflación
 • Que una empresa emite un bono a un año plazo, con valor par de $1.000, con tasa de interés de carátula de 5%
 anual, y pago del monto total del principal ($1.000) e intereses ($50), al final del año de vida del bono.
 • Que el bono descrito anteriormente, es vendido o colocado en el mercado en $960 el primer día del año de vida del
 bono (es decir, cuando le queda un año para expirar).
 A usted se le pide que responda:
 a) ¿Cuál es el costo anual (%) del financiamiento, después de impuestos, que debe pagar la empresa emisora del
 bono:
 i) si ella estuviera acogida al régimen normal?
 ii) si ella estuviera acogida al artículo 104?
 1 Evitar el pago de impuestos, utilizando resquicios legales no contemplados por el legislador al momento de redactar la ley.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 76

[pág. 77]
Finanzas - versión clara y reordenada
 Teoría Financiera | marzo 2011 | pregunta 6
 Convocatoria 1 | página original 69 | Bonos, impuestos y TIR
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 b) La LIR establece que el comprador del bono acogido al artículo 104 deberá tributar sólo por los intereses de
 carátula y no por el mayor valor con respecto al precio de compra que recibirá al momento de recibir el pago del
 bono, es decir, en nuestro ejemplo, no tributará por los $40 de mayor valor que recibirá por la diferencia entre los
 $960 que él pagó al momento de la compra y los $1.000 que recibirá, además de los $50 de intereses, al momento
 del vencimiento del bono. En el caso del régimen normal, el comprador del bono deberá tributar tanto por los
 intereses de carátula como por el mayor valor.
 Suponiendo que la tasa de impuestos del comprador también es 20% y que éste adquiere en $960 el bono de nuestro
 ejemplo, es decir, un bono a un año plazo, con valor par de $1.000, con tasa de interés de carátula de 5% anual, y
 pago del monto total del principal ($1.000) e intereses ($50), en un año más, a usted se le pide que responda lo
 siguiente
 ¿Cuál es el rendimiento (rentabilidad) anual (%), después de impuestos que recibirá el comprador en el caso
 que:
 i) el bono se acoja al régimen normal?
 ii) el bono se acoja al artículo 104?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 77

[pág. 78]
Finanzas - versión clara y reordenada
 Teoría Financiera | marzo 2009 | pregunta 6
 Convocatoria 1 | página original 12 | Bonos/renta fija
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA Nº6
 No se sabe exactamente cuándo comenzó la llamada “Crisis Financiera”, pero su efecto se aprecia en los gráficos de la
 siguiente página. El Gráfico 1 muestra el nivel de tres tasas de interés seleccionadas para Estados Unidos (EEUU): la
 tasa de interés de los bonos nominales del Tesoro a 10 años (TN); la tasa de interés real de los bonos del Tesoro a 10
 años indexados a la inflación (TR); y la tasa de interés nominal de los bonos corporativos o de empresas de “Grado de
 Inversión” de EE.UU. (bonos con categoría de riesgo Baa), también de plazo aproximado de 10 años. Por su parte, el
 Gráfico 2, muestra dos “spreads” o diferencias de tasas: por una parte se muestra el spread o diferencia entre las tasas
 de los bonos corporativos de grado de inversión a 10 años (Baa) con las tasas de interés del bono del Tesoro nominal
 a 10 años (TN), es decir muestra el spread [Baa – TN] y por otra parte se muestra el spread o diferencia entre las tasas
 de los bonos del Tesoro ajustado por inflación a 10 años (TR) con las tasas de interés del bono del Tesoro nominal a
 10 años (TN), es decir muestra el spread [TR – TN]. Se muestra información hasta fines de diciembre del año 2008.
 Los movimientos recientes (últimos 3 meses de 2008) en las tasas de interés ciertamente reflejan aspectos centrales de
 la crisis. Los inversionistas han buscado refugio en los instrumentos que son simultáneamente muy seguros y líquidos
 (lo que suele denominarse flight to quality y flight to liquidity, respectivamente). Eso explicaría parcialmente, por
 ejemplo, la fuerte caída en las tasas del bono nominal del Tesoro a 10 años. Existe además gran incertidumbre acerca
 del impacto que tendrá la crisis sobre el crecimiento económico mundial y sobre cuán profunda y prolongada será
 ésta.
 A usted se le pide responder cada una de las siguientes preguntas separadamente:
 1. Observando la información disponible, si Ud. tuviera que hacer una estimación sobre los niveles de inflación
 esperada de largo plazo en los Estados Unidos para el período que va entre comienzos del año 2003 hasta
 alrededor de los meses de mayo o junio de 2008, ¿de qué orden de magnitud habría sido su estimación?
 2. De los Gráficos 1 y 2, se desprende que tanto el nivel de las tasas de interés de los bonos corporativos (Baa),
 como su spread con respecto a los bonos del Tesoro nominales (Baa - TN) han aumentado. Dos factores que
 explicarían dichos aumentos son la probabilidad de no pago y el premio por riesgo. Explique por qué cada
 uno de estos dos factores contribuye a generar los aumentos antes mencionados.
 3. Considere la evolución del spread entre tasas reales y nominales para los últimos 3 meses (en medio de la crisis
 financiera) del Gráfico 2. ¿Pueden utilizarse los mismos argumentos dados en su respuesta a la pregunta 2
 anterior para explicar la evolución de dicho spread? En caso contrario, ¿se le ocurre una explicación para lo que
 se observa en el Gráfico 2? Tome en cuenta que se trata de instrumentos financieros emitidos a 10 años.
 4. ¿Es la evidencia que se muestra en los gráficos coherente con la afirmación: “Junto con la crisis financiera, han
 surgido notables temores de un rebrote inflacionario, lo que se refleja en que las personas han buscado refugio en
 los papeles estatales indexados a la inflación”? Explique por qué.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 78

[pág. 79]
Finanzas - versión clara y reordenada
 Teoría Financiera | marzo 2009 | pregunta 6
 Convocatoria 1 | página original 13 | Bonos/renta fija
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 GRÁFICOS
 Gráfico 1
 (1) Niveles de tasas de interés
 10
 8 Baa
 Tasas (%)
 6
 4 TN
 2 TR
 0
 Ene-03
 May-03
 Sep-03
 Ene-04
 May-04
 Sep-04
 Ene-05
 May-05
 Sep-05
 Ene-06
 May-06
 Sep-06
 Ene-07
 May-07
 Sep-07
 Ene-08
 May-08
 Sep-08
 Tesoro Real 10 años (TR)
 Tesoro Nominal 10 años (TN)
 Bonos Corp Baa
 Gráfico 2
 (2) Spreads
 10
 DIferencias de tasas (en %)
 8
 6
 4
 2
 0
 -2
 -4
 Ene-03
 May-03
 Sep-03
 Ene-04
 May-04
 Sep-04
 Ene-05
 May-05
 Sep-05
 Ene-06
 May-06
 Sep-06
 Ene-07
 May-07
 Sep-07
 Ene-08
 May-08
 Sep-08
 Baa-TN TR-TN
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 79

[pág. 80]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2010 | pregunta 6
 Convocatoria 2 | página original 56 | Bonos/renta fija
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA Nº6
 Jabor S.A. es una Compañía recientemente creada por sus dueños para iniciar un nuevo negocio. Jabor S.A. pretende
 recaudar un total de $15 millones con la emisión de bonos que serán vendidos a inversionistas institucionales, y ha
 informado a los potenciales compradores de estos bonos que el dinero que se espera recaudar podría ser utilizado
 solamente en uno de dos proyectos, Proyecto “A” o Proyecto “B”, proyectos que son mutuamente excluyentes entre sí.
 El Proyecto “A” le permitiría a Jabor S.A. obtener, en un año más (t = 1), un flujo de caja de $20 millones con 60% de
 probabilidad ó un flujo de caja de $30 millones con 40% de probabilidad. Por su parte, el Proyecto “B” le permitiría a la
 Compañía obtener, en un año más (t = 1), un flujo de caja de $10 millones con 60% de probabilidad ó un flujo de caja de
 $45 millones con 40% de probabilidad. Ambos proyectos requieren una inversión inicial de $15 millones que debe
 hacerse hoy (en t = 0) y no generan más flujos de caja después del año 1 (t = 1), es decir, al término del año 1 y en
 adelante, no habría otros flujos de caja distintos de los indicados anteriormente.
 Una vez que los inversionistas han comprado los bonos no pueden evitar que los dueños de Jabor S.A. lleven a cabo el
 proyecto que ellos estimen más conveniente.
 Suponiendo que:
 • No hay inflación ni impuestos.
 • La tasa de descuento relevante para evaluar ambos proyectos es igual a cero.
 • Los bonos emitidos por Jabor S.A. serán pagados únicamente con los flujos de caja que genere el proyecto elegido
 por los dueños de la empresa.
 • Cualquier otro supuesto que Ud. requiera, déjelo expresamente indicado.
 A Ud. de le pide responder lo siguiente:
 Sobre la base de los antecedentes presentados, ¿estima Ud. que a Jabor S.A. le debiera resultar posible recaudar, con la
 emisión de los bonos, los $15 millones que requiere para financiar los proyectos “A” ó “B”?. Explique su razonamiento
 y su respuesta presentando ordenadamente los cálculos que correspondan.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 80

[pág. 81]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2024 | pregunta 1
 Convocatoria 2 | página original 415 | Bonos/renta fija
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N*1
 El índice Sé-P500 es el índice bursátil más representativo del mercado accionario de EE.UU. En julio de 2024, la razón
 precio-utilidad (cíclicamente ajustada tomando las utilidades promedio de los últimos 10 años corregidas por inflación)
 para el Sé:P500 alcanzó uno de los niveles más altos del último tiempo. En concreto, la razón precio-utilidad en julio de
 2024 llegó a niveles de aproximadamente 35 siendo que el promedio histórico de esta razón es de alrededor de 20. La
 figura de abajo muestra la dinámica de esta razón desde finales del siglo XIX:
 Evolución de la Razón Precio-Utilidad del S£ P500
 un
 Varios de los peaks anteriores en la razón precio-utilidad, como los de 1929 y 1999, precedieron fuertes caídas en la
 bolsa americana. Hay que notar que son solo algunos episodios en más de 100 años. Otros peaks (como el de 2020
 relacionado al Covid) se debieron a fuertes caídas en las utilidades y solo anticiparon fuertes alzas en las utilidades en
 los años siguientes. Por uno u otro motivo, esta razón captura el interés de muchos analistas que argumentan en base a
 ésta, que las acciones americanas están “sobrevaloradas/caras” o “subvaloradas/baratas”.
 En los últimos años, también han subido las tasas de interés largas (por ejemplo, la tasa del bono del tesoro americano a
 10 años en la figura de abajo) y las tasas de interés cortas como la tasa de política monetaria americana (Fed Funds Rate).
 Estas tasas han subido desde niveles de prácticamente 0% durante pandemia hasta 5% aproximadamente hoy en día.
 Evolución de la Tasa del Bono del Tesoro Americano a 10 años
 PRED / — norcetYisidon y.5. Yreasuay Secuntes al 10.Year Constant Metury, Oueted on as fnvesbment Basis
 vurdose oe draz de 1 p an 2 JA Z 0 074
 Saa eras incicale V.S. reseauens Sanee Soers ef Covamars ef e Federal Zeservo Eystam (US)
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 81

[pág. 82]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2024 | pregunta 1
 Convocatoria 2 | página original 416 | Bonos/renta fija
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Evolución de la Tasa de Política Monetaria Americana (FED Funds Rate)
 FRED 2407 — Federal Funda Esactve Rare
 3
 Perconi
 a
 20001 2A Te7 ee 20207
 Shacea arezs inticato UN recessióna:
 Responda las preguntas que se le formulan a continuación, entregando los argumentos en los cuales fundamenta sus
 respuestas.
 1. Explique a través de un modelo de valor presente los elementos necesarios para justificar los actuales niveles
 de la razón precio-utilidad. En su respuesta distinga conceptos como tasa libre de riesgo, premio por riesgo, y
 crecimiento esperado de flujos. ¿Qué implica su análisis respecto de las predicciones de crecimiento de flujos y
 de retornos futuros? Considere un horizonte de 10 años aproximadamente. Se pide un análisis cualitativo, de
 dirección y magnitudes relativas de los efectos, pero no se piden cifras precisas.
 Algunos analistas de mercado han expresado preocupación frente a los niveles de valoración que se observan
 actualmente. Más de alguno menciona la palabra “burbuja”, es decir, la posibilidad de que las valoraciones estén
 desancladas de variables fundamentales y que sean solo ficticias. ¿Implica la razón precio-utilidad a julio de
 2024 necesariamente la existencia de una burbuja?
 Siusted quisiera proteger su inversión actual en el Sé-P500 frente a caídas en los precios, o frente a un “pinchazo
 de la burbuja”: ¿qué instrumento financiero derivado podría utilizar? Sea explícito en las características de ese
 instrumento.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 82

[pág. 83]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2025 | pregunta 6
 Convocatoria 2 | página original 449 | Bonos/renta fija
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N%
 Lavanda S.A. es una empresa especializada en la limpieza de ropa de cama
 (sábanas, plumones, frazadas) que
 presenta una gran estabilidad tanto en sus resultados de operación como en sus
 flujos de caja operacionales. Los
 accionistas controladores de esta empresa son muy conservadores y manejan la compañía
 sin deuda.
 Los cambios en la demografía y los hábitos de los consumidores hacen que el rubro de la limpieza
 de ropa de
 cama sea un negocio maduro con nulas posibilidades de crecimiento. Por esta razón, los analistas
 financieros
 proyectan que la compañía generará, para todos los efectos prácticos, un resultado operacional
 de $6.000
 millones anuales a perpetuidad. Este resultado operacional coincide con el flujo de caja operacional
 que se espera
 genere la empresa a perpetuidad. La tasa de impuestos corporativos es de un 25% y la política
 de dividendos de
 la empresa es repartir a los accionistas el 100% de sus utilidades después de impuestos. El rendimiento
 que se
 exige en el mercado a empresas sin deuda y de similar riesgo operacional a Lavanda S.A. es de
 12% anual
 después de impuestos.
 Suponiendo que la única imperfección presente en el mercado de capitales es la existencia
 de impuestos
 corporativos y que los flujos de caja de la empresa se producen al término de cada año, siendo el
 primer flujo en
 un año más, y en base a los antecedentes que se le han presentado, a Ud. se le pide responder
 las preguntas que
 se le formulan a continuación, fundamentando cada respuesta con los cálculos pertinentes,
 en el caso que
 corresponda. Cuando deba usar tasas de interés en porcentaje ocupe dos decimales (por
 ejemplo 13,75%).
 Preguntas:
 1. Calcule el valor económico del patrimonio de Lavanda S.A.
 2. Los accionistas minoritarios han solicitado al directorio de Lavanda S.A. que la empresa
 emita bonos de
 carácter perpetuo, por un total de $10.000 millones y que simultáneamente este dinero
 sea repartido
 íntegramente a los accionistas como un dividendo extraordinario. Los bonos perpetuos permitirían
 que la
 compañía sólo pagara intereses anuales por $600 millones de manera indefinida (6% anual
 de interés a
 perpetuidad) sin necesidad de devolver el capital ($10.000 millones). De esta manera,
 la empresa quedaría
 con una deuda permanente de $10.000 millones, que dejaría a Lavanda S.A. con un
 endeudamiento
 absolutamente razonable para los estándares de la industria donde opera la compañía.
 El presidente del directorio de Lavanda S.A., coincide con los accionistas minoritarios en que un
 endeudamiento permanente de $10.000 millones es prudente, ya que llevaría a una razón (Deuda /
 Patrimonio) muy inferior a la que exhiben actualmente la mayoría de sus competidores más
 cercanos. Sin
 embargo, le preocupa el efecto que podría tener la operación anterior, ya que él ha escuchado
 que el
 endeudamiento hace más volátiles los flujos de caja de los accionistas, lo cual podría afectar
 negativamente
 el valor económico del patrimonio y la riqueza de los accionistas.
 Para poder tomar una decisión, el presidente del directorio de Lavanda S.A. lo contrata
 a Ud. para que lo
 asesore respecto de los potenciales efectos que podría tener, para los actuales accionistas
 de la empresa, la
 operación antes descrita, (emisión de bonos perpetuos por $10.000 millones y el reparto
 simultáneo de un
 dividendo extraordinario por idéntico monto a los accionistas). En concreto, el presidente
 le solicita a Ud.
 que calcule el valor económico que tendrá la compañía inmediatamente después
 de la operación anterior y
 que señale el impacto que dicha operación tendrá en la riqueza de los actuales accionistas
 Fundamente su
 respuesta mostrando los cálculos correspondientes.
 3. Otro director de la compañía expresó su preocupación por el efecto que podría tener
 la operación descrita
 en el número (2) anterior en el costo de capital de la empresa. Según sus palabras, “una
 mayor volatilidad
 de los flujos de caja de los accionistas unido a un eventual deterioro patrimonial,
 podrían causar un
 aumento en el costo de capital de Lavanda S. A., con el consiguiente impacto
 en la riqueza de los dueños”.
 Por su parte, el gerente general de la compañía respondió a este director señalándol
 e que, a su juicio, “la
 operación de emisión de deuda y reparto simultáneo de dividendos no debiera
 tener ningún impacto en el
 costo de capital de la compañía, ya que se trata de un cambio en el lado
 derecho del balance que no afecta
 12
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 83

[pág. 84]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2025 | pregunta 6
 Convocatoria 2 | página original 450 | Bonos/renta fija
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 en absoluto a los activos de la empresa. En consecuencia, desde el punto de vista operaciona
 l, la compañía
 sigue operando en el mismo negocio y por lo tanto se debiera mantener sin
 cambios el costo de capital.
 ¿Está Ud. de acuerdo con lo expresado por el director de la empresa
 0 más bien con lo que sostiene el
 gerente general de la compañía? Justifique su respuesta ya sea de manera conceptual
 o numérica. Si Ud. no
 está de acuerdo con ninguno de ellos (director o gerente general), explique
 su punto de vista entregando los
 fundamentos correspondientes ya sea de manera conceptual o numérica.
 13
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 84

[pág. 85]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2023 | pregunta 6
 Convocatoria 2 | página original 400 | CDS, beta y arbitraje
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA Nº 6
 Un credit default swap (CDS) es un instrumento financiero que funciona como un seguro de crédito, en el sentido
 que paga al tenedor de este seguro cuando alguien que debe dinero (normalmente llamado el deudor), deja de
 pagar sus deudas. La diferencia con un seguro de crédito estándar es que no es necesario ser acreedor (es decir,
 que a uno le deban dinero) para comprarlo. Un CDS puede ser comprado por cualquier inversionista, sea o no
 acreedor de ese deudor. Se transforma así en un instrumento derivado donde los pagos son contingentes al
 comportamiento de un deudor (básicamente, si paga sus deudas o no). Por lo tanto, como muchos instrumentos
 derivados, puede ser comprado para fines de cobertura o por especulación.
 Puede decirse que el comprador del CDS es el asegurado y el emisor del CDS es el asegurador. El asegurado debe
 pagar periódicamente una prima por este seguro. En caso de que el deudor suspenda sus pagos, el asegurado
 recibe del asegurador el monto impago de la deuda. La prima del CDS se mide en centavos de dólar a pagar (en
 base anual) por cada $100 dólares asegurados. Por ejemplo, el CDS del bono soberano1 chileno en el gráfico
 adjunto alcanzó una prima de poco más de 300 durante la crisis financiera de 2008-2009, es decir, para asegurar
 $100 dólares de deuda chilena se tenían que pagar 300 centavos o 3 dólares como prima.
 CDS Bonos Soberanos Chile
 350,00
 300,00
 250,00
 200,00
 150,00
 100,00
 50,00
 0,00
 En el caso de los bonos soberanos, el CDS es muchas veces usado como un termómetro del riesgo de crédito de
 un país. Un aumento del CDS es interpretado como una mala señal, usualmente como un aumento en la
 probabilidad de no pago de la deuda soberana. Asuma que las suspensiones de pago (o defaults) de bonos
 soberanos tienden a ocurrir en periodos recesivos o de bajo crecimiento a nivel mundial, y de manera coordinada,
 es decir, es frecuente que varios países simultáneamente suspendan pagos de su deuda.
 Sobre la base de la información que se le ha presentado, responda las preguntas que se le formulan a continuación
 entregando los fundamentos correspondientes:
 PREGUNTAS
 a) Suponga que usted compra un portafolio de CDS de bonos de varios países emergentes. ¿Como debería ser
 el beta del CAPM (o beta de mercado) de los flujos asociados a este portafolio de CDS? Si combina este
 portafolio de CDS’s con un portafolio de bonos soberanos de países emergentes, ¿qué debería ocurrir con el
 beta de su portafolio combinado? Justifique sus respuestas.
 1 Un bono soberano es un título de deuda emitido por el gobierno de un país.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 85

[pág. 86]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2023 | pregunta 6
 Convocatoria 2 | página original 401 | CDS, beta y arbitraje
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 b) Dado que el CDS funciona como un seguro, la compra de este instrumento permite “quitar” el riesgo de
 crédito a un bono soberano. Seguirá existiendo riesgo de mercado o riesgo de tasa, pero, en principio,
 comprar un CDS hace al bono soberano de cualquier país igual de seguro que el bono emitido por EE.UU.
 (asumiendo que EE.UU. es un emisor libre de riesgo de crédito). En consecuencia, debería existir una
 relación de arbitraje entre la tasa de un bono soberano chileno (𝑦 ), la prima del CDS (𝑟 ), y la tasa del
 bono del Tesoro de EE.UU. (𝑦 , considerando un bono de EE.UU. al mismo plazo, moneda y otras
 condiciones contractuales que el bono chileno. ¿Cuál debiera ser la relación de arbitraje que debiera
 cumplirse? Explique la intuición de esta relación y los supuestos utilizados.
 c) ¿Qué fricciones podrían explicar que no se cumpliera la relación de arbitraje sugerida por Ud. en (b) en la
 práctica? ¿En qué condiciones de mercado esperaría Ud. que fuera más probable que no se cumpliera la
 relación encontrada en (b)? Sea breve y preciso.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 86

[pág. 87]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2020 | pregunta 6
 Convocatoria 1 | página original 313 | Correlación y cobertura cambiaria
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA Nº6
 Está ampliamente documentado que en países afectados por crisis, como el estallido social ocurrido en Chile
 en octubre de 2019, se producen fuertes caídas en la bolsa local y una depreciación del tipo de cambio
 (típicamente medido como la moneda local versus el dólar estadounidense).
 La tabla que se presenta más abajo ilustra lo antes señalado mostrando el comportamiento mensual de los
 siguientes indicadores financieros para el período septiembre – diciembre del año 2019:
  Retorno del índice accionario IPSA en pesos chilenos (CLP), que agrupa a las principales acciones
 que se transan en la bolsa chilena.
  Retorno del índice accionario S&P500 en pesos chilenos (CLP). Este índice incluye a las principales
 acciones que se transan en la bolsa de EE.UU. Normalmente los retornos del índice S&P500 se miden
 en dólares estadounidenses (USD). Sin embargo, las rentabilidades en USD del S&P500 fueron
 transformadas a CLP para facilitar la comparación directa con el IPSA.
  Variación del tipo de cambio (pesos chilenos por dólar estadounidense).
 Retorno IPSA Retorno S&P500 Variación Tipo
 Mes (en CLP) (en CLP) Cambio (CLP/USD)
 Sep-19 5,30% 2,38% 0,66%
 Oct-19 -6,22% 2,40% 0,36%
 Nov-19 -4,33% 11,10% 7,70%
 Dic -19 2,89% 2,07% -1,90%
 Suponga que las volatilidades históricas de los retornos del IPSA (en CLP) y del S&P500 (tanto en USD como
 en CLP) son similares en magnitud. Suponga que la volatilidad es medida como la desviación estándar de los
 retornos. La tabla anterior se le entrega sólo para ilustrar la dirección de los movimientos de las distintas
 variables en un periodo de crisis.
 A usted se le pide contestar las preguntas que se le formulan a continuación entregando los fundamentos
 conceptuales sobre los cuales basa su respuesta. No es necesario hacer cálculos para responder.
 a) ¿Cree usted que un portafolio en el cual se invierte el 50% de los recursos en el IPSA y el 50% restante en
 el S&P500 tendría mayor o menor volatilidad, medida en pesos chilenos (CLP), que una cartera en la cual se
 invierte el 100% de los recursos en el IPSA? ¿Por qué?
 b) Suponga que usted es un inversionista chileno que tiene una cartera en la cual el 50% de los recursos están
 invertidos en el IPSA y el 50% restante en el S&P500. Como la inversión en el S&P500 está expuesta a la
 variación del tipo de cambio, usted está evaluando la posibilidad de cubrir el riesgo cambiario utilizando
 derivados (forwards o futuros de dólar). Pensando únicamente en términos de volatilidad, medida en CLP, ¿es
 conveniente contratar derivados cambiarios para el portafolio 50% IPSA y 50% S&P 500 o sería mejor no
 hacerlo? ¿Por qué?
 c) Suponga que usted tiene un portafolio con el 100% de los recursos invertidos en el IPSA y está considerando
 adicionalmente la posibilidad de contratar futuros o forwards de dólares estadounidenses. ¿Cómo se vería
 afectada la volatilidad de su cartera si usted mantuviera permanentemente una posición “corta” en futuros, es
 decir, si estuviera vendiendo dólares a futuro? ¿Cambiaría su respuesta anterior si usted mantuviera
 permanentemente una posición “larga” en futuros, es decir, si estuviera comprando dólares a futuro?
 Fundamente sus respuestas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 87

[pág. 88]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2012 | pregunta 5
 Convocatoria 1 | página original 96 | Curva de tasas, spreads y duración
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº5
 La Tabla N° 1 que se presenta a continuación muestra los datos de la estructura de tasas (o curva de rendimiento)
 actualmente vigente en el mercado nacional, para bonos en pesos cero cupón clasificados en categoría de riesgo A:
 TABLA N° 1
 Plazo faltante para el Tasa de interés
 vencimiento (años) anual de mercado
 1 año 3,5%
 2 años 4,0%
 3 años 4,5%
 4 años 5,0%
 Las tasas de mercado que aparecen en la columna de la derecha de la Tabla anterior, corresponden a la las llamadas tasas
 spot anuales o rendimiento anual exigido actualmente (hoy) en el mercado, a bonos en pesos, cero cupón, cuya clasificación
 de riesgo es A y cuyo vencimiento ocurre al final de alguno de los próximos 4 años. Por ejemplo, a un bono en pesos cero
 cupón, con categoría de riesgo A, que expira en tres años más, los inversionistas le exigen hoy en el mercado un rendimiento
 del 4,5% anual.
 Suponiendo que no hay inflación ni impuestos y que el mercado nacional de bonos es eficiente en su forma semi - fuerte, a
 Ud. se le pide responder las tres preguntas que se le formulan a continuación, presentando los argumentos conceptuales
 que corresponda. Para todos los efectos prácticos, cuando se trate de un bono cero cupón (en $), suponga que dicho bono
 tiene un único pago de $1.000 al momento de su vencimiento
 1) Una empresa está pensando emitir bonos en pesos ceros cupón, que vencen en 4 años más, y que tendrían una
 clasificación de riesgo en categoría A. Para estos efectos, la empresa está evaluando utilizar una de las siguientes dos
 alternativas de financiamiento:
 Alternativa 1:
 Emitir bonos cero cupón en pesos, con un plazo de vencimiento de 4 años, en las condiciones de mercado actualmente
 vigentes (tasa de mercado igual a 5% anual).
 Alternativa 2:
 Seguir una estrategia de roll over, con vencimientos anuales, que consiste en que la empresa emite bonos cero cupón en
 pesos, a un año plazo, en las condiciones de mercado actualmente vigentes (tasa de mercado igual a 3,5% anual).
 Transcurrido el año, los bonos son íntegramente pagados con una nueva emisión de bonos a un año plazo, en las
 condiciones de mercado que estén vigentes en esa fecha, y así sucesivamente hasta llegar al final del 4° año.
 Al examinar ambas alternativas de financiamiento el Gerente de Finanzas de la empresa declaró: “Dado que la curva de
 rendimiento tiene pendiente positiva, es obvio que nos conviene utilizar la segunda alternativa de financiamiento, ya que las
 tasas de corto plazo son bastante menores que las tasas de largo plazo.” ¿Está Ud. de acuerdo con la afirmación del Gerente
 de Finanzas? Explique conceptualmente por qué. En su análisis suponga que las dos estrategias de financiamiento le
 permiten recaudar hoy la misma cantidad de recursos a la empresa y que ambas opciones tienen los mismos costos de
 transacción.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 88

[pág. 89]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2012 | pregunta 5
 Convocatoria 1 | página original 97 | Curva de tasas, spreads y duración
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 2) Suponga ahora que los datos de la estructura de tasas (curva de rendimiento) para bonos en pesos cero cupón libres de
 riesgo, actualmente vigentes en el mercado, son los que se muestran a continuación en la segunda columna (de izquierda a
 derecha) en la Tabla N° 2:
 TABLA N° 2
 Tasa de interés Tasa de interés Spread
 Plazo faltante para el anual de mercado anual de mercado
 (Diferencia de
 vencimiento (años) Bonos libre de Bonos categoría riesgo A rendimientos)
 riesgo
 1 año 2,5% 3,5% 1,0%
 2 años 2,9% 4,0% 1,1%
 3 años 3,2% 4,5% 1,3%
 4 años 3,5% 5,0% 1,5%
 Como se puede apreciar en la Tabla N° 2, los datos de la estructura de tasas (o curva de rendimiento) muestran que el
 “spread” (diferencial) de tasas entre bonos cero cupón categoría de riesgo A y bonos cero cupón libres de riesgo, va
 aumentando en el tiempo (parte en 1% hasta llegar a 1,5% en los bonos cero cupón que expiran en 4 años más) ¿Es esta
 situación de aumento en el spread motivo de arbitraje financiero? ¿Qué factores podrían explicar el aumento del spread?
 Explique claramente sus respuestas a estas dos preguntas.
 3). Una persona está analizando la posibilidad de invertir $987,69, a un año plazo, comprando bonos de empresas que sean
 grado de inversión (esto es, cuya clasificación de riesgo sea BBB o superior). Después de un exhaustivo análisis, esta
 persona ha concluido que los papeles más atractivos para invertir son los bonos de las empresas A y B, cada uno de los
 cuales se transa actualmente en el mercado a un precio de $987,69 y cuyas principales características financieras son las
 siguientes:
 Bono Valor de Tasa de Precio
 Pagos del bono al final del: TIR (*)
 Empresa Carátula Carátula Mercado
 Año 1 Año 2 Año 3
 A $ 1.000 10% $ 500 $ 460 $ 220 $ 987,69 10,8%
 B $ 1.000 8,3% $ 83 $ 1.083 --- $ 987,69 9,0%
 (*): Tasa de interés anual a la cual el valor presente de los flujos de caja del bono es igual al precio.
 Suponga ahora que la persona que comprará el bono tiene como objetivo fundamental minimizar la volatilidad de los
 retornos de su inversión (proveniente de las eventuales fluctuaciones en las tasas de mercado). Para cumplir con este
 objetivo, la persona consulta un asesor que le recomienda comprar el bono de la empresa B, ya que al tener un menor plazo
 que el de la empresa A (2 años versus 3 años), su precio será menos sensible a las fluctuaciones en las tasas de interés. Dado
 el objetivo del comprador del bono, ¿está Ud. de acuerdo con la recomendación del asesor?. Fundamente conceptualmente
 su respuesta, suponiendo que ambos bonos se transan activamente en el mercado e ignore cualquier consideración de riesgo
 de crédito.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 89

[pág. 90]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2014 | pregunta 6
 Convocatoria 1 | página original 147 | Deuda, estados y debt overhang
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 PREGUNTA N* 6
 BLIR es una empresa manufacturera nacional que últimamente ha tenido algunos problemas financieros. La
 compañía tiene actualmente (en t = 0) activos que generan un único flujo de caja en un período más (t = 1) que es
 incierto, por cuanto depende de la situación económica que se dé en el país. Según las estimaciones de la empresa,
 dicho flujo puede tomar sólo dos valores: $100 millones en un escenario de alto crecimiento del PIB o $40
 millones si el crecimiento del PIB es bajo. Cada uno de estos escenarios tiene una probabilidad de ocurrencia del
 50%, Los activos de BLIR están parcialmente financiados con deuda bancaria, cuyo valor libro (valor de carátula)
 es de $50 millones.
 Los acreedores de la empresa (bancos) están evaluando la posibilidad de pedir la quiebra de BLIR, lo cual exige
 una serie de formalidades de tipo legal que culminan finalmente en el nombramiento, por parte de los tribunales
 de justicia, de un síndico que se encarga de liquidar (vender) en forma ordenada los activos de la empresa y de
 pagar a los acreedores lo que se recaude en dicha liquidación. El proceso de quiebra tiene un costo esperado de $5
 millones que deben ser pagados hoy (t = 0) por quien solicita la quiebra (acreedores de BLIR).
 Suponiendo que:
 * No hay inflación ni impuestos.
 * Ladeuda de BLIR está pactada con una tasa de interés igual a cero y se debe pagar en t = 1.
 * Latasa de descuento relevante para evaluar cualquier proyecto es igual a cero.
 * _ Los activos y pasivos de la empresa no generan flujos de caja después del próximo período (no hay flujos
 de caja en t=2,t=3, etc.).
 A usted se le pide responder las preguntas que se le formulan a continuación:
 Pregunta A
 Si el valor de liquidación de los activos de BLIR fuera hoy (t = 0) igual a $52 millones, ¿le convendría a los
 acreedores pedir la quiebra de la empresa? Justifique su respuesta mostrando los cálculos necesarios,
 Suponga ahora, y esto es válido solamente para los efectos de responder las preguntas n” 2 y 3 que se formulan
 más abajo, que los acreedores de BLIR acuerdan no solicitar la quiebra de la compañía ya que los ingenieros de la
 empresa acaban de desarrollar una tecnología que le permitirá a BLIR, cualquiera sea el escenario económico que
 finalmente prevalezca, aumentar el próximo período los flujos de caja netos generados por los activos en $10
 millones. Para llevar a cabo este proyecto de implementación de la nueva tecnología, la empresa tendría que
 invertir hoy (t = 0) la suma de $3 millones, que sería financiada íntegramente con aportes de capital de los
 actuales accionistas de BLIR.
 Pregunta B
 Desde un punto de vista financiero, ¿conviene a los actuales dueños de BLIR llevar a cabo el proyecto de
 introducción de la nueva tecnología? Explique por qué exhibiendo todos los cálculos pertinentes.
 Pregunta C
 Suponga que la empresa fuera informada hoy (en t = 0) que las probabilidades de que ocurran los escenarios de
 alto y bajo crecimiento del PIB cambian a 25% y 75% respectivamente y que los flujos de caja de los activos de
 BLIR el próximo período (t = 1) para cada escenario fueran los mismos ($100 millones y $ 40 millones). El
 Gerente de Finanzas de la empresa sostiene que: “dado que el proyecto que introduce la nueva tecnología genera
 (en t = 1) flujos de caja de $10 millones en cualquier escenario de crecimiento del PIB, este cambio en las
 probabilidades no tiene ningún impacto en la conclusión a la que Ud. llegó en la Pregunta B anterior” ¿Está Ud.
 de acuerdo con esta aseveración? Fundamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 90

[pág. 91]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2017 | pregunta 6
 Convocatoria 2 | página original 250 | Deuda, patrimonio y estados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA N” 6
 El pasado mes de junio (2017) el Banco Santander adquirió por un simbólico euro (1 EUR) la propiedad del
 Banco Popular en España, El Banco Popular había experimentado fuertes pérdidas por préstamos inmobiliarios
 a partir de la crisis europea desatada el 2008. El Banco Popular era el sexto banco más importante de España,
 en términos de colocaciones (préstamos), y había sido una buena inversión para sus accionistas hasta antes de
 la venta al Banco Santander, la cual fue, en todo menos en nombre, una quiebra,
 El objetivo de esta pregunta es entender las decisiones de financiamiento de una institución con una
 probabilidad de quiebra no despreciable en el corto plazo como puede haber sido el Banco Popular a comienzos
 del año 2017. A continuación se presenta un ejemplo numérico muy sencillo, pero que tiene como objetivo
 capturar los principales elementos presentes en un caso como el del Banco Popular. Suponga que no hay
 impuestos corporativos y que el mercado de capitales es eficiente en el sentido de que los precios entregan una
 compensación adecuada por el riesgo contenido en los flujos futuros.
 Sitúese al día 31 de diciembre de 2016 evaluando la situación financiera del banco. Suponga que la cartera de
 préstamos del Banco Popular puede entregar flujos (todos en millones de euros) de $120 o de $60 en 6 meses
 más (30 de junio de 2017), dependiendo de cómo evolucione la situación económica general de España. Usted
 estima que la probabilidad de ocurrencia de cada escenario es de 50%. La tasa de retorno esperada (0 tasa de
 descuento exigida) para igual periodo (6 meses) de esta cartera de préstamos es de Ra = 10%. En términos de
 sus pasivos, el banco está financiado con una cartera de deuda (una combinación de depósitos, bonos y otros
 instrumentos de deuda) con valor de carátula (o pago total prometido a futuro) de $80 y una tasa de retorno
 esperado (o tasa de descuento exigida) de Rd =2%, todo a un plazo de 6 meses. El resto del financiamiento
 del Banco Populax corresponde a capital accionario.
 Para las preguntas que se le formulan a continvación, suponga que las tasas de retorno exigidas a los activos y
 a la deuda del banco no cambian y que la información sobre los pagos futuros es sabida por todo el mercado,
 incluyendo acreedores y accionistas. En cada pregunta, fundamente sus respuestas mostrando todos los
 cálculos que sean necesarios.
 PREGUNTAS
 1) Con la información que se le ha proporcionado, ¿cuánto vale el capital accionario del Banco Popular al
 31-12-2016? ¿Qué tasa de retorno esperada a 6 meses tiene dicho capital accionario?
 2) Un director del Banco Popular sugiere en la junta de cierre de año que, para aprovechar mejor las bajas
 tasas de interés que se observan en Europa, sería más conveniente aumentar el financiamiento con deuda.
 En concreto, el director propone aumentar la denda del banco hasta un valor (de carátula) de $90 y
 recomprar acciones con lo obtenido sin afectar la cartera de préstamos. Según el director, esto permitiría
 aumentar el valor económico total del banco (deuda + capital accionario). ¿Qué opina usted al respecto?
 ¿Cambia la riqueza de los accionistas con la operación propuesta por el director? ¿Cambia el retorno
 esperado del capital accionario del banco?
 3) Suponga ahora que, el 1* de enero 2017, las perspectivas sobre la cartera de préstamos del banco se
 deterioran sorpresivamente de tal manera que el flujo en el escenario positivo 6 meses después pasa a ser
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 91

[pág. 92]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2017 | pregunta 6
 Convocatoria 2 | página original 251 | Deuda, patrimonio y estados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 solo $91. En el escenario negativo el flujo sigue siendo $60. Respecto de la situación vigente al 31-12-
 2016 ¿qué ocurre con el valor del capital accionario del banco si la deuda tiene un valor carátula de $80?
 4) Un analista de mercado dice que el valor del capital accionario del Banco Popular, después de conocerse
 el deterioro de la cartera de préstamos el 1% de enero 2017, está excesivamente castigado porque no
 considera el valor de la opción de los préstamos en carpeta (préstamos que el banco podría hacer pero que
 todavía no se han materializado). Argumenta que el banco podría fácilmente, con un aporte (aumento) de
 capital de $6, aumentar su cartera de colocaciones haciendo préstamos de igual riesgo que los actuales y
 que darían flujos, 6 meses después, de $11 en el escenario positivo y $10 en el escenario negativo. El
 mismo analista opina que, frente a estos buenos proyectos en carpeta, un aumento de capital es solo
 frenado por la inoperancia de los actuales accionistas controladores, ¿Está Ud. de acuerdo con la
 afirmación del analista? Fundamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 92

[pág. 93]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2011 | pregunta 6
 Convocatoria 2 | página original 83 | Diversificación y tipo de cambio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA Nº6
 Desde hace algunos años, el Fisco de Chile sigue la llamada regla de “balance estructural”, que consiste en gastar un
 máximo igual a los “ingresos estructurales de largo plazo” del Estado de Chile. En el caso chileno, los ingresos fiscales
 dependen fundamentalmente de dos variables claves: el crecimiento del PIB, que determina los ingresos no-mineros, y el
 precio del cobre, que determina los ingresos mineros.
 Para calcular el nivel de los ingresos estructurales de largo plazo, hay un panel independiente de expertos que pronostica
 las variables claves (precio del cobre y crecimiento del PIB), y sobre esa base se determina cuánto es lo que el Fisco
 puede gastar cada año. De este modo, si en un año determinado el precio del cobre y/o el crecimiento del PIB son
 mayores que sus valores de largo plazo (estimados por el panel de expertos), el Fisco gastará menos que sus ingresos
 corrientes (porque los ingresos estructurales son menores a los ingresos corrientes y lo que no se gasta, se ahorra). Por el
 contrario, si en un año cualquiera se producen variaciones adversas en las variables claves (precio del cobre y/o
 crecimiento del PIB), entonces el Fisco gastará más que sus ingresos corrientes, porque los ingresos estructurales son
 mayores a los ingresos corrientes.
 Para poder cubrir gastos mayores a los corrientes en épocas adversas, el Estado de Chile ha constituido un Fondo de
 Estabilización, llamado FEES. Por ley este fondo debe ser invertido en activos financieros fuera de Chile y será utilizado
 cuando los ingresos corrientes fiscales sean menores que los ingresos estructurales de largo plazo.
 Tomando como referencia el contexto anterior y utilizando conceptos de teoría financiera, a usted se le pide responder,
 en forma breve y precisa, las preguntas que se formulan a continuación. Para simplificar, considere un horizonte de
 inversión de un año.
 1. Un reconocido analista sostiene que: “el Fondo de Estabilización (FEES) debiera invertirse en bonos de gobiernos
 de países desarrollados que tengan la mejor clasificación de riesgo a nivel mundial (AAA). En efecto, desde la
 perspectiva del Estado (Fisco) de Chile, la inversión de los recursos del FESS en bonos de gobierno de países tales
 como EE.UU., Alemania, Francia, etc. es libre de riesgo”. ¿Está Ud. de acuerdo con la afirmación del analista?
 Fundamente su respuesta.
 2. Desde la perspectiva del Estado (Fisco) de Chile ¿cómo debería comportarse un portafolio de bajo riesgo? Sea
 explícito en su respuesta y mencione las fuentes de riesgo que el Estado chileno debiera intentar cubrir con la
 inversión de los recursos del FEES en dicho portafolio.
 3. Suponga que el gasto fiscal al final del período será G = I + F(1 + RP), donde:
 I es el ingreso fiscal efectivo del año, el cual es aleatorio;
 F el saldo inicial del Fondo de Estabilización (FEES), conocido con certeza;
 RP es la rentabilidad esperada del portafolio P en el que se invertirá el FEES;
 F(1+RP) es el valor del FEES al final del período.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 93

[pág. 94]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2011 | pregunta 6
 Convocatoria 2 | página original 84 | Diversificación y tipo de cambio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 Suponga además que RP = wRA + (1 - w)RB, donde w es la fracción (%) invertida en bonos de gobiernos de países
 con clasificación de riesgo AAA, cuya rentabilidad esperada en pesos es RA y RB es la rentabilidad esperada en pesos
 de otro activo financiero en el cual se podría invertir una parte del FEES. Las variables I, RA y RB siguen una
 distribución normal conjunta.
 Finalmente suponga que el Estado de Chile tiene una alta aversión al riesgo y por lo tanto desea minimizar la
 volatilidad (medida como varianza) del gasto fiscal (G). Para lograr este objetivo, un conocido asesor financiero
 sostiene que es suficiente con hacer mínima la varianza del portafolio P, que es el portafolio en el cual estarán
 invertidos los recursos del FEES.
 ¿Está Ud. de acuerdo con la afirmación de este asesor? Explique por qué, y presente la expresión matemática que
 debiera considerarse para lograr el objetivo de minimizar la volatilidad (varianza) del gasto fiscal G.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 94

[pág. 95]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2015 | pregunta 6
 Convocatoria 1 | página original 170 | Eficiencia de mercado y fondos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA N' 6
 En Chile las personas con contrato de trabajo formal deben cotizar (0 imponer) mensualmente una fracción
 de sus ingresos en una Administradora de Fondos de Pensiones (AFP), que son las entidades encargadas de
 invertir los ahorros previsionales de la manera más eficiente posible, para que los cotizantes (o afiliados)
 obtengan buenas pensiones cuando llegue el momento de jubilar. >
 Desde el año 2002, las AFP ofrecen cinco Fondos de Pensiones que los afiliados (o cotizantes) pueden elegir
 para invertir sus ahorros previsionales, Estos Fondos difieren entre sí en el porcentaje de inversión que ellos
 pueden destinar a instrumentos de renta variable e instrumentos de renta fija. Es así como el Fondo A (más
 riesgoso) puede invertir, como máximo, hasta un 80% de los recursos captados en renta variable y el saldo
 restante en renta fija, mientras que el Fondo E (más seguro) sólo puede invertir, como máximo, hasta un 5%
 en renta variable, En la práctica, los Fondos de Pensiones se invierten en porcentajes cercanos al. tope
 máximo en renta variable.
 “El Cuadro N* 1 que se exhibe a continuación, muestra las principales características de los tipos de Fondos
 de Pensiones antes señalados:
 Cuadro N* ]
 Tipo de Fondo l;/o Máxim9 en | % Mínim9_ en Retorn—(za) Volatilit?gd
 enta Variable | Renta Fija Anual Anual
 A 80% 20% 6,99% 6,12%
 B 60% — 40% 5,85% 4,33%
 C 40% 60% 5,22% 2,83%
 D 20% 80% 4,71% 1,58%
 E 5% 95% 3,95% L11%
 (a): Rentabilidad real promedio anual desde septiembre de 2002 — mayo de 2013
 (b): Desviación estándar de los retornos reales entre septiembre-2002 y mayo 2013.
 En los últimos años se ha observado un creciente número de personas que cambian sus ahorros previsionales
 desde un Fondo a otro con la expectativa de conseguir mayores rendimientos. Parte importante de estos |
 cambios están motivados por recomendaciones que hacen asesores no regulados que entregan “alertas” de
 E
 cambio de Fondos, esto es, una sugerencia de trasladar los ahorros desde un determinado Fondo de
 Pensiones a otro, con la promesa de mayores rendimientos.
 Una de las empresas asesoras más conocidas en el rubro es CSN, la cual opera a través de un sitio web y
 cuenta con un volumen significativo de suscriptores, a quienes les ha prometido rendimientos muy atractivos
 y una fórmula que evitaría pérdidas en tiempos de crisis económicas. Los suscriptores de CSN deben pagar
 todos los meses un honorario por tener acceso a las recomendaciones de la empresa.
 El Cuadro N* 2 que se exhibe a continuación, es un ejemplo de recomendaciones efectuadas por CSN en
 distintas fechas, para que los cotizantes trasladen sus ahorros previsionales desde el Fondo A al Fondo E y
 viceversa. Por ejemplo, en la recomendación n” 1, hecha con fecha 27-07-2011, CSN sugiere a sus clientes
 cambiar su ahorro previsional desde el Fondo A al E; en la recomendación n? 2, de fecha 12-10-2011, la
 sugerencia de CSN a sus clientes suscriptores es que muevan sus fondos previsionales desde el Fondo Eal A
 y así sucesivamente. La cuarta columna del Cuadro (Retorno CSN) muestra los rendimientos (retornos)
 acumulados que hubiera obtenido un afiliado, entre la fecha de la recomendación y el 31 de mayo de 2013, si
 hubiera seguido las sugerencias de cambio de Fondos hechas por CSN desde esa fecha en adelante. Estos
 rendimientos acumulados se comparan con los obtenidos por el promedio de las AFP para el Fondo A y el
 Fondo E en el mismo período (columnas 5 y 6 respectivamente):
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 95

[pág. 96]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2015 | pregunta 6
 Convocatoria 1 | página original 171 | Eficiencia de mercado y fondos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 ; Cuadro NC 2
 Rend¡m1entos Acumulados desde la Fecha de Recomendación de Cambio de Fondos al 31/05/13
 «
 No dé Fecha de la Recomendación de | Retorno | Retorno | Retorno
 Recomepdación Recomendación Cambio de Fondos CSN | Fondo A | Fondo E
 . NA 27-07-2011 A-->E 180% | 72% | 12,9%
 C 12-10-2011 E-->A — | 141% | 173% | 9,2%
 - e N93 22-11-2011 A-->E 14,5% | 17,7% | 10,1%
 1, N 10-01-2012 E-->A 1224 | 13,0% | 7,8%
 SFOnos 29-03-2012 A-->E 53% | 60% | 71%
 - N* 6 19-06-2012 E-->A 34% | 11,1% | 5,2%
 N*7 28-06-2012 A-->E 24% | 101% | 4,7%
 Ne 8 19-07-2012 E-->A 25% | 11746 | 4,8%
 N*9 29-08-2012 A-->E 29% | 1272% 3,8%
 N* 10 02-01-2013 E-->A 1,8% 3,8% 2,7%
 N* 11 03-04-2013 A-->E 12% | 32% 12%
 De la lectura del Cuadro N 2, se desprende que un cotizante que cambia sus ahorros previsionales desde el
 Fondo A al E el 27-07-11 (fecha de la recomendación n” 1 de CSN en la que se sugiere dicho cambio),
 acumularía un rendimiento del 18% entre esa fecha y el 31-05-13 si sigue las 10 recomendaciones restantes
 que CSN hace de allí en adelante. En ese mismo período, el rendimiento acumulado que tuvieron los Fondos
 de Pensiones A y E que manejan las AFP fue de 7,2% y 12,9% respectivamente. Por otra parte, un afiliado
 que cambia sus ahorros previsionales desde el Fondo E al A el 12-10-11 (fecha de la recomendación n” 2 de
 CSN en la que se sugiere dicho cambio), obtiene un rendimiento acumulado del 14,1% entre esa fecha y el
 31-05-13 si sigue las 9 recomendaciones restantes que CSN hace de allí en adelante. Para ese mismo
 período, el rendimiento acumulado de los Fondos A y E fue de 17,3% y 9,2% respectivamente. Y así -
 sucesivamente.
 Sobre la base de la información que aquí se le ha entregado, responda las siguieñtes preguntas:
 PREGUNTAS
 1) ¿Son coherentes los resultados que obtendría un afiliado, que siguiera las recomendaciones de CSN, con
 la hipótesis de mercados eficiente en su forma semi - fuerte? Fundamente su respuesta.
 2) Los directivos de CSN han argumentado que la estrategia de inversión que ellos recomiendan no
 necesariamente busca aumentar la rentabilidad para el cotizante sino que también acotar el nivel de riesgo de
 su inversión. Aunque el modelo que fundamenta las recomendaciones de CSN no es-público, hay evidencia
 de que se basa en el desempeño reciente que han tenido los Fondos de Pensiones que administran las AFP,
 Dicho modelo permitiría a CSN recomendar a sus suscriptores estrategias de inversión para que trasladen sus
 ahorros previsionales, por ejemplo, desde el Fondo A (más riesgoso) al E (menos riesgoso), en períodos
 donde se anticipa que la economía no andará bien y viceversa.
 2a) Desde la perspectiva de un añliado conservador, que normalmente pondría sus ahorros previsionales en
 el Fondo E, ¿será exitoso seguir una estrategia de inversión como la que sugiere CSN (ir cambiando los
 ahorros desde el Fondo A al E o viceversa, según las circunstancias), para aumentar la rentabilidad esperada
 y disminuir el riesgo? Explique por qué fundamentando su respuesta.
 2b) Desde la perspectiva de un cotizante agresivo, que usualmente pondría sus ahorros previsionales en el
 Fondo A, ¿será exitoso seguir una estrategia de inversión como la que sugiere CSN (ir cambiando los
 ahorros desde el Fondo A al E o viceversa, según las circunstancias), para aumentar la rentabilidad esperada
 y disminuir el riesgo? Explique por qué entregando los argumentos necesarios.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 96

[pág. 97]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2019 | pregunta 6
 Convocatoria 2 | página original 300 | Flujo residual y valor del equity
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA N"6
 El grupo empresarial representado por la sociedad de inversiones CHINVEST S.A. está considerando comprar
 la compañía de seguros de vida de rentas vitalicias For Ever Young S.A. (FEYSA). Las rentas vitalicias son
 equivalentes a un bono emitido y garantizado por una compañía de seguros (FEYSA, en este caso), que es
 comprado por una persona a que se va a pensionar, con los ahorros acumulados en una AFP (Administradora
 de Fondos de Pensiones) durante su vida laboral, Las rentas vitalicias entregan al pensionado pagos mensuales
 iguales de por vida.
 FEYSA tiene en la actualidad activos financieros cuyo valor de mercado es de $1,000. Dichos activos tienen
 menor liquidez que otros activos financieros, pero son poco riesgosos y tienen una rentabilidad esperada anual
 y perpetua de 2,8%, El valor de mercado de los pasivos por rentas vitalicias de FEYSA (que es el único pasivo
 de la empresa) es de $900 y estos devengan un interés anual del 2,5% anual. Para simplificar, suponga que los
 pagos de las rentas vitalicias cesan al fallecer el pensionado, pero el pensionado fallecido es reemplazado por
 uno más joven, en las mismas condiciones financieras, manteniéndose los flujos de pasivos de FEYSA
 constantes en el tiempo de manera indefínida.
 Suponga que el mercado de capitales es perfecto, esto es, que no hay impuestos ni costos de transacción y que
 la información es gratis y está ampliamente disponible para todos los inversionistas. Suponga también que el
 único costo de operación de FEYSA es el pago de los pasivos por rentas vitalicias. Responda las preguntas
 que se le formulan a continuación:
 a) A partir de los fhujos de caja residuales disponibles para los accionistas, determine el máximo valor
 que CHINVEST estaría dispuesto a pagar por el 100% del patrimonio de FEYSA. Fundamente su
 respuesta mostrando todos los cálculos necesarios.
 b) La consultora extema KERCER cree que FEYSA no está aprovechando todo su potencial
 endeudamiento, ya que las compañías de seguros dedicadas al rubro de las rentas vitalicias pueden
 tener, sin problemas, un Jeverage (razón deuda / patrimonio medida con valores de mercado) de hasta
 20 veces. KERCER estima que con la situación actual, el costo de capital del patrimonio de FEYSA
 es de 5,5% anual y que, dado ese costo de capital, el valor económico del patrimonio (hoy) de la
 compañiía puede aumentar dependiendo del nivel de endeudamiento (no aprovechado) que se utilice,
 Por ejemnplo, si la compañía aumentara el leverage desde 9 a 15 veces, sólo requeriría un patrimonio
 de $60 en vez de $100, lo que liberaría $40 para los accionistas, dejando los pasivos en $900 y los
 activos en $960. Este flujo anticipado de $40 que recibirían hoy (en t = 0) los accionistas, más el valor
 presente de los flujos residuales que ellos recibirían desde t = 1 en adelante, de manera perpetua,
 permitiría incrementar el valor económico del patrimonio a $119,6. La Tabla N* 1 que se muestra a
 continuación, ilustra los resultados que se obtendrían al incrementar la razón (deuda / patrimonio):
 Tabla N* 1: Valor Económico del Patrimonio de FEYSA (cifras en pesos), para una rentabilidad
 esperada de los activos de 2,8% anual.
 Leverage Valor Económico del
 (Deuda / Patrimonio) Patrimonio
 9 100.0
 15 119.6
 20 127.0
 ¿Está Ud. de acuerdo en que el valor económico del patrimonio de FEYSA aumenta con el nivel de
 leverage? Fundamente su respuesta conceptual y numéricamente.
 Continúa en la página siguiente
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 97

[pág. 98]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2019 | pregunta 6
 Convocatoria 2 | página original 301 | Flujo residual y valor del equity
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 c) Un conocido analista de inversiones sostiene que el valor económico del patrimonio de FEYSA
 también podría incrementarse, sin cambiar el actual nivel de everage (9 veces) que tiene la compañía,
 si ésta invirtiera en activos que tuvieran una mayor rentabilidad esperada, tal como se muestra a
 continuación en la Tabla N* 2:
 -Tabla N? 2: Valor Económico del Patrimonio de FEY SA (cifras en pesos)
 Rentabilidad Anual Valor Económico del
 Esperada de los Activos Patrimonio
 2.80% - 100.0
 3.00% 136.4
 3.20% 172.7
 Suponiendo que se cumple la hipótesis de mercados eficientes ¿está Ud. de acuerdo en que al invertir
 en activos (instrumentos financieros) con mayor rentabilidad esperada, aumentará el valor económico
 del patrimonio de FEYSA? Fundamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 98

[pág. 99]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2012 | pregunta 6
 Convocatoria 2 | página original 112 | Fusión, pérdidas tributarias y canje
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 PREGUNTA Nº 6
 ELEKTRIKO es un grupo económico que ha estado en el rubro de la generación eléctrica desde el año 1965. Por mucho
 2
 tiempo este grupo ha tenido y mantenido en perfectas condiciones una central hidroeléctrica de pasada en el sur de Chile, la
 cual es operada por la empresa PASADA S.A., una compañía que es parte del mismo grupo. El único activo de PASADA
 S.A. es la central hidroeléctrica en cuestión, la cual provee flujos de caja sumamente estables, de $100 millones al año,
 después de impuestos ($125 millones antes de impuestos corporativos de un 20%). El balance contable de PASADA S.A.
 está compuesto actualmente por activos fijos por $999 millones y capital de trabajo neto de $1 millón. Todos los activos
 actuales de esta empresa son necesarios para operar la central. PASADA S.A. no tiene deuda y pertenece en un 100% al
 grupo ELECTRIKO.
 Hace unos años, el grupo ELEKTRIKO decidió llevar a cabo un proyecto de Energía Renovable no Convencional (ERNC)
 mediante el desarrollo de tecnología mareomotriz, que consiste en turbinas para generar electricidad activadas por la fuerza
 de las olas del mar. Para materializar este proyecto, el grupo creó una empresa filial que se llama MARELECTRICA S.A.
 reteniendo un 80% de la propiedad de MARELÉCTRICA, e invitó al accionista minoritario CHISPITA a participar con un
 20% de la propiedad. Utilizando solamente patrimonio, ELEKTRIKO y CHISPITA financiaron, a través de
 MARELÉCTRICA, un total de $390 millones de inversión en la tecnología mareomotriz, la que resultó en un total fracaso
 técnico y financiero. En la actualidad, el valor económico de los activos de MARELÉCTRICA, sin considerar la caja, es
 igual a su valor de liquidación, que asciende a $30 millones. La liquidación de estos activos no da origen a utilidades, para
 efectos tributarios. Adicionalmente, MARELÉCTRICA tiene hoy caja por $20 millones y pérdidas tributarias acumuladas de
 $340 millones. Esta empresa no tiene más proyectos que desarrollar, luego del estrepitoso fracaso del negocio mareomotriz y
 tampoco tiene deuda.
 Suponiendo que:
 - el flujo de caja anual de PASADA S.A. ($100 millones después de impuestos) es igual a las utilidades de esta empresa y
 que se mantendrá en este nivel en forma indefinida;
 - no hay límite de tiempo para aprovechar la pérdida tributaria acumulada de $340 millones. Si ésta no puede utilizarse
 íntegramente en un año cualquiera, el remanente se puede traspasar al año siguiente, y así sucesivamente;
 - las únicas empresas que componen el grupo ELECTRIKO son PASADA S.A. (que le pertenece en un 100%) y
 MARELÉCTRICA S.A. (que le pertenece en un 80%);
 - la tasa de impuestos corporativos es un 20%;
 - la tasa de descuento pertinente para actualizar flujos de caja después de impuestos a las empresas en un es 8% anual;
 - no hay inflación;
 Sobre la base de la información proporcionada, A Ud. se le pide responder las preguntas que se le formulan a continuación.
 En todas ellas justifique sus respuestas usando los cálculos que correspondan.
 2 Las centrales eléctricas de pasada requieren embalses mínimos de agua, y generan electricidad en base al flujo normal del río
 sobre el cual están construidas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 99

[pág. 100]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2012 | pregunta 6
 Convocatoria 2 | página original 113 | Fusión, pérdidas tributarias y canje
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 a) Suponiendo, sólo para efectos de contestar esta pregunta, que las pérdidas tributarias no pudieran aprovecharse si las
 empresas PASADA S.A. y MARELÉCTRICA S.A. se mantienen operando separadamente, ¿Cuál es el valor económico
 que debieran tener hoy cada una de estas empresas? ¿Cuál es el valor económico del patrimonio total del grupo
 ELEKTRIKO en ambas empresas?
 b) Los accionistas controladores del grupo ELECTRIKO están considerando la posibilidad de fusionar (juntar en una sola
 compañía) a las empresas PASADA S.A. y MARELECTRICA S.A. para efectos de aprovechar las pérdidas tributarias de
 esta última.3 Para ello, la empresa fusionada, continuadora de PASADA y MARELÉCTRICA, debe ser esta última.
 Suponiendo que no hay costos de transacción ni sinergias en fusionar ambas empresas ¿Cuánto valdrá la empresa
 fusionada? Compare y explique las diferencias con la respuesta que Ud. dio en (a).
 c) Los accionistas de CHISPITA (dueños del 20% de MARELECTRICA S.A) sostienen que, de acuerdo con sus cálculos, si
 se fusionan las empresas PASADA S.A. y MARELÉCTRICA S.A., su participación en la propiedad de la compañía
 fusionada no puede valer menos del 2% del patrimonio de dicha compañía. ¿Está Ud. de acuerdo con esta afirmación?
 Explique por qué.
 3 En Chile, la legislación no permite el aprovechamiento de pérdidas tributarias entre empresas que no estén controladas por el
 mismo dueño, de manera que la única forma que tiene el grupo ELECTRIKO de poder aprovechar la pérdida tributaria
 acumulada de $340 millones, es mediante la fusión de ambas compañías.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 100

[pág. 101]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2017 | pregunta 6
 Convocatoria 1 | página original 236 | Goodwill y ahorro tributario
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA N" 6
 Recientemente (y en más de una oportunidad) una investigación de la Superintendencia de Pensiones decretó
 que dos procesos de fusión entre Administradoras de Fondos de Pensiones (AFP) habían sido válidos y que en
 todo momento actuaron de buena fe y conforme a la normativa vigente.
 Parte de la discusión era la siguiente:
 Hasta el año 2014, para efectos tributarios, cuando una empresa adquiría el 100% de las acciones de otra a un
 valor superior al valor libro se generaba el llamado “Goodwill”. El Goodwill es un.activo intangible que, según
 la ley vigente en esa época, podía amortizarse como gasto (rebajando la base imponible o la utilidad antes de
 impuestos) en un plazo de 10 años. Este es un elemento de la ley de la renta presente en varios países. Por
 ejemplo, supongamos que la empresa B paga por el 100% de las acciones de la empresa A la suma de $1.500.
 Si el valor libro del patrimonio de la empresa A, al momento de venderse, era $1.000, los $500 de “sobreprecio”
 pagados por el 100% de las acciones pueden amortizarse como un gasto, en 10 años, a un monto de $50 por
 año. Por otro lado, los vendedores (accionistas) de A, al recibir un “sobreprecio” de $500, deben pagar
 impuestos por el total de dicha utilidad, en el período (año) en que se produce la venta.
 A partir del año 2015, la ley de la renta eliminó la figura del Goodwill para los negocios generados a partir de
 ese año (los descritos anteriormente se habían gestado años antes). El Goodwill ya no puede amortizarse como
 un gasto, pero el vendedor de todos modos tiene que pagar impuestos por la diferencia entre el valor libro
 ($1.000 en el ejemplo anterior) y el valor recibido en la venta ($1.500 en el ejemplo anterior).
 Suponiendo que la tasa de impuestos corporativos pertinente es 25% y que la tasa de descuento relevante es
 8%, responda las preguntas que se le formulan a continuación:
 PREGUNTAS
 1) Considere los mismos números del ejemplo que se cita en el enunciado y el régimen tributario vígente
 hasta 2014, vale decir, se forma la empresa fusionada llamada AB a partir de la compra del 100% de las
 acciones de la empresa A por parte de la empresa B. La empresa AB tendrá utilidades a futuro por montos
 sustancialmente mayores a $50 al año, entre otras cosas porque la empresa B tenía otros activos antes de
 la adquisición de A. El precio pagado por B fue de $1.500 y el valor en libros del patrimonio de A era de
 $1.000. ¿Qué proporción del precío pagado por B en la compra de la empresa A correspondería al ahorro
 tributario de la amortización del Goodwill? Fundamente su respuesta mostrando los cálculos
 correspondientes.
 2) Suponga ahora que la misma fusión descrita en (1) se hubiera llevado a cabo con la nueva legislación
 tributaria vigente a partir del año 2015, donde el Goodwill ya no puede amortizarse como un gasto:
 2.1) ¿Cree Ud. que con la nueva legislación tributaria los dueños de B estarían dispuestos a pagar un
 precio de $1.500 por el 100% de las acciones de A? Explique su respuesta mostrando los cálculos
 pertinentes.
 2.2) Desde un punto de vista financiero, y tomando como base su respuesta en la pregunta anterior (2.1),
 ¿En cuánto cambiaría la recaudación (por concepto de impuestos) del Servicio de Impuestos Internos por
 la fusión entre A y B? Fundamente su respuesta mostrando Jos cálculos correspondientes.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 101

[pág. 102]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2014 | pregunta 3
 Convocatoria 2 | página original 153 | Gordon y crecimiento sostenible
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N 3
 Durante muchos años una empresa chilena ha mantenido la política de repartir a sus accionistas, como
 dividendo en efectivo al término de cada año, un 60% de sus utilidades después de impuestos. Los
 dividendos de esta compañía han crecido y se espera que continúen haciéndolo en forma indefinida al 4%
 anual. La empresa no utiliza deuda para el financiamiento de sus proyectos, sino únicamente sus utilidades
 retenidas (40% de las utilidades) que son íntegramente reinvertidas, todos los años, en proyectos que tienen
 un rendimiento de 10% anual después de impuestos y que generan flujos de caja perpetuos. La tasa de
 descuento pertinente, después de impuestos, es un 8% anual y la tasa de impuestos corporativos asciende
 actualmente a un 20%. "
 Para las preguntas que se le formulan a continuación, trabaje bajo los supuestos del modelo de crecimiento
 perpetuo de Gordon.* Ignore la'existencia de impuestos personales y suponga que hoy es el 1 de enero de
 2015. Justifique sus repuestas mostrando los cálculos necesarios.
 PREGUNTAS
 1) Si la empresa espera obtener utilidades después de impuestos de $2.500 millones durante 2015 y
 planea mantener la política de dividendos histórica. ¿Cuál será su valor económico?
 2) En tlareforma tributaria que se discute en el Congreso se plantea subir el impuesto a las utilidades de
 las empresas a 27%, Si la compañía mantiene la política de repartir el 60% de sus utilidades después
 de impuestos y suponiendo que la tasa de descuento pertinente sigue siendo un 8% anual, ¿Qué
 impacto tendrá la reforma sobre el valor de la empresa? Haga explícitos los supuestos adicionales
 que estime necesarios,
 3) Suponga ahora que se aprueba la reforma tributaria y que la tasa de impuestos corporativos aumenta
 a 27% a partir del año 2015. A raíz de esto, la.empresa toma la decisión de.ajustar la tasa de reparto
 de dividendos de forma tal de mantener la tasa de crecimiento de las utilidades en 4%. Si la tasa de
 descuento pertinente se mantiene en un 8% anual ¿Cuánto cambia el valor económico de la empresa
 en este escenario, con respecto a la situación inicial? '
 ! El modelo de Gordon establece que el precio de una acción (P,) cuyos flujos de caja (dividendos) crecen en forma
 indefinida a una tasa anual g se puede calcular con la fórmula: Po = d, donde d; es el dividendo en efectivo que se
 r-8
 espera recibir en un período más y r es la tasa de descuento de los flujos de caja esperados.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 102

[pág. 103]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2022 | pregunta 6
 Convocatoria 2 | página original 374 | HME, VIX y valor presente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA Nº6
 A continuación, se presenta un gráfico que muestra la evolución, durante la crisis del COVID - 19 en el año
 2020, del conocido índice accionario S&P 500 (Standard and Poor’s 500) y el indicador de volatilidad esperada
 conocido como VIX:
 S&P 500 y VIX
 5.000 70
 4.500 60
 50
 4.000
 S&P500
 VIX (%)
 40
 3.500
 30
 3.000
 20
 2.500 10
 2.000 0
 dic-19 feb-20 abr-20 may-20 jul-20 sept-20 oct-20 dic-20
 S&P500 VIX
 El eje vertical izquierdo del gráfico muestra el valor del índice accionario S&P 500, medido en dólares, cuya
 evolución, entre diciembre del año 2019 y diciembre del 2020, se exhibe a través de la línea continua en el
 gráfico. Este índice es proporcional al valor de mercado de las 500 empresas más importantes (grandes) de
 EE.UU. Estas empresas representan, aproximadamente, la mitad de la capitalización bursátil mundial. El S&P
 500 es un índice ampliamente diversificado y tiene una correlación de 0,99 con el índice accionario del
 portafolio mundial. De hecho, durante la crisis del COVID – 19 en el año 2020, el portafolio mundial se
 comportó de manera prácticamente idéntica al S&P 500.
 El eje vertical derecho del gráfico muestra la evolución, entre diciembre del año 2019 y diciembre del 2020, del
 índice VIX, a través de la línea discontinua que se exhibe en dicho gráfico. El VIX es un indicador de volatilidad
 esperada (desviación estándar anualizada), que se deriva de los precios de las opciones sobre el S&P 500.
 Concretamente, el VIX mide la volatilidad anualizada implícita que el mercado espera en el futuro, para los
 retornos del S&P 500.
 La epidemia del Coronavirus se inició en China a fines del año 2019. El primer caso de COVID - 19 que se
 confirmó fuera de China, fue el 21 de enero de 2020. De allí en adelante, el virus comenzó a esparcirse por el
 mundo.
 Para efectos de responder las preguntas que se formulan a continuación, suponga que las personas optimizan en
 base a media-varianza, que poseen horizontes de inversión relativamente cortos, es decir, de alrededor de un
 año y que sólo invierten en activos financieros transables.
 a) Al analizar el gráfico del enunciado, el Analista Uno comentaba: “esta relación aparentemente inversa que
 se observa entre el nivel del índice S&P 500 y la volatilidad (VIX) tiene poco sentido y es difícilmente
 coherente con la idea de los mercados eficientes. Todo el mundo sabe que lo pertinente no es la volatilidad
 total, que incluye un componente idiosincrático (riesgo propio o único), sino el riesgo sistemático, no
 diversificable (riesgo de mercado). Por lo tanto, uno no debería esperar encontrarse con esta relación
 inversa.” ¿Está Ud. de acuerdo con los comentarios del Analista Uno? Fundamente su respuesta en forma
 breve y precisa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 103

[pág. 104]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2022 | pregunta 6
 Convocatoria 2 | página original 375 | HME, VIX y valor presente
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 b) Por su parte, el Analista Dos comentaba: “la evidencia demuestra que el mercado accionario claramente
 sobrereaccionó. De hecho, entre diciembre de 2019 y marzo de 2020 el S&P 500 cayó un 30%
 aproximadamente. Esto fue obviamente una sobrerreacción a un evento que se sabía que tendría que
 superarse, tal como ha ocurrido en tantas otras crisis que han afectado a la humanidad. De hecho, tan solo
 2 meses después de marzo de 2020, el índice S&P 500 ya había retomado su valor inicial, para seguir
 subiendo hasta fines de año. Más aún, desde su punto mínimo hasta el final del año 2020, el mercado subió
 un 63%. ¡Nadie puede creer en la hipótesis de mercados eficientes!” ¿Está Ud. de acuerdo con las
 aseveraciones del Analista Dos? Argumente su respuesta, en forma breve y precisa.
 c) El Analista Tres a su vez comentaba: “creo que el Analista Dos tiene razón en cuanto a que hubo una
 sobrerreacción en el mercado accionario el año 2020. Para ahondar en ese punto, fíjense que el valor del
 índice S&P 500 debería ser proporcional al valor presente de los flujos de caja que se espera, generen en el
 futuro, las 500 empresas incluidas en dicho índice. Nadie puede realmente creer que el valor esperado de
 los flujos de caja futuros cayera un 30% a perpetuidad en un mes o en un mes y medio. Esto es absurdo. Es
 equivalente a una destrucción permanente de la riqueza de 30%. Ni una guerra mundial causa esto.” ¿Está
 Ud. de acuerdo con las afirmaciones del Analista Tres? Fundamente su respuesta, en forma breve y precisa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 104

[pág. 105]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2018 | pregunta 6
 Convocatoria 1 | página original 264 | Liquidez y opciones societarias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 PREGUNTA N* 6
 En muchas transacciones privadas, donde se invierte en activos que son muy poco líquidos, como por ejemplo,
 en acciones de empresas cerradas 1 (que suelen llamarse “private equity” en inglés), hay un inversionista
 controlador que invita a accionistas minoritarios a participar en el negocio. Puede tratarse de negocios de
 cualquier tipo y en distintos rubros, tales como la minería, supermercados, concesiones de carreteras, empresas
 pesqueras, etc. En estos negocios, el objettvo normalmente es que, Juego de reorganizar las compañías y forjar
 nuevas alianzas, las empresas cerradas sean abiertas a la bolsa, con la correspondiente expectativa de generar
 ganancias para sus accionistas (controlador y minoritarios). Estos procesos suelen ser largos, con una duración
 de entre 7 y 10 años, por lo que las inversiones en estas compañías cerradas típicamente sólo podrán liquidarse
 en plazos largos.
 El accionista controlador y los accionistas minoritarios que invierten en las acciones de estas empresas, que
 son cerradas, establecen contratos o pactos que suelen ser bastante complejos. Típicamente, estos pactos
 incluyen una o más de las siguientes cuatro clánsulas:
 i) laposibilidad de que después de un tiempo, los minoritarios puedan vender al controlador su paquete
 accionario minoritario a un precio pre - establecido;
 i) la cláusula “Tag Along”, que consiste en que si el inversionista (accionista) controlador logra vender
 sus acciones a un tercero Juego de un tiempo, el inversionista minoritario también pueda concurrir o
 acoplarse a la venta en cuestión bajo Jas mismas condiciones que el controlador;
 iñ la cláusula “Drag Along”, mediante la cual el controlador, en caso de recibir una oferta de un tercero
 para adquirir la empresa, puede obligar a los minoritarios a participar en esta transacción haciendo que
 ambas partes (controlador y minoritarios) vendan sus paquetes accionarios al tercero en las mismas
 condiciones.
 iv) la cláusula “Right of First Refusal”, que da al controlador la posibilidad prioritaria, de comprar al
 minoritario, su participación accionaria, al mismo precio que le ofrecería un tercero (al minoritario)
 por dicha participación,
 Sobre la base de la información que se le ha proporcionado, a Ud. se le pide responder las preguntas que se le
 formulan a continuación. En todos los casos, Justifique claramente sus respuestas.
 PREGUNTAS
 a) Dado un nivel de riesgo (que podríamos medir según el Beta), ¿esperaría Ud. que las acciones de empresas
 cerradas tuvieran un rendimiento mayor, menor o igual que las acciones de una empresa de similares
 características pero que fuera abierta a la bolsa? Fundamente su respuesta.
 b) Utilizando conceptos de finanzas, identifique las “opciones financieras” (put, cali, etc.) que están implícitas
 en cada una de las cuatro cláusulas que se mencionan en el enunciado, y que típicamente forman parte de
 los pactos que se establecen entre el inversionista controlador y los minoritarios en los negocios descritos.
 Para cada “opción financiera”, señale expresamente a cuál de las dos partes involucradas (controlador o
 minoritario) beneficiaría dicha opción.
 ce) ¿Por qué cree Ud. que, en los negocios descritos en el emnciado (“private equity”), se incluyen las cláusulas
 mencionadas en los contratos o pactos entre el inversionista controlador y los accionistas minoritarios? En
 concreto, desde un punto de vista económico - financiero ¿qué se pretendería lograr con cada una de estas
 cuatro cláusulas? Responda, argumentando separadamente para cada cláusula, en forma muy breve y
 precisa.
 1 Se trata de sociedades anónimas cuyas acciones no se transan en bolsa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 105

[pág. 106]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2021 | pregunta 3
 Convocatoria 1 | página original 333 | Mercados eficientes y señalización
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 PREGUNTA Nº3
 El pasado 24 de diciembre de 2020 la compañía chilena SQM (Sociedad Química y Minera de Chile) anunció la
 idea de impulsar un aumento de capital por aproximadamente US$1.100 millones.1 Dicho aumento de capital
 representaría aproximadamente un 10% de la capitalización bursátil total de SQM a la fecha. Los fondos serían
 usados para financiar, en parte, el plan de expansión de US$1.900 millones de la compañía en los años 2021-2024.
 Suponga que este plan de expansión era desconocido para el mercado antes del 24 de diciembre 2020. La expansión
 considera el crecimiento de las operaciones de litio, nitrato y yodo. Gran parte de las inversiones se realizarían en
 Chile, en particular en el desierto de Atacama, donde están las mayores reservas de litio del mundo. Además de
 múltiples aplicaciones industriales, el litio es usado en baterías de dispositivos electrónicos, y últimamente en
 baterías de autos eléctricos.
 El mismo día del anuncio, la acción de SQM cerró su cotización bursátil con una caída de 4,21% (desde un precio
 cierre de $35.180 el 23 de diciembre a un precio cierre de $33.698 el 24 de diciembre). El IPSA (índice que permite
 medir el desempeño del mercado accionario chileno) cerró ese mismo día con una caída de 0,55%. El beta de las
 acciones de SQM se estima que es igual a 0,9. La caída del precio de SQM después del anuncio contrasta con las
 alzas que había experimentado la acción en el último tiempo, en línea con la recuperación del precio del litio a nivel
 mundial. Algunos analistas estimaban que, después del anuncio, el precio de la acción de SQM debería permanecer
 “plano” hasta que se llevara a cabo la junta de accionistas del próximo 22 de enero 2021, donde formalmente se
 sometería a votación el aumento de capital. El aumento de capital no puede ser ejecutado sin esa aprobación.
 Suponiendo que el mercado bursátil chileno es eficiente y que no existen fricciones informacionales, es decir, todos
 los partícipes del mercado (inversionistas minoritarios, controladores, corredores de bolsa, etc.) cuentan con la
 misma información, a Ud. se le pide responder las preguntas que se le formulan a continuación, entregando los
 fundamentos correspondientes:
 a) ¿Cómo es posible interpretar la caída del precio de la acción de SQM, frente al anuncio del aumento de capital,
 el 24 de diciembre de 2020? ¿Qué “cuentas” parecería estar sacando el mercado frente a este anuncio?
 b) Considere ahora que pueden existir asimetrías de información entre los participantes del mercado bursátil y los
 controladores de SQM. Suponga que no existe ninguna otra fricción que diferencie este mercado de un mercado
 clásicamente eficiente. ¿Cómo puede ayudar la información asimétrica a explicar la caída en precio después del
 anuncio? Sea breve y preciso en su descripción de los elementos necesarios para racionalizar esta reacción de
 mercado bajo el supuesto de que existe información asimétrica. Compare sus conclusiones de (a) y (b).
 c) Suponga que usted está analizando las perspectivas futuras de la acción de SQM con la información disponible
 después del anuncio, es decir, usted está haciendo su análisis al cierre del 24 de diciembre 2020. ¿Cuál es la
 mejor predicción del precio de SQM que usted puede hacer hoy, al cierre del 24 de diciembre de 2020, para el
 día 22 enero 2021, justo antes de que se lleve a cabo junta de accionistas? ¿Es razonable esperar una mantención
 del precio alrededor de los $33.698, es decir, un precio aproximadamente “plano” hasta la junta de accionistas,
 como sugieren algunos analistas? ¿Es predecible una recuperación de la caída del 24 de diciembre o, por el
 contrario, una profundización de la caída? Justifique su respuesta.
 1 SQM tiene dos series de acciones, A y B. El aumento de capital y todos los precios reportados en esta pregunta se
 refieren a SQM-B. Para efectos de responder esta pregunta, Ud. puede ignorar la existencia de dos series de acciones y
 responder como si solo existiera una serie.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 106

[pág. 107]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2013 | pregunta 6
 Convocatoria 1 | página original 125 | Opciones y cobertura por estados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA Nº 6
 Inversiones Risk S.A. tiene un portafolio de activos que incluye las acciones de la empresa Pel y Grosa S.A. (PG). Hoy
 es el primer día de trabajo del año 2013 y el gerente de Risk S.A. acaba de recibir información que indica la existencia
 de cuatro posibles escenarios para el valor que podría tener la acción de PG a fines del primer trimestre de 2013 (en 90
 días más). Dicha información se resume en la siguiente tabla, y corresponde a la que utiliza el mercado para valorar
 este activo financiero:
 Escenario N° 1 2 3 4
 Precio PG $100 $50 $30 $10
 Probabilidad 20% 30% 30% 20%
 El gerente de Risk S.A. está convencido de que PG es una buena alternativa de inversión sólo si se dan los escenarios 1
 y 2. Por esta razón, él está explorando la posibilidad de utilizar derivados (opciones sobre la acción de PG), que
 actualmente se transan en el mercado.
 Suponiendo que la acción de PG no paga dividendos, que la tasa de descuento relevante para actualizar cualquier flujo
 de caja es igual a cero y en base a la información entregada, a Ud. se le pide responder las preguntas que se le
 formulan a continuación, justificando sus resultados con los cálculos correspondientes. Si Ud. estima que sus repuestas
 requieren de supuestos adicionales, déjelos explicitados al momento de contestar.
 a) Calcule los pagos esperados que tendrá una opción de compra (call) y una opción de venta (put) sobre la acción de
 PG, para cada uno de los escenarios mencionados en la tabla del enunciado y determine el precio de mercado que
 debieran tener hoy estos dos tipos de opciones. Para todos los efectos prácticos, suponga que ambas opciones son del
 tipo europeas, que tienen un precio de ejercicio (strike price) igual a $50 y que su fecha de expiración es a fines del
 presente trimestre (90 días más).
 b) El gerente de Risk S.A. está evaluando la posibilidad de adquirir alguna de las dos opciones mencionadas en la letra
 (a) con el objeto de remover el riesgo en el precio de la acción de PG eliminando aquellos escenarios que son
 desfavorables (escenarios 3 y 4).
 b1) Si el gerente de Risk S.A. quiere mantener las acciones de PG en el portafolio de activos que administra ¿Cuál de
 las dos tipos de opciones (call o put) anteriores sería más adecuada para el propósito que persigue dicho gerente? ¿Por
 qué?
 b2) Calcule el flujo de caja neto esperado que tendría la estrategia de inversión consistente en mantener la acción de
 PG (que actualmente forma parte del portafolio de Risk S.A.) y adquirir la opción que Ud. recomendó en la letra
 anterior (b1).
 c) Suponga ahora que el gerente de Risk S.A. no comparte las expectativas que tiene el mercado respecto de las
 probabilidades de ocurrencia de los distintos escenarios que se mostraron anteriormente en la tabla del enunciado. En
 particular, el gerente cree que las probabilidades en cuestión son las siguientes:
 Escenario N° 1 2 3 4
 Precio PG $100 $50 $30 $10
 Probabilidad 30% 40% 0% 30%
 Si Ud. fuera un asesor del gerente de Risk, y tomando en cuenta que él le asigna una mayor probabilidad de ocurrencia
 que el mercado al peor de los escenarios (30% versus 20% para el escenario 4) ¿Le aconsejaría que adquiriera la
 opción que Ud. le recomendó en la letra (b1) anterior? Explique por qué.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 107

[pág. 108]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2016 | pregunta 6
 Convocatoria 2 | página original 221 | Opciones y paridad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 PREGUNTA N 6
 El 24 de junio de este año, los habitantes del Reino Unido (o británicos para todos los efectos prácticos)
 concurrieron a las urnas para votar en un plebiscito si permanecían o no dentro de la Unión Europea (UE). El
 referendo fue mundialmente conocido como el Brexit, que corresponde a la abreviatura de dos palabras en
 mglés: Britain (Gran Bretaña o Reino Unido) y exit, que significa salida (de la UE). Un año antes ya se sabía
 que ocurriría esta consulta ciudadana, pero los políticos, las personas y los mercados le asignaban una baja
 probabilidad a la ocurrencia del Brexit y había baja incertidumbre al respecto.
 Al acercarse la fecha del referendo la incertidumbre aumentó exponencialmente. Ya nadie se sentía seguro de
 lo que ocurriría. Se puede pensar que el tipo de cambio spot (tipo de cambio vigente en el mercado cambiario),
 que justo antes del referendo tenía un valor de 1,5 USD/ Libra (1,5 dólares estadounidenses por libra esterlina),
 reflejaba el valor esperado post-consulta: habría una depreciación de la Libra si se aprobaba el Brexit (la salida
 de la UE) y una apreciación si ocurría lo contrario. Pero la volatilidad del tipo de cambio era muy alta, para
 los estándares históricos.
 Suponga que hoy es el 23 de junio de 2016, día inmediatamente anterior a la fecha del referendo, y que los
 resultados del mismo se conocerán al día siguiente (24 de junio). En base a la información que se le ha
 proporcionado, responda las preguntas que se le formulan a continuación, Justifique sus respuestas en forma
 breve y precisa.
 1) En este ambiente de altísima incertidumbre previo al plebiscito:
 i) Si Ud. hubiera querido proteger, frente a un potencial Brexit, el valor de un depósito a plazo en libras
 esterlinas que vence el 24 de junio, y que Ud. tiene la intención de convertir a dólares estadounidenses (USD)
 a su vencimiento, ¿Qué tipo opciones debería haber comprado y por qué?
 ii) Suponiendo igual plazo, precio de ejercicio, tasa de interés y precio spot ¿Crec Ud. que hoy (un día antes
 del referendo) las opciones sobre la libra esterlina tenían precios mayores o menores a los que tenían un año
 atrás? ¿Por qué?
 2) Suponga que Ud. no tuviera certeza alguna de cuál será el resultado del referendo. Proponga, mostrando sus
 resultados gráficamente, una estrategia de inversión, con una opción Put y una opción y Cail, ambas con
 vencimiento al día 24 de junio y precio de ejercicio de 1,5 USD / Libra, que le dé a Ud. la posibilidad de
 obtener resultados positivos, independientemente del resultado de la consulta, si se producen cambios
 significativos (apreciación o depreciación) en el valor de la libra esterlina. Fundamente con claridad su
 respuesta.
 3) El 23 de junio (un día antes que se conociera el resultado de la consulta) se transaban opciones del tipo
 europeas Calls y Puts que vencían el 24 de junio, ambas con precio de ejercicio de 1,5 USD/Libra (igual al
 valor spot de la divisa del día 23). Suponga que se cumple la paridad Put — Call, esto es:
 P=C-So+VP(X)
 (el precio de una opción Put es igual al precio de una opción Call, menos el precio spot del tipo de cambio más
 el valor presente del precio de ejercicio de la opción Call y de la opción Put (X = 1,5 USD/Libra)).
 Suponiendo que la tasa de interés relevante a un día es igual a cero ¿Qué relación debiera cumplirse entre los
 precios de las opciones Call y Put? ¿Significa este resultado que el mercado le asignaba la misma probabilidad
 de ocurrencia a que el Reino Unido permaneciera o saliera de la Unión Europea? Fundamente sus respuestas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 108

[pág. 109]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2009 | pregunta 6
 Convocatoria 2 | página original 25 | Opciones/derivados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA Nº6
 En el directorio de la empresa XPORTA S.A. se ha producido una fuerte discusión sobre el rol que debe tener la
 cobertura cambiaria en una empresa exportadora. Para una empresa de este tipo, la cobertura cambiaria consiste en
 vender anticipadamente, o tener la opción de vender, a un precio fijo, los flujos futuros en moneda extranjera. Para
 llevar a cabo esta operación de cobertura cambiaria existen básicamente dos modalidades de contrato que se pueden
 pactar con un banco: los contratos forward y los contratos de opción de venta de moneda extranjera.
 1) Contrato Forward:
 Este contrato con el banco consiste en que la empresa paga o recibe, por ejemplo al cabo de un año, la diferencia entre
 el precio de mercado (tipo de cambio) de la moneda extranjera vigente en ese momento y el precio fijado con
 anticipación. Por ejemplo, si la empresa espera exportar en un año más US $ 10 millones, puede contratar hoy con el
 banco un forward que le permita vender, en un año más, la suma de US$ 10 millones a un tipo de cambio pactado (por
 ejemplo) de $566. Si al cabo de un año el tipo de cambio cae a $ 500, entonces la empresa recibirá $ 5.000 millones
 por sus exportaciones, y el banco le pagará la diferencia entre $566 y $500, es decir, $66 por cada dólar exportado (un
 total de $660 millones), lo que significará que finalmente la empresa se quede con $ 5.660 millones producto de sus
 exportaciones. Por el contrario, si al cabo de un año el tipo de cambio sube a $ 580, entonces la empresa recibirá $
 5.800 millones por sus exportaciones, y ella deberá pagar al banco la diferencia entre $580 y $566, es decir, $14 por
 cada dólar exportado (un total de $140 millones), lo que significará que finalmente la empresa se quede con $ 5.660
 millones producto de sus exportaciones. Los forwards no generan flujos de caja para la empresa ni para el banco al
 momento de su contratación, sino solamente al momento de la expiración del contrato.
 2) Contrato de Opción de Venta:
 Este contrato con el banco consiste en que la empresa tiene la opción, pero no la obligación, de venderle al banco, al
 cabo de un año, una determinada cantidad de dólares a un precio preestablecido. Por ejemplo, si la empresa espera
 exportar en un año más US $ 10 millones, puede contratar (comprar) ahora una opción que le permita vender al banco,
 en un año más, la suma de US$ 10 millones a un tipo de cambio pactado (por ejemplo) de $566. Si al cabo de un año
 el tipo de cambio cae a $ 500, entonces la empresa recibirá $ 5.000 millones por sus exportaciones, y ejercerá la
 opción con el banco, recibiendo la diferencia entre $566 y $500, es decir, $66 por cada dólar exportado (un total de
 $660 millones), lo que significará que finalmente la empresa se quede con $ 5.660 millones producto de sus
 exportaciones. Por el contrario, si al cabo de un año el tipo de cambio subiera, por ejemplo, a $580, entonces la
 empresa recibirá $ 5.800 millones por sus exportaciones y no ejercerá la opción de vender los dólares al banco. A
 diferencia de un forward, en el caso de una opción de venta, la empresa debe pagar una prima al banco al momento de
 contratarla.
 Los comentarios que se reproducen a continuación (en letra itálica) corresponden a las opiniones entregadas por
 distintos Gerentes de la empresa XPORTA S.A. en una reunión de Directorio:
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 109

[pág. 110]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2009 | pregunta 6
 Convocatoria 2 | página original 26 | Opciones/derivados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 Gerente 1:
 Es correcto pensar que si se cubren los flujos en dólares de nuestras exportaciones disminuiremos su variabilidad (en
 $) a un año. Sin embargo, yo estoy en contra de hacer cobertura, por cuanto si cubrimos el valor del dólar a un año
 plazo y éste cae, simplemente estaremos postergando los ajustes de costos que deberá hacer la empresa. De hecho, al
 cabo de un año de todos modos recibiremos menos ingresos en pesos por los productos propiamente tal que nosotros
 exportamos; es decir, sólo estaremos postergando el sufrimiento.
 Gerente 2:
 Creo que el argumento de mi colega (Gerente 1), ignora el hecho de que no tenemos seguridad sobre el monto o
 cantidades que exportaremos. Los US$ 10 millones son un valor esperado, pero no estamos seguros de que
 efectivamente podremos exportar esta cantidad, ya sea por variaciones en los precios en dólares o por las toneladas
 que logremos producir y vender. Si por alguna razón sólo logramos colocar la mitad de nuestras exportaciones
 (situación para nada improbable), entonces en ese momento la situación financiera de la Empresa podría volverse
 delicada, toda vez que podríamos no estar en condiciones de cubrir oportunamente la obligación financiera que se
 generaría con el banco.
 A continuación se formulan una serie de preguntas que a Ud. se le pide responder. En todas ellas suponga, para
 simplificar, que la empresa sólo puede cubrirse a 1 año plazo a la vez y que todas sus exportaciones son en dólares
 estadounidenses.
 1. ¿Bajo qué circunstancias sería correcto el argumento del Gerente 1? En su respuesta o análisis incorpore el
 concepto de “eficiencia de mercado”.
 2. Suponga que los montos exportados son efectivamente inciertos. En este contexto, ¿es válido el comentario
 efectuado por el Gerente 2, para los dos tipos de contratos (forward y opción de venta), en cuanto a la potencial
 obligación financiera que podría generar a XPORTA S.A. una cobertura cambiaria? Fundamente su respuesta
 entregando un ejemplo numérico.
 3. Suponga ahora, y sólo para efectos de responder esta pregunta, que el mercado del dólar fuera eficiente en su
 forma semifuerte y que los montos o cantidades exportadas fueran inciertas. Tomando en consideración los
 distintos comentarios efectuados por los Gerentes de la empresa, ¿considera Ud. que si XPORTA S.A. siguiera
 una estrategia financiera de cobertura cambiaria de sus exportaciones, ya sea a través de contratos de “forwards”
 o de “opciones de venta”, podría generar riqueza para sus accionistas como resultado de dicha estrategia?
 Fundamente en forma breve y precisa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 110

[pág. 111]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2023 | pregunta 6
 Convocatoria 1 | página original 387 | Paridad cubierta y arbitraje
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA Nº6
 La ausencia de oportunidades de arbitraje es una de las piedras angulares en la valoración de activos financieros.
 Las relaciones de arbitraje pueden ser aplicadas a múltiples mercados, pero quizás las más importantes se refieren
 a mercados cambiarios. Los mercados cambiarios son mercados de gran liquidez y profundidad en el sistema
 financiero mundial. Esto aplica no solo al mercado de cambio spot, sino que también a los mercados de contratos
 futuros o forward. Por ejemplo, el mercado de contratos forward entre el peso chileno (CLP) y el dólar
 estadounidense (US) tiene un volumen diario de transacciones que es aproximadamente el doble que el volumen de
 transacciones del mercado de cambio spot entre las mismas monedas. Inversionistas institucionales y extranjeros
 (por ejemplo, grandes bancos internacionales) son participantes activos del mercado forward.
 Una de las relaciones de arbitraje más importante en los mercados cambiarios es la conocida como paridad cubierta
 de tasas de interés:
 𝑆𝑡
 1 + 𝑅𝑢𝑠,𝑡+𝑗 = (1 + 𝑅𝑐𝑙𝑝,𝑡+𝑗 ) ×
 𝐹𝑡+𝑗
 Donde 𝑅𝑢𝑠,𝑡+𝑗 y 𝑅𝑐𝑙𝑝,𝑡+𝑗 corresponden a las tasas de interés en depósitos a plazo en dólares y pesos respectivamente.
 El tipo de cambio en el mercado spot (𝑆𝑡 ) se mide en pesos por dólar. El precio en un contrato forward (𝐹𝑡+𝑗 )
 también se mide en pesos por dólar. Un contrato forward es un acuerdo tomado hoy (𝑡) de vender o comprar dólares
 a un precio conocido 𝐹𝑡+𝑗 en una fecha futura (𝑡 + 𝑗). En la ecuación de arriba, tanto las tasas de interés como los
 contratos forward se refieren a los mismos plazos (por ejemplo, 𝑗 = 3 meses).
 En términos muy sencillos, esta paridad muestra que, si una persona tiene M pesos chilenos, y quiere invertir hoy a
 3 meses plazo (es decir, j = 3) para obtener dólares en j = 3, tiene dos opciones que debieran ser equivalentes. La
 primera es transformar hoy los M pesos a dólares al tipo de cambio spot vigente (St), y depositar los dólares
 resultantes en un banco, a 3 meses plazo, a la tasa de interés 𝑅𝑢𝑠,𝑡+3 . La segunda alternativa es depositar hoy en un
 banco, a 3 meses plazo, los M pesos chilenos a la tasa de interés 𝑅𝑐𝑙𝑝,𝑡+3, pero asegurando hoy, a través de un
 contrato forward, el tipo de cambio 𝐹𝑡+3 al cual se convertirán en dólares los pesos obtenidos en el depósito bancario,
 cuando éste venza en 3 meses más. En otras palabras:
 𝑀 1
 × (1 + 𝑅𝑢𝑠,𝑡+3 ) = 𝑀 × (1 + 𝑅𝑐𝑙𝑝,𝑡+3 ) × 𝐹
 𝑆𝑡 𝑡+3
 La igualdad anterior pone de manifiesto que la cifra de M pesos chilenos es irrelevante y que, para que no haya
 oportunidades de arbitraje, se debe cumplir que:
 𝑆
 (1 + 𝑅𝑢𝑠,𝑡+3 ) = (1 + 𝑅𝑐𝑙𝑝,𝑡+3 ) × 𝐹 𝑡
 𝑡+3
 Sobre la base de la información que se le ha presentado, responda las preguntas que se le formulan a continuación
 entregando los fundamentos correspondientes:
 a) Considere, sólo para efectos de esta primera pregunta (a) los siguientes datos: tipo cambio spot (para comprar o
 vender) = $832; tipo de cambio del contrato forward (para comprar o vender) = $864; tasa de interés en dólares para
 invertir o endeudarse a 3 meses (no es necesario trimestralizar) = 4%; tasa de interés en pesos para invertir o
 endeudarse (no es necesario trimestralizar) = 8%. Un economista amigo -experto en macroeconomía internacional-
 le dice que la expectativa actual que tiene el mercado sobre el tipo de cambio spot que prevalecerá en 3 meses más
 (es decir, 𝐸𝑡 (𝑆𝑡+3 )) es de $900 y no el tipo de cambio observado en el contrato forward ($864). Su amigo argumenta
 entonces que existe una oportunidad de arbitraje en este mercado. Explique por qué sí o por qué no es verdadero lo
 que dice su amigo macroeconomista.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 111

[pág. 112]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2023 | pregunta 6
 Convocatoria 1 | página original 388 | Paridad cubierta y arbitraje
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 La siguiente información se le presenta para responder las preguntas b) y c) que se formulan más adelante.
 Desde la crisis financiera del año 2008, el cumplimiento de algunas relaciones de arbitraje empezó a deteriorarse.
 Por ejemplo, en la figura adjunta se reporta la cross-currency basis (CCB) a 3 meses del peso chileno que está
 definida como las desviaciones observadas en la paridad cubierta de tasas de interés:
 𝑆𝑡
 𝐶𝐶𝐵𝑐𝑙𝑝,𝑡+𝑗 ≡ (1 + 𝑅𝑢𝑠,𝑡+𝑗 ) − (1 + 𝑅𝑐𝑙𝑝,𝑡+𝑗 ) ×
 𝐹𝑡+𝑗
 CCB 3m (%)
 2,00
 1,00
 0,00
 14.feb.2007 14.feb.2010 14.feb.2013 14.feb.2016 14.feb.2019
 -1,00
 -2,00
 -3,00
 -4,00
 -5,00
 -6,00
 Fuente: Banco Central de Chile (tasas on-shore)
 Por ejemplo, la CCB del peso chileno llegó a niveles de aproximadamente -5% (anualizada) en septiembre de 2008.
 Al igual que en otras monedas mundiales, la CCB del peso ha convergido lentamente hacia niveles cercanos al cero
 después de la crisis del 2008. En el caso chileno, la CCB volvió a ampliarse durante el estallido social de octubre
 2019 y durante la crisis covid (marzo 2020).
 b) ¿Cómo podría un arbitrador aprovecharse de una CCB negativa? Explique una estrategia de inversión que usted
 recomendaría si ese fuera el caso. Sea concreto en términos de las distintas operaciones que debe realizar el
 arbitrador. Suponga que este arbitrador tiene acceso ilimitado a mercados de depósitos y préstamos en dólares y
 pesos chilenos, y a los mercados spot y forward del peso chileno. Para facilitar su respuesta Ud. puede utilizar, si lo
 estima conveniente, los siguientes datos válidos solo para esta pregunta (b): tipo cambio spot (para comprar o
 vender) = $832; tipo de cambio del contrato forward (para comprar o vender) = $845; tasa de interés en dólares para
 invertir o endeudarse a 3 meses (no es necesario trimestralizar) = 4%; tasa de interés en pesos para invertir o
 endeudarse (no es necesario trimestralizar) = 10,5%.
 c) ¿Por qué podría una CCB negativa mantenerse por un tiempo prolongado como sucedió en el periodo 2008-2011
 o 2018-2019? Sea breve y preciso en los mecanismos que Ud. describe en su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 112

[pág. 113]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2016 | pregunta 6
 Convocatoria 1 | página original 195 | Pesos, UF e inflación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA N” 6
 Usted seguramente sabe que en Chile (y en muchos otros países) existen bonos estatales denominados en
 pesos nominales (CLP) y también en Unidades de Fomento (UF). Suponga para efectos de análisis que la
 UF del mes t se reajusta según la inflación del mes t-1. En el mercado chileno, existen y se transan
 activamente bonos estatales a múltiples plazos denominados en cada una de esas monedas.
 Responda las preguntas que se le formulan a continuación entregando los argumentos y cálculos que sean
 necesarios. Suponga que un año tiene 360 días (meses de 30 días).
 a) Suponga que Ud. administra un fondo mutuo de corto plazo. Entre las alternativas elegibles, Ud.
 invertirá una mayor proporción de los recursos en la opción de mayor rentabilidad esperada. La fecha
 actual es el 30 de enero de 2016 y su horizonte de inversión es de 3 meses (hasta el 30 de abril de
 2016). Existen bonos estatales a 2 años plazo del tipo bullet (pagan intereses semestralmente y
 amortizan el 100% del principal al final del período de maduración del bono). Estos bonos pagarán
 intereses por primera vez el 30 de junio de 2016.
 El Cuadro N? 1 que se muestra a continuación, resume las condiciones de mercado actuales (al
 31/01/2016) y los valores que Ud. espera al 30/04/2016. Para cada una de estas fechas, se entrega la
 — tasa interna de retorno (o TIR) para bonos bullet estatales, que maduran en 2 años, denominados en
 pesos (bonos BCP) y bonos bullet estatales, con vencimiento a 2 años, denominados en UF (bonos
 BCU) y el valor de la unidad de fomento (UF). Suponga que el precio de mercado inicial (al
 31/01/2016) de ambos bonos es UF 1 (0 $25.629,09) y que los dos instrumentos se transan actualmente
 a su valor par. Dadas sus expectativas y su horizonte de inversión (3 meses), ¿Cuál de los dos bonos
 favorecería en su portafolio? Fundamente su respuesta mostrando todos los cálculos necesarios.
 Cuadro N* i
 Condiciones de Mercado Bonos BCP y BCU a 2 años
 TIR BCP 2 años TIR BCU 2 años Valor de 1 UF
 (nominal en CLP) (en UF)
 31/01/2016 4,01% 1,26% $25.629,09
 30/04/2016 4,01% 1,26% $25.830,58
 b) Entre los ejecutivos de inversiones es frecuente encontrar la opinión de que siempre conviene estar
 invertido en UF a principios del año. Esto se daría por la estacionalidad de la inflación, que suele ser
 mayor durante los primeros meses del año, en particular en marzo, por el efecto del alza de las
 matrículas escolares y otros ítems del IPC.
 El Cuadro N? 2 que se muestra en la página siguiente, compara la estrategia de invertir en bonos bullet
 con pagos semestrales y vencimiento a 2 años del tipo BCP (en pesos o CLP) y del tipo BCU (en UF),
 para el trimestre Febrero - Abril entre los años 2009 -2015. Los retornos son ex post y están expresados
 en términos reales (corregidos por inflación) para el trimestre señalado. A modo de ejemplo, en el
 trimestre Febrero — Abril del año 2015, la inversión en bonos BCU que maduran en 2 años tuvo un
 rendimiento real de 1,27% mientras que la inversión en bonos BCP con vencimiento a 2 años tuvo un
 retorno real de -0,13% (menos 0,13%).
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 113

[pág. 114]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2016 | pregunta 6
 Convocatoria 1 | página original 196 | Pesos, UF e inflación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 Cuadro N? 2
 Retorno (%) Real Trimestre Febrero — Abril para Bonos BCP y BCU a2 Años
 Año BCU BCP
 2015 127% — -0,13%
 2014 2,739% — 1,77%
 2013 141% — 2,00%
 2012 0,61% — -0,07%
 2011 136% — 1,42%
 2010 2,84% — 0,10%
 2009 3,66% — 4,92%
 Usando argumentos de la teoría financiera y en base a la evidencia presentada en el Cuadro N? 2
 ¿Qué opinión le merece la creencia de los ejecutivos de inversiones en cuánto a que siempre conviene
 estar invertido en UF a principios del año? Fundamente su respuesta.
 c) Suponga ahora que el mercado de bonos está dominado por ahorrantes con horizonte de inversión de
 largo plazo. ¿Cuál de los dos tipos de bonos (BCP o BCU) debería tener una mayor rentabilidad
 esperada a largo plazo y por qué? Mencione en su respuesta el concepto de premio por riesgo.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 114

[pág. 115]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2025 | pregunta 5
 Convocatoria 1 | página original 435 | Portafolio, CAPM y puts
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N'5
 ABC es un Fondo Mutuo que invierte de manera diversificada en acciones de empresas chilenas. En el último
 Comitó de Inversiones de ABC se estudió la posibilidad de incorporar, al portafolio del Fondo, algunos
 activos financieros donde el Fondo no había invertido.
 Lo que se muestra a continuación, es el análisis efectuado por el Comité de Inversiones del Fondo Mutuo -
 respecto de las potenciales inversiones. Ud. debe contestar las preguntas que se le formulan a continuación,
 entregando los fundamentos en los cuales sustenta sus respuestas.
 1. Uno de los sectores en los cuales el Fondo Mutuo de ABC no había invertido era el sector pesquero
 industrial, que consiste en la extracción, mediante el uso de barcos con tecnología avanzada, de
 recursos pelágicos como la anchoveta y la sardina, que posteriormente son transformados en harina de
 pescado. El Gerente Comercial de ABC opinaba que, a pesar de lo atractivo que resultaban los retornos
 esperados de las acciones de empresas pesqueras industriales no era conveniente invertir en ellas,
 porque sus resultados están expuestos a demasiados riesgos que son incontrolables, por ejemplo,
 cambios climáticos (corriente del niño, de la niña, marejadas), vedas (por virus, marea roja o peligro
 de extinción de la especie), alzas en el precio del combustible (insumo para los barcos), huelgas, etc.
 ¿Está Ud. de acuerdo con los fundamentos entregados por el Gerente Comercial de ABC para no
 invertir en acciones de las empresas pesqueras industriales? Explique por qué.
 2. ABC está analizando la posibilidad de que el Fondo Mutuo invierta en acciones de alguna de las
 siguientes dos compañías vinculadas al sector transporte: Rodantes S.A. y Barcarola S.A. Las acciones
 de Rodantes S.A. tienen un retorno anual esperado de 10% y una volatilidad (medida como desviación
 estándar de los retornos) de 30%. Por su parte, las acciones de Barcarola S.A. tienen una rentabilidad
 anual esperada y riesgo (desviación estándar) de 15% y 40% respectivamente. Suponga que se
 cumpliera el modelo CAPM. La tasa libre de riesgo es de un 4% y la prima por riesgo de mercado
 (Rm —RÍ es igual a 6%. La acción de Rodantes S.A. tiene un beta igual a 0,9 y la acción de Barcarola
 S.A. tiene un beta igual 2,0. Sobre la base únicamente de la información que se le ha proporcionado,
 ¿le recomendaría Ud. al Fondo Mutuo ABC invertir en alguna de estas dos acciones del sector
 transporte? Fundamente su respuesta.
 3. Como una manera de enriquecer los retornos del Fondo Mutuo, la administración de ABC decidió
 invertir en opciones sobre acciones de algunas empresas chilenas que formaban parte de la cartera del
 Fondo Mutuo. Desgraciadamente, los precios de los activos subyacentes de estas opciones subieron
 de manera considerable, y el Fondo Mutuo no pudo ejercer dichas opciones. ¿Cuál era la apuesta tras
 la estrategia con opciones que estaba haciendo ABC? ¿Qué posición (corta o larga) y qué tipo de
 opción (put o call) mantenía el Fondo Mutuo ABC?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 115

[pág. 116]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2018 | pregunta 3
 Convocatoria 2 | página original 270 | Portafolios, beta y Sharpe
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTAN” 3
 Alexandra Vanguard es una joven profesional recién graduada de un programa de MBA de una prestigiosa
 universidad extranjera, que acaba de ser contratada como asesora financiera para colaborar en la gestión de la
 cartera de inversiones de una adinerada familia que administra sus inversiones a través de una empresa holding.
 Actualmente, la cartera en cuestión está íntegramente invertida en el fondo mutuo indexado FSP500, que tiene
 como objetivo replicar el conocido índice bursátil Standard éz Poor's (SézP) 500. 1
 La Gerente General del holding familiar está convencida de que la mejor estrategia que debe seguir una persona
 que invierte en acciones es comprar y mantener algo similar a lo que podría ser la cartera de mercado, porque
 ningún otro portafolio diversificado puede ofrecer el mismo retorno esperado a un menor riesgo. Dado que en
 EE.UU, la cartera de mercado típicamente se asocia al índice bursátil SáP 500, existen muchos fondos mutuos
 quereplican este índice y que reciben el nombre de “fondos indexados”. De esa forma, quienes invíerten en dichos
 fondos, es como si estuvieran invirtiendo en una especie de portafolio de mercado, y esa es la razón por la cual
 los recursos financieros del fondo están invertidos en el fondo mutuo FSP500.
 Alexandra, cree que ha llegado el momento de introducir algunos cambios en la administración de la cartera de
 inversiones del holding. En particular, ella ha estudiado las signientes tres alternativas de inversión, mutuamente
 excluyentes, que a su juicio permitirían mejorar la relación riesgo — retorno qué obtiene el holding en sus
 inversiones financieras, tomando en cuenta que los miembros de la familia propietaria del holding son aversos al
 Nesgo: -
 Alternativa 1
 Agregar a la cartera del holding, acciones de una nueva empresa del rubro de la pesca que se acaba de abrir a la
 Bolsa. A juicio de los especialistas, esta nueva empresa, que fabrica y comercializa hariba de pescado, tiene muy
 buenas perspectivas económicas porque utiliza una tecnología de punta en su proceso productivo.
 Alternativa 2
 Mantener un 99% de los recursos invertidos en el fondo mutuo FSP500 (que replica el SP 500) e invertir el 1%
 restante en una de las siguientes acciones que no forman parte del S4-P500: la Compañía A o la Compañía B.
 Alexandra ha recolectado la siguiente información respecto de estas inversiones:
 FSP500 — | COMPAÑÍA A | COMPAÑÍA B
 Retorno anual! esperado 10% 13% 14%
 Desviación estándar 20% 25% 40%
 El coeficiente de correlación entre los retornos esperados del fondo FSP500 y los rendimientos esperados de las
 acciones de las Compafiías A y B se estima en 0,6 y 0,25 respectivamente.
 Alternativa 3
 Invertir el 100% de los recursos del holding en otro tipo de fondos mutuos que también son bastante diversificados
 pero que no tienen como objetivo replicar el índice bursátil SA-P500. Para ello se rescataría el 100% de los
 recursos invertidos por el hoiding en el fondo mutuo FSP500 y estos dineros serían invertidos íntegramente en
 uno de los siguientes fondos mutuos:
 FSP500 FONDO C FONDO D
 Retorno anual esperado 10% 15% 18%
 Desviación estándar 20% 22% 35%
 1 Este índice comprende las 500 acciones de las compafífas más importantes que se transan en bolsa en EE-UU. ponderadas
 de acuerdo a su capitalización de mercado.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 116

[pág. 117]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2018 | pregunta 3
 Convocatoria 2 | página original 271 | Portafolios, beta y Sharpe
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 se le
 Responda las preguntas que se le formulan a continuación en base a la información específica que a Ud.
 está proporcionando en cada una de las Alternativas (por ejemplo, la información de la Alternativa 3 solamente
 es válida para dicha Altemativa y no para las Alternativas 1 y 2).
 PREGUNTAS
 bueno
 a) Al conocer la Alternativa 1, la Gerente General del holding le dice a Alexandra que no cree que sea
 invertir en acciones de la nueva empresa pesquera, porque sus resultados están expuestos a demasiados riesgos
 roja
 que son incontrolables, como por ejemplo, cambios climáticos (corriente del niño, tormentas), vedas (marea
 etc.
 o extinción de la especie), alzas en el precio del combustible (insumo para los barcos pesqueros),
 (principal fuente de ingresos de la pesquera) es un commodity que se transa
 Adicionalmente, la harina de pescado
 a nivel mundial con un precio altamente volátil. ¿Está Ud. de acuerdo con este análisis? Explique por qué.
 b) Si Ud. tuviera que invertir el 1% de la cartera del holding familiar en una de las dos compañías mencionadas
 en la Alternativa 2 (manteniendo el 99% restante en el fondo mutuo FSP500) ¿Cuál de ellas elegiría? Fundamente
 Y %).
 su respuesta en forma conceptual y numérica. Use un mínimo de dos decimales en sus cálenlos (XX,Y
 c) Suponga, sólo para efectos de esta pregunta, que la tasa libre de riesgo fuera del 4% anual y que Ud. tuviera
 que tomar la decisión de invertir, en el corto plazo, el 100% dé los recursos del holding en el fondo mutuo C o el
 fondo mutuo D mencionados en la Alternativa 3, ¿Cuál de ellos elegiría? Fundamente su respuesta en forma
 conceptual y numérica. Use un mínimo de dos decimales en sus cálculos.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 117

[pág. 118]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2020 | pregunta 4
 Convocatoria 2 | página original 322 | Retorno, riesgo, probabilidades y Sharpe
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 PREGUNTA N° 4
 Los fondos de pensiones chilenos (que son administrados por las Administradoras de Fondos de Pensiones o
 AFPs), y otros vehículos de inversión similares, combinan múltiples activos al formar portafolios. El objetivo
 principal es entregar buenas rentabilidades de largo plazo (es decir, pensando en la etapa de jubilación) sujeto a
 un cierto perfil de riesgo deseado por el afiliado o inversionista. En esta pregunta se pide que usted desarrolle
 criterios para evaluar el desempeño de los fondos de pensiones en el corto y largo plazo, bajo el supuesto de
 que los fondos de pensiones hacen un análisis media-varianza simple.
 Para simplificar el análisis considere que existen 3 grandes clases de activos en los que las AFPs invierten:
 depósitos, bonos y acciones. Suponga que la correlación entre los retornos de bonos y acciones es de 0 y que
 sus rentabilidades históricas y esperadas, en términos mensuales y nominales, son las siguientes:
  Depósitos: básicamente el activo libre de riesgo en la economía con un retorno mensual promedio de
 0,2% sin volatilidad (desviación estándar de los retornos igual a 0).
  Bonos: retorno mensual promedio de 0,4% con desviación estándar de 0,6%.
  Acciones: retorno mensual promedio de 1% con desviación estándar de 2%.
 Nos enfocaremos en 2 Fondos ofrecidos por las AFPs a sus afiliados: un Fondo más riesgoso (“Fondo A”) y
 otro menos riesgoso (“Fondo C”). Suponga que los portafolios de estos Fondos tienen la siguiente composición:
 Fondo A Fondo C
 Depósitos 0% 50%
 Bonos 20% 10%
 Acciones 80% 40%
 Para efectos de responder las preguntas que se le formulan a continuación, suponga que los retornos de todos
 los activos siguen la distribución normal y que los retornos de un mes son independientes de todos los meses
 anteriores.
 a) ¿Cuál es la rentabilidad esperada y la volatilidad (medida como desviación estándar) de los Fondos A
 y C? Muestre los cálculos correspondientes.
 b) ¿Qué tan probable es que, en un mes cualquiera, el Fondo A rente menos que el Fondo C? No se pide
 una estimación precisa de esa probabilidad, ni un cálculo matemático muy complicado, sino que se pide
 una respuesta en términos intuitivos en la siguiente escala: muy probable (> 95% de los meses), probable
 (entre 95% y 5%), muy improbable (< 5% de los meses). Justifique su respuesta utilizando la
 información obtenida en la letra anterior. Recuerde que en una distribución normal con media y
 desviación estándar aproximadamente:
  El 95% de los casos posibles están contenidos en el intervalo ± .
  El 68% de los casos posibles están contenidos en el intervalo ± .
  El 38% de los casos posibles están contenidos en el intervalo ± (
 c) Suponga que un afiliado a una AFP decide tratar de maximizar la rentabilidad de sus inversiones
 cambiándose “estratégicamente” entre el Fondo A y el C según un modelo que acaba de idear. Suponga
 que el inversionista tiene hoy 25 años y que seguirá esta política por los próximos 30 años. Considere
 las tres siguientes políticas de inversión:
  Política 1: Invertir siempre en el Fondo C
  Política 2: Invertir siempre en el Fondo A
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 118

[pág. 119]
Finanzas - versión clara y reordenada
 Teoría Financiera | agosto 2020 | pregunta 4
 Convocatoria 2 | página original 323 | Retorno, riesgo, probabilidades y Sharpe
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
  Política 3: Invertir según la estrategia pensada por el inversionista que consiste en invertir en el
 Fondo A, pero cambiarse al Fondo C, por un mes, cada vez que el Fondo A tiene una
 rentabilidad negativa y después volver al Fondo A.
 ¿Cuál sería el ranking de rentabilidades esperadas al comparar las 3 políticas de inversión? No es
 necesario entregar un valor para cada rentabilidad, sólo ordenarlas de mayor a menor. Justifique su
 respuesta suponiendo que los cambios entre los Fondos A y C son instantáneos, es decir, no hay tiempo
 de espera cuando un inversionista decide cambiarse de un Fondo a otro.
 d) Suponga ahora que usted toma una muestra de 20 años y calcula la razón de Sharpe para los Fondos A
 y C, es decir, el retorno promedio del Fondo (en exceso de la tasa de depósitos) dividido por la
 desviación estándar de esos retornos. Suponga que 20 años es suficiente para ser considerado como
 largo plazo. Si el análisis media-varianza que hicieron inicialmente las AFPs fue adecuado, es decir,
 efectivamente maximizaron la razón de Sharpe ofrecida a sus afiliados, y no tenían restricciones de
 inversión en sus portafolios, ¿Cómo debería ser la razón de Sharpe del Fondo A con relación a la razón
 de Sharpe del Fondo C: mayor, menor, igual? Fundamente su respuesta ya sea de manera conceptual o
 numérica.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 119

[pág. 120]
Finanzas - versión clara y reordenada
 Teoría Financiera | marzo 2010 | pregunta 6
 Convocatoria 1 | página original 41 | Riesgo y portafolios
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 PREGUNTA Nº6
 Reacciones frente a la última crisis financiera:
 Durante el año 2008 las acciones chilenas rentaron alrededor de -20% (menos 20%), lo cual representa un retorno
 inusualmente bajo en términos del promedio histórico de aproximadamente 10% anual. El gráfico de la Bolsa de
 Comercio de Santiago que se adjunta al final del enunciado, muestra el comportamiento del IGPA, muestra el
 comportamiento del IGPA, el índice accionario de mayor cobertura del mercado Chileno, durante el año 2008. La caída
 se acentuó durante el último trimestre del año 2008 junto con la quiebra de Lehman Brothers en Septiembre de 2008, uno
 de los bancos de inversión más grandes de EE.UU. y del mundo en ese momento. Todo lo anterior, es el reflejo de lo que
 el mercado ha reconocido como una “crisis financiera” mundial.
 Dicha crisis financiera ha desatado un intenso debate sobre la eficiencia del mercado financiero, sobre su capacidad para
 entender y manejar riesgos, y sobre las precauciones que un inversionista medio puede tomar para protegerse de este tipo
 de crisis “sistémicas” o “globales”.
 A continuación se presentan tres opiniones (independientes entre sí) que se han planteado en relación a dicha crisis. A
 usted se le pide analizar brevemente cada una de ellas, de manera independiente, y responder la pregunta que se le plantea
 al término de cada una de dichas opiniones. Se espera que la respuesta a cada una de las tres opiniones, de manera
 independiente, sea breve y precisa.
 a) Muchos observadores han opinado que a quienes participan en los mercados financieros, les ha faltado capacidad
 predictiva. En concreto, se sorprenden de que grandes inversionistas, administradores de portafolios, o instituciones
 como fondos de pensiones o bancos de inversión no hayan sido capaces de predecir la abrupta caída en precios de
 las acciones que se observó durante el año 2008. De acuerdo a estos observadores, esta falta de capacidad predictiva,
 muestra las falencias de los modelos utilizados en el mercado financiero y la “miopía” de los inversionistas. En el
 extremo algunos argumentan que hay que hacer “borrón y cuenta nueva” con la teoría financiera moderna.
 A usted se le pide que, utilizando los conceptos financieros de “eficiencia de mercado”, entregue su opinión o sus
 comentarios respecto de la opinión de estos observadores del mercado financiero.
 b) Como consecuencia de la caída de las rentabilidades o retornos accionarios, los Fondos A de las AFPs chilenas, es
 decir aquellos fondos que invierten una mayor fracción en renta variable, sufrieron grandes pérdidas durante el año
 2008. En contraste, durante el año 2009 esos mismos fondos tuvieron retornos muy altos, recuperando en gran parte
 lo perdido durante el 2008. Frente a esta volatilidad, algunos se quejaron por la negligencia o falta de habilidad de
 los administradores de fondos de las AFP que parecen estar “jugando con los ahorros de los trabajadores chilenos
 como si estuvieran en un casino”.
 A usted se le pide responder lo siguiente: ¿Puede usted, con la evidencia o información que se le ha entregado en la
 pregunta, concluir que los administradores de fondos de las AFP fueron negligentes o que carecen de habilidad para
 tomar decisiones de portafolio?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 120

[pág. 121]
Finanzas - versión clara y reordenada
 Teoría Financiera | marzo 2010 | pregunta 6
 Convocatoria 1 | página original 42 | Riesgo y portafolios
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 13
 c) Algunos analistas han opinado que como una manera de palear las crisis financieras o disminuir sus efectos
 negativos, los inversionistas debieran invertir en “commodities” o productos genéricos (por ejemplo, en oro o
 cobre). Sin embargo, los mercados de “commodities” también sufren de alta volatilidad. Muchos argumentan
 además que invertir en “commodities” no tiene un valor diversificador adicional al de las acciones, toda vez que el
 mercado accionario ya entrega amplias oportunidades de diversificar el riesgo. Por ejemplo, en el mercado
 accionario chileno se transan más de 100 acciones distintas. La Figura adjunta muestra los retornos del IGPA (Índice
 General de Precios de las Acciones Chilenas) y los retornos de una canasta de “commodities” durante el año 2008.
 A usted se le pide responder lo siguiente: Dada esta evidencia o información que ha recibido, ¿cree usted que
 invertir en “commodities” y en acciones simultáneamente, puede ayudar a los inversionistas a palear o disminuir los
 efectos una crisis como la que se ha indicado? ¿Qué efecto debería tener el incluir “commodities” sobre los retornos
 de un portafolio que es inicialmente sólo accionario?
 Retornos del IGPA y de Canasta de Commodities durante 2008
 IGPA Commodities
 15%
 10%
 Retornos de canasta de
 “commodities”
 5%
 0%
 -5%
 Retornos de Acciones
 del “IGPA”
 -10%
 Ene-2008 Feb-08 Mar-08 Abr-2008 May-08 Jun-08 Jul-08 Ago-2008 Sep-08 Oct-08 Nov-08 Dic-2008
 NOTA: los retornos de la canasta de “commodities” pueden no corresponder exactamente a la realidad del mercado
 mundial de “commodities”
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 121

[pág. 122]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2026 | pregunta 5
 Convocatoria 1 | página original 460 | Riesgo y portafolios
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N“5
 A comienzos de 2025, AndeSur Corredores, una empresa dedicada a la operación y mantención de corredores logísticos
 estratégicos a lo largo del país, se encontraba en un momento clave de su desarrollo. Tras varios años de expansión
 sostenida, la compañía había consolidado contratos estables con clientes de largo plazo, lo que le permitió acceder a
 financiamiento en condiciones muy favorables.
 Sin embargo, informes recientes de analistas financieros comenzaron a advertir que el nivel de endeudamiento de la
 empresa, si bien manejable, podría generar inquietud entre inversionistas más conservadores. Frente a este escenario, el
 directorio decidió realizar un análisis integral para comprender cómo su estructura de capital afecta tanto el valor de la
 firma como sus decisiories futuras de inversión.
 Situación Financiera Actual:
 AndeSur financia actualmente sus activos con un 25 % de deuda y un 75 % de patrimonio, todo sobre la base de valores
 económicos. Gracias a la estabilidad de sus ingresos y a la solidez de sus contratos, el mercado considera que la deuda
 de la empresa es libre de riesgo, por lo que exige una tasa de interés anual de 4 %.
 Las acciones de la empresa presentan un “beta” de 0,75, reflejando una exposición moderada al riesgo sistemático del
 mercado.
 La administración espera generar flujos de caja de $26 millones a perpetuidad, provenientes de sus activos.
 El IPSA se considera como el portafolio de mercado y ofrece un retorno esperado de 20 % anual. Asuma la existencia
 de un mercado de capitales perfecto, sin impuestos, costos de transacción ni asimetrías de información, y que se cumple
 la hipótesis de eficiencia en el mercado de capitales.
 Se Pide responder las preguntas siguientes, presentando los cómputos que la fundamentan sus respuestas:
 1. Determine el valor de mercado de la compañía AndeSur.
 2. Durante una sesión estratégica del directorio, algunos miembros manifestaron su preocupación por la señal que el
 nivel de deuda podría estar enviando al mercado. Como respuesta, se propuso emitir acciones a precio de mercado
 y recomprar parte de la deuda existente, de modo que esta represente solo un 10 % del financiamiento total de los
 activos. ¿Cuál será el retorno exigido por los accionistas de AndeSur inmediatamente después de la operación de
 recompra de deuda? ¿Cuál será el valor de mercado de la empresa AndeSur?
 3. Suponga ahora que después de la recompra de deuda mencionada en la pregunta anterior, el equipo de operaciones
 AndeSur presenta al directorio un proyecto de modemización que permitiría mejorar la eficiencia en el uso de
 recursos y reducir costos de manera significativa. El proyecto requiere una inversión inicial de $60 millones y
 generaría un flujo de caja de $15,6 millones anuales a perpetuidad. Se estima que el riesgo del proyecto es similar
 al de las actuales inversiones o activos de AndeSur.
 El directorio toma la decisión de llevar a cabo el nuevo proyecto y financiar la inversión inicial requerida mediante
 la emisión de nuevas acciones a su precio de mercado. Simultáneamente, la empresa anuncia al mercado el nuevo
 proyecto y su forma de financiamiento.
 3.1 ¿Cuál será el valor de mercado de AndeSur inmediatamente después del anuncio del proyecto de
 modemización, pero antes de la emisión de nuevas acciones necesaria para su financiamiento?
 3.2 Si actualmente AndeSur tiene un único dueño, quien no desea suscribir la emisión de nuevas acciones, ¿qué
 porcentaje de la propiedad retiene el dueño de AndeSur luego de la emisión de las acciones?
 10
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 122

[pág. 123]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2024 | pregunta 6
 Convocatoria 1 | página original 412 | Tasas, portafolio y HME
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 PREGUNTA Nº6
 La tasa de política monetaria (TPM) es la tasa de interés nominal fijada por el Banco Central de Chile (BCCh) para
 sus operaciones con los bancos comerciales. Esta tasa afecta las demás tasas del sistema financiero chileno, tanto
 de corto plazo (por ejemplo, depósitos a 30 días) como de largo plazo (por ejemplo, bonos de tesorería a 10 años),
 aunque no es su único determinante. Las tasas de corto plazo siguen la TPM bastante cerca. Las tasas más largas
 incorporan otros factores como el futuro comportamiento de la política monetaria (las futuras TPM), las tasas
 internacionales de papeles de largo plazo y otros. El comportamiento de la TPM en los años 2017-2023 ha sido el
 siguiente:
 El BCCh subió fuertemente la TPM en 2022 y 2023 con el objetivo de frenar la inflación sufrida en el periodo post-
 pandemia por Chile y el mundo. La inflación ha dado señales de ya estar en una trayectoria descendiente en los
 últimos meses, y tanto analistas como otros operadores del mercado financiero esperan que la TPM comience a
 bajar durante el año 2024 hacia niveles de “neutralidad” lo cual sería una tasa de alrededor del 5%. Estos nuevos
 niveles de tasas, si bien inferiores al máximo de 11,25% visto durante el 2022, son sustancialmente superiores a las
 tasas observadas pre-pandemia de alrededor de 3%. Este es un fenómeno mundial: se espera que las tasas de interés
 extremadamente bajas de la década 2010-2020 no se repitan en el futuro cercano.
 Sobre la base de la información que se le ha presentado, responda las preguntas que se le formulan a continuación
 entregando los fundamentos correspondientes. Si necesita hacer algún supuesto adicional debe explicitarlo en su
 respuesta. Adopte un horizonte de inversión de corto plazo.
 Preguntas
 a) Suponga que usted mantiene un portafolio diversificado que, para simplificar, puede ser descompuesto en dos
 grandes clases de activos: depósitos bancarios de corto plazo en pesos, que prácticamente no tienen riesgo, y
 activos riesgosos, compuestos por acciones chilenas e internacionales. Si su opinión es que el retorno esperado
 y el riesgo de estos activos riesgosos se mantendrán relativamente constantes comparados con la década del
 2010-2020, ¿qué debería implicar para su portafolio, en términos de aumentar o reducir la ponderación de cada
 clase de activos, el mayor nivel de la TPM de neutralidad? Su respuesta puede fundamentarla de manera
 conceptual o, si lo estima conveniente, utilizando un análisis gráfico del tipo media-varianza.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 123

[pág. 124]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2024 | pregunta 6
 Convocatoria 1 | página original 413 | Tasas, portafolio y HME
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 b) Suponga ahora, sólo para efectos de esta pregunta, que Ud. está analizando la posibilidad de agregar al
 portafolio diversificado de la letra (a) una tercera clase de activo compuesta por bonos de largo plazo en pesos.
 En los últimos meses las tasas de los bonos de largo plazo en pesos han sido comparables o incluso han estado
 por debajo de las tasas de los depósitos bancarios de corto plazo. En jerga de mercado, “la estructura de tasas
 ha estado invertida”. Algunos inversionistas opinan que en este contexto los bonos de largo plazo dejan de
 cumplir una función en un portafolio diversificado y deben ser reemplazados por depósitos bancarios de corto
 plazo, ya que estos últimos tienen un menor riesgo y un retorno similar o incluso mayor que los bonos en pesos
 de largo plazo. ¿Es adecuada esta recomendación? Suponga que efectivamente el retorno esperado de invertir
 en bonos de largo plazo es igual (o menor) al de los depósitos de corto plazo. Al igual que en la letra (a) su
 respuesta puede fundamentarla de manera conceptual o, si lo estima conveniente, utilizando un análisis gráfico
 del tipo media-varianza.
 c) Algunos inversionistas opinan que la trayectoria a la baja de la TPM en los próximos años está perfectamente
 incorporada en los bonos de largo plazo en pesos y que el BCCh tiene completa credibilidad en el mercado
 chileno. Dado esto, algunos analistas opinan que es más recomendable invertir en bonos largos que en
 depósitos bancarios de corto plazo en pesos, porque la disminución en las tasas de interés debería producir una
 ganancia de capital que entregaría un retorno superior en estos papeles de alta duración. Cada vez que el BCCh
 baje la TPM, de acuerdo a lo esperado, se produciría ese día una ganancia de capital que no obtendría si solo
 invierto en depósitos de corto plazo. ¿Qué opina usted respecto de los fundamentos de esta recomendación de
 invertir en bonos de largo plazo en pesos? Haga los supuestos que considere necesario para responder esta
 pregunta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 124

[pág. 125]
Finanzas - versión clara y reordenada
 Teoría Financiera | enero 2022 | pregunta 6
 Convocatoria 1 | página original 362 | UF, inflación y eficiencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 PREGUNTA Nº6
 Chile tiene mercados de deuda tanto nominal como indexada al alza del costo de vida representada por la UF
 (unidad de fomento). Suponga que la tasa de interés que se exige en el mercado a un bono nominal, o que
 ofrece pagos en pesos, es 𝑦 , en tanto que el rendimiento exigido en el mercado a un bono indexado a la UF
 es 𝑦 . Es común en el mercado referirse a la diferencia (o spread) 𝑦 − 𝑦 como el break-even de inflación.
 En simple, una tasa de inflación para el periodo igual a 𝑦 − 𝑦 implica que el retorno total medido en pesos
 1
 de ambos bonos es exactamente el mismo . Una inflación efectiva mayor a 𝑦 − 𝑦 implica que el retorno
 en pesos del bono indexado a UF fue mayor al del retorno del bono nominal.
 Preguntas:
 Responda las tres preguntas que se le formulan a continuación. Fundamente cuidadosamente sus respuestas.
 a) Economistas argumentan que tanto la expansión fiscal fruto de la pandemia, como los problemas de
 oferta, han llevado a alzas sistemáticas de precios y a una mayor inflación en 2021 (7,2%, la más alta
 en Chile desde hace una década). Frente a esta inflación en alza, su jefa le pide su opinión respecto de
 nominalizar (invertir en instrumentos de deuda denominados en pesos) o indexar (invertir en
 instrumentos de deuda que tengan reajustabilidad en UF) totalmente su cartera de renta fija. Desarrolle
 una regla de decisión que relacione su expectativa subjetiva de inflación (por ejemplo, basada en sus
 propios modelos económicos o análisis estadístico) con el break-even de inflación observado en el
 mercado para los bonos en pesos y en UF. Suponga que su jefa es neutral al riesgo y que, por lo tanto,
 solo le importa el pago esperado de cada estrategia (no su riesgo).
 b) No solo ha subido la inflación en el último año, sino que también la incertidumbre respecto de la
 inflación futura. Suponga ahora que su jefa es aversa al riesgo, y que prefiere medir los retornos de las
 inversiones en términos de su poder adquisitivo real, es decir, en UF. Si su jefa sigue pensando en
 nominalizar o indexar el 100% de la cartera de renta fija. ¿cómo se modifica, si es que es necesario
 hacerlo, la regla de decisión del inciso a) anterior? No se espera que usted entregue una respuesta
 cuantitativa, sino que explique cualitativamente qué nuevos elementos es necesario incorporar a la
 regla de decisión, de ser el caso.
 c) Una analista del Banco Central que es su amiga está interesada en predecir la inflación futura usando
 datos macroeconómicos y de mercado. Suponga que corre una regresión predictiva de este tipo:
 𝜋 = 𝛼 + 𝛽(𝑦 − 𝑦 ) +𝜀
 Donde 𝜋 es la inflación observada en h periodos después del periodo t, (𝑦 − 𝑦 ) es el break-
 even medido en el periodo t, y 𝜀 es el residuo (error) de la regresión. Esta analista encuentra que el
 poder predictivo del break-even para inflaciones futuras es muy bajo (por ejemplo, baja magnitud y
 significancia del coeficiente 𝛽, bajo 𝑅 de la regresión, etc.). Dado que usted trabaja en el sistema
 financiero, la analista llama para pedirle su ayuda en entender este resultado. En algún punto de la
 conversación su amiga analista hace la siguiente aseveración: “La regresión indica que el mercado de
 la renta fija chilena es totalmente ineficiente: los partícipes del mercado hacen pésimas proyecciones
 de inflación (…)”. Elabore una explicación para su amiga basándose en lo que ya analizó en los incisos
 a) y b) de esta pregunta. ¿Puede el mercado nacional de renta fija ser eficiente a pesar de lo encontrado
 por su amiga en la regresión predictiva? Fundamente su respuesta.
 1 En estricto rigor, esta afirmación es solo aproximadamente correcta, o funciona bien cuando la tasa de inflación es baja.
 Si usamos tasas logarítmicas la afirmación es exacta. Para efectos de esta pregunta puede suponer que no hay error de
 aproximación o que estamos hablando de tasas logarítmicas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 125

[pág. 126]
Finanzas - versión clara y reordenada
 Dirección Financiera - 35 preguntas
Examen de Grado UC | materia, preguntas y respuestas 126

[pág. 127]
Finanzas - versión clara y reordenada
 Dirección Financiera | enero 2012 | pregunta 3
 Convocatoria 1 | página original 92 | APV y escudo tributario
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº 3
 Una empresa está evaluando la conveniencia financiera de llevar a cabo un primer y único proyecto de inversión cuyas
 principales características son las siguientes:
 • La inversión inicial sería de $ 4.000 (el total de ella se debe realizar al inicio de la vida del proyecto) y se destinará en su
 totalidad a la adquisición de activos operacionales que se depreciarán contablemente a razón de $ 250 por año.
 • El 60% del total de recursos necesarios para el financiamiento de la inversión inicial, es decir $ 2.400 será financiado
 usando un préstamo de un Banco que cobra un interés de 10% anual, equivalente a la tasa de mercado para este tipo de
 deuda. El interés debe ser pagado al término de cada año. Sin embargo, se sabe que si al término de cada año la empresa
 paga al Banco los intereses de su deuda, el préstamo de $ 2.400 se puede renovar de manera indefinida. Los restantes
 $ 1.600 de la inversión inicial, serán financiados con aporte de los dueños.
 • La decisión de financiamiento que la empresa ha tomado para el financiamiento de esta única inversión, le permite operar
 con lo que ella estima es su nivel de endeudamiento económico óptimo de largo plazo y la política es mantener dicho
 nivel a perpetuidad.
 • Los resultados esperados del proyecto, en términos anuales, son los que se presentan a continuación (la depreciación del
 ejercicio, única partida del estado de resultados que no es flujo de caja al final de cada período, se incluye dentro de los
 “Gastos de Administración y Ventas”). Para todos los efectos prácticos, estos resultados se mantendrán constantes a
 perpetuidad:
 Estado de Resultados Anual Esperado
 Ventas $ 10.000
 Costos de Explotación (6.000)
 Margen Bruto 4.000
 Gastos de Administración y Ventas (3.000)
 Resultado Operacional 1.000
 Intereses (10%) (240)
 Resultado antes de Impuestos 760
 Impuestos (30%) (228)
 Utilidad Neta $ 532
 Información Adicional y Supuestos:
 • Se estima que los flujos de caja anuales esperados del proyecto son perpetuos y constantes. La perpetuidad de estos flujos
 se logra gracias a que al término de cada año la empresa reinvertiría la suma de $ 290. No obstante estas reinversiones
 anuales, se sabe que en el futuro y de manera permanente, el gasto contable anual por depreciación, se mantendría en
 $ 250. De este modo entonces, el Resultado Operacional anual esperado se podría mantener de manera perpetua.
 • La tasa de impuestos a las empresas es de 30%.. La Tasa de Impuestos Personales es de 0%
 • La tasa de Costo de Capital Promedio Ponderado (C.C.P.P.) relevante para la evaluación financiera de la inversión es de
 15,0% (C.C.P.P. anual, después de impuestos de las empresas).
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 127

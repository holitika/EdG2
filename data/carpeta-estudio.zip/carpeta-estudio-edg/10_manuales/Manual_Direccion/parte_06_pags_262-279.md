# Manual de Direccion · parte 6 (páginas 262-279)

Fuente: 03_MANUAL_ULTIMATE_DIRECCION_EDG_2027_V2_REORDENADO

[pág. 262]
Dirección - versión clara y reordenada
 3. Sostenibilidad y riesgos. Es potencialmente sostenible mientras la demanda valore
 autenticidad y calidad, la empresa forme suficiente talento artesanal, mantenga estándares y no
 crezca más rápido que su capacidad de producción y control. Riesgos: sucesión y dependencia de
 líderes/diseñadores familiares; escasez de artesanos y transmisión de oficio; copia/falsificación;
 cambios generacionales en preferencias; sustitutos de lujo/segunda mano; shocks de lujo
 discrecional; tensión entre expansión y exclusividad; reputación/ética de proveedores;
 concentración de conocimiento y cuellos de botella. El límite de crecimiento anual puede proteger
 identidad pero también restringir capturas y dejar segmentos/mercados a rivales. Recomendaría
 crecer selectivamente, invertir en formación y sucesión, preservar control de calidad y medir
 calidad, repetición, listas de espera y márgenes, no maximizar volumen. La ventaja no es
 invulnerable ni queda demostrada por el alza bursátil de un año.
 agosto 2025 - pregunta 2 - Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 441-442 | convocatoria
 2
 Volver al enunciado original
 1. Modelo de negocio corporativo y sus elementos. Existe porque Nubank combina negocios
 financieros y conectividad alrededor del mismo segmento y de recursos compartidos, con una lógica
 de creación de valor adicional para el conjunto. La mera coexistencia de una tarjeta y una línea
 telefónica no basta: la corporación debe hacer que ambos negocios rindan más juntos que
 separados, después de pagar los costos de coordinación. El segmento son jóvenes poco
 bancarizados, considerados poco rentables por la banca tradicional. La plataforma digital reúne
 tarjeta, cuenta, Cajitas, préstamos e inversiones, y ahora NuCel. La base de 118 millones de
 clientes, con más de 98 millones activos mensuales, aporta relación, distribución y datos; la
 aplicación y el análisis del feedback permiten diseñar productos adecuados y atender con costos
 menores al no tener sucursales. NuCel arrienda capacidad de red a operadores establecidos,
 evitando inversiones propias en antenas; vende planes con voz y WhatsApp ilimitados, cobrados en
 la tarjeta Nubank. El servicio móvil aporta conectividad y datos adicionales, mientras pagos,
 distribución y personalización financieros apoyan la nueva oferta. La fidelización, la venta cruzada y
 la evaluación crediticia más precisa son consecuencias esperadas de esa complementariedad, no
 resultados demostrados. El crecimiento de 74% del beneficio neto financiero hasta US$557
 millones tampoco acredita por sí solo la rentabilidad de NuCel.
 2. Dos elementos favorables y dos desfavorables, específicos del caso.
 1. A favor: segmento y distribución compartidos. NuCel se dirige a los mismos jóvenes
 subatendidos. La base existente, la aplicación y el cobro en tarjeta permiten comercializar una
 solución adaptada sin reconstruir la relación desde cero. Puede reducir adquisición, facilitar pagos y
 elevar permanencia, siempre que la oferta móvil agregue valor frente a alternativas existentes. 2. A
 favor: complementariedad de datos y entrada sin red propia. El uso activo del móvil puede
 mejorar conocimiento, personalización y evaluación de créditos; arrendar capacidad excedentaria
 evita el desembolso de una red propia. El beneficio depende de que el ahorro de capital y la
 contribución financiera incremental superen los arriendos, el servicio y la coordinación. Más datos
 solo ayudan si son utilizables, pertinentes y de calidad. 3. En contra: dependencia de
 proveedores que son competidores. Los grandes operadores poseen las redes. NuCel depende
 de sus precios, capacidad y continuidad mediante contrato, a la vez que amenaza su mercado. Una
Examen de Grado UC | materia, preguntas y respuestas 262

[pág. 263]
Dirección - versión clara y reordenada
 respuesta competitiva o una mala calidad de red puede comprimir margen y dañar también la
 confianza en Nubank; la ausencia de antenas propias reduce inversión, pero no elimina esta
 dependencia. 4. En contra: nueva economía competitiva y capacidad de ejecución.
 Telecomunicaciones es concentrada y muy competitiva, exige garantizar estabilidad y calidad, y el
 caso señala regulaciones más estrictas que las financieras. La experiencia bancaria no asegura
 capacidad operativa móvil ni rentabilidad duradera. El grupo puede gastar más en cumplimiento,
 servicio e integración de lo que gana por retención y venta cruzada.
 Recomendaría un despliegue gradual con contratos exigibles de calidad y capacidad, equipos
 especializados y medición de contribución por cliente, retención incremental, morosidad, calidad y
 reclamos. Compararía cohortes con y sin NuCel antes de expandir regionalmente: la estrategia será
 exitosa si la sinergia neta es positiva y defendible, no por el tamaño inicial de clientes ni por
 diversificar por sí mismo.
 enero 2026 - pregunta 1 - Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 452-453 | convocatoria
 1
 Volver al enunciado original
 1. Explicación de la estrategia competitiva anterior a la adquisición
 Flixbus era el único operador del norte tanto antes como después de adquirir Postbus. Este último
 tenía 15% del mercado nacional y operaba fuera del norte; por ello, el caso no sustenta que la
 reducción de red en esa región elimine capacidad local duplicada. La explicación estratégica más
 consistente es que, antes de adquirir a su principal rival potencial, Flixbus mantenía una cobertura y
 frecuencia elevadas para hacer menos atractivo el ingreso al norte. Su red de terminales y
 paraderos, junto con la capacidad de ofrecer muchos servicios, comprometía recursos y hacía
 creíble una respuesta competitiva que limitaría demanda y rentabilidad de un entrante.
 Una vez adquirido Postbus, desaparece esa amenaza específica de entrada y Flixbus puede reducir
 parte del costo de sostener cobertura y frecuencia disuasivas. Los datos son coherentes con esa
 inferencia: las rutas bajan de 1.240 a 980 (-21,0%), la frecuencia semanal de 9,2 a 6,8 (-26,1%), y la
 ocupación aumenta de 72% a 84%. La tarifa solo baja de €18,4 a €17,6 (-4,3%). Menos rutas y
 servicios concentran pasajeros, reducen costos y pueden elevar utilización; el precio inferior
 compensa parcialmente la pérdida de conveniencia y protege demanda frente a trenes, avión y
 automóvil. Menor precio monetario no implica automáticamente mayor valor total para el cliente,
 que también soporta más espera o menor acceso.
 La disuasión es una inferencia del caso, no una intención demostrada por la tabla. Debe
 contrastarse con costos y alternativas de demanda. Tampoco desaparece toda competencia
 potencial: la aprobación se fundamenta en contestabilidad y presión de otros medios. Sin datos de
 costos, capacidad por bus y demanda no se estima utilidad ni bienestar. Sí hay datos suficientes
 para describir los cambios anteriores y evitar la explicación de duplicación local.
Examen de Grado UC | materia, preguntas y respuestas 263

[pág. 264]
Dirección - versión clara y reordenada
 2.1. Criterios para evaluar la capacidad disuasiva de las acciones de Turbus
 Turbus debe preguntar si la acción es observable para Flixbus, anterior a su decisión de entrada y
 suficientemente duradera; si compromete recursos de modo que resulte creíble mantenerla tras la
 entrada; si reduce la demanda residual o eleva los costos y reduce la rentabilidad esperada del
 entrante; y si es económicamente factible para Turbus. Importa especialmente la irreversibilidad y el
 costo de imitación: Flixbus no tiene caja ni financiamiento adicional para comprar una empresa
 local. Una ampliación que pueda retirarse inmediatamente o una amenaza que no convenga
 ejecutar después de la entrada tiene poca fuerza como compromiso. Los beneficios deben afectar
 las rutas y atributos relevantes para los pasajeros; gastar más por sí solo no crea una barrera.
 2.2. Orden de mayor a menor capacidad disuasiva
 Primero, C: terminales y paraderos propios. Es la medida con mayor potencial de compromiso
 irreversible y visible: construye una red que mejora acceso, cobertura y experiencia, requiere
 recursos y tiempo para imitar y puede modificar durablemente los costos y atractivo del mercado. La
 falta de financiamiento de Flixbus refuerza esa asimetría. Su fuerza depende de que la red aporte
 una ventaja efectiva y de acceso y de que las inversiones estén hechas o comprometidas antes de
 la entrada; si hay infraestructura alternativa equivalente y accesible, la barrera se debilita. No se
 supone que ser propietario otorgue exclusividad legal frente a rivales.
 Segundo, B: inversión en marca. La comunicación puede crear confianza y preferencia, reducir
 demanda disponible para el entrante y acumular un activo intangible cuyo gasto no se recupera al
 retirarlo. Es menos sólida que una red de infraestructura si solo hay publicidad sin una experiencia
 de servicio que la sostenga; Flixbus puede aportar su reputación internacional y competir con
 atributos distintos. Debe medirse preferencia y retención, no únicamente alcance de anuncios.
 Tercero, A: aumentar frecuencias con buses arrendados. Mejora servicio y puede ocupar
 espacio de mercado rápidamente, pero el arriendo suele ser más reversible que construir
 infraestructura propia. Si Turbus puede devolver buses al terminar el contrato, Flixbus puede prever
 que la expansión se retire al encarecerse la rivalidad, por lo que tiene menor valor como
 compromiso. Puede ser más disuasiva con contratos largos y no cancelables o una rentabilidad
 sostenible de la mayor frecuencia, condiciones que el caso no entrega. La reversibilidad es útil para
 administrar flexibilidad, pero no basta para hacer creíble una amenaza de capacidad sostenida.
 El orden C > B > A se justifica por compromiso, duración, imitación y financiamiento, y debe
 reexaminarse si nueva evidencia muestra infraestructura equivalente fácilmente disponible, marca
 poco valorada o arriendos irreversibles. Es una comparación de la información del caso; no una
 garantía de que Flixbus no entrará.
 enero 2019 - pregunta 4 - Integración Walmart-Cornershop
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 284-285 | convocatoria
 1
 Volver al enunciado original
 La principal ventaja de integrar Cornershop a Walmart es complementariedad: Walmart puede
 aportar marca, compras, inventario, red física y escala; Cornershop, plataforma, datos y relación
 digital con usuarios. Una integración que coordine surtido y despacho puede elevar ventas y
 participación, reducir fricciones y monetizar activos existentes. El valor no surge de “ser dueño”,
 sino del incremento de flujos netos comparado con ambas empresas independientes, descontando
Examen de Grado UC | materia, preguntas y respuestas 264

[pág. 265]
Dirección - versión clara y reordenada
 costo de integración y contraprestación pagada.
 La principal desventaja es perder neutralidad y variedad del marketplace. Si Cornershop prioriza a
 Walmart, usuarios que preferían Jumbo, Unimarc u otros comercios pueden migrar; además,
 Walmart puede canibalizar compra física e impulsiva y limitar el crecimiento de Cornershop al
 excluir vendedores. El conflicto entre maximizar supermercado propio y plataforma multi-retailer
 debe gobernarse con reglas de ranking, datos y acceso.
 Dos amenazas importantes: (1) competidores replican la aplicación o la propuesta de despacho; si
 switching costs son bajos y la experiencia no es única, las rentas esperadas y usuarios pueden
 disiparse. Se mitiga con densidad, fiabilidad, datos útiles, surtido y experimentación; la protección
 de datos es condición. (2) falla de integración por diferencias de cultura, tecnología, velocidad,
 incentivos y procesos, o por represalias de retailers no Walmart que reduzcan variedad. La
 adquisición puede destruir valor si pérdida de terceros supera sinergia de Walmart. Se necesita
 gobernanza con unidad digital, métricas de experiencia y margen por cohortes/retailer, integración
 por etapas y regla de no discriminar indebidamente. Compara escenario integrado/independiente
 por valor presente y prueba hipótesis de retención.
 enero 2023 - pregunta 4 - Integración vertical Toyota
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 383-384 | convocatoria
 1
 Volver al enunciado original
 a) Evaluación de la propuesta de externalizar más. La propuesta no es correcta como regla
 general. Toyota puede externalizar actividades sin perder posición si preserva internamente la
 arquitectura del sistema productivo, diseño del proceso, integración, conocimiento de calidad y
 capacidades que generan confiabilidad/costo. El caso atribuye su reputación no solo a piezas
 baratas, sino a probar/validar componentes y coordinar proveedores para cumplir la promesa “no
 falla”. Externalizar más puede dar acceso a especialización y menor costo, pero aumenta riesgo de
 dependencia, variabilidad de calidad, filtración de conocimiento y descoordinación. La decisión
 debe hacerse actividad por actividad según importancia estratégica, especificidad de activos,
 modularidad, costo total, capacidad de supervisión y contribución a valor percibido.
 b. Intensidad competitiva de proveedores y del mercado final
 En proveedores conviene competencia intensa entre alternativas capaces y verificables:
 disciplina precios y calidad, reduce poder negociador y dependencia y permite acceder a
 especialización sin ceder toda la renta. Si la actividad depende de un proveedor único o de activos
 difíciles de cambiar, externalizar motores y diseño puede crear costos de transacción y apropiación
 que anulen el ahorro. Toyota debe poder verificar confiabilidad y coordinar piezas, no considerar
 equivalentes a todos los oferentes baratos.
 En el mercado final, el ahorro debe ser capturable: clientes tienen que seguir valorando y pagando
 la confiabilidad y Toyota conservar alguna diferenciación o barrera que evite que todos los rivales
 igualen la oferta. Una rivalidad de producto y precio muy intensa puede trasladar íntegramente los
 ahorros al cliente y no mejorar la posición de Toyota. Menor presión competitiva efectiva en el
 segmento que valora confiabilidad, o una diferenciación suficientemente defendible, facilita retener
 el beneficio. Esto no significa que ausencia de competencia garantice éxito: hay que sostener el
 atributo y su coordinación. La combinación favorable es proveedores competitivos y capacidad de
Examen de Grado UC | materia, preguntas y respuestas 265

[pág. 266]
Dirección - versión clara y reordenada
 capturar valor en el mercado final; no basta afirmar que competencia alta en ambos mercados
 vuelve deseable externalizar todo.
 c) Práctica con proveedores. Mantener relaciones de largo plazo con desarrollo conjunto y mejora
 continua (kaizen), objetivos compartidos de calidad/entrega/costo, intercambio de información y
 resolución de problemas en terreno. Toyota debe evaluar resultados y ayudar al proveedor a
 desarrollar capacidad, en lugar de comprar solo al precio spot; a la vez, mantiene estándares,
 auditorías y alternativas para evitar dependencia. Esta práctica convierte proveedores externos en
 parte coordinada del sistema, protege conocimiento tácito y confiabilidad, y hace viable capturar
 beneficios de especialización sin perder control del resultado final.
 enero 2013 - pregunta 4 - Integración vertical/adquisición
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 121-122 | convocatoria
 1
 Volver al enunciado original
 1. Cuándo comprar y cerrar una planta puede crear valor privado. Un competidor lo haría si el valor
 presente de los beneficios incrementales -eliminación efectiva de capacidad, mayor utilización de
 plantas eficientes, reducción de costos, sinergias y eventual aumento del precio sobre su propia
 producción restante- excede precio de compra, costos de cierre, indemnizaciones,
 deuda/contingencias asumidas, pérdida de ingresos y costo de capital: VAN_compra-cierre =
 VP(beneficios de eficiencia + margen incremental por capacidad retirada) - precio de compra -
 costos de cierre - pasivos asumidos - costos de integración. La capacidad debe salir realmente del
 mercado; si se revende o reabre, no hay reducción sostenible. Se requiere que la demanda y
 reacción competitiva permitan capturar margen, que el comprador tenga activos/capacidades para
 obtener beneficios, y que no haya impedimentos regulatorios o estratégicos. El alza de precio
 beneficia a todos los productores supervivientes, por lo que aparece un problema de free rider: el
 comprador paga toda la operación y parte del beneficio se reparte a rivales. Cerrar una planta ajena
 puede ser racional si el comprador capta suficiente beneficio en sus ventas/activos o integra
 recursos que reducen costo; no basta que el acero esté barato. 2. Efectividad para recuperar la
 industria: baja como solución aislada, condicional para operaciones individuales. La oferta excede
 demanda en 300 millones de toneladas (capacidad 1.800 frente a pedidos 1.500), y se proyectan
 otras 350 millones de capacidad; además, la industria está fragmentada y gobiernos sostienen
 plantas ineficientes. Una compra y cierre de una planta puede mejorar margen de un grupo si
 reduce producción efectiva, pero no corrige por sí sola la brecha global. Otros productores pueden
 usar capacidad ociosa, expandirse, entrar o recibir apoyo estatal, presionando precios de nuevo.
 Sin cierre verificable de volumen significativo, disciplina de producción y menor inversión futura, el
 efecto sería limitado o temporal. La propuesta puede ser efectiva para una compañía que compra
 bajo valor, no necesariamente para levantar la rentabilidad del sector completo. 3. ¿Debe CAP
 comprar empresas de acero porque están baratas? No aceptaría la sugerencia como regla general.
 Acero aporta 64% de ventas pero solo 2% del margen bruto; minería 19% de ventas y 90% del
 margen; Novacero 17% y 8%. Comprar más acero expone al grupo a sobrecapacidad y baja
 rentabilidad aunque el precio de entrada sea reducido. La integración no elimina el criterio de
 creación de valor por cada inversión. CMP opera al 50% de su capacidad potencial, pero alcanzar
 ese potencial exige inversiones nuevas cuyo costo está en el promedio industrial; no equivale a
 tener capacidad instalada gratuita ociosa. Esa ampliación es una alternativa relevante al uso de
 capital en adquisiciones siderúrgicas, aunque su alto aporte de margen tampoco garantiza el
Examen de Grado UC | materia, preguntas y respuestas 266

[pág. 267]
Dirección - versión clara y reordenada
 retorno de la inversión marginal. Compararía los flujos netos de comprar y operar, comprar y cerrar,
 ampliar minería y no invertir, incluyendo demanda de mineral, costos, capital y respuesta de
 rivales/gobiernos. Una compra de acero solo es recomendable si CAP puede capturar sinergias o
 beneficios de cierre superiores a precio, pasivos, integración y costo de oportunidad. No hay datos
 suficientes para aprobar una adquisición concreta ni para afirmar que cualquier inversión minera
 sería mejor. Conclusión. La adquisición debe responder a una ventaja concreta de CAP y a una
 salida permanente de capacidad. El caso no entrega precios de activos, costos de cierre,
 volúmenes ni sensibilidad de precios para aprobar una compra específica. La recomendación
 correcta es evaluar por escenarios y comprar/cerrar únicamente si la captura privada supera el
 costo, no comprar solo por oportunismo de precio.
 agosto 2016 - pregunta 4 - Integración y economías de alcance
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 213-216 | convocatoria
 2
 Volver al enunciado original
 1. Dos causas del bajo resultado
 Desalineamiento de objetivos y externalidades. ABC recibe ingresos por vender letreros y
 asume sus costos operativos; no captura necesariamente el aumento de ventas del locatario y de
 arriendo variable del mall. La publicidad se dirige exclusivamente a visitantes hacia locales del
 propio centro: afecta directamente la actividad que genera el ingreso principal. La parte variable del
 arriendo es 40%, con tasas de hasta 10-12% en locales pequeños frente a 0,5% de grandes anclas.
 Priorizar anclas o maximizar la tarifa de publicidad puede ser rentable para ABC y dejar de
 maximizar el ingreso total de Grupo Real. No hay que valorar publicidad solo como el menos de 2%
 de ingresos que recauda directamente.
 Gestión subordinada y captura contractual no vinculada al valor total. El contrato es solo 10%
 de la cartera de negocios de la gerente de Marketing -el caso no dice que dedique exactamente
 10% de su tiempo- y paga 45% de ventas con piso de US$250.000; los ingresos de alrededor de
 US$285.000 están apenas por encima del mínimo. Falta una gestión integrada de tráfico, mix de
 locales, compra promedio, vacancia y efectividad por ubicación. El porcentaje aislado no permite
 afirmar que sea injusto sin costos, pero el diseño puede desaprovechar la contribución del mall, su
 audiencia y sus relaciones comerciales.
 2. Gestión interna o externa
 Optaría por gestionar internamente la estrategia y decisiones comerciales de la publicidad,
 integradas a la gestión del mall. Su valor principal incluye las ventas de locatarios, retención,
 vacancia y renta variable, que Grupo Real sí internaliza. Debe elegir ubicaciones, campañas y
 prioridades por su efecto sobre los ingresos y experiencia del conjunto, no solo por la venta de
 letreros. Que sea un ingreso directo pequeño no lo convierte en una actividad estratégicamente
 irrelevante.
 Esto no obliga a fabricar o instalar todos los soportes: puede contratar operación técnica y
 comercial especializada con metas alineadas, datos, auditoría y responsabilidad clara. Si conserva
 un proveedor, Grupo Real debe controlar la estrategia y el aprendizaje sobre ventas y flujo, y
 diseñar el contrato para aproximar el objetivo total. La internalización requiere capacidades y tiene
 costo; compararía su beneficio neto con una gobernanza externa bien diseñada. La información
Examen de Grado UC | materia, preguntas y respuestas 267

[pág. 268]
Dirección - versión clara y reordenada
 sustenta centralizar la gestión del valor estratégico, pero no demuestra que asumir cada tarea
 operativa sea rentable.
 agosto 2017 - pregunta 4 - M&A y sinergias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 246-247 | convocatoria
 2
 Volver al enunciado original
 1. Dos razones para evaluar la afirmación de Polman
 No aceptaría la afirmación categórica de que la operación carece de justificación financiera y
 estratégica. Primera razón: el caso aporta un potencial concreto de eficiencia. Después de integrar
 Kraft y Heinz, el flujo operacional pasó de aproximadamente 20% a 35% de los ingresos; los
 ahorros llegaron a US$1.800 millones, frente a US$1.500 millones previstos. La comparación
 presentada indica un gasto de venta de Unilever cercano al doble del de Kraft Heinz y estima que
 reducirlo en un tercio cubriría el precio de adquisición. Estas cifras no garantizan repetir los
 resultados en otra empresa, pero sí constituyen una hipótesis financiera que debe analizarse; no
 pueden descartarse sin examinar qué costos son prescindibles y cuáles sostienen la diferenciación.
 Segunda razón: la propuesta incorpora una prima de 18%, US$50 por acción, y valoriza Unilever en
 alrededor de US$143 mil millones. El mercado inicialmente eleva el precio 28% y después cae 10%
 sobre ese nivel: si el valor inicial es 100, pasa a 128 y luego a 115,2, todavía 15,2% por encima del
 punto de partida. Es consistente con la expectativa de que hay valor adicional por capturar, ya sea
 mediante otra oferta o mediante mejoras propias; por sí solo el precio no distingue ambas causas.
 El anuncio posterior de Polman de revisar estrategia, procesos y costos prescindibles refuerza que
 la organización también identifica oportunidades de productividad. La justificación estratégica
 consiste en combinar marcas y diferenciación valiosas con mejor eficiencia y disciplina de captura,
 siempre que la integración no destruya el valor social y ambiental por el que el cliente paga.
 2. Evaluación del analista: complementariedad o estrategias diferentes
 La estrategia articula una propuesta de valor, los clientes atendidos, las actividades y recursos que
 la hacen posible y el modo de capturar valor. La de Polman usa responsabilidad social y ambiental,
 vínculo con comunidades y marcas para generar diferenciación y disposición a pagar. La disciplina
 de 3 G busca elevar eficiencia, reducir costos y aumentar el flujo que la empresa retiene. Coincido
 con el analista en que pueden ser complementarias, porque elevar eficiencia no obliga a
 cambiar la estrategia genérica ni a eliminar la diferenciación: una empresa puede mantener el
 beneficio relevante para clientes y capturar una mayor parte al realizar sus actividades con menos
 recursos.
 La complementariedad tiene un límite concreto. Si se recortan actividades ambientales, innovación,
 relaciones comunitarias o calidad que explican el precio superior, bajaría la generación de valor y
 podrían erosionarse marcas y ventas. Si se eliminan duplicaciones y gastos que no sostienen ese
 valor, aumenta su captura. La posición de Polman es defendible como advertencia ante esos
 riesgos y como defensa de identidad, pero es demasiado absoluta al presentar eficiencia y
 propósito como incompatibles. Debe compararse el ahorro posible con sus efectos sobre clientes,
 capacidades y largo plazo, no rechazar de partida la adquisición solo porque su comprador tiene
 una orientación marcada a la eficiencia.
Examen de Grado UC | materia, preguntas y respuestas 268

[pág. 269]
Dirección - versión clara y reordenada
 agosto 2019 - pregunta 4 - Modelo de alianza/plataforma
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 296-297 | convocatoria
 2
 Volver al enunciado original
 a. Tres cambios del modelo de negocio
 1. Propuesta y clientes. Antes, Viajes Falabella ofrecía principalmente paquetes a clientes de la
 multitienda. Después incorpora el catálogo y las capacidades turísticas de Despegar y una oferta
 financiera y de fidelización más integrada: CMR, doble acumulación de puntos y canje en ambos
 sitios, call centers y sucursales. Puede ampliar variedad y clientes, manteniendo la marca; no
 cambia simplemente de nombre. 2. Canales y actividades. El negocio inicialmente se apoyaba en
 tiendas físicas. Despegar pasa a operar los canales digitales, call centers y puntos físicos dentro de
 Falabella, combinando su experiencia online con presencia y atención presencial. La nueva
 arquitectura es omnicanal y conecta reservas, pagos, financiamiento y lealtad. 3. Propiedad,
 recursos y captura. Despegar adquiere el 100% por US$27 millones y opera el negocio; Falabella
 deja la operación turística directa y mantiene licencia de marca y alianza de diez años,
 concentrándose en su aporte financiero y comercial. Despegar suma experiencia en paquetes -65%
 de los US$50 millones de ingresos de Viajes Falabella en 2018-, marca y red física; Falabella
 mantiene acceso al consumo turístico para desarrollar CMR sin administrar todo el negocio. El caso
 no especifica nuevas comisiones o el reparto contractual exacto: no deben inventarse.
 b. Reacciones bursátiles distintas
 El 8% de Despegar frente al 0,2% de Falabella es compatible con una oportunidad
 proporcionalmente mayor para la compradora y con sinergias que ella captura directamente:
 desarrollo de paquetes, canal físico, base leal y financiamiento para clientes de viajes. Viajes
 Falabella tuvo EBITDA de US$3,5 millones, aproximadamente 7% de sus ingresos; Despegar
 puede esperar mejorar escala y crecimiento con capacidades complementarias, aunque el múltiplo
 precio/EBITDA cercano a 7,7 no prueba por sí solo que la compra sea barata.
 Para Falabella, el negocio vendido es pequeño dentro de un portafolio que incluye multitiendas,
 supermercados, centros comerciales y finanzas: incluso un beneficio positivo se diluye en el valor
 total. La venta aporta caja y permite concentrarse en capacidades financieras, pero ya no retiene
 directamente todos los flujos del operador turístico. Son explicaciones específicas y plausibles, no
 prueba de causalidad: sin valores iniciales no corresponde comparar el valor monetario creado con
 los porcentajes, y las expectativas previas también afectan la reacción.
 marzo 2011 - pregunta 2 - Modelo de negocio y ventaja competitiva
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 60-61 | convocatoria 1
 Volver al enunciado original
 1. Modelo de rentabilidad. Huffington Post crea valor para lectores con acceso digital, amplitud de
 temas, curaduría/actualidad, navegación digital y voces/comentarios que generan participación; la
 publicidad monetiza atención y alcance. Contenido de colaboradores reduce costos marginales de
 producción y aumenta variedad, mientras marca, audiencia, distribución social/buscadores y datos
 atraen anunciantes. El ciclo audiencia → inventario publicitario/datos → ingresos e inversión en
 distribución → nueva audiencia puede producir escala y efectos de red indirectos. El modelo puede
 crear ventaja si la plataforma retiene lectores y anunciantes con costos por visita menores y mejor
Examen de Grado UC | materia, preguntas y respuestas 269

[pág. 270]
Dirección - versión clara y reordenada
 segmentación; el contenido gratuito no es por sí mismo una barrera.
 Recursos/capacidades clave: marca y credibilidad; tecnología de publicación, recomendación y
 distribución; relaciones con colaboradores/editores; capacidad de curar y empaquetar; analítica de
 audiencia; ventas publicitarias y rapidez de respuesta. Son estratégicos solo si son valiosos, se
 combinan y permiten apropiarse de ingresos. Riesgos: contenido de calidad inconsistente,
 dependencia de tráfico de terceros, cambios de algoritmo, baja lealtad, costos de verificación,
 competencia por publicidad y sustitución por otras plataformas.
 2. Impacto en prensa tradicional. Puede ser un golpe porque desplaza audiencia y publicidad
 hacia digital, reduce barreras de entrada y fragmenta la atención; medios con costos fijos de
 impresión/distribución y menor adaptación pueden perder escala y margen. Pero no se sigue que la
 prensa tradicional no pueda recuperarse: conserva periodismo original, confianza, investigación,
 marca, suscripciones y relaciones locales. La respuesta estratégica es diferenciar y cobrar por
 contenido valioso, desarrollar capacidades digitales, usar datos propios, formatos y membresías, y
 reconfigurar costos sin sacrificar calidad. La amenaza afecta a quien no adapta propuesta y modelo;
 no demuestra que todo periódico sea sustituible.
 enero 2016 - pregunta 4 - Modelos productivos y ventaja
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 191-192 | convocatoria
 1
 Volver al enunciado original
 1) Fuentes de valor bajo el VAN. VAN=valor presente de los flujos incrementales después de
 inversión inicial, capital de trabajo y riesgo. Las tres fuentes concretas para cada modelo son:
 Tradicional. (i) Compra de lotes grandes y negociación global reducen costo unitario/proveedor; si
 se vende a precio comparable, sube margen bruto y FC. (ii) Distribución a toda la red aprovecha
 tiendas, marca y volumen para generar ventas y economías de escala. (iii) Gestión de precios y
 liquidación al final recupera parte de inventarios sobrantes y reduce pérdidas frente a dejar stock sin
 vender. Su contrapartida es ciclo de 6-9 meses, capital inmovilizado e incertidumbre de moda:
 liquidaciones erosionan precio/margen y el inventario no vendido destruye valor. No tradicional. (i)
 Lotes iniciales pequeños y locales reducen la exposición a pronósticos equivocados, inventario y
 markdowns; es una opción de aprender antes de escalar. (ii) Reposición rápida en tres semanas
 permite aumentar producción solo para productos con ventas probadas y retirar pronto los fallidos;
 mejora el porcentaje vendido a precio completo y la rotación de capital. (iii) Variantes locales y
 oferta dinámica aumentan ajuste cliente-producto, frecuencia y ventas potenciales. Las
 contrapartidas son mayor costo unitario de producción cercana, logística exigente, riesgo de perder
 ventas por lote piloto pequeño y necesidad de coordinación/datos. Una relación útil es VAN = -I
 0-CT 0 + ΣFCF_t/(1+k)^t. Lotes menores/menos inventario pueden disminuir CT 0 y riesgo de flujos;
 logística y reposición afectan costos e ingresos; velocidad adelanta cobros, elevando valor
 presente. La ventaja del modelo depende de que el valor de rapidez, aprendizaje y menos rebajas
 supere sus costos. No se puede concluir que un modelo siempre gane: depende de volatilidad de
 demanda, márgenes, capacidad y costo de respuesta. 2) Decisión para una boutique local.
 Evaluaría tres condiciones. Capacidades: ¿puede financiar lotes de prueba y montar diseño, datos,
 producción cercana, reposición y logística rápidos? Sin ellas, copiar el modelo no tradicional puede
 crear quiebres y costo elevado. Economía de la demanda y el canal: si el producto es
 diferenciado/local y la demanda volátil, un piloto pequeño compra aprendizaje; pero una boutique
Examen de Grado UC | materia, preguntas y respuestas 270

[pág. 271]
Dirección - versión clara y reordenada
 que vende más de 70% por grandes tiendas tradicionales y obtiene allí 15% de su margen depende
 del canal y de sus ciclos de compra. Debe medir margen neto, comisiones, rotación y riesgo de
 perder distribución al cambiar. Costo de transición y opción de coexistir: comparar VAN por
 escenarios, incluyendo inventario, capital de trabajo, inversión, velocidad y posible canibalización.
 Puede probar unos estilos o canal directo mientras conserva distribución actual, ampliar si los datos
 muestran mejores márgenes/rotación y detener si no. La decisión debe basarse en resultados del
 piloto, no en imitar a Zara por su reputación.
 agosto 2013 - pregunta 4 - Posicionamiento y eficiencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 132-133 | convocatoria
 2
 Volver al enunciado original
 1. Propuestas de valor. Son distintas en énfasis, aunque se superponen en ofrecer transporte
 regional conveniente y buenos precios. Alaska: vuelos seguros/confiables y tarifas bajas para
 quienes viajan por la costa oeste de EE.UU., Alaska y Hawaii; su eficiencia de costos le permite
 sostener una promesa de precio atractivo. Copa: la opción más completa y conveniente para viajar
 entre ciudades de Centro y Sudamérica y conectarlas con EE.UU., gracias a su red y conexiones
 rápidas vía Panamá; combina opciones, tiempo de conexión y precios competitivos. No describiría
 Copa solo como “bajo costo”: su promesa principal es conectividad conveniente y alcance de red. 2.
 Modelos de negocio y rentabilidad. Comparten flota estandarizada y alcance regional, que reducen
 costo de mantenimiento, repuestos y complejidad, y permiten utilización eficiente de aviones. Pero
 la lógica de captura difiere: - Alaska compite por tarifas bajas con costo por pasajero menor.
 Obtiene margen mediante control de costos, flota nueva/uniforme, eficiencia de combustible,
 compras de petróleo, estructura liviana y bajo gasto financiero. Sus áreas críticas son operaciones,
 utilización de flota, compra de combustible, mantenimiento, estructura de capital y venta de rutas
 regionales. Activos/capacidades: disciplina de costos, financiamiento favorable, procedimientos y
 conocimiento regional. - Copa monetiza una red de conexiones: concentra vuelos en Panamá,
 reúne pasajeros de múltiples orígenes, conecta con destinos y minimiza espera/tiempo en tierra.
 Genera valor por combinación de rutas, frecuencias y conexiones; captura con ocupación,
 productividad de flota y atractivo para viajeros que prefieren una conexión rápida frente a itinerarios
 alternativos. Áreas/recursos clave son planificación de red, coordinación de horarios, hub
 geográfico, acuerdos de conexión y reputación de servicio. La tarifa es competitiva, pero su fuente
 distintiva no es únicamente ser la de menor costo. 3. Sustentabilidad. Me inclino por la ventaja de
 Copa, con carácter condicional. El hub panameño, la coordinación de horarios, la densidad de
 conexiones y las rutinas que permiten 50 minutos de espera forman un sistema complementario; la
 ubicación no puede copiarse y la red, reputación y aprendizaje de décadas toman tiempo. Bajo
 VRIO, esos recursos pueden ser valiosos, relativamente raros para los destinos y difíciles de imitar
 como conjunto, siempre que Copa los organice y mantenga buen servicio. Alaska también muestra
 una estrategia muy coherente y una capacidad de bajo costo valiosa, pero flota uniforme, 737,
 compras eficientes y tarifas bajas pueden ser replicables; precios del petróleo, financiamiento y
 expansión de competidores pueden erosionar su ventaja. Esta comparación no implica que Copa
 sea invulnerable: congestión, costos del hub, cambios de rutas, sustitutos o una mala ejecución
 pueden debilitarla. Alaska podría ser más sostenible si su disciplina operativa produce una brecha
 de costos persistente y medible.
Examen de Grado UC | materia, preguntas y respuestas 271

[pág. 272]
Dirección - versión clara y reordenada
 agosto 2023 - pregunta 4 - Sostenibilidad y modelo de negocio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 396-397 | convocatoria
 2
 Volver al enunciado original
 1. Cómo robustecer el modelo de Fracción (tres medidas). (i) Construir una relación recurrente
 con pacientes crónicos mediante suscripción y reposición coordinada con receta, recordatorios y
 entregas confiables. La recurrencia aumenta previsibilidad de demanda y valor de vida del cliente;
 debe protegerse la privacidad y evitar incentivar consumo inadecuado. (ii) Integrar canales y
 servicios: combinar plataforma con puntos regionales, farmacias móviles y convenios municipales,
 telemedicina y redes de salud cuando corresponda. Esto mejora acceso y tiempos, amplía alcance
 y crea complementariedades, pero debe sostener economía logística en zonas de baja densidad.
 (iii) Diferenciarse con confianza, disponibilidad y eficiencia operacional: selección de surtido
 esencial, compras institucionales/Cenabast dentro de las reglas, trazabilidad de inventario, analítica
 de demanda y cumplimiento farmacéutico. Así baja costo de servir y se fortalece la propuesta de
 precio y acceso. Las medidas forman una secuencia: densidad/repetición de demanda reduce costo
 por entrega y permite servicio confiable; tecnología sola no constituye barrera, y la dependencia de
 regulación/proveedores y márgenes estrechos sigue siendo riesgo.
 2. Por qué las cadenas tradicionales podrían no imitarla: tres razones. Primero, conflicto de
 posicionamiento y canibalización: una oferta enfocada en precio bajo, menor variedad y
 fraccionamiento puede erosionar margen y marca de cadenas orientadas a amplitud, conveniencia
 inmediata y venta de cajas completas. Segundo, estructura y actividades distintas: locales, surtido,
 inventario, contratos, sistemas y procesos de despacho fueron diseñados para escala física; migrar
 exige inversión, rediseño y asumir costos de transición, sin garantía de rentabilidad en segmentos
 de menor ticket. Tercero, capacidades/incentivos y restricciones: compras, métricas y poder de
 negociación de grandes cadenas pueden favorecer portafolio amplio y venta por local; la venta
 fraccionada, compras públicas y trazabilidad requieren procesos y cumplimiento específicos. No es
 que sean incapaces en abstracto: una cadena podría crear una unidad separada o alianzas, pero
 debe evitar que sinergias aparentes oculten canibalización y costos. La justificación se limita a la
 información del caso y no atribuye intenciones no observadas.
 enero 2025 - pregunta 3 - Transformación de industria y calidad estratégica
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 431-432 | convocatoria
 1
 Volver al enunciado original
 1. Efectos de los cambios competitivos sobre generación de valor, captura y riesgo
 Amazon, cadenas de descuento como TJ Maxx y marcas online alteran la forma de comprar, los
 costos y las alternativas del cliente. La comparación digital de precios y surtido, junto con mayor
 comodidad, eleva el poder de elección y presiona precio, servicio y diferenciación de Macy's,
 Nordstrom y JCPenney. Hay dos efectos de demanda: nuevos segmentos, como los jóvenes,
 entran a la compra online; y parte del segmento tradicional de 45-60 años migra al canal digital. La
 primera tendencia puede ampliar el mercado; la segunda amenaza las ventas físicas de
 incumbentes. Por ello el cambio no destruye todo el valor de la industria, pero cambia qué
 propuestas lo crean y quién puede capturarlo.
Examen de Grado UC | materia, preguntas y respuestas 272

[pág. 273]
Dirección - versión clara y reordenada
 Crear valor exige que la experiencia presencial, asesoría, prueba y confianza ofrezcan beneficios
 que el cliente siga valorando, y que se integren con comodidad digital cuando corresponde. Los
 productos de alto involucramiento y el uso de la tienda como showroom preservan un papel para la
 presencia física, aunque visitar la tienda no garantiza comprar en ella ni que la empresa capture la
 venta. Capturar valor requiere que el precio y la contribución de ventas superen costos de
 infraestructura, logística, inventario, marca y atención. Comparación y promociones intensifican
 rivalidad: una mayor venta con descuentos no asegura mayor margen. Las redes de tiendas
 dependen de escala; perder volumen eleva el costo fijo por venta y deteriora captura aun si el
 cliente aprecia el servicio.
 El riesgo aumenta por sustitución digital, cambios permanentes de preferencias y caída del tráfico
 de malls, además de incertidumbre macroeconómica que desplaza gasto hacia básicos. Altas
 inversiones y costos operativos amplifican la sensibilidad del resultado a la demanda; hay riesgo de
 activos físicos obsoletos y de que inversiones de reconversión no recuperen su costo. El posible
 cierre del 25% de unos 1.100 malls en cinco años y los 5.300 cierres ya señalados ilustran esa
 exposición. A la vez, digitalizar e integrar logística crea costos y riesgo de ejecución. Diferenciarse
 reduce comparación directa únicamente si el segmento valora y paga esa diferencia.
 2. Aspectos positivos, negativos y juicio sobre el nuevo plan
 El plan nuevo del CEO debe evaluarse tal como se describe: foco presencial y cliente tradicional,
 negocio online sin desarrollos adicionales, tiendas más pequeñas fuera de malls, más outlets,
 marcas de lujo en locales seleccionados, inversión logística y modernización de experiencia física.
 Marcas propias y promociones agresivas aparecen como medidas previas en el diagnóstico; no
 reemplazan la evaluación de esas directrices nuevas.
 Hay elementos positivos. La focalización preserva conocimiento de un cliente que aún aprecia
 presencia y experiencia. Salir de grandes malls hacia formatos menores puede reducir
 compromisos de inversión y costos y mejorar proximidad, especialmente ante cierres de centros
 comerciales. Los outlets y diez nuevas tiendas Backstage ofrecen una salida para inventario fuera
 de temporada y atienden sensibilidad al precio. El lujo selectivo puede aumentar diferenciación y
 contribución en un público aspiracional. Logística y modernización pueden mejorar disponibilidad,
 eficiencia y servicio, y preservar el valor de categorías de alto involucramiento.
 También hay riesgos. Mantener el online sin desarrollos adicionales ignora una migración que el
 caso considera permanente, incluso dentro del segmento objetivo; permite que rivales capten
 compras y relaciones futuras. Reducir el formato exige suficiente volumen y una selección de
 surtido coherente: se puede perder la variedad y escala que hacían viable la multitienda. Salir del
 mall reduce dependencia, pero también pierde tráfico compartido y entretenimiento que varios
 consumidores valoran. Outlet y lujo cumplen funciones distintas y pueden coexistir por formatos y
 segmentos, pero necesitan roles claros para evitar canibalización, confusión de marca y clientes
 acostumbrados a descuentos. Modernizar activos físicos y logística requiere caja y retorno por local;
 hacerlo indiscriminadamente podría aumentar exposición a un canal en declive. Abrir diez outlets no
 demuestra que se compensen los cierres de 150 tiendas ni los costos del nuevo sistema.
 Mi juicio es que la estrategia tiene componentes coherentes y útiles, pero, en su conjunto y
 como respuesta de largo plazo al diagnóstico, es insuficiente. La principal contradicción es
 reconocer que el comercio electrónico cambia al consumidor y limitar el desarrollo de ese canal. No
 hace falta buscar a todos los jóvenes ni abandonar el cliente tradicional; sí ofrecerle una experiencia
Examen de Grado UC | materia, preguntas y respuestas 273

[pág. 274]
Dirección - versión clara y reordenada
 integrada de búsqueda, compra, retiro, devolución y asesoría, con papeles distintos para tiendas y
 canal digital. Recomendaría desarrollar esa integración, probar formatos pequeños y lujo donde
 haya demanda, asignar outlets a liquidación y valor con una identidad clara, y invertir o cerrar según
 contribución y valor de red de cada local. Mediría margen por cliente/local, repetición,
 canibalización, inventario y retorno del capital. La caída de 75% de la acción y los resultados
 semestrales débiles refuerzan la necesidad de revisión, pero no identifican por sí solos qué decisión
 causó el deterioro.
 enero 2022 - pregunta 4 - VRIO y diversificación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 359-360 | convocatoria
 1
 Volver al enunciado original
 a) Fuentes de ventaja competitiva. Cirque du Soleil combina diferenciación artística con un
 modelo de producción que eleva disposición a pagar: narrativa, música, acrobacia, diseño visual y
 una experiencia integrada que no compite solo con circos tradicionales. La marca y reputación
 reducen incertidumbre del espectador y permiten giras/licencias internacionales; capacidades
 creativas de diseñar y renovar espectáculos, atraer artistas, coordinar producción y operar
 salas/carpa convierten esa promesa en experiencia repetible. La ventaja no reside en un elemento
 aislado: creatividad, talento especializado, dirección escénica, producción, marketing y distribución
 se complementan. Su reputación y conocimiento acumulado son difíciles de imitar rápidamente; sin
 embargo, parte de las capacidades depende de personas y relaciones, y la diferenciación debe
 renovarse. La singularidad crea valor si el público la valora y paga; la captura depende de
 ocupación, precio, derechos, costos de producción y contratos.
 b) Robustecer ante shocks como pandemia. Mantener la experiencia central pero reducir
 fragilidad financiera y operativa: (i) combinar giras y espectáculos residentes con ingresos menos
 correlacionados o más escalables (contenido audiovisual/digital, licencias, alianzas y productos),
 cuidando que lo digital complemente y no sustituya sin valor la experiencia en vivo; (ii) hacer la base
 de costos y compromisos más flexible -contratos por temporada, producción modular, pausas o
 escalamiento de giras, planificación de liquidez y reservas- y stress-testear escenarios de cierres
 prolongados; (iii) diversificar geografía, canales y fuentes de financiamiento, además de preparar
 protocolos de salud/seguridad, seguros disponibles y contingencia con artistas, recintos y
 proveedores. La empresa debe evaluar costo de flexibilidad frente a eficiencia en operación normal,
 preservar talento y marca, y no asumir que digitalizar sustituye las ventas presenciales. Métricas:
 liquidez/supervivencia bajo escenarios, punto de equilibrio por espectáculo, concentración de
 ingresos, ocupación, margen de contribución y demanda por formato.
 agosto 2018 - pregunta 4 - Ventaja de plataforma y respuesta
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 272-273 | convocatoria
 2
 Volver al enunciado original
 El cambio regulatorio que obliga a Uber a tributar más no implica por sí solo el fin de rentas sobre
 normales. VRIO pide explicar si una fuente sigue siendo valiosa, rara, difícil de imitar y explotada
 por la organización. Marca y experiencia pueden atraer usuarios; software, escala, datos y densidad
 de conductores pueden mejorar emparejamiento y reducir espera; efectos de red pueden aumentar
 valor de la plataforma. La regulación sube costos o cambia condiciones, pero también puede
Examen de Grado UC | materia, preguntas y respuestas 274

[pág. 275]
Dirección - versión clara y reordenada
 profesionalizar entrada, elevar cumplimiento y crear diferenciación si Uber logra adaptarse. La
 respuesta depende de elasticidad, pass-through a tarifas, crecimiento y costes de rivales, y de si la
 ventaja es realmente exclusiva. La cifra global de viajes no prueba poder competitivo en Chile.
 Una aplicación propia de los taxistas podría reducir fricción y mejorar información, pero replicar la
 interfaz no reproduce automáticamente liquidez de dos lados, confianza, pagos, reputación, datos ni
 experiencia uniforme. La asociación podría aprovechar conocimiento local, licencia/seguridad y flota
 existente; enfrenta coordinación de conductores, calidad heterogénea, inversión, adquisición de
 usuarios y masa crítica. Recomendaría una propuesta focalizada donde exista ventaja -p. ej., viajes
 regulados/empresariales o segmentos que valoren seguridad- y construir densidad en un
 territorio/horario primero, en vez de lanzar un clon nacional. La prueba compara tiempos de espera,
 tasa de viajes atendidos, retención de ambos lados, costo de adquisición, repetición, seguridad y
 margen por viaje.
 El argumento estratégico distingue imitación de equiparación, y una mejora de eficiencia de una
 posición defendible. Para sostener rentabilidad, Uber debe conservar valor neto ante costos
 regulatorios, evitar que conductores/clientes tengan alternativas equivalentes y organizarse para
 monetizar capacidades. Un rival puede competir exitosamente si elige un nicho y actividades
 distintas, aun sin dominar el mercado total.
Examen de Grado UC | materia, preguntas y respuestas 275

[pág. 276]
Dirección - versión clara y reordenada
 RESPUESTAS DESARROLLADAS ·
 DIRECCIÓN
 Diagnóstico, comparación de marcos, implementación y métricas
 Respuesta D-U1 · Selección y validez incremental
 Primero definiría desempeño técnico y conductual mediante análisis del cargo: calidad, seguridad,
 diagnóstico, explicación al cliente y aprendizaje. La prueba actual mide conocimiento; no sabemos
 si predice ejecución ni trato. Para cada método nuevo identificaría el constructo, confiabilidad,
 validez para esa población, correlación con la prueba base y costo.
 Validez incremental es la mejora que agrega el método nuevo respecto del sistema existente.
 Puede medirse como aumento de predicción, mejor clasificación de candidatos o utilidad
 económica. Una muestra de trabajo estructurada probablemente agrega evidencia cercana al
 desempeño. Una entrevista estructurada con preguntas, anclas y evaluadores entrenados puede
 aportar sobre situaciones y conducta. Una entrevista libre es menos comparable y más vulnerable a
 sesgo. Personalidad sirve solo para rasgos ligados al trabajo y con instrumento válido.
 Pilotearía con candidatos o trabajadores, reservaría una muestra para validación y revisaría
 impacto adverso, accesibilidad, privacidad y experiencia. Definiría reglas de combinación antes de
 observar resultados y analizaría costos de errores. Elegiría el conjunto que mejora decisiones de
 manera suficiente para justificar costo y complejidad; más pruebas no equivalen a mejor selección.
 Respuesta D-U2 · CAGE y modo de entrada
 Culturalmente, lenguaje común reduce una barrera, pero confianza, relación médico-paciente y
 expectativas de servicio pueden diferir. Administrativamente, privacidad, autorización sanitaria,
 responsabilidad profesional y contratación pública pueden dominar la elección. Geográficamente, el
 software viaja barato; husos, soporte e integración local siguen importando. Económicamente,
 ingreso, cobertura, pago de pacientes, infraestructura y costos profesionales cambian disposición a
 pagar y modelo.
 Compararía cada país por segmento y actividad. Perú puede ofrecer cercanía y aprendizaje
 regional, con necesidad de socio local para prestadores y regulación. España puede tener mayor
 poder adquisitivo e infraestructura, junto con reglas de datos y competencia más exigentes. No
 escogería por distancia promedio: una barrera administrativa crítica puede frenar todo.
 Recomendaría entrada escalonada mediante alianza contractual con prestadores en un país piloto,
 manteniendo control de tecnología y datos bajo cumplimiento local. Definiría hitos de integración,
 adopción clínica, seguridad, margen y renovación. Si el aprendizaje demuestra demanda y
 capacidades, aumentaría inversión; si el socio controla clientes o conocimiento crítico, negociaría
 gobernanza y opciones de compra. La decisión final exige mercado, competencia y flujo de caja
 además de CAGE.
Examen de Grado UC | materia, preguntas y respuestas 276

[pág. 277]
Dirección - versión clara y reordenada
 Respuesta D-U3 · Adquisición, cultura y captura de sinergias
 La unificación inmediata confunde integración con homogeneización. La startup fue comprada por
 una capacidad -tecnología y velocidad- que depende de autonomía, talento, decisiones rápidas e
 identidad. Sistemas rígidos pueden elevar rotación, burocracia y aversión al riesgo antes de
 capturar sinergias. Sin integración alguna, en cambio, no se comparte distribución, datos ni escala.
 Separaría sinergias obligatorias y áreas de autonomía. Integraría seguridad, cumplimiento, finanzas
 y acceso comercial; conservaría equipos de producto, métodos ágiles y autoridad sobre decisiones
 reversibles. Crearía una oficina de integración pequeña, equipos de interfaz y responsables por
 sinergia. La evaluación combinaría hitos de producto, calidad, aprendizaje y contribución, evitando
 premiar solo ventas o velocidad. Usaría retención selectiva y carrera sin exigir que todos adopten el
 mismo perfil.
 La secuencia sería: mapear capacidades y personas críticas; comunicar propósito y no
 negociables; diseñar gobernanza; ejecutar pilotos de colaboración; revisar incentivos y cargas;
 escalar lo que funciona. Indicadores: tiempo de desarrollo, incidentes, adopción, margen de
 sinergia, rotación crítica, clima, decisiones demoradas y dependencia de individuos. Si los
 indicadores de valor mejoran mientras cae la capacidad innovadora, la integración está
 consumiendo el activo que pretendía comprar.
Examen de Grado UC | materia, preguntas y respuestas 277

[pág. 278]
Dirección - versión clara y reordenada
 CONTROL FINAL DE FUENTES · DIRECCIÓN
 Fuentes tardías incorporadas y criterio de descarte
 Fuentes cruzadas en esta ampliación
 Fuente local Acción Aporte al manual
 EDG_E_2009-2026_OCR.pdf + Cruce exacto 35 preguntas de Personas y 35 de
 mapa de 210 Empresas/Estrategia
 Guía Maestra EDG 2026 Lectura completa de 69 Validez incremental y CAGE, añadidos al PDF
 (F0042) páginas ampliado y desarrollados aquí
 Resúmenes de Sofía Pieraj y Lectura completa y cotejo AMO, selección, desempeño, incentivos, cultura,
 compilados de Dirección Porter, recursos, integración y crecimiento
 Manual 2018-2026 y Manual Lectura completa Cadena
 Power hecho-mecanismo-decisión-condición-métrica
 Correcciones históricas y Cotejo por convocatoria Casos de integración, sistemas de personas,
 transcripciones identificables plataformas, disuasión y modelos de negocio
 ZIP, capturas e imágenes Extracción y cierre visual Casos, programas, pruebas y pautas que
 académicas confirman alcance
 Archivos no utilizados
 Se descartaron duplicados binarios, inventarios y planes logísticos como fuentes académicas. Los
 audios de corrección se usaron mediante transcripciones o respuestas escritas cuando existían,
 porque entregan mejor trazabilidad que una reconstrucción auditiva. No se encontró un tema
 exclusivo en un archivo audiovisual que faltara en los programas, resúmenes, casos o correcciones
 escritas revisadas.
 Resultado: Dirección conserva 70 preguntas históricas y soluciones desarrolladas. Esta
 ampliación añade los dos conceptos realmente ausentes y tres casos para aplicarlos sin
 convertirlos en listas de frameworks.
Examen de Grado UC | materia, preguntas y respuestas 278

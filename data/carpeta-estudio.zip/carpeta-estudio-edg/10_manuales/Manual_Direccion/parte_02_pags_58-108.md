# Manual de Direccion · parte 2 (páginas 58-108)

Fuente: 03_MANUAL_ULTIMATE_DIRECCION_EDG_2027_V2_REORDENADO

[pág. 58]
Dirección - versión clara y reordenada
 inferiores al costo de capital.
 En integración vertical se compara el costo total de comprar -precio, negociación, búsqueda,
 monitoreo y riesgo de dependencia- con el costo total de producir internamente -producción,
 inversión, dirección e incentivos-. Integrar es atractivo cuando el segundo, ajustado por calidad y
 beneficios estratégicos, es menor. Algunos esquemas invierten esa desigualdad. La especificidad
 de activos puede aumentar dependencia y riesgo de oportunismo: no implica automáticamente
 externalizar. Tampoco obliga a integrar; contratos, alianzas y salvaguardas pueden funcionar. Las
 capacidades relativas y flexibilidad completan el diagnóstico.
 La q de Tobin compara valor de mercado de activos con costo de reposición y puede orientar
 hipótesis sobre oportunidades. No sustituye el VAN de una inversión. ROE superior al costo de
 patrimonio debe interpretarse con apalancamiento, reglas contables y persistencia. Una reacción
 bursátil refleja cambios de expectativas y otra información concurrente; no demuestra por sí sola
 que una adquisición realizó las sinergias ni que la participación de mercado sea la causa.
 E6. Implementación: mapa, agenda y estructura posible
 La implementación debe conectar personas, áreas clave, sistemas de dirección y estructura
 dentro de una cultura y valores. Un área clave sostiene la ventaja: no es simplemente el
 departamento más grande. Sistemas de control, incentivos y evaluación deben inducir conductas
 compatibles. El capital humano proporciona habilidades; el capital de información, datos y acceso
 oportuno; el capital organizacional, coordinación, cultura y rutinas. No se adopta como ley universal
 el porcentaje de valor atribuido a intangibles en ciertos resúmenes.
 Un mapa estratégico expresa hipótesis causales, no solo cuatro cajas del Balanced Scorecard. Por
 ejemplo: entrenamiento técnico y base de fallas → diagnóstico correcto → menor repetición de
 visitas → mayor continuidad del servicio → retención y margen. Cada flecha necesita prueba y
 puede tener rezagos. Una mejora en satisfacción sin margen sostenible tampoco cierra el modelo.
 La agenda convierte la hipótesis en trabajo. Para una empresa que compite por continuidad de
 servicio:
 Elemento Definición concreta
 Objetivo estratégico Reducir las fallas repetidas de12% a7% en nueve meses,
 con calidad verificable
 Lineamiento Mejorar diagnóstico y disponibilidad de repuestos
 Plan general Rediseñar el proceso de atención y aprendizaje de fallas
 Plan específico Piloto de checklist técnico y repuestos críticos en dos
 zonas
 Responsable Jefatura de servicio, con coordinación de logística
 Hito A los tres meses, revisar uso del checklist y fallas por tipo
 Presupuesto Formación, tiempo de pruebas, inventario y sistema de
 datos
 Control y contrapeso Repeticiones, costo por caso, seguridad y reclamos;
 comparar zonas equivalentes
Examen de Grado UC | materia, preguntas y respuestas 58

[pág. 59]
Dirección - versión clara y reordenada
 Una narrativa explica la posición deseada; un presupuesto incorpora sus consecuencias; la
 medición comunica prioridades y detecta desvíos. Si el bono premia solo visitas por día, contradice
 la reducción de visitas repetidas. El diseño debe incluir el costo de registrar datos y la posibilidad de
 manipularlos.
 Diseñar estructura requiere estrategia → encargos → estructura ideal → restricciones → estructura
 posible → transición. Sus componentes son organigrama, descripciones de cargo y mecanismos de
 coordinación. Si el ideal exige una unidad especializada que hoy no puede financiarse, una
 responsabilidad compartida temporal puede ser viable, con dueño claro y revisión. “No hay
 presupuesto” no justifica dejar una función crítica sin responsable.
 Descentralizar aproxima decisiones a información local, acelera respuesta y puede motivar.
 También aumenta riesgo de agencia y de optimización local. Separar iniciación e implantación
 -derechos ejecutivos- de ratificación y supervisión -derechos de control- ayuda a definir límites,
 especialmente en decisiones relevantes; el grado de separación depende de riesgo y tamaño.
 Delegar una compensación de hasta un monto fijado, registrar motivo y auditar patrones permite
 autonomía con control. Exigir autorización central para toda decisión puede destruir oportunidad.
 Ninguna alternativa gana por definición.
 E7. Ética prudencial, responsabilidad social y límites de la
 evidencia
 Los apuntes de Dirección estudian la decisión económica junto a sus dimensiones sociales y éticas.
 Prudencia significa deliberar con información, alternativas, fines, medios y efectos previsibles; no
 simplemente elegir lo que “funciona”. Una intención valiosa no vuelve legítimo cualquier medio.
 Deben evaluarse deberes y derechos, imparcialidad, proporcionalidad y posibilidades de evitar
 daño.
 El doble efecto distingue un daño previsto como consecuencia de una acción de un daño buscado
 como medio. No es una autorización automática: requiere que la acción y los medios sean
 defendibles, que el daño no sea el propósito ni el instrumento del beneficio, que exista una razón
 proporcionada y que se reduzcan efectos adversos evitables. Ignorancia invencible alude a
 información que razonablemente no podía conocerse; la vencible podía corregirse; la provocada
 evita deliberadamente conocer. Un directivo no puede alegar desconocimiento si descartó informes
 de riesgo que debía revisar.
 Caso razonado. Cerrar una operación insegura puede proteger vidas y causar pérdidas de empleo.
 Primero contrastar reparación, reconversión y suspensión temporal; conocer riesgos, costos y
 tiempo; consultar a afectados y especialistas; determinar si la continuidad es defendible; preparar
 apoyo de transición. El daño laboral no debe usarse como amenaza para obtener aceptación de
 condiciones inseguras. La rentabilidad no elimina deberes de seguridad, y el costo social obliga a
 examinar alternativas concretas.
 Responsabilidad social requiere identificar impactos y mecanismos: mejores condiciones pueden
 reducir ausentismo; transparencia puede reducir asimetrías; inclusión puede ampliar talento y dec
 Qué pregunta realmente. Debo diagnosticar tres fallas principales del diseño de capacitación y
 compensación y proponer tres cambios que reconstruyan capacidades para una estrategia de
 variedad con calidad. La caída de ventas no se atribuye automáticamente a RR.HH. ni a demanda:
Examen de Grado UC | materia, preguntas y respuestas 59

[pág. 60]
Dirección - versión clara y reordenada
 los datos de clientes sobre menor variedad y calidad coinciden con una hipótesis interna que debe
 probarse.
 Tres problemas principales.
 1. Promoción sin análisis de cargo, ajuste ni aceptación. Se eligió a panaderos por antigüedad
 y conocimiento del producto, pero ser buen productor no demuestra habilidad o deseo de enseñar,
 supervisar y crear productos. Los jefes fueron retirados de producción, se les impusieron
 responsabilidades nuevas y algunos no las querían. El título y el aumento no resolvieron
 legitimidad, tiempo, autoridad ni competencias para dirigir a otros. 2. Capacitación informal e
 incompleta. “Mostrar la receta y supervisar” no especifica estándares, secuencia didáctica, práctica
 guiada, evaluación de dominio, retroalimentación o actualización. Las quejas de tardanzas y falta de
 obediencia apuntan a problemas de autoridad, diseño del trabajo y compromiso, no solo a
 desconocimiento de recetas. El modelo escala conocimiento tácito, pero sin convertirlo en
 procedimientos reproducibles puede diluir calidad al crecer a 50 locales. 3. Compensación e
 incentivo mal alineados y sin gestión del desempeño. Duplicar salario fijo únicamente por
 asumir el cargo genera costo permanente sin evidenciar contribución o competencias; decir que
 luego puede subir o bajar según los “números” añade incertidumbre, no criterios controlables. No
 hay objetivos, evaluación ni feedback. Pagar por cada producto nuevo premia cantidad y novedad,
 aunque el producto no venda, reduzca margen, complique operaciones o degrade calidad; además
 confunde creación con innovación que el cliente valore. La explicación de Matta sobre demanda no
 considera evidencia contraria de encuestas y variedad percibida.
 Tres recomendaciones.
 1. Rediseñar el puesto y seleccionar a los instructores con ajuste y consentimiento. Analizar
 tareas y resultados: producir, enseñar, verificar estándares y desarrollar variedad viable. Definir
 tiempo protegido, autoridad, carga, competencias pedagógicas y trayectoria dual para que un
 excelente panadero pueda crecer sin ser obligado a dejar la actividad que prefiere. Invitar
 postulaciones, evaluar interés y enseñar con una demostración y retroalimentación; ofrecer
 alternativa para volver a producción cuando el ajuste no funcione. El nombramiento debe ser
 transparente y no basarse solo en antigüedad.
 2. Institucionalizar formación de formadores y control de calidad. Convertir recetas y
 conocimiento de los panaderos expertos en estándares prácticos con tolerancias y razones críticas;
 entrenar a jefes en demostración, práctica del aprendiz, observación, corrección respetuosa y
 evaluación de competencia. Certificar antes de que alguien enseñe solo, usar listas de verificación,
 calibraciones entre locales y sesiones de refresco. Para innovar, probar recetas en lotes piloto y
 validar sabor, consistencia, seguridad alimentaria, factibilidad, costo y aceptación antes de
 desplegar. Conservar conocimiento tácito mediante mentoría, no reemplazarlo por manuales
 mecánicos.
 3. Vincular remuneración, feedback y desempeño con resultados balanceados. Mantener una
 prima fija por responsabilidades claramente superiores, dimensionada con análisis de cargo y
 equidad interna; agregar reconocimiento o variable moderado por objetivos controlables de equipo:
 calidad y consistencia, amplitud de productos efectivamente disponibles, satisfacción,
 margen/merma y desarrollo certificado de panaderos. Fijar metas y pesos previamente, revisar
 periódicamente con datos confiables y entregar feedback/coaching. No premiar el conteo de recetas
 creadas; remunerar innovaciones solo tras superar pruebas de calidad, demanda y rentabilidad.
Examen de Grado UC | materia, preguntas y respuestas 60

[pág. 61]
Dirección - versión clara y reordenada
 Usar indicadores de resguardo para evitar que una meta de costo provoque deterioro de insumos o
 seguridad.
 Aplicación y evaluación. Diagnosticar primero qué locales, productos y turnos muestran menor
 calidad/variedad; contrastar encuestas con ventas por SKU, quiebres, devoluciones, mermas,
 auditorías y observación del proceso. Pilotear el nuevo sistema en locales comparables y revisar
 línea base, tendencias y estacionalidad antes de escalar. La demanda deprimida puede influir en
 ventas, pero no explica por sí sola la percepción de producto mediocre ni demuestra que el plan de
 personas haya causado todo el descenso.
 Qué hace distinguida esta respuesta: identifica que el problema está en el sistema completo
 -selección y diseño del rol, transferencia de capacidades, incentivos y medición-, distingue producto
 nuevo de innovación valiosa y recomienda pruebas que conectan conducta de personas con
 calidad, variedad y resultados económicos.
 iación entre políticas responsables y retorno financiero no demuestra causalidad: firmas con
 mejores resultados podrían financiar más políticas o tener otra calidad d Qué pregunta realmente.
 Se debe decidir si los resultados de un piloto justifican escalar un reparto de utilidades, rediseñar
 sus incentivos y cambiar la selección para reducir rotación y sostener una estrategia diferenciada
 por calidad, asesoría experta y atención personalizada. Hay que leer conjuntamente indicadores
 económicos y de experiencia, y reconocer que dos locales durante seis meses no prueban
 causalidad general.
 a) Evaluación de las opiniones. Me acerco a la cautela de Aliste y Vera: el plan muestra una señal
 financiera favorable, pero la conclusión de Tormen es demasiado amplia. En ambos locales la
 utilidad operacional sube de $31 a $37 millones en Barrio Italia y de $28 a $34 millones en Mall
 Santiago Centro, es decir, +$6 millones en cada uno. Esto es compatible con mejora de
 rentabilidad, pero no identifica cuánto se debe a Pedalea, cuánto a cambios de ventas/costos, ni si
 el resultado se sostiene. En Barrio Italia los ingresos suben de 100 a 115; en Mall bajan de 100 a
 99. Las encuestas muestran resultados mixtos: en Barrio mejoran sentirse valorado, probabilidad de
 volver y recomendar, pero cae rapidez al saludar y tiempo de espera; en el Mall la mayoría de los
 atributos cae y se mantiene el conocimiento técnico. Esto importa porque servicio personalizado y
 asesoría son parte central de la propuesta, y ventas/utilidad pueden subir al mismo tiempo que se
 deteriora la experiencia.
 No concluiría que el programa fracasó: el aumento de utilidades y ciertas mejoras son señales
 útiles. Recomendaría no escalarlo sin ajustes y evidencia adicional. La comparación es limitada por
 tamaño (dos locales), duración, posibles diferencias de ubicación/flujo y falta de un contrafactual no
 tratado o serie temporal suficiente; las encuestas tampoco informan tamaños muestrales ni
 incertidumbre.
 b) Cambios al esquema Pedalea. Mantendría el vínculo con utilidad incremental, pero definiría una
 línea base verificable y comparable por tienda y ajustaría por factores fuera del control del jefe
 (ubicación, estacionalidad, inversión, afluencia o campañas corporativas). Pagaría por utilidad
 económica sostenible, excluyendo manipulación de costos, diferimiento de mantenimiento o
 recortes que dañen servicio. Incorporaría umbrales de resguardo para satisfacción, calidad de
 asesoría, tiempos de espera y reclamos; si caen bajo un nivel acordado, se reduce o retiene parte
 del bono hasta revisar causas. Usaría una mezcla de métricas financieras y de cliente/equipo, con
 pesos que reflejen la estrategia; combinarlas evita optimizar una dimensión sacrificando las demás.
Examen de Grado UC | materia, preguntas y respuestas 61

[pág. 62]
Dirección - versión clara y reordenada
 Revisaría el reparto 35/15/50 y la regla de pérdida total por renuncia. El reparto del equipo reconoce
 interdependencia, pero debe especificarse el cálculo, elegibilidad y tratamiento de contribuciones, y
 respetar la legislación y derechos devengados aplicables. El retraso puede favorecer retención,
 aunque perder todo el bono al renunciar genera riesgo percibido y puede ser injusto o inducir
 permanencia artificial; preferiría pago proporcional al período cumplido con una parte diferida, si es
 legal y financieramente sostenible. Antes de fijar porcentajes estimaría costo, sensibilidad y
 conducta probable. Probaría el esquema ajustado en más locales comparables con implementación
 gradual.
 c) Selección y retención. Primero validaría el diagnóstico de salida: las entrevistas apuntan a
 remuneración, pero se debe contrastar con compensación total de mercado, carga, jefatura,
 horarios, carrera y condiciones por tienda. Definiría un perfil de jefe que incluya conocimiento
 técnico de bicicletas, orientación consultiva al cliente, liderazgo/coaching y gestión de inventario y
 rentabilidad. Usaría criterios y escalas consistentes para candidatos internos y externos: entrevista
 estructurada, caso de asesoría de cliente y ejercicio de planificación de tienda; evitar decidir solo
 por rapidez o fama deportiva. La contratación inmediata debe cubrir vacantes, pero puede
 mantenerse una terna/pool capacitado y una ruta interna para reducir dependencia de selección
 apurada. Entregaría una descripción realista del rol y sus metas, onboarding y oportunidades de
 desarrollo. Revisaría equidad salarial por tamaño, ubicación y complejidad del local: medir solo
 ventas absolutas penaliza tiendas pequeñas aunque sean muy rentables y contribuyan fuertemente
 a la estrategia.
 Conclusión e indicadores. Pilotearía una versión balanceada del incentivo y el proceso de
 selección, midiendo utilidad incremental ajustada, ventas/margen, retención y rotación, costo de
 vacantes, satisfacción por atributo, reclamos y repetición de compra. Escalaría si la mejora
 económica es repetible y no se obtiene deteriorando calidad de atención. El caso no permite
 estimar significancia estadística ni separar con precisión efectos de incentivo, ubicación y otros
 cambios.
 Qué hace distinguida esta respuesta: calcula los cambios de utilidad correctamente, no confunde
 correlación temporal con efecto causal, alinea el bono con la propuesta de valor completa y conecta
 el problema salarial con selección, equidad entre locales y evidencia de retención.
 a. Evitar afirmar que toda iniciativa social aumenta utilidades, que todo conflicto es fracaso o que un
 impacto favorable vuelve ética cualquier decisión.
Examen de Grado UC | materia, preguntas y respuestas 62

[pág. 63]
Dirección - versión clara y reordenada
 PARTE III - INTEGRACIÓN ENTRE
 ESTRATEGIA Y PERSONAS
 Taller de aplicación: diagnóstico, elección e implementación
 Caso 1. Amenaza de un competidor de bajo costo
 Una firma establecida pierde participación frente a un entrante que ofrece precio 20% menor. La
 respuesta instintiva es igualar el precio. Antes de hacerlo, separa la causa de elección: ¿el rival
 tiene estructura de costos menor?, ¿sacrifica servicio/calidad?, ¿atiende otro segmento?, ¿usa una
 promoción temporal?, ¿tiene menor costo de canal? Revisa margen de contribución propio y rival,
 sensibilidad al precio por segmento, costo de cambio, capacidad, marca y posibilidad de nueva
 entrada.
 Cinco Fuerzas ayuda a preguntar si hay cambio estructural: entrada más fácil, compradores con
 mayor poder o sustituto más atractivo. Cadena de valor localiza dónde la empresa puede bajar
 costo sin destruir diferenciación. VRIO evalúa si un servicio, datos, relación o capacidad es
 realmente valioso y difícil de copiar. Un competidor barato no es automáticamente una amenaza a
 todos los clientes; puede separar un segmento con distinta disposición a pagar.
 Compara cuatro acciones: bajar precio para toda la base; focalizar oferta/segmento; flanquear con
 marca o producto más simple; reforzar diferencia y dejar clientes no rentables. Para cada acción
 proyecta margen, volumen, canibalización, reacción y costo de implementación. Una marca
 secundaria requiere barrera de arquitectura y portafolio; si los clientes solo perciben la marca
 corporativa, puede haber contaminación. Piloto con cohortes/zonas y KPI de contribución neta,
 retención y adquisición. Una respuesta distinguida explica por qué no iguala automáticamente la
 rebaja y cuál evidencia la haría cambiar de decisión.
 Caso 2. Crecimiento a un negocio cercano
 Una empresa propone diversificarse a una categoría relacionada porque comparte clientes y canal.
 Construye hipótesis de sinergia: uso compartido de marca, fuerza de ventas, logística, datos,
 patente, compras o conocimiento. Por cada una estima beneficio, costo, tiempo, propietario
 responsable y probabilidad de captura. Si “sinergia” solo significa “se puede vender al mismo
 cliente”, falta demostrar necesidad, ajuste, disposición a pagar y costo de servicio.
 Compara desarrollo interno, alianza, licencia y adquisición. Crecimiento interno aprende y preserva
 cultura, pero puede tardar; alianza comparte recursos y riesgo, pero crea dependencia y
 gobernanza; compra acelera acceso, pero incluye prima, integración y pasivos ocultos. La
 diversificación puede estabilizar flujos, aunque accionistas quizá diversifican por cartera a menor
 costo. Define pruebas antes de comprometer capital: entrevistas de compradores, piloto comercial y
 economía unitaria. Usa VAN incremental y sensibilidad a adopción/costos. Si la categoría falla en
 un supuesto clave, se debe poder detener o rediseñar sin comprometer todo el balance.
Examen de Grado UC | materia, preguntas y respuestas 63

[pág. 64]
Dirección - versión clara y reordenada
 Caso 3. Plataforma de dos lados
 Una aplicación conecta técnicos independientes y clientes que necesitan reparaciones. La utilidad
 de cada lado depende de variedad, disponibilidad, confianza y tiempo de respuesta. Dibuja ambos
 lados y bucles de red; marca subsidios, comisión, riesgo de desintermediación, multi-homing,
 verificación, reclamos y seguridad. Un precio bajo a clientes puede elevar demanda y valor de
 plataforma para técnicos; un precio bajo a técnicos puede atraer oferta, pero no crear servicio si no
 hay trabajos suficientes.
 El problema de “arranque” requiere densidad local y categoría acotada, no lanzamiento nacional sin
 liquidez. Métricas: búsqueda a solicitud, tiempo hasta match, aceptación, cancelación, repetición
 por lado, margen por servicio, costo de incentivo, incidentes y reclamos. Tasa de registro sin
 emparejamientos no demuestra efecto de red. Prueba en comunas/categorías donde demanda y
 oferta puedan balancearse. Una política de calidad puede restringir cantidad de participantes, así
 que gobernanza y experiencia son parte de la estrategia.
 Caso 4. Elegir entre diseñar internamente o externalizar
 La gerencia quiere externalizar soporte para reducir costos. Compara costo total: tarifa del
 proveedor, transición, supervisión, sistemas, recontactos, errores, penalidades, dependencia,
 pérdida de conocimiento y costo de reversión. Identifica si la actividad es estratégica o fácilmente
 especificable, si el proveedor puede medir calidad, si datos sensibles circulan y si hay alternativas
 reales. El proveedor puede ofrecer escala y tecnología que la empresa no tiene; internalizar no es
 siempre superior.
 Piloto en un tipo de consulta con volumen representativo. Define SLA, auditoría, privacidad,
 escalamiento, retención de casos y métricas de resolución al primer contacto, satisfacción, tiempo,
 costo por caso y repetición. Contrato con incentivos balanceados, transferencia de conocimiento y
 plan de salida. Compara con unidad interna ajustando mezcla de casos. La recomendación
 distinguida reconoce trade-off entre costo, control, calidad y aprendizaje, y propone gobernanza
 posterior a la firma.
 Caso 5. Diagnosticar rotación y desempeño
 Una unidad reporta alta rotación y baja productividad. Construye árbol causal: selección/ajuste;
 habilidad y entrenamiento; carga y turnos; jefatura/feedback; compensación y justicia; seguridad;
 equipo/sistemas; demanda y mercado externo; carrera y flexibilidad. Segmenta por antigüedad,
 cargo, supervisor, turno, género u otra categoría pertinente con privacidad y base suficiente.
 Calcula tasa con denominador consistente y sigue cohortes. Entrevistas a salientes pueden
 sobrerrepresentar experiencias negativas o positivas según participación; compáralas con quienes
 permanecen.
 Modelo AMO ayuda a ubicar si falta habilidad, motivación o oportunidad. Si falta habilidad,
 práctica/apoyo; motivación, justicia y metas/incentivos; oportunidad, autoridad, herramientas y voz.
 Una misma señal puede tener varias causas. Revisa selección y entrenamiento antes de prescribir
 bonos. Si unidad A difiere de B, controla mezcla de clientes, demanda y supervisión. Diseña
 intervención focal y compara unidades comparables, registrando contexto.
Examen de Grado UC | materia, preguntas y respuestas 64

[pág. 65]
Dirección - versión clara y reordenada
 Caso 6. Incentivo que aumentó volumen y dañó calidad
 La empresa paga comisión por contratos firmados; las ventas suben, pero cancelación y reclamos
 también. El incentivo hizo saliente el volumen, pero resultado contratado no es valor retenido.
 Dibuja cadena causal: esfuerzo comercial → contrato → activación → uso/retención → margen
 neto. Averigua si cancelaciones provienen de venta engañosa, mala elegibilidad, promesa
 incumplible o calidad posterior. Consulta clientes, escucha llamadas bajo reglas, mira cohortes y
 compara vendedores/periodos.
 Opciones: comisión parcial pagada tras activación/retención; margen neto con guardarraíl de
 reclamo; combinación individual-equipo; feedback y supervisión; elegibilidad de venta. Cada una
 puede generar riesgo de horizonte corto, menor contratación de clientes difíciles o manipulación de
 clasificación. Simula costos, define auditoría y piloto. Si la firma mide retención a 90 días, evalúa
 horizonte que coincida con promesa y no penalice injustamente shocks fuera de control. Un
 esquema justo requiere reglas transparentes, recursos para cumplir promesa y proceso de
 apelación.
 Caso 7. Selección para una nueva operación
 La empresa abre un servicio con roles nuevos y no hay historial de desempeño. Empieza por
 resultados críticos y tareas observables, consulta expertos y trabajadores que realizan funciones
 semejantes, y distingue requisitos legales de preferencias. Define competencias con evidencia
 conductual: detectar falla, explicar opciones, respetar protocolo, pedir ayuda. Diseña entrevistas
 estructuradas y muestra de trabajo breve, con rúbrica, evaluadores entrenados y criterio de corte
 previo.
 No uses universidad, personalidad genérica o “encaje cultural” como filtro automático sin demostrar
 relación con trabajo y revisar sesgo. Valida después: desempeño, error, satisfacción y permanencia
 por cohorte, con cautela por selección inicial. Ajusta criterio si predice la métrica adecuada y
 respeta equidad. La evaluación de selección también verifica experiencia candidata y accesibilidad;
 legalidad y protección de datos se revisan según jurisdicción vigente, sin inventar una regla.
 Caso 8. Implementar una transformación digital
 Digitalizar un proceso no es instalar software: cambia tareas, decisiones, datos, coordinación y
 poder. Mapea flujo actual y futuro, errores, usuarios, roles, sistemas heredados, privacidad,
 seguridad, competencias y puntos de decisión humana. Consulta a equipos que operan el proceso;
 pueden revelar excepciones que el diseño central ignora. Piloto con criterios de salida antes de
 escalar.
 Identifica grupos afectados, pérdida de autonomía/estatus, riesgo de carga y necesidades de
 capacitación. Si el software mide productividad, gobierna calidad del dato, acceso, revisión humana
 y uso de métricas; evita que un indicador de velocidad incite a cerrar tickets sin resolver.
 Indicadores balanceados: tiempo, tasa de error, resolución, adopción, carga laboral, reclamos,
 incidentes de datos y costo total. Un caso de Distinción organiza transición con responsable,
 contingencia manual y canal de reportes.
Examen de Grado UC | materia, preguntas y respuestas 65

[pág. 66]
Dirección - versión clara y reordenada
 Comparación de marcos sin convertirlos en listas
 Marco Pregunta que responde Evidencia necesaria Límite si se usa solo
 Cinco Fuerzas ¿Cómo la estructura compradores, No explica por sí sola por
 externa distribuye presión y proveedores, rivalidad, qué dos empresas del
 rentabilidad? entrada y sustitutos sector difieren
 definidos
 VRIO ¿Qué recurso/capacidad aporte a valor, rareza, Etiquetar fortaleza sin
 puede sostener ventaja? imitabilidad y organización evidencia no prueba
 rendimiento
 Cadena de valor ¿Qué actividades crean costos, experiencia, Puede fragmentar una
 costo/diferencia y dónde dependencias y procesos propuesta si se ignoran
 intervenir? complementariedades
 Ansoff ¿En qué dirección crecer y cercanía No estima atractivo ni
 qué novedad asume? producto/mercado, probabilidad de éxito
 capacidad y demanda
 AMO ¿Falta habilidad, capacidades, incentivos, No identifica causa sin
 motivación u oportunidad autoridad, herramientas y datos ni reemplaza análisis
 para contribuir? condiciones laboral
 Métricas de personas ¿Qué cambió, en quién y fórmula, cohorte, base y Correlación temporal no
 con qué consecuencia? calidad de registro demuestra efecto de una
 práctica
 Guion de respuesta oral para alcanzar Distinción
 En una respuesta de 3-5 minutos, abre con recomendación condicional en una frase; presenta dos
 o tres hechos determinantes; explica mecanismo del marco elegido; compara la alternativa principal
 descartada; desarrolla implementación con dueño, secuencia y recursos; cierra con métricas, riesgo
 y condición para revisar. No recites cinco fuerzas y VRIO enteros si el caso pregunta sobre
 incentivos. Si piden marco, selecciónalo y justifica pertinencia. Si la evidencia falta, dilo y diseña
 cómo obtenerla, pero no postergues toda decisión: ofrece una recomendación reversible o piloto.
 Un evaluador distingue respuestas por la integración de mecanismo y contexto, no por la cantidad
 de conceptos citados. Las afirmaciones causales requieren evidencia, las generalizaciones deben
 limitarse al grupo y periodo observados, y los trade-offs deben llevar a una elección. Una respuesta
 excelente admite que una opción tiene costo y aun así explica por qué supera a las demás dadas
 las prioridades del caso.
Examen de Grado UC | materia, preguntas y respuestas 66

[pág. 67]
Dirección - versión clara y reordenada
 PARTE IV - TALLERES Y CASOS ANTES DEL
 BANCO HISTÓRICO
 Casos trabajados: integrar evidencia, mecanismo y decisión
 Caso de reconversión de una empresa constructora
 CASA concentra 60% de sus ingresos en viviendas de precio medio/bajo, donde la demanda cae;
 los proyectos eléctricos tienen horizonte de tres años y obras viales horizonte de dos. El dilema
 entre despido de 30% y despido cero no se resuelve aplicando una etiqueta de responsabilidad
 social o eficiencia. Se construyen escenarios de caja y carga de trabajo por unidad: pesimista (obra
 pública se retrasa, viviendas siguen cayendo), base (se materializa parte de proyectos) y favorable.
 Luego se estima personal crítico, tasa de utilización, transferencia de ingenieros, costo de
 capacitación/reubicación, costo de despidos/indemnización, tiempo de contratación futura y daño
 por perder conocimiento.
 Si caja soporta retención temporal y los proyectos están cerca de contratación, usaría movilidad
 interdivisional, capacitación, reducción voluntaria de horas y no reemplazo de salidas, con revisión
 trimestral. Preservaría roles críticos de proyectos y cliente; reduciría en forma focalizada puestos
 cuyo trabajo desaparece de manera estructural. Si la caja cruza un umbral de liquidez o el pipeline
 no se convierte dentro de una fecha, activaría reducción adicional en secuencia predefinida. Para
 justicia y credibilidad, criterios de selección de puestos transparentes, comunicación sobre
 incertidumbre y apoyos de transición. El indicador no puede ser solo costo de nómina: incluye
 margen/proyecto, utilización, calidad, rotación crítica, seguridad y caja.
 Caso de transición de multitienda ante comercio digital
 La transcripción local de la corrección EDG 2025-1 destaca que la pregunta no pide enumerar
 cambios de la industria, sino su efecto en creación/captura de valor y riesgo. En una multitienda
 tradicional ante canales digitales: más rivales y entrantes pueden presionar precio/margen; el
 cliente puede migrar al canal online; nuevos segmentos pueden ampliar la demanda disponible, si el
 incumbente logra capturarlos; adquirir clientes y desarrollar logística/datos exige costos e
 inversiones. Por tanto, no se infiere un solo resultado de “la digitalización”; se construye cadena
 causal desde estructura a (P × Q - C).
 El riesgo puede aumentar si caen barreras de entrada, sube volatilidad de demanda y quedan
 activos físicos fijos difíciles de reasignar. Puede disminuir para firmas livianas si cae costo de
 salida/compromiso fijo. Se debe especificar exposición de la empresa y comparar escenarios. La
 estrategia del CEO que migra a tiendas pequeñas/outlet y refuerza experiencia puede aprovechar
 clientes y activos, pero mantener online sin desarrollo logístico/digital deja expuesta la tendencia. La
 recomendación distinguida decide qué capacidades digitales se desarrollan, para qué segmentos y
 con qué prueba de retorno, mientras protege la experiencia/cliente que soporta la marca. No
 declarar que “la estrategia es buena” sin evaluar ajuste, capacidades y ventaja concreta.
Examen de Grado UC | materia, preguntas y respuestas 67

[pág. 68]
Dirección - versión clara y reordenada
 Caso de incentivos para gerentes de local
 En Sanguchón, el dueño busca ventas y utilidades, mientras la propuesta de valor exige rapidez
 uniforme, ingredientes de calidad, limpieza y trato amable. Incentivar a jefes solo por venta/utilidad
 puede promover descuento excesivo, ahorrar dotación y bajar calidad o seguridad, dañando lo que
 diferencia al negocio. Sin incentivo, puede faltar responsabilidad al crecer cuando el gerente central
 ya no supervisa los 20 locales. Se diseña un cuadro con margen/contribución del local,
 servicio/tiempo, merma/calidad, auditoría de limpieza y cliente, junto con indicador de equipo; las
 medidas son controlables por el jefe, se auditan y tienen umbral mínimo de calidad que impide
 cobrar bono si hay infracción grave. Ponderaciones y techos se calibran con datos históricos y
 piloto.
 La remuneración variable no forma por sí sola la competencia. La empresa debe mapear
 habilidades, definir entrenamiento por rol, incorporar guías y turnos suficientes, habilitar autoridad
 dentro de reglas y coach de jefatura. Si hay rotación alta, analiza tiempo de aprendizaje y
 estabilidad del equipo; una meta de productividad debe corregirse por antigüedad/volumen y no
 incentivar recorte de entrenamiento. Valida efectos sobre ventas, margen, espera, limpieza,
 reclamos, rotación y ausentismo antes de replicar.
 Comparar marcos sin “recitar modelos”
 Porter explica presiones estructurales sobre la captura de valor; VRIO pregunta si
 recursos/capacidades de una empresa pueden sostener una ventaja; cadena de valor localiza
 actividades y vínculos donde se crea costo/diferenciación; modelo de negocio explica arquitectura
 de entrega/captura; AMO detecta si las condiciones de gestión de personas permiten el
 comportamiento; justicia revisa legitimidad del proceso/resultados. Aplicar marcos en conjunto exige
 asignar a cada uno una pregunta distinta. Ejemplo: margen cae en call center. Porter puede indicar
 poder del comprador y sustitutos; cadena de valor muestra alto costo por repetición de llamadas;
 VRIO analiza si datos/procesos crean capacidad difícil de copiar; AMO revisa entrenamiento,
 autoridad y tecnología del agente; justicia verifica metas y evaluación. La intervención podría
 eliminar la causa de repetición, no solo subir bono por llamadas atendidas.
 SWOT resume fortalezas/debilidades internas y oportunidades/amenazas externas, pero no prioriza
 por causalidad ni prueba estrategia. Cada elemento debe estar respaldado y luego conectarse a
 una elección: qué fortaleza permite capturar oportunidad, qué brecha se debe construir o qué
 amenaza cambia la decisión. PESTEL ayuda a explorar factores macro, pero listar seis letras no es
 análisis: pregunta horizonte, impacto, probabilidad, exposición y señal temprana. Cinco fuerzas
 ordena la industria; PESTEL ubica contexto; escenarios muestran cómo incertidumbre podría
 combinarse. Herramientas diferentes pueden contradecirse porque usan niveles y horizontes
 distintos: resuelve la contradicción explicitando límite y dato que discrimina.
Examen de Grado UC | materia, preguntas y respuestas 68

[pág. 69]
Dirección - versión clara y reordenada
 Ética, empleo y gobernanza de datos
 Decisiones sobre selección, desempeño, compensación, monitoreo y desvinculación afectan
 derechos, privacidad, igualdad de oportunidades y dignidad además de eficiencia. El programa UC
 2023 incluye una mirada ética y legal, pero el expediente de fuentes extraídas no permite fijar aquí
 el detalle de toda la legislación laboral chilena aplicable al caso 2027. Antes de implantar una
 práctica, consulta la normativa vigente y políticas institucionales; en el examen, identifica el riesgo
 jurídico como supuesto a verificar y no inventes una regla o plazo.
 Para datos de trabajadores define finalidad, acceso, retención, seguridad y transparencia. No uses
 información sensible porque está disponible; justifica pertinencia y proporcionalidad, minimiza
 variables y conserva revisión humana de decisiones de alto impacto. Una evaluación algorítmica
 puede parecer uniforme y aun discriminar por datos proxy o históricamente sesgados. Audita
 validez predictiva y resultados por grupos, ofrece explicación y apelación y limita el uso a propósito
 declarado. Estas salvaguardas protegen tanto a las personas como la confianza, precisión y
 legitimidad de la organización.
 Cierre del método de respuesta
 Una respuesta final debe poder leerse como una cadena: hecho relevante → problema →
 mecanismo → alternativa → recomendación → implementación → indicador → condición para
 corregir. Si un marco no cambia la decisión, sobra. Si una métrica no tiene denominador o período,
 todavía no es evidencia suficiente.
 Fuentes y trazabilidad
 La reorganización conserva la materia sustantiva del manual maestro, elimina los bloques repetidos
 e intercala los desarrollos adicionales de Personas, Estrategia, validez incremental y CAGE antes
 de la práctica. El banco histórico reproduce páginas del compendio EDG_E_2009-2026_OCR.pdf.
 Las respuestas siguen siendo propuestas de estudio salvo atribución expresa a una pauta
 identificada.
Examen de Grado UC | materia, preguntas y respuestas 69

[pág. 70]
Dirección - versión clara y reordenada
 PARTE DE PRÁCTICA - 70 preguntas
 históricas
 Dirección de Personas - 35 preguntas
Examen de Grado UC | materia, preguntas y respuestas 70

[pág. 71]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2012 | pregunta 4
 Convocatoria 1 | página original 94 | Alineamiento de prácticas con servicio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 PREGUNTA Nº 4
 “Los clientes están profundamente molestos con el comportamiento de las isapres. Las promesas de servicio que ellas hacen
 a sus clientes, rara vez se cumplen. Quien logre entregar un alto nivel de atención a los usuarios aumentará notablemente su
 participación de mercado y rentabilidad.”
 Así comenzaba la charla de Cecilia Dimas, expositora del seminario empresarial al que asistía Alberto Richards, Gerente
 General de la Isapre “Siempre Sanitos". El ejecutivo tenía datos que efectivamente avalaban lo planteado por Dimas, lo que
 le llevaba a plantearse lo siguiente: “la estrategia de negocios está clara. La pregunta es cómo logramos orientar y motivar a
 nuestro personal para atender adecuadamente a nuestros clientes, transmitiendo información compleja de manera oportuna y
 clara y respondiendo rápido a sus necesidades”.
 Interrumpieron sus pensamientos la presentación que hacía Dimas sobre los niveles de sueldos para los diferentes cargos en
 las empresas chilenas. Ella comentaba lo importante que es esta variable en el desempeño de las personas y,
 consecuentemente, en los resultados que obtienen las empresas. Al respecto Richards, reflexionaba: “En nuestra empresa
 pagamos compensaciones de mercado, tanto en lo que se refiere a sueldos fijos como a incentivos variables por
 productividad.”
 En el siguiente gráfico que mostraba la expositora, se indicaba el porcentaje de participación de los trabajadores de diferentes
 países de la OECD1 y las horas promedio de capacitación que recibían. Al respecto, Richards meditó: “‘Siempre Sanitos’
 tienen una inversión en capacitación muy cercana a los números que muestra Chile en el gráfico; ¿no debiéramos, como
 empresa, parecernos a Nueva Zelandia o Finlandia si queremos alcanzar nuestros objetivos?”
 Niveles de Capacitación en diversos países OECD
 300 45%
 40%
 250
 35%
 200 30% Horas promedio al año de
 capacitación por trabajador
 150 25%
 % de trabajadores en las empresas
 20% que participan en capacitación
 100
 15%
 50 10%
 Nueva Finlandia Holanda República Hungría Chile
 Zelandia Checa
 A continuación la expositora mostró el siguiente gráfico, en el que se muestran los resultados de una encuesta sobre las
 percepciones de los trabajadores chilenos respecto a sus posibilidades de desarrollo de carrera. El mismo instrumento se
 había aplicado a “Siempre Sanitos” y los resultados eran idénticos a la muestra nacional. Richards escuchaba atentamente y
 se preguntaba si acaso estos resultados estaban relacionados de alguna manera con la posibilidad de que los trabajadores de
 “Siempre Sanitos” estuvieran alineados con la estrategia de calidad de servicio.
 1 OECD = Organización para la Cooperación y el Desarrollo Económico
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 71

[pág. 72]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2012 | pregunta 4
 Convocatoria 1 | página original 95 | Alineamiento de prácticas con servicio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 ¿Cuán de acuerdo se encuentra Ud. con las
 siguientes afirmaciones?
 Si dos profesionales ingresan a la
 misma empresa, en cargos
 idénticos, siempre llegará más
 lejos el que proviene de una
 familia de altos ingresos
 De acuerdo
 Tener familiares o amigos
 influyentes sigue siendo muy
 importante para lograra el éxito
 laboral
 85% 90% 95%
 En su última lámina, Dimas daba a conocer los resultados de una reciente encuesta a una muestra representativa de
 trabajadores y personal administrativo en empresas de servicio. En ella los encuestados indicaban su grado de satisfacción
 respecto a una serie de prácticas existentes al interior de sus empresas. Una vez más el Gerente General de “Siempre
 Sanitos” recordaba que le acababan de entregar un estudio similar con resultados prácticamente idénticos a los que exponía
 Dimas en su presentación.
 En su calidad de asesor de “Siempre Sanitos” y suponiendo que los datos presentados reflejan fielmente la situación de la
 empresa, indique los tres principales cambios (modificaciones o reforzamientos) que usted propondría en las prácticas de
 gestión de personas con que actualmente cuenta la empresa, para lograr los objetivos estratégicos de ser líder en servicio y
 calidad de atención. En su respuesta explique cómo cada uno de los cambios (modificaciones o reforzamientos) que usted
 propondría, impactarían positivamente en el logro de los objetivos de la estrategia de negocios de “Siempre Sanitos”. En su
 respuesta refiérase exclusivamente a las prácticas de gestión de personas de la empresa y que se desprenden de la
 información entregada en el caso.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 72

[pág. 73]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2017 | pregunta 2
 Convocatoria 1 | página original 228 | Autonomía e innovación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 2
 Vincit es una empresa finlandesa dedicada al desarrollo de software para la optimización de los procesos
 productivos de sus empresas cliente en diversas industrias. Su principal mercado son los países escandinavos
 pero recientemente ha desarrollado negocios en el resto del mundo. Sus 120 trabajadores son, en su gran
 mayoría, ingenieros programadores y expertos en tecnologías de la información dedicados al diseño e
 implementación de sitios web, aplicaciones para dispositivos móviles, servicios de monitoreo y control digital
 de procesos y plataformas de negocios virtuales con un alto nivel de interacción con clientes.
 Hasta hoy, en 2016, la compañía ha tenido resultados mediocres respecto a las expectativas que sus cuatro socios
 fundadores tenían cuando crearon la compañía en Helsinski, en 2007. Tanto los niveles de crecimiento en
 participación de mercado como las utilidades no han ido al ritmo de otros emprendimientos similares a Vincit,
 tanto en Finlandia como en el resto del mundo, Igualmente, el cumplimiento de los objetivos de negocio hacia
 los clientes tampoco eran satisfactorios. El Directorio, en su última reunión, concluyó que la causa de estos
 problemas estaba en el sistema de gestión de personas que había adoptado la compañía en los últimos años.
 Objetivos estratégicos de Vincit
 La compañía tiene tres objetivos de negocio fundamentales:
 e — Desarrollar productos a la medida para las necesidades particulares de cada empresa que atienden,
 e Máxima satisfacción en la experiencia de servicio de sus clientes y
 e — Liderazgo permanente en innovación de productos y servicios
 Para lograr su propósito, la empresa promueve la coordinación de las personas al interior de cada área de la
 compañía y, simultáneamente, la colaboración entre las diferentes gerencias de Vincit. Al respecto, el gerente
 general de la empresa comentaba en una reunión del equipo directivo de la compañía:
 “la experiencia nos enseña que para implementar su modelo de negocios, lograr sus objetivos estratégicos
 y la rentabilidad deseada, Vincit requiere una buena articulación entre las diferentes funciones de la
 organización, ya que todas ellas intervienen en la oferta que finalmente entregamos a nuestros clientes.
 Incluso, ello no es suficiente, si no contamos con n alto nivel de satisfacción de las motivaciones de
 nuestro personal. De otro modo su desempeño individual no alcanzaría los niveles requeridos y tampoco
 tendrían una actitud hacia la colaboración y el trabajo en equipo.”
 Estructara organizacional de la compañía
 La estructura funcional de la compañía, que se muestra a continuación, es altamente centralizada. Está liderada
 por Mikko Kuitunen, socio y gerente general de la compañía, al que reportan cuatro gerencias funcionales y bajo
 ellas se agrupa el resto de los trabajadores de la empresa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 73

[pág. 74]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2017 | pregunta 2
 Convocatoria 1 | página original 229 | Autonomía e innovación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 . El modelo de gestión de personas del gerente general
 Molesto con los magros resultados, Mikko Kuitunen, pretende dar un giro radical con respecto a las políticas de
 gestión de personas existentes actualmente en la empresa e instalar un nuevo modelo de dirección de su personal.
 Las políticas de gobierno corporativo de Vincit establecían que una decisión de esa importancia, debía ser aprobada
 por la unanimidad de los cuatro socios fundadores que conformaban el directorio.
 El gerente general propone tres cambios fundamentales. El primero de ellos consiste no solo en empoderar al
 personal operativo de la empresa para que plantee ideas y sugerencias de mejora en los procesos, productos y
 servicios de la compañía, sino que directamente apunta a eliminar las jefaturas, generando un vínculo directo entre
 los gerentes de la compañía y sus trabajadores. Además, agregó Kuitunen en su presentación:
 “Teniendo como parámetros los objetivos estratégicos de la empresa, cada persona debe decidir la
 planificación y orden de las actividades que requiere realizar, qué y cuántos insumos utilizar (hardware, por
 ejemplo), cuántas personas deben trabajar en los diferentes procesos y cómo controlar la calidad y eficiencia
 de su trabajo. La única regla para los gastos es que cada empleado de Vincit gestione los recursos como si
 fuera su propio dinero.”
 El gerente general señaló luego que el segundo cambio consistía en que al no existir jefes en la nueva estructura
 propuesta, no habrá nadie que coordine los equipos que antes dependian de dichas jefaturas. Ahora, se entrega
 libertad absoluta a cada persona para que busque la colaboración de quien estime pertinente y en el momento que
 se estime oportuno, de modo de sacar adelante las tareas y lograr los objetivos planteados. Además, Kuitunen señaló
 que quería eliminar los horarios de trabajo, los turnos predefinidos y la posibilidad de trabajar un número inferior a
 las 45 horas semanales de lunes a viernes que establecía la ley. Kuitunen le planteaba al Directorio:
 “Solo se debía contar con el compromiso personal de la gente para cumplir con sus tareas y objetivos. Nadie
 le debe decir a nuestros empleados cómo hacer su trabajo, ni cuándo tiene que cumplir con su horario.”
 Incluso, planteó el líder de la compañía:
 “mi fercera propuesta es que no debemos tener despidos en Vincit. Estoy convencido de que si alguien no
 se siente cómodo se irá pronto y voluntariamente.”
 El directorio ha considerado la propuesta de Kuitunen extraordinariamente disruptiva y le ha pedido a usted en su
 calidad de experto, que responda algunas preguntas que ayudarán a los socios de Vincit a tomar la decisión de si
 aceptar o rechazar los tres propuestas del nuevo modelo de gestión de personas propuesto por el gerente general. En
 concreto, a Ud. se le solicita responder a las siguientes cuestiones:
 PREGUNTAS
 1. Desde el punto de vista de la teoría de la motivación de los trabajadores en una empresa, ¿cómo podría justificar
 ]a aplicación de las propuestas del modelo de gestión de personas que propone Kuitunen para el personal de
 Vincit? Fundamente su respuesta de manera breve y precisa.
 2. Considerando los objetivos estratégicos de Vincit, indíque los tres principales argumentos que usted utilizaría
 para defender la propuesta de Kuitunen. Asimismo, señale las tres principales medidas en materia de selección
 de personal, capacitación y control del personal (una para selección, una para capacitación y una para control),
 que usted adoptaría para minimizar posibles efectos adversos en caso de que la propuesta del gerente general se
 implemente.
 3. ¿Qué tipo de sistema de incentivos para el personali operativo podría ayudar al éxito del modelo de gestión de
 personas planteado por el gerente general? Fundamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 74

[pág. 75]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2013 | pregunta 2
 Convocatoria 1 | página original 117 | Bono de retiro y relaciones laborales
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº 2
 Alberto Cupertino, experimentado asesor en negociaciones colectivas, subía en el ascensor al piso 10 de las oficinas de su
 cliente PuroCobre, una importante empresa minera dedicada a la explotación del metal rojo en el norte de Chile. El experto
 tenía claro que la reunión de directorio convocada se centraría en el análisis del bono que Codelco, la empresa cuprífera
 estatal chilena, había pagado al personal de su división Chuquicamata, ubicada en la Región de Antofagasta, como resultado
 de la negociación colectiva concluida recientemente. Cupertino también sabía que le preguntarían cómo su cliente debería
 enfrentar la próxima negociación colectiva y, en particular, el bono que debiera otorgarse a los trabajadores de la empresa.
 Se sabía que en la minería la negociación de una empresa era considerada un antecedente importante para las negociaciones
 en las otras compañías del sector, más aún, pensaba Cupertino, si PuroCobre tenía condiciones muy similares a las de
 Chuquicamata y también iniciaría operaciones de minería subterránea como la empresa estatal (tanto Chuquicamata como
 PuroCobre operan hoy en día a rajo abierto). El asesor aún no se acomodaba bien en su silla cuando uno de los directores le
 “disparó” la primera pregunta: “¿cómo ves la conflictividad laboral en la minería chilena?”. Por suerte Cupertino venía
 preparado e inmediatamente mostró el siguiente gráfico, agregando: “Creo que las cifras hablan por sí solas.”
 Luego de esta intervención, la reunión prosiguió. Se entregaron detalles acerca del bono aprobado entre Chuquicamata y sus
 sindicatos hace unas semanas, el que consistió en que cada uno de los 5.900 trabajadores recibió $16,8 millones por una sola
 vez (equivalente a un pago anual igual a la cuarta parte de ese valor, es decir $4,2 millones anuales), hasta la nueva
 negociación colectiva a fines de 2016. A cambio, la administración consiguió que, a partir de 2013, se le permitiera a la
 división iniciar un plan de retiro voluntario1 de 2.150 trabajadores en la división. Esto último, de acuerdo a su Presidente
 Ejecutivo, Thomas Keller, tenía como objetivo reducir los altos costos que enfrenta Chuquicamata. “En la negociación con
 los sindicatos de esta división nos hemos hecho cargo, afortunadamente junto a los trabajadores, de cómo vamos a transitar
 de la situación actual a una de mayor competitividad en el largo plazo. Eso es lo importante es esta instancia", sostuvo
 Keller. Según el ejecutivo, el futuro proyecto Chuquicamata -que implica abandonar el proceso de explotación a rajo abierto
 por uno de minería subterránea-, requerirá un número considerablemente menor de personal lo cual se hacía inviable si no se
 acordaba con los trabajadores una desvinculación voluntaria paulatina de personas durante los próximos 48 meses –fines de
 2016- que durará el nuevo convenio colectivo –con buenas condiciones económicas de salida para quienes se acojan a retiro.
 De acuerdo con cifras de Codelco, al desvincular a estos 2.150 trabajadores, la compañía se ahorraría unos US$ 200 millones
 en valor presente, que es exactamente equivalente a la cifra a desembolsar por el bono acordado a los 5.900 trabajadores que
 tiene actualmente la división.
 1 Este acuerdo de retiro es no vinculante, con lo cual los trabajadores llegado el momento de solicitarles su salida de la empresa podían rechazar
 dicha oferta y permanecer en sus cargos.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 75

[pág. 76]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2013 | pregunta 2
 Convocatoria 1 | página original 118 | Bono de retiro y relaciones laborales
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 Durante la reunión, uno de los directores de PuroCobre, Roberto Ricoletti, también entregó algunos datos de la división
 Chuquicamata que consideraba importantes para enfrentar la próxima negociación colectiva y el bono a otorgar a los
 trabajadores. Según Ricoletti, las condiciones bajo las cuales operaba PuroCobre eran similares a las de la empresa estatal.
 “En 2012 la producción de Chuqui cayó un 15% en volumen y en US$ 160 millones respecto a lo presupuestado. Uno de los
 factores que explican la caída de la producción es la baja ‘ley del mineral’ (porcentaje de cobre puro en una tonelada de
 material procesado). Se esperaba encontrar una ley de 0,9% y solo se obtuvo una de 0,6%. Además, la caída de la producción
 se debió a fallas en el horno de Codelco -pieza fundamental del proceso-, lo que provocó su paralización por 90 días y por
 ende una producción nula en ese período. Estas cifras son preocupantes si se considera que, por cada día de paralización de
 la producción, la empresa pierde aproximadamente US$ 8 millones. Estos desperfectos eran totalmente evitables si el plan de
 mantenimiento preventivo se hubiera realizado según lo programado.”
 En seguida, Mario Segurovski, otro director de PuroCobre, pidió la palabra: “quiero añadir a esta conversación que siempre
 debemos tener presente la seguridad laboral de nuestras operaciones; uno de los valores de esta empresa. Si vamos a operar
 en minería subterránea, igual que Chuqui, debemos lograr una baja accidentabilidad laboral. En 2011-2012 murieron 15
 personas en minas de rajo abierto, pero en cambio fallecieron 45 personas en minería subterránea.“
 Finalmente, tras una última ronda de opiniones, el directorio de PuroCobre analizó los costos directos de Chuquicamata
 (remuneraciones, costo de refinación y ventas, materiales y energía) de US$ 1,16 la libra en 2012, los que aumentaron en
 11,5% respecto del año previo (US$ 1,04 la libra) y situándose un 8% sobre el costo promedio de las empresas cupríferas
 operando en Chile (US$ 1,07 la libra). Por otro lado, si en 2011 el cobre se cotizó a US$ 4,0 por libra, este año 2012, el
 metal se vendió a US$ 3,5 por libra y según las predicciones de los principales analistas es muy probable que siga a la baja.
 Terminando la reunión, el presidente del directorio de PuroCobre, dirigió la mirada directamente al asesor y le dijo: “tengo 2
 preguntas que me gustaría que me contestaras.” Suponiendo que usted es Cupertino y de acuerdo con la información
 entregada en el caso, responda en forma precisa y concisa las siguientes dos preguntas entregando los fundamentos
 correspondientes:
 1. Analistas del sector han criticado el bono entregado por Chuquicamata a sus trabajadores. ¿Por qué a su juicio, a pesar de
 las críticas, el bono podría ser considerado beneficioso para esa división de la empresa estatal?
 2. Considerando que: (a) PuroCobre tiene negociación con sus sindicatos en algunas semanas más y (b) que la empresa tiene
 características muy similares a la operación de Chuquicamata ¿qué variables consideraría en el diseño del bono que
 PuroCobre debiera entregar a sus trabajadores?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 76

[pág. 77]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2023 | pregunta 2
 Convocatoria 2 | página original 392 | Comisiones y relación de largo plazo
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº 2
 Frut-Ex es una empresa dedicada a la venta de maquinaria agrícola (como por ejemplo tractores y máquinas
 cosechadoras) para la producción frutícola. Fue creada en el año 1998 por Ricardo Paredes (RP), quien fundó la
 empresa antes que Chile se convirtiera en un referente de la producción y exportación de frutas como cerezas,
 uvas, arándanos y frutos secos.
 En esos años, RP aprovechó una amplia red de contactos que había construido en la universidad y sus postgrados
 en el extranjero, para lograr importar maquinarias del rubro agrícola con un alto nivel de especialización que no
 estaban usualmente disponibles en el mercado chileno. Frut-Ex operaba en un mercado en crecimiento, pero
 caracterizado por una cada vez más intensa rivalidad competitiva y el ingreso persistente de nuevas empresas
 comercializadoras de maquinaria con ofertas atractivas para el mundo agrícola.
 Por su parte, la propuesta de valor de Frut-Ex incluía equipamiento de gran calidad y su ventaja se basaba en la
 alta durabilidad de sus productos. A pesar de establecer precios un poco más altos que sus competidores, su
 maquinaria era una buena solución para los agricultores que buscaban rentabilidad en el largo plazo y tenían la
 necesidad de operar con equipamiento de alto nivel de especialización debido a la complejidad de sus tareas
 agrícolas. La vida útil de la maquinaría de Frut-Ex era de 10 años aproximadamente. RP además había conseguido
 que Tuerquita, una empresa independiente, especializada en el servicio de reparación de maquinaria, se hiciera
 cargo del servicio técnico, reparación y mantenimiento a los clientes de Frut-Ex.
 Los clientes de Frut-Ex eran en su gran mayoría medianos y grandes agricultores que tenían cultivos distribuidos
 en varias zonas del país y plantaban diversas variedades de fruta. Los encargados de comprar en dichas empresas
 agrícolas eran en su gran mayoría ingenieros agrónomos con alto conocimiento técnico de los equipos y productos
 que adquirían.
 En sus inicios Frut-Ex comenzó con un equipo de ventas de 10 personas los que eran íntegramente pagados por
 una comisión por articulo vendido. Ese esquema de comisión aún se mantenía. No existía ningún otro tipo de
 pago (el sueldo era 100% variable, sin ningún componente fijo). Ricardo tenía una relación cercana con todos sus
 vendedores (él mismo los seleccionaba y contrataba). A pesar de no contar tampoco con un sistema de evaluación
 de desempeño formal que midiera el desarrollo de las competencias y las conductas deseadas en el personal, la
 tasa de rotación era cercana a cero. Por ello, RP consideraba que el pago íntegramente por comisión hacía todo el
 trabajo necesario para motivar a sus trabajadores. Efectivamente, no solo la rotación era prácticamente nula, sino
 que también las ventas y el negocio crecían satisfactoriamente.
 En los últimos años, RP pensó que el crecimiento del sector frutícola y los logros que había alcanzado su empresa
 eran lo suficientemente robustos como para dar un nuevo salto e innovar. En particular RP pensaba ampliar su
 línea de productos para incluir fertilizantes, mercado altamente competitivo, en donde las innovaciones
 tecnológicas de los fabricantes habían permitido tener productos cada vez de mayor calidad y a mejores precios.
 Una vez analizado este nuevo mercado, RP decidió que sus vendedores ya no sólo venderían maquinaria agrícola,
 es decir, un producto con baja rotación de compra, sino que se ampliaría a fertilizantes, producto que los clientes
 debían comprar de manera repetida varias veces al año para aplicarlos en las distintas variedades y zonas en que
 operaban. A su vez, los fertilizantes eran un producto complejo que requería conocimientos altamente
 especializado del tipo de suelo, la especie de fruta, la humedad, temperatura y otras variables de los predios en
 donde se iban a utilizar, por lo que Frut-Ex tenía considerado que su venta requería entregar una asesoría técnica
 personalizada a sus clientes.
 Luego de conseguir un fertilizante que lo satisfacía desde el punto de vista de la calidad, lo cual era importante
 para ser congruente con su ventaja competitiva, RP y su socio, Carlos Rivero (CR), discutían si es que debían
 modificar la forma en que se motivaba al equipo de ventas. Esto era muy relevante, especialmente porque el
 número de vendedores había crecido de forma sostenida en los últimos años, alcanzando un total de 32 personas
 dedicadas exclusivamente a la venta directa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 77

[pág. 78]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2023 | pregunta 2
 Convocatoria 2 | página original 393 | Comisiones y relación de largo plazo
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 En la última reunión de directorio de Frut-Ex, RP y CR discutían cómo abordar el tema de la motivación a su
 equipo de vendedores a partir de la incorporación de fertilizantes en su oferta a los clientes:
 CR: Ricardo, creo que como nuestro negocio ha crecido, vamos a incorporar ahora la venta de fertilizantes y
 nuestro equipo de vendedores también pasó de 10 a 32 vendedores, es necesario que nos replanteemos como
 motivar a nuestra fuerza de venta.
 RP: Si te refieres a crear un sistema más estructurado para evaluar su desempeño, me parece bien, pero no
 indispensable. Hasta ahora no lo hemos necesitado y además nos ha permitido omitir toda la burocracia que
 significa tener un proceso estructurado y formal de evaluación de desempeño. Por su parte, el sistema de comisión
 por venta, sin un sueldo fijo, nos ha funcionado muy bien durante años. Este esquema ha sido hasta ahora el
 adecuado y consistente con nuestra estrategia de negocio y nuestros atributos de diferenciación. Nos interesa que
 se venda y es por eso se les paga a los vendedores. No veo por qué deberíamos cambiarlo. ¿No te parece Carlos?
 A usted como asesor de la empresa en gestión estratégica de personas y con la información planteada en la
 reunión en la que participa, se le pide que intervenga y responda las siguientes preguntas:
 PREGUNTAS
 a) Considere lo planteado por RP en la reunión respecto a que “el sistema de comisión por venta, sin un sueldo
 fijo, nos ha funcionado muy bien durante años. Este esquema ha sido hasta ahora el adecuado y consistente
 con nuestra estrategia de negocio y nuestros atributos de diferenciación. Nos interesa que se venda y es por
 eso se les paga a los vendedores. No veo por qué deberíamos cambiarlo.” ¿Mantendría usted el esquema de
 incentivos actual? ¿Sí o no? Sea preciso y justifique adecuadamente su respuesta.
 b) Suponga que Frut-Ex ha decidido mantener el esquema de incentivos para la venta de maquinaria, pero al
 mismo tiempo ha optado por desarrollar un nuevo sistema de incentivos para las ventas de fertilizantes.
 ¿Cuáles son los tres principales elementos que la empresa debiera considerar en el diseño de este nuevo sistema
 para la venta de fertilizantes? Fundamente en forma breve su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 78

[pág. 79]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2022 | pregunta 2
 Convocatoria 2 | página original 366 | Contrato psicológico y servicio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº2
 LizTaylor es una empresa chilena de tamaño mediano que diseña, importa y distribuye muebles listos para
 1
 armar . La empresa tiene acuerdos con fabricantes extranjeros para la producción de las distintas partes y piezas
 que luego el consumidor final ensambla en su hogar. LizTaylor fue fundada en 2009 por Igor Robles, dueño y
 gerente general de la empresa, quién recientemente declaraba:
 “Nuestros productos apuntan a acompañar a través de sus diferentes etapas del ciclo de vida al
 segmento de profesionales: primer hogar, vida en pareja, llegada y crecimiento de los hijos, nido
 vacío (los hijos ya adultos se van de la casa) y adultos mayores autovalentes que viven solos de
 manera permanente.”
 Durante toda esta trayectoria vital, LizTaylor se orienta a clientes de ingresos medio-altos, que aprecian los
 diseños atractivos, la buena relación precio-calidad, un excelente servicio de postventa en caso de devoluciones
 y reparaciones y una asesoría personalizada para ayudar a sus clientes en el armado de sus muebles, luego de
 constatar en Chile una cultura aun poco desarrollada en cuanto a las manualidades y reparaciones en el hogar.
 Los clientes de LizTaylor aprecian también la utilización de materiales reciclables asociados a su preocupación
 por el cuidado del medio ambiente.
 Cuando se fundó la empresa, los muebles listos para armar eran una novedad en el mercado chileno y tuvieron
 un éxito mucho mayor a lo que Igor esperaba. La aceptación de la propuesta de valor al cliente que ofrecía la
 compañía le permitieron un fuerte crecimiento en ventas y utilidades entre 2010 y 2019. Durante esa década la
 empresa aumentó su dotación de 50 a 800 trabajadores. Ellos son, prácticamente en su totalidad, profesionales
 calificados con un título técnico avanzado o universitario, de entre 24 y 42 años, que como parte de su
 generación aspiran a “dejar huella” en la sociedad a través de su trabajo, pretenden disfrutar de una buena calidad
 de vida material y emocional, valoran alcanzar mayores logros académicos y profesionales y que dichos
 esfuerzos sean reconocidos.
 A partir de 2020, con el inicio de la pandemia y una necesaria mayor permanencia y trabajo en el hogar, se
 generó un incremento importante en la demanda por los muebles listos para armar. Desafortunadamente,
 LizTaylor no ha aprovechado este incremento de las preferencias de los consumidores de este tipo de muebles.
 De hecho, las ventas de la compañía chilena han caído en los últimos dos años. Sumado a lo anterior, la situación
 competitiva ya no es la misma que en años previos. Recientemente han entrado al mercado varias marcas
 competidoras y en julio de 2022 inició sus operaciones Akilisto, la compañía finlandesa líder mundial en
 muebles listos para armar. Esta empresa ha salido a contratar alrededor de 600 trabajadores para sus primeras
 tiendas según lo anunció su gerente general para Chile hace solo unos días, declarando que:
 “En Akilisto ofrecemos oportunidades de aprendizaje y desarrollo. Creemos en la enorme
 experiencia previa en el sector, capacidad y el gran potencial que pueden seguir desarrollando
 nuestros colaboradores, por lo que los animamos a probar diferentes roles y a cambiar de funciones
 para que adquieran e incrementen su experiencia.”
 La compañía finlandesa se caracteriza por su “diseño escandinavo” mundialmente reconocido de líneas simples
 y cálidas, precios muy convenientes y un servicio de postventa más bien estándar ya que confía en que sus
 clientes pueden seguir fácilmente las instrucciones que acompañan sus productos y “sentirse orgullosos de armar
 sus muebles con sus propias manos”, como declaraba hace unas semanas un ejecutivo de marketing de la
 empresa. Para sostener su propuesta de valor la empresa Akilisto ha mostrado prácticas de gestión de personas
 que son muy atractivas para los trabajadores en todos los ámbitos: un alto nivel de remuneración fija en relación
 a los incentivos variables por desempeño, flexibilidad laboral, buenas condiciones para el trabajo remoto,
 desarrollo profesional del personal y preocupación por el bienestar integral de las familias de sus trabajadores.
 En el ámbito laboral, la rotación voluntaria de LizTaylor, al igual que en la gran mayoría las empresas del retail
 a nivel nacional y global de la industria, han ido en aumento, tal como lo indica el siguiente gráfico.
 1 El cliente compra en la tienda una caja con todos los componentes junto a las herramientas e instrucciones para su armado. Este es un proceso fácil y
 amigable y no requiere de mayores conocimientos ni fuerza física para su ensamblaje.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 79

[pág. 80]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2022 | pregunta 2
 Convocatoria 2 | página original 367 | Contrato psicológico y servicio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 Rotación voluntaria (no despidos)
 25%
 20%
 15%
 10%
 5%
 0%
 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019 2020 2021
 Rotación voluntaria de LizTaylor Rotación voluntaria de del sector retail
 Preocupado por los resultados económicos y también por los niveles de rotación de 1los últimos dos años de
 LizTaylor, Igor encargó un estudio de satisfacción con el trabajo mediante encuestas tanto a ex-trabajadores
 que renunciaron en los últimos dos años y también al personal que actualmente se desempeña en la empresa.
 Los resultados
 2
 se presentan en las siguientes tablas, en donde aparecen los promedios de las respuestas
 obtenidas . Él pensaba que, tal vez, las prácticas de gestión de personas y la relación que estas habían
 conformado entre la compañía y sus empleados habían perdido vigencia. Por otro lado, no estaba seguro ya que,
 reflexionaba: “aquí pagamos bien, más bajo que la competencia en el componente fijo, pero un muy alto
 incentivo variable por productividad que premia el esfuerzo de cada trabajador”
 Dada su preocupación por la caída en resultados e incremento en la rotación, Igor Robles le consulta a usted en
 su calidad de experto en gestión de personas, lo siguiente:
 1. ¿Qué tipo de relación, vínculo o contrato psicológico ha desarrollado LizTaylor con sus trabajadores en el
 tiempo? ¿Es el más apropiado de acuerdo al modelo de negocio que apunta a desarrollar LizTaylor?
 Justifique su respuesta con antecedentes concretos del caso.
 2. Considerando el diagnóstico realizado, proponga los tres cambios más importantes que LizTaylor debe
 realizar en sus prácticas de gestión de personas para mejorar su situación y alcanzar sus objetivos
 estratégicos. Explique, específicamente, cómo los cambios propuestos pueden mejorar la situación
 competitiva de la empresa y la satisfacción/disminución de la rotación de sus trabajadores.
 1 El estudio realizado cuenta con todas las características metodológicas que aseguran su representatividad, validez y confiabilidad.
 2 Las desviaciones estándar en todos los casos son bajas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 80

[pág. 81]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2013 | pregunta 3
 Convocatoria 2 | página original 131 | Contrato temporal y calidad de servicio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 PREGUNTA Nº 3
 Sentado en su oficina junto a algunos de sus ejecutivos, Camelio Arismendi estaba inquieto respecto al rumbo que
 debía darle a la gestión de personas en su empresa de trabajo temporal (ETT), que había fundado bajo el nombre de
 “Por un Rato” (PUR). Su organización se dedicaba a proveer trabajadores temporales a compañías que requerían
 personal externo por períodos breves de tiempo. Concretamente, PUR había adoptado la estrategia de proveer personal
 especializado para desarrollar softwares específicos y mantenimientos complejos que requerían los sistemas
 informáticos de sus clientes. Las empresas que contrataban los servicios de PUR y otras del rubro, habían optado por
 no contar con trabajadores propios para dichas funciones, eligiendo más bien externalizar el personal dedicado a esas
 actividades.
 En los últimos años, muchas empresas respondieron a la mayor rivalidad competitiva y los vaivenes de la demanda
 derivados de los ciclos económicos, con estrategias que flexibilizaban su dotación de personal y disminuían sus costos,
 contratando los servicios de empresas que proveían personal temporal por períodos de tiempo limitados -algunas
 semanas, días o incluso por horas-, para realizar proyectos o tareas específicas.
 PUR entregaba una oferta de servicios cuya demanda si bien era aún acotada en el mercado, crecía a tasas del 25%
 anual, lo que reflejaba la creciente necesidad de las empresas contratantes por acceder a trabajadores temporales en el
 ámbito de la informática. Las empresas que solicitaban personal informático a las ETT apreciaban los conocimientos y
 experiencia técnica de las personas que se les enviaba, y que ojalá estuvieran al tanto de las últimas novedades y
 tendencias computacionales. Frecuentemente, los clientes solicitaban una y otra vez al mismo trabajador cada vez que
 requerían de los servicios de la empresa. Al respecto, un cliente comentaba: “el trabajador ya nos conoce y esto se
 agradece ya que buscamos que haya un calce entre las necesidades puntuales, específicas y de corto plazo que tenemos
 y las características de las personas que nos envían las ETT.”
 PUR pagaba a sus trabajadores temporales un monto fijo por hora que era un 30% mayor que la media del mercado
 para empleos similares. La empresa, por su parte, cobraba a sus clientes el valor de estos honorarios y sobre ellos
 cargaba a los clientes un margen de entre 50% y el 65% de dicho valor.
 Las reflexiones de Arismendi, se vieron interrumpidas ante la descripción que hacía Libardo Valencia, su gerente de
 operaciones, acerca del modelo de gestión de personas que estaba aplicando con el personal de PUR. Valencia había
 optado por estructurar contratos a plazo fijo –con un máximo de 90 días- con el personal que contrataban. “Tenía
 sentido dada la corta duración de los trabajos que les solicitaban; muchas veces nos piden gente sólo por algunas
 semanas, o incluso días”, apuntaba Valencia. Y agregaba, “debemos acostumbrarnos a que no vamos a generar lazos
 afectivos con nuestro personal por la alta rotación que tenemos, ellos están de paso. Por eso mismo buscamos evitar los
 gastos asociados a los contratos indefinidos, como son los sueldos por todo el año, los beneficios al personal y las
 indemnizaciones. También evitamos el costo de capacitación de nuestro personal, que no se justifica, ya que ellos están
 altamente calificados. Ellos tienen que hacerse cargo de su propio desarrollo si es que quieren mantenerse vigentes en
 este negocio.” Valencia terminaba señalando: “nuestro modelo de variabilización y ahorro de costos está perfectamente
 alineado con nuestra estrategia.”
 Arismendi, sin embargo, reflexionaba frente a los argumentos de Valencia. Sabía que había aspectos positivos en sus
 planteamientos, pero sospechaba que también presentaban algunos inconvenientes para PUR.
 PREGUNTAS
 1) Considerando la estrategia de negocios de PUR indique, en forma breve y precisa, los principales aspectos positivos,
 y los elementos negativos que Ud. observa en el “modelo de gestión de personas” propuesto por Valencia.
 2) En el entendido de que PUR ha decidido mantener su actual estrategia de negocios, indique las 3 principales
 prácticas de gestión de personas orientadas al personal de PUR que debieran implementarse, para minimizar los efectos
 negativos derivados del modelo de gestión de personas que ha aplicado PUR hasta ahora e identificados por Ud. en la
 pregunta anterior. Fundamente su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 81

[pág. 82]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2017 | pregunta 2
 Convocatoria 2 | página original 242 | Cultura tóxica y sistema de personas
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N*2
 Es 2008. Cae una intensa nevazón sobre Paris, la “ciudad luz”, capital de Francia. Los emprendedores
 estadounidenses Travis Kalanick y Garrett Camp se encuentran en viaje de negocios en esa ciudad y tienen
 problemas para conseguir un taxi. Piensan en una simple idea: “qué tal sería simplemente presionar un botón
 para conseguir un viaje.”
 Así nació Uber, aplicación que cambió la forma en que las personas se movilizan en el planeta. A los pocos
 meses, ya de regreso a si país, Kalanick y Camp lanzaron Uber, que comenzó a operar en San Francisco, Estados
 Unidos. Hoy la compañía está presente en 500 ciudades en todo el mundo y Kalanick —actual gerente general
 (CEO) de la empresa-, de 40 años, ya posee una fortuna de US$6.700 millones y la empresa tiene un valor de
 US$69.000 millones, según Bloomberg.
 Una de las principales razones para el explosivo crecimiento de la compañía, es la cultura de la empresa de alta
 intensidad, la que está instalada sobre una estructura descentralizada con un énfasis importante en la autonomía
 de cada oficina en cada país y ciudad, sin una supervisión cercana de la oficina central de San Francisco. A cada
 persona se le pide un alto nivel de exigencia con resultados financieros concretos y rápidos.
 Pero, al parecer, los números no lo son todo. Hace 1mos días Kalanick fue obligado a dejar su cargo de CEO,
 tras la fuerte presión de los inversionistas. Aunque seguirá en la empresa, las razones para que saliera de la
 dirección obedecen a una serie de polémicas al interior de la firma, como denuncias y juicios laborales por acoso
 sexual y laboral, declaraciones machistas de varios ejecutivos de nivel alto y mandos medios de la empresa y
 conductas refiidas con la ética de varios empleados de Uber en diferentes niveles jerárquicos y áreas funcionales
 de la organización. De hecho, la compañía despidió hace pocos días a 20 empleados, después de 215 quejas en
 el interior de la empresa por estas malas prácticas. A lo anterior se suman problemas de liderazgo que él mismo
 CEO reconoció, luego que Bloomberg publicara un vídeo, en febrero, en que se mostraba a Kalanick discutiendo
 con un conductor de Uber. La empresa también enfrenta varias investigaciones judiciales por cuestionamientos
 acerca del uso encubierto de softwares para que sus conductores eviten ser detectados por las autoridades en las
 áreas donde sus autos no pueden trabajar y por tácticas aparentemente encaminadas a perturbar a rivales en el
 negocio del transporte compartido.
 Cuando los nuevos empleados son seleccionados y llegan a trabajar a Uber, les piden un par de requisitos: que
 tengas ganas de dario todo en su cargo y que se apeguen a los valores centrales de la empresa Estos valores se
 pueden resumir en que “cada trabajador de Uber debe hacer apuestas audaces, estar “obsesionado” con el cliente,
 trabajar muy arduamente y apuntar a la meritocracia como mecanismo de ascenso en la compañía: la idea de
 que los mejores y más brillantes ascenderán con base en su propio esfuerzo.” Lo anterior también se
 complementa con un agresivo esquema de incentivos que enfatiza el esfuerzo y resultados individuales, con la
 promesa adicional de que “los que más contribuyan al crecimiento de la empresa tendrán un progreso más rápido
 en ella”, en palabras de un alto ejecutivo de Uber. Varios empleados también señalaron que, en ocasiones, se
 observa incluso que ejecutivos de alto desempeño pero con problemas con sus equipos no salían de la empresa,
 sino que eran reasignados a otras regiones. “El despido no es una alternativa para la gente con buenos resultados
 en Uber. A veces, los gerentes problemáticos, objeto de numerosas quejas, eran asignados a distintas regiones;
 los despidos eran menos comunes”, indicó Gerard Stevenson, un trabajador con muy buen desempeño, que ha
 estado desde el inicio de la compañía. Al parecer, un grupo en particular era inmune al escrutinio interno, dijeron
 empleados y ex empleados. Incluso los miembros de ese grupo, llamado A-Team y compuesto por ejecutivos
 de diversos niveles y áreas de la organización, cercanos a Kalanick, no tenían por qué rendir cuentas de sus
 actos.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 82

[pág. 83]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2017 | pregunta 2
 Convocatoria 2 | página original 243 | Cultura tóxica y sistema de personas
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Durante las investigaciones en curso varios trabajadores como Susan Fowler, indicaron que en múltiples
 oportunidades había presentado reclamos a la gerencia de recursos humanos sobre sus problemas. Señalaron que
 a menudo los ignoraban, con lo que quedaban completamente desamparados frente a los abusos. Ella y otros
 empleados dijeron que Recursos Humanos a menudo justificaba estos actos. En una oportunidad, comentó
 Fowler, me señalaron claramente: “sería bueno recordarte que los indicadores de crecimiento en ventas y
 eficiencia operacional para todos los empleados eran los dos indicadores de gestión que contaban. La compañía
 te lo deja claro desde un principio. Esto es Uber.”
 Con la salida de Kalanick como CEO, el directorio se ve ahora en la necesidad de tomar medidas respecto a lo
 sucedido y disminuir las posibilidades de que estos acontecimientos se repitan en el futuro. El directorio se daba
 cuenta que los resnltados financieros no lo eran todo y ahora estaba preocupado por la sustentabilidad de los
 números que mostraba Uber, Para ello, como asesor del directorio a Ud. se le pide que responda las siguientes
 preguntas:
 PREGUNTAS
 1. Indique y describa cuáles son las tres principales prácticas de gestión de personas que llevaron a la creación
 de la cultura de trabajo que se ha desarrollado transversalmente en la empresa Uber.
 2. Explique ¿cómo transformaría la cultura de Uber para hacer de esta una empresa más sostenible? Describa
 las tres principales prácticas de gestión de personas que usted implementaría para lograr el objetivo de
 sustentabilidad señalado.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 83

[pág. 84]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2021 | pregunta 5
 Convocatoria 2 | página original 350 | Desempeño y cambio estratégico
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 PREGUNTA Nº5
 Move+ es una consultora fundada en 2018, dirigida a diseñar, implementar y evaluar programas de mejora de
 salud de trabajadores en empresas de diferentes rubros. Su fundador y gerente general, Germán Carrasco
 entendió que los trabajadores de muchas empresas, con la intención de romper la monotonía de su trabajo,
 incurrían en conductas peligrosas al realizar sus labores. Para ello, la mayoría de los servicios de Move+ se
 han concentrado en crear planes de deporte, salud, meditación y alimentación saludable para estas compañías
 que buscan fomentar el bienestar y la productividad de su personal.
 Move+ apunta a diferenciarse de la competencia por sus soluciones creativas que se adaptan a una gran gama
 de necesidades, considerando las especificidades en las funciones y preferencias de los trabajadores, además
 de las restricciones en las instalaciones disponibles de las empresas que contratan sus servicios, sobre todo
 debido a la pandemia. La relación con los gerentes de recursos humanos, que contrataban los servicios y con
 los trabajadores de las empresas cliente, eran clave para entender sus necesidades y adaptar permanentemente
 las soluciones ofrecidas. La empresa no estaba sola en el mercado. Recientemente, en el mercado en donde
 estaba posicionado Move+, habían aparecido, y capturado una participación de mercado relevante, una serie
 de nuevos competidores. Estos nuevos actores, se diferenciaban mediante la utilización intensiva de las nuevas
 tecnologías digitales y la inteligencia artificial, ofreciendo al mercado aplicaciones móviles y servicios online
 con planes de salud, deporte y bienestar a la medida para los trabajadores de sus clientes.
 Por su parte, con la crisis sanitaria, Move+ creció rápidamente, diversificando aún más el número de programas
 para el personal de las empresas que estaban teletrabajando. En sus inicios la compañía contaba con 5
 ingenieros comerciales a cargo del diseño y la evaluación de los programas para empresas y 20 técnicos
 deportivos y de la salud que implementaban el plan y recogían la información necesaria para hacer las
 evaluaciones de los programas implementados. En 2021, en cambio, la empresa contaba con 15 ingenieros
 comerciales y 50 técnicos.
 Este aumento en el volumen y diversificación de los planes para sus clientes fue posible gracias a la transición
 que hizo el equipo de ingenieros comerciales de Move+, hacia la modalidad de teletrabajo en un 100%, a
 comienzos de 2020. A su vez, los técnicos que implementaban y supervisaban los planes deportivos y de salud
 para las empresas, fueron reasignados de manera transitoria a tareas de apoyo en diseño y la evaluación. De
 todas formas, Germán Carrasco, junto al Directorio de la empresa, decidió que, luego de la pandemia, todo el
 personal de la compañía evolucionaría de manera permanente a una modalidad de trabajo híbrido integrando
 lo presencial con teletrabajo. Las labores remotas hacían aún más crítica la comunicación y colaboración entre
 todos los empleados de Move+. Debían intensificar su integración en los equipos para dar respuesta a los
 constantes cambios que solicitaban los clientes, evaluarlos, rediseñar soluciones y buscar una mayor
 diferenciación de la competencia. Necesitaban profundizar su propuesta de valor asociada al servicio
 personalizado y cercano a las empresas, tanto para quiénes contrataban el servicio como para los usuarios, de
 modo de competir frente a una oferta de la competencia con menor relacionamiento con los clientes, pero
 intensiva en tecnología. Cada equipo de Move+ atendía a varios clientes y una misma persona era parte de
 varios equipos al mismo tiempo.
 Germán Carrasco contaba con 2 jefes comerciales, cada uno a cargo de dirigir y coordinar a los equipos de
 trabajo. En la nueva modalidad de teletrabajo, a él y los coordinadores les costaba más poder interactuar con
 cada persona dentro de la empresa. Si bien recibían informes periódicos de venta, abandono del servicio por
 parte de clientes, encuestas de satisfacción de clientes, o informes con el avance en la implementación de los
 proyectos en sus clientes, el teletrabajo dificultaba los vínculos con cada uno de quienes conformaban los
 equipos. Esta situación se agudizaba por el hecho que durante 2020 habían recibido un número importante de
 nuevos ingenieros comerciales a cargo de diseño y evaluación de programas. Las reuniones de trabajo
 presenciales se hacían menos habitualmente por la dificultad de coordinar horarios debido a las múltiples
 obligaciones que ahora debían absorber los empleados de la compañía. Antes, los directivos le daban mayor
 atención a los trabajadores que sentían que tenían mayores brechas de desempeño, ahora, ello era menos
 frecuente. Por otra parte, el gerente general estaba inquieto porque hasta ahora las remuneraciones (fijas y
 variables) no estaban vinculadas con el desempeño de los empleados de la empresa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 84

[pág. 85]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2021 | pregunta 5
 Convocatoria 2 | página original 351 | Desempeño y cambio estratégico
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 En el mes de diciembre de cada año, Germán Carrasco y sus 2 coordinadores de equipo realizaban la evaluación
 formal de desempeño de cada una de las personas de Move+. Contaban con una pauta y una escala de
 evaluación definida que aplicaban al personal, cada uno de manera individual. Luego, se reunían entre los tres
 y consensuaban la evaluación final de cada empleado. Posteriormente sostenían una entrevista de
 retroalimentación para dar a conocer los resultados y generar un plan de trabajo para el año siguiente con
 acciones que apuntaban al desarrollo de competencias y conductas asociadas a las necesidades del negocio.
 En enero de 2021, sin embargo, los trabajadores le manifestaron al gerente general que durante ese año no era
 conveniente realizar la evaluación de desempeño. Según ellos, la evaluación constituía una instancia estresante
 que nadie estaba dispuesto a enfrentar de buena forma. Los empleados argumentaron que habían tenido un
 aumento de la carga de trabajo y les faltaba tiempo para hacer la evaluación de manera profesional. También
 mencionaron las evidentes presiones que experimentaban los trabajadores de Move+ por las mayores
 exigencias que significaba para ellos el tener que teletrabajar, junto a los deberes asociados al cuidado de niños
 y adultos mayores y otras labores domésticas que consumían importantes horas de su día, con límites de tiempo
 poco claros en la jornada laboral. Por último, el personal indicaba que la evaluación de desempeño estaba
 basada principalmente en variables subjetivas, como la percepción de los clientes, la observación de las
 competencias técnicas de los empleados y las conductas asociadas al servicio al cliente, proactividad y
 colaboración al interior de los equipos, entre otras.
 Suponga que estamos a comienzos de 2021. A usted se le pide, que en relación a la información planteada
 en el caso y tomando en cuenta los objetivos de Move+ junto a los conceptos de gestión estratégica de
 personas, entregue su opinión respecto al esquema de evaluación de desempeño y al sistema de incentivos
 variables. En concreto:
 a) El Directorio de la empresa ha decidido llevar adelante la evaluación de desempeño, pese a la solicitud
 contraria de los trabajadores. Desarrolle dos argumentos que permitan respaldar la decisión del
 Directorio.
 b) Alineado con el mandato del Directorio, Germán Carrasco decidió realizar la evaluación de desempeño
 durante 2021, pero adecuándola a la situación actual y futura de la empresa. Por ello, explique dos
 componentes o características esenciales que debiera considerar el nuevo modelo de evaluación de
 desempeño.
 c) Germán Carrasco, le solicita además que explique dos componentes o características esenciales que
 debiera considerar un esquema de incentivos variables que esté asociado a la evaluación de desempeño
 del personal de Move+.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 85

[pág. 86]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2024 | pregunta 2
 Convocatoria 1 | página original 405 | Diversidad e inclusión
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº2
 Desde su fundación en 2017, InnovarTech Chile se ha destacado como un polo de desarrollo de la innovación en
 el país. La compañía comenzó como una pequeña startup con una estrategia de negocios especializada y a la
 vanguardia en soluciones de inteligencia artificial (IA) que facilitan la capacidad predictiva de sus clientes mineros
 en aspectos como la detección de las áreas óptimas para el desarrollo de su explotación, la prevención de riesgos
 de accidentabilidad o la reducción de costos operacionales. Su estrategia competitiva está orientada al escalamiento
 de sus operaciones de manera de proveer en todo el mundo, a partir de su desarrollo de plataformas tecnológicas
 con una base de productos comunes, soluciones únicas y customizadas a los diferentes clientes y sus necesidades
 de la industria minera.
 El modelo de innovación de InnovarTech se centra en 3 pilares, los que son clave para el logro de sus objetivos de
 negocio en cuanto a liderar el mercado de soluciones avanzadas de IA para la industria minera. Ellos son:
 • Desarrollamos soluciones de IA que atiendan las necesidades actuales y futuras del mercado. Debemos ser líderes
 de innovación en nuestras soluciones para la industria a escala mundial.
 • La Innovación no es un acto individual sino un proceso colectivo y colaborativo que se enriquece con las
 distintas perspectivas de todas nuestras gerencias. Por ello, debemos promover una amplia diversidad de perfiles
 en nuestra organización.
 • Somos una sola marca y una única empresa y debemos proyectarnos al mercado como una única empresa siempre
 coherente con la calidad de nuestras soluciones, la confiabilidad de nuestros productos, así como igualdad de
 oportunidades, desarrollo y trato respetuoso para todos.
 Si bien la empresa había crecido durante la pandemia, alcanzando ingresos de US$80 millones en 2021 que incluye
 sus ventas no solo en Chile, sino que también en mercados internacionales como Perú y Brasil, en los últimos 2
 años los números mostraban una preocupante caída en las ventas y márgenes, así como en su capacidad para innovar
 y de captar y mantener clientes. InnovarTech contaba a fines de 2023 con una dotación de 350 empleados con un
 31% de mujeres y 69% de hombres de 11 nacionalidades y culturas diferentes. Sus edades varían entre 23 y 62
 años al igual que su formación, ya que su personal posee desde títulos técnicos hasta doctorados, existiendo además
 una amplia gama de experiencias profesionales en una multiplicidad de industrias. El personal se selecciona de
 acuerdo a criterios técnicos, apuntando también a su diversidad. Al ser una empresa de soluciones de software el
 énfasis de la capacitación está puesto en los conocimientos y habilidades técnicas, al igual que el desarrollo de
 quienes se destacan en la compañía, cuya promoción depende de su desempeño individual y el mejoramiento
 sostenido de sus habilidades técnicas. Por su parte, los incentivos variables por desempeño para el personal están
 asociados al logro de objetivos definidos para la gerencia en la que cada cual se desempeña.
 La estructura organizacional de InnovarTech sigue una lógica funcional. Así, el Directorio y la Gerencia General
 se encargan de establecer la visión y estrategia de la empresa, supervisar todas las operaciones y asegurar el
 cumplimiento de los objetivos corporativos. Suelen tener opiniones muy homogéneas. Su composición es
 completamente masculina, con personas experimentadas en diversas industrias y países
 Por su parte, la Gerencia de Marketing y Ventas está a cargo de desarrollar estrategias comerciales, gestionar
 campañas publicitarias y supervisar el equipo de ventas para maximizar los ingresos. Es un equipo joven,
 culturalmente muy diverso, que ha logrado éxitos notables en ciertas campañas. Sin embargo, también ha tenido
 resultados pobres al promover soluciones en empresas más tradicionales poco orientadas al uso de nuevas
 tecnologías. Un ejemplo de ello era la gestión de María. Ella es una especialista en marketing, una influencer en
 redes sociales, particularmente en la promoción de nuevas soluciones que Innovar Tech lanzaba al mercado. Si
 bien María tenía gran tracción comercial en el segmento de sus clientes mineros más jóvenes, no siempre lograba
 buenos resultados con empresas más tradicionales en cuanto a su dominio de la tecnología.
 A su vez, la Gerencia de Investigación y Desarrollo genera las primeras ideas y pruebas piloto de las nuevas
 soluciones, apuntando a mantener a la empresa a la vanguardia tecnológica. En las posiciones clave de esta área
 trabajan ingenieros, hombres, reclutados de las dos mejores escuelas de ingeniería de Chile. Pedro, un ingeniero de
 software de Brasil con un historial de excelencia técnica, era la excepción a esta regla ya que fue contratado en esta
 Gerencia. Pedro, de hecho, comentaba las dificultades que había encontrado para adaptarse a su nuevo entorno
 laboral.
 Por último, la Gerencia de Personas estaba compuesta en un 95% por mujeres de diversas edades, currículums
 profesionales y nacionalidades, casi todas provenientes de América Latina. Esta área tiene la responsabilidad sobre
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 86

[pág. 87]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2024 | pregunta 2
 Convocatoria 1 | página original 406 | Diversidad e inclusión
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 la gestión del talento; su atracción y selección, capacitación, desarrollo y retribución de quienes conforman
 InnovarTech. En sus procesos, esta Gerencia pone énfasis en promover un alto grado de diversidad cultural de los
 trabajadores de la empresa, de manera de hacer creíble la promesa de igualdad de oportunidades y desarrollo y con
 ello potenciar la innovación en la compañía. No siempre, sin embargo, se lograba este objetivo. De hecho, Li, una
 ejecutiva de selección de personal, de origen chino, contratada hace un año, comentaba en diversas reuniones que
 se sentía aislada debido a barreras idiomáticas y su poca costumbre a las largas reuniones de trabajo que sostenía
 su equipo versus instancias breves y eficientes a las que ella estaba acostumbrada. Esto afectaba su participación
 en el equipo. Así, en esta Gerencia y en otras, el clima laboral era irregular. Algunas gerencias mostraban muy
 buenos índices y otras, en cambio, mucho conflicto.
 Preguntas:
 1. Frente a los malos resultados del último tiempo, Ricardo Barrios uno de los gerentes de la empresa, en la reunión
 de cierre de resultados de 2023 comentaba: “tenemos demasiada diversidad en nuestro personal y eso dificulta
 la toma de decisiones para la innovación y el logro de nuestros objetivos estratégicos. Como experto en gestión
 de personas y cultura organizacional y considerando el rol de la diversidad en la adecuada ejecución de la
 estrategia de InnovarTech, se le pide que explique: ¿Cuál es el problema con la diversidad en InnovarTech? ¿El
 problema es el que señala el ejecutivo? ¿O es otro el problema? Justifique de manera precisa su respuesta.
 2. Otra ejecutiva de InnovarTech, Sandra Cabrera, señalaba en la misma reunión de cierre de 2023: “la diversidad
 nos favorece, pero está mal gestionada.” A usted como analista se le pide que indique tres iniciativas de gestión
 de personas y cultura organizacional que permitan lograr que la diversidad del personal fortalezca el
 alineamiento de los equipos con los pilares estratégicos y los objetivos de negocio de la empresa. En su respuesta
 señale cómo las prácticas propuestas impactarán positivamente en el alineamiento del personal de la empresa
 con los pilares del modelo de innovación y los objetivos de negocio de la empresa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 87

[pág. 88]
Dirección - versión clara y reordenada
 Dirección de Personas | marzo 2009 | pregunta 4
 Convocatoria 1 | página original 8 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 PREGUNTA Nº4
 “Tenemos que hacer nuestro mejor esfuerzo por proyectar la duración de esta crisis. Lo que es claro es que los
 impactos de esta debacle financiera ya se sienten sobre nuestra empresa”. Con estas palabras iniciaba el Gerente
 General de Constructora el Andamio S.A. (CASA), la última reunión del año 2008 del Comité de Gerentes.
 CASA es una empresa de ingeniería y construcción con una estrategia de negocios de diversificación relacionada que
 opera en tres negocios diferentes. Su actividad principal la desarrolla en la construcción y venta de casas y
 departamentos. Este sector ha experimentado una enorme caída de alrededor de un 50% de las ventas en los últimos
 tres meses de 2008 y se espera que esta baja demanda se mantenga al menos por los próximos 2 años, particularmente
 en el sector de viviendas de precio medio y bajo (menor a UF 3.500), donde CASA mantiene el 60% de los ingresos
 totales de todos sus negocios. Los analistas del sector inmobiliario, sin embargo, indican que el sector de viviendas
 para los segmentos de clientes de mayores ingresos se mantendrá e incluso puede experimentar un crecimiento del
 10% anual.
 CASA también había iniciado operaciones hace un par de años en el negocio de los servicios de ingeniería y
 construcción para el sector eléctrico, en donde se dedica a la instalación de torres de alta tensión y cables de
 transmisión eléctrica. Tanto las autoridades de gobierno como las empresas eléctricas han anunciado el inicio de
 importantes proyectos para los próximos 3 años, de modo de poder cerrar la brecha energética que tiene Chile desde
 hace ya varios años. Por su parte CASA, desarrolla el 20% de su actividad en este sector.
 El tercer tipo de actividad donde opera CASA es el de obras viales, que implica la construcción y reparación de
 caminos y puentes y cuyo principal cliente es el Ministerio de Obras Públicas (MOP). Se espera un incremento
 sustantivo de esta actividad ya que tal como lo han anunciado las autoridades de Gobierno, se va a incurrir en un
 mayor gasto público a través de mayores obras de vialidad, como una manera de reactivar la economía en los
 próximos 2 años.
 CASA es una empresa que, bajo una estrategia corporativa común, opera sus tres unidades de negocio con autonomía,
 contando cada una de ellas con su respectivo Gerente de División. Por su parte, la mayoría del personal de estas áreas
 de negocio (85% de la dotación y las remuneraciones totales de CASA) son ingenieros y constructores civiles
 formados profesionalmente en la propia empresa, con varios años trabajando en ella y con muy buenos niveles de
 desempeño.
 La estructura de la empresa cuenta además con dos Gerencias de Servicios compartidos, que brindan apoyo a las tres
 líneas de negocio y permiten diseñar e implementar sistemas de gestión homogéneos a través de todas las operaciones
 de CASA. Una de ellas es la Gerencia de Administración y Finanzas, bajo cuya responsabilidad están el desarrollo y
 aplicación de las políticas y sistemas de contabilidad, tesorería, finanzas, control de gestión, informática y recursos
 humanos. Por último, CASA contaba con la Gerencia de Estudios y Nuevos Proyectos, en donde se analizan las
 nuevas propuestas y proyectos que la empresa está evaluando emprender en los diferentes sectores de la ingeniería y
 construcción donde actualmente opera. El personal de estas dos gerencias representa el 15% del total del personal y
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 88

[pág. 89]
Dirección - versión clara y reordenada
 Dirección de Personas | marzo 2009 | pregunta 4
 Convocatoria 1 | página original 9 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 las remuneraciones de la compañía, siendo en su mayoría también ingenieros y constructores civiles, con un número
 menor de personal administrativo.
 El organigrama de la empresa, que resume las funciones antes señaladas, se presenta a continuación.
 Cuando transcurría ya un buen rato desde que la reunión del Comité de Gerentes se había iniciado, el Gerente de la
 División Viviendas, señalaba: “Nuestro negocio ha caído abruptamente. Las empresas de nuestro rubro ya están
 despidiendo a mucha gente. Por ello, estoy convencido que deberíamos despedir cerca del 30% de nuestro personal
 técnico y profesional. Es más, tengo ya definido y en mi mano un plan de despidos que les quiero presentar.”
 Parecía que la decisión era inminente y el Comité de Gerentes se disponía a aprobarla, cuando pidió la palabra el
 Gerente de Administración y Finanzas, quién señaló: “Debemos reducir al mínimo los despidos en CASA. Es más,
 ojalá pudiéramos seguir una estrategia de despido cero. Y, al igual que el Gerente de la División Vivienda, también
 tengo un plan diseñado para lo que propongo.”
 A usted se le pide responder las siguientes preguntas:
 1. Sin optar por la propuesta del Gerente de Vivienda o, alternativamente, por la del Gerente de Administración y
 Finanzas, mencione un máximo de cuatro variables específicas, ya sea del entorno de negocios de CASA, su
 estrategia o sus elementos organizacionales internos, que a su juicio sean claves para evaluar ambas
 proposiciones. Sea preciso y justifique su respuesta.
 2. Indique qué comportamiento deberían tener las variables por usted mencionadas en la respuesta a la primera
 pregunta, para que la propuesta del Gerente de Administración y Finanzas – mínimos despidos y ojalá “despido
 cero”-, sea aplicable con éxito en CASA. Sea preciso y justifique su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 89

[pág. 90]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2009 | pregunta 4
 Convocatoria 2 | página original 21 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 PREGUNTA Nº4
 Juan Chalet, principal accionista de “Constructora Los Chaleses” (CLC), leía las impactantes noticias acerca de las
 enormes pérdidas y quiebras de muchas empresas en Estados Unidos de Norteamérica. Esto lo hacía reflexionar
 acerca de su propia Compañía y se preguntaba por qué las empresas con las que competía en el segmento de
 construcción de viviendas de alto precio, seguían creciendo y registrando buenas utilidades, mientras CLC registraba
 pérdidas significativas en los dos últimos ejercicios.
 Más aún, al escuchar a varios analistas indicando que las altas compensaciones e indemnizaciones a los ejecutivos de
 esas empresas en Estados Unidos de Norteamérica, habían sido la principal causa de los malos resultados, Chalet
 comenzó a pensar que él había cometido el mismo error. “Simplemente, no somos capaces de pagar estos sueldos y
 nuestros bonos variables por resultados han incentivado a nuestros ejecutivos a tomar decisiones que han dañado
 severamente nuestro negocio”, argumentaba el empresario frente a otro de sus socios. Y continuaba: “En los últimos
 años no ha existido ninguna relación entre la compensación total que han recibido los principales ejecutivos de la
 empresa y los deficientes resultados que han mostrado los estados financieros, incluso ya desde el año 2007, varios
 meses antes que se desatara la crisis económica actual”.
 La estrategia de CLC apuntaba a generar una diferenciación por calidad, servicio al cliente e innovación tanto en los
 productos habitacionales que vendía como en los procesos constructivos que utilizaba. Al mismo tiempo, la
 constructora buscaba ser una empresa integrada con “una sola cara frente al cliente”, como base para lograr sus
 propósitos anteriores, para lo que se requería una activa cooperación entre las diferentes áreas de la empresa –
 estudios, construcción, administración y finanzas. Juan Chalet se preguntaba entonces, qué cambios realizar -si es que
 fueran necesarios-, en el esquema de compensaciones del equipo ejecutivo, compuesto por Bernardo Maffod -el
 Gerente General de la empresa- y su equipo de Gerentes; un total de 15 personas.
 El actual sistema de remuneraciones del equipo de ejecutivos de CLC, se componía de dos elementos principales. En
 primer lugar y por política, los sueldos base (parte fija de la compensación), se fijaban en un 10% por sobre la media
 del mercado relevante. Segundo, los bonos variables se pagaban por el cumplimiento de los resultados financieros de
 la empresa de acuerdo a una tabla, con la posibilidad de llegar a obtener hasta 6 sueldos base como incentivo total
 anual, si se superaban ampliamente las metas financieras propuestas.
 CLC tenía un equipo ejecutivo con pocos años en la empresa. Todos ellos se habían incorporado en los últimos 2 años
 a la empresa, bajo la lógica de que la Compañía tenía que profesionalizarse y en palabras de otro de los accionistas de
 la empresa, lo clave era “atraer a aquellos que hubieran mostrado buenos resultados en otras empresas del sector”.
 Simultáneamente, uno de los Directores de CLC, afirmaba que todos los miembros del equipo ejecutivo de la
 Compañía tenían una “larga trayectoria técnica y muchos años en el mundo de la construcción”. Por su parte, el
 equipo ejecutivo de CLC tenía un gran desafío, debido a que bajo su dirección tenía gente muy joven y muchas veces
 no con la formación y la experiencia requerida para desarrollar el negocio. Asociado a lo anterior, CLC operaba con la
 lógica de sus socios fundadores, los que planteaban que “nuestros profesionales deben ser proactivos para buscar
 oportunidades de formación en su propio trabajo de terreno; en la obra en que están trabajando ... así es como todos
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 90

[pág. 91]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2009 | pregunta 4
 Convocatoria 2 | página original 22 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 hemos aprendido este oficio”.
 Por otra parte, la política de CLC era de “poca paciencia”, es decir si los resultados no se daban en 2 años, los
 ejecutivos debían salir de la empresa. “Aquí la Compañía se construye obra a obra, proyecto a proyecto. Si no somos
 rentables en cada obra, el negocio no es viable y en ese caso debemos hacer cambios drásticos en nuestra organización
 para enmendar el rumbo”, afirmaba uno de los socios de CLC.
 A raíz de los malos resultados, algunos asesores a los que Juan Chalet había consultado, le habían aconsejado
 negociar con Maffod y los otros ejecutivos de la empresa, el siguiente conjunto de tres medidas en el sistema de
 remuneraciones del equipo de ejecutivos de CLC:
 a. Reducir el sueldo base del equipo ejecutivo y fijarlo un 10% por debajo de la media del mercado.
 b. Incorporar otros indicadores, además de los financieros, para la obtención del bono variable por parte de los
 ejecutivos.
 c. Implementar definitivamente un plan de entrega anual de opciones sobre acciones de la Compañía, que los
 ejecutivos podrían ejercer en un plazo no inferior a 3 años.
 A usted, como viejo amigo de la familia Chalet y en su calidad de experto en administración de personas, se le pide
 que:
 1. Evalúe si las tres medidas propuestas en el ámbito de las compensaciones son, como conjunto, coherentes con el
 logro los objetivos estratégicos de largo plazo de la Compañía CLC. Para su respuesta, indique si aplicaría este
 conjunto de medidas o no. Justifique su respuesta a través de un análisis de las fortalezas y debilidades de esta
 propuesta de compensaciones, considerando las medidas en su conjunto y no cada una de ellas por separado.
 2. Un analista del sector planteaba que “el éxito de CLC no depende sólo de su política de compensaciones. Creo
 que si la empresa efectivamente quiere obtener una rentabilidad atractiva y sustentable, debe modificar la forma
 en que gestiona el desarrollo de las competencias de sus ejecutivos al interior de la empresa.” ¿Está de acuerdo
 con esta afirmación? Justifique de manera precisa su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 91

[pág. 92]
Dirección - versión clara y reordenada
 Dirección de Personas | marzo 2010 | pregunta 4
 Convocatoria 1 | página original 37 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 PREGUNTA Nº4
 El Banco Real de Gales (The Royal Bank of Wales, RBW) es una institución financiera internacional con más de 90 años
 en el mercado de la banca dedicada a entregar servicios financieros a personas. Esta organización, ha logrado establecer
 una posición de liderazgo en Norteamérica, Europa y algunos países emergentes. Recientemente el RBW ha decidido
 entrar a Chile e iniciar operaciones a partir de 2010.
 Los ejecutivos del Banco han planteado que pretenden aplicar en nuestro país, la misma estrategia de negocios mediante
 la cual han logrado altas rentabilidades en el pasado. El RBW es un Banco de “nicho”, concentrando su participación en
 el segmento de más altos ingresos. El cultivo de una relación amable y personalizada con sus clientes y su estándar de
 servicio con apoyo tecnológico con prácticamente “cero error”, se han convertido en su principal fuente de ventaja
 competitiva, logrando una alta satisfacción de sus clientes y una rentabilidad superior a la del promedio de su industria.
 Si bien el RBW plantea tener sucursales y ejecutivos del más alto nivel para la atención presencial de sus exclusivos
 clientes, adicionalmente planea tener un servicio telefónico, un “Call Center”, con un servicio de excelencia. Este Call
 Center, estará conformado por 200 personas que ejercerán el cargo de “Representante de Servicio” (“R. de S.”) de
 RBW. A través de este Call Center se pretende que estos R. de S. reciban todo tipo de requerimientos de servicio por
 parte de los clientes y den respuestas a sus inquietudes, complementando así la atención de excelencia de las sucursales
 presenciales.
 En sus operaciones en otros países del mundo el RBW ha implementado un proceso de selección de sus R. de S.
 minucioso y detallado para sus Call Centers, en general trabajando con asesores locales, en cada lugar donde se instala.
 Ello ha permitido al RBW operar usualmente bajo altos estándares de calidad y bajar considerablemente los niveles de
 rotación de estos empleados. En comparación con los estándares habituales de la industria de Call Centers en Chile –que
 tienen tasas de rotación anuales superiores al 80% en promedio– RBW en general busca una mayor estabilidad de estos
 empleados. En palabras de un importante ejecutivo del Banco: “para mantener una alta calidad en el servicio necesitamos
 una rotación de los R. de S. ojalá inferior al 30%, ya que toma tiempo lograr los altos estándares de calidad requeridos,
 así como también se demora el dominio experto que ellos deben tener de nuestros sistemas informáticos con los que
 atienden a nuestros clientes.”
 Respecto del proceso de selección para la contratación de los 200 Representantes en Chile, Michael Smith, el Gerente
 General del Banco para Chile, planteaba que para él es “evidente que el grupo de personas que se contrate será crucial
 para el éxito del servicio y por ello la inversión en recursos y tiempo en este proceso de selección es fundamental”. En
 otra reunión, Smith agregaba: “los empleados del Call Center tienen que mostrar un nivel de servicio muy alto desde la
 primera llamada recibida en Santiago; en el RBW no podemos esperar, nuestro Call Center debe lograr los altos
 estándares de servicio esperados de inmediato.”
 Para seleccionar y contratar a estos R. de S. el Banco ha delegado de manera importante la selección del personal en una
 consultora local, ya que el RBW no tenía experiencia en países emergentes similares a Chile y se necesita conocimiento
 local.
 La tarea para estos asesores, sin embargo no se veía fácil. Según un analista externo que seguía las actividades de
 instalación del RBW en Chile, los ambiciosos planes de este Banco requerían personal altamente calificado. Lo anterior
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 92

[pág. 93]
Dirección - versión clara y reordenada
 Dirección de Personas | marzo 2010 | pregunta 4
 Convocatoria 1 | página original 38 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 significaba contar con personas aptas para operar con herramientas tecnológicas sofisticadas, capaces de soportar
 importantes grados de presión frente a clientes exigentes que reclamarán un alto nivel de servicio, tal como lo prometía el
 RBW en su propuesta de valor al mercado.
 Luego de numerosas reuniones, el equipo interno de RBW, en conjunto con los consultores, adoptó los siguientes
 criterios respecto del proceso de selección de sus R. de S. para el Call Center:
 a) Se reclutará principalmente a personas muy jóvenes y altamente motivadas por la calidad del trabajo. Se deberá
 buscar empleados que sean “lo más parecidos en términos sociales y educacionales” a los futuros clientes del Banco,
 para que, en palabras de Smith, “entren inmediatamente ‘bien’ con los clientes, de modo que los escuchen y
 validen”. Por ello, las entrevistas a los candidatos serán muy amplias, sin una estructura predeterminada, para
 conocer de manera integral a los candidatos y, especialmente, su perfil socio-cultural.
 b) El foco deberá ponerse en pruebas psicológicas para poder detectar determinadas enfermedades psicológicas que
 sean incompatibles con el alto servicio que se pretende dar. Adicionalmente a la detección de esta “anormalidad
 psicológica”, la consultora deberá detectar si los candidatos pueden trabajar en un marco de “obediencia a las
 reglas”; este requisito es descrito como indispensable para poder funcionar de manera consistente y disciplinada con
 los sofisticados sistemas informáticos del Banco. Esta característica deberá ser medida también a través de tests
 escritos que permitan captar específicamente la capacidad de seguir normas y la disciplina de los candidatos.
 c) Otra característica que la consultora externa deberá evaluar en los candidatos es el manejo de los sistemas
 tecnológicos en que se basa el call center. En palabras de Smith: “sin duda uno de los aspectos fundamentales de
 este proceso, es que estas personas puedan aprender rápido los sistemas tecnológicos del Banco, ya que en mi
 opinión, una vez que estos funcionan eficientemente, ellos entregan de manera casi automática toda respuesta que el
 cliente pueda necesitar ‘o imaginar’”. No obstante, hay consenso en el equipo que dirige este proceso en que “estas
 características están naturalmente presentes en la gente joven que se quiere contratar, ya que ellos nacieron con la
 tecnología incorporada a su vida diaria y por lo tanto, es muy probable que se pueda detectar fácilmente a través de
 sus currículums”.
 Considerando los objetivos de negocio del RBW, a usted se le pide responder las siguientes preguntas:
 1. Señale las dos principales críticas que usted haría a los criterios definidos por el RBW para llevar adelante el
 proceso de selección de sus R. de S. Su respuesta entréguela considerando o analizando en su conjunto, los tres
 criterios de selección mencionados (a+b+c) y no uno a uno. Fundamente brevemente su respuesta.
 2. Proponga las dos mejoras concretas al proceso de selección de los R. de S. de RBW que usted considere más
 relevantes. Argumente de manera específica su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 93

[pág. 94]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2010 | pregunta 4
 Convocatoria 2 | página original 52 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 PREGUNTA Nº4
 RPC es una empresa dedicada a la fabricación y comercialización de puertas y closets para el hogar. Durante los últimos
 años la Compañía ha intentado implementar una estrategia de negocios orientada a ofrecer productos más innovadores, de
 mayor calidad y duración. La realidad, hasta ahora sin embargo, es que las puertas y closets de RPC son muy similares a
 los de su competencia. Además, por la naturaleza cíclica de la construcción, la dirección de la Compañía ha emprendido
 sus primeros esfuerzos para intentar diversificarse de manera relacionada a otros negocios y regiones, tratando de
 desarrollar nuevos productos.
 En una reciente reunión del equipo ejecutivo, el Gerente General mostraba las cifras de los últimos meses indicando que
 los resultados de la Compañía no marchaban de acuerdo a lo esperado. Más aún, indicaba, “nuestros esfuerzos por lograr
 un mayor grado de diferenciación en nuestros productos aspirando a cobrar precios más altos y nuestros objetivos de
 diversificación con nuevas líneas de producto, no se están materializando en la práctica.”
 A continuación el Gerente señaló a su equipo que la razón de fondo para estos malos resultados, era el clima
 organizacional de la empresa. “Podemos buscar causas inmediatas en la poca innovación, calidad y duración de nuestros
 productos, pero en definitiva nuestra gente no tiene la motivación para integrar sus esfuerzos y cooperar en el desarrollo
 de productos con características diferentes a los que actualmente ofrecemos al mercado”.
 Inmediatamente el Gerente de Recursos Humanos ( RRHH) comentó: “Estoy de acuerdo con lo planteado. A partir de la
 información entregada por la última encuesta de clima organizacional (ver gráfico), es que hemos tomado medidas.
 Evidentemente hay muchos aspectos a mejorar, porque como empresa recién le estamos dando importancia al nivel de
 satisfacción y compromiso de nuestros trabajadores”.
 Resultados Encuesta Clima Organizacional
 (1: totalmente insatisfactorio y 7 totalmente satisfactorio)
 7
 6
 Nivel de Satisfacción
 5
 4
 3
 2
 1
 0
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 94

[pág. 95]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2010 | pregunta 4
 Convocatoria 2 | página original 53 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 Luego de mostrar al resto de los Gerentes los resultados de la encuesta, el Gerente de RRHH explicó las tres iniciativas
 que estaba implementando su área para mejorar aquellas variables del clima organizacional “que tendrán un mayor
 impacto en el logro de los objetivos estratégicos planteados por la empresa.”
 Una primera línea de acción, señaló el Gerente de RRHH, es que queremos revertir los malos resultados en
 comunicación. La gerencia de RRHH ha establecido recientemente una línea directa con los empleados. Ahora, “somos el
 oído de la empresa” indicó orgullosamente el Gerente. De esta manera esperamos mejorar la comunicación al interior de
 RPC y saber dónde están los principales problemas para así poder resolverlos prontamente.
 Una segunda iniciativa está relacionada con la seguridad. Si bien los índices de del número y gravedad de los accidentes
 estaban en el promedio de la industria, el Gerente de RRHH consideraba que para lograr las metas de la empresa había
 que tener el liderazgo en materia de seguridad, de modo de lograr el reconocimiento de nuestros clientes. Así, se inició un
 programa para la reducción de accidentes mediante la creación de un comité de seguridad en el trabajo y la fijación de
 premios simbólicos y en efectivo para trabajadores en cuyas unidades no se hubieran producido accidentes durante tres
 meses consecutivos.
 En tercer lugar, el Gerente de RRHH ha introducido recientemente cambios al sistema de compensaciones. Con el
 objetivo de impulsar la preocupación por la calidad de los productos y mejorar la capacidad de innovar hacia nuevos
 productos y líneas de negocio, es que se aumentó en un 10% el sueldo fijo de todos los mandos medios (jefes y
 supervisores) y personal operativo de la empresa. Con ello, indicaba el Gerente de RRHH, se pretende motivar el logro de
 un mejor desempeño en la dirección que quiere la compañía.
 Como asesor externo a la empresa, a Ud. se le pide que responda lo siguiente:
 1. ¿Qué le parecen a usted las 3 medidas adoptadas por la gerencia de RRHH en función de su impacto en el
 mejoramiento del clima organizacional y a través de ello en el logro de la estrategia de la empresa? Responda a la
 pregunta considerando el efecto de las tres medidas en su conjunto (no analizando separadamente cada una de ellas)
 en términos de su impacto en el clima organizacional y a través de ello en el logro de la estrategia de la empresa.
 2. Considerando su respuesta a la pregunta anterior y en el escenario de que usted haya considerado adecuadas las
 medidas adoptadas, ¿qué otras medidas le sugeriría al Gerente de RRHH para lograr el mejoramiento del clima
 organizacional y con ello poder conseguir los objetivos estratégicos de RPC? Si, en cambio, usted consideró
 inadecuadas las acciones emprendidas, ¿cuáles serían a su juicio las medidas que debería tomar la gerencia de
 RRHH para mejorar el clima organizacional y a través de ello lograr implementar exitosamente la estrategia de
 RPC?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 95

[pág. 96]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2024 | pregunta 6
 Convocatoria 2 | página original 424 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 11
 PREGUNTA N%
 Costco y Sam”s Club son dos de las cadenas de supermercados de gran tamaño más exitosas financieramen
 te de las
 últimas décadas. Ellas compiten mano a mano en el mercado de Estados Unidos ofreciendo
 bajos precios a sus
 consumidores. Sam's Club cuenta con 551 tiendas, emplea a 110.200 personas y tiene un 40% del
 mercado en valor de
 ventas de tiendas de gran tamaño, mientras que Costco cuenta con 67.600 empleados, 338 salas de
 venta y un 50% de
 participación de mercado en valor de ventas en Estados Unidos.
 Aligual que en todo el mundo, los supermercados ya desde hace unos seis a siete años enfrentan crecientemente
 múltiples
 desafíos políticos, sociales, ambientales y laborales para su negocio. Las empresas supermercadistas deben
 hacerse cargo
 de reducir dramáticamente las emisiones de carbono que genera toda su cadena de actividades. Por otra
 parte, los
 consumidores están cada vez más activos en castigar a las marcas poco transparentes en la comercialización y
 marketing
 de sus productos y que no basan su negocio en valores positivos. En lo laboral, los gobiernos han estado impulsando
 la
 implementación de nuevas leyes y normativas laborales, a partir de mayores demandas por bienestar de los trabajadores.
 Entre estas nuevas medidas se encuentran la intensificación del teletrabajo y trabajo flexible, la no discriminación en la
 selección, promoción y despido de personal, la equidad de género, una mayor supervisión en materia de condiciones de
 trabajo seguras y saludables, la obligación de incrementar los niveles de información, capacitación y desarrollo en
 diversas materias a los empleados y sanciones más duras en contra del acoso laboral y sexual en el trabajo.
 Para poder comprar en Costco los clientes deben pagar una membresía anual de 100 dólares y así acceder a sus bajos
 precios. Esta tarifa, unida a la venta de sus productos genera ingresos significativos y un margen bruto de alrededor del
 30%. Costco vende una selección limitada de 3.800 productos, lo que le permite negociar mejores precios con un menor
 número de proveedores, usar el espacio de manera más eficiente y rotar su mercadería rápidamente, lo que significa
 menos capital inmovilizado en inventario y con ello puede trasladar esos ahorros a sus clientes miembros. Costco también
 ha expandido su marca propia, Kirkland Signature, que representa más de un 25% de sus ventas y cuyos márgenes brutos
 son más altos que en productos de marca comercial, ya que es considerada una de las marcas privadas de mayor prestigio
 del mercado.
 Por su parte, Sam”s Club compite con “precios bajos todos los días” de manera constante, sin depender de promociones
 temporales, atrayendo a una amplia base de clientes sensibles a precios. También exige una membresía por un valor de
 75 dólares al año para poder acceder a comprar en sus tiendas. Sam's Club ofrece una amplia gama de categorías y
 aproximadamente 7.000 artículos en sus tiendas. La empresa mantiene costos operativos bajos mediante una cadena de
 suministro altamente eficiente, la compra en grandes volúmenes, la búsqueda constante de eficiencia en todas las áreas
 de la empresa y la inversión de montos significativos en tecnología y procesos logísticos avanzados para optimizar sus
 operaciones. Como resultado de su modelo de gestión, Sam's Club tiene márgenes brutos de alrededor del 24%. Sam's
 Club también cuenta con marca propia, Member”s Mark, que representa cerca de un 17% de sus ventas cuyos productos
 son percibidos como de una calidad levemente superior a la de sus marcas comerciales.
 Costco ofrece un sueldo promedio a sus trabajadores de 17 dólares por hora el que es muy superior al de la industria. El
 82% de sus empleados cuenta con un seguro médico y el 91% recibe un plan de jubilación con una contribución anual
 por parte de la empresa de 1.331 dólares por empleado. Cuenta con un esquema de incentivos variables por desempeño
 que aumenta en función de los años de servicio y desarrollo de carrera y pueden alcanzar los 5.550 dólares anuales.
 También otorga un pago de 0,15 dólares por cada dólar que sus trabajadores invierten en acciones de la compañía. La
 empresa entrega amplia autonomía a los empleados para la toma de decisiones sobre el manejo diario de las tiendas
 (siempre alineadas con las políticas y objetivos de la empresa). También otorga un bono a la innovación y sugerencias
 para lograr mejoras operativas y de servicio al cliente. Costco cuenta con una política de promoción interna que ha
 significado que la mayoría de los líderes en Costco hayan sido promovidos desde dentro. También ofrece una variedad
 de programas de capacitación que ayuda a los nuevos empleados a fortalecer las herramientas para desarrollar su actual
 trabajo, a desarrollar habilidades de liderazgo a los empleados promovidos a roles de supervisión y a potenciar sus
 capacidades basadas en los objetivos de la empresa de corto y largo plazo, la amabilidad y proactividad del servicio a
 los clientes y los valores de la compañía.
 En cuanto a su gestión de personas Sam's Club paga un sueldo promedio por hora de casi 12 dólares, muy cercano al
 salario mínimo. Los empleados de Sam's Club pueden recibir bonos variables por desempeño anuales que varían en
 función del desempeño individual y del rendimiento de la tienda. Estas bonificaciones pueden alcanzar hasta 1.000
 dólares dependiendo de las ventas y otros indicadores de rendimiento. Por su parte, Sam's Club también le otorga un
 pago de 0,15 dólares por cada dólar que sus trabajadores invierten en acciones de la compañía. La empresa cuenta
 también con beneficios limitados para sus trabajadores, como un seguro médico que cubre al 45% de sus trabajadores y
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 96

[pág. 97]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2024 | pregunta 6
 Convocatoria 2 | página original 425 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 12
 un plan de jubilación de costo de la empresa que les aporta 747 dólares por empleado. La empresa utiliza una mezcla de
 promociones internas y un alto porcentaje de contrataciones externas para los diferentes cargos de la organización. La
 toma de decisiones tiende a estar más bien centralizada. Los empleados de las tiendas tienen ciertos espacios específicos
 para la definición de una porción de la oferta de productos de cada tienda que no requieren la aprobación de los niveles
 superiores. La capacitación de su personal se basa en un plan de inducción inicial breve en donde se enseñan las políticas
 y procedimientos básicos de la empresa. También cuentan con capacitación por períodos acotados de tiempo en el puesto
 de trabajo y programas de liderazgo en la Sam”s Club Academy para un número reducido de personas de la compañía.
 Preguntas:
 1. En un reciente seminario sobre gestión de personas en retail, un analista planteaba lo siguiente: “No comprendo cómo
 dos empresas que compiten en el mismo sector enfocadas en precios bajos como Sam”s Club y Costco pueden tener
 estrategias de gestión de personas tan diferentes”. ¿Cómo responde usted a la duda que tiene el analista? Indique los
 tres principales argumentos para explicar dichas diferencias.
 Existe un porcentaje mayoritario de empresas que, en distintas industrias, aplican un esquema de gestión de personas
 similar al adoptado por Sam”s Club. Por su parte, una minoría ha adoptado un modelo de gestión de personas similar
 al de Costco. Si ambas empresas han sido exitosas. Indique tres factores fundamentales que explican la mayor
 adopción del modelo de gestión de personas implementado por Sam”s Club con respecto a una minoría de compañías
 que optan por aplicar el esquema de gestión de personal de Costco.
 A continuación, se observa un gráfico con la evolución del precio de la acción de las dos empresas. El mercado valora
 más la gestión de personas implementada por Costco que la de Sam's Club. Asumiendo todo lo demás constante para
 ambas empresas y considerando las variables asociadas a la gestión de personas, se pide que indique qué puede
 explicar esta diferencia en la valorización de la acción entre empresas.
 400%
 2015 2016 2017 2018 2079 2020 2021 2022 2023 2024
 — Sam's Club — Costco
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 97

[pág. 98]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2025 | pregunta 3
 Convocatoria 2 | página original 443 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N“%3
 Andrés Tagle, gerente general del Grupo El Mercurio, hojeaba los
 informes de gestión más recientes con
 creciente inquietud. Aunque el Grupo seguía siendo uno de los conglomer
 ados de medios más influyentes de
 Chile, los dos negocios que lo sostenían —el diario impreso y el portal digital
 Emol.com— parecían vivir en
 mundos paralelos.
 Por una parte, El Mercurio, con una historia centenaría como diario impreso
 en papel, conservaba su rentabilidad
 gracias a contar con una base de suscriptores fieles, publicidad institucion
 al y productos editoriales y
 suplementos especializados. Pero su circulación bajaba año a año: 74.000 ejemplares
 diarios, menos de la mitad
 que una década atrás. Su audiencia era madura, exigente, influyente.
 Así mismo, Emol.com, fundado en 2001 era el portal informativo online propiedad del
 mismo Grupo El Mercurio
 y lideraba el consumo digital de noticias en el país, con más de 6 millones de usuarios
 únicos mensuales, y un
 crecimiento sostenido en redes sociales, contenido audiovisual y posicionamiento SEOS. Sin embargo, su
 rentabilidad era volátil y su fidelización, baja. Su audiencia era joven, fragmentada y
 móvil.
 Andrés Tagle sabía que ambos negocios tenían futuro, pero intuía que la forma
 en que estaban organizados y
 gestionados no era sostenible. “Son dos empresas dentro de una empresa. ¿Pero
 tienen que funcionar así?”, se
 preguntaba.
 Dos formas de entender el periodismo (y de gestionar personas)
 En el diario impreso, Pedro Hurtado, editor general desde 2011, dirigía
 una operación editorial tradicional,
 Jerárquica y especializada en el periodismo escrito. El foco estaba en la calidad
 del contenido, la profundidad, la
 responsabilidad pública y el criterio editorial. Por su parte los incentivos
 variables existentes premiaban esos
 mismos atributos aunque eran muy bajos en cuanto a los montos que se otorgaban.
 El equipo estaba compuesto
 por periodistas con larga trayectoria, muchos con más de 20 años en la
 empresa. Las evaluaciones eran
 cualitativas, las decisiones centralizadas.
 — Aquí no se improvisa. Esto no es hacer noticias ni videos virales.
 Hacemos periodismo serio, que exige
 tiempo, criterio y rigor”, solía decir Pedro Hurtado.
 Mientras tanto, Catalina Ríos, directora de Emol, lideraba un equipo joven, mixto,
 con perfiles que iban desde
 periodistas hasta data analysts, diseñadores UX y community managers”.
 Trabajaban en equipos ágiles, con alta
 autonomía, con tableros de control que contenían indicadores de tráfico
 y lectoría en tiempo real, pruebas A/B7
 para determinar que contenidos obtenían mejor rendimiento entre los lectores,
 y decisiones tomadas en minutos.
 Sus incentivos estaban ligados a incremento del tráfico al sitio web,
 aumento d ellos tiempos de permanenciaen
 el sitio de los lectores digitales y fidelización de esos mismos lectores.
 Los liderazgos eran horizontales y
 colaborativos.
 ——S1 una nota no funciona en los primeros 30 minutos, la matamos. Esa
 es nuestra realidad. La velocidad es
 parte del rigor”, decía Catalina.
 Tensión organizacional: “No somos enemigos, pero no somos
 socios”
 Los dos equipos compartían edificio, pero no compartían rutinas, ni herramient
 as, ni estructuras de gestión. Los
 intentos de colaboración editorial conjunta habían sido esporádicos
 y, muchas veces, incómodos. Las áreas
 comerciales también trabajaban por separado.
 * El posicionamiento SEO (por sus siglas en inglés: Search Engine Optimizatio
 n, u Optimización para Motores de Búsqueda) es el
 conjunto de estrategias y técnicas que se aplican a un sitio web o contenido
 digital para mejorar su visibilidad en los resultados orgánicos
 (no pagados) de Google.
 5 Un diseñador UX (experiencia de usuario) se enfoca en crear productos
 y servicios digitales que sean fáciles de usar, eficientes y
 agradables para el usuario. Su objetivo principal es comprender las
 necesidades y deseos del usuario para diseñar experiencias que sean
 intuitivas y satisfactorias. Por su parte, un community manager
 es un profesional encargado de construir, gestionar y administrar
 comunidad online de una marca o empresa, fomentando interaccione a
 s positivas y relaciones duraderas con clientes y seguidores
 7 Las pruebas A/B en medios digitales son una técnica para comparar
 dos versiones de un elemento, como una página web o un correo
 electrónico, para determinar cuál funciona mejor en función de
 los objetivos de marketing
 6
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 98

[pág. 99]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2025 | pregunta 3
 Convocatoria 2 | página original 444 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 El área de Personas había detectado barreras culturales y de lenguaje.
 Los perfiles que contrataba Emol rara vez
 eran considerados para movilidad interna dentro del Grupo.
 Las evaluaciones de desempeño no eran
 comparables. Y las estructuras de compensación tampoco eran similares.
 En uno de los reportes preparados por el área de Desarrollo Organizac
 ional se incluía una observaci
 ón que había
 pasado desapercibida en reuniones anteriores:
 — En el actual entorno de desinformación y Jragmentación, los medios—i
 ndependientemente de su soporte—
 enfrentan el reto de sostener su legitimidad pública. Aspectos como la claridad
 editorial, la confianza del lector,
 el conocimiento del contexto nacional e internacional y la calidad
 narrativa se han vuelto claves para marcar
 diferencia en la credibilidad de una marca periodística. ”
 Tanto en El Mercurio como en Emol, estos principios aparecían recogidos
 en sus respectivas declaraciones de
 propósito y se mencionaban con frecuencia en discursos internos, aunque
 no estaba claro cómo influían en las
 prácticas cotidianas ni si eran gestionados de forma coordinada entre ambas
 unidades.
 Debate en el directorio
 Durante una reunión extraordinaria del directorio, surgieron dos
 posturas marcadas:
 Carlos Rivas, ejecutivo de Emol con amplia experiencia en medios digitales,
 fue directo:
 — Tenemos que separar los negocios. Son modelos distintos. Requieren estructura
 s distintas, personas distintas,
 culturas distintas. La integración solo los frena. Cada negocio requiere
 de espacio propio para crecer y ser
 rentable.”
 Patricia Moya, periodista histórica del diario, respondió con igual convicció
 n:
 ——Separarlos es destruir la marca. La experiencia del papel es
 el corazón de este medio. Emol tiene que
 integrarse más a esa herencia. Las políticas y prácticas de gestión
 de personas de nuestro diario en papel son
 perfectamente aplicables al negocio online. Solo así tendrá consistencia
 y solidez como marca.”
 El debate se estancó. Ninguna de las dos propuestas convencía del
 todo.
 Preguntas:
 1. Como consultor externo usted ha sido convocado por Grupo El Mercurio
 y sus empresas para ayudar a
 entregar mayor claridad frente a la diferencia de opinión entre Carlos
 Rivas y Patricia Moya, dos personas
 con amplia experiencia en la industria de medios de comunicación.
 En concreto se le pide que, desde el
 punto de vista de la gestión estratégica de personas apuntando a lograr
 los objetivos de Grupo El Mercurio
 y sus negocios, entregue su opinión respecto a las afirmaciones
 de ambos ejecutivos. Fundamente su
 respuesta de manera precisa.
 2. Luego de esta acalorada discusión sostenida en la reunión extraordi
 naria de directorio intervino entonces
 Teresa Larenas, directora con experiencia en estrategia y talento,
 señalando: “Entiendo las diferencias de
 opinión entre Carlos Rivas y Patricia Moya, pero tenemos que tomar decisione
 s para lograr el desarrollo y
 rentabilidad del Grupo El Mercurio y sus dos negocios. A usted
 se le pide que describa y detalle con
 precisión dos políticas de gestión de personas que sean clave para
 el logro de los objetivos del Grupo El
 Mercurio y sus dos negocios. '
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 99

[pág. 100]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2026 | pregunta 4
 Convocatoria 1 | página original 458 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N%4
 Ganga es una de las empresas de retail con mayor trayectoria en Chile. Su modelo de negocios se ha construido sobre
 una amplia cobertura territorial, una oferta diversa de productos y la capacidad de operar a gran escala de manera
 coordinada y confiable a través de todas sus salas de venta. Además, históricamente, la compañía había puesto especial
 énfasis en la gestión de su personal ya que su permanencia y compromiso con la empresa eran clave para lograr la
 diferenciación que se buscaba.
 En los últimos años, el entorno competitivo del retail se ha vuelto más exigente: mayor penetración del comercio
 electrónico, presión por costos, consumidores más informados y un contexto legal y de relaciones laborales con mayor
 conflictividad. En este escenario, Ganga ha optado por un posicionamiento que no descansa exclusivamente ni en el
 bajo precio ni en la digitalización pura, sino en sostener una experiencia de compra predecible, tanto en tiendas físicas
 como en canales digitales, para un segmento amplio de clientes.
 Esta propuesta de valor supone una promesa clara: independientemente de la tienda, el formato o el momento, el cliente
 debería encontrar disponibilidad de productos, atención oportuna y estándares similares de servicio. La ventaja
 competitiva no proviene, por tanto, de innovaciones extraordinarias, sino de la capacidad de establecer metas claras y
 ejecutar procesos operacionales cotidianos de forma disciplinada, estandarizada y simultánea a lo largo de todo el país
 para el logro de dichos objetivos. En este sentido, la sostenibilidad del negocio se encuentra estrechamente vinculada a
 las personas y a la forma en que la organización gestiona su desempeño y la forma en que el personal, y particularmente
 las jefaturas a cargo de los diferentes equipos en las tiendas, toman decisiones.
 Este enfoque ha permitido a la empresa ejecutar campañas comunicacionales complejas de manera simultánea, reducir
 quiebres de stock y mantener niveles aceptables de servicio en contextos de operación normal. Como señalaba un
 ejecutivo senior: “cuando el sistema funciona como está diseñado, los resultados llegan”.
 El rol clave de las jefaturas en situaciones bajo presión
 En papel de las jefaturas de las tiendas en Ganga es clave para el cumplimiento de objetivos operacionales, comerciales
 y laborales. En períodos estables estas metas habitualmente se cumplen. Sin embargo, es en los períodos de alta presión
 (lanzamiento de nuevas colecciones o liquidaciones que requieren precisión en la ejecución, eventos promocionales a
 nivel nacional o acciones comerciales en respuesta a tácticas agresivas de los competidores), cuando las competencias
 de las jefaturas y sus equipos se ponen a prueba.
 En estos escenarios de mayor complejidad, particularmente en los últimos años en donde las exigencias al negocio del
 retail se han vuelto más demandantes, es que, crecientemente los jefes han ido imponiendo un alto nivel de presión
 sobre sus equipos. Si bien Ganga ha establecido políficas generales respecto al cumplimiento de todas las leyes y
 normativas laborales existentes en materia de trato, respeto a las jornadas de trabajo, calidad de vida y salud mental, los
 jefes tienden en muchas ocasiones a poner un alto nivel de presión, exigencia e incluso un trato agresivo con el objeto
 de cumplir las metas asignadas.
 Si bien en algunas tiendas, líderes con mayor experiencia logran combinar el cumplimiento de metas con un manejo
 cuidadoso de situaciones laborales complejas, durante estos períodos de mayor estrés comercial un número importante
 de jefaturas tienden a orientar sus decisiones fundamentalmente en función del sistema de evaluación del desempeño y
 el esquema de incentivos variables que tiene Ganga. Estos se centran básicamente en si las metas comerciales se están
 alcanzando y en las mejoras que requieren implementarse para que el equipo alcance sus objetivos, dejando de lado la
 gestión de las relaciones laborales.
 Consecuencias legales
 En 2021, el Segundo Juzgado de Letras del Trabajo de Santiago acogió una demanda por prácticas antisindicales,
 cuestionando decisiones de ciertas jefaturas de Ganga que afectaron el ejercicio de la actividad sindical. Estas medidas
 apuntaban a evitar negociaciones con las organizaciones sindicales y lograr reducir costos laborales. Además, apuntando
 a las metas operacionales exigidas, varias jefaturas han ido tomando decisiones arbitrarias en materia de beneficios
 $
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 100

[pág. 101]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2026 | pregunta 4
 Convocatoria 1 | página original 459 | Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 laborales (becas, seguros de salud y pago de horas extra) favoreciendo a algunos trabajadores que las jefaturas
 denominaban como “más comprometidos con la empresa” y eliminando estos beneficios para quienes les parecían
 menos “colaboradores”. Por otra parte, un número relevante de jefaturas han estado despidiendo trabajadores sin una
 causal justificada en su afán por mejorar los resultados operacionales de sus tiendas.
 La tabla que se muestra a continuación describe los principales fallos que han afectado negativamente a Ganga en los
 últimos años, derivados de las decisiones de determinadas jefaturas en la empresa.
 Fallos laborales relevantes
 Año Materia Instancia Resultado
 2021 ¡[Prácticas antisindicales Juzgado del Trabajo Demanda acogida
 2023 ¡¡Discriminación laboral Corte Suprema Sentencia confirmada
 2025 |[Despido injustificado Corte Suprema Indemnización = $50 millones
 Efectos acumulados y dilemas abiertos
 Tras cada uno de estos fallos, la organización adoptó medidas correctivas puntuales, principalmente orientadas a reforzar
 procedimientos y controles específicos. Sin embargo, las jefaturas no contaban con instancias sistemáticas para revisar
 internamente las decisiones tomadas, analizar alternativas posibles o extraer aprendizajes individuales y compartidos a
 nivel organizacional. Como resultado, varias jefaturas perciben que deben actuar con rapidez y firmeza, pero sin tener
 plena claridad respecto de dónde están los límites aceptables en situaciones complejas. Adicionalmente, algunos jefes
 reconocen que, frente al riesgo de equivocarse, optan por escalar decisiones hacia niveles superiores o aplicar las reglas
 de manera estrictamente formal, aun cuando intuyen que el contexto requeriría un análisis más fino.
 Más allá de las consecuencias legales, comienzan a observarse otros efectos también persistentes: malestar laboral,
 desconfianza en las jefaturas, mayor cautela de los jefes en la toma de decistones y aumento del escalamiento jerárquico
 ante situaciones de negocio bajo presión. Al mismo tiempo, los indicadores operativos del negocio continúan mostrando
 niveles aceptables de cumplimiento.
 Se pide responder:
 1. En lareciente reunión del comité ejecutivo de Ganga uno de los ejecutivos presente preguntaba: “El análisis de
 los resultados financieros junto a lo que se observa en materia laboral me tienen confundido. Entiendo que hay
 máúltiples variables que inciden en nuestros resultados, pero ¿quién me puede describir cuáles son las tres
 competencias clave que requieren las jefaturas para lograr el desarrollo de nuestra estrategia de negocios de
 manera sostenible? Además, ¿alguien me puede explicar cómo cada una de esas competencias favorecen el logro
 de dicha estrategia?” A usted se le pide que una respuesta a las dos preguntas que el gerente está haciendo para
 aclarar sus dudas.
 2. Durante esa misma reunión, el Gerente de Operaciones de Tiendas señalaba: “Nuestro sistema de evaluación del
 desempeño e incentivos variables por resultados premia el cumplimiento riguroso de metas y procedimientos. Eso
 debería ser condición suficiente para que las jefaturas tomen las decisiones adecuadas alineadas con nuestra
 estrategia, incluso en situaciones complejas. Basta observar nuestros resultados operacionales para comprobar
 lo que digo.” Por su parte, la Gerenta de Sostenibilidad, no estaba del todo de acuerdo con las afirmaciones de su
 colega y señaló que “hay varias medidas clave que deben incorporarse en el sistema de evaluación del desempeño
 e incentivos variables” para lograr los objetivos de negocio de nuestra empresa de manera sostenible. En su calidad
 de experto se le pide que indique tres medidas que pueden complementar al sistema de evaluación de desempeño
 e incentivos variables existente y permitan el logro de los objetivos de negocio de Ganga de manera sostenible.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 101

[pág. 102]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2025 | pregunta 2
 Convocatoria 1 | página original 429 | Evaluación de desempeño e incentivos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N2
 Desde hace 6 años, Lucrecia Guita lidera la Gerencia de Planificación y Control de Gestión
 (GPyCG), en
 Banco Morlacci, uno de los actores más grandes en el sector bancario del país, el
 cual otorga servicios
 financieros a personas, enfocándose en la entrega de préstamos, instrumentos de inversión
 y ahorro, cuentas
 corrientes y tarjetas de crédito y débito. Morlacci aspira a ser el principal banco de personas en Chile
 y desde
 hace un año busca crecer rápidamente en sus colocaciones intentando diferenciarse
 por su capacidad de
 respuesta al cliente, el más ágil en sus transacciones, el mejor percibido en cuanto al desarrollo
 de tecnología
 y por un trabajo en equipo transversal para atender las necesidades integrales de sus clientes.
 Banco Morlacci
 lanzó un plan de transformación organizacional con el objetivo que todas las áreas de la institución
 operaran
 bajo estos principios y los hicieran parte de su cultura de trabajo y de sus actividades diarias.
 En palabras del gerente general del banco, Gustavo Dolareke, “la diferenciación en
 estos atributos nos
 permitirá lograr una rentabilidad superior a las de nuestros competidores. Además,
 señalaba el gerente,
 “lograremos distinguimnos frente a nuestra competencia no solo si entregamos un buen servicio
 a nuestros
 clientes finales, ágil y tecnológicamente amigable. Necesitamos además aplicar estos mismos
 a las relaciones
 y servicio interno entre las áreas del banco que conforman nuestra cadena de valor. La percepción
 de nuestros
 clientes respecto a nuestro banco solo será el reflejo de nuestra gestión al interior de banco
 Morlacci.”
 La GPyCdG que lidera Guita atiende a 12 gerencias funcionales del banco a las que denomina
 stakeholders o
 clientes internos (comercial, finanzas, operaciones, productos bancarios, marketing, medios de pago,
 experiencia de clientes, mesa de dinero, business intelligence, gestión de personas, tecnología
 y fiscalía). A
 partir de la información que cada gerencia del banco les proporciona, PyCDdG elabora
 y luego envía los
 presupuestos finales aprobados por la Gerencia General, así como los informes mensuales
 y anuales de
 cumplimiento de dichos presupuestos. También PyCdG se encarga de entregar los análisis de
 las desviaciones
 de más de 10 indicadores de gestión por cada gerencia en diversos ámbitos (productividad,
 ahorro de costos,
 calidad de servicio interna, gestión de procesos de cada área, clima laboral en cada uno de los equipos
 y nivel
 de capacidades del personal que cada uno de sus stakeholders debe cumplir). Finalmente,
 PyCdG elabora
 propuestas de mejora para cada una de las brechas detectadas tanto en el cumplimiento del presupuesto
 como
 en los indicadores de gestión del negocio que cada una de las gerencias funcionales de Banco Morlacci
 tienen
 asignados. Como señalaba Guita en una reunión con el equipo de su Gerencia, “en Banco
 Morlacci cada
 gerencia cree que es la más importante y por ello exigen que les demos prioridad en la atención.
 Esta enorme
 carga y complejidad de trabajo, superior a la que se observaba en áreas similares en bancos de
 la competencia,
 solo era posible de alcanzar con equipos enfocados en objetivos comunes y compartidos, alta motivación,
 coordinación-y trabajo colaborativo.”
 Debido al gran número y diversidad de “stakeholders” con los que se relaciona y a los cerca de 120
 indicadores
 que debe anditar, revisar y generar las correspondientes recomendaciones de mejora mensualmente
 , PyCdG
 cuenta desde hace años con un sistema FIFO (First In — First Out) para priorizar los requerimient
 os que llegan
 desde los stakeholders a la Gerencia, de modo que la gerencia presta el servicio “por orden de llegada.”
 Desde su entrada al Banco, Raúl y todo su equipo en la GPyCdG reciben una compensación que
 consta de una
 parte fija y otra variable. Ambos componentes de la compensación se pagan, en promedio, en la
 media de
 mercado. La compensación variable conocida como Bono por Resultados está sujeta a una evaluación
 anual y
 considera tres elementos: (1) un ítem asociado al logro del Ebitda del banco (10% del bono),
 (2) la tasa de
 crecimiento de las colocaciones del banco (10% del bono) y (3) un conjunto de KPIs individuales
 asociados a
 la calidad de servicio de cada empleado de la GPyCdG en relación con la gerencia que les correspondía
 atender
 (80% del bono).
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 102

[pág. 103]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2025 | pregunta 2
 Convocatoria 1 | página original 430 | Evaluación de desempeño e incentivos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Los KPIs y la evaluación anual de metas individual (80% del bono) estaban estructurados según el siguiente
 esquema:
 Peso
 KPIs Kel Deficiente Regular Satisfactorio Bueno Excelente
 Tiempo de entrega de presupuestos / control
 32% | mayora 90 días |entre 90 y 46 días | entre 45 y 30 días| menora 30 días | menora 15 días
 presupuestario /análisis de brechas a las gerencias
 Número de errores contenidos en los informes más de 40 | entre40y 330 entre29 y 11 entre 10 y 5 menos de 5
 enviados a las gerencias 32%
 errores errores errores errores errores
 Número de recomendaciones realizadas para el cierre
 de brechas menos de 5 entre 6 y 10 entre 11 y 15 entre 16 y 25 más de 26
 tanto en el cumplimiento del presupuesto 36%
 recomendaciones | recomendaciones | recomendaciones | recomendaciones ! recomendaciones
 como en los indicadores de gestión del negocio
 f
 La definición de estos indicadores las realiza la jefatufa directa de cada persona dentro de la GPyCdG. A su
 vez, la evaluación del cumplimiento de estos KPIs está a cargo del empleado que hace de contraparte en la
 gerencia a la que el personal de la GPyCdG presta el servicio. En otras palabras, su cliente directo es su
 evaluador. Guita estaba muy conforme con su sistema de evaluación del desempeño y con el Bono por
 Resultados.
 Preguntas:
 1. Por tratarse de un área estratégica, el directorio del banco está revisando el sistema de evaluación del
 desempeño de la Gerencia de PyCdG. Para ello citó al gerente general Enrique Dolareque y al Gerente
 del área en cuestión, Lucrecia Guita. Ésta última comentó: “nuestro esquema de KPIs cuenta con los
 más altos estándares SMART!. Si bien no todos los años todos obtienen el mínimo aceptable en la
 porción individual de su bono, cada uno tiene muy claro qué indicador no cumplió y cómo corregir su
 desempeño en el siguiente período.” Inmediatamente el gerente general respondió: “Puede ser que tu
 personal de la Gerencia de PyCdG esté cómoda con el esquema de evaluación de desempeño, pero yo
 pienso que no agrega suficiente valor a nuestro negocio.” Desde el punto de vista de la gestión
 estratégica de personas ¿Son correctos los argumentos entregados por cada uno de los ejecutivos?
 Justifique su respuesta.
 La discusión no terminó ahí y Dolareque volvió a la carga. Con convicción afirmó: “También veo
 problemas en el Bono por Desempeño de la GPyCdG. No genera la motivación en las personas del
 área. De hecho, los datos muestran un aumento en la rotación del personal de dicha gerencia, y no veo
 cómo contribuye al éxito del banco.” Ofuscada, la gerente de la GPyCdG retrucó: “puede que estemos
 perdiendo algunas personas, incluso algunas personas clave, pero eso no significa que el sistema de
 compensación variable no funcione. La gran mayoría de mi equipo está satisfecho con su Bono de
 Resultados.”
 Nuevamente el directorio le pide que desde la perspectiva de la gestión estratégica de personas indique
 si son correctos los argumentos entregados por cada uno de los ejecutivos. Justifique su respuesta.
 1 SMART es un acrónimo para medir ciertas características de los KPIs: específicos/ specific. mesurable/ medibles, alcanzables/
 achievable, realistas/ realistic y de duración limitada/ time-bound.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 103

[pág. 104]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2015 | pregunta 2
 Convocatoria 2 | página original 175 | Formalización y productividad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 2
 Mientras las frías ráfagas de viento azotaban la ciudad, en la sala de reuniones del piso 10 de la torre de
 oficinas “Los Campeones”, la temperatura iba en aumento. El equipo ejecutivo de los supermercados
 Suceso, se encontraba analizando los resultados de la empresa. Suceso estaba entre las cuatro cadenas de
 supermercados más grandes del país. La empresa había invertido muchos recursos en tecnología para hacer
 más eficientes sus procesos operacionales y de ventas en sus salas, en línea con las mejores cadenas del
 mundo. La productividad de sus empleados, sin embargo, era baja, lo que contrastaba con el deseo de la
 empresa de ser líder en productividad de su industria.
 Ricardo Parada, miembro del equipo ejecutivo que estaba reunido, señalaba: “Si queremos ser los mejores en
 la industria, debemos compararnos con los estándares que tienen las cadenas de supermercados en Estados
 Unidos.” Parada, sabía que si no se lograba incrementar la productividad (margen de operación de cada
 tienda/n* de trabajadores), difícilmente la empresa podría convertirse en líder en su propio país y menos
 expandirse a América Latina. Dentro del país todas las cadenas de supermercados mostraban, en promedio,
 niveles similares de productividad. Por lo tanto, afirmaba Parada: “la única manera de ser competitivos en el
 tiempo, es lograr una administración de nuestro negocio, particularmente en lo referido a la gestión de
 personal, que se constituya como nuestra fuente de ventaja competitiva. Por ahora estamos lejos de ser
 competidores de clase mundial.”
 Y en una clara señal de molestia agregó Parada: “miren este análisis de nuestro Departamento de Estudios
 (ver gráfico a continuación)”:
 Brecha de Productividad (Margen operacional de cada sala de supermercado/
 N* de trabajadores) en las cadenas de supermercados 2010-2014
 Productividad Informatidad Bajo uso de las apacidad para Menor Canasta
 enun en la gestión tecnologías lograr que las capacidad de promedio que — enuna sala de
 supermercado — de diversos para nuevas salas Suceso para compra el supermercado
 promedio de procesos operaciones y operena plena — adaptaral consumidor de — líder en
 Suseso (compras, ventas capacidad personal menor valor Estados Unidos
 operaciones, disponiblesen — (madurez) en fr_ente a que en Estados
 servicio al las salas en un menor diferencias en Unidos
 cliente, RR.HH. tiempo la afluencia de — (precios y
 y público productos)
 administración
 general)
 “Los datos muestran que tenemos una productividad equivalente al 35% de la productividad de los
 supermercados líderes en Estados Unidos; o dicho de otra manera, somos un 65% menos eficientes que los
 líderes de la industria. El estudio cuantifica el aumento potencial en productividad que podría producirse en
 cinco áreas si se introdujeran prácticas modernas de gestión, particularmente en cuanto a la dirección de
 personal, que hoy no tenemos. Por ejemplo, si Suceso lograra formalizar la gestión de diversos procesos
 (compras, operaciones, servicio al cliente, etc.) lograría aumentar su productividad en 4% y así acercarse a la
 productividad que consiguen las cadenas de supermercados norteamericanas. ¿Cómo pretendemos escalar
 nuestras operaciones a otros países si nos falta tanto aún por mejorar nuestra gestión del personal?”,
 concluyó Parada.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 104

[pág. 105]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2015 | pregunta 2
 Convocatoria 2 | página original 176 | Formalización y productividad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 A continuación fue el turno del gerente de operaciones, Mario Bermúdez, quién manifesto: “yo creo que el
 problema es que en esta empresa se trabaja poco. Sin infringir la ley, es claro que podemos aumentar el
 número de horas que se trabaja en nuestros supermercados. La gerencia de recursos humanos (RR.HH.)
 recientemente me entregó los datos comparativos del promedio de horas trabajadas en los supermercados
 chilenos (Suceso está en el promedio), comparadas con los supermercados en otros países de la OECD
 (economías más desarrolladas). El gráfico siguiente nos muestra que aún hay espacio para aumentar la
 productividad de nuestros supermercados, incrementando el número de horas trabajadas, lo que aumentaría a
 su vez las ventas de cada sala y con ello la productividad.”
 Horas de trabajo por empleado al año en supermercados en diferentes países de la
 Organización para la Cooperación y el Desarrollo Económicos (OCDE) (*)
 México 2.228
 Costa Rica E 2.216
 Grecia
 Chile
 Estados Unidos o
 Promedio OCDE
 Nueva Zelandia
 Alemania
 (*) Promedio de los años 2010-2014
 PREGUNTAS
 Como asesor del equipo ejecutivo, usted se encuentra esta mañana en la reunión y se le pide su opinión
 respecto a dos asuntos que pueden aportar en la solución al problema de Suceso:
 1. ¿Está usted de acuerdo con los argumentos entregados tanto por Parada (instalar prácticas de gestión de
 personas que incrementen la productividad) como de Bermúdez (aumentar las horas trabajadas en los
 supermercados) para elevar la productividad de Suceso? Justifique en forma precisa su respuesta.
 2. Considerando la información entregada, describa las dos prácticas o decisiones propias de la gestión
 estratégica de RR.HH, que permitirían incrementar de manera más significativa la productividad de
 Suceso (Margen operacional en cada sala de supermercado / N* de trabajadores). En su respuesta explique
 cómo dichas prácticas impactarían de manera relevante en el incremento en productividad de Suceso.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 105

[pág. 106]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2012 | pregunta 2
 Convocatoria 2 | página original 105 | Gestión por competencias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº 2
 Gino Alberdi creó hace 8 años la agencia de publicidad Cáspita, de la cual es socio y gerente general. Hasta ahora, los
 resultados de la empresa han sido muy buenos, sobretodo en lo relacionado con la creatividad de las campañas publicitarias,
 lo que le había permitido obtener premios relevantes incluso a nivel internacional. Dentro del rubro, ha ganado prestigio y
 fama, fundamentalmente debido al personal que trabaja en la agencia.
 Cáspita ha logrado una participación relevante en el mercado nacional de la publicidad y cuenta con 112 empleados, la
 mayoría de ellos publicistas y diseñadores titulados en las mejores escuelas. Debido al tamaño que ha adquirido su empresa,
 Alberdi decidió crear hace 3 años un Departamento de Personal al que se le encargó administrar de manera eficiente las
 compensaciones y los beneficios de los empleados. Más recientemente, hace 6 meses, Alberdi dio un nuevo paso al instalar
 - dependiendo directamente del Jefe del Departamento de Personal – un Área de Desarrollo Organizacional a cargo de la
 gestión del desempeño individual y de la capacitación de las personas que trabajan en Cáspita.
 Alberdi sabía que parte del prestigio ganado se relaciona con el éxito de campañas que han sido percibidas como
 particularmente creativas e ingeniosas. Sin embargo, en gran parte inspirado por el MBA que está cursando, este gerente ha
 considerado una sofisticación de su estrategia. La idea que se impuso hace aproximadamente 1 año fue la de generar un
 negocio nuevo. De esta forma, Alberdi abrió una unidad de consultoría a pequeñas y medianas empresas (PYMES) en temas
 de construcción de imagen corporativa y de apoyo en el desarrollo de propuestas de valor a sus clientes. Alberdi había
 decidido crear esta nueva unidad de negocios dentro de Cáspita, ya que pese al éxito que él sentía que había logrado,
 también observaba que el mercado de la publicidad se había vuelto cada vez más competitivo y defender la participación de
 mercado se hacía crecientemente más complejo. Alberdi creía que este negocio de consultoría era tremendamente
 promisorio. Según él, “Las PYMES son muchas, en general no saben cómo mostrarse al mundo externo y, ‘no tienen idea’
 de cómo fortalecer sus ventajas competitivas. Ellas sí necesitan entender cómo comunicar sus mensajes a los públicos
 relevantes; también necesitan de fortalecimiento de marca (branding). En muchos de estos temas en Cáspita somos
 expertos”.
 Al momento de hacer pública la entrada de Cáspita al negocio de consultoría hace un año, Alberdi reunió a los jefes de
 proyectos y a los equipos profesionales en un evento especial en un hotel de Santiago y, junto con explayarse respecto de la
 estrategia en general, se refirió al nuevo negocio de consultoría. En dicha reunión, Alberdi abordó los principales desafíos
 que planteaba el nuevo negocio y señaló enfáticamente que él tenía plena confianza en que se podían superar. Por supuesto,
 Alberdi también se refirió a algunas características de los cambios asociados que surgían con la apertura de una nueva área
 de negocios, los cuáles se pueden resumir en los siguientes puntos:
 a) Se contrataría un gerente de consultoría, quien previamente realizaba un trabajo similar para otra consultora, con buenos
 resultados. Algunas de sus virtudes más destacadas eran su capacidad para construir equipos y su buen vínculo con los
 clientes.
 b) Alberdi señaló que si bien antes de crear la unidad de consultoría en Cáspita solo se había resaltado la “Creatividad e
 Innovación” como una competencia central (o core competence), ahora se debía agregar la competencia “Análisis y
 Resolución de Problemas” debido al tipo de consultoría que efectuarían. Según Alberdi, ahora se trataba no solo de
 potenciar ideas sino que también de “resolver problemas que permitieran potenciar las ventajas competitivas de cada
 PYME”. Junto con la forma en que él veía esta nueva competencia, Alberdi dio un discurso motivacional instando a
 aplicarla eficazmente en cada instancia en que el cliente pudiera interactuar con un miembro de Cáspita.
 c) Sabiendo que el lanzamiento de este nuevo negocio constituiría un desafío organizacional, Alberdi comunicó su intención
 de constituir equipos de consultoría basados en personas que hubiesen tenido un gran desempeño anterior en Cáspita. Al
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 106

[pág. 107]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2012 | pregunta 2
 Convocatoria 2 | página original 106 | Gestión por competencias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 mencionar esto, citó una frase que aprendió en un curso de competencias en su MBA: “el mejor predictor del desempeño
 futuro es el desempeño pasado”. Por esta razón, Alberdi conformó un comité de jefes de proyecto para seleccionar a
 publicistas de la compañía que se hubieran destacado en diversas campañas exitosas. Como un foco central, se cuidó la
 percepción de justicia del proceso y se aseguró que quienes quedaran seleccionados fueran realmente los de mejor
 desempeño anterior. Explícitamente, para Alberdi el pasar a ser miembro de consultoría era una forma de promoción; los
 sueldos en promedio, para quienes trabajaran en consultoría serían más altos. Adicionalmente, y dado que las personas
 seleccionadas estarían haciendo consultoría, Alberdi recomendó al comité de gerentes seleccionar a quienes parecían
 mostrar altos niveles de asertividad y facilidad para establecer relaciones interpersonales con clientes.
 d) La reacción general de los jefes de proyecto y de los consultores fue positiva. De hecho, para muchos profesionales
 (publicistas y diseñadores), la presentación de Alberdi resultó motivadora e incluso varios comenzaron a preguntar si se
 podía postular a estos cargos. La respuesta fue que no, sino que más bien se haría una selección muy cuidadosa y justa,
 basada en el desempeño anterior.
 Habiendo ya transcurrido poco más de 1 año desde la creación del negocio de consultoría en Cáspita, existe consenso entre
 diferentes miembros de la organización que esta unidad está enfrentando problemas relevantes. Tras una breve indagación
 realizada, se llegó a los siguientes análisis que se presentan a continuación en forma resumida a través de la opinión de 3
 personas de Cáspita:
 (i) Gerente General. “Creo que comenzar este negocio fue una buena idea, aún cuando no hemos obtenido ni las ventas ni
 los clientes que esperábamos. Pero, me preocupa especialmente los reclamos que recibo de los clientes. Ellos me dicen con
 frecuencia que las recomendaciones de nuestros consultores son originales, pero usualmente son también poco prácticas o
 difíciles de implementar; que nuestros consultores no son buenos para escuchar la necesidad del cliente; que algunas de sus
 ideas sobre la propuesta de valor de la PYME son mucho más complejas que lo que la empresa realmente puede ejecutar,
 etc.”
 (ii) Gerente de Consultoría. “Aunque sé que el negocio ha crecido de a poco, tengo preocupaciones relevantes. Mi principal
 problema es que veo que algunos profesionales que eran excepcionales en su trabajo anterior, han funcionado mal en el
 trabajo de consultoría. Por otra parte, cuando veo la calidad específica de nuestro trabajo, no estoy seguro sea consultoría de
 excelencia. Sí, nuestras ideas pueden ser creativas, pero no me parece que estemos siendo un apoyo real a las estrategias de
 negocio de nuestros clientes; al menos esto es lo que sugiere el hecho de que rara vez una misma PYME con la que hemos
 operado, nos ha vuelto a pedir trabajos de consultoría”.
 (iii) Jefe de Personal. “Lo que a mí más me preocupa es que las tasas de rotación durante este año fueron mayores en el
 grupo de profesionales del negocio de consultoría que en los otros profesionales de Cáspita.”
 En base a la información entregada, a Ud. se le pide responder en forma precisa y concisa las siguientes preguntas:
 1) Suponiendo que la decisión estratégica de abrir la unidad de consultoría fue correcta, pero que se ha fallado en su
 implementación, señale y explique las 3 principales debilidades que la Gestión de Personas ha tenido en Cáspita y que
 podrían explicar parte de las fallas de implementación del negocio de consultoría. En su respuesta refiérase
 explícitamente a la gestión de competencias en esta organización.
 2) Señale, entregando los fundamentos correspondientes, las 3 intervenciones específicas más relevantes que debieran
 hacerse, para provocar un cambio positivo significativo en el estado actual de la Gestión de las Competencias en el área
 de Consultoría de Cáspita.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 107

[pág. 108]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2016 | pregunta 2
 Convocatoria 2 | página original 203 | Incentivos estrechos versus amplios
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N*2
 Google acaba de realizar una colocación de acciones en el mercado, captando particularmente la atención de
 inversionistas institucionales que, viendo las enormes oportunidades de la empresa, decidieron invertir en ella.
 Todos quienes habían invertido en la empresa tenían claro que Google operaba en la industria con mayor
 rivalidad competitiva del planeta y con la tasa de cambio y obsolescencia de sus productos y soluciones más
 alta de la llamada “nueva economía.” Días después de la exitosa emisión de títulos de la compañía Lazlo Bock,
 Vicepresidente (VP) de Recursos Humanos de la empresa, paseaba por los jardines del 1.600 de Amphiteatre
 Parkway, en donde Google tenía su cuartel general y se divisaba en el horizonte el maravilloso puente Golden
 Gate de San Francisco, California. El alto ejecutivo reflexionaba acerca del sistema de incentivos que la
 compañía debía implementar para su personal, Bock sabía que Google tenía que responder a la confianza
 recién depositada por los inversionistas en la empresa. Era evidente para Bock que Google debía seguir
 creciendo, para lo cual era imprescindible no perder a su mejor gente. Facebook y Twitter andaban tras ellos
 y había que motivarlos para se quedaran en la empresa. El problema, sin embargo, es que no había consenso
 entre los VPs respecto de qué forma debía tomar dicho esquema de compensación variable. Por ello es que el
 Comité Directivo, la instancia en donde se decidían las cuestiones estratégicas como eran los sistemas de
 compensación variables de los ejecutivos y el personal en general de Google, le había encomendado a Bock
 que presentara una propuesta para la siguiente reunión del Comité, ya que el asunto se había dilatado por
 demasiado tiempo y el crecimiento e innovación permanente de la compañía requerían de un sistema de
 incentivos que permitiera el logro de dichos objetivos. Esa era la principal preocupación de Lazlo Bock
 mientras no dejaba de observar las maravillosas gardenias que florecían en los cuidados jardines de las oficinas
 de Google.
 En la última reunión del Comité Directivo Luc Vicent, VP de Ingeniería tomó la palabra para plantear un
 esquema de incentivos variables para los ejecutivos y el personal en general de la empresa. Vicent señaló que
 “gracias a nuestros exigentes procesos de selección, aquí contratamos a los mejores para cada cargo; solo
 aquellas personas que tanto en la empresa como afuera muestran un alto nivel de desempeño. Por ello, es que
 para los cuatros niveles organizacionales que tiene actualmente la compañía, debe existir una banda de
 incentivos variables relativamente estrecha, que pague entre uno y cuatro sueldos adicionales a los 12 que cada
 persona obtiene como remuneración fija. El sueldo adicional debiera corresponder a aquellos que logran la
 metas que tienen cada año, mientras que los 4 sueldos debieran ser para quienes tengan una performance sobre
 lo esperado. La alta calidad del personal que tiene Google no debiera generar mayores diferencias en bonos
 variables y la dispersión relativamente estrecha que propongo es consistente con el desempeño esperado de
 nuestro personal, Por lo tanto, si dos personas realizan las mismas funciones o se encuentran en niveles
 jerárquicos similares dentro de la compañía, deberían tener bonos variables por desempeño similares. Es lo
 justo” '
 Bock, sin embargo no estaba muy seguro que la propuesta de Luc Vicent fuera la más apropiada para el logro
 de los objetivos de crecimiento en ingresos y márgenes basados en una innovación permanente de Google. El
 VP de Recursos Humanos pensaba que los supuestos detrás del planteamiento de Vicent estaban equivocados
 y que el sistema de incentivos que había que plantear al Comité de Dirección debía ser radicalmente diferente.
 Lazlo Bock pensaba que a la gente en Google había que pagarle de manera “injusta.” En una reunión pasada
 del Comité Directivo, Bock había sugerido de hecho que: “podemos pagarle a alguien un bono 10 veces
 superior al de otra persona que cumple la misma función. Es más, deberíamos estar dispuestos a recompensar
 a alguien con poca experiencia o “junior” con un incentivo variable anual que incluso sea superior al del
 gerente general si acaso su contribución es muy relevante para los resultados de la empresa.”
 Varios metros atrás habían quedado ya las gardenias y ahora Lazlo Bock contemplaba los cerezos en flor en
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 108

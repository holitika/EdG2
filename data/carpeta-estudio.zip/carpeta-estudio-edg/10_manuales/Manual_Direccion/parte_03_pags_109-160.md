# Manual de Direccion · parte 3 (páginas 109-160)

Fuente: 03_MANUAL_ULTIMATE_DIRECCION_EDG_2027_V2_REORDENADO

[pág. 109]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2016 | pregunta 2
 Convocatoria 2 | página original 205 | Incentivos estrechos versus amplios
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 los jardines del 1.600 de Amphiteatre Parkway, mientras meditaba su decisión y decidía consultar a algunos
 expertos en la materia, antes de llevar su propuesta definitiva de incentivos al Comité Ejecutivo de Google.
 Más aún, varios expertos consultados por Bock coincidían en que ambas propuestas de incentivos eran viables
 para los propósitos que perseguía Google, aunque, indicaban, ambas también tenían características y
 potenciales efectos negativos.
 PREGUNTAS
 1. A sujuicio, ¿Cuáles son los supuestos del desempeño de las personas en una organización, que están detrás
 de las propuestas de Bock y Vicent, respectivamente? Señale además cuáles son los potenciales efectos
 negativos fundamentales que cada una de dichas propuestas podría generar.
 2. Para cada una de las dos propuestas planteadas por Bock y Vicent, señale cuál es la principal práctica de
 gestión de personas, distinta al esquema de incentivos, que debe incorporase para atenuar los efectos
 negativos que cada propuesta pueda generar, en cuanto a la capacidad del sistema de incentivos para apoyar
 el logro de los objetivos de Google. Sea breve y preciso.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 109

[pág. 110]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2020 | pregunta 2
 Convocatoria 1 | página original 305 | Incentivos grupales y justicia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº2
 La Empresa Eléctrica Río Claro suministra servicios de construcción de infraestructura e instalaciones
 eléctricas en un mercado de varios miles de pequeñas y medianas empresas. La empresa compite con otras en
 el mercado y se ha posicionado como un proveedor de servicios de calidad y rapidez.
 Jorge Valdivia es el sub-gerente a cargo de todos los equipos humanos encargados de las instalaciones y
 reparaciones de los sistemas eléctricos. Cada equipo está formado aproximadamente por siete empleados que
 trabajan juntos para responder a las llamadas relativas a interrupciones en el suministro, incendios provocados
 por el mal funcionamiento del sistema eléctrico y a la instalación de nuevos equipos o líneas eléctricas.
 Dependiendo de la complejidad de los proyectos en que estos equipos trabajan estos están conformados por
 diferentes combinaciones de ingenieros eléctricos, técnicos electricistas, expertos en seguridad industrial y en
 certificación de normas nacionales sobre instalaciones eléctricas. Cada uno de estos miembros contribuye al
 logro de los objetivos de su equipo desde sus especialidades técnicas en tareas de alta interdependencia. Los
 equipos suelen trabajar juntos desde un mínimo de 3 a 4 meses hasta muchos años seguidos. La empresa se
 sentía orgullosa de que sus equipos de instalaciones y reparaciones eléctricas estaban conformados en un 35%
 por mujeres, cifra que era muy superior al 15% observado en el resto de la industria.
 Hace catorce meses Valdivia decidió poner en marcha un sistema de incentivos mediante el cual se daría a
 cada equipo un premio anual en dinero si lograban ciertos resultados. Valdivia apuntaba a mejorar la gestión
 de sus equipos fomentando el emprendimiento de estos grupos y, de este modo, conseguir llevarlos a un alto
 nivel de auto-gestión. Las medidas de rendimiento incluían indicadores como el tiempo medio necesitado para
 efectuar una faena (ejemplo: restablecer el suministro), los resultados de evaluaciones de satisfacción de
 clientes y el número de horas usadas para realizar de forma correcta un proyecto asignado.
 Al final del primer año, cinco equipos recibieron el incentivo anual, reflejo de las mejoras en productividad y
 satisfacción de los clientes, con un promedio de siete millones de pesos cada equipo. Según las bases del
 sistema (comunicadas inicialmente), el monto del incentivo se distribuyó proporcionalmente, en función de
 los sueldos base de cada miembro del equipo.
 Poco después de que anunciara los grupos que recibirían los premios, Valdivia empezó a recibir una gran
 cantidad de quejas. Algunos de los equipos que no habían obtenido el incentivo expresaron su insatisfacción
 directamente a Valdivia, otros a través de una encuesta anónima que Valdivia distribuyó entre los miembros
 de todos los equipos para evaluar el funcionamiento del nuevo sistema de incentivos. Algunas de las quejas
 más comunes insistían en que los equipos que habían tenido que trabajar en los proyectos más complicados
 eran penalizados (debido a que les resultaba más difícil obtener una buena puntuación en la evaluación).
 También se quejaron de que los equipos que no dedicaban tiempo a colaborar con otros equipos (perjudicando
 al resto), eran precisamente los equipos recompensados. Por último, algunos de los participantes en estos
 equipos se quejaron de sospechar que, como las horas dedicadas a cada proyecto eran informadas
 subjetivamente por cada equipo, los equipos ganadores podían estar alterando el número de horas dedicadas a
 los proyectos, para ganarse los incentivos.
 Para sorpresa de Valdivia, los miembros de los equipos que recibieron los premios también expresaron su
 insatisfacción. Los trabajadores de los equipos recompensados opinaban en las encuestas que el sistema era
 injusto, debido a que los montos individuales del incentivo no reflejaban las contribuciones propias de cada
 integrante del equipo. Algunas opiniones nombraban a “…sacadores de vuelta…” que habían recibido “…más
 de lo que correspondía a su participación”, ya que llegaban tarde con frecuencia a trabajar, alargaban
 demasiado el tiempo de sus almuerzos, paraban muchas veces para descansar y fumar, y carecían de iniciativa.
 Además, las integrantes mujeres de estos equipos ganadores, se quejaron de que sus incentivos eran
 proporcionalmente menores a las de sus pares hombres, ya que ellas eran perjudicadas al ser el incentivo
 calculado en proporción a los sueldos base, debido a que la empresa reflejaba la misma disparidad de
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 110

[pág. 111]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2020 | pregunta 2
 Convocatoria 1 | página original 306 | Incentivos grupales y justicia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 remuneraciones base entre hombres y mujeres observable a nivel nacional, lo que ellas consideraban injusto.
 Valdivia sabía que todos los equipos contaban con las competencias y condiciones para ser más productivos y
 ganarse los premios, sin embargo, no sabía qué hacer.
 El gerente general le recomendó un consultor de RRHH, quién después de escuchar la situación descrita por
 Jorge, le respondió: “Esta empresa debe ponerse a tono con los tiempos. Debe subir los sueldos y eliminar el
 sistema de incentivos. Sugiero un sistema 10X”. Al ver que Jorge no conocía lo que era un sistema 10X el
 consultor prosiguió: “10X es una iniciativa que se ha planteado en redes sociales en medio de la crisis social,
 como un llamado a empresarios para sumarse a una iniciativa que podría aumentar los salarios: Las empresas
 se comprometen a que la brecha máxima entre quién gana más y quién gana menos en la empresa es de 10
 veces el sueldo de quién tiene la menor remuneración", aseguró. “Lo que propongo es eliminar el sistema de
 incentivos e implementar el sistema 10X”, terminó de comentar el consultor.
 PREGUNTAS
 a) Identifique dos problemas centrales relacionados con el diseño y aplicación de planes de retribución por
 rendimiento (incentivos) que ilustra este caso. Razone su respuesta.
 b) Proponga dos intervenciones a incorporar en esta empresa, para mantener la motivación y productividad
 de los equipos al momento de implementar el sistema 10X y lograr los objetivos de negocio de la compañía.
 Indique de qué manera esas intervenciones lograrían estos propósitos.
 c) Identifique dos potenciales problemas que se podrían presentar en la empresa al intentar implementar el
 sistema 10X.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 111

[pág. 112]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2011 | pregunta 4
 Convocatoria 2 | página original 79 | Incentivos por procesos o resultados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 PREGUNTA Nº4
 El Gerente General de la cadena de comida rápida “Sanguchón”, Reinaldo Mostaza Merlo, comentaba a su asesor sobre
 el sistema de incentivos variables asociados a resultados, para sus 20 Jefes de Local en el país: “No estamos logrando las
 ventas y utilidades presupuestadas. Tuvimos buenos resultados porque yo estaba encima de todo, resolviendo dudas y
 tomando decisiones en cada local. Pero el crecimiento nos está pasando la cuenta. Ya no puedo estar en cada local y
 dependo de las decisiones que tome cada Jefe de Local. Se sabe, por otra parte, que no sólo los Jefes de Local, sino
 también que la gran mayoría de nuestros empleados tienen poco tiempo en el negocio. Creo imprescindible instalar un
 modelo de incentivos que oriente y motive a cada Jefe de Local hacia la superación de las metas de venta y utilidades en
 cada local.”
 A su vez, el consultor Julio Barros Jarpa, escuchaba atentamente y le replicaba: “Estoy de acuerdo, tenemos que
 reimpulsar nuestros resultados y lograr hacer mejor lo que nos diferencia: entrega rápida y uniforme de nuestros
 sándwiches, calidad de los ingredientes utilizados, local muy limpio y ordenado y trato amistoso de nuestros
 colaboradores con el público que nos visita cada día. Estos objetivos, a su vez, requieren que cada trabajador de
 “Sanguchón”, tenga un alto nivel de competencias para realizar sus tareas y, al mismo tiempo, esté muy motivado a
 cumplir con cada detalle de nuestro negocio.”
 A continuación Mostaza Merlo indicaba: “Estoy convencido de que la clave está en nuestros Jefes de Local. A nivel de la
 Oficina Central hemos definido una política corporativa de precios y productos que se ajusta muy bien a nuestro
 segmento de clientes. Ahí lo hemos hecho bien. También a nivel central hemos definido nuestra estrategia de publicidad
 y promoción, la que resalta con precisión los atributos más valorados por el cliente: rapidez, calidad estandarizada,
 limpieza y trato amable. Por su parte, los Jefes de Local son nuestros ojos en los detalles que antes veía yo personalmente
 y que tienen un impacto relevante en los resultados, como son la revisión de la calidad de los insumos con los que
 preparamos nuestros sándwiches o los posibles robos que pudieran producirse en diferentes áreas del local. Además de lo
 anterior, los Jefes de Local deben estar atentos a los eventos que ocurran en su entorno geográfico más próximo (como la
 apertura de un centro comercial, la instalación de una estación de Metro, la construcción de nuevas viviendas, etc.) para
 que, dentro del marco de acción que imponen nuestras políticas y estrategias corporativas, puedan tomar decisiones
 específicas que permitan incrementar sus ventas.”
 El sueldo base mensual (fijo) actual de los Jefes de Local era de $1.750.000 para locales con ventas anuales de alrededor
 de $500 millones. Para el resto de los locales dicho sueldo base variaba levemente de acuerdo al nivel de ventas de cada
 local. Por su parte, los Jefes de Local habían manifestado un alto grado de satisfacción con su sueldo base, de acuerdo a
 los resultados de la última encuesta de clima laboral. Existía, sin embargo, una demanda insatisfecha por incentivos
 variables asociados a resultados.
 En su calidad de asesor, Barros Jarpa, le había presentado los siguientes dos planes alternativos de incentivos variables
 para los Jefes de Local.
 Plan A: Los incentivos variables del Jefe de Local estarán determinados por el resultado de la evaluación mensual que
 haga cada uno de los 5 Jefes de Área Geográfica a cada uno de los Jefes de Local que tiene a su cargo, del cumplimiento
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 112

[pág. 113]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2011 | pregunta 4
 Convocatoria 2 | página original 80 | Incentivos por procesos o resultados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 mensual de cuatro variables: calidad, servicio, limpieza y la capacidad para entrenar a su equipo. Cada uno de los factores
 serán evaluados en un nivel 0 si es considerado insatisfactorio, 1 si es satisfactorio y 2 si, en opinión del Jefe de Área, el
 Jefe de Local alcanza un estándar de sobresaliente. Si el Jefe de Local alcanza 8 puntos (2 puntos por 4 variables) recibe
 como bono mensual un 50% adicional de su sueldo base mensual. Si alcanza un puntaje de 7, se hace acreedor de un 35%
 de su salario fijo y así sucesivamente, con un mínimo de 5 puntos, bajo los cuales no se recibe bono.
 Plan B: En este esquema, el Jefe de Local recibirá un incentivo variable proveniente de dos componentes: el primero
 sería un bono anual de 5% del incremento en ventas del local; adicionalmente, un incentivo variable del 10% de las
 utilidades anuales1 del local (siempre que dichas utilidades superen el 12% de las ventas de dicho año). Por ejemplo, si
 las ventas anuales aumentan en $50 millones, es decir, desde $500 millones a $550 millones y las utilidades son un 14%
 de las ventas o $77 millones, lo que es considerado el escenario más probable de acuerdo a la historia y a las
 proyecciones de ventas de la empresa, el Jefe de Local obtiene un bono variable de 5% * $50 millones = $2,5 millones,
 más 10% * $77 millones = $7,7 millones, lo que da un bono total de $10,2 millones anuales aproximadamente.
 A medida que se acercaba el final del año el Gerente de “El Sanguchón”, aún no tenía claro cuál de estas dos alternativas
 era la mejor para la empresa. La propia experiencia en el negocio le había enseñado a Mostaza Merlo que la dedicación y
 el compromiso de los Jefes de Local eran claves en este negocio. En un inicio era él personalmente quien dirigía todo su
 negocio, pero con el crecimiento, los Jefes de Local habían tenido que asumir la conducción de cada local, entrenando a
 sus equipos en los detalles del negocio junto con motivarlos a lograr los resultados.
 En su calidad de consultor y socio de Barros Jarpa, se le pide lo siguiente:
 1. Que indique las diferencias más importantes entre los dos Planes de Compensación variables presentados por el asesor
 Barros Jarpa al Gerente de la Compañía, considerando el impacto que puedan tener en el logro de los objetivos
 estratégicos en los locales de Sanguchón.
 2. Que conteste al planteamiento del Gerente General Reinaldo Mostaza Merlo, quién le acaba de señalar, después de
 analizar los 2 planes, que cree que el sistema de incentivos “ideal” sería la combinación del Plan A con el Plan B.
 Argumente por qué esta opinión podría ser correcta.
 1 Definidas como Ingresos por Ventas Totales anuales del local menos Costos y Gastos Totales Directos anuales del Local.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 113

[pág. 114]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2014 | pregunta 2
 Convocatoria 1 | página original 140 | Incentivos y selección alineados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 2
 Eran las 14:00 horas y Richard Tormen, el gerente de recursos humanos de CletaPlus, empresa dedicada
 a la
 fabricación y comercialización de bicicletas, reflexionaba acerca de la elevada rotación del personal
 comercial de la compañía y cómo ella afectaba la satisfacción de los clientes e impedía el crecimiento de los
 ingresos y la rentabilidad.
 Por ello, Tormen ideó Pedalea, un plan de incentivos que reemplazaba al anterior esquema de bonificacione
 s
 para el personal comercial de las 30 tiendas de venta a público con la que ya contaba la empresa en las
 principales ciudades del país. Este nuevo esquema consistía en el reparto de utilidades concebido
 para que la
 compensación de los jefes de tienda fuese más competitiva y los motivara a maximizar las utilidades de su
 local. Luego de 6 meses, a fines de 2013, el programa Pedalea había concluido su fase piloto en dos tiendas
 cuidadosamente seleccionadas y equivalentes en todas las variables relevantes del negocio. Tormen tenía
 en
 sus manos el informe final de este programa y necesitaba decidir qué recomendar a los dueños y directores
 de CletaPlus: aplicar el programa en todas las tiendas, modificarlo o simplemente desecharlo por completo.
 Sergio Aliste y Fernando “Lobo” Vera, grandes glorias del ciclismo nacional, fundaron CletaPlus al retirarse
 del profesionalismo. Ellos fabricaban y vendían productos elaborados con materiales de primera calidad,
 diseños de vanguardia, aerodinámica y a precios algo superiores a la competencia. CletaPlus buscaba además
 entregar una atención personalizada. “Nos gusta transmitir nuestro carifo por el ciclismo y que el
 cliente
 sienta que vendemos una forma de vida y no solo una bicicleta, junto a una asesoría técnica experta”,
 declaraban los socios. Como consecuencia, en los primeros años del negocio las ventas crecieron
 aceleradamente en un público amplio de ingresos medios y altos.
 Este éxito acelerado, sin embargo, trajo aparejados varios efectos negativos. En particular, la rotación
 del
 personal de CletaPlus comenzó a incrementarse a partir de 2011. Aliste decía que ellos hacían lo mejor
 posible para que CletaPlus fuese un buen lugar para trabajar, especialmente para quienes comparten su
 pasión, así que no podían entender porqué seguían perdiendo buenos jefes de tienda. “El año pasado nuestros
 costos de selección duplicaron lo presupuestado debido a la enorme cantidad de contrataciónes realizadas -a
 mitad de personal externo- para llenar las vacantes que se produjeron.” La falta de personal especializado en
 el mercado, junto a la intensa demanda derivada del crecimiento y la necesidad de dar un excelente servicio
 para diferenciarse de la competencia, implicaba que ningún puesto podía permanecer vacante por mucho
 tiempo. Por ello, las contrataciones las hacía cada jefe de tienda de acuerdo a los requerimientos de su local.
 Á veces, algún empleado ascendía al puesto de jefe; en otras ocasiones, se contrataba a alguien externo, Se
 optaba por lo que fuera más rápido.
 La baja remuneración era el principal motivo que esgrimían los jefes de tienda para renunciar, según las
 entrevistas de salida que realizaba el área de recursos humanos. La compensación a estos ejecutivos consistía
 en un sueldo base mensual más un bono trimestral variable asociado al promedio de ventas de la tienda a su
 cargo en cada período. Estos niveles de ventas se agrupaban en cinco rangos y las jefaturas de las tiendas
 recibían el mismo bono, tanto si apenas habían calificado para el rango como si se encontraban en su límite
 superior. “Comulgo con la estrategia de CletaPlus, pero la compensación no me alcanza; me voy”, afirmó
 uno de Jos jefes de tienda. Otro colega decía: “manejo la tienda más rentable, pero mi compensación no lo
 refleja porque es la más pequeña y no logra ventas suficientes para calificar en un rango más alto”.
 A diferencia del anterior plan de incentivos de la empresa, el nuevo sistema de incentivos (Pedalea), hacía
 que los bonos variables del jefe de tienda estuvieran directamente relacionados con las utilidades de su local
 y no con las ventas. Los jefes recibirían un 35% del incremento de las ganancias de la tienda y los asistentes
 del jefe obtendrían el 15% del aumento de dichas utilidades. El 50% restante de los incrementos sería para la
 empresa, Con el fin de fomentar la retención, los bonos se pagarían un mes después del trimestre en el que se
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 114

[pág. 115]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2014 | pregunta 2
 Convocatoria 1 | página original 141 | Incentivos y selección alineados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 generaron. Cualquier empleado que renunciara antes de la fecha de pago perdería el derecho
 al bono de ese
 periodo. A cambio de ese mayor riesgo que estaban asumiendo, los jefes tendrían, dentro
 de ciertos límites,
 una mayor libertad para gestionar su tienda.
 Como el plan representaba un cambio importante, se decidió probarlo primero en fase piloto antes de
 lanzarlo en toda la empresa. Las siguientes tablas muestran los resultados financieros y de satisfacción
 de
 clientes, antes y después de la implementación del piloto de Pedalea, durante el 2% semestre de 2013. El
 local
 de Barrio Italia, a cargo de Miguel “Topo Gigio” Droguett, estaba ubicado en un barrio atractivo
 por sus
 múltiples ciclovías. Por su parte, la tienda Mall Santiago Centro, se encontraba localizada en
 un centro
 comercial, a cargo de Roberto “Pata de Lana” Muñoz, otro ex ciclista, imbatible en la ascensión
 a los
 “caracoles” de Portillo.
 Resultados Operacionales de las Tiendas (en $ millones)
 . Antes de Después de . Antesde Después de
 Tienda Barrio Ital Tiend | Stgo. Cel
 a Pedalea Pedalea jenda Mall Stgo, Centro Pedalea Pedalea
 ingresos: 100 1151 Ingresos - 100 99
 Gastos Gastos
 Sueldos Jefe 9 10| Sueldos Jefe 10 11|
 “Incentivo Variable Jefe . (o) 5 Incentivo Variable Jefe 0 5
 Sueldo Personal 14: 14 Sueldo Personal 14 7
 Incentivo Variable Personal o: 2 _Incentivo Variable Personal o 1
 Imposiciones 2 2 Imposiciones — 2 2
 Materiales y Publicidad 31 32 Materiales y Publicidad 31 26
 Arriendo y Otros Gastos Fijos 13- 13 Ariendo y Otros Gastos Fijos 15- 13
 Resultado Operacional Tienda 31 37| |Resultado Operaciona! Tienda 28 34l
 Resultados Encuesta Satisfacción de Clientes (1 = Malo; 5 = Excelente)
 , . . Antes de Después de ,
 T ienda Barrio italiha Pedalea Pedalea Antes de Después de
 Tienda Mail ail Stgo. . Centro Pedalea - Pedalea
 Rapidez al saludar 4,3 4,1 Rapidez al saludar . _ 4,2 3,8
 Calidad exposición de las bicicletas 4,6 4,7 Calidad exposición de las bicicletas 4,8 4,5
 Sentirse valorado como cliente 34 4,7 Sentirse valorado como cliente 3,5 31
 Tiempo de espera 4,2 3,5 Tiempo de espera 4,1 3,8
 Conocimiento técnico vendedor 4,5 4,5 Conocimiento técnico vendedor 4,4 4,5
 Probabilidad de volver 44 4,7 Probabilidad de volver 4,3 . 3,9
 Probabilidad de recomendar 4,3 4,6 Probabilidad de recomendar 4,2 3,9
 A la luz de estos resultados, Tormen pensaba que el nuevo sistema de incentivos había dado los resultados
 esperados y que apoyaban la implementación de la estrategia de negocios de CletaPlus. Aliste y “Lobo”
 Vera, en cambio, pensaban que el sistema de incentivos que se había probado en las dos tiendas, no era el
 más adecuado para lograr los objetivos estratégicos de la empresa.
 PREGUNTAS
 a) ¿Con cuál de las opiniones está usted de acuerdo: con Tormen o con Aliste y Vera? Justifique su respuesta
 en forma breve y precisa.
 b) ¿Haría cambios en el esquema de incentivos “Pedalea”? ¿Cuáles y por qué?
 e) ¿Qué modificaciones haría en las prácticas de selección de personal de las tiendas, para disminuir la
 rotación y lograr los objetivos estratégicos de FullCleta? Argumente en forma precisa y concisa. —
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 115

[pág. 116]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2016 | pregunta 2
 Convocatoria 1 | página original 187 | Indicadores, incentivos y cultura
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 2
 En aquella tarde otoñal todo parecía bajo control en la oficina de Emilio Ruíz, Gerente General de Pura Luz, la
 principal empresa de distribución eléctrica del país. Sin embargo, cuando ya se disponía a regresar a casa, el
 ejecutivo recibió una llamada del Gerente de RR.HH. de la empresa comunicándole la muerte de un trabajador de
 la empresa contratista Instalaciones Altiro, que realizaba trabajos para Pura Luz. El trabajador había caído desde
 una altura de 4 metros al estar reparando líneas eléctricas.
 Un año antes de esta fatalidad, en su proceso de planificación estratégica, Pura Luz había definido 4 pilares
 estratégicos para los próximos años: (1) aumentar sus utilidades posicionándose por sobre la media de las
 empresas de su industria; (2) mejorar la satisfacción percibida por sus clientes en el servicio; (3) incrementar el
 1uso de tecnología en sus procesos, particularmente en aquellos vinculados con el servicio a los clientes y (4)
 mejorar sustantivamente la seguridad laboral del personal propio y de las empresas contratistas de Pura Luz.
 La empresa distribuidora contaba con 600 trabajadores propios y 2.000 personas pertenecientes a un conjunto de
 40 empresas contratistas, que realizaban variadas funciones de construcción, instalación y mantención de equipos
 y redes eléctricas. Mediante un contrato, Pura Luz encargaba dichos trabajos a algunas de sus empresas
 contratistas, quienes con su propio personal realizaban dichas labores y luego informaban a un supervisor de Pura
 Luz respecto de lo realizado, junto con el envío de la factura correspondiente. Desde luego la gestión de todos los
 aspectos comerciales, financieros, laborales y de seguridad era de responsabilidad de la empresa contratista. Por
 su parte Pura Luz, de acuerdo a la ley, tiene una responsabilidad subsidiaria con la empresa contratista, debiendo
 responder si esta Última no cumplía con sus obligaciones laborales y previsionales respecto de sus trabajadores.
 El accidente laboral constituyó un aviso para la Gerencia General, de que los pilares estratégicos definidos por la
 empresa meses antes, no se estaban cumpliendo. Si bien las utilidades eran mejores que las de la industria, las
 quejas que escuchaba de los clientes por la baja calidad de servicio eran continuas e iban en aumento, muchas
 áreas de Pura Luz no lograban los resultados esperados y la empresa aún no estaba a la altura de la tecnología que
 ya utilizaban otras empresas de distribución eléctrica. Por ello decidió modificar sus políticas y prácticas de
 gestión de personas de modo que ellas contribuyeran efectivamente a la consecución de los pilares estratégicos.
 Lo primero que hizo Emilio Ruíz fue modificar el sistema de evaluación de metas y los incentivos que existían en
 Pura Luz. Hasta ahora, todo el personal era evaluado exclusivamente por la utilidad obtenida por la empresa cuyo
 cumplimiento estaba asociado a un bono variable si se lograba la meta de utilidad definida por la empresa. El
 Gerente General presentó al Directorio un sistema de evaluación de metas asociado al pago de bonos variables
 por su cumplimiento. Con este esquema, Ruíz pretendía minimizar los accidentes y, al mismo tiempo, medir y
 recompensar los resultados asociados a los diferentes pilares estratégicos definidos meses antes. El tablero de
 indicadores propuesto era el siguiente:
 es e . Ponderación
 Objetivo a Evaluar Indicador Meta
 para el Bono
 - a =
 1 Ut113dad de la em¡3resa (para todas Utilidad de la empresa 10Á). sobre ujahdad¡ 40%
 las áreas) « - media de la industria
 2 Margen operacional (para áreas | Margen operacional de 10% superior a 20%
 que generan ingresos y gastos) áreas de negocio ejercicio anterior
 Indice de satisfacción de
 servicio (encuesta externa
 Satisfacción en el servicio a | independiente que Superior a 85 puntos á
 3 : . 15%
 clientes pregunta por el nivel (escala 1 a 100)
 general de satisfacción
 con el servicio)
 % de clientes cuyo
 i l :
 .. ; n1ed1.dor s 50% de clientes
 Incorporación de tecnología en el | satelitalmente (sin , , 0
 4 E . . cubiertos por 10%
 servicio a clientes necesidad de que — .
 - medición satelital
 concurra un visitador al
 domicilio)
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 116

[pág. 117]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2016 | pregunta 2
 Convocatoria 1 | página original 188 | Indicadores, incentivos y cultura
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Objetivo a Evaluar Indicador Meta Panderación
 para el Bono
 a) N” de accidentes de a) Menos de 4
 personal propio y accidentes por
 contratistas cada 100
 b) Gravedad (n” de días trabajadores
 sin trabajar) del propios o
 personal accidentado contratistas
 propio y contratistas b) Menos de 60 días
 o - . - 15% (5%
 5 | Seguridad laboral del personal a <_ie muertes por a a e cada una de
 accidentes del trabajo cada 100 inmeras)
 de personal propio y trabajadores
 contratistas propios o
 contratistas
 c) Cero muertes en
 el trabajo de
 personal propio y
 contratista
 De acuerdo al nivel de logro alcanzado en los indicadores antes mencionados, cada persona en la empresa,
 podría recibir un pago variable por cumplimiento de entre 0 y 5 sueldos adicionales al año (además de sus 12
 sueldos base).
 Adicionalmente, y para evitar que ocurrieran nuevos accidentes, y así cumplir con lo establecido en el cuarto
 pilar estratégico definido por la empresa (preocupación por la seguridad laboral del personal propio y de
 empresas contratistas), el Gerente General decidió implementar las siguientes medidas:
 Entregar a todo el personal un instructivo de seguridad estableciendo los “procedimientos seguros” que
 cada persona en la empresa debía seguir estrictamente para evitar accidentes y fatalidades en el futuro.
 Proveer a cada persona de Pura Luz, particularmente a aquellos en labores más peligrosas, toda la ropa y
 elementos de seguridad necesarios para realizar sus tareas de manera segura. Ello incluía cascos, guantes,
 arneses y otros elementos que de acuerdo a los expertos eran clave para evitar accidentes.
 De manera análoga, se obligaría a todas las empresas contratistas como Instalaciones Altiro a seguir los
 mismos procedimientos y entregar idéntica ropa y elementos de seguridad a sus propios trabajadores, para
 evitar así que el personal contratista sufriera accidentes.
 PREGUNTAS
 1) El Gerente General de la compañía estaba convencido de que el nuevo esquema de evaluación de metas e
 incentivos propuesto sería un factor clave para mejorar considerablemente e nivel de cumplimiento de los
 4 pilares estratégicos de la empresa. Sin embargo, el Gerente de RR.HH de Pura Luz no comparte la opinión
 del Gerente General. ¿Qué razones podría tener el Gerente de RR.HH. para estar en desacuerdo con el
 Gerente General? Sea breve y preciso.
 2) Frente al accidente ocurrido el Gerente General de Pura Luz señaló: “ ninguna empresa tiene el derecho a
 que sus trabajadores no vuelvan sanos y salvos a sus casas después de la jornada de trabajo. Por ello, estoy
 convencido de que las iniciativas propuestas de: (a) modificar el esquema de evaluación e incentivos en la
 empresa, (b) proveer a todo el personal con la ropa de seguridad adecuada y (c) exigir una serie de
 condiciones de seguridad a sus empresas contratistas; lograrán el objetivo de mejorar significativamente el
 cumplimiento del cuarto pilar estratégico de la compañía que consiste en generar mejoras sustantivas en la
 seguridad laboral del personal propio y de empresas contratistas que trabajaban para Pura Luz.”
 Nuevamente el Gerente de RR.HH. discrepa del Gerente General de la empresa. ¿Qué razones podrían
 explicar que el Gerente de RR.HH. piense que dichas medidas no lograrán el objetivo que se proponen?
 Argumente en forma breve y concisa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 117

[pág. 118]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2021 | pregunta 2
 Convocatoria 1 | página original 331 | Motivación y sistema de evaluación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 3
 PREGUNTA Nº2
 “Esta pandemia nos hace reflexionar sobre las prioridades que nuestro personal tiene respecto de su trabajo. Al
 mismo tiempo, y en una empresa que vende servicios informáticos, como la nuestra, orientada a la calidad de las
 soluciones que entregamos y a una relación personalizada y de largo plazo con nuestros clientes, debemos analizar
 la efectividad de las prácticas de gestión de personas que implementamos. Más aún, el hecho de que el 100% de
 nuestros equipos estén laborando en teletrabajo, le agrega grados de complejidad a nuestra tarea gerencial”.
 Estas eran algunas de las reflexiones de Juan Carlos Bodoque, gerente general de “62 Segundos” (62S), al recibir
 los resultados de un estudio encargado sobre los factores que influían en la satisfacción con el teletrabajo en su
 empresa1. Bodoque sabía que tenía que mantener su reconocida diferenciación en el mercado, que tanto le había
 costado obtener. Al mismo tiempo, tenía muy claro que 62S enfrentaba restricciones presupuestarias ya que la caída
 de actividad a nivel general en la economía durante 2020 también había golpeado a su empresa.
 Bodoque, se detuvo en una lámina del estudio que resumía los factores que tenían mayor impacto en la satisfacción
 con el teletrabajo, la que se muestra a continuación:
 Calidad de vida laboral que
 incluye la carga de trabajo, los
 niveles de estrés que se generan y 0,33
 las posibilidades de tomar algún
 descanso en la jornada laboral
 Espacio físico adecuado en el Adaptabilidad Individual
 0,31
 hogar para hacer teletrabajo
 0,07 0,24
 Liderazgo que entregue un Productividad
 adecuado feedback en R²: 0,21
 condiciones de teletrabajo a las Satisfacción Teletrabajo
 personas, que responda R²: 0,51
 consultas de sus equipos a 0,13 Continuidad Teletrabajo
 tiempo y que haga coaching para R²: 0,23
 entregar herramientas que 0,02 0,48
 mejoren el teletrabajo de su
 personal a cargo
 Coordinación efectiva
 Contar con los equipos,
 conectividad y otros insumos 0,11
 para realizar teletrabajo
 Nivel de adecuación de los
 diferentes cargos a las
 condiciones de teletrabajo en
 cuanto a la posibilidad de 0,05
 trabajar desde el hogar o la
 necesidad de realizar
 presencialmente las labores
 Mediante un modelo causal previamente definido, se encontraron que son cinco variables externas a la persona que
 explican (de manera estadísticamente significativa), la satisfacción de los empleados de 62S con el trabajo a
 distancia. A su vez, se determinó que la satisfacción con el teletrabajo impacta positivamente la productividad de
 los trabajadores en sus labores y el deseo de continuar teletrabajando en el futuro. El modelo incluye dos variables
 personales como son la capacidad de adaptación y de coordinación de cada persona a la nueva forma de trabajo
 analizada. También aparecen los “coeficientes de ruta” (cuadrados pequeños), que son ponderaciones de regresión
 lineal utilizados para examinar el vínculo causal entre las variables. Por ej., al mejorar en un punto la evaluación
 que los trabajadores tienen de su líder, la Satisfacción con el Teletrabajo se incrementa en 0,13 puntos, como indica
 el modelo. Por último, se muestra el coeficiente R2, que indica la proporción de la varianza total de la variable
 explicada por la regresión, reflejando la bondad del ajuste del modelo a la variable que se pretende explicar.
 1 Para su análisis, considere que, desde el punto de vista estadístico, el estudio presentado es técnicamente correcto y confiable.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 118

[pág. 119]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2021 | pregunta 2
 Convocatoria 1 | página original 332 | Motivación y sistema de evaluación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 Al revisar los mismos datos, el gerente de Operaciones de 62S, Tulio Triviño, señaló: “Por fin en recursos humanos
 contamos con datos duros para tomar decisiones. El estudio de teletrabajo y en particular las variables que explican
 de manera causal la satisfacción con el teletrabajo y luego la productividad del personal junto a su deseo de
 permanecer en dicha modalidad laboral, nos entregan un mensaje claro: debemos gestionar y dedicar recursos a
 dichas variables si queremos mantener nuestra diferenciación y por lo tanto el liderazgo en el mercado. Esas son las
 variables que marcan la diferencia y vinculan nuestra gestión de personal con el logro de nuestras metas.”
 Por su parte, Policarpo Avendaño, el gerente de Personas de la compañía, que también había tenido acceso a la
 investigación, comentó en una reciente reunión del equipo ejecutivo que: “si bien el estudio sobre motivación en
 condiciones de teletrabajo es riguroso, no apunta a lo que la empresa necesita para motivar a sus equipos. Son otras
 las variables que debemos gestionar para lograr que las personas de 62S contribuyan de manera significativa, con
 sus esfuerzos y capacidades, a mantener nuestros objetivos de diferenciación en el mercado.”
 Se pide responder:
 1. Partiendo de la base del comentario de Tulio Triviño, señale dos consideraciones que se deben tener usted
 en cuenta para hacer una adecuada gestión de dichas variables. Justifique su respuesta
 2. ¿Comparte la opinión de Policarpo Avendaño? Fundamente su respuesta de manera precisa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 119

[pág. 120]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2022 | pregunta 2
 Convocatoria 1 | página original 356 | Perfil y entrevista estructurada
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº2
 El Hospital Francés entrega servicios. Este centro asistencial se ha posicionado como un proveedor de atención
 de salud con una alta calidad de servicio de todo su personal en los distintos momentos de interacción con el
 paciente (toma de horas, consultas, hospitalizaciones, alimentación, procedimientos médicos y facturación,
 entre otros). A través del tiempo, la organización también instaló la innovación en todas las 25 unidades o
 áreas del Hospital, así como en sus diversos procesos y funciones. Para ello incorporó cambios tecnológicos
 de punta en diagnósticos, tratamientos, cirugías, atención al paciente y administración hospitalaria, como ejes
 sobre los cuáles se debía mantener la diferenciación respecto a otras instituciones de salud.
 A pesar del prestigio logrado, el Hospital no estaba exento de un mayor nivel de rotación de personal que la
 industria. Un grupo de trabajadores que presentaba una rotación no deseada particularmente alta eran los
 Técnicos en Enfermería de Nivel Superior (TENS). Estas personas realizan labores de apoyo a los médicos y
 enfermeras del hospital en funciones como:
  Recibir y preparar pacientes para el control de los diferentes profesionales
  Realizar controles de signos vitales y medidas antropométricas (peso y altura)
  Efectuar tratamientos y cuidados básicos
  Apoyar la realización de electrocardiogramas
  Realizar visitas domiciliarias acompañando a los médicos
 La institución presentaba una rotación no deseada superior a la de la industria, tal como lo indica la tabla
 siguiente:
 Hospital Francés Industria
 Rotación no deseada general 13% 7%
 Rotación no deseada TENS 18% 11%
 Además de los TENS, un número relevante de empleados con buenas capacidades técnicas y conocimientos
 se retiraba del Hospital ya que eran atraídas por otras organizaciones de salud que ofrecían remuneraciones
 más elevadas. Incluso a niveles gerenciales existía fuga de talentos. Sin ir más lejos, hace una semana el
 Gerente de Personas del Hospital, Francisco Morales, recibió una mejor oferta laboral de una empresa
 farmacéutica, y la aceptó. En las entrevistas de salida que realizaba el área de Gestión de Personas a quiénes
 abandonaban la organización, los aspectos económicos, en la gran mayoría de los casos, no eran el factor
 decisivo para presentar su renuncia. Por el contrario, quiénes renunciaban se sentían frustrados sentir que no
 aportaban en forma decisiva al logro de los objetivos del Hospital.
 Por este motivo el Hospital decidió cubrir este puesto con María Sandoval, empleada de la organización hace
 más de 10 años, quien se desempeñaba como Jefa de Remuneraciones y que había cursado hace pocos años
 un diploma en Gestión de Recursos Humanos, el que le permitió incorporar una visión amplia de la gestión de
 personas. Ya en su nuevo cargo de Gerente de Personas, María decidió concentrar sus primeros esfuerzos en
 mejorar la selección de los TENS.
 El foco en la selección de TENS era clave, ya que en las próximas semanas se realizaría una contratación
 masiva de estos técnicos en el Hospital, debido al crecimiento y diversificación de los servicios ofrecidos. El
 Hospital buscaba personas que contaran con el perfil técnico requerido para el cargo, de manera que pudieran
 cubrir adecuadamente las funciones para las que se requerían sus servicios. Asimismo, se necesitaba contratar
 a personas con una buena disposición a integrar los equipos interdisciplinarios que entregaban estos servicios,
 los que incluían a médicos, enfermeras, paramédicos y administrativos, además de los propios TENS. La
 cultura del Hospital Francés, desde sus inicios había sido que el cuidado al paciente requiere de la interacción
 permanente de todas las áreas y especialidades de la organización. De hecho, dentro de la definición de cultura
 organizacional se mencionaba que: “Entregar salud requiere una buena labor de nuestros médicos, enfermeras,
 así como del personal técnico, de apoyo, de hotelería y alimentación, higiene y administración. Tenemos que
 brindar al paciente una experiencia en salud única e integral, que nos distinga de otros centros asistenciales.”
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 120

[pág. 121]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2022 | pregunta 2
 Convocatoria 1 | página original 357 | Perfil y entrevista estructurada
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 Al revisar el proceso de selección del personal TENS, usado actualmente en el hospital, la nueva Gerente de
 Personas observó que los antecedentes de las/los postulantes eran evaluados en varias instancias, las que con
 frecuencia se desarrollaban en distintos momentos en el tiempo, dentro del proceso de selección, pero sin un
 orden prestablecido. Entre las actividades más comúnmente desarrolladas en este proceso se incluían las
 siguientes:
  Pruebas de conocimientos técnicos tales como procedimientos de cuidados básicos de pacientes,
 conocimientos de normas de bioseguridad y normas del manejo de material clínico
  Eliminación de candidatos sin requisitos mínimos para el cargo
  Ranking de postulantes en función de sus antecedentes curriculares
  Administración de una prueba de inteligencia general
  Entrevistas online de los Jefes de Unidad a los candidatos/as. Para ello, la Gerencia de Personas entregaba
 pautas para realizar dichas entrevistas en donde se sugerían algunas preguntas que indagaban en las
 competencias técnicas, ciertos valores como la honestidad y transparencia profesional y su interés real
 por el trabajo a desarrollar.
  Recepción de currículos
  Decisión y selección final del candidato a ocupar la posición por parte de la Gerencia de Personas
 Para llevar adelante el proceso de selección, el Hospital confiaba de manera importante en el buen criterio de
 sus Jefaturas de Unidad de las distintas especialidades médicas (pediatría, cirugía, urgencia, imágenes, etc.).
 Concretamente, para la selección de los TENS, a estas Jefaturas, junto con facilitarles las pautas antes
 mencionadas, se les entregaba libertad para conducir dichas entrevistas. Además, María descubrió que para el
 cargo de TENS, que requiere un grado de especialización importante, se recibía un número extremadamente
 grande de currículos, con una variedad de antecedes de personas con una amplia diversidad de historiales
 personales y profesionales. Un 40% de postulantes decían tener habilidades y conocimientos que, una vez
 contratadas, en realidad se demostraba que no poseían.
 Desde que asumió su nuevo cargo como Gerente de Personas del Hospital, María Sandoval, había recibido
 muchos comentarios respecto del “buen ojo clínico” que los Jefes de Unidad tenían para entrevistar y evaluar
 a los candidatos para los cargos de TENS. María, sin embargo, tiene ciertas dudas respecto al proceso de
 selección y solicita su opinión experta.
 Preguntas:
 a) María le solicita que le indique 3 aspectos clave que deben modificarse en el perfil del cargo (aspectos
 a investigar en los candidatos/as) para acertar en un mayor número de casos a los TENS que se
 seleccionan, de modo de alcanzar los objetivos estratégicos del Hospital y reducir significativamente
 la fuga voluntaria del Hospital Francés.
 b) En segundo lugar, la nueva Gerente de Personas le solicita que, con sus conocimientos de Gestión
 Estratégica de Personas, le desarrolle un proceso estructurado de selección de los TENS, con
 actividades ordenadas secuencialmente en el tiempo, también con el objetivo de contribuir a los
 objetivos estratégicos de la organización y lograr una mayor fidelización de este personal.
 c) Por último y en términos específicos, María le solicita dos proposiciones concretas sobre cómo mejorar
 la efectividad de las entrevistas de selección del Hospital que realizan los Jefes de Unidad para predecir
 de mejor manera el desempeño futuro de los candidatos/as a TENS.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 121

[pág. 122]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2015 | pregunta 2
 Convocatoria 1 | página original 162 | Reforma laboral y alineamiento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTAN Z2
 Ernesto Piña, analista del sector fruticola exportador, preparaba el informe que debía despachar esa misma
 tarde a dos empresas fruticolas que le habían consultado sobre el impacto que tendrían en el negocio los
 cambios en la legislación laboral anunciados para el 2015.
 En Chile, la industria exportadora de frutas está estructurada alrededor de tres actividades: producción,
 procesamiento y exportación de sus productos. Existen alrededor de 7.800 productores, 60 empresas
 procesadoras y 520 exportadoras. Las empresas multinacionales del sector y también grandes y medianas
 empresas nacionales están integradas a través de toda la cadena de valor en las tres actividades mencionadas.
 Las compañías de menor tamaño, en cambio, se dedican a alguna de las actividades específicas de la cadena
 de valor. El sector fruticola exportador es cíclico. La mayor actividad se produce entre octubre y abril, que
 coincide con el período de cosecha, procesamiento y envío al exterior de la mayoría de variedades de fruta
 producida (e.g., arándanos). Algunas empresas se han diversificado a otras variedades de fruta “de invierno”
 (e.g., naranjas) extendiendo su temporada a todo el año.
 Durazno S.A. es una empresa integrada verticalmente con un posicionamiento de bajos costos en la industria.
 Su organización del trabajo entrega metas específicas y gran autonomía a cada una de las tres áreas del
 proceso de la fruta. Cada área intenta reducir costos y con un mínimo nivel de coordinación, le traspasa el
 producto en proceso a la siguiente área de la cadena, hasta llegar al cliente final. Para reducir costos,
 Durazno ha subcontratado la mayor parte de la cosecha en sus huertos y el procesamiento de la fruta a
 empresas con personal altamente especializado y que hacen uso intensivo de tecnología en sus procesos. Las
 exportaciones las realiza en un 100% el equipo de ejecutivos comerciales de Durazno S.A. Esta es una
 compañía que ha tenido una historia de conflictos con su personal debido a un estilo de liderazgo autoritario
 -impuesto por el dueño-, con bajo nivel de comunicación con sus trabajadores y escasa participación de estos
 en la generación de ideas y soluciones que aporten a la reducción de costos. Hasta ahora la empresa ha
 evitado la formación de sindicatos. Cuando dichos intentos han existido, la administración ha respondido con
 incrementos salariales al personal, ante los cuales los trabajadores, hasta ahora, se han desistido de
 sindicalizarse. Durazno opera a capacidad completa durante toda la temporada de fruta fresca y luego,
 durante tres meses, entre julio y septiembre, despide a gran parte del personal, para volver a contratar en la
 siguiente temporada que comienza en octubre. La compañía retiene a un grupo reducido de pe1'sonas con
 contrato indefinido quienes hacen tareas de mantención en los campos (limpieza y poda). La planta cierra
 para mantención de equipos, realizada por mecánicos especializados de una empresa externa.
 ;
 »
 Frambuesa S.A. es una compañía reconocida en los mercados por la calidad de su fruta. Su esquema de |
 |
 |
 trabajo está basado en equipos de trabajadores polifuncionales que realizan diversas actividades en !
 |
 simultáneo: tareas técnicas específicas propias de cada cargo, análisis estadísticos de sus procesos,
 colaboración en mejoras en seguridad laboral y participación en el mejoramiento de la calidad de todos los
 procesos y productos de la compañía, Frambuesa tiene un estilo de liderazgo participativo con diversos
 canales de comunicación con los trabajadores. También mantiene. una relación de colaboración con su
 sindicato que representa al 70% de los trabajadores, mayoritariamente los de mayor antigiiedad en la
 empresa. Últimamente, sin embargo, debido a la escasez de personal calificado en el mercado, la empresa ha
 contratado personal joven, no sindicalizado, que ha mostrado un mayor nivel de rotación en la empresa. Por
 otra parte, Frambuesa realiza labores de cosecha y procesamiento durante toda la temporada de fruta fresca.
 El resto del año (mayo-septiembre) Frambuesa hace mantención en sus campos y presta servicios de
 procesamiento a otras compañías fruteras que producen variedades “de invierno” durante esos meses, las que
 no cuentan con su propia planta y valoran los altos estándares de calidad de esta empresa.
 Recientemente se anunciaron cambios en la legislación laboral que entrarían en vigencia durante el año
 2015, Primero, se prohíbe expresamente que los trabajadores realicen funciones de distinta naturaleza
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 122

[pág. 123]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2015 | pregunta 2
 Convocatoria 1 | página original 163 | Reforma laboral y alineamiento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 diferentes a las que establece su función específica. Segundo, para los contratos por temporada o faena, se
 establece que el plazo del contrato será indefinido cuando un trabajador preste servicios en diversas obras o
 faenas para un mismo empleador durante 8 meses o más en un lapso de 12 meses. Tercero, queda prohibida
 la subcontratación de trabajadores para las labores propias del giro principal de la empresa. Cuarto, en caso
 de encontrarse la empresa en huelga, se prohíbe el reemplazo de los trabajadores que están en paro por otros
 (personal interno de la empresa o de empresas contratistas externas) para realizar dichas funciones que
 quedaron sin personal. Finalmente, las reformas legales contemplan la libertad de empresarios y trabajadores
 para llegar a acuerdos en diversas materias propias de la organización del trabajo -incluidas las antes
 mencionadas y más allá de la negociación de remuneraciones-, como pueden ser diversidad de funciones a
 desempeñar, horarios y jornadas especiales y tareas a realizar que sean diferentes a las habituales, siempre
 que exista un sindicato en la empresa y que éste represente a más del 65% del personal de la compañía.
 Ernesto Piña, ya estaba por concluir su informe. Antes de despacharlo a sus dos empresas cliente, le pide a
 usted, en su calidad de colega consultor experto, que le dé su opinión sobre lo siguiente:
 PREGUNTAS
 1) ¿Cómo afectarán las reformas laborales anunciadas el logro de sus objefivos estratégicos y, en definitiva,
 el éxito del negocio de cada una de estas dos compañías? ¿Serán similares los efectos para Durazno y
 para Frambuesa? Explique de manera breve y precisa.
 2) En relación a los cambios normativos planteados y considerando los sistemas de gestión de personas que
 actualmente tienen implementados Durazno y Frambuesa, respectivamente, indique tres acciones
 concretas que cada una de ellas debiera aáoptar para hacer frente a dichos cambios legales y lograr la
 implementación exitosa de su estrategia de negocio.
 E
 :
 l
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 123

[pág. 124]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2020 | pregunta 3
 Convocatoria 2 | página original 320 | Remuneración, selección y equidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 PREGUNTA N° 3
 “La crisis social, sanitaria y económica que enfrenta Chile requiere de una cantidad enorme de recursos, como nunca
 antes en nuestra historia, para ir en ayuda de los sectores más vulnerables y de las clases medias del país. Esta crisis nos
 acompañará por varios años. Por ello, debemos desplegar todas nuestras capacidades técnicas y buscar ahorros en todos
 los ámbitos. Ello nos permitirá reorientar el gasto fiscal hacia los objetivos más urgentes y los grupos más vulnerables”,
 declaraba recientemente una autoridad de gobierno al referirse a la aprobación de la ley Nº 21.233 que rebaja las
 remuneraciones de Diputados y Senadores. Hasta ahora, los sueldos de estos funcionarios del Estado estaban entre los
 más altos del mundo antes de la modificación legal. Una vez que la ley entre en vigencia, ella establece que las
 remuneraciones de estos funcionarios públicos se reducirán en un 25%. Por ello, agregaba el representante del gobierno,
 “esta reforma nos permite, reducir gastos en el Estado y, al mismo tiempo, ponernos a tono con los estándares
 internacionales en materia de remuneraciones de quienes ejercen funciones públicas.”
 Los Diputados y Senadores conforman el Congreso, uno de los tres poderes autónomos del Estado, y encargado
 fundamental de la aprobación de las leyes de la nación. Para ser parlamentario se requiere, además de ser elegido por
 votación popular, tener 21 años de edad cumplidos en el caso de los Diputados y 35 años si se trata de los Senadores.
 Adicionalmente, es requisito para poder desempeñar funciones parlamentarias, el haber cursado la enseñanza media. Tal
 como lo confirma la reciente aprobación de la ley que impide la reelección a los cargos de Diputados y Senadores, los
 parlamentarios tienden a permanecer por muchos años en sus cargos mediante sucesivas reelecciones. En caso de no ser
 electos, y a pesar de los bajos niveles de credibilidad del parlamento y los partidos políticos (3% de confianza ciudadana
 según encuesta CEP 2019, cuya principal causa es la percepción de corrupción, de acuerdo con informe PNUD, 2016),
 los parlamentarios habitualmente continúan trabajando en labores políticas dentro de sus partidos.
 El siguiente gráfico muestra las remuneraciones de los diferentes cargos públicos, antes de la reforma a la ley Nº 21.233:
 Remuneraciones mensuales 2020 (en $, ajustadas por PPA) *
 14.000.000
 12.000.000
 10.000.000
 8.000.000
 6.000.000
 4.000.000
 2.000.000
 0
 Chile Estados Unidos Alemania Holanda Promedio Total Uruguay
 Países
 Diputados Senadores Directivos Profesionales Jefaturas Profesi onales
 *PPA = paridad de poder adquisitivo
 La modificación legal solo consideró a los parlamentarios. Las remuneraciones de los cargos de Dirección y Jefaturas
 profesionales que se desempeñan en los diversos ministerios y servicios públicos que conforman el Poder Ejecutivo, otro
 de los tres poderes del Estado, no se verán afectadas por este cambio normativo.
 Los Directivos y Jefaturas profesionales se desempeñan en funciones técnicas asociadas al diseño e implementación de
 las políticas públicas, junto a labores de fiscalización en materias especializadas como el monitoreo y persecución de
 faltas a la libre competencia, el desarrollo y supervisión del mercado de valores, el mejoramiento de la salud pública, la
 calidad de la educación y la focalización de recursos para una urgente reducción de la pobreza, entre otros asuntos. En un
 buen número de casos, estas funciones son ocupadas por profesionales que provienen del ámbito privado y que también,
 en otras tantas ocasiones, regresan después de varios años de servicio público, a trabajar a la empresa privada. Una
 comparación válida de las remuneraciones del sector público y privado para los cargos de dirección y jefatura se muestra
 a continuación en el siguiente gráfico:
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 124

[pág. 125]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2020 | pregunta 3
 Convocatoria 2 | página original 321 | Remuneración, selección y equidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 6
 Remuneraciones mensuales 2020 (en $)
 El perfil que establece el Consejo de Alta Dirección Pública (CADP), organismo a cargo del proceso de selección de
 estos funcionarios, para este tipo de posiciones se detalla en la tabla a continuación:
 Requerimientos del perfil de un candidato para ocupar un cargo Directivo o de Jefatura Profesional en la
 Administración Pública chilena
 Título profesional universitario o técnico.
 Master e incluso doctorado cuando la especialidad técnica del cargo a ocupar lo requiere.
 Experiencia profesional no inferior a 5 años en cargos similares.
 Dominio de idioma inglés.
 Competencias estratégicas: visión estratégica, gestión y logro, liderazgo externo y articulación de redes con personas
 clave, manejo de crisis y contingencias, liderazgo interno, gestión de personas, innovación y flexibilidad.
 Competencias para la gestión pública: dirección de servicios públicos, probidad y ética en la gestión pública, vocación
 de servicio público y conciencia de impacto público.
 Este organismo fue creado con el propósito “de fortalecer la función pública y contribuir a la modernización del Estado,
 a través de la implementación de políticas de gestión y desarrollo profesionales en cargos de Jefatura y Dirección, para
 promover un mejor empleo público y un Estado al servicio de los ciudadanos. “En esta coyuntura -indicaba un alto
 funcionario del CADP-, se requiere redoblar los esfuerzos en materia de eficiencia del gasto público. Por ello debemos
 desplegar todo el talento de todos aquellos que tienen un rol directivo y de jefatura, para movilizar a sus equipos en la
 entrega de un servicio y apoyo a los ciudadanos, con excelencia, efectividad, oportunidad y eficiencia. En estas críticas
 circunstancias no hay margen de error para la acción del Estado.”
 PREGUNTAS
 1. La propuesta de rebaja de 25% de las remuneraciones de Diputados y Senadores, fue preparada por el Consejo de
 Alta Dirección Pública (CDAP). El Consejo está compuesto por 5 miembros independientes. Sin embargo, su
 propuesta no fue aprobada por unanimidad. Hubo 3 votos de mayoría y dos de oposición. Uno de los consejeros en
 minoría, consideró que la disminución del 25% era insuficiente, mientras que el otro consejero que también se opuso,
 paradojalmente, consideró que, por el contrario, las remuneraciones de Diputados y Senadores debieran
 incrementarse respecto de los niveles actuales. Los dos votos de minoría, si bien rechazan la reducción de
 remuneraciones de los parlamentarios, lo hacen por razones diametralmente distintas. ¿Desde el punto de vista del rol
 de los sistemas de remuneraciones efectivos, qué razones pueden sustentar estos dos votos de minoría tan dispares?
 Fundamente su respuesta en forma precisa.
 2. Un honorable parlamentario señalaba a un medio de comunicación, minutos después de promulgada la ley Nº 21.233:
 “Me parece contradictoria esta propuesta. Nosotros los parlamentarios, que tenemos un alto nivel jerárquico dentro
 del Estado, terminaremos obteniendo remuneraciones menores a los Directivos y Profesionales de rango inferior.”
 Desde el punto de vista de la efectividad del sistema de remuneraciones, ¿le parece correcta la posición que expresa
 el parlamentario? Justifique su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 125

[pág. 126]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2023 | pregunta 2
 Convocatoria 1 | página original 379 | Rotación y AMO
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº2
 SecurMax es una empresa fundada hace cinco años que presta servicios de seguridad a supermercados,
 proporcionando guardias de seguridad especializados en la prevención y detección del "hurto hormiga”1 y robos
 con intimidación en las salas de supermercados. Estimaciones de la Asociación Gremial de Supermercados de Chile
 indican que a causa de este este tipo de delitos los supermercados pierden entre 150 y 200 millones de dólares
 anuales, cifra que se incrementaba año tras año, con nuevas formas de robo cada vez más variadas, “creativas” y
 violentas. Por esta razón, la demanda por seguridad en la industria de supermercados estaba creciendo a tasas altas
 y constantes.
 SecurMax fue uno de los primeros proveedores de servicios de seguridad en el mercado. Esta compañía ha basado
 su éxito en una estrategia de diferenciación basada en la alta efectividad, confiabilidad y calidad de sus servicios.
 En cada supermercado que atendía, sus equipos estaban compuestos por un grupo de dos a ocho guardias,
 dependiendo del tamaño de la sala de venta. Se esperaba que estos equipos fueran capaces de resolver una amplia
 variedad de situaciones de seguridad y servicio en los supermercados que atendían. Esto era clave ya que los clientes
 de SecurMax evaluaban el desempeño de la empresa en función de la disminución de la tasa de robos y la calidad
 de la relación de los guardias de seguridad con los empleados y clientes en las salas de venta y en base a ello
 renovaban o caducaban cada año sus contratos con SecurMax.
 Hasta hace un año la compañía había tenido una historia exitosa en materia de rentabilidad, control de robos y
 satisfacción con el servicio que entregaba. Ello fue posible porque SecurMax solo tenía equipos de seguridad en
 cinco pequeñas cadenas de supermercados con un total de 15 salas de venta. Además, los jefes de seguridad y sus
 guardias eran gestionados por la Encargada de Personal de SecurMax, Julieta Segura, quién se hacía cargo
 personalmente, y con mucho esfuerzo, de su selección, motivación, capacitación, gestión de compensaciones,
 fidelización y supervisión.
 Este éxito permitió a SecurMax captar de manera explosiva un número importante de nuevos clientes y salas de
 supermercado. Sin embargo, la rápida expansión de la empresa no se tradujo en mejores resultados económicos.
 Muchos clientes reclamaban por la excesiva rotación de guardias y el consecuente deterioro en el servicio entregado.
 En efecto, durante el último año la rotación de los jefes y guardias se acercaba al 50% anual, el doble histórico de
 la empresa y de la industria, la que había sido cercana al 25% al año.
 A raíz de la captación de este importante volumen de nuevos clientes Julieta Segura formó un pequeño equipo de
 trabajo para responder de mejor forma a la mayor carga laboral derivada del crecimiento repentino de la compañía.
 Es así como el proceso de reclutamiento y selección del personal de seguridad comenzaba solicitándole currículos
 e información de compensaciones de mercado a una empresa externa que históricamente proveía de candidatos y
 estudios de compensaciones para los cargos de guardias, conserjes y personal de aseo a diversas industrias. Luego,
 sus colaboradores en el área de personas leían los antecedentes recibidos y, en base a su experiencia,
 preseleccionaban candidatos para ser entrevistados. Luego, Julieta efectuaba todas las entrevistas, en donde
 intentaba identificar las competencias de honestidad, empatía y una actitud positiva frente al servicio. Junto a los
 resultados de las entrevistas se consideraban los antecedentes penales y comerciales de los candidatos, además de
 sus experiencias laborales previas.
 Posteriormente, los seleccionados pasaban por un día de inducción en el cuál mediante charlas breves se les
 informaba sobre la importancia de la calidad del servicio y los valores de SecurMax y se les comunicaba la propuesta
 laboral que entregaba la empresa, la que consistía en un sueldo fijo promedio de mercado para los guardias, una
 semana adicional de vacaciones por sobre lo legal y su ropa de trabajo. El grueso de la jornada de inducción estaba
 dedicada al reconocimiento de su sala de ventas de los recién seleccionados, luego de lo cual los nuevos guardias
 contratados iniciaban su primer día de labores y se esperaba de ellos un rendimiento inmediato acorde a los
 estándares que diferenciaban a la empresa.
 Julieta Segura también consideraba crítico para el negocio el movimiento y reasignación de los equipos de seguridad
 a un nuevo supermercado, cada seis meses. Este proceso, en primer lugar, apuntaba a romper la monotonía del
 trabajo de estos guardias, y segundo, pretendía desarticular posibles relaciones de exceso de confianza entre
 guardias, entre estos y el personal o con los clientes de los supermercados. La experiencia había demostrado que
 estas relaciones habían conducido a crear conflictos de interés que muchas veces podían terminar en conductas
 1 Pequeños hurtos en cantidades menores pero con alta frecuencia
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 126

[pág. 127]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2023 | pregunta 2
 Convocatoria 1 | página original 380 | Rotación y AMO
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 negligentes o deshonestas por parte de los guardias, de los empleados de los supermercados, y/o de los clientes. Por
 ello, y utilizando el factor sorpresa, los traslados se anunciaban con una semana de anticipación.
 Por otra parte, en los últimos meses SecurMax estaba incorporando, adicionalmente al servicio de guardias, sistemas
 de monitoreo mediante cámaras de video instaladas en puntos estratégicos de las salas de supermercado y
 controladas desde una sala de control remoto en las oficinas centrales de SecurMax. Con esta tecnología la empresa
 se posicionaba a la vanguardia del resto de sus competidores, los que no contaban con estos servicios para sus
 clientes. Los guardias en cada sala de supermercado, mediante una aplicación en su teléfono celular, tenían la
 posibilidad de acceder a la información que generaba el sistema de monitoreo remoto. En una charla de bienvenida
 que Julieta daba a los guardias en las diferentes salas de supermercado, entre otros temas, ella planteaba las múltiples
 ventajas para SecurMax y sus clientes de esta tecnología de seguridad remota: protección 24/7, monitoreo desde un
 mismo lugar de múltiples transmisiones de cámaras en diferentes ubicaciones, alerta temprana de problemas de
 seguridad, vídeo grabación de lo ocurrido, bloquear o desbloquear puertas de manera remota de la sala afectada por
 un posible robo, entre otras.
 Julieta está bajo alta presión desde la Gerencia General de la compañía, ya que el gerente general Ernesto
 Tranquilein, le hacía ver que la alta rotación estaba mermando el posicionamiento y los resultados que se esperaban
 del crecimiento en clientes que había tenido SecurMax. En concreto, Tranquilein le mencionó a Julieta que:
 “nuestras prácticas de gestión de personas, o más bien sus deficiencias, están provocando un aumento de los robos
 y una baja satisfacción en nuestros equipos de seguridad. Y ello termina en el 50% de rotación que tenemos en
 nuestra personal de seguridad.” Julieta pensaba que la reciente incorporación de tecnología de monitoreo remoto
 estaba provocando la renuncia masiva de personal, pero no estaba del todo segura. En este sentido le solicita a usted
 que en base a su formación respecto al modelo de gestión estratégica de personas y a la información entregada en
 el texto:
 a) Describa de qué manera la gestión estratégica de personas actualmente existente en la compañía, y en un contexto
 de incorporación de tecnología en SecurMax, está impactando negativamente en los equipos de seguridad y
 consecuentemente en una alta rotación del personal. Seleccione tres prácticas clave, o sus déficits, que estén
 teniendo mayor impacto en dicha rotación, explicando concretamente cómo están afectando la satisfacción y
 posterior renuncia masiva de los guardias de seguridad.
 b) Proponga tres acciones clave de mejora a implementar en materia de gestión estratégica de personas para reducir
 de manera significativa la rotación del personal, señalando de qué forma cada una de sus propuestas permiten
 aumentar la satisfacción de los equipos de seguridad y con ello disminuir la rotación en SecurMax.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 127

[pág. 128]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2018 | pregunta 2
 Convocatoria 2 | página original 268 | Selección y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 2
 empresa financiera de gran tamaño
 Esteban Canales, gerente de estudios del banco de inversiones RSH, una
 analista senior estrella, Pedro Terrazas, había
 ubicada en Santiago de Chile, enfrentaba un gran problema. Su
 la competencia, Con ello, varios clientes
 anunciado abruptamente su renuncia, ya que había recibido una oferta de
 tan competitivo como el que enfrentaba RSH en que los
 quedaron sin un ejecutivo a cargo. En un mercado s
 era clave. RSH prestaba servicios a compañía
 márgenes habían caído enormemente, captar y mantener clientes
 sus proyectos de expansión. El rol de
 de diversas industrias en Latinoamérica, que requerían financiamiento para
 ejecutivos eran los que estudiaban las empresas que
 los analistas era clave para la compañía ya que estos
 potenciale s inversioni stas que quisieran financiar los proyectos de
 solicitaban el servicio, para luego ir a buscar
 crecimiento de sus clientes.
 s a la vez que se destacaba por la
 RSH es una compañía reconocida por la capacidad de análisis de sus ejecutivo
 realizaba y que fuego entregaba tanto
 precisión y claridad de los informes con los resultados de la evaluación que salir
 las altemativas de financiamiento debían
 a sus clientes como a los potenciales inversionistas. Muchas veces
 y que pensaran “fuera de la caja”.
 de lo tradicional y RSE impulsaba la capacidad de innovación de su personal
 ia en análisis de empresas, los analistas requerían capacidad
 Junto a su conocimiento técnico y experienc
 clientes, salían al mercado a captar
 emprendedora y comercial ya que, con las evaluaciones e informes de sus
 iones atractivas para mostrar los beneficios
 potenciales inversionistas, siendo convincentes y haciendo presentac
 de financiar a sus clientes.
 una mayor cantidad de clientes. Los
 El trabajo en equipo permitía a RSH, siendo una empresa mediana, cubrir
 el éxito individual sino también al resultado grupal, La
 bonos para los analistas no solo estaban asociados
 en habilidad es analíticas y de redacción de informes a la vez que implementaba
 compañía desarrollaba talleres
 so con la empresa. RSH exigía que
 ejercicios destinados a fomentar la comunicación, la confianza y compromi
 que los analistas rechazaran las ofertas de
 los analistas senior formaran a los analistas junior. No era extraño
 porque les gustaba la camarade ría y el trabajo en equipo
 aumentos salariales del 15-20% en otras empresas
 que las personas permanec ieran durante la mayor parte de sus carreras en la
 fomentado en RSH. Era común
 compañía.
 , los cuatro candidatos. El primero,
 La empresa de selección le había entregado a Canales, en orden alfabético
 o en el mercado y tenía una cartera
 David Hernández (54 años), era un analista de inversiones muy bien catalogad
 hace 30 años y llevaba 15 años trabajando para su
 de clientes importante que lo seguían. Comenzó su carrera
 cia analítica. Los informes de David, si bien requerían de mayor
 actual empleador, Poseía una gran inteligen
 formado a muchos analistas jóvenes y trabajaba
 claridad, presentaban un buen análisis de las compañías, Había
 o por RSH quería moverse con sus
 con el mismo equipo que él había desarrollado. Planteaba que de ser contratad
 dijo que necesitab a una empresa que le planteara un nuevo
 tres analistas más jóvenes. En la entrevista de selección
 tiempo, evitando una frecuenci a alta de viajes, ya que había sido abuelo
 desafío y le diera fexibilidad de
 recientemente y quería pasar más tiempo con sus nietos.
 como analista. Había estado entre
 Gerardo Hernández (36 años), el segundo candidato, tenía un historial oscilante
 de vuelta”. Puede que los cambios
 los mejores, luego su reputación había decaído y ahora se decía que “estaba
 las empresas tenían de él, pero sin duda “era un
 constantes de empleo le hayan perjudicado en la apreciación que
 te mi esfuerzo y capacidad están dando frutos, más allá de los
 tipo inteligente.” Él mismo señalaba: “finalmen
 trabajado ” Le interesaba el financiam iento de compañías en un amplio espectro de
 equipos con los que he
 pocos sectores. Viajaba constantemente para
 industrias, aunque históricamente había estado solo concentrado en
 en donde había trabajado. No estaba
 estar cerca de sus clientes, los cuales lo seguían a las distintas empresas
 es G£L, sobre todo porque su sueldo se había estancado, Aprendía
 contento en su actual empleo en Inversion
 .
 rápido los aspectos técnicos del negocio y era innovador al analizar las compañías
 conocido como analista en el sector, ya
 Por su parte, Sergio Martínez (42 años), el tercer candidato, no era tan
 de marca. En su actual compañía, Investia,
 que solo había trabajado en empresas pequeñas, con menor exposición
 y en la industria se empezaba a hablar ahora
 llevaba 15 años. Recientemente había hecho un muy buen negocio
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 128

[pág. 129]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2018 | pregunta 2
 Convocatoria 2 | página original 269 | Selección y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 s, en donde se había
 de Martínez y de Investia. Tenía buenos contactos en el sector de empresas informática
 do. Allí había mostrado babilidades comerciale s y sus clientes daban muy buenas referencias sobre él,
 especializa
 donde había trabajado dejaban que cada
 aunque declaraban que sus informes eran algo confusos. Las com pañías
 propios métodos. En la entrevista había mostrado deseos de
 analista trabajara por su cuenta de acuerdo a sus
 cambiarse a RSH. Estaba recién divorciado y su ex mujer e hijos vivían en Osorno.
 Si bien aún no estaba
 Finalmente, Sonia Orrego (35 años), tenía buenas credenciales como analista.
 , se hablaba de ella como “una promesa en crecimiento ”, considerando que había
 completamente consolidada
 daba un servicio muy
 trabajado en bancos de inversiones más pequeñíos tipo boutique con clientes a los que se les
 el tiempo. Manifestó que le gustaría,
 personalizado, pero con un equipo reducido, que ella había formado en
 y así mejorar los buenos resultados que había obtenido.
 trabajar más en equipo para ampliarse a más clientes,
 realizar informes y presentacio nes. Su motivación principal no era el dinero
 Mostraba buenas capacidades para
 de aportar en una compañía más grande y tener un buen equilibrio trabajo - familia, según dijo
 sino la posibilidad
 nte para
 en una entrevista. Está casada y tiene niños chicos. Es muy buena manejando la tecnología, especialme
 armar video conferencias para evitar el exceso de viajes.
 los sueldos de los
 Al pasarle la lista de candidatos a Canales, la empresa de selección le había advertido que
 alza en el mercado. Las expectativas de compensaci ones de los 5
 analistas estaban experimentando una fuerte
 -
 candidatos eran las siguientes:
 Candidato Sueldo actual (millones de $) | Sueldo planteado para incorporarse a RSH
 $10,0 $11,5
 David Bezanilla
 $6,9 $9,0
 Gerardo Hernández
 85,4 $6,7
 Sergio Martínez
 $5,1 $5,5
 Sonia Orrego
 preguntas:
 En su calidad de experto en gestión estratégica de personas a usted se le pide responder las siguientes
 PREGUNTAS
 debería considerar para su
 a) Indique, en orden de importancia, los tres (3) principales factores que Canales
 decisión de contratación. En su respuesta, explique los factores y el orden que usted ha planteado.
 b) Indique cuál es el candidato que Canales debiera elegir. Argumente su respuesta con precisión.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 129

[pág. 130]
Dirección - versión clara y reordenada
 Dirección de Personas | marzo 2011 | pregunta 4
 Convocatoria 1 | página original 64 | Selección, cultura y retención
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 PREGUNTA Nº4
 Durante mucho tiempo, la empresa Genoma fue históricamente líder en el mercado de servicios de tecnología, con una
 exitosa estrategia de diferenciación por calidad de servicio. En los últimos 5 años, sin embargo, el nivel de servicio ha
 decaído. Así lo indican las encuestas de satisfacción a clientes y el aumento sostenido en el número de reclamos por parte
 de los clientes de Genoma.
 El Equipo Ejecutivo, reunido en pleno, no tenía dudas de que el factor fundamental para este retroceso en el servicio, era
 la desmotivación del personal de Genoma para relacionarse adecuadamente con los clientes. Juan Dolly, Gerente de
 Operaciones, señalaba: “Nos equivocamos en el perfil de los candidatos a la hora de hacer nuestra selección de personal.
 En los últimos años la gente que traemos a la empresa -mayoritariamente jóvenes recién egresados de la universidad o de
 la educación técnica- ya no tiene el mismo perfil que nuestros trabajadores con más años en nuestra organización. Ello ha
 debilitado la cultura de proactividad, emprendimiento y orientación al servicio con los clientes, que nos hizo líderes y que
 aún nuestros clientes reclaman. Las nuevas contrataciones no traen ese espíritu de servicio que nos hizo líderes en esta
 industria y, por otro lado tenemos una alta rotación no deseada de estos jóvenes. Por lo tanto, propongo volver a nuestras
 raíces y atraer personal joven con nuestro perfil histórico, particularmente a aquellos que tengan un potencial de
 innovación, proactividad y espíritu de servicio al cliente, acorde a nuestra cultura empresarial.”
 Por su parte, el Gerente Comercial, Raúl Adénico, opinaba: “yo creo, que somos muy anticuados con respecto a lo que
 nuestros nuevos trabajadores buscan en un empleo. Debemos adaptar nuestra cultura a lo que requiere la nueva
 generación de empleados que pretendemos atraer y desarrollar. Somos poco atractivos como organización para ellos. Por
 ello, propongo dos cambios en Genoma: (1) progresivamente modificar nuestra cultura de empresa y orientarla hacia los
 aspectos más valorados por nuestro personal joven y, (2) modificar nuestras políticas y prácticas de atracción, motivación
 y desarrollo de personas al interior de Genoma para ser exitosos en atraer a las nuevas generaciones, dando respuesta a lo
 que ellos demandan de una organización.”
 Para ilustrar su punto, el Sr. Adénico mostraba una serie de antecedentes que indicaban que los jóvenes que estaban
 ingresando a Genoma pertenecen a la llamada Generación “Y” o del Milenio (nacidos entre 1980 y 1996), que ha ido
 entrando crecientemente a la fuerza de trabajo, constituyendo hoy el 25% del personal de las empresas. Este grupo es
 diferente, por ejemplo, a la Generación “X” inmediatamente anterior (nacidos entre 1965 y 1979) y que representan cerca
 del 30% de la fuerza laboral actual.
 Según indican varios estudios, la Generación “Y” es ambiciosa en cuanto sus necesidades de crecimiento y desarrollo
 personal y profesional. A cambio de ello, frente a sus logros, necesitan recibir reconocimiento positivo permanente y que
 se les valore de manera diferenciada por sus aportes. También aprecian los entornos diversos y multiculturales. Por lo
 mismo, les gusta viajar y desarrollar sus múltiples pasiones y hobbies. Crecieron utilizando la tecnología y por lo mismo
 están permanentemente inmersos en las redes sociales. En consistencia con lo anterior, buscan relacionarse con otros de
 manera cercana en las actividades que realizan. Los “Y” pueden desarrollar múltiples actividades simultáneamente. Son
 personas que admiran y se comprometen con instituciones que les provean desafíos y cambios permanentes. Por ello, los
 jóvenes “Y” están motivados a vincularse con organizaciones que generen un impacto positivo en el mundo en el ámbito
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 130

[pág. 131]
Dirección - versión clara y reordenada
 Dirección de Personas | marzo 2011 | pregunta 4
 Convocatoria 1 | página original 65 | Selección, cultura y retención
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 social o medioambiental, por ejemplo. Son jóvenes que, por lo tanto, quieren dejar una huella en el mundo y están
 dispuestos a innovar en sus trabajos, si ello ayuda a cumplir sus objetivos.
 Las generaciones anteriores –particularmente los “X”-, en cambio, presentan características diferentes a los jóvenes “Y”.
 Los “X” crecieron más solos, se forjaron más a sí mismos, son más independientes y se sienten menos obligados a
 contribuir o “devolverle algo a la sociedad”. Por ello, no necesitan estar siendo reconocidos de manera sistemática cada
 vez que consiguen logros. Los “X” buscan una mayor estabilidad en su vida que las nuevas generaciones; son menos
 flexibles y no son tan proclives al cambio. Son menos idealistas. Más pragmáticos. No se sienten tan comprometidos con
 las organizaciones por su sentido de misión o los valores que inspiran, sino porque pueden ser instrumentos para su
 desarrollo y la consecución de sus objetivos personales. Los “X” se sienten más cómodos concentrándose en pocas tareas
 y evitan en alguna medida aquello que altere su estabilidad, su situación familiar o sus proyectos.
 Finalmente, cerrando la reunión, el Gerente General, se refirió a las políticas de gestión de personas de Genoma
 indicando: “damos mucha claridad a cada persona en esta empresa, con descripciones de cargo precisas que establecen lo
 que cada uno debe hacer. Nuestros líderes están orientados a definir las metas de cada persona con precisión y velar por
 el cumplimiento de sus resultados. La mejor motivación es que cada uno tenga clara sus metas. Nuestra organización
 funcional además refuerza la especialización de la gente y ello ayuda al logro de eficiencia en los resultados. Pagamos un
 sueldo fijo y damos oportunidades de carrera dentro de cada área siempre que la persona cuente con varios años de
 experiencia. Buscamos además, mejorar nuestros resultados ya que ello deja contento a los accionistas y da la
 tranquilidad a nuestros empleados de que navegan en un barco sólido”.
 Como asesor externo a la empresa se le pide que responda lo siguiente:
 1. ¿Está usted de acuerdo con lo que propone el Gerente de Operaciones, el señor Juan Dolly o más bien apoya los
 cambios que propone el Gerente Comercial, el señor Raúl Adénico? Justifique su respuesta.
 2. Señale y explique cuáles serían las 3 principales acciones concretas en el ámbito de la gestión de personas que
 Genoma debiera implementar para lograr recuperar su diferenciación y la posición de liderazgo en el mercado.
 Justifique su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 131

[pág. 132]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2019 | pregunta 2
 Convocatoria 1 | página original 281 | Servicio, AMO y cultura
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N2
 Superzon, una importante empresa del comercio online con presencia mundial, hoy no tiene operaciones físicas
 en nuestro país. Si hoy un consumidor chileno quiere comprar un producto por Superzon, debe encargarlo a
 Estados Unidos. Sin embargo, esta empresa ha dado señales inequívocas de que quiere contar con oficinas,
 bodegas y toda la logística que se requiere para ser un operador local. Actualmente es una de las compañías con
 mayor valorización bursátil en el mundo, lo que ha conseguido mediante permanentes inversiones en tecnología,
 la que le permite tener una muy buena interacción con sus clientes. Ello se traduce en recomendaciones de
 productos escogidos a la medida del perfil de los usuarios, buscadores rápidos y efectivos de productos, sistema
 de pago online muy seguro, despachos con precisión en donde el comprador en cada momento tiene información
 del estado de sus pedidos y un sistema muy efectivo de devoluciones.
 Por su parte, la multitienda nacional Chilezon, así como muchas otras compañías de retail locales, también han
 desarrollado sus negocios de venta online, los que complementan su cadena de tiendas en todo el país. Ante la
 amenaza inminente de la instalación de Superzon como competidor local, Chilezon está haciendo grandes
 esfuerzos por ser un actor competitivo en el comercio online. Ha invertido en tecnología, centros de distribución,
 sistemas de pago seguro, aplicaciones para compra mediante teléfonos móviles, logística y también ha adquirido
 empresas que pueden acelerar la construcción de sus ventajas competitivas en el negocio del retail online.
 Hasta ahora la experiencia de los clientes con respecto a Superzon y Chilezon ha sido dispar. Un reciente estudio
 mostraba las opiniones de clientes de ambas empresas. En uno de sus capítulos aparecía este testimonio:
 “Compré un smartphone a través de la página web de Chilezon. Como tenía dudas respecto de la compra, llamé
 al call center. A la persona que me respondió muy amablemente y con gran motivación, le costó dar respuesta
 a mis consultas y sus respuestas no fueron técnicamente muy convincentes. Sentí que improvisó una respuesta.
 Luego de terminar mi conversación, y como necesitaba el smartphone pronto (había perdido el mío), hice clic
 en la opción de retirarlo en tienda en 24 horas. Así que al día siguiente concurrí a Chilezon. Me atendió un señor
 muy amable y proactivo. El problema fue que por más que insistí, solo me pudo informar que mi pedido del día
 anterior estaba ingresado en el sistema, que había smartphones en la tienda, pero que no me lo podían entregar
 porque no se había emitido aún la guía de despacho. Frustrado, insistí en que me lo entregara, pero quién me
 atendía me repitió unay otra vez que de verdad lo sentía mucho, pero que para poder entregarme en ese momento
 el celular que había comprado debía consultar a su jefa, quién no se encontraba disponible en ese momento. Ese
 era el procedimiento y sin la autorización de su supervisor no podía entregarme el producto, me señaló la persona
 de la tienda.
 Por otra parte, una semana después, compré un parlante en el sitio web de la tienda online Superzon. Como
 tenía poca experiencia como usuario y también dudas sobre el producto me contacté con su centro de atención
 al cliente. Un señor me contestó muy amablemente en español. Me indicó que el producto que buscaba no era
 el más adecuado para mis propósitos. Me sugirió en cambio, una alternativa, incluso más barata. Después, en
 un par de minutos me explicó “en fácil”, las ventajas técnicas de su sugerencia. De paso, me dijo que para que
 fuera cliente frecuente de Superzon, me daría gratis el costo del envío. Me convencí de que su producto
 alternativo era mi mejor opción. ¡Y al mismo precio que comprarlo en Chile; flete incluído! Ante mi sorpresa,
 le pregunté si estaba seguro de esta oferta y si acaso no tendría que preguntar a su jefa para lograr tamaño
 descuento. Me contestó: “a nuestra jefa no la molestamos con estos detalles. Sé lo que estoy haciendo.” Por mi
 natural estado de nerviosismo con estas cosas llamé al call center de Superzon varias veces para conocer el
 estado del envío y en todo momento me contestaron con amabilidad e indicándome con mucha seguridad en
 qué estatus se encontraba el envío. Finalmente, el artículo llegó a mi casa en Santiago, sin problemas.”
 El cliente, luego de esta doble experiencia, terminaba su relato con la siguiente conclusión: “El desafío para
 Chilezon no pasa solo por incorporar nuevas tecnologías. Lo que debe cambiar esta empresa es mucho más
 profundo.”
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 132

[pág. 133]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2019 | pregunta 2
 Convocatoria 1 | página original 282 | Servicio, AMO y cultura
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 En su calidad de asesor experto y desde la perspectiva del rol de la gestión de personas, se le pide que conteste
 las siguientes preguntas:
 a) ¿A qué serefiere el cliente citado en el estudio con que el desafío para Chilezon es mucho más profundo
 que solo incorporar las más avanzadas tecnologías en el comercio online? Explique de manera precisa.
 b) Suponiendo que el testimonio planteado por el cliente expuesto en este caso es representativo de una
 realidad para un conjunto amplio de clientes de Chilezon, señale las tres prácticas de gestión de
 personas más importantes que esta empresa debe modificar o implementar si quiere lograr competir en
 igualdad de condiciones con Superzon, de cara a los clientes de nuestro país. Indique en su respuesta
 qué efectos provocará en la forma de hacer negocios de Chilezon, las prácticas que usted propone.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 133

[pág. 134]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2018 | pregunta 2
 Convocatoria 1 | página original 255 | Sistema AMO y contrato
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N*2
 Ejecutivo de la
 Los tiempos navideños no traían la esperada calma a la empresa Casi Fuimos. Se reunía el Comité
 compañía, compuesto por todos sus gerentes, en la última reunión del año, a analizar la Tabla de Mando de la
 Pozo, gerente de recursos humanos de la empresa señaló: "Como
 Gestión de Personas de la empresa. Enrique
 principales indicadores
 recordarán, esta Tabla, cuyas métricas se presentan a continuación, señala la situación de los
 con el
 de la gestión de recursos humanos y relaciones laborales del año 2017 que termina, y su comparación
 promedio de las empresas del sector en donde compite Casi Fuimos.”
 TABLA DE MANDO INTEGRAL 2017 DE CASI FUIMOS
 Promedio
 Variable Métrica Casi Fuimos| Empresas del
 Sector
 Tas¡a d e accidentabilida
 identabilidad: Núum¡ero d e 25 36
 seguridad laboral
 accidentes por cada 100 trabajadores
 % de trabajadores de la empresa que
 tienen claridad sobre cómo su trabajo 42,3%
 Claridad de funciones . , 26,1%
 impacta los resultados de su área y de la
 empresa en su conjunto
 % de trabajadores de la empresa que
 , articiparon habitualmente en equipos de 9,7% 65,0%
 Coordinación transversal P P aUP
 trabajo transversales de innovación y
 mejora continua
 Número de sugerencias promedio al año
 Empoderamiento por trabajador regístradas e implementadas 0,4 7,0
 en el sistema de innovación de la empresa
 % de gerentes y jefes de la empresa que
 tienen un estilo de liderazgo exigente y que,
 Calidad del liderazgo paralelamente, dan espacios de 31,6% 13,9%
 participación a sus equipos y desarro!lan el
 personal que tienen a cargo
 Fortaleza de las Número de sueldos adicionales (a los 12
 sueldos base) por concepto de 1,9 4,0
 compensaciones
 variables productividad promedio por trabajador
 Diferencia entre el suelda bruto promedio
 Equidad interna de las 14 veces 12 veces
 . de gerentes y ejecutivos y el sueldo bruto
 compensaciones
 promedio de trabajadores sin gente a cargo
 Equidad externa de las — |Compensación total promedio por $750.000 $840.000
 compensaciones trabajador
 de Casi
 Una vez presentada la Tabla de Mando, tomó la palabra Alejandra Secco, gerente de relaciones laborales
 con su sindicato, organización que agrupaba al 85%
 Fuimos, a cargo del vínculo de la administración de la empresa
 en el Mapa de Relaciones Laborales que se
 de los trabajadores. Secco pidió a los asistentes que se concentraran
 presenta en la siguiente página:
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 134

[pág. 135]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2018 | pregunta 2
 Convocatoria 1 | página original 256 | Sistema AMO y contrato
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 COMPARADA CONLAS
 MAPA DE LA RELACIÓN ENTRE EL SINDICATO Y LA ADMINISTRACIÓN DE CASI FUIMOS
 SECTOR 2017
 RELACIONES ENTRE SINDICATO Y ADMINISTRACIÓN DE OTRAS EMPRESAS DEL
 Unicirensonal La Agerca el losacaes Mificarensional
 de a (…
 : n y y delamo daz
 sinicato es...
 no son buenas” señaló Secco.
 Como se puede apreciar en el mapa, “las relaciones con nuestra organización sindical
 de conversació n y resolución de temas entre la
 "Estamos en el cuadrante inferior izquierdo. Nuestra agenda
 en materias de corto plazo como incremento de
 administración de la empresa y el sindicato se centra solo
 las becas de escolaridad para los hijos de los
 remuneraciones, los aguinaldos de fiestas patrias y navidad,
 a los trabajadores sindicalizad os de Casi Fuimos
 trabajadores y el bono de término de negociación que se entregaba
 sindicato no hablamos de temas como la necesidad de
 al término de cada negociación colectiva cada 4 años. Con el
 o los cambios tecnológicos qué enfrentará tanto
 mejorar la productividad de la empresa, nuestra calidad de servicio
 es de conílicto, con
 nuestra compañía como sus trabajadores en el mediano plazo. Por otra parte, nuestra relación
 convergenci a entre los intereses de los trabajadores y los
 escasas instancias de diálogo con el sindicato, en busca de
 Lo que tenemos que hacer, sin embargo, está claro.
 de la empresa.” Y remató diciendo: “Me esperaba algo así.
 con ellos reuniones periódicas que nos permitan
 Debemos tener una mayor cercanía con el sindicato, manteniendo
 al cuadrante superior derecho del mapa, que es
 establecer una relación de confianza. De este modo nos moveremos
 dónde queremos estar.”
 Comentó: “sabemos que el
 A continuación, tomó la palabra Dédalo Jara, gerente general de Casi Fuimos.
 fuertemente de cómo
 compromiso de nuestro personal y por tanto nuestros resultados como empresa dependen
 propuesta de valor hacia
 motivamos a nuestros trabajadores, es decir la calidad del contrato sicológico o la llamada
 s extrínsecas vinculadas
 nuestros trabajadores. Tenemos que ser capaces de dar respuesta a las motivacione
 sus motivaciones
 principalmente a las compensaciones de nuestra gente. También debemos ser capaces de satisfacer
 generar una respuesía
 intrínsecas, asociadas a la calidad y potencial del trabajo que realizan, Por último, debemos
 con la calidad de vida al
 que esté a la altura de las necesidades afectivas de nuestro personal, las que dicen relación
 Y no lo estamos logrando.
 interior de nuestra empresa y las relaciones entre nuestros jefes y sus equipos de trabajo.
 Tenemos que rediseñar
 Nuestro contrato sicológico con los trabajadores de Casi Puimos está fallando.
 ”
 completamente la propuesta de valor que como empresa le entregamos a nuestros empleados.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 135

[pág. 136]
Dirección - versión clara y reordenada
 Dirección de Personas | enero 2018 | pregunta 2
 Convocatoria 1 | página original 257 | Sistema AMO y contrato
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 comercial de
 Finalmente, y ya al filo del término de la reunión del Comité Ejecutivo, habló Arturo Verbal, gerente
 casi todo nuestro personal, especialmente nuestros
 la empresa, quién planteó: “Yo estoy en el día a día con
 estamos abordando los resultados de nuestra Tabla
 vendedores, y también con sus dirigentes sindicales. Creo que no
 sistémica, integrando todos sus elementos.
 de Mando de la Gestión de Personas de la empresa de manera
 métricas
 Concretamente, creo que el problema de relaciones laborales se resuelve haciendo una mejor gestión en las
 de dicha 'Tabla de Mando.”
 breve
 En su cafidad de asesor de la empresa, a Ud. se le solicita que responda a las siguientes preguntas en forma
 y precisa:
 PREGUNTAS
 a. ¿Está de acuerdo con el diagnóstico y la solución planteada por Alejandra Secco, gerente de relaciones laborales
 de Casi Fuimos? Justifique su respuesta.
 a que debe
 b. ¿Concuerda con el análisis y conclusiones de Dédalo Jara, gerente genera! Casi Fuimos, respecto
 que Casi Fuimos mantiene con los trabajadores de la
 reestructurarse completamente el contrato sicológicó
 compañía? Fundamente de manera concisa.
 cuanto a que el .
 €. ¿Está de acuerdo con las afirmaciones de Arturo Verbal, gerente comercial de Casi Fuimos, en
 está
 mejoramiento de las relaciones laborales -desplazamiento hacia el cuadrante superior derecho del mapa-,
 su
 fuertemente vinculado a la gestión de las variables de la Tabla de Mando de Gestión de Personas? Justifique
 respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 136

[pág. 137]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2014 | pregunta 2
 Convocatoria 2 | página original 151 | Sistema completo de RR.HH.
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N' 2
 Hace más de 20 años, Augusto Parra creó la cadena de panadería y pastelería Vienna debido a su
 insatisfacción con el modelo que imperaba en aquellos años para este tipo de establecimientos: una panadería
 de barrio, local, que solo ofrecía pan fresco y de mediana calidad. Augusto Parra comentaba: “En aquella
 época, era imposible pensar en una panadería que tuviera algo más que pan. Si querías además un kuchen o
 un pastel, tenías que ir a dos lugares distintos. Para qué decir si estabas buscando algún producto más
 variado, como pan de aceítunas o con finas hierbas. Yo que disfruto de la cocina resolvía esta falta de
 variedad cocinando yo mismo, pero muchas veces esta solución era costosa en términos de tiempo.” Hoy en
 día Vienna contaba con 50 locales en diferentes ciudades del país y su estrategia tenía, como uno de sus
 objetivos, la diversificación de productos de la panadería tradicional.
 Junto con proveer de una amplia línea de productos, el fundador de la empresa también enfrentaba el desafio
 de mantener la alta calidad de sus productos que lo caracterizaba. La diversificación de la oferta no era
 sustentable si los productos no mantenían su excelencia, ya que como decía Augusto Parra, “nadie quiere un
 pan novedoso si es malo. Por el contrario, debemos fabricar con las mejores recetas e ingredientes, ya que
 además la disposición a pagar de los clientes lo permite.”
 Ofrecer una gran variedad de productos de excelente calidad suponía, sin embargo, una gran exigencia en las
 competencias del personal. En sus inicios, Augusto Parra comenzó su cadena con tres panaderos a quienes
 entrenó personalmente en el estilo que él deseaba darle a las creaciones. Sin embargo, cuando el negocio
 creció, se vio en la obligación de delegar el entrenamiento de sus panaderos. Para ello contrató a un
 consultor, Carlos Matta, quien estaba a cargo de ayudarlo a diseñar un conjunto de políticas de capacitación
 y de remuneraciones, para enfrentar opt1mamente el crecimiento de personal que Vienna necesitaba y lograr
 sus objetivos estratégicos.
 Matta creó e implementó un sistema de capacitación interna: los panaderos más antiguos, basados en su
 experiencia, entrenarían a los nuevos panaderos. La justificación del consultor para esta iniciativa era que
 nadie mejor que los panaderos antiguos, partiendo por aquellos que fueron entrenados por Augusto mismo y
 que por lo tanto conocen el sello que él desea darle a los productos, para seguir con la tarea de crear la mejor
 - y más amplia gama de productos. Para ello dividió a los panaderos en. grupos de trabajo bajo la supervisión
 de uno de los panaderos antiguos a los cuales, informalmente y de manera verbal, sé les denominó “Panadero
 Jefe.” Aquellos panaderos a los que se designaba en esta última función de Panadero Jefe, pasaban entonces
 de tareas productivas a ser instructores. Su trabajo consistía primero en mostrar cómo se cocinaban los
 productos de Vienna y luego, una vez que los panaderos ya conocían las recetas, debían supervisar la
 ejecución de las mismas. Se les agregó también responsabilidad de crear nuevos productos.
 Al respecto, uno de los Panaderos Jefe comentaba sobre el desempeño de su nueva función: “los panaderos
 son tan porfiados Don Augusto ... no me hacen caso. Yo les digo cómo se hacen las cosas y no me entienden
 . y se van temprano y llegan tarde ... Yo los reto, pero no me escuchan. Es más, estoy incómodo con mis
 nuevas responsabilidades. A mí nadie me preguntó si quería asumir estas nuevas tareas. Preferiría volver a
 mi puesto de panadero. Lo que a mí me gusta es cocinar, La verdad es que yo acepté ser Panadero Jefe
 porque el sueldo era el doble de lo que ganaba antes y me dijeron que el trabajo era el mismo.”
 Dado que la decisión adoptada por la empresa involucraba la creación de un nuevo puesto, la política de
 capacitación de panaderos debía necesariamente ir aparejada con un nuevo esquema de incentivos. Carlos
 Matta consideró entonces que los Panaderos Jefes debían ganar sustancialmente más que el resto de los
 panaderos ya que el salario debía reflejar la mayor responsabilidad del nuevo cargo. Para ello les aumentó el
 salario fijo hasta casi el doble y les advirtió que éste podría ser ajustado en el futuro (al alza o a la baja)
 según como estuvieran los números de la empresa. No se agregó ninguna instancia formal de evaluación ni
 feedback. Matta creía que duplicar el sueldo fijo era suficiente para que los nuevos Panaderos Jefes se
 esforzaran para mantener su puesto.
 Nueve meses después de que se implementó el nuevo puesto de Panadero Jefe, Augusto Parra citó a Carlos
 Matta para evaluar el programa de capacitación y remuneraciones diseñado e implementado por este último.
 El fundador de la empresa le comunicó a Matta su preocupación porque, desde el trimestre anterior, las
 ventas habían bajado y las encuestas de satisfacción mostraban clientes que ya no creían que los productos de
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 137

[pág. 138]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2014 | pregunta 2
 Convocatoria 2 | página original 152 | Sistema completo de RR.HH.
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Vienna fueran ni los más diversos, ni los de mejor calidad. A luz de la encuesta de satisfacción que habían
 implementado en todos los locales, los clientes señalaban que Vienna se había transformado en un empresa
 con una línea de productos limitada y, peor aún, de calidad mediocre. Carlos Matta, sin embargo, argumentó
 que no creía que la disminución de las ventas y la peor percepción de los clientes se debía a un problema de
 la gestión de recursos humanos. Según él, “como los Panaderos Jefe conocen perfectamente la línea de
 productos que se desea en Vienna, entonces lo más probable es que el problema se deba a que la demanda se -
 encuentra deprimida y tal vez a que se ha puesto más exigente”. Para remediar esta situación, Carlos Matta
 le recomendó a Augusto Parra que entregara un bono variable extra a los Panaderos Jefes por cada producto
 nuevo que crearan para poner a la venta.
 Parra, sin embargo, no estaba ¿onvencido con la explicación que le daba Matta respecto a la caída de las
 ventas y la satisfacción de los clientes. También tenía dudas respecto de la entrega del incentivo variable
 propuesto. -
 PREGUNTAS
 1) Suponga que con el objetivo de mejorar la situación de la empresa Augusto Parra lo contrata a usted
 como nuevo asesor de recursos humanos. Para ello se le pide evaluar el plan de capacitación y
 compensaciones implementado por Carlos Matta, así como su nueva sugerencia de incorporar un bono
 variable, describiendo los tres principales problemas que enfrenta dicho esquema. Sea breve y preciso
 en su respuesta.
 2) Formule tres recomendaciones para mejorar el sistema de capacitación y compensaciones de los
 Panaderos Jefes. Justifique su respuestade manera concisa.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 138

[pág. 139]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2019 | pregunta 2
 Convocatoria 2 | página original 292 | Transformación digital y RR.HH.
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N2
 En la reunión con su equipo ejecutivo, el gerente general de la agencia de publicidad Eclipse afirmaba:
 "Acordamos la implementación de la nueva estrategia de negocios de nuestra compañía. Sin embargo, creo
 que, para alcanzar nuestros nuevos objetivos, no estamos considerando posibles adaptaciones de nuestra
 cultura y de nuestras prácticas de gestión de personal. Tenemos que implementar ciertos cambios.”
 Por estos días, todas las agencias enfrentan un nuevo escenario de negocios. Los consumidores -principalmente
 las nuevas generaciones-, se desplazan hacia el uso intensivo de las redes socíales, el consumo de información
 en medios digitales por sobre los tradicionales (TV, prensa en papel y radio) y compras vía e-commerce, En
 este contexto, las empresas quieren que las agencias de publicidad les ayuden a desarrollar sus estrategias de
 crecimiento en redes sociales, medios de comunicación digitales y comercio electrónico, logrando lo que
 fmalmente les interesa: incrementar sus ventas.
 Un experto comentaba: “Hoy, los mejores resultados no los obtienen las agencias de mayor tamaño, sino las
 más capaces de abordar los cambios que experimenta la industria y transformarlos en oportunidades para
 generar ingresos tangibles para sus clientes. La creatividad es clave, pero ahora las compañías quieren
 monetizar rápidamente sus inversiones en los canales digitales. Y, por cierto, los clientes quieren que estas
 estrategias digitales estén integradas y sean coherentes con sus campañas en medios tradicionales”.
 Eclipse es la principal agencia de publicidad medida en ventas. Cuenta con personal, que como mínimo tiene
 15 años en la empresa, experto en campañas publicitarias en TV, prensa escrita y radio. Sus clientes les
 solicitan apoyo creativo y asesoría en la planificación, diseño de campañas e inversión en la compra de
 espacios, en los medios tradicionales. La fidelización de clientes pasa ahora por ser capaz de brindar soluciones
 digitales con enfoques innovadores que permitan incrementar sus ingresos con estrategias basadas en las
 nuevas plataformas de negocio virtuales (redes sociales y e-commerce) e integradas con los canales
 tradicionales.
 Eclipse tenía tres gerencias, cuyos equipos desarrollaban sus tareas con mucha autonomía, debido a la
 experiencia y especialización alcanzada. Un gerente afirmaba: “Cada uno hace muy bien lo suyo: la Gerencia
 Comercial busca a los clientes, la Gerencia Creativa diseña las estrategias de marca y campañas publicitarias,
 mientras que la Gerencia de Tecnología diseña sitios webs muy interactivos para sus clientes”. Otro ejecutivo
 señalaba: “Coincido con mi colega. Nadie hace campañas publicitarias más atractivas que Eclipse. El escenarío
 de negocios ha cambiado, pero las competencias requeridas y la forma de prestar nuestros servicios siguen
 siendo las mismas. No nos van a enseñar ahora cómo se hace publicidad y cómo se responde a nuestros clientes,
 Basta solo observar los premios que históricamente hemos obtenido en el Festival de Cine Publicitario de
 Cannes por la creatividad y calidad visual de nuestras campañas en TV. Ahí radica nuestra ventaja competitiva
 y nuestro prestigio. Los sitios webs que diseñamos logran incrementar las visitas de los usuarios de las
 compañías a las que prestamos nuestros servicios”.
 Otro gerente indicaba: “Estos logros son consecuencia de la coordinación de las tres gerencias, coordinación
 que realiza nuestro Gerente General, y de los incentivos diseñados para lograr nuestros resultados. La Gerencia
 Comercial obtiene sus bonos de acuerdo a las cuentas (clientes) que logra capturar y mantener, La Gerencia
 de Tecnología recibe sus incentivos variables de acuerdo al grado de aceptación de los clientes en relación al
 atractivo de los sitios web que les diseña. Por su parte, la Gerencia Creativa obtiene sus compensaciones
 variables en base a los premios obtenidos y la satisfacción de los clientes.”
 En la misma reunión, los ejecutivos de Eclipse concordaron que lo fundamental para lograr convertir sus
 servicios a los clientes en ingresos tangibles, era el mejoramiento de los aspectos tecnológicos y digitales de
 sus productos y procesos. Los nuevos competidores -tecnológicos desde su origen-, son disruptivos y generan
 soluciones para sus clientes a gran velocidad y con alta capacidad de transformar sus campañas y servicios
 digitales en mayores ingresos para sus clierites. Estos nuevos competidores cuentan mayoritariamente con
 personal joven -nativos digitales-, quienes desarrollan una intensa interacción con sus clientes. Sus áreas
 comerciales capturan las necesidades digitales de las compañías en materia de e-commerce. Las áreas de
 tecnología, dedicadas al desarrollo de aplicaciones (apps) y otras soluciones para el comercio digital, se
 coordinan con las áreas comerciales para traducir las necesidades de los clientes a soluciones digitales
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 139

[pág. 140]
Dirección - versión clara y reordenada
 Dirección de Personas | agosto 2019 | pregunta 2
 Convocatoria 2 | página original 293 | Transformación digital y RR.HH.
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 apropiadas. Estas áreas tecnológicas también buscan la cooperación con las áreas creativas encargadas de
 generar las estrategias y soluciones digitales que deben realizar sus clientes en redes sociales y e-commerce.
 Finalmente, tanto las áreas de tecnología como las creativas vuelven a conectarse con las áreas comerciales
 para que estas últimas hagan una buena entrega de las soluciones digitales diseñadas a sus clientes.
 El Gerente General, quiere lograr pronto los nuevos objetivos de Eclipse: convertirse en una agencia líder en
 desarrollo de estrategias y campañas en plataformas digitales y redes sociales para sus clientes -integradas con
 sus canales tradicionales- logrando a su vez, un incremento en los ingresos de dichos clientes, Sin embargo,
 salió preocupado de la reunión con su equipo ejecutivo, por lo que requiere de su opinión en varios puntos.
 Por ello, y de acuerdo a la información entregada, el gerente general le pide a usted, que desarrolle de
 manera concreta, las tres principales iniciativas en materia de gestión de personas que le permita a la
 compañía alcanzar los nuevos objetivos estratégicos planteados, Indique de qué manera los cambios que
 usted propone, permiten modificar determinados aspectos de la cultura de la empresa y con ello lograr
 sus objetivos estratégicos.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 140

[pág. 141]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia - 35 preguntas
Examen de Grado UC | materia, preguntas y respuestas 141

[pág. 142]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2021 | pregunta 1
 Convocatoria 2 | página original 341 | Adquisición y diversificación relacionada
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 1
 PREGUNTA Nº1
 El gigante francés del lujo LVMH (en adelante LV), dueño de la marca Louis Vuitton entre muchas otras,
 confirmó su interés en comprar la emblemática joyería estadounidense Tiffany & Co. para muchos la
 joyería más famosa e importante del mundo. La oferta de LV se hizo a comienzos de 2020 y fue de US$
 14.500 millones por quedarse con la afamada joyería, operación que de concretarse sería una de las mayores
 adquisiciones del grupo francés, líder mundial en el mercado de artículos de lujo. LV está presente en moda,
 vinos, perfumes, cosméticos y en una serie de otros productos. Tiene además una acotada línea de joyería
 destacando relojes. Al día siguiente de conocerse el interés en la joyería estadounidense, el precio de las
 acciones de Tiffany aumentó un 30% lo que al menos en parte puede deberse a este evento. La pandemia
 en 2020 y 2021 ha retrasado la operación, y el Directorio del LV continúa debatiendo si la llevará o no
 adelante.
 Los Actores
 En su conjunto, LV y sus 70 marcas -incluidas Christian Dior, Fendi, Hennessy y Dom Pérignon, Bulgari-
 obtuvieron en 2019 resultados récord de ventas y de beneficios. Por su parte, Tiffany registró en el mismo
 año, un aumento de 6,5% en sus ingresos y su facturación bordeó el 10% de la de LV. La disminución en
 los turistas por el Covid-19 frenó el crecimiento de Tiffany desde el inicio de 2020.
 Tiffany & Co., es la primera joyería a nivel mundial, tiene un buen potencial de crecimiento y actualmente
 se encuentra en fase de relanzamiento, después de vivir un difícil 2020. Al cierre de ese año contaba con
 321 tiendas propias en 20 países bajo la marca Tiffany, lo que constituía el principal canal de
 comercialización de la afamada marca. Del total de tiendas de Tiffany, 124 estaban en Estados Unidos y
 90 en Asia. La tienda online representa el 15% de la venta total de Tiffany en el mundo, mientras que las
 tiendas físicas en Estados Unidos explican el 25% de la venta total de la empresa. Desde 1982 la compañía
 controla el suministro y la procedencia de todos sus diamantes en bruto, habiendo claridad en la ruta del
 diamante, desde su origen (la mina desde donde se extrae) hasta la confección de la joya misma, controlando
 así todo el proceso de abastecimiento. El Gerente de Finanzas de LV declaraba: "Queremos aprender e
 integrar nuestra estructura de producción a la de Tiffany y así crear varias sinergias a nivel de LV”.
 Por su parte LV, distribuye sus productos a través de tiendas propias especializadas en cada una de las
 marcas que administra (hay tiendas para Bulgari, otras para Dior y así sucesivamente). Una eventual
 adquisición de Tiffany fortalecería su negocio de joyería, en especial la venta de relojes de lujo, y extendería
 su oferta a joyas más sofisticadas, en donde Tiffany es fuerte. Además, aumentaría su participación en el
 comercio electrónico de Estados Unidos, ya que en tiendas físicas LV muestra una robusta posición en el
 mercado de Estado Unidos. Además, ayudaría a la expansión de LV en Asia, mercado en donde Tiffany
 tiene una buena posición. Según analistas de la industria del lujo, “Tiffany sería un complemento perfecto
 para LV: potenciaría su cartera de productos y regiones combinando tradición y modernidad. Además, le
 permitiría acceder a procesos productivos y a tecnologías aún no desarrolladas adecuadamente en el
 grupo francés”.
 El 2020, un año difícil para la industria del lujo
 A pesar de los signos de recuperación en China en el segundo semestre de 2020 - uno de los máximos
 compradores de artículos de lujo en el mundo con el 35% de la demanda mundial - las ventas de la industria
 del lujo a nivel global sufrieron una contracción del 40% anual durante ese año. Como respuesta a las
 restricciones de movilidad, las firmas que operan en el mercado del lujo han puesto el foco en el comercio
 electrónico ya que suponen que el miedo al contagio en las tiendas físicas persistirá.
 Por otro lado, para el 2021 se espera un incremento en el costo de las materias primas a causa de la
 persistencia de la pandemia, y un aumento de precios entre un 5% y un 17% para piezas icónicas (por
 ejemplo, relojes en la marca Cartier) durante el resto del 2021, pese a la baja proyectada para la industria
 del turismo.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 142

[pág. 143]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2021 | pregunta 1
 Convocatoria 2 | página original 342 | Adquisición y diversificación relacionada
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 Lo difícil que está resultando el 2021 para LV
 En la primera mitad de 2021 las ventas de LV descendieron de manera importante, y más significativo aún
 fue el descenso en sus resultados. Lo anterior muestra uno de los desafíos más importantes que enfrenta el
 grupo y la industria del lujo en general, mientras se combate la pandemia: la reducción significativa de sus
 costos.
 Pero no es la única dificultad que está enfrentando LV. Diversos movimientos ambientalistas y de derechos
 humanos, están obligando a LV a declarar el origen de sus diamantes, de manera de asegurar que los
 productos que se comercializan especialmente en su línea de relojes de lujo y en una serie de artículos que
 incluyen diamantes, no contribuyen a abusos en contra de personas y en especial de niños en los países de
 África en donde se encuentran varias de las principales minas de diamantes. La demanda social concreta,
 busca que LV declare detalles del origen de los diamantes que utiliza, trazando la ruta entre los depósitos
 de diamantes (las minas) hasta las joyas que se exhiben en catálogos y en tiendas.
 La decisión
 El Consejo Directivo de LV se reunió a comienzos de junio de 2021, con el objeto de analizar el impacto
 que la pandemia está teniendo en el negocio, y resolver si mantendrá o no la oferta realizada por Tiffany.
 La operación se presenta como la mayor compra en la historia de LV y su salto definitivo a Asia, un mercado
 que parece atractivo para el gigante del lujo francés.
 El cierre de la compra por parte de LV, en caso de concretarse, debería producirse hacia el mes de
 noviembre de este año, siempre que se cumplan una serie de condiciones, entre ellas la aprobación de los
 organismos regulatorios, el visto bueno de los accionistas de Tiffany y el convencimiento del Directorio de
 LV, el cual enfrentaba opiniones divididas en relación a la decisión.
 Responda las siguientes preguntas basándose sólo en la información presentada en el caso
 a) ¿Fortalece o no el modelo de negocios corporativo de LV la eventual compra de Tiffany & Co.? ¿Por
 qué si o por qué no? En caso de ser afirmativa su respuesta señale tres aspectos específicos que
 fortalezcan el modelo de negocio corporativo. En caso de ser negativa su respuesta, señale tres aspectos
 que deberían tenerse en consideración para fortalecerlo.
 b) Considerando la información del caso, ¿Qué decisión recomienda al Directorio de LV: comprar Tiffany
 o desistirse de la compra? Entregue los dos principales argumentos que sustentan su recomendación.
 Considerando su decisión, ¿cuáles son los riesgos que involucra la decisión tomada y sobre los cuales
 debiera la compañía evaluar planes alternativos? Sea preciso e indique dos riesgos principales.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 143

[pág. 144]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2021 | pregunta 4
 Convocatoria 1 | página original 335 | Adquisición y sinergias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 1
 PREGUNTA Nº4
 El 4 de enero recién pasado, los accionistas de Fiat Chrysler (FCA) y de Peugeot S.A. (Grupo PSA) dieron su
 aprobación a la mega fusión de estos dos colosos de la industria automotriz, convirtiéndose así en el cuarto mayor
 fabricante de autos del planeta. Con una producción de poco de más de 8 millones de vehículos e ingresos por 203
 mil millones de dólares, se espera que Stellantis (nombre de la empresa fusionada) juegue un papel clave en la
 industria en especial en la nueva era de la electrificación, que ya cuenta con desarrollos de otras empresas que llevan
 la delantera. La nueva empresa contará con más de 400 mil empleados y albergará 14 marcas emblemáticas como
 Citroën, Maserati, Fiat, Opel, Peugeot, Alfa Romeo, Chrysler, Dodge y Jeep. El presidente de Stellantis será John
 Elkann, actual Presidente de FCA.
 El comunicado que informaba al mercado acerca de esta operación indicaba lo siguiente: “La entidad fusionada
 estará particularmente bien posicionada para proporcionar soluciones de movilidad innovadoras, limpias y
 sostenibles. Las ganancias en eficiencia derivadas de mayores volúmenes, así como los beneficios de unir las
 fortalezas y competencias de las dos compañías, asegurarán que el negocio combinado pueda ofrecer a todos sus
 clientes los mejores productos, tecnologías y servicios de su clase y responder con mayor agilidad al cambio que
 tiene lugar en este sector tan exigente".
 Lo que está en juego
 Diversos documentos publicados estiman que la fusión tendrá costos administrativos directos del orden de US$
 4.900 millones (honorarios de abogados, indemnizaciones de personal, otros ajustes, etc.) y se espera ahorrar en el
 tiempo una cifra equivalente a US$ 6.130 millones por año, como consecuencia de "optimizar las inversiones en
 plataformas de vehículos, familias de motores y nuevas tecnologías, al tiempo que lograr ahorros por el aumento
 en la escala", señalaba Elkann.
 Analistas de la industria señalaban que la fortaleza de FCA estaba en los mercados de Norteamérica y
 Latinoamérica, mientras que la de PSA en el europeo. Sin embargo, ambas empresas son consideradas débiles en
 los mercados estratégicos de China e India. A modo de referencia y considerando la empresa fusionada, el 46% de
 los ingresos provendrían del mercado europeo, el 43% del mercado norteamericano, y sólo un 11% del resto de los
 mercados mundiales.
 Se espera que PSA aporte a la fusión sus capacidades de diseño y tecnología, y los trabajos que ha comenzado a
 desarrollar en vehículos eléctricos e híbridos. La fusión le viene bien a PSA por el crecimiento potencial en el
 mercado norteamericano y por sus altos costos de producción, investigación y desarrollo dado el mayor volumen
 de operación que se proyectaría.
 Lo que no parece estar claro es qué aporta a la fusión el Grupo FCA, que en los últimos años ha enfrentado malos
 resultados en las evaluaciones que realiza el medio especializado y referente en la industria “Consumer Reports”.
 En efecto, información entregada por esta publicación muestra evaluaciones en rangos deficientes para varias de las
 marcas de FCA. Por ejemplo, en pruebas en autopistas, importantes marcas de FCA han sido evaluadas en rangos
 bajos entre competidores de sus respectivas categorías. Del mismo modo, las calificaciones en confiabilidad y
 economía de combustible no fueron mejores para varias de las marcas de FCA.
 Sin perjuicio de lo anterior, según especialistas lo peor de algunas de las marcas del grupo FCA es que no han
 logrado responder con rapidez a las tendencias cambiantes en las preferencias de los consumidores en todo el
 mundo, quienes buscan diseños atractivos, estilo, mayor potencia, pero con menor consumo, eficiencia y seguridad
 lo que inevitablemente lleva a un mayor enfoque en la innovación.
 Dos empresas, dos estilos
 Pero las diferencias no están solo en los aportes proyectados para cada uno de los actores de esta fusión. También
 están en la forma en cómo cada empresa ha sido gestionada hasta ahora. El Grupo PSA (Peugeot) se ha caracterizado
 por un ambiente de innovación en su gestión, con atención en el desarrollo de productos y en el diseño. Sus prácticas
 de gestión también son innovadoras, incentivando la gestión autónoma, la multifuncionalidad en sus cargos y el uso
 de herramientas de gestión de vanguardia como sistemas de incentivos multivariados, matrices de control de
 desempeño y procesos de evaluación sofisticados. Por su parte FCA (Fiat Chrysler) ha sido una empresa más
 tradicional, con un sistema propio heredado desde su fundación, muy basado en políticas y pautas definidas y muy
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 144

[pág. 145]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2021 | pregunta 4
 Convocatoria 1 | página original 336 | Adquisición y sinergias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 2
 claras. Su esencia ha estado en optimizar el costo del producto, aunque ello pudiera haber afectado otras variables
 sensibles como el diseño de los modelos. Al final, “un precio bajo es lo que busca el consumidor”, según declaraba
 uno de los ejecutivos de FCA.
 Considerando sólo la información que se presenta en el caso, responda las siguientes preguntas.
 1. Desde un punto de vista netamente conceptual de Estrategia Corporativa, ¿bajo qué condiciones una fusión
 como la planteada cumpliría el objetivo que se espera tenga una buena fusión? ¿Qué elementos, también
 conceptuales, determinan el hecho que se cumpla o no lo anterior?
 2. Entrando ahora de lleno a la fusión descrita entre FCA y PSA y considerando sólo los elementos planteados
 en el caso, ¿Se justifica una fusión como la anunciada desde un punto de vista de una buena estrategia
 corporativa? Argumente y justifique.
 3. Para que esta fusión se implemente exitosamente, ¿cuáles son los tres principales riesgos que se deberían
 gestionar –y que deben ser enfrentados con prioridad– por parte del Presidente de Stellantis John Elkann?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 145

[pág. 146]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2020 | pregunta 4
 Convocatoria 1 | página original 309 | Alianza/inversión y ventaja
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 PREGUNTA Nº4
 Delta y Latam una alianza con Impacto
 Delta Airlines Inc. está expandiendo fuertemente su presencia en América Latina, gracias a un acuerdo de US$
 2.250 millones con LATAM, la aerolínea más grande de la región. El acuerdo contempla que Delta pagará
 US$ 1.900 millones por una participación de 20% en LATAM, a través de una oferta pública de adquisición a
 US$ 16 por acción (que ya fue declarada exitosa), más US$ 350 millones que Delta invertirá para deshacer los
 lazos que hoy unen a LATAM con American Airlines, su archirrival, a través de la alianza Oneworld. Para
 Delta, el acuerdo le permite continuar con la estrategia de expansión internacional que viene siguiendo desde
 hace algún tiempo mediante la compra de participaciones en aerolíneas extranjeras. Así, LATAM se agrega a
 una lista de socios que incluye al Grupo Aeroméxico SAB, Air France-KLM y Korean Airlines Co.
 LATAM y su historial de Alianzas y Asociaciones
 Para LATAM esto de las asociaciones no es nuevo. Ya en 2012 LAN y TAM sorprendieron al mercado
 anunciando la unión de ambas compañías. También, el 2019 y ya como LATAM, se intentó un acuerdo
 comercial con American Airlines, el cual fue frustrado por el dictamen de la Corte Suprema chilena que
 impidió que esta asociación se llevara a cabo.
 “Tenemos experiencia valiosa en alianzas” declaraba Enrique Cueto, Gerente General de LATAM en una
 entrevista publicada con ocasión del ingreso de Delta a la compañía. En efecto, ya en 2012 LAN anunció la
 fusión con TAM dando origen a LATAM. Una fusión que, a juicio de algunos analistas, fue estratégica para
 LAN, pero cara. Estratégica, porque accedía al mercado brasilero, el mayor en Latinoamérica. Cara, porque
 los resultados distaron mucho de lo proyectado, ya que la integración de ambas compañías resultó ser más
 compleja de lo que se pensaba. Como consecuencia de lo anterior, las utilidades de la compañía unida se
 desplomaron, las sinergias no fueron las previstas, el negocio en Brasil fue un verdadero dolor de cabeza y a
 eso se suma la pérdida del "investment grade"(Ver Nota #1) que obligó a LATAM a realizar un aumento de
 capital de 1.000 millones de dólares. Como consecuencia de lo anterior, la valorización de mercado de LATAM
 pasó de US$ 14.000 millones a US$ 6.500 millones. Pese a todo, LATAM sigue siendo hoy en día una empresa
 con un desempeño superior que sus competidores en Latinoamérica.
 Por otra parte, en 2019 LATAM buscó concretar un acuerdo con American Airlines para compartir rutas. Era
 un acuerdo sólo comercial dentro de la alianza Oneworld a la que pertenecían ambas aerolíneas, el cual
 permitiría ofrecer códigos compartidos entre ellas, aumentando la oferta de viajes para cada aerolínea. No
 obstante, y pese a que tanto LATAM como American coincidían en un número importante de rutas (en especial
 Santiago-Miami), lo que bajaba el nivel de integración efectivo que pudiera lograrse, la Corte Suprema en
 Chile consideró el acuerdo como contrario a la libre competencia por la alta concentración que generaría en
 las rutas de Norteamérica y Europa.
 El mercado aéreo: competitivo y cada vez más sofisticado
 Volar hoy en día genera desafíos importantes para cualquier compañía aérea. En efecto, las exigencias de los
 clientes, el alto nivel de competencia existente en la industria, la tendencia descendente de los precios, y la
 cada vez mayor concentración existente en el sector, explican este fenómeno. Por tanto, hoy en día competir
 con éxito en la industria aérea exige de cualquier compañía relevante conjugar muy buenas tarifas con buenos
 niveles de servicios, destacándose dentro de esto último, las rutas disponibles, flexibilidad de horarios, y
 conexiones eficientes especialmente en mercados altamente desarrollados, como es el caso del mercado
 norteamericano.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 146

[pág. 147]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2020 | pregunta 4
 Convocatoria 1 | página original 310 | Alianza/inversión y ventaja
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 Los Beneficios de la Alianza LATAM - Delta
 La alianza lograda es mucho más que un acuerdo comercial. Ella permitirá contar con una flota mayor, ya que
 como parte del acuerdo, Delta adquirirá cuatro aviones A350 de Airbus SE para la flota de larga distancia de
 LATAM, más otros diez aviones cuyas entregas estaban programadas a partir del 2020 y hasta el 2025.
 Adicionalmente LATAM mantendrá la compra de ocho aviones A350.
 Con la alianza, Delta Airlines obtiene acceso privilegiado a algunos de los mercados más importantes y de más
 rápido crecimiento de América Latina, como es el caso de Brasil que representa el 30% del negocio general
 de LATAM. Esto generará nuevas oportunidades de crecimiento, y le permitirá a Delta ofrecer una extensa
 red de destinos alrededor del mundo con una experiencia de viaje más fluida y una mejor conexión a nivel
 mundial. A lo anterior hay que sumar una presencia más activa de Delta en tres países con los que Estados
 Unidos tiene acuerdos de cielos abiertos (Ver Nota #2): Chile, Colombia y Perú. En total, la alianza le
 significará sumar 435 nuevos destinos alrededor del mundo a la oferta actual de Delta. Con todo lo anterior,
 Delta quedará pisando los talones al líder del sector, American Airlines, su rival de siempre.
 Por su parte, LATAM con esta alianza gana un socio estadounidense poderoso y estable, y asegura la
 oportunidad de continuar reduciendo su pasivo, con mejoras esperadas en la generación de flujo de efectivo
 libre, reducción de la abultada deuda que mantiene, y mejorar su estructura de capital, todo lo cual aumentará
 la capacidad de ejecutar su estrategia a largo plazo. Por otro lado, LATAM tendrá una presencia más activa en
 el mercado de Estados Unidos, uno de los principales destinos en el mercado de Latinoamérica, con una mejor
 oferta para sus clientes. Así mismo, el acuerdo es definitivamente una integración entre las empresas vía
 participación directa de Delta en la propiedad de LATAM. Con ello, Delta ocupará un sillón en el Directorio
 de LATAM, enriqueciendo la gestión y el gobierno corporativo de esta última empresa.
 Al parecer no es casualidad que el Gerente General de LATAM terminara la entrevista citada anteriormente
 diciendo: “La alianza con Delta nos fortalece como compañía y mejora significativamente nuestra posición
 competitiva en América Latina. Nuestros clientes y nuestros inversionistas lo valorarán”.
 Notas:
 (1) Investment Grade o Grado de Inversión, es una clasificación de la calidad de una empresa desde el punto de vista del
 accionista que espera invertir en ella. Mayor grado de inversión, implica mejor calidad.
 (2) Cielos Abiertos es una especie de acuerdo de libre comercio, pero aplicado al espacio aéreo. Cuando existe este tipo de
 acuerdos las aerolíneas de los países involucrados vuelan libremente en todo el espacio aéreo de los países en cuestión.
 Considerando sólo la información entregada en el caso, responda las siguientes preguntas.
 a) Al considerar la Alianza entre LATAM-Delta, ¿Existen elementos que permiten potenciar o mejorar
 la Ventaja Competitiva de LATAM? ¿Sí o No? ¿Cuáles? En caso de haberlos señale tres. En caso de
 no haberlos, explique por qué. Adicionalmente, explique conceptualmente cómo se puede potenciar o
 mejorar una Ventaja Competitiva.
 b) Al final del caso se cita al Gerente General de LATAM señalando: “La alianza con Delta nos fortalece
 como compañía y mejora significativamente nuestra posición competitiva en América Latina.
 Nuestros clientes y nuestros inversionistas lo valorarán”. Según sus conocimientos de Estrategia, ¿Por
 qué el Gerente General de LATAM afirma que la alianza con Delta mejora significativamente la
 posición competitiva de LATAM en la industria aérea en América Latina? Fundamente su respuesta
 basándose en algún modelo que la sustente.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 147

[pág. 148]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2014 | pregunta 4
 Convocatoria 1 | página original 144 | Alianzas y ventaja sostenible
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 4
 Tres empresas navieras que transportan contenedores a nivel mundial, y que compiten con
 la
 chilena Compañía Sudamericana de Vapores CSAV, anunciaron recientemente que iban
 a
 establecer una alianza estratégica: la “Red P3”. Esta alianza tendría un 38% de participación de
 mercado del transporte de containers (o contenedores) a nivel mundial. Las navieras que conforman
 esta alianza son: Maersk Line que contribuiría con un 42% de la capacidad instalada de transporte
 de la alianza, MSC que aportaría un 34%, y CMA CGM que contribuiría con el 24% restante. Red
 P3 sería la alianza más grande a nivel mundial y se espera que comience a operar en el segundo
 trimestre de 2014.
 El mercado del transporte de contenedores presenta indicios claros de estar en etapa de madurez. La
 manera como funciona es muy estándar: el transporte de containers se realiza en “loops”, esto es,
 una vuelta completa origen — destino — origen, como podría ser, por ejemplo, la ruta Hong Kong —
 Valparaíso — Hong Kong. El servicio de transporte debe estar disponible en forma continua en la
 ruta elegida. Esto significa que cada firma configura sus barcos de modo que, por ejemplo, siempre
 haya uno que está siendo despachado cada semana rumbo al destino (Valparaíso en el ejemplo
 anterior). Si la ruta ida y vuelta toma 10 semanas, la disponibilidad en forma continua significa que
 la naviera tendrá 10 barcos (uno para cada semana) haciendo el “loop” (la vuelta completa). De esta
 forma, distintas navieras compiten en el mismo loop, por lo que los niveles de ocupación de los
 barcos pasan a determinar la rentabilidad de las empresas navieras. Por supuesto, los costos de un
 loop para una naviera son casi todos fijos, ya que una vez que se decide echar a andar un loop no se
 puede suspender el servicio por falta de carga. El costo más importante de una naviera es el costo
 del petróleo.
 Los miembros de la Red P3 han anunciado que operaran 225 barcos en 29 loops, comparado con los
 32 loops que ofrecen actualmente las tres empresas por separado. Analistas de la industria estiman
 que la participación de mercado de la Red P3 alcanzará a un 44% en las rutas Asia-Europa, lo cual
 supera el umbral del 30% establecido por los reguladores de la Unión Europea. Aunque superar el
 30% de participación de mercado no es ilegal, será interesante ver cómo responden los reguladores
 a la noticia, toda vez queel índice de concentración de Herfindahl en estas rutas crecerá
 considerablemente.
 Es crucial tener en mente que las alianzas estratégicas entre navieras no constituyen una fusión de
 las empresas, sino que solo son la optimización de una red de transporte a través del agrupamiento
 - de la flota. Las navieras que entran en la alianza solo pueden compartir los espacios de carga en los
 barcos y administrar en forma conjunta sus operaciones, pero no pueden cooperar en términos de
 fijaciones de precios, ventas, marketing y servicio al cliente.
 En la última reunión del sector celebrada en noviembre recién pasado, James Davis, uno de los
 principales analistas de la industria, comentaba en su exposición: “No hay duda que la Red P3 se
 convertirá en un jugador importante en la industria del transporte de contenedores, generando
 múltiples beneficios para sus integrantes, y en especial el desarrollo de mejores ventajas
 competitivas para cada uno de ellos, en una industria donde las empresas necesitan
 imperiosamente buscar formas de diferenciarse ante sus clientes para ser más competitivas. Lo
 anterior no debería contar con la oposición del regulador, por cuanto las alianzas estratégicas no
 son algo nuevo en esta industria”.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 148

[pág. 149]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2014 | pregunta 4
 Convocatoria 1 | página original 145 | Alianzas y ventaja sostenible
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTAS
 a) El destacado analista James Davis, planteó en el párrafo que está al final del Caso, que uno de los
 beneficios de la Red P3 será “... el desarrollo de mejores ventajas competitivas ...” para cada uno de los
 integrantes de la alianza.
 Desde el punto de vista de la teoría de la ventaja competitiva, ¿Bajo qué condiciones el analista tendrá razón?
 ¿Bajo qué condiciones no tendrá razón? Sea preciso en cada caso.
 b) ¿Qué efectos se pueden prever que tendrá la alianza Red P3 sobre la estructura de la industria? Se le pide
 señalar con precisión los 3 principales efectos que se pueden razonablemente prever.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 149

[pág. 150]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2012 | pregunta 2
 Convocatoria 1 | página original 90 | Cinco fuerzas y adaptación estratégica
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº 2
 Ubicada en Lexington, estado de Kentucky, Joseph Beth es una de las librerías más grandes del mundo. En seis mil
 metros de superficie han logrado ampliarse más allá de los libros. Por ejemplo, en la zona de literatura de viajes situaron
 una agencia de turismo y en la parte de jardinería, artículos para jardinear. También decoraron el lugar con sofás y una
 chimenea; habilitaron una cafetería y un local con platos a la carta. Agregaron terrazas -con vista al lago- para que los
 clientes pudieran ir a hojear los libros por horas sin ser molestados. Hoy en día, con 5 megastores (grandes tiendas o
 cadenas) literarios, Beth es un atractivo turístico en las ciudades en donde se encuentra.
 Innovaciones como las anteriores vienen a hacer frente a un sector que está en evolución, en donde las tiendas de libros
 tienen que hacer el peso a compras por internet de clientes a quienes, al parecer, cada vez cuesta mas sacar de sus casas.
 Más allá del libro
 En la actualidad se pueden distinguir tres modelos de negocio “puros” en el mercado de las librerías: el modelo
 tradicional de librería (librería de barrio o tienda de especialidad de libros), las grandes cadenas o megastores como Beth,
 y las librerías on-line. Los diversos competidores se ubican en alguno de estos modelos de negocio o en combinaciones
 de ellos, aunque siempre con alguna mayor orientación en una de las tres opciones, dependiendo de la visión que ellos
 tengan con respecto al negocio y al sector. Quienes son partidarios del modelo tradicional, perciben a las librerías como
 un territorio donde sólo los libros tienen cabida. En cambio, los partidarios del modelo de grandes cadenas, no ven nada
 de raro en agregar distintos productos o servicios en el mismo local. En Chile, el proceso ha sido a la inversa, ya que
 otros sectores se han puesto a vender literatura, como la Feria del Disco que desde hace un par de años amplió la gama de
 productos ofreciendo libros.
 El Modelo de Librerías on-line
 Que duda cabe que las ventas por internet han aumentado considerablemente en los últimos años, y están destronando a
 grandes librerías que han dominado la industria. La última víctima fue la cadena de librerías Borders, la segunda cadena
 de librerías mas importante en Estados Unidos, la que hace pocas semanas cerró todos sus locales. Fue la “crónica de una
 muerte anunciada” dice Carroll Schuyler, abogado especialista en bancarrotas: “Borders era como el dinosaurio que vio
 llegar la era del hielo pero no pensó que lo iba a afectar”. Según el último reporte de esta compañía, se cerrarían 400
 tiendas, y se producirán 11.000 despidos.
 Según los analistas, Borders no pudo enfrentar la agresiva competencia de b&n.com (perteneciente a Barnes & Noble, la
 cadena de librerías número uno del país) y de amazon.com, desde Internet. Gracias a sus lectores electrónicos quienes
 descargan libros electrónicos (e-Books) en pocos segundos, estas dos punto.com están acrecentando su dominio del
 negocio de venta de libros en forma vertiginosa. Y las cifras son elocuentes: por cada tres libros vendidos y descargados
 por Internet sólo se vende un libro físico, y los primeros suelen costar 1/8 del precio del libro físico.
 Para Elizabeth Subercaseaux, escritora chilena radicada en Estados Unidos, uno de los factores claves de la quiebra de
 Borders fue la falta de adaptación a un escenario cada vez mas familiarizado con el e-Book y la venta on line: “Yo misma
 experimenté su falta de adecuación a las nuevas tecnologías” decía la escritora.
 No obstante lo anterior, "Internet no es un enemigo de la librería, sino que bien utilizada, es un aliado", comentaba un
 conocido analista del sector. Y agregaba: "No sólo para que el librero pueda vender libros tradicionales a través de la
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 150

[pág. 151]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2012 | pregunta 2
 Convocatoria 1 | página original 91 | Cinco fuerzas y adaptación estratégica
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 web, sino también para comunicar las novedades a sus clientes y para armar grupos, blogs y comunidades con el fin de
 fidelizar al público".
 En Chile, la convergencia entre las librerías e internet aún está en pañales. Sólo es cosa de “googlear” las tiendas
 emblemáticas para constatarlo, ya que son pocas las que ofrecen ventas online y algunas ni siquiera tienen una página
 web para revisar el catálogo. Entre las que sí se han adaptado, está Antártica, que tiene un sitio web que cuenta con
 información actualizada con frecuencia, recibe un millón de visitas mensuales, y en el cual se puede comprar en línea.
 Las transacciones a través de su sitio representan hoy un 5% del total de ventas de Antártica, con un crecimiento del
 orden del 20% cada año. En el último año, las ventas por internet en Antártica han crecido un 22% respecto a igual
 período del año anterior. Similares pasos está siguiendo la Feria Chilena del Libro, aunque con algún desfase.
 ¿El fin de los Libreros Tradicionales?. Algunas interrogantes para el futuro
 “Aunque están amenazados, el lector siempre buscará la librería y al librero”. Esa fue una de las tantas conclusiones del
 XXI Congreso Nacional de Libreros Españoles, que estuvo dominado por un ambiente de escepticismo por el futuro. Y
 nada de raro, ya que para muchos el librero es uno de los eslabones más débiles dentro de la cadena literaria.
 Con las ventas virtuales en aumento, lo único claro es que los cambios se han apoderado de esta industria, y
 probablemente lo seguirán haciendo. Lo cierto es que los cambios que se han producido han generado una oferta de libros
 que tiende al infinito, y una demanda cada vez mas atomizada, compleja y diversa. Tal vez el congeniar oferta y
 demanda, constituye uno de los principales desafíos para este sector. Otras interrogantes que se abren a futuro son: ¿Qué
 tipo de industria tendremos?. ¿Cuál será el rol de los libreros? ¿Desaparecerán?. La respuesta a esta última interrogante
 parece clara: o se adaptan o desaparecerán.
 A usted se le pide responder:
 Suponga el caso de un competidor tradicional (en Chile o en cualquier otro país del mundo) en el negocio de las librerías
 (librero tradicional), que ante el nuevo escenario competitivo que se presenta en la industria, está buscando para su
 negocio una forma atractiva de competir, que no le signifique abandonar su actual modelo de negocio tradicional. En
 relación con lo anterior responda las siguientes preguntas:
 Al final del caso se señala con respecto a los libreros tradicionales: “o se adaptan o desaparecerán”.
 1. Desde un punto de vista estratégico, ¿qué significa adaptarse?.
 2. Para un librero tradicional, ¿es posible y/o coherente la idea de adaptarse si éste busca competir en el nuevo
 escenario que se presenta en la industria sin abandonar el modelo de negocio tradicional?. ¿Por qué Si o por qué
 No?. Argumente su posición desde un punto de vista conceptual. Complemente su respuesta señalando un curso o
 alternativa de acción que ejemplifique su posición anterior.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 151

[pág. 152]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2011 | pregunta 2
 Convocatoria 2 | página original 75 | Cinco fuerzas y captura de valor
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº 2
 Un conocido banco de inversión acaba de recibir la solicitud de un cliente de valorizar un negocio potencial, que en
 palabras del cliente, podría ser una verdadera mina de oro. El cliente, un agricultor del Sur de nuestro país, posee un
 manantial de agua mineral, con un potencial para generar hasta 40 litros por segundo de este producto. El agua obtenida
 posee alto contenido de calcio y potasio, pero menos sodio que las aguas minerales hoy establecidas en el mercado,
 siendo ambas características o atributos deseables por el cliente.
 El Agua Mineral
 El agua cumple varias funciones, y es considerado un elemento fundamental para la vida. Si el agua es mineral, tanto
 mejor, por cuanto aporta minerales que hacen la vida más saludable, en particular calcio, potasio y sodio. Sin embargo, el
 exceso de algunos de ellos puede provocar problemas a la salud, como es el caso del sodio, cuyo consumo en altas
 cantidades puede producir alta presión arterial.
 Un agua mineral se considera “natural”, si ella es extraída de yacimientos subterráneos que brotan en un manantial. Lo
 “natural” de un agua mineral, es un atributo valorado por los consumidores.
 El Mercado de Aguas Minerales en Chile
 En Chile existen en la actualidad alrededor de 270 fuentes subterráneas que brotan en manantiales, y la mayoría de ellos
 no han sido explotados para el consumo de la población y su propiedad se encuentra altamente concentrada en dos
 compañías que son los principales actores en este mercado. En relación con este último punto, en el país existen dos
 marcas principales en el mercado de las aguas minerales, una propiedad de CCU y otra de Coca Cola. Vital, es la
 segunda marca en el mercado con un 14,5% de participación en el mercado nacional de aguas (minerales y purificadas),
 mientras que Cachantún lidera la industria con un 43,1% de participación1. El resto del mercado se distribuye en una
 serie de pequeñas marcas de nicho y de aguas minerales Premium que no alcanzan un nivel significativo de participación
 en el negocio. A nivel internacional, existen diversas marcas de aguas minerales de prestigio, no presentes en Chile, como
 por ejemplo las francesas “Perrier” y “Evian”, y otras de distintos países.
 Así como es valorado lo natural del agua, también lo es la marca con la que ella se comercializa. Esto genera una ventaja
 en el mercado para la dos marcas que en la actualidad lo dominan.
 En cuanto a expectativas de crecimiento del mercado de aguas minerales, los antecedentes muestran condiciones
 atractivas. En efecto, el consumo percápita en el país de agua mineral embotellada alcanza los 13 litros al año, versus los
 130 litros percápita de consumo de bebidas. Lo anterior muestra el alto potencialidad de crecimiento del sector del agua
 mineral en Chile. A lo anterior también contribuye la tendencia a una vida más sana y por tanto la consciencia por el
 consumo de productos sanos y saludables.
 1 En el mercado existen, además de las minerales, también las aguas purificadas, que no son minerales, y en donde el
 líder es Benedictino con un 14,1% de participación considerando el mercado total de las aguas, es decir, el mercado de
 las aguas minerales más el de las aguas purificadas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 152

[pág. 153]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2011 | pregunta 2
 Convocatoria 2 | página original 76 | Cinco fuerzas y captura de valor
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 La red de distribución es un factor fundamental para el éxito de una empresa en esta industria. El canal de distribución
 por excelencia son los supermercados, que concentran el 65% de las ventas del país. El 35% restante se reparte en una
 serie de botillerías y otros canales tradicionales como tiendas de conveniencia, entre otras.
 El Manantial en el Sur de Chile
 El manantial que es propiedad del agricultor, se estima que posee un potencial de 40 litros por segundo. Son más de 2
 hectáreas de aguas minerales que no han sido explotadas. Es un manantial considerado de muy buena calidad, por cuanto
 genera agua mineral con alto contenido de calcio y potasio, y con menos sodio que las aguas minerales que actualmente
 se comercializan, y que cumple con el marco legal que rige a la industria. Además cuenta con permisos de
 comercialización vigentes.
 La reunión con el Banco de Inversión
 En el día y hora señalada, llega el agricultor acompañado de un viejo amigo de infancia, hoy profesional egresado de una
 escuela de negocios, para que lo asesore en la reunión en la que el banco de inversión le informará de la conclusión a la
 que ha llegado, con respecto de la valorización de su negocio potencial.
 El representante del banco de inversión, una vez realizada la presentación a su cliente, le comenta: “Después de
 realizar la valoración correspondiente, nuestra conclusión es que la venta del manantial a una de las dos marcas
 principales del mercado, es un proyecto que puede aumentar de manera significativa su riqueza (la del agricultor), es
 decir, el VAN o VPN del proyecto de vender el manantial a una de las dos marcas principales del mercado, sería de
 un monto significativo”.
 No parecía muy convencido el amigo del agricultor con lo que escuchaba por parte del banco de inversión.
 Inmediatamente comentó, dirigiéndose al representante del banco de inversión: “Mi conclusión es casi la contraria.
 Después de escuchar la presentación, estimo que el VAN o VPN para mi amigo agricultor, del proyecto de vender el
 manantial a una de las dos marcas principales del mercado, debiera ser cercano a $0 ($ cero)”.
 Preguntas:
 1. Sabiendo que el resultado de una estrategia y VAN (VPN) que es capaz de generar la misma, en el fondo son
 conceptos que pueden ser vistos como las dos caras de una misma moneda, y considerando únicamente la
 información disponible en la pregunta, ¿qué posición o conclusión le parece a usted más razonable o consistente a
 partir de la información disponible? ¿la del banco de inversión o la del amigo del agricultor?. Argumente con
 precisión.
 2. Suponga ahora que la propiedad de las 270 fuentes subterráneas (no explotadas) que brotan en manantiales está
 ampliamente dispersa entre distintos agricultores, ¿Cambiaría su respuesta a la pregunta anterior? ¿Por qué SI o
 por qué NO?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 153

[pág. 154]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2017 | pregunta 4
 Convocatoria 1 | página original 232 | Coherencia estratégica y VRIO
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N” 4
 Vodafone, líder mundial en el negocio de telefonía móvil, ha declarado públicamente que su meta en el corto
 plazo apunta a ser el número 1 0 2 mundial en número de clientes, en cada uno de los 26 países en donde
 actualmente opera.
 "No es realmente por ser el líder”, dijo el CEO de la compañía, Vittorio Colao, a los analistas el mes pasado.
 La verdadera razón que moviliza en este sentido a Colao, según se desprende del mensaje transmitido por él a
 los analistas, es “el convencimiento de que sólo aquel competidor que ocupe el primer o segundo lugar en el
 mercado en número de clientes, sin importar si se es el primero o segundo, puede lograr una diferenciación
 efectiva por medio de la instalación de redes 1 y altas velocidades en la transmisión y recepción de información
 y datos”. De esta forma, “concentrándose en inversiones en estas dos aéreas (redes y mayor velocidad), los
 operadores líderes pueden justificar precios mayores y tener portafolios más completos (telefonia móvil, fija,
 TV e internet) que ofrecer a sus clientes”.
 Adquiriendo Tamaño
 Después de una pérdida de $130 millones de dólares en 2014 por la venta de su filial Verizon Wireless, Vodafone
 logró generar un esquema de expansión global a gran escala, La compañía abandonó el mercado de
 consumidores de EE.UU. y centró sus inversiones en Europa y el resto del mundo.
 En los últimos dos años, Vodafone ha invertido cerca de $2.400 millones de dólares para expandir sus redes
 móviles de alta velocidad, pilar de su estrategia competitiva. Durante 2015 y 2016 invirtió una importante
 cantidad de recursos para la adquisición de los mayores operadores de Cable en Alemania y España, y sigue
 expandiendo su red de Cable e Internet para abordar otros mercados.
 Los Resultados de Vodafone y la Situación en India -
 Los resultados de Vodafone han sido mixtos: buenos resultados en parte de Europa, pero con márgenes muy
 inferiores a los proyectados, los cuales son consecuencias de continuas guerras de precios, mayores costos y
 gastos de marketing que a menudo surgen como consecuencia de estar permanentemente defendiendo la posición
 de ser el número uno o dos de la industría.
 En esta misma línea, la situación que está experimentando Vodafone en India ha llamado la atención y
 despertado la inquietud de Vittorio Colao, En este país, Vodafone es la empresa número 2 en cuanto a clientes.
 Sin perjuicio de lo anterior, sus resultados se han visto seriamente castigados como consecu encia de la agresiva
 campaña comercial, de marketing y de precios que ha debido enfrentar por parte de un nuevo carrier de celnlares,
 que hace poco más de un año entró a competir en ese mercado. Se trata de la compañía “Reliance Jio Infocomm
 Líd.”, de propiedad del hombre más rico de India, cuya participación de mercado (medida en número de clientes)
 ha ido creciendo sistemáticamente en el último año. En efecto, con importantes inversiones en redes, precios
 muy agresivos, y un atractivo desarrollo de productos y servicios, este competidor ha ido ganando cada vez más
 clientes lo que lo posiciona como una de las empresas de mayor crecimiento en participación de mercado, más
 activas e innovadoras del mercado indio.
 1 Se entiende por redes, a la infraestructura (torres, antenas y otras) establecida por una compañía para la
 transmisión de las señales de comunicación. En la mayoría de los paises del mundo su instalación no está limitada
 y en ningún caso prohibida. Si bien existen regulaciones, ellas son simples y fáciles de cumplir para las empresas.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 154

[pág. 155]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2017 | pregunta 4
 Convocatoria 1 | página original 233 | Coherencia estratégica y VRIO
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTAS
 1. El CEO de Vodafone declara a los analistas del sector, de modo contundente, lo siguiente: “(7a estrategia
 competitiva elegida por Vodafone) se sustenta en el convencimiento de que sólo aquel competidor que
 ocupe el primer o segundo lugar en el mercado en número de clientes, sin importar si se es el primero o
 segundo, puede lograr una diferenciación efectiva por medio de la instalación de redes y la entrega de
 servicios superiores”. Según sus conocimientos de Estrategia Competitiva, ¿le parece conceptualmente
 coherente, conforme lo aprendido, lo declarado por el CEO de Vodafone? Responda si es coherente o no
 siendo preciso en su argumentación.
 El ser el maámero 1 0 2 en número de clientes en el mercado de Vodafone con el objeto de permitir ampliar
 las redes y tener un portafolio de productos amplio (telefonía móvil, fija, TV e internet) ¿es una ventaja
 competitiva? ¿Por qué si o por qué no? Justifique a la luz de algún modelo que conozca para determinar si
 algo es o no una Ventaja Competitiva.
 En relación a la estrategia competitiva que Vodafone desea construir, ¿Qué conclusiones puede obtener su
 CEO a partir de la experiencia que está viviendo en Indía, con respecto a la propia estrategia competitiva
 de Vodafone? Señale dos conclusiones que pueden obtenerse argumentándolas desde el punto de vista de
 sus conocimientos de estrategia.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 155

[pág. 156]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2014 | pregunta 4
 Convocatoria 2 | página original 154 | Cooperación sectorial y redes
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N 4
 En el año 2013, este juego perdió más de un millón de jugadores en el país del Norte.
 Recuperar los niveles que tenía hace diez años, parece difícil, pero aparecen luces de esperanza.
 Hace no mucho tiempo, el golf se consideraba una actividad elegida para establecer vínculos corporativos y el
 vehículo directo para verse exitoso. Sin embargo, hoy las compañías dependen menos de las “relaciones
 sociales”, y mucha gente joven ho se ve atraída por una actividad que se percibe como altamente consumidora
 de tiempo y muy elitista. El resultado de lo anterior se ha dejado ver en los últimos años: el golf ha sufrido, y
 está sufriendo aunque con alguna esperanza de mejoría, un éxodo de jugadores acompañado por el cierre de
 muchas canchas. En efecto, el número de golfistas hoy en día en Estados Unidos se estima en 23 millones de
 personas, un 24% menos del nivel que existía diez años atrás, de acuerdo con proyecciones de Pellucid, una
 compañía consultora especializada en el negocio del golf.
 ¿Qué puede explicar lo que ocurre en la industria? Son varios los factores: el juego es dificil cuando se desea
 jugar bien; requiere mucho tiempo para jugarse; y es un juego caro. A lo anterior se agrega los escándalos
 protagonizados por el principal jugador del mundo, lo que a juicio de algunos también pudo haber afectado el
 desarrollo de este deporte. Asimismo, la abultada tasa de construcción de canchas de golf en los años 90 llevó a
 un exceso de capacidad en la industria, lo que dejó a varios de los actores en una posición muy vulnerable.
 Sin embargo, no todas son malas noticias, y hay hechos que están generando alguna luz de optimismo en esta
 alicaída industria. En efecto, las inversiones en tecnología hechas por las principales empresas de la industria,
 están haciendo más sencillo jugar bien al golf, por la calidad muy superior que tienen en la actualidad los
 implementos claves de este deporte, como es el caso de los palos y las pelotas de golf. Por otro lado, varios
 jugadores jóvenes han logrado muy buenos resultados en el circuito, lo que ha ayudado a reencantar por lo
 menos a una parte de los jóvenes, con este deporte. El canal ESPN golf ha difundido ampliamente los
 principales torneos, atrayendo el interés por el golf a público que hasta ahora no ha mostrado mayor conexión
 con el deporte. Varios de los clubes de golf surgidos con el boom del deporte han desarrollado agresivas
 campañas de captura de socios, estableciendo así mismo acuerdos y convenios entre ellos, para facilitar y
 abaratar el costo del juego. Todo lo anterior, hace pensar a algunos que estaría comenzando un posible cambio
 - de tendencia en el sector, razón por la cual valdría la pena estar en esta industria y apostar por ella.
 Las preocupaciones de fondo
 Sin lugar a dudas la mayor preocupación de los analistas del sector y que los inquieta más que cualquier otro
 factor, es el cambio generacional que ha experimentado el mercado, y cómo las nuevas generaciones están
 respondiendo, fríamente y con cierto desinterés, ante el golf en Estados Unidos, El propio Jim Koopen,
 Presidente de Pellucid, comentaba en una entrevista aparecida el mes pasado: "Tenemos que encontrar una
 manera de contener la disminución de golfistas, partiendo por solucionar la tendencia en cuanto a que las
 nuevas generaciones no se están interesando en el golf; y no se ve que alguien esté haciendo algo para detener
 lo anterior”, terminaba diciendo.
 Reacciones de algunos actores
 Han sido varias y profundas las formas en cómo, diversas empresas, todas partícipes de esta industria, aunque
 no necesariamente competidoras entre sí, han reaccionado ante la difícil situación que se está experimentando en
 el mercado. A continuación, se exponen las reacciones de tres actores diferentes del sector.
 - Golf Technology: es una empresa especializada en implementos para el golf, líder en el mercado
 norteamericano, que cuenta con el 70% de participación en el mercado de implementos técnicos para el
 juego. Palos y pelotas de gran tecnología conforman el grueso de sus mix de oferta. Es reconocida como
 una empresa especializada, líder en innovación tecnológica aplicada a implementos para el golf. Su
 gerente general comentaba la semana pasada en una revista especializada: “Veinte meses atrás, vendia
 los palos de golf a un precio promedio de 850 dólares cada uno, mientras que hoy los mismos productos
 los vendemos a un precio promedio de 8350, menos de la mitad del precio de hace dos años”. El primer
 semestre de 2014 fue el quinto semestre consecutivo de descenso en las utilidades de la empresa, lo que
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 156

[pág. 157]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2014 | pregunta 4
 Convocatoria 2 | página original 155 | Cooperación sectorial y redes
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 acumula una caída de más del 40% en los últimos 3 años. El Directorio está cuestionando la permanencia
 de la empresa en el mercado y evaluando su cierre.
 Adidas: es una gran empresa diversificada en deportes, que participa activamente en el diseño,
 producción y comercialización de artículos de ropa y zapatos deportivos. Hace 5 años, Adidas compró
 una división de vestuario deportivo y zapatos de golf. Posee una oferta muy acotada y menor de
 implementos. La línea golf de Adidas representa en Estados Unidos el 5% de su EBITDA. En la última
 reunión de Directorio de Adidas, el Directorio quedó en un virtual acuerdo de reducir significativamente
 la inversión en la Unidad de Negocio de Golf.
 Clubes de Golf: en Estados Unidos existen principalmente de dos tipos: los clubes de golf privados, que
 son propiedad preferentemente de familias empresarias que están en el negocio inmobiliario, y que se
 abrieron como respuesta al explosivo crecimiento que experimentó el golf. Por otro lado están los Clubes
 de Golf Públicos, que son provistos por el Estado, quien ha dedicado terrenos exclusivos para fomentar la
 vida al aire libre que provee el golf. Los Clubes Públicos construidos han sido declarados zona protegida
 por el Estado, y no pueden destinarse a ningún otro fin distinto al del golf por los próximos 50 años.
 PREGUNTAS
 1) En los últimos meses se ha observado una tendencia a la colaboración o cooperación entre los diferentes
 actores (no necesariamente competidores) que participan en la industria del golf, con el objeto de reflotar
 este deporte. ¿Qué razones específicas pueden explicar esta conducta colaborativa? Señale dos razones
 debidamente argumentadas.
 2) En el caso se presentan cuatro actores diferentes en esta industria: Golf Technology, Adidas, Clubes de
 Golf Privados y Clubes de Golf Públicos. Haga un ranking, ordenando a estos actores, desde mayor a
 menor nivel de disposición, que cada uno ellos tendría para colaborar o cooperar con otros actores de la
 industria. Fundamente su respuesta
 3) ¿En qué aspectos específicos debiera haber colaboración entre los distintos actores para reflotar la
 industría del golf? Señale dos aspectos concretos argumentando en forma breve y precisa. ._
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 157

[pág. 158]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2020 | pregunta 5
 Convocatoria 2 | página original 325 | Diferenciación y sostenibilidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 PREGUNTA N° 5
 GRUPO PATIO Y LA OTRA UTILIDAD
 “En momentos de pandemia la vida nos ha puesto a todos en una posición difícilmente imaginable. Una
 de las grandes preguntas a hacerse desde las empresas es qué rol queremos jugar en estos tiempos.
 Porque si de algo estoy seguro es que por lo que hagamos hoy seremos medidos en el futuro”.
 Así comenzaba una entrevista en un diario de circulación nacional hace pocas semanas atrás, uno de los
 máximos directivos de Grupo Patio, cuando explicaba las bases de la estrategia de la empresa en tiempos de
 Covid, anclada en el concepto de “la otra utilidad”.
 Grupo Patio es un grupo empresarial chileno, que ofrece opciones y soluciones en diferentes mercados
 destinados al arriendo de inmuebles. Sus proyectos, ubicados en zonas estratégicas a lo largo del país y también
 en Perú, se caracterizan por la flexibilidad y conectividad de los edificios y por la preocupación por los detalles
 orientados a mejorar la calidad de vida de quienes los utilizan.
 En la actualidad, Grupo Patio cuenta con más de 200 empleados, posee más de 1.000 clientes (arrendatarios),
 y es propietario de 115 propiedades para arriendo (edificios e inmuebles) lo que totaliza casi 900.000 metros
 cuadrados de superficie arrendable. Opera 77 centros comerciales, 6 de los cuales están en Perú, y el resto en
 Chile.
 Los Negocios
 En Grupo Patio los negocios están organizados dependiendo del uso de los inmuebles en arriendo:
 - Patio Comercial: son 76 propiedades (locales comerciales de diferentes tamaños) en diferentes
 formatos en Chile y Perú. Son construcciones integradas a cada entorno, con soluciones para sus
 vecinos y apropiadas para grandes marcas y retailers. Cuentan con opciones de menor tamaño como
 strip centers.
 - Patio Residencial: edificios con diseños y servicios orientados a clientes arrendatarios. Se busca
 resolver de manera integral las necesidades de vivienda, ubicación y estilo de vida de personas y
 familias.
 - Patio Industrial: se orienta a la solución de problemas de espacio para distintas necesidades. Dirigido
 a empresas grandes o pymes, con desarrollos que se amoldan a distintas necesidades. Bodegas, mini
 bodegas, galpones, son parte de los activos de este negocio.
 - Patio Oficinas: orientado al mercado de empresas, ofrece opciones de oficinas en diferentes
 ubicaciones a lo largo de Chile.
 - Patio Financiero: busca obtener una buena rentabilidad para inversionistas interesados en el mercado
 inmobiliario. Ofrece proyectos inmobiliarios de la propia compañía a inversionistas. Se ofrece además
 asesoría para participar en fondos de inversión.
 La Otra Utilidad
 Hace algunas semanas Grupo Patio informó acerca de los elementos centrales de su nueva estrategia, la cual
 responde a la situación que actualmente enfrenta la economía, el país y sus clientes (empresas grandes,
 medianas y pequeñas, y personas). En efecto, Grupo Patio ha anunciado que implementará con sus clientes un
 paquete de beneficios con el objeto de avanzar en lo que denominan “la otra utilidad”, pensando en el beneficio
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 158

[pág. 159]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2020 | pregunta 5
 Convocatoria 2 | página original 326 | Diferenciación y sostenibilidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 de diferentes grupos de interés que se interrelacionan con Patio. El paquete de beneficios informado por Grupo
 Patio es el siguiente:
 - Suspensión temporal de rentas de arrendamiento en activos comerciales: desde el 18 de marzo de este
 año (inicio de la pandemia) se decidió suspender el cobro de rentas a 413 clientes Pyme (pequeñas y
 medianas empresas) de locales comerciales que no están pudiendo funcionar por disposición de la
 autoridad.
 - Apoyo en la obtención de créditos a tasa real de 0%: se consiguió que los clientes Pyme puedan
 postular a la obtención de créditos otorgados por una empresa especializada por un monto de hasta 10
 millones de pesos con tasa de interés real de 0%, sin comisión y con 3 meses de gracia.
 - Asesoría legal, financiera, emocional y mentoría: se está entregando asesoría legal y financiera para
 que los clientes que lo requieran puedan acceder a los beneficios y programas del Estado. Se
 implementó un equipo asesor compuesto por profesionales especializados en distintas disciplinas sin
 costo para los clientes. Esto incluye mentoría para entregar orientación en el manejo de sus negocios
 en este complejo momento, así como coaching emocional para contener y apoyar a los clientes.
 - Cero despidos y no uso de la ley de protección de empleo: se asumió el compromiso de no desvincular
 a ningún colaborador para ahorrar costos, ni tampoco ocupar la ley de protección de empleo impulsada
 por el gobierno.
 - Compromisos salariales: se tomó la decisión de mantener todos los compromisos salariales adoptados
 con los colaboradores. Esto incluye no rebajar el sueldo a nadie y conservar todo lo acordado con cada
 uno de ellos.
 Las Reacciones
 No se hicieron esperar y fueron variadas. La que destacó fue la reacción de un connotado periodista económico
 y asiduo comentarista en temas de negocios: “Es curioso esto de “la otra utilidad” de Grupo Patio,… suena
 más a campaña de marketing para hacerse publicidad que otra cosa. Si no fuera sólo marketing, sería razón
 más que suficiente para no invertir (como accionista) en esta empresa, ya que la destrucción de valor sería
 significativa para una empresa arrendadora de espacios e inmuebles, cuya razón de ser fundamental debe ser
 cuidar la generación de valor”.
 PREGUNTAS
 1. Suponga que “La Otra Utilidad”, constituye efectivamente el pilar fundamental sobre el cual Grupo Patio
 desea anclar su estrategia. En este contexto, y considerando la esencia de una estrategia competitiva, ¿es
 correcta la conclusión del periodista en el sentido de calificar el planteamiento estratégico de la empresa
 como destructor de valor? ¿Por qué sí o por qué no? Entregue tres razones que avalen su respuesta.
 2. Desde el punto de vista de la posición competitiva de Grupo Patio en su industria, la estrategia competitiva
 anclada en “La Otra Utilidad”, ¿mejora, es neutra o empeora la posición competitiva que la empresa
 mantenía en su industria antes de comenzar la implementación de la misma? En su respuesta señale tres
 posibles razones que sustenten la opción seleccionada. (No es necesario que describa la posición
 competitiva actual, sino que piense en términos de variación en ella, independientemente desde dónde se
 parta).
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 159

[pág. 160]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2022 | pregunta 4
 Convocatoria 2 | página original 370 | Efectos de red y ecosistema
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 PREGUNTA Nº4
 Google es mucho más que un buscador. Es una empresa que compite en diferentes ámbitos y que enfrenta
 diversos competidores de la talla de Microsoft, Apple, Yahoo y Amazon, dependiendo del servicio o producto
 del que estemos hablando. Sus resultados netos al cierre del 2021 superaron los 40 mil millones de dólares, un
 18% superior al 2020. Lo anterior se explica por la alta demanda por sus servicios en un escenario aun de
 pandemia, y la mejora de ingresos en varios de los segmentos de negocio en donde compite.
 El negocio de Google
 La compañía se hizo mundialmente conocida por su famoso buscador de internet (o Google Search), siendo hoy
 en día el principal buscador del mundo (participación de mercado de 92%). La compañía además cuenta con
 una sorprendente lista de servicios, y en algunos casos negocios, con diferentes características y funcionalidades,
 algunos de los cuales van dirigidos a personas y otros a empresas. Además del buscador, Google cuenta con
 Youtube, Google Drive, Google Cloud, Gmail y Google maps entre otros.
 Las fuentes de ingresos de Google
 Los principales ingresos de la compañía provienen de la venta de publicidad digital a empresas, que facturó 149
 mil millones de dólares en 2021. La publicidad se realiza directamente en el buscador o en los videos de
 Youtube. Otra fuente importante de ingresos es Google Cloud que entrega servicios a personas y a empresas.
 El servicio dirigido a personas entrega almacenamiento gratuito en la nube hasta cierta cantidad de GB, debiendo
 pagar para almacenamientos superiores. Para empresas, el servicio es más sofisticado ya que ofrece servidores
 remotos, seguridad informática y servicios de tecnología en la nube como el “Análisis de Datos de Personas y
 Consumidores”, que entrega información procesada de clientes y conductas de compra de consumidores
 digitales. Desde luego, mientras más usuarios existan en el sistema Google, mayor valor tendrá la información
 que se entrega. También se generan ingresos con Soluciones creadas para smartphones, tabletas, laptops, y con
 Google Playstore, que provee de juegos y entretenciones, gratis en niveles básicos y con un cobro en niveles
 más sofisticados. Finalmente, están los contenidos premium en Youtube, que permite disfrutar de videos sin
 interrupción de publicidad a cambio de un pago de US$11 por mes.
 El Modelo de Negocio de Google
 Se basa en dos aspectos fundamentales: por un lado el buscador, que organiza la información con su algoritmo,
 de forma rápida y precisa, generando información útil para quien la solicita y accediendo a un número de páginas
 web muy superiores en relación a otros buscadores. Este conjunto de atributos lo transforma en el mejor
 buscador del mundo. El segundo aspecto fundamental de su modelo de negocio, es la plataforma de publicidad
 que ofrece para una importante cartera de anunciantes, lo que le permite a Google financiar inversiones y
 mejoras al buscador y su plataforma de productos, solventar la gratuidad que se entrega a los usuarios y generar
 ingresos para el negocio.
 Los dos aspectos anteriores requieren de un complemento que resulta fundamental para la generación de valor
 en el negocio de Google: el desarrollo comercial, de productos y de servicios. En efecto, la generación continua
 y creativa de productos y servicios incentivan al mayor uso del buscador, y al mismo tiempo hace que más
 personas lo quieran utilizar. Por tal motivo, la compañía invierte en desarrollar aplicaciones, soluciones e
 infraestructura tecnológica, gratuitamente hasta cierto nivel de servicio, mejorando la experiencia del usuario
 con Google y facilitando que quienes utilicen Google se multipliquen día a día.
 La Innovación en Google
 No cabe duda que la innovación es importante en Google, aunque los realmente importante son quienes la
 realizan: los propios empleados de Google o en el lenguaje interno de la compañía, los “Googlers”. Según el
 presidente de Google, la compañía contrata a los “mejores del mundo, gente inteligente, original y creativa”.
 En los procesos de selección están presentes los futuros compañeros y jefes, y así se ven otros puntos de vista.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 160

# Manual de Direccion · parte 1 (páginas 1-57)

Fuente: 03_MANUAL_ULTIMATE_DIRECCION_EDG_2027_V2_REORDENADO

[pág. 1]
Dirección - versión clara y reordenada
 Dirección manual definitivo
 V2
 Dirección de Personas profundizada, Estrategia ordenada,
 integración, casos, preguntas y respuestas
 Examen de Grado de Ingeniería Comercial UC · preparación 2027
 Esta versión conserva los documentos anteriores y corrige la legibilidad y el orden. La estructura de
 estudio es materia → preguntas → respuestas.
Examen de Grado UC | materia, preguntas y respuestas 1

[pág. 2]
Dirección - versión clara y reordenada
 Índice con páginas del documento
 TABLERO CUANTITATIVO DE DIRECCIÓN DE PERSONAS 13
 Materia: Dirección - recorrido único y ordenado para Distinción 16
 Cómo está construido el aprendizaje . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 16
 Mapa mental de Dirección de Personas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 16
 Mapa mental de Dirección de Empresas y Estrategia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 16
 PARTE I - DIRECCIÓN DE PERSONAS: FUNDAMENTOS Y SISTEMA COMPLETO 17
 II. Dirección de Personas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 17
 1. Alineamiento estratégico y arquitectura de personas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 17
 2. Diseño de cargos, dotación y selección . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 17
 3. Desempeño, feedback y desarrollo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 18
 4. Compensación e incentivos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 18
 5. Cultura, liderazgo, equipos y cambio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 18
 6. Relaciones laborales, bienestar y seguridad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 18
 Indicadores de Personas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 19
 Respuesta a casos de personas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 19
 Dirección de Personas desde cero: diagnosticar, diseñar e implementar . . . . . . . . . . . . . . . . . . . . 19
 1. Personas como parte del sistema estratégico: AMO y señales de las prácticas . . . . . . . . . . . . . . . 19
 2. Motivación, contrato psicológico y justicia organizacional . . . . . . . . . . . . . . . . . . . . . . . . . . . 20
 3. Diseño del trabajo, autonomía, coordinación y dotación . . . . . . . . . . . . . . . . . . . . . . . . . . . 22
 4. Reclutamiento, selección válida y socialización . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 23
 5. Desempeño, competencias, indicadores y retroalimentación . . . . . . . . . . . . . . . . . . . . . . . . . 24
 6. Compensación total e incentivos: esfuerzo, riesgo y cooperación . . . . . . . . . . . . . . . . . . . . . . 26
 7. Formación, transferencia, talento y carrera . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 27
Examen de Grado UC | materia, preguntas y respuestas 2

[pág. 3]
Dirección - versión clara y reordenada
 8. Clima, cultura, liderazgo, diversidad y relaciones laborales . . . . . . . . . . . . . . . . . . . . . . . . . . 28
 9. Continuidad, salidas y aprendizaje del sistema . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 30
 Profundización aplicada de Dirección de Personas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 30
 P3. Arquitectura de empleo, capital humano y dotación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 30
 P4. Reclutamiento, selección, validez y entrevista aplicada . . . . . . . . . . . . . . . . . . . . . . . . . . . 31
 P5. Socialización, desempeño y transferencia de formación . . . . . . . . . . . . . . . . . . . . . . . . . . . 32
 P6. Salarios, bandas, incentivos y comportamientos no deseados . . . . . . . . . . . . . . . . . . . . . . . 33
 P7. Carrera, sucesión, anclas y capital psicológico . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 35
 P8. Cultura, clima, liderazgo y coordinación relacional . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 35
 P9. Relaciones laborales, seguridad, disciplina y salidas . . . . . . . . . . . . . . . . . . . . . . . . . . . . 37
 P10. Responder un caso integrando diagnóstico y decisión . . . . . . . . . . . . . . . . . . . . . . . . . . . 37
 PARTE II - DIRECCIÓN DE EMPRESAS Y ESTRATEGIA 39
 I. Dirección de Empresas y Estrategia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 39
 1. Propósito, diagnóstico y ventaja competitiva . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 39
 2. Modelo de negocio y creación/captura de valor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 39
 3. Crecimiento, diversificación, integración y alianzas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 39
 4. Cambio competitivo, imitación y entrada . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 40
 5. Implementación, estructura y control . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 40
 Plantilla de recomendación estratégica . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 40
 Dirección de Empresas y Estrategia desde cero . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 41
 1. La estrategia como un sistema de decisiones y una hipótesis de valor . . . . . . . . . . . . . . . . . . . . 41
 2. Creación, captura, distribución y medición del valor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 42
 3. Estructura competitiva: analizar mecanismos, actores y mercado relevante . . . . . . . . . . . . . . . . . 44
 4. Dinámica competitiva, compromisos y teoría de juegos . . . . . . . . . . . . . . . . . . . . . . . . . . . . 45
 5. Cadena de valor, recursos, capacidades y sostenibilidad . . . . . . . . . . . . . . . . . . . . . . . . . . . 46
Examen de Grado UC | materia, preguntas y respuestas 3

[pág. 4]
Dirección - versión clara y reordenada
 6. Modelos de negocio, plataformas y cambios de la propuesta . . . . . . . . . . . . . . . . . . . . . . . . . 48
 7. Límites de la empresa: integración, outsourcing, alianzas y adquisiciones . . . . . . . . . . . . . . . . . . 49
 8. Estrategia corporativa, portafolio, implementación y control . . . . . . . . . . . . . . . . . . . . . . . . . . 50
 Validez incremental: cuándo una prueba adicional agrega información . . . . . . . . . . . . . . . . . . . . . 52
 CAGE y expansión internacional . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 52
 Profundización causal de Estrategia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 52
 Dirección de Empresas y Estrategia: mecanismos que completan el aprendizaje . . . . . . . . . . . . . . . . 52
 E1. Empresa como sistema, contingencia y compromisos estratégicos . . . . . . . . . . . . . . . . . . . . . 52
 E2. Valor económico, valor agregado y reparto entre participantes . . . . . . . . . . . . . . . . . . . . . . . 53
 E3. Industria, grupos estratégicos y respuesta competitiva . . . . . . . . . . . . . . . . . . . . . . . . . . . 54
 E4. Costos, recursos y cuatro amenazas a la sustentación . . . . . . . . . . . . . . . . . . . . . . . . . . . 55
 E5. Modelo de negocio, ventaja corporativa y límites del crecimiento . . . . . . . . . . . . . . . . . . . . . . 57
 E6. Implementación: mapa, agenda y estructura posible . . . . . . . . . . . . . . . . . . . . . . . . . . . . 58
 E7. Ética prudencial, responsabilidad social y límites de la evidencia . . . . . . . . . . . . . . . . . . . . . . 59
 PARTE III - INTEGRACIÓN ENTRE ESTRATEGIA Y PERSONAS 63
 Taller de aplicación: diagnóstico, elección e implementación . . . . . . . . . . . . . . . . . . . . . . . . . . 63
 Caso 1. Amenaza de un competidor de bajo costo . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 63
 Caso 2. Crecimiento a un negocio cercano . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 63
 Caso 3. Plataforma de dos lados . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 64
 Caso 4. Elegir entre diseñar internamente o externalizar . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 64
 Caso 5. Diagnosticar rotación y desempeño . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 64
 Caso 6. Incentivo que aumentó volumen y dañó calidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 65
 Caso 7. Selección para una nueva operación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 65
 Caso 8. Implementar una transformación digital . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 65
 Comparación de marcos sin convertirlos en listas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 66
 Guion de respuesta oral para alcanzar Distinción . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 66
Examen de Grado UC | materia, preguntas y respuestas 4

[pág. 5]
Dirección - versión clara y reordenada
 PARTE IV - TALLERES Y CASOS ANTES DEL BANCO HISTÓRICO 67
 Casos trabajados: integrar evidencia, mecanismo y decisión . . . . . . . . . . . . . . . . . . . . . . . . . . 67
 Caso de reconversión de una empresa constructora . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 67
 Caso de transición de multitienda ante comercio digital . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 67
 Caso de incentivos para gerentes de local . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 68
 Comparar marcos sin “recitar modelos” . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 68
 Ética, empleo y gobernanza de datos . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 69
 Cierre del método de respuesta . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 69
 Fuentes y trazabilidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 69
 PARTE DE PRÁCTICA - 70 preguntas históricas 70
 Dirección de Personas - 35 preguntas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 70
 enero 2012 - pregunta 4 - Alineamiento de prácticas con servicio . . . . . . . . . . . . . . . . . . . . . . . . . . . 71
 enero 2017 - pregunta 2 - Autonomía e innovación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 73
 enero 2013 - pregunta 2 - Bono de retiro y relaciones laborales . . . . . . . . . . . . . . . . . . . . . . . . . . . . 75
 agosto 2023 - pregunta 2 - Comisiones y relación de largo plazo . . . . . . . . . . . . . . . . . . . . . . . . . . . 77
 agosto 2022 - pregunta 2 - Contrato psicológico y servicio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 79
 agosto 2013 - pregunta 3 - Contrato temporal y calidad de servicio . . . . . . . . . . . . . . . . . . . . . . . . . . 81
 agosto 2017 - pregunta 2 - Cultura tóxica y sistema de personas . . . . . . . . . . . . . . . . . . . . . . . . . . . 82
 agosto 2021 - pregunta 5 - Desempeño y cambio estratégico . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 84
 enero 2024 - pregunta 2 - Diversidad e inclusión . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 86
 marzo 2009 - pregunta 4 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 88
 agosto 2009 - pregunta 4 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 90
 marzo 2010 - pregunta 4 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 92
 agosto 2010 - pregunta 4 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 94
 agosto 2024 - pregunta 6 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 96
 agosto 2025 - pregunta 3 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 98
Examen de Grado UC | materia, preguntas y respuestas 5

[pág. 6]
Dirección - versión clara y reordenada
 enero 2026 - pregunta 4 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 100
 enero 2025 - pregunta 2 - Evaluación de desempeño e incentivos . . . . . . . . . . . . . . . . . . . . . . . . . . 102
 agosto 2015 - pregunta 2 - Formalización y productividad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 104
 agosto 2012 - pregunta 2 - Gestión por competencias . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 106
 agosto 2016 - pregunta 2 - Incentivos estrechos versus amplios . . . . . . . . . . . . . . . . . . . . . . . . . . . 108
 enero 2020 - pregunta 2 - Incentivos grupales y justicia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 110
 agosto 2011 - pregunta 4 - Incentivos por procesos o resultados . . . . . . . . . . . . . . . . . . . . . . . . . . 112
 enero 2014 - pregunta 2 - Incentivos y selección alineados . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 114
 enero 2016 - pregunta 2 - Indicadores, incentivos y cultura . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 116
 enero 2021 - pregunta 2 - Motivación y sistema de evaluación . . . . . . . . . . . . . . . . . . . . . . . . . . . . 118
 enero 2022 - pregunta 2 - Perfil y entrevista estructurada . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 120
 enero 2015 - pregunta 2 - Reforma laboral y alineamiento . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 122
 agosto 2020 - pregunta 3 - Remuneración, selección y equidad . . . . . . . . . . . . . . . . . . . . . . . . . . . 124
 enero 2023 - pregunta 2 - Rotación y AMO . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 126
 agosto 2018 - pregunta 2 - Selección y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 128
 marzo 2011 - pregunta 4 - Selección, cultura y retención . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 130
 enero 2019 - pregunta 2 - Servicio, AMO y cultura . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 132
 enero 2018 - pregunta 2 - Sistema AMO y contrato . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 134
 agosto 2014 - pregunta 2 - Sistema completo de RR.HH. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 137
 agosto 2019 - pregunta 2 - Transformación digital y RR.HH. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 139
 Dirección de Empresas y Estrategia - 35 preguntas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 141
 agosto 2021 - pregunta 1 - Adquisición y diversificación relacionada . . . . . . . . . . . . . . . . . . . . . . . . 142
 enero 2021 - pregunta 4 - Adquisición y sinergias . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 144
 enero 2020 - pregunta 4 - Alianza/inversión y ventaja . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 146
 enero 2014 - pregunta 4 - Alianzas y ventaja sostenible . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 148
 enero 2012 - pregunta 2 - Cinco fuerzas y adaptación estratégica . . . . . . . . . . . . . . . . . . . . . . . . . . 150
 agosto 2011 - pregunta 2 - Cinco fuerzas y captura de valor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 152
 enero 2017 - pregunta 4 - Coherencia estratégica y VRIO . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 154
Examen de Grado UC | materia, preguntas y respuestas 6

[pág. 7]
Dirección - versión clara y reordenada
 agosto 2014 - pregunta 4 - Cooperación sectorial y redes . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 156
 agosto 2020 - pregunta 5 - Diferenciación y sostenibilidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 158
 agosto 2022 - pregunta 4 - Efectos de red y ecosistema . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 160
 agosto 2012 - pregunta 4 - Entrada y reacción competitiva . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 162
 enero 2018 - pregunta 4 - Estrategia y diversificación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 164
 agosto 2015 - pregunta 4 - Evolución de estrategia y organización . . . . . . . . . . . . . . . . . . . . . . . . . 166
 enero 2015 - pregunta 4 - Guerra de precios en cloud . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 168
 enero 2024 - pregunta 4 - IA, cinco fuerzas y VRIO . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 170
 marzo 2009 - pregunta 2 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 172
 agosto 2009 - pregunta 2 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 174
 marzo 2010 - pregunta 2 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 176
 agosto 2010 - pregunta 2 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 178
 agosto 2024 - pregunta 2 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 180
 agosto 2025 - pregunta 2 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 182
 enero 2026 - pregunta 1 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 184
 enero 2019 - pregunta 4 - Integración Walmart-Cornershop . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 186
 enero 2023 - pregunta 4 - Integración vertical Toyota . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 188
 enero 2013 - pregunta 4 - Integración vertical/adquisición . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 190
 agosto 2016 - pregunta 4 - Integración y economías de alcance . . . . . . . . . . . . . . . . . . . . . . . . . . . 192
 agosto 2017 - pregunta 4 - M&A y sinergias . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 194
 agosto 2019 - pregunta 4 - Modelo de alianza/plataforma . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 196
 marzo 2011 - pregunta 2 - Modelo de negocio y ventaja competitiva . . . . . . . . . . . . . . . . . . . . . . . . . 198
 enero 2016 - pregunta 4 - Modelos productivos y ventaja . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 200
 agosto 2013 - pregunta 4 - Posicionamiento y eficiencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 202
 agosto 2023 - pregunta 4 - Sostenibilidad y modelo de negocio . . . . . . . . . . . . . . . . . . . . . . . . . . . 204
 enero 2025 - pregunta 3 - Transformación de industria y calidad estratégica . . . . . . . . . . . . . . . . . . . . 206
 enero 2022 - pregunta 4 - VRIO y diversificación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 208
Examen de Grado UC | materia, preguntas y respuestas 7

[pág. 8]
Dirección - versión clara y reordenada
 agosto 2018 - pregunta 4 - Ventaja de plataforma y respuesta . . . . . . . . . . . . . . . . . . . . . . . . . . . . 210
 PREGUNTAS ADICIONALES · DIRECCIÓN 212
 Pregunta D-U1 · Selección y validez incremental . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 212
 Pregunta D-U2 · CAGE y modo de entrada . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 212
 Pregunta D-U3 · Adquisición, cultura y captura de sinergias . . . . . . . . . . . . . . . . . . . . . . . . . . 212
 RESPUESTAS - soluciones completas 213
 Dirección de Personas . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 213
 enero 2012 - pregunta 4 - Alineamiento de prácticas con servicio . . . . . . . . . . . . . . . . . . . . . . . . . . 213
 enero 2017 - pregunta 2 - Autonomía e innovación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 213
 enero 2013 - pregunta 2 - Bono de retiro y relaciones laborales . . . . . . . . . . . . . . . . . . . . . . . . . . . 214
 agosto 2023 - pregunta 2 - Comisiones y relación de largo plazo . . . . . . . . . . . . . . . . . . . . . . . . . . 215
 agosto 2022 - pregunta 2 - Contrato psicológico y servicio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 216
 agosto 2013 - pregunta 3 - Contrato temporal y calidad de servicio . . . . . . . . . . . . . . . . . . . . . . . . . 217
 agosto 2017 - pregunta 2 - Cultura tóxica y sistema de personas . . . . . . . . . . . . . . . . . . . . . . . . . . 219
 agosto 2021 - pregunta 5 - Desempeño y cambio estratégico . . . . . . . . . . . . . . . . . . . . . . . . . . . . 219
 enero 2024 - pregunta 2 - Diversidad e inclusión . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 220
 marzo 2009 - pregunta 4 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 222
 agosto 2009 - pregunta 4 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 222
 marzo 2010 - pregunta 4 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 223
 agosto 2010 - pregunta 4 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 223
 agosto 2024 - pregunta 6 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 224
 agosto 2025 - pregunta 3 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 225
 enero 2026 - pregunta 4 - Estrategia y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 226
 enero 2025 - pregunta 2 - Evaluación de desempeño e incentivos . . . . . . . . . . . . . . . . . . . . . . . . . . 226
 agosto 2015 - pregunta 2 - Formalización y productividad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 228
 agosto 2012 - pregunta 2 - Gestión por competencias . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 229
Examen de Grado UC | materia, preguntas y respuestas 8

[pág. 9]
Dirección - versión clara y reordenada
 agosto 2016 - pregunta 2 - Incentivos estrechos versus amplios . . . . . . . . . . . . . . . . . . . . . . . . . . . 230
 enero 2020 - pregunta 2 - Incentivos grupales y justicia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 231
 agosto 2011 - pregunta 4 - Incentivos por procesos o resultados . . . . . . . . . . . . . . . . . . . . . . . . . . 232
 enero 2014 - pregunta 2 - Incentivos y selección alineados . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 233
 enero 2016 - pregunta 2 - Indicadores, incentivos y cultura . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 234
 enero 2021 - pregunta 2 - Motivación y sistema de evaluación . . . . . . . . . . . . . . . . . . . . . . . . . . . . 235
 enero 2022 - pregunta 2 - Perfil y entrevista estructurada . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 236
 enero 2015 - pregunta 2 - Reforma laboral y alineamiento . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 237
 agosto 2020 - pregunta 3 - Remuneración, selección y equidad . . . . . . . . . . . . . . . . . . . . . . . . . . . 239
 enero 2023 - pregunta 2 - Rotación y AMO . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 240
 agosto 2018 - pregunta 2 - Selección y ajuste . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 241
 marzo 2011 - pregunta 4 - Selección, cultura y retención . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 242
 enero 2019 - pregunta 2 - Servicio, AMO y cultura . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 242
 enero 2018 - pregunta 2 - Sistema AMO y contrato . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 243
 agosto 2014 - pregunta 2 - Sistema completo de RR.HH. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 244
 agosto 2019 - pregunta 2 - Transformación digital y RR.HH. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 245
 Dirección de Empresas y Estrategia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 246
 agosto 2021 - pregunta 1 - Adquisición y diversificación relacionada . . . . . . . . . . . . . . . . . . . . . . . . 246
 enero 2021 - pregunta 4 - Adquisición y sinergias . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 246
 enero 2020 - pregunta 4 - Alianza/inversión y ventaja . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 247
 enero 2014 - pregunta 4 - Alianzas y ventaja sostenible . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 248
 enero 2012 - pregunta 2 - Cinco fuerzas y adaptación estratégica . . . . . . . . . . . . . . . . . . . . . . . . . . 249
 agosto 2011 - pregunta 2 - Cinco fuerzas y captura de valor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 250
 enero 2017 - pregunta 4 - Coherencia estratégica y VRIO . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 251
 agosto 2014 - pregunta 4 - Cooperación sectorial y redes . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 251
 agosto 2020 - pregunta 5 - Diferenciación y sostenibilidad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 252
 agosto 2022 - pregunta 4 - Efectos de red y ecosistema . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 253
 agosto 2012 - pregunta 4 - Entrada y reacción competitiva . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 254
Examen de Grado UC | materia, preguntas y respuestas 9

[pág. 10]
Dirección - versión clara y reordenada
 enero 2018 - pregunta 4 - Estrategia y diversificación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 255
 agosto 2015 - pregunta 4 - Evolución de estrategia y organización . . . . . . . . . . . . . . . . . . . . . . . . . 256
 enero 2015 - pregunta 4 - Guerra de precios en cloud . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 256
 enero 2024 - pregunta 4 - IA, cinco fuerzas y VRIO . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 257
 marzo 2009 - pregunta 2 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 258
 agosto 2009 - pregunta 2 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 259
 marzo 2010 - pregunta 2 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 260
 agosto 2010 - pregunta 2 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 260
 agosto 2024 - pregunta 2 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 261
 agosto 2025 - pregunta 2 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 262
 enero 2026 - pregunta 1 - Industria/competencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 263
 enero 2019 - pregunta 4 - Integración Walmart-Cornershop . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 264
 enero 2023 - pregunta 4 - Integración vertical Toyota . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 265
 enero 2013 - pregunta 4 - Integración vertical/adquisición . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 266
 agosto 2016 - pregunta 4 - Integración y economías de alcance . . . . . . . . . . . . . . . . . . . . . . . . . . . 267
 agosto 2017 - pregunta 4 - M&A y sinergias . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 268
 agosto 2019 - pregunta 4 - Modelo de alianza/plataforma . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 269
 marzo 2011 - pregunta 2 - Modelo de negocio y ventaja competitiva . . . . . . . . . . . . . . . . . . . . . . . . . 269
 enero 2016 - pregunta 4 - Modelos productivos y ventaja . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 270
 agosto 2013 - pregunta 4 - Posicionamiento y eficiencia . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 271
 agosto 2023 - pregunta 4 - Sostenibilidad y modelo de negocio . . . . . . . . . . . . . . . . . . . . . . . . . . . 272
 enero 2025 - pregunta 3 - Transformación de industria y calidad estratégica . . . . . . . . . . . . . . . . . . . . 272
 enero 2022 - pregunta 4 - VRIO y diversificación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 274
 agosto 2018 - pregunta 4 - Ventaja de plataforma y respuesta . . . . . . . . . . . . . . . . . . . . . . . . . . . . 274
 RESPUESTAS DESARROLLADAS · DIRECCIÓN 276
 Respuesta D-U1 · Selección y validez incremental . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 276
 Respuesta D-U2 · CAGE y modo de entrada . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 276
Examen de Grado UC | materia, preguntas y respuestas 10

[pág. 11]
Dirección - versión clara y reordenada
 Respuesta D-U3 · Adquisición, cultura y captura de sinergias . . . . . . . . . . . . . . . . . . . . . . . . . 277
 CONTROL FINAL DE FUENTES · DIRECCIÓN 278
 Fuentes cruzadas en esta ampliación . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 278
 Archivos no utilizados . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 278
Examen de Grado UC | materia, preguntas y respuestas 11

[pág. 12]
Dirección - versión clara y reordenada
Examen de Grado UC | materia, preguntas y respuestas 12

[pág. 13]
Dirección - versión clara y reordenada
 TABLERO CUANTITATIVO DE DIRECCIÓN DE
 PERSONAS
 Las métricas ordenan evidencia; no reemplazan diagnóstico. Cada indicador exige población,
 período, denominador y fuente. La interpretación debe explicar qué conducta o mecanismo cambió
 y qué explicación alternativa sigue abierta.
 AMO: ordenar el diagnóstico
 Desempeño ≈ f(Habilidad, Motivación, Oportunidad)
 Qué responde. No es una multiplicación mecánica: recuerda que una barrera crítica puede anular las demás.
 Variables. Habilidad incluye conocimientos; motivación, dirección e intensidad del esfuerzo; oportunidad, recursos,
 autonomía e información.
 Procedimiento. Formula primero la conducta necesaria y busca evidencia en los tres componentes.
 Error típico. Usar AMO como lista de prácticas sin explicar qué mecanismo causa el resultado.
 Dotación equivalente
 FTE requeridos = Carga total de trabajo / Horas productivas por FTE
 Qué responde. Convierte demanda de tareas en capacidad necesaria.
 Variables. La carga y las horas productivas deben usar el mismo período e incorporar reuniones, pausas y
 ausencias una sola vez.
 Procedimiento. Calcula escenario promedio y picos; después añade restricciones de turnos y competencias.
 Error típico. Descontar ausencias dos veces o creer que FTE equivale siempre a número de personas.
 Ejemplo. 720 horas mensuales / 120 horas productivas = 6 FTE.
 Rotación
 Rotación (%) = Salidas del período / Dotación promedio del período ×
 100
 Qué responde. Cuantifica salidas respecto de la población expuesta.
 Variables. Declara voluntaria/involuntaria, población, período, traslados y cohorte.
 Procedimiento. Segmenta por antigüedad, jefe, rol y criticidad antes de atribuir causa.
 Error típico. Comparar tasas con denominadores distintos o asumir que toda salida es negativa.
Examen de Grado UC | materia, preguntas y respuestas 13

[pág. 14]
Dirección - versión clara y reordenada
 Ausentismo por tiempo
 Ausentismo (%) = Horas perdidas / Horas programadas × 100
 Qué responde. Mide capacidad programada que no estuvo disponible.
 Variables. Horas perdidas y programadas deben pertenecer a la misma población y período.
 Procedimiento. Distingue frecuencia, duración y causa; protege confidencialidad.
 Error típico. Usar número de personas ausentes cuando importa cuánto tiempo se perdió.
 Razón de selección
 Razón de selección = Personas contratadas / Personas candidatas
 elegibles
 Qué responde. Muestra cuán selectivo fue el proceso.
 Variables. Define qué cuenta como candidatura elegible y la etapa del embudo.
 Procedimiento. Combínala con calidad, equidad, tiempo y costo; una razón baja no garantiza validez.
 Error típico. Celebrar selectividad sin comprobar desempeño posterior.
 Rendimiento de una fuente
 Yield ratio = Candidatos que avanzan / Candidatos provenientes de la
 fuente
 Qué responde. Compara qué fuentes aportan personas que superan una etapa pertinente.
 Variables. El numerador puede ser entrevista, oferta o contratación; debe declararse.
 Procedimiento. Compara calidad y costo por cohorte, no solo volumen.
 Error típico. Cambiar la definición del numerador entre fuentes.
 Validez incremental
 Aporte incremental = Calidad predictiva con método nuevo - Calidad
 predictiva base
 Qué responde. Pregunta cuánto mejora la decisión al añadir una medida.
 Variables. Puede expresarse en ΔR², clasificación, utilidad o reducción de errores según el diseño.
 Procedimiento. Valida en una población pertinente, reserva datos y considera costo, acceso e impacto adverso.
 Error típico. Suponer que dos métodos válidos suman valor aunque midan casi lo mismo.
Examen de Grado UC | materia, preguntas y respuestas 14

[pág. 15]
Dirección - versión clara y reordenada
 Utilidad de selección
 ΔU ≈ N × T × rxy × SDy × Zx - N × C
 Qué responde. Aproxima beneficio económico de mejorar selección bajo supuestos explícitos.
 Variables. N es contrataciones; T, duración media; r_xy, validez; SD_y, variación monetaria de desempeño; Z_x,
 calidad media seleccionada; C, costo por evaluado o contratado según convención.
 Procedimiento. Declara unidades y convención; realiza sensibilidad porque varios parámetros son inciertos.
 Error típico. Copiar coeficientes como universales o confundir correlación con porcentaje de productividad.
 Compa-ratio
 Compa-ratio = Sueldo individual / Punto medio de la banda
 Qué responde. Ubica remuneración respecto del centro de su banda.
 Variables. La banda debe corresponder a cargo, mercado y fecha pertinentes.
 Procedimiento. Investiga experiencia, contribución, compresión y equidad antes de decidir.
 Error típico. Concluir injusticia solo porque el ratio es menor que 1.
 Ejemplo. $1.350.000 / $1.500.000 = 0,90.
 Posición dentro de la banda
 Posición = (Sueldo - Mínimo) / (Máximo - Mínimo)
 Qué responde. Muestra avance relativo entre mínimo y máximo de la banda.
 Variables. Todos los valores deben corresponder a la misma banda y fecha.
 Procedimiento. Úsala junto a compa-ratio, desempeño, experiencia y reglas de progresión.
 Error típico. Tratar 50% como punto medio salarial cuando la banda no es simétrica.
 Retorno de una intervención
 ROI (%) = (Beneficios monetarios - Costos) / Costos × 100
 Qué responde. Compara beneficio económico estimado con costo de una intervención.
 Variables. Incluye diseño, tiempo, tecnología, reemplazos y costos de implementación.
 Procedimiento. Primero demuestra aprendizaje, transferencia y atribución razonable; luego monetiza con rango.
 Error típico. Atribuir todo cambio posterior al curso o ignorar efectos sobre calidad y bienestar.
Examen de Grado UC | materia, preguntas y respuestas 15

[pág. 16]
Dirección - versión clara y reordenada
 Expectativas y motivación
 Fuerza motivacional ≈ Expectativa × Instrumentalidad × Valencia
 Qué responde. Recuerda que la cadena se debilita si una persona no cree poder rendir, no confía en la
 recompensa o no la valora.
 Variables. Expectativa: esfuerzo→desempeño; instrumentalidad: desempeño→resultado; valencia: valor del
 resultado.
 Procedimiento. Identifica el eslabón débil y modifica recursos, reglas o recompensas.
 Error típico. Multiplicar encuestas como si produjeran una medida exacta universal.
 Materia: Dirección - recorrido único y
 ordenado para Distinción
 Cómo está construido el aprendizaje
 El manual avanza una sola vez por cinco capas. Primero se aprende a diagnosticar el sistema de
 personas. Luego se profundizan sus decisiones: trabajo y dotación, empleo y talento, selección,
 desempeño, compensación, desarrollo, cultura, liderazgo y relaciones laborales. Después se
 estudia estrategia: valor, industria, recursos, modelo de negocio, límites de la empresa e
 implementación. La cuarta capa integra ambos ramos. La quinta aplica el método a casos antes de
 las preguntas históricas y las respuestas.
 Mapa mental de Dirección de Personas
 1. Resultado y conducta: qué resultado importa y qué conducta/capacidad lo produce. 2.
 Diagnóstico causal: habilidad, motivación y oportunidad; nivel individual, equipo, proceso o
 sistema. 3. Arquitectura: qué trabajo existe, cómo se coordina y qué relación de empleo lo
 sostiene. 4. Flujo de personas: atraer, seleccionar, socializar, desarrollar, evaluar, recompensar,
 retener y gestionar salidas. 5. Contexto social: justicia, liderazgo, clima, cultura, diversidad,
 seguridad y relaciones laborales. 6. Implementación: coherencia entre prácticas, responsables,
 secuencia, recursos, riesgos e indicadores.
 Una respuesta de Distinción no salta de un síntoma a una práctica. Expone hechos, formula
 hipótesis rivales, identifica el mecanismo, diseña un sistema coherente, explica trade-offs y propone
 evidencia para revisar la decisión.
 Mapa mental de Dirección de Empresas y Estrategia
 El orden es: propósito y unidad de análisis → creación y captura de valor → industria y competencia
 → recursos y actividades → modelo de negocio → crecimiento y límites → implementación y
 control. Los marcos se eligen por la pregunta que resuelven; nunca se recitan como listas.
Examen de Grado UC | materia, preguntas y respuestas 16

[pág. 17]
Dirección - versión clara y reordenada
 PARTE I - DIRECCIÓN DE PERSONAS:
 FUNDAMENTOS Y SISTEMA COMPLETO
 II. Dirección de Personas
 La dirección de personas conecta decisiones de talento, organización y relaciones laborales con la
 estrategia y la experiencia de trabajadores. Prácticas coherentes importan más que listas aisladas.
 Usa el ciclo atraer-seleccionar-desarrollar-evaluar-recompensar-retener, con resguardos de
 equidad, legalidad, bienestar y diversidad.
 1. Alineamiento estratégico y arquitectura de personas
 Profundización desde notas de estudiantes, no oficiales: material local de apoyo p.3 organiza
 selección, capacitación, desempeño, carrera, flexibilidad y compensaciones como palancas de
 gestión; distingue motivación intrínseca, extrínseca y afectiva y advierte riesgos de incentivos mal
 diseñados (conducta oportunista, problemas de equidad/justicia e individualismo). Usa estas listas
 como hipótesis para diagnosticar alineamiento y efectos, no como taxonomía exhaustiva. material
 local de apoyo p.3 aporta una respuesta manuscrita de Dirección de Personas · Examen de Grado
 UC, marzo 2011, convocatoria 1 · Pregunta 4 · páginas 64-65 (2011-1) sobre selección, cultura y
 retención; caligrafía y exactitud limitan su uso.
 Parte por objetivos del negocio y capacidades críticas. Deriva conductas y puestos que crean valor;
 luego elige prácticas que las habilitan. Una estrategia de innovación puede requerir aprendizaje,
 autonomía y tolerancia a experimentos; operación estandarizada puede requerir confiabilidad,
 seguridad y mejora continua. Hay que comprobar ajuste vertical (estrategia-personas) y horizontal
 (prácticas que no se contradicen).
 No confundas «alineamiento» con que toda persona obedezca una consigna. Explica mecanismo,
 condiciones de autonomía/control, recursos y efectos secundarios. Segmenta necesidades de
 talento por rol/escasez/impacto con criterios explícitos; evita etiquetar personas por intuición.
 2. Diseño de cargos, dotación y selección
 Análisis del cargo define tareas, resultados, competencias/conocimientos, contexto y autoridad.
 Especificación realista ayuda a seleccionar y evaluar, pero no conviertas rasgos vagos
 («proactivo») en filtro sin evidencia. Planificación de dotación combina demanda futura, oferta
 interna/externa, rotación, productividad y escenarios.
 Selección: define competencia relacionada con desempeño, usa métodos válidos y comparables
 (entrevista estructurada, muestra de trabajo, prueba pertinente), criterios antes de evaluar y registro
 consistente. Validez no elimina sesgo: revisa impacto adverso, accesibilidad, privacidad y
 necesidad del dato. Entrevista informal favorece halo, similitud y confirmación.
Examen de Grado UC | materia, preguntas y respuestas 17

[pág. 18]
Dirección - versión clara y reordenada
 3. Desempeño, feedback y desarrollo
 Gestiona objetivos claros, observables y controlables por el rol. Combina resultados y conductas;
 evita metas que invitan a gaming, atajos de calidad o competencia destructiva. Feedback oportuno
 describe situación-conducta-impacto y acuerda acción/apoyo. Una evaluación no sustituye
 conversación continua.
 Capacitación parte de brecha de habilidad y diagnóstico; aprendizaje requiere práctica, feedback,
 apoyo del jefe y oportunidad de aplicación. Evalúa reacción, aprendizaje, transferencia y resultado
 con contrafactual razonable cuando sea viable. No atribuyas mejoría a un curso si cambiaron
 simultáneamente incentivos, selección o demanda.
 Carrera/retención depende de oportunidades, jefatura, justicia, remuneración, flexibilidad, propósito
 y alternativas. Entrevistas de salida describen a quienes se van y tienen sesgo; contrástalas con
 encuestas de permanencia, movilidad, ausentismo y resultados por segmentos.
 4. Compensación e incentivos
 Compensación incluye salario fijo, variable, beneficios y elementos no financieros. La equidad
 interna compara valor relativo de cargos; la externa, mercado relevante; la individual, contribución y
 reglas. Diseña incentivos para resultados controlables, medibles, equilibrados y consistentes con
 horizonte/colaboración. Alta intensidad variable puede aumentar esfuerzo, pero también riesgo,
 manipulación, selección adversa, competencia interna y foco corto.
 Al evaluar un bono define fórmula, umbral, pendiente, tope, periodo, elegibilidad, calidad/seguridad
 guardarraíl y posibilidad de manipulación. Si ventas dependen de territorio, demanda y cooperación,
 compara cambios observados con grupo/periodo apropiado. Percepción de justicia procedimental y
 explicaciones afectan aceptación, no solo monto.
 5. Cultura, liderazgo, equipos y cambio
 Cultura son supuestos, normas y prácticas repetidas; se observa en decisiones, recompensas,
 rituales, voz y respuesta a errores. No es solo el conjunto de valores declarados. Liderazgo efectivo
 depende de tarea, equipo y contexto; delegación sin información/recursos es abandono, y control
 sin voz puede suprimir aprendizaje.
 En cambio organizacional identifica grupo afectado, pérdida percibida, coalición, capacidades,
 mensaje, participación y resultados tempranos. Diferencia resistencia por desacuerdo válido,
 incapacidad, incentivos incompatibles y falta de confianza. Comunicar más no corrige todas las
 causas. Protege continuidad operacional y carga de cambio.
 6. Relaciones laborales, bienestar y seguridad
 Analiza poder de negociación, intereses, reglas y cumplimiento; diseña canales de voz y manejo de
 conflictos antes de crisis. Indicadores de seguridad/bienestar incluyen incidentes, severidad,
 ausentismo, carga y percepción, interpretados junto con subreporte. Un desempeño promedio
 puede ocultar daño en un subgrupo; segmenta con privacidad y criterio.
Examen de Grado UC | materia, preguntas y respuestas 18

[pág. 19]
Dirección - versión clara y reordenada
 Indicadores de Personas
 Rotación voluntaria = salidas voluntarias / dotación promedio (define periodo y población). Tiempo
 para cubrir vacante, tasa de aceptación, ausentismo, brecha de competencias, movilidad y
 desempeño son útiles solo con denominador y cohorte claros. No uses costo por contratación para
 premiar selección de mala calidad. Equilibra productividad, experiencia, equidad, salud y
 cumplimiento.
 Respuesta a casos de personas
 1. Define resultado y grupo afectado; distingue síntoma (rotación) de mecanismo (jefatura, horario,
 pago, carga o ajuste). 2. Propón diagnóstico segmentado: registros + entrevistas/encuesta +
 observación pertinente. Triangula y protege confidencialidad. 3. Intervén sobre causa y entorno, no
 solo sobre individuos. Especifica cambio de práctica, responsable, recursos y riesgo. 4. Evalúa con
 línea base, comparación/cohorte cuando se pueda y métricas guardarraíl (equidad, seguridad,
 calidad, rotación no deseada).
 Dirección de Personas desde cero: diagnosticar, diseñar e
 implementar
 1. Personas como parte del sistema estratégico: AMO y señales
 de las prácticas
 Dirigir personas consiste en crear condiciones para que sus capacidades y acciones produzcan el
 resultado que la organización promete, respetando también su desarrollo y sus intereses. El
 propósito no se reduce a contratar, pagar y resolver conflictos. Una estrategia de innovación
 necesita aprendizaje y coordinación; una de servicio exige comprensión de necesidades y
 capacidad de responder; una de costos necesita productividad que preserve calidad y seguridad.
 Las políticas se eligen a partir del diagnóstico del negocio y del trabajo, y no como un paquete
 idéntico para toda empresa. Los materiales de Carlos Portales articulan alineación vertical -con la
 estrategia- y horizontal -entre prácticas-. (F0609, pp. 1-4; F0910, pp. 2-8; F0912, pp. 1-6).
 AMO ordena tres condiciones del desempeño: habilidades y conocimientos, motivación y
 oportunidades para actuar. «Saber, querer y poder» ayuda a diagnosticar por qué no ocurre una
 conducta esperada. Un trabajador puede conocer el proceso y querer servir bien, pero carecer de
 autorización, información o herramientas. Otro puede disponer de autonomía y motivación, pero no
 dominar la técnica. Ofrecer un bono ante una falla de capacitación o coordinación no remueve la
 restricción relevante. La fórmula no debe tratarse como una multiplicación numérica universal: es
 una lógica para buscar condiciones complementarias y cuellos de botella. (F0609, pp. 3 y 12;
 F0910, pp. 6, 21 y 26; F0912, p. 4).
 El análisis empieza en el resultado y retrocede. ¿Qué proceso produce la atención, precisión o
 innovación requerida? ¿Qué conductas son críticas? ¿Qué conocimiento, motivación y derechos
 permiten realizarlas? Se contrastan hipótesis con registros, observación y voz de empleados y
 clientes. Si los operarios atienden amablemente, pero una tecnología introduce fallas y largas
 esperas, atribuir falta de compromiso sin revisar formación, interfaces o capacidad es una
 conclusión sin evidencia. Capacitar puede resolver dominio; reorganizar el trabajo puede resolver
Examen de Grado UC | materia, preguntas y respuestas 19

[pág. 20]
Dirección - versión clara y reordenada
 interrupciones; un incentivo solo sirve si existe margen para cambiar el comportamiento y si se
 premia el resultado correcto.
 Bowen y Ostroff, citados en los resúmenes, enfatizan que las prácticas funcionan también como
 señales. Los trabajadores interpretan qué se espera y qué conducta recibe realmente
 reconocimiento. Declarar calidad mientras se paga solo volumen emite mensajes contradictorios.
 Una política clara en un documento puede ser aplicada de manera desigual por jefes, debilitando la
 interpretación común. Por eso importan comprensibilidad, consistencia y acuerdo de quienes
 diseñan y ejecutan. Se verifica si los empleados entienden la regla, si la experiencia coincide con
 ella y si varias prácticas apuntan al mismo objetivo. (F0609, p. 4; F0910, pp. 6 y 8; F0912, p. 5).
 La alineación horizontal exige enlaces concretos. Seleccionar para colaboración, asignar tareas
 interdependientes, formar en coordinación, evaluar contribución transversal y reconocer resultados
 compartidos es un sistema. Seleccionar para equipo y premiar un ranking individual excluyente
 puede hacer que el esfuerzo se concentre en impedir ayuda. «Más prácticas» no equivale a mejor
 sistema: prácticas redundantes consumen tiempo y prácticas incompatibles anulan efectos. La
 segmentación puede ser útil cuando cargos tienen competencias o relaciones con resultados
 distintas, pero debe mantener principios comprensibles de justicia y no crear jerarquías arbitrarias
 de dignidad. (F0609, pp. 3-6 y 30-31; F0910, pp. 4-6 y 40-41).
 Las teorías institucional y de recursos responden a preguntas complementarias. La primera ayuda a
 distinguir presiones regulatorias, profesionales y culturales, y a estudiar legitimidad o adopción
 ceremonial. Un programa de diversidad exhibido sin cambiar selección y promociones puede ser
 ceremonial. La perspectiva de recursos pregunta cómo conocimiento, relaciones y organización
 generan resultados difíciles de imitar. Una fuerza laboral valiosa no es automáticamente una
 ventaja: puede ser móvil, común entre rivales o mal coordinada. Se estudian aprendizaje, capital
 social, apropiación y condiciones que conservan la relación. No se conserva la afirmación local de
 que Porter o las fuerzas de mercado estén «obsoletos» porque importe el talento. (F0609, pp. 1-2;
 F0910, pp. 2-3; F0912, pp. 1-3).
 Un sistema de alto compromiso combina participación, información, desarrollo, trato justo y
 exigencia de resultados. Alto compromiso y alto desempeño están relacionados como hipótesis, no
 como equivalencia. Puede haber identificación con una empresa y baja productividad por tecnología
 o diseño; puede haber productividad de corto plazo obtenida con desgaste que destruya
 continuidad. La implementación debe medir capacidades, conductas, resultados y costos, además
 de satisfacción. Los porcentajes de tiempo de liderazgo o cantidades de bonos sugeridos en
 apuntes se tratan como ejemplos de diseño, no estándares universales. (F0609, pp. 6 y 29-31;
 F0910, pp. 5 y 15-16).
 2. Motivación, contrato psicológico y justicia organizacional
 La motivación dirige esfuerzo, intensidad y persistencia; la satisfacción es una evaluación de la
 experiencia; el compromiso expresa vínculo con trabajo u organización. Una persona satisfecha con
 un horario puede no hacer esfuerzo adicional; una persona comprometida puede sentirse
 insatisfecha con una decisión específica. Tampoco falta de satisfacción implica falta de capacidad.
 Separar los conceptos evita concluir que mejorar un índice de bienestar elevará productividad en
 una magnitud determinada. (F0609, pp. 5-6 y 29; F0910, pp. 14-15 y 38-39; caso 62 Segundos,
 fuente pp. 331-332).
Examen de Grado UC | materia, preguntas y respuestas 20

[pág. 21]
Dirección - versión clara y reordenada
 Los materiales distinguen motivos extrínsecos -ingreso, estatus o reconocimiento-, intrínsecos
 -aprendizaje, desafío y logro- y afectivos o trascendentes -pertenencia y efecto sobre otros-.
 Pueden coexistir, cambiar con el trabajo y variar entre personas. No se deduce la preferencia
 individual de la edad ni se justifica pagar menos a quien disfruta su profesión. La política busca un
 intercambio sostenible que respete necesidades, valor del trabajo y alternativas. Un salario justo no
 reemplaza aprendizaje; autonomía no compensa un trato degradante; beneficios no eliminan la
 necesidad de metas claras. (F0609, pp. 5-6; F0910, pp. 14 y 34; F0912, pp. 7-8; F0913, p. 2, con
 esta precisión).
 El contrato psicológico es la creencia sobre obligaciones y promesas de la relación. Se forma con
 anuncios, reclutamiento, acciones del jefe, ascensos y experiencias, no solo con lo escrito. Si se
 promete desarrollo y las promociones dependen de amistades, el incumplimiento percibido puede
 afectar confianza y permanencia. Se diagnostica qué se esperaba, cómo se generó la expectativa y
 cuál práctica real produjo la brecha. No se interpreta como una suma mecánica de motivaciones y
 políticas: la percepción del trabajador media esa relación. (F0609, pp. 5-6 y 11; F0910, pp. 14 y
 20-21; F0912, pp. 16-17).
 Herzberg distingue factores asociados al contenido del trabajo y factores del contexto que pueden
 generar insatisfacción. La distinción ayuda a recordar que responsabilidad, aprendizaje y
 reconocimiento no son lo mismo que condiciones básicas. No significa que el salario nunca motive
 ni que una buena condición pierda importancia al estar satisfecha. Tampoco se traslada su teoría a
 la preferencia del consumidor como si explicara una ventaja de producto. Las teorías de metas y
 características del cargo añaden claridad, desafío, autonomía, significado y retroalimentación; su
 efecto depende de capacidad, recursos y aceptación. Una meta exigente pero imposible puede
 inducir abandono o manipulación. (F0912, pp. 7-8; F0609, pp. 16-17).
 La justicia distributiva evalúa el reparto. Equidad por contribución, igualdad y necesidad son
 principios distintos que pueden ser adecuados para componentes distintos: un bono por resultados,
 una cobertura común o apoyo a una contingencia no necesitan la misma regla. La justicia
 procedimental examina voz, consistencia, información, supresión de sesgos y posibilidad de
 corregir. La justicia interpersonal exige dignidad; la informacional exige explicaciones adecuadas.
 Un resultado desfavorable puede ser aceptado mejor con un proceso comprensible, pero comunicar
 no vuelve justo un reparto efectivamente arbitrario. Primero se corrige la práctica injusta; después
 se explica. (F0910, pp. 7-8; F0912, pp. 34-35).
 Liz Taylor ofrece un diagnóstico concreto. La tabla válida de actuales y renunciados muestra bajo
 resultado en flexibilidad -1,8 y 2,0- y propósito -2,0 y 1,9-, mientras el resultado global es 2,8 y 2,9.
 No se puede afirmar que solo quienes salieron estaban descontentos ni inventar entrevistas de
 salida. Se prioriza examinar organización del trabajo, sentido y trato, junto con compensación. La
 rotación superior al retail orienta la necesidad de intervenir, pero la encuesta no identifica por sí sola
 una causa única de renuncia. (Liz Taylor, fuente pp. 366-367).
 62 Segundos permite distinguir evidencia aceptada de extrapolación. El modelo causal solicitado
 asigna mayores relaciones directas con satisfacción a equilibrio trabajo-vida y espacio de trabajo, y
 relaciones menores a otros factores. La satisfacción se relaciona con productividad y continuidad,
 pero los R² no explican todo el resultado. El diagnóstico debe considerar competencias, esfuerzo y
 recursos; no atribuir a Policarpo opiniones que el enunciado no declara. Una prioridad apoyada por
 el modelo necesita todavía una intervención implementable y medición de efectos. (62 Segundos,
Examen de Grado UC | materia, preguntas y respuestas 21

[pág. 22]
Dirección - versión clara y reordenada
 fuente pp. 331-332).
 La implementación de un cambio de motivación combina participación y claridad. Se recoge
 información sobre expectativas, se definen conductas y recursos, se comunica qué cambiará y por
 qué, se entrenan jefes y se revisa cumplimiento. La evidencia incluye percepción y conducta:
 adopción de horario, colaboración, errores, permanencia y productividad. Mejorar una encuesta sin
 modificar condiciones puede ser una señal transitoria; modificar condiciones sin explicar criterios
 puede generar interpretaciones de favoritismo.
 3. Diseño del trabajo, autonomía, coordinación y dotación
 El diseño racional conecta estrategia, objetivos, procesos, tareas, cargos y unidades. La
 descripción expresa propósito, responsabilidades, decisiones e interfaces; el perfil expresa
 capacidades requeridas. Diseñar desde la persona disponible puede ocultar una tarea necesaria;
 diseñar un cargo sin recursos ni autoridad crea una responsabilidad ficticia. La estructura se
 comprende con segmentación, integración y autonomía. Dividir trabajo genera especialización, pero
 obliga a volver a unirlo para entregar el resultado completo al cliente. (F0910, pp. 9-13 y 23-25;
 F0609, pp. 13-17; F0912, pp. 9-11).
 La estructura funcional agrupa habilidades similares y puede desarrollar eficiencia; corre el riesgo
 de que cada área optimice su propio indicador. La divisional aproxima decisiones a productos,
 territorios o clientes, pero duplica tareas y dificulta compartir. La matricial intenta combinar
 especialización y mercado mediante dos líneas de autoridad; necesita definir cómo se resuelven
 prioridades y recursos. Las configuraciones vinculadas a Mintzberg -simple, burocracia mecánica,
 profesional, divisional y adhocracia- ayudan a examinar dónde reside conocimiento y cómo se
 coordina. No son etiquetas que se asignan solo por edad o tamaño, ni prescripciones automáticas.
 (F0609, pp. 13 y 15; F0910, pp. 9-10 y 24; F0912, pp. 9-10).
 Autonomía significa derechos sobre decisiones delimitadas, acompañados por información,
 competencia y rendición de cuentas. Se separan iniciación e implantación de ratificación y
 supervisión cuando es necesario controlar conflictos. La cercanía a información local favorece
 descentralizar, pero riesgos compartidos, estándares de seguridad o grandes inversiones pueden
 exigir ratificación común. El balance compara velocidad y calidad de información con riesgo de
 decisiones desalineadas. «Más libertad» no produce automáticamente coordinación: sin interfaces
 puede multiplicar decisiones incompatibles. (F0609, pp. 15-16; F0910, p. 25; F0914, p. 4).
 SEMCO se utiliza en los resúmenes para ilustrar la transición de control central a autogestión,
 transparencia, participación y jefes facilitadores. El aprendizaje es identificar qué sustituye la orden
 del jefe: información compartida, límites de acción, equipos capaces y revisión de resultados.
 Copiar flexibilidad sin esos complementos no copia el sistema. Los resultados narrados en el
 apunte no prueban que toda empresa obtendría la misma mejora. Se recomienda ensayar
 autonomía en decisiones específicas y evaluar errores, tiempo, calidad y colaboración antes de
 ampliar. (F0609, pp. 13-16).
 La integración puede usar contacto directo, protocolos, comités, coordinadores, equipos temporales
 y sistemas compartidos. Se elige la menor complejidad que resuelva la interdependencia. Una
 reunión sin decisiones o información nueva aumenta costo; un protocolo útil reduce incertidumbre;
 un coordinador debe tener una responsabilidad identificable. La coordinación relacional combina
Examen de Grado UC | materia, preguntas y respuestas 22

[pág. 23]
Dirección - versión clara y reordenada
 objetivos compartidos, conocimiento del trabajo ajeno, respeto y comunicación frecuente, precisa,
 oportuna y orientada a solucionar problemas. Es especialmente pertinente ante interdependencia,
 incertidumbre y presión de tiempo, pero no se declara siempre el factor más importante. (F0609, pp.
 15 y 30-31; F0910, pp. 24 y 41).
 Río Claro muestra por qué un incentivo de equipo puede seguir fragmentando. Los equipos de unas
 siete personas compiten por una recompensa que puede ignorar la ayuda a otros equipos o
 diferencias de complejidad. Si se premia solo tiempo autoconsignado, aumenta la posibilidad de
 manipulación. Se necesitan medidas de resultado conjunto, calidad y contribución transversal,
 además de reglas comparables. El programa 10X limita el ratio salarial entre mayor y menor
 ingreso; no expresa una meta de producir diez veces más. (Río Claro, fuente pp. 305-306).
 La dotación se mide con una unidad coherente. Equivalentes de jornada completa agregan horas y
 las dividen por horas de una jornada de referencia del mismo período. Una tasa de ausentismo
 puede usar personas ausentes o días ausentes; deben declararse denominador y período, porque
 las tasas no son intercambiables. Rotación requiere distinguir salidas voluntarias, despidos y
 jubilaciones, y seguir cargo o cohorte con una base consistente. Un crecimiento de salidas puede
 reflejar más contratación inicial, no un aumento idéntico de probabilidad individual. (F0910, pp.
 12-13; F0609, pp. 18-19).
 La planificación combina escenarios y modelos cuantitativos. Una proyección histórica puede fallar
 ante cambio tecnológico o demanda inesperada. Se explicitan demanda de trabajo, productividad,
 horas útiles, aprendizaje y restricciones. En CASA, la caída de vivienda y oportunidades en
 electricidad y vialidad requieren decidir qué habilidades transferir, formar o retener; despedir de
 forma uniforme ignora valor acumulado y diferencias de mercado. Se compara costo de mantener,
 reasignar, contratar y perder capacidades, respetando el horizonte del negocio. (F0910, pp. 12-13;
 CASA, fuente pp. 8-9).
 4. Reclutamiento, selección válida y socialización
 Reclutar crea una población de candidatos; seleccionar compara su idoneidad para un trabajo y una
 organización. El proceso empieza con una necesidad real de dotación y un cargo claro. A
 continuación se definen fuentes, medios de contacto y una información honesta. Reclutamiento
 interno puede preservar aprendizaje y ofrecer carrera; externo puede aportar capacidades
 inexistentes o modificar rutinas. Ninguno es siempre más barato o más valioso: se comparan
 tiempo, calidad, incertidumbre y efecto en el sistema. (F0609, pp. 7-9; F0910, pp. 16-19; F0912, pp.
 12-15).
 La promesa de valor al empleado describe lo que recibirá y lo que se espera de él. La imagen de
 empleador es la percepción que otros forman; la marca y su comunicación buscan influirla mediante
 una experiencia real. Atributos instrumentales, como pago o ubicación, conviven con simbólicos,
 como innovación o solidez. Comunicar oportunidades inexistentes puede atraer postulantes y
 después generar ruptura del contrato psicológico. La evaluación compara promesa con experiencia,
 calidad de postulantes, aceptación de ofertas, tiempo a contribución y permanencia, no solo
 seguidores en redes. (F0609, pp. 8-9; F0910, pp. 17-19; F0912, pp. 15-16).
 Seleccionar por competencias requiere identificar conductas y conocimientos que producen el
 resultado del cargo. Confiabilidad significa consistencia de medición bajo condiciones comparables;
Examen de Grado UC | materia, preguntas y respuestas 23

[pág. 24]
Dirección - versión clara y reordenada
 validez de contenido significa relación con el trabajo; validez predictiva significa capacidad de
 anticipar desempeño futuro. Una prueba puede ser confiable y medir una característica irrelevante.
 Un test de personalidad no es diagnóstico de desempeño ni debe decidir por un rótulo; su uso
 depende de evidencia, pertinencia y condiciones del puesto. Los resúmenes contienen confusiones
 entre Big Five y dimensiones de desempeño; se conserva la diferencia. (F0609, pp. 9-12; F0910,
 pp. 19-22; F0912, pp. 13-14).
 Se combinan métodos cuando aportan información distinta: revisión de requisitos, prueba técnica,
 muestra de trabajo, entrevista estructurada y referencias pertinentes. Todos los candidatos deben
 enfrentar criterios comparables, con evaluadores entrenados. STAR organiza relatos en situación,
 tarea, acción y resultado; la pregunta debe separar qué hizo el candidato de lo que hizo su equipo.
 Una respuesta convincente necesita repreguntas y evidencia, no solo una historia bien narrada. La
 simulación permite observar una tarea, pero debe parecerse a lo que realmente exigirá el cargo. No
 se declara que cualquier entrevista sea el peor método: el problema del material es principalmente
 la improvisación y primera impresión. (F0609, pp. 10-13; F0910, pp. 19-22; F0912, pp. 13-15).
 El desempeño pasado depende también de recursos, relaciones y contexto. Contratar una
 «estrella» de publicidad para consultoría exige probar diagnóstico, escucha y propuesta ejecutable;
 ser creativo no demuestra esas competencias. Capital humano general se transfiere con mayor
 facilidad que conocimiento de rutinas o relaciones específicas, pero la transferibilidad no es
 absoluta. La selección contrasta el nuevo trabajo y los apoyos que estarán disponibles. No usa
 sexo, edad o situación familiar como atajos para inferir compromiso. (F0609, p. 12; F0910, p. 22;
 Cáspita, fuente pp. 105-106).
 La socialización anticipatoria empieza antes del ingreso: el candidato conoce condiciones y puede
 autoseleccionarse. En el encuentro compara expectativas con la realidad y aprende interfaces; en
 asentamiento gana claridad, confianza y desempeño. Una presentación realista del cargo evita
 sobrepromesa, pero no elimina por sí sola rotación. La inducción debe incluir tareas, estándares,
 seguridad, relaciones, responsables y acceso a información. Un mentor facilita integración; no
 sustituye al jefe en asignar trabajo y dar retroalimentación. (F0609, p. 11; F0910, pp. 20-21; F0912,
 pp. 16-18).
 Se revisa el proceso por etapas: dónde abandonan candidatos, qué prueba predice el resultado
 pertinente, cuánto tarda el nuevo empleado en aportar y qué falla en su integración. Descartar a
 una persona capaz y contratar a otra inadecuada son errores diferentes, con costos y efectos. El
 número de CV no mide calidad; permanencia sin desempeño tampoco demuestra éxito. La
 selección no debe cargar con problemas que provienen del trabajo, liderazgo o promesa incumplida
 después de contratar. (F0912, pp. 13-15; F0609, pp. 9-12).
 5. Desempeño, competencias, indicadores y retroalimentación
 La gestión del desempeño es un ciclo de expectativas, recursos, seguimiento, retroalimentación,
 evaluación y decisión. La evaluación es una parte. Se distinguen resultados -qué logró-, conductas
 -cómo actuó- y capacidades -qué puede desarrollar-. Medir solo resultados puede omitir
 cooperación, calidad o riesgo; medir solo rasgos puede producir juicios vagos sin relación con el
 trabajo. El instrumento depende del propósito: desarrollo, promoción, remuneración y diagnóstico
 no necesariamente requieren el mismo uso de datos. (F0609, pp. 17-21 y 31-32; F0910, pp. 26-30 y
 41-43; F0912, pp. 24-28).
Examen de Grado UC | materia, preguntas y respuestas 24

[pág. 25]
Dirección - versión clara y reordenada
 Primero se define el desempeño deseado y se observa el real. Después se investiga la causa de la
 brecha: habilidad, motivación, información, herramientas, carga, coordinación o condiciones
 externas. Una intervención se elige para esa causa: capacitación, aclaración, rediseño, apoyo,
 reasignación o feedback. Si el indicador falla, no se interpreta automáticamente como falla de la
 persona. Este paso conecta gestión y aprendizaje, y evita capacitar a todo el personal ante
 cualquier resultado negativo. (F0609, pp. 17 y 31; F0910, pp. 26 y 41-42).
 Un buen criterio es estratégicamente relevante y cubre responsabilidades sin contaminarse con
 factores ajenos. Deficiencia de criterio es omitir una parte importante; contaminación es incorporar
 factores que no representan el desempeño que se pretende evaluar. Controlabilidad no significa
 que el trabajador controle todo resultado; significa distinguir su contribución y diseñar una
 comparación razonable. Un vendedor afectado por cambio de mercado no se evalúa igual que si el
 único cambio fuera su esfuerzo. Se usan medidas de proceso, calidad y contexto para interpretar,
 sin eliminar exigencia de resultados. (F0609, pp. 20 y 31-32; F0910, pp. 28 y 42; F0912, pp. 25-26).
 SMART ayuda a especificar una meta, pero no garantiza que sea la correcta. Debe ser concreta,
 medible, realizable, relevante para la estrategia y situada en un tiempo claro. Hay variantes de las
 letras en los apuntes; el criterio operativo es inequívoco. La ficha incluye fórmula, unidad, fuente,
 responsable, frecuencia, estándar y límites. Un plazo breve puede inducir velocidad a costa de
 calidad; un volumen absoluto puede premiar una cartera mayor o asignaciones más sencillas. Se
 consideran tasas, carga, complejidad y restricciones según el proceso. (F0609, pp. 19-20; F0910,
 pp. 27-28; F0912, pp. 25 y 28).
 Banco Morlacci utiliza 120 KPIs para 12 gerencias y pondera el bono 90% por desempeño
 individual y 10% por empresa. Medir mucho puede diluir prioridades y elevar costo de registro. La
 tabla contiene intervalos y umbrales que requieren reglas claras para no dejar valores sin
 clasificación o producir rangos ambiguos. El criterio FIFO puede ser incompatible con prioridades
 estratégicas y complejidad diferente. La mejora consiste en seleccionar inductores, corregir
 definiciones, equilibrar resultado y calidad, y establecer acciones y datos comparables. La mayoría
 satisfecha y la baja rotación no prueban que esos indicadores sean óptimos ni que el bono causó el
 resultado. (Banco Morlacci, fuente pp. 429-430).
 El Balanced Scorecard conecta capacidades, procesos, cliente y finanzas. Se eligen indicadores
 críticos para una hipótesis de resultado, sin pretender «medir todo». Un indicador de capacitación
 cumplida no equivale a aprendizaje; aprendizaje no equivale a conducta aplicada; conducta no
 equivale a rentabilidad sin observar costos y otros cambios. El mapa causal es útil para decidir qué
 revisar, pero requiere evidencia. Tampoco los pesos deben ser iguales por perspectiva: se justifican
 según aporte, riesgos e interdependencia. (F0609, pp. 19-21; F0910, pp. 27-28; F0912, p. 28).
 Los sesgos incluyen halo, severidad, indulgencia, tendencia central, recencia y similitud. Se
 reducen con criterios conductuales, ejemplos registrados, formación, calibración y revisión. Una
 evaluación 360 reúne perspectivas de jefe, pares, colaboradores y clientes pertinentes;
 discrepancias pueden reflejar contextos de observación, no necesariamente error. Debe definir
 confidencialidad, propósito y cómo convertir resultados en acciones. Más evaluadores no elimina
 colusión ni garantiza objetividad. «Padres» en algunos textos es un error de transcripción: se refiere
 a pares. (F0609, pp. 18 y 21; F0910, pp. 30 y 42-43; F0912, pp. 25-26).
 La retroalimentación identifica una conducta, su efecto y un siguiente paso observable; reconoce lo
 que funciona y permite respuesta del evaluado. Evita rótulos como «poco comprometido» sin
Examen de Grado UC | materia, preguntas y respuestas 25

[pág. 26]
Dirección - versión clara y reordenada
 hechos. Se acuerdan apoyo, responsables y fecha de revisión. Si se usará para pago o promoción,
 los criterios deben ser conocidos antes del período y la posibilidad de corrección debe ser real. La
 evaluación anual no sustituye conversación durante el trabajo ni se vuelve inútil por ser anual: el
 problema es la falta de seguimiento y decisión oportuna. (F0609, pp. 17-21 y 31; F0910, pp. 41-42;
 F0912, pp. 24-26).
 6. Compensación total e incentivos: esfuerzo, riesgo y
 cooperación
 La compensación total reúne sueldo base, pago variable y beneficios, junto con recompensas no
 monetarias. Equidad interna compara responsabilidades, competencias y contribuciones dentro de
 la organización; competitividad externa compara una oferta total con alternativas pertinentes del
 mercado. Son dimensiones transversales, no sinónimos de fijo y variable. La valoración de cargos
 aporta criterios, pero una correlación alta con una línea salarial no prueba justicia. Los umbrales de
 ±20%, R²>0,8 o 40% de diferencia que aparecen en apuntes no son reglas universales. Se examina
 la explicación del reparto, sus consecuencias y la calidad de la comparación. (F0609, pp. 22-25;
 F0910, pp. 31-34; F0912, pp. 29-32; F0914, pp. 6-7).
 El incentivo modifica atractivo de conductas observables. Puede aumentar esfuerzo, focalizar,
 enseñar qué importa y atraer personas que prefieren esa relación. También puede premiar
 manipulación, desplazar tareas no medidas y generar riesgo. Si se paga ventas facturadas, puede
 crecer crédito impago; pagar ventas cobradas corrige una parte, pero podría desincentivar clientes
 rentables de pago lento. La medida se elige por estrategia y controlabilidad. No todo problema de
 agencia exige incentivo financiero: información, supervisión, reputación y diseño de derechos
 también cuentan. (F0609, pp. 23-24; F0910, pp. 32-33; F0912, pp. 30-31).
 Un esquema se diseña desde el valor incremental esperado. Se define conducta, indicador, base
 comparable, umbral, fórmula de pago, tope, momento y salvaguardas. El beneficio debe superar
 bonos, registro, supervisión y efectos negativos. Decir que el incentivo «sale gratis» solo expresa
 una aspiración: requiere medición de valor neto y liquidez para pagarlo. Debe mantenerse relación
 comprensible entre contribución y recompensa; un cambio constante de metas puede producir
 efecto trinquete y reducir confianza. La regla conocida antes de actuar facilita aprendizaje y evita
 arbitrariedad. (F0609, pp. 23-24; F0910, p. 33; F0912, pp. 30-31).
 El incentivo individual permite relacionar aportes cuando son separables; en tareas
 interdependientes puede incentivar retener ayuda o concentrarse en una métrica local. El grupal
 reconoce complementariedad, pero puede crear free riders o desigualdad si reparte por salario
 previo. El diseño mezcla resultados individuales, equipo y empresa según capacidad de influencia,
 con requisitos mínimos de calidad y cooperación. Los grupos pequeños, objetivos claros y
 evaluación de contribución facilitan responsabilidad, sin garantizarla. Un componente corporativo
 excesivamente pequeño puede dejar externalidades importantes sin premiar. (F0609, pp. 23-24;
 F0910, pp. 32-33; Río Claro, fuente pp. 305-306; Morlacci, fuente pp. 429-430).
 El bono máximo de Morlacci, de 7,5 sueldos, puede ser significativo y estimular esfuerzo; su monto
 no acredita por sí solo motivación sostenible. Hay que considerar claridad, capacidad de alcanzar,
 proporcionalidad y efectos de premiar sobre todo al individuo. La motivación intrínseca y afectiva
 necesita trabajo con sentido, desarrollo y colaboración. Un buen resultado de rotación puede
Examen de Grado UC | materia, preguntas y respuestas 26

[pág. 27]
Dirección - versión clara y reordenada
 deberse también a salarios, mercado, selección o condiciones; no demuestra causalidad exclusiva
 del programa. (Morlacci, fuente pp. 429-430).
 Las acciones y opciones pueden alinear con valor futuro y apoyar retención, pero el precio incluye
 shocks ajenos a la persona. Opciones a largo plazo pueden no ser valoradas por quien espera salir
 antes; la estructura de vesting y horizonte debe examinarse, no asumirse. También pueden inducir
 riesgos, manipulación o dilución. Se combina horizonte corto y largo, contribución controlable y
 medidas de sostenibilidad, y se explica el riesgo al participante. La experiencia de un cargo alto no
 implica automáticamente que deba recibir el mayor porcentaje variable en todo contexto. (F0609, p.
 24; F0910, p. 33; F0912, pp. 31-32; Constructora Los Chaleses, fuente pp. 21-22).
 Los beneficios flexibles permiten elegir apoyo de salud, ahorro, tiempo o cuidado según
 preferencias. El diseño considera acceso, costo, administración y percepción de justicia; no
 presupone que todos los jóvenes quieren solo dinero ni todos los mayores protección. La flexibilidad
 valiosa debe ser utilizable: un beneficio que existe pero el jefe impide usar emite una señal
 negativa. Salario por hora y costo laboral por unidad producida describen cosas diferentes; reducir
 salario no equivale a mejorar productividad, y un salario mayor puede coexistir con menor costo
 unitario si mejora capacidad y resultado. (F0609, pp. 22-25; F0910, pp. 31-34; F0914, pp. 6-7).
 Puro Cobre obliga a revisar la base económica del acuerdo: 5.900 trabajadores por CLP16,8
 millones implica CLP99.120 millones, y el ahorro de retiros de US$200 millones del caso no puede
 presentarse como mayor sin compatibilizar monedas y supuestos. Los 2.150 retiros anunciados no
 son obligatorios. Seguridad, productividad y ley del mineral afectan resultados de modos distintos;
 una ley geológica menor no se corrige con más motivación. Las cifras absolutas de accidentes
 tampoco comparan riesgo sin exposición. (Puro Cobre, fuente pp. 117-118).
 7. Formación, transferencia, talento y carrera
 Capacitar facilita competencias del trabajo actual; desarrollar prepara responsabilidades futuras.
 Coaching ayuda a revisar y mejorar desempeño; mentoría aporta orientación y experiencia en una
 relación de acompañamiento. El método se elige por brecha y contexto. Un curso general no
 resuelve automáticamente coordinación ni acceso a herramientas. El diagnóstico combina
 organización -qué exige la estrategia-, tareas -qué conductas requiere el proceso- y personas -qué
 capacidades existen-. (F0609, pp. 26-27; F0910, pp. 35-36; F0912, pp. 18-19).
 La secuencia de diseño define público, objetivo de aprendizaje, práctica, instructor, tiempo, medios
 y condiciones para usar lo aprendido. Enseñar un software exige tareas y casos de uso; enseñar
 coordinación requiere ensayar interfaces y conflictos; enseñar liderazgo exige observación y
 feedback. Se pueden combinar simulación, práctica en el cargo, estudio de caso y
 acompañamiento. El objetivo se formula como capacidad observable: «resolver una incidencia con
 el protocolo y dejar registro completo» es verificable; «conocer la importancia del servicio» no basta.
 (F0609, pp. 26-27; F0910, pp. 35-36).
 La transferencia ocurre cuando se utiliza el aprendizaje en el trabajo. Necesita oportunidad, apoyo
 del jefe, herramientas e incentivos compatibles. Si se forma para autonomía, pero toda iniciativa es
 sancionada o requiere aprobaciones interminables, el sistema inhibe uso. Una capacitación puede
 elevar empleabilidad fuera de la empresa; retener requiere un intercambio adecuado, no impedir
 aprendizaje. El conocimiento específico puede complementar relaciones y rutinas, pero tampoco
Examen de Grado UC | materia, preguntas y respuestas 27

[pág. 28]
Dirección - versión clara y reordenada
 obliga a permanecer. (F0609, pp. 26-27 y 31; F0910, pp. 35-36; F0912, pp. 18-19).
 La evaluación distingue reacción del participante, aprendizaje, conducta y resultado. Satisfacción
 con el instructor no demuestra habilidad; aprobar una prueba no demuestra transferencia; mejorar
 resultado después del curso no demuestra que todo cambio se deba al curso. Para estimar retorno
 se consideran costo, tiempo y beneficio incremental frente a una base o comparación. Se registra
 qué cambió también en demanda, tecnología o equipos. Cuando no hay identificación causal, se
 informa la mejora observada y su límite en vez de calcular un ROI con atribución ficticia. (F0609, p.
 27; F0910, pp. 35-36).
 RPC y Siempre Sanitos ilustran prioridades basadas en evidencia. En RPC, capacitación y
 coordinación presentan brechas mayores que remuneración y seguridad; diseñar solo un bono
 ignora el diagnóstico. En Siempre Sanitos, capacidades, carrera y autonomía/colaboración se
 desprenden de gráficos distintos; no se reduce todo a incentivo monetario. La intervención debe
 combinar formación con condiciones para aplicar y criterios de promoción comprensibles. (RPC,
 fuente pp. 52-53; Siempre Sanitos, fuente pp. 94-95).
 Gestionar talento significa prever capacidades críticas, atraerlas, desarrollarlas, situarlas y sostener
 sucesión. No se identifica «talento» solo con quienes alcanzaron una meta pasada: la nueva
 responsabilidad puede requerir competencias distintas. Las rutas duales pueden permitir carrera
 técnica sin obligar a asumir jefatura. Los planes de sucesión registran puesto crítico, riesgo de
 vacancia, posibles reemplazos y brechas, con oportunidades reales de aprendizaje. El potencial se
 calibra con evidencias y se revisa, evitando rótulos permanentes que cierren desarrollo. (F0609, pp.
 21 y 32-33; F0910, pp. 43-45; F0912, pp. 17-18 y 32).
 La carrera tiene responsabilidad compartida. La persona identifica capacidades, intereses y
 proyectos; la empresa informa oportunidades, exige criterios y ofrece apoyo. No puede prometer
 ascenso a todos, pero puede ofrecer aprendizaje, movilidad y claridad. Las etapas por edad de los
 apuntes son una tipología histórica, no una predicción ni un criterio de selección. Se examinan
 transiciones reales y necesidades individuales. Capital psicológico -autoeficacia, esperanza,
 optimismo y resiliencia- puede apoyar adaptación; confianza no equivale a habilidad y no reemplaza
 recursos o competencia. (F0609, pp. 32-33; F0910, pp. 44-45).
 8. Clima, cultura, liderazgo, diversidad y relaciones laborales
 El clima describe percepciones de prácticas y condiciones en un momento y contexto. La cultura
 refiere significados y supuestos aprendidos que orientan cómo se actúa. Engagement expresa
 vínculo y energía hacia el trabajo. Una encuesta puede medir parte del clima, pero no revelar toda
 cultura. Un buen puntaje promedio puede ocultar una unidad con maltrato o un grupo excluido; se
 examinan distribución, participación y diferencia entre cargos, resguardando interpretación y
 confidencialidad. (F0609, pp. 28-30; F0910, pp. 37-40; F0912, pp. 34-36).
 Schein, nombrado en F0912, permite distinguir artefactos observables, valores declarados y
 supuestos subyacentes. Los símbolos y ritos comunican, pero las decisiones difíciles muestran
 prioridades reales. Declarar respeto mientras se premia al jefe abusivo contradice la cultura
 deseada. Cambiar un afiche no modifica por sí solo el aprendizaje acumulado: se revisan selección,
 promoción, evaluación, sanción, relaciones y ejemplos de liderazgo. La consistencia debe
 comprobarse ante conflictos entre resultados inmediatos y principios. (F0912, pp. 35-36; F0609, pp.
Examen de Grado UC | materia, preguntas y respuestas 28

[pág. 29]
Dirección - versión clara y reordenada
 29-30; F0910, pp. 39-40).
 El enfoque de valores antagónicos contrasta flexibilidad/estabilidad y orientación interna/externa,
 dando tipos clan, adhocracia, jerarquía y mercado. Sirve para reconocer tensiones: innovación
 necesita experimentación, mientras seguridad necesita estándares; pertenencia puede apoyar
 confianza y también ocultar nepotismo. No hay un cuadrante siempre correcto ni una organización
 necesariamente pura. Se identifica qué prácticas necesita la estrategia y cómo equilibrar riesgos.
 (F0609, p. 30; F0910, p. 40).
 Liderazgo orientativo aclara dirección; democrático incorpora voz; afiliativo cuida vínculos; formativo
 apoya aprendizaje; ejemplar muestra estándar; coercitivo ordena. La elección depende de tarea,
 urgencia y capacidades, pero humillación y maltrato no se justifican como técnica de motivación. Un
 líder facilitador entrega información y elimina obstáculos; no abandona responsabilidad. Se evalúa
 conducta real con subordinados, pares y resultados, y se forma en feedback, coordinación y
 resolución de conflictos. (F0609, p. 28; F0910, pp. 37-38; F0912, p. 34).
 InnovarTech plantea diversidad e inclusión. Diversidad de integrantes no asegura aprovechamiento
 de conocimientos si hay exclusión, favoritismo o barreras de participación. El problema no se
 resuelve restringiendo diferencias: requiere criterios de selección y promoción ligados al trabajo,
 voz y trato digno, y jefes capaces de coordinar perspectivas. Tres iniciativas coherentes pueden
 modificar reclutamiento/evaluación, formar liderazgo y crear mecanismos de
 participación/corrección. Deben examinar acceso a oportunidades, permanencia, experiencia y
 resultados, sin presentar una cuota o taller aislado como cambio cultural completo. (InnovarTech,
 fuente pp. 405-406; F0910, pp. 7-8; F0912, pp. 1 y 35-36).
 Las relaciones laborales incluyen cómo empresa y representantes de trabajadores abordan
 intereses, conflictos y futuro del trabajo. El mapa del caso Casi Fuimos combina tipo de relación
 -conflicto o convergencia- y amplitud de agenda -remuneración inmediata o asuntos estratégicos
 múltiples-. Una agenda amplia puede incorporar seguridad, desarrollo, productividad y cambios
 tecnológicos; no elimina diferencias distributivas. La cooperación necesita información compartida,
 instancias periódicas y compromisos revisables. No se mide solo por ausencia de huelgas ni se
 reduce a benevolencia del gerente. (F0913, p. 6; F0914, pp. 7-8; Casi Fuimos, fuente pp. 255-257).
 En Casi Fuimos los indicadores de coordinación, sugerencias y liderazgo permiten examinar por
 qué una relación más convergente puede mejorar resultados. La comparación debe respetar
 unidades y no atribuir toda diferencia a una sola política. En Puro Cobre, retiros y bonos requieren
 negociar continuidad, seguridad, transferencia de oficio y productividad, no solo repartir dinero. La
 implementación define agenda, responsables, información, plazos y revisión, y conserva la
 posibilidad de disentir de forma reconocida. (Casi Fuimos, fuente pp. 255-257; Puro Cobre, fuente
 pp. 117-118).
Examen de Grado UC | materia, preguntas y respuestas 29

[pág. 30]
Dirección - versión clara y reordenada
 9. Continuidad, salidas y aprendizaje del sistema
 Una salida puede ser renuncia, retiro, jubilación o decisión de la organización; sus causas y señales
 son distintas. El análisis de rotación debe distinguir pérdida no deseada de capacidades, reemplazo
 planificado y ajuste de dotación. Antes de decidir se examinan demanda, posibilidad de reasignar o
 formar, costos y efectos sobre quienes permanecen. Un retiro voluntario puede perder justamente a
 quienes tienen mejores alternativas; la ventana, público y transferencia de conocimientos deben
 diseñarse. No se extrapolan las causales o procedimientos legales de resúmenes históricos como
 reglas vigentes. (F0609, pp. 33-34; F0910, pp. 45-46; F0912, pp. 19-21).
 En desempeño insuficiente debe distinguirse qué expectativa estaba clara, qué evidencia se
 recogió, qué apoyo se ofreció y qué posibilidad de mejora existió. En reestructuración el problema
 puede ser el puesto y no una falla personal. La comunicación requiere verdad, precisión, respeto,
 escucha y claridad sobre pasos siguientes. Los tiempos fijos de tres o veinte minutos que aparecen
 en apuntes son recomendaciones particulares, no exigencias universales ni una medición de trato
 adecuado. Outplacement puede apoyar empleabilidad, redes y transición; no borra por sí solo un
 proceso injusto. (F0609, pp. 33-34; F0910, pp. 45-46; F0912, pp. 20-21).
 Entrevistas de salida y conversaciones de permanencia producen información distinta. Se pregunta
 por trabajo, carga, liderazgo, condiciones y alternativas, y se busca patrón entre datos sin atribuir
 automáticamente una causa declarada a todos. Debe evitarse el temor que impide hablar y
 explicarse cómo se utilizará información. Una entrevista honesta no sustituye observación del
 sistema ni una comparación de condiciones de mercado. Liz Taylor necesitaba diagnosticar con la
 tabla efectivamente disponible; no se puede afirmar que ya hizo entrevistas porque serían
 recomendables. (F0912, pp. 20-21; Liz Taylor, fuente pp. 366-367).
 Quienes quedan interpretan la salida como señal sobre valores, seguridad y justicia. El aprendizaje
 conserva qué capacidad se perdió, si selección o trabajo habían fallado y qué prácticas cambiarán.
 Así se cierra el ciclo de Personas: la salida informa reclutamiento, promesa, diseño, formación y
 evaluación. La revisión no termina por tener formularios completos; termina para un alcance
 concreto cuando las evidencias permiten decidir, actuar y comprobar resultados, con límites
 explícitos.
 Profundización aplicada de Dirección de Personas
 P3. Arquitectura de empleo, capital humano y dotación
 Los materiales distinguen capital humano general, estratégico, de industria, relacional y
 específico de empresa. Un profesional puede trasladar análisis general, perder conocimiento de
 una regulación sectorial y no llevar consigo confianza con su equipo anterior. La clasificación ayuda
 a explicar por qué contratar una estrella no garantiza replicar su desempeño. Su transferibilidad
 depende de la tarea y el entorno; el orden de los apuntes es orientativo, no una escala universal.
 La arquitectura de empleo diferencia valor estratégico y singularidad de capacidades. Capacidades
 valiosas y específicas suelen justificar desarrollo interno y relaciones duraderas; habilidades
 valiosas disponibles en el mercado pueden adquirirse; tareas más estandarizadas pueden
 contratarse; capacidades singulares externas pueden requerir alianzas. Los cuatro arreglos de los
Examen de Grado UC | materia, preguntas y respuestas 30

[pág. 31]
Dirección - versión clara y reordenada
 materiales -trabajadores del conocimiento, empleo basado en cargo, contratación y alianza- difieren
 en horizonte, inversión, autonomía y coordinación. No autorizan degradar dignidad, seguridad o
 trato de un grupo. Tampoco “bajo costo” exige salarios bajos: capacitación, retención y menor error
 pueden reducir costo total con mejores salarios.
 Planificar dotación exige demanda de trabajo y oferta de capacidades. Promedios móviles y
 tendencias sirven cuando el pasado es representativo; escenarios y juicio estructurado ayudan
 cuando cambia tecnología o negocio. Deben explicitarse supuestos y revisarse con datos. Cubrir
 una escasez mediante horas adicionales es una solución temporal con límites de costo, fatiga y
 calidad; una sobreoferta requiere comparar reasignación, formación, contratación futura y ajustes
 antes de decidir salidas.
 Ejercicio resuelto de carga y FTE. Se esperan2.400 solicitudes mensuales; cada una requiere18
 minutos. La demanda es43.200 minutos=720 horas. Cada jornada completa aporta120 horas
 efectivas al mes para esa tarea después de reuniones, formación y otras funciones. Se
 requieren720/120=6FTE. Con10% de ausencia sobre esa capacidad disponible, cada FTE
 aporta108 horas; se necesitan6,67FTE. Si solo pueden contratarse jornadas completas y no existe
 otra cobertura, planificar7. Evitar descontar dos veces las ausencias si las120 horas ya las incluían.
 Los picos horarios y competencias pueden requerir más cobertura que el promedio. FTE mide
 equivalentes de tiempo, no necesariamente siete personas distintas.
 Ausentismo por tiempo es horas o días perdidos sobre horas o días programados del mismo
 período. Personas ausentes sobre dotación es otro indicador: dos personas ausentes un día y dos
 ausentes todo el mes producirían la misma proporción de personas, con pérdidas distintas.
 Rotación debe declarar período, población, denominador, salidas voluntarias/involuntarias y si hay
 traslados. Una tasa global oculta la salida de talento crítico.
 P4. Reclutamiento, selección, validez y entrevista aplicada
 El reclutamiento produce una población candidata pertinente; la selección decide con evidencia.
 Selección interna reduce incertidumbre, conserva conocimiento y ofrece carrera; puede perpetuar
 homogeneidad o no aportar nuevas capacidades. La externa amplía perspectivas y capacidades,
 con incertidumbre y costo de adaptación. El criterio es la necesidad del cargo y la estrategia, no
 preferencia automática por una fuente.
 La imagen de empleador incluye atributos instrumentales -pago, localización, oportunidades-,
 simbólicos -innovación, trato- y evaluación global. La propuesta de valor al empleado expresa lo
 que puede esperar a cambio de su trabajo; la marca y su comunicación deben sostenerse en
 experiencia real. En reclutamiento digital, organizar cliente candidato, contenido, comunidad y
 conversación ayuda a escuchar y proporcionar información pertinente. No se confunde este
 esquema con una ley universal de marketing. ASA -atracción, selección y atrición- explica cómo el
 ajuste percibido influye en entrar, ser contratado y permanecer; buscar clones puede estrechar
 pensamiento y diversidad.
 La confiabilidad evalúa consistencia de mediciones; la validez de contenido, representación de
 tareas y conocimientos del cargo; la validez de constructo, qué rasgo mide; la validez de criterio,
 asociación con desempeño relevante. Concurrente observa medición y desempeño en población
 actual; predictiva sigue desempeño posterior. “Validez continua” en algunos apuntes es una
Examen de Grado UC | materia, preguntas y respuestas 31

[pág. 32]
Dirección - versión clara y reordenada
 confusión, no una categoría equivalente. Una prueba confiable puede medir algo irrelevante. Más
 entrevistas no aseguran validez si repiten sesgos o información.
 Big Five comprende responsabilidad o escrupulosidad, extraversión, amabilidad, neuroticismo -o su
 inverso estabilidad emocional- y apertura a la experiencia. Aprendizaje o ventas pueden ser
 resultados relacionados, pero no son dimensiones adicionales. Un rasgo tampoco prescribe éxito
 en todo cargo. Muestras de trabajo observan tareas pertinentes; pruebas de conocimiento evalúan
 dominio; simulaciones y centros de evaluación integran situaciones; pruebas cognitivas y
 personalidad requieren pertinencia, interpretación y resguardos. No copiar coeficientes de tablas
 docentes como si fueran R² universal sin verificar medida, población y criterio.
 Ejercicio de decisiones. En un escenario hipotético donde se conoce la aptitud real de100
 candidatos:
 Decisión / realidad Apto No apto
 Contratar 32 18
 Rechazar 8 42
 Precisión entre contratados=32/50=64%; sensibilidad=32/40=80%; especificidad=42/60=70%. Se
 rechaza20% de aptos y se contrata30% de no aptos. Elevar el umbral suele reducir contrataciones
 erróneas y aumentar exclusiones erróneas; decidir requiere costo del error, escasez y posibilidad de
 formación. En una empresa real no se observa fácilmente cómo habrían rendido los rechazados.
 Analizar solo contratados produce selección de la muestra; estos números son enseñanza, no
 evidencia de un proceso real.
 Entrevista STAR con pauta. Para evaluar coordinación, pedir: “Cuéntame un caso en que tu
 equipo y otro discreparon sobre una entrega”. Situación: contexto y restricciones; tarea:
 responsabilidad concreta; acción: conducta propia y alternativas; resultado: efecto y aprendizaje.
 Repreguntar qué hizo personalmente, qué datos usó y cómo se conoce el resultado. Aplicar la
 misma pregunta central y una pauta anclada: nivel1 culpa a otros sin evidencia; nivel3 describe
 intercambio y un acuerdo básico; nivel5 explicita intereses, usa datos, acuerda responsabilidades y
 verifica resultado. Los números son una pauta pedagógica que debe validarse con incidentes del
 cargo. Registrar hechos antes de impresiones y calibrar evaluadores. Una respuesta elocuente sin
 conducta comprobable no basta.
 La selección digital requiere validar datos, criterio, representatividad, privacidad y revisión humana.
 Entrenar un algoritmo para imitar contrataciones pasadas puede reproducir sesgos sin predecir
 desempeño. No usar apariencia, edad o situación familiar como sustitutos injustificados de
 competencias. La detección de fingimiento tampoco se prueba solo por velocidad de respuesta o
 lenguaje corporal.
 P5. Socialización, desempeño y transferencia de formación
 La socialización anticipatoria forma expectativas antes del ingreso; la de encuentro compara
 promesa y realidad; el asentamiento consolida rol, confianza y pertenencia. Una descripción realista
 del puesto favorece autoselección y reduce sorpresas, pero no garantiza una reducción universal de
 rotación. La inducción debe transmitir conductas críticas, relevantes y límites, sin obligar a
 uniformidad de pensamiento. Un rito que humilla contradice integración y dignidad.
Examen de Grado UC | materia, preguntas y respuestas 32

[pág. 33]
Dirección - versión clara y reordenada
 La gestión del desempeño es continua: fijar expectativas, dar medios, observar, retroalimentar,
 corregir y evaluar. Debe considerar tareas, contribución contextual -por ejemplo ayudar a coordinar-
 y conductas contraproducentes. Separar propósito de desarrollo del administrativo ayuda a evitar
 que una conversación de aprendizaje sea interpretada como amenaza salarial.
 Una medida es deficiente si omite parte importante del desempeño; contaminada si incorpora
 factores ajenos o fuera de control. Evaluar a una vendedora solo por volumen omite calidad de
 asesoría y puede incorporar diferencias territoriales. Rasgos vagos como “actitud” amplían
 arbitrariedad; resultados exclusivamente numéricos tampoco garantizan objetividad. BARS usa
 ejemplos conductuales anclados a niveles de calidad; BOS registra frecuencia de conductas
 observables. Son distintos. MBO o administración por objetivos acuerda resultados y recursos;
 necesita adaptar metas cuando cambian supuestos. Una evaluación360 recopila perspectivas
 pertinentes: no es una votación ni un promedio que elimina automáticamente sesgos.
 Halo generaliza una impresión, indulgencia y severidad sesgan niveles, tendencia central borra
 diferencias y recencia sobrerrepresenta hechos últimos. Reducirlos requiere incidentes registrados
 durante el período, criterios claros, calibración, explicación y posibilidad de corrección. Distribuir
 calificaciones forzadamente no prueba que exista igual distribución real de desempeño en todos los
 equipos.
 Programa de formación trabajado. Hay errores al diagnosticar fallas. Analizar organización
 -prioridad y costo-, tarea -conductas necesarias- y personas -quién tiene brecha-. Si el problema es
 repuestos faltantes, formación no basta. Objetivo: diagnosticar cuatro fallas frecuentes con una
 pauta verificable. Método: demostración, práctica sobre casos, feedback y repetición espaciada.
 Antes: revisar conocimientos básicos; durante: practicar y corregir; después: supervisar casos
 reales y asegurar tiempo y herramientas. Evaluar reacción, aprendizaje, conducta en el trabajo y
 resultado operativo. Un examen final verifica parte del aprendizaje, sin demostrar transferencia.
 Una reducción de errores de10% a6% tras formación es compatible con mejora, pero pudo coincidir
 con nuevo equipamiento o distinta mezcla de casos. Comparar grupos semejantes y controlar esas
 diferencias fortalece la inferencia. La regla70-20-10 puede servir como orientación de variedad de
 experiencias, no como proporción óptima universal comprobada. Coaching trabaja objetivos y
 reflexión mediante acompañamiento; mentoría aporta orientación y experiencia; no son sustitutos
 automáticos de entrenamiento técnico.
 P6. Salarios, bandas, incentivos y comportamientos no
 deseados
 Valorar cargos distingue valor del puesto de desempeño de su ocupante. Ordenamiento y
 clasificación son métodos simples; factores y puntos hacen explícitos requisitos y ponderaciones.
 Los perfiles Hay enfatizan conocimiento, solución de problemas y responsabilidad. Una tabla
 docente que agrega condiciones de trabajo o asigna puntos concretos es un ejemplo de valoración,
 no una reproducción universal del método propietario. Requiere descriptores y evaluadores
 consistentes.
 Equidad interna compara cargos y contribuciones dentro de la organización; competitividad externa
 compara empleos homologables en mercado pertinente. No corresponde asignar toda equidad
 interna al sueldo fijo y toda externa al variable: ambos componentes pueden intervenir. Las
Examen de Grado UC | materia, preguntas y respuestas 33

[pág. 34]
Dirección - versión clara y reordenada
 encuestas requieren fecha, muestra, localización, tamaño, contenido del cargo y paquete total.
 Comparar títulos sin responsabilidades puede producir conclusiones erróneas.
 Ejemplo salarial. Una banda pedagógica tiene punto medio1.500.000 y amplitud±20%:
 mínimo1.200.000 y máximo1.800.000. Una persona gana1.350.000; su compa-ratio
 es1.350.000/1.500.000=0,90. Está10% bajo el punto medio, pero esto no prueba injusticia sin
 examinar experiencia, contribución, antigüedad de la banda y comparables. Superposición entre
 bandas permite progresión sin un ascenso formal; exceso de solapamiento puede volver poco clara
 la estructura. ±20% y R²0,8 presentes en apuntes son referencias de ejemplos, no normas
 universales ni pruebas de justicia.
 Los incentivos pueden producir seis mecanismos: mayor esfuerzo, focalización en lo medido,
 aprendizaje para rendir, autoeficacia, feedback y selección de quienes prefieren ese sistema. El
 caso Safelite de clases ilustra que un cambio de pago puede cambiar esfuerzo y composición: no
 debe atribuirse todo incremento agregado al mismo trabajador. La comparación requiere considerar
 quién permanece y quién entra.
 El efecto trinquete o ratchet aparece cuando un desempeño alto eleva futuras metas o estándares
 y reduce el beneficio esperado de mostrar capacidad hoy. Un empleado puede retrasar ventas si
 teme que su cuota futura aumente automáticamente. No es simplemente resistirse a que le quiten
 un bono: eso puede relacionarse con expectativas o aversión a pérdidas. Diseñar revisiones
 explícitas y evitar castigar mecánicamente mejoras ayuda, pero garantizar metas fijas para siempre
 también puede perder sentido cuando cambia la productividad.
 Pagar resultados aumenta claridad y riesgo de manipular métricas; pagar conductas ayuda cuando
 hay resultados lejanos o fuera de control, pero requiere observar conductas útiles. Bonos
 individuales distinguen contribución y pueden obstaculizar cooperación; grupales apoyan
 interdependencia y generan free riding si el aporte resulta invisible. Mezclas con indicadores
 compartidos, observación individual y umbrales de calidad permiten equilibrar. Una stock option
 tiene pago convexo y puede alentar riesgo; su valor depende también de mercado y decisiones
 ajenas. Reparto de utilidades no equivale a reparto de ahorros: este último debe evitar premiar
 postergar mantención o reducir calidad.
 Caso resuelto. Una fuerza de ventas de fertilizantes cobra solo por volumen y descuida asesoría,
 según los apuntes de corrección2023. No concluir que todas las comisiones sean incompatibles con
 relaciones largas. Cambiar la medida: margen cobrado, retención, calidad de asesoría y reclamos,
 con reglas para factores fuera de control. Un componente fijo sostiene continuidad; parte variable
 reconoce resultados verificables y diferidos. Separar equipos puede ayudar a especializar o
 fragmentar responsabilidad; compararlo con capacitación y cartera compartida. Pilotear y revisar
 ventas, renovación, servicio, colaboración y costo. La pauta estudiantil plantea alternativas, no
 evidencia suficiente para declarar una única solución.
 Beneficios de protección, ahorro, flexibilidad y bienestar forman parte del paquete total; no son
 todos “regalos”, porque pueden existir compromisos contractuales o exigencias legales.
 Preferencias varían dentro de cada edad. Un sistema flexible puede permitir elegir con presupuesto
 y opciones claras, evitando sacrificar protecciones esenciales. No asumir automáticamente que
 toda persona joven quiere bonos o toda persona mayor solo seguridad.
Examen de Grado UC | materia, preguntas y respuestas 34

[pág. 35]
Dirección - versión clara y reordenada
 P7. Carrera, sucesión, anclas y capital psicológico
 La carrera combina iniciativa individual y contexto empresarial. Una trayectoria proteana enfatiza
 valores y autogestión; una carrera sin fronteras reconoce movilidad entre organizaciones y roles. No
 elimina responsabilidad de la empresa de ofrecer información, desarrollo y procesos de oportunidad
 justos. Promover al mejor técnico sin evaluar dirección puede llevarlo a un rol inadecuado; una ruta
 dual permite progreso técnico y gerencial.
 Las ocho anclas de los materiales son: gerencial, técnica/funcional, autonomía, creatividad
 empresarial, seguridad, servicio, integración del estilo de vida y desafío. Son preferencias a
 explorar, no etiquetas permanentes. Una experta puede priorizar autonomía hoy y estabilidad
 después. Diagnosticar con experiencias, decisiones y conversación evita inferir el ancla solo por
 profesión.
 La meseta puede ser estructural -no hay ascensos-, de contenido -no hay aprendizaje- o vital -el
 trabajo ya no conecta con prioridades-. Las respuestas difieren: ruta dual o movilidad lateral;
 proyectos y formación; flexibilidad y reorientación. Inventarios de capacidades y planes de sucesión
 deben distinguir desempeño actual de potencial en un rol futuro. Una matriz de nueve casillas
 organiza conversación, sin demostrar por sí misma talento ni predecir desempeño futuro. Se
 necesitan criterios, experiencias de prueba y revisión de sesgos.
 El capital psicológico reúne autoeficacia -confianza en capacidad para una tarea-; esperanza
 -metas, caminos y energía para avanzar-; optimismo -interpretar obstáculos sin dar por perdido el
 futuro-; resiliencia -adaptar y recuperar funcionamiento frente a adversidad-. No son la misma
 variable. Confianza no prueba competencia, optimismo no exige negar riesgos y resiliencia no
 justifica soportar abuso. Se desarrollan mediante experiencias graduadas, feedback, alternativas y
 apoyo, junto a condiciones de trabajo adecuadas.
 Las redes profesionales y de apoyo aportan información, confianza, mentoría y acceso a
 oportunidades. Vínculos fuertes y débiles pueden cumplir funciones diferentes; cantidad de
 contactos no mide calidad. Cuidar reciprocidad y diversidad evita que networking sea una forma de
 cerrar oportunidades a quienes carecen de contactos.
 Caso resuelto. Una científica competente rechaza una jefatura y piensa salir. Averiguar si pesa
 autonomía, tarea técnica o integración vital; no diagnosticar falta de ambición. Diseñar nivel experto
 con responsabilidad técnica, proyectos y mentoría, remuneración comparable según contribución y
 requisitos, criterios transparentes y preparación de sucesores. Si requiere apoyo para liderar
 proyectos, practicar en un alcance acotado y evaluar. Medir aprendizaje, calidad, cooperación y
 permanencia sin prometer que el cargo retendrá a cualquier persona.
 P8. Cultura, clima, liderazgo y coordinación relacional
 Schein distingue artefactos, valores expresados y supuestos básicos. El edificio o un lema es
 observable; inferir valores exige preguntar y examinar prácticas; los supuestos se revelan
 especialmente cuando hay conflicto. Una empresa declara seguridad y premia entregar aunque se
 omita un control: esa decisión indica una prioridad real distinta. Cambiar carteles no cambia
 automáticamente un supuesto arraigado.
Examen de Grado UC | materia, preguntas y respuestas 35

[pág. 36]
Dirección - versión clara y reordenada
 El marco de valores en competencia de Cameron y Quinn combina foco interno/externo y
 flexibilidad/estabilidad. Clan enfatiza integración y relaciones; adhocracia, experimentación;
 mercado, logro externo; jerarquía, orden y consistencia. Son tipos de cultura, no los mismos objetos
 que las configuraciones estructurales de Mintzberg. Una operación puede necesitar disciplina en
 seguridad y flexibilidad al innovar. Diagnosticar tensiones entre valores y exigencias es más útil que
 elegir un tipo “bueno”.
 Clima examina percepciones del entorno laboral; cultura examina significados y supuestos;
 satisfacción evalúa experiencia; engagement expresa involucramiento. No son indicadores
 intercambiables. Los materiales de Raineri trabajan seis dimensiones de clima: claridad,
 estándares, responsabilidad, flexibilidad, recompensas y compromiso de equipo. Otros resúmenes
 presentan nueve dimensiones: declarar qué marco se usa y qué se está midiendo. Comparar
 tendencias requiere instrumento, población y condiciones comparables.
 Los seis estilos de liderazgo requieren contexto. Orientativo aclara dirección y deja medios;
 democrático incorpora información y participación; afiliativo cuida relaciones; formativo desarrolla
 capacidades; ejemplar eleva exigencia mediante modelo; coercitivo exige respuesta inmediata. Un
 estilo puede resolver una urgencia y erosionar autonomía si se vuelve permanente. Humillar no es
 una competencia necesaria del liderazgo coercitivo. La participación tampoco debe simularse
 cuando la decisión ya está tomada. Diagnosticar capacidad, urgencia, confianza y tipo de tarea
 antes de recomendar.
 La coordinación relacional integra comunicación frecuente, oportuna, precisa y orientada a
 resolver problemas, con metas compartidas, conocimiento compartido y respeto mutuo. Importa
 especialmente con interdependencia, incertidumbre y presión temporal. En una clínica, agenda,
 médico y laboratorio necesitan comprender consecuencias recíprocas. Reuniones sin información
 pertinente o incentivos incompatibles pueden aumentar costo sin coordinación. Un sistema común
 de datos, reglas de escalamiento, objetivos compartidos y retroalimentación sobre incidentes
 convierte la relación en práctica.
 Intervención trabajada. Comercial promete entrega48horas y operaciones evalúa solo costo.
 Diagnóstico: revisar pedidos excepcionales, compromisos, retrasos y entrevistas entre áreas;
 identificar si fallan información, objetivos o recursos. Crear una promesa de servicio verificable,
 visibilidad de capacidad y un responsable para excepciones. Medir cumplimiento y costo juntos,
 mantener umbral de calidad y revisar conflictos con datos. Capacitar en colaboración ayuda si
 existen facultades y procesos que permiten ejercerla.
 Las diferencias culturales entre países orientan preguntas sobre comunicación, jerarquía y
 negociación; no autorizan predecir individuos por nacionalidad. Algunas listas de los apuntes
 simplifican grupos completos. Un administrador transcultural comprueba preferencias, escucha y
 adapta procesos, evitando convertir una generalización en criterio de selección.
Examen de Grado UC | materia, preguntas y respuestas 36

[pág. 37]
Dirección - versión clara y reordenada
 P9. Relaciones laborales, seguridad, disciplina y salidas
 Las relaciones laborales requieren representación, confianza y mecanismos de voz. Sindicatos
 pueden expresar intereses económicos, sociales y preocupaciones sobre trato. Una agenda
 multidimensional reúne remuneración, seguridad, productividad, tecnología y desarrollo.
 Comunicación periódica no reemplaza negociación ni participación efectiva. La ausencia de quejas
 puede reflejar miedo, no paz laboral.
 Para preparar una negociación, identificar intereses de ambas partes, alternativas, restricciones,
 información y un rango de acuerdos posibles. Distinguir una demanda distributiva de oportunidades
 conjuntas: capacitación o programación pueden mejorar bienestar y productividad; repartir ese
 beneficio sigue requiriendo acuerdo. No asumir que colaboración elimina todo conflicto. Las cifras
 de quórums, plazos, fueros o causales incluidas en resúmenes históricos no se reproducen como
 normativa vigente. Aquí se estudia el mecanismo de dirección; si una pregunta requiere derecho
 actual, debe consultarse la norma oficial pertinente al caso.
 Seguridad y bienestar requieren identificar riesgos, controlar su origen, diseñar trabajo seguro,
 formar, registrar incidentes y aprender sin ocultarlos. Medir solo accidentes declarados puede
 incentivar silencio. Incorporar incidentes, condiciones y capacidad de reportar, resguardando
 integridad del dato. Ergonomía, cargas, acoso y salud psicosocial son problemas de diseño y trato,
 además de responsabilidades normativas. No se promete que una charla prevenga cualquier
 accidente.
 La disciplina debe distinguir incapacidad, falta de medios e incumplimiento deliberado. Normas
 conocidas, investigación, documentación, oportunidad de explicación y revisión ayudan a
 decisiones defendibles. Un procedimiento uniforme puede ser injusto si ignora hechos relevantes;
 discreción sin criterios puede ser arbitraria. No presentar una secuencia de sanciones de un
 resumen como obligación jurídica universal.
 Una salida puede responder a retiro, decisión voluntaria, desempeño, reconversión o reducción de
 actividad; no implica siempre que la persona sea incompetente. Antes de una reestructuración,
 comparar reasignación, formación, cambios de operación y otras alternativas viables. Si hay
 desvinculaciones, criterios claros y trato respetuoso protegen a afectados y a quienes permanecen.
 El “síndrome del superviviente” describe inseguridad, culpa o desconfianza que pueden degradar
 desempeño; requiere comunicación honesta, cargas razonables y apoyo.
 Outplacement facilita búsqueda, redes y formación para reinsertarse; no garantiza empleo. La
 entrevista de salida recoge información sobre experiencia y motivos; contrastar tendencias y
 asegurar confidencialidad evita tratar una opinión como causa definitiva. En una comunicación de
 despido, claridad, explicación, escucha y pasos posteriores importan; las reglas de “tres minutos” o
 “veinte minutos” de ciertos apuntes son recomendaciones situacionales, no estándares infalibles ni
 exigencias legales.
 P10. Responder un caso integrando diagnóstico y decisión
 Una buena respuesta parte de un problema verificable, identifica mecanismos alternativos y
 selecciona los relevantes. Luego propone un conjunto coherente y priorizado de prácticas, justifica
 sus costos y límites y define cómo comprobar resultados.
Examen de Grado UC | materia, preguntas y respuestas 37

[pág. 38]
Dirección - versión clara y reordenada
 Caso integral resuelto. Una firma amplía servicio técnico; aumenta rotación, fallas y reclamos. La
 gerencia propone pagar más y contratar una estrella. Primero separar tasas por zona y antigüedad;
 observar tiempos, carga, herramientas y promesas de reclutamiento. Hipótesis: escasez de
 capacidad y repuestos -O-, brecha de diagnóstico -A-, bono que premia cantidad -M- y autonomía
 prometida incumplida -contrato psicológico-. El desempeño de una estrella en otra firma dependía
 además de redes y rutinas específicas.
 Prioridad1: estabilizar cargas y disponibilidad de repuestos para que la tarea sea realizable; definir
 coordinación entre agenda, técnicos y compras. Prioridad2: formación con práctica y seguimiento
 de fallas; selección mediante muestra de trabajo y STAR para coordinación. Prioridad3: reformar
 incentivo con calidad, repetición de fallas y cumplimiento, ajustar equidad salarial con evidencia de
 mercado y dar feedback útil. Prioridad4: ruta técnica y mentoría para sostener aprendizaje y carrera.
 Las cuatro medidas se refuerzan; una banda competitiva no reemplaza recursos y una formación no
 corrige un incentivo contrario.
 Pilotear dos zonas comparables; medir fallas por mezcla de casos, tiempo de atención, reclamos,
 ausentismo y salidas por cohorte; revisar costos y cargas. Si mejora una zona por menor demanda,
 no atribuirlo sin más al piloto. La recomendación cambia si los datos muestran causas distintas. Esa
 capacidad de explicar, contrastar y adaptar vale más que recitar AMO, VRIO o cultura.
Examen de Grado UC | materia, preguntas y respuestas 38

[pág. 39]
Dirección - versión clara y reordenada
 PARTE II - DIRECCIÓN DE EMPRESAS Y
 ESTRATEGIA
 I. Dirección de Empresas y Estrategia
 1. Propósito, diagnóstico y ventaja competitiva
 Estrategia es un conjunto coherente de elecciones de largo plazo sobre dónde competir y cómo
 crear/capturar valor bajo incertidumbre, con renuncias y actividades que se refuerzan. Visión o meta
 de crecimiento sin elección, recursos ni renuncias no es estrategia.
 Diagnóstico externo: PESTEL identifica fuerzas macro; cinco fuerzas analiza estructura y poder en
 industria (rivalidad, entrada, sustitutos, compradores, proveedores). Aclara industria/segmento y no
 confundas competidor directo con sustituto. La rentabilidad sectorial no predice automáticamente
 rentabilidad de una empresa.
 Diagnóstico interno: recursos (activos tangibles/intangibles) y capacidades (rutinas que los
 combinan). VRIO pregunta si son valiosos, raros, difíciles de imitar y organizados para capturar
 valor. Una fortaleza solo genera ventaja si mejora disposición a pagar o costo y es relevante al
 mercado. Cadena de valor localiza actividades y complementariedades; no asumas que
 «outsourcing» reduce costos totales sin considerar coordinación, aprendizaje y riesgo.
 Ventaja competitiva puede basarse en costo, diferenciación o enfoque, pero el mecanismo debe ser
 verificable: ¿qué actividad reduce costo total o aumenta beneficio percibido?, ¿por qué competidor
 no puede copiarlo rápido?, ¿qué segmento valora esa diferencia? El desempeño requiere métrica
 económica y comparación con referencia, ajustada por riesgo y ciclo.
 2. Modelo de negocio y creación/captura de valor
 Un modelo de negocio articula segmento, problema/necesidad, propuesta de valor,
 actividades/recursos/aliados, ingresos y costos. En plataformas distingue lados, efectos de red,
 subsidios, gobernanza, confianza y multihoming. Crecimiento de usuarios puede destruir valor si
 adquisición/subsidio supera margen de vida o intensifica congestión.
 Para probar coherencia pregunta: ¿quién paga?, ¿por qué?, ¿qué actividad crítica entrega
 promesa?, ¿cómo se apropia valor?, ¿qué supuesto haría fracasar el modelo? Define experimento
 que reduzca incertidumbre antes de escalar. ROI y crecimiento son resultados; no sustituyen
 hipótesis de mecanismo.
 3. Crecimiento, diversificación, integración y alianzas
 La matriz producto/mercado ayuda a ordenar penetración, desarrollo de mercado, desarrollo de
 producto y diversificación; el riesgo y capacidades requeridas aumentan cuando se aleja de
 competencias/clientes conocidos. Para integración vertical compara costos de mercado con
 coordinación interna, especificidad de activos, incertidumbre, oportunismo, velocidad e incentivos.
 Integrar puede capturar margen o proteger calidad, pero reduce flexibilidad y añade complejidad.
Examen de Grado UC | materia, preguntas y respuestas 39

[pág. 40]
Dirección - versión clara y reordenada
 Diversificar solo crea valor si hay economías de alcance, capacidades transferibles, capital interno
 superior o reducción de riesgo no replicable por accionistas, neto de costos de
 coordinación/agencia. Alianza/acuerdo requiere complementariedad, incentivos, derechos de
 decisión, intercambio de conocimiento, métricas, salida y salvaguardas.
 En adquisición, estima valor stand-alone, precio pagado, sinergia realizable, costos de integración,
 tiempo, riesgo y alternativas orgánicas. Un comprador puede pagar toda la sinergia al vendedor.
 Analiza integración cultural, talento clave, clientes, sistemas, marca y gobierno.
 4. Cambio competitivo, imitación y entrada
 Un entrante puede desalentar entrada si una acción creíble hace menos atractivo el mercado
 (capacidad comprometida, reputación, costo de cambio, contratos, respuesta probable). La
 amenaza solo disuade si es observable, sostenible y racional ex ante. Precios depredatorios o
 promesas de reacción sin capacidad/credibilidad no constituyen barreras por sí solos. Evalúa
 respuesta del incumbente, represalias, costo hundido y legitimidad/regulación.
 5. Implementación, estructura y control
 La estructura debe facilitar actividades estratégicas: especialización funcional escala conocimiento;
 estructura divisional acerca decisión a producto/mercado; matriz coordina dimensiones pero genera
 doble autoridad. Diseña derechos de decisión, incentivos, información y mecanismos de
 coordinación a partir de interdependencias. Cultura puede apoyar o bloquear estrategia; declara
 prácticas observables que la sostienen, no adjetivos vagos.
 Cuadro de mando equilibra resultados financieros, clientes, procesos y capacidades. Cada
 indicador debe tener fórmula, dueño, frecuencia, meta y umbral con respuesta. Distingue KPI de
 resultado (retorno, margen) y adelantado (adopción, retención, calidad, tiempo). Un sistema de
 control útil permite aprendizaje: compara hipótesis, resultado, causa y ajuste, no solo castiga
 desvíos.
 Plantilla de recomendación estratégica
 Problema: la empresa debe decidir __ en el negocio/mercado __. Diagnóstico: el
 atractivo/amenaza __; la capacidad/ventaja __; evidencia __. Elección: competir en __ para __
 mediante __, renunciando a __. Coherencia: actividades __ se refuerzan y son difíciles de copiar
 porque __. Ejecución: dueño __; recursos __; fases __; riesgo __ y mitigación __. Prueba/control:
 hipótesis __; indicador __; fecha/umbral __; si falla, __.
Examen de Grado UC | materia, preguntas y respuestas 40

[pág. 41]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia desde cero
 1. La estrategia como un sistema de decisiones y una hipótesis
 de valor
 Una estrategia explica a quién atenderá la empresa, qué necesidad resolverá, qué actividades
 realizará y por qué esa combinación permitirá producir y retener valor en el tiempo. No se agota en
 crecer, ser líder o aumentar utilidades: esos son resultados deseados que necesitan una
 explicación. Tampoco equivale a un presupuesto. El presupuesto cuantifica consecuencias de
 decisiones; no explica por sí mismo de dónde vendrá una preferencia del cliente o una ventaja en
 costos. Los apuntes de José Rivera distinguen formulación, implementación y control, e introducen
 el enfoque sistémico y contingente: las áreas son interdependientes y su diseño debe responder al
 entorno y al negocio particular. Esas perspectivas impiden recomendar una misma receta para
 cualquier caso. (F0606, pp. 1-4; F0904, pp. 1-5; F0873, pp. 1-3).
 La formulación comienza definiendo el negocio mediante necesidad, segmento y forma de competir.
 Una productora de agua no necesariamente compite por la misma necesidad que una plataforma de
 pagos, aunque ambas busquen rentabilidad. Dentro de una industria también pueden coexistir
 negocios distintos: transportar carga con una red de pasajeros no es la misma propuesta que
 ofrecer vuelos simples y frecuentes. Esta definición permite escoger competidores relevantes y
 evitar un análisis de industria tan amplio que mezcle fuerzas incompatibles. A continuación se
 diagnostica el entorno y la propia cadena de actividades, se elige una posición futura y se identifica
 la capacidad que deberá construirse para llegar a ella. (F0606, pp. 6-9 y 24-25; F0904, pp. 4-7).
 Michael Porter aparece en estos materiales asociado a la distinción entre eficacia operacional y
 posicionamiento. La primera consiste en hacer mejor actividades comparables: reducir errores,
 utilizar capacidad o acelerar un proceso. El posicionamiento configura actividades o prioridades
 diferentes para atender una necesidad de una forma específica. Ambos se necesitan. Una buena
 propuesta fracasa si no se ejecuta; una mejora aislada puede ser copiada y trasladarse a menores
 precios para los clientes. Sin embargo, tampoco corresponde afirmar que toda eficiencia es
 fácilmente imitable: un sistema de aprendizaje, logística y coordinación puede ser costoso de
 reproducir. Hay que estudiar el mecanismo de imitación y sus plazos. (F0606, pp. 3-4; F0873, pp.
 10-16).
 Los conflictos de elección permiten sostener una posición: ofrecer toda característica a todo cliente
 puede encarecer la operación o diluir aquello que genera preferencia. Hermes renuncia a volumen
 masivo, automatización y promociones; esa renuncia protege artesanía y exclusividad. Su
 estrategia no es irracional porque difiera de sus rivales. Para juzgarla hay que preguntar si el cliente
 objetivo valora lo obtenido, si el precio cubre el costo económico y si las prácticas se refuerzan. En
 cambio, una restricción mantenida solo por tradición puede volverse un obstáculo cuando cambian
 las necesidades. La fidelidad a una identidad requiere preservar el mecanismo de valor, no congelar
 cada práctica histórica. (F0606, pp. 4 y 17-23; caso Hermes, fuente histórica pp. 417-418).
 La evaluación usa cuatro comprobaciones relacionadas. La posición debe ser compatible con el
 entorno que se anticipa; los recursos actuales o construibles deben permitirla; debe existir una
 diferencia económicamente relevante; y la transición debe ser factible en dinero, personas y tiempo.
 Esto obliga a describir también el punto de partida. Macy's puede decidir reforzar tiendas físicas,
Examen de Grado UC | materia, preguntas y respuestas 41

[pág. 42]
Dirección - versión clara y reordenada
 pero necesita examinar ubicaciones, inventarios, costos y clientes actuales; un anuncio de intención
 no garantiza rentabilidad. Una recomendación útil explicita qué debe cambiar primero y cuál señal
 mostraría que la hipótesis estaba equivocada. (F0606, pp. 4 y 25; F0904, pp. 2, 15-16 y 19; Macy's,
 fuente pp. 431-432).
 Para implementar, se traduce la posición a procesos críticos y responsables. Por ejemplo, si la
 propuesta es confiabilidad, no basta medir ventas: se requieren calidad, cumplimiento de entrega,
 manejo de incidentes y aprendizaje. El control entrega información para actuar y revisar la hipótesis;
 no es un informe de castigos al final del año. Una cadena causal explícita podría ser formación
 técnica → menos fallas → mayor retención → margen suficiente. Las flechas son hipótesis que
 deben contrastarse; un mapa dibujado no constituye evidencia causal. (F0606, pp. 25 y 30-33;
 F0904, pp. 19-24).
 El nivel corporativo decide en qué negocios participar y cómo la administración común agrega valor.
 El nivel de negocio explica cómo competir en cada actividad. El funcional determina la contribución
 de operaciones, Personas, Finanzas u otras áreas a esa estrategia. Esta distinción evita responder
 una pregunta corporativa de Nubank solo con una lista de atributos de su aplicación: la cuestión es
 cómo finanzas y conectividad aumentan su valor conjunto. También evita convertir un problema de
 selección de personal en una decisión de mercado sin revisar las competencias necesarias. (F0606,
 pp. 6 y 26; Nubank, fuente pp. 441-442).
 2. Creación, captura, distribución y medición del valor
 La disposición a pagar representa el máximo que un cliente estaría dispuesto a sacrificar por una
 oferta. El precio es lo que efectivamente paga. El costo económico incluye recursos utilizados y
 oportunidades sacrificadas, incluido el capital; el costo contable no siempre lo refleja. En una
 representación simple por unidad, si B es disposición a pagar, P precio y C costo económico, el
 valor creado es B-C; el excedente del cliente es B-P; y la captura de la empresa es P-C. Multiplicar
 por Q solo es válido para unidades y clientes comparables: con segmentos heterogéneos deben
 sumarse sus resultados. La representación es un instrumento analítico, no una medición completa
 disponible en todo caso. (F0606, pp. 5 y 7; F0904, pp. 3 y 10-11; F0873, pp. 19-20).
 Una ilustración ayuda a separar mecanismos. Supóngase una oferta con B=120, P=90 y C=60: crea
 60, el cliente conserva 30 y la empresa captura 30. Una mejora que eleva B a 135 y C a 65 crea 70.
 Si el precio permanece en 90, la captura cae a 25 aunque el valor total aumente. Si la empresa
 consigue P=100, captura 35 y el cliente conserva 35. La mejora puede ser valiosa sin aumentar
 automáticamente la utilidad; capturar exige que la negociación, rivalidad y alternativas permitan
 cobrar o retener el beneficio. Estas cifras son didácticas y no pertenecen a un caso histórico.
 También puede aumentar la captura sin crear más valor total: subir precio, manteniendo B y C,
 redistribuye excedente desde el cliente. Una reducción de costo que disminuya seguridad o calidad
 puede reducir B más que C y destruir valor. Aumentar ventas a través de descuentos puede elevar
 Q pero reducir contribución por unidad, exigir capital de trabajo y canibalizar clientes existentes. Por
 eso hay que examinar cantidades, márgenes, inversiones y efectos sobre otros productos, además
 de ingresos. (F0606, pp. 5, 18-20 y 27; F0873, pp. 13-15).
 La captura depende de quién controla recursos escasos y de sus alternativas. Si la tecnología es
 vendida por un proveedor dominante, puede capturar una parte del ahorro que obtiene el usuario. Si
Examen de Grado UC | materia, preguntas y respuestas 42

[pág. 43]
Dirección - versión clara y reordenada
 abundan productores pero hay pocos compradores, el precio pagado al proveedor puede quedar
 comprimido. Manantial permite comparar el control concentrado de fuentes de agua con la
 propiedad dispersa: la calidad y el acceso siguen importando, pero cambian las alternativas de
 negociación y la apropiación de la renta. No corresponde asignar un valor al derecho de agua solo
 porque el recurso existe o porque un comprador lo aprecia; deben examinarse restricciones,
 alternativas y valor neto de uso. (F0606, pp. 5 y 9-11; Manantial, fuente pp. 75-76).
 Una ventaja competitiva implica desempeño económico superior atribuible a una diferencia
 relevante frente a alternativas comparables. Generar rentabilidad mayor al costo de capital
 demuestra creación de valor para el capital bajo una medición consistente, pero no demuestra por
 sí solo superioridad relativa: toda la industria podría disfrutar de un entorno favorable. De forma
 inversa, una empresa puede superar el promedio de una industria y seguir destruyendo valor si el
 promedio está por debajo del costo de oportunidad. La comparación debe ajustar riesgo, capital
 invertido, horizonte y criterios contables. No se deben comparar ROE y WACC, ni indicadores de
 distinta base, como si fueran intercambiables. (F0606, pp. 7-8; F0873, pp. 11 y 19).
 Los estudios de Schmalensee, Rumelt y Roquebert, mencionados en los resúmenes, motivan la
 comparación de efectos de industria, negocio y corporación. Su enseñanza práctica es que no toda
 diferencia de resultados se explica por el sector ni toda corporación crea una gran sinergia. Los
 porcentajes y órdenes de importancia de una muestra no son constantes universales, ni permiten
 atribuir causalidad a una firma particular. Para un caso concreto se requiere reconstruir el
 mecanismo y contrastarlo con datos. Los resúmenes tienen incluso formulaciones contradictorias
 sobre estos estudios; no se conserva esa contradicción como una regla de examen. (F0606, p. 8;
 F0904, pp. 5-6).
 El precio bursátil incorpora expectativas de flujos y riesgo. Un alza ante un anuncio de adquisición
 es compatible con una expectativa favorable; no prueba que las sinergias se hayan realizado.
 Tampoco el cambio porcentual de acciones de empresas de distinto tamaño mide por sí mismo
 quién ganó más dinero. En Viajes Falabella las variaciones de 8% y 0,2% deben relacionarse con
 bases, expectativas y asimetría del aporte al grupo. En Hermes el alza de un año es un indicio, no
 una estimación suficiente de márgenes o valor creado. (F0883, p. 6, sometido a esta corrección;
 Viajes Falabella, fuente pp. 296-297; Hermes, fuente pp. 417-418).
 La sostenibilidad incorpora a quienes hacen viable la creación de valor. Patagonia o Grupo Patio
 permiten examinar si una política ambiental o de apoyo a locatarios conserva recursos, reputación,
 demanda y continuidad, a la vez que cuesta dinero. Distribuir valor no es siempre una pérdida para
 el accionista: puede sostener el sistema que produce ingresos futuros. Tampoco cualquier gasto
 social es estratégico. Se identifican beneficiarios, mecanismo económico, horizonte, costo y
 resultado comprobable. En Grupo Patio, suspender arriendos protege la supervivencia de locatarios
 y la ocupación futura; hay que comparar esa contribución con la pérdida de caja inmediata. (F0873,
 pp. 23-25; Grupo Patio, fuente pp. 325-326).
Examen de Grado UC | materia, preguntas y respuestas 43

[pág. 44]
Dirección - versión clara y reordenada
 3. Estructura competitiva: analizar mecanismos, actores y
 mercado relevante
 El análisis industrial comienza delimitando producto o necesidad, geografía y etapa de la cadena.
 La concentración nacional puede ocultar intensa competencia en una ciudad, mientras una ruta
 específica puede tener pocos operadores. No basta decir que «la industria es competitiva». Debe
 distinguirse entre muchos participantes, sustitución cercana, intensidad de precios y rentabilidad.
 Los cinco mecanismos de Porter examinan entrada, rivalidad, sustitutos, proveedores y
 compradores; complementadores y gobierno completan el diagnóstico cuando alteran valor o
 acceso. (F0606, pp. 8-11; F0873, pp. 5-9; F0904, pp. 6-9).
 Una barrera de entrada debe dar al incumbente una ventaja frente a quien intenta entrar, no ser
 simplemente un gasto que ambos soportan. Economías de escala obligan al entrante a alcanzar
 volumen o aceptar costo medio mayor. Una reputación acumulada puede exigir tiempo para atraer
 clientes. Canales exclusivos o un recurso escaso pueden limitar acceso. Una licencia puede
 restringir entrada; una tecnología comercial disponible para todos puede reducir barreras. Debe
 separarse la barrera de la reacción esperada del incumbente: la expectativa de una guerra de
 precios afecta la decisión aunque formalmente sea posible ingresar. (F0606, pp. 9 y 15-17; F0873,
 pp. 6 y 8).
 La rivalidad suele intensificarse cuando el crecimiento es lento, las ofertas son sustituibles y existe
 capacidad que las firmas desean ocupar. Con costos fijos altos y costo incremental bajo, vender
 una unidad adicional por encima del costo incremental puede parecer conveniente, aunque el precio
 no cubra todos los costos en el largo plazo. Si varios competidores hacen lo mismo, comprimen
 margen. Las barreras de salida pueden mantener capacidad de firmas que preferirían abandonar,
 agravando el problema. Esto corrige dos afirmaciones invertidas de F0873: menores costos fijos no
 implican siempre mayor rivalidad y mayores barreras de salida no implican menor competencia.
 Ninguna variable se evalúa sola. (F0606, p. 10; F0873, pp. 6-8; F0883, p. 4).
 Un sustituto satisface la necesidad mediante otra solución relevante para el cliente. Su amenaza
 depende de precio, desempeño y costo de cambiar, no de que se parezca físicamente al producto.
 El proveedor tiene poder cuando la empresa depende de un insumo difícil de reemplazar y el
 proveedor posee alternativas mejores. El comprador tiene poder por un razonamiento simétrico:
 concentración, volumen, baja diferenciación o capacidad de abastecerse de otra forma. La
 integración posible debe ser creíble y económicamente viable; nombrarla no basta. (F0606, pp.
 9-10; F0904, p. 8; F0873, p. 6).
 Los complementadores pueden elevar disposición a pagar o demanda: una consola mejora con
 juegos, una plataforma de transporte con más conductores disponibles. Sin embargo, un
 complementador fuerte también puede apropiarse de la renta. La existencia de complementos no
 garantiza mayor rentabilidad para cada participante. Se debe preguntar quién controla el acceso,
 quién paga el desarrollo y cómo se distribuye el beneficio. El gobierno puede alterar permisos,
 estándares y costos, pero una regulación común no necesariamente elimina todas las diferencias
 competitivas. (F0606, pp. 10-11 y 22; F0873, pp. 7 y 25-28).
 BancoEstado ilustra cómo conectar tecnología y estructura. La IA puede facilitar entrada de fintechs
 y profundizar rivalidad, aumentar opciones de clientes jóvenes y reforzar escala de datos o alianzas
 tecnológicas. Automatizar tareas y detectar fraudes son aplicaciones que explican parte de esos
Examen de Grado UC | materia, preguntas y respuestas 44

[pág. 45]
Dirección - versión clara y reordenada
 efectos; no sustituyen el diagnóstico competitivo. El efecto sobre rentabilidad depende de inversión
 neta, pérdidas evitadas y cuánto del ahorro se traslada a clientes. Los riesgos de modelo,
 ciberseguridad y confianza se relacionan con el mecanismo, no se agregan como una lista
 desligada. (BancoEstado, fuente pp. 409-410; F0606, pp. 9-11).
 La concentración y el HHI describen distribución de participaciones bajo una definición de mercado
 y de unidad competitiva. No permiten inferir automáticamente colusión ni rentabilidad. Una alianza
 que coordina capacidad puede cambiar un indicador operativo sin ser una fusión, y la participación
 no equivale a control comercial de precios. En P3 se deben respetar los supuestos de capacidad
 del caso y distinguirlos de propiedad y venta. La evolución de precios y cuotas es información que
 orienta una hipótesis; por sí sola no acredita un acuerdo anticompetitivo. (P3, fuente pp. 144-145;
 F0873, p. 7, sometido a esta precisión).
 Las categorías emergente, madura, declinante y fragmentada sirven para formular preguntas, no
 para imponer una trayectoria. Una industria fragmentada puede no tener economías de escala
 aprovechables, de modo que comprar competidores no garantiza consolidación rentable. Madurez
 no elimina toda diferenciación ni obliga a competir solo en precio. Declive puede admitir nichos o
 cosecha, pero sus flujos y barreras de salida deben evaluarse. Mover primero es valioso si produce
 aprendizaje, activos o costos de cambio defendibles; puede ser desventajoso cuando paga
 experimentación que imitadores aprovechan. (F0606, pp. 11 y 29; F0873, pp. 7 y 32-34; F0904, pp.
 8 y 18-19).
 4. Dinámica competitiva, compromisos y teoría de juegos
 La empresa actúa frente a rivales que responden. Una recomendación que conserva fijos sus
 precios, capacidad y conducta después de una entrada o adquisición puede sobreestimar el
 resultado. El perfil de respuesta de Porter estudia estrategia actual, capacidades, metas y
 supuestos del rival. Saber qué puede hacer difiere de saber qué le conviene hacer. Una firma con
 caja puede sostener una guerra, pero quizá prefiera acomodar entrada si defender el mercado
 cuesta más que la renta conservada. (F0606, pp. 13-17; F0904, pp. 9-10; F0873, pp. 8-9).
 La teoría de juegos obliga a especificar jugadores, decisiones, información, orden y pagos. En
 decisiones simultáneas se buscan mejores respuestas mutuas: un equilibrio de Nash es una
 combinación en que ningún jugador mejora cambiando solo su decisión, dadas las de los demás.
 No significa que sea el mejor resultado conjunto. En decisiones secuenciales se empieza por la
 elección que enfrentará el último jugador y se retrocede: la respuesta futura cambia el valor de la
 decisión inicial. Una amenaza que sería inconveniente ejecutar llegado el momento no es creíble
 salvo que exista un compromiso que modifique pagos o posibilidades. (F0606, pp. 15-17).
 En un ejemplo didáctico, un incumbente obtiene 8 si no entra nadie. Con entrada puede acomodar y
 obtener 4, o combatir y obtener 1. Si el entrante ganaría 3 al ser acomodado y perdería 2 bajo
 combate, anunciar «combatiré» no disuade a un rival que entiende que el incumbente preferirá 4 a
 1 después de su llegada. Una inversión irreversible que haga el combate menos costoso puede
 cambiar la respuesta; una simple frase no. Hay que distinguir el costo hundido del costo futuro
 relevante: lo hundido puede modificar compromisos o capacidad, pero no se recupera justificando
 una mala acción posterior. Las cifras de este ejemplo no pertenecen al banco.
Examen de Grado UC | materia, preguntas y respuestas 45

[pág. 46]
Dirección - versión clara y reordenada
 Flixbus permite aplicar ese razonamiento sin inventar una matriz numérica. Antes de la compra de
 Postbus, aumentar servicio en una zona amenazada puede tener un motivo de disuasión. Después
 de eliminar esa amenaza específica cambia la conveniencia de conservar el esfuerzo. El caso
 muestra en Norte menos rutas y frecuencia y mayor ocupación; no permite decir que allí se duplicó
 capacidad por compra, porque Postbus no operaba en esa región. La evidencia antes/después es
 compatible con una hipótesis estratégica, pero no aísla todas las causas. (Flixbus, fuente pp.
 452-453).
 En el mismo caso, arrendar buses y aumentar frecuencia es relativamente reversible; construir una
 marca requiere tiempo y activos reputacionales; terminales propios exigen inversión específica y
 pueden dar control de acceso. La capacidad disuasoria se evalúa por credibilidad, irreversibilidad,
 costo para el entrante y conveniencia de operar después de entrada. El orden terminales > marca >
 arriendo es una conclusión condicionada a su uso efectivo, no una regla aplicable a cualquier
 transporte. Una terminal inútil solo destruye capital. Un contrato de arriendo firme puede ser menos
 reversible que un activo vendible. (F0606, pp. 4-5 y 16-17; Flixbus, fuente pp. 452-453).
 Las guerras de precio se explican por estructura y por expectativas. Costos fijos, escala,
 aprendizaje y baja diferenciación pueden favorecer descuentos para ocupar capacidad o captar
 base. Pero no es correcto prometer que los sobrevivientes siempre recuperarán pérdidas subiendo
 precios: pueden persistir entrada, sustitución o poder comprador. Los clientes ganan por menor
 precio en el corto plazo si calidad se conserva; empleados, proveedores y firmas pueden soportar
 costos. La evaluación de largo plazo exige analizar salida, futura entrada y condiciones del
 producto. (F0883, pp. 4-5; F0873, p. 8; caso Cloud Computing, fuente pp. 166-167).
 Los mapas de grupos estratégicos resumen posiciones con dos dimensiones que expliquen
 decisiones diferentes. Elegir dos variables casi idénticas desperdicia información; elegir precio y
 una característica sin importancia para el comprador produce un dibujo decorativo. Los espacios
 vacíos pueden revelar una propuesta sin demanda o económicamente inviable. Es útil comparar
 mapas en el tiempo para estudiar movilidad y respuesta, pero no deducir una oportunidad solo por
 ausencia de rivales. (F0606, pp. 14-15; F0904, pp. 9-10; F0873, p. 9).
 La principal limitación de juegos y perfiles es la información: pagos, capacidades o creencias
 pueden no estar identificados. En ese caso se construyen escenarios y se observa qué
 recomendaciones sobreviven al cambio de supuestos. No se asigna un número ficticio para
 aparentar precisión. La colaboración se evalúa por el valor que crea y su gobernanza; coordinación
 no autoriza sustituir competencia comercial por pactos de precios o territorios. El material local
 contiene ejemplos de cooperación que requieren distinguir esos ámbitos. (F0606, pp. 16-17).
 5. Cadena de valor, recursos, capacidades y sostenibilidad
 El análisis interno reconstruye cómo se entrega el resultado por el que el cliente paga. La cadena
 de valor incluye actividades de diseño, abastecimiento, producción, venta, distribución y servicio,
 además de las que habilitan información, personas y coordinación. «Primaria» o «apoyo» no
 equivale a importante o prescindible. Una actividad de RRHH puede ser determinante si crea la
 capacidad de atención o innovación. Se compara cada actividad con alternativas pertinentes y se
 examinan sus enlaces: una compra barata que eleve fallas en producción puede ser un ahorro
 aparente. (F0606, pp. 18-21; F0873, pp. 10-13).
Examen de Grado UC | materia, preguntas y respuestas 46

[pág. 47]
Dirección - versión clara y reordenada
 Los recursos son activos controlados; las capacidades son formas de usarlos de manera repetible.
 Una base de datos no es lo mismo que la capacidad de limpiarla, interpretarla y convertirla en
 decisiones. Tener artesanos no es lo mismo que seleccionar, formar y coordinar especialidades
 para obtener calidad. La perspectiva basada en recursos parte de heterogeneidad y de movilidad
 imperfecta: algunas combinaciones difieren entre empresas y cuesta trasladarlas. No deben
 confundirse recursos con elementos solamente tangibles; reputación, rutinas o vínculos también
 cuentan. (F0606, pp. 20-22; F0873, pp. 10-12).
 VRIO evalúa cuatro preguntas encadenadas. Valor: ¿eleva disposición a pagar o reduce un costo
 relevante en este contexto? Rareza: ¿cuántos rivales cuentan con una alternativa funcionalmente
 equivalente? Imitación: ¿pueden copiar o sustituir el beneficio con costo y tiempo razonables?
 Organización: ¿derechos, incentivos y procesos permiten explotar y retenerlo? Un recurso valioso
 común permite competir, pero no asegura superioridad. Uno raro fácilmente adquirible puede
 producir una ventaja temporal. Uno difícil de imitar mal gobernado puede beneficiar a otra parte o
 permanecer ocioso. La conclusión es condicionada y dinámica. (F0606, pp. 12 y 21-22; F0873, p.
 11).
 Una competencia central es aprendizaje colectivo que coordina habilidades y tecnologías para
 producir beneficios relevantes y abrir aplicaciones. El nombre de una empresa o «calidad» no
 describe esa competencia. En Hermes, oficio transmitido, selección, materiales, control del volumen
 y coordinación de más de 15 especialidades forman un sistema. La escasez refuerza el deseo
 cuando hay calidad auténtica; calidad y reputación legitiman precio; el margen permite mantener
 formación y control. Separar escasez de calidad o aumentar capacidad sin transmisión del oficio
 debilita el ciclo. (F0606, pp. 21-22; Hermes, fuente pp. 417-418).
 Las complementariedades significan que el rendimiento de una práctica mejora con otra. Simplificar
 una flota puede facilitar mantenimiento, formación y rotación rápida; esa rotación vuelve posible
 frecuencia y costos menores. Copiar solo el precio no reproduce el sistema de una aerolínea
 eficiente. La robustez exige identificar enlaces y conflictos, no enumerar prácticas conocidas. En
 Husky, velocidad, duración, servicios técnicos y solución conjunta de máquina y moldes se analizan
 por ahorro y desempeño para el cliente; la etiqueta «tecnología» no explica el resultado. (F0873, pp.
 16-18; F0606, pp. 18-23).
 La ventaja puede erosionarse por imitación, sustitución, ineficiencia o apropiación de renta por otra
 parte. Imitación reproduce una solución; sustitución satisface la necesidad de otra manera. La
 ambigüedad causal dificulta identificar qué copiar; la historia y aprendizaje acumulados dificultan
 acelerar reproducción; relaciones y reputación pueden no transferirse con una compra. Pero esas
 protecciones son hipótesis que se contrastan con desempeño de rivales. Vodafone no demuestra
 una ventaja solo por su tamaño si las redes son replicables y un entrante obtiene buenos
 resultados. (F0606, pp. 21-23; Vodafone, fuente pp. 232-233).
 Renovar capacidades puede exigir abandonar rutinas exitosas. Los materiales describen
 BlackBerry como ilustración de rigidez y pérdida de coordinación frente a nuevas necesidades y
 tecnologías. La enseñanza no es que innovar siempre más garantice supervivencia, sino que debe
 detectarse cuál necesidad cambia, qué recursos quedan obsoletos y qué nuevas combinaciones
 deben desarrollarse. La historia resumida no constituye por sí sola evidencia causal completa del
 fracaso de la compañía. (F0873, pp. 20-21; F0606, p. 6).
Examen de Grado UC | materia, preguntas y respuestas 47

[pág. 48]
Dirección - versión clara y reordenada
 Se implementa una renovación asignando responsables a áreas críticas, financiando aprendizaje y
 estableciendo indicadores de capacidades y resultados. Si una tecnología es vendida a todos, la
 ventaja puede residir en integración, datos, organización o una relación que mejora su uso. Las
 medidas deben incluir costos de transformación y efectos en el sistema existente. No se sacrifica
 una capacidad todavía rentable solo para adoptar la moda tecnológica. La prueba es cuánto valor
 adicional se produce, quién lo captura y durante cuánto tiempo será defendible. (F0606, pp. 20-22 y
 30-35; BancoEstado, fuente pp. 409-410).
 6. Modelos de negocio, plataformas y cambios de la propuesta
 Joan Magretta aparece en los apuntes vinculada a la historia de cómo funciona una empresa; el
 enfoque de opciones y consecuencias permite volver esa historia verificable. Se separan políticas,
 activos y gobierno. Volar a aeropuertos secundarios es una política; una flota es un activo; decidir si
 es propia o arrendada define derechos y obligaciones. Las consecuencias pueden ser flexibles,
 como volumen que cambia rápidamente con precio, o rígidas, como reputación y cultura que se
 modifican lentamente. Un modelo se evalúa por alineación con objetivos, refuerzo entre decisiones
 y resistencia a amenazas. (F0606, pp. 23-24; F0873, pp. 21-23).
 Para estudiar un cambio se dibuja la secuencia opción → proceso → consecuencia → valor. En
 Viajes Falabella la propiedad completa por Despegar, la alianza de diez años, la integración de
 canales y la acumulación/redención CMR alteran distribución, recursos y gobernanza. El acceso
 digital puede ampliar mercado y productividad; el canal físico y relación con clientes puede reducir
 desconfianza; el programa puede reforzar lealtad. Hay costos de compra, tecnología, coordinación
 y posible canibalización que deben descontarse. No se inventan ingresos por comisiones si el caso
 no los identifica. (Viajes Falabella, fuente pp. 296-297; F0606, pp. 23 y 27).
 Una plataforma multilateral coordina lados interdependientes que necesitan propuestas específicas.
 En transporte, usuarios valoran disponibilidad y confiabilidad; conductores valoran viajes e ingresos.
 Más participantes útiles de un lado pueden mejorar el valor para el otro. Ese efecto difiere de una
 economía de escala productiva: no solo baja costo por unidad, cambia la utilidad del servicio. Puede
 ser local, y puede volverse negativo con congestión, baja calidad o competencia excesiva entre
 proveedores. Las métricas deben seguir disponibilidad, tiempos de espera, calidad y permanencia
 de ambos lados, además de volumen total. (F0873, pp. 25-28; F0606, pp. 17 y 22).
 El arranque requiere resolver la falta inicial de contrapartes. Puede subsidiarse un lado, captar un
 segmento concentrado o incorporar oferta antes de expansión. Pero un subsidio solo tiene sentido
 si contribución y retención posteriores compensan inversión; tamaño comprado con pérdidas no
 demuestra una red defendible. Importan facilidad de usar varias plataformas, migración de datos y
 reputación, acceso a usuarios y diferenciación. Una aplicación similar no equivale a una base activa
 ni al sistema de confianza y operación que la sostiene. (F0873, pp. 26-28; caso Uber, fuente pp.
 272-273).
 Operar sin ser dueño del activo no elimina coordinación ni riesgo: la plataforma debe fijar
 estándares, gestionar incidentes y sostener confianza. Tampoco todo negocio de red es
 «colaborativo» o ambientalmente superior. Compartir un activo puede aumentar utilización, pero el
 efecto agregado sobre tráfico o emisiones exige evidencia; no se deduce automáticamente del
 modelo. Las afirmaciones generales de los resúmenes sobre esos efectos se usan como preguntas
 de análisis, no como resultados universales. (F0873, pp. 26-28).
Examen de Grado UC | materia, preguntas y respuestas 48

[pág. 49]
Dirección - versión clara y reordenada
 El crecimiento de una plataforma o línea digital puede amenazar otro negocio del grupo. Chrome
 OS y Office ilustran la diferencia entre atacar un núcleo de rentas y copiar una táctica. Si Microsoft
 responde con Office gratuito en línea, puede legitimar la propuesta web de Google y erosionar su
 propia fuente de ingresos. La alternativa debe considerar sus recursos de distribución y un objetivo
 rival, no solo el producto nuevo. Se distinguen navegador, sistema operativo y buscador para no
 confundir cuotas y fuentes de monetización. (Chrome OS, fuente pp. 17-18).
 El modelo digital se sostiene por acceso, valor y captura, no porque use IA, nube o datos. Nubank
 puede compartir clientes, pagos y personalización con NuCel, pero tendrá que gobernar
 dependencia de redes rivales y demostrar sinergia neta. Así se separan una idea coherente, una
 implementación viable y una ventaja defendible. Los resultados del banco antes del nuevo servicio
 no son el efecto causal de la diversificación. (Nubank, fuente pp. 441-442; F0606, pp. 23-28).
 7. Límites de la empresa: integración, outsourcing, alianzas y
 adquisiciones
 La decisión de hacer, contratar o asociarse compara costos totales y capacidad de coordinación. El
 precio cotizado por un proveedor es solo una parte: se agregan búsqueda, negociación,
 supervisión, adaptación y riesgo de incumplimiento. Integrar añade gestión, capital, incentivos
 internos y posible pérdida de disciplina de mercado. La comparación correcta usa alternativas
 capaces de entregar el mismo resultado y horizonte. Una actividad no se externaliza solo porque
 representa poco ingreso, ni se internaliza solo porque es importante. Importan interdependencia,
 especificidad y posibilidad de gobernarla mediante contrato. (F0606, pp. 26-28; F0873, pp. 28-31).
 La inversión específica pierde valor fuera de una relación: una máquina adaptada a un comprador,
 una red especializada o habilidades ligadas a rutinas particulares. Después de invertir, la parte
 puede quedar expuesta a renegociación oportunista. Frecuencia e incertidumbre vuelven relevantes
 los costos de adaptar contratos incompletos. La integración puede reducir ese riesgo al asignar
 control común, pero no hace desaparecer desacuerdos ni la escasez física. En Ferrero/Oltan el
 acceso a agricultores y contratos explica por qué comprar una red puede importar más que comprar
 instalaciones; una helada seguirá dañando oferta aun bajo propiedad común. (F0873, pp. 30-31).
 Se comparan al menos tres arreglos: mercado o contrato simple cuando la actividad es
 estandarizable; contrato duradero o alianza cuando hay interdependencia que puede gobernarse
 sin compra; propiedad cuando control y adaptación adicionales justifican su costo. El contrato define
 derechos, incentivos, información, calidad, revisión y salida. Una alianza permite acceder a
 recursos complementarios con menos inversión, pero introduce riesgo de aprendizaje unilateral,
 dependencia y reparto de beneficios. Adquirir da derechos distintos, junto con pasivos, cultura y
 costos de integración. (F0606, pp. 26-28; F0873, pp. 29-31).
 Grupo Real muestra una externalidad: publicidad eleva ventas de locatarios y una porción de sus
 ventas se convierte en arriendo variable. El ingreso directo de publicidad es menor al 2%, pero esa
 cifra no mide todo su aporte al negocio. Una clasificación que externaliza automáticamente
 actividades de pequeño ingreso ignora el enlace. La empresa puede internalizar estrategia,
 información y gobierno comercial y contratar instalación técnica. Se deben comparar resultados
 netos, calidad del contrato y el efecto en rentas, no optar por «todo dentro» o «todo fuera» sin
 reconstruir responsabilidades. (Grupo Real, fuente pp. 213-215).
Examen de Grado UC | materia, preguntas y respuestas 49

[pág. 50]
Dirección - versión clara y reordenada
 Toyota exige distinguir dos mercados. Proveedores intensamente competitivos pueden bajar el
 precio del insumo, pero si el producto final es indiferenciado y competitivo, el fabricante quizá
 traslade el ahorro al comprador. Capturar beneficios de outsourcing requiere capacidades y una
 posición final que permita retenerlos. Además, dependencia de calidad o suministro puede justificar
 cooperación duradera incluso con muchos proveedores. El número de oferentes no sustituye el
 análisis de especificidad, desempeño y contratos. (Toyota, fuente pp. 383-384).
 Una adquisición se evalúa con el valor incremental para el comprador menos precio, costos de
 transición y riesgo. Las sinergias pueden ser operativas, comerciales, de conocimiento o de
 gobierno; se cuantifican por actividades cuando hay datos. Si el vendedor cobra anticipadamente
 toda la sinergia, la operación puede crear valor total sin beneficiar al comprador. Las economías de
 escala también pueden verse neutralizadas por complejidad, culturas incompatibles, regulación o
 pérdida de clientes. (F0606, pp. 27-30; F0883, pp. 5-7).
 Stellantis combina fortalezas geográficas y tecnológicas distintas, pero la complementariedad no
 garantiza que integrar sea sencillo. Deben diferenciarse el costo de fusión y el ahorro anual:
 comparar magnitudes sin horizonte produce conclusiones inválidas. En Delta/LATAM la OPA por
 20% compra acciones a vendedores; no equivale automáticamente a una inyección íntegra de
 dinero a LATAM. Los 435 destinos añadidos son de Delta, y deben distinguirse de una expansión
 operativa de LATAM. Estas precisiones determinan qué recursos llegan realmente y quién soporta
 sus costos. (Stellantis, fuente pp. 335-336; Delta/LATAM, fuente pp. 309-310).
 La implementación debe especificar qué integrar y qué preservar. Un comprador de marca de lujo
 puede transferir distribución e inversión mientras mantiene autonomía creativa; uniformar
 demasiado puede destruir diferenciación. Se asignan responsables a sinergias, se fija una base
 previa, se evita contar dos veces ahorros y se supervisan clientes, talento y capital. Una buena
 operación también tiene criterios de revisión: si el ahorro exige sacrificar calidad o el crecimiento no
 cubre inversión, se ajusta el alcance. (Tiffany, fuente pp. 341-342; F0606, pp. 28-35).
 8. Estrategia corporativa, portafolio, implementación y control
 La corporación crea ventaja cuando los negocios valen más bajo esa administración que por
 separado, después de todos los costos de coordinación. Compartir una marca, canal, dato o
 competencia puede elevar ingresos o bajar costos; transferir mejores prácticas puede acelerar
 desarrollo. Una reducción de riesgo por poseer negocios distintos no basta: el accionista puede
 diversificar su portafolio. Debe existir un beneficio adicional no replicable fácilmente fuera de la
 empresa, por ejemplo mejor acceso a información o financiamiento, que supere conflictos de
 asignación y costos de gobierno. (F0606, pp. 26-30; F0904, pp. 16-19; F0873, pp. 31-34).
 La relación se define por eslabones y capacidades compartidas, no por parecido superficial de
 productos. Dos bebidas pueden tener canales distintos; servicios financieros y conectividad pueden
 compartir pagos, clientes y datos. La matriz de Ansoff organiza producto y mercado existentes o
 nuevos, pero no decide rentabilidad. Penetrar, desarrollar mercado, crear producto y diversificar
 generan necesidades de capacidades y riesgos diferentes. La marca puede facilitar entrada, pero
 también diluirse si la extensión contradice atributos conocidos. (F0606, p. 27; F0873, pp. 32-34;
 Nubank, fuente pp. 441-442).
Examen de Grado UC | materia, preguntas y respuestas 50

[pág. 51]
Dirección - versión clara y reordenada
 La asignación de capital compara aportes marginales y oportunidades sacrificadas. Un negocio de
 gran tamaño puede consumir capital con poco margen; uno pequeño puede generar más
 contribución. En CAP, acero representa 64% de ventas y solo 2% del margen bruto del caso,
 mientras minería representa 19% y 90%. Ello obliga a estudiar dónde invertir, pero no prueba que
 cualquier proyecto minero sea rentable. La capacidad potencial al 50% exige nuevas inversiones,
 no es capacidad gratuita instalada. Hay que comparar adquirir, cerrar, ampliar y no invertir bajo
 demanda, riesgo y respuesta competitiva. (CAP, fuente pp. 121-122; F0606, pp. 27-30).
 Los conflictos de agencia aparecen cuando quienes deciden persiguen tamaño, prestigio o
 protección de su cargo por encima del valor conjunto. Un mercado de capital interno puede asignar
 mejor si conoce oportunidades; puede asignar peor si subsidia unidades influyentes. La solución
 combina derechos de decisión, información y rendición de cuentas. No consiste únicamente en
 poner una remuneración variable: un indicador mal diseñado puede inducir adquisiciones, ventas o
 ahorro que destruyan valor futuro. (F0606, pp. 29-33; F0904, pp. 22-24).
 La estructura convierte estrategia en encargos: división de trabajo, coordinación y decisiones. La
 funcional favorece especialización, pero puede fragmentar la visión del cliente. La divisional
 aproxima decisiones a mercados diferentes, con costos de duplicación y competencia por recursos.
 La matricial integra dimensiones simultáneas, pero necesita resolver prioridades y rendición de
 cuentas ante dos líneas de autoridad. Ninguna forma es siempre superior; se pregunta qué
 información debe integrarse, qué decisiones necesitan velocidad y qué costos crea cada arreglo.
 Estrategia orienta estructura, pero restricciones y aprendizaje también pueden obligar a revisar la
 estrategia. (F0606, pp. 31-35; F0904, pp. 20-21; F0609, pp. 13-16).
 Una agenda estratégica conecta objetivos con lineamientos, planes, responsables, hitos y
 presupuesto. «Digitalizar» es demasiado amplio: se define qué proceso, qué cliente, con qué
 resultado y en qué plazo. El mapa estratégico propone cómo capacidades, procesos, clientes y
 finanzas se relacionan. El Balanced Scorecard ayuda a seleccionar medidas coherentes; no exige
 medir todo ni igual número de indicadores por perspectiva. La selección depende de la hipótesis de
 valor y del costo de información. (F0606, pp. 25 y 32-33; F0904, pp. 19 y 22).
 Cada indicador requiere concepto, fórmula, unidad, fuente de datos, estándar, responsable,
 frecuencia y acción ante desviación. Debe medir un factor estratégico y dar margen de reacción. El
 resultado agregado y los inductores no se confunden: capacitación es una actividad; competencia
 adquirida es una capacidad; disminución de fallas es desempeño de proceso; retención es
 resultado de cliente. Se agrega protección frente a efectos negativos: volumen sin calidad, cobros
 sin ética o eficiencia sin seguridad. (F0606, pp. 32-33; F0609, pp. 19-21).
 La sostenibilidad exige un ciclo de aprendizaje. Se revisa si las iniciativas modificaron conductas y
 procesos, si el cliente percibió mejora y si se capturó valor neto. Un dato antes/después puede
 orientar, pero cambios de demanda, composición o tecnología pueden explicar resultados. Se
 buscan comparaciones pertinentes, pilotos y múltiples señales sin prometer causalidad no
 identificada. El control conserva decisiones útiles, corrige hipótesis y retira indicadores que
 incentivan conductas equivocadas. Así la materia de Empresas se conecta con Personas: las
 capacidades se realizan mediante selección, trabajo, desarrollo, evaluación y recompensas
 consistentes.
Examen de Grado UC | materia, preguntas y respuestas 51

[pág. 52]
Dirección - versión clara y reordenada
 Validez incremental: cuándo una prueba adicional agrega
 información
 La validez predictiva pregunta cuánto ayuda una medida a anticipar un criterio laboral definido. La
 validez incremental pregunta si añadir una segunda medida mejora la predicción, clasificación o
 utilidad que ya entrega el sistema base. Dos instrumentos válidos por separado pueden ser
 redundantes si capturan casi la misma información. El procedimiento es: analizar el cargo; definir
 desempeño relevante; estimar calidad del predictor base; añadir el nuevo método; medir mejora
 fuera de muestra; y considerar confiabilidad, correlación, costo, accesibilidad, privacidad e impacto
 adverso. No se suman pruebas por intuición.
 CAGE y expansión internacional
 CAGE ordena distancia cultural, administrativa o política, geográfica y económica. Cada distancia
 debe convertirse en un mecanismo concreto: idioma y confianza afectan adopción; regulación y
 acuerdos afectan acceso; distancia y husos afectan logística y coordinación; ingreso, costos e
 infraestructura afectan demanda y operación. El análisis depende de industria, segmento y
 actividad. CAGE genera hipótesis para elegir país y modo de entrada; no sustituye análisis
 competitivo, flujo de caja ni validación local.
 Profundización causal de Estrategia
 Dirección de Empresas y Estrategia: mecanismos que
 completan el aprendizaje
 Este desarrollo profundiza asuntos que estaban abreviados en la versión anterior. Integra los
 cuadernos de Dirección, los apuntes de José Rivera, los resúmenes de Sofi Muzzio y Sofi Pieraj, los
 esquemas de examen y los materiales docentes. Las resoluciones y ejemplos que siguen son
 desarrollos pedagógicos propios; no constituyen pautas oficiales. Cuando un resumen contiene una
 simplificación que puede producir una respuesta incorrecta, se explica el límite.
 E1. Empresa como sistema, contingencia y compromisos
 estratégicos
 Una empresa es un sistema abierto: recibe personas, información, financiamiento y materiales; los
 transforma mediante subsistemas interdependientes; entrega bienes, servicios y efectos sobre el
 entorno. El resultado comercial puede depender de un cuello de botella operativo o de una mala
 relación laboral. Optimizar aisladamente ventas no garantiza optimizar la empresa. Si ventas
 promete entregas incompatibles con producción, aumentar pedidos puede aumentar multas y
 destruir confianza. La sinergia consiste en que la coordinación permite un resultado superior al de
 las actividades independientes; requiere un mecanismo identificable. La entropía, cuando se usa en
 estos apuntes, es una analogía sobre deterioro y desorganización: no autoriza trasladar sin
 demostración una ley física a las empresas.
Examen de Grado UC | materia, preguntas y respuestas 52

[pág. 53]
Dirección - versión clara y reordenada
 La administración científica asociada a Taylor enfatiza analizar y estandarizar tareas; la tradición de
 Fayol enfatiza funciones y responsabilidades administrativas. Ayudan a entender eficiencia y
 coordinación, pero no basta aplicar sus principios como recetas. La contingencia pregunta qué
 diseño funciona dadas la tecnología, incertidumbre, tamaño, capacidades y estrategia. Un
 procedimiento rígido puede proteger calidad en una operación repetitiva y obstaculizar una
 investigación incierta. La conclusión requiere comparar las consecuencias en cada contexto.
 La decisión estratégica compromete recursos y condiciona otras decisiones. Comprar una planta,
 prometer un estándar de servicio o instalar una cultura de autonomía no se revierte gratuitamente.
 Su importancia depende de magnitud, duración, interdependencias y costos de reversión, además
 de quién la firma. El horizonte pertinente sigue el ciclo económico del negocio, la duración de sus
 inversiones y la velocidad de cambio; no existe un número universal de años.
 En el vocabulario de los apuntes del curso de José Rivera, consistencia examina la
 correspondencia de la posición futura con el entorno y consonancia su correspondencia con
 recursos y capacidades. Ventaja pregunta qué diferencia valiosa y defendible permitirá retornos
 superiores; factibilidad, si los recursos y la ejecución permiten alcanzar esa posición. Otros textos
 usan esas palabras con matices distintos. En examen conviene definir el sentido empleado antes de
 aplicarlo. No sustituir consonancia por “constancia”, error presente en algunos resúmenes.
 Aplicación. Una clínica quiere duplicar atención domiciliaria. Consistencia: envejecimiento y
 demanda favorecen ese servicio, pero debe verificar cobertura geográfica y competencia.
 Consonancia: ¿posee profesionales, coordinación logística y capacidad de seguimiento? Ventaja:
 ¿su continuidad clínica reduce errores de manera valorada y difícil de copiar? Factibilidad:
 ¿financiamiento, dotación y tecnología soportan una expansión gradual? Una población envejecida
 por sí sola prueba una oportunidad, no una buena estrategia.
 E2. Valor económico, valor agregado y reparto entre
 participantes
 Conviene distinguir creación de valor, captura y retorno económico. En una transacción
 simplificada, sean DAP la disposición máxima a pagar, P el precio cobrado, C el pago total por los
 insumos y CE el costo de oportunidad de esos insumos para sus oferentes. Entonces:
 V_total=DAP-CE=(DAP-P)+(P-C)+(C-CE).
 El primer término es el excedente del cliente, el segundo el margen capturado por la empresa y el
 tercero el excedente de los proveedores. El modelo supone que C incluye todos los insumos
 relevantes de esa unidad. Si faltan trabajo, capital u otros costos, P-C no es utilidad económica
 completa. Los pagos son transferencias entre participantes; una rebaja de P redistribuye valor y no
 necesariamente crea más valor por unidad. La utilidad contable tampoco descuenta siempre todos
 los costos de oportunidad del capital.
 Ejercicio resuelto. DAP=120, P=95, C=60 y CE=45. Se crean 75: cliente25, empresa35 y
 proveedor15. Una mejora aumenta DAP a130 y CE a50; con P=103 y C=66, el total pasa a80,
 repartido27,37 y16. Se crean5 adicionales y la empresa captura2. Si en cambio solo renegocia C
 de60 a55, con DAP, P y CE originales, el total sigue75; la empresa gana5 y el proveedor pierde5.
 Esa negociación mejora captura, sin demostrar una mejora productiva.
Examen de Grado UC | materia, preguntas y respuestas 53

[pág. 54]
Dirección - versión clara y reordenada
 El valor agregado de un participante, en el análisis de negociación, es el máximo valor
 alcanzable con él menos el máximo alcanzable sin él. No significa simplemente “agregar un atributo
 premium”. Si sin un distribuidor existe una alternativa casi equivalente, su aporte marginal puede
 ser pequeño aunque gestione muchas ventas. Esa alternativa afecta su poder de negociación. El
 resultado del reparto también depende de contratos, opciones externas y capacidad de coordinar
 acuerdos; el valor agregado no es automáticamente el monto exacto que recibirá.
 Para una compra voluntaria ordinaria, el precio debe ser compatible con la DAP del cliente: P≤DAP.
 La frase de un resumen que exige cobrar un precio “no menor” a la DAP invierte la condición.
 Capturar valor tampoco exige necesariamente un precio máximo; servicio recurrente, volumen y
 permanencia pueden justificar otro precio. Una ventaja de diferenciación requiere que el incremento
 de DAP supere su costo económico incremental y que la empresa pueda apropiarse de una parte
 suficiente.
 E3. Industria, grupos estratégicos y respuesta competitiva
 El paradigma estructura-conducta-desempeño relaciona condiciones del mercado, estrategias y
 resultados. Una industria concentrada puede facilitar poder de mercado, pero la conducta también
 modifica la estructura: innovación, entrada, alianzas o expansión alteran barreras y alternativas. No
 debe interpretarse como una flecha causal única y universal. Los estudios de Schmalensee, Rumelt
 y Roquebert discutidos en los apuntes separan variaciones asociadas a industria, unidad de
 negocio y pertenencia corporativa. Sus resultados dependen de muestra, período, medida de
 rentabilidad y especificación estadística. Que un efecto no resulte significativo en un estudio no
 significa que toda gerencia corporativa sea irrelevante. Una descomposición de varianza tampoco
 demuestra que una decisión individual cause una rentabilidad particular.
 Las cinco fuerzas requieren delimitar el negocio: producto o necesidad atendida, alternativas y
 ámbito geográfico. Los complementadores amplían el análisis al aumentar o reducir el valor de la
 oferta; no cambian retrospectivamente el número de fuerzas del modelo original. No todos los
 cambios actúan del mismo modo. Una barrera de entrada puede proteger retornos, mientras una
 barrera de salida puede intensificar rivalidad al mantener capacidad ineficiente. Elevar ambas no es
 automáticamente beneficioso.
 El HHI resume concentración como Σ_i s_i^2. Con participaciones expresadas en porcentajes,
 cuatro firmas de40%,30%,20%,10% generan3.000; con proporciones,0,30. Las unidades explican la
 diferencia. No prueba colusión, no mide directamente diferenciación y no reemplaza el análisis de
 sustitución, entrada y negociación. No se aplican aquí umbrales regulatorios de otro país o época.
 Un grupo estratégico reúne competidores con formas de competir semejantes, no necesariamente
 todos los miembros de la industria. Para construir un mapa, elegir dos dimensiones que distingan
 decisiones importantes y no repitan el mismo fenómeno; situar cada competidor con evidencia;
 agrupar posiciones similares; estudiar movilidad, represalias y rentabilidad de las posiciones. Por
 ejemplo, en educación ejecutiva, cobertura internacional y grado de personalización pueden
 diferenciar modelos. Un espacio vacío puede deberse a ausencia de demanda o incompatibilidad
 económica, en vez de ser una oportunidad. Las barreras de movilidad dificultan pasar de un grupo a
 otro: reputación, red, capacidades o incompatibilidad de actividades. El método también sirve en
 industrias maduras cuando subsisten posiciones diferentes; madurez no implica convergencia
 completa a competir solo en precios.
Examen de Grado UC | materia, preguntas y respuestas 54

[pág. 55]
Dirección - versión clara y reordenada
 El perfil de respuesta de un rival combina cuatro preguntas: ¿qué estrategia ejecuta?, ¿qué
 capacidades puede movilizar?, ¿qué metas persigue?, ¿qué supuestos tiene sobre el mercado y
 sobre nosotros? Un rival con capacidad ociosa y deuda puede defender volumen, pero no
 conocemos su reacción solo por observar su precio actual. Escenarios y señales verificables
 permiten preparar respuestas.
 Interacción y equilibrio de Nash. Es un conjunto de decisiones donde ningún participante mejora
 su resultado cambiando unilateralmente, dadas las decisiones de los demás. No equivale a
 minimizar pérdidas ni a acordar lo mejor para ambos. Considere este ejemplo pedagógico de dos
 empresas:
 A/B B conserva precio B rebaja precio
 A conserva precio 8;8 2;10
 A rebaja precio 10;2 4;4
 Los números son beneficios de A y B. Si B conserva precio, A prefiere10 a8; si B rebaja, A prefiere4
 a2. B tiene el mismo incentivo. Rebaja/rebaja es equilibrio aunque8;8 sea mejor para ambos. El
 análisis no autoriza concertar precios. Para evitar una guerra destructiva con decisiones
 independientes, examinar diferenciación, estructura de costos y compromiso de servicio; no asumir
 que todas las interacciones tienen estos pagos o que siempre hay estrategia dominante.
 La etapa del ciclo industrial orienta hipótesis. En fase emergente importa resolver incertidumbre y
 establecer capacidades; en crecimiento, escalar sin degradar calidad; en madurez, diferenciar,
 mejorar procesos o atender nichos; en declinación, comparar nicho, cosecha, reconversión y salida.
 Un shakeout es una reducción del número de competidores por desequilibrios de capacidad, costos
 o demanda; no es sinónimo de precios predatorios. La innovación puede pasar de producto a
 proceso, pero es una tendencia contextual. En declinación, cosechar puede erosionar servicio y
 reputación: exige un plan para obligaciones con clientes y trabajadores.
 E4. Costos, recursos y cuatro amenazas a la sustentación
 Economías de escala reducen costo medio dentro del rango pertinente al aumentar volumen por
 período; no exigen que siempre disminuya el costo marginal. Economías de ámbito hacen más
 barato producir conjuntamente distintos productos que por separado. La experiencia relaciona
 aprendizaje y producción acumulada; debe separar aprendizaje de cambios de escala, tecnología y
 composición. La densidad aprovecha más operaciones dentro de una red o área dada; la
 secuencia reduce fricciones al coordinar etapas; los efectos de red aumentan el valor para un
 usuario según otros participantes. Son mecanismos distintos. “Ser más grande” no demuestra
 ninguno.
 Una firma de menor costo puede cobrar el mismo precio y capturar un margen mayor, bajar precio
 para expandir demanda o reinvertir en una diferenciación selectiva. Liderazgo en costos no exige
 siempre el precio más bajo. Combinar costo y diferenciación es posible si las actividades lo
 sostienen; estar atrapado en el medio describe incoherencia o ausencia de ventaja, no una
 prohibición lógica de lograr ambas.
 La visión basada en recursos parte de heterogeneidad e imperfecta movilidad: algunas capacidades
 se construyen mediante aprendizaje, historia y relaciones difíciles de comprar. Un activo puede ser
Examen de Grado UC | materia, preguntas y respuestas 55

[pág. 56]
Dirección - versión clara y reordenada
 valioso y disponible para todos; ayuda a operar, pero no diferencia. La organización debe
 transformar el recurso en resultados mediante derechos, procesos, incentivos y
 complementariedades.
 Diagnóstico del recurso o capacidad Consecuencia esperable, condicionada al contexto
 No aporta valor Costo o desventaja; reconsiderar inversión
 Valioso, común Paridad competitiva
 Valioso y raro, fácil de replicar Ventaja potencialmente transitoria
 Valioso, raro, difícil de imitar; organización incapaz de Valor potencial sin aprovechamiento suficiente
 explotarlo
 Las cuatro condiciones se sostienen y permiten Hipótesis de ventaja sustentable; aún debe contrastarse
 apropiación económica
 Una competencia central articula aprendizaje y coordinación, aporta un beneficio importante al
 cliente, permite acceder a varios mercados y resulta difícil de imitar. “Tenemos buenos empleados”
 no identifica una competencia. Un ejemplo sería coordinar diagnóstico, programación y
 mantenimiento para reducir fallas en distintos equipos. Debe verificarse qué prácticas producen el
 resultado y qué impide copiarlo.
 Las cuatro amenazas de los apuntes separan dos problemas:
 Amenaza Mecanismo y diagnóstico Respuesta posible y límite
 Imitación Rivales replican recurso o sistema; Aprender, proteger conocimiento y
 se reduce la diferencia renovar actividades; una patente no
 cubre todo el negocio
 Sustitución Otra solución satisface la necesidad Observar necesidades, experimentar
 con mejor relación valor/costo y reconvertir; copiar el sustituto sin
 capacidades puede fracasar
 Ineficiencia Desperdicio, coordinación deficiente Rediseñar procesos y
 o burocracia absorben rentas responsabilidades; recortar
 indiscriminadamente puede destruir
 la capacidad
 Expropiación o pérdida de Proveedores, socios o talento Mejorar alternativas, acuerdos y
 apropiación capturan una mayor fracción complementariedades; coerción no
 sustituye una relación sostenible
 Las primeras amenazan la capacidad de generar rentas; las últimas, apropiarlas. Sustentar no exige
 conservar eternamente la misma ventaja: exige renovar la capacidad de generar retornos atractivos
 sin destruir sus condiciones.
 Complemento académico externo: modelo Delta. Hax y Wilde distinguen tres orientaciones:
 mejor producto, solución integral para el cliente y consolidación de un sistema con
 complementadores. La primera concentra comparación de la oferta; la segunda integra
 necesidades del cliente; la tercera busca valor mediante la red y su funcionamiento conjunto. La
 orientación elegida debe traducirse en actividades y procesos adaptativos. No basta declarar
 “ecosistema” ni confundir dependencia forzada con valor. En un caso, Delta ayuda a decidir qué
 vínculo se pretende construir; VRIO examina si tenemos capacidades defendibles para hacerlo.
 Son preguntas complementarias. Hax y Wilde, MIT Sloan Management Review.
Examen de Grado UC | materia, preguntas y respuestas 56

[pág. 57]
Dirección - versión clara y reordenada
 E5. Modelo de negocio, ventaja corporativa y límites del
 crecimiento
 El modelo de cuatro pilares usado en los apuntes permite comprobar una arquitectura económica:
 1. Propuesta de valor: necesidad o tarea, cliente objetivo y precio relativo. Una necesidad
 importante no demuestra demanda suficiente al precio necesario. 2. Fórmula de utilidades:
 ingresos, estructura de costos, márgenes y velocidad de uso de recursos. Un margen alto con
 capital inmovilizado puede producir un retorno bajo. 3. Recursos clave: personas, marca,
 tecnología, instalaciones, redes o conocimiento indispensables. 4. Procesos clave: actividades
 repetibles que convierten los recursos en la propuesta prometida.
 Canvas amplía el mapa de participantes, canales y relaciones; los cuatro pilares hacen
 especialmente visible la consistencia entre propuesta y economía. Ninguno sustituye la evidencia.
 También puede analizarse el modelo como elecciones de activos, actividades y gobierno, sus
 consecuencias y sus supuestos. Las decisiones tácticas se toman dentro de ese modelo: una
 aerolínea sencilla puede cambiar horarios sin necesariamente pasar a un modelo de servicio
 completo.
 Ejemplo trabajado. Una suscripción de mantenimiento cuesta120 por año. El costo variable
 esperado es60; el margen de contribución es60. Con costos fijos de60.000, el equilibrio contable
 simple exige1.000 clientes. Si solo pueden atender800, no basta marketing: debe cambiar
 capacidad, precio o costos. Si el servicio requiere visitas imprevistas, el promedio de costos no
 informa sus picos de capacidad. Recursos: técnicos y repuestos; procesos: diagnóstico, agenda,
 atención y seguimiento. Prometer visita inmediata con dotación mínima contradice la propuesta.
 Para evaluar rentabilidad económica aún se incorporan inversión, capital de trabajo, riesgo y
 duración de contratos.
 La ventaja corporativa pregunta si la gestión conjunta crea más valor que los negocios por
 separado. Diferenciar horizontal -negocios o productos-, vertical -etapas- y geográfico -mercados y
 localización- evita tratar cualquier expansión como diversificación. Las sinergias pueden venir de
 compartir recursos, transferir habilidades, coordinar canales o mejorar inversión; pueden perderse
 por burocracia, conflicto e integración cultural.
 VAN_corporativo=VAN_nuevo negocio independiente+VP_interacciones incrementales-VP_costos
 adicionales de coordinación.
 Ejercicio resuelto. Un nuevo negocio tiene VAN independiente-10. El acceso a clientes genera VP
 incremental18; compartir tecnología ahorra6; coordinación adicional cuesta9. El aporte conjunto
 es5. Puede aceptarse si esas interacciones son comprobables, no están incluidas ya en el VAN
 independiente y compensan el riesgo. Si las sinergias comerciales solo fueran4, el aporte sería-9.
 Nombrar sinergias sin estimar su mecanismo, responsable y costo de ejecución no justifica la
 inversión. Deben examinarse canibalización y reacciones de clientes y rivales.
 La diversificación reduce exposición específica, pero un accionista puede diversificar por sí mismo;
 reducir riesgo no prueba automáticamente que la empresa agregue valor. Un mercado interno de
 capital puede mejorar asignación por información y disciplina, o subsidiar malos proyectos por
 política. La adquisición debe incorporar precio pagado y prima, además de costos posteriores. Una
 firma mayor puede generar más utilidad total y destruir valor si paga demasiado o obtiene retornos
Examen de Grado UC | materia, preguntas y respuestas 57

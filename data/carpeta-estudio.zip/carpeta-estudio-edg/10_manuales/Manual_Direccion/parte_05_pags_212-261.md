# Manual de Direccion · parte 5 (páginas 212-261)

Fuente: 03_MANUAL_ULTIMATE_DIRECCION_EDG_2027_V2_REORDENADO

[pág. 212]
Dirección - versión clara y reordenada
 PREGUNTAS ADICIONALES · DIRECCIÓN
 Tres casos; las respuestas completas se encuentran en la sección siguiente
 Pregunta D-U1 · Selección y validez incremental
 Una empresa selecciona técnicos con una prueba de conocimientos y quiere agregar entrevista no
 estructurada, prueba de personalidad y muestra de trabajo. Explica cómo decidir qué método
 añadir, qué significa validez incremental y qué riesgos de implementación controlar.
 Pregunta D-U2 · CAGE y modo de entrada
 Una plataforma chilena de salud digital evalúa entrar a Perú y España. Su tecnología escala, pero
 maneja datos sensibles, depende de confianza médica y requiere integración con prestadores.
 Aplica CAGE y recomienda un modo de entrada condicional.
 Pregunta D-U3 · Adquisición, cultura y captura de sinergias
 Una empresa grande compra una startup por su tecnología y velocidad. El comprador propone
 unificar de inmediato cargos, evaluación, bonos y procesos. Diagnostica el riesgo y diseña una
 integración que capture sinergias sin destruir la capacidad adquirida.
Examen de Grado UC | materia, preguntas y respuestas 212

[pág. 213]
Dirección - versión clara y reordenada
 RESPUESTAS - soluciones completas
 Las respuestas siguen el mismo orden de las preguntas. Son propuestas de estudio; una atribución
 a pauta oficial exige identificación expresa y verificada.
 Dirección de Personas
 enero 2012 - pregunta 4 - Alineamiento de prácticas con servicio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 94-95 | convocatoria 1
 Volver al enunciado original
 La prioridad es un sistema coherente con información compleja, clara y oportuna y respuesta
 rápida. Como ya paga remuneraciones de mercado, no hay evidencia para que un aumento general
 sea una de las tres principales intervenciones. Propondría:
 1. Capacitación aplicada y extendida. Chile aparece con pocas horas y baja participación relativa
 frente a Nueva Zelandia y Finlandia; no basta copiar cantidades, pero sí cerrar la brecha de acceso
 y aprendizaje. Formaría en productos, normas, comunicación comprensible y resolución, con
 simulaciones, acompañamiento y verificación en el puesto. Mejores capacidades reducen errores y
 permiten respuestas convincentes y rápidas. 2. Carrera y promoción transparentes por
 competencias y contribución. Más de 85% de los encuestados considera relevantes familia o
 contactos para el éxito, según el gráfico de la fuente 95. Publicaría requisitos, oportunidades y
 criterios de evaluación; ofrecería desarrollo para postular y decisiones justificadas. Esto fortalece
 expectativas de reciprocidad y motivación para adquirir capacidades de servicio y evita que el
 esfuerzo parezca inútil frente a ventajas de origen. 3. Autonomía responsable, participación y
 cooperación. La última lámina muestra satisfacción de solo aproximadamente 44% con autonomía,
 45% con flexibilidad para proponer ideas y 48% con cooperación entre áreas; incluso la relación
 entre compañeros ronda 52%. Definiría atribuciones para resolver casos dentro de límites, canales
 de mejora con respuesta y equipos de coordinación entre atención y áreas que entregan
 información. Las jefaturas deben apoyar decisiones y evaluar resolución y calidad, además de
 productividad. Esto reduce esperas y traspasos, mejora la oportunidad de aplicar competencias y
 evita respuestas rápidas pero incompletas.
 Las tres prácticas actúan sobre capacidad, expectativas de desarrollo y oportunidad de contribuir.
 Evaluaría comprensión del cliente, errores, reclamos y tiempos de resolución, sin confundir horas
 de cursos o satisfacción con el resultado final de servicio. Los porcentajes de la última lámina son
 aproximaciones visuales, no valores numéricos impresos exactos.
 enero 2017 - pregunta 2 - Autonomía e innovación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 228-229 | convocatoria
 1
 Volver al enunciado original
 La propuesta de Kuitunen se puede justificar motivacionalmente por autonomía, responsabilidad y
 sentido de maestría: equipos de expertos pueden responder a clientes y aprender más rápido si
 deciden cómo organizarse; libertad puede satisfacer motivación intrínseca y confianza. Pero quitar
 jefaturas no elimina necesidad de coordinación, reglas de jornada o evaluación. Autonomía sin
Examen de Grado UC | materia, preguntas y respuestas 213

[pág. 214]
Dirección - versión clara y reordenada
 propósito común, información, límites y capacidad puede crear ambigüedad, sobrecarga,
 desigualdad y conflictos. Prohibir trabajar menos que la jornada legal indicada en el caso contradice
 su promesa de libertad horaria; la regla laboral debe verificarse con ley vigente antes de implantar.
 Tres argumentos a favor, condicionados: trabajo de software es intensivo en conocimiento;
 productos a medida e innovación requieren aprendizaje; satisfacción/motivación puede facilitar
 colaboración voluntaria. Medidas para reducir efectos adversos: selección, incorporar evidencia de
 colaboración, autogestión, comunicación y aprendizaje con entrevista estructurada/muestra de
 trabajo; capacitación, desarrollar planificación, priorización, feedback, resolución de conflictos y
 coordinación interfuncional; control, sustituir supervisión jerárquica por objetivos acordados, dueño
 por proyecto, dependencias visibles, revisión por pares/cliente, indicadores de calidad y carga,
 mecanismos de escalamiento y evaluación periódica. No dejar “libertad absoluta”: equipos definen
 acuerdos de respuesta, cobertura y descanso; cumplimiento de estándares se controla.
 El sistema de incentivos combina resultados del equipo/proyecto (calidad, satisfacción, entregas,
 innovación) con contribución individual observable, reconocimiento de aprendizaje y reparto
 transparente. Evita pagar solo por velocidad o ventas, que puede fomentar deuda técnica,
 promesas imposibles y free riding. La política de no despidos puede dar seguridad para
 experimentar, pero no sustituye feedback, mejora de desempeño ni debido proceso; la permanencia
 no debe convertir la contribución en opcional.
 enero 2013 - pregunta 2 - Bono de retiro y relaciones laborales
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 117-118 | convocatoria
 1
 Volver al enunciado original
 1. Por qué puede beneficiar el bono
 El bono no se justifica solo por su monto o por “compartir excedentes”: facilita un acuerdo para
 transformar el negocio hacia minería subterránea con menor dotación y continuidad operacional. Se
 pagan $16,8 millones a cada uno de 5.900 trabajadores, $99.120 millones en total, y la
 administración obtiene un plan de retiro de 2.150 personas durante los 48 meses del convenio. El
 caso estima que el ahorro de ese retiro tiene valor presente de US$200 millones, igual al
 desembolso del bono. Por tanto, el ahorro directo por sí solo empata el costo estimado; el beneficio
 adicional puede estar en viabilizar la transformación, evitar conflicto y paralizaciones y preservar
 competitividad futura. No corresponde afirmar que esos ahorros ya superan el pago.
 Hay un riesgo decisivo: el retiro es no vinculante; un trabajador puede rechazarlo. Si no se
 materializan las salidas o se demora el proyecto, no se realiza el ahorro previsto. También deben
 compararse costos de retiro, transición y seguridad y verificar que la paz laboral se sostiene. El
 bono puede ser beneficioso como parte de ese acuerdo y sus efectos estratégicos, sin ser
 automáticamente rentable.
 2. Variables para el bono de PuroCobre
 Consideraría continuidad y mantenimiento preventivo: fallas evitables del horno lo detuvieron 90
 días y el caso valora un día paralizado en alrededor de US$8 millones. Premiar cumplimiento
 preventivo y confiabilidad es más controlable que atribuir toda producción al esfuerzo del trabajador.
 La ley del mineral resultó 0,6% frente a 0,9% prevista: esa condición geológica debe separarse de
 la contribución laboral al definir objetivos.
Examen de Grado UC | materia, preguntas y respuestas 214

[pág. 215]
Dirección - versión clara y reordenada
 Incorporaría productividad, costos y capacidad de adaptación a la mina subterránea. El costo
 directo sube de US$1,04 a US$1,16 por libra y supera el promedio de US$1,07; mientras el cobre
 cae de US$4 a US$3,5. El pago debe ser sostenible bajo escenarios de precio y no prometer
 beneficios financiados por una bonanza incierta. El plan de dotación exige participación y
 compromisos verificables, sin tratar un retiro voluntario como obligación ya asegurada.
 La seguridad debe ser condición central y combinar prevención y resultados sin incentivar ocultar
 accidentes. Los 45 fallecidos en minería subterránea frente a 15 en rajo abierto son una señal de
 riesgo del cambio, aunque el número absoluto no permite comparar tasas sin exposición.
 Finalmente, consideraría expectativas y conflictividad sindical, equidad del reparto y claridad de
 fórmula, horizonte y auditoría. Chuquicamata es referencia de negociación, pero no fija una tarifa
 automática para PuroCobre.
 agosto 2023 - pregunta 2 - Comisiones y relación de largo plazo
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 392-393 | convocatoria
 2
 Volver al enunciado original
 a) ¿Mantener la comisión 100% variable? No la extendería sin cambios a fertilizantes y revisaría si
 el esquema original sigue funcionando para maquinaria. La comisión por artículo pudo ser
 coherente para maquinaria de compra infrecuente, donde el resultado visible es una venta y
 Ricardo supervisaba personalmente a diez vendedores. El crecimiento a 32 reduce esa supervisión
 informal. Fertilizantes se compran repetidamente y requieren diagnóstico técnico de suelo, especie,
 clima y predio, asesoría personalizada y confianza a largo plazo. Pagar solo por cada venta puede
 inducir volumen o producto inadecuado, venta excesiva, descuento para cerrar, abandono
 postventa o atención a corto plazo; puede destruir reputación y repetición. Si el resultado depende
 también de clima, rendimiento del cultivo y decisiones del cliente, comisión por ventas brutas
 atribuye al vendedor resultados que no controla e ignora rentabilidad, calidad y riesgo. Un sueldo
 fijo moderado reduce volatilidad de ingresos y permite dedicar tiempo a diagnóstico y servicio, con
 variable balanceado por resultados controlables. b) Tres elementos para diseñar el incentivo de
 fertilizantes. 1. Traducir estrategia y ciclo del cliente a resultados medibles. No remunerar solo
 toneladas o ventas iniciales. Combinar margen/contribución de productos recomendados, ventas
 repetidas y retención, satisfacción/confianza, cumplimiento de protocolos de recomendación y
 calidad de asesoría. Cuando sea medible, considerar adopción adecuada y resultados
 agronómicos, ajustados por variables fuera del control del vendedor; no prometer causalidad entre
 fertilizante y rendimiento de cosecha. Poner horizonte de seguimiento que recoja recompra y evitar
 pago que premia una recomendación perjudicial. 2. Alinear mezcla fija-variable, nivel
 individual/equipo y línea de control. Definir remuneración fija suficiente para sostener trabajo
 consultivo y componente variable razonable; usar objetivos individuales cuando el vendedor
 controla relación y asesoría, y componente de equipo cuando participan especialistas, logística o
 postventa. Segmentar por cartera, zona, potencial, ciclo de cultivo y dificultad de terreno; evitar que
 vendedores con cartera madura sean comparados con territorios nuevos. La política de maquinaria
 puede mantenerse separada si su tarea y ciclo difieren, pero hacer explícita coordinación cuando se
 venden ambos. 3. Diseñar reglas transparentes, alcanzables y resistentes a conductas perversas.
 Especificar cómo se calcula venta neta, descuentos, devoluciones, cartera compartida, período de
 pago, metas, topes/umbrales y revisión de datos. Usar métricas auditables, consulta a
 vendedores/clientes y piloto; vigilar venta adelantada, recomendación excesiva, descuentos,
Examen de Grado UC | materia, preguntas y respuestas 215

[pág. 216]
Dirección - versión clara y reordenada
 selección de clientes y descuido postventa. Evaluar percepción de justicia, calidad de
 recomendación, margen, recompra, retención y rotación. Dar feedback y capacitación
 comercial-técnica; un plan de pago no corrige por sí solo falta de competencia o recursos.
 Conclusión. Mantendría una comisión adaptada para maquinaria si se confirma su impacto y no
 genera problemas, pero diseñaría para fertilizantes una recompensa mixta y balanceada,
 consistente con asesoría, calidad y relación repetida. La evidencia histórica de éxito no prueba que
 la misma fórmula sea adecuada para un producto, tarea y horizonte distintos.
 agosto 2022 - pregunta 2 - Contrato psicológico y servicio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 366-367 | convocatoria
 2
 Volver al enunciado original
 1. Contrato psicológico y ajuste con el modelo de negocio
 LizTaylor ha desarrollado principalmente un vínculo transaccional, que enfatiza pago por esfuerzo
 y productividad individual: Igor destaca fijo inferior al mercado y alto variable. Ese intercambio
 económico puede sostener algunas tareas, pero resulta estrecho para una empresa que quiere
 acompañar a clientes de ingresos medio-altos durante su ciclo de vida mediante diseño, relación
 precio-calidad, asesoría de armado, postventa excelente y materiales reciclables. La diferenciación
 exige conocimiento acumulado, cooperación y compromiso de servicio que no se resumen en
 productividad de corto plazo.
 La tabla de satisfacción, escala de 1 a 5, permite precisar las brechas. Para actuales y quienes
 renunciaron, respectivamente: flexibilidad horaria 1,8 y 2,0; propósito de empresa y trabajo 2,0 y
 1,9; fijo 2,2 y 2,1; variable 2,4 y 2,4. Los valores de jefatura que desarrolla son 3,1 y 2,9;
 condiciones físicas/tecnológicas 2,9 y 3,1; teletrabajo y equilibrio personal/laboral 2,9 y 3,0;
 capacitación 2,9 y 2,7. La satisfacción integral es 2,8 y 2,9. Por tanto, ni siquiera el variable que Igor
 considera atractivo obtiene satisfacción alta; los problemas más severos aparecen en flexibilidad,
 propósito y retribución fija, con dificultades de desarrollo y condiciones que tampoco desaparecen.
 El gráfico muestra que en 2020-2021 la rotación de LizTaylor se distancia al alza del retail,
 aproximadamente 15% y 21%, frente a 7% y 9% del sector. Esas cifras del gráfico son aproximadas
 y no deben presentarse con precisión adicional.
 El estudio se declara representativo, válido y confiable y con desviaciones estándar bajas; dentro
 del supuesto del caso, las brechas no son solo anécdotas de una persona. Aun así, diferencias de
 promedios no prueban que una práctica haya causado cada renuncia. El texto no informa
 entrevistas de salida que atribuyan las renuncias a falta de contribución; esa afirmación debe
 eliminarse. La entrada de Akilisto crea alternativas de empleo y competencia: ofrece fijo alto relativo
 al variable, aprendizaje, movilidad, flexibilidad y bienestar familiar. Su servicio más estándar
 tampoco permite copiar todas sus prácticas sin examinar el ajuste propio. Para LizTaylor es más
 pertinente un vínculo balanceado que combine remuneración justa, desarrollo y compromiso
 recíproco a largo plazo.
Examen de Grado UC | materia, preguntas y respuestas 216

[pág. 217]
Dirección - versión clara y reordenada
 2. Tres cambios prioritarios y sus efectos
 Primero, flexibilidad y diseño del trabajo. Es el factor peor evaluado. Rediseñaría turnos con
 anticipación, intercambios acordados y autonomía compatible con atención de tienda; habilitaría
 trabajo remoto en tareas que lo permiten y medidas de equilibrio para los demás, evitando que la
 flexibilidad dependa de favoritismo. Mejor planificación mantiene cobertura para clientes y reduce
 conflicto entre vida laboral y personal, aumenta atractivo del empleo y conserva conocimiento de
 postventa. La operación determina límites, no la suposición de que todas las tareas pueden hacerse
 a distancia.
 Segundo, propósito aplicado, desarrollo y participación. Conectar cada rol con la ayuda al
 cliente, soluciones de armado y reparación, y reducción de residuos; recoger ideas e información de
 primera línea y devolver resultados. Formar jefaturas para coaching y reconocimiento; ofrecer rutas
 técnicas y comerciales, aprendizaje de productos, asesoría y movilidad según competencias. Se
 atienden los promedios de propósito cercanos a 2, y se mejora el desarrollo que el personal valora.
 El aporte visible, oportunidades y formación aumentan compromiso y calidad de recomendaciones;
 la mejor experiencia facilita recompra y diferenciación frente al rival de postventa estándar. Una
 declaración de misión sin cambios en decisiones no resolvería esa brecha.
 Tercero, remuneración total y desempeño balanceados. Revisaría el fijo frente a mercado,
 equidad interna y capacidad de pago; el dato de satisfacción 2,2/2,1 indica que la afirmación de
 “pagamos bien” no basta. Reduciría la dependencia de un variable elevado por productividad
 individual, manteniendo una parte ligada a resultados controlables de servicio, calidad, margen y
 colaboración de equipo. Acordar reglas comprensibles y retroalimentación, y evitar premiar volumen
 a costa de asesoría o postventa. Se reduce riesgo de ingresos y se reconoce el trabajo que crea la
 propuesta de valor completa, ayudando a retener especialistas que hoy tienen alternativas
 atractivas.
 Implementaría las tres prácticas como sistema, con pilotos por tiendas comparables. Mediría
 satisfacción por los factores de la tabla, rotación voluntaria y pérdida de perfiles críticos,
 aprendizaje, resolución postventa, recompra, margen y productividad ajustada por calidad. La caída
 de ventas en un mercado cuya demanda aumenta hace urgente cambiar capacidades y relaciones;
 no demuestra que aumentar salarios aislados sea suficiente.
 agosto 2013 - pregunta 3 - Contrato temporal y calidad de servicio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 131-131 | convocatoria
 2
 Volver al enunciado original
 1. Aspectos positivos y negativos. El plazo breve y variable permite ajustar oferta de trabajo a
 proyectos de duración incierta, reducir períodos ociosos y evitar compromisos fijos cuando la
 demanda cae. El pago por hora 30% sobre el mercado puede atraer especialistas escasos, y la
 empresa obtiene un margen de 50-65% sobre honorarios. Esa lógica puede ser coherente con una
 ETT si conserva disponibilidad de talento, calidad y margen neto.
 El problema es asumir que “temporario” significa intercambiable. Los clientes valoran que el técnico
 esté actualizado y solicitan repetidamente a la misma persona porque ya conoce sus sistemas y
 necesidades. Rotación sin continuidad eleva búsqueda, evaluación, inducción, errores y tiempo de
 adaptación; también destruye conocimiento específico del cliente. No capacitar puede volver
Examen de Grado UC | materia, preguntas y respuestas 217

[pág. 218]
Dirección - versión clara y reordenada
 obsoletas habilidades informáticas, afectar seguridad y calidad y reducir la capacidad de cobrar el
 margen. Depender del autodesarrollo individual crea una externalidad: PUR y el cliente reciben
 beneficios del aprendizaje, pero el trabajador paga el costo y puede llevarse la capacidad a otro
 empleador. La ausencia total de vínculos, beneficios y carrera puede reducir compromiso,
 disponibilidad y reputación empleadora, justo cuando la demanda crece 25% anual. Por tanto, el
 ahorro laboral directo debe compararse con costo total de reemplazo, fallas, reclamos, vacantes y
 pérdida de repetición.
 2. Tres prácticas prioritarias, manteniendo la estrategia.
 Primera: selección y asignación por competencias y calce de proyecto. PUR debe mantener
 un registro actualizado de habilidades técnicas verificadas, certificaciones pertinentes, experiencia
 por tecnología y preferencias/disponibilidad. Antes de cada asignación, traducir el requerimiento del
 cliente a criterios observables y validar con entrevista estructurada, prueba breve o evidencia de
 trabajo; registrar retroalimentación del cliente y trabajador después del proyecto. Así se reduce el
 desajuste sin contratar dotación ociosa permanente. La prueba debe ser proporcional y protegida
 para no pedir trabajo productivo gratuito ni usar criterios discriminatorios.
 Segunda: desarrollo continuo y compartido de habilidades. Crear una ruta de actualización en
 módulos cortos, laboratorios y certificaciones focalizadas en tecnologías con demanda real;
 combinar horas de aprendizaje pagadas, aportes de PUR, certificaciones del trabajador y acuerdos
 transparentes con clientes cuando el proyecto requiera entrenamiento específico. Usar
 comunidades técnicas y repositorios de lecciones aprendidas para que el aprendizaje no dependa
 solo de una persona. Priorizar con datos de demanda, cambios tecnológicos, fallas y vacantes
 difíciles. Medir vigencia de habilidades, asignación posterior, calidad y costo por competencia. Esto
 convierte el aprendizaje en inversión ligada a productividad y empleabilidad, sin financiar programas
 generales desvinculados de la estrategia.
 Tercera: gestionar una comunidad flexible de talento y continuidad con clientes. En vez de
 tratar a cada persona como un vínculo que termina al cumplir 90 días, mantener un pool voluntario
 de especialistas para nuevas asignaciones, con contacto entre proyectos, calendario de
 disponibilidad, reconocimiento, feedback y reglas claras de recontratación. Cuando sea posible,
 reubicar al mismo técnico en el cliente que ya conoce; documentar traspasos y conocimiento del
 sistema. Diseñar beneficios portátiles o proporcionales y condiciones contractuales transparentes,
 dentro de la normativa aplicable, evaluando su costo frente a menor rotación, tiempos de cobertura
 y mayor repetición. Esto conserva flexibilidad de dotación, pero crea continuidad relacional y reduce
 costos de búsqueda.
 Implementación y evaluación. Pilotear las tres prácticas en una familia tecnológica o grupo de
 clientes y comparar con proyectos semejantes: tiempo para cubrir, repetición del mismo trabajador,
 satisfacción de ambos lados, defectos/retrabajo, rotación voluntaria del pool, días sin asignación,
 margen neto después de reclutamiento y aprendizaje. Revisar métricas de calidad y seguridad junto
 a costo; premiar solo velocidad de colocación podría inducir malos calces. Ajustar el modelo si la
 continuidad mejora servicio pero aumenta costo más que el valor generado.
 Conclusión y límites. La flexibilidad de contratos y costos puede ser adecuada, pero la propuesta
 de Valencia es incompleta: economiza en relaciones y formación que sostienen precisamente el
 servicio especializado. La recomendación es preservar una estructura variable y añadir selección
 rigurosa, actualización de capacidades y continuidad del pool. Los datos del caso no permiten
Examen de Grado UC | materia, preguntas y respuestas 218

[pág. 219]
Dirección - versión clara y reordenada
 afirmar que contratos indefinidos o beneficios amplios sean rentables para todos; la evidencia debe
 decidir qué inversiones producen retorno y qué modalidades contractuales son legales y
 sostenibles.
 agosto 2017 - pregunta 2 - Cultura tóxica y sistema de personas
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 242-243 | convocatoria
 2
 Volver al enunciado original
 Tres prácticas pueden haber extendido la cultura de Uber: (1) incentivos y ascensos centrados en
 crecimiento/resultado financiero individual, que premian expansión rápida; (2) selección y
 socialización de perfiles competitivos con alta tolerancia a presión y metas; (3) liderazgo, diseño de
 trabajo y controles que privilegian autonomía/descentralización para ejecutar rápido, junto con
 mecanismos débiles para escuchar reclamos o responsabilizar a jefaturas por trato. La cultura
 emerge de lo que se recompensa, tolera y modela, no de valores escritos. En el caso, el énfasis
 financiero, competencia entre equipos y reubicación de jefes frente a problemas de trato pueden
 sostener ejecución y crecimiento, pero trasladan costo a trabajadores y conductores.
 Para sostenibilidad, alinearía las prácticas a resultados de largo plazo. Revisaría selección y
 liderazgo con criterios de respeto, cooperación, seguridad y resolución de problemas; balancearía
 incentivos financieros con métricas de retención, seguridad, experiencia de usuarios/conductores y
 calidad, más un umbral que impida premiar crecimiento con daño grave; y establecería
 voz/confidencialidad, investigación de reclamos, responsables y consecuencias. Capacitación a
 jefaturas para feedback y manejo de conflicto; políticas claras frente a acoso/represalias; datos de
 rotación por supervisor y revisión independiente. La descentralización puede permanecer si hay
 estándares, datos y rendición de cuentas.
 “Sostenible” significa que la ventaja pueda perdurar y que la organización gestione sus impactos y
 capacidades humanas; no se resuelve con un valor cultural agregado. Mide reclamos, rotación,
 seguridad, productividad/innovación y calidad de servicio; vigila que métricas no incentiven
 ocultamiento.
 agosto 2021 - pregunta 5 - Desempeño y cambio estratégico
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 350-351 | convocatoria
 2
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 219

[pág. 220]
Dirección - versión clara y reordenada
 a. Dos argumentos para mantener la evaluación
 1. Alinear y adaptar la ejecución de la diferenciación. Move+ pasó de 5 a 15 ingenieros y de 20
 a 50 técnicos y enfrenta competidores intensivos en aplicaciones e IA. Su propuesta se basa en
 soluciones creativas, adaptadas y cercanas al cliente; el trabajo remoto, las nuevas incorporaciones
 y la pertenencia a varios equipos requieren objetivos y contribuciones entendidos. Evaluar permite
 identificar brechas de coordinación y competencias, revisar responsabilidades y orientar esfuerzos
 hacia esa diferenciación. Suspenderla dejaría la adaptación sin información sistemática. 2. Dar
 apoyo y desarrollar capacidades precisamente bajo presión. Las jefaturas ahora interactúan
 menos y prestan menos atención a quienes tienen brechas. Una evaluación bien rediseñada
 permite escuchar carga y obstáculos, dar retroalimentación, acordar recursos y aprendizaje y
 reconocer aportes. El estrés justifica adaptar frecuencia, alcance y método, no renunciar al proceso.
 Mantener una evaluación no significa juzgar como si todas las condiciones fueran normales ni
 castigar responsabilidades familiares.
 b. Dos características esenciales del nuevo modelo
 1. Resultados y competencias pertinentes, con evidencia y controlabilidad. Acordar metas de
 calidad, satisfacción y continuidad de clientes junto a creatividad, asesoría, proactividad y
 colaboración. Incorporar evidencia de proyectos, clientes y compañeros pertinentes, rúbricas claras
 y calibración. La apreciación de conductas no es inválida por ser subjetiva: debe estructurarse y
 contrastarse; ventas y salud de usuarios tampoco son resultados enteramente controlados por cada
 persona. Ajustar objetivos a carga, cambios y oportunidades reales de cada equipo. 2. Proceso
 continuo de desarrollo y diálogo. Reemplazar una única entrevista anual por revisiones breves
 durante los proyectos, retroalimentación y apoyo individual, incluyendo incorporación y uso de
 tecnología. Revisar distribución de carga y dependencias entre equipos y fijar responsables y
 fechas de planes de desarrollo. Conservar reglas justas de evaluación y un espacio para corregir
 errores, cuidando que medir no agregue una burocracia que agrave la falta de tiempo.
 c. Dos características del incentivo variable
 1. Equilibrio entre contribución individual y resultado de equipo. Una parte reconoce
 capacidades, calidad de asesoría y aporte demostrable; otra, calidad y continuidad del servicio y
 cooperación del equipo. El trabajo interdependiente y las múltiples pertenencias hacen inadecuado
 premiar solo ventas propias o número de programas. Debe contemplar cómo repartir crédito entre
 equipos y no desincentivar ayuda. 2. Fórmula transparente, sostenible y con resguardos. Definir
 pesos, metas, umbrales, horizonte y fuentes de datos antes del período, según control y dificultad.
 No premiar volumen a costa de adaptación, privacidad o seguridad; reconocer calidad y resultados
 sostenidos y auditar información. Vincularlo a retroalimentación y desarrollo, sin asumir que pagar
 un bono corrige falta de competencias, recursos o coordinación. Probar su costo y efectos sobre
 cooperación y desempeño antes de extenderlo.
 enero 2024 - pregunta 2 - Diversidad e inclusión
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 405-406 | convocatoria
 1
 Volver al enunciado original
 1. ¿Cuál es el problema con la diversidad? No es que “haya demasiada diversidad” de personas.
 InnovarTech tiene diversidad demográfica, cultural, de edad y experiencia, pero no la convierte de
Examen de Grado UC | materia, preguntas y respuestas 220

[pág. 221]
Dirección - versión clara y reordenada
 manera confiable en perspectivas que influyan en decisiones y resultados. Hay una brecha entre los
 pilares declarados -innovación colaborativa, diversidad, igualdad y una sola empresa- y las
 prácticas reales: directorio y gerencia homogéneos, I+D concentrada en hombres de dos escuelas,
 estructura funcional, incentivos por gerencia y promoción según desempeño técnico individual.
 Esos mecanismos pueden excluir voces y optimizar silos aunque la organización tenga diversidad
 en su dotación. El caso aporta señales concretas de inclusión débil: María tiene éxito con clientes
 jóvenes pero poca adaptación a empresas tradicionales; Pedro, ingeniero brasileño con alto
 desempeño técnico, encuentra difícil integrarse a I+D; Li, de origen chino, se siente aislada por
 barreras idiomáticas y reuniones largas que reducen su participación; el área de personas es
 diversa, pero no siempre logra igualdad y desarrollo. No se puede concluir que demografía sea la
 causa de la caída de ventas. La caída en margen, innovación y clientes puede provenir de
 problemas de estrategia, oferta, ejecución, incentivos o competencia; hay que diagnosticarla. La
 diversidad puede ampliar información y creatividad, pero también elevar conflicto y costo de
 coordinación si no hay normas de inclusión, seguridad psicológica y objetivos compartidos. La
 homogeneidad directiva puede reducir desafío a supuestos y limitar entendimiento de clientes
 distintos. 2. Tres iniciativas de personas y cultura. Primera: crear gobernanza inclusiva y equipos
 interfuncionales con objetivo común. Formar equipos de producto con I+D, comercial, operaciones,
 personas y perfiles de distintas culturas, disciplinas y experiencia, responsables de oportunidades
 de cliente desde descubrimiento hasta adopción. Asegurar que todas las voces tengan turno, datos
 previos, liderazgo facilitador, desacuerdo respetuoso y responsable de integrar decisiones.
 Incorporar diversidad en dirección y pipeline de liderazgo, no solo en puestos técnicos iniciales.
 Esto integra distintas perspectivas en soluciones de IA y reduce fricción entre producto y clientes
 tradicionales; las metas compartidas conectan innovación y captura comercial. Segunda: alinear
 desempeño, desarrollo e incentivos con colaboración e impacto. Mantener estándares técnicos,
 pero evaluar también aprendizaje, transferencia de conocimiento, mentoría, trabajo
 interdisciplinario, calidad de producto, adopción/retención del cliente y contribución a ingresos y
 margen a horizonte apropiado. No sustituir desempeño por cuotas demográficas ni premiar
 actividad sin resultado; exigir criterios de promoción transparentes y calibrados para evitar que
 “visibilidad” o semejanza con líderes se confunda con mérito. Ofrecer mentoría, patrocinio y rutas de
 carrera para talento técnico/comercial diverso, con movilidad entre áreas. Así se reduce el incentivo
 a optimizar la gerencia propia y se retiene experiencia crítica. Tercera: remover barreras de
 inclusión y facilitar coordinación intercultural. Rediseñar reuniones con agenda, duración y
 decisiones claras; compartir documentos con antelación; habilitar comentarios
 escritos/asincrónicos, lenguaje accesible, facilitación y verificación de comprensión. Implementar
 onboarding y mentorías de pares, acuerdos de equipo sobre comunicación y resolución de conflicto;
 formar a líderes para reconocer interrupciones, aislamiento y sesgos, con canales seguros para
 reportar. Preguntar a Pedro y Li qué cambios les permitirían aportar, sin convertirlos en portavoces
 de una cultura. Medir clima, pertenencia, voz, rotación y acceso a proyectos por grupo y gerencia.
 Ejecución y medición. Pilotear equipos interfuncionales en una línea de solución para clientes
 jóvenes y tradicionales. Medir velocidad de experimentación, calidad técnica, adopción, renovación,
 margen, resolución de problemas, participación en decisiones, clima y retención. Evaluar efectos
 por subgrupo respetando privacidad y evitando comparar grupos sin contexto. Ajustar cuando la
 diversidad aumente coordinación sin suficiente valor, sin usar ese costo como razón para volver a
 excluir voces. Conclusión. La tarea es gestionar la diversidad para producir integración y
 aprendizaje. Una empresa “única” conserva estándares y una estrategia común, a la vez que
 aprovecha diferencias relevantes y distribuye voz y oportunidades. Los resultados de negocio no
Examen de Grado UC | materia, preguntas y respuestas 221

[pág. 222]
Dirección - versión clara y reordenada
 prueban causalidad entre diversidad y desempeño; conviene intervenir en procesos que el caso
 identifica y medir el mecanismo.
 marzo 2009 - pregunta 4 - Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 8-9 | convocatoria 1
 Volver al enunciado original
 La primera parte exige escoger hasta cuatro variables que permitan evaluar ambas propuestas, no
 decidir anticipadamente. (1) Demanda y cartera de proyectos por segmento/negocio y
 horizonte: vivienda media/baja cae cerca de 50% y es 60% del ingreso; vivienda alta se proyecta
 +10%; transmisión eléctrica anuncia proyectos a tres años y obras viales estímulo público por dos.
 Debe validarse probabilidad, margen, calendario y contratos, no equiparar anuncios con trabajo
 asegurado. (2) Posibilidad estratégica de redistribuir actividad y personas entre negocios:
 CASA diversifica de forma relacionada y tiene unidades autónomas con servicios compartidos; la
 coordinación define si reasigna ingeniería a sectores que crecen o enfrenta silos y costos de
 movilidad. (3) Capacidades, especificidad y criticidad del capital humano: 85% de
 dotación/remuneraciones son ingenieros y constructores formados dentro de CASA, con
 experiencia y buen desempeño; perderlos puede destruir conocimiento difícil de reconstruir, aunque
 deben identificarse habilidades transferibles y roles sobrantes. (4) Liquidez y flexibilidad de
 costos/organización: salarios representan compromiso de caja, pero CASA debe comparar
 despido e indemnización con retención, reasignación, menor jornada, vacaciones, capacitación y
 uso de horas extra/contratación.
 Para que “mínimos despidos/despido cero” sea sostenible, el pipeline eléctrico y vial debe
 convertirse con probabilidad suficiente en proyectos rentables y oportunos; la caída residencial
 debe poder absorberse dentro de la firma sin comprometer caja; y las capacidades disponibles
 deben ser transferibles o reentrenables a los nuevos proyectos dentro de sus calendarios. La
 empresa debe poder reducir horas o reasignar trabajo con reglas justas, preservar perfiles críticos y
 controlar costos. Si esos supuestos fallan, mantener toda la dotación puede crear iliquidez y
 amenazar todos los empleos; conviene un plan contingente por unidad, con hitos para activar
 movilidad, reducción temporal o despidos focalizados.
 agosto 2009 - pregunta 4 - Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 21-22 | convocatoria 2
 Volver al enunciado original
 No aplicaría el paquete tal como está, aunque mantendría sus dos intuiciones útiles: alinear
 incentivos con una estrategia de diferenciación y premiar creación de valor de largo plazo. CLC
 quiere calidad, servicio e innovación y depende de cooperación entre estudios, construcción y
 administración/finanzas. Reducir el sueldo fijo 10% bajo mercado arriesga atraer/retener perfiles
 necesarios y hace más sensible la remuneración a resultados que pueden depender del ciclo
 inmobiliario, permisos y proyectos, fuera del control de cada ejecutivo. En un negocio que busca
 calidad, el ahorro de fijo puede salir caro si aumenta rotación o empuja a recortar inversión y
 servicio.
 Agregar indicadores no financieros es coherente solo si representan resultados estratégicos
 observables: reclamos/resolución, defectos y postventa, innovación que llega al mercado,
 cumplimiento de hitos y cooperación entre áreas. Deben equilibrarse con márgenes/caja y auditarse
Examen de Grado UC | materia, preguntas y respuestas 222

[pág. 223]
Dirección - versión clara y reordenada
 para evitar manipulación o burocracia; medir satisfacción sin controlar selección de clientes o
 calidad de datos puede premiar lo incorrecto. Opciones con ejercicio a tres años amplían horizonte
 y exposición al valor accionario, pero pueden incentivar riesgo excesivo, dependen del ciclo/precio
 de acción y no garantizan cooperación. Diseñaría una mezcla de fijo competitivo, variable
 individual/de equipo/empresa, metas plurianuales, acciones restringidas u opciones con vesting,
 métricas de calidad y caja, umbrales, clawback y reglas ante eventos externos.
 Estoy de acuerdo en que compensación no basta para desarrollar competencias. El aprendizaje
 informal “obra a obra” transmite oficio, pero no asegura diagnóstico de brechas, coaching,
 movilidad, retroalimentación ni transferencia entre proyectos. Mantener una política de “poca
 paciencia” a dos años puede expulsar talento antes de madurar capacidades, especialmente
 cuando las obras tienen ciclos largos. Haría mapa de competencias estratégicas, asignaciones
 retadoras con mentoría, formación técnica/comercial, revisión de desempeño y carrera; evaluaría
 después adopción, defectos, postventa, innovación, margen y retención crítica.
 marzo 2010 - pregunta 4 - Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 37-38 | convocatoria 1
 Volver al enunciado original
 El RBW compite con atención personalizada de alta calidad y precisión apoyada por tecnología. El
 diseño de selección mezcla criterios subjetivos y estereotipos, y supone erróneamente que
 sistemas automáticos sustituyen juicio humano. Primera crítica: entrevista amplia sin estructura y
 “encaje sociocultural” no operacionalizado puede seleccionar semejanza personal, crear sesgo y
 producir decisiones inconsistentes; además, seleccionar por rasgos culturales vagos no demuestra
 servicio ni desempeño. Segunda crítica: pruebas de “anormalidad psicológica” y obediencia
 general son difíciles de justificar por el trabajo, arriesgan privacidad/discriminación y pueden excluir
 candidatos aptos; inferir dominio tecnológico por juventud o CV es un estereotipo y no mide
 aprendizaje real. En conjunto, el proceso privilegia impresiones y etiquetas antes que competencias
 críticas, y contrapone obediencia ciega al criterio necesario para resolver requerimientos no
 previstos.
 Propondría dos mejoras integradas. (1) Realizar análisis del cargo con incidentes críticos y definir
 competencias observables: comunicación y escucha, precisión, regulación emocional para
 situaciones difíciles, criterio para escalar, aprendizaje de sistemas y protección de datos. (2)
 Seleccionar con métodos estructurados: entrevista conductual con mismas preguntas y anclas,
 muestra de trabajo simulando llamadas y navegación del sistema, y una prueba de aprendizaje si el
 sistema es complejo. Evaluadores puntúan evidencia de manera independiente y luego comparan;
 verificar validez, accesibilidad, impacto adverso y consistencia. Los exámenes psicológicos solo se
 usarían si se demuestra pertinencia laboral, proporcionalidad y resguardo legal/ético, no para
 etiquetar enfermedad. La orientación a reglas se evalúa mediante situaciones de cumplimiento con
 juicio: seguir protocolo cuando corresponde y saber escalar excepción. Añadir una vista realista del
 trabajo y validar criterios con desempeño posterior/rotación.
 agosto 2010 - pregunta 4 - Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 52-53 | convocatoria 2
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 223

[pág. 224]
Dirección - versión clara y reordenada
 1. Evaluación del conjunto de medidas
 El conjunto es insuficiente para la diferenciación por innovación, calidad y duración. Atiende
 condiciones de trabajo y escucha, pero no resuelve directamente la capacidad y cooperación para
 desarrollar nuevos productos. El gráfico ayuda a priorizar: capacitación obtiene aproximadamente
 3,5 de 7; trabajo en equipo, participación y comunicación entre áreas, cerca de 4; compensaciones
 y beneficios, 5,5, y seguridad, 5. La claridad de objetivos alcanza 6, de modo que no basta volver a
 anunciar metas. Estos valores son lecturas aproximadas de las barras de la fuente 52.
 La línea directa puede dar voz, pero necesita respuesta y solución; centralizar toda comunicación
 en RR.HH. no genera necesariamente cooperación horizontal entre las áreas. El comité de
 seguridad es valioso, pero seguridad ya está mejor evaluada que capacitación y coordinación;
 premiar tres meses sin accidentes puede inducir ocultamiento y no explica por sí mismo innovación.
 El aumento general del fijo puede reforzar equidad y reconocimiento, aunque compensaciones son
 uno de los aspectos mejor evaluados; no desarrolla competencias ni vuelve contingente el pago a la
 calidad o innovación. En conjunto, puede elevar algunas percepciones sin cambiar las prácticas que
 bloquean la estrategia. Mantendría los componentes útiles, pero no lo adoptaría como respuesta
 suficiente ni prioritaria.
 2. Medidas para implementar la estrategia
 Primero, desarrollaría capacidades técnicas y de innovación con formación aplicada, aprendizaje en
 proyectos y retroalimentación sobre defectos, durabilidad y necesidades del cliente. El bajo
 resultado de capacitación es una brecha directamente pertinente a productos que todavía son
 similares a los competidores.
 Segundo, formaría equipos interfuncionales con representantes de desarrollo, producción y
 comercial, objetivos compartidos, tiempo y autoridad para experimentar y coordinación regular. Esto
 aborda trabajo en equipo y comunicación entre áreas, y traduce el conocimiento de cada función en
 diseños fabricables y comercialmente valiosos. Daría un proceso transparente a las sugerencias,
 con respuesta, prueba y cierre visible, en lugar de limitar la participación a un buzón.
 Tercero, reforzaría jefaturas y evaluación del desempeño para apoyar cooperación, aprendizaje y
 mejoras útiles, combinando reconocimiento colectivo e individual y métricas de calidad, durabilidad,
 adopción de productos y seguridad. Ajustaría el premio de seguridad hacia prevención, reporte
 honesto y acciones correctivas. El clima es una condición que favorece esfuerzo, pero el
 desempeño requiere también capacidades, recursos y oportunidad de contribuir; la encuesta no
 demuestra que toda la falta de resultados tenga una sola causa.
 agosto 2024 - pregunta 6 - Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 424-425 | convocatoria
 2
 Volver al enunciado original
 La diferencia entre Costco y Sam’s Club no se explica por una práctica aislada ni demuestra que
 una sea universalmente mejor. Costco compite con selección limitada, rotación, membresía más
 cara y marca propia; su estrategia necesita servicio/productividad y conocimiento del producto, por
 lo que salarios, beneficios, desarrollo, promoción interna, autonomía e incentivos de largo plazo
 forman un sistema complementario. Sam’s Club usa escala, 7.000 artículos, logística/tecnología y
 foco de eficiencia; un modelo de empleo de menor costo y formación más acotada puede ser
Examen de Grado UC | materia, preguntas y respuestas 224

[pág. 225]
Dirección - versión clara y reordenada
 coherente con ese diseño. El ajuste entre estrategia, organización del trabajo y sistema AMO
 (habilidad, motivación, oportunidad) explica desempeño, no la “generosidad” de una política sola.
 Que el modelo de Sam’s sea más común puede deberse a: (1) menor costo salarial inmediato y
 dificultad de capturar retornos inciertos de inversión en personas; (2) estructuras de retail y métricas
 financieras trimestrales que privilegian flexibilidad, estandarización y productividad visible; (3)
 requisitos complementarios y capacidad gerencial: el sistema Costco exige capacitación, carrera
 interna, supervisores capaces de delegar y una propuesta de valor donde productividad/retención
 paguen el mayor costo. Sin esas complementariedades, subir salarios aislados puede elevar costos
 sin desempeño.
 El mercado puede valorar más a Costco si anticipa menores rotación/ausentismo, más
 productividad por hora, ejecución consistente, mejor servicio, sugerencias de eficiencia, menor
 costo de reemplazo, marca empleadora y estabilidad de ingresos/márgenes; también puede atribuir
 valor a reputación laboral frente a mayores expectativas sociales. El precio bursátil no prueba
 causalidad: depende de crecimiento, riesgo, capital, estructura y expectativas; para aislar la
 contribución de personas se necesitaría evidencia longitudinal o cuasi experimental, métricas
 comparables por tienda/empleado y análisis de costos totales.
 agosto 2025 - pregunta 3 - Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 443-444 | convocatoria
 2
 Volver al enunciado original
 No recomendaría ni separar totalmente ni imponer al negocio digital las prácticas del diario impreso.
 Ambos modelos deben preservar capacidades distintas: el impreso requiere investigación, rigor,
 edición y confianza; Emol necesita rapidez, analítica, producto digital, pruebas y retención. Pero
 comparten activos estratégicos: marca, legitimidad, conocimiento local, estándares editoriales,
 talento, datos y relación comercial. La opción es diferenciación de prácticas con integración
 selectiva: autonomía operativa para lo específico, mecanismos de coordinación para lo compartido.
 Dos políticas de personas clave: (1) arquitectura de desempeño común en propósito/ética y
 estándares, con objetivos y métricas diferenciados por canal. Para papel: profundidad, precisión,
 confianza, suscripción; para digital: fidelización y producto, con métricas de calidad/credibilidad
 como contrapeso a clics y tiempo. Calibración común y criterios transparentes facilitan movilidad sin
 equiparar trabajos distintos. (2) gestión de talento y colaboración: mapa de capacidades, formación
 cruzada (verificación, datos, producto, narración), movilidad/rotaciones voluntarias entre equipos,
 equipos editoriales mixtos para proyectos y desarrollo de líderes que traduzcan ritmos distintos.
 Reconocimiento conjunto de productos que aumenten credibilidad y alcance sin sacrificar
 independencia.
 Implementar con gobernanza editorial clara: decisiones sobre verdad, correcciones y fuentes no
 subordinadas a métricas comerciales; resolver propiedad de audiencias/datos y evitar que el
 algoritmo determine pauta. Medir confianza, correcciones, retención y calidad; experimentar con
 formatos; encuestas de colaboración y movilidad. Así se obtiene coherencia de marca sin borrar
 competencias ni culturas útiles de cada negocio.
Examen de Grado UC | materia, preguntas y respuestas 225

[pág. 226]
Dirección - versión clara y reordenada
 enero 2026 - pregunta 4 - Estrategia y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 458-459 | convocatoria
 1
 Volver al enunciado original
 Las tres competencias clave de jefaturas Ganga son: (1) ejecución operacional y priorización bajo
 presión: coordinar stock, campañas, turnos y servicio con estándares consistentes entre tiendas;
 así cumple disponibilidad y experiencia predecible. (2) criterio de decisión laboral y ética: aplicar
 reglas con debido proceso, no discriminación, derechos sindicales, jornada, beneficios y seguridad;
 detectar cuándo escalar con antecedentes, no castigar “falta de colaboración”. Reduce litigios,
 costos, interrupciones y daño reputacional. (3) liderazgo de personas y equipos: comunicar metas,
 distribuir cargas, escuchar, resolver conflictos, dar feedback y proteger salud; mantiene
 compromiso, aprendizaje y capacidad de sostener productividad en periodos exigentes.
 El sistema de metas/resultados no es suficiente: resultados operativos aceptables coexisten con
 prácticas antisindicales, discriminación, despidos injustificados, temor y escalamiento excesivo.
 Metas pueden inducir atajos y ocultar costos legales/reputacionales rezagados. Tres medidas
 complementarias: (a) añadir indicadores de proceso y cumplimiento verificable (jornada, horas
 extra, consistencia en beneficios, investigación de denuncias, respeto a representación) con
 umbrales no compensables; (b) evaluar conductas/competencias con evidencia estructurada de
 trato, distribución de carga, deliberación y manejo de conflictos, feedback 360/voz del equipo y
 calibración para reducir favoritismo; (c) rediseñar incentivos con balance de resultados comerciales,
 servicio/stock, salud/retención y calidad laboral, componente grupal, horizonte diferido y clawback
 por faltas comprobadas, junto con revisión de casos y aprendizaje tras incidentes.
 Debe haber canal seguro, asesoría laboral accesible, entrenamiento práctico para casos, autoridad
 para parar prácticas ilegales y revisión independiente. No premiar cumplimiento “a cualquier costo”;
 sí reconocer resultados sostenibles y decisiones justificables. Revisar indicadores por tienda y
 grupos protegidos, con privacidad, apelación y debido proceso.
 enero 2025 - pregunta 2 - Evaluación de desempeño e incentivos
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 429-430 | convocatoria
 1
 Volver al enunciado original
 1. Evaluación de los argumentos sobre KPIs y SMART
 La gerente Guita acierta en que contar con indicadores y tramos conocidos ofrece claridad sobre lo
 evaluado. Sin embargo, no acredita que su diseño satisfaga los más altos estándares SMART ni
 que esa claridad baste para agregar valor estratégico. El gerente general tiene una crítica fundada:
 Morlacci quiere crecer en colocaciones diferenciándose por agilidad, tecnología y colaboración
 transversal, y exige esos mismos atributos al servicio interno. La GPyCdG sirve a doce gerencias,
 procesa cerca de 120 indicadores y sus resultados dependen de coordinarse con todas ellas. Un
 tablero centrado en productos individuales, atendidos por FIFO, puede cumplir su propia definición
 de éxito y dejar insatisfechas necesidades prioritarias del banco.
 El caso define SMART como específico, medible, alcanzable, realista y acotado en el tiempo. Hay
 fortalezas parciales: el plazo de entrega, los errores y las recomendaciones son observables, y
 existe evaluación anual. Pero deben aclararse el momento de inicio del plazo, el volumen y período
Examen de Grado UC | materia, preguntas y respuestas 226

[pág. 227]
Dirección - versión clara y reordenada
 de informes/recomendaciones y qué cuenta como error o recomendación válida. No se entrega
 evidencia de recursos, carga y línea base que demuestre que las metas son alcanzables y realistas.
 Evaluar una vez al año tampoco garantiza una gestión oportuna del desempeño: un informe de
 presupuesto puede ser inútil si llega después de la decisión que debía apoyar.
 La tabla además contiene ambigüedades comprobables. En tiempos, “bueno: menor a 30 días” y
 “excelente: menor a 15 días” se superponen si no se fija que prevalece el tramo superior. En
 recomendaciones quedan sin clasificar exactamente cinco y exactamente veintiséis: las categorías
 son menos de cinco, seis a diez, once a quince, dieciséis a veinticinco y más de veintiséis. Hay que
 establecer intervalos exhaustivos y excluyentes. El conteo absoluto de errores tampoco permite
 comparar a quien procesa pocos informes simples con quien recibe muchos complejos.
 La debilidad estratégica más relevante es que los KPIs no miden suficientemente la utilidad del
 servicio. El 32% del componente individual premia rapidez, otro 32% errores y el 36% cantidad de
 recomendaciones. La rapidez no está diferenciada por urgencia, complejidad e impacto; el número
 de recomendaciones puede premiar fragmentar o inflar propuestas, sin que se implementen o
 cierren brechas. FIFO iguala requerimientos de importancia desigual y puede postergar una
 decisión crítica tras tareas rutinarias. Que el cliente interno sea evaluador aporta información
 pertinente, pero, usado como única fuente sin evidencia y calibración, abre riesgos de favoritismo,
 negociación de notas y castigo por emitir diagnósticos incómodos.
 Rediseñaría el sistema con una priorización por criticidad y acuerdos de nivel de servicio por tipo de
 requerimiento; tasas de entregas oportunas y errores ajustadas por volumen y complejidad; y
 calidad, adopción e impacto de recomendaciones sobre brechas verificables. Agregaría
 colaboración transversal y satisfacción de clientes internos, contrastadas con datos y criterios
 comunes. La persona debe conocer metas, recursos, responsables y reglas antes del período,
 recibir feedback durante él y poder revisar la evaluación. SMART es una condición de buena
 medición; el alineamiento de lo medido con la estrategia y la consistencia entre prácticas son
 condiciones adicionales.
 2. Evaluación de los argumentos sobre bono, motivación y éxito del banco
 El gerente general tiene razones para cuestionar el bono, pero el aumento de rotación no
 demuestra por sí solo que este cause desmotivación ni que ninguna persona esté motivada.
 Pueden intervenir sobrecarga, jefaturas, carrera y ofertas externas; el área tiene una complejidad
 mayor que sus pares. Guita también tiene razón en que la salida de algunas personas no prueba
 que el sistema falle para todos. Su inferencia de que funciona porque la mayoría está satisfecha es
 insuficiente: satisfacción con recibir dinero, esfuerzo orientado a los objetivos correctos, retención
 de personas clave y contribución al negocio son resultados diferentes. Perder capacidades críticas
 puede perjudicar al banco aunque la mayoría que permanece declare satisfacción.
 El diseño ofrece una explicación plausible del problema. El 10% ligado al EBITDA y el 10% al
 crecimiento de colocaciones conectan con resultados del banco, pero cada empleado de GPyCdG
 tiene escaso control directo sobre ellos; existen condiciones macroeconómicas y decisiones de
 otras áreas. El 80% individual domina el pago, aunque la gerente reconoce que la carga exige
 objetivos compartidos, coordinación y colaboración. Puede inducir a proteger la propia cartera,
 evitar trabajos complejos o ayudar menos a un colega si esa ayuda no cuenta para el bono. Dentro
 del total, tiempos y errores pesan cada uno 25,6% (80% × 32%) y cantidad de recomendaciones
 28,8% (80% × 36%); estas tres métricas concentran los incentivos reales. Pagar fijo y variable en la
Examen de Grado UC | materia, preguntas y respuestas 227

[pág. 228]
Dirección - versión clara y reordenada
 media del mercado no elimina esos desajustes.
 Desde la teoría de expectativas, debe existir una relación creíble entre esfuerzo y desempeño, entre
 desempeño y pago, y entre el pago y lo que cada persona valora. Sobrecarga y dependencias
 externas debilitan la primera relación; evaluación anual, indicadores ambiguos o clientes
 evaluadores inconsistentes debilitan la segunda; una compensación media puede no retener a
 especialistas escasos ni sustituir desarrollo y reconocimiento. Desde justicia organizacional, importa
 que el resultado y el procedimiento reconozcan dificultad, contribución y cooperación. Desde
 motivación intrínseca, hacer recomendaciones útiles, desarrollar competencias y participar en
 decisiones puede sostener un compromiso que el bono monetario solo no produce.
 Por ello mantendría un componente de resultados del banco, pero combinaría contribución
 individual con desempeño del equipo y calidad del servicio transversal. No fijaría pesos nuevos sin
 conocer costos y conductas esperadas: se acordarían y probarían con personas y clientes internos.
 Usaría metas controlables, reglas transparentes, calibración, reconocimiento de ayuda entre áreas
 y guardas contra sacrificar calidad o independencia. Complementaría el pago con dotación y carga
 adecuadas, formación, autonomía para priorizar y carrera para perfiles críticos. Revisaría rotación
 por antigüedad, jefatura y especialidad, entrevistas de salida y permanencia, remuneración total
 comparada, colaboración y resultados del servicio. La prueba de éxito sería que el sistema motive
 conductas útiles para la estrategia y sostenga capacidades, no solo que entregue bonos o reciba
 una encuesta favorable.
 agosto 2015 - pregunta 2 - Formalización y productividad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 175-176 | convocatoria
 2
 Volver al enunciado original
 1. Evaluación de Parada y Bermúdez
 Estoy de acuerdo con Parada en mejorar la gestión para elevar productividad. El estudio entrega
 una descomposición concreta: Suceso parte en 35 frente al índice 100 de los líderes de Estados
 Unidos; la adaptación de dotación a la afluencia aporta 28 puntos, reducir el tiempo de maduración
 de nuevas salas 18, la canasta promedio 12, formalizar procesos 4 y utilizar tecnología los 3
 restantes por diferencia aritmética. Los 3 no se leen como etiqueta clara en la barra, pero
 completan 35+4+3+18+28+12=100. No todo corresponde exclusivamente a personas: la canasta
 también depende de precios y productos. El benchmark orienta prioridades, aunque hay que
 verificar comparabilidad e interacciones antes de atribuirle una causalidad exacta.
 No estoy de acuerdo con la explicación general de Bermúdez de que se trabaja poco. Chile ya
 registra 1.990 horas anuales, frente a 1.789 en Estados Unidos y 1.770 promedio OCDE; trabajar
 más no explica automáticamente la eficiencia. El indicador es margen operacional por trabajador:
 más horas con la misma dotación puede subirlo si atiende demanda adicional, pero no
 necesariamente mejora productividad por hora ni margen después de recargos, fatiga y errores. Se
 debe organizar la capacidad según demanda y crear competencias, en vez de aumentar horas
 indiscriminadamente.
Examen de Grado UC | materia, preguntas y respuestas 228

[pág. 229]
Dirección - versión clara y reordenada
 2. Dos prácticas de mayor impacto
 1. Planificar y flexibilizar dotación y turnos según afluencia. Es la brecha mayor, 28 puntos.
 Usar datos de tráfico y tareas por franja para dimensionar cobertura, ajustar jornadas dentro de las
 reglas aplicables y formar personas capaces de cubrir más de una tarea. Reduciría personal ocioso
 en horas bajas y pérdidas de ventas, filas y mala atención en horas punta. Debe incluir estabilidad y
 previsibilidad para trabajadores y resguardos de servicio y seguridad; el objetivo es mayor margen
 por dotación y por hora, no solo recortar personal. 2. Acelerar aprendizaje y puesta en marcha de
 salas. La maduración explica 18 puntos, segunda brecha. Definir estándares de trabajo, capacitar
 antes de abrir, trasladar mentores experimentados y formar jefaturas y equipos en operación,
 tecnología y atención. Acompañar el aprendizaje con retroalimentación e indicadores de
 disponibilidad, merma, calidad y flujo. Esto permite que las salas nuevas utilicen más pronto su
 capacidad y alcancen margen normal sin improvisar. La formación también ayuda a capturar los
 beneficios menores de tecnología y formalización, pero no debe reemplazar la prioridad que el
 gráfico otorga a adaptación de dotación y madurez.
 agosto 2012 - pregunta 2 - Gestión por competencias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 105-106 | convocatoria
 2
 Volver al enunciado original
 1. Tres debilidades de gestión de competencias
 1. Definición incompleta de las competencias del nuevo negocio. Anunciar “Análisis y
 Resolución de Problemas” y dar un discurso motivacional no especifica conductas, niveles ni
 evidencia. Consultoría requiere escuchar y diagnosticar a la PYME, comprender restricciones,
 evaluar alternativas y formular recomendaciones ejecutables; creatividad publicitaria no sustituye
 esas capacidades. Los reclamos sobre soluciones originales pero impracticables muestran esta
 brecha. 2. Selección y promoción con un predictor que no corresponde al nuevo cargo. El
 desempeño pasado predice mejor cuando tareas y contexto son pertinentes. Elegir a los mejores
 publicistas de campañas y a personas asertivas no comprueba capacidad consultiva ni escucha.
 Impedir postular puede dejar fuera a candidatos con mejor potencial. Un proceso percibido como
 justo por desempeño creativo puede ser válido para premiar publicidad y aun así seleccionar mal
 para consultoría. 3. Ausencia de cierre sistemático de brechas y evaluación pertinente. El área
 de Desarrollo Organizacional recién creada no aparece traduciendo el cambio en formación,
 acompañamiento, evaluación o carrera. La alta rotación y la falta de repetición de clientes indican
 que promoción y mayor sueldo no bastan. La ubicación del área puede debilitar su influencia, pero
 no demuestra por sí sola la causa del problema.
Examen de Grado UC | materia, preguntas y respuestas 229

[pág. 230]
Dirección - versión clara y reordenada
 2. Tres intervenciones
 1. Construir perfiles por competencias con el gerente de consultoría y evidencia de clientes:
 diagnóstico, análisis de negocio, escucha, trabajo en equipo y recomendaciones implementables,
 con niveles y criterios comunes. 2. Evaluar al equipo y futuros postulantes mediante casos de
 PYMES, entrevistas conductuales y referencias pertinentes; abrir postulación y justificar decisiones.
 Combinar talento interno con contratación externa cuando falten capacidades, en vez de usar
 premios publicitarios como sustituto. 3. Implementar desarrollo y desempeño integrados: mentoría,
 formación en diagnóstico y estrategia, proyectos supervisados, revisión de recomendaciones y
 retroalimentación de clientes; evaluar implementación, satisfacción y repetición, no solo
 originalidad. Alinear reconocimiento y carrera con esos resultados y revisar carga y apoyo para
 reducir rotación. Así la competencia declarada se convierte en habilidad demostrada y aplicada.
 agosto 2016 - pregunta 2 - Incentivos estrechos versus amplios
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 203-206 | convocatoria
 2
 Volver al enunciado original
 Qué pregunta realmente. El caso contrasta dos supuestos sobre cómo se distribuye el desempeño
 y qué tan bien puede medirse: Vicent propone una banda estrecha de bonos por nivel; Bock acepta
 diferencias extremas entre personas, incluso dentro de la misma función. Debo explicar las teorías
 implícitas, riesgos y una práctica de personas distinta a compensación que modere cada riesgo. 1.
 Supuestos y efectos potenciales. Vicent: diferencias pequeñas y desempeño alto relativamente
 homogéneo. Supone que la selección rigurosa lleva a contratar personas de alta calidad, que
 quienes ocupan cargos/niveles similares aportan valor comparable y que la justicia exige bandas
 similares. El bono se concibe como reconocimiento y foco para metas, no como precio exacto de
 contribución individual. Ventajas: previsibilidad, cooperación, menor costo de medición y menor
 rivalidad interna. Riesgos: comprime diferencias reales de aporte; puede retener mal a talento
 escaso si sus alternativas pagan más; trata igual contribuciones distintas, debilitando motivación y
 señalando que el esfuerzo extra no se reconoce. Premiar metas anuales también puede dejar fuera
 innovación de largo plazo o colaboración cuyo resultado es difícil de atribuir. Bock: variación muy
 grande en contribución individual y capacidad de identificarla. Supone que una minoría puede
 producir valor excepcional, que el efecto marginal de sus aportes es muy desigual y que la empresa
 puede medirlo suficientemente bien para pagar mucho más sin dañar el sistema. Ventajas: retener
 capacidades escasas y alinear recompensas a contribuciones de alto valor en una industria
 cambiante. Riesgos: confundir resultados con suerte, equipo o asignación de proyectos; sesgo y
 ruido de evaluación; percepción de arbitrariedad; competencia destructiva, ocultamiento de
 conocimiento y sacrificio de calidad o cooperación; concentración en resultados visibles/cortos;
 inequidad por sesgos o acceso desigual a oportunidades. Una diferencia grande solo es justa y
 eficaz si se apoya en evidencia de contribución y proceso legítimo, no en intuición del jefe. 2.
 Práctica complementaria para cada propuesta. - Para la banda estrecha de Vicent: reforzar diseño
 del trabajo, desarrollo y reconocimiento no monetario para sostener motivación y retención de
 personas de alto desempeño aunque el bono varíe poco. Ofrecer desafíos técnicos, autonomía,
 aprendizaje, carrera experta y participación en proyectos de innovación; reconocer contribuciones
 específicas y trabajo de equipo. Esto mitiga la sensación de que el bono plano ignora capacidades
 escasas. Debe acompañarse de entrevistas de retención y señales de mercado; beneficios
 intangibles no compensan automáticamente una brecha salarial injustificada. - Para la dispersión
Examen de Grado UC | materia, preguntas y respuestas 230

[pág. 231]
Dirección - versión clara y reordenada
 amplia de Bock: establecer gestión del desempeño rigurosa y justa antes de asignar diferencias
 extremas: expectativas por rol, metas de equipo e individuales, criterios de impacto, evidencia de
 todo el año, feedback frecuente, revisión entre pares/calibración, evaluación de colaboración y
 calidad, explicación de decisiones y canal de revisión. Incluir indicadores adelantados de
 aprendizaje/innovación y no solo ingresos inmediatos. Así se mejora validez y legitimidad; no
 elimina el ruido ni convierte una contribución colectiva en propiedad de una persona. Conclusión.
 Ninguna estructura es óptima por sí sola. Diseñaría bandas diferenciadas por mercado y
 contribución, con componente de equipo para complementariedad y criterios explícitos de impacto
 individual; pilotearía y revisaría retención, colaboración, innovación, equidad y desempeño por
 grupos. La estrategia de crecimiento e innovación exige atraer talento, pero también construir
 contextos donde las personas compartan conocimiento y prueben ideas.
 enero 2020 - pregunta 2 - Incentivos grupales y justicia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 305-306 | convocatoria
 1
 Volver al enunciado original
 a) Dos problemas centrales del plan de incentivos
 Primero, evaluación y asignación del premio con baja comparabilidad y conductas adversas.
 Río Claro presta un servicio diferenciado por calidad y rapidez mediante equipos de unas siete
 personas con especialidades interdependientes. El premio anual combina tiempo de ejecución,
 horas utilizadas y satisfacción, pero los equipos que reciben proyectos difíciles parten en desventaja
 si se comparan tiempos brutos sin controlar complejidad. Además, ayudar a otro equipo consume
 horas propias sin reconocimiento y puede disminuir el premio del que coopera: el sistema
 recompensa competencia entre equipos donde el negocio necesita colaboración. Las horas
 autoinformadas sin verificación hacen posible manipular el indicador. No se demuestra que los
 premiados hayan falseado datos; el riesgo y la sospecha bastan para deteriorar justicia y confianza.
 Segundo, reparto interno que confunde sueldo base con contribución. Los cinco equipos
 ganadores recibieron un promedio de $7 millones por equipo, repartido en proporción a salarios.
 Esa regla reproduce brechas salariales, incluidas las de género descritas, sin comprobar diferencias
 de aporte. También permite que personas de baja contribución cobren una fracción importante por
 tener mayor sueldo, lo que genera free riding y desmotiva a quienes sí colaboran. El premio
 colectivo es coherente con tareas interdependientes; el problema es medir y repartir con criterios
 que no reflejan esfuerzo, rol y contribución justa. Haber comunicado la regla previamente aporta
 transparencia, pero no vuelve justo o estratégico su contenido.
 b) Dos intervenciones al incorporar 10 X
 El caso define 10 X como una brecha máxima de diez veces entre el mayor y el menor sueldo, junto
 con la propuesta de eliminar el incentivo. No es una meta de producir diez veces más. Bajo ese
 supuesto, primero establecería una arquitectura salarial transparente por valor del cargo,
 competencias y responsabilidades, auditando diferencias no justificadas entre hombres y
 mujeres y simulando cómo cumplir el cociente máximo sin comprometer solvencia. Comunicaría
 criterios y transición, escucharía a equipos y mantendría rutas de progresión técnica y desarrollo
 dentro de la nueva estructura. Así se reduce inequidad y se conserva una relación entre aportes,
 reconocimiento y carrera aun sin el bono anterior.
Examen de Grado UC | materia, preguntas y respuestas 231

[pág. 232]
Dirección - versión clara y reordenada
 Segundo, instalaría gestión participativa del desempeño y autogestión, separando la
 evaluación de la obligación de pagar un premio financiero. Acordar objetivos de calidad, rapidez y
 seguridad por dificultad de proyecto; revisar resultados frecuentemente; verificar horas con registros
 y valorar ayuda entre equipos. Entregar a los equipos autoridad, información y recursos para
 planificar, aprender y corregir problemas, con feedback y reconocimiento de contribuciones. La
 participación, autonomía responsable y desarrollo sostienen motivación intrínseca y colaboración, y
 conservan control de productividad. Eliminar un bono defectuoso no elimina la necesidad de metas
 ni convierte un salario más equitativo en garantía de buen desempeño.
 c) Dos problemas potenciales de implementación
 Uno, costo y viabilidad de ajustar la estructura. Cumplir 10 X elevando salarios bajos puede
 aumentar el costo fijo; hacerlo reduciendo salarios altos puede provocar pérdida de especialistas y
 directivos, percepción de incumplimiento y dificultad de atraer talento. Es necesario aclarar qué
 remuneración se compara y estimar escenarios de costo, mercado y responsabilidades; el ratio por
 sí solo no define esos detalles.
 Dos, debilitamiento de diferenciación y justicia percibida. Si se elimina todo reconocimiento de
 aporte sin reemplazar evaluación, feedback y carrera, quienes desempeñan tareas difíciles o
 contribuyen más pueden percibir que se trata igual a aportes distintos; el free riding descrito puede
 persistir. La compresión salarial tampoco repara automáticamente brechas de género dentro de un
 cargo, manipulación de datos o desincentivo a ayudar. 10 X puede contribuir a una política de
 equidad, pero debe acompañarse de un sistema de trabajo y desempeño coherente con calidad,
 rapidez y capacidades técnicas escasas.
 agosto 2011 - pregunta 4 - Incentivos por procesos o resultados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 79-80 | convocatoria 2
 Volver al enunciado original
 El Plan A paga por evaluación mensual de calidad, servicio, limpieza y entrenamiento; el Plan B
 paga anualmente 5% del crecimiento de ventas más 10% de utilidades cuando el margen supera
 12%. Para un local base de $500 millones, el sueldo fijo anual es cerca de $21 millones. A puntaje
 8, el Plan A entrega 50% mensual del fijo: $875.000 por mes o hasta $10,5 millones por año. A
 puntaje 7, sería 35% mensual: $612.500 por mes o $7,35 millones anualizados. El Plan B, en el
 escenario descrito, genera $2,5 millones por ventas incrementales y $7,7 millones por utilidades,
 total $10,2 millones/año.
 A evalúa directamente conductas estratégicas del servicio y entrenamiento, y entrega señal
 frecuente, pero su dependencia del juicio del jefe de área puede introducir severidad/afinidad y
 presión para inflar notas; escalones 0/1/2 producen discontinuidades y las ventas/utilidades quedan
 poco representadas. B conecta con resultados financieros y crecimiento, pero el umbral de 12%
 crea salto/cliff: pequeñas diferencias contables pueden eliminar un componente completo; ventas
 pueden premiarse aun con baja calidad, y el gerente puede tener poca influencia sobre ubicación,
 marketing corporativo o costos asignados. Es anual, por lo que la retroalimentación es más lenta.
 Combinar A y B puede ser correcto porque equilibra drivers de servicio/equipo con resultados
 económicos. No sumaría mecánicamente dos bonos: definiría peso y techo, indicadores
 controlables, auditoría objetiva y una puerta mínima de calidad/seguridad. Por ejemplo, el pago
 financiero se activa solo si se cumplen estándares críticos de calidad y reclamos; parte colectiva
Examen de Grado UC | materia, preguntas y respuestas 232

[pág. 233]
Dirección - versión clara y reordenada
 premia formación/retención y parte local margen de contribución comparable. Calibro diferencias de
 ubicación, estacionalidad y cambios de política central; hago retroalimentación mensual y
 liquidación anual. Piloto y seguimiento de margen, ventas, satisfacción, rapidez, reclamos, merma,
 dotación/entrenamiento y rotación.
 enero 2014 - pregunta 2 - Incentivos y selección alineados
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 140-141 | convocatoria
 1
 Volver al enunciado original
 Qué pregunta realmente. Se debe decidir si los resultados de un piloto justifican escalar un reparto
 de utilidades, rediseñar sus incentivos y cambiar la selección para reducir rotación y sostener una
 estrategia diferenciada por calidad, asesoría experta y atención personalizada. Hay que leer
 conjuntamente indicadores económicos y de experiencia, y reconocer que dos locales durante seis
 meses no prueban causalidad general. a) Evaluación de las opiniones. Me acerco a la cautela de
 Aliste y Vera: el plan muestra una señal financiera favorable, pero la conclusión de Tormen es
 demasiado amplia. En ambos locales la utilidad operacional sube de $31 a $37 millones en Barrio
 Italia y de $28 a $34 millones en Mall Santiago Centro, es decir, +$6 millones en cada uno. Esto es
 compatible con mejora de rentabilidad, pero no identifica cuánto se debe a Pedalea, cuánto a
 cambios de ventas/costos, ni si el resultado se sostiene. En Barrio Italia los ingresos suben de 100 a
 115; en Mall bajan de 100 a 99. Las encuestas muestran resultados mixtos: en Barrio mejoran
 sentirse valorado, probabilidad de volver y recomendar, pero cae rapidez al saludar y tiempo de
 espera; en el Mall la mayoría de los atributos cae y se mantiene el conocimiento técnico. Esto
 importa porque servicio personalizado y asesoría son parte central de la propuesta, y ventas/utilidad
 pueden subir al mismo tiempo que se deteriora la experiencia. No concluiría que el programa
 fracasó: el aumento de utilidades y ciertas mejoras son señales útiles. Recomendaría no escalarlo
 sin ajustes y evidencia adicional. La comparación es limitada por tamaño (dos locales), duración,
 posibles diferencias de ubicación/flujo y falta de un contrafactual no tratado o serie temporal
 suficiente; las encuestas tampoco informan tamaños muestrales ni incertidumbre. b) Cambios al
 esquema Pedalea. Mantendría el vínculo con utilidad incremental, pero definiría una línea base
 verificable y comparable por tienda y ajustaría por factores fuera del control del jefe (ubicación,
 estacionalidad, inversión, afluencia o campañas corporativas). Pagaría por utilidad económica
 sostenible, excluyendo manipulación de costos, diferimiento de mantenimiento o recortes que
 dañen servicio. Incorporaría umbrales de resguardo para satisfacción, calidad de asesoría, tiempos
 de espera y reclamos; si caen bajo un nivel acordado, se reduce o retiene parte del bono hasta
 revisar causas. Usaría una mezcla de métricas financieras y de cliente/equipo, con pesos que
 reflejen la estrategia; combinarlas evita optimizar una dimensión sacrificando las demás. Revisaría
 el reparto 35/15/50 y la regla de pérdida total por renuncia. El reparto del equipo reconoce
 interdependencia, pero debe especificarse el cálculo, elegibilidad y tratamiento de contribuciones, y
 respetar la legislación y derechos devengados aplicables. El retraso puede favorecer retención,
 aunque perder todo el bono al renunciar genera riesgo percibido y puede ser injusto o inducir
 permanencia artificial; preferiría pago proporcional al período cumplido con una parte diferida, si es
 legal y financieramente sostenible. Antes de fijar porcentajes estimaría costo, sensibilidad y
 conducta probable. Probaría el esquema ajustado en más locales comparables con implementación
 gradual. c) Selección y retención. Primero validaría el diagnóstico de salida: las entrevistas apuntan
 a remuneración, pero se debe contrastar con compensación total de mercado, carga, jefatura,
Examen de Grado UC | materia, preguntas y respuestas 233

[pág. 234]
Dirección - versión clara y reordenada
 horarios, carrera y condiciones por tienda. Definiría un perfil de jefe que incluya conocimiento
 técnico de bicicletas, orientación consultiva al cliente, liderazgo/coaching y gestión de inventario y
 rentabilidad. Usaría criterios y escalas consistentes para candidatos internos y externos: entrevista
 estructurada, caso de asesoría de cliente y ejercicio de planificación de tienda; evitar decidir solo
 por rapidez o fama deportiva. La contratación inmediata debe cubrir vacantes, pero puede
 mantenerse una terna/pool capacitado y una ruta interna para reducir dependencia de selección
 apurada. Entregaría una descripción realista del rol y sus metas, onboarding y oportunidades de
 desarrollo. Revisaría equidad salarial por tamaño, ubicación y complejidad del local: medir solo
 ventas absolutas penaliza tiendas pequeñas aunque sean muy rentables y contribuyan fuertemente
 a la estrategia. Conclusión e indicadores. Pilotearía una versión balanceada del incentivo y el
 proceso de selección, midiendo utilidad incremental ajustada, ventas/margen, retención y rotación,
 costo de vacantes, satisfacción por atributo, reclamos y repetición de compra. Escalaría si la mejora
 económica es repetible y no se obtiene deteriorando calidad de atención. El caso no permite
 estimar significancia estadística ni separar con precisión efectos de incentivo, ubicación y otros
 cambios.
 enero 2016 - pregunta 2 - Indicadores, incentivos y cultura
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 187-188 | convocatoria
 1
 Volver al enunciado original
 Qué pregunta realmente. Hay dos preguntas distintas: por qué un tablero de metas y bonos puede
 fallar como sistema de ejecución estratégica; y por qué distribuir instrucciones y equipo de
 protección, junto con exigirlos al contratista, no basta para reducir accidentes. La muerte de un
 trabajador externo revela una brecha grave de gestión del sistema, no solo un incumplimiento
 individual. 1. Razones para desconfiar del tablero. El esquema intenta atender cuatro pilares, pero
 un bono individual de 0-5 sueldos basado en indicadores corporativos y metas no garantiza que
 cada área tenga influencia, información o recursos para lograrlos. La utilidad pesa 40%, el margen
 20%, la satisfacción 15%, la tecnología 10% y seguridad 15%; las ponderaciones pueden llevar a
 sacrificar calidad, inversión o prevención para proteger rentabilidad. Pagar a todos con igual
 indicador también debilita la línea de visión: una persona no controla la utilidad global ni el
 despliegue de tecnología de otra área. Metas de umbral generan efectos de todo o nada,
 manipulación temporal y concentración justo bajo/encima del corte; cinco salarios variables crean
 fuerte presión y riesgo de gaming. “Más de 10% sobre promedio” o “10% sobre año anterior”
 requiere definir referente, ajuste por ciclo y si es controlable. Las medidas de seguridad usan
 número de accidentes por cada 100 trabajadores, días perdidos y muertes. No ajustan claramente
 por horas de exposición, tarea ni severidad potencial; con baja frecuencia de eventos, una tasa
 anual puede fluctuar mucho. Un bono por pocos accidentes, especialmente cero muertes, puede
 desincentivar reportar lesiones, incidentes y casi accidentes, precisamente la información que
 permite prevenir. La seguridad debe ser un requisito no compensable por ganancias en otros
 pilares, no una ponderación pequeña que se pueda “comprar” con utilidad. Además, no basta un
 tablero: hacen falta responsables, recursos, capacidades, revisión de causas y consecuencias ante
 metas en conflicto. 2. Por qué instrucciones y PPE no bastan. Un instructivo escrito no asegura
 comprensión, competencia, supervisión, práctica, actualización ni que el procedimiento sea viable
 en terreno. Entregar casco, guantes o arnés reduce exposición solo si el equipo es adecuado,
 compatible, está en buen estado, se ajusta correctamente, se inspecciona y existe entrenamiento y
Examen de Grado UC | materia, preguntas y respuestas 234

[pág. 235]
Dirección - versión clara y reordenada
 uso real. Reglas idénticas para 40 contratistas pueden ignorar peligros diferentes, condiciones del
 sitio, coordinación y estándares de subcontratación; el principal no puede limitarse a pedir
 cumplimiento documental. Responsabilidad contractual no equivale a control efectivo del riesgo. La
 seguridad depende de identificar peligros y eliminar/controlar riesgos en la fuente antes de confiar
 en conducta y elementos individuales: diseño seguro de trabajo, bloqueo de energía, protección
 contra caídas, planificación, permisos, competencias, dotación, mantenimiento, supervisión, fatiga,
 coordinación entre equipos y facultad de detener tareas inseguras. Hay que investigar incidentes y
 cuasi accidentes sin castigo por reporte, escuchar a trabajadores propios y contratistas, asignar
 responsables y verificar cierre de acciones. Incentivos exclusivamente retrospectivos por “cero
 accidentes” pueden ocultar señales; conviene combinar resultados con indicadores preventivos
 (inspecciones de calidad, acciones cerradas, entrenamiento demostrado, riesgos críticos
 corregidos), y nunca premiar reportar menos. Recomendación de diseño. Mantendría el tablero
 como herramienta de conversación, no aplicaría un bono uniforme sin pruebas de controlabilidad y
 medición. Traducir cada pilar a pocos objetivos por nivel y función, con metas acordadas, datos
 auditables, umbrales de resguardo y evaluación individual/equipo según influencia. Para
 contratistas, incluir criterios de selección, estándares de competencia, auditorías en terreno,
 coordinación, notificación e investigación de eventos, planes de mejora y consecuencias
 contractuales. Medir incidentes con exposición adecuada y contextualizar tendencias, pero usar
 seguridad como condición fundamental y aprendizaje, no como competencia para ocultar
 accidentes.
 enero 2021 - pregunta 2 - Motivación y sistema de evaluación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 331-332 | convocatoria
 1
 Volver al enunciado original
 1. Dos consideraciones para gestionar las variables del modelo
 Priorizar por beneficio alcanzable, costo y necesidad concreta. La calidad de vida laboral y la
 adecuación del espacio físico tienen las relaciones más altas con satisfacción, 0,33 y 0,31; después
 aparecen el apoyo del líder, 0,13, y el equipamiento y conectividad, 0,11. Con restricciones
 presupuestarias después de 2020, 62 Segundos puede partir por redistribuir cargas, fijar pausas y
 horarios, reducir estrés y desarrollar acompañamiento de jefaturas. Debe ofrecer apoyos
 focalizados para empleados cuyo espacio o conexión impiden trabajar, en vez de comprar el mismo
 equipamiento para todos. Un coeficiente mayor no establece automáticamente la primera inversión:
 también importan cuánto se puede mejorar cada variable, el costo, el nivel inicial y las
 complementariedades. Un espacio adecuado sin conectividad, o equipos sin coordinación, puede
 ser insuficiente.
 Usar el modelo como evidencia parcial, vinculada a los resultados y a la estrategia. El caso
 acepta que el modelo causal es técnicamente correcto, por lo que no corresponde descartarlo por
 una crítica metodológica inventada. Sin embargo, explica 51% de la variación de satisfacción, 21%
 de productividad y 23% de continuidad; quedan otros factores relevantes. Los coeficientes
 satisfacción-productividad, 0,24, y satisfacción-continuidad, 0,48, tampoco hacen equivalentes
 estos resultados. Conviene seguir satisfacción, productividad, calidad de los servicios y continuidad
 separadamente, evaluar intervenciones y complementar el modelo con capacidades y coordinación.
 Para la diferenciación tecnológica y la atención personalizada de largo plazo de 62 Segundos,
Examen de Grado UC | materia, preguntas y respuestas 235

[pág. 236]
Dirección - versión clara y reordenada
 mejorar comodidad debe traducirse en servicio competente, calidad y relaciones sostenibles con
 clientes. Adaptabilidad individual, 0,07, y coordinación, 0,02, pueden requerir desarrollo aunque su
 efecto directo estimado sobre satisfacción sea menor.
 2. Evaluación de la opinión de Policarpo
 Estoy de acuerdo con su advertencia, con una precisión: el estudio es útil, pero satisfacer
 condiciones de trabajo no asegura por sí solo la motivación para realizar esfuerzo y desarrollar las
 capacidades que requiere la diferenciación. Tulio tiene razón en gestionar los factores que
 favorecen satisfacción y continuidad; Policarpo tiene razón en pedir que se analice además la
 motivación. No corresponde atribuirle una opinión sobre motivación intrínseca o afectiva que el texto
 no contiene.
 El apoyo material y una carga razonable reducen obstáculos e insatisfacción. Deben
 complementarse con objetivos entendidos, autonomía y retroalimentación, aprendizaje de
 competencias tecnológicas, reconocimiento y recompensas justas, y sentido de contribución al
 cliente. Esto conecta motivación extrínseca, intrínseca y afectiva con la estrategia. Por ejemplo, un
 líder puede ayudar a resolver sobrecarga y, al mismo tiempo, explicar cómo la calidad de una
 solución sostiene la relación personalizada de largo plazo. La productividad requiere esfuerzo,
 capacidades y oportunidad real de utilizarlas: ni satisfacción aislada ni exigencia sin condiciones
 suficientes garantizan el desempeño. Por ello, conservaría las cinco variables de gestión
 propuestas por Tulio y añadiría medición y acciones de motivación, aprendizaje y desempeño
 estratégico.
 enero 2022 - pregunta 2 - Perfil y entrevista estructurada
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 356-357 | convocatoria
 1
 Volver al enunciado original
 a) Tres dimensiones del perfil. Definiría atributos observables, ligados al trabajo y a la estrategia,
 evitando “encaje cultural” entendido como parecido personal. 1. Competencia técnica y seguridad
 demostrables: cuidados básicos, signos vitales, bioseguridad, manejo de material y límites de
 actuación. El caso reporta que 40% declara capacidades que después no demuestra; se deben
 validar con ejercicios y credenciales, no confiar en el currículum. 2. Cuidado centrado en el paciente
 y comunicación: escucha, respeto, empatía, confidencialidad, manejo sereno de situaciones difíciles
 y explicación comprensible. La experiencia del paciente depende de múltiples contactos, incluidos
 los TENS. 3. Colaboración interdisciplinaria y aprendizaje/adaptabilidad: coordinarse con médicos,
 enfermeras y apoyo, compartir información, pedir ayuda ante riesgo y aprender
 tecnología/procedimientos nuevos. Añadir una evaluación realista de expectativas del turno, carga,
 exposición emocional, trayectoria y condiciones del cargo para reducir salidas por desajuste. No
 usar simpatía, edad o “vocación” como sustitutos de evidencia. La selección puede elevar ajuste y
 desempeño, pero no resolverá por sí sola la rotación: la frustración por falta de contribución y las
 remuneraciones externas requieren rediseño de trabajo, desarrollo, reconocimiento y condiciones.
 b) Proceso estructurado y secuencial. 1. Análisis del cargo y resultados: observar turnos y servicios;
 consultar TENS, pacientes, jefaturas y equipos; identificar tareas críticas, riesgos, estándares,
 competencias y razones de salida. Definir requisitos imprescindibles y entrenables. 2. Perfil, rúbrica
 y plan de medición: fijar competencias, niveles conductuales, pesos, umbrales mínimos y
 evidencias antes de abrir vacante; seleccionar instrumentos pertinentes, accesibles y consistentes
Examen de Grado UC | materia, preguntas y respuestas 236

[pág. 237]
Dirección - versión clara y reordenada
 para todos. 3. Postulación y filtro objetivo: recibir antecedentes con formato uniforme; verificar
 título/licencia y requisitos mínimos; revisar brechas o datos de manera proporcionada y proteger
 información personal. No rankear por prestigio curricular si no predice el cargo. 4. Prueba
 técnica/work sample: mediante simulación segura, evaluar cuidado básico, bioseguridad, lectura de
 instrucción, signos vitales o respuesta ante un riesgo; usar pauta y evaluadores entrenados. No
 exponer pacientes reales ni sustituir trabajo remunerado. 5. Evaluación de juicio y equipo: caso
 situacional y entrevista estructurada que mida comunicación, confidencialidad, coordinación y
 escalamiento de dudas. Si se usa prueba cognitiva, demostrar pertinencia al cargo y no excluir por
 formatos innecesarios. 6. Entrevista panel y verificación: jefatura de unidad y RR.HH. hacen
 preguntas iguales, registran evidencia por competencia y puntúan por separado antes de deliberar.
 Verifican referencias/credenciales con autorización y criterios uniformes. 7. Decisión documentada y
 oferta realista: combinar resultados según regla predefinida; documentar excepciones y razones.
 Explicar funciones, horarios, exigencias, oportunidades y remuneración; permitir preguntas y
 confirmar expectativas antes de aceptar. 8. Onboarding y evaluación posterior: inducción al servicio,
 mentoría, supervisión y metas de aprendizaje; revisar a 30/90 días desempeño, experiencia,
 integración y causas de salida. Auditar validez del proceso: desempeño seguro, evaluación de
 pares, incidentes, retención y diferencias entre grupos. c) Dos mejoras concretas a las entrevistas
 de jefaturas. Primero, reemplazar libertad de entrevista por una pauta estructurada: mismas
 preguntas conductuales y situacionales, orden y tiempo comparables, basadas en incidentes
 críticos del cargo y con anclas de respuesta esperada; entrenar a jefaturas para preguntar evidencia
 concreta y evitar preguntas no laborales. Segundo, usar escala de puntuación anclada por
 competencia, tomar notas de ejemplos verificables y calificar individualmente antes de discutir en
 panel; separar simpatía general de evidencia, calibrar evaluadores y revisar discrepancias y
 sesgos. Esto aumenta consistencia y reduce halo/confirmación, aunque no elimina error ni
 compensa un proceso que mida criterios irrelevantes.
 enero 2015 - pregunta 2 - Reforma laboral y alineamiento
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 162-163 | convocatoria
 1
 Volver al enunciado original
 Alcance del análisis. Interpreto las cuatro reglas laborales y la excepción de acuerdos colectivos
 exactamente como las formula el caso de 2015; no las presento como descripción de la ley actual.
 La pregunta evalúa ajuste entre estrategia, organización del trabajo y gestión de personas bajo
 nuevas restricciones. 1. Efectos estratégicos y comparación. Los efectos no son iguales. Durazno
 compite por costo, integra la cadena y opera con áreas autónomas, poca coordinación,
 subcontratación de cosecha/procesamiento, dotación estacional y liderazgo autoritario. La
 prohibición de subcontratar labores del giro principal puede elevar costos fijos y exigir internalizar
 funciones, cambiando su ventaja de costos; requiere aclarar con asesoría jurídica qué actividades
 son giro principal. La regla de ocho meses en doce limita el despido y recontratación estacional:
 Durazno despide entre julio y septiembre y vuelve a contratar en octubre, de modo que la secuencia
 habitual puede durar nueve meses y superar el umbral. Debe regularizar las relaciones que lo
 superen y planificar su costo, en vez de asumir que siempre conserva contratos por temporada o
 fragmentar artificialmente faenas. La restricción de funciones limita la flexibilidad entre etapas y la
 cobertura de picos, mientras la prohibición de reemplazo durante huelga hace más costoso
 sostener una política de conflicto y debilita la estrategia de evitar sindicatos con alzas salariales
Examen de Grado UC | materia, preguntas y respuestas 237

[pág. 238]
Dirección - versión clara y reordenada
 puntuales. La posibilidad de acordar flexibilidad con sindicato representativo de más de 65% abre
 una vía negociada: Durazno hoy carece de la relación colaborativa y legitimidad necesarias.
 Frambuesa diferencia por calidad, usa equipos polifuncionales y mejora continua, mantiene
 comunicación y colaboración sindical, y sostiene actividad fuera de la cosecha con mantención y
 procesamiento de fruta de invierno. La limitación de funciones específicas puede chocar
 directamente con la polifuncionalidad; un acuerdo bajo la excepción prevista permitiría conservarla
 si se cumplen sus condiciones y hay consentimiento colectivo auténtico. La regla de 8/12 puede
 convertir en indefinidos contratos de personas que enlazan faenas de temporada y actividad de
 invierno, pero su ocupación continua en meses de baja demanda ya agrega valor en procesamiento
 y mantención, de modo que el efecto puede ser menos adverso o incluso estabilizar capacidades.
 El cambio en subcontratación puede afectar según qué tareas Frambuesa externalice; el caso no
 informa suficientemente para afirmar impacto concreto. El veto al reemplazo también eleva el riesgo
 de interrupción, aunque una relación de colaboración puede ayudar a prevenir y resolver conflictos,
 sin eliminarlos. La disposición al acuerdo es una oportunidad comparativamente mayor porque el
 sindicato representa 70% del personal descrito, pero debe verificarse el umbral de más de 65% que
 exige el caso para la empresa y el ámbito del acuerdo. 2. Tres acciones concretas para Durazno. 1.
 Rediseñar make-or-buy y dotación estacional con legalidad y costo total. Mapear qué actividades
 forman parte del giro principal, identificar labores hoy subcontratadas, y construir escenarios de
 internalización, contratos con proveedores para actividades legalmente permitidas, automatización
 y programación de capacidad. Proyectar demanda por variedad y calendario, distinguir faenas y
 contratos, y presupuestar obligaciones de continuidad sin fragmentar artificialmente el empleo.
 Mantener la meta de bajo costo mediante productividad por hora, rendimiento, merma y calidad
 exportable. 2. Negociar un acuerdo de organización del trabajo y continuidad. Reparar la relación
 laboral con diálogo regular, representación legítima y acceso transparente a información
 operacional. Si se alcanza la representatividad exigida, negociar formalmente diversidad funcional,
 horarios y tareas conforme a la excepción del caso; acordar capacitación, seguridad, movilidad,
 compensación y mecanismos de resolución de controversias. No sustituir diálogo por pagos
 reactivos ni asumir que un acuerdo puede eliminar garantías legales. 3. Instalar coordinación y
 gestión participativa de productividad. Crear equipos interárea para cosecha, planta y exportación;
 fijar estándares compartidos de calidad, tiempos y mermas y mecanismos para que trabajadores
 aporten mejoras. Entrenar en roles permitidos, planificar temporadas y desarrollar una dotación
 núcleo para conocimiento crítico. Esto reduce costos de fallas en interfaces y prepara a Durazno
 para restricciones de flexibilidad y de reemplazo. Tres acciones concretas para Frambuesa. 1.
 Formalizar el acuerdo que proteja la polifuncionalidad estratégica. Con el sindicato y bajo el umbral
 colectivo aplicable en el caso, negociar funciones diversas, movilidad entre faenas, horarios y
 temporadas con límites de seguridad, competencia, cargas y compensación. Incorporar a
 trabajadores jóvenes y no sindicalizados en consulta y comunicación para que la colaboración no
 represente solo a personal antiguo. 2. Planificar empleo continuo y desarrollo de capacidades.
 Modelar necesidades entre octubre-abril y mayo-septiembre, proyectar qué trabajadores podrían
 superar ocho meses de servicios en doce y regularizar contratos conforme a la regla del caso.
 Diseñar formación cruzada y certificación para calidad, análisis de procesos, seguridad, mantención
 y procesamiento de fruta de invierno; aprovechar la continuidad para retener experiencia y reducir
 curva de aprendizaje, sin prometer empleo que la demanda no sostenga. 3. Integrar cumplimiento
 legal, participación y prevención de conflictos. Auditar funciones, contratos, subcontratistas y
 seguridad; corregir cualquier tarea incompatible y asegurar consulta temprana sobre cambios.
 Fortalecer equipos con canales de mejora, indicadores compartidos de calidad y productividad, y un
Examen de Grado UC | materia, preguntas y respuestas 238

[pág. 239]
Dirección - versión clara y reordenada
 procedimiento de negociación y continuidad operacional ante conflicto que respete la prohibición de
 reemplazo. La participación debe influir decisiones y repartir beneficios de productividad, no ser solo
 comunicación. Conclusión y límites. Durazno afronta mayor rediseño porque varias prácticas
 actuales -outsourcing de procesos centrales, fragmentación estacional, bajo diálogo y poca
 coordinación- chocan con las reglas y con la resiliencia necesaria. Frambuesa tiene mejor base
 relacional y una actividad anual más continua, pero su polifuncionalidad requiere formalizarse
 mediante la vía colectiva prevista y su dotación debe adaptarse a la regla de continuidad. No es
 posible cuantificar costos ni establecer qué funciones integran jurídicamente el giro de cada
 empresa sin datos operacionales y análisis legal específico.
 agosto 2020 - pregunta 3 - Remuneración, selección y equidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 320-321 | convocatoria
 2
 Volver al enunciado original
 1. Razones de los dos votos de minoría
 El consejero que considera insuficiente bajar 25% puede priorizar equidad externa y costo
 sostenible. El gráfico ajustado por PPA muestra que las remuneraciones de parlamentarios
 chilenos son muy superiores al promedio de países, mientras los requisitos formales son edad y
 enseñanza media y las carreras suelen ser prolongadas. La alta permanencia no sugiere una
 dificultad general para atraer candidatos al sueldo anterior. En la crisis, reducir más puede liberar
 recursos y mejorar percepción de justicia frente a la ciudadanía, cuya confianza es de apenas 3%.
 Esto no demuestra qué porcentaje exacto es óptimo ni que recortar sueldo corrija corrupción, pero
 fundamenta por qué 25% puede parecer insuficiente.
 El consejero que propone aumentar puede priorizar atracción de personas capaces y costo de
 oportunidad, dado el valor social y la responsabilidad de legislar. Una remuneración mayor podría
 ampliar el conjunto de candidatos, incluidos profesionales con buenas alternativas externas, y
 reducir dependencia económica de intereses particulares; es una hipótesis sobre selección y
 autonomía. Sin embargo, solo pagar más no mejora competencias ni probidad. El caso ya muestra
 paga internacionalmente elevada y baja confianza; la propuesta requiere evidencia de candidatos
 excluidos por costo de oportunidad y mecanismos de selección, rendición de cuentas y control que
 conviertan el pago en desempeño público.
 Ambos votos pueden apoyarse en funciones legítimas de las remuneraciones, pero asignan pesos
 distintos a equidad y restricción fiscal frente a atracción y desempeño. La evaluación correcta
 compara cargos y mercados pertinentes, remuneración total y efectos probables, no asume que
 más o menos dinero siempre mejora resultados.
 2. Objeción del parlamentario por rango
 No es correcta como criterio suficiente. La jerarquía política no equivale al valor relativo del cargo
 para un sistema de remuneraciones. Los Directivos y Jefaturas deben tener título, experiencia de al
 menos cinco años, inglés y competencias estratégicas y de servicio público; algunas especialidades
 exigen posgrado. Sus funciones técnicas y la movilidad al sector privado hacen pertinente
 compararlos con profesionales privados de perfil comparable.
 El segundo gráfico muestra remuneraciones públicas inferiores a las privadas: aproximadamente
 $3,3 frente a $5,1 millones para jefaturas y $4,5 frente a $7 millones para directivos, por lectura de
Examen de Grado UC | materia, preguntas y respuestas 239

[pág. 240]
Dirección - versión clara y reordenada
 barras. Recortarlas por mantener una pirámide política puede dificultar atraer y retener capacidad
 precisamente cuando se exige excelencia y eficiencia sin margen de error. Es posible que un
 especialista cobre más que una autoridad electa sin que eso sea incoherente: la equidad interna
 considera complejidad, responsabilidad, capacidades y contribución, y la externa considera
 alternativas reales. Estos montos son aproximados; no son etiquetas exactas impresas.
 enero 2023 - pregunta 2 - Rotación y AMO
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 379-380 | convocatoria
 1
 Volver al enunciado original
 Qué pregunta realmente. SecurMax escaló rápidamente y pasó de gestión personal de 15 salas por
 una sola encargada a crecimiento con alta rotación, nuevos clientes y vigilancia remota. Debo
 explicar cómo el sistema de trabajo puede haber perdido ajuste y recomendar tres acciones que
 retengan competencias y sostengan confiabilidad y servicio. El caso muestra asociación entre
 expansión, tecnología y rotación cercana a 50%; no entrega entrevistas de salida que permitan
 declarar una causa única. a) Tres déficits con mecanismos. 1. Planificación y selección que no
 escalan con el crecimiento. El proveedor externo entrega currículos y referencias salariales; el
 equipo filtra según experiencia y Julieta entrevista a todos con criterio personal sobre honestidad,
 empatía y servicio. Esa práctica pudo funcionar a pequeña escala, pero al crecer deja poca
 estandarización, validación de habilidades críticas, evaluación de trabajo en equipo y capacidad
 para contratar al ritmo de nuevas salas. Seleccionar por criterios generales sin definir escenarios
 del cargo puede generar desajuste y salidas tempranas. No se informa que esta sea la causa
 comprobada del 50%: es una brecha de sistema a validar. 2. Onboarding y desarrollo insuficientes
 para un trabajo exigente y tecnológico. Una inducción de un día se concentra en valores y
 reconocimiento del local; luego se espera rendimiento inmediato. No se describen práctica
 supervisada, respuesta a conflictos, protocolos de prevención, coordinación con empleados del
 supermercado, uso de video/aplicación ni apoyo ante incidentes violentos. La tecnología puede
 ayudar a detección y protección, pero también se puede vivir como vigilancia, amenaza a la
 autonomía o fuente de incertidumbre si no se enseña ni se incorpora al rol. Sin entrenamiento,
 feedback y apoyo, aumenta estrés, errores y frustración. 3. Diseño de turnos/equipos y retención
 que dañan continuidad. Reasignar a todo equipo cada seis meses con solo una semana de aviso
 rompe rutinas, relaciones de equipo, conocimiento de la sala y vínculos con clientes y empleados.
 El objetivo anti-conflicto es legítimo, pero una rotación abrupta y generalizada puede transmitir
 desconfianza y empeorar vida personal. La propuesta salarial es sueldo fijo promedio de mercado
 más una semana adicional de vacaciones; no hay carrera, incentivos por calidad/antirrobo ni
 reconocimiento descritos. El crecimiento aumenta carga de jefaturas y puede debilitar supervisión.
 En conjunto esto resta atractivo frente a exigencias del cargo y a alternativas laborales. b) Tres
 acciones de mejora. 1. Profesionalizar selección y planificación de dotación. Hacer análisis de
 tareas con guardias, clientes y supervisores; definir competencias técnicas y conductuales por tipo
 de sala (observación, juicio, comunicación, autocontrol, ética y respuesta segura). Usar filtro
 estructurado de requisitos, verificación proporcional de credenciales/referencias, prueba situacional
 y entrevista con pautas/anclas; entregar una descripción realista de turnos, riesgos, interacción y
 traslado. Dimensionar reclutamiento por salas/horarios y crear una reserva de candidatos para no
 acelerar contrataciones sin capacidad de evaluación. 2. Implantar onboarding, formación y apoyo
 progresivo. Incorporar práctica supervisada y certificación en prevención de pérdidas,
Examen de Grado UC | materia, preguntas y respuestas 240

[pág. 241]
Dirección - versión clara y reordenada
 desescalamiento, atención, protocolos de seguridad, privacidad, coordinación con el supermercado
 y uso de cámaras/aplicación; acompañar al nuevo guardia durante sus primeros turnos, con mentor
 y feedback. Incluir a guardias en el diseño del uso de monitoreo, aclarar qué decisiones pueden
 tomar y cómo la tecnología complementa el criterio humano. Revisar incidentes, carga y salud
 psicosocial, y formar jefes para coaching y apoyo. 3. Rediseñar continuidad, participación y
 recompensa. Mantener equipos en una sala el tiempo necesario para dominar rutinas y construir
 coordinación; usar rotación basada en riesgo y controles específicos, con calendario anticipado,
 transición ordenada y excepciones por necesidad personal. Ofrecer reconocimiento y progresión de
 guardia a especialista/jefe, además de compensación total revisada por turnos y riesgo; cualquier
 variable debe equilibrar prevención, reportabilidad, calidad de trato y satisfacción del cliente, sin
 premiar solo “cero robos” que pueda inducir ocultamiento. Abrir canales para problemas y
 decisiones de terreno. Esto mejora pertenencia, previsibilidad y conocimiento del cliente. Medición.
 Segmentar rotación por sala, jefe, antigüedad, turno, tipo de cliente y etapa de incorporación;
 entrevistar a salientes y actuales, registrar motivos sin presuponerlos. Medir cobertura de vacantes,
 abandono antes de 90 días, retención de equipos, accidentes/incidentes, robos ajustados por
 exposición, satisfacción del cliente y empleados, uso/certificación tecnológica. Pilotear acciones en
 salas comparables y separar efecto de expansión, condiciones de trabajo y supervisión.
 agosto 2018 - pregunta 2 - Selección y ajuste
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 268-269 | convocatoria
 2
 Volver al enunciado original
 Canales debe priorizar (1) capacidad para asumir el trabajo crítico y continuidad con clientes:
 análisis financiero, manejo de varias industrias/proyectos, calidad de entregables y capacidad de
 construir confianza; (2) competencias de colaboración, planificación, orden y manejo de presión,
 porque el rol coordina clientes, socios y equipo y hay margen bajo; (3) ajuste de expectativas,
 motivación, aprendizaje y riesgo de retención dentro de un mercado donde suben remuneraciones.
 No ordenaría por salario actual ni por “estrella”; el dato de que Terrazas deja clientes sin ejecutivo
 muestra costo urgente de cobertura y transferencia de conocimiento.
 Elegiría a Sonia Orrego como alternativa preferente si, como indica la información de candidatos,
 satisface requisitos técnicos esenciales y su expectativa ($5,5 millones) se alinea mejor con el
 presupuesto y la retención. El diferencial frente a su sueldo actual ($5,1) es menor que en otras
 candidaturas; pero no es “la más barata” por sí solo: verificar referencias, experiencia transferible,
 capacidad de asumir cuentas, desempeño en muestra de trabajo y compatibilidad de expectativas.
 Si falta experiencia crítica, diseñar onboarding/mentoría y una transición de cartera con Pedro y
 otros analistas. Evitar usar familia/estatus o estereotipos para definir ciclo de vida; preguntar
 disponibilidad y motivación laboralmente pertinente.
 La oferta debe explicar responsabilidad, carga, carrera, equipo y remuneración total, y resolver
 riesgo de contrapropuesta. Un plan de retención y sucesión para clientes reduce dependencia de
 una estrella; distribuir relaciones con respaldo y documentar conocimiento. Una oferta alta a una
 persona puede generar inequidad interna, mientras pagar bajo mercado puede perderla en poco
 tiempo.
Examen de Grado UC | materia, preguntas y respuestas 241

[pág. 242]
Dirección - versión clara y reordenada
 marzo 2011 - pregunta 4 - Selección, cultura y retención
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 64-65 | convocatoria 1
 Volver al enunciado original
 1. Posición ante Dolly y Adénico
 Apoyo principalmente a Adénico: hay que adaptar las prácticas de atracción, motivación y desarrollo
 a las personas que se pretende incorporar. La empresa ofrece cargos rígidos, estructura funcional,
 liderazgo centrado en control de metas, sueldo fijo y carrera dependiente de antigüedad; esto puede
 frustrar necesidades de desafío, desarrollo, reconocimiento y contribución descritas para los nuevos
 empleados. Dolly acierta al preservar proactividad y servicio al cliente, pero volver al perfil histórico
 de contratación no corrige esas prácticas. Tampoco adoptaría una cultura solo para agradar a una
 generación: conservaría la diferenciación por servicio y modificaría la forma de hacerla posible,
 verificando necesidades individuales sin convertir las edades en estereotipos.
 2. Tres acciones prioritarias
 1. Selección y socialización por competencias de servicio. Definir escucha, resolución,
 proactividad, colaboración y aprendizaje; comprobarlas con entrevistas estructuradas y
 simulaciones. Integrar a las nuevas personas con mentoría y experiencias con clientes que
 transmitan el propósito de Genoma. Esto recoge la preocupación válida de Dolly sin asumir que los
 jóvenes carecen de vocación. 2. Desarrollo, autonomía y carrera por contribución. Dar desafíos,
 formación, rotación y proyectos con responsabilidades progresivas; reemplazar la antigüedad como
 único acceso a carrera por competencias y resultados demostrados. Entrenar a las jefaturas para
 retroalimentación y coaching. Así se satisfacen aprendizaje y reconocimiento y se habilita una
 respuesta más proactiva al cliente. 3. Cooperación e incentivos alineados al servicio. Crear
 objetivos y equipos interfuncionales para resolver requerimientos; reconocer calidad, colaboración e
 innovación útil además de resultados individuales. Conectar el trabajo con su impacto en clientes y
 dar reconocimiento frecuente y diferenciado por aportes. Esto corrige los silos y el énfasis exclusivo
 en claridad de metas y remuneración fija. Mediría reclamos, satisfacción, solución efectiva,
 aprendizaje y rotación no deseada para ajustar las tres acciones.
 enero 2019 - pregunta 2 - Servicio, AMO y cultura
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 281-282 | convocatoria
 1
 Volver al enunciado original
 El testimonio compara dos experiencias: Chilezon incorpora logística/tecnología, pero el cliente no
 recibe respuesta informada del envío; Superzon resuelve consulta con cordialidad, precisión y
 seguridad. El desafío “más profundo” es capacidades y sistema de gestión: anticipar problemas,
 poner al cliente en el centro, dar autonomía dentro de estándares y coordinar información entre
 pedidos, bodega, despacho y servicio. Invertir en una plataforma no convierte por sí sola a la
 empresa en un operador de comercio electrónico competente.
 Modificaría tres prácticas. (1) Selección y socialización: contratar por escucha, solución de
 problemas, comunicación y aprendizaje, con entrevistas estructuradas y simulación de un
 requerimiento; explicar realisticamente turnos y trabajo. (2) Capacitación/desarrollo: formar en
 sistemas, productos, trazabilidad y conversaciones difíciles, con práctica y coaching en puesto;
 comprobar transferencia en precisión, tiempo y resolución. (3) Desempeño, liderazgo y diseño:
Examen de Grado UC | materia, preguntas y respuestas 242

[pág. 243]
Dirección - versión clara y reordenada
 medir resolución y calidad, no solo apego a protocolo o velocidad; entregar al agente acceso a
 estado del pedido y autoridad para resolver/escalar, con reglas claras, cooperación con logística y
 feedback. Alinear incentivos y reconocimiento con solución confiable, privacidad y colaboración, no
 con cerrar llamadas.
 El mecanismo es que personas con habilidad, motivación y oportunidad convierten la tecnología en
 experiencia: reciben señal del cliente, acceden a información correcta, deciden dentro de límites y
 corrigen causas. La gestión debe rastrear reclamos repetidos hasta inventario/despacho. Medir
 resolución al primer contacto, errores, reclamos, tiempos, satisfacción, ausentismo y rotación;
 pilotear antes de escalar.
 enero 2018 - pregunta 2 - Sistema AMO y contrato
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 255-257 | convocatoria
 1
 Volver al enunciado original
 a. Mapa de relaciones laborales y propuesta de Secco
 El mapa tiene dos ejes. En el eje de relación, un extremo es confrontación o conflicto y el otro
 convergencia, confianza y cooperación. En el eje de agenda, un extremo es unidimensional,
 concentrado en remuneraciones y problemas inmediatos, y el otro es multidimensional, que
 incorpora estrategia, productividad, calidad, tecnología y el futuro de la empresa y del empleo.
 Estos ejes permiten distinguir cuatro situaciones: conflicto con agenda inmediata; conflicto con
 agenda amplia; cooperación limitada a asuntos inmediatos; y cooperación con agenda estratégica
 amplia.
 CasiFuimos se aproxima al primer cuadrante: la relación está distanciada y la discusión se
 concentra en condiciones y remuneraciones, aunque 85% de los trabajadores está sindicalizado y
 existe una contraparte representativa con la que se puede construir una agenda común. Las
 reuniones periódicas y una mayor cercanía que propone Secco pueden mover a la empresa hacia
 mayor cooperación. Son un comienzo adecuado, pero no bastan para llegar al cuadrante de
 mayor convergencia y agenda multidimensional. Deben incluir información compartida y
 espacios para tratar productividad, coordinación, tecnología, capacitación, calidad y sostenibilidad
 de los puestos, con acuerdos, responsables y seguimiento. La cercanía sin contenido estratégico
 deja la relación en una agenda estrecha.
 b. Evaluación de reconstruir todo el contrato psicológico
 Dédalo identifica un problema real, pero no es necesario desechar todas las prácticas. En
 seguridad, CasiFuimos registra 2,5 accidentes por cada 100 trabajadores frente a 3,6 del sector; en
 liderazgo exigente, participativo y orientado al desarrollo alcanza 31,6% frente a 13,9%. Estas son
 bases favorables que deben conservarse y extenderse. Un contrato psicológico se reconstruye
 cumpliendo promesas y expectativas recíprocas, no solo anunciando una nueva política.
 Sí se requiere una corrección importante. El pago total promedio, $750.000, es inferior a $840.000
 del sector; los bonos equivalen a 1,9 sueldos frente a 4 y la brecha entre ejecutivos y trabajadores
 es 14 veces frente a 12. Esto puede debilitar la percepción de equidad y la motivación extrínseca.
 La claridad sobre el impacto del cargo es 26,1% frente a 42,3%; la coordinación entre áreas, 9,7%
 frente a 65%; las sugerencias implementadas son 0,4 por trabajador frente a 7. Estos datos
 muestran brechas de sentido, autonomía efectiva, participación y capacidad de contribuir,
Examen de Grado UC | materia, preguntas y respuestas 243

[pág. 244]
Dirección - versión clara y reordenada
 relevantes para motivación intrínseca y afectiva. Propondría aclarar contribuciones y objetivos,
 mejorar coordinación y respuesta a sugerencias, revisar la estructura de remuneraciones y acordar
 expectativas realistas con los representantes. Los indicadores orientan una intervención focalizada;
 no prueban que todos los componentes del contrato sean malos.
 c. Gestión de indicadores y relaciones laborales
 La gestión sistemática que propone Verbal puede mejorar las relaciones si los indicadores
 conducen a cambios verificables en las prácticas que generan desconfianza. Las brechas ofrecen
 una agenda concreta: seguridad y liderazgo como fortalezas; equidad de remuneraciones, claridad
 de contribución, coordinación y participación como prioridades. Es útil fijar metas, responsables,
 plazos y rendir cuentas con trabajadores y dirigentes.
 Sin embargo, mejorar cifras no reemplaza el diálogo. Hay que compartir su interpretación, escuchar
 problemas que los promedios ocultan y negociar compromisos sostenibles. La alta sindicalización
 hace especialmente pertinente una relación institucional con la organización sindical. Vincular las
 mejoras internas con calidad, productividad y futuro del negocio amplía la agenda del mapa:
 combina cooperación en la relación con contenido estratégico. Así, las propuestas de Secco y
 Verbal son complementarias cuando la cercanía, la información y la gestión producen compromisos
 y mejoras reales.
 agosto 2014 - pregunta 2 - Sistema completo de RR.HH.
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 151-152 | convocatoria
 2
 Volver al enunciado original
 Qué pregunta realmente. Debo diagnosticar tres fallas principales del diseño de capacitación y
 compensación y proponer tres cambios que reconstruyan capacidades para una estrategia de
 variedad con calidad. La caída de ventas no se atribuye automáticamente a RR.HH. ni a demanda:
 los datos de clientes sobre menor variedad y calidad coinciden con una hipótesis interna que debe
 probarse. Tres problemas principales. 1. Promoción sin análisis de cargo, ajuste ni aceptación. Se
 eligió a panaderos por antigüedad y conocimiento del producto, pero ser buen productor no
 demuestra habilidad o deseo de enseñar, supervisar y crear productos. Los jefes fueron retirados
 de producción, se les impusieron responsabilidades nuevas y algunos no las querían. El título y el
 aumento no resolvieron legitimidad, tiempo, autoridad ni competencias para dirigir a otros. 2.
 Capacitación informal e incompleta. “Mostrar la receta y supervisar” no especifica estándares,
 secuencia didáctica, práctica guiada, evaluación de dominio, retroalimentación o actualización. Las
 quejas de tardanzas y falta de obediencia apuntan a problemas de autoridad, diseño del trabajo y
 compromiso, no solo a desconocimiento de recetas. El modelo escala conocimiento tácito, pero sin
 convertirlo en procedimientos reproducibles puede diluir calidad al crecer a 50 locales. 3.
 Compensación e incentivo mal alineados y sin gestión del desempeño. Duplicar salario fijo
 únicamente por asumir el cargo genera costo permanente sin evidenciar contribución o
 competencias; decir que luego puede subir o bajar según los “números” añade incertidumbre, no
 criterios controlables. No hay objetivos, evaluación ni feedback. Pagar por cada producto nuevo
 premia cantidad y novedad, aunque el producto no venda, reduzca margen, complique operaciones
 o degrade calidad; además confunde creación con innovación que el cliente valore. La explicación
 de Matta sobre demanda no considera evidencia contraria de encuestas y variedad percibida. Tres
 recomendaciones. 1. Rediseñar el puesto y seleccionar a los instructores con ajuste y
Examen de Grado UC | materia, preguntas y respuestas 244

[pág. 245]
Dirección - versión clara y reordenada
 consentimiento. Analizar tareas y resultados: producir, enseñar, verificar estándares y desarrollar
 variedad viable. Definir tiempo protegido, autoridad, carga, competencias pedagógicas y trayectoria
 dual para que un excelente panadero pueda crecer sin ser obligado a dejar la actividad que prefiere.
 Invitar postulaciones, evaluar interés y enseñar con una demostración y retroalimentación; ofrecer
 alternativa para volver a producción cuando el ajuste no funcione. El nombramiento debe ser
 transparente y no basarse solo en antigüedad. 2. Institucionalizar formación de formadores y control
 de calidad. Convertir recetas y conocimiento de los panaderos expertos en estándares prácticos
 con tolerancias y razones críticas; entrenar a jefes en demostración, práctica del aprendiz,
 observación, corrección respetuosa y evaluación de competencia. Certificar antes de que alguien
 enseñe solo, usar listas de verificación, calibraciones entre locales y sesiones de refresco. Para
 innovar, probar recetas en lotes piloto y validar sabor, consistencia, seguridad alimentaria,
 factibilidad, costo y aceptación antes de desplegar. Conservar conocimiento tácito mediante
 mentoría, no reemplazarlo por manuales mecánicos. 3. Vincular remuneración, feedback y
 desempeño con resultados balanceados. Mantener una prima fija por responsabilidades claramente
 superiores, dimensionada con análisis de cargo y equidad interna; agregar reconocimiento o
 variable moderado por objetivos controlables de equipo: calidad y consistencia, amplitud de
 productos efectivamente disponibles, satisfacción, margen/merma y desarrollo certificado de
 panaderos. Fijar metas y pesos previamente, revisar periódicamente con datos confiables y
 entregar feedback/coaching. No premiar el conteo de recetas creadas; remunerar innovaciones solo
 tras superar pruebas de calidad, demanda y rentabilidad. Usar indicadores de resguardo para evitar
 que una meta de costo provoque deterioro de insumos o seguridad. Aplicación y evaluación.
 Diagnosticar primero qué locales, productos y turnos muestran menor calidad/variedad; contrastar
 encuestas con ventas por SKU, quiebres, devoluciones, mermas, auditorías y observación del
 proceso. Pilotear el nuevo sistema en locales comparables y revisar línea base, tendencias y
 estacionalidad antes de escalar. La demanda deprimida puede influir en ventas, pero no explica por
 sí sola la percepción de producto mediocre ni demuestra que el plan de personas haya causado
 todo el descenso.
 agosto 2019 - pregunta 2 - Transformación digital y RR.HH.
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 292-293 | convocatoria
 2
 Volver al enunciado original
 La agencia Eclipse requiere que sus equipos integren creatividad, cuentas/cliente, estrategia y
 ejecución digital para ofrecer una solución coherente. Tres intervenciones: (1) capacidad y
 coordinación: capacitación aplicada en planificación interfuncional, datos/redes sociales y traspaso
 entre roles, con proyectos reales y retroalimentación; así “saber” trabajar de modo integrado. (2)
 gestión del desempeño e incentivos: metas compartidas de resultado de cliente y calidad de
 colaboración, además de contribución individual; incluir métricas de proceso (brief compartido,
 tiempos/errores de traspaso) y resultados (retención, respuesta, efectividad) para que la
 cooperación no quede sin recompensa. (3) selección y cultura: contratar por capacidad digital,
 colaboración y criterio creativo con muestras de trabajo; socializar expectativas y reconocer
 conductas coherentes. La edad no es una competencia y no debe usarse como sustituto de
 capacidad digital; evalúa habilidades, no demografía.
 La cultura cambia cuando la conducta premiada, los recursos y el liderazgo cambian. Los directivos
 deben modelar planificación transversal, resolver rivalidades de presupuesto y dar
Examen de Grado UC | materia, preguntas y respuestas 245

[pág. 246]
Dirección - versión clara y reordenada
 tiempo/herramientas para aprender. Un taller aislado no corregirá metas que enfrentan a las áreas.
 Piloto por cuentas o equipos; mide calidad de campaña, tiempos, satisfacción/retención,
 colaboración, retrabajo y desarrollo de capacidades. No supongas que “más jóvenes” garantiza
 innovación.
 Dirección de Empresas y Estrategia
 agosto 2021 - pregunta 1 - Adquisición y diversificación relacionada
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 341-342 | convocatoria
 2
 Volver al enunciado original
 a. Tres fortalecimientos corporativos
 Sí, la compra puede fortalecer el modelo corporativo. 1. Portafolio y mercados complementarios:
 Tiffany amplía joyería sofisticada y relojes; sus 90 tiendas asiáticas y posición regional
 complementan la oferta de LVMH. 2. Producción, tecnología y trazabilidad: Tiffany controla
 origen y ruta de diamantes desde 1982; permite aprender e integrar capacidades que LVMH no
 tiene desarrolladas y responder a demandas de derechos humanos y sostenibilidad. 3. Canales y
 experiencia: Tiffany aporta comercio online, 15% de sus ventas, y una red de 321 tiendas en 20
 países. Puede contribuir al crecimiento digital de LVMH y combinarlo con distribución y gestión de
 marcas, manteniendo el control de la experiencia propia de cada marca.
 La ventaja corporativa procede de que el grupo transfiera y comparta esas capacidades de modo
 que cada negocio sea más valioso que por separado, no solo de agregar una marca reconocida.
 b. Decisión, dos argumentos y dos riesgos
 Recomendaría mantener la compra, condicionada a que el precio y financiación permitan
 capturar las sinergias netas. Primer argumento: el encaje de producto y Asia crea oportunidades
 específicas de crecimiento y complementa negocios donde Tiffany ya posee marca y capacidad.
 Segundo: trazabilidad y producción responden a una carencia urgente de LVMH, mientras canal
 digital ayuda a adaptarse a restricciones de movilidad. La subida de 30% de Tiffany refleja
 expectativas o prima para su accionista, pero no prueba que US$14.500 millones sea un precio
 conveniente para el comprador.
 Los dos riesgos principales son: 1. Sobrepago y presión financiera ante demanda incierta. La
 industria cae 40%, turismo se frena y las materias primas subirían en 2021; incluso LVMH registra
 caída importante de resultados. Evaluar escenarios de demanda, ahorro, caja y precio y preparar
 una integración gradual y financiación suficiente. 2. Integración que destruya diferenciación o
 capacidades. Recortes o mezcla indiscriminada de canales pueden debilitar exclusividad, talento y
 control de diamantes. Preservar autonomía de marca y experiencia, transferir trazabilidad y
 procesos de modo selectivo y medir sinergias netas junto a reputación, calidad y retención. La
 decisión no autoriza aplicar una reducción general de costos a actividades que generan el valor
 adquirido.
 enero 2021 - pregunta 4 - Adquisición y sinergias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 335-336 | convocatoria
 1
Examen de Grado UC | materia, preguntas y respuestas 246

[pág. 247]
Dirección - versión clara y reordenada
 Volver al enunciado original
 1. Condiciones conceptuales
 Una buena fusión crea un valor conjunto superior al valor de ambas firmas separadas y a los costos
 de realizarla: el excedente debe provenir de complementariedades, economías o capacidades que
 la combinación permite crear y capturar. Influyen el encaje de negocios y recursos, posibilidad real
 de compartir actividades, costos de coordinación e integración, gobernanza y efectos competitivos.
 Sumar ventas o quedar cuarto en producción no satisface esta prueba; las sinergias tienen que ser
 netas, realizables y superiores a alternativas como alianzas.
 2. Evaluación de FCA-PSA
 La fusión tiene una justificación corporativa plausible: PSA aporta diseño, tecnología y desarrollo
 eléctrico e híbrido; FCA, acceso y presencia en Norteamérica y Latinoamérica. El mayor volumen
 puede amortizar investigación, plataformas y motores y reducir costos de PSA. El caso proyecta
 ahorros anuales de US$6.130 millones frente a US$4.900 millones de costos administrativos
 directos. La magnitud favorece la hipótesis, pero no prueba retorno: hay que considerar plazo,
 inversión, costos omitidos y probabilidad de realización, sin comparar un flujo anual recurrente con
 un costo único como si fueran magnitudes equivalentes.
 Recomendaría avanzar condicionado a esos beneficios netos y a cerrar las brechas que el caso
 identifica. La complementariedad no soluciona sola las malas evaluaciones de confiabilidad y
 consumo de FCA ni la lentitud para adaptarse. Ambas son débiles en China e India y 89% de los
 ingresos conjuntos quedaría en Europa y Norteamérica; no debe presentarse alcance geográfico
 completo donde no existe.
 3. Tres riesgos prioritarios
 1. Integración de estilos de gestión. PSA promueve innovación, autonomía y herramientas
 sofisticadas; FCA usa reglas claras y optimización del costo. Una estandarización que imponga el
 segundo estilo puede destruir las capacidades que PSA aporta. Definir qué integrar, preservar
 capacidad creativa y acordar autoridad e incentivos. 2. Ahorros que dañen calidad e innovación
 o no se realicen. Racionalizar 14 marcas y plataformas puede generar retrasos, conflictos y
 deterioro, especialmente con problemas de FCA. Fijar metas verificables de sinergia junto a
 confiabilidad, consumo y desarrollo eléctrico, evitando medir solo recortes. 3. Capacidad de
 responder al mercado y transición eléctrica. La combinación sigue concentrada en dos regiones
 y enfrenta rivales adelantados en electrificación. Priorizar inversión y aprendizaje, probar productos
 y proteger liquidez, en vez de asumir que escala compensa debilidad tecnológica y acceso
 insuficiente a China e India.
 enero 2020 - pregunta 4 - Alianza/inversión y ventaja
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 309-310 | convocatoria
 1
 Volver al enunciado original
 a. Tres elementos que potencian la ventaja
 Sí existen elementos para mejorarla. Conceptualmente, una ventaja se potencia aumentando el
 valor percibido por clientes o reduciendo el costo de generarlo, y protegiendo los recursos y
 actividades que permiten retener ese excedente frente a rivales.
Examen de Grado UC | materia, preguntas y respuestas 247

[pág. 248]
Dirección - versión clara y reordenada
 1. Complementariedad de red y servicio. LATAM accede a un socio fuerte en Estados Unidos y
 puede ofrecer más rutas, mejores horarios y conexiones; Delta obtiene acceso a Latinoamérica,
 incluido Brasil, que es 30% del negocio de LATAM. La oferta conjunta de destinos y conexiones
 fluidas agrega valor para el pasajero. La cifra de 435 nuevos destinos corresponde a lo que agrega
 la alianza a la oferta de Delta, no exclusivamente a LATAM. 2. Flota y capacidad financiera. El
 acuerdo incorpora aviones y el caso espera menor deuda, mayor flujo libre y mejor estructura de
 capital para LATAM. Esto permite sostener inversión y ejecución de largo plazo. Los US$1.900
 millones compran 20% mediante una oferta pública; no corresponde tratarlos automáticamente
 como una inyección de caja a LATAM. El beneficio financiero para ella debe provenir de los
 mecanismos descritos y de su realización efectiva. 3. Compromiso de propiedad y gobierno. La
 participación y el asiento de Delta en el directorio facilitan coordinación, aportan experiencia y
 hacen más estable la cooperación que un acuerdo comercial aislado. Debe gestionarse la
 integración: LAN-TAM ya mostró que sinergias prometidas pueden fallar y el valor de mercado bajó
 de US$14.000 a US$6.500 millones.
 b. Posición competitiva en la industria
 Con cinco fuerzas, la alianza mejora potencialmente la posición frente a la rivalidad: la red
 complementaria y el acceso a Estados Unidos permiten competir con una oferta más completa y
 enfrentar a American sin la misma superposición de rutas que el acuerdo anterior frustrado. La
 escala y coordinación pueden reducir costos y mejorar condiciones de compra de recursos; la
 capacidad financiera permite sostener esa posición. Una red densa de rutas, hubs y relaciones
 también puede dificultar que un entrante replique la conectividad.
 La valoración de clientes surge de mejores conexiones, tarifas y servicio; la de inversionistas, de
 flujos y riesgo financiero, no del tamaño por sí solo. Los US$350 millones destinados a romper
 vínculos con American muestran un costo de transición concreto. La experiencia de rechazo del
 acuerdo anterior y de integración con TAM obliga a verificar regulación, costos y coordinación. Los
 beneficios son defendibles como hipótesis estratégica, pero se convierten en ventaja solo con
 ejecución y retorno neto.
 enero 2014 - pregunta 4 - Alianzas y ventaja sostenible
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 144-145 | convocatoria
 1
 Volver al enunciado original
 a) Cuándo la alianza crea ventaja competitiva para cada naviera. La alianza puede elevar la
 competitividad si coordinar flota y loops genera una combinación de menor costo por contenedor,
 mejor frecuencia/cobertura y mayor utilización que cada firma podría lograr sola. Al pasar de 32 a
 29 loops con 225 barcos, puede eliminar duplicación de rutas y asignar capacidad de manera más
 eficiente. Como los costos de un loop son mayoritariamente fijos y el combustible es clave,
 compartir espacios ayuda a llenar barcos, repartir riesgo de ocupación y sostener un servicio
 regular. Para constituir ventaja, el ahorro debe exceder costos de coordinación, complejidad
 contractual y posibles conflictos de calidad; además, cada miembro debe poder convertirlo en mejor
 costo, disponibilidad o confiabilidad para sus clientes y retener valor mediante las actividades que
 controla. La ventaja no es automática ni necesariamente igual para los tres. Depende de derechos
 de acceso a capacidad, reglas de asignación, calidad de ejecución y complementariedad de redes.
 Debe ser difícil de replicar por alianzas rivales o producir una brecha de desempeño persistente; de
Examen de Grado UC | materia, preguntas y respuestas 248

[pág. 249]
Dirección - versión clara y reordenada
 lo contrario es paridad competitiva o una eficiencia temporal. El texto prohíbe coordinar precios,
 ventas, marketing y servicio al cliente, por lo que no cabe afirmar que la alianza permita cobrar más
 o coludir. Si reduce costos pero cada naviera compite intensamente por precio, el beneficio puede
 trasladarse a clientes; eso puede aumentar volumen/utilización, aunque no garantiza captura de
 rentas. Tampoco es una fusión: las empresas conservan decisiones comerciales separadas. b) Tres
 efectos previsibles en la estructura industrial. 1. Más concentración y mayor escrutinio. La alianza
 reuniría 38% del mercado global y, según la estimación, 44% de Asia-Europa, por encima del
 umbral de referencia citado de 30%. El caso anticipa un aumento del HHI en Asia-Europa; al
 interpretar ese indicador debe aclararse la unidad competitiva y el mercado relevante, pues
 capacidad coordinada no equivale a una fusión ni autoriza cooperación comercial. El umbral no
 vuelve ilegal la alianza por sí mismo, pero aumenta la probabilidad de revisión de poder de
 mercado, acceso y efectos sobre rivales/clientes. 2. Reconfiguración de capacidad y barreras.
 Pasar de 32 a 29 loops apunta a racionalizar rutas y flota; rivales más pequeños podrían enfrentar
 una red menos densa, costos unitarios mayores y desventaja de frecuencia. A la vez, una red
 combinada podría reducir sobrecapacidad y mejorar utilización, sin que el caso pruebe que habrá
 salida neta de barcos o competidores. 3. Rivalidad comercial y respuestas estratégicas. Aunque no
 se permite coordinar precios ni atención al cliente, una red más eficiente puede intensificar la
 competencia en tarifas, frecuencias, cobertura y fiabilidad, y empujar a rivales a formar alianzas o
 rediseñar redes. Debe vigilarse que el acceso a espacios no discrimine ni limite alternativas, y
 distinguir eficiencias operativas verificables de coordinación comercial.
 enero 2012 - pregunta 2 - Cinco fuerzas y adaptación estratégica
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 90-91 | convocatoria 1
 Volver al enunciado original
 1. Qué significa adaptarse. Adaptarse estratégicamente es responder a cambios relevantes en
 clientes, tecnología, canales, costos y competencia reconfigurando propuesta de valor, actividades
 y capacidades para mantener viabilidad y ventaja. No significa seguir cada moda, copiar una
 cadena o abandonar automáticamente la identidad. La empresa debe leer qué necesidad se
 transforma, decidir qué segmento servirá y qué actividades debe modificar; sostener una decisión
 coherente puede ser mejor que expandir sin foco. 2. ¿Puede el librero tradicional adaptarse sin
 abandonar su modelo? Sí. “Tradicional” no tiene que significar congelar prácticas; puede seguir
 siendo una librería especializada en libros y competir en dimensiones diferentes al precio mínimo y
 surtido infinito del canal online: conocimiento del librero, selección curada, recomendación
 personalizada, confianza, comunidad local, acceso a editoriales/autores y descubrimiento. Puede
 especializarse en un segmento o nicho (literatura infantil, independiente, académica, local),
 organizar clubes y lanzamientos, ofrecer pedidos de títulos, catálogo y reservas digitales,
 comunicación por correo/redes y retiro en tienda. Estos canales amplían contacto y conveniencia
 sin convertir el local en una megastore ni renunciar al libro como centro del negocio. Debe articular
 lo digital con actividades y economía del modelo: inventario bien seleccionado, alianzas de
 distribución, datos de preferencias con consentimiento, eventos que generen tráfico rentable y
 servicio que aumente repetición. No basta abrir una página web si no hay disponibilidad, despacho
 fiable o una razón para comprar allí. Tampoco todas las iniciativas encajan: agregar artículos ajenos
 al libro puede dispersar identidad y capital; competir exclusivamente por precio contra grandes
 plataformas puede ser inviable. Evaluaría margen por categoría/canal, rotación, ventas repetidas,
 conversión digital, participación en eventos y costo de servir. La frase “o se adaptan o
Examen de Grado UC | materia, preguntas y respuestas 249

[pág. 250]
Dirección - versión clara y reordenada
 desaparecerán” no determina una única ruta. Un librero puede fortalecer su especialización y usar
 internet como aliado; una estrategia híbrida bien diseñada conserva el núcleo y modifica canal,
 relación y capacidades. Si define su identidad como “nunca cambiar procesos ni hablar con clientes
 fuera del local”, entonces esa rigidez sí puede impedir adaptarse. Hay trade-offs: menor escala y
 variedad a cambio de curaduría, proximidad y diferenciación; la viabilidad depende de que un
 segmento valore esos atributos y pague lo suficiente.
 agosto 2011 - pregunta 2 - Cinco fuerzas y captura de valor
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 75-76 | convocatoria 2
 Volver al enunciado original
 1. Posición más razonable
 La del banco es más razonable como hipótesis de un VAN significativo para el agricultor, sin
 que los datos permitan calcular un monto. El recurso tiene caudal potencial de 40 litros por
 segundo, calidad apreciada -natural, alto calcio y potasio, menos sodio-, cumplimiento legal y
 permisos de comercialización vigentes. No corresponde afirmar que faltan esos permisos. La
 mayoría de 270 fuentes no explotadas está concentrada en los dos grandes actores: una fuente
 independiente puede tener valor estratégico como alternativa de abastecimiento para quien quiera
 entrar o desarrollar un nicho y como recurso que uno de los dos líderes prefiera controlar.
 Hay complementariedad con las marcas y redes existentes: Cachantún tiene 43,1% y Vital 14,5%;
 65% de ventas pasa por supermercados. Los compradores pueden convertir la fuente en una oferta
 mediante capacidades que el agricultor no posee. El bajo consumo relativo, 13 litros por persona
 frente a 130 de bebidas, y la tendencia saludable favorecen el potencial. La calidad y el acceso
 independiente a una fuente bajo propiedad concentrada pueden dar capacidad de negociación y
 una alternativa de venta a más de un interesado; un posible entrante internacional es una
 inferencia, no un hecho establecido.
 El amigo acierta en que caudal y crecimiento no bastan para una ventaja, pero no hay base para
 afirmar automáticamente VAN cercano a cero. Hay que comparar precio recibido, costos y
 alternativa de no vender, y comprobar sustitución y poder negociador. La existencia de recursos
 abundantes ya controlados por compradores puede limitar el precio; por ello la tesis del banco
 depende de que el acceso independiente, calidad o ubicación tenga valor y exista una alternativa
 creíble de uso o comprador. Una buena valoración incorpora estas condiciones, no llama al recurso
 “mina de oro” solo por producir agua.
 2. Fuentes ampliamente dispersas
 Sí cambiaría el diagnóstico hacia la posición del amigo: si muchas fuentes comparables están
 disponibles con agricultores independientes, los compradores pueden sustituir una por otra, baja la
 rareza del acceso y aumenta la competencia entre vendedores. Se reduce la posibilidad de que
 este agricultor capture una renta extraordinaria; la calidad natural general no basta para diferenciar
 un recurso que muchos ofrecen. El VAN cercano a cero debe entenderse como ausencia de renta
 extraordinaria sobre la alternativa relevante, no como que el manantial no tenga precio ni ingresos.
 La dispersión no prueba un cero numérico: diferencias de composición, caudal sostenible,
 ubicación, derechos y transporte pueden conservar valor específico. La respuesta cambia porque
 cambia la estructura de propiedad y las alternativas de negociación, no porque desaparezca la
Examen de Grado UC | materia, preguntas y respuestas 250

[pág. 251]
Dirección - versión clara y reordenada
 demanda por agua o los permisos existentes.
 enero 2017 - pregunta 4 - Coherencia estratégica y VRIO
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 232-233 | convocatoria
 1
 Volver al enunciado original
 1. Coherencia de la afirmación del CEO
 No es conceptualmente coherente afirmar que solo el número uno o dos en clientes puede
 diferenciarse. La escala puede ayudar a amortizar los costos de redes y ampliar el portafolio, pero
 diferenciación depende de ofrecer beneficios por los que un segmento pague más y de disponer de
 actividades y recursos que los sostengan. Un competidor menor puede invertir, innovar y
 diferenciarse; la entrada de Reliance Jio ilustra esa posibilidad. El puesto en clientes es un objetivo
 o una posible condición de escala, no una definición ni requisito universal de estrategia competitiva.
 2. Tamaño como ventaja competitiva
 Con VRIO, la base de clientes puede ser valiosa por economías de escala, pero el rango uno o dos
 no demuestra rareza, dificultad de imitación ni organización que capture valor. El caso señala que
 instalar redes no está limitado o prohibido y la regulación es simple; por eso la infraestructura no
 constituye automáticamente una barrera protectora. Jio accede a capital, desarrolla redes y
 servicios y crece rápidamente. Vodafone debe comprobar que el sistema completo -calidad,
 cobertura, portafolio, servicio y costos- crea un excedente que los rivales no pueden igualar y que la
 compañía retiene después de inversión y guerra comercial. Sus US$2.400 millones invertidos y
 adquisiciones aumentan escala, pero no prueban retorno superior.
 3. Dos conclusiones desde India
 1. La posición número dos no asegura diferenciación ni captura. Vodafone ya ocupa ese lugar
 y aun así sus resultados se deterioran frente a un entrante con redes, productos atractivos y precios
 agresivos. Los márgenes europeos también quedan por debajo de lo previsto. Debe medir
 disposición a pagar y retorno, no usar clientes como sustituto de rentabilidad. 2. Perseguir cuota
 puede erosionar la propia estrategia. Defender permanentemente los primeros lugares genera
 guerras de precio y más marketing, mientras la oferta busca cobrar un precio superior por servicio.
 Debe elegir segmentos y países donde su sistema sea defendible, reforzar atributos valorados y
 ajustar inversión al retorno. La respuesta de competidores y facilidad de instalar redes deben
 incorporarse a la decisión, en vez de asumir que alcanzar escala termina la competencia.
 agosto 2014 - pregunta 4 - Cooperación sectorial y redes
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 154-155 | convocatoria
 2
 Volver al enunciado original
Examen de Grado UC | materia, preguntas y respuestas 251

[pág. 252]
Dirección - versión clara y reordenada
 1. Dos razones para cooperar
 1. Demanda compartida y complementariedad. Fabricantes, clubes y medios ganan cuando
 aumenta la base de jugadores; una firma sola no captura todo el beneficio de atraer principiantes.
 Cooperar combina implementos, canchas, aprendizaje y difusión y permite financiar un esfuerzo
 que beneficia a varios eslabones. 2. Superar barreras de adopción y exceso de capacidad.
 Dificultad, costo, tiempo y percepción elitista reducen el interés juvenil; hay 23 millones de
 jugadores, 24% menos que diez años antes. La tecnología de implementos, acuerdos de acceso y
 promoción pueden hacer la experiencia más sencilla y atractiva y aprovechar canchas existentes.
 La cooperación tiene sentido para crear demanda y eficiencia, sin implicar coordinación de precios
 entre competidores.
 2. Ranking de disposición a colaborar
 De mayor a menor, propongo clubes públicos, Golf Technology, clubes privados y Adidas,
 usando dependencia del negocio y barreras de salida como criterio principal.
 1. Clubes públicos: terrenos protegidos que no pueden destinarse a otro uso durante 50 años.
 Tienen la barrera de salida explícita más alta; no pueden responder a la caída del golf reasignando
 esos activos. Reflotar la actividad preserva uso y finalidad de los terrenos. Esto fundamenta
 incentivo a colaborar, aunque la capacidad presupuestaria pública puede limitar cuánto aportan. 2.
 Golf Technology: especializada en implementos, 70% de cuota, cinco semestres de utilidades
 decrecientes y caída superior a 40% en tres años. Su continuidad depende de recuperar jugadores
 y puede capturar una parte importante del beneficio; conocimiento y activos especializados tienen
 pocas alternativas fuera del golf. 3. Clubes privados: padecen exceso de capacidad y cierres, por
 lo que les interesa atraer socios; pero pertenecen principalmente a familias del negocio inmobiliario.
 Frente a los públicos, tienen más opciones de vender o reconvertir el uso del activo, si las
 condiciones permiten hacerlo; el caso no les impone la protección de 50 años. 4. Adidas:
 diversificada y golf explica solo 5% de EBITDA; su directorio ya considera reducir inversión. Tiene la
 menor dependencia relativa y alternativas para recursos y marca, de modo que puede preferir salir
 o concentrarse en otros deportes.
 El ranking no es una medida de virtud o de urgencia financiera aislada. Los detalles de contratos,
 restricciones privadas y presupuestos pueden modificarlo; con la información dada, la imposibilidad
 de salida de los clubes públicos no justifica ubicarlos al final.
 3. Dos ámbitos de colaboración
 Primero, programas de iniciación juvenil: clases, préstamo de implementos y acceso introductorio,
 con clubes, fabricantes, deportistas jóvenes y medios. Reducen dificultad, costo y desconocimiento
 y deben medirse por práctica recurrente, no solo asistencia.
 Segundo, formatos de menor tiempo y experiencia más accesible: rondas cortas, disponibilidad
 coordinada, convenios de uso y difusión de tecnología que facilita jugar. La prueba es retención de
 jugadores y utilización rentable de canchas; acuerdos de producto y acceso no requieren fijar
 conjuntamente precios del mercado.
 agosto 2020 - pregunta 5 - Diferenciación y sostenibilidad
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 325-326 | convocatoria
 2
Examen de Grado UC | materia, preguntas y respuestas 252

[pág. 253]
Dirección - versión clara y reordenada
 Volver al enunciado original
 1. Tres razones para evaluar la supuesta destrucción de valor
 No es correcta como conclusión automática. Primera: el valor estratégico se evalúa por flujos y
 capacidades de largo plazo, no solo por renta cobrada durante el cierre. Suspender temporalmente
 rentas de 413 Pymes puede evitar quiebras y vacancia, preservando cobros y ocupación
 posteriores; debe compararse el costo actual con la pérdida evitada.
 Segunda: crédito de hasta $10 millones a tasa real cero, asesoría y mentoría ayudan a que
 arrendatarios sobrevivan y adapten su negocio. Se crea valor para clientes y para el conjunto de
 locales que comparte flujo y atractivo comercial; no es una donación necesariamente desvinculada
 de la propuesta inmobiliaria. La empresa especializada otorga el crédito: no se debe suponer que
 Patio financia todo ese monto.
 Tercera: mantener empleos y salarios puede preservar conocimiento, servicio y confianza, reducir
 costos de reconstrucción y fortalecer reputación con clientes, colaboradores e inversionistas. Los
 compromisos tienen costo y pueden ser insostenibles sin liquidez; por ello tampoco se puede
 asegurar creación de valor. Lo incorrecto es concluir destrucción solo porque se renuncia a cobros y
 ahorros inmediatos, sin analizar beneficios, horizonte y capacidad financiera.
 2. Tres razones de mejora de la posición
 Selecciono mejora potencial, sujeta a que las medidas sean sostenibles y útiles. 1. Una respuesta
 consistente en la crisis diferencia a Patio como socio inmobiliario confiable y puede atraer y retener
 clientes, aumentando preferencia y reduciendo costos de captación. 2. La supervivencia de Pymes
 y asesoría reducen vacancia y deterioro de los centros, sosteniendo flujos y calidad de los activos
 frente a arrendadores que pierdan ocupantes. 3. La continuidad y compromiso del personal
 conserva capacidades de servicio y ejecución, reforzando un sistema de relaciones que es más
 difícil de imitar que una campaña.
 Son cambios respecto de la situación previa, no una descripción estática de la industria. Las
 medidas pueden ser imitadas y clientes beneficiados pueden no sobrevivir; si el costo provoca
 iliquidez, empeora la posición. Deben seguirse cobros recuperados, vacancia, renovación, liquidez,
 continuidad del personal y respuesta de clientes, evitando atribuir automáticamente toda mejora al
 programa.
 agosto 2022 - pregunta 4 - Efectos de red y ecosistema
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 370-371 | convocatoria
 2
 Volver al enunciado original
 1 a. Buscador y publicidad como motor. El buscador atrae usuarios porque resuelve una tarea
 frecuente con baja fricción y mejora con uso/datos relevantes. La plataforma publicitaria monetiza
 intención y atención conectando anunciantes con usuarios; más usuarios atraen anunciantes, más
 anuncios relevantes financian producto e infraestructura, y mejores resultados mantienen uso. Son
 efectos de red indirectos y un ciclo de retroalimentación entre audiencia, datos, calidad y
 monetización. La energía para construir otras líneas proviene de flujo de caja, capacidades
 técnicas, marca, datos y distribución. El mecanismo tiene límites: privacidad, regulación, saturación,
 dependencia de publicidad y riesgo de que monetización deteriore experiencia.
Examen de Grado UC | materia, preguntas y respuestas 253

[pág. 254]
Dirección - versión clara y reordenada
 1 b. Creatividad e innovación. Una base de búsqueda/publicidad proporciona recursos y activos,
 pero no determina qué negocios adyacentes crear ni si serán valiosos. La innovación debe
 identificar necesidades y complementariedades, experimentar, decidir cuándo desarrollar
 internamente, asociarse o adquirir, y retirar iniciativas sin encaje. El éxito depende de convertir
 recursos en ofertas con disposición a pagar y una estructura de costos/captura viable; la tecnología
 por sí sola no garantiza adopción ni ventaja.
 2. Ventaja corporativa. Tiene sentido analizar ventaja corporativa cuando la matriz puede crear
 valor en varios negocios por encima de lo que cada unidad lograría independiente: compartir
 infraestructura/datos/capacidades, integrar productos, asignar capital y talento, marca/distribución o
 aprendizaje transversal. Para Google/Alphabet, la base de búsqueda, publicidad, nube,
 infraestructura, IA, desarrolladores y ecosistemas puede generar economías de alcance y acelerar
 innovaciones entre negocios. Pero el beneficio debe superar costos de coordinación, subsidios
 cruzados, burocracia, conflictos regulatorios y distracción. Para sostenerla se requiere que las
 capacidades compartidas sean valiosas y difíciles de igualar y que la matriz facilite cooperación sin
 suprimir autonomía de unidades. Su sostenibilidad es condicional: cambios tecnológicos y de
 plataformas, rivales, regulación/antitrust, privacidad y disrupción de la búsqueda pueden debilitar el
 núcleo que financia o conecta los negocios. Evaluaría contribución incremental de la matriz frente al
 contrafactual de unidades independientes; el tamaño o variedad del portafolio no prueba ventaja.
 agosto 2012 - pregunta 4 - Entrada y reacción competitiva
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 108-109 | convocatoria
 2
 Volver al enunciado original
 1. Por qué LAN celebra la entrada. La explicación no es que un competidor en su mercado central le
 convenga por sí mismo. LAN puede estar mirando el juego competitivo en más de un país y el
 efecto de precedente: como operador multinacional con sociedades y escala en varios mercados
 latinoamericanos, una tendencia regional hacia cielos abiertos le ofrece opciones de expansión que
 una aerolínea pequeña y solo chilena no tiene. Puede incluso esperar que la apertura unilateral de
 Chile impulse acuerdos recíprocos o liberalización futura, aunque la norma descrita hoy no le
 conceda derechos en otros países. Además, su 73% de participación nacional y posición dominante
 en una ruta con más de 25 vuelos diarios le dan recursos, densidad y capacidad de responder a
 AUP; un nuevo entrante aislado puede ampliar la demanda o validar la ruta sin amenazar de
 inmediato el núcleo de LAN. La alegría es probablemente por la opción estratégica de globalización
 y la posibilidad de competir con ventaja en otros mercados, no porque toda entrada mejore
 automáticamente su rentabilidad doméstica. Debe distinguirse la apertura vigente, sin reciprocidad,
 de una eventual liberalización futura que no está asegurada. 2. Tres determinantes probables del
 fracaso de AUP. 1. Propuesta insuficiente para el segmento dominante. El 75% de viajes son de
 negocio, y esos clientes priorizan flexibilidad horaria y ahorro de tiempo. AUP ofrece un vuelo por
 día con horarios adecuados para habitantes de Concepción, pero estos son solo 20% del flujo y
 78% corresponde a capitalinos. Su oferta no se adapta igual al origen dominante ni da la flexibilidad
 del mercado con más de 25 vuelos diarios, dominado por LAN, o alternativas cuando se pierde el
 vuelo. La comodidad de 90 asientos, servicio y seguridad son valiosos, pero no resuelven el atributo
 principal para viajeros frecuentes. 2. Precio promocional no equivale a economía sostenible ni a
 diferenciación duradera. US$38 ida y vuelta puede atraer prueba, pero la tarifa regular anunciada
 deUS$67 apenas queda por debajo de tarifas mínimas LAN/SKY cercanas aUS$70; no se informa
Examen de Grado UC | materia, preguntas y respuestas 254

[pág. 255]
Dirección - versión clara y reordenada
 costos, ocupación o ingreso por asiento para concluir rentabilidad. Si la compra empresarial valora
 horario y red más que precio, el descuento puede no inducir suficiente demanda y erosiona margen.
 La tarifa promocional tampoco asegura frecuencia, fidelidad, distribución corporativa ni ingresos por
 equipaje/servicios. 3. Desventaja de red, escala y costo de operar una ruta aislada. AUP tiene siete
 aviones, entra con una sola ruta nacional y usa un avión que llega desde Montevideo y queda fuera
 de su red durante la noche en Concepción. Tiene menos frecuencias, respaldo operativo,
 conocimiento local y conexiones nacionales que un incumbente dominante con escala y red. Sus
 conexiones internacionales por alianza no sustituyen una red doméstica densa ni una fuerza
 comercial local. Ante costos fijos de operación, una baja ocupación o respuesta tarifaria de
 LAN/SKY podría hacer inviable la ruta. La evidencia del caso no permite calcular margen,
 ocupación ni probar cuál factor causó el retiro; son mecanismos estratégicos consistentes con la
 información. La entrada a más ciudades debía condicionarse a validar demanda, costo por vuelo,
 frecuencia que valora el cliente, repetición y rentabilidad, no solo a una tarifa inicial atractiva.
 enero 2018 - pregunta 4 - Estrategia y diversificación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 260-261 | convocatoria
 1
 Volver al enunciado original
 a. Evaluación de la estrategia en emergentes
 La estrategia descrita es coherente con las oportunidades y características del mercado,
 aunque las ventas por sí solas no prueban creación de valor. Los negocios crecen más de 29%,
 emergentes representan 34% del total y el plan chino de US$125.000 millones en hospitales abre
 una oportunidad concreta para equipos de salud. Philips asigna allí personal, investigación y
 distribución y reduce actividades en otros países: reorienta recursos hacia la oportunidad, en vez de
 fijar solo una meta de 50% de ventas para 2020.
 También adapta diseño y fabricación al mercado local y distribuye mediante tiendas de barrio para
 una población muy dispersa. Más líderes locales y mayor descentralización permiten responder a
 información que la sede no maneja. Esa combinación conecta producto, canal y organización. El
 riesgo es que competidores locales se vuelvan regionales o globales y que los rivales también
 adapten productos y descentralicen. Por ello, la coherencia de la estrategia es favorable, pero su
 diferenciación y captura no quedan aseguradas por adoptar prácticas compartidas.
Examen de Grado UC | materia, preguntas y respuestas 255

[pág. 256]
Dirección - versión clara y reordenada
 b. Dos condiciones para que iluminación sea atractiva
 1. Economía de distribución rentable en un mercado fragmentado geográficamente. El
 crecimiento debe convertirse en margen después del costo de llegar a muchas tiendas y
 consumidores dispersos. Philips necesita densidad, cobertura y coordinación de canal suficientes,
 mediante red propia o acuerdos, para que volumen y precio compensen logística y servicio. La alta
 dispersión es un desafío de costo y acceso, no prueba por sí sola que la industria esté fragmentada
 en número de competidores. 2. Ventaja específica que permita capturar y sostener ese margen.
 Productos adaptados, tecnología, marca, fabricación y distribución deben aportar beneficios o
 eficiencia superiores frente a competidores locales y globales y ser difíciles de replicar como
 sistema. El negocio representa más de 55% de ventas y más de 60% de rentabilidad mundial, lo
 que acredita importancia y capacidades existentes, pero no garantiza que funcionen igual en
 emergentes. Será atractivo si esas capacidades, con ejecución local, crean un retorno superior al
 costo de los recursos y del riesgo de expansión.
 agosto 2015 - pregunta 4 - Evolución de estrategia y organización
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 179-180 | convocatoria
 2
 Volver al enunciado original
 1) Objetivo de cada visión/misión. En 1990-2000, Mejías buscaba cambiar resultados estancados y
 construir una posición diferenciada y rentable en cada negocio frente a entrada creciente. “Único,
 inspirador, admirado”, calidad y rentabilidad expresan una aspiración de marca/posicionamiento
 para cada unidad, y la diversificación describe el portafolio corporativo deseado. En 2000-2010, la
 segunda formulación conserva y consolida las posiciones ya logradas, pero incorpora una
 capacidad interna: libertad para crear, aprovechar el potencial de las personas, productividad,
 eficiencia y reconocimiento del aporte. La meta deja de ser solo que cada producto/negocio sea
 preferido; también busca una organización que innove y ejecute bien en mercados maduros. 2) Dos
 razones del ajuste. (i) El entorno cambió: los mercados desaceleraban y entraban en madurez; la
 demanda ya no crecía y habían desaparecido competidores. El crecimiento fácil vía expansión de
 mercado pierde fuerza, así que es necesario defender posiciones y mejorar productividad/costos.
 (ii) El primer período construyó posicionamiento y marcas; el desafío siguiente era movilizar a
 profesionales y trabajadores para sostenerlo, renovar ofertas y convertir capacidades humanas en
 innovación y eficiencia. La nueva visión complementa la estrategia externa con cultura, compromiso
 y ejecución. No basta afirmar que la nueva misión “motiva”: debe traducirse en autonomía con
 dirección, recursos, métricas de productividad e incentivos coherentes, evitando que eficiencia
 ahogue la creatividad o que una declaración amplia no guíe prioridades.
 enero 2015 - pregunta 4 - Guerra de precios en cloud
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 166-167 | convocatoria
 1
 Volver al enunciado original
 1) ¿Es esperable una guerra de precios? Sí, es plausible, aunque no inevitable en todos los
 segmentos. Hay tres mecanismos: 1. Estructura de costos y capacidad: 70% de los costos son
 inversión, salarios y otros fijos; el costo incremental de atender capacidad disponible puede ser
 relativamente bajo. Una firma puede bajar precio para aumentar utilización y repartir costos fijos
 entre más clientes. Si todos reaccionan, el precio puede caer por debajo del nivel que cubre el costo
Examen de Grado UC | materia, preguntas y respuestas 256

[pág. 257]
Dirección - versión clara y reordenada
 total en el largo plazo. 2. Crecimiento y escala: la categoría crece pero está debajo de su potencial;
 ganar cargas de trabajo hoy puede generar escala, aprendizaje, reputación y oportunidades de
 vender servicios de mayor valor. Esto incentiva recortes agresivos para captar clientes, y la
 respuesta de Google, Amazon y Microsoft muestra que los competidores pueden igualarlos. 3.
 Comoditización y comparación: almacenamiento/cómputo pueden ser comparables y el cliente
 puede cambiar carga o negociar con varios proveedores; ello hace visible el precio y aumenta
 rivalidad. Sin embargo, seguridad, disponibilidad, privacidad, compatibilidad, latencia y nube híbrida
 diferencian ofertas y elevan costos de cambio. La infraestructura propia es sustituto para algunas
 empresas. Por eso cabe esperar una guerra en servicios estandarizados, no necesariamente un
 precio único en toda la industria. 2) Quién gana y pierde. En el corto plazo ganan clientes que
 pueden mover cargas, especialmente los que sustituyen servidores internos caros, porque pagan
 menos y pueden posponer inversión propia. Pierden márgenes los proveedores; los pequeños o
 con menor utilización son más vulnerables. Amazon, Google y Microsoft pueden soportar recortes si
 tienen escala, caja, tecnología y capacidad ociosa, pero no se debe inferir que todo descuento sea
 rentable. En el mediano/largo plazo, los clientes siguen beneficiándose si la rivalidad fuerza mejoras
 en precio, seguridad y servicio, pero pueden perder si salidas y concentración reducen alternativas,
 aumentan dependencia o encarecen migraciones posteriores. Los proveedores que ganan son los
 que convierten escala y aprendizaje en costos unitarios bajos y diferencian con seguridad, fiabilidad
 e híbrida, sin sacrificar inversión. Los que compiten solo por precio, mantienen capacidad
 subutilizada o no recuperan costos fijos pueden salir o consolidarse. La guerra también puede
 destruir valor si todos reducen precios sin generar demanda incremental suficiente. Conclusión.
 Recomendaría analizar margen de contribución por servicio, utilización, costo de
 adquisición/retención y valor de vida del cliente, junto con seguridad y costos de salida. Una
 reducción puede ser inversión racional para capturar volumen y escala; solo es sostenible si el valor
 de clientes/eficiencias compensa el margen cedido.
 enero 2024 - pregunta 4 - IA, cinco fuerzas y VRIO
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 409-410 | convocatoria
 1
 Volver al enunciado original
 1. Tres impactos directos sobre la estructura competitiva, rentabilidad y riesgos.
 1. Entrada y rivalidad. La distribución digital y la automatización permiten a fintechs atender sin
 una extensa red de sucursales, reduciendo una barrera histórica y el costo de servir a jóvenes. La
 IA agrega personalización y predicción, por lo que los incumbentes deben mejorar su oferta. La
 mayor rivalidad puede transferir ahorros a clientes mediante menor precio o mejores servicios y
 reducir márgenes; los primeros que ejecuten bien pueden capturar rentas temporales. La inversión
 en datos, talento y controles conserva barreras nuevas: comprar un algoritmo no garantiza una
 entrada viable. Se agregan riesgos de fallas tecnológicas, fraude y carreras de inversión con
 retornos insuficientes. 2. Poder de clientes y segmentación. El banco llega al cliente donde esté y
 facilita cotización y comparación; los jóvenes del caso muestran menor lealtad y buscan
 conveniencia. Ello aumenta opciones y presión por servicio/precio. La personalización puede
 contrarrestar esa presión elevando ajuste, satisfacción y retención, y la evaluación predictiva puede
 rentabilizar segmentos antes caros de atender. Pero la rentabilidad depende de crédito
 efectivamente cobrado y de costos netos, no de aprobar más préstamos. Errores, sesgos o uso de
 datos que dañe confianza elevan riesgos crediticios y reputacionales. Los clientes tradicionales
Examen de Grado UC | materia, preguntas y respuestas 257

[pág. 258]
Dirección - versión clara y reordenada
 valoran confianza y cobertura, por lo que el efecto no es uniforme entre segmentos. 3. Nueva
 escala de recursos y complementariedad entre bancos y fintechs. El costo de construir
 modelos, integrar sistemas y controlar fraudes es en parte fijo: una base amplia de datos y
 transacciones puede amortizarlo y mejorar aprendizaje. Esto puede reforzar a actores que
 combinen escala, datos y confianza, mientras alianzas con fintechs amplían el ecosistema y
 compiten con ofertas aisladas. La automatización de back office reduce costos y la detección de
 fraude reduce pérdidas, pero esas ganancias solo elevan rentabilidad industrial si no quedan
 absorbidas por inversión o competencia. La dependencia de socios tecnológicos, las fallas
 compartidas, ciberataques y modelos similares pueden concentrar riesgos operacionales y afectar a
 varios actores a la vez.
 2. Tres determinantes de la sostenibilidad competitiva de BancoEstado.
 1. Complementar la base propia con IA relevante. Casi 15 millones de clientes, confianza y
 cobertura nacional son recursos que el caso señala como difíciles de igualar. La IA debe convertir
 ese conocimiento en soluciones inclusivas y precisas, conservando atención apropiada para
 clientes tradicionales. BEPay, biometría, Bolsillo Familiar Electrónico y cuenta digital pueden crear
 valor si funcionan como sistema accesible y confiable. Comprar tecnología común por sí solo es
 imitable; el diferencial es su combinación con relación, datos, cobertura y conocimiento de
 necesidades. 2. Ejecutar y aprender con rapidez, sin erosionar confianza. El tamaño dificulta
 agilidad. BancoEstado debe integrar datos y sistemas, formar equipos, simplificar procesos y definir
 responsables de calidad, seguridad y revisión de errores. La biometría y la predicción de fraude
 deben reducir riesgo, con continuidad y respuesta cuando fallan; una mala automatización puede
 deteriorar el principal activo reputacional. Una implantación lenta permite que competidores capten
 clientes antes de que el banco materialice sus recursos. 3. Capturar valor compatible con misión
 y segmentos. El plan busca impactar a más de 10 millones de clientes, reducir
 efectivo/presencialidad y mantener costos mientras crecen transacciones. Debe comprobar menor
 costo por operación, pérdidas por fraude, adopción y satisfacción, además de inclusión y
 accesibilidad. La reducción de costos debe superar inversión y mantenimiento; personalizar
 campañas debe mejorar productos y uso responsable, no solo elevar contactos. La sostenibilidad
 depende de renovar capacidades y conservar clientes frente a rivales, manteniendo el propósito
 inclusivo, y no de una ventaja automática por moverse primero.
 Los tres factores se refuerzan: recursos propios sin ejecución no generan resultados; ejecución
 eficiente sin ajuste a clientes puede perder confianza; resultados de corto plazo sin aprendizaje
 pueden ser imitados. El caso sustenta una oportunidad competitiva y riesgos precisos, pero no
 demuestra aún una ventaja permanente ni el retorno total del plan.
 marzo 2009 - pregunta 2 - Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 4-5 | convocatoria 1
 Volver al enunciado original
 La imitación no es una tercera estrategia genérica ni una ventaja por sí misma: describe cómo una
 empresa adopta rasgos visibles de una oferta rival. Puede facilitar entrada, reducir costos de
 diseño/aprendizaje y acelerar una propuesta para consumidores que ya conocen la categoría, pero
 la ventaja solo existe si crea valor neto superior al costo y permite capturarlo. Liderazgo en costos y
 diferenciación siguen siendo fuentes de posición; una imitación puede competir con menor costo,
 paridad suficiente, foco local, canal o servicio distintos. Copiar envase/nombre sin una economía
Examen de Grado UC | materia, preguntas y respuestas 258

[pág. 259]
Dirección - versión clara y reordenada
 mejor puede ser “quedar atrapado al medio” y enfrentar presión de precio.
 La tesis de que imitar destruye valor es demasiado general. El imitador puede evitar parte de I+D,
 educar menos al mercado, aprovechar demanda creada por el líder y atender a compradores más
 sensibles a precio. Con $489 frente a $599 y share 15% frente a 65%, la marca seguidora puede
 obtener contribución positiva si costo variable, marketing, distribución y volumen cubren
 inversión/costos fijos. Participación y precio no revelan margen, elasticidad, canibalización, costo de
 adquisición ni rentabilidad total; tampoco sabemos si las cifras representan un equilibrio o un
 periodo.
 Que la práctica persista puede deberse a que el líder no puede apropiarse de toda la demanda, la
 categoría crece, el imitador tiene escala/canales/costos distintos, la copia funciona como señal de
 familiaridad o el portafolio tolera un producto de margen menor que atrae clientes hacia otras líneas.
 También puede haber fallas: subsidios cruzados, objetivos de share, exceso de capacidad, sesgos
 gerenciales o expectativas de respuesta del líder. Deben distinguirse rentabilidad del SKU, del
 segmento y del portafolio; además, la copia debe respetar marcas, diseños y normas de
 competencia/consumo.
 agosto 2009 - pregunta 2 - Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 17-18 | convocatoria 2
 Volver al enunciado original
 1. Dos razones estratégicas para el posible éxito de Chrome OS
 Cambio del sistema de actividades y propuesta de valor. Chrome OS basado en Linux ofrece
 arranque rápido, software ligero y aplicaciones accesadas desde internet, comenzando en
 netbooks. Sustituye la instalación de suites completas por uso conectado y pago reducido solo por
 aplicaciones utilizadas. Puede atender clientes que valoran sencillez, velocidad y costo, reduciendo
 la dependencia de Windows/Office y parte de sus costos de cambio. No pretende necesariamente
 derrotar de inmediato toda la base empresarial instalada: entra por una ocasión y plataforma donde
 los beneficios distintos pueden pesar más que compatibilidad heredada.
 Complementariedades y desarrollo abierto. Google aporta buscador, marca y servicios como
 Gmail, Docs, Maps, Earth y YouTube; el código abierto permite que desarrolladores mejoren el
 sistema y adapten aplicaciones y equipos. Más usos y desarrolladores elevan atractivo para
 usuarios, y estos atraen desarrollo adicional. Al fomentar actividad en la web, Google puede
 monetizar búsqueda y publicidad aun si Chrome OS no cobra una licencia elevada. Los riesgos son
 conexión, compatibilidad, calidad y distracción del negocio central: las complementariedades hacen
 posible el éxito, no lo garantizan.
 2. Respuesta concreta de Microsoft y alternativa
 Microsoft anuncia versiones gratuitas online de Office. Es comprensible para impedir que Google
 sustituya la suite; sin embargo, como reacción aislada es estratégicamente débil y puede
 beneficiar al rival. Microsoft tiene 94% de Office frente a 0,04% de Google: gratuidad en la web
 puede canibalizar rentas de su posición fuerte y legitimar el cambio hacia un modelo online en el
 que el buscador de Google domina con 65%, frente al 8% de Microsoft. Esto explica el “bienvenido”
 del ejecutivo de Google: más trabajo en internet aumenta la importancia de navegación, búsqueda y
 publicidad, no necesariamente la compra de Windows y Office instalados.
Examen de Grado UC | materia, preguntas y respuestas 259

[pág. 260]
Dirección - versión clara y reordenada
 Una alternativa de reacción es atacar o desarrollar con fuerza el negocio que sostiene la
 rentabilidad de Google: búsqueda y publicidad, combinando mejora de su buscador con su
 distribución, navegador y base de aplicaciones. La tabla muestra 66% de Microsoft en navegadores
 frente a 1,8% de Google, capacidad que puede conectar con servicios de búsqueda competitivos y
 facilitar adopción. No basta imponer un buscador: debe ofrecer calidad, confianza e
 interoperabilidad y evitar que una defensa de distribución sustituya innovación. A la vez, Office
 online puede formar parte de una estrategia segmentada y monetizable que mantenga valor de
 aplicaciones avanzadas; el problema es responder únicamente regalando el negocio propio sin
 actuar sobre el modelo de captura del rival.
 Navegador y buscador. El navegador es el software que abre y muestra páginas web (por ejemplo
 Explorer); el buscador es el servicio que recibe consultas y localiza contenido (por ejemplo Google).
 Un navegador puede acceder a distintos buscadores. La tabla no debe confundirse con cuotas del
 sistema operativo Windows: la columna de sistemas operativos se refiere expresamente a
 teléfonos.
 marzo 2010 - pregunta 2 - Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 33-34 | convocatoria 1
 Volver al enunciado original
 1. Cómo puede crear valor la integración vertical. Integrar etapas sucesivas puede reducir
 costos de transacción y coordinación cuando hay activos específicos, incertidumbre, inversiones
 difíciles de contratar o riesgo de oportunismo; asegurar abastecimiento/calidad y sincronizar etapas;
 evitar doble marginalización entre proveedor y productor; proteger conocimiento e interfaces; o
 facilitar una solución conjunta que el cliente valore. El beneficio económico es el valor incremental
 de mejor coordinación, control, economías y diferenciación, menos inversión, costos
 administrativos, menor flexibilidad y riesgo de gestionar una etapa que otros hacen mejor. Integrar
 no crea valor por el solo hecho de “controlar toda la cadena”: comparar mercado, contratos/alianzas
 e integración con costo total y contrafactual.
 2. Oracle y fuerzas competitivas. La compra de Sun permite ofrecer un sistema integrado de
 hardware y software, coordinar desempeño y simplificar la compra/implementación para clientes
 corporativos; puede diferenciar la oferta y reducir dependencia de proveedores de hardware críticos
 (poder de proveedores), además de elevar costos de cambio si todo el stack queda integrado. Pero
 Oracle entra a competir con fabricantes y puede perder neutralidad como proveedor de software
 para otros; competidores como IBM, HP, Dell, Microsoft y plataformas abiertas pueden responder.
 Los compradores pueden negociar más si hay alternativas, y sustitutos cloud/soluciones modulares
 pueden limitar el valor del paquete. La integración puede elevar barreras por escala/compatibilidad,
 pero también capital comprometido, complejidad y riesgo de obsolescencia. Su valor depende de
 que el cliente prefiera la solución completa y de que Oracle coordine sin encerrar al cliente de forma
 que provoque rechazo/regulación.
 agosto 2010 - pregunta 2 - Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 48-49 | convocatoria 2
 Volver al enunciado original
 1 a. Movilidad de competidores. Restaurantes pueden entrar o salir con relativamente menos
 capital hundido que industrias intensivas en tecnología, aunque ubicación, permisos, equipamiento,
Examen de Grado UC | materia, preguntas y respuestas 260

[pág. 261]
Dirección - versión clara y reordenada
 marca y contratos generan costos. Cambios de tendencias, arriendos, márgenes bajos, reputación
 local y alta incertidumbre hacen que muchos prueben el mercado y salgan si no logran
 ocupación/contribución; nuevos conceptos aparecen porque gustos y ocasiones cambian. La
 movilidad depende de barreras de entrada/salida, no solo de que la industria sea atractiva.
 1 b. Por qué algunos permanecen. Permanecen negocios con propuesta y actividades coherentes
 para un segmento, ubicación/contrato adecuado, reputación y repetición, ejecución (calidad,
 servicio, costos, turnos), relaciones con proveedores, aprendizaje y suficiente caja. Una marca local
 o costos hundidos pueden elevar permanencia, pero quedarse no prueba rentabilidad o ventaja:
 algunos continúan por subsidios, costos de salida o expectativas.
 2 a. Clustering geográfico. La proximidad crea aglomeración: concentra tráfico, hace del barrio un
 destino, reduce costo de búsqueda/comparación y permite al cliente escoger entre opciones en una
 salida; restaurantes cercanos capturan externalidades de flujo y reputación del distrito, aunque
 compitan. Proveedores, transporte y empleo especializado también pueden beneficiarse.
 2 b. No contradice la ventaja competitiva. Ventaja no exige distancia física. Los locales pueden
 diferenciarse en cocina, ocasión, precio, experiencia, servicio, reputación o conveniencia y operar
 dentro de una zona que atrae demanda común. La co-localización aumenta rivalidad y
 comparación, por lo que exige una propuesta clara y economía unitaria positiva. Si son
 homogéneos, el clustering puede intensificar guerra de precios; si la variedad eleva tráfico y los
 consumidores valoran elegir, puede beneficiar al conjunto. La pregunta estratégica es cómo
 capturar valor en la ubicación frente a costos de arriendo/rivalidad, no “alejarse siempre”.
 agosto 2024 - pregunta 2 - Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf | páginas originales 417-418 | convocatoria
 2
 Volver al enunciado original
 1. Creación y captura de valor. Sí, la estrategia parece crear valor al ofrecer lujo, calidad,
 artesanía, diseño, herencia y escasez a clientes con alta disposición a pagar. Evitar automatización
 masiva y controlar ritmos/estándares de producción protege la experiencia y reputación, pero
 renuncia deliberadamente a volumen y economías de escala. También parece capturarlo: precio y
 crecimiento del valor de marca/acción sugieren que parte de la disposición a pagar se convierte en
 margen y rentabilidad; sin datos de costos, rentabilidad por producto y excedente de clientes no se
 puede cuantificar cuánto. La escasez solo crea valor si la espera eleva deseo y no expulsa al
 cliente.
 2. Competencia central y complementariedades. No es solo “hacer carteras de calidad”; es un
 sistema coherente. La selección y formación intergeneracional de artesanos sostiene conocimiento
 tácito; fabricación manual por un artesano y talleres especializados preservan consistencia y
 singularidad; control directo de diseño, materiales, calidad y volumen evita que crecimiento
 comercial degrade el producto; la herencia y reputación legitiman precio; la distribución y
 comunicación selectivas mantienen exclusividad. Estos elementos se refuerzan mutuamente:
 artesanía y control elevan calidad percibida, escasez aumenta deseo, la reputación sostiene precio
 y margen financia aprendizaje/capacidad artesanal. Un rival puede copiar un atributo aislado, pero
 replicar el sistema requiere tiempo, cultura, habilidades, proveedores y credibilidad. Si se separan
 las prácticas (por ejemplo, escasez artificial sin calidad), el sistema pierde coherencia.
Examen de Grado UC | materia, preguntas y respuestas 261

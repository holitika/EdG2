# Manual de Direccion · parte 4 (páginas 161-211)

Fuente: 03_MANUAL_ULTIMATE_DIRECCION_EDG_2027_V2_REORDENADO

[pág. 161]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2022 | pregunta 4
 Convocatoria 2 | página original 371 | Efectos de red y ecosistema
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 Google cuida mucho a sus trabajadores razón por la cual sus prácticas de gestión de personas son admiradas y
 destacadas en el mundo entero. Entre ellas cabe destacar las diversas entretenciones y juegos con que cuenta en
 las zonas de trabajo, gimnasio, comida gratis, entre otras. Una especial mención requiere el programa “20%
 Time Program”, que permite a los “Googlers” utilizar una parte de su tiempo de trabajo (un día por semana) en
 proyectos propios enfocados en algo que a la persona le apasione, pudiendo utilizar la estructura y los recursos
 de la empresa para avanzar. Esto estimula la creatividad, la motivación y el buen ambiente desde donde puedan
 surgir buenas ideas incluso para la propia compañía. También se destaca el programa de objetivos, el sistema
 de incentivos, y muchas otras iniciativas focalizadas en hacer de Google un logar atractivo para los googlers.
 No cabe duda que Google es una empresa admirada, y siempre se destaca en cualquier espacio donde se discuta
 el sector y el futuro. Un ejemplo de lo anterior se dio en la última convención mundial de empresas de tecnología,
 donde el prestigioso analista George Derek, señaló en parte de su exposición lo siguiente:
 “Google es una compañía cuidadosa y creativamente diseñada. Los dos aspectos centrales de su modelo de
 negocio (el buscador y la plataforma de publicidad) generan la energía necesaria para construir su base de
 negocio. Estos dos elementos se encuentran entrelazados en un perfecto círculo virtuoso que genera las
 condiciones necesarias para la creación de valor de la empresa. El éxito final dependerá de la creatividad e
 innovación con que finalmente Google desarrolle su negocio”.
 Preguntas:
 1. ¿Podría explicar el comentario del analista George Derek? En concreto se pide que desde el punto de
 vista de sus conocimientos de estrategia, explique los siguientes dos aspectos:
 a. ¿Por qué el analista señala que “los dos aspectos centrales de su modelo de negocio (el
 buscador y la plataforma de publicidad) generan la energía necesaria para construir su base
 de negocio”? Sea preciso.
 b. ¿Por qué el analista dice “el éxito final dependerá de la creatividad e innovación con que
 finalmente Google desarrolle su negocio”? Sea preciso.
 2. Analice la Ventaja Competitiva Corporativa de Google. Señale cuál es, por qué tiene sentido hablar
 de Ventaja Competitiva Corporativa y no por Unidad de Negocio, y si le parece que es o no sostenible.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 161

[pág. 162]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2012 | pregunta 4
 Convocatoria 2 | página original 108 | Entrada y reacción competitiva
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 PREGUNTA Nº 4
 Política de ‘Cielos Abiertos’ en Chile
 El Gobierno de Chile dio a conocer el 18 de enero de 2012 que, a partir de esta fecha, Chile tiene una política de “cielos
 abiertos” para su mercado aéreo, liberando el transporte aéreo dentro del territorio nacional, sin reciprocidad, es decir,
 cualquier compañía extranjera puede transportar pasajeros y carga en las rutas nacionales sin que ello signifique que las
 empresas chilenas puedan hacer lo mismo en otros mercados. Según el Gobierno, esto atraerá a nuevas líneas aéreas a operar
 en las rutas nacionales, bajando las barreras a la entrada, lo que podría crear mayor competencia y reducciones en los precios
 a los usuarios.
 LAN, la principal línea aérea nacional, se declaró contenta con la medida, ya que se podría introducir mayor competencia no
 sólo a nivel local, sino también a futuro, en el resto de América Latina, siendo el desarrollo del mercado en Latinoamérica
 uno de sus objetivos estratégicos como compañía globalizada. Por su parte, las líneas aéreas más pequeñas alegan que, esta
 política de “cielos abiertos”, por ser unilateral y sin reciprocidad alguna, significa entregar un bien nacional, como los cielos,
 en forma gratuita.
 La primera línea aérea internacional en iniciar vuelos en Chile fue Aerolíneas Uruguayas PEÑAROL (AUP), empresa con
 una historia de seguridad impecable y un servicio a bordo que es comparable con el ofrecido por los competidores
 nacionales. AUP cuenta con una flota compuesta por siete aviones Bombardier CRJ-900, con diseño y tecnología de última
 generación, concebidos especialmente para vuelos regionales. Son aviones relativamente pequeños, que recuerdan un jet
 ejecutivo, con 90 asientos de cuero, muy cómodos, en que nadie viaja “al medio” y sólo se viaja “ventana o pasillo”. Otras
 características de los CRJ–900 es que operan con un 30% menos de emisiones contaminantes y con mayor eficiencia en el
 consumo de combustible.
 En cuanto a destinos, AUP vuela desde Montevideo y Punta del Este a Buenos Aires (con hasta 10 vuelos diarios) y a las
 principales ciudades del Cono Sur (Santiago de Chile y Sao Paulo, entre otras). Sus vuelos sirven de conexión en viajes a
 Europa y Estados Unidos a través de alianzas con Iberia y American Airlines.
 “AUP presenta su nueva ruta Santiago-Concepción-Santiago con una tarifa inigualable”
 En marzo de 2012, AUP fue la primera compañía internacional en aprovechar la política de “cielos abiertos” en Chile. Así es
 como, en febrero 2012, AUP anunció el inicio de sus vuelos en su nueva ruta Santiago–Concepción–Santiago, con una tarifa
 promocional de US$ 38 (ida y vuelta) que denominó como ‘inigualable’, aunque la tarifa regular, se anunciaba, sería de
 US$67. Como referencia, las tarifas de menores precios de LAN y de SKY en esa ruta, bordean los US$70.
 Los horarios de los vuelos de AUP son muy favorables para los habitantes de Concepción, ya que permitirían ir a Santiago y
 volver en el día, con salida desde Concepción a las 06:45 hrs. y regreso a las 23:15 hrs. En la práctica, lo que AUP hace es
 utilizar su Bombardier CRJ – 900, proveniente de Montevideo, que arriba a Santiago a las 19:50 hrs. y que vuelve a
 Montevideo a las 08:55 hrs. del día siguiente. Dado lo breve del vuelo a Concepción desde Santiago, no es necesario cambio
 de tripulación, la que en vez de dormir en Santiago, lo hace en Concepción. No se da comida a bordo en esta ruta. AUP
 también anunció que si le va bien, entrará a más rutas en ciudades como Antofagasta e Iquique, desde Santiago.
 Otras empresas internacionales están esperando ver el resultado de AUP para evaluar su incorporación a las rutas nacionales.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 162

[pág. 163]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2012 | pregunta 4
 Convocatoria 2 | página original 109 | Entrada y reacción competitiva
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 El Mercado y la Competencia de AUP
 SKY y LAN son las empresas aéreas más importantes de Chile. Ambas líneas aéreas operan un negocio de pasajeros y de
 carga. Las actuales participaciones de estas empresas en el mercado nacional de transporte de pasajeros (vía aérea) se
 estiman en las siguientes:
 Mercado de Pasajeros en Chile
 Particip. M° Ruta Nacional Particip. M° Ruta Internacional
 Sky Airline 20% 5%
 Lan Airline 73% 60%
 Sky cuenta con 17 aviones. Por su parte, LAN opera sociedades en Chile, Argentina, Colombia, Ecuador y Perú. En 2011,
 LAN obtuvo ingresos de USD$ 5.718 millones, de los cuales USD$ 4.008 correspondieron al transporte de pasajeros y mas
 de USD$ 1.550 millones al transporte de carga.
 La ruta Santiago-Concepción-Santiago es una de las más demandadas en Chile. El 75% de los viajes en esta ruta obedece a
 razones de negocio. Para los viajeros de negocio, la flexibilidad de horarios y la escasez de tiempo son los atributos
 determinantes en la decisión de compra de pasajes. Un 20% del flujo de demanda en la ruta señalada se explica por
 ciudadanos domiciliados en la octava región, y el 78% es por capitalinos. En Concepción existe un polo industrial muy
 importante, en donde las principales empresas del país tienen desplegadas sucursales que son relevantes desde el punto de
 vista de negocio, haciendo de éste un mercado atractivo para las líneas aéreas. Ello explica que en la actualidad haya más de
 25 vuelos diarios en esta ruta, la que es ampliamente dominada por LAN.
 Considerando solo la información entregada en el caso, a Ud. se le pide responder las siguientes preguntas:
 1) Ante la incursión de AUP en el mercado de pasajeros nacionales, LAN señala su satisfacción con la medida, por cuanto
 introducirá mayor competencia en el sector tanto a nivel local como en América Latina. ¿Cómo se puede explicar, desde
 un punto de vista estratégico, que un competidor líder en el sector, cuyo negocio global depende en un 70% del transporte
 de pasajeros y cuya participación de mercado en Chile se empina al 73%, se “alegre” y se “acomode” a la entrada de un
 competidor en ese mercado? ¿Cuál es probablemente la verdadera razón de esa alegría? Sea preciso en su respuesta.
 2) Noticia de última hora: a mediados de julio de este año, en un escueto comunicado, AUP informó oficialmente que,
 debido a los débiles resultados financieros logrados por la empresa, ésta dejará de volar por tiempo indefinido la ruta
 Santiago – Concepción – Santiago en Chile.
 Desde un punto de vista estratégico, ¿cuáles diría Ud. que pueden haber sido las principales determinantes del fracaso de
 AUP en esta incursión en el mercado nacional? Señale tres factores claves que podrían explicar este fracaso.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 163

[pág. 164]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2018 | pregunta 4
 Convocatoria 1 | página original 260 | Estrategia y diversificación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N" 4
 Philips y su Estrategia en los Mercados Emergentes
 Este es el título de una entrevista aparecida hace algunas semanas en el diario Wall Street Journal a Gerard
 Kleisterlee, Presidente Ejecutivo de la compañía holandesa Philips. Al momento de jubilarse, lo que ocurnrá
 el próximo año, Kleisterlee habrá dejado una empresa con un creciente enfoque en los mercados emergentes.
 Por lo menos los números así lo demuestran.
 Philips es una de las empresas más importantes del mundo que compite a escala global en tres líneas de
 negocios: cuidado de la salud, con equipamiento de alto nivel para clínicas y centros médicos como ecógrafos
 con
 y scanners; iluminación, con ampolietas de diversos tipos, diseños y materíales; y consumo,
 electrodomésticos de la más amplia gama. Todos estos negocios de Philips, literalmente se han disparado en
 las
 los mercados emergentes, especialmente en China, India y América Latina, subiendo en más de un 29%
 ventas en el segundo trimestre del 2017 en comparación con el mismo período del año 2016.
 ha planteado
 Los mercados emergentes representan el 34% del total de las ventas de la compañía, y Philips se
 compañía
 como objetivo elevar dicha participación a un 50% para el año 2020. La mayor concentración de la
 en China se explica por el atractivo plan de inversiones que tiene el gobierno central en ese país, por más de
 US$125.000 millones, para construir miles de hospitales y clínicas durante los próximos tres años. Para
 responder a lo anterior, Philips, al igual que sus principales competidores, está también ampliando sus equipos
 de trabajo y sus divisiones de investigación en dicho país, además de fortalecer sus redes de distribución. Lo
 anterior contrasta con la actitud que el propio Kleisterlee ha impulsado en otros países donde compite la
 compañía, en los cuales ha reducido el número de empleados, ha disminuido el número de negocios y las
 carteras de productos, disminuyendo de esta forma el volumen de operación.
 Philips en los Mercados Emergentes
 La carrera hacia los mercados emergentes empezó hace 10 años. La crisis y la desaceleración, en especial en
 los mercados occidentales, enfatizaron aún más esta tendencia. Lo que se ha empezado a ver en muchos de los
 mercados emergentes es que competidores locales se convierten en rivales regionales o incluso en aspirantes
 a ser compañías globales, dado los volúmenes de negocio en los países emergentes.
 En países como India y China, no basta con servir sólo en las zonas metropolitanas, por el alto nivel de
 de
 fragmentación demográfica 1 existente en esos mercados. Es indispensable tener una buena estructura
 distribución rural, por la gran cantidad de consumidores que habitan en lugares apartados de las grandes
 mercado
 ciudades. Ante ello, tanto Philips como otros competidores, han respondido a esta tendencia del
 y para los mercados emergentes, con una
 desarrollando productos en los propios mercados emergentes
 de barrío para ir a tono con la manera en cómo se distribuye
 distribución muy al detalle en almacenes y tiendas
 sino
 la población. Así, “no son productos europeos o estadounidenses los que se venden en China o India,
 artículos diseñados y fabricados de manera local para el mercado local”, declaraba Kleisterlee en la entrevista
 al diario norteamericano.
 Haciendo Negocios en los Mercados Emergentes
 En la misma entrevista antes citada, el Presidente Ejecutivo de Philips señalaba que en el caso de los mercados
 emergentes la compañía fomenta más la toma de decisiones local, tendencia común en industrias emergentes,
 la cual es asumida por varios de los actuales competidores. En general, decía el Presidente de Philips, “tratamos
 en el
 de delegar responsabilidades hasta los puestos más bajos y descentralizar todo lo que sea posible. Pero
 más que en los mercados desarrollados. Con nuestra fuerte
 caso de los mercados emergentes, lo hemos hecho
 1 Mercado fragmentado geográficamente significa que los consumideres se encuentran altamente dispersos en el territorio
 y ningún punto concentra a una cantidad significativa de potenciales consumidores.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 164

[pág. 165]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2018 | pregunta 4
 Convocatoria 1 | página original 261 | Estrategia y diversificación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 asiática,
 presencia en mercados emergentes, es lógico que tengamos una gran presencia en la fuerza laboral
 ya que también necesitamos tener más líderes locales”
 El Mercado de luminación
 participa:
 Como se señaló anteriormente, Philips compite en tres ámbitos de negocio en los mercados en donde
 de iluminación es
 el cuidado de la salud, la iluminación, y un mercado de productos de consumo. El negocio
 Philips
 de gran importancia para la compañía por cuanto representa sobre el 55% de la venta consolidada de
 en el mundo, y explica más del 60% de la rentabilidad a nivel mundial.
 mercado de altísima
 En los mercados emergentes se le reconoce al mercado de iluminación, como un
 ón demográfica, con canales muy de nivel retail, como almacenes y tiendas de barrio, y por tanto
 fragmentaci
 que en los países del mundo
 pequeñas unidades comerciales muy dispersas a lo largo del país. Es un mercado
 por la cual Philips lo mira con mncha atención
 emergente ha mostrado importantes tasas de crecimiento, razón
 y altas expectativas para construir una posición atractiva en l.
 PREGUNTAS:
 a) Considerando solamente la información del caso basada en la entrevista dada por el Presidente Ejecutivo
 emergentes?
 de Philips al diario WSI, ¿Qué le parece la estrategia seguida por Philips en los mercados
 Argumente su respuesta con precisión.
 caso, ¿En qué
 b) En relación al negocio de iluminación, y sólo considerando la información del
 emergentes seríaun negocio afractivo
 circunstancias el negocio de iluminación de Philips en los mercados
 los
 para la compañía? Señale dos aspectos esenciales que permitan responder lo anterior entregando
 fundamentos correspondie ntes.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 165

[pág. 166]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2015 | pregunta 4
 Convocatoria 2 | página original 179 | Evolución de estrategia y organización
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 4
 El Grupo Innovation and Development Group (IDG) es considerado un ejemplo en desarrollo empresarial, y
 su único Gerente General Corporativo latino, el mexicano Juan Antonio Mejías, un ejemplo de buenas
 prácticas de gestión de alta dirección.
 IDG fue fundada para explotar patentes de invención y gestionar procesos de innovación y desarrollo
 tecnológico. En poco tiempo se convertiría en un grupo empresarial con participación en diversos campos de
 actividad comercial, con operaciones relacionadas con la generación, distribución y uso de energía eléctrica.
 De esta forma, el portafolio de negocios del Grupo IDG fue aumentando con el tiempo, y en la actualidad
 posee negocios en los sectores de la aviación, el plástico, la energía nuclear y la informática, entre varios
 otros. El Grupo IDG opera además otras divisiones como generadores, transformadores, cables, iluminación
 y electrodomésticos, La envergadura de este Grupo es de tal complejidad, que desde hace muchos años su
 gestión representa un verdadero reto para quienes la dirigen.
 Entre los principales ejecutivos que el Grupo IDG ha tenido a lo largo de su historia, sin lugar a dudas
 merece una mención especial Juan Antonio Mejías, quien ejerció la posición de Gerente General entre 1990
 y el 2010. Mejías es considerado por muchos como la persona que trasformó verdaderamente a este Grupo, y
 que lo llevó al sitial que hoy día tiene en el mundo. En las dos décadas que estuvo al mando de la gestión del
 grupo empresarial, Mejías realizó diversas transformaciones, siendo una de las principales la que hizo en el
 desarrollo y formulación de la Visión/Misión Estratégica del Grupo IDG. Los resultados lo acompañaron
 durante su gestión, con sostenidas alzas en la cotización bursátil de la acción del Grupo a lo largo de los 20
 años que lo dirigió.
 El primer período de la administración de Mejiías (1990 — 2000)
 La situación de los diversos sectores donde participaba el Grupo IDG se fue tornando cada vez más
 competitiva como consecuencia de la permanente entrada de nuevos actores, la cual era estimulada por el
 desarrollo y crecimiento en cada sector donde se competía. Para ganar posición en los diferentes mercados,
 Mejías se orientó a construir un posicionamiento estratégico en cada negocio en que participaba. Su gran
 desafío por negocio fue impulsar el desarrollo comercial y de los productos, construyendo marcas y ventajas
 competitivas en cada uno de ellos, de manera de capturar resultados atractivos y salir del período de
 monotonía que hasta 1990 mostraban los resultados del Grupo. En palabras del propio Mejías, la
 Visión/Misión Estratégica del Grupo IDG como un todo, a comienzos de 1990 fue la siguiente:
 “Buscaremos que cada negocio del Grupo IDG, sea percibido como tmnico, altamente
 inspirador, admirado y muy rentable. Buscaremos además que como grupo empresarial se nos
 aprecie como muy diversificado y líder en calidad en todos y cada uno de nuestros productos, ”
 El segundo período de Mejías (2000 — 2010)
 Fue un período complejo para el Grupo 1DG. Todo el posicionamiento estratégico construido en la década
 anterior había logrado forjar una sólida posición en cada negocio, la cual requería consolidarse y fortalecerse,
 sobre todo considerando el nuevo entorno que se vivía. En efecto, en los diferentes mercados aparecían
 señales de desaceleración, con una demanda que no crecía, habiendo desaparecido muchas empresas
 competidoras de los diferentes negocios de IDG. Parecía claro que los distintos sectores donde se competía,
 habían entrado en una fase de madurez. Lo anterior, en opinión del propio Mejías, generaba importantes
 desafíos para el equipo de profesionales, directivos y trabajadores de la empresa. A ellos “les correspondía
 hacer su parte”, señalaba Mejías ante el difícil momento que se presentaba en todos los mercados al inicio
 del 2000. Fue precisamente en esa época, cuando Mejías hace un nuevo ajuste en la Visión/Misión
 Estratégica del Grupo IDG, quedando ésta a contar del año 2000 de la siguiente manera:
 “En los últimos años hemos construido el posicionamiento estratégico deseado para IDG, cual
 es el de im grupo empresarial admirado, creciente, con productos de my buena calidad y muy
 rentable. Necesitamos seguir en esta línea estratégica y no desviarnos de ella, fortaleciendo el
 posicionamiento alcanzado en cada mercado.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 166

[pág. 167]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2015 | pregunta 4
 Convocatoria 2 | página original 180 | Evolución de estrategia y organización
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 En los próximos 10 años, queremos que, además de lo anterior, las revistas describan al Grupo
 IDG como un lugar donde la gente tiene la libertad para crear, un lugar que saca a la huz lo
 mejor de cada persona, de cada colaborador. Un lugar donde se alcanzan destacados niveles de
 productividad y eficiencia, que sean un ejemplo para el mercado y ampliamente reconocidos en
 la industria. Un Ilugar abierto y agradable, donde la gente tenga la sensación de que su trabajo
 cuenta, y donde esa percepción sea retribuida tanto en lo económico como en el espíritu.”
 PREGUNTAS
 1. ¿Qué objetivo persigue Juan Antonio Mejías con la primera definición de Visión/Misión que realiza
 para su primer período (1990 — 2000) como gerente general de IDG ? ¿Qué objetivo persigue con la
 segunda definición de Visión/Misión, que realiza en su segundo período (2000 —2010) como gerente
 general de IDG? Sea preciso en su respuestas.
 Desde un punto de vista estratégico, y en base a la información que se le ha proporcionado en el
 enunciado, ¿qué razones (señale dos) explican el ajuste de la primera a la segunda definición de la
 Visión/Misión realizado por Juan Antonio Mejías? Sea preciso para contestar.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 167

[pág. 168]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2015 | pregunta 4
 Convocatoria 1 | página original 166 | Guerra de precios en cloud
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 4
 Cloud Computing: el nuevo escenario para la guerra tecnológica
 Gigantes de la tecnología desarrollan una guerra de precios para ganar
 el negocio computacional de otras firmas
 En 2004, la empresa Amazon comenzaba a armar su infraestructura tecnológica para ofrecer servicios
 computacionales a otras compañías. Diez años después, Amazon había constituido “Amazon Web Services”,
 empresa a través de la cual estaba realizando cuantiosas inversiones tecnológicas, las cuales constituían el foco
 central para el éxito y consolidación de su negocio de Cloud Computing (CC). El servicio de CC, también
 conocido como la “Nube”, permite a diferentes empresas arrendar espacio de almacenaje y capacidad de
 procesamiento en servidores de terceros (por ejemplo, en servidores de Amazon), en lugar de comprar y
 mantener sus propios servidores y bases de datos. La “Nube” prometía ser revolucionaria: sería más barata,
 ofrecería una gran capacidad de almacenamiento de datos, mantendría los software al día, con mayores niveles
 de seguridad, permitiendo además una mayor colaboración entre los usuarios.
 Pero las grandes compañías han incorporado el concepto de la Nube de manera más lenta que lo esperado. Hay
 quienes no han entrado al CC porque sus propios equipos de Tecnologías de Información pueden dar los
 servicios de manera más económica. Otros, no ingresan por las dudas que les genera el manejar información
 importante en servidores de otras firmas. En todo caso y pese a lo anterior, el negocio del CC ha ido creciendo
 de manera sistemática, aunque más lento que lo esperado.
 Desde el punto de vista de la estructura del negocio de CC, el 70% de los costos corresponde a amortización de
 inversiones, sueldos y gastos fijos, dejando a sólo un 30% como costos que podrían ser administrados a partir de
 una eficiente gestión de recursos e insumos variables,
 Los resultados del negocio del CC están comenzando a mostrar niveles atractivos aunque todavía en la parte
 baja de la curva, como lo muestran las proyecciones que hace la empresa IDC, firma de investigación en el
 negocio de CC, que estima, para este año 2015, que el comercio mundial gastará unos 100.000 millones de
 dólares en servicios de CC, lo que se considera aceptable para un sector que aún está lejos de haber alcanzado su
 potencial de crecimiento.
 Es posible que el volumen anterior de negocios pronto comience a superarse, ya que las bajas de precios hacen
 al CC cada vez más barato. A fines de Marzo de 2014, Google redujo sus precios para el servicio CC, entre un
 30% y un 85%. Esta acción estratégica de Google, orientada a impulsar su negocio de CC, provocó una rápida
 respuesta por parte de Amazon, quien también redujo precios en hasta un 65%. Por su parte Microsoft, quien
 también es considerado un grande en el negocio de la Nube, los acompañó reduciendo sus propios precios.
 Y la situación no termina aquí, por cuanto se proyecta que los precios continúen bajando. "4zn no hemos
 llegado a la base de la curva. Cada proveedor en la Nube hará lo imposible para igualar los precios de la
 competencia", señalaba en una revista especializada el Presidente de SR Group, empresa que monitorea a
 diversas compañías que utilizan CC.
 Algunos clientes ya están tomando ventaja de esta situación, como es el caso de la Edmund.com que ofrece vía
 web información sobre autos. Esta compañía recibe 18.000 visitantes mensuales, y según ha anunciado su CEO,
 la empresa pondrá todo su sistema en la Nube de Google, con lo que espera ahorrar millones de dólares anuales.
 Amazon y otros competidores trabajan duramente para asegurar a las personas y empresas que sus datos estarán
 seguros en la Nube, un trabajo que ha sido complejo por rumores que han circulado en la industria en cuanto a
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 168

[pág. 169]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2015 | pregunta 4
 Convocatoria 1 | página original 167 | Guerra de precios en cloud
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 que empresas como Google y Microsoft, son parte de redes de vigilancia online. En respuesta, las grandes
 firmas americanas de la Nube han avanzado en sus niveles de encriptación de información para proteger los
 datos que manejan y continúan trabajando en la obtención de mayores niveles de seguridad.
 A pesar de los precios decrecientes en el sector, de la mayor seguridad, y del mayor nivel de ofertas disponibles,
 una gran cantidad de empresas se mantienen cautelosas de entregar todas sus necesidades computacionales a
 otra compañía. Por ello es que ha surgido el concepto de "Nube Híbrida", que mezcla el uso del servicio de
 almacenamiento entregado por la Nube de empresas como Google, con la mantención de otros servicios y
 aplicaciones en servidores propios de la compañía. Empresas como IBM y Rackspace, están promoviendo
 ofertas híbridas para competir con otras del estilo de Amazon y Google.
 Para los próximos años, esquemas híbridos en la Nube posiblemente serán los que dominen en el sector,
 especialmente por la posibilidad que ofrecen a empresas que manejan información reservada (de clientes, del
 negocio, etc.), de poder combinar almacenamiento externo en la Nube, con otro mantenido en la propia
 empresa, para información considerada como más reservada o estrafégica.
 El Potencial del Cloud Computing
 Ya son varios los interesados en el desarrollo del servicio del CC, y se proyecta que a medida que los precios
 caigan y la seguridad aumente, habrán más actores en esta industria. Diversos analistas del sector atribuyen este
 alto interés en el negocio del CC al hecho de ser considerado como la puerta de entrada a otros servicios de -
 - mayor valor agregado. ¿Qué nos depara el futuro en la industria del CC. En poco tiempo más se irá dilucidando
 esta interrogante.
 PREGUNTAS
 1) A la luz de la dinámica competitiva que se presenta en el sector descrito en el Caso, ¿es esperable una guerra
 de precios en el sector del Cloud Computing? ¿Por qué sí o por qué no? Señale tres fundamentos que
 sustenten su respuesta, Sea breve y preciso.
 2) Considere a los principales actores de la industria. En el caso de darse una guerra de precios, ¿quién(es)
 gana(n) en el corto plazo y en el mediano y largo plazo? ¿Quiéntes) pierde(en) en el corto plazo y en el
 mediano y largo plazo? Argumente cada respuesta, en forma concisa, desde el punto de vista estratégico,
 |
 |
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 169

[pág. 170]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2024 | pregunta 4
 Convocatoria 1 | página original 409 | IA, cinco fuerzas y VRIO
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 PREGUNTA Nº4
 Inteligencia artificial y el Sector Bancario en Chile
 La Inteligencia Artificial (IA) está desempeñando un papel fundamental en la transformación de la banca chilena. Este
 cambio no sólo ha mejorado la eficiencia y la productividad, sino también ha fortalecido la seguridad de las
 operaciones financieras, además de ofrecer la oportunidad a bancos, fintechs (empresas financieras online) e
 instituciones financieras, de mejorar las experiencias de los clientes y su percepción de valor.
 La inteligencia artificial se refiere al desarrollo de sistemas capaces de aprender, planear o resolver problemas de una
 forma similar a como lo hacen los humanos. Para que un dispositivo electrónico o software tenga inteligencia artificial
 necesita de datos y de algoritmos capaces de tomar decisiones. Los primeros los puede recibir a través de internet,
 aplicaciones de Big data o conectándose directamente con otros dispositivos para intercambiar información. Los
 segundos, en cambio, son una serie de instrucciones con las que han sido programados para que creen conductas o
 patrones según los diferentes datos que reciben. Lo que diferencia a la IA de la digitalización es que no solo automatiza,
 sino también, puede mejorar sus propios procesos de forma autónoma, descubrir nuevos segmentos, detectar nuevos
 gustos de los clientes, y por tanto generar nuevos productos. Es decir, aprende de las tareas realizadas en el pasado sin la
 necesidad de la intervención humana. Esto último se le conoce también como machine learning.
 El Sector Bancario y la IA
 Es un sector competitivo, de grandes actores, en donde la segmentación y las estrategias comerciales juegan un rol
 importante en la forma en como competir. No cabe duda de que la tecnología y la IA han transformado al sector bancario,
 han impactado a competidores tradicionales, y han permitido el acceso a la industria a una banca distinta, basada en
 internet, que no requiere el que un cliente vaya a una sucursal, ya que posibilita recibir al banco, cotizar productos, recibir
 sugerencias, en cualquier lugar en donde estén las personas. Esto ha permitido bancarizar fuertemente a segmentos como
 los jóvenes, que muestran menos rasgos de lealtad con una institución en particular, y buscan más la conveniencia, la
 facilidad, la agilidad, en comparación con los segmentos tradicionales los cuales tardan más en la adopción de tecnologías
 en sus operaciones financieras, ya que privilegian confianza, cobertura y solidez de la institución que está detrás. Quizás
 por este motivo es que los bancos tradicionales han intentado incorporar tecnología e IA en el desarrollo de productos,
 compitiendo en ciertos segmentos con las Fintech, que es como se les conoce a las empresas financieras basadas
 completamente en internet.
 Por lo anteriormente expuesto, es que probablemente la IA ha intervenido fuertemente en la industria bancaria chilena.
 Los usos y aplicaciones más frecuentes hasta ahora son mejorar la atención al cliente, optimizar los procesos de
 aprobación de créditos para prevenir la morosidad, automatizar procesos internos que reduzcan costos, entre otras
 aplicaciones. Sin embargo, el verdadero potencial de la IA en la banca chilena se encuentra en la tecnología predictiva,
 es decir, la correcta predicción de eventos, respaldada por datos sólidos y accesibles, siendo una herramienta crucial para
 la toma de decisiones informadas. Así mismo, importantes aportes tendrá la IA en el conocimiento de clientes y de sus
 hábitos, en los modelos de segmentación que se utilicen y en la generación de valor a los clientes. Todo lo anterior puede
 verse mejorado con la potencial colaboración entre bancos y fintechs, permitiendo la creación de ecosistemas
 interconectados que beneficien a los clientes.
 Además de lo anterior, existen otras variadas aplicaciones de la IA en diferentes partes del negocio bancario: en cuanto
 al front office (procesos con interacción con clientes), la IA ha permitido mejorar la experiencia del cliente, ofreciendo
 servicios más rápidos y personalizados, como asistentes virtuales que recomiendan productos y solucionan dudas como
 consultas de saldos. Uno de los aspectos más destacados es poder llegar a segmentos masivos con soluciones
 personalizadas. En el middle Office (procesos con impacto en clientes, pero sin interacción), la IA se utiliza en la gestión
 de fraudes en transacciones financieras y en la automatización de las tareas que ahorran costos. Finalmente, en el back
 office (procesos rutinarios que impactan el costo), la IA aporta eficiencia y precisión en tareas contables, facturación,
 gestión de documentos y otras tareas rutinarias, todo lo cual reduce los costos y aumenta la productividad.
 Analistas de la industria bancaria proyectan una mayor intensidad en el uso de la IA por las claras ventajas y atributos
 que generan en las empresas del sector, en especial en la forma de desarrollar y gestionar clientes. Así mismo es
 presumible que con el desarrollo tecnológico se fortalezca la IA en la industria y con ello las ventajas que genera sobre
 el sector. Desde luego que en este caso, como otros, los efectos sobre los competidores establecidos serán variables. Por
 ejemplo, y como habitualmente ocurre, quienes se muevan primero, más rápido y lo hagan bien, obtendrán la mayor
 parte del valor potencial que la IA será capaz de aportar en la industria bancaria.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 170

[pág. 171]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2024 | pregunta 4
 Convocatoria 1 | página original 410 | IA, cinco fuerzas y VRIO
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 BancoEstado y la Inteligencia Artificial
 BancoEstado es sinónimo de banca tradicional, una banca basada en la relación con el banco por medio de ejecutivo de
 cuenta, en sucursal física y con uso de internet para operaciones puntuales. Es un banco que genera alta confianza en la
 población (Banco Estado es una de las instituciones bancarias más confiables de Chile), que llega a todos los habitantes
 de nuestro país, que no distingue clase social, ni tipo de trabajo, y que cuenta con clientes muy tradicionales de todas las
 edades, quienes se sienten atraídos por la confianza que les genera la institución. En la actualidad Banco Estado tiene
 casi 15 millones de clientes en todos los rincones de Chile, quienes confían en la institución, y la adoptan como su banco.
 Lo anterior hace que el banco cuente con una gran base de datos de información de clientes, la cual es el resultado de
 entregar confianza y cobertura geográfica, a través de contar con sucursales en todo el país y el acceso al sitio web del
 banco para realizar ciertas operaciones. El despliegue de BancoEstado a lo largo de todo el país y el gran número de
 clientes que posee (gran parte de los habitantes del país), es algo que ningún otro banco puede igualar. Sin perjuicio de
 lo anterior cabe destacar que su tamaño a veces le impide moverse con la agilidad que se requiere, y en un mercado
 competitivo la velocidad en la respuesta estratégica se aprecia y genera valor.
 La misión de BancoEstado es crear soluciones financieras innovadoras, sostenibles e inclusivas para el progreso de los
 habitantes en Chile, y su propósito es impulsar un ecosistema financiero innovador, social y sostenible que haga de
 Chile un mejor país. En la cuenta pública del 11 de mayo 2023, su presidente dio a conocer las principales cifras e hitos
 de la institución durante el 2022 y anunció importantes desafíos para 2023 y los próximos años. En la instancia, el
 ejecutivo destacó que el banco está desarrollando un plan de transformación digital, con el que busca adaptarse a los
 nuevos desafíos del sector. Se espera que este plan impacte a más de 10 millones de clientes con el objetivo de reducir
 el uso de efectivo (dinero) y disminuir la presencialidad en sucursales.
 El plan digital y de IA de BancoEstado permitirá digitalizar y automatizar procesos para lograr mantener sus costos,
 mientras siguen creciendo las transacciones por los canales digitales y ofreciendo una experiencia personalizada. Para
 lograr lo anterior, se han incorporado nuevas herramientas tecnológicas basada en Inteligencia Artificial que permiten
 identificar clientes y detectar fraudes. En ese marco, algunas de las innovaciones que se trabajan son el Bolsillo Familiar
 Electrónico; el pago a través del celular, la Billetera Digital (BEPay) que permite pagar sin la necesidad de tener un
 plástico asociado; la cuenta corriente digital de BancoEstado; la autenticación por biometría facial para el enrolamiento,
 recuperación de clave o desbloqueo de tarjetas mediante IA, entre otros. Así mismo, el banco ha comenzado a incursionar
 en campañas digitales personalizadas a millones de clientes, dándoles a conocer los productos y servicios del banco.
 Preguntas:
 1. ¿Qué impacto tiene la IA en la estructura competitiva del Sector Bancario en Chile? Señale tres impactos directos y
 sus consecuencias sobre la rentabilidad y riesgos de esta industria. Sea preciso.
 2. Pensando ahora en Banco Estado, ¿Qué elementos determinarán el nivel de impacto que la IA tendrá sobre la
 sostenibilidad de la estrategia competitiva de Banco Estado? Se solicita que señale tres de estos elementos.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 171

[pág. 172]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | marzo 2009 | pregunta 2
 Convocatoria 1 | página original 4 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº 2
 La sabiduría convencional indica que las ventajas competitivas se construyen a partir de una de dos estrategias
 genéricas: la diferenciación o el liderazgo en costos. Por otro lado, una visita a cualquier supermercado de Santiago o
 de regiones permite concluir que la imitación1 es una práctica habitual en diversos mercados.
 A continuación se presentan cuatro ejemplos que ilustran la situación anterior: Zucaritas de Kellog´s y Zucosos de
 Nestlé; Mayonesa Maggi y Mayonesa Hellmann´s; Gatorade y Powerade; y Compota de Nestlé y Compota de
 Soprole. Como se advierte, en todos ellos se aprecia una aparente imitación, por cuanto los nombres, formas de
 envases, colores, sonido, etc., son muy similares en cada caso. Tomemos uno de los ejemplos: las marcas Gatorade y
 Powerade pertenecen a la categoría de productos conocidos como bebidas isotónicas. Parece ser que habría imitación
 en los nombres, los colores de la bebida, el diseño de los envases, los logos, las etiquetas, etc. Ambas bebidas
 comparten en su nombre el sufijo “RADE”, sus envases en apariencia son muy similares, ambas con tapas que
 permiten el consumo mientras se hace ejercicio, ambos de un color azul cristalino (en una de sus presentaciones), y
 ambos denotan energía en la gráfica de sus etiquetas (una usa como ícono comercial la imagen de un rayo y la otra la
 de un tornado). Cabe destacar en este ejemplo, que estos productos semejantes entre si, pertenecen a dos grandes
 compañías multinacionales, Pepsi Cola y Coca Cola, ambas empresas reconocidas por su capacidad comercial, las
 cuales compiten entre si en muchos países.
 1 : Por imitación, debe entenderse que la empresa, dentro del marco legal, intenta copiar características tangibles del
 producto tales como empaque, envases, nombre, color, entre otros.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 172

[pág. 173]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | marzo 2009 | pregunta 2
 Convocatoria 1 | página original 5 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 El caso de las mayonesas es representativo de una situación muy común, la cual se repite en varias industrias.
 Considere la siguiente tabla, que muestra lo que ocurre para un tipo específico de producto de mayonesa (bolsa de 250
 grs.), con una marca principal y con una imitadora, las cuales, al igual que en la figura anterior son de envases, colores
 y gráficas muy similares.
 Tipo de Producto Marca Precio Participación de Mercado
 MAYONESA, bolsa de 250 grs. Principal (la imitada) $599 65%
 MAYONESA, bolsa de 250 grs. Seguidora (imitadora) $489 15%
 Todo lo anteriormente expuesto pareciera sugerir que existe una tercera estrategia genérica de competencia, la
 “imitación”.
 A usted se le pide responder las siguientes preguntas:
 1. ¿Se podría decir que la “imitación” es un tercer tipo de ventaja competitiva? ¿Por qué Si o por qué No?.
 2. Diversos analistas han coincidido al comentar que: “la ‘imitación’ es una fórmula destructora de valor, ya que
 las marcas que imitan en general tienen precios más bajos que las imitadas, y por otra parte, rara vez alcanzan
 niveles de participación de mercado que las haga rentables”. No obstante, y al margen que los analistas tengan o
 no razón en su comentario, llama la atención la alta frecuencia con que sigue ocurriendo el fenómeno de la
 imitación en diferentes industrias.
 Desde el punto de vista de sus conocimientos de estrategia empresarial, ¿Qué opinión le merece el comentario
 en que han coincidido los analistas y que se presenta al inicio de esta pregunta 2? ¿Cómo se puede explicar
 que haya “imitación” que se mantiene pese a los aparentes deficientes resultados económicos que en
 muchos casos generan los productos imitadores?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 173

[pág. 174]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2009 | pregunta 2
 Convocatoria 2 | página original 17 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº 2
 El plan de Google Inc. para lanzar un nuevo sistema operativo1, el “Chrome OS”, confirma lo que se veía venir: el
 gigante de Internet quiere atacar a Microsoft Corp. en su negocio principal, el sistema operativo Windows y los
 programas de aplicaciones como Office. La decisión de Google acarrea riesgos importantes, ya que no hay ninguna
 garantía de que habrá una gran demanda para el nuevo sistema operativo y las nuevas iniciativas podrían distraer a los
 ejecutivos del que sigue siendo el negocio principal de Google: la venta de publicidad en el buscador de Internet.
 El Sistema Operativo Chrome OS
 Hace pocas semanas los blogs hervían luego de que Google anunciara la creación del sistema operativo "Chrome OS",
 que estará disponible el próximo año y que vendría pre-instalado en un comienzo sólo en pequeños computadores
 llamados netbooks2. Según Google el nuevo sistema operativo será liviano y rápido de usar.
 “Chrome OS” fue creado a partir del sistema operativo Linux y pretende cambiar la idea tradicional del sistema
 operativo en un computador personal. En efecto, los sistemas operativos mas tradicionales como Windows y
 aplicaciones como Office, se pre-instalan directamente en la computadora del usuario. Por lo anterior se requieren
 altos tiempos de espera para usar el computador, y hacen que este último esté mas expuesto al ataque de diversos
 virus.
 A diferencia de lo anterior, para aprovechar el “Chrome OS” al máximo, el usuario tiene que estar conectado a la
 Web. Las aplicaciones no se instalan en el computador personal, sino que se accesan directamente desde internet. Así
 mismo el “Chrome OS” podrá configurarse en pocos segundos para entrar directamente a la web y usar distintos
 navegadores, no solo el de Google. Podrá conectarse en forma eficiente a aplicaciones de Google, como Google
 Maps, Gmail, Google Docs, Google Earth, y a otras aplicaciones como YouTube. El usuario pagará un precio
 reducido solo por las aplicaciones que utilice y no por todo el software como en la actualidad ocurre con aquellos que
 operan con sistemas operativos tradicionales y sus aplicaciones (como el caso del Windows y Office de Microsoft).
 Una de las diferencias mas significativas del “Chrome OS” con los sistemas operativos tradicionales, está en que el
 primero será un programa de “código abierto”3, que se liberará a fines del 2009 a la comunidad de desarrolladores de
 software para internet, de manera que lo puedan mejorar, adaptar a otros tipos de computadores y desarrollar
 aplicaciones que puedan ser ejecutadas accediendo a ellas desde la web.
 1 El sistema operativo es el programa esencial para el funcionamiento de un computador. Administra el hardware y sobre él
 se ejecutan las otras aplicaciones.
 2 Los netbooks son máquinas que traen sistema operativo mínimo, y que funciona con conexión a la web utilizando la
 plataforma de software existente en ella.
 3 Los programas computacionales con código de programación abierto pueden ser modificados, estudiados y distribuidos
 por cualquier programador que quiera intervenirlos con la sola condición que los nuevos aportes al programa deben ser
 compartidos con toda la comunidad de programadores y usuarios.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 174

[pág. 175]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2009 | pregunta 2
 Convocatoria 2 | página original 18 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 Microsoft responde a Google
 Tres días después de conocidos los hechos anteriores, Microsoft Inc. compañía que domina el mercado mundial con
 su sistema operativo Windows y su popular programa de aplicaciones Office, anunció que comenzará a ofrecer en
 forma gratuita versiones en línea de Microsoft Office. Una verdadera sorpresa para Google.
 Consultado por la reacción anterior de Microsoft, un importante ejecutivo de Google sorprendió al mercado cuando
 declaró: “Bienvenido Microsoft: es justamente lo mejor para Google …”
 A continuación se presenta información de participación de mercado actual de Google y Microsoft por categoría o
 línea de negocio:
 Sistemas Paquete de Programas Búsquedas en la
 COMPETIDORES Navegadores * Operativos para tipo Office Web
 Teléfonos
 Google 1,8% 1,6% 0,04% 65%
 Microsoft 66% 10% 94% 8%
 Se Pide:
 1. Un académico experto en el sector comentaba: “‘Chrome OS’ es una apuesta innovadora y arriesgada, pero es
 difícil desplazar el sistema operativo Windows al que la gente está acostumbrada. Va a ser muy difícil destronar al
 competidor que domina el mercado mundial de Sistemas Operativos”. Desde el punto de vista estratégico, ¿Cuáles
 serían las principales razones que podrían hacer que Google fuera exitosa con el “Chrome OS”? Señale las dos
 principales razones estratégicas para lo anterior. Sea preciso y argumente con precisión.
 2. Desde un punto de vista estratégico, ¿qué le parece la respuesta de Microsoft a Google? ¿Buena o Mala? ¿Por
 qué?. ¿Existirá otra mejor forma de reaccionar por parte de Microsoft? ¿Si, No? ¿Cuál? (para esta última
 respuesta considere especialmente el cuadro de participaciones de mercado que se muestra en el cuadro
 anterior).
 Explicar brevemente la diferencia entre lo que es un “Navegador” (ejm.: Explorer, Gorzilia, etc.) y un
 “Buscador” (Google, Yahoo, etc.)
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 175

[pág. 176]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | marzo 2010 | pregunta 2
 Convocatoria 1 | página original 33 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº 2
 Redescubren beneficios de la Verticalización
 Después de medio siglo de especialización
 Oracle, empresa que hasta ahora ha estado especializada en software, planea comprar Sun Microsystems Inc. y
 transformarse en un fabricante de software, computadoras y componentes de computadoras, es decir una empresa más
 parecida a los conglomerados estadounidenses de los años 60 que a la fragmentada industria tecnológica de los últimos
 años.
 Ellison, Presidente de Oracle, es uno de los ejecutivos que ha resucitado la integración vertical, una estrategia concebida
 hace 100 años. Muchas otras compañías han avanzado en esa dirección y los motivos son diversos: mayor control sobre
 las materias primas; mayor autoridad sobre la distribución; entre otras.
 Hace tan sólo dos años, Ellison declaró que “Oracle seguiría concentrada en el software. El hardware de computadoras
 no es un negocio en el que tengamos ambiciones", afirmó. En un discurso de septiembre de 2009, dijo que esa postura
 estaba "fundamentalmente equivocada".
 La creciente popularidad de la integración vertical marca una gran diferencia respecto al último medio siglo, cuando las
 empresas se especializaron y dejaron en manos de terceros funciones como la fabricación y la compra de materias primas.
 El principio conductor era que la especialización impulsaría la eficiencia y la calidad. El resultado: una desintegración de
 procesos de valor. En la actualidad Oracle intenta combinar nuevamente en una sola mano todas esas funciones.
 Otros casos de integración
 Pepsi, por su parte, pretende recomprar las embotelladoras que vendió en 1999. En ese entonces, quería concentrarse en
 el marketing (distribución y publicidad preferentemente) y dejar la mayoría de las decisiones operativas a las
 embotelladoras en manos de terceros. Ahora, Pepsi busca un mayor control sobre los procesos de embotellado, de manera
 de lograr mayor control sobre la distribución de su creciente menú de productos.
 En los últimos dos años, Boeing compró una planta y una participación de 50% en una empresa conjunta que fabrica
 partes para su avión Dreamliner 787. Las medidas revirtieron parcialmente la agresiva estrategia de tercerización de
 Boeing para ensamblar el Dreamliner con partes fabricadas por cientos de proveedores.
 La integración en el sector de la tecnología y de la computación
 Quizás el cambio más radical en materia de integración se haya producido en la industria de la tecnología y de la
 computación, un sector muy competitivo y cambiante producto de las constantes innovaciones generadas por los mismos
 actores que participan en ella. Lo anterior lo hace ser un sector de alta volatilidad, caracterizado históricamente por
 continuas entradas y salidas de empresas, de proveedores y de distribuidores.
 Tradicionalmente la industria de la tecnología y de la computación se ha caracterizado, especialmente en la última
 década, por estar altamente dominada por la especialización y la tercerización en los modelos de negocio implementados
 por las diferentes empresas que participan en ella. En efecto, en los años 70, los fabricantes de computadoras como
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 176

[pág. 177]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | marzo 2010 | pregunta 2
 Convocatoria 1 | página original 34 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 Internacional Business Machines Corp (IBM), también producían los semiconductores, los sistemas de almacenamiento
 de datos y el software de la computadora. Para 1982, los rivales de IBM ofrecían computadoras personales más baratas,
 que funcionaban con el software de muchas empresas. Este cambio abrió paso a un período de innovación y
 especialización.
 Hace unos años, el péndulo comenzó a oscilar en la dirección opuesta. En 2005, Oracle comenzó a comprar software de
 otros fabricantes. El año pasado Hewlett Packard, la conocida empresa de computadores e impresoras, y que además
 cuenta con varios otros negocios entre los cuales se encuentra el de la consultoría, compró Electronic Data Systems Inc.,
 que administra sistemas informáticos corporativos, precisamente para fortalecer su negocio de consultoría y ejercer más
 control sobre un canal de ventas clave. Dell Inc. y Apple Inc. han dado pasos similares.
 El giro de Oracle es uno de los más pronunciados del sector. Durante 32 años, su Presidente Ejecutivo fue uno de los
 mayores defensores de la especialización en lo que llamó la "industria de la computación horizontal". La compra de Sun
 Microsystems revirtió dicha estrategia. Ahora, Ellison quiere vender "sistemas completos" compuestos de chips,
 almacenamiento de datos, computadoras y software de Oracle.
 A usted se le pide responder:
 1. Desde el punto de vista de la creación de valor económico, ¿cómo puede aportar valor la integración vertical en una
 empresa?. Sea preciso. Entregue una explicación económica.
 2. ¿Cuál es el impacto que la integración vertical tiene o puede tener para Oracle, desde el punto de vista de su
 posición competitiva en relación con las fuerzas externas competitivas del mercado?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 177

[pág. 178]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2010 | pregunta 2
 Convocatoria 2 | página original 48 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº 2
 De que el negocio de los restaurantes es cambiante, parece ser que no cabe duda. Y si la tiene, sólo piense en lo que
 ocurre en Santiago, en el barrio El Bosque, un tradicional sector de la capital que concentra gran parte de la oferta de
 restaurantes de la Región Metropolitana. Más precisamente considere la calle Isidora Goyenechea, epicentro del sector
 gastronómico capitalino: en el último año la tasa de movilidad (apertura y cierre) de restaurantes en dicho sector alcanzó
 el 45%. Vale decir, casi la mitad de los restaurantes existentes en esa zona sufrieron algún cambio geográfico (llegó a
 instalarse, se fue de la zona o se cambió de ubicación en la misma zona o en otras cercanas).
 Una rápida mirada a la situación de los restaurantes ubicados en la calle Isidora Goyenechea a Junio de 2009 y a Junio de
 2010 da como resultado que de una muestra aleatoria de 19 restaurantes considerados a Junio de 2009, sólo 10 se
 mantienen a Junio de 2010 (53%), 9 (47%) de ellos cerraron. Por otra parte, en el mismo período (junio 2009 a junio
 2010), hubo 8 nuevos restaurantes que se abrieron al público en ese sector. La información detallada de lo anterior se
 muestra a continuación:
 Restaurantes Existentes en Isidora Goyenechea a Junio de 2009: California, Nolita, Friday´s, Silvestre,
 Crepes and Waffles, Soup and Salads, Trattoria Fiori, Tiramisú, Publicity, Piola, Casa Particular, la Maison,
 Ruby Tuesday, Tip y Tap, Best Food, Don Carlos, Due Torri, Pinpilinpausha y Miguel Torres.
 Restaurantes Existentes en Isidora Goyenechea a Junio de 2010: Oporto, Nolita, La Piccola Italia,
 Maxó, Pepino´s, Trattoria Fiori, Tiramisú, Piola, Confitería Torres, Dominó, Ruby Tuesday, Tip y Tap,
 Bariloche, Don Carlos, Coquinaria, Due Torri, Pinpilinpausha y Miguel Torres.
 El sector de Restaurantes
 Es un sector cíclico que se mueve muy de la mano con la situación económica del país. Los próximos años, para los
 cuales existen buenas proyecciones de crecimiento del país, auguran una buena situación para la industria. En efecto,
 datos de la propia industria y de la Asociación Chilena de Gastronomía (Achiga) proyectan una situación de crecimiento
 del sector.
 En relación a las características competitivas del mercado de restaurantes, los propios actores y analistas independientes
 de la industria, lo describen como un sector esencialmente fragmentado, de alta rivalidad y alta movilidad de los
 competidores. El costo de arriendo en el sector, uno de los principales costos del negocio, no es considerado como
 especialmente alto por parte de los locatarios, y los contratos de arriendo que se realizan tienden a ser bastante flexibles,
 principalmente por la alta demanda de locales que existe en esa zona.
 En cuanto a los clientes, ellos pueden segmentar su negocio de diferentes formas: algunos orientan su oferta al mercado
 laboral, mientras otros a la comida por placer. De igual forma, suele utilizarse la segmentación por “temática” del
 restaurant: comida internacional, comida rápida o informal, comida mediterránea, son solo parte de algunas de las
 opciones que se consideran. Si bien el mercado es amplio, son reconocidas ciertas zonas geográficas como generadoras
 de ofertas atractivas, las cuales capturan la atención de diferentes grupos de clientes. En estas zonas se encuentra oferta
 diversa orientada a distintos públicos.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 178

[pág. 179]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2010 | pregunta 2
 Convocatoria 2 | página original 49 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 Un vecino del barrio Isidora Goyenechea, conversando con un “analista” de la industria, le comentaba lo siguiente: “Es
 sorprendente esto de los restaurantes. Se abren y cierran a cada rato. Parte de la explicación parece ser que muchos de los
 restaurantes nuevos son cadenas que abren locales en el barrio, como el Dominó, el Bariloche y la Piccola Italia. Otros
 son el resultado de emprendedores que “se la juegan” por su proyecto. Un ejemplo de ello es el Maxó, restaurante de
 propiedad de un Ingeniero Comercial UC, a cuyo padre le gusta cocinar y ambos decidieron emprender con un restaurant
 de comida mediterránea. Claro que hay otros que son restaurantes que estaban en el centro y que se trasladaron al barrio,
 como el Due Torri y el Pinpilinpausha.”
 El “analista” le contestó: “la verdad es que es sorprendente esta alta movilidad, y no tengo explicación a este fenómeno.
 Además, más sorprendente aún es que todos estén juntos en el mismo barrio, uno al lado del otro, contraviniendo lo que
 uno debiera esperar; la conveniencia de alejarse geográficamente de los competidores, para que no haya tanta
 competencia en precios”. Parece ser que es un fenómeno verdaderamente difícil de explicar.
 Preguntas:
 El “analista” de la industria que se señala en este caso, plantea varias interrogantes para las cuales no encuentra
 explicación, y que probablemente Ud. puede ayudarle a dilucidar. Utilizando sus conocimientos de Estrategia
 Empresarial, responda de manera muy precisa las siguientes preguntas:
 1. Desde el punto de vista de la movilidad de los competidores en la industria:
 a. ¿Cómo le puede explicar al “analista” la alta movilidad de competidores en la industria?.
 b. ¿Por qué hay competidores que permanecen, pese a la alta movilidad? Sea preciso.
 2. Desde el punto de vista de la ubicación de los restaurantes:
 a. ¿Cómo le puede explicar al “analista” el hecho que estén todos los restaurantes juntos, uno al lado del otro?.
 b. ¿No le parece que ello contraviene la teoría de la ventaja competitiva, la cual sugiere la necesidad de
 “desmarcarse” o alejarse de los competidores? Sea preciso.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 179

[pág. 180]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2024 | pregunta 2
 Convocatoria 2 | página original 417 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N2
 La “anti-estrategia” de Hermés
 Hermés International, es un fabricante francés de artículos de lujo especializado en accesorios de cuero,
 seda, textiles y
 otros artículos. Ha sido calificada como la marca de lujo más valiosa del mundo en diferentes estudios de
 valoración de
 marcas. La categoría de artículos de cuero es la que más contribuye a los ingresos de la empresa (41%).
 En el último
 año, las acciones de Hermés han subido más de un 30% con un rendimiento superior al de grandes marcas de
 lujo, como
 Louis Vuitton o Gueci.
 Hermés goza de un estatus icónico en el mundo del lujo, gracias a una combinación de historia heredada,
 artesanía única
 y exclusiva, atención y máximo cuidado en los detalles y altos niveles de calidad y profesionalismo
 en la confección de
 los productos. Su secreto, dicen los expertos, es que no ha intentado masificar sus productos, sino
 que ha optado por
 mantener la calidad y exclusividad de los mismos, estimulando el sentido de escasez ante el cliente, quien no
 necesariamente encuentra el producto cuando lo desea. Nunca se ha dirigido a un segmento muy masivo,
 sino que
 siempre exclusivo. El masivo per se, no le interesa. Su foco está en quienes valoran genuinamente un artículo
 de lujo.
 Hermes mantiene un estricto control de su crecimiento, lo que va en sintonía con la sensación de escasez. Hoy
 en día, la
 compañía es dirigida por los primos Axel y Pierre-Alexis Dumas, ambos directores propietarios de la empresa
 y
 tataranietos del fundador, quienes han sido fieles a los valores de la marca: calidad, herencia y refinamiento.
 Son estos
 principios los que la han llevado a hacer casi lo contrario de lo que hacen otras marcas de lujo. En efecto, en Hermés
 siempre se ha evitado la producción masiva, las líneas de fabricación automatizadas y la subcontratación de partes del
 proceso de fabricación; nunca se ha sustituido al mejor material posible para algún producto por razones de
 ahorro de
 costos, ya que todo ello deteriora el resultado final y por tanto el valor percibido por el cliente.
 La innovación continua y el refinado diseño es lo que ha caracterizado el desarrollo de la empresa, proceso
 que está a
 cargo de sus directores propietarios. Ello ha ido de la mano con abrir talleres y no fábricas, reflejando la dedicación
 única
 a cada producto. La selección de artesanos es otra de las tareas relevantes, llegando hoy en día a contar con
 un equipo
 de más de 7.000 artesanos, todos empresarios independientes a Hermés, pero que trabajan prácticamente
 de forma
 exclusiva para la fabricación de productos de Hermés. Son de diferentes edades y nacionalidades, y el oficio
 de artesano
 de Hermés se va heredando de generación en generación enseñando padres a hijos a trabajar conforme a los
 principios
 de la compañía.
 Los artesanos están separados en diferentes especialidades (cueros, maderas, materiales reciclables,
 etc.) los cuales dan
 vida a cada producto, siempre cuidando los más mínimos detalles. Son más de 15 especialidades
 distintas
 cuidadosamente coordinadas por los directores propietarios desde la casa matriz para así lograr el producto
 final buscado
 con los estándares anhelados. Unido a lo anterior es necesario destacar el estricto proceso de control
 de calidad en la
 fabricación, que además va estableciendo el cuánto fabricar. Esto último es ejercido directamente
 por los directores
 propietarios de la compañía, quienes ponen especial énfasis en entender las necesidades de los clientes
 y en realizar el
 control de calidad para asegurar que lo producido satisfaga lo que el cliente anhela. Así mismo,
 el crecimiento no está
 entregado a los ejecutivos comerciales, ya que son los propios directores propietarios quienes deciden
 cuánto producir y
 dan el visto bueno para saber si un producto sale o no al mercado, dependiendo del alineamiento
 que tenga con los gustos
 y necesidades de los clientes. Con todo, Hermés solo incrementa su capacidad de
 producción en un máximo de 10%
 cada año, lo que supone una garantía de crecimiento sin abandonar ni los atributos esenciales
 de la marca, ni la
 motivación que moviliza a la compañía: seguir siendo un objeto de deseo para los consumidores
 que aman el real lujo.
 Los productos de Hermes se fabrican en su totalidad en sus “Ateliers Hermes” (talleres de
 trabajo Hermés), todos en
 Francia. Cada producto es fabricado integramente a mano por un solo artesano, lo que incrementa
 la percepción de
 calidad, de artesanía y de singularidad. El aura de exclusividad de la marca es esencial ya
 que no tiene la intención de
 presentarse como al alcance de todos. Nuevamente aquí aparecen los directores propietarios.
 Son ellos quienes
 seleccionan a los artesanos que pasarán a integrar la red de “artistas” que más tarde producirán
 las piezas que darán vida
 a las exclusivas colecciones. Literalmente, un trabajo hecho de detalles en el más propio
 sentido de la palabra.
 Como parte de su estrategia de marketing Hermes no colabora con celebridades para
 construir marca. Tampoco lanza
 ofertas ni promociones de productos. Las mismas colecciones de productos se venden en todo
 el mundo, y siempre con
 edición limitada y distribución acotada sólo a sus propias tiendas. La compañía introduce
 la “paciencia” como un
 principio muy fuerte de su marca. En lugar de hacer frente a la alta demanda subiendo
 el precio, como dictan las leyes
 del mercado, Hermes suple esa solución clásica por la lista de espera. En otras palabras,
 el exceso de demanda es parte
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 180

[pág. 181]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2024 | pregunta 2
 Convocatoria 2 | página original 418 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 de lo buscado lo que contribuye a hacer al producto aún más anhelado. Un ejemplo de esto último es el exclusivo bolso
 Birkin, el modelo más icónico de la empresa, cuyo precio oscila entre los 100 mil y los 300 mil dólares. Su producción
 es obra de solo un artesano (de entre los 7.000), demora dos meses en la confección de una unidad, y hay lista de
 espera
 de 18 meses para adquirir uno de ellos. Los interesados deben ser clientes de la marca desde hace años, de lo contrario
 no pueden comprarlo. Lo interesante además es que esta espera desvía la atención hacia otros productos del catálogo que
 sirven de “consuelo a la espera”, como carteras y cinturones mientras llega el anhelado bolso. Finalmente señalar que la
 publicidad es muy selectiva, con una inversión en televisión, medios impresos y videos en línea, cuidadosamente
 analizados y seleccionados utilizando el humor traducido en ingeniosas situaciones, para mostrar los productos.
 Los desafíos futuros para Hermés
 Hermés sabe del poder de su marca. Hoy en día, la compañía se encuentra en la encrucijada de cómo mantener los
 valores
 que le han dado el éxito, y al mismo tiempo lograr un mayor crecimiento sin entrar a ser masivo en el mercado del lujo
 y rentabilizando el activo que la marca le proporciona. La empresa es consciente que se ha desarrollado con éxito a lo
 largo del tiempo, siempre apegada a principios empresariales sólidos. Sin embargo, en los últimos años, se ha instalado
 un sentimiento de duda con respecto a las bondades de su estrategia para competir en un creciente y cada vez más
 competitivo mercado del lujo. Incluso se ha llegado a hablar de la “anti-estrategia” de Hermés, en alusión a que un
 planteamiento tan descabellado como el que tiene la compañía, desafía los parámetros tradicionales de la forma de
 competir en el mercado del lujo. Un conocido analista del sector del lujo lo verbalizó muy bien la semana pasada en
 Nueva York en una nota alusiva a la empresa aparecida en el prestigioso diario 7he New York Times: “No parece
 sostenible que Hermes pueda continuar aplicando una estrategia tan contradictoria con lo que el mercado hace,
 negándose a crecer como lo hacen la mayoría de las empresas en una industria. Su afán por hacerlo siempre en contra
 de lo que hacen otros grandes de la industria le está pasando la cuenta y cada vez la separa más de los sólidos principios
 de una buena estrategia competitiva”.
 Preguntas:
 1. Conrespecto a la estrategia de Hermés, ¿Diría Ud. que crea valor? ¿Diría que captura valor? Para cada pregunta
 explique por qué Sí o por qué No.
 2. No cabe duda que Hermés tiene ventaja competitiva. ¿Cuál es la core competence o complementariedades
 estratégicas que hacen realidad la materialización de dicha ventaja competitiva? Señale de la forma más clara
 posible, los elementos que la conforman y la manera en cómo ellos se interrelacionan entre sí.
 3. ¿Es sostenible la estrategia de Hermés? ¿Qué riesgos existen a la sostenibilidad de dicha estrategia?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 181

[pág. 182]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2025 | pregunta 2
 Convocatoria 2 | página original 441 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N%2
 Nubank: la gigante Fintech de Servicios Bancarios
 Nubank, es una plataforma de servicios financieros 100% digital, sin sucursales físicas, fundada
 en 2013 en Sáo
 Paulo, Brasil, y es reconocida como uno de los bancos digitales más grandes del mundo.
 Conocida como Nu, ha
 revolucionado la industria financiera en América Latina en base a tecnología e innovación,
 ofreciendo todos sus
 servicios a través de una aplicación móvil intuitiva y fácil de usar lo que le permite
 operar con costos mucho
 más bajos que los bancos tradicionales y ofrecer productos sin comisiones o con tarifas
 muy reducidas,
 generando gran lealtad entre sus clientes. Sus objetivos son ambiciosos: luchar contra la burocracia,
 las altas
 comisiones y el mal servicio de la banca tradicional.
 Nubank cuenta con más de 118 millones de clientes en Brasil, México y Colombia, poco
 más de 98 millones son
 usuarios activos cada mes. Conocedores de la industria señalan que más allá de la tecnología,
 el principal activo
 estratégico de Nubank, son los millones de clientes que posee.
 La compañía ha tenido un crecimiento vertiginoso con un total enfoque en el cliente, ejecutando un modelo
 de
 negocio que a juicio de entendidos es fácilmente escalable a volúmenes mayores. Sus decisiones se basan
 en
 analizar grandes cantidades de datos provenientes del feedback de los clientes. Lo anterior ha permitido
 que
 Nubank se posicione como una de las empresas más valiosas e innovadoras de América Latina. Con
 el tiempo,
 la compañía ha ido ampliando su oferta de productos y servicios más allá de su tarjeta de crédito
 inicial,
 convirtiéndose en una plataforma financiera integral. En el primer trimestre de 2025, su beneficio
 neto creció un
 74% (respecto del primer trimestre del año anterior), alcanzando los 557 millones de dólares.
 La compañía se ha enfocado y seguirá haciéndolo, en Jóvenes no bancarizados, un segmento
 de cliente
 desatendido por los bancos tradicionales por considerarlos poco rentables. Nubank vio en ellos una
 oportunidad,
 construyendo un completo portafolio de productos financieros para su mercado objetivo.
 Los principales
 productos / negocios con que hoy en día cuenta Nubank son: Tarjeta de Crédito Nu, Cuenta Digital
 Nu (Cuenta
 de Débito), Cajitas Nubank (para separar dinero para objetivos de ahorro específicos), Préstamos
 Personales, e
 Inversiones. Todos son productos de bajo costo, creados, construidos e inspirados pensando en
 el segmento
 objetivo.
 El sector de Telecomunicaciones en Brasil capturó la mirada de Nubank
 Es un sector muy competitivo, con alto nivel de concentración y con una segmentación más
 bien clásica:
 empresas versus personas, y dentro de estas últimas, de prepago y post pago. El mercado de
 prepago, donde
 normalmente habitan los jóvenes, es mirado como un segmento más bien marginal por su baja rentabilidad.
 Las redes de comunicación están concentradas en pocos actores de la industria, y son propiedad
 de los
 competidores más grandes, quienes ocupan una parte de la capacidad de dichas redes. Esto permite
 que en el
 mercado operen empresas más pequeñas, sin infraestructura tecnológica (sin antenas),
 pero que arriendan
 espacio disponible en el mercado.
 El ingreso de Nubank al negocio de telefonía móvil
 Nubank señala que está ampliando su presencia más allá del sector financiero con la entrada en servicios móviles
 (NuCel), con foco en su mismo segmento objetivo, y una oferta adaptada a sus necesidades. Lo
 anterior permite
 también lograr mejoras en la gestión de pagos del cliente al contar con la aplicación móvil para pagar,
 lo cual
 refuerza su posición como líder Fintech en América Latina. Con esta estrategia espera
 convertirse en un
 proveedor de servicios esenciales, no solo financieros, sino también de conectividad, entre otros,
 lo que refuerza
 la fidelización del cliente.
 En el negocio de telefonía móvil, NuCel ofrece diferentes tipos de productos, todos a precios
 muy competitivos
 y con diseños pensados en su segmento objetivo. El pago se carga a la tarjeta de crédito
 de Nubank y todos los
 planes incluyen un paquete de voz ilimitado para llamadas locales y de larga distancia, y WhatsApp
 ilimitado,
 incluyendo llamadas de voz y vídeo.
 Con lo anterior, Nubank entra a competir directamente con los operadores tradicionales
 de telefonía móvil en
 Brasil, amenazando con captar una parte del negocio por medio de ofrecer una alternativa
 digital, ágil, de bajo
 4
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 182

[pág. 183]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2025 | pregunta 2
 Convocatoria 2 | página original 442 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Costo, y con beneficios exclusivos pensados y adaptados a los segmentos
 objetivos de clientes. De hecho, Nubank
 planea expandir NuCel a nivel regional en varios países de sudamérica.
 NuCel actúa como operador de móviles de forma virtual, lo que le permite
 ofrecer servicios sin necesidad de
 grandes inversiones en redes de telecomunicaciones, arrendando capacidad a competidor
 es establecidos. De
 hecho, Nubank no poseería redes de comunicación propia, sino que utilizaría,
 vía contrato de arriendos, la
 capacidad excedentaria en las redes existentes que son propiedad de los
 grandes actores de la industria.
 Evidentemente que este modelo no está exento de riesgos, ya que se debe garantizar
 la estabilidad y calidad del
 servicio para competir con los operadores tradicionales, además de enfrentar
 las regulaciones del sector de
 telecomunicaciones, que suelen ser más estrictas que las del sector financiero.
 También existe la incertidumbre
 sobre la rentabilidad a largo plazo de estos servicios, especialmente en mercados con
 alta competencia.
 Con el negocio de telefonía celular, Nubank espera además mejorar su capacidad de recolección
 de datos lo que
 se vería enriquecido con el servicio móvil activo. Medidas así permitirán a Nubank potenciar
 algoritmos para la
 evaluación de créditos, ofertas personalizadas y desarrollo de productos más precisos.
 Las dudas que genera la estrategia corporativa de Nubank
 Diversos analistas han planteado dudas acerca de la estrategia corporativa que está
 implementando Nubank. No
 está claro si con el modelo que desea implementar podrá llegar a ser un actor relevante
 en la industria de las
 telecomunicaciones. Tampoco se sabe cuál será la reacción que tendrán los competidor
 es existentes en la
 industria de las telecomunicaciones. En lo que si hay acuerdo es que el éxito
 de Nubank en su estrategia
 corporativa dependerá de la innovación que le imprima a su negocio.
 Preguntas:
 1. ¿Por qué razón podría decirse que existe un Modelo de Negocio Corporativo de
 Nubank? ¿Cuáles serían
 los principales elementos de este modelo de negocio corporativo?
 2. ¿Qué elementos específicos del caso podrían permitir afirmar que la estrategia
 corporativa que está
 implementando Nubank podría ser exitosa? Señale dos. ¿Qué elementos
 específicos del caso podrían
 permitir afirmar que la estrategia corporativa que está implementando Nubank podría No
 ser exitosa? Señale
 dos.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 183

[pág. 184]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2026 | pregunta 1
 Convocatoria 1 | página original 452 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N"1
 En un informe de 2019 desarrollado por una empresa consultora internacional se explicaba un proceso de adquisición
 de una empresa por parte de otra en el mercado del transporte de buses interurbanos en Alemania. A continuación se
 presenta un extracto de dicho informe: “En 2016, el mayor operador de transporte de buses interurbanos de Alemania,
 Flixbus cuya participación alcanzaba el 80% del mercado total, adquirió al segundo operador del país, Postbus que
 mantenía un 15% del mercado nacional y operaba una serie de rutas fuera de la región norte de Alemania. Tanto antes
 como con posterioridad a la adquisición Flixbus era el único operador en la región norte de Alemania, tradicionalmente
 la más rentable.”
 Este informe fue el resultado del análisis de más de 6.000 rutas en el norte de Alemania. El informe identificó que tras
 la adquisición, Flixbus redujo su número de terminales y paraderos propios, lo que implicó también reducir el número
 total de rutas activas en el norte de Alemania. Flixbus también redujo la frecuencia promedio de servicios por ruta en
 esa región. Al mismo tiempo, la compañía alemana decidió aplicar una leve baja en los precios por trayecto, de manera
 de compensar los inconvenientes que la reducción de sus servicios podría causar en los clientes.
 Mana de Alemacnia
 y Zora N dei País 1d da sa rIO
 uT
 TALISEANLE
 g Y
 = É
 En una de las entrevistas realizadas como parte del informe, se capturó también las opiniones de diversos ejecutivos de
 Flixbus y la industria. En uno de estos testimonios, un gerente regional de Flixbus lo resumía así: “Sabíamos que menos
 rutas y frecuencia implicaba un costo para el cliente. Por ello decidimos aplicar una pequeña reducción de nuestras
 tarifas por viaje de modo que la demanda no se resintiera.”
 La siguiente tabla es parte de la información contenida en el informe antes mencionado, el cual resume algunos
 indicadores relevantes antes y después de la adquisición.
 Evolución de la red y precios - Norte de Alemania
 Indicador 2015 (pre-adquisición) |2017 (post-adquisición)
 Rutas activas 1.240 980
 Frecuencia promedio semanal (por ruta) 9,2 6,8
 Precio promedio por trayecto (€) 18,4 17,6
 Ocupación promedio (%) 7% 84%
 La operación de adquisición fue aprobada por las autoridades de competencia alemanas bajo el argumento de que el
 mercado seguía siendo contestable y que la presión competitiva provenía, en parte, del transporte aéreo, ferroviario y
 del automóvil privado, ampliamente extendidos en el país.
 »
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 184

[pág. 185]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2026 | pregunta 1
 Convocatoria 1 | página original 453 | Industria/competencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Se pide responder:
 1. En relación con la situación de FlixBus en Alemania, un analista de la industria señalaba que: “no entiendo la lógica
 del cambio de estrategia de FlixBus. Antes de la adquisición de Postbus, la empresa FlixBus mantenía un gran
 número de paraderos propios y un importante número de rutas, alta frecuencia y precios en el promedio de las tarifas
 a nivel nacional. Sin embargo, luego de la adquisición de Postbus, Flixbus disminuyó el número de rutas, y entregó
 una menor frecuencia de viajes en la zona norte del país en donde seguía siendo el único operador de servicios de
 buses interurbanos.”
 En su calidad de experto(a), habiendo conocido las medidas adoptadas por Flixbus de manera posterior a la
 adquisición de Postbus (reducción de terminales, paraderos, rutas y frecuencias y leve disminución de precios),
 ¿CÓMO explica la estrategia competitiva de Flixbus antes de esta adquisición?
 FlixBus no sólo se ha expandido en Alemania sino también a otros países. De hecho FlixBus ha decidido ingresar al
 mercado chileno, aunque ha descartado comprar alguna empresa local ya que debido a su agresiva política de
 expansión internacional no cuenta con caja ni financiamiento adicional para adquirir alguna compañía de buses en
 Chile. En nuestro país, el mercado de buses presenta una alta concentración y es dominado por la empresa Turbus,
 que alcanza un 55% del mercado con rutas en las principales zonas del país.
 En el último directorio de Turbus varios asistentes manifestaron su temor por la entrada al mercado chileno de la
 empresa de buses alemana. Sin embargo, la discusión no solo quedó en el diagnóstico, sino que se elaboraron tres
 medidas para disuadir la entrada de Flixbus al mercado chileno. Las medidas propuestas eran las siguientes:
 a. Aumentar frecuencia de buses entre terminales, arrendando buses para dicho propósito.
 b. Invertir en campañas comunicacionales para reforzar el valor de la marca Turbus.
 C. Aumentar inversión en terminales y paraderos propios para entregar un servicio más exclusivo a los pasajeros.
 Como experto(a) en dirección de empresas y estrategia de negocios se le pide que responda lo siguiente,
 fundamentando sus respuestas:
 2.1 ¿Qué criterios debería utilizar Turbus para evaluar la capacidad disuasiva frente a la entrada de Flixbus?
 2.2 Ordene de más a menos efectiva estas potenciales acciones en relación a su capacidad para disuadir la entrada
 de Flixbus a Chile. Discuta como estas medidas cumplen los criterios que usted incluyó en la Jetra a).
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 185

[pág. 186]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2019 | pregunta 4
 Convocatoria 1 | página original 284 | Integración Walmart-Cornershop
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N'4
 En un intento por incorporarse de lleno al mundo del comercio electrónico, la cadena de supermercados
 Walmart, compró recientemente el 100% de la compañía chilena de compra asistida con despacho a domicilio
 Cornershop por US$225 millones. La firma recién adquirida, se convierte entonces en una subsidiaria de
 Walmart.
 A través de la aplicación de Cornershop para smartphones y tablets, o desde su sitio web, los usuarios ingresan
 a supermercados como Jumbo, Líder o Unimarc, a farmacias, al Mundo del Vino, Dulcería Montolin,
 Chocolates Varsovienne, Alimentos Felipe Didier y otros comercios. El usuario o cliente, indica el comercio en
 donde desea realizar su compra y luego marca los productos que quiere comprar, lo cual genera una orden de
 compra para un “shopper” (comprador). Después de hacer su pedido y pagar online, el shopper irá al comercio
 señalado por el usuario y efectuará la compra por cuenta de éste.
 Si el shopper no encuentra algún producto, él llamará e indicará al cliente qué alternativas hay y si quiere que
 haga el cambio del producto que no se encuentra, por uno que esté disponible. Por ejemplo, es muy común el
 tipo de llamadas del shopper al cliente diciendo: “no hay mostaza Marca A, pero está la Marca B que vale $20
 más”. Entonces, a diferencia de empresas como Jumbo online, Telemercados u otros competidores o sustitutos,
 al cliente no le llegan productos cambiados sin avisarle. En este sentido, un experto de la industria afirma sobre
 Cornershop: “Eso es lo que lo hace tan atractivo. Es como que tú mismo fueses al supermercado, pero sin salir
 de tu casa. Habrá alguien eligiendo la fruta, una persona que dirá “esta manzana está fea” y simplemente tomará
 otra.”
 El mismo experto señalaba que: “Otra cosa que destaca a Comershop es que el pedido llega en horas, no días.
 O lo puedes agendar para recibirlo en un horario específico, por ejemplo, mañana entre las 9 y las 10 AM. El
 objetivo es fortalecer la entrega de los pedidos en la “última milla', nombre que recibe el paso final en la cadena
 de distribución de un pedido online, proporcionando una nueva y más conveniente forma de comprar para el
 consumidor."
 Por su parte, uno de los socios de Cornershop señalaba sobre su compañía que: “la principal diferencia de
 nuestra empresa con otras, es que nosotros estamos totalmente orientados por la tecnología. Estamos llenos de
 ingenieros de software y toda nuestra logística y operaciones son algoritmos. Esto a su vez, nos permite medir
 nuestras operaciones para ir cambiando y mejorando constantemente.”
 En relación a la reciente adquisición de Cornershop, el gerente general de Walmart, destacó que: “Estoy
 convencido de que la recién adquirida Cornershop debe ser administrada de manera integrada por Walmart. Es
 decir, como si ambas fueran una sola empresa. Creo que tanto el Directorio de Walmart, como su gerente general
 y el equipo ejecutivo deben tener la administración y control directo sobre Cornershop e integrar esta compañía
 al negocio de Walmart, compartiendo gerencias, activos, bases de datos y actividades de soporte. La
 administración de Cornershop por parte de Walmart en una sola gerencia potenciará las sinergias entre ambas
 empresas. Cornershop necesita nuestras tiendas para poder dar una última milla de excelencia a nuestros clientes
 y nosotros necesitamos a Cornershop para complementar nuestra propuesta no solamente de venta, sino para
 entregar un servicio completo al cliente.”
 Saliendo al paso de las opiniones del ejecutivo de Walmart, una importante analista del sector de retail online
 señalaba que: “Walmart y Cornershop deberían administrarse de manera separada, como dos compañías
 independientes. Walmart no debiera administrar de manera integrada su negocio de supermercados con el
 negocio de Comershop recién adquirido. Ello destruirá valor económico para Walmart. La administración
 integrada ignora que una serie de condiciones externas del entorno competitivo y también las características de
 cada una de las dos compañías involucradas en esta transacción, podrían llevar a que esta adquisición finalmente
 termine destruyendo valor económico.”
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 186

[pág. 187]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2019 | pregunta 4
 Convocatoria 1 | página original 285 | Integración Walmart-Cornershop
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTAS
 a) Frente a estas dos opiniones encontradas (administración integrada o independiente), el Directorio tiene
 dudas de cuál esquema de administración adoptar. En su calidad de experto, el Directorio le solicita a
 usted que mencione y describa la principal ventaja y la principal desventaja de la administración
 integrada de Cornershop por parte de Walmart, si lo que se pretende es crear valor económico con la
 adquisición recientemente realizada.
 b) Por otra parte, el mismo Directorio le pide que, considerando como supuesto un eventual escenario de
 administración integrada de Comershop por parte de Walmart, responda lo siguiente: ¿qué condiciones
 del entorno competitivo y/o factores internos de las propias compañías involucradas en esta operación
 (Walmart y Cornershop), podrían destruir el potencial valor económico de esta adquisición? Mencione
 y describa las dos condiciones y/o factores más importantes.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 187

[pág. 188]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2023 | pregunta 4
 Convocatoria 1 | página original 383 | Integración vertical Toyota
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 PREGUNTA Nº4
 En el mercado automotriz, existen importantes diferencias en la forma en que el público percibe la calidad de los
 automóviles en diferentes dimensiones. Por ejemplo, en la encuesta anual del año 2022 de la empresa internacional
 de estudios de mercado Consumer Reports aparece la empresa Toyota, de origen japonés, como aquella con los
 vehículos percibidos con mayor “confiabilidad” por los consumidores, quiénes mostraban un alto nivel de
 satisfacción tanto con esta marca, así como con cada uno de sus modelos. En el segundo lugar de preferencias en la
 variable confiabilidad se ubicaban dos empresas alemanas: BMW y Mercedes-Benz. A una cierta distancia, el tercer
 lugar lo ocupaban Ford y General Motors (GM).
 Un especialista de la industria de automóviles definía confiabilidad como:
 “La falta de problemas y fallas en el funcionamiento de su motor. Adicionalmente se entiende que un
 vehículo tiene un conjunto de piezas mecánicas y electrónicas que deben trabajar juntas como un
 sistema coherente e integrado. La confiabilidad consiste en diseñar ese conjunto de procesos y piezas
 de forma que se reduzcan al mínimo las posibles fallas.
 Para conseguir la confiabilidad una marca de autos tiene que desarrollar y aplicar su conocimientos
 y experiencia en el diseño, planificación de la producción, la elección correcta de materiales e
 innumerables pruebas de esfuerzo, de tests en carretera y miles de kilómetros en todo tipo de
 condiciones. Cuando llega el automóvil al concesionario de venta todas las piezas del vehículo,
 además de su motor, han debido ser puestas a prueba y validada su confiabilidad. Desde el primer
 tornillo del motor hasta el último resorte del asiento.”
 De hecho, el informe Consumer Reports tenía un capítulo especial en el que se transcribían testimonios de clientes
 que fueran representativos de un número significativo de ellos. En uno de estos comentarios, un dueño “histórico”
 de la marca nipona, indicaba que “un Toyota nunca te falla, cumple exactamente con la promesa que te hacen cuando
 uno va a la automotora y compra el auto”.
 Pero no todo es dulce para Toyota. Numerosos sitios de internet especializados en el sector automotriz orientados a
 púbicos de especialistas y expertos en la industria de automóviles, constataban que los autos Toyota traen
 equipamiento más básico y utilizan materiales más económicos que los vehículos de competidores como Ford y
 GM que tienen precios de venta al público de sus automóviles similares a los del fabricante japonés.
 La fabricación de automóviles
 Las distintas marcas de automóviles desarrollan básicamente las mismas etapas para la fabricación de su producto
 final, siendo las principales el diseño de un prototipo, el diseño completo del proceso de fabricación, producción
 del motor y partes y piezas del vehículo, ensamblaje, control de calidad, acabado y logística de abastecimiento y
 despacho. A su vez, todas las empresas fabricantes de automóviles implementan un alto grado de externalización
 (del orden de 70%-80%) de sus procesos y actividades, a través de proveedores especializados en cada una de las
 etapas de fabricación.
 Al mismo tiempo, sin embargo, se observan diferencias en la forma en que las marcas de automóviles llevan adelante
 dichas estrategias de externalización hacia proveedores de la industria. Es así como Toyota diseña internamente el
 proceso completo de sus operaciones de fabricación y logística y fabrican ellos mismos sus motores. En cambio,
 Ford y GM deciden externalizar la producción de motores y diseño de procesos a otras empresas ubicadas
 generalmente en otros países para lograr niveles de costos inferiores a los de sus competidores japoneses.
 La decisión a la que está enfrentada Toyota
 En el último Directorio de la compañía, uno de sus directores, muy sensible a los comentarios de los públicos
 especializados, reaccionó a lo señalado en los sitios expertos, solicitando revisar la conveniencia de continuar con
 la estrategia de diseñar internamente el proceso completo de sus operaciones de fabricación y logística y de fabricar
 ellos mismos sus motores, que hasta ahora la compañía ha venido llevando a cabo. La argumentación entregada por
 el director fue la siguiente:
 “No es posible seguir tolerando que se diga que los autos que produce Toyota tienen equipamiento
 más básico que otros competidores, y que utilizan materiales relativamente más básicos, pero al
 mismo precio de venta de los vehículos de nuestros competidores Ford y GM. Para evitar esa
 distorsión definitivamente debiéramos tener costos más competitivos e intensificar aun más nuestra
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 188

[pág. 189]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2023 | pregunta 4
 Convocatoria 1 | página original 384 | Integración vertical Toyota
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 estrategia de externalización, ampliándola hacia el diseño de los procesos de fabricación y la
 producción de los motores, y con ello lograr vender nuestros vehículos a un precio por debajo del de
 nuestros competidores”.
 En relación a lo señalado a usted se le pide que:
 a) Indique si le parece correcto o incorrecto para Toyota la propuesta del citado Director. Justifique su respuesta.
 Inmediatamente un segundo director salió al paso de su colega indicando que, “en principio, la mayor
 externalización de Toyota puede ser contraproducente para su estrategia competitiva. Sin embargo, puede haber
 características tanto en la industria de proveedores de componentes y servicios como en el mercado de vehículos a
 la venta, que harían deseable la ampliación y profundización de dicha externalización hacia todas nuestras
 actividades, manteniendo el nivel de diferenciación competitiva de Toyota frente a sus clientes.”
 En relación a lo señalado a usted se le pide que:
 b) Indique qué características en la industria de automóviles deberían existir de modo que el planteamiento del
 segundo director en cuanto a la ampliación y profundización de la externalización pueda ser adecuado para la
 posición competitiva de Toyota. Refiérase en particular a características en: (i) la intensidad de la competencia
 de proveedores y (ii) la intensidad de la competencia en el mercado final a clientes. Justifique su respuesta.
 Finalmente, un tercer director indicó que “si se decide una mayor externalización en todas nuestras actividades
 planteada por mi segundo colega, habría que considerar aspectos clave de nuestra gestión con nuestros proveedores
 externos si queremos mantener nuestro posicionamiento competitivo”.
 En relación a lo señalado a usted se le pide que:
 c) Indique una práctica clave de la gestión de Toyota con sus proveedores que permita mantener el posicionamiento
 competitivo de la empresa en el contexto de una ampliación y profundización de la externalización. Justifique
 su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 189

[pág. 190]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2013 | pregunta 4
 Convocatoria 1 | página original 121 | Integración vertical/adquisición
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 PREGUNTA Nº 4
 La industria siderúrgica mundial (industria que produce acero) tiene actualmente un exceso de oferta y sigue creciendo.
 Las plantas de acero alrededor del mundo tienen una capacidad de producción de 1.800 millones de toneladas este año,
 mientras que los pedidos sólo llegan a los 1.500 millones de toneladas. Como se aprecia, en lugar de consolidarse y
 tratar de ser más eficientes, la industria está generando más capacidad. Sólo en China, país que representa el 46% de la
 producción mundial de acero, existen unas 800 plantas, y se prevé que en 2013 entren en operación en el mundo otras
 100, aportando unos 350 millones de toneladas adicionales.
 Como era de esperarse, el exceso de producción ha reducido los precios y los márgenes del acero y ha causado nuevos
 llamados en favor de la racionalización de la industria. Wolfang Eder, presidente de Eurofer, la asociación de
 siderúrgicas europeas, estima que las compañías acereras europeas deben reducir la capacidad instalada por lo menos
 en un 25%.
 Los gobiernos, casi sin excepción, y a diferencia de lo que ocurre en otras industrias, han respaldado el surgimiento de
 plantas de acero, ya sea nacionalizando la producción o bien comprando empresas que amenazan ser cerradas. Así, hay
 varios ejemplo de gobiernos que han invertido y siguen invirtiendo en plantas de acero que posteriormente no pueden
 vender, perpetuando empresas ineficientes y artificialmente sostenidas. Por otro lado, la caída en los precios de las
 materias primas y de las acciones de empresas siderúrgicas, tampoco incentiva la realización de fusiones que podrían
 hacer más eficiente la producción. Para ilustrar esto último, considérese que solo entre el 2011 y 2012 los acuerdos de
 fusión que estaban contemplados en el sector descendieron un 43% en valor.
 El Grupo CAP
 La Compañía de Acero del Pacífico S.A. (CAP) es un holding chileno diversificado e integrado verticalmente, que
 participa en tres negocios: (i) CAP Acero - (CSH), dedicado a la fabricación de acero en planchas y barras, realiza sus
 actividades a través de su filial, Compañía Siderúrgica Huachipato S.A. (CSH); (ii) CAP Minería - (CMP), desarrolla
 su negocio a través de la Compañía Minera del Pacífico (CMP) y sus filiales, siendo el mayor productor de minerales
 de hierro y pellets en la costa del Pacífico. En la actualidad CMP opera al 50% de la capacidad potencial que tendría
 esta Unidad de Negocio en la medida que ejecutara algunas inversiones cuyo costo (de las nuevas inversiones) para
 CAP se ubica en los niveles promedio de la industria; y (iii) CAP Novacero, cuyo principal objetivo es la fabricación
 de tubos de acero, sistemas de construcción y el diseño de soluciones en acero principalmente para los sectores de la
 construcción, industria e infraestructura tanto en Chile como en el extranjero. A continuación se presenta información
 sintetizada de los distintos negocios de CAP:
 Negocio Capacidad % de la Venta % del Margen Bruto
 de Producción del Grupo CAP del Grupo CAP
 CAP Acero 1,45 mill de Toneladas 64% 2%
 CAP Minería 11,5 mill de Toneladas 19% 90%
 CAP Novacero 425 mil Toneladas 17% 8%
 El futuro de la Industria Siderúrgica
 Se espera que la industria siderúrgica mundial, que factura cerca de un billón (millón de millones) de dólares anuales,
 siga siendo la más fragmentada entre las grandes industrias. Las cinco mayores acereras controlan 18,2% del
 suministro global de acero. En cambio, las cinco principales automotrices dominan 50,6% del mercado global. "Las
 siderúrgicas necesitan a una empresa importante que compre plantas de mal desempeño para cerrarlas", afirma Tim
 Cahill, uno de los más importantes analistas del sector.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 190

[pág. 191]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2013 | pregunta 4
 Convocatoria 1 | página original 122 | Integración vertical/adquisición
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 Responda las siguientes preguntas:
 1. Al final del caso se afirma: "Las siderúrgicas necesitan a una empresa importante que compre plantas de mal
 desempeño para cerrarlas". ¿Bajo qué condiciones un competidor que actualmente esté instalado en la industria
 del acero haría lo anterior? Sea preciso. (Si le ayuda formular alguna ecuación que modele su respuesta, hágalo y
 explique).
 2. Bajo el contexto que vive la industria según se describe en el caso, ¿Qué efectividad piensa Ud. que tendría una
 medida como la propuesta por Tim Cahill, para levantar la alicaída industria del acero? ¿Alta, Baja, Ninguna?
 ¿Por qué?
 3. En la última reunión de Directorio de CAP, uno de sus ejecutivos planteó que la empresa debería aprovechar las
 oportunidades de precios de compañías que se presentan en el sector del acero, y comprar empresas que
 actualmente existen. Desde el punto de vista del análisis estratégico, ¿le parece que el Directorio debería aceptar
 esta sugerencia? ¿Por qué sí o por qué no?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 191

[pág. 192]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2016 | pregunta 4
 Convocatoria 2 | página original 213 | Integración y economías de alcance
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 4
 Como ha ocurrido en gran parte de los países del mundo, el desarrolio de los Malls y Centros Comerciales ha
 sido la tónica en los últimos años. En Latinoamérica cada vez se aprecia una mayor profundidad en el desarrollo
 de este tipo de comercio. El mercado ecuatoriano no ha sido la excepción a esta tendencia.
 Grupo Real
 Desde hace más de 15 años el protagonista principal en el sector de los Malls y Centros Comerciales en Ecuador
 ha sido Grupo Real, una compañía internacional, fundada hace 70 años, y que opera centros comerciales en
 Ecuador, Perú, Colombia y Venezuela. Su principal giro es el desarrollo, comercialización y operación de
 centros comerciales. Ello se materializa a través de ofrecer locales comerciales principalmente en arriendo, y
 unos pocos que se ofrecen en venta.
 En Ecuador, Grupo Real tiene 8 centros comerciales, los cuales representan un millón de metros cuadrados
 construidos. Es uno de los cinco principales actores en la industria latinoamericana y el número uno en Ecuador.
 Grupo Real opera bajo estrictas normas de seguridad y está ubicado en las principales ciudades del país.
 La Industria de Centros Comerciales en Ecuador y su Modelo de Negocio
 Es una industria que ha venido creciendo sistemáticamente durante los últimos 5 años. A los centros comerciales
 ya establecidos, se han ido agregando nuevos malls de distintos tipos, tamaños y público objetivo, los cuales
 buscan llenar las expectativas de los diferentes segmentos de consumidores que hay en el país. A este
 crecimiento han contribuido factores como la seguridad que brindan los centros comerciales, lo que permite que
 sean lugares de esparcimiento, diversión y compras.
 Un centro comercial recibe ingresos por múltiples actividades que realiza. Su principal fuente de ingresos es el
 arriendo de locales comerciales, valor que se compone de una tarifa fija de arriendo (un valor cobrado por metro
 cuadrado de superficie arrendada en el local comercial), más una tarifa variable calculada como un porcentaje
 de las ventas del local. Para la tarifa variable, en cualquier mall, a los locales pequeños, que son los de menor
 venta, se les cobra una tasa porcentual que fluctúa entre el 10% y el 12% de las ventas mensuales del local; a
 los medianos, entre el 5% y el 8% de las ventas mensuales; y a los de mayor tamaño, entre el 1% y el 3%. Las
 grandes casas comerciales pagan por lo general el 0,5% de las ventas mensuales como renta porcentual,
 En términos relativos, la parte fija del ingreso por arriendo representa por lo general un 60% del total de estos
 ingresos por arriendo, mientras que la variable representa el 40% restante. De esta forma, la gestión comercial
 del mall se orienta a no tener vacancia de locales arrendables, a preocuparse por generar el mayor tráfico posible
 al interior del mall, lo que incide directamente en la vacancia, y a obtener la mayor compra promedio en cada
 local del mall de manera que se genere mucha venta para el local y así el mall tenga un atractivo ingreso
 porcentual en la parte variable del cobro por arriendo.
 También un mall recibe ingresos por una serie de otras actividades o negocios, como es el caso de la venta de
 publicidad, del estilo paletas publicitarias, en los pasillos interiores del mail, el cobro por el estacionamiento, y
 una serie de otras actividades menores.
 Cabe destacar que al interior del Grupo Real, los ingresos por publicidad interna en los propios malls que posee
 en Ecuador alcanzaron durante el año 2015 la cantidad de US$285.000, una cifra muy discreta sobretodo si se
 considera que representa menos del 2% de los ingresos obtenidos por el arriendo de locales en los mismos mallis.
 La Publicidad en los Malls del Grupo Real
 Cuando hablamos de publicidad en los malls, nos estamos refiriendo a la venta de publicidad en paletas
 publicitarias ubicadas en los pasillos interiores del mall y en algunos grandes letreros que se ubican en los
 exteriores del centro comercial. Este tipo de publicidad se utiliza exclusivamente por las propias empresas que
 operan y venden al interior del mall, para atraer a su tienda o casa comercial a aquellos clientes que se encuentran
 dentro del mall, Dada esta característica, en la publicidad interna del mall suelen avisarse ofertas, liquidaciones
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 192

[pág. 193]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2016 | pregunta 4
 Convocatoria 2 | página original 215 | Integración y economías de alcance
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 10
 o ganchos comerciales de tiendas específicas del mall para conducir al visitante que está en el centro comercial
 hacia un determinado local comercial,
 La publicidad al interior de los malls del Grupo Real en Ecuador, se realiza a través de la empresa ABC
 Publicidad, compañía externa independiente del Grupo Real. Con esta empresa, se tiene suscrito desde hace 3
 años un contrato para regular la relación comercial entre Grupo Real y ABC Publicidad. Las condiciones del
 contrato suscrito entre ambas partes son las siguientes:
 - Grupo Real recibe el 45% del valor de la venta de la publicidad, con un ingreso mínimo garantizado de US$
 250.000 anuales.
 - ABC Publicidad cobra al avisador una tarifa fija por letrero cuyo valor varía dependiendo del tamaño y de la
 ubicación del letrero en el mall.
 - Los espacios publicitarios privilegian las marcas anclas y los locales internos del centro comercial.
 - ABC Publicidad asume los costos de instalación, medidores y los costos operativos de energía eléctrica.
 El contrato con ABC Publicidad está bajo la responsabilidad de la Gerente de Marketing del Grupo Real, quien
 maneja un portafolio de contratos en donde el suscrito con ABC Publicidad representa sólo un 10% del total de
 negocios que están bajo su responsabilidad.
 Voces de Alerta en el Directorio
 Después de tres años de vigencia del contrato con ABC Publicidad, la dirección de Grupo Real no está contenta
 con los resultados del mismo, y se han generado opiniones muy diversas que están complicando al Directorio.
 “En estos tres años hemos bordeado los US$ 285.000 en ingresos por publicidad, lo que nos acerca el nivel
 mínimo de ingresos garantizados (US$ 250.000) que contempla el contrato, y pienso que hay elementos que
 muestran que debiéramos haber sido mucho más exitosos desde el punto de vista financiero con la publicidad
 vendida”, señalaba el Gerente de Administración y Finanzas del Grupo Real en el último Directorio. Otro de
 los gerentes apuntaba directamente al contrato de arriendo: “El contrato está mal diseñado a nuestros intereses
 ya que nos llevamos una parte del negocio muy poco significativa en relación con muestro real aporte”.
 Pareciera ser que el Directorio debía tomar cartas en el asunto.
 PREGUNTAS
 Considerando sólo la información contenida en este caso, responda las preguntas que se le formulan a
 continuación:
 1. Enelúltimo comentario que se señala en el caso, uno de los gerentes del Grupo Real sostiene: “El contrato
 está mal diseñado a nuestros intereses ya que nos llevamos una parte del negocio muy poco significativa
 en relación con nuestro real aporte”. Desde un punto de vista estratégico, ¿cómo explicaría Ud. el bajo
 resultado para el Grupo Real que hoy muestra el negocio de publicidad al interior de sus malls? Señale dos
 posibles causas de este bajo resultado. Sea breve y preciso en su respuesta.
 2. Desde un punto de vista estratégico del Grupo Real, ¿debiera la publicidad en los malis gestionarse con una
 empresa externa del tipo ABC Publicidad, o debiera manejarse internamente en el Grupo Real? Defimna con
 claridad su posición y arguméntela adecuadamente.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 193

[pág. 194]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2017 | pregunta 4
 Convocatoria 2 | página original 246 | M&A y sinergias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N" 4
 Unilever en la mira de 3G Capital -
 Si la fusión hubiera resultado, habría sido la segunda empresa de alimentos más grande del mundo, solo superada
 por Nestlé. Por un lado estaba Unilever y por el otro los brasileños de la firma de inversión privada 3G Capital
 en alianza con el millonario Warren Bufíett.
 Unilever es una compañía anglo - holandesa dueña de marcas líderes en diferentes industrias. Sólo por nombrar
 algunas: Omo y Drive en el mercado de los detergentes; Dove en higiene y cuidado personal; Bresler en el
 mercado de los helados, que además es el mayor fabricante de helados del mundo; Hellmann*s en mayonesas;
 y Knorr en sopas y condimentos. A éstas, hay que sumar una gran variedad de otras marcas que lideran sus
 respectivas industrias en Estados Unidos y en otros países del mundo.
 La compañía 3G Capital es un fondo de inversión privado con sede en Brasil, que a través de audaces
 adquisiciones hoy controla empresas muy importantes en diferentes industrias como Lojas Americanas, Kraft
 Heinz, Burger King y el imperio cervecero AB Inbev con marcas como Miller.
 Fue a mediados de febrero de este año, cuando 3G Capital en alianza con Warren Buffett hicieron llegar una
 oferta al directorio de Unilever de US$50 por acción (un premio de 18% sobre el precio de mercado), para
 fusionar ambas compañías. La oferta, que totalizaba US$143 billones de dólares, fue rechazada — en palabras de
 Paul Polman, el Gerente General de Unilever — “por no tener justificación financiera ni estratégica”. Los
 potenciales compradores decidieron “retirar amigablemente” su oferta, dada la hostilidad del directorio de
 Unilever y las críticas desde el ámbito político.
 Dos visiones en disputa
 “Lo que estaba en juego no era meramente una operación bursátil, sino que dos visiones empresariales muy
 diferentes” señalaba Paul Polman.
 Paul Polman es conocido por haber priorizado la responsabilidad social empresarial (RSE) y la sustentabilidad
 de los resultados en los negocios de la firma anglo-holandesa realizando importantes inversiones para el cuidado
 del medio ambiente y las relaciones comunitarias con clientes y con sus stakeholders en general. De hecho, en
 un elogioso artículo en la revista Harvard Business Review, hace un par de años lo bautizaron como el “Capitán
 Planeta” del sector empresarial por su estrategia de crecimiento sostenible, orientada entre otras medidas de
 responsabilidad social empresarial, a reducir la huella de carbono y mejorar el impacto social en las comunidades
 a través del “Plan de Sustentabilidad de Unilever”. Todas estas medidas han posibilitado a Unilever cobrar
 precios levemente superiorés a los de su competencia.
 La visión de Buffett y sus socios de 3G Capital, por su parte, era muy distinta. Ellos eran conocidos por la
 aplicación de eficiencia operacional y la búsqueda de prodnctividades no logradas por las empresas. Luego de
 un análisis detallado de los principales procesos de la cadena de valor, estimaban costos según benchmarks (o
 estándares de referencia) reconocidos. Sín cambiar necesariamente de estrategia (diferenciación o costos), e
 independientemente de la estrategía con que compitiera la compañía, se establecían brechas de costos y se
 formulaban planes de reducción y de eficiencia de manera de llevar a la compañía a niveles comparables con
 los principales competidores de referencia, incluso muchas veces superándolos y estableciendo nuevos
 estándares en la industria. A modo de ejemplo, hace algún tiempo, Buffett y 3G generaron la fusión por US$ 55
 billones de dólares entre Heinz y Kraft, prometiendo rebajas de US$1.500 millones en los costos anuales antes
 — de 2017. Previo a esta fusión, el flujo de caja operacional de la compañía bordeaba el 20% de los ingresos. Al
 poco tiempo de efectuada la fusión, el nuevo flujo de caja operacional combinado superaba el 35% de los
 ingresos combinados, logrando rebajas efectivas de costos mayores a los US$ 1.800 millones, un 20% más de
 lo que inicialmente se había estimado. -
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 194

[pág. 195]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2017 | pregunta 4
 Convocatoria 2 | página original 247 | M&A y sinergias
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Reacciones
 Sobre lo que se esperaba, el precio de la acción de Unilever subió 28% - a un nivel record - cuando se conoció
 la oferta de 3G y Buffett, y cayó posteriormente en un 10% cuando ésta fue rechazada.! Pero las cosas no
 terminaron ahí.
 Ánte la presión de los accionistas, Polman anunció que la frustrada fusión y las motivaciones que le dieron
 origen en febrero recién pasado, “subrayaban la necesidad de capturar el valor que vemos en Unilever, razón
 por la cual se efectuaría uma profunda revisión estratégica de los negocios y de los procesos de la compañía,
 de manera de capturar eficiencias que hoy en día están al alcance de la empresa”. De esta forma, Polman
 estructuró un ambicioso plan de recortes de gastos prescindibles, unido al rediseño de procesos y a importantes
 mejoras en la productividad, de manera de elevar sustancialmente los niveles de caja operacional generada. Y
 aparentemente los números le daban la razón a Polman, ya que en un indicador crucial, como es el costo de
 ventas, un competidor directo de Unilever, como Kraft, mostraba un nivel que era la mitad del costo de ventas
 que exhibía el negocio comparable en Unilever,
 Los cálculos de 3G y Buffett eran auspiciosos. Ellos estimaban que reduciendo los costos de ventas de Unilever
 en un tercio, Kraft pagaba el precio de adquisición ofrecido por Unilever. Con estos múmeros, medios británicos
 especulaban que 3G y Buffett podrían volver a la carga en seis meses más, dada la legislación sobre Fusiones y
 Adquisiciones, y los altos diferenciales de márgenes existentes entre las compañías.
 PREGUNTAS
 1. Tal como se expone en el caso, Paul Polman, Gerente General de Unilever, señalaba que el fracaso de la
 oferta de 3G y Buffett se explicaba "por no tener justificación financiera ni estratégica". ¿Le parece
 correcto este comentario toda vez que el precio de la acción aumenta en un 28% conocida la posible fusión,
 y luego baja sólo un 10% cuando se anuncia su fracaso? Sea específico señalando dos posible razones
 concretas que pueden ayudar a fundamentar su respuesta.
 2. Un destacado analista de los sectores en donde compite Unilever escribió en una columna de opinión: "el
 nuevo plan que Paul Polman pretende implementar (contenido en el penúltimo párrafo del Caso), viene a
 complementar lo que hasta ahora ha venido realizando Unilever, y bajo ninguna circunstancia puede verse
 como algo contradictorio o como una visión diferente en relación con lo que ha hecho la empresa hasta
 ahora". Sin embargo, Polman opina que son "dos visiones de negocio muy diferentes". ¿Quién tiene la
 razón: Polman o el analista? ¿Por qué? (Ayuda: en su respuesta no olvide cuál es el verdadero propósito de
 una estrategia competitiva para una empresa).
 1 Por ejemplo, si el precio de la acción de Unilever era de $100 antes del anuncio de la potencial fusión, éste subió a
 $128 con el anuncio y posteriormente cayó a $ 115,2 (un 10% menos de $128) cuando la fusión fue rechazada.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 195

[pág. 196]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2019 | pregunta 4
 Convocatoria 2 | página original 296 | Modelo de alianza/plataforma
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N'4
 “Falabella vende Viajes Falabella a Despegar”
 El pasado lunes 15 de abril de 2019, Falabella anunció la venta de su negocio Viajes Falabella a Despegar.
 Operación que incluye una alianza comercial por 10 años”.
 Falabella realizó un cambio radical en su negocio de viajes al cerrar un acuerdo con Despegar, el mayor actor
 online en este rubro en Latinoamérica. El acuerdo contempla la venta del 100% del negocio “Viajes Falabella”
 en las operaciones de Chile, Colombia, Perú y Argentina, más Ja licencia por el uso de la marca “Viajes
 Falabella”, todo en US$ 27 millones. La operación implicará la salida de Falabella de la operación turística
 directa, pasando a ser parte de una alianza comercial por diez años con Despegar, por medio de la cual Falabella
 profundizará su oferta de productos financieros asociados al negocio turístico, El acuerdo también contempla
 la posibilidad de ampliar la asociación entre ambas empresas hacia otros mercados en donde operan ambas
 firmas. -
 Despegar (antiguamente Despegar.com), es una agencia de viajes que opera exclusivamente online con sede
 en Argentina. Cuenta con presencia en 21 países y es la agencia de viajes.más grande de América Latina en
 volumen de transacciones.
 Falabella, por su parte, es uno de los más importantes holding empresariales latinoamericanos. Opera y
 gestiona un portafolio de negocios amplio, compuesto por varias unidades de negocio, entre ellas Viajes
 Falabella y Falabella Financiero, entre varios otros negocios (multitienda, centros comerciales, seguros,
 supermercados, etc). A Falabella Financiero pertenece CMR, la tarjeta de crédito y débito que constituye un
 producto esencial de su negocio financiero, En el negocio de multitienda (tiendas por departamentos), Falabella
 mantiene operaciones en Chile, Argentina, Perú, Colombia, entre otros países, llegando con sus negocios a
 millones de personas, las cuales presentan altos niveles de lealtad con marca. La empresa posee un sólido
 posicionamiento en los diferentes mercados en donde compite, lo que es producto de un amplio y activo
 despliegue comercial en los diferentes mercados en donde participa. Así mismo, Falabella gestiona diversos
 canales, entre ellos un creciente canal online para la venta de sus productos, el cual ha ido creciendo
 sistemáticamente en los últimos años, siendo hoy en día un canal muy relevante dentro de la estrategia
 comercial de la empresa.
 Desde sus inicios, Viajes Falabella desarrolló el negocio de viajes operando principalmente desde las propias
 tiendas de Falabella con una oferta orientada esencialmente a los clientes de la multitienda. En 2018, Viajes
 Falabella registró ingresos por US$ 50 millones, de los cuales un 65% se debió a la venta de paquetes turísticos.
 En el mismo período, Viajes Falabella obtuvo un EBITDA (utilidad antes de intereses, impuestos,
 depreciaciones y amortizaciones) por aproximadamente US$ 3,5 millones.
 Dado que la transacción tiene por delante las aprobaciones de las autoridades de libre competencia de los
 países involucrados, las partes esperan contar con luz verde durante el segundo semestre de este año.
 El Acuerdo
 Las compañías acordaron mantener la marca “Viajes Falabella” que será comercializada a través de Despegar,
 al igual que las plataformas digitales y redes de tiendas físicas, base desde la cual Despegar potenciará sus
 productos y servicios en viajes y turismo. Por su parte, Falabella Financiero aportará con sus capacidades de
 procesamiento de pagos, financiamiento y el programa de lealtad más reconocido de la región, mejorando la
 oferta y la experiencia digital con su programa CMR puntos.
 Como primera acción, se espera que se enfatice el uso de CMR como medio de pago. Por ejemplo, todas las
 ventas que se realicen con CMR en Despegar tendrán acceso a doble acumulación de puntos. Además, los
 puntos CMR se podrán canjear en el sitio de Viajes Falabella, en el sitio de Despegar, en los Call Centers y/o
 en las sucursales de Viajes Falabella, todos canales que serán operados por el equipo de Despegar,
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 196

[pág. 197]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2019 | pregunta 4
 Convocatoria 2 | página original 297 | Modelo de alianza/plataforma
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 manteniéndose los puntos de venta dentro de las tiendas de la casa comercial. Adicionalmente, los clientes de
 Falabella podrán acceder a promociones exclusivas desarrolladas por Despegar.
 Un alto ejecutivo de Despegar señalaba en una reciente entrevista: “Estamos adquiriendo una empresa con un
 trayectoria exitosa y atractivas oportunidades de crecimiento, completamente alineada con nuestra estrategia
 de enfocarnos en paquetes, hoteles y otros productos de viajes, La alianza comercial nos permitirá fortalecer
 nuestra oferta de financiamiento para nuestros productos. Nos permite adquirir capacidades y es una
 oportunidad para potenciar los equipos de ambas compañías en las actividades que mejor desarrollan; Viajes
 Falabella es experto en la venta de paquetes turísticos, que es justamente donde Despegar busca seguir
 creciendo y enriqueciendo la propuesta de valor a los clientes de toda la región”.
 A su vez, por el Jado de Falabella, otro alto ejecutivo de esta compañía explicó: “La alianza permitirá integrar
 una mejor propuesta de valor a nuestro ecosistema digital, mejorando ampliamente la ojerta de viajes y la
 experiencia del programa CMR puntos, dando acceso a nuestros clientes al mejor contenido de productos
 turísticos del mercado ”. La compañía busca un modelo de atención omnicanal, esto es, incorpora los procesos
 de atención digital a sus canales físicos y viceversa,
 La Reacción del Mercado
 Conocida la noticia de esta operación, las reacciones no se hicieron esperar. Algunos analistas de la industria
 celebraban efusivamente la transacción, mientras que otros se mostraban cautos y expectantes, La reacción
 que no demoró fue la del mercado financiero, Las bolsas donde transan Falabella y Despegar mostraron al día
 siguiente, comportamientos disímiles, pese a ser la misma operación. En efecto, las acciones de Falabella
 subieron un tímido 0,2%, mientras que las de Despegar, la empresa compradora, lo hicieron con fuerza,
 empinándose un 8% más que al cierre de la jornada anterior, cuando aúm no se conocía la transacción.
 Responda las siguientes preguntas en base al caso “Venta de Viajes Falabella a Despegar” y sólo utilizando la
 información que se desprende del caso
 a) ¿Cómo cambia el modelo de negocios de Viajes Falabella comparando la situación inicial antes de la
 venta a Despegar, versus la situación post venta a Despegar? Señale y explique al menos tres cambios
 a nivel del modelo de negocio de Viajes Falabella.
 b) Utilizando sus conocimientos de estrategía, ¿cómo se pueden interpretar las disímiles reacciones del
 mercado en relación a uno y otro caso, para una misma transacción? Se pide que su interpretación no
 sea sólo conceptual, sino también específica y concreta aplicada a la situación del caso.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 197

[pág. 198]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | marzo 2011 | pregunta 2
 Convocatoria 1 | página original 60 | Modelo de negocio y ventaja competitiva
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 4
 PREGUNTA Nº 2
 El martes 16 de noviembre, durante la mañana, los sitios webs de los principales diarios estadounidenses informaban que
 dos consultores del partido demócrata habían presentado una querella contra Arianna Huffington y Kenneth Lerer, los
 fundadores de la Compañía dueña de The Huffington Post, uno de los diarios electrónicos más influyentes del mundo.
 Los acusaban de haberles “robado la idea”. La verdad es que no era para menos, ya que en sólo cinco años, The
 Huffington Post se ha convertido en un modelo de referencia en cuanto a noticias en internet y en uno de los medios
 online más exitosos del mundo. “Este diario ha sido una revolución en esta industria” comentaba un destacado analista
 de medios refiriéndose a The Huffington Post.
 The Huffington Post tiene en la actualidad 180 empleados, congrega a 6 mil bloggers, tiene mas de 23 millones de
 visitantes al mes, y recibe 3,4 millones de “posteos” mensuales. El principal motor de este diario electrónico ha sido
 Arianna Huffington, su fundadora, quien saltó a la fama a comienzos de la década del 2000 cuando postuló como
 candidata independiente a la gobernación de California, enfrentando al mismísimo Arnold Schwarzenegger. No le fue
 bien a Arianna en la política, pero sí en los negocios. El diario electrónico que lleva su apellido comenzó a funcionar en
 mayo de 2005, y rápidamente revolucionó a los mayores medios mundiales de la prensa escrita, por su novedoso sistema
 de organización de la información, entre otras particularidades que posee.
 The Huffington Post funciona con un par de editores claves, además de “bloggers” y periodistas contratados, los cuales
 cubren y comentan las noticias, entregando además enlaces hacia artículos relacionados en otros medios. Los “bloggers”
 están compuestos por políticos, periodistas, escritores y actores, todos célebres, bien reconocidos e influyentes en sus
 campos de actuación. La idea es crear una plataforma informativa integral, que verdaderamente informe y genere
 discusión y opinión en la audiencia. Los lectores van abriendo los comentarios que sean de su interés, de manera que cada
 uno vaya construyendo su propio ámbito de información, de acuerdo a sus intereses y comentaristas favoritos. “Lo que
 buscamos es generar conversaciones como las que podríamos tener alrededor de una mesa, en lanzamientos de libros o
 en caminatas con amigos. Mientras mas conversaciones hayan, mas argumentos y puntos de vista habrán. Nuestro rol
 en The Huffington Post, es tomar todas estas conversaciones y crear un sitio global en donde la conversación se
 transforme en información en tiempo real, que le sirva a nuestro lector para formarse su propio punto de vista respecto a
 hechos de relevancia para la vida, los negocios y las personas. En otras palabras, buscamos interconexiones múltiples
 de nuestros lectores con diferentes medios e instancias de información, lo que constituye sin lugar a dudas un enorme
 valor agregado en relación a lo entregado por la prensa tradicional”, señalaba la fundadora en una entrevista
 recientemente aparecida.
 Otra de las particularidades de este exitoso diario está en la manera creativa y distinta en como plantea la publicidad. En
 efecto, en The Huffington Post no encontrará los típicos avisos laterales, pop-up (avisos que prenden y apagan) u otros
 del estilo. La publicidad es personalizada conforme al perfil de lector que en el diario se describa, el cual se va
 construyendo conforme a los artículos de interés que el mismo lector va abriendo. Evidentemente hay publicidad para
 todos los lectores, pero hay importantes avisos que van segmentados según el perfil del lector. Cuando es tiempo de la
 publicidad (cada cierto rato), se despliega sobre toda la pantalla del diario electrónico un verdadero comercial de la
 televisión, pero en la misma página del diario y a página completa. El lector tiene la posibilidad de eliminar el aviso si lo
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 198

[pág. 199]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | marzo 2011 | pregunta 2
 Convocatoria 1 | página original 61 | Modelo de negocio y ventaja competitiva
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 5
 desea para continuar con la lectura, o bien de esperar que la publicidad termine. Este esquema publicitario le ha valido a
 The Huffington Post no sólo ser reconocido como un influyente diario en el mundo, sino también, como uno de los que
 más creativamente muestra la publicidad en formatos online, lo que entre otras cosas le ha posibilitado implementar
 políticas de precios diferenciadas en publicidad según el modelo publicitario que se utilice (segmentado o no),
 optimizando así tanto el interés de los avisadores, como la recaudación financiera por este concepto.
 En 2006, un año después de la creación de The Huffington Post, Arianna dio uno de sus grandes golpes al ser incluida
 ella misma por primera vez en la lista de la revista Time, como una de las 100 personas más influyentes del planeta.
 Varios de quienes compartieron este privilegio, han sido “bloggers” de The Huffington Post. Después de este evento,
 Arianna se empinó como una de las mujeres más poderosas del mundo, y su diario electrónico en la lista de los medios
 más influyentes. ¿Cuál ha sido el secreto de su éxito?. Ni la misma Arianna lo tiene claro. En una entrevista hace un par
 de semanas, respondiendo la pregunta anterior, ella señalaba: “ha sido un conjunto de cosas, no tengo claro realmente
 cuál ha sido la más importante. Hay que reconocer que la suerte ha estado conmigo y siempre es bueno contar con ella.
 Además el diario comenzó su circulación justo en la mitad de una tormenta perfecta para las noticias políticas y para un
 diario como éste, como fue cuando el Presidente Bush fue cuestionado por no encontrar armas de destrucción masiva en
 Irak”.
 El pasado 9 de Febrero de 2011, el éxito de The Huffington Post se ve coronado por la noticia que invadió los diferentes
 diarios del mundo: “AOL, el gigante del periodismo digital, adquiere The Huffington Post por mas de US$ 315 millones,
 creando una alianza sin precedentes en el periodismo online”.
 A Ud. se le pide responder lo siguiente:
 1. ¿Cuál es el modelo de rentabilidad (entiéndase modelo para la obtención de retornos en el mediano y largo plazo o
 modelo de negocio) que le permite a The Huffington Post alcanzar ventajas competitivas sustentables?. Para
 responder esta pregunta, específicamente se pide que responda:
 • ¿Cuál es la propuesta de valor que Huffington Post entrega al Lector, o dicho de otra forma, qué valor
 entrega Huffington Post al lector, que hace que este esté dispuesto a preferir y a pagar por lo que ofrece la
 Compañía?
 • ¿Cuál es la forma en cómo la Compañía construye su retorno en el largo plazo, o dicho de otra forma, de
 qué manera la Compañía es capaz de alcanzar ventajas competitivas sustentables?
 • ¿Qué Recursos y Procesos/Capacidades son Estratégicos y Claves en la Compañía?.
 2. ¿Por qué debiéramos estar de acuerdo con la afirmación hecha por el analista: “The Huffington Post, sin lugar a
 dudas, le ha propinado a la prensa escrita tradicional un duro golpe del cual no le será fácil salir?. Argumente con
 precisión desde el punto de vista estratégico.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 199

[pág. 200]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2016 | pregunta 4
 Convocatoria 1 | página original 191 | Modelos productivos y ventaja
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 4
 El Nuevo Escenario en la Industria del Retail de Ropa
 Como muchos sectores de consumo masivo, el sector del retail de ropa 1 ha presentado en el último tiempo
 dificultades. Los altos costos de la infraestructura y las cada vez más agresivas liquidaciones de los stocks al
 final de las temporadas, explican una parte importante de lo anterior. Sin embargo, es un sector que sigue en
 movimiento.
 Al interior del sector de venta de ropa al detalle, se pueden distinguir tres tipos de competidores. Un grupo de
 ellos, el mayoritario, ha seguido un modelo de negocio que podríamos denominar T7radicional, representado
 por grandes tiendas de departamento cuyo ámbito de operación es de alcance local (operan principalmente en
 un país o un grupo muy acotado de países). Por otro parte, encontramos a empresas muy innovadoras, con una
 buena propuesta de valor asociada a productos considerados premium, que han desarrollado un modelo de
 negocio que podríamos definir como No Tradicional. Son empresas cuya escala de operación es global, con
 alta adaptación al consumidor local de cada uno de los países en donde operen. Finalmente, y aunque en menor
 número, en este mercado también se encuentra a un tipo de competidores que son verdaderas “boutiques
 locales”, las cuales poseen cadenas de tiendas propias en un determinado país, aunque una parte importante de
 su negocio es distribuida a través de grandes tiendas locales tradicionales.
 El Modelo Tradicional
 Ampliamente difundido y adoptado por las grandes tiendas y casas comerciales en el mercado de la ropa, es
 un modelo que hasta ahora ha sido exitoso. No obstante hoy en día enfrenta importantes amenazas. Es un
 modelo ampliamente conocido. Primero, se analizan tendencias de la moda y lo que se llevará en la próxima
 temporada; luego se diseñan las colecciones a encargar; a continuación se ponen las órdenes de pedido para la
 fabricación generalmente en países como China. Son grandes lotes de pedido que se encargan a proveedores
 globales, lo que hace aprovechar al máximo las economías de escala en el proceso de compra. Con el pedido
 ya en el país donde se efectuará la venta, se llenan las estanterías de todos los locales de la respectiva cadena.
 Luego comienza el proceso de ventas, y finalmente, hacia el término de la temporada, se realizan diferentes
 tipos de liquidaciones de stocks sobrantes para salir de los remanentes no vendidos y reducir al mínimo las
 pérdidas por inventarios. Como se puede apreciar, es un modelo centrado fundamentalmente en una buena
 decisión de qué comprar y en una buena negociación de precios al realizar la compra del stock, para lo cual se
 aprovechan al máximo las economías de escala que genera el gran volumen comprado. Complementa a lo
 anterior, la continua gestión que se va haciendo del precio a medida que transcurre la temporada, de manera
 de agotar los stocks al final del período. Es un modelo que en general va reduciendo el margen a lo largo de la
 temporada y requiere de entre 6 y 9 meses desde la orden de pedido y hasta el llenado de estanterías para la
 venta. Empresas como Macy's en USA y Falabella en Chile, Perú y Colombia, son exponentes de este tipo de
 modelo de negocio.
 El Modelo No Tradicional
 Desde hace un tiempo, algunos competidores han estado cambiando la forma de hacer el negocio. En efecto,
 el modelo de negocio en este caso es diferente. Primero, los competidores toman rápidamente una decisión de
 fabricación de algún modelo de ropa que se quiere introducir o de alguna tendencia que se espera tenga éxito;
 luego se manda a fabricar con mucha rapidez, a proveedores geográficamente cercanos al lugar en donde se
 generará la demanda, un lote “acotado” de prendas de vestir, de no más del 5% de lo que se esperaría vender
 en la temporada. En poco tiempo el pedido está confeccionado y se seleccionan los puntos de venta en donde
 ofrecer el producto. Se pone el pedido a la venta en esas ubicaciones; luego se analiza la velocidad de venta
 de los diferentes tipos de prendas introducidas. Si el resultado se evalúa como satisfactorio, se manda a fabricar
 en grandes cantidades para distribución en todas las tiendas de la cadena en el mundo o en la región,
 1 Para los efectos de este caso, por industria de retail de ropa vamos a entender a aquella compuesta por tiendas de
 departamento y otras tiendas menores de distribución al detalle de todo tipo de ropa, más las marcas cuyos productos se
 distribuyen por medio de los canales anteriores. No considera negocios complementarios o adicionales como crédito,
 seguro, etc. sino que solo la venta de prendas de vestir al detalle.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 200

[pág. 201]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2016 | pregunta 4
 Convocatoria 1 | página original 192 | Modelos productivos y ventaja
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 introduciendo las particularidades de los distintos consumidores en las diferentes localidades en donde opera
 la empresa. Es un modelo que permite realizar variantes de diseño lo que permite introducir modelos diferentes
 en una misma temporada. Si por el contrario, el resultado del lote original encargado en producción no es
 exitoso, se desecha el ítem fabricado y no se pone a la venta en la temporada. Rápidamente se manda a producir
 otro tipo de ropa con otro diseño y el ciclo comercial comienza nuevamente, donde se requiere aún más rapidez
 que con el pedido original, Así, una logística eficiente para actuar, mezclando con eficiencia lo global de las
 decisiones comerciales con la ejecución de estas decisiones en los mercados locales, marcarán la diferencia
 entre competidores y se traducirá en ofertas atractivas, variadas y dinámicas para los clientes. En este modelo,
 sólo transcurren 3 semanas entre la puesta del pedido y el llenado de las estanterías para ver si el producto
 tiene o no éxito. Empresas como HézM, Forever 21 y Zara, son exponentes de este tipo de modelo de negocios.
 Las Boutiques Locales
 Aunque en un número significativamente menor que los actores en los dos modelos anteriores, las boutiques
 locales son competidores locales (en un solo país), de menor tamaño, los cuales han construido algún grado de
 diferenciación en relación a su marca, y dada la alta dependencia de su venta de las grandes cadenas de tiendas
 por departamento, han seguido un modelo del tipo tradicional. Estos competidores distribuyen un porcentaje
 muy importante de su venta a través de grandes tiendas de departamento que siguen el modelo tradicional. Se
 estima que sobre el 70% de su venta sale por el canal de grandes tiendas, canal que representa del orden del
 15% de su margen. Empresas como Saville Raw y Trial en Chile, son claros exponentes de este tipo de
 competidor.
 No está claro qué modelo de negocio primará o si podrán coexistir todos ellos. Por otra parte, las boutiques
 locales están enfrentando una complicada situación y gran incertidumbre, al no conocer si las grandes tiendas
 locales se mantendrán en el modelo que hasta ahora les ha dado el éxito, o si definitivamente migrarán hacia
 el esquema no tradicional.
 PREGUNTAS
 1) ¿Qué elementos crean valor en el modelo de negocio tradicional y en el no tradicional? Responda esta
 pregunta utilizando como referencia, los distintos componentes que conforman el indicador financiero
 conocido como Valor Actual Neto (VAN). Para cada uno de los modelos señale tres elementos concretos
 que permiten crear valor. No olvide utilizar en su respuesta al VAN como medida de creación de valor.
 2) Considerando ahora la situación de una “Boutique Local”, ¿Qué elementos determinarán si este competidor
 decidirá mantenerse en el Modelo Tradicional o cambiarse al Modelo No Tradicional? Señale y explique
 tres elementos. Sea breve y preciso en su respuesta. —
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 201

[pág. 202]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2013 | pregunta 4
 Convocatoria 2 | página original 132 | Posicionamiento y eficiencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 PREGUNTA Nº 4
 La industria aérea ha tenido en los últimos años una particular habilidad para “drenar” los bolsillos de sus bien
 intencionados inversionistas. Balances con altos niveles de endeudamiento y quiebras han sido y siguen siendo la
 norma en esta industria. Los significativos costos laborales y el alto precio del petróleo, entre otros, han causado
 estragos en los costos del sector.
 Sin embargo, hay algunas líneas aéreas que dentro del sombrío panorama anterior, han generado sólidos resultados
 trimestre a trimestre. Dos ejemplos de ellas son Alaska Airways y Copa Airlines. Cada una de estas aerolíneas ha sido
 sistemáticamente rentable en los últimos años.
 Aspectos Comunes en sus Estrategias
 Si se revisan las estrategias de estas dos líneas aéreas, se encuentra que hay dos aspectos que son comunes a ellas:
 Alcance Regional y Flota Uniforme.
 - Alcance Regional: ninguna de las dos líneas aéreas intenta competir en gran escala internacional, sino que se
 enfocan en regiones específicas. Alaska Airways, por ejemplo, se focaliza en la costa oeste de Estados Unidos,
 y naturalmente en Alaska y Hawaii, mientras que Copa Airlines lo hace en el continente americano, más
 específicamente entre ciudades de Centro y Sudamérica, y conexiones de ellas con las principales ciudades de
 Estados Unidos.
 - Flota Uniforme: siguiendo las prácticas de la pionera Southwest, las dos aerolíneas poseen flotas de aviones
 uniformes (mismo modelo y mismo proveedor), lo cual tiene efectos en los costos de mantención, en la
 gestión de inventarios y en la eficiencia en el uso del combustible. Con una flota estandarizada, se reducen los
 niveles de inventarios de piezas y partes, y se logra una mejor distribución de los stocks en un menor número
 de aeropuertos, con importantes bajas en las inversiones requeridas. La flota uniforme, a su vez, facilita la
 utilización de “hub” o centro de operaciones, en determinados aeropuertos, lo que favorece la coordinación
 entre los flujos de oferta y demanda de pasajeros, permitiendo un uso más eficiente y por tanto más rentable de
 la flota.
 Las Estrategias Individuales
 Sin embargo, y mas allá de las similitudes antes señaladas, estas dos líneas aéreas tienen diferencias estratégicas en la
 forma en como realizan su negocio. En efecto, Alaska Airways es una aerolínea conocida por sus bajas tarifas. Por
 ello la atención está puesta en el control de costos, y en particular en el costo por pasajero, indicador que constituye el
 principal driver de su resultado. Así, en la actualidad, Alaska Airways es una de las líneas aéreas más eficientes del
 mundo, con estructuras de costos menores que sus competidores relevantes. La posición anterior es producto de varios
 factores: una flota de aviones nueva (promedio de antigüedad de 4,6 años) y estandarizada en torno al Boeing 737, el
 avión más eficiente en el consumo de combustible, buenas condiciones de financiamiento, una estructura de capital
 conservadora que le genera bajo gasto en intereses, eficientes procesos de compra de petróleo, estructura
 organizacional liviana y control de costos. Como se ve, es una combinación de elementos lo que le permite tener el
 menor costo por pasajero transportado de la región en donde compite, materializando así una ventaja competitiva que
 la acompaña desde hace años, y que le ha dado muy buenos niveles de éxito en comparación con los grandes actores de
 la industria aérea en Estados Unidos y Europa.
 Por su parte Copa Airlines es una aerolínea que ha estado en este negocio por 66 años, y que llega en la actualidad a
 29 países. Su base de operación está ubicada en Panamá, ciudad que cuenta con una ubicación geográfica privilegiada
 por estar en el punto medio de América. La compañía ha logrado desarrollar en la actualidad una estrategia global, que
 en palabras de su Presidente Ejecutivo, le permite entregar “la más completa y más conveniente opción para viajar
 dentro de Centro y Sudamérica y sus conexiones con las principales ciudades de Estados Unidos”. Para lograr esto,
 Copa Airlines ha optimizado los flujos de sus operaciones desde su base de Panamá, lugar en el que confluyen viajeros
 desde diferentes ciudades y desde donde salen estos a las distintas ciudades, con un nivel de coordinación tal, que en
 promedio la espera de un pasajero para tomar una conexión es de 50 minutos, con lo que se minimiza el tiempo de los
 aviones en tierra optimizándose el tamaño de la flota, y la velocidad con que rotan sus recursos. Todo lo anterior
 permite optimizar el uso de recursos, alcanzar buenos niveles de eficiencia y optimizar la velocidad de generación de
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 202

[pág. 203]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2013 | pregunta 4
 Convocatoria 2 | página original 133 | Posicionamiento y eficiencia
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 sus márgenes. Es justamente esta eficiencia la que le permite a esta aerolínea ser, para muchos, la más conveniente
 (buenas opciones de vuelos a los mejores precios) alternativa para viajar dentro de América.
 PREGUNTAS
 1) ¿Son distintas las Propuestas de Valor de Alaska Airlines y de Copa Airlines? ¿Sí o No? Argumente con precisión,
 explicitando la(s) Propuesta(s) de Valor.
 2) ¿Son distintos los modelos de negocio de Alaska Airlines y de Copa Airlines? En particular, responda la pregunta
 desde la perspectiva del modelo de rentabilidad (o modelo de generación de utilidades) de cada aerolínea, y de las áreas
 claves y/o recursos claves.
 3) ¿Cuál de estos dos competidores (Alaska o Copa) diría Ud. tiene la estrategia más sustentable? ¿Por qué? Justifique
 utilizando algún modelo que conozca.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 203

[pág. 204]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2023 | pregunta 4
 Convocatoria 2 | página original 396 | Sostenibilidad y modelo de negocio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 PREGUNTA Nº 4
 Farmacias Fracción
 Fracción es la primera farmacia digital lanzada en Chile. Fundada en 2018, vende medicamentos fraccionados,
 para que las personas puedan comprar las dosis exactas recetadas por su médico evitando así el gasto en cajas
 completas. Su objetivo es acercar medicamentos a bajo costo a todo el país, sobre todo en localidades aisladas
 que no cuentan con farmacias. En la actualidad, Fracción ofrece más de 1.400 medicamentos, que se pueden
 buscar por marca o por principio activo. Tiene despacho a domicilio en todo Chile con plazos de entrega entre 24
 y 72 horas. En 2022, sus ventas aumentaron 10 veces en relación a 2021, y los pedidos 8 veces. Hoy cuenta con
 más de 10 mil clientes activos en todo el país.
 El sitio web de Fracción permite enviar medicamentos a nivel nacional, lo que se espera reforzar con la apertura
 de un local en cada región, medida que acortará tiempos de entrega y abaratará el servicio. Así mismo, Fracción
 está implementando farmacias móviles a través de convenios con municipalidades y centros comunitarios, además
 de contar con vehículos que llevan el local físicamente hasta comunas donde no hay ninguna farmacia. Otra
 medida que está próxima a lanzarse es el plan de suscripción, pensado para pacientes crónicos que toman
 medicamentos todos los meses. Para ellos se contempla un plan de entrega mensual en la casa del paciente, sin
 costos adicionales a los del fármaco. Todo lo anterior ayudará a Fracción a expandir su negocio.
 Los laboratorios de los que se abastece Fracción son los mismos que proveen a las grandes cadenas de farmacias,
 pero Fracción ofrece una menor variedad de medicamentos que las grandes cadenas y a un precio más bajo. Los
 menores precios obedecen a tres factores: la venta fraccionada de medicamentos permitida y regulada por la Ley
 de Fármacos 1; la ley de Cenabast que permite abastecerse de productos de manera conjunta con el Estado de
 Chile que actúa como intermediario aprovechando así el poder de compra que se genera, aunque viendo limitado
 el precio máximo que Fracción puede cobrar al público por un medicamento; y, por los menores costos de
 operación y comercialización que tiene el modelo de Fracción.
 Las potencialidades del modelo de Fracción
 La pandemia permitió a la compañía validar su modelo de negocio el que se visualiza como de gran potencial. En
 efecto, Fracción es vista como una parte de una cadena que puede llegar a ser mucho más robusta. Como ejemplo
 considérese una eventual integración con la telemedicina que creció fuertemente con la pandemia.
 Teniendo en vista lo anterior, la empresa ha realizado importantes convenios con Microsoft por sus servidores
 Cloud en la plataforma Azure, lo que le ha permitido contar con esta tecnología desde sus inicios, lo cual fue
 fundamental para afrontar los desafíos de la pandemia y responder a la alta demanda de los clientes que
 comenzaron a comprar sus medicamentos en línea.
 La distribución de medicamentos en Chile
 El mercado de distribución de medicamentos en Chile bordea los 2.000 millones de dólares en ventas al cierre de
 2022. Es un mercado altamente concentrado; las tres principales cadenas de distribución de medicamentos
 (Ahumada, Cruz Verde y Salcobrand) representan el 60% de las farmacias existentes en el país. Al mismo tiempo,
 Chile es reconocido como el país en donde los consumidores invierten más en fármacos de marca y es uno de los
 países con los mayores precios de medicamentos.
 El año 2022, el 52% del valor de las compras de medicamentos en Chile se hizo en cadenas de farmacias, el 12%
 en farmacias que no son de cadenas, y el resto, en compras públicas que se destinan a hospitales y centros de
 atención, incluyendo además las compras realizadas por instituciones privadas como clínicas. Las cadenas de
 farmacias Cruz Verde, Salcobrand y Ahumada pagan en promedio un 70% de mayor precio por sus compras de
 medicamentos a los laboratorios, en relación a lo que paga el sector público, y un 60% más que los precios
 pagados por compradores privados institucionales (por ejemplo, clínicas).
 La pandemia Covid-19 ayudó al desarrollo del sector. En efecto, si bien detuvo en parte el desarrollo de locales
 de las grandes cadenas de farmacias, permitió potenciar y modernizar los canales online. Otros factores que han
 ayudado al crecimiento de este sector son el aumento de las enfermedades crónicas (hipertensión, diabetes,
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 204

[pág. 205]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2023 | pregunta 4
 Convocatoria 2 | página original 397 | Sostenibilidad y modelo de negocio
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 9
 enfermedades cardiovasculares y cáncer) a nivel mundial, la aparición de nuevas enfermedades, mejoras y
 sofisticaciones en las estrategias de marketing, el uso de nuevos modelos comerciales y el aumento de los puntos
 de venta. Todos estos factores se consideran además como potenciales motores para el crecimiento futuro de la
 industria.
 Las cadenas de farmacias tradicionales
 Son tres las cadenas de farmacias que han dominado hasta ahora el mercado de distribución de medicamentos en
 Chile: Ahumada, Cruz Verde y Salcobrand. Ninguna de ellas ha mostrado interés por replicar lo que hace
 Fracción, pese a que han transcurrido 4 años desde que se promulgaron las leyes antes citadas. Por el contrario,
 todas estas cadenas han intensificado sus estrategias comerciales y de negocios, basadas en la apertura de locales
 que amplíen los puntos de contacto con el cliente (en una misma cuadra se puede encontrar una farmacia de cada
 una de estas tres cadenas), el fortalecimiento de sus líneas de productos por medio de aumentar tanto la amplitud
 como la profundidad de fármacos ofrecidos para diferentes dolencias, y el desarrollo de productos
 complementarios que han convertido a las farmacias de cadenas en verdaderas tiendas de conveniencia.
 Los altos costos comerciales y operacionales asociados a la estrategia anterior se han enfrentado con políticas de
 precios que han posicionado a Chile como uno de los países con mayores precios de medicamentos, aunque
 matizados con permanentes ofertas, clubes de clientes frecuentes y convenios con diferentes instituciones que
 reducen el precio final al cliente.
 Cabe señalar que la estrategia anterior le ha reportado hasta ahora a las grandes cadenas, éxito financiero y
 también algunos cuestionamientos reputacionales. Pese a lo anterior, no ha sido ésta la estrategia seguida por
 compradores institucionales (clínicas, hospitales, etc.), quienes privilegian el tener un buen precio al cliente final,
 aunque ello signifique sacrificar variedad de productos.
 El futuro de la Industria
 Expertos señalan que existen tendencias claras que determinarán la industria en el futuro: la consolidación del
 comercio digital; el fortalecimiento de la relación con los clientes; el monitoreo de información médica de los
 clientes en la nube; y la sofisticación de los niveles de servicio y de postventa demandados por los clientes. Las
 tendencias anteriores han hecho surgir actores internacionales que están desarrollando activamente este negocio.
 Cabe destacar el caso de Amazon con su servicio “Pill Pack by Amazon Pharmacy”, con el cual aspira convertirse
 en la mayor farmacia del mundo: medicamentos fraccionados, en las dosis justas por día, y entregados en la
 frecuencia que el tratamiento del paciente (cliente) requiere. Como se aprecia, un nivel de servicio y de
 integración llevado al extremo.
 Basado únicamente en la información provista en el caso, responda las preguntas que se le formulan a
 continuación:
 PREGUNTAS
 1) Analistas de la industria coinciden en señalar lo poco sostenible que es el modelo de negocio de Fracción.
 ¿De qué forma podría Fracción robustecer su modelo de negocio de manera de hacerlo más sostenible? Se
 pide que Ud. entregue las tres principales medidas concretas que fortalecerían el modelo de negocio de
 Fracción desde el punto de vista de la sostenibilidad del mismo, indicando el por qué cada una de las medidas
 señaladas hace que el modelo sea más sostenible.
 2) ¿Por qué las cadenas de farmacia tradicionales no siguieron la estrategia de negocios implementada por
 Fracción? Indique, entregando los fundamentos correspondientes, los tres principales argumentos estratégicos
 que pueden explicar lo anterior.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 205

[pág. 206]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2025 | pregunta 3
 Convocatoria 1 | página original 431 | Transformación de industria y calidad estratégica
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N3
 Macy's y su nueva Estrategia para reposicionarse en el sector de Multitiendas
 No corren buenos tiempos para Macy's. La tradicional mutitienda de Estados Unidos, acaba de informar el
 cierre de 150 tiendas adicionales a las cerradas hasta ahora en el país del norte, y el despido de cerca de 2.350
 empleados (3,5% de su plantilla). Pese a los esfuerzos hechos por la compañía, los resultados de la estrategia
 implementada por su nuevo CEO no han dado los resultados esperados. Macy's cerró el primer semestre de
 2024 con resultados económicos inferiores al mismo período del año anterior en cuanto a facturación y un
 ebitda en similar nivel. En los últimos 9 años el valor de su acción ha caído un 75%. Hoy cuenta con 722
 tiendas en todo Estados Unidos, habiendo cerrado casi 300 en los últimos seis años.
 Macy”'s, al igual que otras multitiendas, señaló que estos resultados se deben principalmente a que su mercado
 objetivo, el consumidor estadounidense de clase media, privilegió el gasto en alimentación, productos básicos
 y servicios frente a la incertidumbre económica en Estados Unidos, lo que se ha venido prolongando desde
 después de la pandemia. Con el objeto de avanzar en diferenciación, la compañía ha ido incorporando
 productos de marca propia, líneas de productos de lujo y promociones agresivas. Lo cierto es que ello sólo
 ha ayudado a intensificar el nivel de competencia en la industria.
 El sector de multitiendas en Estados Unidos
 Una multitienda es una gran tienda minorista que incluye varias tiendas en su interior, cada una orientada a
 diferentes productos, mercados, y/o clientes (vestuario, electrónica, jóvenes, hogar, etc.). Vende al cliente
 final, y su gestión se realiza de forma centralizada. Son tiendas que suelen tener un tamaño superior a los
 1.500 metros cuadrados, de manera de entregar comodidad al cliente y al mismo tiempo mostrar diferentes
 experiencias que complementen a los conceptos de tiendas que incorporan en su interior. Las multitiendas
 operan, ya sea en el interior de centros comerciales (malls) o están d1rectamente ubicadas hacia la calle en
 avenidas de alto tráfico.
 En los últimos años, el sector de tiendas minoristas en Estados Unidos se ha destacado por el auge de tiendas
 como Amazon, la creciente fuerza de cadenas de descuentos como TJ Maxx y las marcas online.
 Históricamente, la competencia ha sido intensa entre las diversas cadenas tradicionales, especialmente
 Macy's, Nordstrom y JCPenney. Estas últimas tres son cadenas orientadas a consumidores entre 45 y 60
 años, de clase media, y de hábitos más bien tradicionales. Son consumidores que buscan la presencialidad
 para realizar sus compras y el vivir la experiencia al adquirir los productos que requieren. Si bien no son un
 segmento que se sienta atraído por el comercio online, algunos de estos consumidores han comenzado a
 emigrar hacia el comercio electrónico reconociendo las bondades y comodidad que ello significa.
 Según datos de Credit Suisse, actualmente hay unos 1.100 centro comerciales (malls) en EE.UU., y el 25%
 de ellos estaría en riesgo de cerrar en los próximos cinco años. En el sector de multitiendas, ya se han cerrado
 alrededor de 5.300 tiendas, incluyendo el cierre de varios puntos de venta de gigantes minoristas como Sears,
 Macy”'s, JCPenney, RadioShack y Kmart.
 Las multitiendas requieren una inversión importante de recursos para alcanzar volúmenes que permitan
 Viabilizar económicamente su negocio. Las altas inversiones se explican por infraestructura, recursos
 tecnológicos, y redes logísticas robustas. Además, requieren de inversiones en marketing y posicionamiento
 de la marca. Debido a sus altos costos operativos, requieren lograr economías de escala y establecer una red
 de proveedores. Por ello resulta fundamental lograr tamaño y volumen para ser competitivos en esta industria.
 De esta forma, si las ventas no crecen, se deteriora la posición competitiva de estas cadenas al no alcanzar
 volúmenes mínimos eficientes de operación.
 Cambios en las preferencias de los consumidores
 Son varios los cambios que se están dando en el sector de multiendas en Estados Unidos. Quizás uno de los
 factores más relevantes que explica la evolución de esta industria se encuentra en el desarrollo del comercio
 electrónico, que ha traído la incorporación al sector de nuevos consumidores que valoran un fácil acceso a
 una gran variedad de opciones, una compra más fácil y cómoda, disponer de información de precios y
 comparaciones en línea, todos atributos que les brinda el comercio online, y que les da mayor poder en la
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 206

[pág. 207]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2025 | pregunta 3
 Convocatoria 1 | página original 432 | Transformación de industria y calidad estratégica
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 toma de decisiones. Estos nuevos consumidores son distintos a los tradicionales que históricamente han
 comprado en multitiendas, ya que poseen hábitos de compra distintos, son más exigentes y sensibles al precio,
 buscan ofertas y descuentos manteniendo el nivel de servicio, lo que obliga a las empresas a ser competitivas
 en términos de facilidad, flexibilidad, precios y promociones. Así mismo, existe un flujo de consumidores
 tradicionales que están emigrando hacia la compra online por las comodidades que provee. Diversos analistas
 de la industria concuerdan de que son transformaciones que llegaron para quedarse. Hay tres tendencias en
 el sector que son claras: -
 - Aumento de las compras online: generado principalmente por la irrupción de Amazon, lo que
 provocó que todas las empresas mejorarán sus procesos de logística y personalización. Comprar
 online se há convertido en una experiencia social y es cada vez más masivo. Ha atraído a segmentos
 de clientes que hasta ahora no participaban de las compras en multitiendas, como es el caso de los
 jóvenes.
 - Búsqueda de mejor experiencia en tienda y al interior de centros comerciales: los centros
 comerciales y sus tiendas, en especial los competidores más tradicionales, han reaccionado buscando
 mejorar la experiencia de los clientes en la misma tienda y en el centro comercial, incluyendo
 espacios de entretenimiento como cines, cafeterías, espectáculos y juegos para niños. Cada vez son
 malls más pequeños orientados a segmentos específicos, y están pasando de ser lugares de compraa
 ser un mix de esparcimiento, entretención y compras.
 - La tienda sigue siendo la opción más conveniente para tipos de productos específicos como
 productos del hogar y de alto involucramiento: la tienda se utiliza muchas veces como showroom
 para posteriormente comprar presencial u online. Una situación similar viven otras categorías cuya
 compra requiere alto involucramiento por parte del cliente.
 La estrategia de Macy's para impulsar su futuro
 El nuevo CEO de Macy's, Tony Spring, siendo fiel a lo que ha sido hasta ahora la empresay el tipo de cliente
 al cual se orienta, anunció un nuevo plan estratégico, el cual se enfoca en lo que ha sido esencial hasta ahora
 de la empresa: presencialidad, foco en clientes tradicionales, manteniendo su negocio online sin desarrollos
 adicionales, considerando a los clientes tradicionales a los cuales se orienta. Las principales directrices de la
 nueva estrategia son las siguientes:
 - Expansión hacia afuera de los centros comerciales, apartándose del formato de grandes tiendas, y
 emigrando a formatos más pequeños.
 - Una mayor orientación al desarrollo de outlet.
 - — Incrementar la apuesta por el lujo incorporando nuevas marcas dentro de esta categoría en tiendas
 seleccionadas de la cadena dado el nivel aspiraciones del segmento tradicional que frecuenta la
 tienda.
 - Mejorar la imagen de la tienda, y robustecer la logística con importantes inversiones.
 - Modernización de la infraestructura de sus tiendas, mejorando la experiencia al interior de ella.
 En complemento a lo anterior, Macy”s planea abrir 10 nuevas tiendas de su marca outlet, Macy”s Backstage,
 para beneficiar a los productos fuera de temporada, en centros comerciales más pequeños y cercanos, en
 condiciones de precios muy favorables.
 Preguntas:
 1. Considere como industria al sector de multitiendas de Estados Unidos. ¿Cómo afectan a los
 competidores tradicionalmente establecidos tipo Macy's, desde la perspectiva de la generación y
 captura de valor, y desde la óptica del riesgo del negocio, los cambios que están ocurriendo en la
 estructura competitiva de este sector?
 2. ¿Quéaspectos positivos y negativos tiene la nueva estrategia de Macy's impulsada por su nuevo CEO?
 Al considerar el conjunto de su análisis, ¿diría Ud. que la nueva estrategia de Macys's es buena o no?
 ¿Por qué?
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 207

[pág. 208]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2022 | pregunta 4
 Convocatoria 1 | página original 359 | VRIO y diversificación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 7
 PREGUNTA Nº4
 La reinvención del Cirque Du Soleil
 En junio de 2020, la empresa de espectáculos más conocida del mundo, Cirque du Soleil, se
 declaró en quiebra, al mismo tiempo que los principales inversionistas de la compañía, presentaban
 un plan de reestructuración para enfrentar las dificultades financieras agudizadas por la aparición de la
 pandemia de Covid-19. A partir de Marzo de 2022, el circo regresa en gloria y majestad con más de 10
 espectáculos y muchos desafíos.
 Cirque du Soleil es un espectáculo circense sin animales que incluye artistas, payasos, acróbatas y gimnastas,
 creando una mezcla de actos de danza, teatro y música. No ofrece simples espectáculos circenses, ofrece
 experiencias teatrales que capturan la imaginación, deseos y recuerdos de sus espectadores. Su objetivo es
 entregar entretenimiento, innovación e invocar la imaginación. Es una experiencia inolvidable por donde
 quiera que se mire.
 El centro del espectáculo no es único, es múltiple y diverso, y recae en los propios artistas. Números
 simultáneos que sorprenden y mantienen al espectador durante las dos horas que dura el espectáculo
 completamente sintonizado con la escena.
 Su Estrategia
 En palabras simples se trata de gestionar de una forma no tradicional un negocio de espectáculo, combinando
 expresión artística y libertad para los artistas situándolos a ellos como centro del entretenimiento. Todo con
 un esquema muy estudiado y disciplinado que hace que cualquier espectáculo donde quiera que se exhiba e
 independiente de los artistas que actúen, será siempre el mismo ante los ojos del espectador.
 El circo busca diferenciarse en los detalles de sus montajes y en la constante innovación que ofrece a través de
 espectáculos de vanguardia, con tecnología de punta y una permanente capacidad de reinvención que lo sitúa
 como “El Mejor Circo del Mundo”.
 Entre sus principales prácticas de gestión está el reclutamiento de artistas a nivel mundial, los cuales pueden
 ser desde personas que ofrecen espectáculos callejeros, hasta medallistas olímpicos. Hay una constante
 búsqueda de gente creativa a todo nivel. Se estimula un buen clima laboral en el cual el personal se siente muy
 orgulloso de trabajar en la empresa, donde se promueven sus habilidades, personalidad y creatividad,
 haciéndoles sentir que son parte de todo el espectáculo. Se privilegia la diversidad cultural, de idiosincrasias y
 costumbres. Se tienen condiciones de trabajo ejemplares para todos los empleados (transporte, vivienda,
 comida, etc.), con una importante inversión en capacitación para tener a los mejores “maestros” en cada
 especialidad. Se protege el conocimiento mediante la transmisión de competencias entre los propios integrantes
 de la organización. La compañía se preocupa del cuidado y manejo de las lesiones de los artistas; de la rotación
 de ellos entre los diferentes espectáculos, e incluso cambiar los espectáculos.
 Desde su creación hace 36 años, Cirque du Soleil se orientó a un público selecto compuesto por familias de
 alto poder adquisitivo capaces de pagar un nivel de precios superior por un espectáculo de la sofisticación que
 ofrecía Cirque du Soleil. Sin embargo, la pandemia lo cambio todo, y de la noche a la mañana, el público
 desapareció de sus teatros y carpas, con lo que su principal fuente de ingresos, el público en vivo en el
 espectáculo, se redujo a cero.
 La Crisis de Cirque du Soleil
 El presidente y consejero delegado de Cirque du Soleil, Daniel Lamarre, declaró que “durante los pasados 36
 años, Cirque du Soleil ha sido una organización muy exitosa y rentable. Sin embargo, sin ingresos desde la
 pandemia nos hemos visto forzados a cerrar”.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 208

[pág. 209]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | enero 2022 | pregunta 4
 Convocatoria 1 | página original 360 | VRIO y diversificación
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 8
 Hasta la aparición de Covid-19 la compañía operaba 44 espectáculos en todo el mundo. El cierre de sus
 espectáculos implicó el despido de unas 4.680 personas, 95% de ellos directamente relacionados con el
 espectáculo (artistas la mayoría, músicos, cantantes e iluminadores), debido a la cancelación de sus espectáculos.
 En 2019, el Circo generó ganancias por 155 millones de dólares. En 2020, sin ganancias ni caja, y con una deuda
 de unos 900 millones de dólares, por primera vez en su historia el circo enfrentó la quiebra de la mano de un
 profundo plan de reestructuración financiera.
 El renacer del Cirque de Soleil.
 El último trimestre de 2021 y el inicio del 2022 presentaron un nuevo panorama para la compañía. En efecto,
 recientemente Cirque du Soleil ha iniciado una campaña de promoción para anunciar su regreso en todo el
 mundo. Ya ha retomado siete espectáculos fijos en Las Vegas, otro en Riviera Maya y la gira del espectáculo
 “Alegría”. Además, ha estrenado un montaje nuevo en Orlando y en enero del 2022 presentará el espectáculo
 “Luzia” en la sala Royal Albert Hall de Londres. Pero no será hasta marzo del año 2022 cuando vuelva a
 levantar su emblemática carpa itinerante en Europa, y lo hará por primera vez en Barcelona con Luzia, que se
 trasladará en julio a Alicante y en noviembre a Madrid. La balanza parece haberse invertido de nuevo: desde
 éxito a la quiebra en tres meses y de la quiebra otra vez al éxito en menos de un año.
 Son muchas las preguntas que deja el caso vivido por Cirque du Soleil. Aunque quizás la más importante de
 todas tiene que ver con cómo evitar volver a vivir lo que la pandemia le enrostró: pese a ser tan único y
 espectacular, no era infalible.
 Preguntas:
 a) ¿Cuáles son las fuentes que generan la Ventaja Competitiva de Cirque Du Soleil? Argumente con
 precisión. En su respuesta se solicita que muestre los diferentes elementos que participan en la creación
 de la Ventaja Competitiva y por qué la hacen sostenible.
 b) Dado el impacto que la pandemia le ha mostrado a Cirque du Soleil, ¿Qué ajustes debiera la compañía
 incorporar en su modelo de negocio de manera de robustecer su posición competitiva, y así evitar a
 futuro el impacto generado en el negocio por eventos como la pandemia vivida? Argumente con
 precisión.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 209

[pág. 210]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2018 | pregunta 4
 Convocatoria 2 | página original 272 | Ventaja de plataforma y respuesta
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 PREGUNTA N* 4
 Uber: cambiando la forma en que se mueve el mundo
 por día en
 Uber es una de las compañías más icónicas de nuestro tiempo y hoy atiende casi 2 millones de viajes
 453 ciudades de 65 países del mundo.
 , crear una
 El servicio es muy fácil de utilizar. Los usuarios solo tienen que bajar la aplicación a sus Smartphones
 se requiere pedir un auto, se presiona un botón
 cuentay entregar información sobre una tarjeta de crédito. Cuando
 muestra autos cercanos disponibles y en cuestión de segundos un
 en la aplicación. Entonces la aplicación
 que está en camino a recoger al usuario. El usuario puede ver el nombre del conductor y su
 conductor indica
 telefónicame nte.
 ranking de calidad (1 a 5), incluso rechazarlo si así quisiera. Ambas partes pueden comunicarse
 en la misma
 Una vez a bordo, el conductor lleva al pasajero a su destino usando un dispositivo GPS incorporado
 también son incorporados en el sistema Uber de tal forma que los
 aplicación Uber. Usuarios frecuentes
 desechar llamadas asociadas a usuarios problemático s. Adicionalme nte, Uber entrega a los
 conductores pueden
 conductores información de las áreas donde es más probable encontrar más demanda.
 10%)
 Uber cobra tarifas de acuerdo al tiempo y la distancia del viaje que típicamente son menores (en promedio
 dinámicos
 que las que cobra un taxi. Sin embargo, de acuerdo al sistema “Surge Price”, algoritmo de precios
 más
 incluido en la aplicación del servicio, cada vez que la demanda supera a la oferfa de autos, Uber cobra tarifas
 las tarifas normales. Para ser transparentes con los usuarios, Uber avisa a
 altas que oscilan entre 1,5 y 1,7 veces
 vez que el sistema Surge Price ha sido activado. La firma suple sus altos requerimient os de
 sus clientes cada
 procesamiento de datos con la contratación de Ph.D.s de los más variados campos.
 Los conductores son contratistas independientes pagados por las carreras realizadas y no son empleados
 permanentes de Uber. De la tarifa que se cobra a un pasajero, un 20% es para Uber y el 80% para el conductor.
 En el
 Los conductores del servicio más común (UberX) debían poseer licencia de manejo y seguro de automóvil.
 caso de los servicios más exclusivos (como UberBlack), la licencia de manejo debía ser profesional.
 Adicionalmente, ningún conductor podía tener antecedentes por mal manejo y se requería que cada conductor
 requisitos,
 tuviese un smartphone. Uber no es dueña de los autos pero aquellos utilizados deben satisfacer ciertos
 a tipos
 como por ejemplo tener menos de 10 años de antigiledad. Actualmente existen servicios asociados
 particulares de autos como UberX (autos más grandes) y UberSUV (autos tipo SUV).
 anticipación.
 Cuando Uber planea entrar a nuevas ciudades, envía a dos equipos de avanzada con seis semanas de
 “conciencia” en el mercado sobre la próxima entrada de Uber. El otro
 Uno de los equipos tiene a su cargo crear
 contratar conductores para el servicio. En esa tarea, este segundo grupo enfatiza los beneficios de
 tiene a cargo
 y también ser capaces
 trabajar en las horas que a ellos les convenga, ganar buen dinero, recibir un pago inmediato,
 de excluir del servicio a los usuarios mal comportados. Adicionalmente, Uber ofrece a los nuevos conductores
 financiamiento para comprar el vehículo o un smartphone en caso que no tuvieran.
 Competencia
 las
 Uber compite con la industria de los taxistas que opera en diversos países. En contra de los taxistas, abundan
 quejas de los usuarios (autos en mal estado, sucios, música a todo volumen y algunos hablan por teléfono mientras
 de las ciudades
 conducen). Adicionalmente, encontrar un taxi no es siempre fácil, en particular en ciertas partes
 son
 y durante la noche, Además, en muchos países las restriceiones y requerimientos regulatorios para ser taxista
 fijado). Eu otros segmentos del mercado, Uber
 elevados (sus precios están regulados y el número de taxistas está
 de transporte
 también enfrenta competencia en servicios de limousines, transportes livianos y otros servicios
 como Lyft, Cabify y Sidecar, Ninguno de estos servicios, sin embargo, tiene la popularidad de Uber.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 210

[pág. 211]
Dirección - versión clara y reordenada
 Dirección de Empresas y Estrategia | agosto 2018 | pregunta 4
 Convocatoria 2 | página original 273 | Ventaja de plataforma y respuesta
 Fuente: C:\Users\User\OneDrive\Documentos\PUC\edg\EDG_E_2009-2026_OCR.pdf
 Regulación y la batalla de dos mundos
 de los taxistas ya estaban
 Pocos meses después de la creación de Uber, los reguladores, políticos y la industria
 En países como Holanda y Corea,
 peleando en su contra y para el 2015 la lucha había alcanzado gran intensidad.
 ilegal. En otros países, los taxistas se han manifestad o con protestas
 Uber ha sido tratado como un servicio de taxis
 contra sus gobiernos por no haber regulado.
 los servicios
 En realidad, la legalidad del negocio de Uber no estaba clara. Aunque existían leyes que regulaban
 no era para nada evidente que Uber en verdad ofrecía ese tipo de servicios. Lo cierto es que
 de taxis y limousines,
 y tanto leyes como reguladores
 la tecnología usada por Uber significaba un cambio radical para esos mercados
 no estaban preparados para lidiar con ella.
 en UberX. Sin
 Una de las críticas contra la firma era que usaba conductores no-profesionales, lo cual era verdad
 respondía que los tests y exámenes a los que se
 embargo, ¿se estaban poniendo vidas en riesgo por ello? Uber
 eran más estrictos que los propios de la industria de taxis. Otra crítica se
 sometían sus conductores muchas veces
 esquemas de cobro de precios que estaban pensados para eliminar la competencia
 refería a que Uber utilizaba
 prefería no
 (taxis). Su CEO respondía que Uber se enfrentaba a una industria protegida y que por definición
 “Nuestro oponente — el gran cartel de los taxistas-
 competir. Aún más, Kalancik (CEO de Uber) llegaría a escribir:
 e influencias para restringir la competencia, reducir las opciones a
 ha usado décadas de contribuciones políticas
 No hay necesidad de decir
 los consumidores y restringir las oportunidades en el mercado de los conductores”.
 que los consumidores que defienden a Uber son muchos. ' -
 te había ganado una
 Al cerrar el año 2015, Uber tenía muchas razones para celebrar. Una de ellas, recientemen
 número de autos
 batalla no menor en Nueva York. Su alcalde, Bill de Blasio había amenazado con limitar el
 lanzó una campañia publicitaria enrostrándo le al alcalde su
 operando con Uber. Como respuesta, Uber no solo
 de la industria de taxis, sino que también introdujo simulacione s en su
 excesiva dependencia económica
 para que las personas pudieran estimar los largos tiempos de espera para conseguir un taxí que se
 aplicación
 , incluyendo
 producirían si la medida de Blasio se aprobase. El apoyo popular a Uber y de numerosas celebridades
 estado de Nueva York no se hicieron esperar. Otras señales del
 autoridades como el Gobernador del mismo
 sugerencias del positivo impacto del desarrollo inmobiliario en ciertas ubicaciones de
 momentum de Uber eran
 sí lo más importante,
 las ciudades, una reducción en los casos de conducir bajo la influencia de alcohol, y tal vez
 Sin embargo, al
 una reducción de hasta 40% en el valor de las licencias para operar un taxi en ciertas ciudades.
 cortes en múltiples países
 mismo tiempo, la compañía continuaba con sus colisiones con los reguladores y con las
 encendiendo ciudades
 alrededor del mundo. Las protestas contra Uber, algunas veces violentas, continuaban
 desde Paris hasta Madrid.
 se le formulan a
 Basado únicamente en la información provista en el caso, responda las preguntas que
 continuación:
 PREGUNTAS
 independientes
 1) Actualmente se está discutiendo la idea de incrementar la regulación hacia los proveedores
 mínimo implicarán que
 de servicios de transporte urbano como Uber, Estos incrementos regulatorios como
 Expertos en estrategias de negocios han
 Uber tendrá que pagar más impuestos que los que paga hoy.
 significará el fin de la capacidad de Uber de obtener rentabilida des
 aseverado que este cambio regulatorio
 el largo plazo ¿Está Ud. de acuerdo con la opinión de estos expertos? Utilice conceptos de
 sobre normales en
 Estrategias de Negocios para justificar su respuesta.
 de las más
 2) Dados los efectos generados por la irrupción de Uber en el mercado del transporte urbano, una
 de taxistas ha decidido desarrollar su propia aplicación para competir con Uber. ¿Cree
 grandes asociaciones
 exitosament e contra Uber?
 Ud. que esta estrategia le permitirá a la mencionada asociación de taxistas competir
 Utilice conceptos de Estrategias de Negocios para justificar su respuesta.
 Enunciado original completo. Respuesta desarrollada al final del manual.
Examen de Grado UC | materia, preguntas y respuestas 211

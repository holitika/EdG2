# Carpeta de estudio · Examen de Grado de Administración

Esta carpeta convierte a una IA (Claude, ChatGPT, Gemini u otra) en tu tutor para el Examen de Grado. Funciona junto con la bitácora EdG, que te dice qué estudiar cada día. Trae todo el material ya convertido a texto: los 3 manuales, las clases de los 6 ramos y los exámenes anteriores.

## Cómo usarla

1. Crea un proyecto en tu IA (o el equivalente: una carpeta de trabajo con archivos adjuntos).
2. Pega el contenido de 00_prompt_inicio.md como instrucción del proyecto (o como primer mensaje si tu IA no tiene instrucciones de proyecto).
3. Sube a ese proyecto los archivos 00 a 05 y la carpeta 10_manuales. Son el núcleo y pesan poco.
4. Las clases (20_clases) y los exámenes anteriores (30_examenes_anteriores) tienen mucho texto. Si tu IA no deja subir todo, sube solo los del ramo que te toca esa semana, o los que pida la sesión del día. El archivo INDICE.md dice qué hay en cada carpeta.
5. Cada día abre la bitácora, mira qué sesión te toca y escribe, por ejemplo: «Sesión DE 1».

## Qué hay en cada archivo

- 00_prompt_inicio.md: instrucciones para la IA. Define cómo enseña y qué comandos entiende.
- 01_temario_y_sesiones.md: las clases de cada ramo y las 45 sesiones de estudio, con sus preguntas asignadas.
- 02_banco_preguntas.csv: las 216 preguntas de exámenes anteriores (marzo 2009 a agosto 2026) con tema y páginas de manual.
- 03_guia_de_examen.md: formato del examen, reglas de aprobación y método para los simulacros.
- 04_temas_mas_preguntados.md: lo que más se repite en cada ramo.
- 05_registro_de_errores.md: plantilla para anotar tus errores y repasarlos al final.
- 10_manuales/: los manuales de Dirección, Finanzas y Marketing, en partes. Cada página lleva su marca [pág. N], que coincide con las páginas del banco de preguntas.
- 20_clases/: las diapositivas de cada ramo en texto (DE, DP, TF, F2, FM, MA). Se pierden los gráficos y las imágenes; el texto y las tablas quedan.
- 30_examenes_anteriores/: los exámenes de grado en texto. Los de 2014 a 2019 y los enunciados 2024 a 2026 eran escaneos: se leyeron con OCR y pueden tener errores de lectura menores. En la bitácora aparecen con extensión .pdf; aquí tienen el mismo nombre pero en .md.

## Comandos útiles

«Sesión TF 3» · «Repaso DF» · «Refuerzo 2» · «Corrige simulacro 2023-08» · «Registro de errores» · «Cronómetro de sección»

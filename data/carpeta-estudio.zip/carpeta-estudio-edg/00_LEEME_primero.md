# Carpeta de estudio · Examen de Grado de Administración

Esta carpeta convierte a una IA (Claude, ChatGPT, Gemini u otra) en tu tutor para el Examen de Grado. Funciona junto con la bitácora EdG, que te dice qué estudiar cada día.

## Cómo usarla

1. Crea un proyecto en tu IA (o el equivalente: una carpeta de trabajo con archivos adjuntos).
2. Sube a ese proyecto todos los archivos de esta carpeta.
3. Sube también tus materiales dentro de la carpeta "material": los PDF de las clases de cada ramo, los manuales de Dirección, Finanzas y Marketing, y los PDF de los exámenes de 2023 a 2026. Mientras más completos, mejor enseña tu tutor. Las instrucciones de qué subir están en material/LEEME.md.
4. Copia el contenido de 00_prompt_inicio.md y pégalo como instrucción del proyecto (o como primer mensaje si tu IA no tiene instrucciones de proyecto).
5. Cada día abre la bitácora, mira qué sesión te toca y escribe, por ejemplo: «Sesión DE 1».

## Qué hay en cada archivo

- 00_prompt_inicio.md: instrucciones para la IA. Define cómo enseña y qué comandos entiende.
- 01_temario_y_sesiones.md: las clases de cada ramo y las 45 sesiones de estudio, con sus preguntas asignadas.
- 02_banco_preguntas.csv: las 216 preguntas de exámenes anteriores (marzo 2009 a agosto 2026) con tema y páginas de manual.
- 03_guia_de_examen.md: formato del examen, reglas de aprobación y método para los simulacros.
- 04_temas_mas_preguntados.md: lo que más se repite en cada ramo.
- 05_registro_de_errores.md: plantilla para anotar tus errores y repasarlos al final.
- material/: aquí van tus PDF.

## Comandos útiles

«Sesión TF 3» · «Repaso DF» · «Refuerzo 2» · «Corrige simulacro 2023-08» · «Registro de errores» · «Cronómetro de sección»

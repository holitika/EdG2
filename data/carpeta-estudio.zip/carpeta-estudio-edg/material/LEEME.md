# Material que debes agregar

Esta carpeta va vacía. Agrega aquí los archivos que tengas y súbelos junto con el resto al proyecto de tu IA:

- Clases por ramo (diapositivas): Dirección de Personas, Dirección de Empresas, Teoría Financiera, Finanzas II, Fundamentos de Marketing y Marketing Analytics. El archivo 01_temario_y_sesiones.md lista los nombres de las clases esperadas.
- Manuales de preguntas y respuestas: Manual de Dirección, Manual de Finanzas y Manual de Marketing. El banco de preguntas (02_banco_preguntas.csv) indica en qué página está cada pregunta y cada respuesta.
- Exámenes completos en PDF para los simulacros: agosto 2023, enero 2024, agosto 2024, enero 2025, agosto 2025, enero 2026 y agosto 2026.

Si te falta algo, la IA te avisará y trabajará desde el programa del curso.

# Registro de errores

Anota cada pregunta que falles. En el repaso final rehaz una por ramo. Pídele a tu IA «Registro de errores» para que te arme la tabla.

| Fecha | Examen | Ramo | Tema | Qué fallé | Regla o concepto correcto |
|---|---|---|---|---|---|
| | | | | | |
